﻿using Dapper;
using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Request.Bundle;
using Models.Contracts.Request.CountryDestination;
using Models.Contracts.Request.Digitalk;
using Models.Contracts.Request.Rate;
using Models.Contracts.Response;
using Models.Database;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class Bundle_DL : IBundle_DL
    {
        private readonly ILogger _logger;
        private readonly IUserAccount_DL _userAccountDL;
        private readonly IApiCall _apiCall;
        private readonly DigitalkConfig _digitalkConfig;
        private readonly ConnectionStrings _dbConnections;

        public Bundle_DL(
            ILogger logger,
            IUserAccount_DL userAccountDL,
            IApiCall apiCall,
            IOptions<DigitalkConfig> digitalkConfig,
            IOptions<ConnectionStrings> dbConnections)
        {
            _dbConnections = dbConnections.Value;
            _logger = logger;
            _userAccountDL = userAccountDL;
            _apiCall = apiCall;
            _digitalkConfig = digitalkConfig.Value;
        }

        /// <summary>
        /// Get Offer Bundles Info
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<IEnumerable<OfferBundleDetails>> GetOfferBundlesInfo(List<string> ids)
        {
            try
            {
                var dt = new DataTable();
                dt.Columns.Add("ID", typeof(Guid));
                ids.ForEach(e =>
                {
                    dt.Rows.Add(Guid.Parse(e));
                });
                var parameters = new DynamicParameters();
                parameters.Add("@Ids", dt.AsTableValuedParameter("GuidList"));

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryAsync<OfferBundleDetails>("tha_offer_info_byids", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetOfferBundlesInfo, Class: Bundle_DL, Parameters: Ids {ids}");
            }
            return null;
        }

        /// <summary>
        /// Is Offer Bundle
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> IsOfferBundle(string id)
        {
            try
            {
                bool isExist = false;
                var parameters = new DynamicParameters();
                parameters.Add("@calling_package_id", id, DbType.String, ParameterDirection.Input);
                parameters.Add("@exist", isExist, DbType.Boolean, ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    var result = await dbConnection.QueryFirstOrDefaultAsync("tha_is_offer_bundle", parameters, commandType: CommandType.StoredProcedure);
                    return parameters.Get<bool>("@exist");
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: IsOfferBundle, Class: Bundle_DL, Parameters: Id {id}");
            }
            return false;
        }

        /// <summary>
        /// Get Bundle By Id
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<Bundles> GetBundleById(string Id, string account)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@calling_package_id", Guid.Parse(Id));
            parameters.Add("@account", account);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                return await dbConnection.QueryFirstOrDefaultAsync<Bundles>("tha_web_get_compatible_bundles_by_id_v1", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        /// <summary>
        /// Set Bundle Auto Renewal
        /// </summary>
        /// <param name="isAutoRenew"></param>
        /// <param name="Msisdn"></param>
        /// <param name="account"></param>
        /// <param name="bundleId"></param>
        /// <param name="isTrial"></param>
        /// <returns></returns>
        public async Task<ValidateResponse> SetBundleAutoRenewal(bool isAutoRenew, string Msisdn, string account, string bundleId, bool isTrial = false)
        {
            var garb = new ValidateResponse();
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@account", account);
                parameter.Add("@msisdn", Msisdn);
                parameter.Add("@is_renew", isAutoRenew);
                parameter.Add("@bundle_id", bundleId);
                parameter.Add("@is_trial", isTrial);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    await dbConnection.ExecuteAsync("tha_update_user_package_renewal_status", parameter, commandType: CommandType.StoredProcedure);
                }

                garb.isValid = true;

            }
            catch (Exception ex)
            {
                garb.isValid = false;
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: SetBundleAutoRenewal, Class: Bundle_DL, Parameters: IsAutoRenew {isAutoRenew}, Msisdn {Msisdn}, Account {account}, BundleId {bundleId}, IsTrial {isTrial}");
            }
            return garb;
        }
        public async Task<ValidateResponse> SetBundleAutoRenewalV2(bool isAutoRenew, string Msisdn, string account, string bundleId, bool isTrial,PaymentMethods paymentMethod,string cardMaskedPAN,string cardInitialTransactionId,string paypalSubscriptionId)
        {
            var garb = new ValidateResponse();
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@account", account);
                parameter.Add("@msisdn", Msisdn);
                parameter.Add("@is_renew", isAutoRenew);
                parameter.Add("@bundle_id", bundleId);
                parameter.Add("@is_trial", isTrial);
                parameter.Add("@paymentMethod", paymentMethod);
                parameter.Add("@cardMaskedPAN", cardMaskedPAN);
                parameter.Add("@cardInitialTransactionId", cardInitialTransactionId);
                parameter.Add("@paypalSubscriptionId", paypalSubscriptionId);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    await dbConnection.ExecuteAsync(StoredProcedures.AutoRenewal.Set, parameter, commandType: CommandType.StoredProcedure);
                }

                garb.isValid = true;

            }
            catch (Exception ex)
            {
                garb.isValid = false;
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: SetBundleAutoRenewal, Class: Bundle_DL, Parameters: IsAutoRenew {isAutoRenew}, Msisdn {Msisdn}, Account {account}, BundleId {bundleId}, IsTrial {isTrial}");
            }
            return garb;
        }

        /// <summary>
        /// Get Data Bundle Record
        /// </summary>
        /// <param name="nowtelReference"></param>
        /// <param name="productId"></param>
        /// <returns></returns>
        public async Task<DataBundleRecord> GetDataBundleRecord(string nowtelReference, int productId)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@NowtelTransactionReference", nowtelReference);
                parameters.Add("@ProductId", productId);

                IEnumerable<DataBundleRecord> result = new List<DataBundleRecord>();

                using (var dbConnection = new SqlConnection(_dbConnections.AttDb))
                {
                    result = await dbConnection.QueryAsync<DataBundleRecord>("tha_get_access_data_nowtel_reference", parameters, commandType: CommandType.StoredProcedure);
                }

                return result?.FirstOrDefault();
            }
            catch (Exception ex)
            {
                _logger.Error("Exception Occured Get Bundle Record :" + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Get Compatible Bundles Via SQL
        /// </summary>
        /// <param name="na_service_id"></param>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Bundle>> GetCompatibleBundlesViaSQL(int na_service_id, string account)
        {
            try
            {
                var storedProcedure = "tha_get_compatible_bundles_v1";//V1 with trial bundle info and bundle details

                var parameters = new DynamicParameters();
                parameters.Add("@na_service_id", na_service_id);
                parameters.Add("@account", account);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryAsync<Bundle>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Bundle_DL, Method: GetCompatibleBundlesViaSQL, Parameters=> na_service_id: {na_service_id}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return null;
        }

        /// <summary>
        /// Get Compatible Bundles Via SQL V2
        /// </summary>
        /// <param name="na_service_id"></param>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Bundle>> GetCompatibleBundlesViaSQLV2(int na_service_id, string account)
        {
            try
            {
                var storedProcedure = "tha_get_compatible_bundles_v2";//V2 with trial bundle info, bundle details and hide payg bundles
                //var storedProcedure = "tha_get_compatible_bundles_QA";//V2 with trial bundle info, bundle details and hide payg bundles

                var parameters = new DynamicParameters();
                parameters.Add("@na_service_id", na_service_id);
                parameters.Add("@account", account);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryAsync<Bundle>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Bundle_DL, Method: GetCompatibleBundlesViaSQL, Parameters=> na_service_id: {na_service_id}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Get Country Rates
        /// </summary>
        /// <param name="na_service_id"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<IEnumerable<RateRev>> GetCountryRates(int na_service_id, int id)
        {

            var storedProcedure = "tha_get_international_web_rates_by_na_service_id_id";

            var parameters = new DynamicParameters();
            parameters.Add("@na_service_id", na_service_id);
            parameters.Add("@id", id);
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                     return await dbConnection.QueryAsync<RateRev>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                _logger.Error("GetCountryRates : " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Offer Bundle Validation
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="bundleId"></param>
        /// <returns></returns>
        public async Task<(int, string)> OfferBundleValidation(string accountId, string bundleId)
        {
            var parameter = new DynamicParameters();
            parameter.Add("@bundleref", bundleId);
            parameter.Add("@account", accountId);
            parameter.Add("@offer_bundle_subscription_count", 1);
            parameter.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameter.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                await dbConnection.QueryAsync(
                                "tha_offer_bundle_validation", parameter, commandType: CommandType.StoredProcedure);
                return (parameter.Get<int>("@errorcode"), parameter.Get<string>("@errormsg"));
            }
        }

        /// <summary>
        /// Get Bundle Details By Ids
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<IEnumerable<BundleDetailsDB>> GetBundleDetailsByIds(List<string> ids)
        {
            try
            {
                var parameter = new DynamicParameters();
                var dataTable = new DataTable();
                dataTable.Columns.Add("@ID", typeof(Guid));
                ids.ForEach(e =>
                {
                    dataTable.Rows.Add(Guid.Parse(e));
                });
                parameter.Add("@Ids", dataTable.AsTableValuedParameter());

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryAsync<BundleDetailsDB>("tha_get_calling_package_details_by_ids", parameter, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetBundleDetailsByIds, Class: Bundle_DL, Parameters: Ids {ids}");
                throw;
            }
        }

        /// <summary>
        /// Get Account Digitalk Bundles Via SQL
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Bundle>> GetAccountDigitalkBundlesViaSQL(string account)
        {
            List<Bundle> lb = new List<Bundle>();

            try
            {
                var storedProcedure = "tha_get_account_bundlesV3";

                var parameters = new DynamicParameters();
                parameters.Add("@account", account);

                IEnumerable<Bundle> queryResult = new List<Bundle>();

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    queryResult = await dbConnection.QueryAsync<Bundle>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }
                var resultSet = queryResult.ToList<Bundle>();
                return resultSet;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Bundle_DL, Method: GetAccountDigitalkBundlesViaSQL, Parameters=> account: {account}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return null;
        }

        /// <summary>
        /// Get Account Digitalk Bundles
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<IEnumerable<DigitalkBundle>> GetAccountDigitalkBundles(string msisdn)
        {
            List<DigitalkBundle> ls = new List<DigitalkBundle>();

            try
            {
                var userAccount = await _userAccountDL.GetUserAccount(msisdn);
                var url = _digitalkConfig.ApiUrl + $"/subscribers/{userAccount.SubscriberId}/subscriptions/0/bundles?type=1";
                var result = await _apiCall.GetAsync(url, TokenType.Basic, Convert.ToBase64String(Encoding.ASCII.GetBytes("NowtelAPIUser:trR_911@54FD")));

                if (!result.IsSuccessStatusCode)
                {
                    //bundleLogger.Write(LogEventLevel.Warning, "GetAccountDigitalkBundles return status code : " +
                    //    result.IsSuccessStatusCode.ToString(CultureInfo.InvariantCulture));
                    return ls;
                }

                var bundles = JsonConvert.DeserializeObject<DigitalkBundleItems>(await result.Content.ReadAsStringAsync());

                return bundles.Items;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Bundle_DL, Method: GetAccountDigitalkBundles, Parameters=> msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return ls;
            }
        }

        /// <summary>
        /// Add Digitalk Bundles Via SQL
        /// </summary>
        /// <param name="account"></param>
        /// <param name="bundleid"></param>
        /// <returns></returns>
        public async Task<StandardResponse> AddDigitalkBundlesViaSQL(string account, string bundleid)
        {
            StandardResponse stdRes = new StandardResponse();
            stdRes.ErrorCode = 1;
            stdRes.ErrorMsg = "Bundle Purchase Failed!";

            try
            {
                var storedProcedure = "tha_add_accounts_bundle";

                var parameters = new DynamicParameters();
                parameters.Add("@account", account);
                parameters.Add("@bundle_id", bundleid);
                parameters.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    var queryResult = await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    if (parameters.Get<dynamic>("@error_code") != null && parameters.Get<dynamic>("@error_msg") != null)
                    {
                        stdRes.ErrorCode = parameters.Get<Int32>("@error_code");
                        stdRes.ErrorMsg = parameters.Get<string>("@error_msg");
                    }
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Bundle_DL, Method: GetAccountDigitalkBundlesViaSQL, Parameters=> account: {account}, bundleid: {bundleid}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return stdRes;
        }

        /// <summary>
        /// Get User Top Bundles
        /// </summary>
        /// <param name="na_service_id"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<IEnumerable<TopDestinationBundleDetails>> GetuserTopBundles(int na_service_id, string msisdn)
        {
            IEnumerable<TopDestinationBundleDetails> topDestinationBundleDetails = Enumerable.Empty<TopDestinationBundleDetails>();
            try
            {
                try
                {
                    var storedProcedure = "[DBA_roster_get_countrycode_count]";
                    var parameters = new DynamicParameters();
                    parameters.Add("@cli", msisdn);

                    IEnumerable<IsoCodeCount> isoCodeCount;

                    using (var dbConnection = new SqlConnection(_dbConnections.RosterDb))
                    {
                        isoCodeCount = await dbConnection.QueryAsync<IsoCodeCount>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                    }

                    // Get country with bundles
                    var ListOfCountriesWithBundles = await GetTopCountriesWithBundles(na_service_id);

                    //getting top 3 iso codes countries with available bundels
                    var top3IsoCodes = isoCodeCount.Where(r => ListOfCountriesWithBundles.Select(s => s.dest_iso_code).Contains(r.IsoCode))
                        .OrderByDescending(o => o.Count)
                        .Take(3);

                    //gettting the bundle against each top iso code
                    topDestinationBundleDetails = ListOfCountriesWithBundles.Where(s => top3IsoCodes.Select(ss => ss.IsoCode).Contains(s.dest_iso_code));
                }
                catch (Exception ex)
                {
                    var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                    _logger.Error($"Class: Bundle_DL, Method: GetuserTopBundles.roaster sp, Parameters=>msisdn:{msisdn}, na_service_id: {na_service_id}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                }

                //get contacts from ejabbered if not found from roaster database

                //if (topDestinationBundleDetails.Count == 0)
                //{
                //    #region ejabbered
                //    using (var connection = new MySqlConnection(ejabberdRosterDbConnection.SqlConnection.ConnectionString))
                //    {
                //        await connection.OpenAsync();

                //        var sql = "select substring(jid, 1, locate('@', jid)-1) username  from rosterusers  where username='" + msisdn + "'";
                //        //logger.Warning($"Executing sql .. {sql}");
                //        // find all xmpp users whose roster list contains this new user
                //        var results = await connection.QueryAsync(sql);

                //        List<PhoneIsoCode> phoneIsoCodes = new List<PhoneIsoCode>();
                //        PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();

                //        //Iterating through all user's numbers
                //        foreach (dynamic row in results)
                //        {
                //            string contactMsisdn = row.username.ToString(CultureInfo.InvariantCulture);

                //            try
                //            {
                //                if (contactMsisdn.IndexOf("+") == -1)
                //                {
                //                    contactMsisdn = "+" + contactMsisdn;
                //                }

                //                //get ISo Code against number
                //                PhoneNumber numberProto = phoneUtil.Parse(contactMsisdn, "");
                //                int countryCode = numberProto.CountryCode;
                //                var IsoRegionCode = phoneUtil.GetRegionCodeForCountryCode(countryCode);
                //                phoneIsoCodes.Add(new PhoneIsoCode() { msisdn = contactMsisdn, IsoCode = IsoRegionCode });

                //            }
                //            catch (NumberParseException e)
                //            {
                //                //System.err.println("NumberParseException was thrown: " + e.ToString(CultureInfo.InvariantCulture));
                //            }
                //            //logger.Warning($"Notifying {row.username} from {user}");
                //            //tasks.Add(this.pushService.SendXmppContactJoinedNotification(row.username, row.usernameuser));
                //        }

                //        if (phoneIsoCodes.Count > 0)
                //        {

                //            //Grouping by count of ISo Codes
                //            List<IsoCodeCount> isoCodeCount = phoneIsoCodes.GroupBy(n => n.IsoCode).
                //                Select(s => new IsoCodeCount()
                //                {
                //                    IsoCode = s.Key,
                //                    Count = s.Count()
                //                }
                //                ).OrderByDescending(o => o.Count).ToList();


                //            // Get country with bundles
                //            var ListOfCountriesWithBundles = await GetTopCountriesWithBundles(na_service_id);

                //            //getting top 3 iso codes countries with available bundels
                //            var top3IsoCodes = isoCodeCount.Where(r => ListOfCountriesWithBundles.Select(s => s.dest_iso_code).Contains(r.IsoCode))
                //                .OrderByDescending(o => o.Count)
                //                .Take(3)
                //                .ToList();

                //            //gettting the bundle against each top iso code
                //            topDestinationBundleDetails = ListOfCountriesWithBundles.Where(s => top3IsoCodes.Select(ss => ss.IsoCode).Contains(s.dest_iso_code)).ToList();
                //        }
                //    }
                //    #endregion
                //}

                return topDestinationBundleDetails;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Bundle_DL, Method: GetuserTopBundles, Parameters=>msisdn:{msisdn}, na_service_id: {na_service_id}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                //return null;
            }
            return topDestinationBundleDetails;
        }

        /// <summary>
        /// Get Dispay Off Peak
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="na_service"></param>
        /// <returns></returns>
        public async Task<bool> GetDispayOffPeak(string msisdn, int na_service)
        {
            var storedProcedure = "tha_get_off_peak_settings";

            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", msisdn);
            parameters.Add("@na_service_id", na_service);
            parameters.Add("@isOffPeak", dbType: DbType.Boolean, direction: ParameterDirection.Output);
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    return parameters.Get<bool>("@isOffPeak");
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetDispayOffPeak, Class: Bundle_DL, Parameters: Msisdn {msisdn}, NaService {na_service}");
            }
            return false;
        }

        /// <summary>
        /// Is Bundle Purchased Previously
        /// </summary>
        /// <param name="account"></param>
        /// <param name="bundleId"></param>
        /// <returns></returns>
        public async Task<bool> IsBundlePurchasedPreviously(string account, string bundleId)
        {
            var storedProcedure = "tha_is_auto_bundle_renewal_record_exists";

            var parameters = new DynamicParameters();
            parameters.Add("@account", account);
            parameters.Add("@bundleId ", bundleId);
            parameters.Add("@exists", dbType: DbType.Boolean, direction: ParameterDirection.Output);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<bool>("@exists");
            }
        }

        /// <summary>
        /// Monthly Bundle Validation After Trial Expire
        /// </summary>
        /// <param name="account"></param>
        /// <param name="msisdn"></param>
        /// <param name="bundleId"></param>
        /// <param name="trialBundleId"></param>
        /// <returns></returns>
        public async Task<bool> MonthlyBundleValidationAfterTrialExpire(string account, string msisdn, string bundleId, string trialBundleId)
        {
            var storedProcedure = "tha_validate_monthly_bundle_activation";

            var parameters = new DynamicParameters();
            parameters.Add("@account", account);
            parameters.Add("@msisdn", msisdn);
            parameters.Add("@callingPackageId", bundleId);
            parameters.Add("@trialCallingPackageId", trialBundleId);
            parameters.Add("@isValid", dbType: DbType.Boolean, direction: ParameterDirection.Output);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<bool>("@isValid");
            }
        }

        /// <summary>
        /// Any Active Auto Bundle Renwal
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<bool> AnyActiveAutoBundleRenwal(string account)
        {
            bool isExists = false;
            var parameters = new DynamicParameters();
            parameters.Add("@account", account);
            parameters.Add("@exists", isExists, direction: ParameterDirection.Output);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                await dbConnection.ExecuteAsync("thaAnyActiveAutoBundleRenewal", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<bool>("@exists");
            }
        }

        /// <summary>
        /// Get Country Rates With Budle
        /// </summary>
        /// <param name="na_service_id"></param>
        /// <returns></returns>
        public async Task<IEnumerable<RateRev>> GetCountryRatesWithBudle(int na_service_id)
        {
            try
            {

                var storedProcedure = "tha_get_rates_by_na_service_id";

                var parameters = new DynamicParameters();
                parameters.Add("@na_service_id", na_service_id);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                   return await dbConnection.QueryAsync<RateRev>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                _logger.Error("Pull Rates :" + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Get Country Rates With Budle
        /// </summary>
        /// <param name="na_service_id"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<IEnumerable<RateRev>> GetCountryRatesWithBudle(int na_service_id, string msisdn)
        {
            try
            {
                var storedProcedure = "tha_get_rates_by_na_service_id_v1";

                var parameters = new DynamicParameters();
                parameters.Add("@na_service_id", na_service_id);
                parameters.Add("@msisdn", msisdn);

                IEnumerable<RateRev> rates;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    rates = await dbConnection.QueryAsync<RateRev>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }

                //As TalkHomeApps DB don't have latest available bundles data, so we are getting available bundles for countries data from DigitalkDatabase.
                var countriesWhichHaveCompatibleBundles = await GetAvailableBundlesCountryCodes(na_service_id);
                //TODO:Update IsBundleAvailable bit if that country exists in compatible bundles countries list
                foreach (var x in rates)
                {
					x.isBundleAvailable = countriesWhichHaveCompatibleBundles.Contains(x.ISOCode);
				}
                return rates;
            }
            catch (Exception ex)
            {
                _logger.Error("Method: GetCountryRatesWithBudle Exception:" + ex.ToString());
                return new List<RateRev>();
            }
        }

        /// <summary>
        /// Get Available Bundles Country Codes
        /// </summary>
        /// <param name="na_service_id"></param>
        /// <returns></returns>
        private async Task<List<string>> GetAvailableBundlesCountryCodes(int na_service_id)
        {
            try
            {

                //var storedProcedure = "tha_get_available_bundles_country_codes_QA";
                var storedProcedure = "tha_get_available_bundles_country_codes";

                var parameters = new DynamicParameters();
                parameters.Add("@na_service_id", na_service_id);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    var result = await dbConnection.QueryAsync<string>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.Error("Method: GetAvailableBundlesCountryCodes Exception:" + ex.ToString());
                return new List<string>();
            }
        }

        /// <summary>
        /// Get Top Countries With Bundles
        /// </summary>
        /// <param name="na_service_id"></param>
        /// <returns></returns>
        public async Task<IEnumerable<TopDestinationBundleDetails>> GetTopCountriesWithBundles(int na_service_id)
        {
            try
            {
                var storedProcedure = "tha_get_country_available_bundle";

                var parameters = new DynamicParameters();
                parameters.Add("@na_service_id", na_service_id);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    return await dbConnection.QueryAsync<TopDestinationBundleDetails>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Bundle_DL, Method: GetTopCountriesWithBundles, Parameters=> na_service_id: {na_service_id}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Save Bundle Purchase Data
        /// </summary>
        /// <param name="isSuccess"></param>
        /// <param name="bundleName"></param>
        /// <param name="bundleRef"></param>
        /// <param name="bundleAmount"></param>
        /// <param name="accountId"></param>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        public async Task SaveBundlePurchaseData(bool isSuccess, string bundleName, string bundleRef, float bundleAmount, string accountId, string errorMessage)
        {
            var storedProcedure = "tha_save_bundle_purchase_data";

            var parameters = new DynamicParameters();
            parameters.Add("@accountId", accountId);
            parameters.Add("@bundleName", bundleName);
            parameters.Add("@bundleRef", bundleRef);
            parameters.Add("@bundleAmount", bundleAmount);
            parameters.Add("@productItemCode", "THAATA");
            parameters.Add("@isSuccess", isSuccess);
            parameters.Add("@ErrorMessage", errorMessage);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
            }
        }
    }
}
