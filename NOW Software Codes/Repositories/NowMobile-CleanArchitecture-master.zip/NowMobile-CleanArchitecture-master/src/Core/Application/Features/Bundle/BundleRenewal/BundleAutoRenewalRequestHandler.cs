using Application.Features.Bundle.BundleDetail;
using Application.Features.Bundle.Model;
using Microsoft.AspNetCore.Http;

namespace Application.Features.Bundle.BundleRenewal;

public sealed class GetBundleAutoRenewalRequestHandler : IRequestHandler<GetBundleAutoRenewalRequest, Result<GetBundleAutoRenewalStatus>>
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<BundleAutoRenewalRequestHandler> _localizer;
    private readonly IUserService _userService;
    private readonly ICommonService _commonService;

    public GetBundleAutoRenewalRequestHandler(
        IUnitOfWork unitOfWork,
        ICurrentUser currentUser,
        IStringLocalizer<BundleAutoRenewalRequestHandler> localizer,
        IUserService userService,
        ICommonService commonService)
    {
        _unitOfWork = unitOfWork;
        _currentUser = currentUser;
        _localizer = localizer;
        _userService = userService;
        _commonService = commonService;
    }

    public async Task<Result<GetBundleAutoRenewalStatus>> Handle(GetBundleAutoRenewalRequest request, CancellationToken cancellationToken)
    {
        var msisdnDetails=await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
        var bundleAutoRenewalStatus= await _unitOfWork.BundleRepo.GetBundleAutoRenewal(request.Msisdn, msisdnDetails.AccountId, request.BundleId);
        return Result<GetBundleAutoRenewalStatus>.Success(bundleAutoRenewalStatus, "success");
    }
}
public sealed class BundleAutoRenewalRequestHandler : IRequestHandler<BundleAutoRenewalRequest, Result<object>>
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<BundleAutoRenewalRequestHandler> _localizer;
    private readonly IUserService _userService;
    private readonly ICommonService _commonService;

    public BundleAutoRenewalRequestHandler(
        IUnitOfWork unitOfWork,
        ICurrentUser currentUser,
        IStringLocalizer<BundleAutoRenewalRequestHandler> localizer,
        IUserService userService,
        ICommonService commonService)
    {
        _unitOfWork = unitOfWork;
        _currentUser = currentUser;
        _localizer = localizer;
        _userService = userService;
        _commonService = commonService;
    }

    public async Task<Result<object>> Handle(BundleAutoRenewalRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        //Check if user msisdn
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Get bundle Info
        var bundlesResponse = await _unitOfWork.BundleRepo.GetBundleById(new BundleByIdRequest() { Id = request.BundleId.ToString() });
        if (bundlesResponse == null)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }
        if (bundlesResponse.Type == (int) BundleType.Rolling)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }

        var msisdnInfo = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);

        //Get subscribed bundles
        var subscribedBunldes = await _unitOfWork.UserRepo.GetSubscribedBundles(msisdnInfo.AccountId!);
        if (subscribedBunldes.Any())
        {
            if (!subscribedBunldes.Any(x => x.Id.ToString().Equals(bundlesResponse.UuId, StringComparison.InvariantCultureIgnoreCase)))
            {
                return Result<object>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
            }
        }

        //set bundle auto renewal
        await _unitOfWork.BundleRepo.SetBundleAutoRenewal(
                request.IsAutoRenew,
                request.Msisdn,
                msisdnInfo.AccountId!,
                bundlesResponse.UuId!,
                _currentUser.GetUserEmail()!,
                PaymentMethod.Card);

        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }
}
