﻿namespace Infrastructure.Services;

internal sealed class UserService : IUserService
{
    //private readonly ICurrentUser _currentUser;
    private readonly IUnitOfWork _uow;

    public UserService(/*ICurrentUser currentUser, */IUnitOfWork uow)
    {
      //  _currentUser = currentUser;
        _uow = uow;
    }

    /*public async Task<bool> IsUserMsisdn(string msisdn)
    {
        var userProducts = await _uow.UserRepo.GetUserProducts(_currentUser.GetUserId());

        return userProducts.Any() && userProducts.Any(x => x.Msisdn != null && x.Msisdn.Equals(msisdn, StringComparison.InvariantCultureIgnoreCase));
    }*/
    public async Task<MsisdnDetails> GetMsisdnDetail(string msisdn)
    {
        var msisdnDetails = await _uow.UserRepo.GetMsisdnDetail(msisdn);

        return msisdnDetails;
    }
}
