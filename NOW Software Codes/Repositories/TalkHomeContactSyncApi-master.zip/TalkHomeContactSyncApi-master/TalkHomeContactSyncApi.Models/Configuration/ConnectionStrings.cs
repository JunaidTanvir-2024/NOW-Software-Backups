﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkHomeContactSyncApi.Models.Configuration
{
    public class ConnectionStrings
    {
        public string DefaultConnectionString { get; set; }
    }
}
