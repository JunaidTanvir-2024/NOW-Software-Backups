using Asp.Versioning;

using FH.Api.Controllers.Common;
using FH.UseCases.Countries;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.V1;

[ApiVersion(1.0)]
public sealed class CountryController : BaseApiController
{
    [HttpPost]
    public async Task<ActionResult> GetCountries(GetCountries.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}
