﻿using Now.Infrastructure.Services;
using Now.Models.Contracts;
using Now.Models.Database;
using Now.Models.Enums;

namespace Now.Infrastructure.DAL;

public interface ICreditSimFulfillment_DL : ISerivcesType.ITransientService
{
    Task<IEnumerable<DbSimOrderPool>> GetActiveNumbersFromPool();
    Task<DbResult<List<DbCreditSimOrderDetail>>> GetCreditSimOrderDetail(string msisdn);
    Task<DbResult<string>> UpdateCreditSimFullfilment(long id, bool isFullfilled, string fulfillment_error_message, string fulfillment_ref);
    Task<DbResult<DbAddBundleOrTopupResult>> AddBundleOrTopup(
        string transactionId, string bundleRef, string amount, string msisdn, PaymentType paymentType,string email);
    Task UpdateCreditSimFullfilmentInSimPool(int id, bool isFullfiled, string errorMessage);

    Task UpdateSimStatus(string msisdn);
    Task<(bool, OrderDetails, IEnumerable<OrderItemDetails>)> GetOrderDetails(string transactionId);
    Task<Bundle> GetBundleById(int bundleId);
    Task<MsisdnDetails> GetMsisdnDetail(string msisdn);
    Task SetBundleAutoRenewal(bool isRenew, string msisdn, string accountId, string bundleUuid, string userEmail,
        PaymentType paymentMethod, string cardPanMasked = null, string cardInitialTransactionId = null);
    Task SetAutoTopup(bool isAutoTopup, string msisdn, string userEmail, float topupAmount,
        string topupCurrency, float topupTheresholdAmount, PaymentType paymentMethod,
        string cardMaskedPan = default!, string cardInitialTransactionId = default!);
}
