﻿using CallingCode.Mvc.Common.Models;
using System.Text.Json;

namespace CallingCode.Mvc.Persistence;

public static class JsonDataStore
{
    #region Countries
    public static List<Country>? Countries { get; private set; }
    public static string? ContentVariations { get; private set; }

    public static WebApplicationBuilder BindCountries(this WebApplicationBuilder builder)
    {
        var filePath = builder.Environment.WebRootPath + "\\Country-Codes\\Assets\\JsonData\\CountriesData.json";
        var contentfilePath = builder.Environment.WebRootPath + "\\Country-Codes\\Assets\\JsonData\\contentvariations.json";

        // Bind JSON file to static class
        var countriesDataJson = File.ReadAllText(filePath);
        var options = new JsonSerializerOptions
        {
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
            WriteIndented = true
        };
        var countriesData = JsonSerializer.Deserialize<CountriesData>(countriesDataJson, options);
        Countries = countriesData?.Countries;

        // Bind JSON file to static class
        var contentVariationsDataJson = File.ReadAllText(contentfilePath);
        ContentVariations = contentVariationsDataJson;

        return builder;
    }
    #endregion
}