﻿namespace THCC.Domain.Aggregates
{
    public class ClassicPinDetail
    {
        public DateTime? StartDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public decimal? TotalCredit { get; set; }
        public decimal? RemainingCredit { get; set; }
        public int State { get; set; }
    }
}
