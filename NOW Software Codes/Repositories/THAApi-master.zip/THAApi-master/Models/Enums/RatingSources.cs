﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum RatingSources
    {
        APP = 1,
        Web = 2
    }
}
