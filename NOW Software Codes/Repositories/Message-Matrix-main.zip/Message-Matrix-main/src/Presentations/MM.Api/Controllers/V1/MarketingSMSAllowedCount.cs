namespace MM.Api.Controllers.V1;

public class MarketingSMSAllowedCount
{
    public const string SectionName = "AllowedCounts";
    public static MarketingSMSAllowedCount Bind = new MarketingSMSAllowedCount();
    public int Counts { get; set; }
}
