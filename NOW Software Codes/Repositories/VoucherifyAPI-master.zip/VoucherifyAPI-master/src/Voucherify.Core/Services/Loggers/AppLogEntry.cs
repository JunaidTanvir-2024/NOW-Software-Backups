namespace Voucherify.Core.Services.Loggers;

public class AppLogEntry
{
    public DateTimeOffset Timestamp { get; set; }
    public string? RequestPath { get; set; }
    public string? RequestMethod { get; set; }
    public string? RequestBody { get; set; }
    public string? ResponseBody { get; set; }
    public int StatusCode { get; set; }
    public long Duration { get; set; }
    public string? ClientIP { get; set; }
    public string? UserAgent { get; set; }
    public long ResponseSize { get; set; }
    public string? ErrorMessage { get; set; }
    public string? CorrelationId { get; set; }
    public string? Headers { get; set; }
    public string? QueryString { get; set; }
    public string? UniqueReference { get; set; }
    public string? ProductCode { get; set; }
    public string? ProductItemCode { get; set; }
}
