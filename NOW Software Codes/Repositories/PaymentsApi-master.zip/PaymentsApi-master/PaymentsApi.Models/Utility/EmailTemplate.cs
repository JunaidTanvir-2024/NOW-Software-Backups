﻿using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace PaymentsApi.Models.Utility
{

    public interface IEmailTemplates
    {
        string GetTHRCCTemplate(string name, string currency, string amount, string cardNumber, string pin, string points, string newBalance);
        string GetTHRCCTemplate(string name, string currency, string amount, string cardNumber, string points, string newBalance);
        string GetTHCCTemplate(string name, string currency, string amount, string pin);
        string GetWTCCTemplate(string name, string currency, string amount, string pin);
        string GetSTCCTemplate(string name, string currency, string amount, string pin);
        string GetBTCCTemplate(string name, string currency, string amount, string pin);
        string GetMTCCTemplate(string name, string currency, string amount, string pin);
        string GetTDCCTemplate(string name, string currency, string amount, string pin);
    }

    public class EmailTemplates : IEmailTemplates
    {

        private IHostingEnvironment HostingEnv;

        public EmailTemplates(IHostingEnvironment hostingEnv)
        {
            HostingEnv = hostingEnv;
        }

        public string GetTDCCTemplate(string name, string currency, string amount, string pin)
        {
            string html = "";
            try
            {
                string webRootPath = HostingEnv.WebRootPath;
                var templatelePath = webRootPath + @"\EmailTemplates\TDCC.html";
                html = File.ReadAllText(templatelePath);
                html = html.Replace("###name###", name).Replace("###currency###", currency).Replace("###amount###", amount).Replace("###pin###", pin);

            }
            catch (Exception ex)
            {

            }
            return html;
        }

        public string GetMTCCTemplate(string name, string currency, string amount, string pin)
        {
            string html = "";
            try
            {
                string webRootPath = HostingEnv.WebRootPath;
                var templatelePath = webRootPath + @"\EmailTemplates\MTCC.html";
                html = File.ReadAllText(templatelePath);
                html = html.Replace("###name###", name).Replace("###currency###", currency).Replace("###amount###", amount).Replace("###pin###", pin);

            }
            catch (Exception ex)
            {

            }
            return html;
        }

        public string GetBTCCTemplate(string name, string currency, string amount, string pin)
        {
            string html = "";
            try
            {
                string webRootPath = HostingEnv.WebRootPath;
                var templatelePath = webRootPath + @"\EmailTemplates\BTCC.html";
                html = File.ReadAllText(templatelePath);
                html = html.Replace("###name###", name).Replace("###currency###", currency).Replace("###amount###", amount).Replace("###pin###", pin);

            }
            catch (Exception ex)
            {

            }
            return html;
        }

        public string GetSTCCTemplate(string name, string currency, string amount, string pin)
        {
            string html = "";
            try
            {
                string webRootPath = HostingEnv.WebRootPath;
                var templatelePath = webRootPath + @"\EmailTemplates\STCC.html";
                html = File.ReadAllText(templatelePath);
                html = html.Replace("###name###", name).Replace("###currency###", currency).Replace("###amount###", amount).Replace("###pin###", pin);

            }
            catch (Exception ex)
            {

            }
            return html;
        }

        public string GetTHRCCTemplate(string name, string currency, string amount, string cardNumber, string pin, string points, string newBalance)
        {
            string html = "";
            try
            {
                string webRootPath = HostingEnv.WebRootPath;
                var thrccTemplatelePath = webRootPath + @"\EmailTemplates\Thrcc_New_Card.html";
                html = File.ReadAllText(thrccTemplatelePath);
                html = html.Replace("###name###", name).Replace("###currency###", currency).Replace("###amount###", amount).Replace("###card###", cardNumber).Replace("###pin###", pin).Replace("###point###", points).Replace("###balance###", newBalance);

            }
            catch (Exception ex)
            {

            }
            return html;
        }

        public string GetTHRCCTemplate(string name, string currency, string amount, string cardNumber, string points, string newBalance)
        {
            string html = "";
            try
            {
                string webRootPath = HostingEnv.WebRootPath;
                var thrccTemplatelePath = webRootPath + @"\EmailTemplates\Thrcc_Existing_Card.html";
                html = File.ReadAllText(thrccTemplatelePath);
                html = html.Replace("###name###", name).Replace("###currency###", currency).Replace("###amount###", amount).Replace("###card###", cardNumber).Replace("###point###", points).Replace("###balance###", newBalance);

            }
            catch (Exception ex)
            {

            }
            return html;
        }

        public string GetTHCCTemplate(string name, string currency, string amount, string pin)
        {
            string html = "";
            try
            {
                string webRootPath = HostingEnv.WebRootPath;
                var thccTemplatelePath = webRootPath + @"\EmailTemplates\Thcc.html";
                html = File.ReadAllText(thccTemplatelePath);
                html = html.Replace("###name###", name).Replace("###currency###", currency).Replace("###amount###", amount).Replace("###pin###", pin);

            }
            catch (Exception ex)
            {

            }
            return html;
        }

        public string GetWTCCTemplate(string name, string currency, string amount, string pin)
        {
            string html = "";
            try
            {
                string webRootPath = HostingEnv.WebRootPath;
                var thccTemplatelePath = webRootPath + @"\EmailTemplates\WTCC.html";
                html = File.ReadAllText(thccTemplatelePath);
                html = html.Replace("###name###", name).Replace("###currency###", currency).Replace("###amount###", amount).Replace("###pin###", pin);

            }
            catch (Exception ex)
            {

            }
            return html;
        }      


    }
}
