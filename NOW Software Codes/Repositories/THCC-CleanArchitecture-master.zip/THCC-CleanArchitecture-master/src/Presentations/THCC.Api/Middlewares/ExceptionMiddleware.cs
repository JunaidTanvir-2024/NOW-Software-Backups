﻿using static THCC.Domain.Constants.ThccConstants;

using ILogger = Serilog.ILogger;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Api.Middlewares
{
    internal sealed class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger _logger;
        public ExceptionMiddleware(ILogger logger, RequestDelegate next)
        {
            _next = next;
            _logger = logger;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message);
                var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                context.Response.ContentType = "application/json";
                context.Response.StatusCode = 500;
                await context.Response.WriteAsync(JsonConvert.SerializeObject(new ErrorResult()
                {
                    Errors = new List<ErrorDto>()
                        {
                            new ErrorDto() {
                                Code = CustomStatusCode.InternalServerError,
                                Message = environment!.Equals("Production", StringComparison.InvariantCultureIgnoreCase)? CustomStatusKey.InternalServerError: ex.Message ?? ex.ToString()
                            }
                        }
                }, new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() }));
            }
        }
    }

    internal static class ExceptionMiddlewareExtensions
    {
        internal static IApplicationBuilder UseExceptionMiddleware(this IApplicationBuilder app) => app.UseMiddleware<ExceptionMiddleware>();
    }
}
