﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class GenericPay360ApiResponse<T>
    {
        public string Status { get; set; }
        public string Message { get; set; }
        public T Payload { get; set; }
        public int ErrorCode { get; set; }
        public string Pay360ApiCode { get; set; }
        public static GenericPay360ApiResponse<T> Success(T payload, string message)
        {
            return new GenericPay360ApiResponse<T>
            {
                ErrorCode = 0,
                Status = "Success",
                Message = message,
                Payload = payload
            };
        }
        public static GenericPay360ApiResponse<T> Success(string message)
        {
            return new GenericPay360ApiResponse<T>
            {
                ErrorCode = 0,
                Status = "Success",
                Message = message
            };
        }
        public static GenericPay360ApiResponse<T> Failure(string message, ApiStatusCodes errorCode)
        {
            return new GenericPay360ApiResponse<T>
            {
                ErrorCode = (int)errorCode,
                Status = "Failure",
                Message = message

            };
        }
        public static GenericPay360ApiResponse<T> Failure(T payload, string message, ApiStatusCodes errorCode)
        {
            return new GenericPay360ApiResponse<T>
            {
                ErrorCode = (int)errorCode,
                Status = "Failure",
                Message = message,
                Payload = payload
            };
        }
    }
}
