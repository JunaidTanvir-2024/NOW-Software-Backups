﻿using Application.Common.Models;

namespace Application.Common.Interfaces;
public interface ISocialLoginService : ISerivcesType.ITransientService
{
    Task<GoogleUserViewModel> GetUserFromGoogle(string AccessToken);
    Task<FacebookUserViewModel> GetUserFromFacebook(string AccessToken);
    Task<bool> ValidateAppleToken(string Code, string Email);
}
