﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class AppConfig_DL : IAppConfig_DL
    {

        private IUserAccount_DL _userAccount_DL;
        private readonly ILogger _logger;
        private readonly IStringLocalizer _localizer;
        private readonly IConfiguration _configuration;
        private readonly ConnectionStrings _dbConnections;

        public AppConfig_DL(
            IStringLocalizer localizer,
            IConfiguration config, 
            IUserAccount_DL userAccount_DL, 
            IOptions<ConnectionStrings> dbConnections,
            ILogger logger)
        {
            _userAccount_DL = userAccount_DL;
            _dbConnections = dbConnections.Value;
            _logger = logger;
            _localizer = localizer;
            _configuration = config;
        }

        /// <summary>
        /// Get Carousel Dynamic
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="na_service_id"></param>
        /// <param name="language"></param>
        /// <returns></returns>
        public async Task<List<CarouselContent>> GetCarouselDynamic(string msisdn, int na_service_id, string language)
        {
            var storedProcedure = "thac_get_content";
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@NSId", na_service_id);
                parameters.Add("@ISOCode", language);

                using (var dbConnection = new SqlConnection(_dbConnections.CmsCarouselDb))
                {
                    var result = await dbConnection.QueryAsync<CarouselContent>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetCarouselDynamic, Class: AppConfig_DL");
                return null;
            }

        }

        /// <summary>
        /// Get Carousel Menu
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="na_service_id"></param>
        /// <returns></returns>
        public async Task<List<CarouselMenu>> GetCarouselMenu(string msisdn, int na_service_id)
        {

            var storedProcedure = "tha_get_carousel_menu";
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@na_service_id", na_service_id);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.QueryAsync<CarouselMenu>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetCarouselMenu, Class: AppConfig_DL");
                return null;
            }

        }

        /// <summary>
        /// Get Carousel Menu V1
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="na_service_id"></param>
        /// <param name="version"></param>
        /// <param name="itVersion"></param>
        /// <returns></returns>
        public async Task<List<CarouselMenu>> GetCarouselMenuV1(string msisdn, int na_service_id, int version, string itVersion)
        {

            var storedProcedure = "tha_get_carousel_menu_v2";
            try
            {
                string app_submit_version = _configuration["ApiConfig:payment_itunes_only_version"];
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@na_service_id", na_service_id);
                parameters.Add("@app_release", version);
                parameters.Add("@app_it_version", itVersion);
                parameters.Add("@app_submit_version", app_submit_version);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.QueryAsync<CarouselMenu>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetCarouselMenuV1, Class: AppConfig_DL");
                return null;
            }

        }

        /// <summary>
        /// Get Carousel Menu V1
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="na_service_id"></param>
        /// <param name="version"></param>
        /// <returns></returns>
        public async Task<List<CarouselMenu>> GetCarouselMenuV1(string msisdn, int na_service_id,int version)
        {

            var storedProcedure = "tha_get_carousel_menu_v1";
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@na_service_id", na_service_id);
                parameters.Add("@app_release", version);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.QueryAsync<CarouselMenu>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetCarouselMenuV1, Class: AppConfig_DL, Parameters: Msisdn {msisdn}, NaServiceId {na_service_id}, Version {version}");
                return null;
            }
        }

        /// <summary>
        /// Get Bundle SMS
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<string> getBundleSMS(string msisdn)
        {
            string bundlesmsnumber = "";
            try
            {
                var storedProcedure = "tha_get_bundlesms_number";

                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                parameters.Add("@bundlesmsnumber", dbType: DbType.String, direction: ParameterDirection.Output, size: 25);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    if (parameters.Get<dynamic>("@bundlesmsnumber") == null)
                    {
                        return null;
                    }

                    bundlesmsnumber = parameters.Get<string>("@bundlesmsnumber").ToString(CultureInfo.InvariantCulture);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: getBundleSMS, Class: AppConfig_DL, Parameters: Msisdn {msisdn}");
                return null;
            }

            return bundlesmsnumber;
        }

        /// <summary>
        /// Get Airtime Config
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<List<AirtimeConfig>> GetAirtimeConfig(string msisdn)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.QueryAsync<AirtimeConfig>("tha_get_airtime_config", parameters, commandType: CommandType.StoredProcedure);
                    if (result != null)
                    {
                        return result.AsList<AirtimeConfig>();
                    }
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetAirtimeConfig, Class: AppConfig_DL, Parameters: Msisdn {msisdn}");
                return null;
            }
        }

        /// <summary>
        /// Get Referral Msgs
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<List<string>> getReferralMsgs(string msisdn)
        {
            bool canReffer = false;
            string credit = "1£";

            List<string> ls = new List<string>();

            try
            {
                UserAccount userAccount = await _userAccount_DL.GetUserAccount(msisdn);

                int na_service_id = userAccount.UserAccountDetails.Na_Service_Id;

                var storedProcedure = "tha_get_raf_status";

                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@na_service_id", na_service_id);

                parameters.Add("@isenabled", dbType: DbType.Boolean, direction: ParameterDirection.Output);
                parameters.Add("@credit", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    if (parameters.Get<dynamic>("@isenabled") == null)
                    {
                        return null;
                    }

                    canReffer = parameters.Get<bool>("@isenabled");
                    credit = parameters.Get<string>("@credit");

                    if (canReffer)
                    {
                        string msg1 = _localizer["referralMessage1", credit];

                        string msg2 = _localizer["referralMessage2", credit];

                        ls.Add(msg1);
                        ls.Add(msg2);

                        return ls;
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: getReferralMsgs, Class: AppConfig_DL, Parameters: Msisdn {msisdn}");
                return null;
            }
        }
    }
}
