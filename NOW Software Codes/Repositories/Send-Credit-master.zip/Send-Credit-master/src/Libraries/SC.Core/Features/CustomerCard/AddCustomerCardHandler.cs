﻿using Microsoft.AspNetCore.Identity;

using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerCard.Request;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.Notification.Request;
using SC.Core.Models.Dtos.CustomerCard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerCard;
internal sealed class AddCustomerCardHandler : IRequestHandler<AddCustomerCardRequest, IResultWrapper>
{
    private readonly ICustomerCardRepository _customerCardRespository;
    private readonly ICommonService _commonService;
    private readonly IHelperService _helperService;
    public AddCustomerCardHandler(ICustomerCardRepository customerCardRespository, 
        ICommonService commonservice,
        IHelperService helperService)
    {
        _customerCardRespository = customerCardRespository;
        _commonService = commonservice;
        _helperService = helperService;
    }
    public async Task<IResultWrapper> Handle(AddCustomerCardRequest request, CancellationToken cancellationToken)
    {

        var dateParsed = _helperService.ConvertCartExpiryStringToDate(request.Expiry, out DateTime result);
        if (!dateParsed)
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);


        var card = new CustomerCardDto()
        {
            UserId = _commonService.GetUserID(),
            Pan = request.Pan,
            NameOnCard = request.NameOnCard,
            CardType = request.CardType,
            Expiry = result,
            IsDefault = request.IsDefault,

        };
        var response = await _customerCardRespository.AddCustomerCardAsync(card);
        string Reason = string.Empty;
        if (response == (int)AppEnums.CustomerCardEnum.IsCardNumberAlreadyExist)
            Reason = "Card Number Already Exists";





        return ResultWrapper.Success(new { IsCardAdded = response > 0 ? true : false, Message = Reason });
    }



}

