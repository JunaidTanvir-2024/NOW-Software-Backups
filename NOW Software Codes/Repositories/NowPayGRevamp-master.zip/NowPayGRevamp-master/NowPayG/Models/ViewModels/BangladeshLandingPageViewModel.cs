﻿using NowPayG.Models.ApiContracts.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class BangladeshLandingPageViewModel :BaseViewModel
    {
        public PlanResponseModel Plan { get; set; }
        public PlansResponseModel Plans { get; internal set; }
    }
}
