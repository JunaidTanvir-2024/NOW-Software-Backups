namespace Application.Features.Payment.Invoice;
public class InvoiceRequestValidator : AbstractValidator<InvoiceRequest>
{
    public InvoiceRequestValidator()
    {
        RuleFor(p => p.OrderId).NotNull().NotEmpty().Must(p => p > 0);
    }
}