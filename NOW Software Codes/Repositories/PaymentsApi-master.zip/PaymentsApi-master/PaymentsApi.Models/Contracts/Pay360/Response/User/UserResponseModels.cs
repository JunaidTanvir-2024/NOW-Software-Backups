﻿using Newtonsoft.Json;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using System.Collections.Generic;

namespace PaymentsApi.Models.Contracts.Pay360.Response.User
{
    public class UserResponseModels
    {
        public UserResponseModels()
        {
            Processing = new ProcessingModel();
        }
        [JsonProperty("customerId")]
        public string CustomerId { get; set; }
        [JsonProperty("transactionId")]
        public string TransactionId { get; set; }
        [JsonProperty("transactionAmount")]
        public string TransactionAmount { get; set; }
        //[JsonProperty("paymentMethod")]
        //public PaymentMethodResponseModel PaymentMethod { get; set; }
        [JsonProperty("outcome")]
        public OutcomeModel OutcomeModel { get; set; }
        [JsonProperty("processing")]
        public ProcessingModel Processing { get; set; }
        [JsonProperty("clientRedirect")]
        public ClientRedirectModel ClientRedirect { get; set; }
        [JsonProperty("threeDSecure")]
        public ThreeDSecureModel ThreeDSecure { get; set; }
        [JsonProperty("basketResponse")]
        public List<BasketItemsResponse> BasketResponse { get; set; }
        [JsonProperty("recurring")]
        public bool Recurring { get; set; }
        [JsonProperty("maskedPan")]
        public string MaskedPan { get; set; }
    }
}
