﻿using Microsoft.Extensions.Options;
using NowPayGApi.Models.Configurations;
using NowPayGApi.Models.DbConnections;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using Dapper;
using NowPayGApi.Models.DAOs;
using System.Threading.Tasks;
using System.Data;
using NowPayGApi.Infrastructure.DAL.Interfaces;
using Newtonsoft.Json.Linq;
using NowPayGApi.Models.Contracts.Response;
using NowPayGApi.Models.Contracts.Request;

namespace NowPayGApi.Infrastructure.DAL.Impelmentation
{
    public class DL_CommonServices : IDL_CommonServices
    {
        private readonly IDbConnectionSettings Db;

        public DL_CommonServices(IOptions<ConnectionString> connectionString)
        {
            Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.NowPaygDbConnection));
        }

        public async Task<IEnumerable<DBPlan>> GetAllActivePlans()
        {
            IEnumerable<DBPlan> result;
            try
            {
                result = await Db.SqlConnection.QueryAsync<DBPlan>("NowPayG_Api_GetAllActivePlans", commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<DBPlan>> GetAllPlans()
        {
            try
            {
                IEnumerable<DBPlan> result;
                result = await Db.SqlConnection.QueryAsync<DBPlan>("NowPayG_Api_GetAllPlans", commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<DBCountry>> GetCountry()
        {
            try
            {
                var result = await Db.SqlConnection.QueryAsync<DBCountry>("NowPayG_Api_GetCountries", commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<DBPlanCategory>> GetPlanCategories()
        {
            try
            {
                var result = await Db.SqlConnection.QueryAsync<DBPlanCategory>("NowPayG_Api_GetPlanCategories", commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<DBProduct>> GetProduct()
        {
            try
            {
                var result = await Db.SqlConnection.QueryAsync<DBProduct>("NowPayG_Api_GetProducts", commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Currencies>> GetCurrency()
        {
            try
            {
                var result = await Db.SqlConnection.QueryAsync<Currencies>("NowPayG_Api_GetCurrencies", commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GetPlanResponseModel> GetPlanById(IdRequestModel model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Id", model.Id);
                var result = await Db.SqlConnection.QueryFirstOrDefaultAsync<GetPlanResponseModel>("NowPayG_Api_GetPlanById", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<DBInternationalRates>> GetAllInternationalRates()
        {
            try
            {
                var result = await Db.SqlConnection.QueryAsync<Models.DAOs.DBInternationalRates>("NowPayG_Api_GetAllInternationalRates", commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<DBRoamingRates> GetRoamingRates(int fromCountryId, int toCountryId)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@FromCountryID", fromCountryId);
                parameters.Add("@ToCountryID", toCountryId);

                var result = await Db.SqlConnection.QueryFirstOrDefaultAsync<DBRoamingRates>("NowPayG_Api_GetRoamingRates", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<DBUKRates>> GetAllUKRates()
        {
            try
            {
                var result = await Db.SqlConnection.QueryAsync<Models.DAOs.DBUKRates>("NowPayG_Api_GetAllUKRates", commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<DBCountry>> GetAllCountriesWithPlans()
        {
            try
            {
                var result = await Db.SqlConnection.QueryAsync<DBCountry>("NowPayG_Api_GetAllCountriesWithPlans", commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GetSimOrdersNoByEmailResponseModel> GetSimOrderNoByEmail(string email)
        {
            GetSimOrdersNoByEmailResponseModel result = new GetSimOrdersNoByEmailResponseModel();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", email);
                parameters.Add("@UserId", DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@NumberOfSimOrders", DbType.Int32, direction: ParameterDirection.Output);

                await Db.SqlConnection.QueryFirstOrDefaultAsync<GetSimOrdersNoByEmailResponseModel>("NowPayG_Api_GetUserNumberOfSimOrdersByEmail", parameters, commandType: CommandType.StoredProcedure);
                result.UserId = parameters.Get<int>("@UserId");
                result.NumberOfSimOrders = parameters.Get<int>("@NumberOfSimOrders");
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
