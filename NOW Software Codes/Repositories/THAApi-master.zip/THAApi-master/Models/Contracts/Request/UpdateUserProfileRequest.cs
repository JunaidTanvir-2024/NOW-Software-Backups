﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class UpdateUserProfileRequest
    {

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("dobDay")]
        public int DobDay { get; set; } = default;

        [JsonProperty("dobMonth")]
        public int DobMonth { get; set; } = default;

        [JsonProperty("dobYear")]
        public int DobYear { get; set; } = default;

        //[JsonProperty("canEmail")]
        //public bool CanEmail { get; set; } = true;

        //[JsonProperty("canSms")]
        //public bool CanSms { get; set; } = true;

        //[JsonProperty("canPush")]
        //public bool CanPush { get; set; } = true;

        [JsonProperty("image")]
        public IFormFile Image { get; set; }
    }

    public class UpdateUserProfileRequestV2
    {

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("dobDay")]
        public int DobDay { get; set; } = default;

        [JsonProperty("dobMonth")]
        public int DobMonth { get; set; } = default;

        [JsonProperty("dobYear")]
        public int DobYear { get; set; } = default;

        //[JsonProperty("canEmail")]
        //public bool CanEmail { get; set; } = true;

        //[JsonProperty("canSms")]
        //public bool CanSms { get; set; } = true;

        //[JsonProperty("canPush")]
        //public bool CanPush { get; set; } = true;

        [JsonProperty("image")]
        public IFormFile Image { get; set; }
        
        [JsonProperty("isImageDelete")]
        public bool IsImageDelete { get; set; }
    }
}
