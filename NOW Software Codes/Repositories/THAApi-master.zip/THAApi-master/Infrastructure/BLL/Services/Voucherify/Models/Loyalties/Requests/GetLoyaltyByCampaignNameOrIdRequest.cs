﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Loyalties.Requests
{
    public class GetLoyaltyByCampaignNameOrIdRequest
    {
        public string CampaignIdOrName { get; set; } = null!;
    }
}
