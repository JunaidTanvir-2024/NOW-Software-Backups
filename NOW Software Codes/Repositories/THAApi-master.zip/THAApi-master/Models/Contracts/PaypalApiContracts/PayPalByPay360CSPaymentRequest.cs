﻿using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.PaypalApiContracts
{
	public class PayPalByPay360CSPaymentRequest
	{
		[JsonProperty("customerName")]
		[Required]
		public string CustomerName { get; set; }

		[JsonProperty("customerUniqueRef")]
		[Required]
		public string CustomerUniqueRef { get; set; }

		[JsonProperty("customerMsisdn")]
		public string CustomerMsisdn { get; set; }

		[JsonProperty("CustomerEmail")]
		public string CustomerEmail { get; set; }

		[JsonProperty("transactionCurrency")]
		public string transactionCurrency { get; set; }

		[JsonProperty("transactionAmount")]
		public decimal transactionAmount { get; set; }

		[JsonProperty("isDirectFullfilment")]
		public bool isDirectFullfilment { get; set; }

		[JsonProperty("ipAddress")]
		public string ipAddress { get; set; }

		[JsonProperty("productCode")]
		[Required]
		public string ProductCode { get; set; }

		[Required]
		public PayPalByPay360PaymentMethod PaymentMethod { get; set; }

		[JsonProperty("basket")]
		[Required]

		public List<PayPalByPay360Basket> Basket { get; set; }
		public PayPalByPay360BillingAddress CustomerBillingAddress { get; set; }
		public PayPalByPay360CustomField CustomFields { get; set; }
		public bool sendPay360Email { get; set; }
	}


	public class PayPalByPay360BillingAddress
	{
		public string line1 { get; set; }
		public string line2 { get; set; }
		public string line3 { get; set; }
		public string line4 { get; set; }
		public string city { get; set; }
		public string region { get; set; }
		public string postcode { get; set; }
		public string countryCode { get; set; }
	}
	public class PayPalByPay360CustomField
	{
		public List<PayPalByPay360FieldState> fieldState { get; set; }
	}
	public class PayPalByPay360FieldState
	{
		public string name { get; set; }
		public string value { get; set; }
		public bool transient { get; set; } = false;

	}
	public class PayPalByPay360PaymentMethod
	{
		public PayPalByPay360Urls Paypal { get; set; }
	}

	public class PayPalByPay360Urls
	{
		[Required]
		public string returnUrl { get; set; }

		[Required]
		public string cancelUrl { get; set; }
	}
}
