
namespace MM.Core.Common.Interfaces.Services;
public interface IEmailService
{
    Task SendEmailAsync(SendEmailRequestDTO sendEmailRequestDTO);
}
