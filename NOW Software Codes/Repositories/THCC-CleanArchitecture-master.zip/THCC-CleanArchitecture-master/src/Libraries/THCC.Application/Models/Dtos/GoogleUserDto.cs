﻿
using Newtonsoft.Json;

namespace THCC.Application.Models.Dtos
{
    public class GoogleUserDto
    {
        [JsonProperty("sub")]
        public string? Id { get; set; }

        [JsonProperty("name")]
        public string? Name { get; set; }

        [JsonProperty("given_name")]
        public string? Given_name { get; set; }

        [JsonProperty("family_name")]
        public string? Family_name { get; set; }

        [JsonProperty("email")]
        public string? Email { get; set; }

        [JsonProperty("email_verified")]
        public string? EmailVerified { get; set; }

        [JsonProperty("picture")]
        public string? Picture { get; set; }
    }
}
