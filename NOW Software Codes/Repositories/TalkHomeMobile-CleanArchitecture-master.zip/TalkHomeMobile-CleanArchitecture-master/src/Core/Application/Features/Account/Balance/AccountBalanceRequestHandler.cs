using Application.Common.Interfaces;
using Application.Common.Models;
using Application.Common.Settings;
using Application.Features.Account.ProductSummary;
using Microsoft.Extensions.Options;

namespace Application.Features.Account.Balance;

public class AccountBalanceRequestHandler : IRequestHandler<AccountBalanceRequest, Result<AccountBalanceResponse>>
{
    #region Fields
    private readonly IStringLocalizer<AccountBalanceRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;
    private readonly ProfileSettings _profileSetting;
    private readonly CallBackSettings _callBackSettings;
    private readonly ICommonService _commonService;

    #endregion

    #region Ctor

    public AccountBalanceRequestHandler(
         IStringLocalizer<AccountBalanceRequestHandler> localizer,
         IUnitOfWork unitOfWork,
         IMapper mapper,
         ICurrentUser currentUser,
         IOptions<CallBackSettings> callBackSettings,
         ICommonService commonService,
         IOptions<ProfileSettings> profileSetting)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _currentUser = currentUser;
        _profileSetting = profileSetting.Value;
        _callBackSettings = callBackSettings.Value;
        _commonService = commonService;
    }
    #endregion

    #region Method
    public async Task<Result<AccountBalanceResponse>> Handle(AccountBalanceRequest request, CancellationToken cancellationToken)
    {
        var response = new AccountBalanceResponse();
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        var products = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        if (products.Any(x => x.Msisdn == request.Msisdn))
        {
            var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
            if (msisdnDetails == null)
            {
                return Result<AccountBalanceResponse>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            }
            response = new AccountBalanceResponse()
            {
                Id = 0,
                Balance = (Single) msisdnDetails!.Credit,
                Msisdn = msisdnDetails!.Msisdn,
                CurrencySymbol = CurrencySymbol.GBP,
            };
        }
        return Result<AccountBalanceResponse>.Success(response, _localizer[CustomStatusKey.Success]);
    }
    #endregion
}