﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Response
{
    public class UserAccountSummary
    {
        public string productRef { get; set; }

        public decimal creditRemaining { get; set; }

        public string currency { get; set; }

        public string activeDate { get; set; }

        public int points { get; set; }
        public string RefreashedToken { get; set; }
    }
}
