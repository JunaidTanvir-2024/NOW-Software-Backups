﻿using SMSOutReach.Modal.Xeebi;
using System.Collections.Generic;

namespace SMSOutReach.Infastructure.Interface
{
    public interface ISenderProduct
    {
        List<SenderProduct> GetSenderProducts();
    }
}
