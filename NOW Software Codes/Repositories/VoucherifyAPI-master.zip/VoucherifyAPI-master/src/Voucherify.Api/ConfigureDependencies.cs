using FluentValidation;
using Voucherify.Core;
using Voucherify.Api.Features.Loyalties.Requests;
using Voucherify.Api.Features.EarningRules.Requests;
using Voucherify.Api.Features.Products.Requests;
using Voucherify.Api.Features.StackableDiscounts.Requests;
using Voucherify.Api.Features.Loyalties;
using Voucherify.Api.Features.Utility;
using Voucherify.Api.Features.Promotions.Requests;
using Voucherify.Api.Features.Customers.Requests;
using Voucherify.Api.Features.Campaigns.Requests;
using Voucherify.Api.Features.Products;
using Voucherify.Api.Features.EarningRules;
using Voucherify.Api.Features.Vouchers.Requests;
using Voucherify.Api.Features.Utility.Requests;
using Voucherify.Api.Features.StackableDiscounts;
using Voucherify.Api.Features.Customers;
using Voucherify.Api.Features.Promotions;
using Voucherify.Api.Features.Vouchers;
using Voucherify.Api.Features.Campaigns;

namespace Voucherify.Api;

public static class ConfigureDependencies
{
    public static IServiceCollection AddApiDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.RegisterRequestsValidation();
        services.RegisterHandlers();
        services.AddCoreDependencies(configuration);
        return services;
    }
    private static IServiceCollection RegisterRequestsValidation(this IServiceCollection services)
    {
        // Customers Region
        services.AddScoped<IValidator<AddCustomerRequest>, AddCustomerRequestValidator>();
        services.AddScoped<IValidator<UpdateCustomerRequest>, UpdateCustomerRequestValidator>();
        services.AddScoped<IValidator<GetCustomerRequest>, CustomerByIdRequestValidator>();
        services.AddScoped<IValidator<GetCustomersRequest>, CustomersRequestValidator>();
        services.AddScoped<IValidator<DeleteCustomerRequest>, DeleteCustomerByIdRequestValidator>();
        services.AddScoped<IValidator<GetReferralCodeRequest>, GetReferralCodeRequestValidator>();

        // Vouchers Region
        services.AddScoped<IValidator<GetVouchersRequest>, GetVouchersRequestValidator>();
        services.AddScoped<IValidator<GetVoucherRequest>, GetVoucherByIdRequestValidator>();
        services.AddScoped<IValidator<DeleteVoucherRequest>, DeleteVoucherRequestValidator>();
        services.AddScoped<IValidator<RedeemVoucherRequest>, RedeemVoucherRequestValidator>();
        services.AddScoped<IValidator<ValidateVoucherRequest>, ValidateVoucherRequestValidator>();

        // Campaigns Region
        services.AddScoped<IValidator<GetCampaignsRequest>, GetCampaignsRequestValidator>();
        services.AddScoped<IValidator<GetCustomerCampaignsRequest>, GetCustomerCampaignsRequestValidator>();
        services.AddScoped<IValidator<GetCampaignRequest>, GetCampaignByIdOrNameRequestValidator>();

        // Promotions Region
        services.AddScoped<IValidator<GetPromotionTierByIdRequest>, GetPromotionTierByIdRequestValidator>();
        services.AddScoped<IValidator<GetPromotionTiersRequest>, GetPromotionsRequestValidator>();
        services.AddScoped<IValidator<ValidatePromotionTierRequest>, ValidatePromotionTierRequestValidator>();
        services.AddScoped<IValidator<RedeemPromotionTierRequest>, RedeemPromotionTierRequestValidator>();
        services.AddScoped<IValidator<GetCustomerSpecificPromotionTiersRequest>, GetCustomerSpecificPromotionTiersRequestValidator>();

        // Earning Rules Region
        services.AddScoped<IValidator<GetEarningRulesRequest>, GetEarningRulesRequestValidator>();
        services.AddScoped<IValidator<GetEarningRuleRequest>, GetEarningRuleRequestValidator>();
        services.AddScoped<IValidator<EnableEarningRuleRequest>, EnableEarningRuleRequestValidator>();
        services.AddScoped<IValidator<DisableEarningRuleRequest>, DisableEarningRuleRequestValidator>();

        // Loyalties Region
        services.AddScoped<IValidator<AddLoyaltyPointsRequest>, AddLoyaltyPointsRequestValidator>();
        services.AddScoped<IValidator<GetLoyaltyRewardsByCampaignIdRequest>, GetLoyaltyRewardsByCampaignIdRequestValidator>();
        services.AddScoped<IValidator<GetLoyaltiesRequest>, GetLoyaltiesRequestValidator>();
        services.AddScoped<IValidator<GetLoyaltyByCampaignNameRequest>, GetLoyaltyByCampaignNameRequestValidator>();

        // Utility Region
        services.AddScoped<IValidator<InvokeEventRequest>, InvokeEventRequestValidator>();

        // Stackable Discounts Region
        services.AddScoped<IValidator<StackableDiscountRedemptionRequest>, StackableDiscountRedemptionRequestValidator>();
        services.AddScoped<IValidator<StackableDiscountValidationRequest>, StackableDiscountValidationRequestValidator>();
        services.AddScoped<IValidator<StackableDiscountRollbackRequest>, StackableDiscountRollbackRequestValidator>();
        services.AddScoped<IValidator<GetProductsRequest>, GetProductsRequestValidator>();
        services.AddScoped<IValidator<GetProductRequest>, GetProductRequestValidator>();
        services.AddScoped<IValidator<GetSkusRequest>, GetSkusRequestValidator>();
        services.AddScoped<IValidator<GetProductSkuRequest>, GetProductSkuRequestValidator>();

        return services;
    }
    private static IServiceCollection RegisterHandlers(this IServiceCollection services)
    {
        services.AddScoped<IVouchersHandler, VouchersHandler>();
        services.AddScoped<ICustomersHandler, CustomersHandler>();
        services.AddScoped<IPromotionsHandler, PromotionsHandler>();
        services.AddScoped<ICampaignsHandler, CampaignsHandler>();
        services.AddScoped<IEarningRulesHandler, EarningRulesHandler>();
        services.AddScoped<ILoyaltiesHandler, LoyaltiesHandler>();
        services.AddScoped<IUtilityHandler, UtilityHandler>();
        services.AddScoped<IStackableDiscountsHandler, StackableDiscountsHandler>();
        services.AddScoped<IProductsHandler, ProductsHandler>();

        return services;
    }
}
