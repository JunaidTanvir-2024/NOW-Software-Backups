﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.Configurations
{
    public class AppsFlyerConfig
    {
        public string ApiEndpoint { get; set; }
        public bool IsActive { get; set; }
    }
}
