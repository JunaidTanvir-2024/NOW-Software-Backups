﻿using THCC.Application.Extensions.FluentValidation;
using THCC.Application.Settings;

namespace THCC.Application.Features.User.Profile.UpdateProfileImage;

public class UpdateProfileImageRequest : IRequest<object>
{
    public IFormFile Image { get; set; } = default!;
}

public class UpdateProfileImageRequestValidator : AbstractValidator<UpdateProfileImageRequest>
{
    public UpdateProfileImageRequestValidator(IOptions<FileUploadSettings> fileSettings)
    {
        RuleFor(p => p.Image!).NotNull().NotEmpty().FileSmallerThan(fileSettings.Value.FileSizeInBytes).FileExtensionAllowed(fileSettings);
    }
}
