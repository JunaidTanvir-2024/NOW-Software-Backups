namespace Voucherify.Core.Commons.Extensions;

public static class UtilityExtensions
{
    public static int StringToInt(this object value)
    {
        return value is string stringValue && int.TryParse(stringValue, out int intValue) ? intValue : 0;
    }
    public static long StringToLong(this object value)
    {
        return value is string stringValue && long.TryParse(stringValue, out long intValue) ? intValue : 0;
    }
}
