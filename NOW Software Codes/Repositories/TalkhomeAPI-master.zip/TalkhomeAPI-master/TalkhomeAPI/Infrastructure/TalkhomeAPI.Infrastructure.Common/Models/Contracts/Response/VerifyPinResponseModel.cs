﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.DTOs;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class VerifyPinResponseModel
    {
        public UserInfo User { get; set; }
        public string Token { get; set; }
        public DateTime ValidTo { get; set; }
    }
}
