﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.Configurations
{
    public class AirshipConfig
    {
        public bool IsActive { get; set; }
        public string PaymentTagGroupName { get; set; }
        public string CustomerTagGroupName { get; set; }
        public string ApiEndpoint { get; set; }
        public string ActivityTagGroupName { get; set; }
        public string TransactionTagGroupName { get; set; }
        public string ServiceTagGroupName { get; set; }
    }
}
