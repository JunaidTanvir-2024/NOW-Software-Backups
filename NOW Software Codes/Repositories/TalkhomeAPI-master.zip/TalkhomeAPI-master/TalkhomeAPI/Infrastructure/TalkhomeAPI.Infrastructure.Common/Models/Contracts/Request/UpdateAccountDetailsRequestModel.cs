﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class UpdateAccountDetailsRequestModel
    {
        [Required(ErrorMessage = "Enter first name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Please enter alphabets only")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Enter last name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Please enter alphabets only")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Enter email address"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [EmailAddress(ErrorMessage = "Email is invalid")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Email is invalid")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Select day")]
        [Range(1, 31)]
        public int DayOfBirth { get; set; }

        [Required(ErrorMessage = "Select month")]
        [Range(1, 12)]
        public int MonthOfBirth { get; set; }

        public bool EmailSubscription { get; set; }
    }
}
