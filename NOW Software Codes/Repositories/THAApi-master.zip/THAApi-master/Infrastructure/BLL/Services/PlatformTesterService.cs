﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.BLL.Services
{
    
    public class PlatformTesterService : IPlatformTesterService
    {
        private const bool includeTesters = true;
        private List<string> whitelistedDevelopers = new List<string> { 
            "447422479143",
            "447421698483",
            "447776266239",
            "447421216083",
            "447421698459",
            "447756490226",
            "447789633879",
            "921234567890",
            "923325226145",
            "447825152591",
            "447410710242",
            "918602665454",
            "918602665544",
            "447419365581","447410877070","447419365592"};
        private List<string> whitelistedTesters = new List<string> {
            "447579111111",
            "447929591941",
            "447419626174",
            "447579733333",
            "391234512345",
            "971552367278",
            "447410710242"
        };
        private readonly IPhoneNumberService phoneNumberService;

        public PlatformTesterService(IPhoneNumberService phoneNumberService)
        {
            this.phoneNumberService = phoneNumberService;
        }

        public bool CanTestInAppPurchase(string msisdn)
        {
            if (whitelistedDevelopers.Contains(msisdn))
            {
                return true;
            }
            return false;
        }

        public bool CanTestBundles(string msisdn)
        {
            if (whitelistedDevelopers.Contains(msisdn))
            {
                return true;
            }
            else if (includeTesters)
            {
                if (whitelistedTesters.Contains(msisdn))
                {
                    return true;
                }
            }
            return false;
        }

        public bool CanUseBundes(string msisdn)
        {
            if (msisdn.StartsWith("+44") ||
                msisdn.StartsWith("44") ||
                msisdn.StartsWith("39") ||
                msisdn.StartsWith("+39") ||
                msisdn.StartsWith("+33") ||
                msisdn.StartsWith("33") ||
                msisdn.StartsWith("+971") ||
                msisdn.StartsWith("971"))
            {
                return true;
            }
            return false;
        }
    }
}
