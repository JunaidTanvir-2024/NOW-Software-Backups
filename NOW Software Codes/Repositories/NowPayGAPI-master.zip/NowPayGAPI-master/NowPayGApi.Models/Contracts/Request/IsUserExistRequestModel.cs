﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class IsUserExistRequestModel
    {
        public string Email { get; set; }
    }
}
