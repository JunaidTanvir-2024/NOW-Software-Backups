﻿using SenderService.Core.Common.Enums;

namespace SenderService.Core.Persistence.Entities;

//public class Email
//{
//    public long Id { get; set; }

//    public string FromEmail { get; set; } = null!;

//    public string? FromName { get; set; }

//    public string? ReplyToEmail { get; set; }

//    public string? ReplyToName { get; set; }

//    public string Subject { get; set; } = null!;

//    public string Body { get; set; } = null!;

//    public int Attempts { get; set; }

//    public byte Priority { get; set; }

//    public byte ProcessingStatus { get; set; }

//    public string? AttachmentFilePath { get; set; }

//    public DateTime? ScheduledDateTimeUtc { get; set; }

//    public DateTime CreatedOnUtc { get; set; }

//    public long ProductItemCodeId { get; set; }

//    public virtual ICollection<EmailRecipient> EmailRecipients { get; } = new List<EmailRecipient>();

//    public virtual ProductItemCode ProductItemCode { get; set; } = null!;

//    public List<string> ToEmails => EmailRecipients.Where(x => x.RecipientType == (byte) RecipientType.To).Select(x => x.EmailAddress).ToList();

//    public List<string> CcEmails => EmailRecipients.Where(x => x.RecipientType == (byte) RecipientType.CC).Select(x => x.EmailAddress).ToList();

//    public List<string> BccEmails => EmailRecipients.Where(x => x.RecipientType == (byte) RecipientType.BCC).Select(x => x.EmailAddress).ToList();
//}

public class Email
{
    public long Id { get; set; }

    public string FromEmail { get; set; } = null!;

    public string? FromName { get; set; }

    public string Subject { get; set; } = null!;

    public string Body { get; set; } = null!;

    public int Attempts { get; set; }

    public byte Priority { get; set; }

    public byte ProcessingStatus { get; set; }

    //public string? AttachmentFilePath { get; set; }

    public DateTime ScheduledDateTimeUtc { get; set; }

    public DateTime CreatedOnUtc { get; set; }

    public bool IsSent { get; set; }

    public DateTime SentDateTimeUtc { get; set; }

    public DateTime LastAttemptDateTimeUtc { get; set; }

    public string? ErrorMessage { get; set; }

    public long ProductCodeId { get; set; }

    public virtual ICollection<EmailRecipient> EmailRecipients { get; } = new List<EmailRecipient>();

    public virtual ProductCode ProductCode { get; set; } = null!;

    public List<string> ToEmails => EmailRecipients.Where(x => x.RecipientType == (byte) RecipientType.To).Select(x => x.EmailAddress).ToList();

    public List<string> CcEmails => EmailRecipients.Where(x => x.RecipientType == (byte) RecipientType.CC).Select(x => x.EmailAddress).ToList();

    public List<string> BccEmails => EmailRecipients.Where(x => x.RecipientType == (byte) RecipientType.BCC).Select(x => x.EmailAddress).ToList();
}