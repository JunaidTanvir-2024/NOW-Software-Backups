namespace Application.Features.Rate.Model;

public class RoamingRate
{
    public string IsoCode { get; set; } = default!;
    public int FromCountry { get; set; }
    public int ToCountry { get; set; }
    public float Call { get; set; }
    public float SMS { get; set; }
    public float Data { get; set; }
    public float ReceivedCall { get; set; }
    public bool IsEU { get; set; }=false;
}
