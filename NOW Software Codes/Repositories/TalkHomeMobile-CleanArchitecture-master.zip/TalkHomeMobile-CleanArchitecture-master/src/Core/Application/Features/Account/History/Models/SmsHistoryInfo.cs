namespace Application.Features.Account.History.Models;

public sealed class SmsHistoryInfo
{
    public DateTime DateStarted { get; set; }
    public string? ReceiverNumber { get; set; }
    [JsonIgnore]
    public long TotalCount { get; set; }
    public string? SubscriberCharge { get; set; }
}