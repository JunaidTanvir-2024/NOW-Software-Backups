﻿using CancelBundleApi.Models.DbModels;

namespace CancelBundleApi.Services.Interfaces;

public interface IUserServices
{
    Task<MsisdnDetails> GetMsisdnDetail(string msisdn);
}