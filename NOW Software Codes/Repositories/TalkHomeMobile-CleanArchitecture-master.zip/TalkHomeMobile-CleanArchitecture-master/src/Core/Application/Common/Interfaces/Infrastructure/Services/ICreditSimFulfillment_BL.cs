﻿using Application.Common.Extensions.DependencyResolver;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Interfaces.Infrastructure.Services;
public interface ICreditSimFulfillmentService : IServicesType.IScopedService
{
    Task StartFulfillment();
}
