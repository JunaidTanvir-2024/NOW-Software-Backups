﻿namespace CancelBundleApi.Models.DbModels
{
    public class LkptService
    {
        public int LkptServiceId { set; get; }
        public string ServiceShortDesc { set; get; }
        public string ServiceLongDesc { set; get; }
    }
}
