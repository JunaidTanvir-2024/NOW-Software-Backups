namespace Application.Features.Bundle.Bundle;

public sealed class BundlesRequestValidator : AbstractValidator<BundlesRequest>
{
    public BundlesRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn)
            .Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p!))
            .When(p => !string.IsNullOrEmpty(p.Msisdn))
            .WithMessage("Invalid Msisdn");
    }
}