﻿using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.Account.Profile.UserProfile;
public class UserProfileRequestHandler : IRequestHandler<UserProfileRequest, Result<UserInfo>>
{
    #region Fields

    private readonly IStringLocalizer<UserProfileRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly CallBackSettings _callBackSettings;
    private readonly ProfileSettings _profileSetting;

    #endregion

    #region Ctor

    public UserProfileRequestHandler(
        IStringLocalizer<UserProfileRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICurrentUser currentUser,
        IMapper mapper,
        IOptions<ProfileSettings> profileSetting,
        IOptions<CallBackSettings> callBackSettings)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _currentUser = currentUser;
        _profileSetting = profileSetting.Value;
        _mapper = mapper;
        _callBackSettings = callBackSettings.Value;
    }

    #endregion

    #region Method

    public async Task<Result<UserInfo>> Handle(UserProfileRequest request, CancellationToken cancellationToken)
    {
        var user = await _unitOfWork.UserRepo.GetUserByIdAsync(_currentUser.GetUserId());
        var userInfo = _mapper.Map<UserInfo>(user!);
        if (!string.IsNullOrEmpty(userInfo.Image))
        {
            userInfo.Image = $"{_callBackSettings.WebBaseUrl}{_profileSetting.VirtualDirectoryName}/{user!.Id}/{user.Image}";
        }
        return Result<UserInfo>.Success(userInfo, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
