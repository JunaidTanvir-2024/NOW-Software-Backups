﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrasnferHome.Models.Configurations
{
    public class RedirectUrls
    {
        public string VerifyEmailRedirectUrl { get; set; }
        public string ForgotPasswordRedirectUrl { get; set; }
    }
}
