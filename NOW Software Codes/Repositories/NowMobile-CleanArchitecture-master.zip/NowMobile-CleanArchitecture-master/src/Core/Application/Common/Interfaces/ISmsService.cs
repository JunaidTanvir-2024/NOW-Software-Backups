﻿namespace Application.Common.Interfaces;

public interface ISmsService : ISerivcesType.ITransientService
{
    Task SendOtpMessage(string msisdn, string otp);
}
