﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.ContactUs
{
    public class ContactUsRequestHandler : IRequestHandler<ContactUsRequest, object>
    {
        private readonly IMailService _mailService;

        public ContactUsRequestHandler(IMailService mailService)
        {
            _mailService = mailService;
        }

        Task<object> IRequestHandler<ContactUsRequest, object>.Handle(ContactUsRequest request, CancellationToken cancellationToken)
        {
            //await _mailService.SendContactUsEmail(
            //    name: request.Name.Trim()!,
            //    email: request.Email.Trim()!,
            //    phoneNumber: request.PhoneNumber!,
            //    message: request.Message.Trim()!);
            throw new NotImplementedException();
        }
    }
}
