﻿using FluentValidation;

namespace Voucherify.Api.Features.Vouchers.Requests;

public class DeleteVoucherRequest
{
    public string VoucherCodeOrId { get; set; } = null!;
}
internal class DeleteVoucherRequestValidator : AbstractValidator<DeleteVoucherRequest>
{
    public DeleteVoucherRequestValidator()
    {
        RuleFor(p => p.VoucherCodeOrId).NotNull().NotEmpty();
    }
}