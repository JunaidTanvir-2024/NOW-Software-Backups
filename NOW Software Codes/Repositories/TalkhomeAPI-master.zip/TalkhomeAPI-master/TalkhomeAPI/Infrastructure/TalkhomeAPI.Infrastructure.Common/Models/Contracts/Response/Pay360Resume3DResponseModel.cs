﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class Pay360Resume3DResponseModel
    {
        public BundlePurchaseInfo bundlePurchaseInfo { get; set; }
        public TopupInfo topupInfo { get; set; }
    }
}
