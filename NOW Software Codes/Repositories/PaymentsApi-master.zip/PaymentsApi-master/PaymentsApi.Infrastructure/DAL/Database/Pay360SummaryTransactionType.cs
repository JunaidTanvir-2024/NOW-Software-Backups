﻿using PaymentsApi.Infrastructure.DAL.EnumToLookup;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public class Pay360SummaryTransactionType : LookupTableBase
    {
        public Pay360SummaryTransactionType()
        {

        }
    }
}
