﻿namespace Application.Features.AutoTopup.GetAutoTopupV2;

public class GetAutoTopupRequestValidatorV2 : AbstractValidator<GetAutoTopupRequestV2>
{
    public GetAutoTopupRequestValidatorV2(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");
    }
}