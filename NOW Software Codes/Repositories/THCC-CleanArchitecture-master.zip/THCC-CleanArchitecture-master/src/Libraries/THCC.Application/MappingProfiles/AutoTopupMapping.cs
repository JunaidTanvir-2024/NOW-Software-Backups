﻿using THCC.Application.Models.Dtos;

namespace THCC.Application.MappingProfiles;
public sealed class AutoTopupMapping : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<AutoTopup, AutoTopupResponseDto>
           .NewConfig()
            .Map(autotopupDto => autotopupDto.MaskedPan, autotopup => $"{autotopup.MaskedPan}")
            .Map(autotopupDto => autotopupDto.Threshold, autotopup => $"{autotopup.ThresHold}")
            .Map(autotopupDto => autotopupDto.Amount, autotopup => $"{autotopup.Topup}")
            .Map(autotopupDto => autotopupDto.Status, autotopup => $"{autotopup.Status}");
    }
}