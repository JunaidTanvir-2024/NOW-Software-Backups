﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using SmsOutReachCallBackUrlApi.Contracts.Poppayouts.Request;
using SmsOutReachCallBackUrlApi.Models;
using SmsOutReachCallBackUrlApi.Models.Configurations;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SmsOutReachCallBackUrlApi.Infrastructure.Poppayouts
{
    public class PoppayoutsPost : IPoppayoutsPost
    {
        private readonly ILogger Logger;
        private IPoppayoutsDb Db;

        public PoppayoutsPost(ILogger logger, IOptions<ConnectionString> connectionConfig)
        {
            Logger = logger;
            string connectionString = connectionConfig.Value.DefaultConnection;
            Db = new PoppayoutsDb(connectionString);
        }

        async public Task<DbResult> InsertUpdateSmsCallBackUrlData(PoppayoutsSmsCallBackUrlRequest deliveryReport)
        {

            DbResult result = null;
            try
            {

                result = await Db.InsertUpdateSmsCallBackUrlData(deliveryReport);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Database Insertion Error: - Class: PoppayoutPost, Method: InsertUpdateSmsCallBackUrlData, Parameters --> SmsCallBackUrlJson: {JsonConvert.SerializeObject(deliveryReport)}, Exception: {ex.Message}");
                result = new DbResult();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                return result;
            }
        }
    }
}
