﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using THCCWEB.Utilities;

namespace THCCWEB.Models.ViewModels.CheckOutView
{
    public class Secure3DViewModel
    {
        public string MD { get; set; }
        public string PaRes { get; set; }
        public string Type { get; set; }
        public bool IsAutoTopup { get; set; }
        public bool IsAuthenticated { get; set; }
        public string AccountNumber { get; set; }
        public string Email { get; set; }
    }
}
