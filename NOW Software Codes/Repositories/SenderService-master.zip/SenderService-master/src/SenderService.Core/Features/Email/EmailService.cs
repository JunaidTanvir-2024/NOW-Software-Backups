﻿using MapsterMapper;
using SenderService.Core.Common;
using SenderService.Core.Common.Enums;
using SenderService.Core.Features.Email.Request;
using SenderService.Core.Features.Email.Response;
using SenderService.Core.Persistence.Entities;
using SenderService.Core.Persistence.Repository;
using System.Net;

namespace SenderService.Core.Features.Email;

internal sealed class EmailService : IEmailService
{
    private readonly IEmailRepository _emailRepository;
    private readonly IEmailRecipientRepository _emailRecipientRepository;
    private readonly IProductCodeRepository _productCodeRepository;
    private readonly IMapper _mapper;

    public EmailService(IEmailRepository emailRepository, IEmailRecipientRepository emailRecipientRepository, IProductCodeRepository productCodeRepository, IMapper mapper)
    {
        _emailRepository = emailRepository;
        _emailRecipientRepository = emailRecipientRepository;
        _productCodeRepository = productCodeRepository;
        _mapper = mapper;
    }

    public async Task<ApiResult<bool>> AddEmailAsync(AddEmailRequest request)
    {
        var formatedProductCode = request.ProductCode.Trim().ToUpperInvariant();

        var productCode = await _productCodeRepository.GetProductCodeByItemCodeAsync(formatedProductCode);
        if (productCode == null)
        {
            return ApiResult<bool>.Failure("Product Item Code not exist", errorCode: (int) HttpStatusCode.BadRequest);
        }

        var email = new Persistence.Entities.Email
        {
            FromEmail = request.FromEmail,
            FromName = request.FromName,
            Subject = request.Subject,
            Body = request.Body,
            Priority = request.Priority,
            ProcessingStatus = (int) ProcessingState.Pending,
            ScheduledDateTimeUtc = DateTime.UtcNow,
            CreatedOnUtc = DateTime.UtcNow,
            ProductCodeId = productCode.Id,
        };
        var emailId = await _emailRepository.AddEmailAsync(email);


        var emailRecieptents = request.Recipients.ConvertAll(a => new EmailRecipient
        {
            EmailId = emailId,
            EmailAddress = a.EmailAddress,
            RecipientName = a.RecipientName,
            RecipientType = a.RecipientType
        });

        await _emailRecipientRepository.AddBulkEmailRecipientAsync(emailRecieptents);

        return ApiResult<bool>.Success(successCode: (int) HttpStatusCode.Created);
    }

    public async Task DeleteEmailAsync(RemoveEmailRequest request)
    {
        await _emailRepository.DeleteAsync(request.Email!, request.RecipientType);
    }

    public async Task<EmailResponse> GetSpecificEmailRecordAsync(GetSpecificEmailRecordRequest request)
    {
        var email = await _emailRepository.GetSpecificEmailRecordAsync(request.Email);
        return _mapper.Map<EmailResponse>(email!);
    }

    public async Task<ApiResult<IEnumerable<EmailResponse>>> GetEmailsAsync(GetEmailsRequest request)
    {

        var emails = await _emailRepository.GetEmailsAsync(request.PageNumber, request.PageSize, request.Email);
        if (emails.Any())
        {
            return ApiResult<IEnumerable<EmailResponse>>.Success(data: _mapper.Map<List<EmailResponse>>(emails));
        }
        else
        {
            return ApiResult<IEnumerable<EmailResponse>>.Failure(message: "No unsent email", errorCode: (int) HttpStatusCode.NotFound);
        }
    }

    public async Task<bool> UpdateEmailAsync(UpdateEmailRequest request)
    {
        var email = await _emailRepository.GetSpecificEmailRecordAsync(request.Email);
        if (email != null)
        {
            email.FromEmail = request.FromEmail!;
            email.Subject = request.Subject!;
            email.Body = request.Body!;
            email.Priority = request.Priority;
            email.ProductCodeId = request.ProductCodeId;

            await _emailRepository.UpdateEmailAsync(email);

            return true;
        }
        return false;
    }
}