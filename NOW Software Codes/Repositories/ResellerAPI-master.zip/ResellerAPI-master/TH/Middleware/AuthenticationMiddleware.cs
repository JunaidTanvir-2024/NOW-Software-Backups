﻿using Microsoft.AspNetCore.Http;
using Serilog;
using System;
using System.Text;
using System.Threading.Tasks;
using TH.Infrastructure.DAL;
using TH.Models.Database;

namespace TH.Middleware
{
    

    public class AuthenticationMiddleware
    {

        private readonly RequestDelegate Next;        
        private readonly ILogger Logger;
        private ITHDb_DL Db;

        public AuthenticationMiddleware(RequestDelegate next, ILogger logger, ITHDb_DL db)
        {
            Next = next;
            Logger = logger;
            Db = db;
        }

        public async Task InvokeAsync(HttpContext context)
        {

            try
            {
                string authHeader = context.Request.Headers["Authorization"];
                if (authHeader != null && authHeader.StartsWith("basic", StringComparison.OrdinalIgnoreCase))
                {
                    //Extract credentials
                    string encodedUsernamePassword = authHeader.Substring("Basic ".Length).Trim();
                    //Encoding encoding = Encoding.GetEncoding("iso-8859-1");
                    //string usernamePassword = encoding.GetString(Convert.FromBase64String(encodedUsernamePassword));

                    string usernamePassword = Encoding.UTF8.GetString(Convert.FromBase64String(encodedUsernamePassword));

                    string[] credentials = usernamePassword.Split(':');

                    if (credentials.Length == 2)
                    {
                        
                        User user = await Db.Login(credentials[0], credentials[1]);

                        if (user != null)
                        {
                            await Next.Invoke(context);
                        }
                        else
                        {
                            context.Response.StatusCode = 401; //Unauthorized
                            context.Response.Headers.Add("WWW-Authenticate", "Basic realm=\"realm\"");
                            return;
                        }
                    }
                    else
                    {
                        context.Response.StatusCode = 401; //Unauthorized
                        context.Response.Headers.Add("WWW-Authenticate", "Basic realm=\"realm\"");
                        return;
                    }
                }
                else
                {
                    // no authorization header
                    context.Response.StatusCode = 401; //Unauthorized
                    context.Response.Headers.Add("WWW-Authenticate", "Basic realm=\"realm\"");
                    return;
                }
            }
            catch(Exception ex)
            {

                Logger.Error($"Class: AuthenticationMiddleware, Method: InvokeAsync, ErrorMessage:{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                context.Response.StatusCode = 500; //Internal Server Error               
                return;
            }
        }


    }
}
