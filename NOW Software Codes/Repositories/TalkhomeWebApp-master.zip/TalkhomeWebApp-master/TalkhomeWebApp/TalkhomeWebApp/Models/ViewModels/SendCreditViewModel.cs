﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class SendCreditViewModel
    {
        [Required(ErrorMessage = "Enter your phone number")]
        [StringLength(maximumLength:15)]
        public string TransferPhoneNumber { get; set; }
        public string twoLetterCountryCode { get; set; }
        public string SelectedProductId { get; set; }
        public string Currency { get; set; }
    }
}
