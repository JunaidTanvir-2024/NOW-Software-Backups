﻿
using Application.Features.Carousel;

namespace NowMobile.Api.Controllers;
public class CarouselController : VersionedApiController
{
    [HttpGet]
    [OpenApiOperation("Get carousels.", "")]
    public async Task<IActionResult> GetCarousel([FromQuery] CarouselRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    //[OpenApiOperation("Get promotion carousel.", "")]
    //public async Task<IActionResult> GetCarousel()
    //{
    //    return Ok(await Mediator.Send(new CarouselRequest()));
    //}
}
