using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.DataBundle;

public sealed class DataBundleRequest : IRequest<Result<List<BundleInfo>>>
{
    public string? Msisdn { get; set; } = null;
}
