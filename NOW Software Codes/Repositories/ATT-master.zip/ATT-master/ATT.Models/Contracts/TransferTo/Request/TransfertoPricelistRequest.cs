﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Request
{
    public class TransfertoPricelistRequest : TransfertoBaseRequest
    {
        public string action { get; set; }
        public string info_type { get; set; }
        public int content { get; set; }

        public TransfertoPricelistRequest(string _action, string _info_type, int _content = -1)
        {
            action = _action;
            info_type = _info_type;
            content = _content;
        }

        public string toXML()
        {
            string returnXML = "<TransferTo>";

            returnXML = returnXML + base.toXML() + $"<action>{action}</action><info_type>{info_type}</info_type>";

            if (content != -1)
                returnXML = returnXML + "<content>" + content + "</content>";

            returnXML = returnXML + "</TransferTo>";

            return returnXML;
        }

    }
}
