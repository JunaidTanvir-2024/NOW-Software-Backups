﻿namespace Application.Features.AutoTopup.SetAtutoTopup;

public class SetAutoTopupRequestHandler : IRequestHandler<SetAutoTopupRequest, Result<object>>
{
    private readonly IStringLocalizer<SetAutoTopupRequestHandler> _localizer;
    private readonly ITopupRepository _autoTopupService;
    private readonly ICurrentUser _currentUser;
    private readonly IUserService _userService;

    public SetAutoTopupRequestHandler(
        IStringLocalizer<SetAutoTopupRequestHandler> localizer,
        ITopupRepository autoTopupService,
        ICurrentUser currentUser,
        IUserService userService)
    {
        _localizer = localizer;
        _autoTopupService = autoTopupService;
        _currentUser = currentUser;
        _userService = userService;
    }

    public async Task<Result<object>> Handle(SetAutoTopupRequest request, CancellationToken cancellationToken)
    {
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        await _autoTopupService.SetAutoTopup(
            request.Status,
            request.Msisdn,
            _currentUser.GetUserEmail()!,
            request.TopupAmount,
            Currency.GBP.ToString(),
            request.ThresholdAmount,
            PaymentMethod.Card);
        //var isSuccess=await _autoTopupService.SetAutoTopUp(
        //                        request.Msisdn, _currentUser.GetUserEmail()!,
        //                        request.ThresholdAmount,
        //                        request.TopupAmount,s
        //                        request.Status);
        //if (!isSuccess)
        //{
        //    return Result<object>.Failure(
        //        _localizer[CustomStatusKey.SetAutoTopupFailure], CustomStatusCode.InternalServerError);
        //}

        var responseMessage = _localizer[CustomStatusKey.SetAutoTopupSuccess].ToString();

        return Result<object>.Success(null!, responseMessage.Replace("{status}", request.Status ? "enabled" : "disabled"));
    }
}
