﻿namespace THCC.Application.Models.Dtos;
public class Resume3DV2Info
{
    public string? ThreeDSServerTransId { get; set; }
    public string? TransactionId { get; set; }
    public string? Url { get; set; }
}
