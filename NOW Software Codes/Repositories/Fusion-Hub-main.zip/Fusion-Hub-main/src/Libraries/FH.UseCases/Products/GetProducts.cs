using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;
using RW.Models;

namespace FH.UseCases.Products;

public sealed class GetProducts
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public Filter? Filters { get; set; }

        public sealed record Filter
        {
            public string? CountryIsoCode { get; set; }
            public string? CurrencyCode { get; set; }
            public int? CallingCode { get; set; }
            public string? ValidityUnit { get; set; }
            public int? OperatorId { get; set; }
            public int? ProductId { get; set; }
            public int? ProductCategoryId { get; set; }
            public string? ProductAliasName { get; set; }
            public string? OperatorShortCode { get; set; }
            public string? ProductSubCategoryShortCode { get; set; }
        }
    }

    #endregion Query

    #region Validator

    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Page).GreaterThan(0);
            RuleFor(x => x.RecordsPerPage).LessThan(100);
        }
    }

    #endregion Validator

    #region Response

    public sealed record Response
    {
        public ProductInfo Product { get; set; } = new ProductInfo();

        public sealed record ProductInfo
        {
            public long ProductId { get; set; }
            public string? ProductName { get; set; }
            public string? ProductAliasName { get; set; }
            public string? Description { get; set; }
            public string? Logo { get; set; }
            public string? ValidityUnit { get; set; }
            public string? ValidityValue { get; set; }
            public string? VendorProductCode { get; set; }
            public string? VendorOperatorCode { get; set; }
            public string? ProductType { get; set; }
            public ProductOperatorInfo ProductOperator { get; set; } = new ProductOperatorInfo();
            public ProductCountryInfo ProductCountry { get; set; } = new ProductCountryInfo();
            public ProductCurrencyInfo ProductCurrency { get; set; } = new ProductCurrencyInfo();
            public ProductCategoryInfo ProductCategory { get; set; } = new ProductCategoryInfo();
            public ProductSubCategoryInfo ProductSubCategory { get; set; } = new ProductSubCategoryInfo();
            public ProductVendorInfo ProductVendor { get; set; } = new ProductVendorInfo();
            public ProductPriceInfo ProductPrice { get; set; } = new ProductPriceInfo();
            public string? ProductBenefitsJson { get; set; }
        }
        public sealed record ProductOperatorInfo
        {
            public string? OperatorName { get; set; }
            public string? OperatorDescription { get; set; }
        }

        public sealed record ProductCountryInfo
        {
            public string? CountryName { get; set; }
            public string? CountryIsoCode2 { get; set; }
            public string? CountryIsoCode3 { get; set; }
            public string? Continent { get; set; }
            public string? CallingCode { get; set; }
        }

        public sealed record ProductCurrencyInfo
        {
            public string? CurrencyName { get; set; }
            public string? CurrencyCode { get; set; }
            public bool? CurrencyIsDefault { get; set; }
        }

        public sealed record ProductCategoryInfo
        {
            public string? CategoryName { get; set; }
            public string? CategoryDescription { get; set; }
        }

        public sealed record ProductSubCategoryInfo
        {
            public string? SubCategoryName { get; set; }
            public string? SubCategoryDescription { get; set; }
        }

        public sealed record ProductVendorInfo
        {
            public string? VendorName { get; set; }
            public string? VendorDescription { get; set; }
        }

        public sealed record ProductPriceInfo
        {
            public decimal? SellingPrice { get; set; }
            public decimal? Tax { get; set; }
            public decimal? Fee { get; set; }
            public decimal? MaxPrice { get; set; }
            public decimal? MinPrice { get; set; }
        }
    }

    #endregion Response

    #region Handler

    internal sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IMapper _mapper = mapper;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        async ValueTask<IResultWrapper> IRequestHandler<Query, IResultWrapper>.Handle(Query request, CancellationToken cancellationToken)
        {
            var productsRequestDto = _mapper.Map<ProductDto.Request>(request);

            // Setting Default Values
            //productsRequestDto.Filters = Filters;
            productsRequestDto.IsActive = true;
            productsRequestDto.IsDeleted = false;

            (IEnumerable<ProductDto.Response> products, DatabasePaginationDto pagination) = await _unitOfWork.ProductRepository.GetProducts(productsRequestDto);

            if (products is null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
            }
            var getProductsResponse = _mapper.Map<List<Response>>(products);
            return ResultWrapper.Success(getProductsResponse, new Pagination(pagination.TotalRecords, pagination.TotalPages, request.Page, request.RecordsPerPage));
        }
    }

    #endregion Handler
}
