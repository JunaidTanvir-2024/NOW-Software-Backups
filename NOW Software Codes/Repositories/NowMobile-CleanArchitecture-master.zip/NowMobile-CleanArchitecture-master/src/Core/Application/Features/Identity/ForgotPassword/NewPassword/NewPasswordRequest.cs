﻿using Application.Common.Models.ResponseWrappers;

namespace Application.Features.Identity.ForgotPassword.NewPassword;
public class NewPasswordRequest : IRequest<Result<object>>
{
    public string Password { get; set; } = default!;
    public string ConfirmPassword { get; set; } = default!;
    public string Email { get; set; } = default!;
    public int Otp { get; set; }
}
