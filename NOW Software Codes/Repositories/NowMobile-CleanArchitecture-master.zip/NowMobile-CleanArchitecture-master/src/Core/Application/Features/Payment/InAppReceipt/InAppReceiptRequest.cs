﻿using Application.Features.Address;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Payment.InAppReceipt;
public class InAppReceiptRequest : IRequest<Result<InAppReceiptResponse>>
{
    public string? Msisdn { get; set; }

    //public string? Pin { get; set; }

    public string? Receipt { get; set; }

    public string? AppVersion { get; set; }
}
