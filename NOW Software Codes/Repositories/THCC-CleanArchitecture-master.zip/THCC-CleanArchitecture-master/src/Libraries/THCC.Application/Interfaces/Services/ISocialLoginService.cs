﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Services;

public interface ISocialLoginService : ServiceType.ITransient
{
    Task<GoogleUserDto> GetUserFromGoogle(string accessToken);
    Task<FacebookUserDto> GetUserFromFacebook(string accessToken);
}