﻿using MapsterMapper;
using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder;
public sealed class CustomerOrder
{
    #region Query
    public sealed record Request : IRequest<IResultWrapper>
    {
        public required long OrderID { get; set; }
    }
    #endregion
    public sealed class Validator : AbstractValidator<Request>
    {
        public Validator()
        {

            RuleFor(x => x.OrderID).GreaterThan(0);

        }
    }
    #region response
    public sealed record OrderResponse
    {

        public long CustomerOrderID { get; set; } = default!;
        public string CustomerID { get; set; } = default!;
        public string PromoCode { get; set; } = default!;
        public int DiscountTypeId { get; set; } = default!;
        public decimal DiscountInclusiveAmount { get; set; } = decimal.Zero;
        public decimal DiscountAmount { get; set; } = decimal.Zero;
        public decimal ServiceFee { get; set; } = decimal.Zero;
        public decimal TaxAmount { get; set; } = decimal.Zero;
        public decimal TaxInclusiveAmount { get; set; } = decimal.Zero;
        public decimal TaxExclusiveAmount { get; set; } = decimal.Zero;
        public decimal TotalOrderAmount { get; set; } = decimal.Zero;
        public string Currency { get; set; } = default!;
        public string OrderStatus { get; set; } = default!;
        public long CustomerAddressId { get; set; } = default!;
        public string RequestId { get; set; } = default!;
        public string AddressType { get; set; } = default!;
        public string StreetAddress1 { get; set; } = default!;
        public string StreetAddress2 { get; set; } = default!;
        public string City { get; set; } = default!;
        public string State { get; set; } = default!;
        public string PostalCode { get; set; } = default!;
        public string Country { get; set; } = default!;
        public string Email { get; set; } = default!;
        public string Phone { get; set; } = default!;
        public string Region { get; set; } = default!;
        public string CountryCode { get; set; } = default!;
        public string Firstname { get; set; } = default!;
        public string Lastname { get; set; } = default!;
        public string? PaymentMethod { get; set; }

        public IEnumerable<CartItems> CartDetail { get; set; } = default!;


        public sealed record CartItems
        {
            public long CustomerCartID { get; set; } = default!;
            public string UserID { get; set; } = default!;
            public int ProductId { get; set; } = default!;
            public string ProductName { get; set; } = default!;
            public decimal Price { get; set; } = default!;
            public int Quantity { get; set; } = default!;
            public string Currency { get; set; } = default!;
            public string DiscountType { get; set; } = default!;
            public decimal DiscountAmount { get; set; } = default!;
            public decimal TotalOrderPrice { get; set; } = default!;
            public string Status { get; set; } = default!;
            public string State { get; set; } = default!;
            public int CustomerOrderId { get; set; } = default!;
            public string ProductVendorCode { get; set; } = default!;
            public string ProductType { get; set; } = default!;
            public string ReceiverMobile { get; set; } = default!;
            public string SenderMobile { get; set; } = default!;
            public decimal ServiceFeeAmount { get; set; } = default!;
            public string ProductPriceType { get; set; } = default!;
            public string VendorFinalStatus { get; set; } = default!;
        }
    }
    #endregion

    #region handler
    internal sealed class Handler(ICustomerCartRespository customerCartRespository, IMapper mapper, ICommonService commonService) : IRequestHandler<Request, IResultWrapper>
    {
        private readonly ICustomerCartRespository _customerCartRespository = customerCartRespository;
        private readonly IMapper _mapper = mapper;
        private readonly ICommonService _commonService = commonService;
        public async Task<IResultWrapper> Handle(Request request, CancellationToken cancellationToken)
        {
            var response = await _customerCartRespository.GetCustomerOrderDetail(_commonService.GetUserID(), AppEnums.OrderStatusEnum.Checkout.Getkey(), request.OrderID);
            if (response == null)
                return ResultWrapper.Failure(AppConstants.StatusKeys.BadRequest, AppConstants.StatusCodes.BadRequest);
            var OrderDetail = _mapper.Map<OrderResponse>(response);
            return ResultWrapper.Success(OrderDetail);
        }


    }
    #endregion

}

