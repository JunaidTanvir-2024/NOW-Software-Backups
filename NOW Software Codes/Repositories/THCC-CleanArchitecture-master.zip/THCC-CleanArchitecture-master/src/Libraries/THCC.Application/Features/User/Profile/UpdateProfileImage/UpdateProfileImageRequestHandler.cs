﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

namespace THCC.Application.Features.User.Profile.UpdateProfileImage;

public class UpdateProfileImageRequestHandler : IRequestHandler<UpdateProfileImageRequest, object>
{
    #region Fields

    private readonly IFileService _fileService;
    private readonly ICurrentUser _currentUser;
    private readonly ILogger _logger;
    private readonly ICommonService _commonService;
    private readonly IUserRepository _userRepository;
    private readonly ProfileSettings _profileSettings;

    #endregion

    #region Ctor

    public UpdateProfileImageRequestHandler(
        IFileService fileService,
        IOptions<ProfileSettings> profileSettings,
        IUserRepository userRepository,
        ICurrentUser currentUser,
        ILogger logger,
        ICommonService commonService)
    {
        _fileService = fileService;
        _currentUser = currentUser;
        _logger = logger;
        _commonService = commonService;
        _userRepository = userRepository;
        _profileSettings = profileSettings.Value;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(UpdateProfileImageRequest request, CancellationToken cancellationToken)
    {
        //Upload profile image
        var user = await _userRepository.GetUserByEmailAsync(_currentUser.GetUserEmail());
        string? imageName = string.Empty;

        if (request.Image == null)
        {
            _logger.Debug($"Failed {user!.Email} update user profile image info: Image not found");
            return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
        }
        
        var virtualDirectories = _fileService.GetVirtualDirectoriesBySite(_profileSettings.SiteName!);

        foreach (var domainPath in virtualDirectories!.DomainPath!.Where
        (domainPath => domainPath.VirtualPath!.Equals
        (_profileSettings.VirtualDirectoryName, StringComparison.InvariantCultureIgnoreCase)))
        {
            var (fileName, isSuccess, errorMessage) = await _fileService.FileUploaderAsync(
              request.Image, $"{domainPath.PhysicalPath}/{_currentUser.GetUserId()}");
            if (isSuccess)
            {
                imageName = fileName;
            }
            else
            {
                _logger.Debug($"Failed {user!.Email} update user profile image info: {errorMessage}");
                return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
            }
        }

        var imageResponse = await _userRepository.UpdateprofileImage(user!, imageName);
        if (!imageResponse.Succeeded)
        {
            _logger.Debug($"Failed {user!.Email} update user profile image info: Image path not saved to database");
            return ErrorResult.Failure(CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
        }
        if (!string.IsNullOrEmpty(user!.ProfileImage))
        {
            user!.ProfileImage = $"{_commonService.GetHostRequestUrl()}{_profileSettings.VirtualDirectoryName}/{user.Id}/{user.ProfileImage}";
        }

        return new UpdateProfileImageResponse {ImagePath= user!.ProfileImage! };
    }

    #endregion
}