﻿using System.ComponentModel;

using FluentValidation;

namespace Voucherify.Api.Features.Campaigns.Requests;

public class GetCampaignsRequest
{
    [DefaultValue(1)]
    public int PageNumber { get; set; }
    [DefaultValue(10)]
    public int PageSize { get; set; }
}

internal class GetCampaignsRequestValidator : AbstractValidator<GetCampaignsRequest>
{
    public GetCampaignsRequestValidator()
    {
        RuleFor(p => p.PageNumber).GreaterThan(0);
        RuleFor(p => p.PageSize).GreaterThan(0);
    }
}