﻿using System.Globalization;

using Microsoft.Extensions.Options;

using THCC.Application.Interfaces.Services;
using THCC.Application.Settings;

namespace THCC.Infrastructure.Services;

public class DiscountService : IDiscountService
{
    #region Fields

    private readonly DiscountSettings _discount;

    #endregion

    #region Ctors

    public DiscountService(IOptions<DiscountSettings> discount)
    {
        _discount = discount.Value;
    }

    #endregion

    #region Methods

    public decimal GetDiscount(decimal amount)
    {
        var currentDate = DateTime.Now.Date;
        var startDate = DateTime.Parse(_discount.StartDate!, CultureInfo.InvariantCulture);
        var endDate = DateTime.Parse(_discount.EndDate!, CultureInfo.InvariantCulture);
        if (_discount.IsActive == true && currentDate >= startDate && currentDate <= endDate)
        {
            return amount * 10 / 100;

            //if (amount <= 15)
            //{
            //    return amount * 10 / 100;
            //}
            //else if (amount >= 16)
            //{
            //    return amount * 20 / 100;
            //}
        }
        return 0;
    }

    #endregion
}
