﻿using Application.Common.Enums;
using Newtonsoft.Json;

namespace Application.Common.Models;
public class SocialLoginResponse
{
}
public class GoogleUserViewModel
{
    public string Id { get; set; }
    public string Name { get; set; }
    public string Given_name { get; set; }
    public string Email { get; set; }
    public string Picture { get; set; }
}

public class FacebookUserViewModel
{
    public string Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public FacebookPictureViewModel Picture { get; set; }
}

[JsonObject("Picture")]
public class FacebookPictureViewModel
{
    [JsonProperty("data")]
    public FacebookPictureDataViewModel Data { get; set; }
}

[JsonObject("data")]
public class FacebookPictureDataViewModel
{
    public string Url { get; set; }
}


public class AppleLoginModel
{
    public string State { get; set; }
    public string Code { get; set; }
    public string Id_token { get; set; }
    public AppleUserModel User { get; set; }
}
public class AppleUserModel
{
    public AppleUserNameModel Name { get; set; }
    public string Email { get; set; }
}
public class AppleUserNameModel
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
}
public class AppleTokenValidationResponse
{
    public string Access_token { get; set; }
    public string Token_type { get; set; }
    public string Expires_in { get; set; }
    public string Id_token { get; set; }
}

public class SocialUserViewModel
{
    public string Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Picture { get; set; }
    public SocialLoginType Type { get; set; }
}
