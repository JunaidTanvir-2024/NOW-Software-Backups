namespace FH.Core.Definitions;

public static class AppEnums
{
	public enum ClientInformation
	{
		ProductCode,
		ProductItemCode,
		UniqueReference
	}
	public enum CountryRequestType
	{
		AllCountries = 1,
		CountryByIsoCode = 2
	}
	public enum OperatorRequestType
	{
		AllOperators = 1,
		OperatorByName = 2
	}
	public enum ProductRequestType
	{
		AllProducts = 1,
		ProductByName = 2
	}
	public enum ProductPurchaseType
	{
		Topup = 1,
		Bundle = 2,
		InternetData = 3,
		GiftCard = 4
	}
	public enum Vendor
	{
		DTOne = 1,
		Reloadly = 2
	}
	public enum TransactionStatus
	{
		Created = 1001,
		Cancelled = 1002,
		Rejected = 1003,
		Declined = 1004,
		Completed = 1005,
		Reversed = 1006,
		Confirmed = 1007,
		Submitted = 1008
	}
}
