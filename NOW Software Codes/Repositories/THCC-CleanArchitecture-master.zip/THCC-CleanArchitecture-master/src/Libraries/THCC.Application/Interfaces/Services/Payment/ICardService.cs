﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Services.Payment;

public interface ICardService : ServiceType.IScoped
{
    Task<List<CustomerCardDto>> GetCustomerCards(string customerUniqueRef);
    Task<bool> MakeCustomerDefaultCard(string cv2, string cardToken, string customerUniqueRef);
    Task<bool> RemoveCard(string cardToken, string customerUniqueRef);
    Task<CardPaymentResponseDto> CardPayment(CardPaymentRequestDto request);
    Task<CardPaymentResponseDto> Resume3dCardPayment(string transactionId);
    Task<bool> RefundFullPayment(string transactionId);
    Task<bool> RefundPartialPayment(string transactionId, double amount);
    Task<bool> CapturePayment(string transactionId);
    Task<bool> CancelPayment(string transactionId);
    Task<CardPaymentResponseDto> RecurringPayment(RecurringPaymentDto recurringPaymentDto);
}