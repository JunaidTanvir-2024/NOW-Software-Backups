using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Promotions.Common;

public class PromotionTierCustomerInfo
{
    public string? SourceId { get; set; }
    public Metadata? Metadata { get; set; }
}