﻿using MediatR;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using THCC.Api.Controllers.Common;
using THCC.Application.Features.User.Login;
using THCC.Application.Features.User.RefreshToken;

namespace THCC.Api.Controllers.Identity
{
    [AllowAnonymous]
    public class TokenController : BaseApiController
    {
        [HttpPost("refresh")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(LoginResponse))]
        public async Task<IActionResult> RefreshAsync([FromBody] RefreshTokenRequest request, CancellationToken cancellationToken)
        {
            return HandleResponse(await Mediator.Send(request, cancellationToken));
        }       
    }
}
