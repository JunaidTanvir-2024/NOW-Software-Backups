﻿using Dapper;
using Newtonsoft.Json;
using SmsOutReachCallBackUrlApi.Contracts.Sap.Request;
using SmsOutReachCallBackUrlApi.Models;
using SmsOutReachCallBackUrlApi.Models.Connections;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace SmsOutReachCallBackUrlApi.Infrastructure.Sap
{
    public class SapDb : ISapDb
    {
        private IDbConnectionSettings DbConnection;


        public SapDb(string connectionString)
        {

            DbConnection = new DbConnectionSettings(new SqlConnection(connectionString));

        }

        async public Task<DbResult> AddSmsCallBackData(SapSmsCallBackRequest deliveryReport)
        {
            DbResult result = null;
            try
            {
                string callBackJson = JsonConvert.SerializeObject(deliveryReport);
                var parameters = new DynamicParameters();
                parameters.Add("@Message", deliveryReport.message);
                parameters.Add("@MessageId", deliveryReport.messageId);
                parameters.Add("@Msisdn", deliveryReport.msisdn);
                parameters.Add("@Status", deliveryReport.status);
                parameters.Add("@CallBackJson", callBackJson);
                
                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult>("Sap_Api_AddCallBackData", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                return result;
            }
        }
    }
}
