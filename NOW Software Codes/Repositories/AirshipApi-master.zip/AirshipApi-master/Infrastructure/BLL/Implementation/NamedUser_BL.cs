﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Airship.Request;
using Models.Contracts.Airship.Response;
using Models.Contracts.Pay360.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using RestSharp;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class NamedUser_BL : INamedUser_BL
    {

        private IApiCall ApiCall;
        private readonly ILogger Logger;
        private INamedUser_DL NUserDb;

        public NamedUser_BL(ILogger logger, IApiCall apiCall, INamedUser_DL nUserDb)
        {
            Logger = logger;
            ApiCall = apiCall;
            NUserDb = nUserDb;
        }
        public async Task<GenericApiResponse<string>> NUserChannelAssociation(NUserChannelAssocRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<string>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/named_users/associate";
                ApiNUserChannelAssocRequest apiRequest = new ApiNUserChannelAssocRequest() { ChannelId = request.ChannelId, DeviceType = request.DeviceType.ToString(), NamedUserId = request.NamedUserId };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest);
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: NamedUser_BL, Method: NuserChannelAssociation, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<string>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiOkResponse apiResponseModel = JsonConvert.DeserializeObject<ApiOkResponse>(responseJson);
                        if (apiResponseModel.Ok == true)
                        {
                            var dbResult = await NUserDb.NUserChannelAssociation(request);
                            if (dbResult.Status == Status.Success)
                            {
                                return GenericApiResponse<string>.Success(null, "Success");
                            }
                            else
                            {
                                return GenericApiResponse<string>.Failure(dbResult.ErrorMessage, ApiStatusCodes.UnSuccessful);
                            }

                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<string>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUser_BL, Method: NuserChannelAssociation, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericApiResponse<string>> NuserChannelDisassociation(NuserChannelDisassociationRequest request)
        {
            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<string>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/named_users/disassociate";
                ApiNUserChannelAssocRequest apiRequest = new ApiNUserChannelAssocRequest() { ChannelId = request.ChannelId, DeviceType = request.DeviceType.ToString(), NamedUserId = request.NamedUserId };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest);
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: NamedUser_BL, Method: NuserChannelDisassociation, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<string>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiOkResponse apiResponseModel = JsonConvert.DeserializeObject<ApiOkResponse>(responseJson);
                        if (apiResponseModel.Ok == true)
                        {
                            return GenericApiResponse<string>.Success(null, "Success");
                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<string>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }
                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUser_BL, Method: NuserChannelDisassociation, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }
        }
        public async Task<GenericApiResponse<string>> AddNUserTags(AddNUserTagsRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<string>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/named_users/tags";
                Dictionary<string, List<string>> tags = new Dictionary<string, List<string>>();
                tags.Add(request.TagGroup, request.Tags);
                ApiAddNUserTagsRequest apiRequest = new ApiAddNUserTagsRequest() { audience = new ApiAddNUserTagsAudience() { named_user_id = new List<string>() { request.NamedUser } }, add = tags };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest);
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: NamedUser_BL, Method: AddNUserTags, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<string>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiOkResponse apiResponseModel = JsonConvert.DeserializeObject<ApiOkResponse>(responseJson);
                        if (apiResponseModel.Ok == true)
                        {

                            var dbResult = await NUserDb.AddNUserTags(request);
                            if (dbResult.Status == Status.Success)
                            {
                                return GenericApiResponse<string>.Success(null, "Success");
                            }
                            else
                            {
                                return GenericApiResponse<string>.Failure(dbResult.ErrorMessage, ApiStatusCodes.UnSuccessful);
                            }

                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<string>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUser_BL, Method: AddNUserTags, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericApiResponse<ApiGetUserByIdResponse>> GetNamedUserById(GetUserByIdRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<ApiGetUserByIdResponse>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/named_users/?id=" + request.Named_user_id;
                IRestResponse httpResponse = await ApiCall.Get(url, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: NamedUser_BL, Method: GetNamedUserById, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<ApiGetUserByIdResponse>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiGetUserByIdResponse apiResponseModel = JsonConvert.DeserializeObject<ApiGetUserByIdResponse>(responseJson);
                        if (apiResponseModel.ok == true)
                        {
                            return GenericApiResponse<ApiGetUserByIdResponse>.Success(apiResponseModel, "Success");
                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<ApiGetUserByIdResponse>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetUserByIdResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetUserByIdResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUser_BL, Method: GetNamedUserById, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApiGetUserByIdResponse>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericApiResponse<ApiGetNamedUsersResponse>> GetNamedUsers(GetAllNamedUsersRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<ApiGetNamedUsersResponse>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/named_users";
                IRestResponse httpResponse = await ApiCall.Get(url, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: NamedUser_BL, Method: GetNamedUserById, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<ApiGetNamedUsersResponse>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiGetNamedUsersResponse apiResponseModel = JsonConvert.DeserializeObject<ApiGetNamedUsersResponse>(responseJson);

                        return GenericApiResponse<ApiGetNamedUsersResponse>.Success(apiResponseModel, "Success");

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetNamedUsersResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetNamedUsersResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUser_BL, Method: GetNamedUsers, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApiGetNamedUsersResponse>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericApiResponse<string>> WebNUserChannelAssociation(WebNUserChannelAssociationRequest request)
        {
            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<string>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/named_users/associate";
                var apiRequest = new ApiWebNUserChannelAssociationRequest() { ChannelId = request.ChannelId, NamedUserId = request.NamedUserId };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest);
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: NamedUser_BL, Method: WebNUserChannelAssociation, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<string>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiOkResponse apiResponseModel = JsonConvert.DeserializeObject<ApiOkResponse>(responseJson);
                        if (apiResponseModel.Ok == true)
                        {
                            return GenericApiResponse<string>.Success(null, "Success");
                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<string>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }
                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUser_BL, Method: WebNUserChannelAssociation, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericApiResponse<string>> EmailAssociationWithNamedUser(EmailAssociationWithNamedUserRequest request)
        {
            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<string>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/named_users/associate";
                var apiRequest = new ApiEmailAssociationWithNamedUserRequest() { NamedUserId = request.NamedUserId, EmailAddress = request.EmailAddress };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest);
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: NamedUser_BL, Method: EmailAssociationWithNamedUser, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<string>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiOkResponse apiResponseModel = JsonConvert.DeserializeObject<ApiOkResponse>(responseJson);
                        if (apiResponseModel.Ok == true)
                        {
                            return GenericApiResponse<string>.Success(null, "Success");
                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<string>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }
                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUser_BL, Method: EmailAssociationWithNamedUser, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericApiResponse<string>> DisassociateEmailChannelFromNamedUser(DisassociateEmailChannelFromNamedUserRequest request)
        {
            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<string>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/named_users/disassociate";
                var apiRequest = new ApiEmailAssociationWithNamedUserRequest() { NamedUserId = request.NamedUserId, EmailAddress = request.EmailAddress };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest);
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: NamedUser_BL, Method: DisassociateEmailChannelFromNamedUser, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<string>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiOkResponse apiResponseModel = JsonConvert.DeserializeObject<ApiOkResponse>(responseJson);
                        if (apiResponseModel.Ok == true)
                        {
                            return GenericApiResponse<string>.Success(null, "Success");
                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<string>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }
                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUser_BL, Method: DisassociateEmailChannelFromNamedUser, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }
        }
    }
}
