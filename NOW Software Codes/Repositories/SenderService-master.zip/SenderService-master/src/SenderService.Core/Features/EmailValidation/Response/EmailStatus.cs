﻿namespace SenderService.Core.Features.EmailValidation.Response;

public class EmailStatus
{
    public bool IsDomainBlocked { get; set; }
    public bool IsDomainWhitelist { get; set; }
    public bool IsEmailVerified { get; set; }
    public bool IsEmailWhitelist { get; set; }
    public bool IsEmailAlreadyProcessed { get; set; }
}