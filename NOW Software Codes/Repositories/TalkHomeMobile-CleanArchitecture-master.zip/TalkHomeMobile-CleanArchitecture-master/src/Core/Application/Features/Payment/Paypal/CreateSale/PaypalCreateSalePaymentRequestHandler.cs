﻿using Application.Common.Interfaces.Payment;
using Application.Features.Payment.Paypal.Models;

namespace Application.Features.Payment.Paypal.CreateSale;

public class PaypalCreateSalePaymentRequestHandler : IRequestHandler<PaypalCreateSalePaymentRequest, Result<PaypalResponse>>
{
    private readonly IPaymentService _paymentService;

    public PaypalCreateSalePaymentRequestHandler(IPaymentService paymentService)
    {
        _paymentService = paymentService;
    }

    public async Task<Result<PaypalResponse>> Handle(
        PaypalCreateSalePaymentRequest request, CancellationToken cancellationToken)
    {
        var isSubscriptionRequest = (request?.TopupInfo?.AutoTopupInfo?.Status == true || request?.BundleInfo?.IsRenewable == true);
        return await _paymentService.HandlePaypalPaymentRequest(
            request!.TopupInfo!,
            request.BundleInfo!,
            request.CreditSimInfo!,
            request.Msisdn!,
            request.Email!,
            request.IpAddress!,
            isSubscriptionRequest,
            subscriptionWithInitialSale: true,
            request.ConversionID,
            (int) request.ConversionPlatFormID);
    }
}