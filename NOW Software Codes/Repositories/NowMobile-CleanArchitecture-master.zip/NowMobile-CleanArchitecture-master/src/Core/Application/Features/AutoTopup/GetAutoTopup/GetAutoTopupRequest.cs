﻿namespace Application.Features.AutoTopup.GetAutoTopup;

public class GetAutoTopupRequest : IRequest<Result<AutoTopupResponse>>
{
    public string Msisdn { get; set; } = default!;
}
