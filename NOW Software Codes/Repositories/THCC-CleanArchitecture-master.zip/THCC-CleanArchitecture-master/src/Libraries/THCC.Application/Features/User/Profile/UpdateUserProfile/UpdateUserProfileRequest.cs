﻿namespace THCC.Application.Features.User.Profile.UpdateUserProfile;
public class UpdateUserProfileRequest : IRequest<object>
{
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public bool IsSubscribedToNewsletter { get; set; } = false;
}
public class SetUserProfileRequestValidator : AbstractValidator<UpdateUserProfileRequest>
{
    public SetUserProfileRequestValidator()
    {
        RuleFor(p => p.FirstName).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MaximumLength(255);
        RuleFor(p => p.LastName).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MaximumLength(255);
    }
}
