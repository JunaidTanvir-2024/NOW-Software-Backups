﻿
using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.SuggestedBundle;
public class SuggestedBundleRequest : IRequest<Result<List<BundleInfo>>>
{
    public string? Msisdn { get; set; }
}
