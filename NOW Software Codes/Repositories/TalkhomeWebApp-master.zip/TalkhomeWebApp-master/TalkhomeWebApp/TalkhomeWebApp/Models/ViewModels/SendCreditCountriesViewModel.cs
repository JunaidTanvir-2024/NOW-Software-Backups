﻿using System.Collections.Generic;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class SendCreditCountriesViewModel
    {
        public string Continent { get; set; }
        public List<CountryViewModel> Countries { get; set; }
    }
    public class CountryViewModel
    {
        public string Continent { get; set; }
        public string CountryId { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public int OperatorsCount { get; set; }
        public string OperatorsName { get; set; }
    }
    public class OperatorViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string Continent { get; set; }
    }
    public class SendCreditByCountryViewModel
    {
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string Continent { get; set; }
        public List<OperatorViewModel> Operators { get; set; }
        public List<Item> Promotions { get; set; }
        public string CountryPictureUrl { get; set; }

        public List<CountryViewModel> Countries { get; set; }

    }
    public class SendCreditByOperatorViewModel
    {
        public string Continent { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string CountryPictureUrl { get; set; }
        public string OperatorId { get; set; }
        public string OperatorName { get; set; }
        public string OperatorImageUrl { get; set; }
        public List<Item> Promotions { get; set; }
        public List<CountryViewModel> Countries { get; set; }
        public List<OperatorViewModel> Operators { get; set; }
    }
}
