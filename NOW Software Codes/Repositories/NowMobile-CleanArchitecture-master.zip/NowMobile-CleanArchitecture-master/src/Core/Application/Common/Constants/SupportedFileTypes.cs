namespace Application.Common.Constants;

public static class SupportedFileTypes
{
    public static List<CommonFileTypes> FileTypeSupported()
    {
        return new List<CommonFileTypes>()
        {
            new CommonFileTypes("bin", "53 50 30 31"),
            new CommonFileTypes("bac", "42 41 43 4B 4D 49 4B 45 44 49 53 4B"),
            new CommonFileTypes("bz2", "42 5A 68"),
            new CommonFileTypes("tif tiff", "49 49 2A 00"),
            new CommonFileTypes("tif tiff", "4D 4D 00 2A"),
            new CommonFileTypes("cr2", "49 49 2A 00 10 00 00 00 43 52"),
            new CommonFileTypes("cin", "80 2A 5F D7"),
            new CommonFileTypes("exr", "76 2F 31 01"),
            new CommonFileTypes("dpx", "53 44 50 58"),
            new CommonFileTypes("dpx", "58 50 44 53"),
            new CommonFileTypes("bpg", "42 50 47 FB"),
            new CommonFileTypes("lz", "4C 5A 49 50"),
            new CommonFileTypes("ps", "25 21 50 53"),
            new CommonFileTypes("fits", "3D 20 20 20 20 20 20 20 20 20 20 20 20 20 20 20 20 20 20 2020 54"),
            new CommonFileTypes("doc xls ppt msg", "D0 CF 11 E0 A1 B1 1A E1"),
            new CommonFileTypes("dex", "64 65 78 0A 30 33 35 00"),
            new CommonFileTypes("vmdk", "4B 44 4D"),
            new CommonFileTypes("crx", "43 72 32 34"),
            new CommonFileTypes("cwk", "05 07 00 00 42 4F 42 4F 05 07 00 00 00 00 00 00 00 00 00 00 0001"),
            new CommonFileTypes("fh8", "41 47 44 33"),
            new CommonFileTypes("cwk", "06 07 E1 00 42 4F 42 4F 06 07 E1 00 00 00 00 00 00 00 00 00 0001"),
            new CommonFileTypes("toast", "45 52 02 00 00 00"),
            new CommonFileTypes("toast", "8B 45 52 02 00 00 00"),
            new CommonFileTypes("xar", "78 61 72 21"),
            new CommonFileTypes("dat", "50 4D 4F 43 43 4D 4F 43"),
            new CommonFileTypes("nes", "4E 45 53 1A"),
            new CommonFileTypes("tox", "74 6F 78 33"),
            new CommonFileTypes("MLV", "4D 4C 56 49"),
            new CommonFileTypes("lz4", "04 22 4D 18"),
            new CommonFileTypes("cab", "4D 53 43 46"),
            new CommonFileTypes("flif", "46 4C 49 46"),
            new CommonFileTypes("stg", "4D 49 4C 20"),
            new CommonFileTypes("der", "30 82"),
            new CommonFileTypes("wasm", "00 61 73 6d"),
            new CommonFileTypes("lep", "cf 84 01"),
            new CommonFileTypes("rtf", "7B 5C 72 74 66 31"),
            new CommonFileTypes("m2p vob", "00 00 01 BA"),
            new CommonFileTypes("zlib", "78 01"),
            new CommonFileTypes("zlib", "78 9c"),
            new CommonFileTypes("zlib", "78 da"),
            new CommonFileTypes("lzfse", "62 76 78 32"),
            new CommonFileTypes("orc", "4F 52 43"),
            new CommonFileTypes("avro", "4F 62 6A 01"),
            new CommonFileTypes("rc", "53 45 51 36"),
            new CommonFileTypes("tbi", "00 00 00 00 14 00 00 00"),
            new CommonFileTypes("ttf", "00 01 00 00 00"),
            new CommonFileTypes("mdf", "00 FF FF FF FF FF FF FF FF FF FF 00 00 02 00 01"),
            new CommonFileTypes("asf wma wmv", "30 26 B2 75 8E 66 CF 11 A6 D9 00 AA 00 62 CE 6C"),
            new CommonFileTypes("ogg oga ogv", "4F 67 67 53"),
            new CommonFileTypes("psd", "38 42 50 53"),
            new CommonFileTypes("mp3", "FF FB"),
            new CommonFileTypes("mp3", "49 44 33"),
            new CommonFileTypes("bmp dib", "42 4D"),
            new CommonFileTypes("jpg,jpeg", "ff,d8,ff,db"),
            new CommonFileTypes("png", "89,50,4e,47,0d,0a,1a,0a"),
            new CommonFileTypes("zip,jar,odt,ods,odp,docx,xlsx,pptx,vsdx,apk,aar", "50,4b,03,04"),
            new CommonFileTypes("zip,jar,odt,ods,odp,docx,xlsx,pptx,vsdx,apk,aar", "50,4b,07,08"),
            new CommonFileTypes("zip,jar,odt,ods,odp,docx,xlsx,pptx,vsdx,apk,aar", "50,4b,05,06"),
            new CommonFileTypes("rar", "52,61,72,21,1a,07,00"),
            new CommonFileTypes("rar", "52,61,72,21,1a,07,01,00"),
            new CommonFileTypes("class", "CA FE BA BE"),
            new CommonFileTypes("pdf", "25 50 44 46"),
            new CommonFileTypes("rpm", "ed ab ee db"),
            new CommonFileTypes("flac", "66 4C 61 43"),
            new CommonFileTypes("mid midi", "4D 54 68 64"),
            new CommonFileTypes("ico", "00 00 01 00"),
            new CommonFileTypes("z,tar.z", "1F 9D"),
            new CommonFileTypes("z,tar.z", "1F A0"),
            new CommonFileTypes("gif", "47 49 46 38 37 61"),
            new CommonFileTypes("dmg", "78 01 73 0D 62 62 60"),
            new CommonFileTypes("gif", "47 49 46 38 39 61"),
            new CommonFileTypes("exe", "4D 5A"),
            new CommonFileTypes("mkv mka mks mk3d webm", "1A 45 DF A3"),
            new CommonFileTypes("gz tar.gz", "1F 8B"),
            new CommonFileTypes("xz tar.xz", "FD 37 7A 58 5A 00 00"),
            new CommonFileTypes("7z", "37 7A BC AF 27 1C"),
            new CommonFileTypes("mpg mpeg", "00 00 01 BA"),
            new CommonFileTypes("mpg mpeg", "00 00 01 B3"),
            new CommonFileTypes("woff", "77 4F 46 46"),
            new CommonFileTypes("woff2", "77 4F 46 32"),
            new CommonFileTypes("XML", "3c 3f 78 6d 6c 20"),
            new CommonFileTypes("swf", "43 57 53"),
            new CommonFileTypes("swf", "46 57 53"),
            new CommonFileTypes("deb", "21 3C 61 72 63 68 3E"),
            new CommonFileTypes("jpg,jpeg","FF D8 FF E0 ?? ?? 4A 46 49 46 00 01"),
            new CommonFileTypes("jpg,jpeg","FF D8 FF E1 ?? ?? 45 78 69 66 00 00"),
        };
    }
}

public sealed class CommonFileTypes
{
    public CommonFileTypes(string fileTypeName, string fileHeaderValue)
    {
        FileTypeName = fileTypeName;
        FileHeaderValue = fileHeaderValue;
    }

    public string FileTypeName { get; set; }
    public string FileHeaderValue { get; set; }
}
