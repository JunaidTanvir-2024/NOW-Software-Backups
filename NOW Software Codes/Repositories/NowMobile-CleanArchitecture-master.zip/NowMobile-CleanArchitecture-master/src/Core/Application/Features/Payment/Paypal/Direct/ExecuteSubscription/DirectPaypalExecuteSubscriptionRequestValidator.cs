﻿namespace Application.Features.Payment.Paypal.Direct.ExecuteSubscription;
public class DirectPaypalExecuteSubscriptionRequestValidator : AbstractValidator<DirectPaypalExecuteSubscriptionRequest>
{
    public DirectPaypalExecuteSubscriptionRequestValidator()
    {
        RuleFor(p => p.CustomerUniqueRef).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.OrderId).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.PayerId).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.PaymentId).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
    }
}
