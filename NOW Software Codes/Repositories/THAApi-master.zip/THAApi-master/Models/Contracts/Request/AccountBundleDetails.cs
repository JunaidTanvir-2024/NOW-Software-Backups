﻿using Models.Contracts.Response;
using Models.Database;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class AccountBundleDetails
    {
        public AccountBundleDetails()
        {
            this.Allowances = new List<BundleAllowance>();
        }

        public string Id { get; set; }

        public string Name { get; set; }
		public List<BundleAllowance> Allowances { get; set; }

        public DateTime Expiry { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public int BundleCategory { get; set; }
        public string BundleCategoryName { get; set; }
        public int BundleType { get; set; }
        public string BundleTypeName { get; set; }
        public bool IsAutoRenew { get; set; }
        public int ValidityDays { get; set; }
        public int TotalMinutes { get; set; }
        public int RemainingMinutes { get; set; }
        public int DiscountPercentage { get; set; }
        public bool IsOffer { get; set; }
        public string Price { get; set; }
    }
    public class AccountBundleDetailsV2
    {
        public AccountBundleDetailsV2()
        {
            this.Allowances = new List<BundleAllowance>();
        }

        public string Id { get; set; }

        public string Name { get; set; }
        public string Description { get; set; }
        public string Terms { get; set; }
        public List<BundleAllowance> Allowances { get; set; }

        public DateTime Expiry { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public int BundleCategory { get; set; }
        public string BundleCategoryName { get; set; }
        public int BundleType { get; set; }
        public string BundleTypeName { get; set; }
        public bool IsAutoRenew { get; set; }
        public int ValidityDays { get; set; }
        public int TotalMinutes { get; set; }
        public int RemainingMinutes { get; set; }
        public int DiscountPercentage { get; set; }
        public bool IsOffer { get; set; }
        public string Price { get; set; }
        public PaymentMethods PaymentMethod { set; get; }
        public string CardMaskedPAN { get; set; }
        public bool IsLastRenewalFailed { set; get; }
    }
    public class AccountSubscriptionDetails
    {
        public IEnumerable<AccountBundleDetails> Bundles { get; set; }
        //public LastTopup Topup { get; set; }
    }
    public class AccountSubscriptionDetailsV2
    {
        public IEnumerable<AccountBundleDetailsV2> Bundles { get; set; }
        public GetAutoTopupDetailsResponse AutoTopup { get; set; }
        //public LastTopup Topup { get; set; }
    }
    //public class AutoTopupDetails
    //{
    //    public bool IsAutoTopup { get; set; }
    //    public float AutoTopupAmount { get; set; }
    //    public float AutoTopupThreshhold { get; set; }
    //}
    public class BundleAllowance
    {
        public string Remaining { get; set; }
    }
}
