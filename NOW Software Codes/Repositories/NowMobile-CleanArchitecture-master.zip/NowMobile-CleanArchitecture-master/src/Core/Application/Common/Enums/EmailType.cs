﻿namespace Application.Common.Enums;

public enum EmailType : byte
{
    ForgotPassword = 1,
    SignUp = 2,
    Payment = 3,
    FreeSim = 4,
    CreditSim = 5,
    Topup=6,
    Bundle=7
}


