﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TH.Models.Database
{
    public class Customer
    {

        //public int account { get; set; }
        public string msisdn { get; set; }
        public string Balance { get; set; }
        //public string Subscriber_id { get; set; }
        public string PUK1 { get; set; }
        public string PUK2 { get; set; }
        public string ICCID { get; set; }
        public string IMSI { get; set; }
        public string PrimarySimState { get; set; }
        public string PrimarySimUserState { get; set; }

    }
}
