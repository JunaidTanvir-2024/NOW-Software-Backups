﻿namespace THCC.Application.Features.User.Profile.AddUserPassword
{
    public class AddUserPasswordRequest : IRequest<object>
    {
        public string Password { get; set; } = default!;
    }
    class AddUserPasswordRequestValidator : AbstractValidator<AddUserPasswordRequest>
    {
        public AddUserPasswordRequestValidator()
        {
           RuleFor(p => p.Password)
            .NotEmpty()
            .NotNull()
            .MinimumLength(6).WithMessage("Your password length must be at least 6.")
            .MaximumLength(20).WithMessage("Your password length must not exceed 20.")
            .Matches(@"[A-Z]+").WithMessage("Your password must contain at least one uppercase letter.")
            .Matches(@"[a-z]+").WithMessage("Your password must contain at least one lowercase letter.")
            .Matches(@"[0-9]+").WithMessage("Your password must contain at least one number.");
        }
    }
}
