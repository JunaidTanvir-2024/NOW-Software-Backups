﻿using System.Reflection.Metadata;

namespace CancelBundleApi.Constants.Enums;

public static class CustomStatusKey
{
    public const string BundleUnSubscribeSuccess = "Bundle unsubscribed successfully";
    public const string BundleUnSubscribeFail = "Bundle unsubscribed failed";
    public const string NoSubscriptionBundlesFound = "No subscription bundles list found";
    public const string NoSubscriptionBundleItemFound = "No subscription bundle item found";

}