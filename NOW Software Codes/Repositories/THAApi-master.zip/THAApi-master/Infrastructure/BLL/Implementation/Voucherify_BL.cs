﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.BLL.Services.Voucherify;
using Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Customers.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.EarningRules.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Events;
using Infrastructure.BLL.Services.Voucherify.Models.Events.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.MetadataModels;
using Infrastructure.BLL.Services.Voucherify.Models.Products.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Promotions.Common;
using Infrastructure.BLL.Services.Voucherify.Models.Promotions.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Promotions.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common;
using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Responses;
using Infrastructure.DAL.Implementation;
using Infrastructure.DAL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Models.Common;
using Models.Configurations;
using Models.Constants;
using Models.Contracts.Request;
using Models.Contracts.Request.Voucherify;
using Models.Contracts.Response;
using Models.Contracts.Response.Voucherify;
using Models.Database;
using Models.Enums;
using MySqlX.XDevAPI.Common;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using static Infrastructure.BLL.Services.Voucherify.Models.Promotions.Responses.GetCustomerSpecificPromotionsResult;
using static Models.Contracts.Response.Voucherify.VoucherifyLoyaltiesResponse;

namespace Infrastructure.BLL.Implementation
{
	internal class Voucherify_BL : IVoucherify_BL
	{
		private readonly IVoucherifyService _voucherifyService;
		private readonly IUserAccount_DL _userAccount_DL;
		private readonly IStringLocalizer _localizer;
		private readonly IATT_DL _aTT_DL;
		private readonly IAirShipService _airShipService;
		private readonly IBundle_DL _bundle_DL;
		private readonly IPaymentFullfillment_DL _paymentFullfillment_DL;
		private readonly IHelper_BL _helper_BL;
		private readonly ILogger _logger;
		private readonly IPay360Service _pay360Service;
		private readonly IInternationalTopupServiceFeeCalculator _internationalTopupServiceFeeCalculator;
		private readonly Pay360Config _pay360Config;
		private readonly VoucherifyConfig _voucherifyConfig;

		private const string _DiscountType = "voucher";

		public Voucherify_BL(IVoucherifyService voucherifyService,
			IOptions<VoucherifyConfig> options,
			IUserAccount_DL userAccount_DL,
			IStringLocalizer localizer,
			IOptions<Pay360Config> pay360Config,
			IATT_DL aTT_DL,
			IAirShipService airShipService,
			IBundle_DL bundle_DL,
			IPaymentFullfillment_DL paymentFullfillment_DL,
			IHelper_BL helper_BL,
			ILogger logger,
			IPay360Service pay360Service,
			IInternationalTopupServiceFeeCalculator internationalTopupServiceFeeCalculator)
		{
			_voucherifyService = voucherifyService;
			_userAccount_DL = userAccount_DL;
			_localizer = localizer;
			_aTT_DL = aTT_DL;
			_airShipService = airShipService;
			_bundle_DL = bundle_DL;
			_paymentFullfillment_DL = paymentFullfillment_DL;
			_helper_BL = helper_BL;
			_logger = logger;
			_pay360Service = pay360Service;
			this._internationalTopupServiceFeeCalculator = internationalTopupServiceFeeCalculator;
			_pay360Config = pay360Config.Value;
			_voucherifyConfig = options.Value;
		}

		public async Task<GenericApiResponse<LoyaltyPointsRedemptionResponse>> RedeemLoyaltyPoints(string userMsisdn, LoyaltyPointsRedemptionRequest request)
		{
			if (!_voucherifyConfig.EndpointConfig.RedeemLoyaltyPoints)
			{
				return GenericApiResponse<LoyaltyPointsRedemptionResponse>.Failure(_localizer["PointsNotRedeemed"], ApiStatusCodes.PointsNotRedeemed);
			}

			var customerLoyaltyCardRequest = new GetVoucherifyCustomerRequest()
			{
				LoyaltyCampaignId = _voucherifyConfig.LoyaltyCampaignId,
				SourceId = userMsisdn
			};

			// Get Specific Customer
			var voucherifyCustomer = await _voucherifyService.GetCustomerBySourceId(customerLoyaltyCardRequest, userMsisdn);

			// Customer Not Found - Return
			if (voucherifyCustomer?.Payload == null)
			{
				_logger.Debug($"{{Class: Voucherify_BL, Method:RedeemLoyaltyPoints, Message: Customer not found, Request:{userMsisdn},{JsonConvert.SerializeObject(request)}}}");
				return GenericApiResponse<LoyaltyPointsRedemptionResponse>.Failure(_localizer["PointsNotRedeemed"], ApiStatusCodes.PointsNotRedeemed);
			}

			// Get Specific Loyalty Product SKU
			var loyaltyProduct = await _voucherifyService.GetProductSKU(new GetProductSkuRequest() { SkuNameOrId = request.SkuId }, userMsisdn);

			// Customer does not have enough point for SKU - Return
			if (voucherifyCustomer?.Payload?.Points < loyaltyProduct?.Payload?.Points)
			{
				_logger.Debug($"{{Class: Voucherify_BL, Method:RedeemLoyaltyPoints, Message: Insufficient Points {voucherifyCustomer?.Payload?.Points} {loyaltyProduct?.Payload?.Points}, Request:{userMsisdn}, {request.SkuId}}}");

				return GenericApiResponse<LoyaltyPointsRedemptionResponse>.Failure(_localizer["InsufficientPoints"], ApiStatusCodes.InsufficientPoints);
			}

			var redemptionRequest = new StackableDiscountRedemptionRequest()
			{
				Customer = new StackableDiscountCustomerInfo()
				{
					SourceId = userMsisdn,
					Metadata = null
				},
				Order = new StackableDiscountOrderInfo()
				{
					SkuId = request.SkuId,
					Quantity = 1,
				},
				Redemption = new StackableDiscountInfo()
				{
					DiscountType = _DiscountType,
					DiscountCode = voucherifyCustomer.Payload.LoyaltyCard,
					RewardId = _voucherifyConfig.LoyaltyRewardId,
					Metadata = null
				}
			};

			var redemptionResult = await _voucherifyService.RedeemStackableDiscounts(redemptionRequest, userMsisdn);

			if (redemptionResult?.Payload != null && !string.IsNullOrEmpty(redemptionResult?.Payload?.RedemptionId)
				&& redemptionResult?.Payload?.Order?.Amount != null)
			{

				// Add Balance After Redemption
				var balanceAddedOrNot = await VoucherifyFulfillment(userMsisdn, redemptionResult?.Payload.RedemptionId, CreditReason.Points, (decimal)redemptionResult.Payload.Order.Amount / 100);

				if (balanceAddedOrNot)
				{
					return GenericApiResponse<LoyaltyPointsRedemptionResponse>.Success(new LoyaltyPointsRedemptionResponse() { IsRedeemed = true }, _localizer["LoyaltyPointsRedeemed"]);
				}
				else
				{
					//Note : Need to revert redemption if the fullfilment failed
					await _voucherifyService.RollbackStackableDiscounts(new StackableDiscountRollbackRequest()
					{
						RedemptionId = redemptionResult?.Payload.RedemptionId
					}, userMsisdn);
				}
			}
			_logger.Debug($"{{Class: Voucherify_BL, Method:RedeemLoyaltyPoints, Message: {_localizer["PointsNotRedeemed"]}, Request:CustomerMsisdn:{userMsisdn}, {JsonConvert.SerializeObject(request)}");

			return GenericApiResponse<LoyaltyPointsRedemptionResponse>.Failure(_localizer["PointsNotRedeemed"], ApiStatusCodes.PointsNotRedeemed);
		}

		public async Task<GenericApiResponse<ReferralCodeResponse>> GetReferralCode(string customerMsisdn)
		{
			if (!_voucherifyConfig.EndpointConfig.GenerateInviationCode)
			{
				return GenericApiResponse<ReferralCodeResponse>.Failure(_localizer["ReferralCodeNotCreated"], ApiStatusCodes.ReferralCodeNotCreated);
			}

			var isNewUser = await _userAccount_DL.IsNewUser(customerMsisdn);
			if (isNewUser)
			{
				_logger.Debug($"{{Class: Voucherify_BL, Method:GetReferralCode, Message: Customer is new user. can't redeem, Request:{customerMsisdn}}}");
				return GenericApiResponse<ReferralCodeResponse>.Failure(_localizer["ReferralCodeNotCreated"], ApiStatusCodes.ReferralCodeNotCreated);
			}

			var getReferralCodeRequest = new GetReferralCodeRequest()
			{
				CampaignNameOrId = _voucherifyConfig.ReferralCampaignId,
				CustomerSourceId = customerMsisdn
			};

			var referralCode = await _voucherifyService.GetReferralCode(getReferralCodeRequest, customerMsisdn);

			if (referralCode?.Payload == null || string.IsNullOrEmpty(referralCode.Payload.ReferralCode))
			{
				_logger.Debug($"{{Class: Voucherify_BL, Method:GetReferralCode, Message: Unable to create referral Code, Request:CustomerMsisdn:{customerMsisdn}");

				return GenericApiResponse<ReferralCodeResponse>.Failure(_localizer["ReferralCodeNotCreated"], ApiStatusCodes.ReferralCodeNotCreated);
			}

			// Will Create a App Download Link
			var referralCodeResponse = new ReferralCodeResponse()
			{
				ReferralCode = referralCode.Payload.ReferralCode,
			};

			return GenericApiResponse<ReferralCodeResponse>.Success(referralCodeResponse, "Success");
		}

		public async Task<GenericApiResponse<ValidateReferralCodeResponse>> ValidateReferralCode(ReferralCodeValidationRequest request, string customerMsisdn, string userAccount)
		{
			if (!_voucherifyConfig.EndpointConfig.ValidateReferralCode)
			{
				return GenericApiResponse<ValidateReferralCodeResponse>.Success(
					new ValidateReferralCodeResponse
					{
						Value = 0,
						DiscountCode = request.ReferralCode,
						DiscountType = DiscountType.ExtraBalance,
						IsValid = false
					}, "Success");
			}

			// Find customer transaction as these customer are eligible for referral campaign. 
			var isNewUser = await _userAccount_DL.IsNewUser(customerMsisdn);
			if (!isNewUser)
			{
				_logger.Debug("Class: Voucherify_BL, Method:GetReferralCode, Message: Can't Validate Referral Code - Customer has not done any transaction, " +
					$"Request:{customerMsisdn} {JsonConvert.SerializeObject(request)}");
				return GenericApiResponse<ValidateReferralCodeResponse>.Success(
					new ValidateReferralCodeResponse
					{
						Value = 0,
						DiscountCode = request.ReferralCode,
						DiscountType = DiscountType.ExtraBalance,
						IsValid = false
					}, "Success");
			}

			var isFirstTopup = await _userAccount_DL.IsFirstTopUp(customerMsisdn);
			var isFirstInternationalTopup = await _aTT_DL.IsFirstATTTransaction(userAccount);

			var customerMetadata = new CustomerMetadata
			{
				TransactionDone = !isNewUser,
				FirstInternationalTopup = isFirstInternationalTopup,
				FirstTopup = isFirstTopup
			};

			// There are two type of discounts (promotion/voucher)
			var validationRequest = new StackableDiscountValidationRequest()
			{
				Customer = new StackableDiscountCustomerInfo()
				{
					SourceId = customerMsisdn,
					Metadata = customerMetadata.ToMetadata()
				},
				Order = new StackableDiscountOrderInfo(),
				Validation = new StackableDiscountInfo()
				{
					DiscountType = nameof(DiscountCodeType.Voucher).ToLower(),
					DiscountCode = request.ReferralCode,
				}
			};

			var validationResult = await _voucherifyService.ValidateStackableDiscounts(validationRequest, customerMsisdn);

			if (validationResult?.Payload == null || validationResult?.Payload?.Order?.DiscountType.Equals("UNIT", StringComparison.InvariantCultureIgnoreCase) == false)
			{
				_logger.Debug($"{{Class: Voucherify_BL, Method:ValidateReferralCode, Message: Invalid Code, Request:CustomerMsisdn:{customerMsisdn}, {JsonConvert.SerializeObject(request)}, {userAccount}");

				return GenericApiResponse<ValidateReferralCodeResponse>.Success(
					new ValidateReferralCodeResponse
					{
						Value = 0,
						DiscountCode = request.ReferralCode,
						DiscountType = DiscountType.ExtraBalance,
						IsValid = false
					}, "Success");
			}

			return GenericApiResponse<ValidateReferralCodeResponse>.Success(
				new ValidateReferralCodeResponse
				{
					Value = validationResult.Payload.Order.Amount != null ? validationResult.Payload.Order.Amount.Value / 100 : 0,
					DiscountCode = request.ReferralCode,
					DiscountType = DiscountType.ExtraBalance,
					IsValid = validationResult.Payload.IsValid
				}, "Success");
		}

		public async Task<GenericApiResponse<ReferralCodeEligibilityResponse>> IsUserEligibleToGenerateInvitationCode(string customerMsisdn)
		{
			if (!_voucherifyConfig.EndpointConfig.IsCustomerEligibleToGenerateInviationCode)
			{
				return GenericApiResponse<ReferralCodeEligibilityResponse>.Success(new ReferralCodeEligibilityResponse() { IsEligibile = false }, "Success");
			}

			// Find customer transaction as these customer are eligible for referral campaign. 
			var isNewUser = await _userAccount_DL.IsNewUser(customerMsisdn);
			if (isNewUser)
			{
				return GenericApiResponse<ReferralCodeEligibilityResponse>.Success(new ReferralCodeEligibilityResponse() { IsEligibile = false }, "Success");
			}

			return GenericApiResponse<ReferralCodeEligibilityResponse>.Success(new ReferralCodeEligibilityResponse() { IsEligibile = true }, "Success");
		}

		public async Task<GenericApiResponse<StackableDiscountResponse>> RedeemDiscount(StackableDiscountRequest request, string msisdn, string userAccount, CustomerMetadata customerMetadata = null)
		{
			// Extra Balance in case of referral
			decimal extraBalanceAmount = 0;

			if (!_voucherifyConfig.EndpointConfig.ValidateReferralCode)
			{
				//We can pass null beacuse its not returning direct response
				return null;
			}

			string skuId = GenerateSkuId(request);
			if (customerMetadata == null)
			{
				var isNewUser = await _userAccount_DL.IsNewUser(msisdn);
				var isFirstTopup = await _userAccount_DL.IsFirstTopUp(msisdn);
				var isFirstInternationalTopup = await _aTT_DL.IsFirstATTTransaction(userAccount);
				customerMetadata = new CustomerMetadata
				{
					TransactionDone = !isNewUser,
					FirstTopup = isFirstTopup,
					FirstInternationalTopup = isFirstInternationalTopup
				};
			}

			var orderMetadata = new OrderMetadata
			{
				CheckoutType = new[] { request.CheckoutType.ToString() },
				PaymentMethod = new[] { request.PaymentMethod.ToString() },
				OperatorName = !string.IsNullOrEmpty(request.Operator) ? request.Operator.ToLower() : string.Empty,
				InternationalTopupDestination = !string.IsNullOrEmpty(request.DestinationCountryISOCode)
															? request.DestinationCountryISOCode.ToLower() : string.Empty,
			};

			// There are two type of discounts (promotion/voucher)
			var redemptionRequest = new StackableDiscountRedemptionRequest()
			{
				Customer = new StackableDiscountCustomerInfo()
				{
					SourceId = msisdn,
					Metadata = customerMetadata.ToMetadata()
				},
				Order = new StackableDiscountOrderInfo()
				{
					SkuId = skuId,
					Quantity = 1,
					Amount = (long)(request.Amount * 100),
					Metadata = orderMetadata.ToMetadata()
				},
				Redemption = new StackableDiscountInfo()
				{
					// Referral Code itself represent as a voucher, so that's why it should be treated as voucher.
					DiscountType = (int)request.DiscountCodeType == (int)DiscountType.ExtraBalance
							? nameof(DiscountCodeType.Voucher).ToLower() : request.DiscountCodeType.ToString().ToLower(),
					DiscountCode = request.DiscountCode,
					RewardId = _voucherifyConfig.LoyaltyRewardId,
					Metadata = new Metadata()
				}
			};

			if ((int)request.DiscountCodeType == (int)DiscountCodeType.Referral)
			{
				var referralCodeValidationResult = await ValidateReferralCode(new ReferralCodeValidationRequest()
				{
					ReferralCode = request.DiscountCode,

				}, msisdn, userAccount);

				if (referralCodeValidationResult?.Payload?.IsValid == true)
				{
					extraBalanceAmount = referralCodeValidationResult.Payload.Value;
				}
			}

			var result = await _voucherifyService.RedeemStackableDiscounts(redemptionRequest, msisdn);
			if (result?.Payload != null)
			{
				// Both referee and referral get balance after code redemption

				// Referee
				if ((int)request.DiscountCodeType == (int)DiscountCodeType.Referral
							&& !string.IsNullOrEmpty(result?.Payload.RedemptionId) && extraBalanceAmount > 0)
				{
					await VoucherifyFulfillment(msisdn, result?.Payload.RedemptionId, CreditReason.Referee, extraBalanceAmount);
					await InvokeEvent(msisdn, VoucherifyEventsNames.SuccessPointsReferee, new VoucherifyEventsMetadata() { Timestamp = DateTime.UtcNow, LoyaltyPoints = _voucherifyConfig.LoyaltyEarningRules.Referral.RefereePoints });
				}

				// Referrer
				if ((int)request.DiscountCodeType == (int)DiscountCodeType.Referral
							&& !string.IsNullOrEmpty(result?.Payload?.Referrer?.SourceId))
				{
					await VoucherifyFulfillment(result?.Payload?.Referrer?.SourceId, result?.Payload.RedemptionId, CreditReason.Referrer);
					await InvokeEvent(result?.Payload?.Referrer?.SourceId, VoucherifyEventsNames.SuccessPointsReferrer, new VoucherifyEventsMetadata() { Timestamp = DateTime.UtcNow, LoyaltyPoints = _voucherifyConfig.LoyaltyEarningRules.Referral.ReferrerPoints });
					await _airShipService.ReferralRedeemedAirshipEvent(result?.Payload?.Referrer?.SourceId, _voucherifyConfig.LoyaltyEarningRules.Referral.ReferrerPoints);
				}

				var response = new StackableDiscountResponse
				{
					Order = result?.Payload.Order
				};

				response.Order.Amount /= 100;
				response.Order.DiscountAmount = (int)request.DiscountCodeType == (int)DiscountType.ExtraBalance ? 0 : result.Payload.Order.DiscountAmount != null ? Convert.ToDecimal(result.Payload.Order.DiscountAmount) / 100 : result.Payload.Order.AmountOff.Value / 100;
				response.RedemptionId = result.Payload.RedemptionId;
				response.CampaignName = result.Payload.CampaignName;

				return GenericApiResponse<StackableDiscountResponse>.Success(response, "Success");
			}

			_logger.Debug("Class: Voucherify_BL, Method: RedeemDiscount, Message: RedeemDiscount failed, " +
					$"Request:{msisdn} {JsonConvert.SerializeObject(request)} {JsonConvert.SerializeObject(customerMetadata)} {JsonConvert.SerializeObject(redemptionRequest)}");

			return null;
		}

		public async Task<GenericApiResponse<ValidateDiscountResponse>> ValidateDiscount(StackableDiscountRequest request, string msisdn, string userAccount, CustomerMetadata customerMetadata = null)
		{
			if (!_voucherifyConfig.EndpointConfig.ValidateDiscount)
			{
				return GenericApiResponse<ValidateDiscountResponse>.Failure(_localizer["VoucherCodeInvalid"], ApiStatusCodes.VoucherCodeInvalid);
			}

			string skuId = GenerateSkuId(request);

			if (customerMetadata == null)
			{
				// new user (if customer does not have any transactional record)
				var hasUserDoneTransaction = await _userAccount_DL.IsNewUser(msisdn);
				var isFirstTopup = await _userAccount_DL.IsFirstTopUp(msisdn);
				var isFirstInternationalTopup = await _aTT_DL.IsFirstATTTransaction(userAccount);

				customerMetadata = new CustomerMetadata
				{
					TransactionDone = !hasUserDoneTransaction,
					FirstInternationalTopup = isFirstInternationalTopup,
					FirstTopup = isFirstTopup,
				};
			}
			var orderMetadata = new OrderMetadata
			{
				CheckoutType = new[] { request.CheckoutType.ToString() },
				PaymentMethod = new[] { request.PaymentMethod.ToString() },
				OperatorName = !string.IsNullOrEmpty(request.Operator) ? request.Operator.ToLower() : string.Empty,
				InternationalTopupDestination = !string.IsNullOrEmpty(request.DestinationCountryISOCode) ? request.DestinationCountryISOCode.ToLower() : string.Empty,
			};
			// There are two type of discounts (promotion/voucher)
			var validationRequest = new StackableDiscountValidationRequest()
			{
				Customer = new StackableDiscountCustomerInfo()
				{
					SourceId = msisdn,
					Metadata = customerMetadata.ToMetadata()
				},
				Order = new StackableDiscountOrderInfo()
				{
					SkuId = skuId,
					Quantity = 1,
					Amount = (long)(request.Amount * 100), // Multiplying with 100. Voucherify deals numbers in this way. (1 count a 100)
					Metadata = orderMetadata.ToMetadata()
				},
				Validation = new StackableDiscountInfo()
				{
					DiscountType = (int)request.DiscountCodeType == (int)DiscountType.ExtraBalance ? nameof(DiscountCodeType.Voucher).ToLower() : request.DiscountCodeType.ToString().ToLower(),
					DiscountCode = request.DiscountCode,
					RewardId = _voucherifyConfig.LoyaltyRewardId,
					Metadata = new Metadata()
				}
			};
			var result = await _voucherifyService.ValidateStackableDiscounts(validationRequest, msisdn);
			if (result?.Payload?.Order != null && result?.Payload.IsValid == true)
			{
				_logger.Debug($"{{Class: Voucherify_BL, Method:ValidateDiscount, Message: Invalid Code, Request:CustomerMsisdn:{msisdn}, {JsonConvert.SerializeObject(request)}, {userAccount}, {JsonConvert.SerializeObject(customerMetadata)}");

				DiscountType discountType;
				if (result.Payload.Order.DiscountType.Equals("AMOUNT", StringComparison.InvariantCultureIgnoreCase)
				|| result.Payload.Order.DiscountType.Equals("FIXED", StringComparison.CurrentCultureIgnoreCase))
				{
					discountType = DiscountType.Amount;
				}
				else if (result.Payload.Order.DiscountType.Equals("UNIT", StringComparison.InvariantCultureIgnoreCase))
				{
					discountType = DiscountType.ExtraBalance;
				}
				else
				{
					discountType = DiscountType.Percent;
				}
				var discountInfo = GetDiscountValueAndType(result.Payload.Order.AmountLimit ?? 0, result.Payload.Order.PercentOff ?? 0, result.Payload.Order.AmountOff ?? 0, discountType, request.Amount);

				return GenericApiResponse<ValidateDiscountResponse>.Success(new ValidateDiscountResponse
				{
					CampaignName = result.Payload?.CampaignName,
					Amount = result.Payload.Order.Amount != null ? Convert.ToDecimal(result.Payload.Order.Amount) / 100 : 0,
					Value = discountInfo.discountValue,
					DiscountAmount = discountInfo.discountAmount,
					DiscountCode = request.DiscountCode,
					DiscountType = discountInfo.discountType,
				}, "Success");
			}

			return GenericApiResponse<ValidateDiscountResponse>.Failure(_localizer["VoucherCodeInvalid"], ApiStatusCodes.VoucherCodeInvalid);
		}
		public async Task<GenericApiResponse<ValidateDiscountResponse>> ValidateDiscountV3(StackableDiscountRequestV3 request, string msisdn, string userAccount, CustomerMetadata customerMetadata = null)
		{
			InternationalTopupTransactionLog internationalTopupTransactionLog = null;
			var transferOperator = string.Empty;
			var details = new ValidateDiscountResponse.OrderDetail();
			var origination = _helper_BL.GetCountryCode(msisdn);
			var transferDestination = string.Empty;
			if (request.CheckoutType == CheckOutTypes.Transfer)
			{
				internationalTopupTransactionLog = await _aTT_DL.GetTransactionLog(request.TransferNowtelRef, request.TransferProduct);
				if (internationalTopupTransactionLog is null)
				{
					internationalTopupTransactionLog = await PrepareTransactionLogAsync(request.TransferNowtelRef, request.TransferProduct, decimal.Zero);
					await _aTT_DL.CreateTransactionLogAsync(internationalTopupTransactionLog);
				}
				var orderDetails = new ValidateDiscountResponse.OrderDetail();
				var product = await _aTT_DL.GetProductByNowtelTransactionReference(request.TransferNowtelRef, request.TransferProduct);
				transferDestination = _helper_BL.GetCountryCode(product.tomsisdn);
				transferOperator = product.operatorName;
				(decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, transferDestination, product.fromCurrency, request.Amount);
				details = new ValidateDiscountResponse.OrderDetail
				{
					ServiceFee = serviceFee,
					ServiceFeeDiscount = serviceFeeDiscount,
					TotalServiceFee = totalServiceFee,
				};
			}
			if (!_voucherifyConfig.EndpointConfig.ValidateDiscount)
			{
				if (request.CheckoutType == CheckOutTypes.Transfer)
				{
					PrepareUpdateTransactionLog(internationalTopupTransactionLog, null, 0, "Invalid voucher code");
					await _aTT_DL.UpdateTransactionLog(internationalTopupTransactionLog);
				}
				return GenericApiResponse<ValidateDiscountResponse>.Failure(_localizer["VoucherCodeInvalid"], ApiStatusCodes.VoucherCodeInvalid);
			}

			string skuId = GenerateSkuId(request);

			if (customerMetadata == null)
			{
				// new user (if customer does not have any transactional record)
				var hasUserDoneTransaction = await _userAccount_DL.IsNewUser(msisdn);
				var isFirstTopup = await _userAccount_DL.IsFirstTopUp(msisdn);
				var isFirstInternationalTopup = await _aTT_DL.IsFirstATTTransaction(userAccount);

				customerMetadata = new CustomerMetadata
				{
					TransactionDone = !hasUserDoneTransaction,
					FirstInternationalTopup = isFirstInternationalTopup,
					FirstTopup = isFirstTopup,
				};
			}
			var orderMetadata = new OrderMetadata
			{
				CheckoutType = new[] { request.CheckoutType.ToString() },
				PaymentMethod = new[] { request.PaymentMethod.ToString() },
				OperatorName = !string.IsNullOrEmpty(transferOperator) ? transferOperator.ToLower() : string.Empty,
				InternationalTopupDestination = !string.IsNullOrEmpty(transferDestination) ? transferDestination.ToLower() : string.Empty,
			};
			// There are two type of discounts (promotion/voucher)
			var validationRequest = new StackableDiscountValidationRequest()
			{
				Customer = new StackableDiscountCustomerInfo()
				{
					SourceId = msisdn,
					Metadata = customerMetadata.ToMetadata()
				},
				Order = new StackableDiscountOrderInfo()
				{
					SkuId = skuId,
					Quantity = 1,
					Amount = (long)(request.Amount * 100), // Multiplying with 100. Voucherify deals numbers in this way. (1 count a 100)
					Metadata = orderMetadata.ToMetadata()
				},
				Validation = new StackableDiscountInfo()
				{
					DiscountType = (int)request.DiscountCodeType == (int)DiscountType.ExtraBalance ? nameof(DiscountCodeType.Voucher).ToLower() : request.DiscountCodeType.ToString().ToLower(),
					DiscountCode = request.DiscountCode,
					RewardId = _voucherifyConfig.LoyaltyRewardId,
					Metadata = new Metadata()
				}
			};
			var result = await _voucherifyService.ValidateStackableDiscounts(validationRequest, msisdn);
			if (result?.Payload?.Order != null && result?.Payload.IsValid == true)
			{
				_logger.Debug($"{{Class: Voucherify_BL, Method:ValidateDiscount, Message: Invalid Code, Request:CustomerMsisdn:{msisdn}, {JsonConvert.SerializeObject(request)}, {userAccount}, {JsonConvert.SerializeObject(customerMetadata)}");

				DiscountType discountType;
				if (result.Payload.Order.DiscountType.Equals("AMOUNT", StringComparison.InvariantCultureIgnoreCase)
				|| result.Payload.Order.DiscountType.Equals("FIXED", StringComparison.CurrentCultureIgnoreCase))
				{
					discountType = DiscountType.Amount;
				}
				else if (result.Payload.Order.DiscountType.Equals("UNIT", StringComparison.InvariantCultureIgnoreCase))
				{
					discountType = DiscountType.ExtraBalance;
				}
				else
				{
					discountType = DiscountType.Percent;
				}
				var discountInfo = GetDiscountValueAndType(result.Payload.Order.AmountLimit ?? 0, result.Payload.Order.PercentOff ?? 0, result.Payload.Order.AmountOff ?? 0, discountType, request.Amount);
				if (request.CheckoutType == CheckOutTypes.Transfer)
				{
					PrepareUpdateTransactionLog(internationalTopupTransactionLog, null, 0, "Valid voucher code");
					await _aTT_DL.UpdateTransactionLog(internationalTopupTransactionLog);
				}
				return GenericApiResponse<ValidateDiscountResponse>.Success(new ValidateDiscountResponse
				{
					OrderDetails = details,
					CampaignName = result.Payload?.CampaignName,
					Amount = result.Payload.Order.Amount != null ? Convert.ToDecimal(result.Payload.Order.Amount) / 100 : 0,
					Value = discountInfo.discountValue,
					DiscountAmount = discountInfo.discountAmount,
					DiscountCode = request.DiscountCode,
					DiscountType = discountInfo.discountType,
				}, "Success");
			}
			if (request.CheckoutType == CheckOutTypes.Transfer)
			{
				PrepareUpdateTransactionLog(internationalTopupTransactionLog, null, 0, "VoucherCodeInvalid");
				await _aTT_DL.UpdateTransactionLog(internationalTopupTransactionLog);
			}
			return GenericApiResponse<ValidateDiscountResponse>.Failure(_localizer["VoucherCodeInvalid"], ApiStatusCodes.VoucherCodeInvalid);
		}

		public async Task<GenericApiResponse<VoucherifyLoyaltiesResponse>> GetLoyaltiesInfo(string customerMsisdn, string customerEmail, string description)
		{
			if (!_voucherifyConfig.EndpointConfig.GetLoyaltyInformation)
			{
				return GenericApiResponse<VoucherifyLoyaltiesResponse>.Success(
					new VoucherifyLoyaltiesResponse()
					{
						CustomerPoints = 0,
						LoyaltyCampaigns = await GetLoyaltyCampaignsFromAppSettings(customerMsisdn, false),
						RewardProducts = new List<LoyaltyRewardProducts>(),
						LoyaltyTermsInfo = new LoyaltyTerms()
						{
							Descripion = description,
							Heading = _localizer["LoyaltyTermsHeading"]
						}
					}, "Success");
			}

			//Get AutoTopup
			if (string.IsNullOrEmpty(customerEmail))
			{
				var userInfo = await _userAccount_DL.GetUserProfile(customerMsisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						customerEmail = userInfo.Data.email.Trim();
				}
			}

			var isAutoTopupEnabled = false;
			var autoTopupResponse = await _pay360Service.GetAutoTopUp(customerMsisdn, customerEmail);
			if (autoTopupResponse.ErrorCode == 0 && autoTopupResponse.Payload != null)
			{
				isAutoTopupEnabled = autoTopupResponse.Payload.AutoTopUpStatus;
			}

			var getCustomerRequest = new GetVoucherifyCustomerRequest() { SourceId = customerMsisdn, LoyaltyCampaignId = _voucherifyConfig.LoyaltyCampaignId };
			var voucherifyCustomer = await _voucherifyService.GetCustomerBySourceId(getCustomerRequest, customerMsisdn);
			if (voucherifyCustomer?.Payload == null)
			{
				_logger.Debug("Class: Voucherify_BL, Method:GetLoyaltiesInfo, Message: Customer not found, " +
					$"Request: CustomerMsisdn:{customerMsisdn}, IsAutoTopupEnabled:{isAutoTopupEnabled}, LoyaltyTerms:{description}");

				// If customer doens't exist, New customer will be created inside voucherify
				var isUserCreated = await CreateVoucherifyNewUser(customerMsisdn);
				if (!isUserCreated)
				{
					//Will return Empty response
					return GenericApiResponse<VoucherifyLoyaltiesResponse>.Success(
						new VoucherifyLoyaltiesResponse()
						{
							CustomerPoints = 0,
							LoyaltyCampaigns = await GetLoyaltyCampaignsFromAppSettings(customerMsisdn, isAutoTopupEnabled),
							RewardProducts = new List<LoyaltyRewardProducts>(),
							LoyaltyTermsInfo = new LoyaltyTerms()
							{
								Descripion = description,
								Heading = _localizer["LoyaltyTermsHeading"]
							}
						}, "Success");
				}
				voucherifyCustomer = await _voucherifyService.GetCustomerBySourceId(getCustomerRequest, customerMsisdn);
			}

			var getEarningRulesRequest = new GetEarningRulesRequest()
			{
				CampaignId = _voucherifyConfig.LoyaltyCampaignId,
				PageNumber = 1,
				PageSize = 100,
			};

			// Earning rules will be fetched from appsettings
			//var otherLoyaltyCampaigns = await _voucherifyService.GetCampaignEarningRules(getEarningRulesRequest);
			var rewardProducts = await _voucherifyService.GetProductSKUs(
				new GetProductSkusRequest()
				{
					ProductNameOrId = _voucherifyConfig.LoyaltyProductId,
				}, customerMsisdn);

			var response = new VoucherifyLoyaltiesResponse()
			{
				CustomerPoints = voucherifyCustomer?.Payload == null ? 0 : voucherifyCustomer.Payload.Points,
				LoyaltyCampaigns = await GetLoyaltyCampaignsFromAppSettings(customerMsisdn, isAutoTopupEnabled),
				RewardProducts = rewardProducts == null || rewardProducts.Payload == null
							? default : rewardProducts.Payload.Select(rewardProduct => new LoyaltyRewardProducts()
							{
								Points = rewardProduct.Points,
								Price = Convert.ToDecimal(rewardProduct.Price) / 100,
								SkuId = rewardProduct?.SkuId,
							}),
				LoyaltyTermsInfo = new LoyaltyTerms()
				{
					Descripion = description,
					Heading = _localizer["LoyaltyTermsHeading"]
				}
			};

			return GenericApiResponse<VoucherifyLoyaltiesResponse>.Success(response, "Success");
		}
		private InternationalTopupTransactionLog PrepareUpdateTransactionLog(InternationalTopupTransactionLog transaction, decimal? discount, int checkoutStatus, string message)
		{
			if (discount.HasValue)
			{
				transaction.DiscountApplied = discount.Value;
				transaction.TotalPrice -= discount.Value;
			}
			transaction.CheckoutStatus = checkoutStatus;
			transaction.Message = message;
			return transaction;
		}
		private async Task<InternationalTopupTransactionLog> PrepareTransactionLogAsync(string nowtelRef, string productId, decimal discount = 0)
		{
			var product = await _aTT_DL.GetProductByNowtelTransactionReference(nowtelRef, productId);
			var productAmount = decimal.Parse(product.fromAmount, CultureInfo.InvariantCulture);
			var origination = _helper_BL.GetCountryCode(product.fromMsisdn);
			var destination = _helper_BL.GetCountryCode(product.tomsisdn);
			var amountToCharge = decimal.Parse(product.CustomerChargeValue, CultureInfo.InvariantCulture);
			(decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, product.fromCurrency, productAmount);
			amountToCharge += totalServiceFee;
			amountToCharge -= discount;
			return new InternationalTopupTransactionLog
			{
				CheckoutStatus = 0,
				Currency = product.fromCurrency,
				CustomerIdentifier = product.fromMsisdn,
				ToMsisdn = product.tomsisdn,
				TransactionIdentifier = nowtelRef,
				ProductPrice = productAmount,
				DiscountOnServiceFee = serviceFeeDiscount,
				DiscountApplied = discount,
				Message = "",
				ProductIdentifier = product.product,
				TotalPrice = amountToCharge,
				ServiceFee = totalServiceFee,
				SalePrice = productAmount,
			};
		}
		public async Task<GenericApiResponse<GetCustomerSpecificPromotionsResult>> GetCustomerSpecificPromotionsTiers(GetCustomerSpecificPromotionsRequest request, string customerMsisdn, string userAccount, string currency)
		{
			try
			{
				var origination = _helper_BL.GetCountryCode(customerMsisdn);
				var destination = string.Empty;
				OrderDetail details = new OrderDetail();
				if (request.CheckoutType == CheckOutTypes.Transfer)
				{
				}
				if (!_voucherifyConfig.EndpointConfig.GetPromotions)
				{
					return GenericApiResponse<GetCustomerSpecificPromotionsResult>.Success(
						new GetCustomerSpecificPromotionsResult()
						{
							Promotions = null,
							Rewards = null,
							OrderDetails = details
						}, "Success");
				}

				//TODO:Create voucherify customer
				await CreateVoucherifyNewUser(customerMsisdn);

				string skuId = string.Empty;
				int rewardPoints = 0;
				if (request.CheckoutType == CheckOutTypes.Bundle)
				{
					skuId = $"THA_Bundle_{request.BundleRef}";
					var BundleDetails = await _bundle_DL.GetBundleById(request.BundleRef, null);
					if (BundleDetails is null)
					{
						return GenericApiResponse<GetCustomerSpecificPromotionsResult>.Failure(_localizer["TryAgainLater"], ApiStatusCodes.BadRequest);
					}
					rewardPoints = BundleDetails.RewardPoints;
				}
				else if (request.CheckoutType == CheckOutTypes.TopUp)
				{
					skuId = $"THA_Topup_{request.Amount}";
					rewardPoints = _pay360Config.TopupAmounts.FirstOrDefault(x => x.Amount == request.Amount)?.RewardPoints ?? 0;
				}
				else if (request.CheckoutType == CheckOutTypes.Transfer)
				{
					skuId = $"THA_IntTopup_{request.Amount}";
					rewardPoints = Utility.CalculateInternationalTopupRewardPointsRange(request.Amount, _voucherifyConfig.LoyaltyEarningRules.International);

				}
				var hasTransactionDone = await _userAccount_DL.IsNewUser(customerMsisdn);
				var isFirstTopup = await _userAccount_DL.IsFirstTopUp(customerMsisdn);
				var isFirstInternationalTopup = await _aTT_DL.IsFirstATTTransaction(userAccount);
				var customerMetadata = new CustomerMetadata()
				{
					TransactionDone = !hasTransactionDone,
					FirstTopup = isFirstTopup,
					FirstInternationalTopup = isFirstInternationalTopup
				};
				var orderMeatdata = new OrderMetadata
				{
					CheckoutType = new string[] { request.CheckoutType.ToString() },
					InternationalTopupDestination = request.DestinationCountryISOCode.ToLowerInvariant(),
					OperatorName = request.Operator,
					PaymentMethod = new string[] { request.PaymentMethod.ToString() }
				};
				var getCustomerSpcificPromotionTiers = new GetCustomerSpecificPromotionTiersRequest()
				{
					Customer = new PromotionTierCustomerInfo { SourceId = customerMsisdn, Metadata = customerMetadata.ToMetadata() },
					Order = new PromotionTierOrderInfo
					{
						Quantity = 1,
						SkuId = skuId,
						Amount = Convert.ToInt64(request.Amount * 100),
						Metadata = orderMeatdata.ToMetadata()
					}
				};
				var promotions = await _voucherifyService.GetCustomerSpecificPromotionTiers(getCustomerSpcificPromotionTiers, customerMsisdn);
				if (promotions?.Payload == null)
				{
					_logger.Debug($"{{Class: Voucherify_BL, Method:GetCustomerSpecificPromotionTiers, Message: There is currently promotions not exist for this customer, Request:CustomerMsisdn:{customerMsisdn}, {JsonConvert.SerializeObject(request)}");
					return GenericApiResponse<GetCustomerSpecificPromotionsResult>.Success(
						new GetCustomerSpecificPromotionsResult()
						{
							Promotions = null,
							Rewards = new RewardsInfo()
							{
								RewardPoints = rewardPoints,
							},
							OrderDetails = details,
						}, "Success");
				}
				DiscountType discountType;

				if (promotions.Payload.DiscountType.Equals("AMOUNT", StringComparison.InvariantCultureIgnoreCase)
					|| promotions.Payload.DiscountType.Equals("FIXED", StringComparison.CurrentCultureIgnoreCase))
				{
					discountType = DiscountType.Amount;
				}
				else
				{
					discountType = DiscountType.Percent;
				}

				var discountInfo = GetDiscountValueAndType(promotions.Payload.AmountLimit ?? 0, promotions.Payload.PercentOff ?? 0, promotions.Payload.AmountOff ?? 0, discountType, request.Amount);

				var result = new GetCustomerSpecificPromotionsResult
				{
					Promotions = new PromotionsInfo()
					{
						DiscountCode = promotions.Payload.PromotionId,
						Banner = promotions.Payload.Banner,
						Value = discountInfo.discountValue,
						DiscountType = discountInfo.discountType,
						Amount = request.Amount,
						DiscountAmount = discountInfo.discountAmount
					},
					OrderDetails = details,
					Rewards = new RewardsInfo()
					{
						RewardPoints = rewardPoints,
					}
				};
				return GenericApiResponse<GetCustomerSpecificPromotionsResult>.Success(result, "Success");
			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: Voucherify_BL, Method: GetCustomerSpecificPromotionsTiers");
				return GenericApiResponse<GetCustomerSpecificPromotionsResult>.Failure("Failure ", ApiStatusCodes.InternalServerError);
			}
		}
		public async Task<GenericApiResponse<GetCustomerSpecificPromotionsResult>> GetCustomerSpecificPromotionsTiersV3(GetCustomerSpecificPromotionRequestV3 request, string customerMsisdn, string userAccount, string currency)
		{
			InternationalTopupTransactionLog internationalTopupTransactionLog = null;
			if (request.CheckoutType == CheckOutTypes.Transfer)
				internationalTopupTransactionLog = await PrepareTransactionLogAsync(request.TransferNowtelRef, request.TransferProduct, decimal.Zero);
			try
			{
				var origination = _helper_BL.GetCountryCode(customerMsisdn);
				var transferDestination = string.Empty;
				var transferOperator = string.Empty;
				OrderDetail details = new OrderDetail();
				if (request.CheckoutType == CheckOutTypes.Transfer)
				{
					var product = await _aTT_DL.GetProductByNowtelTransactionReference(request.TransferNowtelRef, request.TransferProduct);
					transferDestination = _helper_BL.GetCountryCode(product.tomsisdn);
					transferOperator = product.operatorName;
					(decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, transferDestination, currency, request.Amount);
					details = new OrderDetail
					{
						ServiceFee = serviceFee,
						ServiceFeeDiscount = serviceFeeDiscount,
						TotalServiceFee = totalServiceFee,
					};
				}
				if (!_voucherifyConfig.EndpointConfig.GetPromotions)
				{
					if (request.CheckoutType == CheckOutTypes.Transfer)
					{
						await _aTT_DL.CreateTransactionLogAsync(internationalTopupTransactionLog);
					}
					return GenericApiResponse<GetCustomerSpecificPromotionsResult>.Success(
						new GetCustomerSpecificPromotionsResult()
						{
							Promotions = null,
							Rewards = null,
							OrderDetails = details
						}, "Success");
				}

				//TODO:Create voucherify customer
				await CreateVoucherifyNewUser(customerMsisdn);

				string skuId = string.Empty;
				int rewardPoints = 0;
				if (request.CheckoutType == CheckOutTypes.Bundle)
				{
					skuId = $"THA_Bundle_{request.BundleRef}";
					var BundleDetails = await _bundle_DL.GetBundleById(request.BundleRef, null);
					if (BundleDetails is null)
					{
						return GenericApiResponse<GetCustomerSpecificPromotionsResult>.Failure(_localizer["TryAgainLater"], ApiStatusCodes.BadRequest);
					}
					rewardPoints = BundleDetails.RewardPoints;
				}
				else if (request.CheckoutType == CheckOutTypes.TopUp)
				{
					skuId = $"THA_Topup_{request.Amount}";
					rewardPoints = _pay360Config.TopupAmounts.FirstOrDefault(x => x.Amount == request.Amount)?.RewardPoints ?? 0;
				}
				else if (request.CheckoutType == CheckOutTypes.Transfer)
				{
					skuId = $"THA_IntTopup_{request.Amount}";
					rewardPoints = Utility.CalculateInternationalTopupRewardPointsRange(request.Amount, _voucherifyConfig.LoyaltyEarningRules.International);

				}
				var hasTransactionDone = await _userAccount_DL.IsNewUser(customerMsisdn);
				var isFirstTopup = await _userAccount_DL.IsFirstTopUp(customerMsisdn);
				var isFirstInternationalTopup = await _aTT_DL.IsFirstATTTransaction(userAccount);
				var customerMetadata = new CustomerMetadata()
				{
					TransactionDone = !hasTransactionDone,
					FirstTopup = isFirstTopup,
					FirstInternationalTopup = isFirstInternationalTopup
				};
				var orderMeatdata = new OrderMetadata
				{
					CheckoutType = new string[] { request.CheckoutType.ToString() },
					InternationalTopupDestination = transferDestination.ToLowerInvariant(),
					OperatorName = transferOperator,
					PaymentMethod = new string[] { request.PaymentMethod.ToString() }
				};
				var getCustomerSpcificPromotionTiers = new GetCustomerSpecificPromotionTiersRequest()
				{
					Customer = new PromotionTierCustomerInfo { SourceId = customerMsisdn, Metadata = customerMetadata.ToMetadata() },
					Order = new PromotionTierOrderInfo
					{
						Quantity = 1,
						SkuId = skuId,
						Amount = Convert.ToInt64(request.Amount * 100),
						Metadata = orderMeatdata.ToMetadata()
					}
				};
				var promotions = await _voucherifyService.GetCustomerSpecificPromotionTiers(getCustomerSpcificPromotionTiers, customerMsisdn);
				if (promotions?.Payload == null)
				{
					_logger.Debug($"{{Class: Voucherify_BL, Method:GetCustomerSpecificPromotionTiers, Message: There is currently promotions not exist for this customer, Request:CustomerMsisdn:{customerMsisdn}, {JsonConvert.SerializeObject(request)}");
					if (request.CheckoutType == CheckOutTypes.Transfer)
					{
						await _aTT_DL.CreateTransactionLogAsync(internationalTopupTransactionLog);
					}
					return GenericApiResponse<GetCustomerSpecificPromotionsResult>.Success(
						new GetCustomerSpecificPromotionsResult()
						{
							Promotions = null,
							Rewards = new RewardsInfo()
							{
								RewardPoints = rewardPoints,
							},
							OrderDetails = details,
						}, "Success");
				}
				DiscountType discountType;

				if (promotions.Payload.DiscountType.Equals("AMOUNT", StringComparison.InvariantCultureIgnoreCase)
					|| promotions.Payload.DiscountType.Equals("FIXED", StringComparison.CurrentCultureIgnoreCase))
				{
					discountType = DiscountType.Amount;
				}
				else
				{
					discountType = DiscountType.Percent;
				}

				var discountInfo = GetDiscountValueAndType(promotions.Payload.AmountLimit ?? 0, promotions.Payload.PercentOff ?? 0, promotions.Payload.AmountOff ?? 0, discountType, request.Amount);

				var result = new GetCustomerSpecificPromotionsResult
				{
					Promotions = new PromotionsInfo()
					{
						DiscountCode = promotions.Payload.PromotionId,
						Banner = promotions.Payload.Banner,
						Value = discountInfo.discountValue,
						DiscountType = discountInfo.discountType,
						Amount = request.Amount,
						DiscountAmount = discountInfo.discountAmount
					},
					OrderDetails = details,
					Rewards = new RewardsInfo()
					{
						RewardPoints = rewardPoints,
					}
				};
				if (request.CheckoutType == CheckOutTypes.Transfer)
				{
					PrepareUpdateTransactionLog(internationalTopupTransactionLog, result.Promotions.DiscountAmount, 0, string.Empty);
					await _aTT_DL.CreateTransactionLogAsync(internationalTopupTransactionLog);
				}
				return GenericApiResponse<GetCustomerSpecificPromotionsResult>.Success(result, "Success");
			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: Voucherify_BL, Method: GetCustomerSpecificPromotionsTiers");

				if (request.CheckoutType == CheckOutTypes.Transfer)
				{
					PrepareUpdateTransactionLog(internationalTopupTransactionLog, null, 0, "Error occured on checkout: { ex.Message}");
					await _aTT_DL.CreateTransactionLogAsync(internationalTopupTransactionLog);
				}
				return GenericApiResponse<GetCustomerSpecificPromotionsResult>.Failure("Failure ", ApiStatusCodes.InternalServerError);
			}
		}

		public async Task<bool> CreateVoucherifyNewUser(string userMsisdn)
		{
			var userProfile = await _userAccount_DL.GetUserProfile(userMsisdn);
			var hasTransactionDone = await _userAccount_DL.IsNewUser(userMsisdn);
			var isFirstTopup = await _userAccount_DL.IsFirstTopUp(userMsisdn);
			var isFirstInternationalTopup = await _aTT_DL.IsFirstATTTransaction(userMsisdn);
			var createCustomerRequest = new CreateVoucherifyCustomerRequest()
			{
				SourceId = userMsisdn,
				Name = $"{userProfile?.Data?.firstName}{userProfile?.Data?.lastName}",
				Email = userProfile?.Data?.email,
				Description = "UserCreatedViaApi",
				Phone = userMsisdn,
				Country = _helper_BL.GetCountryCode(userMsisdn).ToLowerInvariant(),
				Metadata = new CustomerMetadata()
				{
					TransactionDone = !hasTransactionDone,
					FirstInternationalTopup = isFirstInternationalTopup,
					FirstTopup = isFirstTopup,
				}.ToMetadata()
			};
			var newUser = await _voucherifyService.CreateVoucherifyCustomer(createCustomerRequest, userMsisdn);
			if (newUser?.Payload == null)
			{
				_logger.Debug($"{{Class: Voucherify_BL, Method: CreateVoucherifyCustomer, Message: Unable to create voucherify customer, Request:CustomerMsisdn:{userMsisdn}");
				return false;
			}
			return true;
		}

		public async Task<InvokedVoucherifyEventResponse> PurchaseEvent(string msisdn, string eventName, VoucherifyEventsMetadata eventMetadata)
		{
			if (!_voucherifyConfig.EndpointConfig.Event)
			{
				return null;
			}
			eventMetadata.ChargeAmount *= 100;
			return await HandleEvent(msisdn, eventName, eventMetadata);
		}

		public async Task<InvokedVoucherifyEventResponse> InvokeEvent(string msisdn, string eventName, VoucherifyEventsMetadata metadata)
		{
			if (!_voucherifyConfig.EndpointConfig.Event)
			{
				return null;
			}
			return await HandleEvent(msisdn, eventName, metadata);
		}

		#region Private Methods

		private async Task<InvokedVoucherifyEventResponse> HandleEvent(string msisdn, string eventName, VoucherifyEventsMetadata eventMetadata = default)
		{
			var request = new InvokeVoucherifyEventRequest
			{
				CustomerSourceId = msisdn.Replace("+", ""),
				EventName = eventName,
				Metadata = eventMetadata?.ToMetadata(),
			};
			await _airShipService.VoucherifyPointsEarnAirshipEvent(msisdn, eventMetadata.LoyaltyPoints);
			var eventResponse = await _voucherifyService.InvokeVoucherifyEvent(request, msisdn);
			if (eventResponse?.Payload?.IsEventInvoked == false)
			{
				_logger.Debug("Class: Voucherify_BL, Method: HandleEvent, Message: Unable to invoke event, Request:CustomerMsisdn " +
											$"{msisdn}, EventName: {eventName}, EventMetadata: {JsonConvert.SerializeObject(eventMetadata)}");
				return null;
			}
			return eventResponse.Payload;
		}




		private static string GenerateSkuId(StackableDiscountRequest request)
		{
			string skuId = string.Empty;
			switch (request.CheckoutType)
			{
				case CheckOutTypes.TopUp:
					skuId = $"THA_Topup_{request.Amount}";
					break;
				case CheckOutTypes.Bundle:
					skuId = $"THA_Bundle_{request.BundleRef}";
					break;
				case CheckOutTypes.Transfer:
					skuId = $"THA_IntTopup_{request.Amount}";
					break;
				default:
					break;
			}
			return skuId;
		}
		private static string GenerateSkuId(StackableDiscountRequestV3 request)
		{
			string skuId = string.Empty;
			switch (request.CheckoutType)
			{
				case CheckOutTypes.TopUp:
					skuId = $"THA_Topup_{request.Amount}";
					break;
				case CheckOutTypes.Bundle:
					skuId = $"THA_Bundle_{request.BundleRef}";
					break;
				case CheckOutTypes.Transfer:
					skuId = $"THA_IntTopup_{request.Amount}";
					break;
				default:
					break;
			}
			return skuId;
		}

		private async Task<IEnumerable<LoyaltyEarningCampaigns>> GetLoyaltyCampaignsFromAppSettings(string msisdn, bool isAutoTopupEnabled)
		{
			var userProfile = await _userAccount_DL.GetUserProfile(msisdn);
			bool isProfileCompleted = CommonHelpers.IsUserProfileCompleted(userProfile.Data.firstName, userProfile.Data.lastName, userProfile.Data.email, userProfile.Data.emailVerified, userProfile.Data.imageUrl, userProfile.Data.dobDay);
			bool hasUserDoneTransaction = await _userAccount_DL.IsNewUser(msisdn);
			return _voucherifyConfig.LoyaltyCampaigns
				.Where(x => GetLoyaltyCampaignStatus(x, isAutoTopupEnabled, isProfileCompleted, hasUserDoneTransaction))
				.OrderBy(x => x.DisplayOrder)
				.Select(loyaltyCampaign => new LoyaltyEarningCampaigns
				{
					LoyaltyName = _localizer[loyaltyCampaign.LoyaltyName],
					LoyaltyPoints = loyaltyCampaign.LoyaltyPoints,
					LoyaltyType = loyaltyCampaign.LoyaltyType,
				});
		}

		private static bool GetLoyaltyCampaignStatus(VoucherifyConfig.CampaignConfig loyaltyCampaign, bool isAutoTopupEnabled, bool isProfileCompleted, bool isNewUser)
		{
			string loyaltyName = loyaltyCampaign.LoyaltyName.ToLowerInvariant();
			if (loyaltyName.Equals("buywelcomeoffer", StringComparison.CurrentCultureIgnoreCase) && isNewUser)
			{
				return true;
			}
			else if (loyaltyName.Equals("enableautotopup", StringComparison.CurrentCultureIgnoreCase) && !isAutoTopupEnabled)
			{
				return true;
			}
			else if (loyaltyName.Equals("referafriend", StringComparison.CurrentCultureIgnoreCase) && !isNewUser)
			{
				return true;
			}
			else if (loyaltyName.Equals("completeyourprofile", StringComparison.CurrentCultureIgnoreCase) && !isProfileCompleted)
			{
				return true;
			}
			else if (loyaltyName.Equals("topupyouraccount", StringComparison.CurrentCultureIgnoreCase))
			{
				return true;
			}
			return false;
		}

		private async Task<bool> VoucherifyFulfillment(string userMsisdn, string redemptionId, CreditReason creditReason, decimal balanceAmount = 3, int redemptionPoints = 0)
		{
			TransactionsPaymentType transactionPaymentType = TransactionsPaymentType.Points;
			var paymentMethod = string.Empty;
			var reason = string.Empty;
			var userProfile = await _userAccount_DL.GetUserProfile(userMsisdn);
			var userAccount = await _userAccount_DL.GetUserAccountInfo($"THA{userMsisdn}");
			if (userAccount == null)
			{
				_logger.Debug($"{{Class: Voucherify_BL, Method:VoucherifyFulfillment, Message: account not found {userMsisdn}}}");
				return false;
			}
			if (creditReason == CreditReason.Points)
			{
				transactionPaymentType = TransactionsPaymentType.Points;
				reason = $"TALK HOME App - Redeem Points - {redemptionPoints}";
				paymentMethod = "VoucherifyPointsRedeem";
			}
			else if (creditReason == CreditReason.Referrer)
			{
				transactionPaymentType = TransactionsPaymentType.Referrer;
				reason = "TALK HOME App - Voucherify Referrer";
				paymentMethod = "VoucherifyReferrerCredit";
			}
			else if (creditReason == CreditReason.Referee)
			{
				transactionPaymentType = TransactionsPaymentType.Referee;
				reason = "TALK HOME App - Voucherify Referee";
				paymentMethod = "VoucherifyRefereeCredit";
			}
			var basket = new basket
			{
				bundleRef = null,
				discountAmount = balanceAmount,
				chargeAmount = 0,
				productItemCode = nameof(ProductItemCode.THAATA),
				productRef = userMsisdn
			};
			var transactionId = await _paymentFullfillment_DL.InsertTransactionPaymentAsync(new List<basket> { basket }, userAccount.Currency, userProfile?.Data?.email, ProductCode.THA.ToString(), redemptionId, userMsisdn, transactionPaymentType, 0, false, null, null);
			var fulfillmentStatus = await _paymentFullfillment_DL.VoucherifyFulfillment(userAccount.AccountID, redemptionId, reason, paymentMethod, balanceAmount * 100);
			if (fulfillmentStatus)
			{
				await _paymentFullfillment_DL.UpdatePaymentTransactionAsync(transactionId, true);
				await _paymentFullfillment_DL.UpdatePaymentTransactionsItemsAsync(true, transactionId, "Success", false, null);
			}
			else
			{
				await _paymentFullfillment_DL.UpdatePaymentTransactionAsync(transactionId, true);
				await _paymentFullfillment_DL.UpdatePaymentTransactionsItemsAsync(false, transactionId, "Fulfillment failed", false, null);
			}
			return fulfillmentStatus;
		}

		private static (decimal discountAmount, DiscountType discountType, decimal discountValue) GetDiscountValueAndType(decimal amountLimit, decimal percentOff, decimal amountOff, DiscountType discountType, decimal productAmount)
		{
			decimal discountAmount = 0;
			decimal discountValue = 0;

			if ((int)discountType == (int)DiscountType.ExtraBalance)
			{
				discountAmount = 0;
				discountValue = 0;

				return (discountAmount, discountType, discountValue);
			}
			if (discountType == DiscountType.Percent && amountLimit <= 0)
			{
				discountAmount = (percentOff / 100) * productAmount;
				discountValue = percentOff;
			}
			if (discountType == DiscountType.Amount)
			{
				discountAmount = Convert.ToDecimal(amountOff) / 100;
				discountValue = discountAmount;
			}
			if (discountType == DiscountType.Percent && amountLimit > 0)
			{
				// Calculate the discount percentage
				decimal calculatedDiscount = (percentOff / 100) * productAmount;

				// Ensure the discount is not greater than the maximum allowed discount
				decimal maxDiscount = Convert.ToDecimal(amountLimit) / 100;

				discountAmount = calculatedDiscount < maxDiscount ? calculatedDiscount : maxDiscount;

				if (calculatedDiscount > maxDiscount)
				{
					discountType = DiscountType.Amount;
					discountValue = Convert.ToDecimal(amountLimit) / 100;
				}
				else
				{
					discountValue = percentOff;
				}
			}

			// Special case, if promotion return discount as a fix amount and product price is too small, then it sould return 0 instead of discount
			if (discountAmount <= 0)
			{
				return (0, discountType, discountValue);
			}
			return (discountAmount, discountType, discountValue);
		}

		#endregion
	}
}
