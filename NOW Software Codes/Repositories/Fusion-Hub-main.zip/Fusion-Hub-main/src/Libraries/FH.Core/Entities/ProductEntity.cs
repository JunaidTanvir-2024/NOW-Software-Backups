namespace FH.Core.Entities;
public sealed record ProductEntity : BaseEntity<long>
{
    public string? Name { get; set; }
    public string? Description { get; set; }
    public required long OperatorId { get; set; }
    public required long ProductPriceId { get; set; }
    public required long CurrencyUnitId { get; set; }
    public required long ProductCategoryId { get; set; }
    public required long ProductSubCategoryId { get; set; }
    public string? ValidityUnit { get; set; }
    public long? ValidityValue { get; set; }
    public required string VendorProductCode { get; set; }
    public required string VendorOperatorCode { get; set; }
    public long VendorId { get; set; }
    public bool? ProductType { get; set; }
}
