﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Response
{
    public class Pin
    {
        public string number { get; set; }          //Only for Mobile PIN products. PIN number
        public string serial { get; set; }          //Only for Mobile PIN products. PIN serial
        public string instructions { get; set; }    //Only for Mobile PIN products. Instructions to redeem the PIN
    }
}
