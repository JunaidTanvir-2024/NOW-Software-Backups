﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class AppConfigData
    {
        public IEnumerable<LocalAccessNumber2> localaccess { set; get; }
        public string bundlesms { get; set; }
        public string referralMessage1 { get; set; }
        public string referralMessage2 { get; set; }
        public Refreshconfig refreshconfig { get; set; }
        public AirtimeConfig airtimeconfig { get; set; }
        public a2aCallSettings A2ACallSettings { get; set; }
        public PaidCallSettings PaidCallSettings { get; set; }
        public bool isSIPCallLockedIPV6 { get; set; }
        public bool isIPV6MsgDisplay { get; set; }
        public Shortcut[] defaultShortcuts { get; set; }
        public string[] exclusionShortcuts { get; set; }
        public bool canShowApp2APP { get; set; }
        public bool multiStepFO { get; set; }
        public ForceUpdateMessage forceUpdateMessage { get; set; }
    }

    public class Shortcut
    {
        public int index { get; set; }
        public string service { get; set; }

    }

    public class Refreshconfig
    {
        public int startupoptions { get; set; }
        public int topupbuttons { get; set; }
        public string scdisable { get; set; }

    }

    public class CRIOSVersion
    {
        public string version { get; set; }
        public string itVersion { get; set; }
    }


    public class CRVersion
    {
        public string version { get; set; }
    }

    public class CarouselContent
    {
        public string service { get; set; }
        public string content { get; set; }
        public string title { get; set; }
    }

    public class SipResponse
    {
        public string Key { get; set; }
    }

    public class SipRequest
    {
        public string user { get; set; }
        public string domain { get; set; }
    }

    public class CarouselMenu
    {

        public string service { get; set; }
        public string title { get; set; }
        public string naservice { get; set; }

    }

    public class ForceUpdateMessage
    {

        public Message disabledMessage { get; set; }
        public string[] disabledVersionsAndroid { get; set; }
        public string[] disabledVersionsIos { get; set; }
        public Message upgradeMessage { get; set; }
        public object[] upgradeVersionsAndroid { get; set; }
        public object[] upgradeVersionsIos { get; set; }
    }

    public partial class Message
    {
        public string el { get; set; }
        public string en { get; set; }
        public string it { get; set; }
        public string fr { get; set; }
    }
}
