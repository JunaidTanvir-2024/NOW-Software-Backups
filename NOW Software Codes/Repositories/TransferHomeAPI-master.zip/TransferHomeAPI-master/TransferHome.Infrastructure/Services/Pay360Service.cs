﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using TransferHome.Models.Contracts.Service.Pay360ApiContracts;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TrasnferHome.Models.Configurations;
using TrasnferHome.Models.Utility;
using TransferHome.Infrastructure.Services.Interfaces;
using TransferHome.Models.Contracts.InAppModels;

namespace TransferHome.Infrastructure.Services
{
    public class Pay360Service : IPay360Service
    {
        private readonly string Pay360APiEndpoint;
        private readonly bool IsAuthorization;
        private readonly bool Do3DSecure;
        private readonly bool IsDirectFullfilment;

        public Pay360Service(IOptions<Pay360Config> Pay360Config)
        {
            Pay360APiEndpoint = Pay360Config.Value.Pay360ApiEndpoint;
            IsAuthorization = Pay360Config.Value.IsAuthorization;
            Do3DSecure = Pay360Config.Value.Do3DSecure;
            IsDirectFullfilment = Pay360Config.Value.IsDirectFullfilment;
        }

        public async Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Resume3DTransaction(Pay360Resume3DRequest request)
        {

            string endpoint = Pay360APiEndpoint + "Pay360CashierApi/Resume3DSecureTransaction";

            GenericPay360ApiResponse<Pay360PaymentResponse> ret = new GenericPay360ApiResponse<Pay360PaymentResponse>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360PaymentResponse>>(Result);

            return ret;

        }

        public async Task<GenericPay360ApiResponse<Pay360CardsResponse>> Pay360GetCards(Pay360CustomerRequestModel request)
        {
            GenericPay360ApiResponse<Pay360CardsResponse> ret = new GenericPay360ApiResponse<Pay360CardsResponse>();

            string endpoint = Pay360APiEndpoint + "Pay360CommonServices/GetCustomerPaymentMethodsByCustomerUniqueRef";

            var json = JsonConvert.SerializeObject(request);

            var Result = await Post(endpoint, json);

            if (Result == null)
            {
                return null;
            }

            //LoggerService.Debug(GetType(), Result);

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360CardsResponse>>(Result);

            return ret;
        }

        public async Task<GenericPay360ApiResponse<Pay360CustomerResponseModel>> GetCustomer(Pay360CustomerRequestModel model)
        {

            GenericPay360ApiResponse<Pay360CustomerResponseModel> ret = new GenericPay360ApiResponse<Pay360CustomerResponseModel>();

            string endpoint = "";

            endpoint = Pay360APiEndpoint + "Pay360CommonServices/GetCustomerByCustomerUniqueRef";

            var Json = JsonConvert.SerializeObject(model);

            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360CustomerResponseModel>>(Result);

            return ret;


        }

        public async Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType)
        {
            GenericPay360ApiResponse<Pay360PaymentResponse> ret = new GenericPay360ApiResponse<Pay360PaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";

            switch (paymentType)
            {
                case Pay360PaymentType.New:
                    endpoint = Pay360APiEndpoint + "Pay360CashierApi/NewCustomerPayment";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestNew);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.Default:
                    endpoint = Pay360APiEndpoint + "Pay360CashierApi/ExistingCustomerPaymentDefaultCard";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestDefault);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.ExistingNew:
                    endpoint = Pay360APiEndpoint + "Pay360CashierApi/ExistingCustomerPaymentNewCard";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestExistingNew);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.Token:
                    endpoint = Pay360APiEndpoint + "Pay360CashierApi/PaymentToken";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestToken);
                    Result = await Post(endpoint, Json);
                    break;
            }
            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360PaymentResponse>>(Result);
            return ret;

        }

        public Pay360PaymentRequestToken CreatePay360PaymentRequestToken(Pay360StartPaymentRequestModel model)
        {
            Pay360PaymentRequestToken result = new Pay360PaymentRequestToken
            {
                cardCv2 = model.UserCard.SecurityCode,
                customerMsisdn = model.CustomerPhoneNumber,
                isAuthorizationOnly = IsAuthorization,
                isDirectFullfilment = IsDirectFullfilment,
                transactionAmount = model.Amount,
                transactionCurrency = model.Currency,
                do3DSecure = Do3DSecure,
                cardToken = model.UserCard.Token
            };

            return result;
        }

        public Pay360PaymentBase CreatePay360PaymentBaseRequest(StartPay360RequestModel model)
        {
            Pay360PaymentBase result = new Pay360PaymentBase
            {
                cardCv2 = model.CardCv2,
                customerMsisdn = model.Msisdn,
                isAuthorizationOnly = IsAuthorization,
                isDirectFullfilment = IsDirectFullfilment,
                transactionAmount = model.Amount,
                transactionCurrency = model.Currency,
                do3DSecure = Do3DSecure
            };

            return result;
        }

        public Pay360PaymentRequestExistingNew CreatePay360PaymentRequestExistingNew(Pay360StartPaymentRequestModel model)
        {
            Pay360PaymentRequestExistingNew result = new Pay360PaymentRequestExistingNew
            {

                cardCv2 = model.UserCard.SecurityCode,
                cardExpiryDate = model.UserCard.ExpiryMonth + model.UserCard.ExpiryYear,
                cardPan = model.UserCard.CardNumber,
                customerMsisdn = model.CustomerPhoneNumber,
                isAuthorizationOnly = IsAuthorization,
                isDirectFullfilment = IsDirectFullfilment,
                isDefaultCard = false,
                do3DSecure = Do3DSecure,
                transactionAmount = model.Amount,
                transactionCurrency = model.Currency,
                customerName = model.UserCard.NameOnCard,
                billingAddress = new billingAddress
                {
                    line1 = "xx",
                    line2 = "",
                    line3 = "",
                    line4 = "",
                    city = "xx",
                    region = "xx",
                    postcode = "xx",
                    countryCode = "GB"
                }
            };

            return result;
        }

        public Pay360PaymentRequestNew CreatePay360PaymentRequestNew(Pay360StartPaymentRequestModel model)
        {
            Pay360PaymentRequestNew result = new Pay360PaymentRequestNew
            {
                customerName = model.UserCard.NameOnCard,
                cardCv2 = model.UserCard.SecurityCode,
                cardExpiryDate = model.UserCard.ExpiryMonth + model.UserCard.ExpiryYear,
                cardPan = model.UserCard.CardNumber,
                customerMsisdn = model.CustomerPhoneNumber,
                customerEmail = model.CustomerEmail,
                isAuthorizationOnly = IsAuthorization,
                isDirectFullfilment = IsDirectFullfilment,
                isDefaultCard = true,
                do3DSecure = Do3DSecure,
                transactionAmount = model.Amount,
                transactionCurrency = model.Currency,
                billingAddress = new billingAddress
                {
                    line1 = "xx",
                    line2 = "",
                    line3 = "",
                    line4 = "",
                    city = "xx",
                    region = "xx",
                    postcode = "xx",
                    countryCode = "GB"
                }
            };

            return result;
        }

        public async Task<GenericPay360ApiResponse<string>> SetAutoTopUp(Pay360SetAutoTopUpRequest model)
        {

            GenericPay360ApiResponse<string> ret = new GenericPay360ApiResponse<string>();

            string endpoint = Pay360APiEndpoint + "Pay360CommonServices/SetAutoTopup";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<string>>(Result);
                return ret;
            }

            return ret;

        }

        public async Task<GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(Pay360GetAutoTopUpRequest model)
        {

            GenericPay360ApiResponse<Pay360GetAutoTopUpResponse> ret = new GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>();

            string endpoint = Pay360APiEndpoint + "Pay360CommonServices/GetAutoTopup";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>>(Result);
                return ret;
            }

            return ret;

        }

        public async Task<GenericPay360ApiResponse<Models.Contracts.Service.Pay360ApiContracts.paymentMethodResponse>> SetCustomerDefaultCard(SetCustomerDefaultCardRequest model)
        {

            GenericPay360ApiResponse<Models.Contracts.Service.Pay360ApiContracts.paymentMethodResponse> ret = new GenericPay360ApiResponse<Models.Contracts.Service.Pay360ApiContracts.paymentMethodResponse>();

            string endpoint = Pay360APiEndpoint + "Pay360CommonServices/SetCustomerDefaultCard";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Models.Contracts.Service.Pay360ApiContracts.paymentMethodResponse>>(Result);
                return ret;
            }

            return ret;

        }

        public async Task<GenericPay360ApiResponse<string>> RemoveCard(RemoveCardRequest model)
        {

            GenericPay360ApiResponse<string> ret = new GenericPay360ApiResponse<string>();

            string endpoint = Pay360APiEndpoint + "Pay360CommonServices/RemoveCard";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<string>>(Result);
                return ret;
            }

            return ret;

        }

        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address), Timeout = TimeSpan.FromSeconds(60) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                    {
                        throw new WebException();
                    }

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (System.Exception e)
            {

                return null;
            }
        }

    }
}
