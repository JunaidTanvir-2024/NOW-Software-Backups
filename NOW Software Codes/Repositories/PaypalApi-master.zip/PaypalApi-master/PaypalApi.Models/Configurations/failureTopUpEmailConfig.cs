﻿namespace PaypalApi.Models.Configurations
{
    public class FailureTopUpEmailConfig
    {
        public string to { get; set; }
        public string subject { get; set; }
        public string body { get; set; }
    }
}
