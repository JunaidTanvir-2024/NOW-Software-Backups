﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBRoamingRates
    {
        public int Id { get; set; }
        public decimal VoiceRate { get; set; }
        public decimal SmsRate { get; set; }
        public decimal DataRate { get; set; }
        public int FromCountryId { get; set; }
        public int ToCountryId { get; set; }
    }
}
