﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Campaigns.Requests
{
    public class UpdateCampaignRequest
    {
    }
}
