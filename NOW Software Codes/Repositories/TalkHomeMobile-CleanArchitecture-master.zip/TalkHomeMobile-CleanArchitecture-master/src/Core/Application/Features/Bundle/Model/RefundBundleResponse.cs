﻿namespace Application.Features.Bundle.Model;
public class RefundBundleResponse
{
    public int OrderId { get; set; }
}
