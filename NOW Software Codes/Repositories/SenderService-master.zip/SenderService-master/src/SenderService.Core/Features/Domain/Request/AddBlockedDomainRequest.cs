﻿namespace SenderService.Core.Features.Domain.Request;
public class AddBlockedDomainRequest
{
    public string Domain { get; set; } = default!;
}
