﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.PayPal.GuestCheckout.CallingCard
{
    public class GuestCheckoutPaypalCallingCardRequestHandler : IRequestHandler<GuestCheckoutPaypalCallingCardRequest, object>
    {
        #region Fields

        private readonly IPaymentService _paymentService;
        private readonly ICurrentUser _currentUser;
        private readonly IUserRepository _userRepository;
        private readonly IUserService _userService;
        private readonly IOtpService _otpService;

        #endregion

        #region Ctor

        public GuestCheckoutPaypalCallingCardRequestHandler(
            IPaymentService paymentService,
            ICurrentUser currentUser,
            IUserRepository userRepository,
            IUserService userService,
            IOtpService otpService)
        {
            _paymentService = paymentService;
            _currentUser = currentUser;
            _userRepository = userRepository;
            _userService = userService;
            _otpService = otpService;
        }

        #endregion

        #region Method

        public async Task<object> Handle(GuestCheckoutPaypalCallingCardRequest request, CancellationToken cancellationToken)
        {
            var user = await _userRepository.GetUserByEmailAsync(request.Email!);
            if (user == null)
            {
                return ErrorResult.Failure(CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
            }

            //get confirmation token
            var emailToken = await _otpService.GetTokenAgainstOtp(
                            request.Email!, request.EmailOtp!, OtpType.SignUp);
            if (string.IsNullOrEmpty(emailToken))
            {
                return ErrorResult.Failure(CustomStatusKey.InvalidOtp, CustomStatusCode.BadRequest);
            }

            return await _paymentService.HandlePaypalPaymentRequest(
                productType: ProductType.CallingCard,
                userInfo: new UserDto()
                {
                    Id = user.Id,
                    Email = user.Email!
                },
                amount: request.Amount,
                cardNumber: null!
           );
        }

        #endregion
    }
}
