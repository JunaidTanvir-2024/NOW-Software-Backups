﻿$(document).ready(function () {
    //Get Auto Topup setting on load
    accountSummary.GetAutoTopup();

    //Setting AutoTopup 
    $('#AutoTopupSetting').click(function () {
        $("#AutotopupSuccessMessage").text("");
        $("#AutotopupErrorMessage").text("");
        var model = {};
        model.isAutoTopup = $("#chkQuickTopUp").is(":checked") == true ? true : false;
        model.topupAmount = $("#topupAmount_value").val();
        model.thresholdBalanceAmount = $("#Threshold").val();
        $.ajax({
            type: "POST",
            url: "/SetAutoTopUp",
            data: model,
            success: function (result) {
                
                if (result.errorCode == 0) {
                    $('#AutotopupSuccessMessage').html(result.message).show();
                }
                else {
                    $('#AutotopupErrorMessage').html(result.message).show();
                }
                
            },
            error: function (xhr, error, status) {
                $('#AutotopupErrorMessage').html(result.message).show();
            }

        });
    });

    THCC_AirShip.AddTag(
        THCC_AirShip.Tags.names.thrcc_view_points_account_summary_web,
        THCC_AirShip.Tags.types.payment, true,
        () => { });
    
});

var accountSummary = {
    GetAutoTopup: function getautotopup() {
        $.ajax({
            type: "POST",
            url: "/getautotopup",
            success: function (json) {
                if (json && json.errorCode == 0) {
                    $(Threshold).val(json.payload.thresHold);
                    $(topupAmount_value).val(json.payload.topup).trigger('change')

                    if (json.payload.status == true) {
                        $(chkQuickTopUp).prop("checked", true);
                    }
                    else {
                        $(chkQuickTopUp).prop("checked", false);
                    }



                }
            },
            error: function (xhr, status, error) {

            }
        });
    }
}

$("#redeempoints").on("click", function (event) {

    var model = {};
    model.points = $("#pointstoredeem").val();
    $.ajax({
        beforeSend: function () {
            loader.btnloadershow(event);
        },
        type: "POST",
        url: "/redeempoints",
        data: model,
        async: true,
        success: function (json) {
            if (json && json.errorCode == 0) {
                window.location.href = "/account/myaccount"
                $('html, body').animate({ 'scrollTop': $("#rechargecarddiv").position().top });
                $("#pointssucessDiv").text("Points Redeemed and your balance is added sucessfully");
            }
            else {
                $("#pointsErrorDiv").text("Failed to redeem points");
            }

        },
        complete: function () {
            loader.btnloaderhide(event);
        },
        error: function (xhr, status, error) {
            $("#pointsErrorDiv").text("Failed to redeem points");

        }
    });
});
