using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class TripPlace : IBaseEntity<long>
{
    public long Id { get; set; }
    public long TripId { get; set; }
    public long PlaceId { get; set; }
    public Trip Trip { get; set; } = null!;
    public Place Place { get; set; } = null!;
}
