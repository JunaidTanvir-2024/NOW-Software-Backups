﻿using Microsoft.OpenApi.Any;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.MessageBroker;
public sealed class MessageBrokerSetting
{
    public const string SectionName = nameof(MessageBrokerSetting);
    public required string Host { get; set; } = default!;
    public required ushort Port { get; set; }
    public required string VirtualHost { get; set; } = default!;
    public required string UserName { get; set; } = default!;
    public required string Password { get; set; } = default!;
    public required string Queue { get; set; } = default!;
    public required bool ShouldIncludeDTOPrefix { get; set; }
    public required string MessagePrefix { get; set; }
}

