﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class DispatchOrderRequestModel
    {
        [Required]
        [Range(1, int.MaxValue)]
        public int OrderId { get; set; }
    }
}
