﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class GetInAppPurchaseOptionsRequestModel
    {
        [Required]
        public string version { get; set; }
    }
}
