using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DC.Core.Features.HangFire;
public record InitiateHangFireJobRequest() : IRequest<IResultWrapper>
{
    public string? RequestType { get; set; } 

}
public class InitiateHangFireJobRequestValidator : AbstractValidator<InitiateHangFireJobRequest>
{
    public InitiateHangFireJobRequestValidator()
    {

    }
}
