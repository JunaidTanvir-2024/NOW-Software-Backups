﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{
   public class ServiceProviderConfig
    {
        public bool THACheckProductItemCode { get; set; }
        public bool TRHCheckProductItemCode { get; set; }
    }
}
