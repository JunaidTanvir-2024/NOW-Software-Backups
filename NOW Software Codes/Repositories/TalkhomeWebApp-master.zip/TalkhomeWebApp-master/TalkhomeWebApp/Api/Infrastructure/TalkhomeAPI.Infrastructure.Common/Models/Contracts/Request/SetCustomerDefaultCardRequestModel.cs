﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class SetCustomerDefaultCardRequestModel
    {
        [Required]
        [MaxLength(4)]
        public string CardCV2 { get; set; }

        [Required]
        [MaxLength(100)]
        public string CardToken { get; set; }
    }
}
