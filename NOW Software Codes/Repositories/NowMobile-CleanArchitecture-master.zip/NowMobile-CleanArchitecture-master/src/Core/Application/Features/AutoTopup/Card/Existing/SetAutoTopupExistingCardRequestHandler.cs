using Application.Common.Interfaces.Payment;
using Application.Common.Settings;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;
using Microsoft.Extensions.Options;

namespace Application.Features.AutoTopup.Card.Existing;

public class SetAutoTopupExistingCardRequestHandler : IRequestHandler<SetAutoTopupExistingCardRequest, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly ICardService _cardService;
    private readonly IStringLocalizer<SetAutoTopupExistingCardRequestHandler> _localizer;
    private readonly TopupSettings _topupSettings;

    public SetAutoTopupExistingCardRequestHandler(
        IPaymentService paymentService,
        ICurrentUser currentUser,
        IMapper mapper,
        IOptions<TopupSettings> topupSettings,
        ICardService cardService,
        IStringLocalizer<SetAutoTopupExistingCardRequestHandler> localizer)
    {
        _paymentService = paymentService;
        _currentUser = currentUser;
        _mapper = mapper;
        _cardService = cardService;
        _localizer = localizer;
        _topupSettings = topupSettings.Value;
    }
    public async Task<Result<CardResponse>> Handle(SetAutoTopupExistingCardRequest request, CancellationToken cancellationToken)
    {
        string existigCardNumber, cardScheme;

        //Check if card is user own card
        var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
        if (cards == null || cards != null &&
            !cards.Any(x => x.CardToken.Equals(
                request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)))
        {
            return Result<CardResponse>.Failure(
                _localizer[CustomStatusKey.InvalidPaymentCard], CustomStatusCode.InvalidPaymentCard);
        }

        existigCardNumber = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).MaskedPan;

        cardScheme = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).CardScheme;


        request.ThresHoldAmount = _topupSettings.ThresholdAmount;
        var paymentTopupInfo = _mapper.Map<PaymentTopupInfo>(request);
        var result = await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: null!,
            paymentExistingCardInfo: request.PaymentCardInfo,
            paymentAddressInfo: null!,
            topupInfo: paymentTopupInfo,
            bundleInfo: null!,
            creditSimInfo: null!,
            msisdn: request.Msisdn,
            email: _currentUser.GetUserEmail()!,
            ipAddress: request.IpAddress,
            cardMaskedPan: existigCardNumber!,
            cardScheme: cardScheme!,
            isAuthorizeOnly: true
            );
        return result;
    }
}