﻿namespace THCC.Application.Models.Dtos
{
    public class PaymentDefaultCardDto
    {
        public string CardCv2 { get; set; } = default!;
    }
}
