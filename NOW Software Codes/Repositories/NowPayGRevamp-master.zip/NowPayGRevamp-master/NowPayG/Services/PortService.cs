﻿using Newtonsoft.Json;
using NowPayG.Services.Interfaces;
using System;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using NowPayG.Models.Porting;
using Microsoft.Extensions.Options;
using NowPayG.Configurations;

namespace NowPayG.Services
{
    public class PortService : IPortService
    {
        private HttpClient client;
        private string PortingApiEndpoint { get; set; }

        public PortService(IOptions<EndPoints> endpoints)
        {
            PortingApiEndpoint = endpoints.Value.PortingApiEndpoint;
        }

        public async Task<GenericPortingApiResponse<GetPortingRequestsResponseModel>> GetPortRequests(GetPortingDetailsRequestModel request)
        {
            try
            {
                GenericPortingApiResponse<GetPortingRequestsResponseModel> response = new GenericPortingApiResponse<GetPortingRequestsResponseModel>();
                string endpoint = PortingApiEndpoint + "api/Porting/GetPortingRequests";
                var Result = await Get(endpoint, null, $"Email={request.Email}", $"Msisdn={request.Msisdn}", $"product={Products.NowPayg}");
                if (Result == null)
                {
                    return null;
                }

                return response = JsonConvert.DeserializeObject<GenericPortingApiResponse<GetPortingRequestsResponseModel>>(Result.Content.ReadAsStringAsync().Result);
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericPortingApiResponse<bool>> PortOut(PortOutRequestModel request)
        {
            string endpoint = PortingApiEndpoint;
            if (request.CodeType == CodeTypes.STAC)
            {
                endpoint += "api/Porting/PortOutSTAC";
            }
            else
            {
                endpoint += "api/Porting/PortOutPAC";
            }
            string json = JsonConvert.SerializeObject(request);
            var Result = await Get(endpoint, null, $"Email={request.Email}", $"NTMsisdn={request.NTMsisdn}", $"Product={Products.NowPayg}", $"Medium={MediumTypes.Web}", $"UserPortingDate={request.UserPortingDate}", $"ReasonId={request.ReasonId}");

            return JsonConvert.DeserializeObject<GenericPortingApiResponse<bool>>(Result.Content.ReadAsStringAsync().Result);
        }

        public async Task<GenericPortingApiResponse<bool>> PortIn(PortInRequestModel request, PortTypes type)
        {
            string endpoint = PortingApiEndpoint;
            HttpResponseMessage response = null;

            if (type == PortTypes.PortIn)
            {
                endpoint += "api/Porting/PortIn";
                string json = JsonConvert.SerializeObject(request);
                response = await Get(endpoint, null, $"Email={request.Email}", $"PortMsisdn={request.PortMsisdn}", $"NTMsisdn={request.NTMsisdn}", $"UserPortingDate={request.UserPortingDate}", $"Code={request.Code}", $"Product={Products.NowPayg}", $"Medium={MediumTypes.Web}");
            }
            else if (type == PortTypes.PortInNew)
            {
                endpoint += "api/Porting/PortInNewOrder";
                string json = JsonConvert.SerializeObject(request);
                response = await Get(endpoint, null, $"Email={request.Email}", $"PortMsisdn={request.PortMsisdn}", $"Code={request.Code}", $"OrderReferenceId={request.OrderRefId}", $"Product={Products.TalkHome}", $"Medium={MediumTypes.Web}");
            }

            if (response == null)
            {
                return null;
            }

            return JsonConvert.DeserializeObject<GenericPortingApiResponse<bool>>(response.Content.ReadAsStringAsync().Result);
        }

        public async Task<GenericPortingApiResponse<bool>> CancelPortingRequest(CancelPortingRequestModel request)
        {
            string endpoint = PortingApiEndpoint;
            HttpResponseMessage response = null;

            endpoint += "api/Porting/CancelPortingRequest";
            string json = JsonConvert.SerializeObject(request);
            response = await Get(endpoint, null, $"RequestID={request.RequestID}");
            if (response == null)
            {
                return null;
            }

            return JsonConvert.DeserializeObject<GenericPortingApiResponse<bool>>(response.Content.ReadAsStringAsync().Result);
        }

        public async Task<GenericPortingApiResponse<SwitchingInformationApiResponseModel>> GetSwitchingInfo(GetSwitchingInformationRequestModel request)
        {
            string endpoint = PortingApiEndpoint;
            HttpResponseMessage response = null;

            endpoint += "api/Porting/GetSwitchingInformation";
            string json = JsonConvert.SerializeObject(request);
            response = await Get(endpoint, null, $"msisdn={request.msisdn}");
            if (response == null)
            {
                return null;
            }

            return JsonConvert.DeserializeObject<GenericPortingApiResponse<SwitchingInformationApiResponseModel>>(response.Content.ReadAsStringAsync().Result);
        }

        private async Task<HttpResponseMessage> Get(string Uri, string authToken = null, params string[] parameters)
        {
            HttpResponseMessage response;

            try
            {
                string paramString = parameters.Count() > 0 ? "?" : String.Empty;

                using (client = new HttpClient())
                {
                    foreach (var param in parameters)
                    {
                        paramString += param + "&";
                    }
                    paramString = paramString.TrimEnd('&');

                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                    if (authToken != null)
                    {
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
                    }


                    response = await client.GetAsync(Uri + paramString);

                    return response;
                }
            }
            catch
            {
                throw;
            }
        }

        private async Task<HttpResponseMessage> Post(string Uri, object model, string AuthToken = null)
        {
            try
            {
                using (client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                    if (AuthToken != null)
                    {
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", AuthToken);
                    }

                    string json = JsonConvert.SerializeObject(model);
                    var stringContent = new StringContent(json, Encoding.UTF8, "application/json");
                    return await client.PostAsync(Uri, stringContent);
                }
            }
            catch
            {
                throw;
            }
        }

    }
}
