﻿//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using SenderService.Core.Persistence.Entities;

//namespace SenderService.Core.Persistence.Configurations;
//internal class ProductCodeConfiguration : IEntityTypeConfiguration<ProductCode>
//{
//    public void Configure(EntityTypeBuilder<ProductCode> entity)
//    {
//        entity.HasKey(e => e.Id).HasName("PK_ProductCode");

//        entity.Property(e => e.Code).HasMaxLength(15);
//        entity.Property(e => e.ItemCode).HasMaxLength(30);
//    }
//}
