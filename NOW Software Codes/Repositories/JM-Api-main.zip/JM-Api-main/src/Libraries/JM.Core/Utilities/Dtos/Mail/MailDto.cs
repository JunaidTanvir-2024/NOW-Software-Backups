namespace JM.Core.Utilities.Dtos.Mail;
public sealed class MailDto
{
    public sealed record Request
    {
        public required List<string> To { get; set; }
        public required string Subject { get; set; }
        public string? Body { get; set; }
        public string? From { get; set; }
        public string? DisplayName { get; set; }
        public string? ReplyTo { get; set; }
        public string? ReplyToName { get; set; }
        public List<string>? Bcc { get; set; }
        public List<string>? Cc { get; set; }
        public IDictionary<string, byte[]>? AttachmentData { get; set; }
        public IDictionary<string, string>? Headers { get; set; }
    }
}
