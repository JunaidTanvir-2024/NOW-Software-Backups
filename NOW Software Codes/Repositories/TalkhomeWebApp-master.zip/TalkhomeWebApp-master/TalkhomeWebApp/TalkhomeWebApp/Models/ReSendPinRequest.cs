﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models
{
    public class ReSendPinRequest
    {
        [Required(ErrorMessage = "Enter your phone-number")]
        [MaxLength(length: 50, ErrorMessage = "Maximum length exceeded")]
        public string PhoneNumber { get; set; }
        [Required]
        [MaxLength(length: 5, ErrorMessage = "Maximum length exceeded")]
        public string PhoneNumberCountryCode { get; set; }

        //[Required(ErrorMessage = "Valid reCaptcha response is required")]
        public string Token { get; set; }
        public string IpAddress { get; set; }
    }
}
