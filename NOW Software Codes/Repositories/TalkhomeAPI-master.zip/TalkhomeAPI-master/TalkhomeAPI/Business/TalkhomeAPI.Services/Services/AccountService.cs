﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PhoneNumbers;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.ExtensionMethods;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.DTOs;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Implementations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome;
using TalkhomeAPI.Services.Interfaces;

namespace TalkhomeAPI.Services.Services
{
    public class AccountService : IAccountService
    {
        private readonly IAccountRepository _accountRepository;
        private readonly ISmsService _smsService;
        private readonly ITalkHomeService _talkHomeService;
        private readonly IEmailService _emailService;
        private readonly ILogger _logger;
        private readonly IAirShipService _airShipService;
        private readonly SMSConfig _smsConfig;

        public AccountService(IAccountRepository accountRepository,
            ISmsService smsService,
            ITalkHomeService talkHomeService,
            IEmailService emailService,
            ILogger logger,
            IOptions<SMSConfig> smsConfig,
            IAirShipService airShipService)
        {
            _accountRepository = accountRepository;
            _smsService = smsService;
            _talkHomeService = talkHomeService;
            _emailService = emailService;
            _logger = logger;
            _airShipService = airShipService;
            _smsConfig = smsConfig.Value;
        }

        public Task<DBAccountInfo> GetAccountDetails(string Username, string pin)
        {
            return _accountRepository.GetAccountDetails(Username, pin);
        }
        public Task<bool> IsUserExist(string UserName)
        {
            return _accountRepository.IsUserExist(UserName);
        }
        public async Task<GenericApiResponse<string>> ValidateMsisdn(string msisdn)
        {
            var result = await _accountRepository.ValidateMsisdn(msisdn);
            if (result != null)
            {
                if (result.error_code == 0)
                {
                    return GenericApiResponse<string>.Success(result.error_msg, result.error_msg);
                }
                else
                {
                    return GenericApiResponse<string>.Failure("Your provided number is Invalid", ApiStatusCodes.InvalidNumber);
                }
            }
            return GenericApiResponse<string>.Failure("Something went wrong on server.", ApiStatusCodes.InternalServerError);
        }
        public async Task<string> ValidateUser(string msisdn)
        {
            return await _accountRepository.ValidateUser(msisdn);
        }
        public async Task<GenericApiResponse<SignUpResponseModel>> SignUp(SignUpRequestModel model)
        {
            //Check number validity
            var phoneNumberUtil = PhoneNumberUtil.GetInstance();
            PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

            bool IsValidNumber;
            try
            {
                IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

                if (IsValidNumber)
                {
                    model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
                        .Replace("+", "").Trim();
                }
            }
            catch
            {
                IsValidNumber = false;
            }

            if (!IsValidNumber)
            {
                return GenericApiResponse<SignUpResponseModel>.Failure(null,
                                        "Number is invalid", ApiStatusCodes.InvalidNumber);
            }

            //Check if user already registered
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
            if (accountResponse != null)
            {

                return GenericApiResponse<SignUpResponseModel>.Failure(null,
                                        "User is already registered", ApiStatusCodes.UserAlreadyRegistered);
            }

            //Sign-Up User
            var signUpResponse = await _talkHomeService.SignUp(new SignUpRequest()
            {
                msisdn = model.PhoneNumber,
                appInfo = new AppInfo() { DevicePersistentID = model.IpAddress + "-" + model.PhoneNumber }
            });

            if (signUpResponse == null)
            {
                return GenericApiResponse<SignUpResponseModel>.Failure(null,
                                        "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }
            else if (signUpResponse.payload == null)
            {
                _logger.Error($"Class: AccountService, Method: SignUp, Parameters=> model: " +
                                                $"{JsonConvert.SerializeObject(model)}, ErrorMessage: Unable to register");

                return GenericApiResponse<SignUpResponseModel>.Failure(null,
                                        "Unable to register user", ApiStatusCodes.SignUpFailed);
            }

            //Update user
            await _accountRepository.UpdateUser(new DBUser()
            {
                firstname = model.FirstName,
                lastname = model.LastName,
                email = model.Email,
                email_subscribed = model.MailSubscription,
                msisdn = model.PhoneNumber
            });

            //Generate token & Save to DB
            var token = Guid.NewGuid();
            await _accountRepository.InsertEmailVerificationToken(model.PhoneNumber, token.ToString());

            //Send email to user
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
            _emailService.SendUserRegistrationEmail(model.Email,
                                model.FirstName + " " + model.LastName, token.ToString());
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed


            return GenericApiResponse<SignUpResponseModel>.Success(null, "Pin sent successfully");
        }
        public async Task<GenericApiResponse<LoginResponseModel>> Login(LoginRequestModel model)
        {
            //Check number validity
            var phoneNumberUtil = PhoneNumberUtil.GetInstance();
            PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

            bool IsValidNumber;
            try
            {
                IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

                if (IsValidNumber)
                {
                    model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
                        .Replace("+", "").Trim();
                }
            }
            catch
            {
                IsValidNumber = false;
            }

            if (!IsValidNumber)
            {
                return GenericApiResponse<LoginResponseModel>.Failure(null,
                                                    "Number is invalid", ApiStatusCodes.InvalidNumber);
            }


            //Get User Info
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
            if (accountResponse == null)
            {
                return GenericApiResponse<LoginResponseModel>.Failure(null,
                                                "User not registered", ApiStatusCodes.UserNotRegistered);
            }

            //Check User is active or not
            var validationResponse = await _accountRepository.ValidateUser(model.PhoneNumber);
            if (validationResponse != null)
            {
                return GenericApiResponse<LoginResponseModel>.Failure(null,
                                                "User not authorized", ApiStatusCodes.UserNotAuthorized);
            }

            //Get User Pin
            var pinResponse = await _accountRepository.GetPinByPhoneNumber("THA" + model.PhoneNumber);
            if (string.IsNullOrEmpty(pinResponse))
            {
                return GenericApiResponse<LoginResponseModel>.Failure(null,
                                                "User not authorized", ApiStatusCodes.UserNotAuthorized);
            }

            try
            {
                var IsValidSmsRequest = await _accountRepository.ValidateSmsRequest(model.PhoneNumber,
                                                                                    model.IpAddress,
                                                                                    _smsConfig.LoginSMSLimit,
                                                                                    SmsTypeId.Login);
                if (IsValidSmsRequest)
                {
                    await _smsService.SendSms(Number.CountryCode, model.PhoneNumber,
                                                $"Welcome to TALK HOME App! Your PIN is {pinResponse.Trim()}. To manage your account online, or to top up credit, visit https://www.talkhomeapp.com");
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountService, Method: IsValidSmsRequest-Login, Parameters=> model: " +
                                                     $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}");
            }

            return GenericApiResponse<LoginResponseModel>.Success(null, "Pin sent successfully");
        }
        public async Task<GenericApiResponse<VerifyPinResponseModel>> VerifyPin(VerifyPinRequestModel model)
        {
            //Check number validity
            var phoneNumberUtil = PhoneNumberUtil.GetInstance();
            PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

            bool IsValidNumber;
            try
            {
                IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

                if (IsValidNumber)
                {
                    model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
                        .Replace("+", "").Trim();
                }
            }
            catch
            {
                IsValidNumber = false;
            }

            if (!IsValidNumber)
            {
                return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
                                        "Number is invalid", ApiStatusCodes.InvalidNumber);
            }

            //Get User Info
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
            if (accountResponse == null)
            {
                return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
                                                "User not registered", ApiStatusCodes.UserNotRegistered);
            }

            //Check User is active or not
            var validationResponse = await _accountRepository.ValidateUser(model.PhoneNumber);
            if (validationResponse != null)
            {
                return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
                                               "User not authorized", ApiStatusCodes.UserNotAuthorized);
            }

            //Get user pin
            var pinResponse = await _accountRepository.GetPinByPhoneNumber("THA" + model.PhoneNumber);
            if (string.IsNullOrEmpty(pinResponse))
            {
                return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
                                                "User not authorized", ApiStatusCodes.UserNotAuthorized);
            }

            //Verify pin
            if (!model.PinNumber.Equals(pinResponse.Trim()))
            {
                return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
                                                "Pin is invalid", ApiStatusCodes.InvalidPinNumber);
            }

            var userResponse = await _accountRepository.GetUserByPhoneNumber(model.PhoneNumber);

            if (userResponse == null)
            {
                return GenericApiResponse<VerifyPinResponseModel>.Failure(new VerifyPinResponseModel()
                {
                    User = new UserInfo()
                    {
                        Msisdn = model.PhoneNumber,
                        Currency = accountResponse.Currency,
                        AccountID = accountResponse.AccountID,
                        Na_Service_Id = accountResponse.Na_Service_Id,
                        ISO_Two_CountryCode = model.PhoneNumberCountryCode
                    }
                }, "User details are missing", ApiStatusCodes.MissingPersonDetails);
            }

            if (string.IsNullOrEmpty(userResponse.firstname)
                || string.IsNullOrEmpty(userResponse.lastname)
                || string.IsNullOrEmpty(userResponse.email))
            {

                return GenericApiResponse<VerifyPinResponseModel>.Failure(new VerifyPinResponseModel()
                {
                    User = new UserInfo()
                    {
                        Msisdn = model.PhoneNumber,
                        Currency = accountResponse.Currency,
                        AccountID = accountResponse.AccountID,
                        Email = userResponse.email,
                        IsEmailVerified = userResponse.email_verified,
                        Na_Service_Id = accountResponse.Na_Service_Id,
                        ISO_Two_CountryCode = model.PhoneNumberCountryCode,
                        IsMailSubscription = userResponse.email_subscribed
                    }
                }, "User details are missing", ApiStatusCodes.MissingPersonDetails);

            }

            return GenericApiResponse<VerifyPinResponseModel>.Success(new VerifyPinResponseModel()
            {
                User = new UserInfo()
                {
                    Msisdn = userResponse.msisdn,
                    Currency = accountResponse.Currency,
                    AccountID = accountResponse.AccountID,
                    Email = userResponse.email,
                    IsEmailVerified = userResponse.email_verified,
                    Na_Service_Id = accountResponse.Na_Service_Id,
                    ISO_Two_CountryCode = model.PhoneNumberCountryCode,
                    IsMailSubscription = userResponse.email_subscribed
                }
            }, "logged-in successfully");
        }
        public async Task<GenericApiResponse<ReSendPinResponseModel>> ReSendPin(ReSendPinRequestModel model)
        {
            //Check number validity
            var phoneNumberUtil = PhoneNumberUtil.GetInstance();
            PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

            bool IsValidNumber;
            try
            {
                IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

                if (IsValidNumber)
                {
                    model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
                        .Replace("+", "").Trim();
                }
            }
            catch
            {
                IsValidNumber = false;
            }

            if (!IsValidNumber)
            {
                return GenericApiResponse<ReSendPinResponseModel>.Failure(null,
                    "Number is invalid", ApiStatusCodes.InvalidNumber);
            }

            //Get user details
            var userResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
            if (userResponse == null)
            {
                return GenericApiResponse<ReSendPinResponseModel>.Failure(null,
                            "User is not registerd", ApiStatusCodes.UserNotRegistered);
            }

            //Send pin
            var pinResponse = await _accountRepository.GetPinByPhoneNumber("THA" + model.PhoneNumber);
            if (string.IsNullOrEmpty(pinResponse))
            {
                return GenericApiResponse<ReSendPinResponseModel>.Failure(null,
                                                    "User not authorized", ApiStatusCodes.UserNotAuthorized);
            }

            try
            {
                var IsValidSmsRequest = await _accountRepository.ValidateSmsRequest(model.PhoneNumber,
                                                                                    model.IpAddress,
                                                                                    _smsConfig.ResendSmsLimit,
                                                                                    SmsTypeId.Resend);
                if (IsValidSmsRequest)
                {
                    await _smsService.SendSms(Number.CountryCode, model.PhoneNumber,
                               $"Welcome to TALK HOME App! Your PIN is {pinResponse.Trim()}. To manage your account online, or to top up credit, visit https://www.talkhomeapp.com"); ;
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountService, Method: ReSendPin, Parameters=> model: " +
                                            $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}");
            }

            return GenericApiResponse<ReSendPinResponseModel>.Success(null, "Pin sent successfully");


        }
        public async Task<GenericApiResponse<VerifyEmailResponseModel>> VerifyEmail(VerifyEmailRequestModel model)
        {
            var verificationResponse = await _accountRepository.VerifyEmail(model.Token);
            if (verificationResponse == 0)
            {
                #region Airship
                try
                {
                    if (_airShipService.IsActive)
                    {
                        var userResponse = await _accountRepository.GetUserInfoByEmailToken(model.Token);

#pragma warning disable CS4014

                        if (userResponse.email_subscribed)
                        {
                            _airShipService.AddEmailChannelCommercial(userResponse.email);
                        }
                        else
                        {
                            _airShipService.AddEmailChannel(userResponse.email);
                        }

                        //Associate email with named user
                        _airShipService.EmailAssociationWithNamedUser(userResponse.msisdn, userResponse.email);
                    }
#pragma warning restore CS4014
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: AccountService, Method: VerifyEmail-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }
                #endregion


                return GenericApiResponse<VerifyEmailResponseModel>.Success(null,
                    "Email verified successfully");
            }
            else
            {
                return GenericApiResponse<VerifyEmailResponseModel>.Failure(null,
                    "Token is invalid", ApiStatusCodes.InvalidToken);
            }
        }
        public async Task<GenericApiResponse<ReSendEmailVerificationResponse>> ReSendEmailVerificationLink(string msisdn)
        {
            //Check if user already registered
            var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);
            if (userResponse == null)
            {

                return GenericApiResponse<ReSendEmailVerificationResponse>.Failure(null,
                                        "User is not registered", ApiStatusCodes.UserNotRegistered);
            }

            if (userResponse.email_verified)
            {
                return GenericApiResponse<ReSendEmailVerificationResponse>.Failure(null,
                                        "Email is already verified", ApiStatusCodes.EmailAlreadyVerified);
            }


            string token;

            //Get token if exists 
            var tokenInfo = await _accountRepository.GetEmailVerificationToken(msisdn);
            if (!string.IsNullOrEmpty(tokenInfo))
            {
                token = tokenInfo;
            }
            else
            {
                //Generate token & Save to DB
                var newToken = Guid.NewGuid();
                token = newToken.ToString();

                await _accountRepository.InsertEmailVerificationToken(msisdn, token);
            }

            //Send email to user
            if (!string.IsNullOrEmpty(userResponse.firstname))
            {
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                _emailService.SendUserRegistrationEmail(userResponse.email,
                            userResponse.firstname + " " + userResponse.lastname, token);
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
            }
            else
            {
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                _emailService.SendUserRegistrationEmail(userResponse.email, msisdn, token);
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
            }

            return GenericApiResponse<ReSendEmailVerificationResponse>.Success(null, "Token generated successfully");
        }
        public async Task<GenericApiResponse<GetAccountDetailsResponseModel>> GetAccountDetails(string msisdn)
        {
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);
            var pinResponse = await _accountRepository.GetPinByPhoneNumber("THA" + msisdn);


            var response = new GetAccountDetailsResponseModel()
            {
                Balance = accountResponse.Balance,
                Pin = CommonExtentionMethods.EncryptString("b14ca5898a4e4133bbce2ea2315a1916", pinResponse.Trim())
            };

            if (userResponse != null)
            {
                response.FirstName = userResponse.firstname;
                response.LastName = userResponse.lastname;
                response.Email = userResponse.email;
                response.IsEmailVerified = userResponse.email_verified;
                response.EmailSubscription = userResponse.email_subscribed;
                response.DayOfBirth = userResponse.dayOfBirth;
                response.MonthOfBirth = userResponse.monthOfBirth;
            }

            return GenericApiResponse<GetAccountDetailsResponseModel>.Success(response, "User details found successfully");
        }
        public async Task<GenericApiResponse<UpdateMissingDetailsResponseModel>> UpdateMissingDetails(
                                                                    UpdateMissingDetailsRequestModel model, string msisdn)
        {
            //Update data
            await _accountRepository.UpdateUser(new DBUser()
            {
                firstname = model.FirstName,
                lastname = model.LastName,
                email = model.Email,
                email_subscribed = model.EmailSubscription,
                msisdn = msisdn
            });

            var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);

            if (!userResponse.email_verified)
            {
                string token;

                //Get token if exists 
                var tokenInfo = await _accountRepository.GetEmailVerificationToken(msisdn);
                if (!string.IsNullOrEmpty(tokenInfo))
                {
                    token = tokenInfo;
                }
                else
                {
                    //Generate token & Save to DB
                    var newToken = Guid.NewGuid();
                    token = newToken.ToString();

                    await _accountRepository.InsertEmailVerificationToken(userResponse.msisdn, token);
                }

                //Send email to user
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                _emailService.SendUserRegistrationEmail(model.Email,
                                    model.FirstName + " " + model.LastName, token.ToString());
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
            }

            return GenericApiResponse<UpdateMissingDetailsResponseModel>.Success(null,
                                                            "User details updated successfully");
        }
        public async Task<GenericApiResponse<UpdateAccountDetailsResponseModel>> UpdateAccountDetails(
                                                                    UpdateAccountDetailsRequestModel model, string msisdn)
        {
            var userOldDataResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);

            var response = await _accountRepository.UpdateAccountDetails(new DBUser()
            {
                msisdn = msisdn,
                dayOfBirth = model.DayOfBirth,
                monthOfBirth = model.MonthOfBirth,
                firstname = model.FirstName,
                lastname = model.LastName,
                email = model.Email,
                email_subscribed = model.EmailSubscription
            });

            if (response > 0)
            {
                var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);

                if (!userResponse.email_verified)
                {
                    string token;

                    //Get token if exists 
                    var tokenInfo = await _accountRepository.GetEmailVerificationToken(msisdn);
                    if (!string.IsNullOrEmpty(tokenInfo))
                    {
                        token = tokenInfo;
                    }
                    else
                    {
                        //Generate token & Save to DB
                        var newToken = Guid.NewGuid();
                        token = newToken.ToString();

                        await _accountRepository.InsertEmailVerificationToken(userResponse.msisdn, token);
                    }

                    //Send email to user
#pragma warning disable CS4014
                    _emailService.SendUserRegistrationEmail(userResponse.email,
                                                        userResponse.firstname + " " + userResponse.lastname, token.ToString());
#pragma warning restore CS4014
                }

                #region Airship
                try
                {
                    if (_airShipService.IsActive)
                    {
#pragma warning disable CS4014

                        //remove previous email channel from current user (beacuse user email is changed)
                        if (!userOldDataResponse.email.Equals(userResponse.email))
                        {
                            _airShipService.RemoveEmailChannelCommercial(userResponse.email);
                            _airShipService.DisassociateEmailChannelFromNamedUser(userOldDataResponse.msisdn, userOldDataResponse.email);
                        }

                        // Register + Removal of commercial emails
                        if (userResponse.email_verified && userResponse.email_subscribed)
                        {
                            _airShipService.AddEmailChannelCommercial(userResponse.email);
                        }
                        else if (userResponse.email_verified && !userResponse.email_subscribed)
                        {
                            _airShipService.RemoveEmailChannelCommercial(userResponse.email);
                        }
                    }
#pragma warning restore CS4014
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: AccountService, Method: UpdateAccountDetails-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }
                #endregion

                return GenericApiResponse<UpdateAccountDetailsResponseModel>.Success(new UpdateAccountDetailsResponseModel()
                {
                    IsEmailVerified = userResponse.email_verified
                }, "User details updated successfully");
            }
            else
            {
                return GenericApiResponse<UpdateAccountDetailsResponseModel>.Failure(
                    null, ApiStatusCodes.RecordNotFound);
            }
        }
        public async Task<GenericApiResponse<CallHistoryResponseModel>> GetCallingHistory(string accountNumber)
        {
            var result = await _accountRepository.GetCallingHistory(accountNumber);

            return GenericApiResponse<CallHistoryResponseModel>.Success(
                new CallHistoryResponseModel()
                {
                    CallHistory = result
                }, result.Count() > 0 ? "Found calling history" : "calling history not found");

        }
        public async Task<GenericApiResponse<GetTopUpPaymentHistoryResponseModel>> GetTopUpPaymentHistory(string accountNumber)
        {
            var result = await _accountRepository.GetTopUpPaymentHistory(accountNumber);

            return GenericApiResponse<GetTopUpPaymentHistoryResponseModel>.Success(
                          new GetTopUpPaymentHistoryResponseModel()
                          {
                              TopUpHistory = result
                          }, result.Count() > 0 ? "Found topup history" : "TopUp history not found");

        }
        public async Task<GenericApiResponse<GetInternationalTopUpHistoryResponseModel>> GetInternationalTopUpHistory(string accountNumber)
        {
            var result = await _accountRepository.GetInternationalTopUpHistory(accountNumber);
            return GenericApiResponse<GetInternationalTopUpHistoryResponseModel>.Success(
                          new GetInternationalTopUpHistoryResponseModel()
                          {
                              TopUpHistory = result
                          }, result.Count() > 0 ? "Found topup history" : "TopUp history not found");

        }
        public async Task<GenericApiResponse<bool>> IsEmailAlreadyExists(IsEmailAlreadyExistsRequestModel model)
        {
            return GenericApiResponse<bool>.Success(await _accountRepository.IsEmailAlreadyExists(model.Email), "Sucess");
        }
        public async Task<GenericApiResponse<GetBundlesHistoryResponseModel>> GetBundlesHistory(string accountNumber)
        {
            var result = await _accountRepository.GetBundlesHistory(accountNumber);

            return GenericApiResponse<GetBundlesHistoryResponseModel>.Success(
                          new GetBundlesHistoryResponseModel()
                          {
                              BundlesHistory = result
                          }, result.Count() > 0 ? "Found Bundles history" : "Bundles history not found");
        }
        public async Task<GenericApiResponse<bool>> IsMsisdnRegistered(IsMsisdnRegisteredRequestModel request)
        {

            var msisdn = request.Msisdn.StartsWith("+") ? request.Msisdn.Replace("+", "").Trim() : request.Msisdn;
            msisdn = request.Msisdn.StartsWith("00") ? request.Msisdn.Replace("00", "").Trim() : request.Msisdn;

            bool IsValidNumber;
            try
            {   //Check number validity
                var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                PhoneNumber Number = phoneNumberUtil.Parse("+" + msisdn, "");

                IsValidNumber = phoneNumberUtil.IsValidNumber(Number);
            }
            catch
            {
                IsValidNumber = false;
            }

            if (!IsValidNumber)
            {
                return GenericApiResponse<bool>.Failure(false, "Number is invalid", ApiStatusCodes.InvalidNumber);
            }

            //Check if user already registered
            var validationResponse = await _accountRepository.ValidateMsisdn(msisdn);
            if (validationResponse == null)
                return GenericApiResponse<bool>.Failure(false, "Number is invalid", ApiStatusCodes.InvalidNumber);

            if (validationResponse.error_code != 0)
                return GenericApiResponse<bool>.Failure(false, "Number is invalid", ApiStatusCodes.InvalidNumber);

            return GenericApiResponse<bool>.Success(true, "Number is valid");
        }
        public async Task<GenericApiResponse<GetAccountDetailsByMsisdnResponseModel>> GetAccountDetailsByMsisdn(GetAccountDetailsByMsisdnRequestModel request)
        {
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + request.Msisdn);

            if (accountResponse == null)
            {
                return GenericApiResponse<GetAccountDetailsByMsisdnResponseModel>.Failure(null, "Number is invalid", ApiStatusCodes.InvalidNumber);
            }


            var userResponse = await _accountRepository.GetUserByPhoneNumber(request.Msisdn);


            var response = new GetAccountDetailsByMsisdnResponseModel()
            {
                Currency = accountResponse.Currency,
                EmailAddress = userResponse != null && !string.IsNullOrEmpty(userResponse.email) ? userResponse.email.Trim() : null
            };

            return GenericApiResponse<GetAccountDetailsByMsisdnResponseModel>.Success(response, "User details found successfully");
        }
    }
}
