﻿using Application.Features.Payment.Card.CustomerCards;

namespace Application.Features.Payment.Card.RemoveCard;

public class RemoveCardRequest : IRequest<Result<List<CustomerCard>>>
{
    public string CardToken { get; set; } = default!;
}
