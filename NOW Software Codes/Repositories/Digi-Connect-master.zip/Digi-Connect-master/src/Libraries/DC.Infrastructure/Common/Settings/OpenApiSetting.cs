namespace DC.Infrastructure.Common.Settings;

/// <summary>
/// Represents the OpenAPI Configurations used to configure the Swagger generator and UI.
/// </summary>
public sealed class OpenApiSetting
{
    public const string SectionName = nameof(OpenApiSetting);
    public static OpenApiSetting Instance { get; } = new OpenApiSetting();
    public string? Version { get; set; }
    public string? Title { get; set; }
    public string? Description { get; set; }
    public string TermsOfService { get; set; } = default!;
    public string? ContactName { get; set; }
    public string ContactUrl { get; set; } = default!;
    public string? LicenseName { get; set; }
    public string LicenseUrl { get; set; } = default!;
    public string? JwtSecurityDefinitionName { get; set; }
    public string? JwtSecurityDefinitionDescription { get; set; }
    public string? JwtSecurityDefinitionBearerFormat { get; set; }
}
