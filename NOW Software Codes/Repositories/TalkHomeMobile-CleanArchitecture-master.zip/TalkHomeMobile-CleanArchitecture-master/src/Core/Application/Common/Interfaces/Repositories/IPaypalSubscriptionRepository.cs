﻿using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces.Repositories;

public interface IPaypalSubscriptionRepository : IServicesType.IScopedService
{
    Task UpdateMsisdnInPaypalSubscription(string newNumber, string oldNumber);
    Task<List<PaypalPendingSubscriptionFulfillment>> GetPaypalPendingSubscriptionFulfillments();
    Task<bool> UpdateSubscriptionProductRef(string subscriptionId,string productRef);
    Task<Subscription> GetSubscriptionBySaleId(string merchantRef, string saleId);
    Task<List<Subscription>> GetPaypalNotSyncedCancelledSubscriptions();
    Task<bool> UpdatePaypalSubscriptionStatusSynched(string subscriptionId);
    Task<bool> UpdateSubscriptionSaleStatus(string saleId, string InvoiceNumber = null, string fulfillmentStatus = null, int? fulfillmentErrorCode = null, string fulfillmentErrorMsg = null, string State = null);
}
