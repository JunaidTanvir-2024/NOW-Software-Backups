﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request.Paypal
{
    public class PaypalRequest
    {
        public PaypalRequest()
        {
            Transaction = new Transactions();
            Basket = new List<ProductBasket>();
        }
        public string CustomerName { get; set; }
       
        public string CustomerUniqueRef { get; set; }

        public string CustomerMsisdn { get; set; }

        public string CustomerEmail { get; set; }

        public string ProductCode { get; set; }
        public string ipAddress { get; set; }
        public float Amount { get; set; }
        public string PageRedirect { get; set; }
        public string Pin { get; set; }
        public string CardNumber { get; set; }
        public List<ProductBasket> Basket { get; set; }
        public Transactions Transaction { get; set; }
    }
}
