﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.Profile.AddUserPassword
{
    public class AddUserPasswordRequestHandler : IRequestHandler<AddUserPasswordRequest, object>
    {
        private readonly IUserRepository _userRepository;
        private readonly ICurrentUser _currentUser;
        private readonly IUserService _userService;

        public AddUserPasswordRequestHandler(IUserRepository userRepository, ICurrentUser currentUser, IUserService userService)
        {
            _userRepository = userRepository;
            _currentUser = currentUser;
            _userService = userService;
        }
        public async Task<object> Handle(AddUserPasswordRequest request, CancellationToken cancellationToken)
        {
            request.Password = request.Password.Trim();
            var user = await _userRepository.GetUserByIdAsync(_currentUser.GetUserId());
            if (user == null)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
            }

            if (!string.IsNullOrEmpty(user.PasswordHash))
            {
                return ErrorResult.Failure(
                    CustomStatusKey.NotFound, CustomStatusCode.BadRequest);
            }

            if ((await _userService.AddPasswordAsync(user, request.Password))?.Succeeded==false)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
            }
            return Unit.Value;

        }
    }
}
