﻿using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class Pay360PaypalPaymentPostModel
    {

        public string EmailAddress { get; set; }
        public float Amount { get; set; }
        public string Msisdn { get; set; }
        public string UUID { get; set; }
        public CheckOutTypes CheckoutPaymentType { get; set; }
        public string BundleName { get; set; }
        public string customerName { get; set; }
        public string returnUrl { get; set; }
        public string cancelUrl { get; set; }

    }
}
