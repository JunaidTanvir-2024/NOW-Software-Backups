﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class ExternalLoginRequestModel
    {
        //[Required(AllowEmptyStrings = false)]
        public string accessToken { get; set; }
        //[Required(AllowEmptyStrings = false)]
        //[Range(1,int.MaxValue, ErrorMessage = "Please enter a value bigger than {1}")]
        public int? socialLoginType { get; set; }
    }
}
