﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.DAOs
{
    public class DBTwoFactorAuthenticationToken
    {
        public int Id { get; set; }
        public string Token { get; set; }
        public TwoFactorTokenTypes TokenTypeId { get; set; }
        public int UserId { get; set; }
        public string NowtelTransactionReference { get; set; }
        public bool IsUsed { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int ExpiryMinutes { get; set; }
    }
}
