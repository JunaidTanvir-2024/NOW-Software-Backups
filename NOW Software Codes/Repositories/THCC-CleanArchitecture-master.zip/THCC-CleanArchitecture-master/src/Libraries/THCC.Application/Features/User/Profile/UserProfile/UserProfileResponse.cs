﻿namespace THCC.Application.Features.User.Profile.UserProfile
{
    public class UserProfileResponse
    {
        public string Id { get; set; } = default!;
        public string FirstName { get; set; } = default!;
        public string LastName { get; set; } = default!;
        public bool IsSubscribedToNewsletter { get; set; }
        public string Image { get; set; } = default!;
        public bool HasPassword { get; set; } = false;
    }
}