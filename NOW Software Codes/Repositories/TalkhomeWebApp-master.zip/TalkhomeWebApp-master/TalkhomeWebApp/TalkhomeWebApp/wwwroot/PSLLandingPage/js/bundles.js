﻿var BundlesPage = {
    CountriesData: null,
    BundlesData: null,
    AllCountriesData: null,
    Init: function () {
        this.GetCountries();
    },
    GetCountries: function () {
        $.ajax({
            url: "/bundlesCountries",
            dataType: "json",
            type: "GET",
            beforeSend: function (xhr) {
                $('#overlay').fadeIn();
            },
            success: function (response) {
                if (response.isAuth) {

                    $('#countryBundlesDropdown').attr('data-selected-country', response.iso_code);

                    // Country Bundles
                    $('#countryBundlesDropdown').flagStrap({
                        buttonSize: "btn-lg btn-flat",
                        buttonType: "btn-primary btn-block"
                    });

                    $('#countryBundlesDropdown button').addClass('disabled');

                    BundlesPage.GetBundles("", "", response.currencySymbol); //User is logged in

                }
                else {
                    if (response.bundlesCountries.length > 0) {

                        BundlesPage.CountriesData = response.bundlesCountries;

                        //Populate countries
                        var countryJsonString = "{"
                        $.each(response.bundlesCountries, function (index, value) {
                            countryJsonString += '"' + value.isO_Code + '":"' + value.country + '",';
                        });
                        countryJsonString = countryJsonString.substring(0, countryJsonString.length - 1);
                        countryJsonString += "}";
                        var countryJson = JSON.parse(countryJsonString);


                        // Country Bundles
                        $('#countryBundlesDropdown').flagStrap({
                            countries: countryJson,
                            buttonSize: "btn-lg btn-flat",
                            buttonType: "btn-primary btn-block",
                            onSelect: function (value, element) {
                                BundlesPage.ChangeBundleCountry(value);
                            }
                        });
                    }
                }
            },
            complete: function (xhr, status) {
                $('#overlay').fadeOut();
            }
        });
    },
    GetBundles: function (Na_Service_Id, fromCoutry, currencySymbol) {
        $.ajax({
            url: "/Home/GetBundlesByOrigination",
            type: "GET",
            data: { Na_Service_Id: Na_Service_Id, fromCoutry: fromCoutry },
            beforeSend: function (xhr) {
                $("#FlagParentDiv").empty();
                $('#overlay').fadeIn();
            },
            success: function (response) {
                if (response != null) {
                    var array_name = [];
                    if (response.errorCode == 0) {
                        if (response.data.length > 0) {

                            BundlesPage.BundlesData = response.data;

                            $.each(response.data, function (key, val) {
                                if (array_name.indexOf(val.description.toLowerCase()) == -1) {
                                    if (val.description != "") {
                                        $("#FlagParentDiv").append($('<div class="col-md-3 col-6 mb-4"><div class="flagbox" data-currency=' + currencySymbol + ' data-countryname=' + encodeURIComponent(val.countryName) + ' data-id=' + val.description.toLowerCase() + ' id="activate_modal" onclick="BundlesPage.GetCountryRatesData(this)"><i class="img-thumbnail flag flag-icon-background flag-icon-' + val.description.toLowerCase() + '"></i><h6>' + val.countryName + '</h6> </div></div>'));
                                        array_name.push(val.description.toLowerCase());
                                    }
                                }
                            });
                        }
                        else {
                            $("#FlagParentDiv").html('<div class="alert alert-danger">Bundles not found</div>')
                        }
                    }
                    else {
                    }
                }
                else {
                }
            },
            complete: function (xhr, status) {
                $('#overlay').fadeOut();
            },
            error: function (xhr, status, error) {
                $('#overlay').fadeOut();
            }
        });
    },
    ChangeBundleCountry: function (context) {

        var selectedCountry = BundlesPage.CountriesData.filter(function (x) { return x.isO_Code == context });

        var serviceId = selectedCountry[0].na_Service_Id;
        var fromCountry = selectedCountry[0].isO_Code;
        var currencySymbol = selectedCountry[0].currencySymbol;

        this.GetBundles(serviceId, fromCountry, currencySymbol);
    },
    GetCountryRatesData: function (context) {
        var id = $(context).data('id');
        var countryName = decodeURIComponent($(context).data('countryname'));
        var countrySymbol = $(context).data('currency');
        var selectedBundleData = BundlesPage.BundlesData.filter(function (x) { return x.description.toLowerCase() === id });
        $(".modal-body").empty();
        $(".modal-header").empty();
        $(".modal-header").append('<h5 class="modal-title" id="countryBundleRate">' + countryName + '</h5><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>');
        var bundleElements = "";
        $.each(selectedBundleData, function (key, val) {
            bundleElements += '<div class="col-sm-6 mb-3"><div class="amount-box"><label class="amount"><strong>' + val.minutes + '<span class="font-weight-normal d-block ml-0 mt-2">Minutes</span></strong><a href="../bundle-purchase?data=' + val.bundleInfo + '" class="btn btn-primary btn-block">' + countrySymbol + '' + val.totalCostPence / 100 + ' Buy Now</a></label><p class="text-danger text-center fs-sm mb-0 mt-3">Valid for ' + val.chargePeriodDays + ' days<br class= "d-md-none"></p></div></div>'
        });
        var modelbody = '<div class="choose-amount"><div class="row gutters-10 justify-content-center">' + bundleElements + '</div></div>'
        $(".modal-body").append(modelbody);
        $("#countryBundles").modal('show');
    }
}

$(document).ready(function () {
    BundlesPage.Init();
});