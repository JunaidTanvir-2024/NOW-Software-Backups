﻿using MapsterMapper;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Models;
using SC.Core.Vendors.FusionHub;
using SC.Core.Vendors.Payment;
using SC.Core.Vendors.Payment.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder;
internal sealed class ResumePaymentHandler : IRequestHandler<ResumePaymentRequest, IResultWrapper>
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly IFusionHubService _fusionHubService;
    private readonly IPaymentIntegration _iPay360Integration;
    private readonly ICustomerOrderService _customerOrderService;
    public ResumePaymentHandler(ICustomerCartRespository customerCartRespository, IMapper mapper, ICommonService commonService, IFusionHubService fusionHubService, IPaymentIntegration pay360Integration, ICustomerOrderService customerOrderService)
    {
        _customerCartRespository = customerCartRespository;
        _mapper = mapper;
        _commonService = commonService;
        _fusionHubService = fusionHubService;
        _iPay360Integration = pay360Integration;
        _customerOrderService = customerOrderService;
    }

    public async Task<IResultWrapper> Handle(ResumePaymentRequest request, CancellationToken cancellationToken)
    {
        var OrderID = await _customerCartRespository.GetOrderIDbyTransactionIDAsync(_commonService.GetUserID(), AppEnums.OrderStatusEnum.Init.Getkey(), request.TransactionId);
        if (OrderID == 0)
            return ResultWrapper.Failure(AppConstants.StatusKeys.InvalidTransactionID, 404);

        var orderDetail = await _customerCartRespository.GetCustomerOrderDetail(_commonService.GetUserID(), AppEnums.OrderStatusEnum.Init.Getkey(), OrderID);
        if (orderDetail == null || orderDetail.CartDetail.Count == 0)
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonCustomerOrderError, 404);

        var paymentresponse = await _iPay360Integration.ResumePaymentAsync(new ResumePaymentRequest
        {
            TransactionId = request.TransactionId
        });
        await _customerOrderService.CreateOrderPaymentHistory(orderDetail!.CustomerOrderID, orderDetail.TotalOrderAmount, paymentresponse?.TransactionId, AppEnums.PaymentActionEnum.Resume.Getkey(), paymentresponse?.IsFailure);// create history
        if (paymentresponse == null || paymentresponse.IsFailure)
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonPaymentError, 404);

        var inventryresponse = await _customerOrderService.PurchaseInventory(orderDetail);

        if (inventryresponse == null || inventryresponse.Payload == null)
        {
            var cancelPaymentResposne = await _iPay360Integration.CancelPaymentAsync(new CancelPaymentRequest
            {
                TransactionId = paymentresponse!.TransactionId!
            });
            await _customerOrderService.CreateOrderPaymentHistory(orderDetail!.CustomerOrderID, orderDetail.TotalOrderAmount, cancelPaymentResposne?.TransactionId, AppEnums.PaymentActionEnum.Cancel.Getkey(), cancelPaymentResposne?.IsFailure);// create history
            if (cancelPaymentResposne == null || cancelPaymentResposne.IsFailure)
                return ResultWrapper.Failure(AppConstants.StatusKeys.CommonPaymentError, 404);
            return ResultWrapper.Failure(AppConstants.StatusKeys.PurchaseInventoryFailed, 404);
        }
        var purchaseInventroyResponce = _mapper.Map<PurchaseInventoryResponse>(inventryresponse.Payload);
        decimal RefundAmount = 0;
        if (purchaseInventroyResponce.PurchasedItems != null && purchaseInventroyResponce.PurchasedItems.Count > 0)
        {
            var failedProducts = purchaseInventroyResponce.PurchasedItems
                                                .Where(x => x.Status.ToUpper() == nameof(TransactionStatus.Cancelled).ToUpper() ||
                                                    x.Status.ToUpper() == nameof(TransactionStatus.Rejected).ToUpper() ||
                                                x.Status.ToUpper() == nameof(TransactionStatus.Declined).ToUpper()).ToList();
            if (failedProducts?.Count > 0)
                foreach (var product in failedProducts)
                {
                    var cartProduct = orderDetail.CartDetail.Where(x => x.ProductId == product.ProductId && x.ProductVendorCode == product.ProductVendorCode).FirstOrDefault();
                    if (cartProduct != null)
                        RefundAmount += cartProduct.Price;
                }
        }
        if (RefundAmount > 0)
        {
            var refundPayment = await _iPay360Integration.RefundPaymentAsync(new RefundPaymentRequest
            {
                TransactionId = paymentresponse!.TransactionId!,
                IsFullRefund = false,
                PartialRefund = new PartialRefundDto
                {
                    Currency = orderDetail.Currency,
                    Amount = (float)RefundAmount
                }
            });
            await _customerOrderService.CreateOrderPaymentHistory(orderDetail!.CustomerOrderID, RefundAmount, refundPayment?.TransactionId, AppEnums.PaymentActionEnum.Refund.Getkey(), refundPayment?.IsFailure);// create history
            if (refundPayment == null || refundPayment.IsFailure)
                return ResultWrapper.Failure(AppConstants.StatusKeys.CommonPaymentError, 404);
        }
        await _customerOrderService.UpdateOrder(orderDetail);// Update Customer Order Status
        return ResultWrapper.Success(orderDetail);

    }
}

