﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class PaypalPaymentCallBackRequestModel
    {
        [Required]
        public string PayerId { get; set; }

        [Required]
        public string PaymentId { get; set; }

        [Required]
        [Range(1,2)]
        public CheckOutTypes type { get; set; }
        public string bundleId { get; set; }
        public string IpAddress { get; set; }

        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        public string Msisdn { get; set; }
        public decimal TopUpAmount { get; set; }
        public int PTId { get; set; }
	}
}
