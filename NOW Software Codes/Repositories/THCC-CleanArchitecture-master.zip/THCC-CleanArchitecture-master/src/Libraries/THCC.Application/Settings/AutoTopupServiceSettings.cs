﻿namespace THCC.Application.Settings
{
    public sealed class AutoTopupServiceSettings
    {
        public const string SectionName = nameof(AutoTopupServiceSettings);
        public static AutoTopupServiceSettings Bind = new AutoTopupServiceSettings();
        public bool AutoTopupSimulationMode { get; set; }
        public decimal AutoTopupMonthlyMaxLimit { get; set; }
    }
}
