﻿using NowPayG.Models.PaypalApiContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Services.Interfaces
{
    public interface IPayPalService
    {
        Task<GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>> PayPalCreateSalePayment(PayPalCreateSalePaymentRequest request);
        Task<GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>> PayPalExecuteSalePayment(PayPalExecuteSalePaymentRequest request);
        Task<GenericPayPalApiResponse<Pay360PayPalCreateSalePaymentResponse>> Pay360PayPalCreateSalePayment(Pay360PayPalCreateSalePaymentRequest request);
        Task<GenericPayPalApiResponse<Pay360PayPalCreateResumePaymentResponse>> Pay360ResumePayment(Pay360PayPalResumePaymentRequest request);
    }
}
