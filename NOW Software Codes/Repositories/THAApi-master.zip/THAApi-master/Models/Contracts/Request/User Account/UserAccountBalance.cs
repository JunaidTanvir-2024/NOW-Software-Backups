﻿namespace Models.Contracts.Request
{
    public class UserAccountBalance
    {
        public string Currency { get; set; }

        public string Balance { get; set; }

        public string CurrencySymbol { get; set; }

        public int RewardPoints { get; set; }
    }
}
