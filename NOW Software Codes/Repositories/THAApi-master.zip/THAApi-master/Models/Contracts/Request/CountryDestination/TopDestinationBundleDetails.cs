﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.CountryDestination
{
	public class TopBundlesView
	{
		public IEnumerable<TopDestinationBundleDetails> bundles { get; set; }
		public IEnumerable<CountryDestination> rates { get; set; }
	}
	public class TopDestinationBundleDetails
	{
		public string bundle_id { get; set; }
		public string bundle_name { get; set; }
		public string dest_iso_code { get; set; }
		public string dest_country_name { get; set; }
		public string bundle_price { get; set; }
		public string bundle_days { get; set; }
		public string bundle_minutes { get; set; }
		public string flagImageUrl { get; set; }
		public string bundleMobileRate { get; set; }
		public bool IsOffer { get; set; }
		public int DiscountPercentage { get; set; }
		public int Type { get; set; }
		public string TypeName { get; set; }
		public int Category { get; set; }
		public string CategoryName { get; set; }
		public TrialBundle TrialBundle { get; set; }
		public int RewardPoints { get; set; }
    }
}
