﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATTDaemon.Models
{
    public class countries
    {
        public int CountryID { get; set; }
        public string Name {get; set;}
        public string ISOCode2 { get; set; }
        public string ISOCode3 { get; set; }
        public bool GetRates { get; set; }
        public int ServiceProviderID { get; set; }
    }
}
