﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;

namespace AirShipApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CustomEventController : ControllerBase
    {
        private readonly ILogger Logger;
        private ICustomEvents_BL CustomEventBl;

        public CustomEventController(ILogger logger, ICustomEvents_BL customEventBl)
        {
            Logger = logger;
            CustomEventBl = customEventBl;
        }

        [HttpPost]
        [Route("AddCustomEvent")]
        public async Task<IActionResult> AddCustomEvent(AddCustomEventsRequest request)
        {

            try
            {
                var response = await CustomEventBl.AddCustomEvents(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: CustomEventController, Method: AddCustomEvent, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<ApiCustomEventResponse>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

    }
}