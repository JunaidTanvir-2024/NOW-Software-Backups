﻿//using Microsoft.AspNetCore.Http;
//using Microsoft.Extensions.Logging;
//using SC.Core.Common.Definitions.Constants;
using Microsoft.AspNetCore.Http;
using SC.Core.Common.Definitions.Constants;
using Serilog;
using System.Net.Http;

namespace SC.Infrastructure.Common.Middlewares;
public class AppExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger _logger;

    public AppExceptionMiddleware(RequestDelegate next, ILogger logger)
    {
        _next = next;
        _logger = logger;
    }
    public async Task Invoke(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            // Handle the exception and generate an appropriate response
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = AppConstants.StatusCodes.InternalServerError;

            _logger.Error(ex, ex.Message);

            await context.Response.WriteAsJsonAsync(new { message = ex.StackTrace?.ToString(), code = AppConstants.StatusCodes.InternalServerError });
        }
    }
}

