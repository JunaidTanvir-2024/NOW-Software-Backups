﻿
namespace Application.Common.Settings;
public class ReplacementSimSettings
{
    public const string SectionName = "ReplacementSimSettings";
    public static ReplacementSimSettings Bind = new ReplacementSimSettings();
    public int? Noofdays { get; set; }
    public int? Nooforders { get; set; }
  
}
