﻿namespace Infrastructure.Caching;
internal sealed class CacheKeyService : ICacheKeyService
{
    public string GetCacheKey(string name, string id)
    {
        return $"{name}-{id}";
    }
}