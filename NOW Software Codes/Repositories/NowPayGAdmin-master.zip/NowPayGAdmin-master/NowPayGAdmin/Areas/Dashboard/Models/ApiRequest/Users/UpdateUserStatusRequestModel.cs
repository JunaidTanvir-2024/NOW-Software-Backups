﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models.ApiRequest.Users
{
    public class UpdateUserStatusRequestModel
    {
        public int UserID { get; set; }
        public int StatusID { get; set; }
    }
}