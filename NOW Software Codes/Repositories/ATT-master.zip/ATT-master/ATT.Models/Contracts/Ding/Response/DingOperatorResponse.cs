﻿using ATT.Models.Contracts.Ding.Response;
using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Ding.Response
{
    public class DingOperatorResponse
    {
        public int ResultCode { get; set; }
        public List<ErrorCodes> ErrorCodes { get; set; }
        public List<DingProviderDetail> Items { get; set; }
    }

    public class DingProviderDetail
    {
        public string ProviderCode { get; set; }
        public string CountryIso { get; set; }
        public string Name { get; set; }
        public string ShortName { get; set; }
        public string ValidationRegex { get; set; }
        public string CustomerCareNumber { get; set; }
        public string[] RegionCodes { get; set; }
        public object PaymentTypes { get; set; }
        public string LogoUrl { get; set; }
    }


    public class DingOperatorDetailedResponse
    {
        public int ResultCode { get; set; }
        public List<ErrorCodes> ErrorCodes { get; set; }
        public List<DingProductDetail> Items { get; set; }
    }

    public class DingProductDetail
    {
        public string ProviderCode { get; set; }
        public string SkuCode { get; set; }
        public object SettingDefinitions { get; set; }
        public DingRates Maximum { get; set; }
        public DingRates Minimum { get; set; }
        public decimal CommissionRate { get; set; }
        public string ProcessingMode { get; set; }
        public string RedemptionMechanism { get; set; }
        public string[] Benefits { get; set; }
        public string ValidityPeriodIso { get; set; }
        public string UatNumber { get; set; }
        public string AdditionalInformation { get; set; }
        public string DefaultDisplayText { get; set; }
        public string RegionCode { get; set; }
        public object PaymentTypes { get; set; }
        public bool LookupBillsRequired { get; set; }

    }

    public class DingRates
    {
        public decimal CustomerFee { get; set; }
        public decimal DistributorFee { get; set; }
        public decimal ReceiveValue { get; set; }
        public string ReceiveCurrencyIso { get; set; }
        public decimal ReceiveValueExcludingTax { get; set; }
        public decimal TaxRate { get; set; }
        public string TaxName { get; set; }
        public string TaxCalculation { get; set; }
        public decimal SendValue { get; set; }
        public string SendCurrencyIso { get; set; }
    }


}
