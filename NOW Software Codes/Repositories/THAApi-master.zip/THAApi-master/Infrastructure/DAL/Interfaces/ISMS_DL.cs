﻿using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface ISMS_DL
    {
        Task<int> CountSMSResend(string msisdn);
        Task UpdateSMSResend(string msisdn);
    }
}