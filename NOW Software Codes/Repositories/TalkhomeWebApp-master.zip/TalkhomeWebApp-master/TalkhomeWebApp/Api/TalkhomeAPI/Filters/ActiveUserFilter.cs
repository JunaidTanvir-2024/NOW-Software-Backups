﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.Interfaces;

namespace TalkhomeAPI.Filters
{
    public class ActiveUserFilter : IAsyncAuthorizationFilter
    {
        private readonly ILogger _logger;
        private readonly IAccountRepository _accountRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ActiveUserFilter(ILogger logger,
                                IAccountRepository accountRepository,
                                IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _accountRepository = accountRepository;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            var httpContext = _httpContextAccessor.HttpContext;

            try
            {
                var msisdn = httpContext.User.Claims.First(i => i.Type == "msisdn").Value;

                //------>validate user
                var response = await _accountRepository.ValidateUser(msisdn);

                if (string.IsNullOrEmpty(response))
                {
                    //----------->Check pin-number validation to check for blocking
                    var pinResponse = await _accountRepository.GetPinByPhoneNumber("THA" + msisdn);
                    if (pinResponse == null)
                    {
                        ReturnUnauhtorizedResult(context);
                        return;
                    }

                    await Task.CompletedTask;
                    return;
                }
                else
                {
                    ReturnUnauhtorizedResult(context);
                    return;
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: ActiveUserFilter, Method: OnAuthorizationAsync, " +
                                            $"Path: {httpContext.Request.Path.Value}" +
                                            $"User_Claims: {JsonConvert.SerializeObject(httpContext.User.Claims)}" +
                                            $"Error_Message: {ex.Message}, StackTrace: {ex.StackTrace},");

                httpContext.Response.StatusCode = 500;
                await Task.CompletedTask;
                return;
            }
        }

        private void ReturnForbiddenResult(AuthorizationFilterContext context)
        {
            context.Result = new ForbidResult();
        }

        private void ReturnUnauhtorizedResult(AuthorizationFilterContext context)
        {
            context.Result = new UnauthorizedResult();
        }
    }
}
