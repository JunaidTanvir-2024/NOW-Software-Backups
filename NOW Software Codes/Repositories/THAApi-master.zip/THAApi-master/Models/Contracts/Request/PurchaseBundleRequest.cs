﻿using Models.Contracts.Request.Voucherify;
using Models.Enums;
using System.Collections.Generic;

namespace Models.Contracts.Request
{
    public class PurchaseBundleRequest
    {
        public bool IsBundleAutoRenew { get; set; }

        //public AppsFlyerInfo AppsFlyerInfo { get; set; }
        public string AppsFlyerId { get; set; }
        public int DeviceType { get; set; }
    }

	public class SuggestedBundleRequest
    {
        public List<string> CountryCodes { get; set; }
    }
}
