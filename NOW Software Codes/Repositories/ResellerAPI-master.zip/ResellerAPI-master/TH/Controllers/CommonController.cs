﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using TH.Infrastructure.BLL;
using TH.Models.Contracts.Request;
using TH.Models.Contracts.Response;
using TH.Models.Database;

namespace TH.Controllers
{
    //[Route("[controller]")]
    [ApiController]
    public class CommonController : ControllerBase
    {
       
        private readonly ILogger Logger;
        private ITH_BL THBL;

        public CommonController(ILogger logger, ITH_BL thBl)
        {
            Logger = logger;
            THBL = thBl;
        }

        [HttpGet("Common/Test")]
        public  ActionResult Test()
        {
            Logger.Error("This is a test");
            
            return Ok(DateTime.UtcNow.ToString());
        }

        [HttpGet("UserAccount/CustomerDetails")]
        public async Task<ActionResult> CustomerDetails(Customer customer)
        {

            GenericApiResponse<Customer> response;
            try
            {

                if (!ModelState.IsValid || customer == null || customer.msisdn==null)
                {
                    return BadRequest(ModelState);
                }

                response = await THBL.CustomerDetails(customer.msisdn);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<Customer>()
                {
                    errorCode = 2,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: CommonController, Method: CustomerDetails, Parameters=> msisdn: {customer.msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpGet("UserAccount/Plans")]
        public async Task<ActionResult> AccountPlans(string msisdn)
        {

            GenericApiResponse<List<AccountPlans>> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await THBL.GetAccountPlans(msisdn);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<List<AccountPlans>>()
                {
                    errorCode = 2,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: CommonController, Method: AccountPlans, Parameters=> msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpGet("Common/Plans")]
        public async Task<ActionResult> Plans()
        {

            GenericApiResponse<List<Plans>> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await THBL.GetPlans();

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<List<Plans>>()
                {
                    errorCode = 2,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: CommonController, Method: Plans, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }


        [HttpPost("UserAccount/PrimarySimState")]
        public async Task<ActionResult> PrimarySimState(UserReqPrimarySimState userReq)
        {

            GenericApiResponse<string> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await THBL.SetPrimarySIMState(userReq.msisdn, userReq.state,userReq.userId);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<string>()
                {
                    errorCode = 10,
                    status = "Failure",
                    message = "Fatal error occurred",
                    payload = null
                };
                Logger.Error($"Controller: CommonController, Method: PrimarySIMState, Parameters => jsonRequest: {JsonConvert.SerializeObject(userReq)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("topup/voucher")]
        public async Task<ActionResult> TopupVoucher(UserReqTopupVoucher userReq)
        {

            GenericApiResponse<string> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await THBL.TopupVoucher(userReq.msisdn, userReq.pin);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<string>()
                {
                    errorCode = 2,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: CommonController, Method: TopupVoucher, Parameters => jsonRequest: {JsonConvert.SerializeObject(userReq)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("topup/purchase")]
        public async Task<ActionResult> Purchase(UserRequestPurchase userReq)
        {

            GenericApiResponse<PurchaseResult> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await THBL.Purchase(userReq.msisdn, userReq.bundleref, userReq.amount, userReq.transactionid);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<PurchaseResult>()
                {
                    errorCode = 2,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: CommonController, Method: Purchase, Parameters => jsonRequest: {JsonConvert.SerializeObject(userReq)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpGet("topup/history")]
        public async Task<ActionResult> TopupHistory(string msisdn)
        {

            GenericApiResponse<List<TopupHistory>> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await THBL.GetTopupHistory(msisdn);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<List<TopupHistory>>()
                {
                    errorCode = 2,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: CommonController, Method: TopupHistory, Parameters=> msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

    }
}
