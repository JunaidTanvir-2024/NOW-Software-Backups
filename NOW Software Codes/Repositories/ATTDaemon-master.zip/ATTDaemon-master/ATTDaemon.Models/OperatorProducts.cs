﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATTDaemon.Models
{
    public class OperatorsAndProducts
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public operatorpayload payload { get; set; }
    }


    public class operatorpayload
    {
        public List<operators> operators { get; set; }
    }


    public class operators
    {
        public int id { get; set; }
        public string name { get; set; }
        public string country { get; set; }
        public string nowtelTransactionReference { get; set; }
        public string iconUri { get; set; }
        public List<productdata> products { get; set; }
        public bool isFixed { get; set; }
    }


    public class productdata
    {
        public string clientccy { get; set; }
        public string receiverccy { get; set; }
        public string transactionfeeClientccy { get; set; }
        public string product { get; set; }
        public string itemPriceClientccy { get; set; }
        public string totalPriceClientccy { get; set; }
    }

}
