﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class InternationalTopUpHistoryRequestModel
    {
        public string clientNumber { get; set; }
        public string accountNumber { get; set; }
    }
}
