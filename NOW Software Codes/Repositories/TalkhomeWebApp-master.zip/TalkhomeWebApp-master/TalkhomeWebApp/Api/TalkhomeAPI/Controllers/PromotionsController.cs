﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeAPI.Services.Interfaces;

namespace TalkhomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PromotionsController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IPromotionService _promotionService;

        public PromotionsController(ILogger logger, IPromotionService promotionService)
        {
            _logger = logger;
            _promotionService = promotionService;
        }


        [HttpGet]
        [Route("GetAccountPromotions")]
        public async Task<IActionResult> GetAccountPromotions(string msisdn)
        {
            try
            {
                return Ok(await _promotionService.GetAccountPromotions(msisdn));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PromotionsController, Method: GetAccountPromotions, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
    }
}
