﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Response
{
    public class BasketItemsResponseforTrackingscript
    {
        public string ProductItemCode { get; set; }
        public bool IsFullFilled { get; set; }
        public string Pin { get; set; }
        public string card { get; set; }
        public int Points { get; set; }
        public string Transactionid { get; set; }
        public string Transactionamount { get; set; }
        public bool IsAutoProductAttached { get; set; }
    }
}
