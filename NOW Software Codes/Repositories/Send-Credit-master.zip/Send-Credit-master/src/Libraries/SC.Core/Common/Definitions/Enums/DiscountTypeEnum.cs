﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants;

public static partial class AppEnums
{
    public enum DiscountTypeEnum
    {
        [Key("flatOrder")]
        FlatOrder = 1,

        [Key("percentage")]
        PercentageOrder = 2,

        [Key("FlatItem")]
        FlatItem = 3,

        [Key("PercentageItem")]
        PercentageItem = 4,

        [Key("FlatServiceFee")]
        FlatServiceFee = 5,

        [Key("PercentageServiceFee")]
        PercentageServiceFee = 6,
    }
}