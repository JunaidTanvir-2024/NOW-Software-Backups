﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using static Models.Contracts.Response.Voucherify.VoucherifyLoyaltiesResponse;

namespace Models.Configurations
{
    public class ATTConfig
    {
        public const string Section = "ATTApi";
        public string ApiEndpoint { get; set; }
        public string local_promotions_uri { get; set; }
        public string only_dtOne_promotions { get; set; }
        public Servicefee ServiceFee { get; set; }

        public class Servicefee
        {
            public string[] ExcludedOriginations { get; set; }=Array.Empty<string>();
            public string[] ExcludedDestinations { get; set; } = Array.Empty<string>();
            public FeeRule[] FeeRules { get; set; }=Array.Empty<FeeRule>();
            public FeeDiscountRule[] FeeDiscountRules { get; set; }=Array.Empty<FeeDiscountRule>();
            public class FeeRule
            {
                public string Currency { get; set; }
                public int Min { get; set; }
                public int Max { get; set; }
                public decimal FeePercentage { get; set; }
                public string Origination { set; get; }
                public string Destination { set; get; }

			}

            public class FeeDiscountRule
            {
                public string Currency { get; set; }
                public string Origination { get; set; }
                public string Destination { get; set; }
                public decimal DiscountPercentage { get; set; }
            }
        }
    }

    public class VoucherifyConfig
    {
        public const string SectionName = nameof(VoucherifyConfig);
        public string ApiEndpoint { get; set; }
        public string LoyaltyCampaignId { get; set; }
        public string LoyaltyProductId { get; set; }
        public string LoyaltyRewardId { get; set; }
        public string ReferralCampaignId { get; set; }
        public List<CampaignConfig> LoyaltyCampaigns { get; set; }
        public VoucherifyEndpointConfig EndpointConfig { get; set; }
        public LoyaltyEarningRulesInfo LoyaltyEarningRules { get; set; }

        public class CampaignConfig
        {
            public string LoyaltyName { get; set; }
            public long LoyaltyPoints { get; set; }
            public LoyaltyActionType LoyaltyType { get; set; }
            public int DisplayOrder { get; set; }
        }
        public class VoucherifyEndpointConfig
        {
            public bool GetLoyaltyInformation { get; set; }
            public bool GetPromotions { get; set; }
            public bool RedeemLoyaltyPoints { get; set; }
            public bool IsCustomerEligibleToGenerateInviationCode { get; set; }
            public bool ValidateReferralCode { get; set; }
            public bool GenerateInviationCode { get; set; }
            public bool ValidateDiscount { get; set; }
            public bool Event { get; set; }
            public bool BundleReward { get; set; }
        }

        public class LoyaltyEarningRulesInfo
        {
            public SignupLoyalty Signup { get; set; }
            public TopupLoyalty Topup { get; set; }
            public InternationalLoyalty[] International { get; set; }
            public BundleLoyalty Bundle { get; set; }
            public ProfileCompleteLoyalty ProfileComplete { get; set; }
            public ReferralLoyalty Referral { get; set; }

            public class SignupLoyalty
            {
                public int Points { get; set; }
            }
            public class ProfileCompleteLoyalty
            {
                public int Points { get; set; }
            }
            public class ReferralLoyalty
            {
                public int RefereePoints { get; set; }
                public int ReferrerPoints { get; set; }
            }

            public class BundleLoyalty
            {
                public WelcomeLoyalty Welcome { get; set; }
                public PaygLoyalty Payg { get; set; }

                public class WelcomeLoyalty
                {
                    public int Points { get; set; }
                }
                public class PaygLoyalty
                {
                    public int BasePoints { get; set; }
                    public int BaseValue { get; set; }
                }
            }

            public class TopupLoyalty
            {
                public int BasePoints { get; set; }
                public int BaseValue { get; set; }
            }

            public class InternationalLoyalty
            {
                public int Points { get; set; }
                public decimal Min { get; set; }
                public decimal Max { get; set; }
            }
        }
    }
}