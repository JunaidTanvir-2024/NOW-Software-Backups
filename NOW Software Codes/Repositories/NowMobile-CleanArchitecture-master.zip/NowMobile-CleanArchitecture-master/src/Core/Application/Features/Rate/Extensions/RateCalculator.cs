namespace Application.Features.Rate.Extensions;

public static class RateCalculator
{
    public static string GetRate(this string rate)
    {
        return Math.Round(Convert.ToSingle(rate) * 100).ToString();
    }
}