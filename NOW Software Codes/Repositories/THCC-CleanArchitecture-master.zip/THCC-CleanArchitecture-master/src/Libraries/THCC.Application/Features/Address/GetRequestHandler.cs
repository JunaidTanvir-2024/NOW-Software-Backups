﻿using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Address;

public class GetRequestHandler : IRequestHandler<GetAddressRequest, object>
{
    private readonly IAddressService _addressService;

    public GetRequestHandler(IAddressService addressService)
    {
        _addressService = addressService;
    }

    public async Task<object> Handle(GetAddressRequest request, CancellationToken cancellationToken)
    {
        var response = await _addressService.GetAddresses(request.PostCode.Trim());
        return response == null
            ? ErrorResult.Failure(CustomStatusKey.AddressNotFound, CustomStatusCode.AddressNotFound)
            : response;
    }
}