﻿namespace Application.Common.Models.Airship;

public class SimPurchaseEventData
{
    public string Email { get; set; } = string.Empty;
    public bool IsCard { get; set; } = false;
    public bool IsSuccess { get; set; }
    public bool IsTopupIncluded { get; set; }
    public bool IsBundleIncluded { get; set; }
    public bool AutoTopup { get; set; } = false;
    public bool? AutoRenew { get; set; } = false;
    public bool IsNewCustomer { get; set; }
    public bool IsCreditSIM { get; set; } = false;
    public bool SaveCard { get; set; } = false;
    public decimal Amount { get; set; }
}
