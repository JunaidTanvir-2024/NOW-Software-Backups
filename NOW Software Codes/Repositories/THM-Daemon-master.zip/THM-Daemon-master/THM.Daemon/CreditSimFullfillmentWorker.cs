using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using THM.Infrastructure.BLL;

namespace THM.Daemon
{
    public class CreditSimFullfillmentWorker : BackgroundService
    {
        private readonly ILogger<CreditSimFullfillmentWorker> _logger;
        private readonly ICreditSimFulfillment_BL _creditSimFulfillment_BL;
        private readonly Serilog.ILogger _serilogLogger;

        public CreditSimFullfillmentWorker(ILogger<CreditSimFullfillmentWorker> logger,
                                                            ICreditSimFulfillment_BL creditSimFulfillment_BL,
                                                            Serilog.ILogger  serilogLogger)
        {
            _logger = logger;
            _creditSimFulfillment_BL = creditSimFulfillment_BL;
            _serilogLogger = serilogLogger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await _creditSimFulfillment_BL.StartFulfillment();
                }
                catch (Exception ex)
                {
                    _logger.LogError("CreditSimFullfillmentWorker,  " +
                                     "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                     "StackTrace: " + ex.StackTrace);
                    
                    _serilogLogger.Error("CreditSimFullfillmentWorker,  " +
                                     "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                     "StackTrace: " + ex.StackTrace);
                }

                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
        }
    }
}
