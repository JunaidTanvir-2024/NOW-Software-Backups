using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class Friendship : IBaseEntity<long>
{
    public long Id { get; set; }
    public long InitiatorId { get; set; }
    public long ResponderId { get; set; }
    public string Status { get; set; } = null!;
    public User Initiator { get; set; } = null!;
    public User Responder { get; set; } = null!;
}
