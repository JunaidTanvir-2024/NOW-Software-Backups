using Serilog;

namespace Voucherify.Core.Services.Loggers;
public static class LoggerService
{
    public static void EnsureInitialized()
    {
        if (Log.Logger is not Serilog.Core.Logger)
        {
            Log.Logger = new LoggerConfiguration()
                .Enrich.FromLogContext()
                .WriteTo.Sentry()
                .WriteTo.Console()
                .CreateLogger();
        }
    }
}
