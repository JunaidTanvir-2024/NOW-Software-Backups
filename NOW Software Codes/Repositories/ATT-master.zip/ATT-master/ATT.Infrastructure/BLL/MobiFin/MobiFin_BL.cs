﻿using ATT.Infrastructure.BLL.Common;
using ATT.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.MobiFin
{
    public class MobiFin_BL : IMobiFin_BL
    {

        private ICommon_BL Comm_BL;
        public MobiFin_BL(ICommon_BL comm_BL)
        {
            Comm_BL = comm_BL;
        }

        public async Task<GenericApiResponse<string>> GetSessionId()
        {
            HttpClient SochitelHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(120) };
            SochitelHttpClient.Timeout = TimeSpan.FromSeconds(120);
            //SochitelHttpClient.BaseAddress = new Uri("http://URL-2.com/distributormobilerest/distributormobilerest");
            string data = "{\"RequestUniqueID\":\"5635666445675\",\"MethodName\":\"DstGenerateSessionID\"}";
            string eData =  Comm_BL.AesEncrypt(data);
            string dat = "{\"TerminalNumber\":\"20848609\",\"Data\":\"" + eData + "\"";
            var httpContent = new StringContent(dat, Encoding.UTF8, "text/json");
            var httpResponse = await SochitelHttpClient.PostAsync("http://URL-2.com/distributormobilerest/distributormobilerest", httpContent);

            if (httpResponse.Content != null)
            {
                string returnData = await httpResponse.Content.ReadAsStringAsync();
            }
            return null;
        }

    }
}
