using Microsoft.AspNetCore.Builder;

namespace FH.Infrastructure.Common.Middlewares;
public static class MiddlewareExtensions
{
    /// <summary>
    /// Voucherify Logging Middleware Extension
    /// </summary>
    /// <param name="app"></param>
    /// <returns></returns>
    public static IApplicationBuilder UseAppLoggingMiddleware(this IApplicationBuilder app)
    {
        return app.UseMiddleware<AppLoggingMiddleware>();
    }
    /// <summary>
    /// Global Exception Middleware Extension
    /// </summary>
    /// <param name="app"></param>
    /// <returns></returns>
    public static IApplicationBuilder UseAppExceptionMiddleware(this IApplicationBuilder app)
    {
        return app.UseMiddleware<AppExceptionMiddleware>();
    }

    /// <summary>
    ///Security Headers Middleware Extension
    /// </summary>
    /// <param name="app"></param>
    /// <returns></returns>
    public static IApplicationBuilder UseSecurityHeadersMiddleware(this IApplicationBuilder app)
    {
        return app.UseMiddleware<SecurityHeadersMiddleware>();
    }
}
