﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome
{
    public class SignUpResponse
    {
        public string msisdn { get; set; }
        public bool isexistingUser { get; set; }
        public bool isPreAuthVerified { get; set; }
    }
}
