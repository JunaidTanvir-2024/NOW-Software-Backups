﻿namespace NTCB.Api.Features.DTOne.Requests;

public class VerifyDTOneTransactionRequest
{
    public string TransactionReferenceId { get; set; } = default!;
}