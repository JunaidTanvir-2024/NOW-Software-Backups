﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class Pay360Resume3DRequestModel
    {
        public string MD { get; set; }
        public string PaRes { get; set; }
        public CheckOutTypes type { get; set; }
        public string customerEmail { get; set; }
        public string customerMsisdn { get; set; }
        public string currency { get; set; }
        public string clientRedirectType { get; set; }
        public string bundleId { get; set; }
        public string IpAddress { get; set; }


        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }

        public bool IsAutoTopUp { get; set; }
        public bool IsAutoBundleRenew { get; set; }
        public int PTId { get; set; }
        public bool ShouldSaveCard { get; set; }
    }
    public class SetAutoTopupWithCardPay360Resume3DRequestModel
    {
        public string MD { get; set; }
        public string PaRes { get; set; }
        public CheckOutTypes type { get; set; }
        public string customerEmail { get; set; }
        public string customerMsisdn { get; set; }
        public string currency { get; set; }
        public string clientRedirectType { get; set; }
        public string IpAddress { get; set; }
        public int PTId { get; set; }
        public bool ShouldSaveCard { get; set; }
        public float TopupAmount { get; set; }
        public float ThresholdAmount { get; set; }
    }
    public class SetAutoRenewalWithCardPay360Resume3DRequestModel
    {
        public string MD { get; set; }
        public string PaRes { get; set; }
        public CheckOutTypes type { get; set; }
        public string customerEmail { get; set; }
        public string customerMsisdn { get; set; }
        public string currency { get; set; }
        public string clientRedirectType { get; set; }
        public string IpAddress { get; set; }
        public int PTId { get; set; }
        public string BundleId { get; set; }
    }
}
