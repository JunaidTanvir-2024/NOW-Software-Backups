﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Campaigns.Requests
{
    public class GetCampaignByIdOrNameRequest
    {
        public string CampaignName { get; set; } = null!;
    }
}
