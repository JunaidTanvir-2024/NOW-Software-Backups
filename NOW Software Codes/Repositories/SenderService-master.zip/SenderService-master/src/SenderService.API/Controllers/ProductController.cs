﻿using Microsoft.AspNetCore.Mvc;
using SenderService.API.Controllers.Common;
using SenderService.Core.Common;
using SenderService.Core.Features.Email.Response;
using SenderService.Core.Features.ProductCode;
using SenderService.Core.Features.ProductCode.Request;
using SenderService.Core.Features.ProductCode.Response;
using System.Net;

namespace SenderService.API.Controllers;

public class ProductController : BaseApiController
{
    private readonly IProductCodeService _productCodeService;

    public ProductController(IProductCodeService productCodeService)
    {
        _productCodeService = productCodeService;
    }

    [HttpPost]
    public async Task<ActionResult<bool>> AddProductCode(AddProductCodeRequest request)
    {
        var isProductCodeAdded = await _productCodeService.AddProductCodeAsync(request);
        if (isProductCodeAdded > 0)
        {
            return CreatedAtAction(nameof(GetProductCodeById), routeValues: isProductCodeAdded, value: ApiResult<long>.Success(successCode: (int) HttpStatusCode.Created, data: isProductCodeAdded));
        }
        else
        {
            return BadRequest(ApiResult<EmailResponse>.Failure());
        }
    }
    [HttpGet]
    public async Task<ActionResult> GetProductCodes()
    {
        var productCodes = await _productCodeService.GetProductCodesAsync();
        if (productCodes.Any())
        {
            return Ok(ApiResult<IEnumerable<ProductCodeResponse>>.Success(data: productCodes));
        }
        else
        {
            return NotFound(ApiResult<IEnumerable<ProductCodeResponse>>.Failure("Not found",errorCode: (int) HttpStatusCode.NotFound));
        }
    }
    [HttpGet("Id")]
    public async Task<ActionResult> GetProductCodeById([FromQuery] GetProductCodeByIdRequest request)
    {
        var productCode = await _productCodeService.GetProductCodeByIdAsync(request);
        if (productCode != null)
        {
            return Ok(ApiResult<ProductCodeResponse>.Success(data: productCode));
        }
        else
        {
            return NotFound(ApiResult<ProductCodeResponse>.Failure("Not found",errorCode: (int) HttpStatusCode.NotFound));
        }
    }
}
