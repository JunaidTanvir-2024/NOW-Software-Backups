﻿namespace SC.Core.Common.Definitions.Constants;
public static partial class AppConstants
{
    public static class StatusCodes
    {
        // Commonly Used Status Codes
        public const int Success = Microsoft.AspNetCore.Http.StatusCodes.Status200OK;
        public const int BadRequest = Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest;
        public const int Forbidden = Microsoft.AspNetCore.Http.StatusCodes.Status403Forbidden;
        public const int NotFound = Microsoft.AspNetCore.Http.StatusCodes.Status404NotFound;
        public const int Unauthorized = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;
        public const int InternalServerError = Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError;
        public const int Conflict = Microsoft.AspNetCore.Http.StatusCodes.Status409Conflict;
    }
    public static class CustomStatusCode
    {
        public const int Success = 100200;
        public const int BadRequest = 100400;
        public const int Forbidden = 100403;
        public const int NotFound = 100404;
        public const int Unauthorized = 100401;
        public const int InternalServerError = 100500;
        public const int TooManyRequests = 100429;
        public const int EmailNotVerified = 100104;
        public const int AddressNotFound = 100108;
    }
}

