﻿using SC.Api.Model.Common;

using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Model.Country;

public class CountryModel
{
    public int Page { get; set; } = AppConstants.CommonAppConfig.DefaultPageSize;
    public int RecordsPerPage { get; set; } = AppConstants.CommonAppConfig.DefaultRecordsPerPageSize;

    public CountryFilter? CountryFilters { get; set; }

    public sealed record CountryFilter
    {
        public string? CountryName { get; set; }
        public string? CountryCallingCode { get; set; }
        public string? IsoCode2 { get; set; }
        public string? IsoCode3 { get; set; }
    }
}