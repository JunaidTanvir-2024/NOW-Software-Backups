﻿using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Requests
{
    public class StackableDiscountValidationRequest
    {
        public StackableDiscountCustomerInfo Customer { get; set; } = null!;
        public StackableDiscountOrderInfo Order { get; set; } = null!;
        public StackableDiscountInfo Validation { get; set; } = null!;
    }
}