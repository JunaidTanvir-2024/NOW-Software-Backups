﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.OrderCheckout.Payment;

public class CustomFieldDto
{
    public List<FieldStateDto>? FieldState { get; set; }
}
public class FieldStateDto
{
    public string? Name { get; set; }
    public string? Value { get; set; }
    public bool Transient { get; set; }
}

