﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Reloadly.Response
{
    public class ReloadlyTopUpResponse
    {
        public string transactionId { get; set; }
        public string recipientPhone { get; set; }
        public string recipientEmail { get; set; }
        public string senderPhone { get; set; }
        public string countryCode { get; set; }
        public int operatorId { get; set; }
        public string operatorName { get; set; }
        public decimal requestedAmount { get; set; }
        public decimal? discount { get; set; }
        public string discountCurrencyCode { get; set; }
        public string requestedAmountCurrencyCode { get; set; }
        public decimal deliveredAmount { get; set; }
        public string deliveredAmountCurrencyCode { get; set; }
        public string customIdentifier { get; set; }
        public DateTime transactionDate { get; set; }
        public BalanceDetails balanceInfo { get; set; }
        public string pinDetail { get; set; }
 
    }

    public class BalanceDetails
    {
        public decimal oldBalance { get; set; }
        public decimal newBalance { get; set; }
        public string currencyCode { get; set; }
        public string currencyName { get; set; }
        public DateTime updatedAt { get; set; }
    }
}
