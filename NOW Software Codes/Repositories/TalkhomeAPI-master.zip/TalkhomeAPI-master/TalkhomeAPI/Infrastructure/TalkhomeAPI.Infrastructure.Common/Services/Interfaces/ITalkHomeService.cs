﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface ITalkHomeService 
    {
        Task<GenericApiResponse<SignUpResponse>> SignUp(SignUpRequest request);
    }
}
