﻿using ATT.Models.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts
{
    // This class is used to return back the OperatorProductResponse in Json format.
    public class JsonOperatorProductResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public int errorCodeDtOne { get; set; }
        public int servcieproviderid { get; set; }
        public PayLoad payload { get; set; }
    }
    public class JsonATTCRMOperatorProductResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public int errorCodeDtOne { get; set; }
        public bool isRange { get; set; }
        public ATTCRMPayLoad ATTCRMpayload { get; set; }
    }
    public class PayLoad
    {
        public List<AttOperator> operators { get; set; }
    }
    public class ATTCRMPayLoad
    {
        public List<AttCRMOperator> operators { get; set; }
    }

    public class AttOperator
    {
        public string id { get; set; }
        public string name { get; set; }
        public string country { get; set; }
        public string nowtelTransactionReference { get; set; }
        public int routingType { get; set; }
        public string routingTypeName { get; set; }
        public string iconUri { get; set; }
        public List<AttProduct> products { get; set; }
        public int accessid { get; set; }
        public string ProductItemCode { get; set; }

    }

    public class AttCRMOperator
    {
        public string name { get; set; }
        public string country { get; set; }
        public List<AttProduct> products { get; set; }
    }

    public class AttProduct
    {
        public string clientccy { get; set; }
        public string receiverccy { get; set; }
        public string product { get; set; }
        public string itemPriceClientccy { get; set; }
        public string transactionfeeClientccy { get; set; }
        public string totalPriceClientccy { get; set; }
        public decimal discountPercentage { get; set; }
        public string orignalAmount { get; set; }

    }

    public class OperatorAndDBInsertStatus
    {
        public AttOperator attOperator;
        public int DBStatus { get; set; } // 1 for Success and 0 for Failure
        public string DBErrorSP { get; set; } // Error Stored Procedure Name
        public string DBErrorMessage { get; set; } // Error Message
    }

}
