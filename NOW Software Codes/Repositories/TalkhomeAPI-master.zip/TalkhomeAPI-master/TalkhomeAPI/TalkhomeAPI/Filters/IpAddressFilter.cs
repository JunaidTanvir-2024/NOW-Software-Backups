﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;

namespace TalkhomeAPI.Filters
{
    public class IpAddressFilter : IAsyncAuthorizationFilter
    {
        private readonly IpAddressConfig _ipAddressConfig;
        private readonly ILogger _logger;
        private readonly IAccountRepository _accountRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public IpAddressFilter(IOptions<IpAddressConfig> ipAddressConfig,
                                ILogger logger,
                                IAccountRepository accountRepository,
                                IHttpContextAccessor httpContextAccessor)
        {
            _ipAddressConfig = ipAddressConfig.Value;
            _logger = logger;
            _accountRepository = accountRepository;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            var httpContext = _httpContextAccessor.HttpContext;

            try
            {
                string IpAddress = "";
                httpContext.Request.EnableBuffering();

                StreamReader reader = new StreamReader(httpContext.Request.Body, Encoding.UTF8);

                string bodyString = await reader.ReadToEndAsync();
                httpContext.Request.Body.Position = 0;

                var path = httpContext.Request.Path.ToString().ToLower();
                switch (path)
                {
                    case "/api/account/login":
                        IpAddress = JsonConvert.DeserializeObject<LoginRequestModel>(bodyString).IpAddress;
                        break;
                    case "/api/account/verifypin":
                        IpAddress = JsonConvert.DeserializeObject<VerifyPinRequestModel>(bodyString).IpAddress;
                        break;
                    case "/api/account/resendpin":
                        IpAddress = JsonConvert.DeserializeObject<ReSendPinRequestModel>(bodyString).IpAddress;
                        break;
                    case "/api/account/signup":
                        IpAddress = JsonConvert.DeserializeObject<SignUpRequestModel>(bodyString).IpAddress;
                        break;
                    default:
                        break;
                }

                var response = await _accountRepository.IsValidIpAddress(
                        IpAddress, path, _ipAddressConfig.requestsLimit, _ipAddressConfig.requestsLimitMinutes, bodyString);
                if (response)
                {
                    await Task.CompletedTask;
                    return;
                }
                else
                {
                    ReturnForbiddenResult(context);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: IpAddressFilter, Method: OnAuthorizationAsync, " +
                                            $"Path: {httpContext.Request.Path.Value}" +
                                            $"Error_Message: {ex.Message}, StackTrace: {ex.StackTrace},");
                httpContext.Response.StatusCode = 500;
                await Task.CompletedTask;
                return;
            }
        }
        private void ReturnForbiddenResult(AuthorizationFilterContext context)
        {
            context.Result = new ForbidResult();
        }
    }
}
