﻿namespace Application.Features.Account.Product.MakeDefault;
public class DefaultProductRequest : IRequest<Result<IOrderedEnumerable<UserProductInfo>>>
{
    public string Msisdn { get; set; } = default!;
}
