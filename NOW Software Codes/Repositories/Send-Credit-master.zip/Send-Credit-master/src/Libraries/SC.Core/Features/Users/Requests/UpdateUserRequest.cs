﻿using System;
namespace SC.Core.Features.Users.Requests;
public class UpdateUserRequest : IRequest<IResultWrapper>
{
    public string UserID { get; init; } = default!;
    public string UserStatus { get; init; } = default!;
    public string UserToken { get; init; } = default!;
    public string TokenPurpose { get; init; } = default!;
    public UserTypeEnum UserType { get; set; } = default!;
}
public class UpdateUserRequestValidator : AbstractValidator<UpdateUserRequest>
{
    public UpdateUserRequestValidator()
    {
        RuleFor(x => x.UserID).NotNull().NotEmpty();
        RuleFor(x => x.UserStatus).NotNull().NotEmpty();
    }
}

