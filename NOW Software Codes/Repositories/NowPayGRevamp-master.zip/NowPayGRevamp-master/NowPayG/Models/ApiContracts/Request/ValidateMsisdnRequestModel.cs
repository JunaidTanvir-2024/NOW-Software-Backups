﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Request
{
    public class ValidateMsisdnRequestModel
    {
        public string Msisdn { get; set; }
    }
}
