﻿using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Request
{
    public class UserAddressRequestModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string County { get; set; }
        public string PostCode { get; set; }
        public int CountryId { get; set; }
        public AddressTypes AddressType { get; set; }
    }
}
