﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace TalkhomeAPI.Data.DbConnections
{
    public interface IDbConnectionSettings
    {
        IDbConnection SqlConnection { get; }
    }
}
