﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ThaPromotionsApi.Models.Configurations
{
    public class TransferToConfig
    {
        public string PromotionsApiEndPoint { get; set; }
    }
}
