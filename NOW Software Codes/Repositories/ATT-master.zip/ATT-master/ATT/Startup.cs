﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ATT.Infrastructure.BLL.Common;
using ATT.Infrastructure.BLL.Ding;
using ATT.Infrastructure.BLL.Mobiquity;
using ATT.Infrastructure.BLL.Reloadly;
using ATT.Infrastructure.BLL.Reloady;
using ATT.Infrastructure.BLL.Sms;
using ATT.Infrastructure.BLL.Sochitel;
using ATT.Infrastructure.BLL.TransferTo;
using ATT.Infrastructure.DAL;
using ATT.Infrastructure.DAL.SmsLogging;
using ATT.Middleware;
using ATT.Models.Configurations;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Serilog;
using Swashbuckle.AspNetCore.Swagger;

namespace ATT
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddSingleton((ILogger)new LoggerConfiguration()
             .MinimumLevel.Debug()
             .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "ATTAPI-log-{Date}.txt"))
             .CreateLogger());

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.Configure<TransferToConfig>(Configuration.GetSection("TransferTo"));
            services.Configure<ConnectionString>(Configuration.GetSection("ConnectionStrings"));
            services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));
            services.Configure<SochitelConfig>(Configuration.GetSection("Sochitel"));
            services.Configure<ReloadlyConfig>(Configuration.GetSection("Reloadly"));
            services.Configure<MobiquityConfig>(Configuration.GetSection("Mobiquity"));
            services.Configure<DingConfig>(Configuration.GetSection("Ding"));
            services.Configure<TwilioConfig>(options => Configuration.GetSection("TwilioConfig").Bind(options));
            services.Configure<SmtpConfig>(options => Configuration.GetSection("Smtp").Bind(options));
            services.Configure<HttpConfig>(options => Configuration.GetSection("HttpConfig").Bind(options));
            services.Configure<ServiceProviderConfig>(options => Configuration.GetSection("ServiceProviderConfig").Bind(options));
            services.Configure<SmsServiceConfig>(options => Configuration.GetSection("SmsServiceConfig").Bind(options));
            services.AddTransient<ITransfertoAutomation_BL, TransfertoAutomation_BL>();
            services.AddTransient<ITransfertoPost_BL, TransfertoPost_BL>();
            services.AddSingleton<ITransfertoAuth_BL, TransfertoAuth_BL>();
            services.AddTransient<ISochitelAutomation_BL, SochitelAutomation_BL>();
            services.AddTransient<ISochiPost_BL, SochiPost_BL>();
            services.AddSingleton<ISochiTelAuth_BL, SochiTelAuth_BL>();
            services.AddTransient<IAttDb_DL, AttDb_DL>();
            services.AddTransient<IReloadlyPost_BL, ReloadlyPost_BL>();
            services.AddTransient<IMobiquityPost_BL, MobiquityPost_BL>();
            services.AddTransient<IReloadlyAuth_BL, ReloadlyAuth_BL>();
            services.AddTransient<ICommon_BL, Common_BL>();
            services.AddTransient<IDingPost_BL, DingPost_BL>();
            services.AddTransient<IDingAuth_BL, DingAuth_BL>();
            services.AddTransient<IDataBundlesDb_DL, DataBundlesDb_DL>();
            services.AddTransient<ISmsLoggingRepository, SmsLoggingRepository>();
            services.AddTransient<ISmsSendingService, SmsSendingService>();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "ATT API",
                    Description = "ATT Api for Airtime Transfer.",
                    TermsOfService = "None",
                    Contact = new Contact() { Name = "ATT", Email = "hello@talkhomemobile.com", Url = "https://talkhome.co.uk/" }
                });
            });

            //services.AddDbContext<DatabaseContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseMiddleware<DogStatsDMiddleware>();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Pay360 API V1");
                });
            }
            else
            {
                app.UseHsts();
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Pay360 API V1");
                });
            }

            //app.UseHttpsRedirection();
            app.UseMvc();
           
        }
    }
}
