﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PushNotification
{
    class Program
    {

        static void Main(string[] args)
        {
            var message = ConfigurationManager.AppSettings["message"].ToString();
            var msisdn = "";

            try
            {
                string[] lines = File.ReadAllLines(@ConfigurationManager.AppSettings["file"].ToString());
                int x = lines.Length;
                THMService ths = new THMService();
                while (x > 0)
                {

                    Task.Run(async () =>
                    {
                        msisdn = lines[x - 1].Trim();

                        //msisdn = "447825152591";
                       // msisdn = "447495578501";

                        var token=await ths.GetAndroidAccount(msisdn);

                        if (token != null)
                            await SendFCM(message, msisdn);
                        else 
                             await Send(message, msisdn);

                        Thread.Sleep(100);

                        Console.WriteLine("Running.. '{0}{1}'.",
                                  Thread.CurrentThread.Name, msisdn);
                    }).Wait();

                    x--;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception... '{0}{1}'.",
                              Thread.CurrentThread.Name, ex.ToString());
            }



        }






















        //static void Main(string[] args)
        //{
        //    var message = ConfigurationManager.AppSettings["message"].ToString();
        //    var msisdn = "";

        //    try
        //    {
        //        string[] lines = File.ReadAllLines(@ConfigurationManager.AppSettings["file"].ToString());
        //        int x = lines.Length;
        //        while (x > 0)
        //        {

        //            Task.Run(async () =>
        //            {
        //                msisdn = lines[x - 1].Trim();

        //                msisdn = "447825152591";
        //                var ret = await Send(message, msisdn);

        //                Thread.Sleep(100);

        //                Console.WriteLine("Running.. '{0}{1}'.",
        //                          Thread.CurrentThread.Name, msisdn);
        //            }).Wait();

        //            x--;

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("Exception... '{0}{1}'.",
        //                      Thread.CurrentThread.Name, ex.ToString());
        //    }



        //}



        //static void Main(string[] args)
        //{
        //    //var message = ConfigurationManager.AppSettings["message"].ToString();
        //    var msisdn = "";

        //    try
        //    {
        //        ////string[] lines = File.ReadAllLines(@ConfigurationManager.AppSettings["file"].ToString());
        //        //int x = lines.Length;
        //        while (true)
        //        {

        //            Task.Run(async () =>
        //            {
        //                THMService ths = new THMService();

        //                //msisdn = "447825152591";
        //                //var ret = await Send(message, msisdn);
        //                await ths.GetThccPoints();


        //                Console.WriteLine("Running Points Daemon.");
        //            }).Wait();

        //            Console.WriteLine("Waiting...");
        //            Thread.Sleep(1000);

        //            Console.WriteLine("Starting new item.. ");
        //            //;

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("Exception... '{0}{1}'.",
        //                      Thread.CurrentThread.Name, ex.ToString());
        //    }



        //}








        //static void Main(string[] args)
        //{
        //    //var message = ConfigurationManager.AppSettings["message"].ToString();
        //    var msisdn = "";

        //    try
        //    {
        //        ////string[] lines = File.ReadAllLines(@ConfigurationManager.AppSettings["file"].ToString());
        //        //int x = lines.Length;
        //        while (true)
        //        {

        //            Task.Run(async () =>
        //            {
        //                THMService ths = new THMService();

        //                //msisdn = "447825152591";
        //                //var ret = await Send(message, msisdn);
        //                await ths.GetThccUserAccount();


        //                Console.WriteLine("Running.. '{0}{1}'.",
        //                          Thread.CurrentThread.Name, msisdn);
        //            }).Wait();

        //            //Thread.Sleep(100);

        //            Console.WriteLine("Starting new item.. ");
        //            //;

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("Exception... '{0}{1}'.",
        //                      Thread.CurrentThread.Name, ex.ToString());
        //    }



        //}

        static bool RunJob(string[] args)
        {
            int milliseconds = 1000;
            Thread.Sleep(milliseconds);

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n");
            return true;
        }

        public static async Task<int> SendFCM(string Message, string msisdn)
        {
            /**
             * 
             * 
             *  "to": "447495578501",
  "title": "TalkHome",
  "body": "This is test"
             * 
             * 
             */ 
            HttpClient client = new HttpClient
            {
                BaseAddress = new Uri("http://172.24.1.197:83/"),
            };

            client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
            client.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");
            //client.DefaultRequestHeaders.Authorization =
            //        new AuthenticationHeaderValue(
            //            "Basic",
            //            Convert.ToBase64String(Encoding.ASCII.GetBytes("447495578501:6069")));


            var body = JsonConvert.SerializeObject(new { to = msisdn, title = "TalkHome", body= Message }, new JsonSerializerSettings
            {
                ContractResolver = new DefaultContractResolver()
            });



            try
            {
                //ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; 
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3;
                var requestMessage = new HttpRequestMessage(HttpMethod.Post,
                    $"FCMPush/SendPush")
                {
                    Content = new StringContent(body, Encoding.UTF8, "application/json")
                };

                var result = await client.SendAsync(requestMessage);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured : " + ex.ToString());
            }
            return 0;
        }





        public static async Task<int> Send(string Message, string msisdn)
        {

            HttpClient client = new HttpClient
            {
                BaseAddress = new Uri("https://lab3.talkhomeapp.com/"),
            };

            client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
            client.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");
            client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue(
                        "Basic",
                        Convert.ToBase64String(Encoding.ASCII.GetBytes("447495578501:6069")));


            var body = JsonConvert.SerializeObject(new { messageTitle = "TalkHome", messageBody = Message }, new JsonSerializerSettings
            {
                ContractResolver = new DefaultContractResolver()
            });



            try
            {
                var requestMessage = new HttpRequestMessage(HttpMethod.Post,
                    $"push/notification/{msisdn}")
                {
                    Content = new StringContent(body, Encoding.UTF8, "application/json")
                };

                var result = await client.SendAsync(requestMessage);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured : " + ex.ToString());
            }
            return 0;
        }
    }
}

