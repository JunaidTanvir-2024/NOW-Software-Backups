﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBUKRates
    {
        public int Id { get; set; }
        public float Landline { get; set; }
        public float Data { get; set; }
        public float Mobile { get; set; }
        public float Text { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int CreatedBy { get; set; }
        public int LastUpdatedBy { get; set; }
        public string CreatedByUsername { get; set; }
        public string LastUpdatedbyUsername { get; set; }
        public bool IsActive { get; set; }
    }
}
