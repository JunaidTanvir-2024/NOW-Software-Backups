﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace PayPalInApp.Extensions.Html
{
    public static class CurrencyHelper
    {
        public static IHtmlContent GetSymbol(this IHtmlHelper htmlHelper, string code)
        {
            string symbol = "";
            switch (code)
            {
                case "EUR":
                    symbol = "&euro;";
                    break;
                case "USD":
                    symbol = "&dollar;";
                    break;
                case "GBP":
                    symbol = "&pound;";
                    break;
                default:
                    symbol = "&pound;";
                    break;
            }

            return new HtmlString(symbol);
        }
    }
}
