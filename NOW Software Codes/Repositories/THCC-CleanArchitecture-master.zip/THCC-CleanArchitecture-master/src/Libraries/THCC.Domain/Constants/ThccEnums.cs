namespace THCC.Domain.Constants;

public static class ThccEnums
{
    public enum ProductCode : byte
    {
        THCC = 1
    }
    public enum ProductItemCode : byte
    {
        THCC = 1,
        THRCC,
        THRCC_AUTO_TOPUP
    }
    public enum SocialLoginType : byte
    {
        Google = 1,
        Facebook = 2,
        Apple = 3
    }
    public enum EmailType : byte
    {
        ForgotPassword = 1,
        SignUp = 2,
        Payment = 3,
    }
    public enum OrderStatus : byte
    {
        Created = 1,
        Success,
        Failure
    }
    public enum OtpType : byte
    {
        ForgotPassword = 1,
        SignUp
    }
    public enum PaymentMethod : byte
    {
        Card = 1,
        Paypal = 2,
        Points = 3
    }
    public enum PaymentStatus : byte
    {
        Pending = 1,
        Success = 2,
        Failure = 3,
        Refunded = 4,
        Authorize = 5
    }
    public enum ProductType : byte
    {
        FastTopup = 1,
        AutoTopupEnable,
        Topup,
        CallingCard,
        RechargeableCallingCard,
        AutoTopupTransaction
    }
    public enum DeviceType
    {
        ios = 1,
        android = 2,
        amazon = 3,
        web = 4,
        open = 5,
        email = 6,
        sms = 7,
        wns = 8
    }
    public enum CEventChannelIdentifier
    {
        named_user_id = 1,
        ios_channel = 2,
        android_channel = 3,
        web_channel = 4,
        amazon_channel = 5,
        channel = 6
    }
}
