﻿namespace Application.Common.Enums;

public enum NowBasketItemType : byte
{
    FreeSimOrder = 1,
    Topup = 2,
    Bundle = 3,
    Discount = 4,
    AutoTopup = 5
}


