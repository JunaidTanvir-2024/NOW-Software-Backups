﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using ATTDaemon.Models;
using Dapper;
using ATTDaemon.Models.DB;

namespace ATTDaemon.Infrastructure.Repositories
{
    public class DaemonDB : IDaemonDB
    {
        private IDbConnection _db = new SqlConnection(ConfigurationManager.ConnectionStrings["SochiTelDB"].ConnectionString);

        public List<countries> getCountries()
        {
            string SqlString = "SELECT * FROM at_countries WHERE GetRates = 1";
            var ourCountries = (List<countries>)_db.Query<countries>(SqlString);

            return ourCountries;
        }


        public void insertOperator(int ServiceProviderOperatorID, int serviceProviderID, string currency, string Name, int CountryID, string iconUri, bool isFixed)
        {
            try
            {
                var p = new DynamicParameters();
                p.Add("@@ServiceProviderOperatorID", ServiceProviderOperatorID, dbType: DbType.Int16);
                p.Add("@serviceProviderID", serviceProviderID, DbType.Int16);
                p.Add("@currency", currency, DbType.String);
                p.Add("@Name", Name, DbType.String);
                p.Add("@CountryID", CountryID, dbType: DbType.Int16);
                p.Add("@iconUri", iconUri, dbType: DbType.String);
                p.Add("@isFixed", isFixed, dbType: DbType.Byte);

                _db.Execute("at_createOperator", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                //_loggerAPIAccess.Debug($"\"Database Error   Message:{ex.ToString()}");
            }
        }



        public void insertOperatorProductRate(int OperatorRecordID, float transactionfeeClientccy,float itemPriceClientccy,
           float totalPriceClientccy,string clientccy,string receiverccy, string product)
        {
            try
            {
                var p = new DynamicParameters();
                p.Add("@OperatorRecordID", OperatorRecordID, DbType.Int16);
                p.Add("@transactionfeeClientccy", transactionfeeClientccy, dbType: DbType.Decimal);
                p.Add("@itemPriceClientccy", itemPriceClientccy, dbType: DbType.Decimal);
                p.Add("@totalPriceClientccy", totalPriceClientccy, dbType: DbType.Decimal);
                p.Add("@clientccy", clientccy, dbType: DbType.String);
                p.Add("@receiverccy", receiverccy, dbType: DbType.String);
                p.Add("@product", product, dbType: DbType.String);

                _db.Execute("at_createOperatorProductsAndRates", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                //_loggerAPIAccess.Debug($"\"Database Error   Message:{ex.ToString()}");
            }
        }



        public at_Operators getOperatorRecord(int serviceProviderOperatorID, int serviceProviderID, string currency)
        {
            return _db.Query<at_Operators>("SELECT * FROM [at_Operators] WHERE serviceProviderOperatorID = @serviceProviderOperatorID and serviceProviderID = @serviceProviderID and currency = @currency", new { serviceProviderOperatorID = serviceProviderOperatorID, serviceProviderID = serviceProviderID, currency = currency }).SingleOrDefault();
        }



        public void deleteOperatorRatesRecords(int operatorRecordID)
        {
            _db.Query<at_Operators>("DELETE FROM [at_OperatorServiceProviderRates] WHERE operatorRecordID = @operatorRecordID", new { operatorRecordID = operatorRecordID}).SingleOrDefault();
        }


    }




}

