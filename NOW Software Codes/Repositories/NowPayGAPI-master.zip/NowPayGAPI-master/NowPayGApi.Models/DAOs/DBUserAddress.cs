﻿using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBUserAddress
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public bool IsDefaultAddress { get; set; }
        public string City { get; set; }
        public string County { get; set; }
        public string PostCode { get; set; }
        public int CountryId { get; set; }
        public string CountryName { get; set; }
        public AddressTypes AddressType { get; set; }
    }
}
