﻿using TransferHome.Models.Contracts.Service.Pay360ApiContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TransferHome.Models.Contracts.InAppModels;

namespace TransferHome.Infrastructure.Services.Interfaces
{
    public interface IPay360Service
    {
        Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Resume3DTransaction(Pay360Resume3DRequest request);
        Task<GenericPay360ApiResponse<Pay360CustomerResponseModel>> GetCustomer(Pay360CustomerRequestModel model);
        Task<GenericPay360ApiResponse<Pay360CardsResponse>> Pay360GetCards(Pay360CustomerRequestModel request);
        Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType);
        Pay360PaymentRequestToken CreatePay360PaymentRequestToken(Pay360StartPaymentRequestModel model);
        Pay360PaymentBase CreatePay360PaymentBaseRequest(StartPay360RequestModel model);
        Pay360PaymentRequestExistingNew CreatePay360PaymentRequestExistingNew(Pay360StartPaymentRequestModel model);
        Pay360PaymentRequestNew CreatePay360PaymentRequestNew(Pay360StartPaymentRequestModel model);
        Task<GenericPay360ApiResponse<string>> SetAutoTopUp(Pay360SetAutoTopUpRequest model);
        Task<GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(Pay360GetAutoTopUpRequest model);
        Task<GenericPay360ApiResponse<Models.Contracts.Service.Pay360ApiContracts.paymentMethodResponse>> SetCustomerDefaultCard(SetCustomerDefaultCardRequest model);
        Task<GenericPay360ApiResponse<string>> RemoveCard(RemoveCardRequest model);
    }
}
