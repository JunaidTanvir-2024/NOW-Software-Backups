﻿
$(document).ready(function () {

    //Get All Payment Methods
    ShowMyPaymentMethods_myPayment();

    //Set Default Card
    $('#BtnCnfrmDefault_myPayment').click(function () {

        if (!$('#SetDefaultCardForm').valid()) {
            return false;
        }
        else {
            $.ajax({
                url: "/Pay360/SetCustomerDefaultCard",
                type: "POST",
                data: { defaultCardCV2: $('#SecurityCode').val(), cardToken: $('#CardData_myPayment').val() },
                beforeSend: function (xhr) {

                    $('#BtnCnfrmDefault_myPayment,#BtnNoDefault_myPayment,#BtnCnfrmDefault_close_myPayment').attr('disabled', true);

                    $('#BtnCnfrmDefault_lbl_myPayment').hide();
                    $('#BtnCnfrmDefault_Spin_myPayment').show();

                },
                success: function (response) {

                    if (response != null) {
                        if (response.status == true) {

                            $('#CV2-popup-myPayment').modal('hide');
                            ShowMyPaymentMethods_myPayment();
                        }
                        else {
                            $('#CnfrmDefaultFailureMsg_myPayment').text(response.message);
                            $('#CnfrmDefaultFailureAlert_myPayment').slideDown().delay(4000).slideUp();
                        }
                    }
                    else {
                        $('#CnfrmDefaultFailureMsg_myPayment').text('Something went wrong on server.');
                        $('#CnfrmDefaultFailureAlert_myPayment').slideDown().delay(4000).slideUp();
                    }

                },
                complete: function (xhr, status) {

                    $('#BtnCnfrmDefault_Spin_myPayment').hide();
                    $('#BtnCnfrmDefault_lbl_myPayment').show();

                    $('#BtnCnfrmDefault_myPayment,#BtnNoDefault_myPayment,#BtnCnfrmDefault_close_myPayment').attr('disabled', false);

                },
                error: function (xhr, status, error) {
                    $('#CnfrmDefaultFailureMsg_myPayment').text('Something went wrong on server.');
                    $('#CnfrmDefaultFailureAlert_myPayment').slideDown().delay(4000).slideUp();
                }
            });
        }
    });

    //Remove Card
    $('#BtnRemoveCard_myPayment').click(function () {

        $.ajax({
            url: "/Pay360/RemoveCard",
            type: "POST",
            data: { cardToken: $('#CardData_myPayment').val() },
            beforeSend: function (xhr) {

                $('#BtnRemoveCard_myPayment,#BtnNoRemoveCard_myPayment,#BtnRemoveCard_close_myPayment').attr('disabled', true);

                $('#BtnRemoveCard_lbl_myPayment').hide();
                $('#BtnRemoveCard_Spin_myPayment').show();

            },
            success: function (response) {

                if (response != null) {
                    if (response.status == true) {

                        $('#RemoveCard-popup-myPayment').modal('hide');
                        ShowMyPaymentMethods_myPayment();
                    }
                    else {
                        $('#RemoveCardFailureMsg_myPayment').text(response.message);
                        $('#RemoveCardFailureAlert_myPayment').slideDown().delay(4000).slideUp
                    }
                }
                else {
                    $('#RemoveCardFailureMsg_myPayment').text('Something went wrong on server.');
                    $('#RemoveCardFailureAlert_myPayment').slideDown().delay(4000).slideUp();;
                }

            },
            complete: function (xhr, status) {

                $('#BtnRemoveCard_myPayment,#BtnNoRemoveCard_myPayment,#BtnRemoveCard_close_myPayment').attr('disabled', false);

                $('#BtnRemoveCard_lbl_myPayment').show();
                $('#BtnRemoveCard_Spin_myPayment').hide();

            },
            error: function (xhr, status, error) {

                $('#RemoveCardFailureMsg_myPayment').text('Something went wrong on server.');
                $('#RemoveCardFailureAlert_myPayment').slideDown().delay(4000).slideUp();

            }
        });

    });

    //Remove Default Card
    $('#BtnRemoveDefaultCard_myPayment').click(function () {

        $.ajax({
            url: "/Pay360/RemoveDefaultCard",
            type: "POST",
            data: { cardToken: $('#CardData_myPayment').val() },
            beforeSend: function (xhr) {

                $('#BtnRemoveDefaultCard_myPayment,#BtnNoRemoveDefaultCard_myPayment,#BtnRemoveDefaultCard_close_myPayment').attr('disabled', true);

                $('#BtnRemoveDefaultCard_lbl_myPayment').hide();
                $('#BtnRemoveDefaultCard_Spin_myPayment').show();

            },
            success: function (response) {

                if (response != null) {
                    if (response.status == true) {

                        $('#RemoveDefaultCard-popup-myPayment').modal('hide');
                        ShowMyPaymentMethods_myPayment();
                    }
                    else {
                        $('#RemoveDefaultCardFailureMsg_myPayment').text(response.message);
                        $('#RemoveDefaultCardFailureAlert_myPayment').slideDown().delay(4000).slideUp
                    }
                }
                else {
                    $('#RemoveDefaultCardFailureMsg_myPayment').text('Something went wrong on server.');
                    $('#RemoveDefaultCardFailureAlert_myPayment').slideDown().delay(4000).slideUp();;
                }

            },
            complete: function (xhr, status) {

                $('#BtnRemoveDefaultCard_myPayment,#BtnNoRemoveDefaultCard_myPayment,#BtnRemoveDefaultCard_close_myPayment').attr('disabled', false);

                $('#BtnRemoveDefaultCard_lbl_myPayment').show();
                $('#BtnRemoveDefaultCard_Spin_myPayment').hide();

            },
            error: function (xhr, status, error) {
                $('#RemoveDefaultCardFailureMsg_myPayment').text('Something went wrong on server.');
                $('#RemoveDefaultCardFailureAlert_myPayment').slideDown().delay(4000).slideUp();
            }
        });
    });

});

function ShowMyPaymentMethods_myPayment() {

    $.ajax({
        url: "/Pay360/GetMyPaymentMethods",
        type: "GET",
        beforeSend: function (xhr) {
            $('.loading-bar').show();
        },
        success: function (response) {

            if (response != null) {

                if (response.status == true) {

                    var cardsHtML = '';

                    $('#MyPayments_DefaultCard_MaskedPan').html('');
                    $('#MyPayments_OtherCardsContent').html('');

                    $.each(response.data.paymentMethodResponses, function (key, val) {

                        if (val.isPrimary) {
                            var defaultcardHtml = "<div class=\"form-row paymentcard\">" +
                                "<div class=\"col-12 col-sm-5\">" +
                                "<div class=\"form-group\">" +
                                "<i class=\"fab fa-cc-" + val.card.cardScheme.toLowerCase() + "\"></i> " + "<label>" + val.card.maskedPan + "</label>" +
                                "</div>" +
                                "</div>" +
                                "<div class=\"col-12 col-sm-7\" > " +
                                "<button data-token=" + val.card.cardToken + " type=\"button\" onclick=\"SetRemoveDefaultCardValues_myPayment(this)\" class=\"btn btn-primary-3\">Remove</button>" +
                                "</div>" +
                                "</div>";

                            $('#MyPayments_DefaultCard_MaskedPan').html(defaultcardHtml);
                        }
                        else {
                            cardsHtML += "<div class=\"form-row paymentcard\">" +
                                "<div class=\"col-12 col-sm-5\">" +
                                "<div class=\"form-group\">" +
                                "<i class=\"fab fa-cc-" + val.card.cardScheme.toLowerCase() + "\"></i> " + "<label>" + val.card.maskedPan + "</label>" +
                                "</div>" +
                                "</div>" +
                                "<div class=\"col-12 col-sm-7\" > " +
                                "<button type=\"button\" class=\"btn btn-primary-3\" onclick=\"SetCardValuesAsDefult_myPayment(this)\" data-token=" + val.card.cardToken + ">Set Default Card</button> <button data-token=" + val.card.cardToken + " type=\"button\" onclick=\"SetRemoveCardValues_myPayment(this)\" class=\"btn btn-primary-3\">Remove</button>" +
                                "</div>" +
                                "</div>";
                        }

                    })
                    $('#MyPayments_OtherCardsContent').html(cardsHtML);
                }
                else {
                    $('#MyPayments_DefaultCard_MaskedPan').html('');
                    $('#MyPayments_OtherCardsContent').html('');
                }
            }
            else {
                $('#MyPayments_DefaultCard_MaskedPan').html('');
                $('#MyPayments_OtherCardsContent').html('');
            }

        },
        complete: function (xhr, status) {
            $('.loading-bar').hide();
        },
        error: function (xhr, status, error) {
            $('#MyPayments_DefaultCard_MaskedPan').html('');
            $('#MyPayments_OtherCardsContent').html('');
        }
    });


}

function SetCardValuesAsDefult_myPayment(control) {

  
    $('#CardData_myPayment').val($(control).data("token"));

    $('#CV2-CardNumber-myPayment').html($(control).parent().parent().children()[0].children[0].innerHTML);

    ResetForm('SetDefaultCardForm');

    $('#CV2-popup-myPayment').modal('show');

    $('body').css('padding-right', 0);
}

function SetRemoveCardValues_myPayment(control) {

    $('#CardData_myPayment').val($(control).data("token"));

    $('#RemoveCard-CardNumber-myPayment').html($(control).parent().parent().children()[0].children[0].innerHTML);

    $('#RemoveCard-popup-myPayment').modal('show');

    $('body').css('padding-right', 0);

}

function SetRemoveDefaultCardValues_myPayment(control) {

    $('#CardData_myPayment').val($(control).data("token"));

    $('#RemoveDefaultCard-CardNumber-myPayment').html($(control).parent().parent().children()[0].children[0].innerHTML);

    $('#RemoveDefaultCard-popup-myPayment').modal('show');

    $('body').css('padding-right', 0);
}

function SecurityCode_Validation_myPayment(evt) {

    var theEvent = evt || window.event;
    var TotalLength = $("#" + evt.currentTarget.id).val().length;


    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }

    var regex = /[0-9]/;

    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }

    // length
    if (TotalLength >= 4) {
        theEvent.returnValue = false;
        theEvent.preventDefault();
    }
}