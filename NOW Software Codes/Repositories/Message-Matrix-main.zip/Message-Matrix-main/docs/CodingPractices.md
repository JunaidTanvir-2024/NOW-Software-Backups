# Practices for Fusion-Hub Code Quality 
###### Last Updated: (02-10-2023)

Here are coding practices for maintaining code quality in Fusion-Hub:

1. **Remove Unused Code and namspaces**
   - Always clean up your codebase by removing unused using statements and unnecessary code.

2. **Null Checking**
   - Perform null checks where applicable to prevent Null Reference Exceptions during runtime.

3. **Follow Naming Conventions**
   - Adhere to naming conventions consistently throughout your codebase.
   - Follow these naming conventions [Naming Conventions](#naming-conventions)

1. **Code Reusability**
   - Extract reusable methods and create generic functions to avoid code duplication.

2. **Code Consistency**
   - Use var instead of explict type to maintain consistency.

3. **Code Readability**
   - Write code that is easy for other developers to understand.

4. **Dispose of Unmanaged Resources**
   - Properly manage unmanaged resources, such as file I/O and network resources, using using blocks.

5. **Exception Handling and Logging**
   - Implement robust exception handling using try/catch/finally blocks and log exceptions for debugging purposes.

6.  **Method Length**
    - Keep methods concise, generally not exceeding 30-40 lines of code.

7.  **Avoid Nesting**
    - Minimize nested loops and conditional statements to improve code readability.


11. **Unit Testing**
    - Write developer test cases and perform unit testing to catch basic issues before QA testing.

12. **Access Specifiers**
    - Choose access specifiers (e.g., private, public, internal) according to the required scope.

13. **Interfaces**
    - Implement interfaces and depedency injection to decouple components and promote low coupling.

14. **Class Modifiers**
    - Mark classes as sealed, static, or abstract based on their intended usage.
    - By default every class should be sealed

15. **Stringbuilder Usage**
    - Use StringBuilder for efficient string concatenation to reduce memory overhead.

16. **Remove Unreachable Code**
    - Identify and eliminate unreachable code segments.

17. **Method Comments**
    - Add comments to describe the purpose, input types, and return types of methods.

18. **Performance Monitoring**
    - Utilize tools like Fiddler to analyze HTTP/network traffic and measure web application and service performance.

19. **Constants and Readonly**
    - Use constants and readonly keywords for values that should not change.

20. **Minimize Type Casting**
    - Avoid unnecessary type casting and conversions to improve performance.

21. **Memory Leak Detection**
    - Regularly check for memory leaks in your code and fix any identified issues.

22. **Security**
    - Implement security measures to prevent cross-scripting attacks, SQL injection, and other vulnerabilities.

23. **Avoid Default Keyword**
    - Refrain from using the 'default' keyword for known types (e.g., int, decimal) unless dealing with generic types.

24. **Avoid 'out' and 'ref' Keywords**
    - Minimize the use of 'out' and 'ref' keywords, following Microsoft's guidelines for code analysis.

## Naming Conventions
- **Solution Name**: Pascal Case
- **Project Name**: Pascal Case
- **Folder Name**: Pascal Case
- **Namespace Name**: Pascal Case
- **Class Name**: Pascal Case(use PascalCasing for abbreviations 3 characters or more, use Noun or Noun Phrase for name, e.g., Employee, BusinessLocation)
- **Property Name**: Pascal Case
- **Private Class Variable Injectable**: `_camelCase`
- **Function Name**: Pascal Case
- **Method Arguments**: Camel Case
- **Use of Enums in the right way**
- **Avoid direct string comparison; use enum for that**
- **Do not use underscore in identifiers**
    -**Correct**: `DateTime clientAppointment;`
    -**Avoid**: `DateTime client_Appointment;`

- **Local Variables**: Camel Case
    -**Correct**: `int counter;`
    -**Avoid**: `int iCounter;`

- **Use implicit type `var` for local variable declarations**
    - **Example**: 
```csharp
				var stream = File.Create(path);
				var customers = new Dictionary();
```
- **Use the letter "I" for interface name prefix**
```csharp
		public interface IShape{}
```
- **Organize namespaces with a clearly defined structure**
    -- Use filescoped namespace instead of blocked namespace.
	  -**Correct**: `namespace Company.Product.Module.SubModule;`
    -**Avoid**: `namespace Company.Product.Module.SubModule {}`
		
- **Code should be properly indented**