using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;

namespace FH.UseCases.Categories;

public class GetSubCatgories
{
    #region Query

    public sealed record Query : IRequest<IResultWrapper>
    {
        public string? CategoryAliasName { get; set; }
    }

    #endregion Query

    #region Validator

    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.CategoryAliasName).NotEmpty()
                                                            .NotNull();
        }
    }

    #endregion Validator

    #region Response

    public sealed record Response
    {
        public string? CategoryAliasName { get; set; }
        public SubCategory? SubCategoryObj { get; set; }

        public sealed record SubCategory
        {
            public long SubCategoryId { get; set; }
            public string? SubCategoryName { get; set; }
            public string? SubCategoryShortCode { get; set; }
            public string? SubCategoryDescription { get; set; }
        }
    }

    #endregion Response

    #region Handler

    public sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IMapper _mapper = mapper;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var getSubCategoryRequest = _mapper.Map<SubCategoryDto.Request>(request);

            // Assigning Default Values
            getSubCategoryRequest.IsActive = true;
            getSubCategoryRequest.IsDeleted = false;

            var subCategoriesDto = await _unitOfWork.CategoryRepository.GetSubCategoryName(getSubCategoryRequest);

            var subCategories = _mapper.Map<IEnumerable<Response>>(subCategoriesDto);

            if (subCategories is null)
            {
                ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
            }

            return ResultWrapper.Success(subCategories);
        }
    }

    #endregion Handler
}
