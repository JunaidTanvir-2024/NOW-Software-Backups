using DC.Core.Common.DependencyResolver;
using DC.Core.Common.Entities;


namespace DC.Core.Common.Interfaces.Database;

public interface IAppLoggerRepository : ServiceType.IScoped
{
    Task AppLogUpsertAsync(AppLogEntity logDto);
    Task VendorLogInsertAsync(VendorLogEntity vendorLogDto);
}
