﻿namespace Models.Contracts.PaypalApiContracts
{
	public class PaypalPaymentResponse
	{
		public string RedirectUrl { get; set; }
		public string TransactionId { get; set; }
		public bool IsSuccess { get; set; }
		public int ErrorCode { get; set; }
		public string ErrorMessage { get; set; }
		public string SubscriptionId { get; set; } = string.Empty;
	}
}
