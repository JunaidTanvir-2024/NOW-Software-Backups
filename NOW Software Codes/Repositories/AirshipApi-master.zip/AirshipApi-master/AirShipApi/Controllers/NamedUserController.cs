﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts;
using Models.Contracts.Airship.Request;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;

namespace AirShipApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class NamedUserController : ControllerBase
    {

        private readonly ILogger Logger;
        private INamedUser_BL NUserBl;

        public NamedUserController(ILogger logger, INamedUser_BL nUserBl)
        {
            Logger = logger;
            NUserBl = nUserBl;
        }

        [HttpPost]
        [Route("Channel/Association")]
        public async Task<IActionResult> NuserChannelAssociation(NUserChannelAssocRequest request)
        {

           
            try
            {                
                var response = await NUserBl.NUserChannelAssociation(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUserController, Method: NuserChannelAssociation, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("Channel/Disassociation")]
        public async Task<IActionResult> NuserChannelDisassociation(NuserChannelDisassociationRequest request)
        {


            try
            {
                var response = await NUserBl.NuserChannelDisassociation(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUserController, Method: NuserChannelDisassociation, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("Channel/WebAssociation")]
        public async Task<IActionResult> WebNUserChannelAssociation(WebNUserChannelAssociationRequest request)
        {
            try
            {
                var response = await NUserBl.WebNUserChannelAssociation(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUserController, Method: WebNUserChannelAssociation, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("EmailAssociationWithNamedUser")]
        public async Task<IActionResult> EmailAssociationWithNamedUser(EmailAssociationWithNamedUserRequest request)
        {
            try
            {
                var response = await NUserBl.EmailAssociationWithNamedUser(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUserController, Method: EmailAssociationWithNamedUser, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }
        
        [HttpPost]
        [Route("DisassociateEmailChannelFromNamedUser")]
        public async Task<IActionResult> DisassociateEmailChannelFromNamedUser(DisassociateEmailChannelFromNamedUserRequest request)
        {
            try
            {
                var response = await NUserBl.DisassociateEmailChannelFromNamedUser(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUserController, Method: DisassociateEmailChannelFromNamedUser, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }


        [HttpPost]
        [Route("AddNuserTags")]
        public async Task<IActionResult> AddNuserTags(AddNUserTagsRequest request)
        {


            try
            {
                var response = await NUserBl.AddNUserTags(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUserController, Method: AddNuserTags, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }
        [HttpPost]
        [Route("GetNamedUserById")]
        public async Task<IActionResult> GetUserNameById(GetUserByIdRequest request)
        {


            try
            {
                var response = await NUserBl.GetNamedUserById(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUserController, Method: GetUserNameById, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<ApiGetUserByIdResponse>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("GetNamedUsers")]
        public async Task<IActionResult> GetUserNames(GetAllNamedUsersRequest request)
        {


            try
            {
                var response = await NUserBl.GetNamedUsers(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUserController, Method: GetUserNames, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<ApiGetNamedUsersResponse>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

    }
}