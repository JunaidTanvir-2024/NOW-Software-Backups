﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.DAOs;
using TrasnferHome.Models.Utility;

namespace TransferHome.Infrastructure.DAL.Interfaces
{
    public interface IDL_Transfer
    {
        Task<DBProduct> GetProductByNowtelTransactionReference(string guid, string product);
        Task<int> SaveTransferTransaction(DBTransferTransactions model);
        Task<int> UpdateTransferTransaction(DBTransferTransactions model);
        Task<int> DebitUserBalance(DbDebit model);
        Task<decimal> CreditUserBalance(DBCredit model);
        Task<int> SaveTwoFactorAuthenticationToken(DBTwoFactorAuthenticationToken model);
        Task<int> VerifyTwoFactorToken(DBTwoFactorAuthenticationToken model);
        Task<int> SaveAutoTransferSettings(DBAutoTransfer model);
        Task<IEnumerable<DBAutoTransfer>> GetUserAutoTransferNumbers(int userId);
        Task<DBAutoTransfer> UpdateAutoTransferStatus(int id, bool status, int userId);
        Task<int> RemoveAutoTransferNumber(int id, int userId);
        Task<int> UpdateAutoTransferSettings(UpdateAutoTransferSettingsRequestModel model, int userId);
        Task<int> ValidateTransferRequest(int userId, decimal amount);
    }
}