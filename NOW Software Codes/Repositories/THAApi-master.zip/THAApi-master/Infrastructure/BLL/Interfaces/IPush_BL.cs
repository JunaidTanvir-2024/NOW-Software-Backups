﻿using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Request;
using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IPush_BL
    {
        Task<bool> SendNotification(string msisdn, PushPayload payload);
        Task<GenericApiResponse<string>> GetFCMToken(string msisdn);
        Task<GenericApiResponse<APNSToken>> GetAPNSToken(string msisdn);
        Task<GenericApiResponse<FcmPushPayload>> SendFCMPush(FCMPushRequest request);
        Task<GenericApiResponse<ApnsPayload>> SendAPNSPush(APNSPushRequest request);
    }
}
