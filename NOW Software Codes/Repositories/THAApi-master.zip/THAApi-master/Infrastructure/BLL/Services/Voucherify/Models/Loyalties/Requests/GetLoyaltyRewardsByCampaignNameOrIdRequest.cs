﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Loyalties.Requests
{
    public class GetLoyaltyRewardsByCampaignNameOrIdRequest
    {
        public string? CampaignNameOrId { get; set; }
    }
}
