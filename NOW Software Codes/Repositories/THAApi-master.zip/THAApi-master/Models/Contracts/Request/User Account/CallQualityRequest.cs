﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.User_Account
{
    public class CallQualityRequest
    {
        public string call_id { get; set; }
        public bool is_somme_user { get; set; }
        public decimal mos { get; set; }
        public int user_call_rating { get; set; }
        public decimal avg_jitter { get; set; }
        public decimal avg_lat { get; set; }
        public decimal pkt_loss { get; set; }
        public decimal rFactor { get; set; }

    }
}
