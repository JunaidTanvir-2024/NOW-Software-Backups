﻿using Application.Features.Bundle.Model;
using Application.Features.Bundle.SimBundle;
using Application.Features.Bundle.SuggestedBundle;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Bundle.RoamingBundle;

public class RoamingBundleRequestHandler : IRequestHandler<RoamingBundleRequest, Result<List<BundleInfo>>>
{
    #region Fields

    private readonly IUnitOfWork _unitOfWork;
    private readonly IStringLocalizer<SimBundleRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly IUserService _userService;

    #endregion

    #region Ctors

    public RoamingBundleRequestHandler(
        IUnitOfWork unitOfWork,
        IStringLocalizer<SimBundleRequestHandler> localizer,
        IMapper mapper,
        IUserService userService)
    {
        _unitOfWork = unitOfWork;
        _localizer = localizer;
        _mapper = mapper;
        _userService = userService;
    }

    #endregion

    #region Methods

    public async Task<Result<List<BundleInfo>>> Handle(RoamingBundleRequest request, CancellationToken cancellationToken)
    {
        var bundles = _mapper.Map<List<BundleInfo>>(await _unitOfWork.BundleRepo.GetRoamingBundles(request));
        return Result<List<BundleInfo>>.Success(bundles, _localizer[CustomStatusKey.Success]);
    }
    #endregion
}