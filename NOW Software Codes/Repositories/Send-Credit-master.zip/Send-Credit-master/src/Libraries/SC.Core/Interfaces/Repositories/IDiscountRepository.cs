﻿namespace SC.Core.Interfaces.Repositories
{
    public interface IDiscountRepository
    {
        Task<IEnumerable<DiscountDto.Response>> GetDiscounts(DiscountDto.Request request);
        Task<long> GetNoOfCustomersDiscountAvailedAsync(string? customerID, int DiscountTypeID);
        Task<float> GetTotalOrderDiscountAmountByDiscountTypeID(string? customerID, int DiscountTypeID);
    }
}