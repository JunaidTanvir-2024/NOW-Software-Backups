﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Configurations
{
    public class ConnectionString
    {
        public string DigitalkDbConnection { get; set; }
        public string TalkHomeAppDbConnection { get; set; }
        public string ATTDbConnection { get; set; }
        public string TalkHomeAppsAccountsDbConnection { get; set; }
        public string ThaConnection { get; set; }
        public string DefaultConnection { get; set; }
    }
}
