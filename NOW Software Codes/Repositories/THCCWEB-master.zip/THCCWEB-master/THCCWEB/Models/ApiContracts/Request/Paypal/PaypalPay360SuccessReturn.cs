﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request.Paypal
{
    public class PaypalPay360SuccessReturn
    {
        public string uRef { get; set; }
        public string paymentId { get; set; }
        public string token { get; set; }
        public string PayerID { get; set; }
        public string ProductCode { get; set; }
        public string TransectionAmmount { get; set; }
        public string ProductItemCode { get; set; }
        public string Email { get; set; }
        public string PageRedirect { get; set; }
        public string CardNumber { get; set; }
        public string Pin { get; set; }
    }
}
