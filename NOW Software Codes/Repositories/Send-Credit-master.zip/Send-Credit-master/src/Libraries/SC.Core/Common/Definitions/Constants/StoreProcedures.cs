﻿namespace SC.Core.Common.Definitions.Constants;

public static partial class AppConstants
{
    public static class StoreProcedures
    {
        public const string AppLogUpsert = "sc_app_log_uppsert";
        public const string VendorLogInsert = "vndr_vendor_log_insert";
        public const string UserLoginLogInsert = "sc_user_login_insert";
        public const string UserLoginAttempsCount = "sc_user_login_attemps_count";
        public const string UserUpdate = "sc_user_detail_update";
        public const string OrderCreation = "sc_customer_order_insert";
        public const string CartCreation = "sc_customer_cart_insert";
        public const string RemoveProdcutfromCart = "sc_customer_cart_remove";
        public const string CustomerCartInfoInsert = "sc_customer_cart_info_insert";
        public const string GetUserDetail = "sc_user_detail_get";
        public const string GetCustomerCart = "sc_customer_cart_get";
        public const string GetCustomerOrder = "sc_customer_order_get";
        public const string CustomerAddressInsert = "sc_customer_address_insert";
        public const string GetPaymentMethods = "sc_payment_method_get";
        public const string GetCustomerOrderDetail = "sc_customer_order_detail_get";
        public const string OrderPaymentInsert = "sc_order_payment_insert";
        public const string UserAccountDetailUpdate = "sc_user_account_update";
        public const string CustomerCardInsert = "sc_customer_card_insert";
        public const string CustomerCardGet = "sc_customer_card_get";
        public const string CustomerCardRemove = "sc_customer_card_remove";
        public const string CustomerCardMarkDefault = "sc_customer_card_mark_default";
        public const string GetDiscount = "dbo.sc_discount_get";
        public const string GetContactPersons = "dbo.sc_contact_person_get";
        public const string InsertContactPerson = "dbo.sc_contact_person_insert";
        public const string UpdateContactPerson = "dbo.sc_contact_person_update";
        public const string DeleteContactPerson = "dbo.sc_contact_person_delete";
        public const string GetCustomerOrders = "sc_customer_orders_get";
        public const string CheckValidUserID = "sc_check_valid_userid";
        public const string CreateUserAsGuest = "sc_guest_user_create";
        public const string MigrateGuestData = "sc_migrate_guest_data";
        public const string GetFaqByOperator = "sc_faq_by_Operator_get";
        public const string GetOrderIDByTransactionID = "sc_customer_order_id_by_transactionid";
        public const string UpdateCustomerCart = "sc_order_cart_update";
        public const string GetServiceFeeConfiguration = "sc_service_fee_configuration_get";
        public const string GetTotalCustomersDiscountAvailed = "sc_customer_discount_avail_count";
        public const string GetTotalDiscountAmountByDiscountTypeID = "sc_get_total_discount_by_discountTypeId";
        public const string GetOrderLimitConfiguration = "sc_order_limit_configuration_get";
        public const string GetTotalOrderAmountPerDay = "sc_get_total_order_amount_per_day";
        public const string CartFinalStatusUpdate = "sc_cart_final_status_update";
    }
}