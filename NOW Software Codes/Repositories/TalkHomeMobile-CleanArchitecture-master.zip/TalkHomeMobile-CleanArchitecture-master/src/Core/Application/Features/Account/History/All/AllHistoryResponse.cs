﻿using Application.Features.Account.History.Models;

namespace Application.Features.Account.History.All;

public class AllHistoryResponse
{
    public IEnumerable<CallHistoryInfo> CallHistory { get; set; } = new List<CallHistoryInfo>();
    public IEnumerable<SmsHistoryInfo> SmsHistory { get; set; } = new List<SmsHistoryInfo>();
    public IEnumerable<DataHistoryInfo> DataHistory { get; set; } = new List<DataHistoryInfo>();
    public IEnumerable<PaymentHistoryInfo> PaymentHistory { get; set; } = new List<PaymentHistoryInfo>();
}
