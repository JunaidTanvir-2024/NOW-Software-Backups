using Microsoft.AspNetCore.Mvc;
namespace CH.Api.Features.DTOne;

public static class DTOneEndpoints
{
    private const string EndpointTag = "DTOne Endpoints";
    private const string EndpointPrefix = "/api/dtone";

    public static void AddDTOneEndpoints(this WebApplication app)
    {
        var campaignEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);
        campaignEndpoints.MapPost("/Transaction", TransactionCallback);
    }

    private static async Task TransactionCallback([FromBody] object request, IDTOneHandler dTOneHandler)
    {
        await dTOneHandler.DTOneTransactionCallback(request);
    }
}
