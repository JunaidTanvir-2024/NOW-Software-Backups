﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Models.Pay360ApiContracts;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class AccountSummaryResponseModel
    {
        public IEnumerable<CallHistoryResponseModel> CallHistory { get; set; }
        public IEnumerable<GetTopUpPaymentHistoryResponseModel> PaymentHistory { get; set; }
        public IEnumerable<GetInternationalTopUpHistoryResponseModel> TopUpHistory { get; set; }
        public Pay360CardsResponse UserPay360Cards { get; set; }
        public Pay360GetAutoTopUpResponse Autotopupsettings { get; set; }

    }
}
