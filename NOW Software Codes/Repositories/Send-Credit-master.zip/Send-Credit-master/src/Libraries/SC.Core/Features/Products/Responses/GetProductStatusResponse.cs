﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SC.Core.Features.Products.Responses;
public sealed class GetProductStatusResponse
{
    [JsonPropertyName("isActive")]
    public string IsActive { get; set; } = default!;
    [JsonPropertyName("product")]
    public ProductInfo Product { get; set; } = default!;
    public sealed record ProductInfo
    {
        [JsonPropertyName("id")]
        public long Id { get; set; } = default!;
        [JsonPropertyName("vendorCode")]
        public string VendorCode { get; set; } = default!;
        [JsonPropertyName("nameAlias")]
        public string NameAlias { get; set; } = default!;
        [JsonPropertyName("operator")]
        public OperatorInfo Operator { get; set; } = default!;
        [JsonPropertyName("category")]
        public CategoryInfo Category { get; set; } = default!;
        [JsonPropertyName("subCategory")]
        public SubCategoryInfo SubCategory { get; set; } = default!;

        public record OperatorInfo
        {
            [JsonPropertyName("id")]
            public long Id { get; set; } = default!;
            [JsonPropertyName("nameAlias")]
            public string NameAlias { get; set; } = default!;
        }
        public sealed record CategoryInfo
        {
            [JsonPropertyName("id")]
            public long Id { get; set; } = default!;
            [JsonPropertyName("name")]
            public string Name { get; set; } = default!;
        }
        public sealed record SubCategoryInfo
        {
            [JsonPropertyName("id")]
            public long Id { get; set; } = default!;
            [JsonPropertyName("name")]
            public string Name { get; set; } = default!;
        }
    }
}

