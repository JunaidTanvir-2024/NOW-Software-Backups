using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class GiftCreate
{
    [JsonPropertyName("amount")]
    public long Amount { get; set; }
}
