using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.IO;
using THAAPI.Filters;
using THAAPI.Utilities;
using PhoneNumbers;
using THAApi.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Binders;
using Microsoft.AspNetCore.Localization;
using System.Globalization;
using System.Collections.Generic;
using Microsoft.Extensions.Localization;
using THAApi.Resources;
using THAApi.Utilities;
using Infrastructure;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;
using Serilog;
using Microsoft.Extensions.Options;
using Sentry.Serilog;

namespace THAAPI
{
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{

			services.AddLocalization();
            //I have registered this service so that we can use global level localization
            services.AddScoped<IStringLocalizer, StringLocalizer<Language>>();
			services.AddHttpContextAccessor();
			services.AddControllersWithViews(config =>
			{
				config.Filters.Add<BasicPinAuthenticationFilter>();
				config.Filters.Add<LanguageFilter>();
				config.ModelBinderProviders.RemoveType<DateTimeModelBinderProvider>();
			})
				.AddJsonOptions(options =>
			{
				options.JsonSerializerOptions.Converters.Add(new DateTimeConverter());
				options.JsonSerializerOptions.IgnoreNullValues = true;
			});
			//Setup Serilog File logging and Sentry logging
			services.AddSentry();
			
			services.AddSingleton((ILogger)new LoggerConfiguration()
						.MinimumLevel.Debug()
						.WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "THAAPI-log-{Date}.txt"))
						.WriteTo.Sentry(options=> Configuration.Bind("Sentry", options))
						.CreateLogger());

			services.RegisterAppSettingsConfig(Configuration);
			services.AddSingleton(PhoneNumberUtil.GetInstance());
			services.RegisterBLServices(Configuration);
			services.RegisterDLServices();
			services.AddSwaggerGen(c =>
			{
				c.SwaggerDoc("v1", new OpenApiInfo { Title = "THA Api", Version = "v1" });
				c.SwaggerDoc("v2", new OpenApiInfo { Title = "THA Api", Version = "name: v2" });
				c.AddSecurityDefinition("Bearer Token", new OpenApiSecurityScheme
				{
					Name = "Bearer Token",
					Description = null,
					In = ParameterLocation.Header,
					Type = SecuritySchemeType.Http,
					Scheme = "Bearer",
				});
				c.AddSecurityDefinition("Basic Auth", new OpenApiSecurityScheme
				{
					Name="Basic Auth",
					In=ParameterLocation.Header,
					Type = SecuritySchemeType.Http,
					Scheme="Basic",
				});
				c.OperationFilter<SwaggerAuthFilters>();
			});
			services.AddApiVersioning(options =>
			{
				options.ReportApiVersions = true;
				options.AssumeDefaultVersionWhenUnspecified = true;
				options.DefaultApiVersion = new ApiVersion(1, 0);
				options.ApiVersionReader = new UrlSegmentApiVersionReader();
				options.UseApiBehavior = true;
			});
			services.AddVersionedApiExplorer(options =>
			{
				options.GroupNameFormat = "'v'VVV";
				options.SubstituteApiVersionInUrl = true;
			});
		}
		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
		{
            app.UseSentryTracing();

            if (env.IsDevelopment() || env.IsStaging())
			{
				app.UseDeveloperExceptionPage();
				app.UseSwagger();
				app.UseSwaggerUI(c =>
				{
					c.SwaggerEndpoint(url: "/swagger/v1/swagger.json", "THA v1");
					c.SwaggerEndpoint("/swagger/v2/swagger.json", "THA v2");
				});
			}
			app.UseMiddleware<CustomExceptionHandler>();
			app.UseStaticFiles();

			var supportedCultures = new List<CultureInfo>()
			{
			   new CultureInfo("el"),
			   new CultureInfo("nl"),
			   new CultureInfo("de"),
			   new CultureInfo("fr"),
			   new CultureInfo("en"),
			   new CultureInfo("es"),
			   new CultureInfo("sv"),
			   new CultureInfo("it"),
			   new CultureInfo("nb"),
			   new CultureInfo("pt"),
			   new CultureInfo("tr"),
			   new CultureInfo("fil"),
			   new CultureInfo("vi")
			};

			foreach (var culture in supportedCultures)
			{
				culture.NumberFormat.NumberDecimalSeparator = ".";
			}	

			app.UseRequestLocalization(new RequestLocalizationOptions
			{
				DefaultRequestCulture = new RequestCulture("en"),
				// Formatting numbers, dates, etc.
				SupportedCultures = supportedCultures,
				// UI strings that we have localized.
				SupportedUICultures = supportedCultures
			});
			app.UseRouting();
			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllers();
				endpoints.MapDefaultControllerRoute();
			});
		}
	}
}
