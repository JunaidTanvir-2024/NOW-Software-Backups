﻿namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DeleteAccountReasonResponseModel
    {
        public int Id { get; set; }
        public string Reason { get; set; }
    }
}
