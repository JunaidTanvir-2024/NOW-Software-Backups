﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class PaypalRequestModel
    {
        public string EmailAddress { get; set; }
        public float Amount { get; set; }
        public string Msisdn { get; set; }
        public CheckOutTypes CheckoutPaymentType { get; set; }
        public string IPAddress { get; set; }
        public string Currency { get; set; }
    }
}
