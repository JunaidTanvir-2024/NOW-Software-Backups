﻿using SC.Core.Features.Operators;
using SC.Core.Vendors.Notification.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Notification.Request;
public sealed class SendNotificationRequest : IRequest<SendNotificationResponse>
{
    public string To { get; set; } = default!;
    public string EmailBody { get; set; } = default!;
    public string ProductCode { get; set; } = default!;
    public string Subject { get; set; } = default!;
    public int EmailType { get; set; } = default!;
}
public sealed class SendNotificationRequestValidator : AbstractValidator<SendNotificationRequest>
{
    public SendNotificationRequestValidator()
    {
    }
}

