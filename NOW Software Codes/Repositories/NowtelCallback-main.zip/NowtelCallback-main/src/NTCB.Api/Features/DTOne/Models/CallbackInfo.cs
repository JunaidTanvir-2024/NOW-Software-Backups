﻿using System.Text.Json.Serialization;

namespace NTCB.Api.Features.DTOne.Models;

public class CallbackInfo
{
    [JsonPropertyName("benefits")]
    public BenefitInfo[]? Benefits { get; set; }

    [JsonPropertyName("callback_url")]
    public string? CallbackUrl { get; set; }

    [JsonPropertyName("confirmation_date")]
    public string? ConfirmationDate { get; set; }

    [JsonPropertyName("confirmation_expiration_date")]
    public string? ConfirmationExpirationDate { get; set; }

    [JsonPropertyName("creation_date")]
    public string? CreationDate { get; set; }

    [JsonPropertyName("credit_party_identifier")]
    public CreditPartyIdentifierInfo? CreditPartyIdentifier { get; set; }

    [JsonPropertyName("external_id")]
    public string? ExternalId { get; set; }

    [JsonPropertyName("id")]
    public long Id { get; set; }

    [JsonPropertyName("operator_reference")]
    public string? OperatorReference { get; set; }

    [JsonPropertyName("prices")]
    public PricesInfo? Prices { get; set; }

    [JsonPropertyName("product")]
    public ProductInfo? Product { get; set; }

    [JsonPropertyName("promotions")]
    public object? Promotions { get; set; }

    [JsonPropertyName("rates")]
    public RatesInfo? Rates { get; set; }

    [JsonPropertyName("status")]
    public StatusInfo? Status { get; set; }
}