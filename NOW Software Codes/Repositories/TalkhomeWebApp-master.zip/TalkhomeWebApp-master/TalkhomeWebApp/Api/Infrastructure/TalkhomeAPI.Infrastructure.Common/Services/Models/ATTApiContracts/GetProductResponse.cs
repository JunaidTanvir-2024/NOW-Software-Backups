﻿using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Infrastructure.Common.Models;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.ATTApiContracts
{
    public class GetProductResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCodeDtOne { get; set; }
        public int errorCode { get; set; }
        public int servcieproviderid { get; set; }
        public AttPayLoad payload { get; set; }
    }

    public class AttPayLoad
    {
        public List<AttOperator> operators { get; set; }
    }

    public class AttOperator
    {
        public string id { get; set; }
        public string name { get; set; }
        public string country { get; set; }
        public string nowtelTransactionReference { get; set; }
        public string iconUri { get; set; }
        public List<AttProduct> products { get; set; }
        public int accessid { get; set; }
    }

    public class AttProduct
    {
        public string clientccy { get; set; }
        public string receiverccy { get; set; }
        public string product { get; set; }
        public string itemPriceClientccy { get; set; }
        public string transactionfeeClientccy { get; set; }
        public string totalPriceClientccy { get; set; }
        public decimal discountPercentage { get; set; }
        public string orignalAmount { get; set; }
    }

    public class ExecuteDataRequest
    {
        public string nowtelTransactionReference { get; set; }
        public string operatorid { get; set; }
        public string product { get; set; }
        public string messageToRecipient { get; set; }
        public string fromMSISDN { get; set; }
    }

    public class ExecuteDataResponse
    {
        public string errorCode { get; set; }
        public string errorCodeDtOne { get; set; }
        public string status { get; set; }
        public string message { get; set; }
        public string amount { get; set; }
        public string currency { get; set; }
        public string reference { get; set; }
		public string pinCode { set; get; }
	}
    public class DTOneCountriesListPayloadResponse
    {
        public Dictionary<string, string> countries { get; set; }
    }
    public class CountriesWithOperatorNamesPayloadResponse
    {
        public List<CountriesWithOperatorNamesResponse> Countries { get; set; }
        public List<PromotionItem> Promotions { get; set; }
    }
    public class CountriesWithOperatorNamesResponse
    {
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string OperatorNames { get; set; }
        public string Continent { get; set; }
        public int OperatorCount { get; set; }
    }
    public class TransferCountriesResponse
    {
        public List<TransferCountry> Countries { get; set; }
        public List<PromotionItem> Promotions { get; set; }
        public class TransferCountry
        {
            public string CountryId { get; set; }
            public string Code { get; set; }
            public string Continent { get; set; }
            public string Name { get; set; }
            public int OperatorsCount { get; set; }
            public string OperatorsName { get; set; }
        }
    }
    public class TransferOperatorsByCountryResponse
    {
        public List<Operator> Operators { get; set; }
        public List<PromotionItem> Promotions { get; set; }
    }
    public class TransferOperatorDetailsResponse
    {
        public List<PromotionItem> Promotions { get; set; }
        public Operator Details { get; set; }
        public List<Operator> Operators { get; set; }
    }
    public class Operator
    {
        public string countryName { get; set; }
        public string countryCode { get; set; }
        public string continent { get; set; }
        public string TransferToOperatorId { get; set; }
        public string operatorName { get; set; }
        public string operatorImageUrl { get; set; }
    }

    public class DTOneOperatorsPayloadResponse
    {
        public string country { get; set; }
        public List<Operator> operators { get; set; }
        public List<PromotionItem> promotions { get; set; }
    }
    public class DTOneOperatorDetailsResponse
    {
        public Operator OperatorDetails { get; set; }
        public List<Operator> Operators { get; set; }
        public List<PromotionItem> Promotions { get; set; }
    }
    public class AttResponse<T> where T:class
    {
        public int errorCode { get; set; }
        public string status { get; set; }
        public string message { get; set; }
        public T payLoad { get; set; }
    }


}
