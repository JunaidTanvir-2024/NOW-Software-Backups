﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TransferHome.Models.Contracts.Service.Pay360ApiContracts;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.InAppModels
{
    public class InAppPay360CardPostModel
    {
        [Required]
        public decimal Amount { get; set; }
        public int UserId { get; set; }
        [Required]
        public string Currency { get; set; }

        public string CardId { get; set; }
        [Required]
        public string ExpiryMonth { get; set; }
        [Required]
        public string ExpiryYear { get; set; }

        public string CVV { get; set; }

        public bool IsRegistered { get; set; }

        [Required(ErrorMessage = "Enter Card Name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        public string NameOnCard { get; set; }
        [Required]
        public string Token { get; set; }
        public string Default { get; set; }
        public string NoCards { get; set; }

        public string CustId { get; set; }
        public string CustomerPhoneNumber { get; set; }
        public string CustomerEmail { get; set; }
        [Required(ErrorMessage = "Enter Card Number"), MinLength(length: 16, ErrorMessage = "Minimum 16 characters allowed"), MaxLength(length: 19, ErrorMessage = "Maximum 19 characters allowed")]
        public string CardNumber { get; set; }

        [Required(ErrorMessage = "Enter Security Code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [Range(0, int.MaxValue, ErrorMessage = "Only numbers allowed.")]
        public string SecurityCode { get; set; }

        public CheckOutTypes CheckOutType { get; set; }
        public Pay360PaymentType Pay360PaymentType { get; set; }
        public string IPAddress { get; set; }

        [Required]
        public string nowtelTransactionReference { get; set; }
        [Required]
        public string operatorid { get; set; }
        [Required]
        public string product { get; set; }
        [Required]
        public string messageToRecipient { get; set; }
        [Required]
        public string fromMSISDN { get; set; }
    }

}
