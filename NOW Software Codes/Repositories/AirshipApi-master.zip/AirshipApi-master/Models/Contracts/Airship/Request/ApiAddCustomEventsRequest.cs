﻿using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Airship.Request
{
    public class ApiAddCustomEventsRequest
    {
        [JsonProperty("occurred")]        
        public string OccurredTime { get; set; }

        [JsonProperty("user")]
        public User User { get; set; }

        [JsonProperty("body")]
        public Body Body { get; set; }
    }

    public class User
    {
        [JsonIgnore]
        public CEventChannelIdentifier ChannelIdentifier { get; set; }

        [JsonIgnore]
        public string ChannelIdentifierValue { get; set; }

        [JsonProperty("named_user_id")]
        public string NamedUserId { get; set; }
        public bool ShouldSerializeNamedUserId()
        {
            
            if (ChannelIdentifier == CEventChannelIdentifier.named_user_id)
            {
                NamedUserId = ChannelIdentifierValue;
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonProperty("ios_channel")]
        public string IosChannel { get; set; }
        public bool ShouldSerializeIosChannel()
        {

            if (ChannelIdentifier == CEventChannelIdentifier.ios_channel)
            {
                IosChannel = ChannelIdentifierValue;
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonProperty("android_channel")]
        public string AndroidChannel { get; set; }
        public bool ShouldSerializeAndroidChannel()
        {

            if (ChannelIdentifier == CEventChannelIdentifier.android_channel)
            {
                AndroidChannel = ChannelIdentifierValue;
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonProperty("web_channel")]
        public string WebChannel { get; set; }
        public bool ShouldSerializeWebChannel()
        {

            if (ChannelIdentifier == CEventChannelIdentifier.web_channel)
            {
                WebChannel = ChannelIdentifierValue;
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonProperty("amazon_channel")]
        public string AmazonChannel { get; set; }
        public bool ShouldSerializeAmazonChannel()
        {

            if (ChannelIdentifier == CEventChannelIdentifier.amazon_channel)
            {
                AmazonChannel = ChannelIdentifierValue;
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonProperty("channel")]
        public string Channel { get; set; }
        public bool ShouldSerializeChannel()
        {

            if (ChannelIdentifier == CEventChannelIdentifier.channel)
            {
                Channel = ChannelIdentifierValue;
                return true;
            }
            else
            {
                return false;
            }
        }
                
        
    }

    public class Body
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("value")]
        public double Value { get; set; }

        public bool ShouldSerializeValue()
        {

            if (Value > 0)
            {                
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonProperty("transaction")]
        public string Transaction { get; set; }

        public bool ShouldSerializeTransaction()
        {

            if (string.IsNullOrWhiteSpace(Transaction))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        [JsonProperty("interaction_id")]
        public string InteractionId { get; set; }

        public bool ShouldSerializeInteractionId()
        {

            if (string.IsNullOrWhiteSpace(InteractionId))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        [JsonProperty("interaction_type")]
        public string InteractionType { get; set; }

        public bool ShouldSerializeInteractionType()
        {

            if (string.IsNullOrWhiteSpace(InteractionType))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        [JsonProperty("properties")]
        public Dictionary<string, string> Properties { get; set; }

        public bool ShouldSerializeProperties()
        {

            if (Properties == null || Properties.Count == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        //[JsonProperty("session_id")]
        //public string SessionId { get; set; }

        //public bool ShouldSerializeSessionId()
        //{

        //    if (string.IsNullOrWhiteSpace(SessionId))
        //    {
        //        return false;
        //    }
        //    else
        //    {
        //        return true;
        //    }
        //}
    }
}
