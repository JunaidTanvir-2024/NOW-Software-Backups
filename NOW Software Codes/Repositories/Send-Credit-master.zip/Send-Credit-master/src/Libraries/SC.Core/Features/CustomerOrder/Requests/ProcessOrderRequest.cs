﻿using SC.Core.Common.Interfaces.Services;
using SC.Core.Models.OrderCheckout.Payment;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder.Requests;

public sealed class ProcessOrderRequest : IRequest<IResultWrapper>
{
    public CardPaymentCustomerDto? Customer { get; set; } = default!;
    public CardPaymentInfoDto Payment { get; set; } = default!;
    public PaymentCardDto Card { get; set; } = default!;
    public CustomFieldDto? CustomFields { get; set; }
    public string IpAddress { get; set; } = default!;
    public string? PromoCode { get; set; }
    public AppEnums.PaymentMethod paymentMethod { get; set; }

}

public sealed class ProcessOrderRequestValidator : AbstractValidator<ProcessOrderRequest>
{
    private readonly IHelperService _client;

    public ProcessOrderRequestValidator(IHelperService client)
    {
        _client = client;
        RuleFor(x => x.PromoCode).MustAsync(async (promoCode, cancellation) => await _client.ValidatePromoCode(promoCode)).WithMessage("Discount Configuration does not exist in system against provided Promo Code");
    }
}