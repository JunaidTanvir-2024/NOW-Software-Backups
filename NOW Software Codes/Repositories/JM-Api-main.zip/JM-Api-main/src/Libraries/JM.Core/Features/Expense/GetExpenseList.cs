using System.Linq.Expressions;

using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Auth.Expense;

public abstract class GetExpenseList
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public QueryFilter Filters { get; set; } = new QueryFilter();
        public sealed record QueryFilter
        {
            public long? TripId { get; set; }
            public long? CategoryId { get; set; }
        }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public string? Description { get; set; }
        public decimal Amount { get; set; }
        public TravelerInfo? Traveler { get; set; }
        public ExpenseCategoryInfo? Category { get; set; }
        public sealed record TravelerInfo
        {
            public required long Id { get; set; }
            public string? FullName { get; set; }
            public string? Email { get; set; }
        }
        public sealed record ExpenseCategoryInfo
        {
            public required long Id { get; set; }
            public required string Name { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var expenseList = query.Filters is null ?
             await _unitOfWork.ExpenseRepository.GetExpenseList() :
             await _unitOfWork.ExpenseRepository.GetExpenseList(GetFilters(query.Filters));

            if (expenseList is not null)
            {
                return ResultWrapper.Success(expenseList.Select(x => new Response()
                {
                    Id = x.Id,
                    Amount = x.Amount,
                    Description = x.Description,
                    Traveler = x.Traveler is not null ? new Response.TravelerInfo()
                    {
                        Id = x.Traveler.User.Id,
                        Email = x.Traveler.User?.Email,
                        FullName = x.Traveler.User?.UserDetail?.FullName,
                    } : default,
                    Category = x.Category is not null ? new Response.ExpenseCategoryInfo()
                    {
                        Id = x.Category.Id,
                        Name = x.Category.Name
                    } : default,
                }));
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
        private static Expression<Func<Entities.Expense, bool>> GetFilters(Query.QueryFilter filters)
        {
            Expression<Func<Entities.Expense, bool>> filterExpression = x =>
                x.IsActive &&
                (filters.TripId == null || x.TripId.Equals(filters.TripId)) &&
                (filters.CategoryId == null || x.CategoryId.Equals(filters.CategoryId));

            return filterExpression;
        }
    }
    #endregion
}
