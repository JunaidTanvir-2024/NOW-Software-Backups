﻿using ATT.Infrastructure.BLL.Mobiquity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace ATT.Controllers
{
    [ApiController]
    public class MobiquityController : ControllerBase
    {
        private IMobiquityPost_BL _mobiquityPost_BL;
        private ILogger _loggerAPIAccess;
        public MobiquityController(IMobiquityPost_BL mobiquityPost_BL, ILogger appLoggers)
        {
            _loggerAPIAccess = appLoggers;
            _mobiquityPost_BL = mobiquityPost_BL;
        }


        [HttpGet]
        [Route("MobiquityGetBalance")]
        public async Task<IActionResult> MobiquityGetBalance()
        {
            try
            {
                var result = await _mobiquityPost_BL.MobiquityGetBalance();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($" MobiquityController, \"GET /MobiquityGetBalance\"  Failed  Message:{ex.ToString()}");
                var errorResult = new { errorCode = 2, status = "Failure", message = ex.Message };
                return Ok(errorResult);
            }
        }
    }
}
