using Application.Common.Interfaces.Infrastructure.Identity;
using Application.Common.Interfaces.Infrastructure.Services;
using Application.Common.Mailing;
using Application.Common.Settings;
using Domain.Entities;
using Microsoft.Extensions.Options;

namespace Application.Features.Identity.Signup.Signup;

public class SignupRequestHandler : IRequestHandler<SignupRequest, Result<object>>
{
    #region Fields

    private readonly IUnitOfWork _unitOfWork;
    private readonly IStringLocalizer<SignupRequestHandler> _localizer;
    private readonly IOtpService _otpService;
    private readonly IMailService _mailService;
    private readonly ISmsService _smsService;
    private readonly ICommonService _commonService;
    private readonly IEmailValidationService _validationService;
    private readonly DeleteAccountSettings _deleteSettings;


    #endregion

    #region Ctor

    public SignupRequestHandler(
        IUnitOfWork unitOfWork,
        IStringLocalizer<SignupRequestHandler> localizer,
        IOtpService otpService,
        IMailService mailService,
        ISmsService smsService,
        ICommonService commonService,
        IEmailValidationService validationService,
        IOptions<DeleteAccountSettings> deleteSettings

            )
    {
        _localizer = localizer;
        _otpService = otpService;
        _mailService = mailService;
        _smsService = smsService;
        _commonService = commonService;
        _validationService = validationService;
        _deleteSettings = deleteSettings.Value;
        _unitOfWork = unitOfWork;
    }

    #endregion

    #region Request Handler

    public async Task<Result<object>> Handle(SignupRequest request, CancellationToken cancellationToken)
    {
        //check delete account limit againt email

        //get user by email
        var userReponse = await _unitOfWork.UserRepo.GetUserByEmail(request.UserInfo.Email);
        // Check wether email is supported or not if email is not already attached

        if (userReponse == null)
        {
            var emailValidationResponse = await _validationService.VerifyEmailAddress(request.UserInfo.Email, request.IpAddress);
            if (emailValidationResponse?.Payload.IsEmailVerified == false)
            {

                return Result<object>.Failure(_localizer[CustomStatusKey.InvalidEmail],
                      CustomStatusCode.InvalidEmail);
            }
        }
        if (userReponse != null)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.EmailAlreadyRegistered],
                  CustomStatusCode.EmailAlreadyRegistered);
        }

        //Format msisdn
        request.UserInfo.Msisdn = _commonService.FormatMsisdn(request.UserInfo.Msisdn);

        //Is valid msisdn
        var msisdnDetails =await _unitOfWork.UserRepo.GetMsisdnDetail(request.UserInfo.Msisdn);
        if (msisdnDetails == null)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Check if msisdn already attached
        if (await _unitOfWork.UserRepo.IsProductAlreadyAttached(request.UserInfo.Msisdn))
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.MsisdnAlreadyRegistered], CustomStatusCode.MsisdnAlreadyRegistered);
        }

        //Check for any type of deactivation

        //Craet Email Otp
        var (emailOtp, otpModel) = await _otpService.CreateOtp(request.UserInfo.Email, OtpType.SignUp, true);
        if (otpModel.StatusCode != CustomStatusCode.OtpIsNotCreated)
        {
            await _mailService.SendSignupEmailOtpAsync(request.UserInfo.Email, emailOtp);
        }
        //Crete Msisdn Otp
        var (msisdnOtp, msisdnOtpModel) = await _otpService.CreateOtp(request.UserInfo.Msisdn, OtpType.SignUp, false);
        if (msisdnOtpModel.StatusCode != CustomStatusCode.OtpIsNotCreated)
        {
            await _smsService.SendOtpMessage(request.UserInfo.Msisdn, msisdnOtp.ToString());
        }
        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }
    #endregion
}