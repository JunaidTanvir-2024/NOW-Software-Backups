﻿using Dapper;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using THM.Models.Configurations;
using THM.Models.Database;
using THM.Models.DbConnections;
using THM.Models.Enums;

namespace THM.Infrastructure.DAL
{
    public class SimOrderEmails_DL : ISimOrderEmails_DL
    {
        private readonly IDbConnectionSettings THM_Web_Db;

        public SimOrderEmails_DL(IOptions<ConnectionStrings> connectionString)
        {
            THM_Web_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.THWEbConnection));
        }

        public async Task<DbSimOrder> GetCreditSimOrderDetails(int OrderId)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@OrderId", OrderId);

            return await THM_Web_Db.SqlConnection.QueryFirstOrDefaultAsync<DbSimOrder>
                                        ("th_sim_order_getCreditSimOrderDetails",
                                                parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<DbSimOrder> GetSimOrderDetails(int OrderId)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@OrderId", OrderId);

            return await THM_Web_Db.SqlConnection.QueryFirstOrDefaultAsync<DbSimOrder>
                                        ("th_sim_order_getFreeSimOrderDetails",
                                                parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<DbSimOrder>> GetNotActivatedSimOrders(SimOrderType simOrderType)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@Sim_Order_Type", (Int16)simOrderType);

            return await THM_Web_Db.SqlConnection.QueryAsync<DbSimOrder>("th_sim_order_getNotActivatedSimOrders"
                                                                                   , parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<DbSimOrder>> GetNotToppedUpSimOrders(SimOrderType simOrderType)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@Sim_Order_Type", (Int16)simOrderType);

            return await THM_Web_Db.SqlConnection.QueryAsync<DbSimOrder>("th_sim_order_getNotToppedUpSimOrders",
                                                                    parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<DbSimOrder>> GetOrdersForOtherServicesEmail(SimOrderType simOrderType)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@Sim_Order_Type", (Int16)simOrderType);

            return await THM_Web_Db.SqlConnection.QueryAsync<DbSimOrder>("th_sim_order_getOrdersForOtherServicesEmail",
                                                                        parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<DbSimOrder>> GetOrdersForSocialMediaEmails(SimOrderType simOrderType)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@Sim_Order_Type", (Int16)simOrderType);

            return await THM_Web_Db.SqlConnection.QueryAsync<DbSimOrder>("th_sim_order_getOrdersForSocialMediaEmails_v2",
                                                                        parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<DbSimOrder>> GetWhyAndBenefitsEmails(SimOrderType simOrderType)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@Sim_Order_Type", (Int16)simOrderType);

            return await THM_Web_Db.SqlConnection.QueryAsync<DbSimOrder>("th_sim_order_emails_get_whyandbenefits",
                                                                       parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task LogEmail(int simOrderId, SimOrderType simOrderType, EmailsType emailsType, bool emailResponse, string emailErrorMessage)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@simOrderId", simOrderId);
            parameters.Add("@simOrderType", (Int16)simOrderType);
            parameters.Add("@emailsType", (Int16)emailsType);
            parameters.Add("@isEmailSent", emailResponse);
            parameters.Add("@emailErrorMessage", emailErrorMessage);

            await THM_Web_Db.SqlConnection.ExecuteAsync("th_sim_order_emails_saveEmailLogs",
                                                        parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<DbEmailLogs>> GetSentEmailsDetail(int OrderId, SimOrderType simOrderType, EmailsType emailsType)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@simOrderId", OrderId);
            parameters.Add("@simOrderType", (Int16)simOrderType);
            parameters.Add("@emailsType", (Int16)emailsType);

            return await THM_Web_Db.SqlConnection.QueryAsync<DbEmailLogs>("th_sim_order_emails_get_sent_count",
                                                                                parameters, commandType: CommandType.StoredProcedure);
        }
    }
}
