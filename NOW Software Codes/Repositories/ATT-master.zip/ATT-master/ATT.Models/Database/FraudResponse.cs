﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Database
{
    public class FraudResponse
    {
        public bool isPermitted { get; set; }
        public int errorCode { get; set; }
    }
}
