﻿namespace Application.Common.Models;
public class SetCustomerIdRequestModel
{
    public string? CustomerUserId { get; set; }
    public string? AfUserId { get; set; }
    public string ProductCode { get; set; } = "THM-WEB"; 
    public string BaseProductCode { get; set; } = "THM";
}
