﻿using JM.Core.Utilities.DependencyResolver;
using JM.Core.Utilities.Dtos.Auth;

namespace JM.Core.Utilities.Interfaces.Services;

public interface IIdentityService : ResolveAs.IScoped
{
    Task<LoginDto.Response> LoginAsync(LoginDto.Request request);
    Task<ResetPasswordDto.Response> ResetPassword(ResetPasswordDto.Request request);
    Task<RegisterDto.Response> RegisterAsync(RegisterDto.Request request);
}
