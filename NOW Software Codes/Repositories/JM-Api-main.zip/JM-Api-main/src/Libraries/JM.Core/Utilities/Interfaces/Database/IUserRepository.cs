using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;

public interface IUserRepository : ResolveAs.IScoped
{
    UserDetail UpdateUserDetail(UserDetail userDetail);
    Task<User> AddUser(User user);
    Task<UserDetail> AddUserDetail(UserDetail user);
    Task<IEnumerable<User>?> GetUsers(Expression<Func<User, bool>> expression);
    Task<User?> GetUser(Expression<Func<User, bool>> expression);
    void UpdateUser(User user);
}
