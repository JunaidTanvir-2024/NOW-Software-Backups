﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Request
{
    public class ExecTransactionRequest : BaseRequest
    {
        public string command = "execTransaction";

        public string @operator { get; set; }

        public string msisdn { get; set; }

        public string amount { get; set; }

        public string userReference { get; set; }

        public string smsText { get; set; }

        public bool simulate { get; set; }

    }

    public class SMSRequest : BaseRequest
    {
        public string command = "sendSms";

        public string msisdn { get; set; }

        public string smsText { get; set; }

    }
}
