﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace Application.Common.Models.Airship;

public class CustomEventsRequest
{
    [JsonProperty("ProductCode")]
    [Required]
    public string ProductCode { get; set; } = "NOWPAYG";

    [JsonProperty("CustomEventName")]
    [Required]
    public string CustomEventName { get; set; } = string.Empty;

    [JsonProperty("ChannelIdentifier")]
    [Required]
    [EnumDataType(typeof(CEventChannelIdentifier))]
    public CEventChannelIdentifier ChannelIdentifier { get; set; }

    [JsonProperty("ChannelIdentifierValue")]
    [Required]
    public string ChannelIdentifierValue { get; set; } = string.Empty;

    [JsonProperty("Value")]
    public double Value { get; set; }

    [JsonProperty("Transaction")]
    public string Transaction { get; set; } = string.Empty;

    [JsonProperty("InteractionId")]
    public string InteractionId { get; set; } = string.Empty;

    [JsonProperty("InteractionType")]
    public string InteractionType { get; set; } = string.Empty;

    [JsonProperty("Properties")]
    public Dictionary<string, string>? Properties { get; set; }
}
public enum CEventChannelIdentifier
{
    named_user_id = 1,
    ios_channel = 2,
    android_channel = 3,
    web_channel = 4,
    amazon_channel = 5,
    channel = 6
}
