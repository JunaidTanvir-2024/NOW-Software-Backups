namespace FH.Core.DTOs.Database;
public sealed record ProductTransactionInsertDto
{
    public sealed record Request
    {
        public required string TransactionReference { get; set; }
        public required string VendorTransactionReference { get; set; }
        public required string VendorTransactionId { get; set; }
        public required string CartReference { get; set; }
        public required long ProductId { get; set; }
        public required string ProductVendorCode { get; set; }
        public required string Status { get; set; }
    }

    public sealed record Response { }
}
