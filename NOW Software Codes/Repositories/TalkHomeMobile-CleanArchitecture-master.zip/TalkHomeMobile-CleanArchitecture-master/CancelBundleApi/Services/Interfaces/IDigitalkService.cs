﻿using CancelBundleApi.Models.RequestModels;
using CancelBundleApi.Models.ResponseModels;

namespace CancelBundleApi.Services.Interfaces
{
    internal interface IDigitalkService
    {
        Task<(List<Item> Items, bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> GetSubscribedBundles(UnSubscribeBundlesRequest request, string correlationGuid);
        Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> DeleteSubscribedBundles(UnSubscribeBundlesRequest request, Item item);
        Task NoDataFound(string endPoint, string noDataFound, UnSubscribeBundlesRequest request, string correlationGuid);
    }
}
