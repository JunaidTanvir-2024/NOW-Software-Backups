using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;
using JM.Core.Utilities.Interfaces.Services;
using JM.Core.Utilities.Settings;

using Mediator;

using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

using RW;

namespace JM.Core.Features.Auth.Otp;

public abstract class GetOtp
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public string Email { get; set; } = string.Empty;
        public AppEnum.OtpType Type { get; set; }
    }

    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Type).Must(value => Enum.IsDefined(typeof(AppEnum.OtpType), value)).WithMessage("Type must be a valid enum value of OtpType.");
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public required string Code { get; set; }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IOptions<OtpSetting> otpSetting, ITimeWarpService timeWarpService, IOtpService otpService, IHostEnvironment hostEnvironment) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly ITimeWarpService _timeWarpService = timeWarpService;
        private readonly IOtpService _otpService = otpService;
        private readonly IHostEnvironment _hostEnvironment = hostEnvironment;
        private readonly OtpSetting _otpSetting = otpSetting.Value;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            // Getting user info against phone number
            var userInfo = await _unitOfWork.UserRepository.GetUser(x => x.NormalizedEmail!.Equals(query.Email.ToUpperInvariant()));

            if (userInfo is null)
            {
                return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
            }

            // Getting otp info against user
            var otpInfo = await _unitOfWork.OtpRepository.GetOtp(x => x.Type == (ushort)query.Type && x.UserId == userInfo!.Id);

            if (otpInfo is not null)
            {
                // Update otp info against user before creating new otp. It is required to get latest otp status against user
                await UpdateOtpInfo(otpInfo, userInfo!.Id);
            }

            var latestOtpInfo = await _unitOfWork.OtpRepository.GetOtp(x => x.Type == (ushort)query.Type && x.UserId == userInfo!.Id);

            if (latestOtpInfo?.IsBlocked == true || latestOtpInfo?.IsRetryLimitExceeded == true)
            {
                return ResultWrapper.Failure(AppConstant.StatusKey.TooManyRequests, AppConstant.StatusCode.TooManyRequests);
            }

            var otpCode = _hostEnvironment.IsDevelopment() || _hostEnvironment.IsStaging() ? _otpSetting.DefaultCode : _otpService.GenerateOtp();

            var otpEntity = await _unitOfWork.OtpRepository.AddOtp(new Entities.Otp
            {
                Code = otpCode,
                ExpiryTime = _timeWarpService.UtcNow.AddMinutes(_otpSetting.ExpiryTimeInMinutes),
                Type = (ushort)query.Type,
                UserId = userInfo!.Id,
            });
            _unitOfWork.SaveChanges();
            if (query.Type == AppEnum.OtpType.Signup)
            {
                return ResultWrapper.Success(new Response { Code = otpEntity.Code });
            }
            return ResultWrapper.Success(AppConstant.StatusKey.OtpSent, AppConstant.StatusCode.Success);
        }

        private DateTime? GetOtpUnblockTime(DateTime? blockTime)
        {
            var remainingBlockTime = blockTime?.AddMinutes(_otpSetting.BlockTimeInMinutes) - _timeWarpService.UtcNow;

            var retryAfterTime = remainingBlockTime?.TotalMinutes ?? 0;

            return _timeWarpService.UtcNow.AddMinutes(retryAfterTime);
        }
        private async Task UpdateOtpInfo(Entities.Otp? otpInfo, long userId)
        {
            var unblockTime = GetOtpUnblockTime(otpInfo?.BlockTime);

            var otpCounts = await _unitOfWork.OtpRepository.GetOtpCount(x => x.Type == otpInfo!.Type && x.UserId == userId);

            if (otpInfo is not null)
            {
                if (otpCounts >= _otpSetting.CreationLimit)
                {
                    if (unblockTime <= _timeWarpService.UtcNow && otpInfo.IsBlocked == true)
                    {
                        _unitOfWork.OtpRepository.DeleteOtp(otpInfo);
                        _unitOfWork.SaveChanges();
                    }

                    otpInfo.IsRetryLimitExceeded = true;
                    otpInfo.IsBlocked = true;
                    otpInfo.BlockTime = _timeWarpService.UtcNow.AddMinutes(_otpSetting.BlockTimeInMinutes);
                }
                _unitOfWork.OtpRepository.UpdateOtp(otpInfo);
                _unitOfWork.SaveChanges();
            }
        }
    }
    #endregion
}
