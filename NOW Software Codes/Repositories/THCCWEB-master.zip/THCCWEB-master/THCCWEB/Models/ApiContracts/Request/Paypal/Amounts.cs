﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request.Paypal
{
    public class Amounts
    {
        public float Total { get; set; }

        public string Currency { get; set; }
    }
}
