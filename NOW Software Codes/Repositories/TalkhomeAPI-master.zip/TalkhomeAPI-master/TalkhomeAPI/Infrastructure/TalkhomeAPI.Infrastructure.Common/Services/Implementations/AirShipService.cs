﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Airship;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public interface IAirShipService
    {
        public bool IsActive { get; }
        public string PaymentTagGroupName { get; }
        public string CustomerTagGroupName { get; }

        Task<GenericAirShipApiResponse<string>> AddNamedUserTags(NamedUserTagsRequest request);
        Task<GenericAirShipApiResponse<string>> AddCustomEvent(CustomEventsRequest request);
        Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress);
        Task AddEmailChannel(string emailAddress);
        Task DisassociateEmailChannelFromNamedUser(string namedUserId, string emailAddress);
        Task AddEmailChannelCommercial(string emailAddress);
        Task RemoveEmailChannelCommercial(string emailAddress);
    }

    public class AirShipService : IAirShipService
    {

        private readonly string AirShipApiEndpoint;
        private readonly ILogger Logger;

        public bool IsActive { get; }
        public string PaymentTagGroupName { get; }
        public string CustomerTagGroupName { get; }

        
        public AirShipService(ILogger logger, IOptions<AirShipConfig> appConfig)
        {
            Logger = logger;
            AirShipApiEndpoint = appConfig.Value.AirShipApiEndpoint;
            IsActive = appConfig.Value.IsActive;
            PaymentTagGroupName = appConfig.Value.PaymentTagGroupName;
            CustomerTagGroupName = appConfig.Value.CustomerTagGroupName;
        }

        
        public async Task<GenericAirShipApiResponse<string>> AddNamedUserTags(NamedUserTagsRequest request)
        {
            string endpoint = AirShipApiEndpoint + "NamedUser/AddNuserTags";

            GenericAirShipApiResponse<string> ret = new GenericAirShipApiResponse<string>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                Logger.Error($"Controller: AirShipService, Method: AddNamedUserTags, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:null ");
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericAirShipApiResponse<string>>(Result);

            if (ret.errorCode != 0)
            {
                Logger.Error($"Controller: AirShipService, Method: AddNamedUserTags, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:{Result} ");
            }

            return ret;
        }

        public async Task<GenericAirShipApiResponse<string>> AddCustomEvent(CustomEventsRequest request)
        {
            string endpoint = AirShipApiEndpoint + "CustomEvent/AddCustomEvent";

            GenericAirShipApiResponse<string> ret = new GenericAirShipApiResponse<string>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                Logger.Error($"Controller: AirShipService, Method: AddCustomEvent, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:null ");
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericAirShipApiResponse<string>>(Result);
            if (ret.errorCode != 0)
            {
                Logger.Error($"Controller: AirShipService, Method: AddCustomEvent, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:{Result} ");
            }

            return ret;
        }

        public async Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "NamedUser/EmailAssociationWithNamedUser")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        EmailAddress = emailAddress,
                        NamedUserId = namedUserId,
                        ProductCode = "THA"
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task AddEmailChannel(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THA"
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task AddEmailChannelCommercial(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THA",
                        commercialOptedIn = DateTime.UtcNow
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task RemoveEmailChannelCommercial(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THA",
                        commercialOptedOut = DateTime.UtcNow
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DisassociateEmailChannelFromNamedUser(string namedUserId, string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "NamedUser/DisassociateEmailChannelFromNamedUser")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        EmailAddress = emailAddress,
                        NamedUserId = namedUserId,
                        ProductCode = "THA"
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                        throw new WebException();

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch
            {
                return null;
            }
        }
    }
}
