using DC.Core.Common.Definitions;
using DC.Core.Common.DTOs.Vendors.DTOne;
using DC.Core.Common.Entities;
using DC.Core.Common.Helpers;
using DC.Core.Common.Interfaces.Database;
using DC.Core.Common.Interfaces.Services;
using DC.Core.Features.HangFire;
using DC.Core.Features.Notifications.Requests;

using Serilog;


namespace DC.Core.Features.Notifications.Handlers;
internal class NewRegisteredMsisdnHandler : IRequestHandler<NewRegisteredMsisdnRequest, IResultWrapper>
{

    private readonly IDigiTalkRepository _digiTalkRepository;
    private readonly IDigiConnectRepository _digiConnectRepository;
    private readonly ILogger _logger;

    public NewRegisteredMsisdnHandler(IDigiTalkRepository digiTalkRepository, IDigiConnectRepository digiConnectRepository, ILogger logger)
    {
        _digiTalkRepository = digiTalkRepository;
        _digiConnectRepository = digiConnectRepository;
        _logger = logger;
    }
    public async Task<IResultWrapper> Handle(NewRegisteredMsisdnRequest request, CancellationToken cancellationToken)
    {
        try
        {


            var date = DateTime.UtcNow.AddMinutes(-5);
            var response = await _digiTalkRepository.GetNewRegisteredMsisdn(date, AppEnums.SimState.Active.ToString());
            if (response != null)
            {
                foreach (var item in response)
                {
                    item.CreatedOn = DateTime.UtcNow;
                    item.CreatedBy = "HangFire";
                    item.ModifiedOn = DateTime.UtcNow;
                    item.ModifiedBy = "";
                    item.Product = ProductType(item.Product);
                    await _digiConnectRepository.UpsertNewRegisteredMsisdn(item);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.Error(ex, nameof(NewRegisteredMsisdnHandler), nameof(NewRegisteredMsisdnHandler));
        }
        return ResultWrapper.Success("Data Added Successfully", AppConstants.StatusCode.Success);
    }
    private string ProductType(string product)
    {
        if (product == "Retail")
        {
            if (product.Length == 12)
            {
                return "Retail-NowMobile";
            }
            return "Retail-THM";

        }
        return product;
    }

}
