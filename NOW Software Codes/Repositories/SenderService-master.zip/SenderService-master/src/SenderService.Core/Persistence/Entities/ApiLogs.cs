﻿namespace SenderService.Core.Persistence.Entities;
public class ApiLogs
{
    public int Id { get; set; }
    public string? Url { get; set; }
    public string? Method { get; set; }
    public string? RequestBody { get; set; }
    public string? ResponseBody { get; set; }
    public int StatusCode { get; set; }
    public DateTime Timestamp { get; set; }
}
