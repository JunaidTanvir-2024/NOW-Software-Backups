﻿using System.Text.Json.Serialization;
namespace NTCB.Api.Features.DTOne.Models;

public class ServiceInfo
{
    [JsonPropertyName("id")]
    public int? Id { get; set; }
    
    [JsonPropertyName("name")]
    public string? Name { get; set; }
    
    [JsonPropertyName("subservice")]
    public SubServiceInfo? Subservice { get; set; }
}
