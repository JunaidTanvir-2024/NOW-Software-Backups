﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class ErrorObjectViewModel
    {
        public HttpStatusCode StatusCode { get; set; }
        public string Key { get; set; }
        public string ErrorMessage { get; set; }
        public BundleTransactionModel BundleInfo { get; set; }
        public TopupTransactionModel TopupInfo { get; set; }
        public MobileTopupTransactionModel MobileTopupInfo { get; set; }
    }
}
