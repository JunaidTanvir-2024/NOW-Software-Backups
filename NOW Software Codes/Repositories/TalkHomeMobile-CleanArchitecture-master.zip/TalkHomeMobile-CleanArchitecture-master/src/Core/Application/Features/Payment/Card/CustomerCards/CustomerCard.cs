﻿namespace Application.Features.Payment.Card.CustomerCards;

public class CustomerCard
{
    public bool IsPrimary { get; set; }
    public string CardToken { get; set; } = string.Empty;
    public string CardType { get; set; } = string.Empty;
    public string CardUsageType { get; set; } = string.Empty;
    public string CardScheme { get; set; } = string.Empty;
    public string MaskedPan { get; set; } = string.Empty;
    public string ExpiryDate { get; set; } = string.Empty;
    public string ImageUrl { get; set; } = string.Empty;
}