using FH.Core.DependencyResolver;
using FH.Core.Entities;

namespace FH.Core.Interfaces.Database;

public interface ICurrencyRepository : ServiceType.IScoped
{
    Task<IEnumerable<CurrencyUnitEntity>> CurrencyUnitUpsert(IEnumerable<CurrencyUnitEntity> currencyUnitDtos);
}
