﻿using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts.Pay360.Response.User
{
    public class UserPaymentMethodsResponse
    {
        public List<PaymentMethodResponseModel> paymentMethodResponses { get; set; }
    }

    public class UserPaymentMethodResponse
    {
        public PaymentMethodResponseModel PaymentMethodResponse { get; set; }
    }

    public class MSISDN
    {
        public string Msisdn { get; set; }
    }

    public class CUSTOMERID
    {
        public string CustomerID { get; set; }
    }

    public class TRRANSACTIONID
    {
        public string TransactionId { get; set; }
    }

    



}
