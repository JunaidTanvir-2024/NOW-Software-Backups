using DC.Core.Common.Definitions;
using DC.Core.Common.Entities;
using DC.Core.Common.Helpers;
using DC.Core.Common.Interfaces.Database;
using DC.Core.Features.Notifications.Requests;

using Serilog;

namespace DC.Core.Features.Notifications.Handlers;
internal class SendTopUpSmsHandler : IRequestHandler<SendTopUpSmsRequest, IResultWrapper>
{

    private readonly IDigiConnectRepository _digiConnectRepository;
    private readonly ISmsHelper _smsHelper;
    private readonly ILogger _logger;

    public SendTopUpSmsHandler(IDigiConnectRepository digiConnectRepository, ISmsHelper smsHelper, ILogger logger)
    {
        _digiConnectRepository = digiConnectRepository;
        _smsHelper = smsHelper;
        _logger = logger;
    }
    public async Task<IResultWrapper> Handle(SendTopUpSmsRequest request, CancellationToken cancellationToken)
    {
        var allActivationSMS = await _digiConnectRepository.GetMessageContent(AppEnums.SmsType.Topup.ToString());
        await GetFirstTopupToSendMessage(allActivationSMS);
        await GetMsisdnWithNoPlanToSendMessage(allActivationSMS);
        return ResultWrapper.Success("Message send successfully", AppConstants.StatusCode.Success);
    }

    private async Task GetFirstTopupToSendMessage(List<SmsDetails> messageContent)
    {
        try
        {
            var nowDate = DateTime.UtcNow.AddMinutes(-5);
            var res = await _digiConnectRepository.GetNewTopUp(nowDate, string.Empty);
            foreach (var log in res)
            {
                var topupCount = res.Count(x => x.Msisdn.Equals(log.Msisdn));
                if (topupCount < 2)
                {
                    var record = new ActiveMsisdnLog
                    {
                        Msisdn = log.Msisdn,
                        CreatedBy = "Hangfire"
                    };
                    DateTime createdOn = log.TopUpDate;
                    TimeSpan timeDifference = createdOn - nowDate;
                    int hours = (int)timeDifference.TotalHours;
                    var category = string.Empty;

                    if (hours < 12)
                    {
                        record.Cadence = AppEnums.Cadence.Immediate.ToString();
                        var message = messageContent.Where(x => x.Cadence.Equals(AppEnums.Cadence.Immediate.ToString()) && x.SmsSubCategory == AppEnums.SmsSubCategory.AllTopUps.ToString()).FirstOrDefault();
                        var content = message.SmsContent.Replace("[TOPBA]", log?.TopUpAmount.ToString()).Replace("[AVLBA]", log?.AvailableBalance.ToString());
                        await _smsHelper.sendSms(record, content, category);
                    }
                }
            }
        }
        catch (Exception ex)
        {

            _logger.Error(ex, nameof(SendTopUpSmsHandler), nameof(SendTopUpSmsHandler));
        }

    }
    private async Task GetMsisdnWithNoPlanToSendMessage(List<SmsDetails> messageContent)
    {
        try
        {
            var nowDate = DateTime.UtcNow.AddMinutes(-5);
            var res = await _digiConnectRepository.GetMsisdnWithNoPlan(nowDate, string.Empty);
            var dist = res.DistinctBy(x => x.Msisdn).ToList();

            foreach (var log in dist)
            {
                var msisdnWithBundle = res.Any(x => x.TransactionType != null && x.TransactionType.Equals("Bundle") && x.Msisdn.Equals(log.Msisdn));
                var msisdnWithTopUp = res.Any(x => x.TransactionType != null && x.TransactionType.Equals("TopUp") && x.Msisdn.Equals(log.Msisdn));
                if (msisdnWithBundle == false && msisdnWithTopUp)
                {
                    var record = new ActiveMsisdnLog
                    {
                        Msisdn = log.Msisdn,
                        CreatedBy = "Hangfire"
                    };
                    DateTime createdOn = log.CreatedOn;
                    TimeSpan timeDifference = createdOn - nowDate;
                    int hours = (int)timeDifference.TotalHours;
                    var category = string.Empty;

                    if (hours > 11 && hours < 48)
                    {
                        record.Cadence = AppEnums.Cadence.T12hours.ToString();
                        var message = messageContent.Where(x => x.Cadence.Equals(AppEnums.Cadence.T12hours.ToString()) && x.SmsSubCategory == AppEnums.SmsSubCategory.FirstTopUpNoPlan.ToString()).FirstOrDefault();
                        await _smsHelper.sendSms(record, message.SmsContent, category);
                    }
                    else if (hours > 47)
                    {
                        record.Cadence = AppEnums.Cadence.T48hours.ToString();
                        var message = messageContent.Where(x => x.Cadence.Equals(AppEnums.Cadence.T48hours.ToString()) && x.SmsSubCategory == AppEnums.SmsSubCategory.FirstTopUpNoPlan.ToString()).FirstOrDefault();
                        await _smsHelper.sendSms(record, message.SmsContent, category);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.Error(ex, nameof(SendTopUpSmsHandler), nameof(SendTopUpSmsHandler));
        }

    }
}
