﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Data.Repositories;

namespace TalkhomeAPI.Infrastructure.DependencyInjection.DependencyModules
{
    public static class RepositoryModules
    {
        public static void Configure(this IServiceCollection services) 
        {
            services.AddTransient<IBundleRepository, BundleRepository>();
            services.AddTransient<IRatesRepository, RatesRepository>();
            services.AddTransient<IAccountRepository, AccountRepository>();
            services.AddTransient<ITransferRepository, TransferRepository>();
        }
    }
}
