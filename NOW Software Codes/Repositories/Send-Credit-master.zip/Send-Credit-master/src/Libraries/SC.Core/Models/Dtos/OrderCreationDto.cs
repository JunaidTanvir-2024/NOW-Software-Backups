﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.Dtos;
public record OrderCreationDto
{
    public long CustomerOrderID { get; set; } = default!;
    public string CustomerID { get; set; } = default!;
    public string PromoCode { get; set; } = default!;
    public int? DiscountTypeId { get; set; }
    public decimal DiscountAmount { get; set; } = decimal.Zero;
    public decimal DiscountInclusiveAmount { get; set; } = decimal.Zero;
    public decimal ServiceFee { get; set; } = decimal.Zero;
    public decimal TaxAmount { get; set; } = decimal.Zero;
    public decimal TaxInclusiveAmount { get; set; } = decimal.Zero;
    public decimal TaxExclusiveAmount { get; set; } = decimal.Zero;
    public decimal TotalOrderAmount { get; set; } = decimal.Zero;
    public string Currency { get; set; } = default!;
    public string OrderStatus { get; set; } = default!;
    public bool isDeleted { get; set; } = default!;
    public bool isActive { get; set; } = default!;
    public string UserID { get; set; } = default!;
    public long CustomerAddressId { get; set; } = default!;
    public string RequestId { get; set; } = default!;
    public string? PaymentMethod { get; set; }
}

