using THCC.Infrastructure;

namespace THCC.Api;

public static class ConfigureMiddlewares
{
    public static WebApplication AddMiddlewares(this WebApplication app, IServiceCollection services, IConfiguration configuration)
    {
        return app;
    }
}