﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Services.Interfaces;
using ThmApi.Filters;

namespace TalkhomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BundlesController : ControllerBase
    {
        private readonly IBundleService _bundleService;
        private readonly ILogger _logger;

        public BundlesController(IBundleService bundleService, ILogger logger)
        {
            _bundleService = bundleService;
            _logger = logger;
        }

        [HttpGet]
        [Route("GetCountriesByBundle")]
        [BasicAuth]
        public async Task<IActionResult> GetCountriesByBundle()
        {
            try
            {
                return Ok(await _bundleService.GetCountriesByBundle());
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: BundlesController, Method: GetCountriesByBundle, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetBundleByCountry")]
        [BasicAuth]
        public async Task<IActionResult> GetBundleByCountry(string ServiceId)
        {
            try
            {
                return Ok(await _bundleService.GetBundleByCountry(ServiceId));
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: BundlesController, Method: GetBundleByCountry, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }

        }

        [HttpGet]
        [Route("GetBundleByID")]
        [BasicAuth]
        public async Task<IActionResult> GetBundleByID(string Id)
        {
            try
            {
                Guid id = Guid.Parse(Id);
                return Ok(await _bundleService.GetBundleById(Id));
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: BundlesController, Method: GetBundleByID, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
    }
}