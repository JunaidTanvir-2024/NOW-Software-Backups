using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Web;

using JM.Core.Entities;
using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;
using JM.Infrastructure.Services.Caching;

using Microsoft.AspNetCore.Http;

namespace JM.Infrastructure.Services.Http;


internal sealed class HttpService(
                IHttpClientFactory httpClientFactory,
                IUnitOfWork unitOfWork,
                IHttpContextAccessor httpContextAccessor,
                ICacheService cacheManager) : IHttpService
{
    private const string CORRELATION_ID = "Correlation_Id";
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly IUnitOfWork _unitOfWork = unitOfWork;
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;
    private readonly ICacheService _cacheManager = cacheManager;
    private string? _basicAuthUsername;
    private string? _basicAuthPassword;
    private bool _isLoggingEnabled;
    private int _vendorId;
    private bool _isBearerTokenNeeded;
    private string? _tokenProperty;
    private string? _tokenExpiryProperty;
    private string? _cachedTokenKey;
    private Dictionary<string, string> _headers = [];
    private bool _isTokenInfoExpired;
    private string? _apiKey;
    private string? _apiKeyHeaderName;

    IHttpService IHttpService.WithBearerAuth(string cachedTokenKey, string tokenProperty, string tokenExpiryProperty)
    {
        _isBearerTokenNeeded = true;
        _tokenProperty = tokenProperty;
        _tokenExpiryProperty = tokenExpiryProperty;
        _cachedTokenKey = cachedTokenKey;
        return this;
    }

    IHttpService IHttpService.WithBasicAuth(string? username, string? password)
    {
        _basicAuthUsername = username;
        _basicAuthPassword = password;
        return this;
    }

    IHttpService IHttpService.WithDefaultHeaders(Dictionary<string, string> headers)
    {
        _headers = headers;
        return this;
    }

    IHttpService IHttpService.WithApiKey(string? apiKey, string? apiKeyHeaderName)
    {
        _apiKey = apiKey;
        _apiKeyHeaderName = apiKeyHeaderName;
        return this;
    }
    IHttpService IHttpService.EnableLogging()
    {
        _isLoggingEnabled = true;
        return this;
    }
    IHttpService IHttpService.SetVendor(AppEnum.VendorType vendor)
    {
        _vendorId = (int)vendor;
        return this;
    }

    public async Task<(bool isFailure, string json)> GetAsync(string requestUri, object? queryParams = default, Dictionary<string, List<string>>? queryHeaders = null)
    {
        var httpRequest = await RequestBuilderAsync(HttpMethod.Get, requestUri, queryParams, queryHeaders);
        return await SendAndLogHttpRequest(httpRequest.Stopwatch, httpRequest.HttpClient, httpRequest.HttpRequestMessage);
    }

    public async Task<(bool isFailure, string json)> PostAsync(string requestUri, object? data = default, bool isAccessTokenRequest = false, Dictionary<string, List<string>>? queryHeaders = null)
    {
        if (isAccessTokenRequest)
        {
            var bearerTokenInfo = await _cacheManager.RetrieveFromCache(_cachedTokenKey) ?? string.Empty;

            if (!string.IsNullOrEmpty(bearerTokenInfo))
            {
                return (false, bearerTokenInfo);
            }
            _isTokenInfoExpired = true;
        }

        var httpRequest = await RequestBuilderAsync(HttpMethod.Post, requestUri, content: data, isAccessTokenRequest: isAccessTokenRequest, queryHeaders: queryHeaders);

        return await SendAndLogHttpRequest(httpRequest.Stopwatch, httpRequest.HttpClient, httpRequest.HttpRequestMessage);
    }

    public async Task<(bool isFailure, string json)> PutAsync(string requestUri, object? data = default, Dictionary<string, List<string>>? queryHeaders = null)
    {
        var httpRequest = await RequestBuilderAsync(HttpMethod.Put, requestUri, content: data, queryHeaders: queryHeaders);
        return await SendAndLogHttpRequest(httpRequest.Stopwatch, httpRequest.HttpClient, httpRequest.HttpRequestMessage);
    }

    public async Task<(bool isFailure, string json)> DeleteAsync(string requestUri, Dictionary<string, List<string>>? queryHeaders = null)
    {
        var httpRequest = await RequestBuilderAsync(HttpMethod.Delete, requestUri, queryHeaders: queryHeaders);
        return await SendAndLogHttpRequest(httpRequest.Stopwatch, httpRequest.HttpClient, httpRequest.HttpRequestMessage);
    }

    private async Task<(HttpRequestMessage HttpRequestMessage, HttpClient HttpClient, Stopwatch Stopwatch)> RequestBuilderAsync(HttpMethod method, string requestUri, object? queryParameters = null, Dictionary<string, List<string>>? queryHeaders = null, object? content = null, bool isAccessTokenRequest = false)
    {

        var client = _httpClientFactory.CreateClient();

        var stopwatch = Stopwatch.StartNew();

        var apiUrl = queryParameters is null ? requestUri : BuildQueryParams(requestUri, queryParameters);

        var request = new HttpRequestMessage(method, apiUrl);
        // Add API key to headers if provided

        // if (!string.IsNullOrEmpty(_apiKey) && !string.IsNullOrEmpty(_apiKeyHeaderName))
        // {
        //     client.DefaultRequestHeaders.Add(_apiKeyHeaderName, _apiKey);
        // }

        // if (_headers.Count > 0)
        // {
        //     foreach (var header in _headers)
        //     {
        //         client.DefaultRequestHeaders.Add(header.Key, header.Value);
        //     }
        // }

        // if (queryHeaders != null)
        // {
        //     foreach (var queryHeader in queryHeaders)
        //     {
        //         foreach (var value in queryHeader.Value)
        //         {
        //         }
        //     }
        // }
        client.DefaultRequestHeaders.Clear();
        client.DefaultRequestHeaders.Add("X-Goog-FieldMask", "*");

        request.Content = content is not null ? CreateJsonContent(content) : default;

        if (_isBearerTokenNeeded && !isAccessTokenRequest)
        {
            var bearerToken = await GetBearerToken(_tokenProperty);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
        }

        else if (!_isBearerTokenNeeded && _basicAuthUsername is not null && _basicAuthPassword is not null)
        {
            var authValue = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_basicAuthUsername}:{_basicAuthPassword}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authValue);
        }

        return (request, client, stopwatch);
    }

    private async Task<(bool isFailure, string json)> SendAndLogHttpRequest(Stopwatch stopwatch, HttpClient client, HttpRequestMessage? request)
    {
        var (responseBody, statusCode, isFailure, exception) = await SendHttpRequest(client, request);

        await LogHttpRequest(stopwatch, request, responseBody, statusCode, exception);

        return new() { isFailure = isFailure, json = responseBody! };
    }

    private async Task LogHttpRequest(Stopwatch stopwatch, HttpRequestMessage? request, string responseBody, int statusCode, Exception? ex = null)
    {
        var requestBody = request?.Content is not null ? await request.Content.ReadAsStringAsync() : string.Empty;

        if (ex is null)
        {
            InsertVendorLogs(stopwatch, request, statusCode, responseBody, requestBody, string.Empty);
        }

        InsertVendorLogs(stopwatch, request, AppConstant.StatusCode.InternalServerError, string.Empty, requestBody, ex?.StackTrace?.ToString());
    }

    private async Task<(string responseBody, int statusCode, bool isFailure, Exception? exception)> SendHttpRequest(HttpClient client, HttpRequestMessage? request)
    {
        string responseBody = default!;
        int statusCode = default;

        try
        {
            var httpResponseMessage = await client.SendAsync(request!);

            if (_isBearerTokenNeeded && _isTokenInfoExpired)
            {
                await StoreBearerTokenInfo(_cachedTokenKey, responseBody, _tokenExpiryProperty);
            }

            statusCode = (int)httpResponseMessage.StatusCode;

            return (responseBody, statusCode, !httpResponseMessage.IsSuccessStatusCode, null);
        }
        catch (Exception ex)
        {
            return (responseBody, statusCode, false, ex);
        }
    }
    private static StringContent CreateJsonContent(object? data)
    {
        var json = JsonSerializer.Serialize(data, new JsonSerializerOptions
        {
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        });
        return new StringContent(json, Encoding.UTF8, AppConstant.ContentType.ApplicationJson);
    }

    private void InsertVendorLogs(Stopwatch stopwatch, HttpRequestMessage? request, int statusCode, string? responseBody, string? requestBody, string? stackTraceError)
    {
        if (_isLoggingEnabled)
        {
            var logEntry = new VendorLog
            {
                RequestReference = _httpContextAccessor.HttpContext?.Items[AppConstant.Headers.RequestReference]?.ToString()!,
                ProductReference = _httpContextAccessor.HttpContext?.Items[AppConstant.Headers.ProductReference]?.ToString()!,
                RequestPath = request?.RequestUri?.ToString()!,
                RequestBody = requestBody!,
                ResponseBody = responseBody!,
                StatusCode = statusCode,
                ProcessDuration = stopwatch.ElapsedMilliseconds,
                RequestHeaders = JsonSerializer.Serialize(request?.Headers),
                ErrorReason = stackTraceError,
                RequestMethod = request?.Method.ToString()!,
                VendorId = _vendorId,
                RequestTimeStamp = DateTime.UtcNow
            };

            _unitOfWork.LoggerRepository.VendorLogInsert(logEntry);
            _unitOfWork.SaveChanges();
        }
    }

    private static string BuildQueryParams(string requestUrl, object? queryParams)
    {
        var properties = from p in queryParams?.GetType().GetProperties()
                         let jsonPropertyName = p.GetCustomAttributes(typeof(JsonPropertyNameAttribute), true)
                             .OfType<JsonPropertyNameAttribute>()
                             .FirstOrDefault()?.Name ?? p.Name
                         where p.GetValue(queryParams, null) != null
                         select jsonPropertyName + "=" + HttpUtility.UrlEncode(p.GetValue(queryParams, null)?.ToString());

        var queryString = string.Join("&", properties.ToArray());
        return $"{requestUrl}?{queryString}";
    }

    private async Task<string?> GetBearerToken(string? accessTokenKey)
    {
        var tokenInfo = await _cacheManager.RetrieveFromCache(_cachedTokenKey) ?? string.Empty;

        var authResponse = JsonSerializer.Deserialize<Dictionary<string, object>>(tokenInfo);

        var bearerToken = !string.IsNullOrEmpty(accessTokenKey) ? Convert.ToString(authResponse![accessTokenKey]) : default;

        return bearerToken;
    }
    private async Task StoreBearerTokenInfo(string? cacheTokenKey, string jsonResponse, string? bearerTokenExpiryProperty)
    {
        var authResponse = JsonSerializer.Deserialize<Dictionary<string, object>>(jsonResponse);

        var bearerTokenExpiryTime = !string.IsNullOrEmpty(bearerTokenExpiryProperty) ? Convert.ToString(authResponse![bearerTokenExpiryProperty]) : default;

        await _cacheManager.StoreInCache(cacheTokenKey, jsonResponse, bearerTokenExpiryTime);
    }
}
