﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.Airship
{
    public class TopupInfoAirship
    {
        public string Msisdn { get; set; }
        public string Amount { get; set; }
        public string Origination { get; set; }
        public bool? IsCard { get; set; }
        public bool IsSuccess { get; set; }
        public bool SaveCard { get; set; }
        public bool IsAutoTopUp { get; set; }
    }
}
