﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum DeviceType
    {
        IOS=1,
        Android=2
    }
}
