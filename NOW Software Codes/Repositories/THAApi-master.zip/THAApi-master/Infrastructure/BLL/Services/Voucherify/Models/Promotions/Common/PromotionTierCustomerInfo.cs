﻿using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Common
{
    public class PromotionTierCustomerInfo
    {
        public string SourceId { get; set; }
        public Metadata Metadata { get; set; }
    }
}
