﻿using Mapster;
using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Features.CustomerCard.Response;
using SC.Core.Features.CustomerOrder.Responses;
using SC.Core.Features.Users.Responses;
using SC.Core.Models.Dtos.CustomerCard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.MapProfiles;
public class UserProfiles : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        //Handler Query &Response should be as destination and DTOs Request & Responses should be on the right

        config.NewConfig<GetUserDetailResponse, GetUserDetailDto>()
        .TwoWays()
        .Map(des => des.UserToken, src => src.UserToken)
        .Map(des => des.UserStatus, src => src.UserStatus)
        .Map(des => des.UserID, src => src.UserID)
        .Map(des => des.TokenPurpose, src => src.TokenPurpose);

        config.NewConfig<CustomerCardDto,GetCustomerCardResponse>()
        .Map(des => des.Expiry, src  => src.Expiry.ToString("MMyy"));

        config.NewConfig<GetUserDetailDto, GetAccountDetailResponse>()
        .Map(des => des.DateOfBirth, src => src.DateOfBirth.ToString(AppConstants.CommonAppConfig.DateFormat));

        


    }
}

