﻿namespace Models.Configurations
{
    public class FCMConfig
    {
        public string ServerKey { get; set; }
        public string SenderId { get; set; }
        public string URL { get; set; }
    }
}
