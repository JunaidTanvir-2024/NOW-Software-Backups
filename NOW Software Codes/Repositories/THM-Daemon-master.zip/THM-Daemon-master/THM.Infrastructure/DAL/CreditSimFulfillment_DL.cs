﻿using Dapper;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using THM.Models.Configurations;
using THM.Models.Contracts;
using THM.Models.Database;
using THM.Models.DbConnections;
using THM.Models.Enums;

namespace THM.Infrastructure.DAL
{
    public class CreditSimFulfillment_DL : ICreditSimFulfillment_DL
    {
        private readonly IDbConnectionSettings DGT_NowMobile_Db;
        private readonly IDbConnectionSettings THM_Web_Db;
        private readonly ILogger _logger;

        public CreditSimFulfillment_DL(IOptions<ConnectionStrings> connectionString, ILogger logger)
        {
            DGT_NowMobile_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigiTalkNowMobileConnection));
            THM_Web_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.THWEbConnection));
            _logger = logger;
        }

        public async Task<IEnumerable<DbSimOrderPool>> GetActiveNumbersFromPool()
        {
            return await DGT_NowMobile_Db.SqlConnection.QueryAsync<DbSimOrderPool>(
                                                    "thm_creditSim_fulfillment_getActiveNumbers", commandType: CommandType.StoredProcedure);
        }

        public async Task<DbResult<List<DbCreditSimOrderDetail>>> GetCreditSimOrderDetail(string msisdn)
        {
            DbResult<List<DbCreditSimOrderDetail>> response = new DbResult<List<DbCreditSimOrderDetail>>();

            var parameter = new DynamicParameters();
            parameter.Add("@msisdn", msisdn);

            var result = await THM_Web_Db.SqlConnection.QueryAsync<DbCreditSimOrderDetail>(
                                                    "th_get_creditSim_order_detail", parameter, commandType: CommandType.StoredProcedure);
            if (result == null)
            {
                response.DBStatus = DbStatus.Failure;
                response.ErrorCode = 2;
                response.DBErrorMessage = "No Record Found.";
            }
            else
            {
                response.DBStatus = DbStatus.Success;
                response.ErrorCode = 1;
                response.DBErrorMessage = "";
                response.Data = result.AsList();
            }

            return response;
        }

        public async Task<DbResult<DbAddBundleOrTopupResult>> AddBundleOrTopup(
            string transactionId, string bundleRef, string amount, string msisdn, PaymentType paymentType, string customerEmail)
        {

            if (string.IsNullOrWhiteSpace(bundleRef))
            {
                bundleRef = "";
            }

            string creditReason = "TalkHome Credit SIM Topup";
            string paymentMethod = "Paypal Topup";

            if (paymentType == PaymentType.Card)
            {
                paymentMethod = "Pay360 Topup";
            }

            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@bundleref", bundleRef);
            parameters.Add("@productref", msisdn);
            parameters.Add("@amount", Decimal.Parse(amount));
            parameters.Add("@transactionid", transactionId);
            parameters.Add("@bundlename", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
            parameters.Add("@ProductCode", "THM");
            parameters.Add("@Email", customerEmail);
            parameters.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);


            var result = await DGT_NowMobile_Db.SqlConnection.QueryFirstOrDefaultAsync<DbFullfilmentResult>(
                                        "thm_pay360_accountupdatebalance_v3", parameters, commandType: CommandType.StoredProcedure);
            if (result == null)
            {
                _logger.Error($"Class: CreditSimFulfillment_DL, Method: AddBundleOrTopup, Parameters => transactionId: " +
                                        $"{transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {msisdn}, " +
                                        $"paymentType: {paymentType}, ErrorMessage: Null response received from database.");


                return new DbResult<DbAddBundleOrTopupResult>
                {
                    DBStatus = DbStatus.Failure,
                    DBErrorMessage = "Null response received from database.",
                    ErrorCode = 1
                };
            }

            int ErrorCode = parameters.Get<int>("@error_code");
            string ErrorMessage = parameters.Get<string>("@error_msg");

            if (ErrorCode > 0)
            {
                return new DbResult<DbAddBundleOrTopupResult>
                {
                    DBStatus = DbStatus.Failure,
                    DBErrorMessage = ErrorMessage,
                    ErrorCode = 1
                };
            }

            DbAddBundleOrTopupResult responseData = new DbAddBundleOrTopupResult();
            responseData.audit_id = result.audit_id.ToString();
            responseData.bundleName = parameters.Get<string>("@bundlename");
            return new DbResult<DbAddBundleOrTopupResult> { DBStatus = DbStatus.Success, DBErrorMessage = "", ErrorCode = 0, Data = responseData };

        }

        public async Task<DbResult<string>> UpdateCreditSimFullfilment(long id, bool isFullfilled, string fulfillment_error_message, string fulfillment_ref)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@id", id);
            parameters.Add("@isFullfilled", isFullfilled);
            parameters.Add("@fulfillment_error_message", fulfillment_error_message);
            parameters.Add("@fulfillment_ref", fulfillment_ref);

            var result = await THM_Web_Db.SqlConnection.ExecuteAsync("th_update_creditSim_Fullfilment", parameters, commandType: CommandType.StoredProcedure);
            if (result > 0)
            {
                return new DbResult<string> { DBStatus = DbStatus.Success, DBErrorMessage = "", ErrorCode = 0 };
            }
            else
            {
                _logger.Error($"Class: CreditSimFulfillment_DL, Method: UpdateCreditSimFullfilment, Parameters => id: {id}, " +
                    $"isFullfilled: {isFullfilled}, fulfillment_error_message: {fulfillment_error_message}, " +
                    $"fulfillment_ref: {fulfillment_ref}, ErrorMessage: Error in Data updation.");

                return new DbResult<string> { DBStatus = DbStatus.Failure, DBErrorMessage = "Error in Data updation.", ErrorCode = 1 };
            }
        }

        public async Task UpdateCreditSimFullfilmentInSimPool(int id, bool isFullfiled, string errorMessage)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@id", id);
            parameters.Add("@isFullfilled", isFullfiled);
            parameters.Add("@fulfillment_error_message", errorMessage);

            await DGT_NowMobile_Db.SqlConnection.ExecuteAsync("thm_creditSim_fulfillment_updateFullfillmentStatus", parameters, commandType: CommandType.StoredProcedure);
        }
    }
}
