﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SC.Core.Features.Countries.Requests;
using SC.Core.Features.PaymentMethod;

namespace SC.Api.Controllers.V1;
[ApiVersion(1.0)]
public sealed class PaymentMethodController : BaseApiController
{
    [Authorize]
    [HttpGet]
    public async Task<ActionResult> GetPaymentMethods()
    {
        var result = await Mediator.Send(new GetPaymentMethodRequest() { });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}

