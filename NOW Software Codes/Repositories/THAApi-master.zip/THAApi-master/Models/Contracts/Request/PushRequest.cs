﻿using Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Models.Contracts.Request
{

    public class NotificationTag
    {
        private NotificationTag() { }

        public NotificationTag(string msisdn)
        {
            Msisdn = msisdn;
            QueuedAt = DateTime.Now;
            semaphore = new SemaphoreSlim(0, 1);
        }

        public string Msisdn { get; private set; }
        public DateTime QueuedAt { get; private set; }

        private SemaphoreSlim semaphore;
        private bool result;

        public void SetResult(bool Result)
        {
            result = Result;
            semaphore.Release();
        }

        public async Task<bool> GetResultAsync()
        {
            await semaphore.WaitAsync();
            return result;
        }
    }
    public class PushPayload
    {
        public string MessageTitle;
        public string MessageBody;
        public JObject Data; // Free-form app specific data
        public string Token;

        public bool ExpiresImmediately;
        public bool PrefersPushKit;

        public void PopulateFlags()
        {
            // VoIP notifications should be delivered immediately or not at all
            ExpiresImmediately = Data != null && (
                Data["sip_calling"] != null ||
                Data["sip_ready"] != null ||
                false);

            PrefersPushKit = Data != null && (
                Data["sip_calling"] != null ||
                Data["sip_ready"] != null ||
                Data["xmpp_from"] != null ||
                false);
        }
    }
    public class FCMPushRequest
    {
        //[JsonProperty("to")]
        //[Required]
        //public string To { get; set; }
        public string DeviceToken { get; set; }
        public FCMNotificationTypes NotificationType { get; set; }

        public string MessageTitle { get; set; }

        public string MessageBody { get; set; }
        public string sip_calling { get; set; }
        public string call_uuid { get; set; }
        public string xmpp_message { get; set; }
    }

    public class APNSPushRequest
    {
        //[JsonProperty("to")]
        //[Required]
        //public string To { get; set; }
        public ApnServerType server { get; set; }
        public string DeviceToken { get; set; }
        public APNSNotificationTypes NotificationType { get; set; }


        public string MessageTitle { get; set; }


        public string MessageBody { get; set; }
        public string sip_calling { get; set; }
        public string call_uuid { get; set; }
        public string xmpp_message { get; set; }
    }


    public class PushRequest
    {
        //[JsonProperty("to")]
        //[Required]
        //public string To { get; set; }
        public ApnServerType server { get; set; }
        public string DeviceToken { get; set; }
        public NotificationTypes NotificationType { get; set; }

        public string MessageTitle { get; set; }

        public string MessageBody { get; set; }
        public string sip_calling { get; set; }
        public string call_uuid { get; set; }
        public string xmpp_message { get; set; }
    }

    public class PushRegistration
    {
        public string msisdn { get; set; }
        public string gcm { get; set; }
        public string apns { get; set; }
        public string pushKit { get; set; }
        public bool sandbox { get; set; }
        public string version { get; set; }
        public string language { get; set; }

        public bool IsAndroid() { return gcm != null; }
        public bool IsIos() { return apns != null || pushKit != null; }

        public bool WantsXmppMessageBody()
        {
            // Recent versions of the app fetch the message body over XMPP and ignore the push payload

            if (IsAndroid() && version != null)
                return System.Version.Parse("2.5.3") <= System.Version.Parse(version);

            if (IsIos() && version != null)
                return System.Version.Parse("2.5.2") <= System.Version.Parse(version);

            return true;
        }

        public bool WantsXmppMessageViaPushKit()
        {
            if (version == null || pushKit == null)
                return false;

            // Sending message notifications via PushKit ensures the app is launched after a force quit
            return System.Version.Parse("2.5.3") <= System.Version.Parse(version);
        }
    }

}
