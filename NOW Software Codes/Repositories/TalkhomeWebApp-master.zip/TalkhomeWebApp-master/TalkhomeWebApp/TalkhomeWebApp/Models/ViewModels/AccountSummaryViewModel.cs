﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.ApiContracts.Request;
using TalkhomeWebApp.Models.ApiContracts.Response;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class AccountSummaryViewModel
    {
        public string UserCurrencySymbol { get; set; }
        public AutoTopUpSettings AutoTopUp { get; set; }
    }

    public class AutoTopUpSettings
    {
        [Required(ErrorMessage = "Select Threshold Amount")]
        [CollectionValidation(values: new int[] { 1, 3, 5 })]
        public int thresholdBalanceAmount { get; set; }

        [Required(ErrorMessage = "Select TopUp Amount")]
        [CollectionValidation(values: new int[] { 5, 10, 15, 20, 25 })]
        public int amount { get; set; }

        public bool isActive { get; set; }
    }

    public class SetAutoTopupWithCardResponseModel
    {
        public ThreeDSecureData threeDSecureData { get; set; }
        public AutoTopupInfo AutoTopupInfo { get; set; }
    }
    public class SetAutoRenewalWithCardResponseModel
    {
        public ThreeDSecureData threeDSecureData { get; set; }
    }
    public class SetAutoTopupWithCardRequestModel
    {
        [Required(ErrorMessage = "Select Threshold Amount")]
        [CollectionValidation(values: new int[] { 1, 3, 5 })]
        public int ThresholdBalanceAmount { get; set; }

        [Required(ErrorMessage = "Select TopUp Amount")]
        [CollectionValidation(values: new int[] { 5, 10, 15, 20, 25 })]
        public int Amount { get; set; }
        [Required]
        public string IpAddress { get; set; }
        public NewCardInfo NewCardInfo { get; set; }
        public ExistingCardInfo ExistingCardInfo { get; set; }
        public BillingAddressModel AddressInfo { get; set; }
    }
    public class SetAutoRenewalWithCardRequestModel
    {
        [Required]
        public string BundleId { get; set; }
        [Required]
        public string IpAddress { get; set; }
        public NewCardInfo NewCardInfo { get; set; }
        public ExistingCardInfo ExistingCardInfo { get; set; }
        public BillingAddressModel AddressInfo { get; set; }
    }
    public class NewCardInfo
    {
        [Required(ErrorMessage = "Enter name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid Name")]
        public string NameOnCard { get; set; }

        [Required(ErrorMessage = "Enter card number")]
        [StringLength(maximumLength: 19, ErrorMessage = "Length must be between (16-19)", MinimumLength = 16)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string CardNumber { get; set; }

        [Required(ErrorMessage = "Select month")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string ExpiryMonth { get; set; }

        [Required(ErrorMessage = "Select year")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string ExpiryYear { get; set; }

        [Required(ErrorMessage = "Enter security code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string SecurityCode { get; set; }
    }
    public class ExistingCardInfo
    {
        [Required]
        [MaxLength(300)]
        public string cardToken { get; set; }

        [Required(ErrorMessage = "Enter Security Code"),
            StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string securityCode { get; set; }
    }
    public class CollectionValidationAttribute : ValidationAttribute
    {
        private readonly int[] values;

        public CollectionValidationAttribute(int[] values)
        {
            this.values = values;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (!values.Contains((int)value))
                return new ValidationResult("Invalid amount");

            return ValidationResult.Success;
        }
    }
}
