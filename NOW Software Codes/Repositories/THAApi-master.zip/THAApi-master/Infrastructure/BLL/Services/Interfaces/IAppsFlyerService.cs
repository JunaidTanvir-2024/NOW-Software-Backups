﻿using Models.Contracts.Request;
using Models.Contracts.Request.AppsFlyer;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface IAppsFlyerService
    {
        Task CreateCustomEvent(List<CreateEventRequestModel> request);
        Task HandleTopupEvents(string AppsFlyerId, DeviceType DeviceType, bool IsSuccess, bool? IsCard, decimal Amount, string currency, string origination,string ipAddress=null);
        Task HandleBundlePurchaseEvents(string AppsFlyerId, DeviceType DeviceType, string origination, string destination, BundleType BundleType, bool IsSuccess, bool? IsCard, decimal Amount, string currency,string ipAddress = null);
        Task HandleIntTopupEvents(string AppsFlyerId, DeviceType DeviceType, string origination, string destination, bool IsSuccess, bool? IsCard, decimal Amount,string ipAddress,bool isTransferRequest);
        Task HandleAutoTopup(string AppsFlyerId, DeviceType DeviceType, bool isActive, decimal Amount, string ipAddress = null);

    }
}
