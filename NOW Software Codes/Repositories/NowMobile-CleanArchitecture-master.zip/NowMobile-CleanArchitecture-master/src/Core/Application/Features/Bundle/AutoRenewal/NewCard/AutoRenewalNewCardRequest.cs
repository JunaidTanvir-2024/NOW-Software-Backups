using Application.Features.Payment.Card.Models;

namespace Application.Features.Bundle.AutoRenewal.NewCard;
public class AutoRenewalNewCardRequest : IRequest<Result<CardResponse>>

{
    public string Msisdn { get; set; } = default!;
    public int BundleId { get; set; } = default!;
    public bool IsAutoRenew { get; set; } = default!;
    public string IpAddress { get; set; } = string.Empty;
    public PaymentNewCardInfo PaymentCardInfo { get; set; } = new PaymentNewCardInfo();
    public PaymentAddressInfo PaymentAddressInfo { get; set; } = new PaymentAddressInfo();
}