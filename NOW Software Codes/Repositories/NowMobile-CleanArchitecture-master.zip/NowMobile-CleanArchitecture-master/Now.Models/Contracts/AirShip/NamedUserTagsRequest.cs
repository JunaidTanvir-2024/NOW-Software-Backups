﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Now.Models.Contracts.AirShip;
public class NamedUserTagsRequest
{
    [JsonProperty("NamedUser")]
    public string NamedUser { get; set; }

    [JsonProperty("ProductCode")]
    public string ProductCode { get; set; }

    [JsonProperty("TagGroup")]
    public string TagGroup { get; set; }

    [JsonProperty("Tags")]
    public List<string> Tags { get; set; }
}