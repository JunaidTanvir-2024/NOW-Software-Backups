namespace Application.Features.Identity.Signup.SignupResend;

public sealed class SignupResendRequestValidator : AbstractValidator<SignupResendRequest>
{
    public SignupResendRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.EmailAddress)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .Must(p => commonService.IsValidEmailAddress(p))
            .WithMessage("Invalid Emaill Address");

        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid Msisdn");
    }
}