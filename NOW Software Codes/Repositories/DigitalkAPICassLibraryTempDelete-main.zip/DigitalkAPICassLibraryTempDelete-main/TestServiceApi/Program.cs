using Application;
using Application.Common.Configurations;
using FluentValidation.AspNetCore;
using Infrastructure;
using Serilog;

try
{
    IConfiguration configuration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
    var builder = WebApplication.CreateBuilder(new WebApplicationOptions()
    {
        EnvironmentName = configuration["Environment"]
    });
    {
        builder.Host.AddJsonFilesConfigurations();
    }
    builder.Host.UseSerilog((hostingContext, config) => config.ReadFrom.Configuration(hostingContext.Configuration));
    #region Layers registration
    builder.Services.AddControllers();
    
    builder.Services.AddFluentValidationAutoValidation().AddFluentValidationClientsideAdapters();

    builder.Services
        //.AddSharedServices()
        .AddApplicationServices(builder.Configuration)
        .AddInfrastructureServices(builder.Configuration);


    
    builder.Services.AddSwaggerGen();
    

    //.AddJwtAuthServices(builder.Configuration); 
    #endregion

    builder.Services.Configure<ApiBehaviorOptions>(options => options.SuppressModelStateInvalidFilter = true);
    
    var app = builder.Build();
    app.UseSwagger();
    app.UseSwaggerUI();
    app.UseRouting();
    app.MapControllers();

    app.Run();
}
catch (Exception ex) when (!ex.GetType().Name.Equals("StopTheHostException", StringComparison.Ordinal))
{
   // StaticLogger.EnsureInitialized();
    Log.Fatal(ex, "Unhandled exception");
}
finally
{
    //StaticLogger.EnsureInitialized();
    Log.Information("Server Shutting down...");
    Log.CloseAndFlush();
}

