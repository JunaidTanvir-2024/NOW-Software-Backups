using System.Text.RegularExpressions;

using FluentValidation;
using FluentValidation.Results;

using PhoneNumbers;

using RW;

using Serilog;

using Voucherify.Core.Services.Loggers;

namespace Voucherify.Core.Commons.Extensions;

public static class FluentValidationExtensions
{
    public static async Task<IResultWrapper<List<ValidationFailure>>> ValidateAndGetErrorAsync<T>(this IValidator<T> validator, T request)
    {
        ValidationResult? validationResult = await validator.ValidateAsync(request);
        var errorMessages = validationResult.Errors.Select(x => new { errorMessage = $"{x.PropertyName} is not valid property", param = x.PropertyName });

        return !validationResult.IsValid ? ResultWrapper.Failure<List<ValidationFailure>>(validationResult.Errors) : ResultWrapper.Success<List<ValidationFailure>>();
    }

    public static IRuleBuilderOptions<T, string?> FormatPhoneNumber<T>(
    this IRuleBuilder<T, string?> ruleBuilder,
    Action<T, string> phoneNumberSetter)
    {
        return ruleBuilder.Must((rootObject, phoneNumber, _) =>
        {
            if (phoneNumber?.StartsWith("+") == true)
            {
                phoneNumberSetter(rootObject, phoneNumber.Replace("+", ""));
            }
            else
            {
                phoneNumberSetter(rootObject, phoneNumber!);
            }
            return true;
        });
    }
    public static IRuleBuilderOptions<T, string?> IsValidEmailAddress<T>(this IRuleBuilder<T, string?> ruleBuilder)
    {
        var emailValidationRegex = @"^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$";

        var emailValidationRegexCompiled = new Regex(emailValidationRegex, RegexOptions.IgnoreCase);
        return ruleBuilder
            .Must(email =>
            {
                return GetEmailAddressValidity(email, emailValidationRegexCompiled); ;

            }).WithMessage("Invalid email address format.").NotEmpty().WithMessage("Email address is required.");
    }

    private static bool GetEmailAddressValidity(string? email, Regex emailValidationRegexCompiled)
    {
        var emailParts = email?.Split('@', StringSplitOptions.RemoveEmptyEntries);

        if (emailParts?.Length == 2 && emailParts[1].Contains('.'))
        {
            var isValidRegex = emailValidationRegexCompiled.IsMatch(email!);
            var isValidFormat = new System.ComponentModel.DataAnnotations.EmailAddressAttribute().IsValid(email);

            return isValidRegex && isValidFormat;
        }
        return false;
    }
}
