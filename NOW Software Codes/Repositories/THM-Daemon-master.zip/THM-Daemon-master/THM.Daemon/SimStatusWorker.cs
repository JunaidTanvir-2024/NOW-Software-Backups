﻿
using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using THM.Infrastructure.BLL;

namespace THM.Daemon
{
    public class SimStatusWorker : BackgroundService
    {
        private readonly ILogger<AirshipWorker> _logger;
        private readonly IAirship_BL _airship_BL;
        private readonly Serilog.ILogger _serilogLogger;

        public SimStatusWorker(
            ILogger<AirshipWorker> logger, 
            IAirship_BL airship_BL,
            Serilog.ILogger serilogLogger)
        {
            _logger = logger;
            _airship_BL = airship_BL;
            _serilogLogger = serilogLogger;
        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await _airship_BL.AddSimStatusAirShipEventsAndTags();
                }
                catch (Exception ex)
                {
                    _logger.LogError("SimStatusWorker,  " +
                                     "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                     "StackTrace: " + ex.StackTrace);

                    _serilogLogger.Error("SimStatusWorker,  " +
                         "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                         "StackTrace: " + ex.StackTrace);
                }
                await Task.Delay(TimeSpan.FromHours(24), stoppingToken);
            }
        }
    }
}