﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBPromotions
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Priority { get; set; }
        public bool IsAllowedMultiplePromotions { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public PromotionType Type { get; set; }
        public AudienceType Audience { get; set; }
         public PromotionDependentTypes PromotionDependentType { get; set; }
        public OfferUnitTypes OfferUnit { get; set; }
        public decimal OfferValue { get; set; }
        
    }
}
