﻿using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests
{
    public class UpdateVoucherifyCustomerRequest
    {
        public string SourceId { get; set; } = null!;
        public Metadata Metadata { get; set; }
    }
}
