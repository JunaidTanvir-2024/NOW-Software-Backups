﻿using System;

namespace THCC.Application.Features.User.History.CallingCardsHistory;

public class CallingCardsHistoryRequest : IRequest<object> { }

