﻿using Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PayPalInApp.Configurations;
using PayPalInApp.Interfaces;
using PayPalInApp.Models;
using PayPalInApp.Models.AirShip;
using PayPalInApp.Models.Configurations;
using PayPalInApp.Models.DbConnections;
using PayPalInApp.Models.Enums;
using PayPalInApp.Models.Paypal;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace PayPalInApp.Controllers
{
    [Route("app")]
    public class TopUpController : Controller
    {
        private readonly ILogger Logger;
        private readonly IPayPalService PayPalService;
        private readonly IAirShipService AirShipService;
        private readonly string PaymentTagGroupName;
        private readonly string CustomerTagGroupName;
        private IDbConnectionSettings TalkHomeConnection;
        private string DigitalkMobileDbConnectionString;
        private readonly bool IsAirShipActive;
        public TopUpController(IPayPalService payPalService, IAirShipService airShipService, ILogger logger, IOptions<AirShipConfig> airShipConfig, IOptions<ConnectionStrings> connectionConfig)
        {
            Logger = logger;
            PayPalService = payPalService;
            AirShipService = airShipService;
            PaymentTagGroupName = airShipConfig.Value.PaymentTagGroupName;
            CustomerTagGroupName = airShipConfig.Value.CustomerTagGroupName;
            TalkHomeConnection = new DbConnectionSettings(new SqlConnection(connectionConfig.Value.TalkHomeDigitalkDb));
            DigitalkMobileDbConnectionString = connectionConfig.Value.DigitalkMobileDb;
            IsAirShipActive = airShipConfig.Value.IsActive;
        }

        // GET
        [Route("paypal")]
        public async Task<ActionResult> paypal(string msisdn, string currency, string il8n, string utm_campaign, string utm_medium, string utm_source)
        {
            try
            {


                PaypalTopUpViewModel viewModel = new PaypalTopUpViewModel
                {
                    msisdn = msisdn,
                    currency = currency,
                    language = il8n,
                    utm_campaign = utm_campaign,
                    utm_medium = utm_medium,
                    utm_source = utm_source
                };

                return View("~/Views/TopUp/TopUpPrices.cshtml", viewModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: TopUpController, Method: paypal, Parameters=> msisdn: {msisdn}, currency: {currency}, language={il8n}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [HttpPost]
        [Route("payPalStartPayment")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> PayPalStartPayment(PaypalStartPaymentModel model)
        {
            try
            {
             
                var baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                PayPalCreateSalePaymentRequest request = new PayPalCreateSalePaymentRequest
                {
                    CustomerName = model.msisdn,
                    CustomerMsisdn = model.msisdn,
                    CustomerUniqueRef = model.msisdn,
                    RedirectUrl = new RedirectUrls
                    {
                        ReturnUrl = PayPalService.GetResumeUrl("app/topUpSuccessReturn?reference=" + model.msisdn + "&amount=" + model.amount + "&currency=" + model.currency + "&utm_source=" + model.utm_source + "&utm_medium=" + model.utm_medium + "&utm_campaign=" + model.utm_campaign, baseUrl),
                        CancelUrl = PayPalService.GetResumeUrl("app/cancelReturn", baseUrl)
                    }
                };

                var response = await PayPalService.PayPalCreateSalePayment(request, model);

                if (response == null)
                {
                    ViewBag.Msg = "Payment Service is not responding at the moment. Please try again later";
                    ViewBag.ErrorCode = 2;
                    return View("~/Views/Shared/Result.cshtml");

                }
                if (response.errorCode > 0)
                {
                    TempData["ErrorCode"] = 999;
                    ViewBag.Msg = response.message;
                    ViewBag.ErrorCode = response.errorCode;
                    return View("~/Views/Shared/Result.cshtml");
                }
                return Redirect(response.payload.RedirectUrl);
            }
            catch (System.Exception ex)
            {
                Logger.Error($"Controller: TopUpController, Method: PayPalStartPayment, Parameters=> PaypalStartPaymentModel: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("topUpSuccessReturn")]
        public async Task<ActionResult> TopUpSuccessReturn(SuccessReturnPayPalViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ViewBag.Msg = "Something wrong happened. Please try again later.";
                    return View("/Views/Shared/Result.cshtml");
                }

                PayPalExecuteSalePaymentRequest PaymentRequest = new PayPalExecuteSalePaymentRequest
                {
                    CustomerUniqueRef = model.reference,
                    PayerId = model.PayerID,
                    PaymentId = model.paymentId,
                    ProductCode = "THA"
                };

                var response = await PayPalService.PayPalExecuteSalePayment(PaymentRequest);

                if (response == null)
                {
                    ViewBag.Msg = "Payment Service is not responding at the moment. Please try again later.";
                    ViewBag.ErrorCode = 2;
                    return View("~/Views/Shared/Result.cshtml");
                }

                ViewBag.Msg = response.message;
                ViewBag.ErrorCode = response.errorCode;


                if(IsAirShipActive)
                {
                    var isFirstTopup = await FirstTopUp(model.reference);

                    var isSuccess = response.errorCode == 0 ? true : false;

                    #region AirShipTags

                    List<string> tags = new List<string>();
                    if (isSuccess)
                    {
                        tags.Add(Tags.topupany_app.ToString());
                        tags.Add(Tags.purchase_success.ToString());
                        if (isFirstTopup)
                        {
                            tags.Add(Tags.topup_app.ToString());
                        }

                        switch (Convert.ToInt32(model.amount))
                        {
                            case 5:
                                tags.Add(Tags.topup5_app.ToString());
                                break;
                            case 10:
                                tags.Add(Tags.topup10_app.ToString());
                                break;
                            case 15:
                                tags.Add(Tags.topup15_app.ToString());
                                break;
                            case 20:
                                tags.Add(Tags.topup20_app.ToString());
                                break;
                            case 25:
                                tags.Add(Tags.topup25_app.ToString());
                                break;
                        }
                    }
                    else
                    {
                        tags.Add(Tags.purchase_failure.ToString());
                    }

                    NamedUserTagsRequest namedUserTagsRequest = new NamedUserTagsRequest()
                    {
                        ProductCode = ProductCode.THA.ToString(),
                        NamedUser = model.reference,
                        TagGroup = PaymentTagGroupName,
                        Tags = tags


                    };
                    AirShipService.AddNamedUserTags(namedUserTagsRequest);

                    #region Customer Tags
                    tags = new List<string>();
                    tags.Add(Tags.tha_customer_app.ToString());
                    namedUserTagsRequest = new NamedUserTagsRequest()
                    {
                        ProductCode = ProductCode.THA.ToString(),
                        NamedUser = model.reference,
                        TagGroup = CustomerTagGroupName,
                        Tags = tags


                    };
                    AirShipService.AddNamedUserTags(namedUserTagsRequest);
                    #endregion

                    #endregion

                    #region AirShipCustomEvents 
                    CustomEventsRequest customEventsRequest = new CustomEventsRequest()
                    {
                        ProductCode = ProductCode.THA.ToString(),
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = model.reference,
                        Value = Convert.ToDouble(model.amount),
                        Transaction = response.payload.PaypalTransactionId,
                        InteractionId = "Topup/Card",
                        InteractionType = "url"
                    };

                    if (isSuccess)
                    {
                        switch (Convert.ToInt32(model.amount))
                        {
                            case 5:
                                customEventsRequest.CustomEventName = CustomEvents.topup5_app.ToString();
                                break;
                            case 10:
                                customEventsRequest.CustomEventName = CustomEvents.topup10_app.ToString();
                                break;
                            case 15:
                                customEventsRequest.CustomEventName = CustomEvents.topup15_app.ToString();
                                break;
                            case 20:
                                customEventsRequest.CustomEventName = CustomEvents.topup20_app.ToString();
                                break;
                            case 25:
                                customEventsRequest.CustomEventName = CustomEvents.topup25_app.ToString();
                                break;
                        }
                    }
                    else
                    {
                        customEventsRequest.CustomEventName = CustomEvents.purchase_failure.ToString();
                    }

                    customEventsRequest.Properties = new Dictionary<string, string>();
                    customEventsRequest.Properties.Add("Amount", model.amount);
                    customEventsRequest.Properties.Add("TransactionId", response.payload.PaypalTransactionId);
                    customEventsRequest.Properties.Add("isSuccess", isSuccess == true ? "true" : "false");
                    customEventsRequest.Properties.Add("Currency", model.currency);
                    customEventsRequest.Properties.Add("Msisdn", model.reference);
                    customEventsRequest.Properties.Add("utmCampaign", model.utm_campaign ?? "");
                    customEventsRequest.Properties.Add("utmMedium", model.utm_medium ?? "");
                    customEventsRequest.Properties.Add("utmSource", model.utm_source ?? "");

                    AirShipService.AddCustomEvent(customEventsRequest);

                    //add success event as well
                    if (isSuccess)
                    {
                        customEventsRequest.CustomEventName = CustomEvents.purchase_success.ToString();
                        AirShipService.AddCustomEvent(customEventsRequest);
                    }

                    #endregion
                }

                if (response.errorCode > 0)
                {
                    TempData["ErrorCode"] = 999;

                    return View("~/Views/Shared/Result.cshtml");
                }

                model.transactionId = PaymentRequest.PaymentId;

                return View("~/Views/Shared/Result.cshtml", model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: TopUpController, Method: TopUpSuccessReturn, Parameters=> SuccessReturnPayPalViewModel: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("cancelReturn")]
        public async Task<ActionResult> CancelReturn(CancelReturnPayPalViewModel model)
        {
            try
            {
                ViewBag.Msg = "PayPal Payment Cancelled";
                ViewBag.ErrorCode = 2;
                return View("~/Views/Shared/Result.cshtml");
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: TopUpController, Method: CancelReturn, Parameters=> CancelReturnPayPalViewModel: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }



        [HttpPost]
        [Route("pay360payPalStartPayment")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Pay360PayPalStartPayment(PaypalStartPaymentModel model)
        {
            try
            {
                var baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                var isFirstTopup = await FirstTopUp(model.msisdn);

                string FirstUseDate = await Get_Sim_ActivationDate(model.msisdn);
                var response = await PayPalService.Pay360PayPalCreateSalePayment(model, baseUrl, GetRemoteIPAddress(HttpContext),FirstUseDate);

                if (response == null)
                {
                    ViewBag.Msg = "Payment Service is not responding at the moment. Please try again later";
                    ViewBag.ErrorCode = 2;
                    return View("~/Views/Shared/Result.cshtml");

                }
                if (response.errorCode > 0)
                {
                    TempData["ErrorCode"] = 999;
                    ViewBag.Msg = response.message;
                    ViewBag.ErrorCode = response.errorCode;
                    return View("~/Views/Shared/Result.cshtml");
                }

                return Redirect(response.payload.clientRedirectUrl);
            }
            catch (System.Exception ex)
            {
                Logger.Error($"Controller: TopUpController, Method: Pay360PayPalStartPayment, Parameters=> PaypalStartPaymentModel: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("pay360topUpSuccessReturn")]
        public async Task<ActionResult> Pay360TopUpSuccessReturn(SuccessReturnPayPalViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ViewBag.Msg = "Something wrong happened. Please try again later.";
                    return View("/Views/Shared/Result.cshtml");
                }

                Pay360PayPalResumePaymentRequest request = new Pay360PayPalResumePaymentRequest
                {
                    PaypalCheckoutToken = model.token
                };

                var response = await PayPalService.Pay360ResumePayment(request);

                if (response == null)
                {
                    ViewBag.Msg = "Payment Service is not responding at the moment. Please try again later.";
                    ViewBag.ErrorCode = 2;
                    return View("~/Views/Shared/Result.cshtml");
                }

                ViewBag.Msg = response.message;
                ViewBag.ErrorCode = response.errorCode;

                if (IsAirShipActive)
                {
                    var isSuccess = response.errorCode == 0 ? true : false;

                    var isFirstTopup = await FirstTopUp(model.reference);

                    #region AirShipTags

                    List<string> tags = new List<string>();
                    if (isSuccess)
                    {
                        tags.Add(Tags.topupany_app.ToString());
                        tags.Add(Tags.purchase_success.ToString());
                        if (isFirstTopup)
                        {
                            tags.Add(Tags.topup_app.ToString());
                        }

                        switch (Convert.ToInt32(model.amount))
                        {
                            case 5:
                                tags.Add(Tags.topup5_app.ToString());
                                break;
                            case 10:
                                tags.Add(Tags.topup10_app.ToString());
                                break;
                            case 15:
                                tags.Add(Tags.topup15_app.ToString());
                                break;
                            case 20:
                                tags.Add(Tags.topup20_app.ToString());
                                break;
                            case 25:
                                tags.Add(Tags.topup25_app.ToString());
                                break;
                        }
                    }
                    else
                    {
                        tags.Add(Tags.purchase_failure.ToString());
                    }

                    NamedUserTagsRequest namedUserTagsRequest = new NamedUserTagsRequest()
                    {
                        ProductCode = ProductCode.THA.ToString(),
                        NamedUser = model.reference,
                        TagGroup = PaymentTagGroupName,
                        Tags = tags


                    };
                    AirShipService.AddNamedUserTags(namedUserTagsRequest);

                    #region Customer Tags
                    tags = new List<string>();
                    tags.Add(Tags.tha_customer_app.ToString());
                    namedUserTagsRequest = new NamedUserTagsRequest()
                    {
                        ProductCode = ProductCode.THA.ToString(),
                        NamedUser = model.reference,
                        TagGroup = CustomerTagGroupName,
                        Tags = tags


                    };
                    AirShipService.AddNamedUserTags(namedUserTagsRequest);
                    #endregion

                    #endregion

                    #region AirShipCustomEvents 
                    CustomEventsRequest customEventsRequest = new CustomEventsRequest()
                    {
                        ProductCode = ProductCode.THA.ToString(),
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = model.reference,
                        Value = Convert.ToDouble(model.amount),
                        Transaction = response.payload.transactionId,
                        InteractionId = "Topup/Card",
                        InteractionType = "url"
                    };

                    if (isSuccess)
                    {
                        switch (Convert.ToInt32(model.amount))
                        {
                            case 5:
                                customEventsRequest.CustomEventName = CustomEvents.topup5_app.ToString();
                                break;
                            case 10:
                                customEventsRequest.CustomEventName = CustomEvents.topup10_app.ToString();
                                break;
                            case 15:
                                customEventsRequest.CustomEventName = CustomEvents.topup15_app.ToString();
                                break;
                            case 20:
                                customEventsRequest.CustomEventName = CustomEvents.topup20_app.ToString();
                                break;
                            case 25:
                                customEventsRequest.CustomEventName = CustomEvents.topup25_app.ToString();
                                break;
                        }
                    }
                    else
                    {
                        customEventsRequest.CustomEventName = CustomEvents.purchase_failure.ToString();
                    }

                    customEventsRequest.Properties = new Dictionary<string, string>();
                    customEventsRequest.Properties.Add("Amount", model.amount.ToString());
                    customEventsRequest.Properties.Add("TransactionId", response.payload.transactionId);
                    customEventsRequest.Properties.Add("isSuccess", isSuccess == true ? "true" : "false");
                    customEventsRequest.Properties.Add("Currency", model.currency);
                    customEventsRequest.Properties.Add("Msisdn", model.reference);
                    customEventsRequest.Properties.Add("utmCampaign", model.utm_campaign ?? "");
                    customEventsRequest.Properties.Add("utmMedium", model.utm_medium ?? "");
                    customEventsRequest.Properties.Add("utmSource", model.utm_source ?? "");

                    AirShipService.AddCustomEvent(customEventsRequest);

                    //add success event as well
                    if (isSuccess)
                    {
                        customEventsRequest.CustomEventName = CustomEvents.purchase_success.ToString();
                        AirShipService.AddCustomEvent(customEventsRequest);
                    }

                    #endregion
                }

                if (response.errorCode > 0)
                {
                    TempData["ErrorCode"] = 999;

                    return View("~/Views/Shared/Result.cshtml");
                }

                model.transactionId = response.payload.transactionId;

                return View("~/Views/Shared/Result.cshtml", model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: TopUpController, Method: Pay360TopUpSuccessReturn, Parameters=> SuccessReturnPayPalViewModel: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }


        private string GetRemoteIPAddress(HttpContext context, bool allowForwarded = true)
        {
            if (allowForwarded)
            {
                string header = (context.Request.Headers["CF-Connecting-IP"].FirstOrDefault() ?? context.Request.Headers["X-Forwarded-For"].FirstOrDefault());
                if (IPAddress.TryParse(header, out IPAddress ip))
                {
                    return ip.MapToIPv4().ToString();
                }
            }
            return context.Connection.RemoteIpAddress.MapToIPv4().ToString();
        }
        private async Task<bool> FirstTopUp(string msisdn)
        {
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@msisdn", msisdn);
                var result = await TalkHomeConnection.SqlConnection.ExecuteScalarAsync<DateTime?>("tha_first_topup", parameter, commandType: CommandType.StoredProcedure);

                if (result == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: TopUpController, Method: isFirstTopUp, Parameters=> msisdn:{msisdn}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return false;
            }
        }
        private async Task<string> Get_Sim_ActivationDate(string msisdn)
        {
            
            try
            {

                var parameter = new DynamicParameters();
                parameter.Add("@msisdn", msisdn);
                var result = await TalkHomeConnection.SqlConnection.ExecuteScalarAsync<string>("get_sim_activationdate", parameter, commandType: CommandType.StoredProcedure);
                return result?.ToString() ?? null ;
            }
            catch (Exception e)
            {
                return null;
            }
        }
    }
}