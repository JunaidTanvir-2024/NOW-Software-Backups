using System.Text.Json.Serialization;

using Voucherify.Core.Commons.Converters;
using Voucherify.Core.Services.VoucherifyApi.Definations;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

public class Voucher
{
    [JsonPropertyName("code")]
    public string? Code { get; set; }

    [JsonPropertyName("code_config")]
    public CodeConfig? CodeConfig { get; set; }

    [JsonPropertyName("type")]
    [JsonConverter(typeof(EnumConverter<VoucherifyEnums.VoucherType>))]
    public VoucherifyEnums.VoucherType Type { get; set; }

    [JsonPropertyName("campaign")]
    public string? Campaign { get; set; }

    [JsonPropertyName("campaign_id")]
    public string? CampaignId { get; set; }

    [JsonPropertyName("category")]
    public string? Category { get; set; }

    [JsonPropertyName("discount")]
    public Discount? DiscountInfo { get; set; }

    [JsonPropertyName("loyalty_card")]
    public LoyaltyCard? LoyaltyCard { get; set; }

    [JsonPropertyName("gift")]
    public Gift? Gift { get; set; }

    [JsonPropertyName("start_date")]
    public DateTime? StartDate { get; set; }

    [JsonPropertyName("expiration_date")]
    public DateTime? ExpirationDate { get; set; }

    [JsonPropertyName("active")]
    public bool Active { get; set; }

    [JsonPropertyName("assets")]
    public VoucherAssets? Assets { get; set; }

    [JsonPropertyName("publish")]
    public VoucherPublishList? Publish { get; set; }

    [JsonPropertyName("redemption")]
    public VoucherRedemptionList? Redemption { get; set; }

    [JsonPropertyName("additional_info")]
    public string? AdditionalInfo { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    [JsonPropertyName("applicable_to")]
    public VoucherSubjectList? ApplicableTo { get; set; }

    [JsonPropertyName("is_referral_code")]
    public bool IsReferralCode { get; set; }

    [JsonPropertyName("referrer_id")]
    public string? ReferrerId { get; set; }

    [JsonPropertyName("holder_id")]
    public string? HolderId { get; set; }

    [JsonPropertyName("holder")]
    public VoucherHolder? Holder { get; set; }
}
