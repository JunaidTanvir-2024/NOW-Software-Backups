﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    
    public enum ApiStatusCodes
    {
        MsisdnNotExists = 1,
        CodeException = 2,
        Pay360Error = 3,
        NullContent = 4,
        DataNotAvailable = 5,
        DataNotUpdated = 6,
        UnSuccessful = 7,
        FcmTokenNotFound = 8
    }
}
