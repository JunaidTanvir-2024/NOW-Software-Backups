﻿using SenderService.Core.Features.ProductCode.Request;
using SenderService.Core.Features.ProductCode.Response;

namespace SenderService.Core.Features.ProductCode;
public interface IProductCodeService
{
    Task<long> AddProductCodeAsync(AddProductCodeRequest request);
    Task<ProductCodeResponse> GetProductCodeByIdAsync(GetProductCodeByIdRequest request);
    Task<List<ProductCodeResponse>> GetProductCodesAsync();
}