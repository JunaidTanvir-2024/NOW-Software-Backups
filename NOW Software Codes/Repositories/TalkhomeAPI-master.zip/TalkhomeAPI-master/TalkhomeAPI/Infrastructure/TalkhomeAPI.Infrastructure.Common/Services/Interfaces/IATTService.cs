﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Services.Models.ATTApiContracts;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface IATTService
    {
        Task<GetProductResponse> GetProducts(string fromMsisdn, string toMsisdn, string currencyAccount);
        Task<ExecuteDataResponse> Execute(ExecuteDataRequest request);
    }
}
