namespace Application.Features.Bundle.InternationalBundle;

public sealed class InternationalBundleRequestValidator : AbstractValidator<InternationalBundleRequest>
{
    public InternationalBundleRequestValidator(ICommonService commonService)
    {
        (bool IsAppRequest, DeviceType? deviceType, MediumType? MediumType) = commonService.IsAppRequest();
        //  RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .Must(p => commonService.IsValidMsisdn(p!))
            .When(p => !string.IsNullOrEmpty(p.Msisdn) && IsAppRequest)
            .WithMessage("Invalid Msisdn");
    }
}
