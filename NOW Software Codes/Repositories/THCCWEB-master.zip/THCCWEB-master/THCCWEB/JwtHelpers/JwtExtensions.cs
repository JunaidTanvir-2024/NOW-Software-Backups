﻿using System;
using Microsoft.Extensions.Configuration;
using THCCWEB.Models.ApiContracts.Response;

namespace THCCWEB.JwtHelpers
{
    public static class JwtExtensions
    {   
        public static void GenerateToken(this LoginResponseModel user, IConfiguration configuration)
        {
            try
            {
                var token = new JwtTokenBuilder()
                                .AddSecurityKey(JwtSecurityKey.Create(configuration.GetValue<string>("JwtSecretKey")))
                                .AddIssuer(configuration.GetValue<string>("JwtIssuer"))
                                .AddAudience(configuration.GetValue<string>("JwtAudience"))
                                .AddExpiryInDays(1)
                                .AddClaim("Id", user.Id.ToString())
                                //.AddRole(user.Role.ToString())
                                .Build();

                user.Token = token.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
