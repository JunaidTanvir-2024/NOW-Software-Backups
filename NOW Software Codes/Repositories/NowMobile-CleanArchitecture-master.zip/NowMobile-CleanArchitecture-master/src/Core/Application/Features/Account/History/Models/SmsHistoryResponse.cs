﻿namespace Application.Features.Account.History.Models;
public class SmsHistoryResponse
{
    public IEnumerable<SmsHistoryInfo> History { get; set; } = new List<SmsHistoryInfo>();
    public long TotalCount { get; set; }
    public int RecordsFiltered { get; set; }
    public int PageNo { get; set; }
}
