namespace DC.Core.Features.Notifications.Requests;

public record NewRegisteredMsisdnRequest() : IRequest<IResultWrapper>
{
    public string? To { get; set; }
    public string message { get; set; }
    public string ProductCode { get; set; }
    public string RequestID { get; set; }



}
public class NewRegisteredMsisdnRequestValidator : AbstractValidator<NewRegisteredMsisdnRequest>
{
    public NewRegisteredMsisdnRequestValidator()
    {

    }
}




