﻿using System.ComponentModel.DataAnnotations;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class PinCodeViewModel
    {              

        [Required(ErrorMessage = "Please enter 4-digit pin")]
        [StringLength(4, MinimumLength = 4, ErrorMessage = "Please enter 4-digit pin")]
        public string PinCode { get; set; }
        public string Token { get; set; }                   
    }
}
