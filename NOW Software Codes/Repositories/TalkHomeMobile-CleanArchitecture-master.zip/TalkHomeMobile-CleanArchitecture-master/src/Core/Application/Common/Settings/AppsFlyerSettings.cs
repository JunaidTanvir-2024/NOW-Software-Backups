﻿namespace Application.Common.Settings;

public class AppsFlyerSettings
{
    public const string SectionName = "AppsFlyerSettings";
    public static AppsFlyerSettings Bind = new AppsFlyerSettings();
    public string? ApiEndpoint { get; set; }
    public bool IsActive { get; set; }
}

