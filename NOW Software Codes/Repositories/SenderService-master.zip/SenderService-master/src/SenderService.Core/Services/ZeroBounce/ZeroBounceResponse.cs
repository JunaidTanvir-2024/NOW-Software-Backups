﻿using System.Text.Json.Serialization;

namespace SenderService.Core.Services.ZeroBounce;
public class ZeroBounceResponse
{
    [JsonPropertyName("address")]
    public string? Address { get; set; }

    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("sub_status")]
    public string? SubStatus { get; set; }

    [JsonPropertyName("free_email")]
    public bool FreeEmail { get; set; }

    [JsonPropertyName("did_you_mean")]
    public object? DidYouMean { get; set; }

    [JsonPropertyName("account")]
    public string? Account { get; set; }

    [JsonPropertyName("domain")]
    public string? Domain { get; set; }

    [JsonPropertyName("domain_age_days")]
    public string? DomainAgeDays { get; set; }

    [JsonPropertyName("smtp_provider")]
    public string? SmtpProvider { get; set; }

    [JsonPropertyName("mx_found")]
    public string? MxFound { get; set; }

    [JsonPropertyName("mx_record")]
    public string? MxRecord { get; set; }

    [JsonPropertyName("firstname")]
    public object? Firstname { get; set; }

    [JsonPropertyName("lastname")]
    public object? Lastname { get; set; }

    [JsonPropertyName("gender")]
    public object? Gender { get; set; }

    [JsonPropertyName("country")]
    public object? Country { get; set; }

    [JsonPropertyName("region")]
    public object? Region { get; set; }

    [JsonPropertyName("city")]
    public object? City { get; set; }

    [JsonPropertyName("zipcode")]
    public object? Zipcode { get; set; }

    //[JsonPropertyName("processed_at")]
    //public DateTime? ProcessedAt { get; set; }
}
