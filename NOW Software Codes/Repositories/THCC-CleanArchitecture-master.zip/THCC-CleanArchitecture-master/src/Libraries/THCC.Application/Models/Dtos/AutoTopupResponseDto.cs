﻿namespace THCC.Application.Models.Dtos
{
    public class AutoTopupResponseDto
    {
        public bool Status { get; set; }
        public string? MaskedPan { get; set; }
        public decimal Amount { get; set; }
        public decimal Threshold { get; set; }
    }
}
