﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests
{
    public class GetVoucherifyCustomerLoyaltyCardRequest
    {
        public string SourceId { get; set; }
        public string LoyaltyCampaignId { get; set; }
    }
}
