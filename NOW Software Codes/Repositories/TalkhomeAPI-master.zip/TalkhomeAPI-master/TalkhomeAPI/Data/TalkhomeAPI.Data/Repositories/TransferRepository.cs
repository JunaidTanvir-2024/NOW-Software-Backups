﻿using Dapper;
using Microsoft.Extensions.Options;
using Org.BouncyCastle.Ocsp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.DbConnections;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Repositories
{
    public class TransferRepository : ITransferRepository
    {
        private readonly IDbConnectionSettings _Att_Db;
        private readonly IDbConnectionSettings _Digitalk;
        private readonly IDbConnectionSettings _TalkHomeAppDb;

        public TransferRepository(IOptions<ConnectionString> connectionString)
        {
            _Att_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.ATTDbConnection));
            _Digitalk = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigitalkDbConnection));
            _TalkHomeAppDb = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppDbConnection));
        }

        public async Task<DBProduct> GetProductByNowtelTransactionReference(string guid, string product)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@guid", guid);
            parameters.Add("@product", product);

            return await _Att_Db.SqlConnection.QueryFirstOrDefaultAsync<DBProduct>("at_getAPIAccessGUIDRecord_Trh", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task SaveTransaction(DBTransferTransaction transaction)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@AccountId", transaction.AccountId);
            parameters.Add("@PaymentTypeId", (int)transaction.PaymentTypeId); //web
            parameters.Add("@PaymentRef", transaction.PaymentRef);
            parameters.Add("@StatusId", transaction.StatusId);
            parameters.Add("@NowtelRef", transaction.NowtelRef);
            parameters.Add("@ClientCurrency", transaction.ClientCurrecny);
            parameters.Add("@ReceiverCurrency", transaction.ReceiverCurrecny);
            parameters.Add("@Product", transaction.Product);
            parameters.Add("@ItemPrice", transaction.ItemPrice);
            parameters.Add("@TotalPrice", transaction.TotalPrice);
            parameters.Add("@FromMsisdn", transaction.FromMsisdn);
            parameters.Add("@ToMsisdn", transaction.ToMsisdn);
            parameters.Add("@OperatorCountryName", transaction.OperatorCountryName);
            parameters.Add("@CountryCode", transaction.CountryCode);
            parameters.Add("@OperatorName", transaction.OperatorName);
            parameters.Add("@OperatorLogoUrl", transaction.OperatorLogoUrl);
            parameters.Add("@TransferRef", transaction.TransferRef);

            await _TalkHomeAppDb.SqlConnection.ExecuteAsync("tha_web_save_itopup_transactions",
                parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> IsFirstInternationTopup(string account)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@AccountId", account);
            parameters.Add("@IsFirstTopup", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await _TalkHomeAppDb.SqlConnection.ExecuteAsync("tha_web_isfirstitopup", parameters, commandType: CommandType.StoredProcedure);

            return parameters.Get<int>("@IsFirstTopup");
        }

        public async Task<DBAccountBalance> UpdateAccountBalance(decimal amount, string accountID, string reference)
        {
            amount = Math.Round(100 * amount, 0);

            var parameters = new DynamicParameters();

            parameters.Add("@account", accountID);
            parameters.Add("@channel", 2); //web
            parameters.Add("@amount", amount);
            parameters.Add("@bonus", 0);
            parameters.Add("@creditReason", "AirTime Transfer Debit Web");
            parameters.Add("@paymentMethod", "AccountBalance");
            parameters.Add("@rechargeType", 0);
            parameters.Add("@reference", reference);
            parameters.Add("@ccsTransId", 0);
            parameters.Add("@ccAuthCode", "THATRWeb");

            return await _Digitalk.SqlConnection.QueryFirstOrDefaultAsync<DBAccountBalance>("tha_web_AccountUpdateBalance", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<PromotionBalanceDedutionDetails> InsertSpecialPromotionLogs(decimal amount, string accountID, string reference,string paymentMethod)
        {
            amount = Math.Round(100 * amount, 0);

            var parameters = new DynamicParameters();

            parameters.Add("@account", accountID);
            parameters.Add("@channel", 2); //web
            parameters.Add("@amount", amount);
            parameters.Add("@bonus", 0);
            parameters.Add("@creditReason", "AirTime Transfer Debit Web");
            parameters.Add("@paymentMethod", paymentMethod);
            parameters.Add("@rechargeType", 0);
            parameters.Add("@reference", reference);
            parameters.Add("@ccsTransId", 0);
            parameters.Add("@ccAuthCode", "THATRWeb");
            parameters.Add("@ccExpdate", null);
            parameters.Add("@ccIssue", null);
            parameters.Add("@ccName", null);
            parameters.Add("@ccNum", null);
            parameters.Add("@ccType", null);
            parameters.Add("@ccValid", null);
            parameters.Add("@paymentBillId", null);
            parameters.Add("@settleBillId", null);
            parameters.Add("@userName", null);
            parameters.Add("@refundedAuditId", null);
            parameters.Add("@suppressBillPaymentAlways", false);
            parameters.Add("@suppressNotify", false);
            parameters.Add("@checkCreditLimits", true);
            parameters.Add("@auditId", null);
            parameters.Add("@show_output", true);

            parameters.Add("@retAmount", dbType: DbType.Decimal, direction: ParameterDirection.Output);
            parameters.Add("@retcreditReason", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

             await _Digitalk.SqlConnection.ExecuteAsync("tha_special_promotions_insert_v3", parameters, commandType: CommandType.StoredProcedure);
            
            return new PromotionBalanceDedutionDetails()
            {
                retAmount = parameters.Get<decimal>("retAmount") / 100,
                retcreditReason = parameters.Get<string>("retcreditReason")
            };


        }



        public async Task<PromotionBalanceDedutionDetails> GetSpecialPromotionBalanceToDeduct(decimal amount, string accountID)
        {
            amount = Math.Round(100 * amount, 0);

            var parameters = new DynamicParameters();

            parameters.Add("@account", accountID);
            parameters.Add("@amount", amount);
            parameters.Add("@creditReason", "AirTime Transfer Debit Web");
            parameters.Add("@retAmount", dbType: DbType.Decimal, direction: ParameterDirection.Output);
            parameters.Add("@retcreditReason", dbType: DbType.String, direction: ParameterDirection.Output,size:100);

             await _Digitalk.SqlConnection.ExecuteAsync("tha_special_promotions_balance_to_Deduct", parameters, commandType: CommandType.StoredProcedure);

            return new PromotionBalanceDedutionDetails() { 
            retAmount= parameters.Get<decimal>("retAmount")/100,
            retcreditReason= parameters.Get<string>("retcreditReason")
            };

        }

        public async Task<TransferValidationResponse> ValidateTransferRequest(DBValidateTransferRequest request)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@FromCountryCode", request.FromCountryCode);
            parameters.Add("@ToCountryCode", request.ToCountryCode);
            parameters.Add("@AccountId", request.AccountId);
            parameters.Add("@TotalAmount", request.TotalAmount);
            parameters.Add("@UserCurrency", request.UserCurrency);
            parameters.Add("@FromMsisdn", request.FromMsisdn);

            parameters.Add("@Response", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await _TalkHomeAppDb.SqlConnection.ExecuteAsync("tha_web_validate_transfer_request", parameters, commandType: CommandType.StoredProcedure);

            return parameters.Get<TransferValidationResponse>("@Response");
        }
    }
}
