using Application.Features.Account.History.Models;

namespace Application.Features.Account.History.Call;
public sealed class CallUsageHistoryRequestHandler : IRequestHandler<CallUsageHistoryRequest, Result<CallHistoryResponse>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<CallUsageHistoryRequestHandler> _localizer;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;

    public CallUsageHistoryRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<CallUsageHistoryRequestHandler> localizer,
        ICommonService commonService,
        IUserService userService)
    {
        _uow = uow;
        _localizer = localizer;
        _commonService = commonService;
        _userService = userService;
    }

    public async Task<Result<CallHistoryResponse>> Handle(CallUsageHistoryRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();
        if (IsAppRequest)
        {
            request.StartDate = DateTime.UtcNow.Date;
            request.EndDate = DateTime.UtcNow.Date.AddDays(7);
            request.PageNo = 1;
            request.PageSize = 20;
        }
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<CallHistoryResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var callHistory = await _uow.UserRepo.CallHistory(request.Msisdn, request.StartDate, request.EndDate, request.PageNo, request.PageSize);
        var callHistoryResponse = new CallHistoryResponse()
        {
            History = callHistory,
            TotalCount = callHistory.Select(x => x.TotalCount).FirstOrDefault(),
            PageNo = request.PageNo,
            RecordsFiltered = callHistory.Count()
        };
        return Result<CallHistoryResponse>.Success(callHistoryResponse, _localizer[CustomStatusKey.Success]);
    }
}