using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class AppLog : IBaseEntity<long>
{
	public long Id { get; set; }
	public string RequestReference { get; set; } = null!;
	public string RequestPath { get; set; } = null!;
	public string RequestMethod { get; set; } = null!;
	public string RequestBody { get; set; } = null!;
	public string ResponseBody { get; set; } = null!;
	public int StatusCode { get; set; }
	public long ProcessDuration { get; set; }
	public string ClientIp { get; set; } = null!;
	public string UserAgent { get; set; } = null!;
	public string? ErrorReason { get; set; }
	public string RequestHeaders { get; set; } = null!;
	public required string ProductReference { get; set; }
	public DateTime RequestTimestamp { get; set; } = DateTime.UtcNow;
}
