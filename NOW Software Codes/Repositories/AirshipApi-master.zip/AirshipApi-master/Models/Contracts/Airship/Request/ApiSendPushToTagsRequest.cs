﻿using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Airship.Request
{
    public class ApiSendPushToTagsRequest
    {
        [JsonProperty("device_types")]       
        [EnumDataType(typeof(DeviceType))]
        public List<DeviceType> DeviceTypes { get; set; }

        [JsonProperty("audience")]
        public ApiTagAudience TagAudience { get; set; }

        [JsonProperty("notification")]        
        public ApiNotification Notification { get; set; }        

    }
    public class ApiNotification
    {
        [JsonProperty("alert")]
        [Required]
        public string Alert { get; set; }

        [JsonProperty("actions")]
        public ApiAction Actions { get; set; }

        public bool ShouldSerializeActions()
        {
            // don't serialize the TagGroup property if it is NULL or Empty
            if (RequestActions == null)
            {
                return false;
            }
            else
            {
                Actions = new ApiAction() { Open = new ApiOpen() { Type = RequestActions.Open.Type.ToString(), Content = RequestActions.Open.Content, FallbackUrl = RequestActions.Open.FallbackUrl, LandingPageContent = new LandingPageContent() { Body = RequestActions.Open.Content, ContentType = "text/html" } } };
                return true;
            }
        }


        [JsonIgnore]
        public Contracts.Request.Action RequestActions { get; set; }
    }

    public class ApiTagAudience
    {
        [JsonProperty("group")]
        public string TagGroup { get; set; }

        [JsonProperty("tag")]
        public List<string> Tags { get; set; }

        public bool ShouldSerializeTagGroup()
        {
            // don't serialize the TagGroup property if it is NULL or Empty
            if (string.IsNullOrWhiteSpace(TagGroup))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

    public class ApiAction
    {
        [JsonProperty("open")]        
        public ApiOpen Open { get; set; }
    }

    public class ApiOpen
    {
        [JsonProperty("type")]        
        public string Type { get; set; }

        [JsonProperty("content")]        
        public string Content { get; set; }

        public bool ShouldSerializeContent()
        {

            if (Type == "deep_link" || Type == "url")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonProperty("LandingPageContent")]
        public LandingPageContent LandingPageContent { get; set; }

        public bool ShouldSerializeLandingPageContent()
        {

            if (Type == "landing_page")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonProperty("fallback_url")]
        public string FallbackUrl { get; set; }

        public bool ShouldSerializeFallbackUrl()
        {
            
            if (!string.IsNullOrWhiteSpace(FallbackUrl) && (Type == "deep_link" || Type == "landing_page"))
            {
                return true;
            }
            else
            {                
                return false;
            }
        }
    }

    public class LandingPageContent
    {
        [JsonProperty("body")]
        public string Body { get; set; }

        [JsonProperty("content_type")]
        public string ContentType { get; set; }
    }

}
