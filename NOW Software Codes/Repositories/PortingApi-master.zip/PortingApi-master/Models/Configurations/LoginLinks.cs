﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class LoginLinks
    {
        public string NowPayGLink { get; set; }
        public string TalkhomeLink { get; set; }
    }
}
