﻿namespace Application.Features.Payment.Models;

public class PaymentCreditSimInfo
{
    public long OrderId { get; set; }
    public string? Alias { get; set; }
}
