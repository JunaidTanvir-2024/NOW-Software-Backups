﻿namespace Application.Features.Payment.Card.Models;
public class CardResponse
{
    public int OrderId { get; set; }
    public ThreeDSecureData? ThreeDSecureData { get; set; }
    public string? PaymentHtmlData { get; set; }
}