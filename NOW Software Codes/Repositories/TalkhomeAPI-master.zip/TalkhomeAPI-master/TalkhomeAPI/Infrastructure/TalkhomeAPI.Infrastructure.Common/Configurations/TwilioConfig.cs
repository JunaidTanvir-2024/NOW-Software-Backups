﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class TwilioConfig
    {
        public string Sid { get; set; }
        public string AuthToken { get; set; }
        public string[] TwilioFromNumberCountries { get; set; }
        public string TwilioNumber { get; set; }
        public string TwilioFromNotRestricted { get; set; }
    }
}
