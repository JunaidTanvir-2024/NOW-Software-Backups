﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class CardViewModel
    {
        [Required(ErrorMessage = "Enter Card Name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression("^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid Name")]
        public string NameOnCard { get; set; }

        [Required(ErrorMessage = "Enter Card Number")]
        [StringLength(maximumLength: 19, ErrorMessage = "Length must be between (14-19)", MinimumLength = 14)]
        public string CardNumber { get; set; }

        [Required(ErrorMessage = "Select Expiry Month")]
        public string ExpiryMonth { get; set; }

        [Required(ErrorMessage = "Select Expiry Year")]
        public string ExpiryYear { get; set; }

        [Required(ErrorMessage = "Enter Security Code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [Range(0, int.MaxValue, ErrorMessage = "Only numbers allowed.")]
        public string SecurityCode { get; set; }

        [Required(ErrorMessage = "Select Card")]
        public string Token { get; set; }

        [Required(ErrorMessage = "Select Country")]
        public string CoutryCode { get; set; }
    }
}
