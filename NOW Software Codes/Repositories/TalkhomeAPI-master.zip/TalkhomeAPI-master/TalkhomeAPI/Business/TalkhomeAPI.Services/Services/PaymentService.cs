﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Models.Pay360ApiContracts;
using TalkhomeAPI.Models.PaypalApiContracts;
using TalkhomeAPI.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Models.Configurations;
using Microsoft.Extensions.Options;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using Serilog;
using System.Linq;
using TalkhomeAPI.Infrastructure.Common.Services.Implementations;
using PhoneNumbers;
using TalkhomeAPI.Infrastructure.Common.Models;
using Microsoft.AspNetCore.Hosting;
using System.Reflection;
using System.IO;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Airship;
using TalkhomeAPI.Infrastructure.Common.ExtensionMethods;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using System.Net.Mail;
using System.Net;

namespace TalkhomeAPI.Services.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly IPay360Service _pay360Service;
        private readonly IPayPalService _payPalService;
        private readonly IAccountRepository _accountRepository;
        private readonly ILogger _logger;
        private readonly IBundleRepository _bundleRepository;
        private readonly IAppsFlyerService _appsFlyerService;
        private readonly IAirShipService _airShipService;
        private readonly IPaymentFullfillmentRepository _PaymentFullfillment;
        private readonly IPromotionService _promotionService;

        private readonly PayPalConfig _payPalConfig;
        private readonly Pay360Config _pay360Config;
        private readonly SmtpConfig _SmtpConfig;

        public PaymentService(
            IPay360Service pay360Service,
            IPayPalService payPalService,
            IAccountRepository accountRepository,
            ILogger logger,
            IBundleRepository bundleRepository,
            IAppsFlyerService appsFlyerService,
            IAirShipService airShipService,
            IPaymentFullfillmentRepository IPaymentFullfillment,
            IPromotionService promotionService,
            IOptions<PayPalConfig> paypalConfig,
            IOptions<Pay360Config> pay360Config,
            IOptions<SmtpConfig> SmtpConfig
            )
        {
            _pay360Service = pay360Service;
            _payPalService = payPalService;
            _payPalConfig = paypalConfig.Value;
            _pay360Config = pay360Config.Value;
            _accountRepository = accountRepository;
            _logger = logger;
            _bundleRepository = bundleRepository;
            _appsFlyerService = appsFlyerService;
            _airShipService = airShipService;
            _PaymentFullfillment = IPaymentFullfillment;
            _promotionService = promotionService;
            _SmtpConfig = SmtpConfig.Value;
        }

        public async Task<GenericApiResponse<VoucherRechargeResponseModel>> VoucherRecharge(VoucherRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<VoucherRechargeResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;

            var result = await _accountRepository.VoucherRecharge(model.Pin, account);

            if (result == null)
                return GenericApiResponse<VoucherRechargeResponseModel>.Failure("Something went wrong on server", ApiStatusCodes.InternalServerError);

            if (result.error_code == 0)
            {

                #region Events
                try
                {
                    if (_airShipService.IsActive || _appsFlyerService.IsActive)
                    {
                        var isFirstTopup = await _accountRepository.IsFirstTopUp(msisdn);
                        var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());

                        var PhoneUtil = PhoneNumberUtil.GetInstance();
                        PhoneNumber Number = PhoneUtil.Parse(msisdn.StartsWith("+") ? msisdn : "+" + msisdn, "");
                        var CountryCode = PhoneUtil.GetRegionCodeForNumber(Number);

                        var topupAmount = result.card_credit / 100;

#pragma warning disable CS4014
                        #region AppsFlyer
                        if (_appsFlyerService.IsActive)
                        {
                            if (isFirstTopup)
                            {
                                _appsFlyerService.CreateEvent(msisdn, "user_first_topup", model.IpAddress);
                            }

                            _appsFlyerService.CreateEvent(msisdn, "user_last_topup", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "success_topup", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "voucher_buy", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "any_topup", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "topup_" + Convert.ToInt32(topupAmount) + "", model.IpAddress, result.voucher_currency, (decimal)topupAmount, new
                            {
                                origination = CountryCode.ToLower(),
                                amount = topupAmount
                            });
                        }

                        #endregion

                        #region Airship
                        FireAirShipTopupEvents(msisdn, topupAmount.ToString(), result.voucher_id.ToString(), result.voucher_currency, isFirstTopup, PaymentType.Voucher, CountryCode, customerResoonse.Balance);
                        #endregion
#pragma warning restore CS4014
                    }

                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: PaymentService, Method: VoucherRecharge-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }
                #endregion

                return GenericApiResponse<VoucherRechargeResponseModel>.Success(new VoucherRechargeResponseModel()
                {
                    card_credit = result.card_credit > 0 ? result.card_credit / 100 : result.card_credit,
                    voucher_currency = result.voucher_currency,
                    voucher_id = result.voucher_id
                }, "voucher added successfully");
            }
            else
            {
                return GenericApiResponse<VoucherRechargeResponseModel>.Failure(
                                                result.error_msg, ApiStatusCodes.VoucherRechargeFailed);
            }
        }
        public async Task<GenericApiResponse<Pay360CardsResponse>> Pay360GetCards(string msisdn)
        {
            var response = await _pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
            {
                customerUniqueRef = msisdn,
                productCode = ProductCode.THA.ToString()
            });

            if (response != null)
            {
                if (response.errorCode > 0)
                {
                    if (response.errorCode == (int)Pay360StatusCodes.CustomerNotExist) //Customer not Exist
                    {
                        return GenericApiResponse<Pay360CardsResponse>.Failure(
                                            "Customer Not Found", ApiStatusCodes.CustomerNotExist);
                    }
                }
                else
                {
                    if (response.payload != null)
                    {
                        return response;
                    }
                }
            }

            return GenericApiResponse<Pay360CardsResponse>.Failure(
                                  "Something went wrong on server", ApiStatusCodes.InternalServerError);
        }
        public async Task<GenericApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(string msisdn)
        {
            var response = await _pay360Service.GetAutoTopUp(new Pay360GetAutoTopUpRequest()
            {
                Email = "dummy@gmail.com",
                Msisdn = msisdn,
                ProductCode = ProductCode.THA.ToString()
            });

            if (response == null)
                return GenericApiResponse<Pay360GetAutoTopUpResponse>.Failure(
                            "Somehting went wrong on server", ApiStatusCodes.InternalServerError);

            return response;
        }
        public async Task<GenericApiResponse<bool>> SetAutoTopUp(SetAutoTopUpRequestModel model, string msisdn, string currency)
        {

            var response = await _pay360Service.SetAutoTopUp(new Pay360SetAutoTopUpRequest()
            {
                isAutoTopup = model.isActive,
                thresholdBalanceAmount = model.thresholdBalanceAmount,
                topupAmount = model.amount,
                productCode = ProductCode.THA.ToString(),
                productItemCode = ProductItemCode.THAATW.ToString(),
                productRef = msisdn,
                topupCurrency = currency,
                Email = "dummy@gmail.com"
            });

            if (response == null)
            {
                return GenericApiResponse<bool>.Failure(
                                "Somehting went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (response.errorCode == 0)
            {

                #region Airship
                try
                {
                    if (_airShipService.IsActive)
                    {
#pragma warning disable CS4014
                        //events
                        var customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = msisdn,
                            CustomEventName = model.isActive ? "auto_topup_enabled" : "auto_topup_disabled"
                        };

                        _airShipService.AddCustomEvent(customEventsRequest);

                        //tags
                        _airShipService.AddNamedUserTags(new NamedUserTagsRequest()
                        {
                            NamedUser = msisdn,
                            ProductCode = "THA",
                            TagGroup = _airShipService.CustomerTagGroupName,
                            Tags = new List<string>() { model.isActive ? "auto_topup_enabled" : "auto_topup_disabled" }
                        });
#pragma warning restore CS4014
                    }
                }
                catch
                {

                }
                #endregion


                return GenericApiResponse<bool>.Success(true, "Auto Top-Up settings saved successfully");
            }
            else
            {
                return GenericApiResponse<bool>.Failure(
                            "Somehting went wrong on server", ApiStatusCodes.InternalServerError);
            }
        }
        public async Task<GenericApiResponse<bool>> SetCustomerDefaultCard(SetCustomerDefaultCardRequestModel model, string msisdn)
        {
            var customerResponse = await _pay360Service.GetCustomer(new Pay360CustomerRequestModel()
            {
                customerUniqueRef = msisdn,
                productCode = ProductCode.THA.ToString()
            });

            if (customerResponse == null)
            {
                return GenericApiResponse<bool>.Failure(
                            "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (customerResponse.errorCode > 0)
            {
                _logger.Error($"Class: PaymentService, Method: SetCustomerDefaultCard - customerResponse, " +
                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                     $"Response => Model : {JsonConvert.SerializeObject(customerResponse)}");

                if (customerResponse.errorCode == (int)Pay360StatusCodes.CustomerNotExist)
                {
                    return GenericApiResponse<bool>.Failure("Customer does not exist", ApiStatusCodes.CustomerNotExist);
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            var cardResponse = await _pay360Service.SetCustomerDefaultCard(new SetCustomerDefaultCardRequest()
            {
                cardToken = model.CardToken,
                defaultCardCV2 = model.CardCV2,
                pay360CustomerID = customerResponse.payload.pay360CustId
            });

            if (cardResponse == null)
            {
                return GenericApiResponse<bool>.Failure(
                                    "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (cardResponse.errorCode > 0)
            {
                _logger.Error($"Class: PaymentService, Method: SetCustomerDefaultCard - cardResponse, " +
                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                     $"Response => Model : {JsonConvert.SerializeObject(cardResponse)}");

                if (customerResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<bool>.Failure(customerResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            return GenericApiResponse<bool>.Success(true, "success");

        }
        public async Task<GenericApiResponse<bool>> RemoveCard(RemoveCardRequestModel model, string msisdn)
        {
            var customerResponse = await _pay360Service.GetCustomer(new Pay360CustomerRequestModel()
            {
                customerUniqueRef = msisdn,
                productCode = ProductCode.THA.ToString()
            });

            if (customerResponse == null)
            {
                return GenericApiResponse<bool>.Failure(
                            "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (customerResponse.errorCode > 0)
            {
                _logger.Error($"Class: PaymentService, Method: RemoveCard - customerResponse, " +
                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                     $"Response => Model : {JsonConvert.SerializeObject(customerResponse)}");

                if (customerResponse.errorCode == (int)Pay360StatusCodes.CustomerNotExist)
                {
                    return GenericApiResponse<bool>.Failure("Customer does not exist", ApiStatusCodes.CustomerNotExist);
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            var cardResponse = await _pay360Service.RemoveCard(new RemoveCardRequest()
            {
                cardToken = model.CardToken,
                pay360CustomerID = customerResponse.payload.pay360CustId
            });

            if (cardResponse == null)
            {
                return GenericApiResponse<bool>.Failure(
                                    "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (cardResponse.errorCode > 0)
            {
                _logger.Error($"Class: PaymentService, Method: RemoveCard - cardResponse, " +
                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                     $"Response => Model : {JsonConvert.SerializeObject(cardResponse)}");

                if (customerResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<bool>.Failure(customerResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            return GenericApiResponse<bool>.Success(true, "success");
        }
        public async Task<GenericApiResponse<Pay360CustomerModel>> GetCustomer(Pay360CustomerRequestModel model)
        {
            var response = await _pay360Service.GetCustomer(model);
            if (response != null)
            {
                if (response.errorCode > 0)
                {
                    return GenericApiResponse<Pay360CustomerModel>.Failure(
                                "Error Occured while Get Customer", ApiStatusCodes.TransactionUnSuccessful);
                }
                else
                {
                    if (response.payload != null)
                    {
                        return response;
                    }
                }
            }
            return response;
        }
        public async Task<GenericApiResponse<BundlePurchaseViaABResponseModel>> BundlePurchaseViaAccountBalance(
                                                    BundlePurchaseViaABRequestModel model, string accountId, string msisdn, string currency)
        {
            //Check Bundle Limit
            var bundlesResponse = await _accountRepository.GetBundlesHistory(accountId);
            if (bundlesResponse.Count() >= 10)
            {
                return GenericApiResponse<BundlePurchaseViaABResponseModel>.Failure("Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
            }

            //Get Bundle Info
            var bundleInfo = await _bundleRepository.GetBundleById(model.BundleId);

            if (bundleInfo == null)
            {
                return GenericApiResponse<BundlePurchaseViaABResponseModel>.Failure("Invalid Bundle", ApiStatusCodes.InvalidBundle);
            }

            //Check Balance
            var accountInfo = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);

            if (accountInfo.Balance < (bundleInfo.TotalCostPence / 100))
            {
                return GenericApiResponse<BundlePurchaseViaABResponseModel>.Failure("Insufficient Balance", ApiStatusCodes.InsufficientBalance);
            }

            //Purchase Bundle
            var response = await _bundleRepository.BundlePurchaseViaAccountBalance(accountId, model.BundleId);
            if (response > 0)
            {
                _logger.Error($"Class: PaymentService, Method: BundlePurchaseViaAccountBalance" +
                                $"AccountId => {accountId }" +
                                $"BundleId =>  {model.BundleId }" +
                                $"ErrorCode => {response}");

                if (response == 1111 || response == 300)
                {
                    return GenericApiResponse<BundlePurchaseViaABResponseModel>.Failure("Bundle limit is exceeded", ApiStatusCodes.BundleLimitExceeded);
                }

                return GenericApiResponse<BundlePurchaseViaABResponseModel>.Failure("Unable to purchase bundle", ApiStatusCodes.BundlePurchasedFailed);
            }

            #region Events
            try
            {
                if (_appsFlyerService.IsActive || _airShipService.IsActive)
                {

                    var bundleAmount = (bundleInfo.TotalCostPence / 100);
                    var IsBundleExists = await _accountRepository.IsBundleExists(msisdn);
                    var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());

#pragma warning disable CS4014
                    #region AppsFlyer
                    if (_appsFlyerService.IsActive)
                    {
                        _appsFlyerService.CreateEvent(msisdn, "success_bundle", model.IpAddress);

                        _appsFlyerService.CreateEvent(msisdn, "last_bun", model.IpAddress);

                        _appsFlyerService.CreateEvent(msisdn, "purchased_payg_bun", model.IpAddress);

                        _appsFlyerService.CreateEvent(msisdn, "any_bundle", model.IpAddress, currency, (decimal)bundleAmount, new
                        {
                            amount = (decimal)bundleAmount,
                            origination = model.FromBundleISO2,
                            destination = model.ToBundleISO2
                        });

                        _appsFlyerService.CreateEvent(msisdn, "" + GetCountryNameByCountryCode(model.ToBundleISO2) + "_bun", model.IpAddress, eventValue: new
                        {
                            origination = model.FromBundleISO2
                        });

                        if (IsBundleExists == 0)
                        {
                            _appsFlyerService.CreateEvent(msisdn, "first_bun", model.IpAddress);
                        }
                    }
                    #endregion

                    #region Airship
                    await FireAirShipBundlePurchaseEvents(
                        msisdn, bundleAmount.ToString(), "", currency, PaymentType.AccountBalance, bundleInfo.BrandedName,
                        model.FromBundleISO2, model.ToBundleISO2, customerResoonse.Balance, IsBundleExists == 0 ? true : false);
                    #endregion

#pragma warning restore CS4014


                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentService, Method: BundlePurchaseViaAccountBalance-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            #endregion

            //Need to send email

            return GenericApiResponse<BundlePurchaseViaABResponseModel>.Success(new BundlePurchaseViaABResponseModel()
            {
                bundlePurchaseInfo = new BundlePurchaseInfo()
                {
                    TransactionId = Guid.NewGuid().ToString(),
                    BundleAmount = (bundleInfo.TotalCostPence / 100).ToString(),
                    BundleName = bundleInfo.BrandedName,
                    Currency = accountInfo.Currency,
                    Msisdn = msisdn
                }
            }, "Bundle purchased successfully");
        }
        public async Task<GenericApiResponse<NewCustomerPaymentResponseModel>> NewCustomerPayment(NewCustomerPaymentRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;

            if (!string.IsNullOrEmpty(model.EmailAddress))
                model.EmailAddress = model.EmailAddress.Trim();

            //Get User registration Date
            float ChargeAmount;
            string BundleName = "";

            if (model.CheckoutType == CheckOutTypes.Bundle)
            {

                //Check Bundle Limit
                var bundlesResponse = await _accountRepository.GetBundlesHistory(account);
                if (bundlesResponse.Count() >= 10)
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure("Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
                }

                //Get Bundle details
                var bundleResponse = await _bundleRepository.GetBundleById(model.BundleId);
                if (bundleResponse == null)
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure("Invalid Bundle", ApiStatusCodes.InvalidBundle);
                }

                BundleName = bundleResponse.BrandedName;
                ChargeAmount = bundleResponse.TotalCostPence / 100;
            }

            else
            {
                ChargeAmount = model.TopUpAmount;
            }

            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };

            if (model.CheckoutType == CheckOutTypes.TopUp)
            {
                promResponse = await _promotionService.CheckAnyActivePromotions(
                   ChargeAmount,
                   msisdn,
                   PaymentMethodTypes.Card,
                     new PromotionDependentTypes[] { PromotionDependentTypes.Topup, PromotionDependentTypes.AutoTopup },
                   model.IsAutoTopUp
                   );
            }

            var paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                PromotionsDetails = promResponse,
                CustomerMsisdn = msisdn,
                Amount = ChargeAmount,
                CheckoutPaymentType = model.CheckoutType,
                BundleId = model.BundleId,
                IpAddress = model.ipAddress,
                CustomerEmail = model.EmailAddress,
                Currency = currency,
                Pay360PaymentType = Pay360PaymentType.New,
                CustomerAddressData = new AddressData()
                {
                    AddressL1 = model.billingAddressData.AddressL1,
                    AddressL2 = model.billingAddressData.AddressL2,
                    AddressL3 = model.billingAddressData.AddressL3,
                    AddressL4 = model.billingAddressData.AddressL4,
                    PostCode = model.billingAddressData.PostCode,
                    City = model.billingAddressData.City,
                    Region = model.billingAddressData.Region,
                    CountryCode = model.billingAddressData.CountryCode
                },
                CustomerCardData = new CardData()
                {
                    CardNumber = model.cardData.CardNumber,
                    NameOnCard = model.cardData.NameOnCard,
                    SecurityCode = model.cardData.SecurityCode,
                    ExpiryMonth = model.cardData.ExpiryMonth,
                    ExpiryYear = model.cardData.ExpiryYear
                },
                ShouldSaveCard = model.cardData.ShouldSaveCard,
                accountNumber = account,
                CustomerUniqueRef = model.CustomerUniqueRef
            });


            var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.New);

            if (paymentResponse == null)
            {
                return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(null, "Payment service not responding",
                                                                                                ApiStatusCodes.PaymentServiceError);
            }

            paymentrequest.Pay360PaymentRequestNew.basket.First().amount = (float)promResponse.FullfilmentAmount;

            if (paymentResponse.errorCode == 0)
            {
                await _PaymentFullfillment.InsertTransactionPayment(
                        paymentrequest.Pay360PaymentRequestNew.basket,
                        paymentrequest.Pay360PaymentRequestNew.transactionCurrency,
                        paymentrequest.Pay360PaymentRequestNew.customerEmail,
                        paymentrequest.Pay360PaymentRequestNew.productCode,
                        paymentResponse.payload.transactionId,
                        paymentrequest.Pay360PaymentRequestNew.customerMsisdn,
                        Fullfillmenttype.Pay360,
                        0);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: PaymentService, Method: NewCustomerPayment - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(null,
                                "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(null,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(null,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            if (paymentResponse.payload.outcome.reasonCode == "U100") //3d Secure Scenario
            {
                //Send Response
                return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(
                                                new NewCustomerPaymentResponseModel()
                                                {
                                                    threeDSecureData = new ThreeDSecureData()
                                                    {
                                                        pareq = paymentResponse.payload.clientRedirect.pareq,
                                                        redirectUrl = paymentResponse.payload.clientRedirect.url,
                                                        transactionId = paymentResponse.payload.transactionId,
                                                        returnUrl = _pay360Config.TopUpSettings.ReturnUrl +
                                                        "type=" + (int)model.CheckoutType +
                                                        "&customerEmail=" + model.EmailAddress +
                                                        "&customerMsisdn=" + msisdn +
                                                        "&currency=" + currency +
                                                        "&bundleId=" + model.BundleId +
                                                        "&FromBundleISO2=" + model.FromBundleISO2 +
                                                        "&ToBundleISO2=" + model.ToBundleISO2 +
                                                        "&IsAutoTopUp=" + model.IsAutoTopUp
                                                    }
                                                }, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

            }
            else if (paymentResponse.payload.outcome.reasonCode == "S100")
            {
                //Full filment
                if (_pay360Config.IsDirectFullfilment == false)
                {
                    try
                    {
                        await Pay360CardPaymentFullfillment(paymentResponse, paymentrequest.Pay360PaymentRequestNew.customerMsisdn, paymentrequest.Pay360PaymentRequestNew.customerEmail);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(
                                $"Class: Paymentservices, " +
                                $"Method: NewCustomerPayment - PaymentFullfillment, " +
                                $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                                $"ErrorMessage: {ex.Message}");
                    }
                }

                //Set auto topup
                if (model.IsAutoTopUp && model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await SetAutoTopUp(msisdn, currency);
                }

                //Events
                try
                {
                    if (_airShipService.IsActive || _appsFlyerService.IsActive)
                    {
                        bool isFirstTopup = false;
                        int IsBundleExists = 1;

                        if (model.CheckoutType == CheckOutTypes.TopUp)
                            isFirstTopup = await _accountRepository.IsFirstTopUp(msisdn);

                        if (model.CheckoutType == CheckOutTypes.Bundle)
                            IsBundleExists = await _accountRepository.IsBundleExists(msisdn);

                        var PhoneUtil = PhoneNumberUtil.GetInstance();
                        PhoneNumber Number = PhoneUtil.Parse(msisdn.StartsWith("+") ? msisdn : "+" + msisdn, "");
                        var CountryCode = PhoneUtil.GetRegionCodeForNumber(Number);

                        var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);
                        var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());

#pragma warning disable CS4014

                        #region AppsFlyer
                        if (_appsFlyerService.IsActive)
                        {
                            if (model.CheckoutType == CheckOutTypes.Bundle)
                            {
                                _appsFlyerService.CreateEvent(msisdn, "success_bundle", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "cc_buy", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "last_bun", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "purchased_payg_bun", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "any_bundle", model.ipAddress, currency, transactionAmount, new
                                {
                                    amount = transactionAmount,
                                    origination = model.FromBundleISO2,
                                    destination = model.ToBundleISO2
                                });

                                _appsFlyerService.CreateEvent(msisdn, "" + GetCountryNameByCountryCode(model.ToBundleISO2) + "_bun", model.ipAddress, eventValue: new
                                {
                                    origination = model.FromBundleISO2
                                });

                                if (IsBundleExists == 0)
                                {
                                    _appsFlyerService.CreateEvent(msisdn, "first_bun", model.ipAddress);
                                }
                            }
                            else
                            {
                                if (isFirstTopup)
                                {
                                    _appsFlyerService.CreateEvent(msisdn, "user_first_topup", model.ipAddress);
                                }

                                _appsFlyerService.CreateEvent(msisdn, "user_last_topup", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "success_topup", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "any_topup", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "cc_buy", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "topup_" + Convert.ToInt32(transactionAmount) + "", model.ipAddress, currency, transactionAmount, new
                                {
                                    origination = CountryCode.ToLower(),
                                    amount = transactionAmount
                                });
                            }
                        }
                        #endregion

                        #region Airship
                        if (model.CheckoutType == CheckOutTypes.TopUp)
                            FireAirShipTopupEvents(msisdn, paymentResponse.payload.transactionAmount, paymentResponse.payload.transactionId, currency, isFirstTopup, PaymentType.Card, CountryCode, customerResoonse.Balance);

                        if (model.CheckoutType == CheckOutTypes.Bundle)
                            FireAirShipBundlePurchaseEvents(msisdn, paymentResponse.payload.transactionAmount, paymentResponse.payload.transactionId, currency, PaymentType.Card, BundleName, model.FromBundleISO2, model.ToBundleISO2, customerResoonse.Balance, IsBundleExists == 0);
                        #endregion

#pragma warning restore CS4014
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: PaymentService, Method: NewCustomerPayment-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }

                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Success(new NewCustomerPaymentResponseModel()
                    {
                        bundlePurchaseInfo = new BundlePurchaseInfo()
                        {
                            TransactionId = paymentResponse.payload.transactionId,
                            BundleAmount = paymentResponse.payload.transactionAmount,
                            BundleName = BundleName,
                            Msisdn = msisdn,
                            Currency = currency
                        }
                    }, "Bundle purchased successfully");
                }
                else
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Success(new NewCustomerPaymentResponseModel()
                    {
                        topupInfo = new TopupInfo()
                        {
                            TopupAmount = paymentResponse.payload.transactionAmount,
                            Msisdn = msisdn,
                            TransactionId = paymentResponse.payload.transactionId,
                            Currency = currency
                        }
                    }, "Top-Up Successfull");
                }
            }

            return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(null,
                                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
        }
        public async Task<GenericApiResponse<NewCardPaymentResponseModel>> NewCardPayment(NewCardPaymentRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<NewCardPaymentResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;

            if (!string.IsNullOrEmpty(model.EmailAddress))
                model.EmailAddress = model.EmailAddress.Trim();

            float ChargeAmount;
            string BundleName = "";

            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                //Check Bundle Limit
                var bundlesResponse = await _accountRepository.GetBundlesHistory(account);
                if (bundlesResponse.Count() >= 10)
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Failure("Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
                }

                //Get Bundle details
                var bundleResponse = await _bundleRepository.GetBundleById(model.BundleId);
                if (bundleResponse == null)
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Failure("Invalid Bundle", ApiStatusCodes.InvalidBundle);
                }

                BundleName = bundleResponse.BrandedName;
                ChargeAmount = bundleResponse.TotalCostPence / 100;
            }
            else
            {
                ChargeAmount = model.TopUpAmount;
            }

            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };

            if (model.CheckoutType == CheckOutTypes.TopUp)
            {
                promResponse = await _promotionService.CheckAnyActivePromotions(
                   ChargeAmount,
                   msisdn,
                   PaymentMethodTypes.Card,
                     new PromotionDependentTypes[] { PromotionDependentTypes.Topup, PromotionDependentTypes.AutoTopup },
                   model.IsAutoTopUp
                   );
            }

            var paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                PromotionsDetails = promResponse,
                CustomerMsisdn = msisdn,
                Amount = ChargeAmount,
                CheckoutPaymentType = model.CheckoutType,
                BundleId = model.BundleId,
                IpAddress = model.ipAddress,
                CustomerEmail = model.EmailAddress,
                Currency = currency,
                Pay360PaymentType = Pay360PaymentType.ExistingNew,
                CustomerAddressData = new AddressData()
                {
                    AddressL1 = model.billingAddressData.AddressL1,
                    AddressL2 = model.billingAddressData.AddressL2,
                    AddressL3 = model.billingAddressData.AddressL3,
                    AddressL4 = model.billingAddressData.AddressL4,
                    PostCode = model.billingAddressData.PostCode,
                    City = model.billingAddressData.City,
                    Region = model.billingAddressData.Region,
                    CountryCode = model.billingAddressData.CountryCode
                },
                CustomerCardData = new CardData()
                {
                    CardNumber = model.cardData.CardNumber,
                    NameOnCard = model.cardData.NameOnCard,
                    SecurityCode = model.cardData.SecurityCode,
                    ExpiryMonth = model.cardData.ExpiryMonth,
                    ExpiryYear = model.cardData.ExpiryYear
                },
                ShouldSaveCard = model.cardData.ShouldSaveCard,
                accountNumber = account,
                CustomerUniqueRef = model.CustomerUniqueRef
            });

            var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.ExistingNew);

            if (paymentResponse == null)
            {
                return GenericApiResponse<NewCardPaymentResponseModel>.Failure(null, "Payment service not responding",
                                                                                                ApiStatusCodes.PaymentServiceError);
            }

            paymentrequest.Pay360PaymentRequestExistingNew.basket.First().amount = (float)promResponse.FullfilmentAmount;

            if (paymentResponse.errorCode == 0)
            {
                await _PaymentFullfillment.InsertTransactionPayment(
                      paymentrequest.Pay360PaymentRequestExistingNew.basket,
                      paymentrequest.Pay360PaymentRequestExistingNew.transactionCurrency,
                      paymentrequest.Pay360PaymentRequestExistingNew.customerEmail,
                      paymentrequest.Pay360PaymentRequestExistingNew.productCode,
                      paymentResponse.payload.transactionId,
                      paymentrequest.Pay360PaymentRequestExistingNew.customerMsisdn,
                      Fullfillmenttype.Pay360,
                      0);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: PaymentService, Method: NewCardPayment - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Failure(null,
                                "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Failure(null,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Failure(null,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            if (paymentResponse.payload.outcome.reasonCode == "U100") //3d Secure Scenario
            {
                //Send Response
                return GenericApiResponse<NewCardPaymentResponseModel>.Failure(
                                                new NewCardPaymentResponseModel()
                                                {
                                                    threeDSecureData = new ThreeDSecureData()
                                                    {
                                                        pareq = paymentResponse.payload.clientRedirect.pareq,
                                                        redirectUrl = paymentResponse.payload.clientRedirect.url,
                                                        transactionId = paymentResponse.payload.transactionId,
                                                        returnUrl = _pay360Config.TopUpSettings.ReturnUrl +
                                                        "type=" + (int)model.CheckoutType +
                                                        "&customerEmail=" + model.EmailAddress +
                                                        "&customerMsisdn=" + msisdn +
                                                        "&currency=" + currency +
                                                        "&bundleId=" + model.BundleId +
                                                        "&FromBundleISO2=" + model.FromBundleISO2 +
                                                        "&ToBundleISO2=" + model.ToBundleISO2 +
                                                        "&IsAutoTopUp=" + model.IsAutoTopUp
                                                    }
                                                }, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

            }
            else if (paymentResponse.payload.outcome.reasonCode == "S100")
            {
                //Fullfilment
                if (_pay360Config.IsDirectFullfilment == false)
                {
                    try
                    {
                        await Pay360CardPaymentFullfillment(paymentResponse, paymentrequest.Pay360PaymentRequestExistingNew.customerMsisdn, paymentrequest.Pay360PaymentRequestExistingNew.customerEmail);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(
                                $"Class: Paymentservices, " +
                                $"Method: Pay360PaymentRequestExistingNew - PaymentFullfillment, " +
                                $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                                $"ErrorMessage: {ex.Message}");
                    }
                }


                //set auto topup
                if (model.IsAutoTopUp && model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await SetAutoTopUp(msisdn, currency);
                }

                try
                {
                    if (_airShipService.IsActive || _appsFlyerService.IsActive)
                    {
                        bool isFirstTopup = false;
                        int IsBundleExists = 1;

                        if (model.CheckoutType == CheckOutTypes.TopUp)
                            isFirstTopup = await _accountRepository.IsFirstTopUp(msisdn);

                        if (model.CheckoutType == CheckOutTypes.Bundle)
                            IsBundleExists = await _accountRepository.IsBundleExists(msisdn);

                        var PhoneUtil = PhoneNumberUtil.GetInstance();
                        PhoneNumber Number = PhoneUtil.Parse(msisdn.StartsWith("+") ? msisdn : "+" + msisdn, "");
                        var CountryCode = PhoneUtil.GetRegionCodeForNumber(Number);

                        var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);
                        var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());

#pragma warning disable CS4014

                        #region AppsFlyer
                        if (_appsFlyerService.IsActive)
                        {
                            if (model.CheckoutType == CheckOutTypes.Bundle)
                            {
                                _appsFlyerService.CreateEvent(msisdn, "success_bundle", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "cc_buy", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "last_bun", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "purchased_payg_bun", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "any_bundle", model.ipAddress, currency, transactionAmount, new
                                {
                                    amount = transactionAmount,
                                    origination = model.FromBundleISO2,
                                    destination = model.ToBundleISO2
                                });

                                _appsFlyerService.CreateEvent(msisdn, "" + GetCountryNameByCountryCode(model.ToBundleISO2) + "_bun", model.ipAddress, eventValue: new
                                {
                                    origination = model.FromBundleISO2
                                });

                                if (IsBundleExists == 0)
                                {
                                    _appsFlyerService.CreateEvent(msisdn, "first_bun", model.ipAddress);
                                }
                            }
                            else
                            {
                                if (isFirstTopup)
                                {
                                    _appsFlyerService.CreateEvent(msisdn, "user_first_topup", model.ipAddress);
                                }

                                _appsFlyerService.CreateEvent(msisdn, "user_last_topup", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "success_topup", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "any_topup", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "cc_buy", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "topup_" + Convert.ToInt32(transactionAmount) + "", model.ipAddress, currency, transactionAmount, new
                                {
                                    origination = CountryCode.ToLower(),
                                    amount = transactionAmount
                                });

                            }
                        }
                        #endregion

                        #region Airship
                        if (model.CheckoutType == CheckOutTypes.TopUp)
                            FireAirShipTopupEvents(
                                msisdn, paymentResponse.payload.transactionAmount, paymentResponse.payload.transactionId, currency, isFirstTopup, PaymentType.Card, CountryCode, customerResoonse.Balance);

                        if (model.CheckoutType == CheckOutTypes.Bundle)
                            FireAirShipBundlePurchaseEvents(
                                msisdn, paymentResponse.payload.transactionAmount, paymentResponse.payload.transactionId, currency, PaymentType.Card, BundleName, model.FromBundleISO2, model.ToBundleISO2, customerResoonse.Balance, IsBundleExists == 0);
                        #endregion

#pragma warning restore CS4014
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: PaymentService, Method: NewCardPayment-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }

                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Success(new NewCardPaymentResponseModel()
                    {
                        bundlePurchaseInfo = new BundlePurchaseInfo()
                        {
                            TransactionId = paymentResponse.payload.transactionId,
                            BundleAmount = paymentResponse.payload.transactionAmount,
                            BundleName = BundleName,
                            Currency = currency,
                            Msisdn = msisdn
                        }
                    }, "Bundle purchased successfully");
                }
                else
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Success(new NewCardPaymentResponseModel()
                    {
                        topupInfo = new TopupInfo()
                        {
                            TopupAmount = paymentResponse.payload.transactionAmount,
                            Msisdn = msisdn,
                            TransactionId = paymentResponse.payload.transactionId,
                            Currency = currency
                        }
                    }, "Top-Up Successfull");
                }
            }

            return GenericApiResponse<NewCardPaymentResponseModel>.Failure(null,
                                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
        }
        public async Task<GenericApiResponse<ExistingCardPaymentResponseModel>> ExistingCardPayment(ExistingCardPaymentRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;

            if (!string.IsNullOrEmpty(model.EmailAddress))
                model.EmailAddress = model.EmailAddress.Trim();

            float ChargeAmount;
            string BundleName = "";

            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                //Check Bundle Limit
                var bundlesResponse = await _accountRepository.GetBundlesHistory(account);
                if (bundlesResponse.Count() >= 10)
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure("Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
                }

                //Get Bundle details
                var bundleResponse = await _bundleRepository.GetBundleById(model.BundleId);
                if (bundleResponse == null)
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure("Invalid Bundle", ApiStatusCodes.InvalidBundle);
                }

                BundleName = bundleResponse.BrandedName;
                ChargeAmount = bundleResponse.TotalCostPence / 100;
            }
            else
            {
                ChargeAmount = model.TopUpAmount;
            }


            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };

            if (model.CheckoutType == CheckOutTypes.TopUp)
            {
                promResponse = await _promotionService.CheckAnyActivePromotions(
                  ChargeAmount,
                   msisdn,
                   PaymentMethodTypes.Card,
                     new PromotionDependentTypes[] { PromotionDependentTypes.Topup, PromotionDependentTypes.AutoTopup },
                   model.IsAutoTopUp
                   );
            }



            var paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                PromotionsDetails = promResponse,
                CustomerMsisdn = msisdn,
                Amount = ChargeAmount,
                CheckoutPaymentType = model.CheckoutType,
                BundleId = model.BundleId,
                IpAddress = model.ipAddress,
                CustomerEmail = model.EmailAddress,
                Currency = currency,
                Pay360PaymentType = Pay360PaymentType.Token,
                CardToken = model.cardToken,
                SecurityCode = model.securityCode,
                accountNumber = account,
                CustomerUniqueRef = model.CustomerUniqueRef
            });

            var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.Token);

            if (paymentResponse == null)
            {
                return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(null, "Payment service not responding",
                                                                                                    ApiStatusCodes.PaymentServiceError);
            }
            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: PaymentService, Method: ExistingCardPayment - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");

                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(null,
                                "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(null,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(null,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            paymentrequest.Pay360PaymentRequestToken.basket.First().amount = (float)promResponse.FullfilmentAmount;

            if (paymentResponse.errorCode == 0)
            {
                await _PaymentFullfillment.InsertTransactionPayment(
                      paymentrequest.Pay360PaymentRequestToken.basket,
                      paymentrequest.Pay360PaymentRequestToken.transactionCurrency,
                      paymentrequest.Pay360PaymentRequestToken.customerEmail,
                      paymentrequest.Pay360PaymentRequestToken.productCode,
                      paymentResponse.payload.transactionId,
                      msisdn,
                      Fullfillmenttype.Pay360,
                      0);
            }


            if (paymentResponse.payload.outcome.reasonCode == "U100") //3d Secure Scenario
            {
                //Send Response
                return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(
                                                new ExistingCardPaymentResponseModel()
                                                {
                                                    threeDSecureData = new ThreeDSecureData()
                                                    {
                                                        pareq = paymentResponse.payload.clientRedirect.pareq,
                                                        redirectUrl = paymentResponse.payload.clientRedirect.url,
                                                        transactionId = paymentResponse.payload.transactionId,
                                                        returnUrl = _pay360Config.TopUpSettings.ReturnUrl +
                                                        "type=" + (int)model.CheckoutType +
                                                        "&customerEmail=" + model.EmailAddress +
                                                        "&customerMsisdn=" + msisdn +
                                                        "&currency=" + currency +
                                                        "&bundleId=" + model.BundleId +
                                                        "&FromBundleISO2=" + model.FromBundleISO2 +
                                                        "&ToBundleISO2=" + model.ToBundleISO2 +
                                                        "&IsAutoTopUp=" + model.IsAutoTopUp
                                                    }
                                                }, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

            }
            else if (paymentResponse.payload.outcome.reasonCode == "S100")
            {
                //Fullfilment
                if (_pay360Config.IsDirectFullfilment == false)
                {
                    try
                    {
                        await Pay360CardPaymentFullfillment(
                            paymentResponse,
                            paymentrequest.Pay360PaymentRequestToken.customerMsisdn,
                            paymentrequest.Pay360PaymentRequestToken.customerEmail);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(
                                $"Class: Paymentservices, " +
                                $"Method: Pay360PaymentRequestToken - PaymentFullfillment, " +
                                $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                                $"ErrorMessage: {ex.Message}");
                    }
                }

                //set auto topup
                if (model.IsAutoTopUp && model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await SetAutoTopUp(msisdn, currency);
                }

                //Events
                try
                {
                    if (_airShipService.IsActive || _appsFlyerService.IsActive)
                    {
                        bool isFirstTopup = false;
                        int IsBundleExists = 1;

                        if (model.CheckoutType == CheckOutTypes.TopUp)
                            isFirstTopup = await _accountRepository.IsFirstTopUp(msisdn);

                        if (model.CheckoutType == CheckOutTypes.Bundle)
                            IsBundleExists = await _accountRepository.IsBundleExists(msisdn);

                        var PhoneUtil = PhoneNumberUtil.GetInstance();
                        PhoneNumber Number = PhoneUtil.Parse(msisdn.StartsWith("+") ? msisdn : "+" + msisdn, "");
                        var CountryCode = PhoneUtil.GetRegionCodeForNumber(Number);

                        var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);

                        var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());

#pragma warning disable CS4014

                        #region AppsFlyer
                        if (_appsFlyerService.IsActive)
                        {
                            if (model.CheckoutType == CheckOutTypes.Bundle)
                            {
                                _appsFlyerService.CreateEvent(msisdn, "success_bundle", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "cc_buy", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "last_bun", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "purchased_payg_bun", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "any_bundle", model.ipAddress, currency, transactionAmount, new
                                {
                                    amount = transactionAmount,
                                    origination = model.FromBundleISO2,
                                    destination = model.ToBundleISO2
                                });

                                _appsFlyerService.CreateEvent(msisdn, "" + GetCountryNameByCountryCode(model.ToBundleISO2) + "_bun", model.ipAddress, eventValue: new
                                {
                                    origination = model.FromBundleISO2
                                });

                                if (IsBundleExists == 0)
                                {
                                    _appsFlyerService.CreateEvent(msisdn, "first_bun", model.ipAddress);
                                }
                            }
                            else
                            {
                                if (isFirstTopup)
                                {
                                    _appsFlyerService.CreateEvent(msisdn, "user_first_topup", model.ipAddress);
                                }

                                _appsFlyerService.CreateEvent(msisdn, "user_last_topup", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "success_topup", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "any_topup", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "cc_buy", model.ipAddress);

                                _appsFlyerService.CreateEvent(msisdn, "topup_" + Convert.ToInt32(transactionAmount) + "", model.ipAddress, currency, transactionAmount, new
                                {
                                    origination = CountryCode.ToLower(),
                                    amount = ChargeAmount
                                });

                            }
                        }
                        #endregion

                        #region Airship

                        if (model.CheckoutType == CheckOutTypes.TopUp)
                            FireAirShipTopupEvents(
                                msisdn, paymentResponse.payload.transactionAmount, paymentResponse.payload.transactionId, currency, isFirstTopup, PaymentType.Card, CountryCode, customerResoonse.Balance);

                        if (model.CheckoutType == CheckOutTypes.Bundle)
                            FireAirShipBundlePurchaseEvents(
                                msisdn, paymentResponse.payload.transactionAmount, paymentResponse.payload.transactionId, currency, PaymentType.Card, BundleName, model.FromBundleISO2, model.ToBundleISO2, customerResoonse.Balance, IsBundleExists == 0);

                        #endregion

#pragma warning restore CS4014

                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: PaymentService, Method: ExistingCardPayment-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }

                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Success(new ExistingCardPaymentResponseModel()
                    {
                        bundlePurchaseInfo = new BundlePurchaseInfo()
                        {
                            TransactionId = paymentResponse.payload.transactionId,
                            BundleAmount = paymentResponse.payload.transactionAmount,
                            BundleName = BundleName,
                            Currency = currency,
                            Msisdn = msisdn
                        }
                    }, "Bundle purchased successfully");
                }
                else
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Success(new ExistingCardPaymentResponseModel()
                    {
                        topupInfo = new TopupInfo()
                        {
                            TopupAmount = paymentResponse.payload.transactionAmount,
                            Msisdn = msisdn,
                            TransactionId = paymentResponse.payload.transactionId,
                            Currency = currency
                        }
                    }, "Top-Up Successfull");
                }
            }

            return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(null,
                                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
        }
        public async Task<GenericApiResponse<Pay360Resume3DResponseModel>> Resume3DTransaction(Pay360Resume3DRequestModel request)
        {
            var paymentResponse = await _pay360Service.Resume3DTransaction(new Pay360Resume3DRequest()
            {
                pareq = request.PaRes,
                pay360TransactionId = request.MD,
                customerEmail = request.customerEmail
            });

            if (paymentResponse == null)
            {
                return GenericApiResponse<Pay360Resume3DResponseModel>.Failure(null, "Payment service not responding",
                                                                                                ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: PaymentService, Method: Resume3DTransaction - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(request)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<Pay360Resume3DResponseModel>.Failure(null,
                                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<Pay360Resume3DResponseModel>.Failure(null,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<Pay360Resume3DResponseModel>.Failure(null,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            //Full-filment
            if (_pay360Config.IsDirectFullfilment == false)
            {
                try
                {
                    await Pay360CardPaymentFullfillment(paymentResponse, request.customerMsisdn, request.customerEmail);
                }
                catch (Exception ex)
                {
                    _logger.Error(
                            $"Class: Pay360_BL, " +
                            $"Method: Resume3d - PaymentFullfillment, " +
                            $"Parameters=> Request: {JsonConvert.SerializeObject(request)}, " +
                            $"ErrorMessage: {ex.Message}");
                }
            }

            //Set auto top-up
            if (request.IsAutoTopUp && request.type == CheckOutTypes.TopUp)
            {
                await SetAutoTopUp(request.customerMsisdn, request.currency);
            }


            string bundleName = "";

            if (request.type == CheckOutTypes.Bundle)
                bundleName = (await _bundleRepository.GetBundleById(request.bundleId)).BrandedName;

            try
            {
                if (_airShipService.IsActive || _appsFlyerService.IsActive)
                {
                    bool isFirstTopup = false;
                    int IsBundleExists = 1;

                    if (request.type == CheckOutTypes.TopUp)
                        isFirstTopup = await _accountRepository.IsFirstTopUp(request.customerMsisdn);

                    if (request.type == CheckOutTypes.Bundle)
                        IsBundleExists = await _accountRepository.IsBundleExists(request.customerMsisdn);

                    var PhoneUtil = PhoneNumberUtil.GetInstance();
                    PhoneNumber Number = PhoneUtil.Parse(request.customerMsisdn.StartsWith("+") ? request.customerMsisdn : "+" + request.customerMsisdn, "");
                    var CountryCode = PhoneUtil.GetRegionCodeForNumber(Number);

                    var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);

                    var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + request.customerMsisdn);

#pragma warning disable CS4014

                    #region AppsFlyer
                    if (_appsFlyerService.IsActive)
                    {
                        if (request.type == CheckOutTypes.Bundle)
                        {
                            _appsFlyerService.CreateEvent(request.customerMsisdn, "success_bundle", request.IpAddress);

                            _appsFlyerService.CreateEvent(request.customerMsisdn, "cc_buy", request.IpAddress);

                            _appsFlyerService.CreateEvent(request.customerMsisdn, "last_bun", request.IpAddress);

                            _appsFlyerService.CreateEvent(request.customerMsisdn, "purchased_payg_bun", request.IpAddress);

                            _appsFlyerService.CreateEvent(request.customerMsisdn, "any_bundle", request.IpAddress, request.currency, transactionAmount, new
                            {
                                amount = transactionAmount,
                                origination = request.FromBundleISO2,
                                destination = request.ToBundleISO2
                            });

                            _appsFlyerService.CreateEvent(request.customerMsisdn, "" + GetCountryNameByCountryCode(request.ToBundleISO2) + "_bun", request.IpAddress, eventValue: new
                            {
                                origination = request.FromBundleISO2
                            });

                            if (IsBundleExists == 0)
                            {
                                _appsFlyerService.CreateEvent(request.customerMsisdn, "first_bun", request.IpAddress);
                            }
                        }
                        else
                        {
                            if (isFirstTopup)
                            {
                                _appsFlyerService.CreateEvent(request.customerMsisdn, "user_first_topup", request.IpAddress);
                            }
                            _appsFlyerService.CreateEvent(request.customerMsisdn, "user_last_topup", request.IpAddress);
                            _appsFlyerService.CreateEvent(request.customerMsisdn, "success_topup", request.IpAddress);
                            _appsFlyerService.CreateEvent(request.customerMsisdn, "any_topup", request.IpAddress);
                            _appsFlyerService.CreateEvent(request.customerMsisdn, "cc_buy", request.IpAddress);

                            _appsFlyerService.CreateEvent(request.customerMsisdn, "topup_" + Convert.ToInt32(transactionAmount) + "", request.IpAddress, request.currency, transactionAmount, new
                            {
                                origination = CountryCode.ToLower(),
                                amount = transactionAmount
                            });

                        }
                    }
                    #endregion

                    #region Airship
                    if (request.type == CheckOutTypes.TopUp)
                        FireAirShipTopupEvents(
                            request.customerMsisdn, paymentResponse.payload.transactionAmount, paymentResponse.payload.transactionId, request.currency, isFirstTopup, PaymentType.Card, CountryCode, customerResoonse.Balance);

                    if (request.type == CheckOutTypes.Bundle)
                        FireAirShipBundlePurchaseEvents(
                            request.customerMsisdn, paymentResponse.payload.transactionAmount, paymentResponse.payload.transactionId, request.currency, PaymentType.Card, bundleName, request.FromBundleISO2, request.ToBundleISO2, customerResoonse.Balance, IsBundleExists == 0);
                    #endregion

#pragma warning restore CS4014
                }

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentService, Method: Resume3DTransaction-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }

            if (request.type == CheckOutTypes.Bundle)
            {
                return GenericApiResponse<Pay360Resume3DResponseModel>.Success(new Pay360Resume3DResponseModel()
                {
                    bundlePurchaseInfo = new BundlePurchaseInfo()
                    {
                        TransactionId = paymentResponse.payload.transactionId,
                        BundleAmount = paymentResponse.payload.transactionAmount,
                        BundleName = bundleName,
                        Msisdn = request.customerMsisdn,
                        Currency = request.currency
                    },
                }, "Bundle purchased successfully");
            }
            else
            {
                return GenericApiResponse<Pay360Resume3DResponseModel>.Success(new Pay360Resume3DResponseModel()
                {
                    topupInfo = new TopupInfo()
                    {
                        TopupAmount = paymentResponse.payload.transactionAmount,
                        Msisdn = request.customerMsisdn,
                        TransactionId = paymentResponse.payload.transactionId,
                        Currency = request.currency
                    }
                }, "Top-Up Successfull");
            }
        }
        public async Task<GenericApiResponse<PaypalPaymentResponseModel>> PaypalPayment(PaypalPaymentRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<PaypalPaymentResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;

            //Get User registration Date
            float ChargeAmount;

            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                //Check Bundle Limit
                var bundlesResponse = await _accountRepository.GetBundlesHistory(account);
                if (bundlesResponse.Count() >= 10)
                {
                    return GenericApiResponse<PaypalPaymentResponseModel>.Failure("Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
                }

                //Get Bundle details
                var bundleResponse = await _bundleRepository.GetBundleById(model.BundleId);
                if (bundleResponse == null)
                {
                    return GenericApiResponse<PaypalPaymentResponseModel>.Failure("Invalid Bundle", ApiStatusCodes.InvalidBundle);
                }

                ChargeAmount = bundleResponse.TotalCostPence / 100;
            }
            else
            {
                ChargeAmount = model.TopUpAmount;
            }


            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };

            if (model.CheckoutType == CheckOutTypes.TopUp)
            {
                promResponse = await _promotionService.CheckAnyActivePromotions(
                   ChargeAmount,
                   msisdn,
                   PaymentMethodTypes.Paypal,
                   new PromotionDependentTypes[] { PromotionDependentTypes.Topup, PromotionDependentTypes.AutoTopup },
                   false
                   );
            }


            //Get user details
            var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);

            if (_payPalConfig.IsPaypalByPay360)
            {
                //Get User Registration Date
                var userRegistrationDate = await _accountRepository.GetUserRegistrationDate(account);

                PayPalByPay360CSPaymentRequest request = new PayPalByPay360CSPaymentRequest
                {
                    CustomerName = userResponse != null ? !string.IsNullOrEmpty(userResponse.firstname) ? userResponse.firstname : msisdn : msisdn,
                    CustomerEmail = model.EmailAddress,
                    CustomerMsisdn = msisdn,
                    CustomerUniqueRef = msisdn,
                    ProductCode = ProductCode.THA.ToString(),
                    isDirectFullfilment = _pay360Config.IsDirectFullfilment,
                    transactionCurrency = currency,
                    PaymentMethod = new PayPalByPay360PaymentMethod()
                    {
                        Paypal = new PayPalByPay360Urls()
                        {
                            returnUrl = _payPalConfig.TopupByPayPalReturnUrl.TopupPayPalByPay360ReturnUrl + "type=" + (int)model.CheckoutType + "&bundleId=" + model.BundleId + "&FromBundleISO2=" + model.FromBundleISO2 +
                                                        "&ToBundleISO2=" + model.ToBundleISO2 + "&Msisdn=" + model.Msisdn.Trim(),
                            cancelUrl = _payPalConfig.TopupByPayPalReturnUrl.TopupCancelUrl
                        }
                    },
                    ipAddress = model.ipAddress,
                    Basket = new List<PayPalByPay360Basket>() {
                            new PayPalByPay360Basket()
                            {
                                amount =  promResponse.ChargeAmount,
                                bundleRef = model.CheckoutType == CheckOutTypes.Bundle ? model.BundleId:"",
                                productItemCode = ProductItemCode.THAATW.ToString(),
                                productRef = msisdn
                            }
                        },
                    transactionAmount = promResponse.ChargeAmount,
                    CustomFields = new PayPalByPay360CustomField()
                    {
                        fieldState = new List<PayPalByPay360FieldState>()
                            {
                                new PayPalByPay360FieldState() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
                                new PayPalByPay360FieldState() { name = "ProductItemCode", value = ProductItemCode.THAATW.ToString(), transient = false },
                                new PayPalByPay360FieldState() { name = "FirstUseDate", value = userRegistrationDate.ToString("yyyy-MM-dd"), transient = false  }
                            }
                    }
                };
                var paymentResponse = await _payPalService.PayPalByPay360CS(request);

                if (paymentResponse == null)
                {
                    return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                  "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }

                request.Basket.First().amount = promResponse.FullfilmentAmount;

                if (paymentResponse.errorCode == 0)
                {
                    await _PaymentFullfillment.InsertPaypalTransactionPayment(
                           request.Basket,
                           request.transactionCurrency,
                           request.CustomerEmail,
                           request.ProductCode,
                           paymentResponse.payload.transactionId,
                           request.CustomerMsisdn,
                           Fullfillmenttype.Pay360Paypal,
                           0);
                }

                if (paymentResponse.errorCode > 0)
                {
                    _logger.Error($"Class: PaymentService, Method: PaypalPayment - PaymentResponse - V2, " +
                                            $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                            $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                    if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                    "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                    }
                    else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                                          paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                    }
                    else
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                            "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                    }
                }

                return GenericApiResponse<PaypalPaymentResponseModel>.Success(
                    new PaypalPaymentResponseModel()
                    {
                        clientRedirectUrl = paymentResponse.payload.clientRedirectUrl
                    }, "Payment created successfully");

            }
            else
            {
                var baskets = new List<ProductBasket>();
                var basket = new ProductBasket()
                {
                    Amount = ChargeAmount,
                    BundleRef = model.CheckoutType == CheckOutTypes.Bundle ? model.BundleId : "",
                    ProductItemCode = ProductItemCode.THAATW.ToString(),
                    ProductRef = msisdn
                };

                baskets.Add(basket);

                var request = new PayPalCreateSalePaymentRequest
                {
                    CustomerName = !string.IsNullOrEmpty(userResponse.firstname)
                                                            ? userResponse.firstname : msisdn,
                    CustomerMsisdn = msisdn,
                    CustomerUniqueRef = msisdn,
                    CustomerEmail = model.EmailAddress,
                    ProductCode = ProductCode.THA.ToString(),
                    Transaction = new Transactions()
                    {
                        Amount = new Amounts()
                        {
                            Total = ChargeAmount,
                            Currency = currency
                        },
                        Description = model.CheckoutType == CheckOutTypes.TopUp
                        ? "Topup payment request from THA-Web" : "Bundle payment request from THA-Web"
                    },
                    RedirectUrl = new RedirectUrls
                    {
                        ReturnUrl = _payPalConfig.TopupByPayPalReturnUrl.TopupPayPalReturnUrl + "type=" + (int)model.CheckoutType + "&bundleId=" + model.BundleId + "&Msisdn=" + model.Msisdn.Trim(),
                        CancelUrl = _payPalConfig.TopupByPayPalReturnUrl.TopupCancelUrl
                    },
                    Basket = baskets
                };

                var paymentResponse = await _payPalService.PayPalCreateSalePayment(request);

                if (paymentResponse == null)
                {
                    return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                  "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }

                if (paymentResponse.errorCode > 0)
                {
                    _logger.Error($"Class: PaymentService, Method: PaypalPayment - PaymentResponse - V1, " +
                                            $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                            $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                    if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                    "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                    }
                    else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                                          paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                    }
                    else
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                    }
                }

                return GenericApiResponse<PaypalPaymentResponseModel>.Success(
                    new PaypalPaymentResponseModel()
                    {
                        clientRedirectUrl = paymentResponse.payload.RedirectUrl
                    }, "Payment created successfully");
            }
        }
        public async Task<GenericApiResponse<PaypalPaymentCallBackResponseModel>> PaypalPaymentCallBack(
                                                                                        PaypalPaymentCallBackRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;

            var paymentResponse = await _payPalService.PayPalExecuteSalePayment(new PayPalExecuteSalePaymentRequest()
            {
                PayerId = model.PayerId,
                PaymentId = model.PaymentId,
                ProductCode = ProductCode.THA.ToString(),
                CustomerUniqueRef = msisdn
            });

            if (paymentResponse == null)
            {
                return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Failure(null,
                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: PaymentService, Method: PaypalPaymentCallBack - PaymentResponse, " +
                                             $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                             $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Failure(null,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Failure(null,
                                                    paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            if (model.type == CheckOutTypes.Bundle)
            {
                //Get Bundle details
                var bundleResponse = await _bundleRepository.GetBundleById(model.bundleId);

                return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Success(new PaypalPaymentCallBackResponseModel()
                {
                    bundlePurchaseInfo = new BundlePurchaseInfo()
                    {
                        TransactionId = paymentResponse.payload.PaypalTransactionId,
                        BundleAmount = ((bundleResponse.TotalCostPence) / 100).ToString(),
                        BundleName = bundleResponse.BrandedName,
                        Msisdn = msisdn,
                        Currency = currency
                    }

                }, "Bundle purchased successfully");
            }
            else
            {
                return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Success(new PaypalPaymentCallBackResponseModel()
                {
                    topupInfo = new TopupInfo()
                    {
                        Msisdn = msisdn,
                        TransactionId = paymentResponse.payload.PaypalTransactionId,
                        Currency = currency
                    }
                }, "Top-Up Successfull");
            }
        }
        public async Task<GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>> PaypalByPay360PaymentCallBack(
                                                                                            PaypalByPay360PaymentCallBackRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;

            var paymentResponse = await _payPalService.PayPalByPay360ES(new PayPalByPay360ESPaymentRequest()
            {
                PaypalCheckoutToken = model.Token
            });

            if (paymentResponse == null)
            {
                return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Failure(null,
                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: PaymentService, Method: PaypalByPay360PaymentCallBack - PaymentResponse, " +
                                             $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                             $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Failure(null,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Failure(null,
                                                    paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            //Fullfilment
            if (_payPalConfig.IsDirectFullfilment == false)
            {
                try
                {
                    await Pay360PaypalPaymentFullfillment(paymentResponse, model.Msisdn, "");
                }
                catch (Exception ex)
                {
                    _logger.Error(
                            $"Class: Paymentservices, " +
                            $"Method: PaypalByPay360PaymentCallBack - PaymentFullfillment, " +
                            $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                            $"ErrorMessage: {ex.Message}");
                }
            }


            string bundleName = "";

            if (model.type == CheckOutTypes.Bundle)
            {
                bundleName = (await _bundleRepository.GetBundleById(model.bundleId)).BrandedName;
            }

            //Events
            try
            {
                if (_airShipService.IsActive || _appsFlyerService.IsActive)
                {
                    bool isFirstTopup = false;
                    int IsBundleExists = 1;

                    if (model.type == CheckOutTypes.TopUp)
                        isFirstTopup = await _accountRepository.IsFirstTopUp(msisdn);

                    if (model.type == CheckOutTypes.Bundle)
                        IsBundleExists = await _accountRepository.IsBundleExists(msisdn);

                    var PhoneUtil = PhoneNumberUtil.GetInstance();
                    PhoneNumber Number = PhoneUtil.Parse(msisdn.StartsWith("+") ? msisdn : "+" + msisdn, "");
                    var CountryCode = PhoneUtil.GetRegionCodeForNumber(Number);

                    var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);

                    var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);

#pragma warning disable CS4014

                    #region AppsFlyer
                    if (_appsFlyerService.IsActive)
                    {
                        if (model.type == CheckOutTypes.Bundle)
                        {
                            _appsFlyerService.CreateEvent(msisdn, "success_bundle", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "last_bun", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "purchased_payg_bun", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "any_bundle", model.IpAddress, currency, transactionAmount, new
                            {
                                amount = transactionAmount,
                                origination = model.FromBundleISO2,
                                destination = model.ToBundleISO2
                            });

                            _appsFlyerService.CreateEvent(msisdn, "" + GetCountryNameByCountryCode(model.ToBundleISO2) + "_bun", model.IpAddress, eventValue: new
                            {
                                origination = model.FromBundleISO2
                            });

                            if (IsBundleExists == 0)
                            {
                                _appsFlyerService.CreateEvent(msisdn, "first_bun", model.IpAddress);
                            }
                        }
                        else
                        {
                            if (isFirstTopup)
                            {
                                _appsFlyerService.CreateEvent(msisdn, "user_first_topup", model.IpAddress);
                            }

                            _appsFlyerService.CreateEvent(msisdn, "user_last_topup", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "success_topup", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "any_topup", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "pp_buy", model.IpAddress);

                            _appsFlyerService.CreateEvent(msisdn, "topup_" + Convert.ToInt32(transactionAmount) + "", model.IpAddress, currency, transactionAmount, new
                            {
                                origination = CountryCode.ToLower(),
                                amount = transactionAmount
                            });
                        }
                    }
                    #endregion

                    #region Airship

                    if (model.type == CheckOutTypes.TopUp)
                        FireAirShipTopupEvents(msisdn, paymentResponse.payload.transactionAmount, paymentResponse.payload.transactionId, currency, isFirstTopup, PaymentType.Paypal, CountryCode, customerResoonse.Balance);

                    if (model.type == CheckOutTypes.Bundle)
                        FireAirShipBundlePurchaseEvents(msisdn, paymentResponse.payload.transactionAmount, paymentResponse.payload.transactionId, currency, PaymentType.Card, bundleName, model.FromBundleISO2, model.ToBundleISO2, customerResoonse.Balance, IsBundleExists == 0);

                    #endregion

#pragma warning restore CS4014
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentService, Method: PaypalByPay360PaymentCallBack-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }


            if (model.type == CheckOutTypes.Bundle)
            {
                return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Success(
                    new PaypalByPay360PaymentCallBackResponseModel()
                    {
                        bundlePurchaseInfo = new BundlePurchaseInfo()
                        {
                            TransactionId = paymentResponse.payload.transactionId,
                            BundleAmount = paymentResponse.payload.transactionAmount,
                            BundleName = bundleName,
                            Currency = currency,
                            Msisdn = msisdn
                        }

                    }, "Bundle purchased successfully");
            }
            else
            {
                return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Success(new PaypalByPay360PaymentCallBackResponseModel()
                {
                    topupInfo = new TopupInfo()
                    {
                        TopupAmount = paymentResponse.payload.transactionAmount,
                        Msisdn = msisdn,
                        TransactionId = paymentResponse.payload.transactionId,
                        Currency = currency
                    }
                }, "Top-Up Successfull");
            }
        }
        private async Task<Pay360PaymentRequest> GeneratePay360PaymentRequest(Pay360PaymentRequestData model)
        {
            //Get User Registration Date
            var userRegistrationDate = await _accountRepository.GetUserRegistrationDate(model.accountNumber);

            List<fieldstate> _fieldState = new List<fieldstate>()
                {
                    new fieldstate() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
                    new fieldstate() { name = "ProductItemCode", value = ProductItemCode.THAATW.ToString(), transient = false },
                    new fieldstate() { name = "FirstUseDate", value = userRegistrationDate.ToString("yyyy-MM-dd"), transient = false },
                };

            List<basket> baskets = new List<basket>();

            if (model.CheckoutPaymentType == CheckOutTypes.Bundle)
            {
                basket basket = new basket()
                {
                    amount = model.Amount,
                    bundleRef = model.BundleId,
                    productItemCode = ProductItemCode.THAATW.ToString(),
                    productRef = model.CustomerMsisdn
                };

                baskets.Add(basket);
            }
            else
            {
                basket basket = new basket()
                {
                    amount = model.PromotionsDetails.ChargeAmount,
                    bundleRef = "",
                    productItemCode = ProductItemCode.THAATW.ToString(),
                    productRef = model.CustomerMsisdn
                };

                baskets.Add(basket);
            }

            Pay360PaymentRequest request = new Pay360PaymentRequest();

            switch (model.Pay360PaymentType)
            {
                case Pay360PaymentType.New:
                    request.Pay360PaymentRequestNew = new Pay360PaymentRequestNew();
                    request.Pay360PaymentRequestNew.basket = baskets;
                    request.Pay360PaymentRequestNew.customerName = model.CustomerCardData.NameOnCard;
                    request.Pay360PaymentRequestNew.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestNew.customerUniqueRef = model.CustomerUniqueRef;
                    request.Pay360PaymentRequestNew.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestNew.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestNew.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestNew.transactionAmount = model.PromotionsDetails.ChargeAmount;
                    request.Pay360PaymentRequestNew.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestNew.cardCv2 = model.CustomerCardData.SecurityCode;
                    request.Pay360PaymentRequestNew.cardExpiryDate = model.CustomerCardData.ExpiryMonth + model.CustomerCardData.ExpiryYear;
                    request.Pay360PaymentRequestNew.cardPan = model.CustomerCardData.CardNumber;
                    request.Pay360PaymentRequestNew.isDirectFullfilment = _pay360Config.IsDirectFullfilment;
                    request.Pay360PaymentRequestNew.isAuthorizationOnly = _pay360Config.IsAuthorization;
                    request.Pay360PaymentRequestNew.isDefaultCard = true;
                    request.Pay360PaymentRequestNew.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestNew.saveCard = model.ShouldSaveCard;
                    request.Pay360PaymentRequestNew.billingAddress = new billingAddress()
                    {
                        line1 = model.CustomerAddressData.AddressL1,
                        line2 = model.CustomerAddressData.AddressL2,
                        line3 = model.CustomerAddressData.AddressL3,
                        line4 = model.CustomerAddressData.AddressL4,
                        region = model.CustomerAddressData.Region,
                        city = model.CustomerAddressData.City,
                        postcode = model.CustomerAddressData.PostCode,
                        countryCode = model.CustomerAddressData.CountryCode
                    };
                    if (_pay360Config.IsBillingAndCustomerAddressSame == true)
                        request.Pay360PaymentRequestNew.customerBillingAddress = request.Pay360PaymentRequestNew.billingAddress;
                    break;
                case Pay360PaymentType.Token:
                    request.Pay360PaymentRequestToken = new Pay360PaymentRequestToken();
                    request.Pay360PaymentRequestToken.basket = baskets;
                    request.Pay360PaymentRequestToken.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestToken.customerUniqueRef = model.CustomerUniqueRef;
                    request.Pay360PaymentRequestToken.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestToken.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestToken.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestToken.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestToken.cardCv2 = model.SecurityCode;
                    request.Pay360PaymentRequestToken.transactionAmount = model.PromotionsDetails.ChargeAmount;
                    request.Pay360PaymentRequestToken.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestToken.isDirectFullfilment = _pay360Config.IsDirectFullfilment;
                    request.Pay360PaymentRequestToken.isAuthorizationOnly = _pay360Config.IsAuthorization;
                    request.Pay360PaymentRequestToken.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestToken.cardToken = model.CardToken;
                    break;
                case Pay360PaymentType.ExistingNew:
                    request.Pay360PaymentRequestExistingNew = new Pay360PaymentRequestExistingNew();
                    request.Pay360PaymentRequestExistingNew.basket = baskets;
                    request.Pay360PaymentRequestExistingNew.customerName = model.CustomerCardData.NameOnCard;
                    request.Pay360PaymentRequestExistingNew.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestExistingNew.customerUniqueRef = model.CustomerUniqueRef;
                    request.Pay360PaymentRequestExistingNew.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestExistingNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestExistingNew.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestExistingNew.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestExistingNew.cardCv2 = model.CustomerCardData.SecurityCode;
                    request.Pay360PaymentRequestExistingNew.transactionAmount = model.PromotionsDetails.ChargeAmount;
                    request.Pay360PaymentRequestExistingNew.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestExistingNew.cardExpiryDate = model.CustomerCardData.ExpiryMonth + model.CustomerCardData.ExpiryYear;
                    request.Pay360PaymentRequestExistingNew.cardPan = model.CustomerCardData.CardNumber;
                    request.Pay360PaymentRequestExistingNew.isDirectFullfilment = _pay360Config.IsDirectFullfilment;
                    request.Pay360PaymentRequestExistingNew.isAuthorizationOnly = _pay360Config.IsAuthorization;
                    request.Pay360PaymentRequestExistingNew.isDefaultCard = true;
                    request.Pay360PaymentRequestExistingNew.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestExistingNew.saveCard = model.ShouldSaveCard;
                    request.Pay360PaymentRequestExistingNew.billingAddress = new billingAddress()
                    {
                        line1 = model.CustomerAddressData.AddressL1,
                        line2 = model.CustomerAddressData.AddressL2,
                        line3 = model.CustomerAddressData.AddressL3,
                        line4 = model.CustomerAddressData.AddressL4,
                        region = model.CustomerAddressData.Region,
                        city = model.CustomerAddressData.City,
                        postcode = model.CustomerAddressData.PostCode,
                        countryCode = model.CustomerAddressData.CountryCode
                    };
                    break;
            }

            return request;
        }

        private string GetCountryNameByCountryCode(string code)
        {
            var completePath = Path.GetFullPath(Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot/CountriesName.json"));

            var json = System.IO.File.ReadAllText(completePath);

            var _countries = JsonConvert.DeserializeObject<CountriesData>(json);

            return _countries.countries.Where(x => x.IsoTwoCharacterCode.ToLower().Equals(code.ToLower())).First().Name.ToLower().Replace(" ", "").Trim();
        }

        private async Task Pay360CardPaymentFullfillment(
            GenericApiResponse<Pay360PaymentResponse> paymentResponse, string missdn, string PaymentEmailAddress)
        {
            string pay360TransactionId = paymentResponse.payload.transactionId;

            var basket = await _PaymentFullfillment.Getbasketitem(paymentResponse.payload.transactionId);
            foreach (var item in basket)
            {

                var ccAuthCode = pay360TransactionId;
                var CssTransId = pay360TransactionId;
                var amount = item.amount * 100;
                var bundleRef = item.bundleref;

                var result = await _PaymentFullfillment.
                    ThaPay360cardCustomerFullfilment(missdn, (decimal)amount, CssTransId, ccAuthCode, bundleRef);

                if (result != null && result.ErrorCode == 0)
                {
                    await _PaymentFullfillment.UpdatePaymenttransactionsItems(true, item.id, null, true);

                    var newBalanceCurrency = item.Transactioncurrency;
                    if (newBalanceCurrency == "USD")
                    {
                        newBalanceCurrency = "$";
                    }
                    else if (newBalanceCurrency == "GBP")
                    {
                        newBalanceCurrency = "£";
                    }
                    else if (newBalanceCurrency == "EUR")
                    {
                        newBalanceCurrency = "€";
                    }

                    if (PaymentEmailAddress != null && _SmtpConfig.sendEmailToCustomer)
                    {
                        string customerEmailMsg = $"Talkhome App \r\nYou have successfully Topped Up. \r\nTop Up Amount: {newBalanceCurrency}{item.amount}\r\nTransaction Id: {pay360TransactionId}";
                        if (!string.IsNullOrWhiteSpace(item.bundleref))
                        {
                            customerEmailMsg = $"Talkhome App\r\nYou have successfully purchased a bundle. \r\nBundle Name: {result.BundleName} \r\nBundle Amount: {newBalanceCurrency}{item.amount}\r\nTransaction Id: {pay360TransactionId}";
                        }
                        await SendEmailToCustomer(PaymentEmailAddress, customerEmailMsg);
                    }

                }
                else
                {
                    await _PaymentFullfillment.UpdatePaymenttransactionsItems(false, item.id, result.ErrorMessage, false);
                }
            }

        }

        private async Task Pay360PaypalPaymentFullfillment(
            GenericPayPalApiResponse<PayPalByPay360ESPaymentResponse> paymentResponse, string msisdn, string PaymentEmailAddress)
        {
            string pay360TransactionId = paymentResponse.payload.transactionId;

            var basket = await _PaymentFullfillment.Getbasketitem(paymentResponse.payload.transactionId);

            foreach (var item in basket)
            {
                PaymentEmailAddress = item.Email;

                var ccAuthCode = pay360TransactionId;
                var CssTransId = pay360TransactionId;
                var amount = item.amount * 100;
                var bundleRef = item.bundleref;

                var result = await _PaymentFullfillment.ThaPay360paypalStraightCustomerFullfilment(CssTransId, bundleRef, (decimal)amount, msisdn);

                if (result != null && result.ErrorCode == 0)
                {
                    await _PaymentFullfillment.UpdatePaymenttransactionsItems(true, item.id, null, true);

                    var newBalanceCurrency = item.Transactioncurrency;
                    if (newBalanceCurrency == "USD")
                    {
                        newBalanceCurrency = "$";
                    }
                    else if (newBalanceCurrency == "GBP")
                    {
                        newBalanceCurrency = "£";
                    }
                    else if (newBalanceCurrency == "EUR")
                    {
                        newBalanceCurrency = "€";
                    }

                    if (PaymentEmailAddress != null && _SmtpConfig.sendEmailToCustomer)
                    {
                        string customerEmailMsg = $"Talkhome App \r\nYou have successfully Topped Up. \r\nTop Up Amount: {newBalanceCurrency}{item.amount}\r\nTransaction Id: {pay360TransactionId}";

                        if (!string.IsNullOrWhiteSpace(item.bundleref))
                        {
                            customerEmailMsg = $"Talkhome App\r\nYou have successfully purchased a bundle. \r\nBundle Name: {result.BundleName} \r\nBundle Amount: {newBalanceCurrency}{item.amount}\r\nTransaction Id: {pay360TransactionId}";
                        }

                        await SendEmailToCustomer(PaymentEmailAddress, customerEmailMsg);
                    }

                }
                else
                {
                    await _PaymentFullfillment.UpdatePaymenttransactionsItems(false, item.id, result.ErrorMessage, false);
                }
            }

        }

        private async Task<bool> SendEmailToCustomer(string customerEmail, string Message, bool IsHtmlBody = false)
        {
            try
            {
                SmtpClient client = new SmtpClient(_SmtpConfig.server);

                if (_SmtpConfig.userName != "" && _SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(_SmtpConfig.userName, _SmtpConfig.password);
                }



                //client.DeliveryMethod = SmtpDeliveryMethod.Network;
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(_SmtpConfig.fromForCustomer);
                mailMessage.To.Add(customerEmail);
                if (IsHtmlBody)
                {
                    mailMessage.IsBodyHtml = IsHtmlBody;
                }
                mailMessage.Body = Message;
                mailMessage.Subject = _SmtpConfig.subjectForCustomer;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Paymentservice, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }

        }

        private async Task SetAutoTopUp(string msisdn, string currency)
        {
            var response = await _pay360Service.GetAutoTopUp(new Pay360GetAutoTopUpRequest()
            {
                Email = "dummy@gmail.com",
                Msisdn = msisdn,
                ProductCode = ProductCode.THA.ToString()
            });

            if (response != null && response.errorCode == 0)
            {
                if (response.payload.Status == false)
                {
#pragma warning disable CS4014
                    _pay360Service.SetAutoTopUp(new Pay360SetAutoTopUpRequest()
                    {
                        isAutoTopup = true,
                        thresholdBalanceAmount = response.payload.ThresHold,
                        topupAmount = (decimal)response.payload.Topup,
                        productCode = ProductCode.THA.ToString(),
                        productItemCode = ProductItemCode.THAATW.ToString(),
                        productRef = msisdn,
                        topupCurrency = currency,
                        Email = "dummy@gmail.com"
                    });
#pragma warning restore CS4014
                }
            }
        }

        private async Task FireAirShipTopupEvents(string msisdn, string Amount, string transactionId, string currency, bool isFirstTopup,
            PaymentType paymentType, string origination, decimal balance)
        {
            try
            {
#pragma warning disable CS4014
                if (_airShipService.IsActive)
                {
                    List<string> tags = new List<string>();

                    var customEventRequest = new CustomEventsRequest()
                    {
                        ProductCode = "THA",
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = msisdn,
                        InteractionType = "url",
                        InteractionId = paymentType == PaymentType.Card ? "Topup/Card" : paymentType == PaymentType.Paypal ? "Topup/Paypal" : "Topup/Voucher"
                    };

                    customEventRequest.Properties = new Dictionary<string, string>
                        {
                            { "Amount", Amount },
                            { "TransactionId", transactionId},
                            { "Currency", currency },
                            { "CurrencySymbol", CommonExtentionMethods.GetCurrencySymbol(currency) },
                            { "Msisdn", msisdn },
                            { "NewBalance", balance.ToString("0.00") },
                            { "OriginationCode", origination },
                            { "OriginationName", GetCountryNameByCountryCode(origination) }
                        };

                    //events    
                    if (isFirstTopup)
                    {
                        tags.Add("user_first_topup");
                        customEventRequest.CustomEventName = "user_first_topup";
                        _airShipService.AddCustomEvent(customEventRequest);
                    }

                    tags.Add("user_last_topup");
                    customEventRequest.CustomEventName = "user_last_topup";
                    _airShipService.AddCustomEvent(customEventRequest);

                    tags.Add("success_topup");
                    customEventRequest.CustomEventName = "success_topup";
                    _airShipService.AddCustomEvent(customEventRequest);

                    tags.Add("any_topup");
                    customEventRequest.CustomEventName = "any_topup";
                    _airShipService.AddCustomEvent(customEventRequest);

                    tags.Add(paymentType == PaymentType.Card ? "cc_buy" : paymentType == PaymentType.Paypal ? "pp_buy" : "voucher_buy");
                    customEventRequest.CustomEventName = paymentType == PaymentType.Card ? "cc_buy" : paymentType == PaymentType.Paypal ? "pp_buy" : "voucher_buy";
                    _airShipService.AddCustomEvent(customEventRequest);

                    var topup__eventName = "topup_" + Convert.ToInt32(Amount) + "";
                    tags.Add(topup__eventName);
                    customEventRequest.CustomEventName = topup__eventName;
                    _airShipService.AddCustomEvent(customEventRequest);

                    //tags
                    if (tags.Count > 0)
                    {
                        _airShipService.AddNamedUserTags(new NamedUserTagsRequest()
                        {
                            NamedUser = msisdn,
                            ProductCode = "THA",
                            TagGroup = _airShipService.PaymentTagGroupName,
                            Tags = tags
                        });
                    }
                }
#pragma warning restore CS4014
            }
            catch
            {
                throw;
            }
        }

        private async Task FireAirShipBundlePurchaseEvents(string msisdn, string Amount, string transactionId, string currency, PaymentType paymentType,
            string bundleName, string origination, string destination,
            decimal balance, bool isFirstBundle = false)
        {
            try
            {
#pragma warning disable CS4014
                if (_airShipService.IsActive)
                {
                    List<string> tags = new List<string>();

                    var customEventRequest = new CustomEventsRequest()
                    {
                        ProductCode = "THA",
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = msisdn,
                        InteractionType = "url",
                        InteractionId = paymentType == PaymentType.Card ? "Bundle/Card" : paymentType == PaymentType.Paypal ? "Bundle/Paypal" : "Bundle/AccountBalance"
                    };

                    customEventRequest.Properties = new Dictionary<string, string>
                        {
                            { "Amount", Amount },
                            { "TransactionId", transactionId},
                            { "Currency", currency },
                            { "CurrencySymbol", CommonExtentionMethods.GetCurrencySymbol(currency) },
                            { "Msisdn", msisdn },
                            { "NewBalance", balance.ToString("0.00") },
                            { "BundleName", bundleName },
                            { "OriginationCode", origination },
                            { "DestinationCode",  destination },
                            { "OriginationName", GetCountryNameByCountryCode(origination) },
                            { "DestinationName",  GetCountryNameByCountryCode(destination) }
                        };

                    //events    
                    if (isFirstBundle)
                    {
                        tags.Add("first_bun");
                        customEventRequest.CustomEventName = "first_bun";
                        _airShipService.AddCustomEvent(customEventRequest);
                    }

                    tags.Add("success_bundle");
                    customEventRequest.CustomEventName = "success_bundle";
                    _airShipService.AddCustomEvent(customEventRequest);

                    tags.Add("last_bun");
                    customEventRequest.CustomEventName = "last_bun";
                    _airShipService.AddCustomEvent(customEventRequest);

                    tags.Add("purchased_payg_bun");
                    customEventRequest.CustomEventName = "purchased_payg_bun";
                    _airShipService.AddCustomEvent(customEventRequest);

                    tags.Add("any_bundle");
                    customEventRequest.CustomEventName = "any_bundle";
                    _airShipService.AddCustomEvent(customEventRequest);

                    var destinationCountryName = GetCountryNameByCountryCode(destination);
                    tags.Add(destinationCountryName + "_bun");
                    customEventRequest.CustomEventName = destinationCountryName + "_bun";
                    _airShipService.AddCustomEvent(customEventRequest);

                    tags.Add(paymentType == PaymentType.Card ? "cc_buy" : paymentType == PaymentType.Paypal ? "pp_buy" : "ab_buy");
                    customEventRequest.CustomEventName = paymentType == PaymentType.Card ? "cc_buy" : paymentType == PaymentType.Paypal ? "pp_buy" : "ab_buy";
                    _airShipService.AddCustomEvent(customEventRequest);

                    //tags
                    if (tags.Count > 0)
                    {
                        _airShipService.AddNamedUserTags(new NamedUserTagsRequest()
                        {
                            NamedUser = msisdn,
                            ProductCode = "THA",
                            TagGroup = _airShipService.PaymentTagGroupName,
                            Tags = tags
                        });
                    }
                }
#pragma warning restore CS4014
            }
            catch
            {
                throw;
            }
        }
    }
}