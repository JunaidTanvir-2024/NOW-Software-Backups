﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Models.Contracts.Service;

namespace TransferHome.Infrastructure.Services.Interfaces
{
    public interface IATTService
    {
        Task<ExecuteDataResponse> Execute(ExecuteDataRequest request);
        Task<GetProductResponse> GetProducts(GetProductRequest request);
    }
}
