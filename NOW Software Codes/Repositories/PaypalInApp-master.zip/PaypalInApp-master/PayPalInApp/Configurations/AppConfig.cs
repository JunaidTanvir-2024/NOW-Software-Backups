﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Configurations
{
    public class AppConfig
    {
        public string PaypalApiEndpoint { get; set; }
        public string AirShipApiEndpoint { get; set; }
        public string Pay360PayPalApiEndpoint { get; set; }
    }
}
