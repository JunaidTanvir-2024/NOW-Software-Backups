﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetAllInternationalRatesResponseModel
    {
        public IEnumerable<InternationalRatesResponseModel> InternationalRatesList { get; set; }
    }
}
