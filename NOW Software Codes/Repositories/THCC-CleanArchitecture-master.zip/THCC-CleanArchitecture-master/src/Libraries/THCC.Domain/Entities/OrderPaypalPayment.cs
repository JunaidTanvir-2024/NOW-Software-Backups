﻿namespace THCC.Domain.Entities
{
    public class OrderPaypalPayment
    {
        public long PaymentId { get; set; }
        public string? PaypalEmail { get; set; }
    }
}
