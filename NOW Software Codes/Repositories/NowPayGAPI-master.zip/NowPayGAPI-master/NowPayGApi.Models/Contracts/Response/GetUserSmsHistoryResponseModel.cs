﻿using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetUserSmsHistoryResponseModel
    {
        public IEnumerable<DBSmsHistory> SmsHistory { get; set; }
        public int SmsHisotryTotalRecords { get; set; }
    }
}
