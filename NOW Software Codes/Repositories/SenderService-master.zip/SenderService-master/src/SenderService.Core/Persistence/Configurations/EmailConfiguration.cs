﻿//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using SenderService.Core.Persistence.Entities;

//namespace SenderService.Core.Persistence.Configurations;

//internal class EmailConfiguration : IEntityTypeConfiguration<Email>
//{
//    public void Configure(EntityTypeBuilder<Email> entity)
//    {
//        entity.HasIndex(e => e.ProductCodeId, "IX_Emails_ProductCode");

//        entity.Property(e => e.AttachmentFilePath).HasMaxLength(1000);
//        entity.Property(e => e.ErrorMessage).HasMaxLength(1000);
//        entity.Property(e => e.FromEmail).HasMaxLength(510);
//        entity.Property(e => e.FromName).HasMaxLength(510);
//        entity.Property(e => e.Subject).HasMaxLength(510);

//        entity.HasOne(d => d.ProductCode).WithMany(p => p.Emails).HasForeignKey(d => d.ProductCodeId);
//    }
//}