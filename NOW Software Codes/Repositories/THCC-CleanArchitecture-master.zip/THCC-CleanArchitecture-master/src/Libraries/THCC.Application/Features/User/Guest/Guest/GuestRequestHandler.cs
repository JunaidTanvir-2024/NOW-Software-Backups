using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.Guest.Guest;

public class GuestRequestHandler : IRequestHandler<GuestRequest, object>
{
    #region Fields

    private readonly IUserService _userService;
    private readonly ILegacyRepository _legacyRepo;
    private readonly IUserRepository _userRepository;
    private readonly IMailService _mailService;

    #endregion

    #region Ctor

    public GuestRequestHandler(
        IUserService userService,
        ILegacyRepository legacyRepository,
        IUserRepository userRepository,
        IMailService mailService)
    {
        _userService = userService;
        _legacyRepo = legacyRepository;
        _userRepository = userRepository;
        _mailService = mailService;
    }

    #endregion

    #region Request Handler

    public async Task<object> Handle(GuestRequest request, CancellationToken cancellationToken)
    {
        request.Email = request.Email.Trim();

        //Check if user exists in new DB
        var user = await _userRepository.GetUserByEmailAsync(request.Email);

        //Check email validation
        var isValidEmail = await _mailService.IsValidEmailAddress(request.Email);
        if (!isValidEmail)
        {
            return ErrorResult.Failure(
                CustomStatusKey.EmailNotSupported, CustomStatusCode.BadRequest);
        }

        var response = new SignUpInfoDto();
        if (user is not null)
        {
            //Send OTP in email
            response = await _userService.SendGuestUserOtp(user.Id);
        }
        else
        {
            //Register this user in new db as Guest
            response = await _userService.SignUpAsync(
               null!,
               null!,
               request.Email,
               null!,
               UserRole.Guest,
               false);
            //As SignUpAsync method not send email for guest customers, that's why sending manually
            response = await _userService.SendGuestUserOtp(response.Id!);
        }
        return !response.IsSuccess ? ErrorResult.Failure(CustomStatusKey.SignUpFailed, CustomStatusCode.BadRequest) : Unit.Value;
    }

    #endregion
}