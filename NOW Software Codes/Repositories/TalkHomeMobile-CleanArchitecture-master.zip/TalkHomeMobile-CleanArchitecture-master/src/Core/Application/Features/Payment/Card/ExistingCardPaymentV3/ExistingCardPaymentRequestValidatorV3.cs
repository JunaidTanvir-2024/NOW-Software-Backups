﻿using Application.Common.Settings;
using Application.Features.Payment.Card.ExistingCardPaymentV2;
using Microsoft.Extensions.Options;

namespace Application.Features.Payment.Card.ExistingCardPaymentV3;
internal class ExistingCardPaymentRequestValidatorV3 : AbstractValidator<ExistingCardPaymentRequestV3>
{
    public ExistingCardPaymentRequestValidatorV3(ICommonService commonService, IOptions<TopupSettings> options)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p!))
            .When(p => p.CreditSimInfo == null || (p.CreditSimInfo != null && p.CreditSimInfo.OrderId <= 0))
            .WithMessage("Invalid msisdn");

        RuleFor(p => p.PaymentCardInfo.CardToken).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MaximumLength(100);
        RuleFor(p => p.PaymentCardInfo.SecurityCode).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(3).MaximumLength(4);

        RuleFor(p => p.TopupInfo).Cascade(CascadeMode.Stop)
           .NotEmpty()
           .NotNull()
           .When(p => p.BundleInfo == null && p.CreditSimInfo == null);

        RuleFor(p => p.BundleInfo).Cascade(CascadeMode.Stop)
           .NotEmpty()
           .NotNull()
           .When(p => p.TopupInfo == null && p.CreditSimInfo == null);

        RuleFor(p => p.CreditSimInfo).Cascade(CascadeMode.Stop)
           .NotEmpty()
           .NotNull()
           .When(p => p.BundleInfo == null && p.TopupInfo == null);

        RuleFor(p => p.TopupInfo!.TopupAmount).Cascade(CascadeMode.Stop)
            .NotEmpty()
        .NotNull()
            .Must(p => options.Value.TopUpAmounts.Contains(p))
            .When(p => p.TopupInfo != null)
            .WithMessage("Invalid topup amount");

        RuleFor(p => p.TopupInfo!.AutoTopupInfo).Cascade(CascadeMode.Stop)
            .NotEmpty()
        .NotNull()
            //.Must(p => options.Value.AutoTopupThresholdAmounts.Contains(p!.ThresHoldAmount)).WithMessage("Invalid threshold amount")
            .Must(p => options.Value.TopUpAmounts.Contains(p!.TopupAmount)).WithMessage("Invalid auto top-up amount")
            .When(p => p.TopupInfo != null && p.TopupInfo.AutoTopupInfo != null);

        RuleFor(p => p.BundleInfo).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => p!.BundleId > 0).WithMessage("Invalid bundle reference")
            .When(p => p.BundleInfo != null);

        RuleFor(p => p.CreditSimInfo).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => p!.OrderId > 0).WithMessage("Invalid credit sim reference")
            .When(p => p.CreditSimInfo != null);
    }
}