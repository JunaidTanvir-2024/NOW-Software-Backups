﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.PaypalApiContracts
{
    public class PayPalByPay360CSPaymentResponse
    {
        public string customerId { get; set; }
        public string transactionId { get; set; }
        public string transactionAmount { get; set; }
        public PayPalByPay360CSOutcome outcome { get; set; }
        public string clientRedirectUrl { get; set; }
        public string checkoutToken { get; set; }
    }

    public class PayPalByPay360CSOutcome
    {
        public string status { get; set; }
        public string reasonCode { get; set; }
        public string reasonMessage { get; set; }
    }
}
