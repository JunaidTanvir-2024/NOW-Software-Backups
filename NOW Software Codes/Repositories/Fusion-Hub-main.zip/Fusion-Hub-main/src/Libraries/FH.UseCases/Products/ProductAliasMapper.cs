using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;
using FH.UseCases.Exports;

using FluentValidation;

using Mediator;

using Microsoft.AspNetCore.Http;

using RW;

namespace FH.UseCases.Products;
public sealed class ProductAliasMapper
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public required IFormFile CsvFile { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator() { }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var csvData = request.CsvFile.CsvFileToJson<IEnumerable<ProductAliasFile.Response>>();

            var productsAliasUpdate = csvData?.Select(x => new ProductAliasDto.Request()
            {
                ProductId = x.ProductId,
                ProductNameAlias = x.ProductAliasName ?? string.Empty,
                ProductDescription = x.ProductDescription ?? string.Empty
            });

            if (productsAliasUpdate is null)
            {
                return ResultWrapper.Failure("fail to update Operator aliases", AppConstants.StatusCode.BadRequest);
            };
            await _unitOfWork.ProductRepository.UpdateProductsAliases(productsAliasUpdate);

            return ResultWrapper.Success("Product aliases updated successfully", AppConstants.StatusCode.Success);
        }
    }
    #endregion
}
