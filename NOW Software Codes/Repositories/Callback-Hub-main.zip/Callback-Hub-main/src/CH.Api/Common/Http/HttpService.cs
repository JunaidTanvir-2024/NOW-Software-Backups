using System.Diagnostics;
using System.Text;
using System.Text.Json;

using CH.Api.Common.Definitions;
using CH.Api.Common.Repositories;
using CH.Api.Common.Repositories.DTOs;

namespace CH.Api.Common.Http;

internal sealed class HttpService(IHttpClientFactory httpClientFactory, ILoggerRepository loggerRepository, IHttpContextAccessor httpContextAccessor) : IHttpService
{
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly ILoggerRepository _loggerRepository = loggerRepository;
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;
    private const string CORRELATION_ID = "Correlation_Id";
    private Uri? _baseUrl;
    private int _vendorId;
    private Dictionary<string, string> _headers = [];
    IHttpService IHttpService.BaseUrl(string baseUrl)
    {
        _baseUrl = new Uri(baseUrl);
        return this;
    }
    IHttpService IHttpService.WithHeaders(Dictionary<string, string> headers)
    {
        _headers = headers;
        return this;
    }
    IHttpService IHttpService.SetVendor(AppEnums.Vendor vendor)
    {
        _vendorId = (int)vendor;
        return this;
    }
    public async Task<(bool IsFailure, string Json)> PostAsync(string requestUri, object? data = default)
    {
        return await SendRequestAsync(HttpMethod.Post, requestUri, CreateJsonContent(data));
    }

    private async Task<(bool IsFailure, string Json)> SendRequestAsync(HttpMethod method, string requestUri, HttpContent? content = null)
    {
        var client = _httpClientFactory.CreateClient();
        var apiUrl = $"{_baseUrl}{requestUri}";
        var stopwatch = Stopwatch.StartNew();
        var request = new HttpRequestMessage(method, apiUrl);

        if (_headers.Count > 0)
        {
            foreach (var header in _headers)
            {
                client.DefaultRequestHeaders.Add(header.Key, header.Value);
            }
        }

        if (content is not null)
        {
            request.Content = content;
        }

        return await SendAndLogHttpRequest(stopwatch, client, request);
    }

    private async Task<(bool IsFailure, string Json)> SendAndLogHttpRequest(Stopwatch stopwatch, HttpClient client, HttpRequestMessage? request)
    {
        var (responseBody, statusCode, isFailure, exception) = await SendHttpRequest(client, request);

        await LogHttpRequest(stopwatch, request, responseBody, statusCode, exception);

        return new() { IsFailure = isFailure, Json = responseBody! };
    }
    private async Task<(string responseBody, int statusCode, bool isFailure, Exception? exception)> SendHttpRequest(HttpClient client, HttpRequestMessage? request)
    {
        string responseBody = default!;
        int statusCode = default;

        try
        {
            var httpResponseMessage = await client.SendAsync(request!);
            responseBody = await httpResponseMessage.Content.ReadAsStringAsync();
            statusCode = (int)httpResponseMessage.StatusCode;

            return (responseBody, statusCode, !httpResponseMessage.IsSuccessStatusCode, null);
        }
        catch (Exception ex)
        {
            return (responseBody, statusCode, false, ex);
        }
    }
    private async Task LogHttpRequest(Stopwatch stopwatch, HttpRequestMessage? request, string responseBody, int statusCode, Exception? ex = null)
    {
        var requestBody = request?.Content is not null ? await request.Content.ReadAsStringAsync() : string.Empty;

        if (ex is null)
        {
            await InsertVendorLogs(stopwatch, request, statusCode, responseBody, requestBody, Encoding.UTF8.GetByteCount(responseBody), string.Empty);
        }
        else
        {
            await InsertVendorLogs(stopwatch, request, AppConstants.StatusCodes.InternalServerError, string.Empty, requestBody, 0, ex?.StackTrace?.ToString());
        }
    }

    private static StringContent CreateJsonContent(object? data)
    {
        var json = JsonSerializer.Serialize(data);
        return new StringContent(json, Encoding.UTF8, AppConstants.ContentTypes.ApplicationJson);
    }
    private async Task InsertVendorLogs(Stopwatch stopwatch, HttpRequestMessage? request, int statusCode, string? responseBody, string? requestBody, int responseSize, string? stackTraceError)
    {
        var logEntry = new VendorLogDto
        {
            CorrelationId = _httpContextAccessor.HttpContext?.Items[CORRELATION_ID]?.ToString()!,
            Timestamp = DateTime.UtcNow,
            RequestPath = request?.RequestUri?.ToString(),
            RequestBody = requestBody,
            ResponseBody = responseBody,
            StatusCode = statusCode,
            Duration = stopwatch.ElapsedMilliseconds,
            Headers = JsonSerializer.Serialize(request?.Headers),
            QueryString = request?.RequestUri?.Query,
            ErrorReason = stackTraceError,
            ResponseSize = responseSize,
            RequestMethod = request?.Method.ToString(),
            VendorId = _vendorId,
        };

        await _loggerRepository.VendorLogInsertAsync(logEntry);
    }
}
