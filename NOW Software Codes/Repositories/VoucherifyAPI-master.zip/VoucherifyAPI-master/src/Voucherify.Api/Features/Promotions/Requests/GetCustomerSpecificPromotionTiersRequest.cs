using FluentValidation;

using Voucherify.Api.Features.Promotions.Common;
using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Promotions.Requests;

public class GetCustomerSpecificPromotionTiersRequest
{
    public PromotionTierCustomerInfo Customer { get; set; } = null!;
    public PromotionTierOrderInfo Order { get; set; } = null!;
    public Metadata? ValidationMetadata { get; set; } = null!;
}

internal class GetCustomerSpecificPromotionTiersRequestValidator : AbstractValidator<GetCustomerSpecificPromotionTiersRequest>
{
    public GetCustomerSpecificPromotionTiersRequestValidator()
    {
        RuleFor(p => p.Customer.SourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.Customer.SourceId = phoneNumber);
    }
}
