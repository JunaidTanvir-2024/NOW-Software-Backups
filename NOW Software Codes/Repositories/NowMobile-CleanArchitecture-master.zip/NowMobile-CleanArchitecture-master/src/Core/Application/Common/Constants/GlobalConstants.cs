﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Constants;
public static class GlobalConstants
{
    public static class ContentType
    {
        public const string ApplicationJson = "application/json";
        public const string ApplicationOctetStream = "application/octet-stream";
        public const string ApplicationXml = "application/xml";
    }

    public static class AuthType
    {
        public const string Basic = "Basic";
        public const string Jwt = "Bearer";
    }
    public static class EmailServiceEndpoints
    {
        public const string Email = "Email";
        public const string EmailValidation = "Email/Validation";
    }
}
