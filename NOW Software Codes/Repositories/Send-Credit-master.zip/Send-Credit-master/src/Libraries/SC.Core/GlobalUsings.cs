﻿global using Microsoft.Extensions.Configuration;
global using Microsoft.Extensions.DependencyInjection;
global using System.Reflection;
global using SC.Core.Common.DTOs;
global using FluentValidation;
global using MediatR;
global using RW;
global using SC.Core.Common.Behaviors;
global using System.Security.Claims;
global using System.Security.Cryptography;
global using SC.Core.Common.Interfaces.Services.Models;
global using static SC.Core.Common.Definitions.Constants.AppEnums;
global using SC.Core.Common.Definitions.Constants;
global using System.Runtime.InteropServices;
global using System.Security;
global using System.Text;
global using SC.Core.Models.Dtos;
global using SC.Core.Interfaces.Repositories;
global using SC.Core.Features.Users.Requests;
global using SC.Core.Common.Definitions.Utilities;
global using SC.Core.Common.Helpers;


