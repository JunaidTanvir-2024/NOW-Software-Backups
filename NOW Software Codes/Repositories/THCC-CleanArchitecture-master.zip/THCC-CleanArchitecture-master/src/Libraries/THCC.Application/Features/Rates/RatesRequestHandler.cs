using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Rates;

public class InternationalRatesAgainstIsoCodeRequestHandler : IRequestHandler<RatesRequest, object>
{
    #region Fields

    private readonly IRatesRepository _ratesRepository;
    private readonly IMapper _mapper;

    #endregion

    #region Ctors
    public InternationalRatesAgainstIsoCodeRequestHandler(
        IRatesRepository ratesRepository,
        IMapper mapper)
    {
        _ratesRepository = ratesRepository;
        _mapper = mapper;
    }

    #endregion

    #region Methods
    public async Task<object> Handle(RatesRequest request, CancellationToken cancellationToken)
    {
        var rates = await _ratesRepository.GetRates();
        return rates != null ? _mapper.Map<IList<RatesDto>>(rates!) :
            ErrorResult.Failure(
                CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
    }

    #endregion
}