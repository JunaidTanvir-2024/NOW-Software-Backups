using JM.Core.Utilities.Interfaces.Services;

namespace JM.Infrastructure.Services.TimeWarp;

internal sealed class TimeWarpService : ITimeWarpService
{
    public DateTime UtcNow => DateTime.UtcNow;
}
