﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Loyalties.Requests
{
    public class GetLoyaltiesRequest
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
