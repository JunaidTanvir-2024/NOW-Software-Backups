﻿namespace SC.Core.Common.Definitions.Constants;
public static partial class AppConstants
{
    public static class StatusKeys
    {
        public const string Success = "Congratulations! Your request was fulfilled successfully.";
        public const string SuccessTokenVerification = "Congratulations! Your Token Verified successfully.";
        public const string SuccessPasswordReset = "Congratulations! Your Password updated successfully.";
        public const string InvalidToken = "Invalid or Expired Token Please try again with a valid token.";
        public const string EmailExist = "Email Already Exists.";
        public const string EmailNotFound = "Invalid Email Address";
        public const string InvalidEmailFormat = "Please provide a valid email address";
        public const string EmailOrPasswordInvalid = "Email Or Password is invalid.";
        public const string CommonFailureMessage = "No Record Found.";
        public const string GuestUserCreationError = "Guest User not created";
        public const string ProductCommonFailureMessage = "No Product Found.";
        public const string PurchaseInventoryFailure = "Purchase Inventory Failed due to : ";
        public const string PurchaseInventoryFailed = "Purchase Inventory Failed ";
        public const string UserLocked = "User Account is locked, please retry after few minutes.";
        public const string EmailVerificationRequired = "A 6 digit verification code send on your email, please verify it.";
        public const string BadRequest = "Whoops! Something went wrong with your request. Please try again.";
        public const string Forbidden = "Sorry, you don't have permission to access this resource.";
        public const string NotFound = "Hmmm, we couldn't find what you're looking for.";
        public const string Unauthorized = "Oops! You need to be authorized to access this resource.";
        public const string InternalServerError = "Whoops! Something went wrong on our end. Please try again later.";
        public const string CommonPaymentError = "Order Payment Failed.";
        public const string CommonCustomerOrderError = "Incomplate Customer Order, Please try again with a valid customer order";
        public const string InvalidTransactionID = "Order Does not exist, agaisnt provided transaction ID";
        public const string OrderSuccessCheckout = "order processed successfully";
        public const string OrderCreationError = "Order Creation failed";
        public const string UserNotProvided = "User Is not Provided";
        public const string MaximumAllowedGiftCard = "System does not allow to purchase gift card more than {0} value";
        public const string MaximumAllowedMobileTopup = "System does not allow to mobile top up more than {0} value";
        public const string ProductRepeatedInOrder = "System does not allow to add product in cart more than {0} times";
        public const string PerOrderMaxValue = "System does not allow to create order more than {0} value";
        public const string PerOrderMaxValuePerDay = "System does not allow to create order more than {0} value per day";
        // Token
        public const string JwtTokenMissing = "Uh oh! Token is missing. Please try again with a valid token.";
        public const string JwtTokenExpired = "Whoops! Your token has expired. Please request a new one.";
        public const string JwtTokenInvalid = "Whoops! Your authorization token is invalid. Please try again with a valid token.";
        public const string EmailBody = "Your Send Credit Email verification Code is : ";
        public const string EmailSubject = "Send Credit Email verification";

        //Purchase type
        public const string IncompleteOrder = "Incomplete Customer Order";
        public const string wrongProductType = "Wrong Product Type, it's should be  airtime, bundle ,gift card & data";
        public const string InvalidProductInCart = "Customer Order has some Invalid product, please remove this product from cart";
    }
}



