﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.Web.Administration;

using Myrmec;

using Serilog;

using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Application.Settings;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Infrastructure.Services;
public class FileService : IFileService
{
    private readonly FileUploadSettings _fileSettings;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger _logger;

    public FileService(
        IOptions<FileUploadSettings> fileSettings,
        IHttpClientFactory httpClientFactory,
        ILogger logger
        )
    {
        _fileSettings = fileSettings.Value;
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }

    #region File Methods
    /// <summary>
    /// Async file upload function which will save the file in the directory that you provide.
    /// </summary>
    /// <param name="file"></param>
    /// <param name="path"></param>
    /// <returns>fileName, errorMessage</returns>
#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
    public async Task<(string fileName, bool isSuccess, string errorMessage)> FileUploaderAsync(IFormFile file, string path)
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously
    {
        var fileName = string.Empty;
        var errorMessage = string.Empty;
        var isSuccess = false;

        var directoryPath = PathNormalizer(path);
        try
        {
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }
        }
        catch (Exception ex)
        {
            _logger.Error(
                        "Class:FileService," +
                        "Method:FileUploaderAsync," +
                        "Failied Uploading Image with error: " +
                        $"{ex.Message}");
        }
        string extensionName = Path.GetExtension(file.FileName);
        fileName = Guid.NewGuid().ToString() + extensionName;
        var fileSavePath = Path.Combine(directoryPath, fileName);
        fileSavePath = PathNormalizer(fileSavePath);
        try
        {
            Stream strm = file.OpenReadStream();
            CompressImage(strm, fileSavePath);
            isSuccess = true;

            //using (var stream = new FileStream(fileSavePath, FileMode.Create))
            //{
            //    await file.CopyToAsync(stream);
            //    isSuccess = true;
            //}
            DirectoryInfo di = new DirectoryInfo(directoryPath);
            foreach (FileInfo item in di.GetFiles())
            {
                if (item.Name != fileName)
                {
                    item.Delete();
                }
            }

        }
        catch (Exception ex)
        {
            _logger.Error(
                         "Class:FileService," +
                         "Method:FileUploaderAsync," +
                         "Failied Uploading Image with error: " +
                         $"{ex.Message}");
        }
        return (fileName, isSuccess, errorMessage);
    }

    /// <summary>
    /// Path Normalizer which will trim and add double (//) slashes to the path
    /// </summary>
    /// <param name="path"></param>
    /// <returns>Normalize Path (String)</returns>
    public string PathNormalizer(string path)
    {
        return Path.GetFullPath(new Uri(path).LocalPath)
                   .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
    }

    #endregion

    #region Virtual Directory

    public ServerDirectoriesModel GetVirtualDirectoriesBySite(string siteName = "THCC")
    {
        // I am hardcoding website name. We can define it in appsetting as well via IOption pattern
        var talkHomeSite = GetServerSiteByName(siteName);

        var directories = new ServerDirectoriesModel();
        foreach (Microsoft.Web.Administration.Application app in talkHomeSite.Applications)
        {
            Console.WriteLine($"Applications Path is {app.Path}");

            if (app?.Path.Equals("/", StringComparison.InvariantCultureIgnoreCase) == false)
            {
                // Add domain name
                directories.DomainName = talkHomeSite.Bindings.Select(x => new Uri($"{x.Protocol}://{x.Host}{app.Path}")).FirstOrDefault();
            }
            if (app?.VirtualDirectories.Count > 0)
            {
                foreach (VirtualDirectory vdir in app.VirtualDirectories)
                {
                    if (!vdir.Path.Equals("/", StringComparison.InvariantCultureIgnoreCase))
                    {
                        directories.DomainPath.Add(new DomainPath() { PhysicalPath = vdir.PhysicalPath, VirtualPath = vdir.Path });
                    }
                }
            }
        }
        return directories;
    }
    public string? VirtualPathGenerator(string fileName, string virtualDirectoryName, string siteName = "THCC")
    {
        //var talkHomeSite = GetServerSiteByName(siteName);
        //var filePath = talkHomeSite.Bindings.Select(x => new Uri($"{x.Protocol}://{x.Host}{talkHomeSite.Applications.First().Path}{virtualDirectoryName}/{fileName}")).FirstOrDefault();
        //var hostName = talkHomeSite.Bindings.Select(x => !string.IsNullOrEmpty(x.Host) ? x.Host : "localhost").First();
        //var filePath = talkHomeSite.Bindings.Select(x => new Uri($"{x.Protocol}://{hostName}{talkHomeSite.Applications.First().Path}")).FirstOrDefault();
        //return Convert.ToString(filePath);
        return $"{virtualDirectoryName}/{fileName}";
    }
    private static Site GetServerSiteByName(string siteName = "THCC")
    {
        return new ServerManager().Sites[siteName];
    }
    #endregion

    #region File Size Validator
    public bool FileSizeValidator(IFormFile file)
    {
        var maxFileSize = _fileSettings.FileSizeInBytes;
        return file is null || file.Length <= maxFileSize;
    }
    #endregion

    #region File Extension Validator
    public bool FileExtensionValidator(IFormFile file)
    {
        var supportedFiles = new List<Record>();

        foreach (var fileExtension in _fileSettings.SupportedExtensions)
        {
            var result = SupportedFileTypes.FileTypeSupported().Where(x => x.FileTypeName.Equals(fileExtension, StringComparison.CurrentCultureIgnoreCase));
            foreach (var item in result)
            {
                supportedFiles.Add(new Record(item.FileHeaderValue, item.FileTypeName));
            }
        }
        var sniffer = new Sniffer();
        sniffer.Populate(supportedFiles);

        using var fs = new BinaryReader(file.OpenReadStream());
        var bytes = new byte[20];
        fs.Read(bytes, 0, 20);

        byte[] fileHead = bytes;
        var matchHeaderTypes = sniffer.Match(fileHead);
        return matchHeaderTypes.Count > 0;
    }
    #endregion

    #region File Compress
#pragma warning disable CA1416 // Validate platform compatibility
    private void CompressImage(Stream srcImgStream, string targetPath)
    {
        try
        {
            // Convert stream to image
            using var image = Image.FromStream(srcImgStream);

            float maxHeight = 900.0f;
            float maxWidth = 900.0f;
            int newWidth;
            int newHeight;

            var originalBMP = new Bitmap(srcImgStream);
            int originalWidth = originalBMP.Width;
            int originalHeight = originalBMP.Height;

            if (originalWidth > maxWidth || originalHeight > maxHeight)
            {
                // To preserve the aspect ratio  
                float ratioX = (float)maxWidth / (float)originalWidth;
                float ratioY = (float)maxHeight / (float)originalHeight;
                float ratio = Math.Min(ratioX, ratioY);
                newWidth = (int)(originalWidth * ratio);
                newHeight = (int)(originalHeight * ratio);
            }
            else
            {
                newWidth = (int)originalWidth;
                newHeight = (int)originalHeight;
            }


            var bitmap = new Bitmap(originalBMP, newWidth, newHeight);
            var imgGraph = Graphics.FromImage(bitmap);
            imgGraph.SmoothingMode = SmoothingMode.Default;
            imgGraph.InterpolationMode = InterpolationMode.HighQualityBicubic;
            imgGraph.DrawImage(originalBMP, 0, 0, newWidth, newHeight);

            var extension = Path.GetExtension(targetPath).ToLower();
            // for file extension having png and gif
            if (extension == ".png" || extension == ".gif")
            {
                // Save image to targetPath
                bitmap.Save(targetPath, image.RawFormat);
            }
            // for file extension having .jpg or .jpeg
            else if (extension == ".jpg" || extension == ".jpeg")
            {
                ImageCodecInfo jpgEncoder = GetEncoder(ImageFormat.Jpeg);
                System.Drawing.Imaging.Encoder myEncoder = System.Drawing.Imaging.Encoder.Quality;
                var encoderParameters = new EncoderParameters(1);
                var parameter = new EncoderParameter(myEncoder, 50L);
                encoderParameters.Param[0] = parameter;

                // Save image to targetPath
                bitmap.Save(targetPath, jpgEncoder, encoderParameters);
            }

            bitmap.Dispose();
            imgGraph.Dispose();
            originalBMP.Dispose();

        }
        catch (Exception ex)
        {
            _logger.Error("FileService," + " Method:CompressImage " + $"{targetPath} - {ex.Message}");
        }
    }

    private ImageCodecInfo GetEncoder(ImageFormat format)
    {
        ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
        foreach (ImageCodecInfo codec in codecs)
        {
            if (codec.FormatID == format.Guid)
            {
                return codec;
            }
        }
        return null!;
    }
#pragma warning restore CA1416 // Validate platform compatibility
    #endregion


    #region Download Image using url
    public async Task<string> DownloadImageAsync(string imageUrl, string userId, string SiteName, string virtualDirectoryName)
    {
        var httpClient = _httpClientFactory.CreateClient();
        string fileName = "";
        try
        {
            using (var response = await httpClient.GetAsync(imageUrl))
            {
                response.EnsureSuccessStatusCode();
                string extension = GetImageExtension(response);
                fileName = Guid.NewGuid().ToString() + extension;
                var virtualDirectories = GetVirtualDirectoriesBySite(SiteName);
                foreach (var domainPath in virtualDirectories!.DomainPath!.Where
                (domainPath => domainPath.VirtualPath!.Equals
                (virtualDirectoryName, StringComparison.InvariantCultureIgnoreCase)))
                {
                    var directoryPath = PathNormalizer($"{domainPath.PhysicalPath}/{userId}");
                    if (!Directory.Exists(directoryPath))
                    {
                        Directory.CreateDirectory(directoryPath);
                    }
                    var fileSavePath = Path.Combine(directoryPath, fileName);
                    fileSavePath = PathNormalizer(fileSavePath);
                    using var stream = await response.Content.ReadAsStreamAsync();
                    using var fileStream = File.Create(fileSavePath);
                    await stream.CopyToAsync(fileStream);
                }
            }
            return fileName;
        }
        catch (Exception ex)
        {
            _logger.Error("Class:FileService," +
                           "Method:DownloadImageAsync," +
                           $"Failied Uploading Image with error:{ex.Message}");
            return null!;
        }
    }
    private string GetImageExtension(HttpResponseMessage response)
    {
        if (response.Content.Headers.TryGetValues("Content-Type", out var contentTypes))
        {
            foreach (var contentType in contentTypes)
            {
                if (contentType.StartsWith("image/"))
                {
                    switch (contentType)
                    {
                        case "image/jpeg":
                            return ".jpg";
                        case "image/png":
                            return ".png";
                            // Add more cases as needed for other image formats
                    }
                }
            }
        }

        // If the image format is not recognized, you can return a default extension like ".jpg" or handle it as per your requirements
        return ".jpg";
    }

    #endregion

}