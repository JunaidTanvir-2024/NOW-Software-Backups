using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Orders;

public class OrderCreate
{
    [JsonPropertyName("source_id")]
    public string? SourceId { get; set; }

    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("amount")]
    public long? Amount { get; set; }

    [JsonPropertyName("items")]
    public List<OrderItem>? Items { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    [JsonPropertyName("customer")]
    public Customer? Customer { get; set; }
}
