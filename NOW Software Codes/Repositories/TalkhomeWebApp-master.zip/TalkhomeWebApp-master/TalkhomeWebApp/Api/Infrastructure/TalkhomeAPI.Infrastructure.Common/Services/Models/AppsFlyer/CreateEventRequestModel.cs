﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.AppsFlyer
{
    public class CreateEventRequestModel
    {
        public string customerUserId { get; set; }
        public string ip { get; set; }
        public string eventName { get; set; }
        public string eventRevenenuCurrency { get; set; }
        public decimal eventRevenue { get; set; }
        public object eventValue { get; set; }
        public string productCode { get; set; } = "THA-WEB-API";
    }
}
