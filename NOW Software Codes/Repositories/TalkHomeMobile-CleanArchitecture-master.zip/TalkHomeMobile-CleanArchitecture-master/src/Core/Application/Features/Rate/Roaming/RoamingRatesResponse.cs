﻿using Application.Features.Bundle.Model;
using Application.Features.Rate.Model;

namespace Application.Features.Rate.Roaming;

public class RoamingRatesResponse
{
    public RoamingRate? Rate { get; set; }
    public List<BundleInfo>? Bundles { get; set; }
    public bool IsEU { get; set; } = false;
}