using Asp.Versioning;

using FH.Api.Controllers.Common;
using FH.UseCases.Cart;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.V1;

[ApiVersion(1.0)]
public sealed class CartController : BaseApiController
{
    [HttpPost("topup")]
    public async Task<ActionResult> BuyTopup([FromBody] BuyTopup.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);
    }
    [HttpPost("bundle")]
    public async Task<ActionResult> BuyBundle([FromBody] BuyBundle.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);
    }
    [HttpPost("data")]
    public async Task<ActionResult> BuyInternetData([FromBody] BuyInternetData.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);
    }
    [HttpPost("bulk")]
    public async Task<ActionResult> BuyItemsBulk([FromBody] BulkPurchase.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);
    }
    [HttpPost("giftcard")]
    public async Task<ActionResult> BuyGiftCard([FromBody] BuyGiftCard.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);
    }
}
