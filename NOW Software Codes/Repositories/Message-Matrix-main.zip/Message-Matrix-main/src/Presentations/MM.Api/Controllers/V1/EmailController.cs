using Microsoft.AspNetCore.Authorization;
using MM.Core.Features.Email.Request;

namespace MM.Api.Controllers.V1;
public class EmailController :  BaseApiController
{
    [HttpPost, AllowAnonymous]
public async Task<ActionResult> SendEmail(SendEmailRequest request)
{
    var result = await Mediator.Send(request);
    if (result.IsSuccess)
    {
        return Ok(result);
    }
    return NotFound(result);
}
}
