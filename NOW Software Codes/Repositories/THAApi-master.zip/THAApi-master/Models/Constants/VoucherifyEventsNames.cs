﻿namespace Models.Constants
{
    public static class VoucherifyEventsNames
	{
        public const string Signup = "Signup_Event";
        
        public const string WelcomeBundle = "Welcome_Bundle_Event";
        public const string PayGBundle = "PayG_Bundle_Event";
        public const string PayGBundleAutoRenew = "Auto_Renew_PayG_Bundle_Event";
        
        public const string Topup = "Topup_Event";
        
        public const string AutoRecharge = "Auto_Recharge_Event";
        public const string FirstAutoRecharge = "First_Auto_Recharge_Event";

        public const string SuccessPointsReferee = "Success_Points_Referee";
        public const string SuccessPointsReferrer = "Success_Points_Referrer";
        public const string ProfileComplete = "Profile_Complete_Event";

        public const string InternationalTopup = "international_topup_event_{0}_points";
    }
}
