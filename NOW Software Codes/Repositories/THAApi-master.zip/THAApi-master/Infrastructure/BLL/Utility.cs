﻿using Models.Configurations;
using Models.Contracts.Request.Voucherify;
using Models.Enums;
using Models.Services.Airship;
using System;
using System.Linq;
using static Models.Configurations.VoucherifyConfig.LoyaltyEarningRulesInfo;

namespace Infrastructure.BLL
{
    public class Utility
    {
        public static int CalculateInternationalTopupRewardPointsRange(decimal amountInGBP, InternationalLoyalty[] loyalty)
        {
            var result = loyalty.FirstOrDefault(loyaltyTier => loyaltyTier.Min <= amountInGBP && (loyaltyTier.Max == -1 || amountInGBP <= loyaltyTier.Max));
            
            return result?.Points ?? 0;
        }

        public static int CalculateTopupRewardPoints(decimal topupAmount, VoucherifyConfig voucherifyConfig)
        {
            // Calculate the number of times the base value can be added with the top-up amount
            int numberOfTimes = (int)topupAmount / voucherifyConfig.LoyaltyEarningRules.Topup.BaseValue;

            // Calculate the total points per base value
            var totalPoints = numberOfTimes * voucherifyConfig.LoyaltyEarningRules.Topup.BasePoints;
            return totalPoints;
        }

        public static VoucherifyAirshipInfo GetVoucherifyInfo(string campaignName, CheckOutTypes type, DiscountCodeType discountCodeType, bool? isFirstInternationalTopup = false, int? internationalTopupPoints = 0, bool? isFirstTopup = false, int? topupPoints = 0, bool? isWelcomeBundle = false, int? bundlePoints = 0, bool? isRedeemedSuccess = false)
        {
            return new VoucherifyAirshipInfo()
            {
                InternationalTopup = type == CheckOutTypes.Transfer ? new VoucherifyAirshipInfo.InternationalTopupInfo()
                {
                    IsFirst = isFirstInternationalTopup != null && isFirstInternationalTopup == true ? true : false,
                    Points = internationalTopupPoints != null ? internationalTopupPoints : 0,
                } : null,

                Topup = type == CheckOutTypes.TopUp ? new VoucherifyAirshipInfo.TopupInfo()
                {
                    IsFirst = isFirstTopup != null && isFirstTopup == true ? true : false,
                    Points = topupPoints != null ? topupPoints : 0
                } : null,

                Bundle = type == CheckOutTypes.Bundle ? new VoucherifyAirshipInfo.BundleInfo()
                {
                    IsWelcome = isWelcomeBundle != null && isWelcomeBundle == true ? true : false,
                    Points = bundlePoints != null ? bundlePoints : 0,
                } : null,

                Referral = discountCodeType == DiscountCodeType.Referral ? new VoucherifyAirshipInfo.ReferralInfo()
                {
                    IsReferredUser = isRedeemedSuccess != null && isRedeemedSuccess == true ? true : false
                } : null,

                Coupon = discountCodeType == DiscountCodeType.Voucher ? new VoucherifyAirshipInfo.CouponInfo()
                {
                    Status = isRedeemedSuccess != null && isRedeemedSuccess == true ? true : false,
                    CampaignName = string.IsNullOrEmpty(campaignName) ? string.Empty : campaignName,
                } : null,

                DirectPromotion = discountCodeType == DiscountCodeType.Promotion_Tier ? new VoucherifyAirshipInfo.DirectPromotionInfo()
                {
                    Status = isRedeemedSuccess != null && isRedeemedSuccess == true ? true : false
                } : null
            };
        }
        public static string CreateBasicHeader(string Username, string Password)
        {
            return Convert.ToBase64String(
                                System.Text.ASCIIEncoding.ASCII.GetBytes(
                                    string.Format("{0}:{1}", Username, Password)));
        }

        public static string ConvertMicrosoftJsonDate(string microsoftJsonDate)
        {
            // Orignal Date Format = "/Date(1563580800000+0100)/"

            try
            {
                if (!string.IsNullOrWhiteSpace(microsoftJsonDate))
                {
                    if (microsoftJsonDate.Contains("/Date("))
                    {
                        DateTime initialDate = new DateTime(1970, 1, 1);
                        microsoftJsonDate = microsoftJsonDate.Replace("/Date(", "").Split(new char[] { '+' })[0];
                        double dateMilliseconds = Convert.ToDouble(microsoftJsonDate);
                        string returndate = initialDate.AddMilliseconds(dateMilliseconds).ToString("dd-MMM-yyyy HH:mm:ss");
                        return returndate;
                    }
                    else
                    {
                        return microsoftJsonDate;
                    }
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }

        }



        public static string GetJsonObjectValueByKey(string key, string jsonData)
        {
            string result = "An error occured.";
            try
            {
                // reasonMessage
                key = "\"" + key + "\"";
                int startIndex = jsonData.IndexOf(key);
                if (startIndex != -1)
                {
                    startIndex = startIndex + key.Length;
                    startIndex = jsonData.IndexOf("\"", startIndex);
                    if (startIndex != -1)
                    {
                        int endIndex = jsonData.IndexOf("\"", startIndex + 1);
                        if (endIndex != -1)
                        {
                            result = jsonData.Substring(startIndex + 1, endIndex - startIndex - 1);
                        }
                    }
                }
                else // key does not exists in jsonData
                {

                }
            }
            catch (Exception)
            {

                throw;
            }
            return result;
        }

    }


}
