﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models
{
    public class Country
    {
        public int Id { get; set; } //(int, not null)
        public string Name { get; set; } //(varchar(50), not null)
        public string Code { get; set; } //(varchar(50), not null)
        public string CountryAbbr { get; set; }
        public bool IsNational { get; set; } //(bit, not null)
    }
}