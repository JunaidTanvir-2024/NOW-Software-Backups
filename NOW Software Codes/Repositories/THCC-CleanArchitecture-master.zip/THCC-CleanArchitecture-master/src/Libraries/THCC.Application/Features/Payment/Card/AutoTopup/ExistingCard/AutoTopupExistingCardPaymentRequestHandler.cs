﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

namespace THCC.Application.Features.Payment.Card.AutoTopup.ExistingCard
{
    public class AutoTopupExistingCardPaymentRequestHandler
        : IRequestHandler<AutoTopupExistingCardPaymentRequest, object>
    {
        #region Fields 

        private readonly IPaymentService _paymentService;
        private readonly ICurrentUser _currentUser;
        private readonly IUserRepository _userRepository;
        private readonly Pay360Setting _pay360Settings;

        #endregion

        #region Ctors

        public AutoTopupExistingCardPaymentRequestHandler(
            IPaymentService paymentService,
            ICurrentUser currentUser,
            IUserRepository userRepository,
            IOptions<Pay360Setting> options)
        {
            _paymentService = paymentService;
            _currentUser = currentUser;
            _userRepository = userRepository;
            _pay360Settings = options.Value;
        }

        #endregion

        #region Methods

        public async Task<object> Handle(AutoTopupExistingCardPaymentRequest request, CancellationToken cancellationToken)
        {
            var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
            if (userProduct == null)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
            }

            #region Trim Request

            request.PaymentCardInfo.CardToken = request.PaymentCardInfo.CardToken.Trim();
            request.PaymentCardInfo.SecurityCode = request.PaymentCardInfo.SecurityCode.Trim();

            #endregion

            return await _paymentService.HandleCardPaymentRequest(
                paymentNewCardInfo: null!,
                paymentAddressInfo: null!,
                paymentExistingCardInfo: request.PaymentCardInfo!,
                autoTopupInfo: new AutoTopupDto()
                {
                    Amount = request.Amount,
                    Status = true
                },
                userInfo: new UserDto()
                {
                    Id = _currentUser.GetUserId(),
                    Email = _currentUser.GetUserEmail()
                },
                productType: ProductType.AutoTopupEnable,
                amount: _pay360Settings.AutoTopupAmount,
                cardNumber: userProduct.Product!);
        }

        #endregion
    }
}
