namespace FH.Core.Entities;
public sealed record ProductPriceEntity : BaseEntity<long>
{
    public required string DataDumpReference { get; set; }
    public decimal? Price { get; set; }
    public decimal? Tax { get; set; }
    public decimal? Fee { get; set; }
    public decimal? DiscountPercentage { get; set; }
    public decimal? RangeMinPrice { get; set; }
    public decimal? RangeMaxPrice { get; set; }
    public DateTime? EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
}
