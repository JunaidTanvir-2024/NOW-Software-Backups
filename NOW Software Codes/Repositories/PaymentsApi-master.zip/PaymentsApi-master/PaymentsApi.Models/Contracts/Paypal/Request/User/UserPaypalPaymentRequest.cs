﻿using Newtonsoft.Json;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace PaymentsApi.Models.Contracts.Paypal.Request.User
{
    public class UserPaypalPaymentRequest
    {
        [JsonProperty("customerName")]
        [Required]
        public string CustomerName { get; set; }

        [JsonProperty("customerMsisdn")]
        public string CustomerMsisdn { get; set; }

        [JsonProperty("customerUniqueRef")]
        [Required]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("customerEmail")]
        public string CustomerEmail { get; set; }

        [JsonProperty("sendPay360Email")]
        public bool SendPay360Email { get; set; } = true;

        [JsonProperty("transactionCurrency")]
        [Required]
        public string TransactionCurrency { get; set; }

        [JsonProperty("transactionAmount")]
        [Required]
        public float TransactionAmount { get; set; }

        [JsonProperty("isDirectFullfilment")]
        [Required]
        public bool IsDirectFullfilment { get; set; }

        [JsonProperty("ipAddress")]
        [Required]
        public string IpAddress { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("basket")]
        [Required]
        public ProductBasket[] Basket { get; set; }

        [JsonProperty("paymentMethod")]
        [Required]
        public PaypalPaymentMethod PaymentMethod { get; set; }

        [JsonProperty("customerBillingAddress")]
        public PaypalCustomerBillingAddress CustomerBillingAddress { get; set; }

        [JsonProperty("shippingAddress")]
        public PaypalShippingAddress ShippingAddress { get; set; }

        [JsonProperty("financialServices")]
        public UserFinancialServicesModel FinancialServices { get; set; }

        [JsonProperty("customFields")]
        public CustomFields CustomFields { get; set; }
    }

    public class PaypalCustomerBillingAddress
    {
        [JsonProperty("line1")]
        //[Required]
        public string Line1 { get; set; }

        [JsonProperty("line2")]
        public string Line2 { get; set; }

        [JsonProperty("line3")]
        public string Line3 { get; set; }

        [JsonProperty("line4")]
        public string Line4 { get; set; }

        [JsonProperty("city")]
        //[Required]
        public string City { get; set; }

        [JsonProperty("region")]
        //[Required]
        public string Region { get; set; }

        [JsonProperty("postcode")]
        //[Required]
        public string PostCode { get; set; }

        [JsonProperty("countryCode")]
        //[Required]
        [MaxLength(3)]
        public string CountryCode { get; set; }

    }
    public class PaypalShippingAddress
    {
        [JsonProperty("name")]
        //[Required]
        public string Name { get; set; }

        [JsonProperty("line1")]
        //[Required]
        public string Line1 { get; set; }

        [JsonProperty("line2")]
        public string Line2 { get; set; }

        [JsonProperty("line3")]
        public string Line3 { get; set; }

        [JsonProperty("line4")]
        public string Line4 { get; set; }

        [JsonProperty("city")]
        //[Required]
        public string City { get; set; }

        [JsonProperty("region")]
        //[Required]
        public string Region { get; set; }

        [JsonProperty("postcode")]
        //[Required]
        public string PostCode { get; set; }

        [JsonProperty("countryCode")]
        // [Required]
        [MaxLength(3)]
        public string CountryCode { get; set; }

    }
    public class PaypalPaymentMethod
    {
        [JsonProperty("paypal")]
        [Required]
        public PaypalUrls paypal { get; set; }

    }
    public class PaypalUrls
    {
        [JsonProperty("returnUrl")]
        [Required]
        public string returnUrl { get; set; }

        [JsonProperty("cancelUrl")]
        [Required]
        public string cancelUrl { get; set; }

    }
  
   

}
