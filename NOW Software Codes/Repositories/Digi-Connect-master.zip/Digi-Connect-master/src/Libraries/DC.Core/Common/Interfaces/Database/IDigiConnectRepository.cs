using DC.Core.Common.Definitions;
using DC.Core.Common.DependencyResolver;
using DC.Core.Common.Entities;
using DC.Core.Features.Notifications.Requests;


namespace DC.Core.Common.Interfaces.Database;

public interface IDigiConnectRepository : ServiceType.IScoped
{
    Task<List<ActiveMsisdnEntity>> GetNewRegisteredMsisdn();
    Task UpsertNewRegisteredMsisdn(ActiveMsisdnEntity logDto);
    Task<List<SmsDetails>> GetMessageContent(string type);
    Task<List<ActiveMsisdnLog>> GetActiveMsisdnLog(DateTime created, string cadence); 
    Task AddSendSMSLog(SendSMSLog request);
    Task<List<GetNewTopUp>> GetNewTopUp(DateTime created, string cadence);
    Task<List<GetMsisdnWithNoPlan>> GetMsisdnWithNoPlan(DateTime created, string cadence);
}
