﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.PayPal.RechargeableCallingCard
{
    public class PaypalRechargeableCallingCardRequestHandler : IRequestHandler<PaypalRechargeableCallingCardRequest, object>
    {
        #region Fields
        
        private readonly IPaymentService _paymentService;
        private readonly ICurrentUser _currentUser;
        private readonly IUserRepository _userRepository;

        #endregion

        #region Ctor

        public PaypalRechargeableCallingCardRequestHandler(IPaymentService paymentService,ICurrentUser currentUser,IUserRepository userRepository)
        {
            _paymentService = paymentService;
            _currentUser = currentUser;
            _userRepository = userRepository;
        }

        #endregion

        #region Method

        public async Task<object> Handle(
            PaypalRechargeableCallingCardRequest request, CancellationToken cancellationToken)
        {
            var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
            if (userProduct != null)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.ProductAlreadyExist, CustomStatusCode.BadRequest);
            }

            return await _paymentService.HandlePaypalPaymentRequest(
               productType: ProductType.RechargeableCallingCard,
               userInfo: new UserDto()
               {
                   Id = _currentUser.GetUserId(),
                   Email = _currentUser.GetUserEmail()
               },
               amount: request!.Amount,
               cardNumber: null!);
        }

        #endregion
    }
}
