﻿
namespace Now.Models.Database;

public class OrderItemDetails
{
    public int TransactionItemType { get; set; }
    public float Amount { get; set; }
    public float Discount { get; set; }
    public float TotalAmount { get; set; }
    public Guid? BundleId { get; set; }
    public string? BundleName { get; set; }
    public string? BundleCountryCode { get; set; }
    public bool IsAuto { get; set; }
}
