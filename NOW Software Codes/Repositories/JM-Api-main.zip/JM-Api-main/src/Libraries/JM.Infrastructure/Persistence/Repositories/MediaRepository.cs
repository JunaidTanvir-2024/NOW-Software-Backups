using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.EntityFrameworkCore;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;

public class MediaRepository(AppDbContext context, ILogger logger) : IMediaRepository
{
	private readonly AppDbContext _context = context;
	private readonly ILogger _logger = logger;

	public async Task<Media> AddMedia(Media media)
	{
		try
		{
			var addedMedia = await _context.Set<Media>().AddAsync(media);
			return addedMedia.Entity;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(MediaRepository), nameof(AddMedia));
			return default!;
		}
	}
	public void UpdateMedia(Media media)
	{
		try
		{
			_context.Entry(media).CurrentValues.SetValues(media);
			_context.Entry(media).State = EntityState.Modified;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(MediaRepository), nameof(UpdateMedia));
		}
	}
	public async Task<Media?> GetMedia(Expression<Func<Media, bool>> expression)
	{
		try
		{
			return await _context.Set<Media>()
				.Where(expression)
				.Include(x => x.Traveler)
				.ThenInclude(x => x.Trip)
				.ThenInclude(x => x.Creator)
				.ThenInclude(x => x.UserDetail)
				.FirstOrDefaultAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(MediaRepository), nameof(GetMedia));
			return default!;
		}
	}
	public async Task<IEnumerable<Media>> GetMediaList(Expression<Func<Media, bool>> expression = default!)
	{
		try
		{
			var query = _context.Set<Media>()
			   .Include(x => x.Traveler)
				.ThenInclude(x => x.Trip)
				.ThenInclude(x => x.Creator)
				.ThenInclude(x => x.UserDetail);
			return expression is null ? await query.ToListAsync() : await query.Where(expression).ToListAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(MediaRepository), nameof(GetMediaList));
			return default!;
		}
	}
}
