namespace MM.Infrastructure.Common.Settings;
public class SMSServiceSetting
{
    public const string SectionName = nameof(SMSServiceSetting);
    public static SMSServiceSetting Bind { get; } = new SMSServiceSetting();

    public string? Sid { get; set; }

    public string? AuthToken { get; set; }
    public string? TwilioNumber { get; set; }

    public List<string>? TwilioFromNumberCountries { get; set; }

    public string? SmsStatusCallbackURL { get; set; }
}

