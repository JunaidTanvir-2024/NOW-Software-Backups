﻿using ATT.Models.Configurations;
using ATT.Models.Contracts;
using ATT.Models.Contracts.TransferTo.Request;
using ATT.Models.Contracts.TransferTo.Response;
using ATT.Models.Database;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;


namespace ATT.Infrastructure.BLL.TransferTo
{
    public class TransfertoPost_BL : ITransfertoPost_BL
    {
        private ILogger _loggerExternalAPIExceptions;
        private Serilog.ILogger _loggerAPIAccess;
        private ITransfertoAuth_BL _TransferToAuth;
        private TransferToConfig TransferToConf;
        private readonly HttpConfig httpConfig;

        //  SochiTelAuth is Infrastructure Security module defined in TalkHome.WebServices project
        //  Injected in this controller through AutoFac. Review AutofacConfig.cs in TalkHome.WebServices.App_Start
        public TransfertoPost_BL(ITransfertoAuth_BL transferToAuth, ILogger appLoggers, IOptions<TransferToConfig> transferToConf, IOptions<HttpConfig> http)
        {
            _TransferToAuth = transferToAuth;
            _loggerExternalAPIExceptions = appLoggers;
            _loggerAPIAccess = appLoggers;
            TransferToConf = transferToConf.Value;
            httpConfig = http.Value;
        }


        public async Task<GenericApiResponse<TransferToOperatorsByCountryId>> DTOneOperatorListbyCountry(string currency, int CountryID, string productCode)
        {
            GenericApiResponse<TransferToOperatorsByCountryId> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject_TRH(currency, productCode);
                TransfertoPricelistRequest req = new TransfertoPricelistRequest("pricelist", "country", CountryID);
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                string s = req.toXML();

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                xmlDoc.LoadXml(strResponseJSON); // Load the XML document from the specified file

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    XmlNodeList xmlOperators = xmlDoc.GetElementsByTagName("operator");
                    string[] operators = xmlOperators.Item(0).InnerText.Split(',');

                    XmlNodeList xmlOperatorIDS = xmlDoc.GetElementsByTagName("operatorid");
                    string[] operatorIDS = xmlOperatorIDS.Item(0).InnerText.Split(',');
                    List<string> opIds = new List<string>();

                    List<OperatorsByCountry> OperatorIDNameList = new List<OperatorsByCountry>();
                    for (int a = 0; a < operatorIDS.Length; a++)
                    {
                        if (!opIds.Contains(operatorIDS[a]))
                        {
                            opIds.Add(operatorIDS[a]);
                            OperatorsByCountry op = new OperatorsByCountry()
                            {
                                OperatorId = operatorIDS[a],
                                OperatorName = operators[a],
                                OperatorImageUrl = "https://operator-logo.transferto.com/logo-" + operatorIDS[a] + "-1.png"
                            };
                            OperatorIDNameList.Add(op);
                        }

                    }
                    TransferToOperatorsByCountryId operatorsRecord = new TransferToOperatorsByCountryId();
                    operatorsRecord.Operators = OperatorIDNameList;
                    operatorsRecord.Country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;

                    returnResult = GenericApiResponse<TransferToOperatorsByCountryId>.Success(operatorsRecord);
                }
                else
                    returnResult = GenericApiResponse<TransferToOperatorsByCountryId>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return returnResult;
        }

        async Task<string> transferToPostService(string xml)
        {
            HttpClient SochitelHttpClient = new HttpClient{ Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut) };
            SochitelHttpClient.Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut);
            SochitelHttpClient.BaseAddress = new Uri(TransferToConf.AttApiEndPoint);

            var httpContent = new StringContent(xml, Encoding.UTF8, "text/xml");

            string returnData = "";
            try
            {
                var httpResponse = await SochitelHttpClient.PostAsync(TransferToConf.AttApiEndPoint, httpContent);

                if (httpResponse.Content != null)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    Exception ex = new Exception($"Sochitel API Call Exception - Empty Contents Received - {xml}");
                    throw ex;
                }
            }
            catch (WebException wex)
            {
                _loggerExternalAPIExceptions.Debug($"\"Post  Transferto  API Web Access\"     Failed      Data:{xml}     Message:{wex.ToString()}");
                throw wex;
            }
            catch (Exception ex)
            {
                _loggerExternalAPIExceptions.Debug($"\"Post  Transferto API\"  Failed       Generasl Exception       Data:{xml}      Message:{ex.ToString()}");
                throw ex;
            }

            return returnData;
        }

        private async Task<HttpResponseMessage> TransferToGet(string Uri)
        {
            HttpResponseMessage response;

            try
            {

                using (HttpClient client = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut) })
                {
                    client.Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut);
                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                    //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);

                    response = await client.GetAsync(Uri);

                    return response;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<GenericApiResponse<decimal>> transferToGetAccountBalance(string currency)
        {
            GenericApiResponse<decimal> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject(currency);
                TransfertoBalance req = new TransfertoBalance();
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                string s = req.toXML();

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(strResponseJSON);

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    returnResult = GenericApiResponse<decimal>.Success(decimal.Parse(xmlDoc.GetElementsByTagName("balance").Item(0).InnerText));
                }
                else
                {
                    returnResult = GenericApiResponse<decimal>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));
                }

                return returnResult;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<string>> transfertoReserveID(string currency)
        {
            GenericApiResponse<string> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject(currency);
                TransfertoReserveID req = new TransfertoReserveID();
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                string s = req.toXML();

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(strResponseJSON);

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    returnResult = GenericApiResponse<string>.Success(strResponseJSON);
                }
                else
                {
                    returnResult = GenericApiResponse<string>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));
                }

                return returnResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<string>> transferToCheckService(string currency)
        {
            GenericApiResponse<string> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject(currency);
                TransfertoPing req = new TransfertoPing();
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                string s = req.toXML();

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(strResponseJSON);

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    returnResult = GenericApiResponse<string>.Success(xmlDoc.GetElementsByTagName("info_txt").Item(0).InnerText);
                }
                else
                {
                    returnResult = GenericApiResponse<string>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));
                }

                return returnResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<GenericApiResponse<Dictionary<string, string>>> transfertoCountryList(string currency, string productCode)
        {
            GenericApiResponse<Dictionary<string, string>> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject_TRH(currency, productCode);
                TransfertoPricelistRequest req = new TransfertoPricelistRequest("pricelist", "countries");
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                string s = req.toXML();

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(strResponseJSON);

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    XmlNodeList xmlCountries = xmlDoc.GetElementsByTagName("country");
                    string[] countries = xmlCountries.Item(0).InnerText.Split(',');

                    XmlNodeList xmlCouuntryIDS = xmlDoc.GetElementsByTagName("countryid");
                    string[] countryIDS = xmlCouuntryIDS.Item(0).InnerText.Split(',');

                    Dictionary<string, string> CountryIDNameList = new Dictionary<string, string>();
                    for (int a = 0; a < countryIDS.Length; a++)
                    {
                        if (!CountryIDNameList.ContainsKey(countryIDS[a]))
                        {
                            CountryIDNameList.Add(countryIDS[a], countries[a]);
                        }
                    }

                    returnResult = GenericApiResponse<Dictionary<string, string>>.Success(CountryIDNameList);
                }
                else
                    returnResult = GenericApiResponse<Dictionary<string, string>>.Failure(xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return returnResult;
        }


        public async Task<GenericApiResponse<Dictionary<string, string>>> transferToOperatorsList(string currency, int CountryID)
        {
            GenericApiResponse<Dictionary<string, string>> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject(currency);
                TransfertoPricelistRequest req = new TransfertoPricelistRequest("pricelist", "country", CountryID);
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                string s = req.toXML();

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                xmlDoc.LoadXml(strResponseJSON); // Load the XML document from the specified file

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    XmlNodeList xmlOperators = xmlDoc.GetElementsByTagName("operator");
                    string[] operators = xmlOperators.Item(0).InnerText.Split(',');

                    XmlNodeList xmlOperatorIDS = xmlDoc.GetElementsByTagName("operatorid");
                    string[] operatorIDS = xmlOperatorIDS.Item(0).InnerText.Split(',');

                    Dictionary<string, string> OperatorIDNameList = new Dictionary<string, string>();
                    for (int a = 0; a < operatorIDS.Length; a++)
                    {
                        if (!OperatorIDNameList.ContainsKey(operatorIDS[a]))
                        {
                            OperatorIDNameList.Add(operatorIDS[a], operators[a]);
                        }
                    }

                    returnResult = GenericApiResponse<Dictionary<string, string>>.Success(OperatorIDNameList);
                }
                else
                    returnResult = GenericApiResponse<Dictionary<string, string>>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return returnResult;
        }

        public async Task<GenericApiResponse<string>> getOperatorProductsMSISDN(string destinationMSISDN, string currency, string product)
        {
            try
            {
                GenericApiResponse<string> operatorProductsXMLString;
                GenericApiResponse<TransferToMSISDNInfoResponse> parsedMSISDNobject = await transfertoParseMSISDN(destinationMSISDN, currency, product);

                if (parsedMSISDNobject.Status == 0)
                {

                    if (product.ToUpper() == "TRH")
                        operatorProductsXMLString = await transferToOperatorPriceList_TRH(currency, parsedMSISDNobject.Result.operatorid, product);
                    else
                        operatorProductsXMLString = await transferToOperatorPriceList(currency, parsedMSISDNobject.Result.operatorid);

                    if (operatorProductsXMLString.Status == 0)
                        return operatorProductsXMLString;
                    else
                        return GenericApiResponse<string>.Failure(operatorProductsXMLString.Message);
                }
                else
                    return GenericApiResponse<string>.Failure(parsedMSISDNobject.Message, parsedMSISDNobject.Status);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<GenericApiResponse<string>> getOperatorProductsMSISDN(string destinationMSISDN, string currency, long? sourceMSISDN = null)
        {
            try
            {
                GenericApiResponse<TransferToMSISDNInfoResponse> parsedMSISDNobject = await transfertoParseMSISDN(destinationMSISDN, currency, sourceMSISDN);

                if (parsedMSISDNobject.Status == 0)
                {
                    GenericApiResponse<string> operatorProductsXMLString = await transferToOperatorPriceList(currency, parsedMSISDNobject.Result.operatorid, sourceMSISDN);

                    if (operatorProductsXMLString.Status == 0)
                        return operatorProductsXMLString;
                    else
                        return GenericApiResponse<string>.Failure(operatorProductsXMLString.Message);
                }
                else
                    return GenericApiResponse<string>.Failure(parsedMSISDNobject.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        // For FreeSwitch Daemon
        #region For_FreeSwitch_Daemon

        public async Task<GenericApiResponse<string>> getFreeSwitchOperatorProductsMSISDN(string destinationMSISDN, string currency)
        {
            try
            {
                GenericApiResponse<TransferToMSISDNInfoResponse> parsedMSISDNobject = await transfertoFreeSwitchParseMSISDN(destinationMSISDN, currency);

                if (parsedMSISDNobject.Status == 0)
                {
                    GenericApiResponse<string> operatorProductsXMLString = await transferToFreeSwitchOperatorPriceList(currency, parsedMSISDNobject.Result.operatorid);

                    if (operatorProductsXMLString.Status == 0)
                        return operatorProductsXMLString;
                    else
                        return GenericApiResponse<string>.Failure(operatorProductsXMLString.Message);
                }
                else
                    return GenericApiResponse<string>.Failure(parsedMSISDNobject.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<TransferToMSISDNInfoResponse>> transfertoFreeSwitchParseMSISDN(string msisdn, string currency)
        {
            GenericApiResponse<TransferToMSISDNInfoResponse> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getFreeSwitchAuthJSONObject();
                TransferToMSISDNInfoRequest req = new TransferToMSISDNInfoRequest();
                req.destination_msisdn = msisdn;
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                // req.operatorid = "2867";

                string s = req.toXML();

                Task<String> HttpTransfertoPostService = transferToPostService(s);
                string strResponseJSON = await HttpTransfertoPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(strResponseJSON);

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    TransferToMSISDNInfoResponse parseMSISDN = new TransferToMSISDNInfoResponse();

                    parseMSISDN.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;
                    parseMSISDN.countryid = int.Parse(xmlDoc.GetElementsByTagName("countryid").Item(0).InnerText);
                    parseMSISDN.@operator = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;
                    parseMSISDN.operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    returnResult = GenericApiResponse<TransferToMSISDNInfoResponse>.Success(parseMSISDN);
                }
                else
                {
                    returnResult = GenericApiResponse<TransferToMSISDNInfoResponse>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));
                }

                return returnResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<string>> transferToFreeSwitchOperatorPriceList(string currency, int OperatorID)
        {

            GenericApiResponse<string> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getFreeSwitchAuthJSONObject();
                TransfertoPricelistRequest req = new TransfertoPricelistRequest("pricelist", "operator", OperatorID);
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                string s = req.toXML();

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                xmlDoc.LoadXml(strResponseJSON); // Load the XML document from the specified file

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                    returnResult = GenericApiResponse<string>.Success(strResponseJSON);
                else
                    returnResult = GenericApiResponse<string>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;
        }

        public async Task<GenericApiResponse<transfertoExecuteTransaction>> transfertoExecuteTransactionFreeSwitch(string fromMsisdn, string toMsisdn, string amount, string currency, string operatorid, string success_sms_quote, long requestKey)
        {
            GenericApiResponse<transfertoExecuteTransaction> returnResult = new GenericApiResponse<transfertoExecuteTransaction>();

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getFreeSwitchAuthJSONObject(requestKey);

                TransfertoTransaction req = new TransfertoTransaction();

                if (TransferToConf.AttSimulationMode == true)
                    req.action = "simulation";
                else
                    req.action = "topup";

                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                req.destination_msisdn = toMsisdn;
                req.msisdn = fromMsisdn;
                req.product = amount;
                req.operatorid = operatorid;
                req.sms = success_sms_quote;
                string s = req.toXML("TRH");

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                xmlDoc.LoadXml(strResponseJSON); // Load the XML document from the specified file

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    transfertoExecuteTransaction trans = new transfertoExecuteTransaction();
                    trans.error_code = int.Parse(xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText);
                    trans.error_txt = xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText;
                    trans.transactionid = xmlDoc.GetElementsByTagName("transactionid").Item(0).InnerText;
                    trans.msisdn = xmlDoc.GetElementsByTagName("msisdn").Item(0).InnerText;
                    trans.destination_msisdn = xmlDoc.GetElementsByTagName("destination_msisdn").Item(0).InnerText;
                    trans.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;
                    trans.originating_currency = xmlDoc.GetElementsByTagName("originating_currency").Item(0).InnerText;
                    trans.destination_currency = xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText;
                    trans.product_requested = xmlDoc.GetElementsByTagName("product_requested").Item(0).InnerText;
                    trans.wholesale_price = decimal.Parse(xmlDoc.GetElementsByTagName("wholesale_price").Item(0).InnerText);
                    trans.retail_price = decimal.Parse(xmlDoc.GetElementsByTagName("retail_price").Item(0).InnerText);
                    trans.@operator = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;
                    trans.operatorid = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;

                    returnResult = GenericApiResponse<transfertoExecuteTransaction>.Success(trans);
                    returnResult.ATTTransactionReference = trans.transactionid;
                    returnResult.APITransactionReference = req.key.ToString();  // Unique key generated in Request
                }
                else
                {
                    returnResult = GenericApiResponse<transfertoExecuteTransaction>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText), int.Parse(xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText));
                    returnResult.ATTTransactionReference = "";
                    returnResult.APITransactionReference = req.key.ToString();  // Unique key generated in Request
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;
        }


        #endregion For_FreeSwitch_Daemon


        public async Task<GenericApiResponse<TransferToMSISDNInfoResponse>> transfertoParseMSISDN(string msisdn, string currency, string product)
        {
            GenericApiResponse<TransferToMSISDNInfoResponse> returnResult;

            try
            {
                TransfertoBaseRequest basereq;
                if (product.ToUpper() == "TRH")
                    basereq = _TransferToAuth.getAuthJSONObject_TRH(currency, product);
                else
                    basereq = _TransferToAuth.getAuthJSONObject(currency, product, false);

                TransferToMSISDNInfoRequest req = new TransferToMSISDNInfoRequest();
                req.destination_msisdn = msisdn;
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                // req.operatorid = "2867";

                string s = req.toXML();

                Task<String> HttpTransfertoPostService = transferToPostService(s);
                string strResponseJSON = await HttpTransfertoPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(strResponseJSON);

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    TransferToMSISDNInfoResponse parseMSISDN = new TransferToMSISDNInfoResponse();

                    parseMSISDN.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;
                    parseMSISDN.countryid = int.Parse(xmlDoc.GetElementsByTagName("countryid").Item(0).InnerText);
                    parseMSISDN.@operator = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;
                    parseMSISDN.operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    returnResult = GenericApiResponse<TransferToMSISDNInfoResponse>.Success(parseMSISDN);
                }
                else
                {
                    returnResult = GenericApiResponse<TransferToMSISDNInfoResponse>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText), Convert.ToInt32(xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText));
                }

                return returnResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<TransferToMSISDNInfoResponse>> transfertoParseMSISDN(string msisdn, string currency, long? sourceMSISDN = null)
        {
            GenericApiResponse<TransferToMSISDNInfoResponse> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject(currency, sourceMSISDN);
                TransferToMSISDNInfoRequest req = new TransferToMSISDNInfoRequest();
                req.destination_msisdn = msisdn;
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                // req.operatorid = "2867";

                string s = req.toXML();

                Task<String> HttpTransfertoPostService = transferToPostService(s);
                string strResponseJSON = await HttpTransfertoPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(strResponseJSON);

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    TransferToMSISDNInfoResponse parseMSISDN = new TransferToMSISDNInfoResponse();

                    parseMSISDN.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;
                    parseMSISDN.countryid = int.Parse(xmlDoc.GetElementsByTagName("countryid").Item(0).InnerText);
                    parseMSISDN.@operator = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;
                    parseMSISDN.operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    returnResult = GenericApiResponse<TransferToMSISDNInfoResponse>.Success(parseMSISDN);
                }
                else
                {
                    returnResult = GenericApiResponse<TransferToMSISDNInfoResponse>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));
                }

                return returnResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public async Task<GenericApiResponse<string>> transferToOperatorPriceList_TRH(string currency, int OperatorID, string product)
        {

            GenericApiResponse<string> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject_TRH(currency, product);
                TransfertoPricelistRequest req = new TransfertoPricelistRequest("pricelist", "operator", OperatorID);
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                string s = req.toXML();

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                xmlDoc.LoadXml(strResponseJSON); // Load the XML document from the specified file

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                    returnResult = GenericApiResponse<string>.Success(strResponseJSON);
                else
                    returnResult = GenericApiResponse<string>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;
        }


        public async Task<GenericApiResponse<DtOnePromotionsResponse>> DtOneGetPromotions()
        {

            GenericApiResponse<DtOnePromotionsResponse> response = null;
            try
            {

                string url = TransferToConf.AttPromotionApiEndPoint;
                HttpResponseMessage httpResponse = null;
                try
                {

                    httpResponse = await TransferToGet(url);
                }
                catch (Exception ex)
                {
                    _loggerAPIAccess.Error($"class: TransferToPost_BL, Method: DtOneGetPromotions, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                    return response = GenericApiResponse<DtOnePromotionsResponse>.Failure(ex.Message);
                }

                if (httpResponse == null)
                {
                    _loggerAPIAccess.Error($"class: TransferToPost_BL, Method: DtOneGetPromotions, ErrorMessage: Null response received from TransferTo promotions Api.");
                    return response = GenericApiResponse<DtOnePromotionsResponse>.Failure("Null response received from TransferTo promotions Api.");
                }
                else
                {

                    string return_response_data = "";

                    if (httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        return_response_data = httpResponse.Content.ReadAsStringAsync().Result;
                    }

                    if (!string.IsNullOrWhiteSpace(return_response_data))
                    {

                        Channel channel = new Channel();
                        List<Item> items = new List<Item>();
                        List<Country1> countryList = new List<Country1>();

                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(return_response_data);


                        XmlNodeList xnList = doc.SelectNodes("rss/channel/item");
                        foreach (XmlNode xn in xnList)
                        {
                            string title = xn["title"].InnerText.Trim();
                            string description = xn["description"].InnerText.Trim();
                            string dateFrom = xn["dateFrom"].InnerText;
                            string dateTo = xn["dateTo"].InnerText;
                            string pubDate = xn["pubDate"].InnerText;
                            string operatorName = xn["operatorName"].InnerText;
                            string operatorId = xn["operatorId"].InnerText;
                            string subOperatorId = xn["subOperatorId"].InnerText;
                            string countryId = xn["countryId"].InnerText;
                            string countryName = xn["countryName"].InnerText;
                            string title2 = xn["title2"].InnerText.Trim();
                            string denomination = xn["denomination"].InnerText.Trim();

                            string denominationLocal = "";

                            if (xn["denominationLocal"] != null)
                            {
                                denominationLocal = xn["denominationLocal"].InnerText.Trim();
                            }

                            DateTime start = DateTime.Parse(dateFrom);
                            DateTime end = DateTime.Parse(dateTo);
                            DateTime now = DateTime.UtcNow;
                            string status = string.Empty;

                            string promotionstatus = "";


                            // see if start comes before end
                            if (start <= now && now <= end)
                            {
                                promotionstatus = "Active";
                            }
                            else if (start >= now && now <= end)
                            {
                                promotionstatus = "UpComing";
                            }

                            items.Add(new Item
                            {
                                dateFrom = dateFrom,
                                dateTo = dateTo,
                                denomination = denomination,
                                denominationLocal = denominationLocal,
                                description = description,
                                operatorId = operatorId,
                                operatorName = operatorName,
                                pubDate = pubDate,
                                subOperatorId = subOperatorId,
                                title = title,
                                title2 = title2,
                                countryId = countryId,
                                countryName = countryName,
                                promotionstatus = promotionstatus
                            });


                            countryList.Add(new Country1
                            {
                                countryId = countryId,
                                countryName = countryName,

                            });



                        }

                        XmlNodeList xnChannel = doc.SelectNodes("rss/channel");
                        foreach (XmlNode xn in xnChannel)
                        {
                            string title = xn["title"].InnerText.Trim();
                            string description = xn["description"].InnerText.Trim();
                            string link = xn["link"].InnerText;
                            string pubDate = xn["pubDate"].InnerText;
                            string lastBuildDate = xn["lastBuildDate"].InnerText;
                            string ttl = xn["ttl"].InnerText;

                            channel.title = title;
                            channel.description = description;
                            channel.link = link;
                            channel.pubDate = pubDate;
                            channel.lastBuildDate = lastBuildDate;
                            channel.ttl = ttl;

                            channel.item = items;
                        }

                        var country = countryList.GroupBy(x => x.countryId)
                                    .Select(g => g.First()).OrderBy(x => x.countryName);

                        DtOnePromotionsResponse rss = new DtOnePromotionsResponse { channel = channel, country = country.ToList() };
                        return GenericApiResponse<DtOnePromotionsResponse>.Success(rss);

                    }
                    else
                    {
                        _loggerAPIAccess.Error($"class: TransferToPost_BL, Method: DtOneGetPromotions, ErrorMessage: Null response received from TransferTo promotions Api.");
                        return response = GenericApiResponse<DtOnePromotionsResponse>.Failure("Null response received from TransferTo promotions Api.");
                    }
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Error($"class: TransferToPost_BL, Method: DtOneGetPromotions, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return response = GenericApiResponse<DtOnePromotionsResponse>.Failure(ex.Message);
            }
        }


        public async Task<GenericApiResponse<string>> transferToOperatorPriceList(string currency, int OperatorID, long? sourceMSISDN = null)
        {

            GenericApiResponse<string> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject(currency, sourceMSISDN);
                TransfertoPricelistRequest req = new TransfertoPricelistRequest("pricelist", "operator", OperatorID);
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                string s = req.toXML();

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                xmlDoc.LoadXml(strResponseJSON); // Load the XML document from the specified file

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                    returnResult = GenericApiResponse<string>.Success(strResponseJSON);
                else
                    returnResult = GenericApiResponse<string>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;
        }

        public async Task<GenericApiResponse<transfertoExecuteTransaction>> transfertoTransaction_TRH(string fromMsisdn, string toMsisdn, string amount, string currency, string operatorid, string success_sms_quote, long requestKey, string productCode)
        {
            GenericApiResponse<transfertoExecuteTransaction> returnResult = new GenericApiResponse<transfertoExecuteTransaction>();

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject_TRH(currency, requestKey, productCode);

                TransfertoTransaction req = new TransfertoTransaction();

                if (TransferToConf.AttSimulationMode == true)
                    req.action = "simulation";
                else
                    req.action = "topup";

                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                req.destination_msisdn = toMsisdn;
                req.msisdn = fromMsisdn;
                req.product = amount;
                req.operatorid = operatorid;
                req.sms = success_sms_quote;
                string s = req.toXML("trh");

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                xmlDoc.LoadXml(strResponseJSON); // Load the XML document from the specified file

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    transfertoExecuteTransaction trans = new transfertoExecuteTransaction();
                    trans.error_code = int.Parse(xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText);
                    trans.error_txt = xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText;
                    trans.transactionid = xmlDoc.GetElementsByTagName("transactionid").Item(0).InnerText;
                    trans.msisdn = xmlDoc.GetElementsByTagName("msisdn").Item(0).InnerText;
                    trans.destination_msisdn = xmlDoc.GetElementsByTagName("destination_msisdn").Item(0).InnerText;
                    trans.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;
                    trans.originating_currency = xmlDoc.GetElementsByTagName("originating_currency").Item(0).InnerText;
                    trans.destination_currency = xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText;
                    trans.product_requested = xmlDoc.GetElementsByTagName("product_requested").Item(0).InnerText;
                    trans.wholesale_price = decimal.Parse(xmlDoc.GetElementsByTagName("wholesale_price").Item(0).InnerText);
                    trans.retail_price = decimal.Parse(xmlDoc.GetElementsByTagName("retail_price").Item(0).InnerText);
                    trans.@operator = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;
                    trans.operatorid = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;

                    returnResult = GenericApiResponse<transfertoExecuteTransaction>.Success(trans);
                    returnResult.ATTTransactionReference = trans.transactionid;
                    returnResult.APITransactionReference = req.key.ToString();  // Unique key generated in Request
                }
                else
                {
                    returnResult = GenericApiResponse<transfertoExecuteTransaction>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText), int.Parse(xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText));
                    returnResult.ATTTransactionReference = "";
                    returnResult.APITransactionReference = req.key.ToString();  // Unique key generated in Request
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;
        }


        public async Task<GenericApiResponse<transfertoExecuteTransaction>> transfertoTransaction(string fromMsisdn, string toMsisdn, string amount, string currency, string operatorid, string success_sms_quote, long requestKey)
        {
            GenericApiResponse<transfertoExecuteTransaction> returnResult = new GenericApiResponse<transfertoExecuteTransaction>();

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject(currency, requestKey, long.Parse(fromMsisdn));

                TransfertoTransaction req = new TransfertoTransaction();

                if (TransferToConf.AttSimulationMode == true)
                    req.action = "simulation";
                else
                    req.action = "topup";

                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;
                req.destination_msisdn = toMsisdn;
                req.msisdn = fromMsisdn;
                req.product = amount;
                req.operatorid = operatorid;
                req.sms = success_sms_quote;
                string s = req.toXML();

                Task<String> HttpSochitelPostService = transferToPostService(s);
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                xmlDoc.LoadXml(strResponseJSON); // Load the XML document from the specified file

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    transfertoExecuteTransaction trans = new transfertoExecuteTransaction();
                    trans.error_code = int.Parse(xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText);
                    trans.error_txt = xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText;
                    trans.transactionid = xmlDoc.GetElementsByTagName("transactionid").Item(0).InnerText;
                    trans.msisdn = xmlDoc.GetElementsByTagName("msisdn").Item(0).InnerText;
                    trans.destination_msisdn = xmlDoc.GetElementsByTagName("destination_msisdn").Item(0).InnerText;
                    trans.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;
                    trans.originating_currency = xmlDoc.GetElementsByTagName("originating_currency").Item(0).InnerText;
                    trans.destination_currency = xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText;
                    trans.product_requested = xmlDoc.GetElementsByTagName("product_requested").Item(0).InnerText;
                    trans.wholesale_price = decimal.Parse(xmlDoc.GetElementsByTagName("wholesale_price").Item(0).InnerText);
                    trans.retail_price = decimal.Parse(xmlDoc.GetElementsByTagName("retail_price").Item(0).InnerText);
                    trans.@operator = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;
                    trans.operatorid = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;

                    returnResult = GenericApiResponse<transfertoExecuteTransaction>.Success(trans);
                    returnResult.ATTTransactionReference = trans.transactionid;
                    returnResult.APITransactionReference = req.key.ToString();  // Unique key generated in Request
                }
                else
                {
                    returnResult = GenericApiResponse<transfertoExecuteTransaction>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText), int.Parse(xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText));
                    returnResult.ATTTransactionReference = "";
                    returnResult.APITransactionReference = req.key.ToString();  // Unique key generated in Request
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;
        }

        public async Task<GenericApiResponse<TransferToGetTransactionResponse>> transfertoGetTransactionDetailFromKey(string transactionKey, string account)
        {

            GenericApiResponse<TransferToGetTransactionResponse> response;
            try
            {
                TransferToGetTransactionIdFromKeyResponse result = await transfertoGetTransactionIdFromKey(transactionKey, account);
                if (result != null && result.error_code == "0" && !string.IsNullOrEmpty(result.id))
                {
                    response = await transfertoGetTransactionDetailFromTransactionId(result.id, account);
                }
                else
                {
                    response = new GenericApiResponse<TransferToGetTransactionResponse>();
                    response.Status = 2;
                    response.Message = result.error_txt;
                }
            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<TransferToGetTransactionResponse>();
                response.Status = 2;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<GenericApiResponse<TransferToGetTransactionResponse>> transfertoGetTransactionDetailFromTransactionId(string transactionId, string account)
        {
            GenericApiResponse<TransferToGetTransactionResponse> returnResult;

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject(account);
                TransferToGetTransactionRequest req = new TransferToGetTransactionRequest();
                req.transactionid = transactionId;
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;

                string s = req.toXML();

                Task<String> HttpTransfertoPostService = transferToPostService(s);
                string strResponseJSON = await HttpTransfertoPostService;                     // Send the request to Sochitel and receive JSON 

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(strResponseJSON);

                if (xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText == "0")
                {
                    TransferToGetTransactionResponse response = new TransferToGetTransactionResponse();

                    response.transactionid = xmlDoc.GetElementsByTagName("transactionid").Item(0).InnerText;
                    response.msisdn = xmlDoc.GetElementsByTagName("msisdn").Item(0).InnerText;
                    response.destination_msisdn = xmlDoc.GetElementsByTagName("destination_msisdn").Item(0).InnerText;
                    response.transaction_authentication_key = xmlDoc.GetElementsByTagName("transaction_authentication_key").Item(0).InnerText;
                    response.transaction_error_code = int.Parse(xmlDoc.GetElementsByTagName("transaction_error_code").Item(0).InnerText);
                    response.transaction_error_txt = xmlDoc.GetElementsByTagName("transaction_error_txt").Item(0).InnerText;
                    response.reference_operator = xmlDoc.GetElementsByTagName("reference_operator").Item(0).InnerText;
                    response.product_requested = xmlDoc.GetElementsByTagName("product_requested").Item(0).InnerText;
                    response.actual_product_sent = xmlDoc.GetElementsByTagName("actual_product_sent").Item(0).InnerText;
                    response.wholesale_price = Convert.ToDecimal(xmlDoc.GetElementsByTagName("wholesale_price").Item(0).InnerText);
                    response.retail_price = Convert.ToDecimal(xmlDoc.GetElementsByTagName("retail_price").Item(0).InnerText);
                    response.sms = xmlDoc.GetElementsByTagName("sms").Item(0).InnerText;
                    response.originating_currency = xmlDoc.GetElementsByTagName("originating_currency").Item(0).InnerText;
                    response.destination_currency = xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText;
                    response.authentication_key = xmlDoc.GetElementsByTagName("authentication_key").Item(0).InnerText;
                    response.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;
                    response.countryid = int.Parse(xmlDoc.GetElementsByTagName("countryid").Item(0).InnerText);
                    response.@operator = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;
                    response.operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    returnResult = GenericApiResponse<TransferToGetTransactionResponse>.Success(response);
                }
                else
                {
                    returnResult = GenericApiResponse<TransferToGetTransactionResponse>.Failure((xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText));
                }

                return returnResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<TransferToGetTransactionIdFromKeyResponse> transfertoGetTransactionIdFromKey(string transactionKey, string currency)
        {
            TransferToGetTransactionIdFromKeyResponse returnResult = new TransferToGetTransactionIdFromKeyResponse();

            try
            {
                TransfertoBaseRequest basereq = _TransferToAuth.getAuthJSONObject(currency);
                TransferToGetTransactionIdFromKeyRequest req = new TransferToGetTransactionIdFromKeyRequest();
                req.from_key = transactionKey;
                req.login = basereq.login;
                req.md5 = basereq.md5;
                req.key = basereq.key;

                string s = req.toXML();

                Task<String> HttpTransfertoPostService = transferToPostService(s);
                string strResponseJSON = await HttpTransfertoPostService;                     // Send the request to Sochitel and receive JSON 

                if (!string.IsNullOrEmpty(strResponseJSON))
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(strResponseJSON);

                    returnResult.error_code = xmlDoc.GetElementsByTagName("error_code").Item(0).InnerText;
                    returnResult.error_txt = xmlDoc.GetElementsByTagName("error_txt").Item(0).InnerText;
                    if (returnResult.error_code == "0")
                    {
                        returnResult.id = xmlDoc.GetElementsByTagName("id").Item(0).InnerText;
                        returnResult.authentication_key = xmlDoc.GetElementsByTagName("authentication_key").Item(0).InnerText;
                    }
                }

                return returnResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<GenericApiResponse<string>> transfertoGoodsServiceParseMsisdn(string msisdn, string countryId, string serviceId, string currency)
        {
            GenericApiResponse<string> returnResult = null;

            try
            {
                string baseUrl = TransferToConf.DataBundlesGsApiEndPoint; //"3a066b0e-0bff-446d-be01-67c5cdf9add8";
                string serviceUrl = baseUrl + "/services/" + serviceId + "/operators?country_id=" + countryId + "&account_number=" + msisdn;
                HttpRequestMessage request = _TransferToAuth.HttpRequestMessage(currency, serviceUrl);

                using (var client = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut) })
                {
                    HttpResponseMessage response = await client.SendAsync(request);
                    string jsonResult = await response.Content.ReadAsStringAsync();
                    //var result = JsonConvert.DeserializeObject<string>(jsonResult);

                    //if (result != null)
                    //{
                    returnResult = GenericApiResponse<string>.Success(jsonResult);
                    //}
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;

        }

        public async Task<GenericApiResponse<TransfertoServciesList>> transfertoServiceList(string currency)
        {
            GenericApiResponse<TransfertoServciesList> returnResult = null;

            try
            {
                string baseUrl = TransferToConf.DataBundlesGsApiEndPoint; //"3a066b0e-0bff-446d-be01-67c5cdf9add8";
                string serviceUrl = baseUrl + "/services";
                HttpRequestMessage request = _TransferToAuth.HttpRequestMessage(currency, serviceUrl);

                using (var client = new HttpClient{ Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut) })
                {
                    HttpResponseMessage response = await client.SendAsync(request);
                    string jsonResult = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<TransfertoServciesList>(jsonResult);

                    if (result != null)
                    {
                        returnResult = GenericApiResponse<TransfertoServciesList>.Success(result);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;

        }


        public async Task<GenericApiResponse<TransferToCountriesListByServices>> transfertoCountryListByService(string currency, int serviceId)
        {
            GenericApiResponse<TransferToCountriesListByServices> returnResult = null;

            try
            {
                string baseUrl = TransferToConf.DataBundlesGsApiEndPoint;
                string serviceUrl = baseUrl + "/services/" + serviceId + "/countries";
                HttpRequestMessage request = _TransferToAuth.HttpRequestMessage(currency, serviceUrl);

                using (var client = new HttpClient{ Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut) })
                {
                    HttpResponseMessage response = await client.SendAsync(request);
                    string jsonResult = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<TransferToCountriesListByServices>(jsonResult);

                    if (result != null)
                    {
                        returnResult = GenericApiResponse<TransferToCountriesListByServices>.Success(result);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;

        }



        public async Task<GenericApiResponse<TransfertoOperatorListByServices>> transfertoOperatorListByService(string currency, int serviceId)
        {
            GenericApiResponse<TransfertoOperatorListByServices> returnResult = null;

            try
            {
                string baseUrl = TransferToConf.DataBundlesGsApiEndPoint;
                string serviceUrl = baseUrl + "/services/" + serviceId + "/operators";
                HttpRequestMessage request = _TransferToAuth.HttpRequestMessage(currency, serviceUrl);

                using (var client = new HttpClient{ Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut) })
                {
                    HttpResponseMessage response = await client.SendAsync(request);
                    string jsonResult = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<TransfertoOperatorListByServices>(jsonResult);

                    if (result != null)
                    {
                        returnResult = GenericApiResponse<TransfertoOperatorListByServices>.Success(result);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;

        }


        public async Task<GenericApiResponse<TransfertoDataBundleProductList>> transfertoDataBundleProductList(string currency, int serviceId, int operatorId, int countryid)
        {
            GenericApiResponse<TransfertoDataBundleProductList> returnResult = null;

            try
            {
                string baseUrl = TransferToConf.DataBundlesGsApiEndPoint;
                //https://api.transferto.com/v1.1/services/7/products?operator_id=1449&country_id=678
                string serviceUrl = baseUrl + "/services/" + serviceId + "/products?operator_id=" + operatorId + "&country_id=" + countryid + "";
                HttpRequestMessage request = _TransferToAuth.HttpRequestMessage(currency, serviceUrl);

                using (var client = new HttpClient{ Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut) })
                {
                    HttpResponseMessage response = await client.SendAsync(request);
                    string jsonResult = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<TransfertoDataBundleProductList>(jsonResult);

                    if (result != null)
                    {
                        returnResult = GenericApiResponse<TransfertoDataBundleProductList>.Success(result);
                    }
                    else
                    {
                        returnResult = GenericApiResponse<TransfertoDataBundleProductList>.Failure("An error occured.");
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;

        }

        private string FormatStringForAPI(string str)
        {
            if (str == null)
            {
                str = "";

            }
            else
            {
                str = "\"" + str + "\"";
            }

            return str;
        }

        public async Task<GenericApiResponse<TransfertoTranscationDataBundleGSReponse>> transfertoDataBundleTransaction(TransfertoTranscationDataBundleGSRequest data)
        {
            GenericApiResponse<TransfertoTranscationDataBundleGSReponse> returnResult = null;

            try
            {


                string baseUrl = TransferToConf.DataBundlesGsApiEndPoint;
                string serviceUrl = baseUrl + "/transactions/fixed_value_recharges";

                // int rand = DateTime.Now.Millisecond;

                // 1 simulation  0 = live
                int simulation = -1;
                if (TransferToConf.DataBundlesSimulationMode == true)
                    simulation = 1;
                else
                    simulation = 0;

                string jsonData = "{" +
                    "\"account_number\":" + FormatStringForAPI(data.account_number) + "," +
                    "\"product_id\":" + FormatStringForAPI(data.product_id) + "," +
                    "\"external_id\":" + FormatStringForAPI(data.external_id.ToString()) + "," +
                    "\"simulation\":" + FormatStringForAPI(simulation.ToString()) + "," +
                    "\"sender_sms_notification\":" + FormatStringForAPI(data.sender_sms_notification) + "," +
                    "\"sender_sms_text\":" + FormatStringForAPI(data.sender_sms_text) + "," +
                    "\"recipient_sms_notification\":" + FormatStringForAPI(data.recipient_sms_notification) + "," +
                    "\"recipient_sms_text\":" + FormatStringForAPI(data.recipient_sms_text) + "," +

                     "\"sender\":{" +
                    "\"last_name\":" + FormatStringForAPI(data.sender.last_name) + "," +
                    "\"middle_name\":" + FormatStringForAPI(data.sender.middle_name) + "," +
                    "\"first_name\":" + FormatStringForAPI(data.sender.first_name) + "," +
                    "\"email\":" + FormatStringForAPI(data.sender.email) + "," +
                     "\"mobile\":" + FormatStringForAPI(data.sender.mobile) + " " +
                     "}," +


                     "\"recipient\":{" +
                    "\"last_name\":" + FormatStringForAPI(data.recipient.last_name) + "," +
                    "\"middle_name\":" + FormatStringForAPI(data.recipient.middle_name) + "," +
                    "\"first_name\":" + FormatStringForAPI(data.recipient.first_name) + "," +
                    "\"email\":" + FormatStringForAPI(data.recipient.email) + "," +
                     "\"mobile\":" + FormatStringForAPI(data.recipient.mobile) + " " +
                     "}" +

                    "}";

                var content = new StringContent(jsonData, Encoding.UTF8, "application/json");
                HttpRequestMessage request = _TransferToAuth.HttpRequestMessage(data.currency, serviceUrl, HttpMethod.Post, content);

                using (var client = new HttpClient{ Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut) })
                {
                    HttpResponseMessage response = await client.SendAsync(request);
                    string jsonResult = await response.Content.ReadAsStringAsync();

                    var result = JsonConvert.DeserializeObject<TransfertoTranscationDataBundleGSReponse>(jsonResult);

                    if (result != null)
                    {
                        returnResult = GenericApiResponse<TransfertoTranscationDataBundleGSReponse>.Success(result);
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;

        }



        public async Task<GenericApiResponse<TransfertoTranscationDataBundleGSReponse>> transfertoGetDataBundleTransactionByTransactionid(string currency, int transactionid)
        {
            GenericApiResponse<TransfertoTranscationDataBundleGSReponse> returnResult = null;

            try
            {
                string baseUrl = TransferToConf.DataBundlesGsApiEndPoint;
                string serviceUrl = baseUrl + "/transactions/fixed_value_recharges/" + transactionid;
                HttpRequestMessage request = _TransferToAuth.HttpRequestMessage(currency, serviceUrl);

                using (var client = new HttpClient{ Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut) })
                {
                    HttpResponseMessage response = await client.SendAsync(request);
                    string jsonResult = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<TransfertoTranscationDataBundleGSReponse>(jsonResult);

                    if (result != null)
                    {
                        returnResult = GenericApiResponse<TransfertoTranscationDataBundleGSReponse>.Success(result);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;

        }



    }
}
