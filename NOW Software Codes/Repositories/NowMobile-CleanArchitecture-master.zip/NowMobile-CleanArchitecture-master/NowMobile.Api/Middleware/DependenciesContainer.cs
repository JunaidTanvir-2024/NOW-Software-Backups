﻿using Application.Common.Settings;

namespace NowMobile.Api.Middleware;
internal static class DependenciesContainer
{
    internal static IServiceCollection AddMiddlewaresServices(this IServiceCollection services, MiddlewareSettings settings)
    {
        // Request Logging Services
        if (settings.EnableHttpsLogging)
        {
            //services.AddSingleton<RequestLoggingMiddleware>();
            //services.AddScoped<ResponseLoggingMiddleware>();
        }

        // Exception Middleware
        services.AddScoped<ExceptionMiddleware>();

        // Enable Localization middleware
        if (settings.EnableLocalization)
        {
            services.AddSingleton<LocalizationMiddleware>();
        }
        return services;
    }
}