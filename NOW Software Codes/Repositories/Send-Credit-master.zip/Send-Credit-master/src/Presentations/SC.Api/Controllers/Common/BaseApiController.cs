﻿using System.Net;

namespace SC.Api.Controllers.Common;

[Route("api/v{version:apiVersion}/[controller]")]
[ApiController]
public abstract class BaseApiController : ControllerBase
{
    private ISender _mediator = null!;
    protected ISender Mediator => _mediator ??= HttpContext.RequestServices.GetRequiredService<ISender>();

    [ApiExplorerSettings(IgnoreApi = true)]
    [NonAction]
    public IActionResult HandleResponse(object response)
    {
        if (response != null)
        {
            if (response is ErrorResult result)
            {
                var responseData = result.Errors[0];
                return responseData.Code switch
                {
                    AppConstants.StatusCodes.BadRequest => BadRequest(response),
                    AppConstants.StatusCodes.InternalServerError => StatusCode((int)HttpStatusCode.InternalServerError, response),
                    AppConstants.StatusCodes.Unauthorized => Unauthorized(response),
                    AppConstants.StatusCodes.Forbidden => StatusCode((int)HttpStatusCode.Forbidden, response),
                    AppConstants.StatusCodes.NotFound => NotFound(response),
                    _ => BadRequest(response),
                };
            }
            else
            {
                return Ok(response);
            }
        }
        return Ok();
    }
}