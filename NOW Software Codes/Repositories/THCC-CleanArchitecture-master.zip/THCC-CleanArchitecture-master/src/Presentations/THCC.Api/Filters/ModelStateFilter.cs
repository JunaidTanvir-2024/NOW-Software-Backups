using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

using THCC.Application.Models.ResponseWrappers;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Api.Filters;

public class ModelStateFilterAttribute : IActionFilter
{
    public void OnActionExecuting(ActionExecutingContext context)
    {
        if (!context.ModelState.IsValid)
        {
            var errorResult = new ErrorResult();

            foreach (var keyModelStatePair in context.ModelState.Where(x => x.Key != "$" && x.Key != "request"))
            {
                var errors = keyModelStatePair.Value?.Errors;
                if (errors?.Count > 0)
                {
                    foreach (var item in errors)
                    {
                        errorResult.Errors.Add(new ErrorDto()
                        {
                            Code = CustomStatusCode.BadRequest,
                            Message = $"`{keyModelStatePair.Key} : {item.ErrorMessage}`"
                        });
                    }
                }
            }

            context.Result = new JsonResult(errorResult) { StatusCode = 400 };
        }
    }

    public void OnActionExecuted(ActionExecutedContext context)
    {

    }
}
