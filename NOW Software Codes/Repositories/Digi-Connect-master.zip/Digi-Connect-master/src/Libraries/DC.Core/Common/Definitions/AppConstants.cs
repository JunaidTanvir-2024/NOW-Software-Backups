namespace DC.Core.Common.Definitions;

public static class AppConstants
{
    public static class ContentType
    {
        public const string ApplicationJson = "application/json";
        public const string ApplicationOctetStream = "application/octet-stream";
        public const string ApplicationXml = "application/xml";
        public const string XlsxFile = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    }

    public static class Database
    {
        public static class StoreProcedure
        {
            public const string AppLogUpsert = "dbo.fh_app_log_upsert";
            public const string VendorLogInsert = "dbo.fh_vendor_log_insert";
            public const string GetActiveMsisdn = "get_active_msisdn";
            public const string InsertActiveMsisdn = "insert_active_msisdn_log";
            public const string GetSmsContent = "get_sms_content";
            public const string GetActiveMsisdnLog = "get_active_msisdn_log";
            public const string AddSendSMSLog = "insert_send_sms_log";
            public const string GetNewTopUp = "get_new_top_up";
            public const string GetMsisdnWithNoPlan = "get_msisdn_with_no_plan";
        }

        public static class Name
        {
            public const string FusionHub = "FusionHub";
            public const string MessageBroker = "MessageBroker";
            public const string MessageMatrix = "MessageMatrix";
            public const string DigiConnect = "DigiConnect";
        }
    }

    public static class SecurityHeader
    {
        public const string XFrameOptions = "X-FrameOptions";
        public const string XContentTypeOptions = "X-Content-Type-Options";
        public const string ReferrerPolicy = "Referrer-Policy";
        public const string PermissionsPolicy = "Permissions-Policy";
        public const string SameSite = "SameSite";
        public const string XXSSProtection = "X-XSS-Protection";
        public const string ContentPolicy = "ContentPolicy";
    }

    public static class StatusKey
    {
        public const string Success = "Congratulations! Your request was fulfilled successfully.";
        public const string BadRequest = "Whoops! Something went wrong with your request. Please try again.";
        public const string Forbidden = "Sorry, you don't have permission to access this resource.";
        public const string NotFound = "Hmmm, we couldn't find what you're looking for.";
        public const string Unauthorized = "Oops! You need to be authorized to access this resource.";
        public const string InternalServerError = "Whoops! Something went wrong on our end. Please try again later.";

    }

    public static class StatusCode
    {
        // Commonly Used Status Codes
        public const int Success = Microsoft.AspNetCore.Http.StatusCodes.Status200OK;

        public const int BadRequest = Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest;
        public const int Forbidden = Microsoft.AspNetCore.Http.StatusCodes.Status403Forbidden;
        public const int NotFound = Microsoft.AspNetCore.Http.StatusCodes.Status404NotFound;
        public const int Unauthorized = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;
        public const int InternalServerError = Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError;
    }
}
