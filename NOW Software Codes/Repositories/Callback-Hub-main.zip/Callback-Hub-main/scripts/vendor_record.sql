INSERT INTO [dbo].[vendor]
  ([name]
  ,[description]
  )
VALUES
  ('FusionHub',
    'Fusion Hub Digital Value Service')
GO