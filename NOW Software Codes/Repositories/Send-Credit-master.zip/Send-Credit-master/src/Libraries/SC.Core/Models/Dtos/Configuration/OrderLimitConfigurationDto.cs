﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.Dtos.Configuration;
public record OrderLimitConfigurationDto
{
    public long OrderLimitConfigurationId { get; set; }
    public int? Level { get; set; }
    public decimal? GiftCardMaxValue { get; set; }
    public decimal? MobileTopUpMaxValue { get; set; }
    public string? Currency { get; set; }
    public decimal? PerTransactionOrderMaxValue { get; set; }
    public decimal? CustomerPerDayOrderMaxValue { get; set; }
    public int? ProductRepeatedInOrder { get; set; }
}

