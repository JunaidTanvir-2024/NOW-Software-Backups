﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Utilities
{
    public enum LoginTypes
    {
        Google = 1,
        Facebook = 2,
        Instagram = 3,
        Twitter = 4,
        Normal = 5
    }

    public enum UserTokenTypes
    {
        SignUpVerificationToken = 1,
        ForgotPasswordVerificationToken = 2
    }
    public enum AddressTypes
    {
        Billing = 1,
        simOrder = 2
    }
    public enum ProductType
    {
        THAATW = 1
    }

    public enum CheckOutTypes
    {
        TopUp = 1,
        Bundle = 2,
        FastTopup = 3,
        MobileTopup=4
    }

    public enum Currency
    {
        GBP,
        USD,
        EUR
    }

    public enum ApiCallType
    {
        BasicAuth,
        Bearer,
        NoHeader
    }
    public enum ApiStatusCodes
    {
        InvalidNumber = 1,
        UserNotRegistered,
        InternalServerError,
        InvalidPinNumber,
        InvalidToken,
        SignUpFailed,
        DTOneServiceError,
        DenominationsNotAvailable,
        DenominationBlocked,
        OperatorBlocked,
        PaymentServiceError,
        TopupNumberLimitExceed,
        Pending3dSecure,
        TopupAmountLimitExceed,
        DestinationMsisdnOutOfRange,
        InvalidNowtelReferenceOrProduct,
        InsufficientBalance,
        NoAddressFound,
        CustomerNotExist,
        PaymentCreationFailed_Pay360,
        PaymentCreationFailed_PayPal,
        TransactionUnSuccessful,
        DailyLimitExceeded,
        MissingPersonDetails,
        UserAlreadyRegistered,
        RecordNotFound,
        EmailAlreadyVerified,
        VoucherRechargeFailed,
        RatesNotFound,
        BundlePurchasedFailed,
        UserNotAuthorized,
        InvalidBundle,
        BundleLimitExceeded,
        TransferNotAuthorized,
        TransferServiceNotAvailable
    }

    public enum PromotionType
    {
        Discount = 1,
        ExtraBalance = 2
    }
    public enum AudienceType
    {
        All = 1,
        Web = 2,
        Android = 3,
        IOS = 4
    }
    public enum PromotionDependentTypes
    {
        AutoTopup = 1,
        Topup = 2,
        InternationalTopup = 3
    }
    public enum OfferUnitTypes
    {
        Percentage = 1,
        Value = 2
    }
    public enum PaymentMethodTypes
    {
        Card = 1,
        Voucher = 2,
        Paypal = 3,
        AccountBalance = 4
    }
    public enum ThemeMode
    {
        Light = 1,
        Dark = 2
    }
    public enum BundleCategory
    {
        Platinum = 1,
        Gold,
        Silver
    }
    public enum BundleType
    {
        Welcome = 1,
        Monthly,
        PAYG,
        Trial
    }
}
