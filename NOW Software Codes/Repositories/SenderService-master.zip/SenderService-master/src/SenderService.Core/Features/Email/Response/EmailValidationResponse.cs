﻿namespace SenderService.Core.Features.Email.Response;
public class EmailValidationResponse
{
    public string? Email { get; set; }
    public bool IsVerified { get; set; }
}
