﻿using Application.Common.Interfaces.Shared;
using Application.Features.Bundle.Bundle;
using Application.Features.Bundle.Model;
using Application.Features.Bundle.SubscribedBundle;
using Application.Features.Bundle.SubscribedBundle.V3;
using CancelBundleApi.Models.ResponseModels;
using Domain.Entities;
using MediatR;
using Newtonsoft.Json.Linq;

namespace Application.Features.Bundle.TwelveMonthBundle;
public class TwelveMonthBundleRequestHandler : IRequestHandler<TwelveMonthBundleRequest, Result<List<BundleInfo>>>
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly IStringLocalizer<TwelveMonthBundleRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;
    private readonly IUserService _userService;

    public TwelveMonthBundleRequestHandler(IUnitOfWork uow,
        ICommonService commonService,
        IStringLocalizer<TwelveMonthBundleRequestHandler> localizer,
        IMapper mapper,
        ICurrentUser currentUser,
         IUserService userService,
        ISender sender)
    {
        _unitOfWork = uow;
        _commonService = commonService;
        _localizer = localizer;
        _mapper = mapper;
        _userService = userService;
        _currentUser = currentUser;
    }
    public async Task<Result<List<BundleInfo>>> Handle(TwelveMonthBundleRequest request, CancellationToken cancellationToken)
    {
        (bool IsMobileRequest, DeviceType? DeviceType, MediumType MediumType) = _commonService.IsAppRequest();
        bool hasChangePlan = false;
        bool has12MonthFollowPlan = false;
        bool has12MonthsSub = false;
        bool hasAutoRenewAvailable = false;
        if (_currentUser.IsAuthenticated() && !string.IsNullOrEmpty(request.Msisdn))
        {
            request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        }

        var bundlesList = _mapper.Map<List<BundleInfo>>(await _unitOfWork.BundleRepo.GetTwelveMonthBundles(request));
        if (_currentUser.IsAuthenticated() && !string.IsNullOrEmpty(request.Msisdn))
        {
            if (!await _userService.IsUserMsisdn(request.Msisdn))
            {
                return Result<List<BundleInfo>>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            }
            var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
            if (msisdnDetails == null)
            {
                return Result<List<BundleInfo>>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            }

            if (msisdnDetails.AccountId != null)
            {
                var productSummaryResponse = _mapper.Map<List<SubscribedBundleInfo>>(await _unitOfWork.UserRepo.GetSubscribedBundlesV3(msisdnDetails!.AccountId!));
                if (productSummaryResponse != null)
                {
                    var AffiliateSub = productSummaryResponse.FirstOrDefault(x => x.Category == BundleCategory.Affiliate);
                    if (AffiliateSub != null)
                    {
                        var IsFollowedByPlan12MonthContract = await _unitOfWork.UserRepo.IsFollowedByPlan12MonthContract(AffiliateSub.Id.ToString());
                        if (IsFollowedByPlan12MonthContract)
                        {
                            has12MonthFollowPlan = true;
                        }
                    }
                }
            }
            if (IsMobileRequest)
            {
                bundlesList.ForEach(x =>
                {
                    x.ShowChangePlan = true;
                    x.ShowCancelPlan = true;
                });
            }
            var subscribe12MonthBundlesList = _mapper.Map<List<SubscribedBundleInfo>>(await _unitOfWork.UserRepo.GetSubscribedBundlesV3(msisdnDetails.AccountId!)).FirstOrDefault(x => x.Category == BundleCategory.TwelveMonthsContract);
            if (subscribe12MonthBundlesList != null)
            {
                has12MonthsSub = true;
                hasAutoRenewAvailable = subscribe12MonthBundlesList.IsAutoRenew;
                var changePlan = _mapper.Map<SubscribedBundleInfo>(await _unitOfWork.BundleRepo.GetChangePlanBundleByMsisdn(msisdnDetails.Msisdn!));
                DateTime? newBillingDate = null;
                foreach (var item in bundlesList)
                {
                    if (item.UuId.ToString().Trim().ToLower() == subscribe12MonthBundlesList!.Id.ToString().ToLower())
                    {
                        if (IsMobileRequest)
                        {
                            item.ShowChangePlan = false;
                            item.ShowCancelPlan = false;
                        }
                        else
                        {
                            item.ShowChangePlan = true;
                            item.ShowCancelPlan = true;
                        }
                        item.IsSubscribed = true;
                        newBillingDate = Convert.ToDateTime(subscribe12MonthBundlesList.Expiry.ToString("yyyy-MM-ddTHH:mm:ss"));
                        //newBillingDate = Convert.ToDateTime(subscribe12MonthBundlesList.SubscriptionDate.AddMonths((subscribe12MonthBundlesList.GrantedCount == 0 ? 1 : subscribe12MonthBundlesList.GrantedCount)).ToString("yyyy-MM-ddTHH:mm:ss"));
                        item.NewBillingDate = (newBillingDate != null ? Convert.ToDateTime(newBillingDate!.Value.ToString("yyyy-MM-ddTHH:mm:ss")) : null);
                    }

                    if (changePlan != null)
                    {
                        hasChangePlan = true;
                        if (item.UuId.ToString().Trim().ToLower() == changePlan.Id.ToString().ToLower())
                        {
                            item.IsChangePlan = true;
                            item.ShowChangePlan = false;
                            item.ShowCancelPlan = false;
                        }
                    }
                }
                if (newBillingDate != null)
                {
                    var bundle = bundlesList.FirstOrDefault(x => x.IsChangePlan);
                    if (bundle != null)
                    {
                        bundle.NewBillingDate = Convert.ToDateTime(newBillingDate!.Value.ToString("yyyy-MM-ddTHH:mm:ss"));
                    }
                }
            }
        }
        if (has12MonthFollowPlan)
        {
            bundlesList.ForEach(x => x.IsAvailable = false);
        }
        else if (has12MonthsSub && hasAutoRenewAvailable == false && hasChangePlan == false)
        {
            if (IsMobileRequest)
            {
                bundlesList.ForEach(x =>
                {
                    x.IsAvailable = false;
                    x.ShowChangePlan = false;
                    x.ShowCancelPlan = false;
                });
            }
            else
            {
                bundlesList.ForEach(x => x.IsAvailable = false);
            }
        }
        else if (has12MonthsSub && hasChangePlan == false)
        {
            bundlesList.ForEach(x => x.IsAvailable = true);
        }       
        else
        {
            bundlesList.ForEach(x => x.IsAvailable = true);
        }
        if (IsMobileRequest && has12MonthsSub && hasAutoRenewAvailable == true)
        {
            bundlesList.ForEach(x => x.IsAvailable = false);
        }
        return Result<List<BundleInfo>>.Success(bundlesList.OrderBy(e => e.TotalPrice).ToList(), _localizer[CustomStatusKey.Success]);
    }
}
