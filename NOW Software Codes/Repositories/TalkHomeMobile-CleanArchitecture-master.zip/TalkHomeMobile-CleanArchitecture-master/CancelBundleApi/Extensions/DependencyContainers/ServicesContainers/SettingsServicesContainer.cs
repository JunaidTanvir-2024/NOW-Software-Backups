﻿using CancelBundleApi.Settings.Database;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CancelBundleApi.Extensions.DependencyContainers.ServicesContainers;

internal static class SettingsServicesContainer
{
    public static IServiceCollection RegisterSettingsServices(this IServiceCollection services, IConfiguration config)
    {
        services.Configure<DigitalkSettings>(config.GetSection(DigitalkSettings.SectionName));
        return services;
    }
}
