﻿using System.Data;

using Dapper;

using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

using Serilog;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.Dtos;
using THCC.Domain.Aggregates;
using THCC.Domain.Entities;
using THCC.Infrastructure.Persistence.DapperConfigurations;

using static THCC.Domain.Constants.ThccConstants;
using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Persistence.Repositories;

internal class UserRepository : IUserRepository
{
    #region Fields

    private readonly UserManager<User> _userManager;
    private readonly IConfiguration _configuration;
    private readonly ILogger _logger;
    private readonly SemaphoreSlim _asyncLock = new(1, 1);

    #endregion

    #region Ctors

    public UserRepository(
        UserManager<User> userManager,
        IConfiguration configuration,
        ILogger logger)
    {
        _userManager = userManager;
        _configuration = configuration;
        _logger = logger;
    }

    #endregion

    #region Methods

    public async Task<User?> GetUserByEmailAsync(string userEmail)
    {
        return await _userManager.FindByEmailAsync(userEmail);
    }
    public async Task<User?> GetUserByIdAsync(string userId)
    {
        return await _userManager.FindByIdAsync(userId);
    }
    public async Task<IEnumerable<string>> GetUserRoleAsync(User user)
    {
        return await _userManager.GetRolesAsync(user);
    }
    public async Task<(string id, bool isSuccess, IEnumerable<IdentityErrorDto>? errors)> Create(User user, string password)
    {
        var identityResult = new IdentityResult();
        identityResult = !string.IsNullOrEmpty(password)
            ? await _userManager.CreateAsync(user, password) : await _userManager.CreateAsync(user);
        return (user.Id, identityResult.Succeeded, identityResult.Succeeded ? null : identityResult.Errors.Select(e => new IdentityErrorDto(e.Code, e.Description)));
    }
    public async Task<(bool isSuccess, int errorCode, string errorMessage)> CreateProduct(string product, string userId, DateTime dateCreated)
    {
        var p = new DynamicParameters();
        p.Add("@product", product.Trim());
        p.Add("@userId", userId);
        p.Add("@dateCreated", dateCreated);
        p.Add("@errorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
        p.Add("@errorMsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);
        await DapperWrapper.ExecuteAsync(StoredProcedures.AddUserProduct, p, commandType: CommandType.StoredProcedure, connectionString: _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
        int errorCode = p.Get<int>("@errorCode");
        string errorMsg = p.Get<string>("@errorMsg");
        return (isSuccess: errorCode == 0, errorCode, errorMessage: errorMsg);
    }
    public async Task<IdentityResult> UpdatUserAsync(User user, string firstname, string lastname, string password = null!)
    {
        var response = new IdentityResult();
        if (!string.IsNullOrEmpty(firstname) && !string.IsNullOrEmpty(lastname))
        {
            user.FirstName = firstname;
            user.LastName = lastname;
            response = await _userManager.UpdateAsync(user);
        }
        if (!string.IsNullOrEmpty(password))
        {
            response = await _userManager.RemovePasswordAsync(user!);
            if (response.Succeeded)
            {
                response = await _userManager.AddPasswordAsync(user!, password);
            }
        }
        return response;
    }
    public async Task<IdentityResult> UpdateprofileImage(User user, string path)
    {
        user.ProfileImage = path;
        return await _userManager.UpdateAsync(user);

    }
    public async Task<IdentityResult> ConfirmEmailAsync(User user, string token)
    {
        return await _userManager.ConfirmEmailAsync(user, token);
    }
    public async Task<string> GenerateEmailConfirmationTokenAsync(User appUser)
    {
        return await _userManager.GenerateEmailConfirmationTokenAsync(appUser);
    }
    public async Task<string> GeneratePasswordResetTokenAsync(User user)
    {
        return await _userManager.GeneratePasswordResetTokenAsync(user);
    }
    public async Task<bool> IsValidToken(User user, string token, OtpType type)
    {
        string provider = "", purpose = "";

        if (OtpType.ForgotPassword == type)
        {
            purpose = "ResetPassword";
            provider = _userManager.Options.Tokens.PasswordResetTokenProvider;
        }
        else if (OtpType.SignUp == type)
        {
            purpose = "Email-Confirmation";
            provider = _userManager.Options.Tokens.EmailConfirmationTokenProvider;
        }

        return await _userManager.VerifyUserTokenAsync(user, provider, purpose, token);
    }
    public async Task<IdentityResult> PasswordResetAsync(User user, string token, string newPassword)
    {
        return await _userManager.ResetPasswordAsync(user, token, newPassword);
    }
    public async Task UpdateRefreshTokenAsync(string? email, string refreshToken, DateTime refreshTokenExpiryTime)
    {
        _logger.Information($"UpdateRefreshTokenAsync: email {email} refreshToken:{refreshToken}");

        // Enter the lock to ensure mutual exclusion
        await _asyncLock.WaitAsync();
        try
        {
            var user = await _userManager.FindByEmailAsync(email!);
            user!.RefreshToken = refreshToken;
            user.RefreshTokenExpiryTime = refreshTokenExpiryTime;
            await _userManager.UpdateAsync(user);
        }
        finally
        {
            // Release the lock when you're done
            _asyncLock.Release();
        }
    }

    public async Task<UserProduct> GetUserProducts(string userId)
    {
        var parameters = new DynamicParameters();
        parameters.Add("@UserId", userId);
        return await DapperWrapper.QueryFirstOrDefaultAsync<UserProduct>(StoredProcedures.GetUserProduct, parameters, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
    }
    public async Task<AccountDto> GetAccountDetails(string cardnumber)
    {
        var param = new DynamicParameters();
        param.Add("@account", cardnumber);
        return await DapperWrapper.QueryFirstOrDefaultAsync<AccountDto>(StoredProcedures.GetAccountDetails, param, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.BackHome));
    }
    public async Task<LastTopupDto> GetLastTopup(string cardnumber)
    {
        var param = new DynamicParameters();
        param.Add("@account", cardnumber);

        return await DapperWrapper.QueryFirstOrDefaultAsync<LastTopupDto>(StoredProcedures.GetLastTopupInfo, param,
                commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.BackHome));
    }
    public async Task<(int, IList<PaymentDetail>)> PaymentHistory(string userId, int pageNo, int pageSize, int productType)
    {
        var p = new DynamicParameters();
        p.Add("@ProductType", productType);
        p.Add("@PageNumber", pageNo);
        p.Add("@PageSize", pageSize);
        p.Add("@UserId", userId);
        p.Add("@TotalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);
        var paymentHistoryList = (await DapperWrapper.QueryAsync<PaymentDetail>(StoredProcedures.GetTransactionHistory, p,
                commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.DefaultConnection))).ToList();
        int totalCount = p.Get<int>("@TotalCount");
        return (totalCount, paymentHistoryList ?? new List<PaymentDetail>());
    }
    public async Task AddRating(int rating, string userId)
    {
        var parameters = new DynamicParameters();
        parameters.Add("@Rating", rating);
        parameters.Add("@UserId", userId);
        await DapperWrapper.ExecuteAsync(StoredProcedures.CreateUpdateRating, parameters, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));

    }
    public async Task<List<PinDetail>> CallingCardsHistory(string userId)
    {
        var p = new DynamicParameters();
        p.Add("@UserId", userId);
        var callingcardsList = (await DapperWrapper.QueryAsync<PinDetail>(StoredProcedures.GetCallingCardsHistory, p,
                commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.DefaultConnection))).ToList();

        return callingcardsList ?? new List<PinDetail>();
    }
    public async Task<User> GetUserByProduct(string cardNumber)
    {
        var parameters = new DynamicParameters();
        parameters.Add("@CardNumber", cardNumber);
        return await DapperWrapper.QueryFirstOrDefaultAsync<User>(StoredProcedures.GetUserByProduct, parameters, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
    }

    public async Task<bool> IsSocialLoginUser(User user)
    {
        var logins = await _userManager.GetLoginsAsync(user);
        if (logins.Count > 0)
        {
            return true;
        }
        return false;
    }

    #endregion
}
