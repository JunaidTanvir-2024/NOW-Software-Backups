using Microsoft.AspNetCore.Mvc;

using NTCB.Api.Features.DTOne;
using NTCB.Api.Features.DTOne.Models;

namespace NTCB.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CallBackController : ControllerBase
{
    private readonly IDTOneService _dTOneService;

    public CallBackController(IDTOneService dTOneService)
    {
        _dTOneService = dTOneService;
    }

    #region DTOne CallBacks


    [HttpPost, Route("DTOne/Transaction")]
    public async Task<ActionResult> DTOneTransactionAsync([FromBody] CallbackInfo callbackInfo)
    {
        var result = await _dTOneService.UpdateDTOneTransactionRecord(callbackInfo);
        return Ok(result);
    }

    #endregion
}
