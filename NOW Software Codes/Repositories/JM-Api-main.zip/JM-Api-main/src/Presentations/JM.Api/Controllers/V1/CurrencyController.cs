
using JM.Api.Controllers.Common;
using JM.Core.Features.Currency;
using JM.Core.Utilities.Definitions;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using RW.Common;
using RW.Failures;
using RW.Models;
using RW.Successes;

namespace JM.Api.Controllers.V1;
[AllowAnonymous]
public class CurrencyController : V1ApiController
{
    [HttpGet]
    [ProducesResponseType<SuccessPayload<IEnumerable<GetCurrencyList.Response>>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    public async Task<ActionResult> Currency()
    {
        var result = await Mediator.Send(new GetCurrencyList.Query(), HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpGet("id")]
    [ProducesResponseType<SuccessPayload<GetCurrency.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    public async Task<ActionResult> GetCurrency([FromQuery] GetCurrency.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
}
