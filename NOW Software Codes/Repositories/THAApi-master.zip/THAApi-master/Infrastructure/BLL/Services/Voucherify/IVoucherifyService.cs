﻿using Models.Common;
using System.Threading.Tasks;
using Infrastructure.BLL.Services.Voucherify.Models.Vouchers.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Vouchers.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Customers.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Products.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.Products.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Events.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.Events;
using Models.Contracts.Response.Voucherify;
using Infrastructure.BLL.Services.Voucherify.Models.EarningRules.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.EarningRules.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Promotions.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.Promotions.Requests;

namespace Infrastructure.BLL.Services.Voucherify
{
    public interface IVoucherifyService
    {
        Task<ApiResult<CustomerResponse>> CreateVoucherifyCustomer(CreateVoucherifyCustomerRequest request, string uniqueReference);
        Task<ApiResultSet<EarningRuleResponse>> GetCampaignEarningRules(GetEarningRulesRequest request, string uniqueReference);
        Task<ApiResult<CustomerResponse>> GetCustomerBySourceId(GetVoucherifyCustomerRequest request, string uniqueReference);
        Task<ApiResult<PromotionTierResponse>> GetCustomerSpecificPromotionTiers(GetCustomerSpecificPromotionTiersRequest request, string uniqueReference);
        Task<ApiResult<ProductSkusResponse>> GetProductSKU(GetProductSkuRequest request, string uniqueReference);
        Task<ApiResultSet<ProductSkusResponse>> GetProductSKUs(GetProductSkusRequest request, string uniqueReference);
        Task<ApiResult<ReferralCodeResponse>> GetReferralCode(GetReferralCodeRequest request, string uniqueReference);
        Task<ApiResult<InvokedVoucherifyEventResponse>> InvokeVoucherifyEvent(InvokeVoucherifyEventRequest request, string uniqueReference);
        Task<ApiResult<StackableDiscountRedemptionResponse>> RedeemStackableDiscounts(StackableDiscountRedemptionRequest request, string uniqueReference);
        Task<ApiResult<StackableDiscountRollbackResponse>> RollbackStackableDiscounts(StackableDiscountRollbackRequest request, string uniqueReference);
        Task<ApiResult<StackableDiscountValidationResponse>> ValidateStackableDiscounts(StackableDiscountValidationRequest request, string uniqueReference);

        #region Commented Unused Code
        //Task<ApiResult<CustomerLoyaltyCardResponse>> GetCustomerLoyaltyCard(GetVoucherifyCustomerLoyaltyCardRequest request);
        //Task<ApiResult<PromotionTierResponse>> GetPromotionTierById(string promotionTierId);
        //Task<ApiResultSet<CustomerResponse>> GetCustomers(GetVoucherifyCustomersRequest request);
        //Task<ApiResultSet<PromotionTierResponse>> GetPromotionTiers(GetPromotionTiersRequest request);
        //Task<ApiResult<VoucherResponse>> GetVoucher(GetVoucherifyVoucherByCodeRequest request);
        //Task<ApiResultSet<VoucherResponse>> GetVouchers(GetVoucherifyVouchersRequest request);
        //Task<ApiResult<VoucherRedemptionResponse>> RedeemVoucher(RedeemVoucherRequest request);
        //Task<ApiResult<CustomerResponse>> UpdateCustomer(UpdateVoucherifyCustomerRequest request);
        //Task<ApiResult<VoucherValidationResponse>> ValidateVoucher(ValidateVoucherRequest request);
        //Task<bool> DeleteCustomer(DeleteVoucherifyCustomerRequest request);
        //Task<bool> DeleteVoucher(string voucherId);
        //Task<ApiResult<EarningRuleResponse>> GetCampaignEarningRule(GetEarningRuleRequest request);
        //Task<ApiResultSet<EarningRuleResponse>> GetCampaignEarningRules(GetEarningRulesRequest request);
        #endregion
    }
}
