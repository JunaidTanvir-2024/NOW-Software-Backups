-- CREATE DATABASE fusion_hub
-- USE fusion_hub

----------------------------------------------------------------

---------------------------TABLES-------------------------------

----------------------------------------------------------------

-- drop table [dbo].[app_log]
-- drop table [dbo].[currency_unit]
-- drop table [dbo].[operator]
-- drop table [dbo].[product]
-- drop table [dbo].[product_benefit]
-- drop table [dbo].[product_category]
-- drop table [dbo].[product_price]
-- drop table [dbo].[product_subcategory]
-- drop table [dbo].[vendor_data_hash]
-- drop table [dbo].[vendor_log]
-- drop table [dbo].[vendor_operator]
-- drop table [dbo].[product_transaction]
-- drop table [dbo].[vendor_operator]
-- drop table [dbo].[country]
-- drop table [dbo].[vendor]


-- USE [fusion_hub]
-- GO

GO
CREATE TABLE [dbo].[country]
(
    [country_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [iso_code2] [NVARCHAR](2) NULL,
    [iso_code3] [NVARCHAR](3) NULL,
    [calling_code] [SMALLINT] NULL,
    [name] [NVARCHAR](50) NOT NULL,
    [iso_numeric_code] [NVARCHAR](5) NULL,
    [continent] [NVARCHAR](50) NULL,
    [is_active] BIT DEFAULT 1,
    [is_deleted] BIT DEFAULT 0,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    [row_version] ROWVERSION
)

GO
CREATE TABLE [dbo].[vendor]
(
    [vendor_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [name] [NVARCHAR](50) NOT NULL,
    [description] [NVARCHAR](max) NULL,
    [is_active] BIT DEFAULT 1,
    [is_deleted] BIT DEFAULT 0,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    [row_version] ROWVERSION
)

GO
CREATE TABLE [dbo].[app_log]
(
    [app_log_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [request_timestamp] [DATETIME2](7) NULL,
    [request_path] [NVARCHAR](255) NULL,
    [request_method] [NVARCHAR](10) NULL,
    [request_body] [NVARCHAR](2000) NULL,
    [response_body] [NVARCHAR](MAX) NULL,
    [status_code] [INT] NULL,
    [duration] [BIGINT] NULL,
    [client_ip] [NVARCHAR](50) NULL,
    [user_agent] [NVARCHAR](255) NULL,
    [response_size] [BIGINT] NULL,
    [error_reason] [NVARCHAR](1500) NULL,
    [correlation_id] [UNIQUEIDENTIFIER] NOT NULL,
    [headers] [NVARCHAR](3000) NULL,
    [query_string] [NVARCHAR](250) NULL,
    [unique_reference] [NVARCHAR](50) NULL,
    [product_code] [NVARCHAR](15) NULL,
    [product_item_code] [NVARCHAR](30) NULL,
)


GO
CREATE TABLE [dbo].[currency_unit]
(
    [currency_unit_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [code] [NVARCHAR](50) NOT NULL,
    [name] [NVARCHAR](50) NOT NULL,
    [is_default] BIT NOT NULL,
    [is_active] BIT DEFAULT 1,
    [is_deleted] BIT DEFAULT 0,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    [row_version] ROWVERSION
)


GO
CREATE TABLE [dbo].[operator]
(
    [operator_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [name] [NVARCHAR](50) NOT NULL,
    [logo] [NVARCHAR](100) NOT NULL,
    [name_alias] [NVARCHAR](150) NULL,
    [description] [NVARCHAR](max) NULL,
    [country_id] [BIGINT] NOT NULL,
    [is_active] BIT DEFAULT 1,
    [is_deleted] BIT DEFAULT 0,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    [short_code] [NVARCHAR](60) NULL,
    CONSTRAINT [FK_Operator_Country] FOREIGN KEY ([country_id]) REFERENCES [dbo].[country] ([country_id])
)


GO
CREATE TABLE [dbo].[vendor_data_hash]
(
    [vendor_hash_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [batch_hash] [NVARCHAR](500) NOT NULL,
    -- Use an appropriate data type for your hash (e.g., VARCHAR, CHAR)
    [api_type] [NVARCHAR](50) NOT NULL,
    [api_page] [bigint] NOT NULL,
    [vendor_id] [BIGINT] NOT NULL,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    CONSTRAINT [FK_VendorDataHash_Vendor] FOREIGN KEY ([vendor_id]) REFERENCES [dbo].[vendor] ([vendor_id]),
)

GO
CREATE TABLE [vendor_operator]
(
    [vendor_operator_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [name] [NVARCHAR](50) NOT NULL,
    [logo] [NVARCHAR](100) NOT NULL,
    [operator_id] [BIGINT] NOT NULL,
    [vendor_operator_code] [NVARCHAR](50) NOT NULL,
    -- Special Id which will be used to add vendor operator id
    [country_id] [BIGINT] NOT NULL,
    [is_active] BIT DEFAULT 1,
    [is_deleted] BIT DEFAULT 0,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    [row_version] ROWVERSION,
    CONSTRAINT [FK_VendorOperator_Country] FOREIGN KEY ([country_id]) REFERENCES [dbo].[country] ([country_id]),
    CONSTRAINT [FK_VendorOperator_Operator] FOREIGN KEY ([operator_id]) REFERENCES [dbo].[operator] ([operator_id])
)

GO
CREATE TABLE [dbo].[product_category]
(
    [product_category_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [name] [NVARCHAR](50) NOT NULL,
    [alias_name] [NVARCHAR](50) NOT NULL,
    [description] [NVARCHAR](max) NULL,
    [is_active] BIT DEFAULT 1,
    [is_deleted] BIT DEFAULT 0,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    [row_version] ROWVERSION
)

GO
CREATE TABLE [dbo].[product_subcategory]
(
    [product_subcategory_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [name] [NVARCHAR](50) NOT NULL,
    [alias_name] [NVARCHAR](50) NOT NULL,
    [description] [NVARCHAR](max) NULL,
    [is_active] BIT DEFAULT 1,
    [is_deleted] BIT DEFAULT 0,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    [row_version] ROWVERSION,
    [product_category_id] [BIGINT] NULL,
    [short_code] [nvarchar] (60) NULL,
    CONSTRAINT [FK_ProductSubCategory_ProductCategory] FOREIGN KEY ([product_category_id]) REFERENCES [dbo].[product_category] ([product_category_id])
)

GO
CREATE TABLE [dbo].[product_price]
(
    [product_price_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [data_dump_reference] NVARCHAR(55) NOT NULL,
    [price] [DECIMAL](18, 2) NOT NULL,
    [tax] [DECIMAL](18, 2) NOT NULL,
    [fee] [DECIMAL](18, 2) NOT NULL,
    [discount_percentage] [DECIMAL](18, 2) NOT NULL,
    [range_min_price] [DECIMAL](18, 2) NULL,
    [range_max_price] [DECIMAL](18, 2) NULL,
    [effective_from] [DATETIME2](7) NULL,
    [effective_to] [DATETIME2](7) NULL,
    [is_active] BIT DEFAULT 1,
    [is_deleted] BIT DEFAULT 0,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    [row_version] ROWVERSION
)

GO
CREATE TABLE [dbo].[product]
(
    [product_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [name] [NVARCHAR](150) NULL,
    [name_alias] [NVARCHAR](250) NULL,
    [description] [NVARCHAR](max) NULL,
    [operator_id] [BIGINT] NOT NULL,
    [currency_unit_id] [BIGINT] NOT NULL,
    [product_category_id] [BIGINT] NOT NULL,
    [product_subcategory_id] [BIGINT] NOT NULL DEFAULT(1),
    [product_price_id] [BIGINT] NOT NULL,
    [validity_unit] [NVARCHAR](100) NULL,
    [validity_value] [INT] NULL,
    [vendor_product_code] [NVARCHAR](50) NOT NULL,
    -- Special Id which will be used to add vendor product id
    [vendor_operator_code] [NVARCHAR](50) NOT NULL,
    -- Special Id which will be used to add vendor operator id
    [vendor_id] [BIGINT] NOT NULL,
    [product_type] bit,
    -- It will be either fixed or range based. 0 for fix, 1 for range 
    [is_active] BIT DEFAULT 1,
    [is_deleted] BIT DEFAULT 0,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    [row_version] ROWVERSION,
    CONSTRAINT [FK_Product_Operator] FOREIGN KEY ([operator_id]) REFERENCES [dbo].[operator] ([operator_id]),
    CONSTRAINT [FK_Operator_Vendor] FOREIGN KEY ([vendor_id]) REFERENCES [dbo].[vendor] ([vendor_id]),
    CONSTRAINT [FK_Product_ProductPrice] FOREIGN KEY ([product_price_id]) REFERENCES [dbo].[product_price] ([product_price_id]),
    CONSTRAINT [FK_Product_CurrencyUnit] FOREIGN KEY ([currency_unit_id]) REFERENCES [dbo].[currency_unit] ([currency_unit_id]),
    CONSTRAINT [FK_Product_ProductCategory] FOREIGN KEY ([product_category_id]) REFERENCES [dbo].[product_category] ([product_category_id]),
    CONSTRAINT [FK_Product_ProductSubCategory] FOREIGN KEY ([product_subcategory_id]) REFERENCES [dbo].[product_subcategory] ([product_subcategory_id])
)

GO
CREATE TABLE [dbo].[product_benefit]
(
    [product_benefit_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [data_dump_reference] NVARCHAR(55) NOT NULL,
    [description] [NVARCHAR](max) NULL,
    [unit] [NVARCHAR](50) NULL,
    [unit_type] [NVARCHAR](50) NULL,
    [benefit_type] [NVARCHAR](50) NULL,
    [benefit_with_tax] [DECIMAL](18, 2) NULL,
    [benefit_without_tax] [DECIMAL](18, 2) NULL,
    [range_min_benefit_with_tax] [DECIMAL](18, 2) NULL,
    [range_max_benefit_with_tax] [DECIMAL](18, 2) NULL,
    [range_min_benefit_without_tax] [DECIMAL](18, 2) NULL,
    [range_max_benefit_without_tax] [DECIMAL](18, 2) NULL,
    [product_id] [BIGINT] NOT NULL,
    [is_active] BIT DEFAULT 1,
    [is_deleted] BIT DEFAULT 0,
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    CONSTRAINT [FK_Benefit_Product] FOREIGN KEY ([product_id]) REFERENCES [dbo].[product] ([product_id])
)

GO
CREATE TABLE [dbo].[product_transaction]
(
    [transaction_id] [bigint] IDENTITY(1,1) NOT NULL,
    [transaction_reference] [nvarchar](255) NOT NULL,
    [unique_reference] [nvarchar](255) NOT NULL,
    [vendor_product_code] [nvarchar](50) NOT NULL,
    [status] [int] NOT NULL,
    [product_id] [BIGINT],
    [created_at] DATETIME DEFAULT GETUTCDATE(),
    [updated_at] DATETIME DEFAULT GETUTCDATE(),
    [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
    CONSTRAINT [FK_Product_Transaction] FOREIGN KEY ([product_id]) REFERENCES [dbo].[product] ([product_id])
);



GO
CREATE TABLE [dbo].[vendor_log]
(
    [vendor_log_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [request_timestamp] [DATETIME2](7) NULL,
    [request_path] [NVARCHAR](255) NULL,
    [request_method] [NVARCHAR](10) NULL,
    [request_body] [NVARCHAR](1000) NULL,
    [response_body] [NVARCHAR](MAX) NULL,
    [status_code] [INT] NULL,
    [duration] [BIGINT] NULL,
    [response_size] [BIGINT] NULL,
    [error_reason] [NVARCHAR](1000) NULL,
    [correlation_id] [UNIQUEIDENTIFIER] NOT NULL,
    [headers] [NVARCHAR](2000) NULL,
    [query_string] [NVARCHAR](500) NULL,
    [vendor_id] [BIGINT] NOT NULL,
    CONSTRAINT [FK_VendorLog_Vendor] FOREIGN KEY ([vendor_id]) REFERENCES [dbo].[vendor] ([vendor_id])
)



-- Quries to Update Columns AliasNames and ShortCode

            -- For Operator

-- SELECT  TOP 10 * FROM dbo.operator
-- UPDATE dbo.operator
-- SET name_alias  =REPLACE(LOWER(name), ' ', '_')
-- UPDATE dbo.operator
-- SET short_code  =REPLACE(LOWER(name), ' ', '_')



--              For Product

-- SELECT TOP 10 * FROM dbo.product
-- UPDATE dbo.product
-- SET name_alias  =REPLACE(LOWER(name), ' ', '_')



--              For Product-Category

-- SELECT * FROM dbo.product_category
-- UPDATE dbo.product_category
-- SET name_alias  =REPLACE(LOWER(name), ' ', '_')




--              For Product-Sub-Category

-- SELECT * FROM dbo.product_subcategory
-- UPDATE dbo.product_subcategory
-- SET short_code  =REPLACE(LOWER(name), ' ', '_')
--  SET name_alias  =REPLACE(LOWER(name), ' ', '_')



