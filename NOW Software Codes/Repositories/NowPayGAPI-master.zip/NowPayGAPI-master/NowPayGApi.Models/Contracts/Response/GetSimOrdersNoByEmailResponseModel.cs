﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetSimOrdersNoByEmailResponseModel
    {
        public int UserId { get; set; }
        public int NumberOfSimOrders { get; set; }
    }
}
