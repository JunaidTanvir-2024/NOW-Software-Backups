namespace Application.Features.Bundle.AutoRenewal.ExistingCard;

public class AutoRenewalExistingCardRequestValidator : AbstractValidator<AutoRenewalExistingCardRequest>
{
    public AutoRenewalExistingCardRequestValidator(ICommonService commonService)
    {
        // Payment Card properties validation
        RuleFor(p => p.PaymentCardInfo.CardToken).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MaximumLength(100);
        RuleFor(p => p.PaymentCardInfo.SecurityCode).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(3).MaximumLength(4);

        // Bundle auto renewal properties validation
        RuleFor(p => p.Msisdn)
            .Cascade(CascadeMode.Stop)
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid Msisdn");
        RuleFor(p => p.BundleId).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.IsRenewable).Cascade(CascadeMode.Stop).NotNull();
    }
}