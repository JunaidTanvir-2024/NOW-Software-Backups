﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class NewCustomerPaymentResponseModel
    {
        public ThreeDSecureData threeDSecureData { get; set; }
        public BundlePurchaseInfo bundlePurchaseInfo { get; set; }
        public TopupInfo topupInfo { get; set; }
    }

    public class BundlePurchaseInfo
    {
        public string TransactionId { get; set; }
        public string BundleName { get; set; }
        public string BundleAmount { get; set; }
        public string Msisdn { get; set; }
        public string Currency { get; set; }
    }

    public class TopupInfo
    {
        public string TransactionId { get; set; }
        public string TopupAmount { get; set; }
        public string Msisdn { get; set; }
        public string Currency { get; set; }
    }
}
