﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs.Digitalk
{
    public class UserAccountBalance
    {
        public string Currency { get; set; }
        public string Balance { get; set; }
        public int error_code { get; set; }
        public string error_msg { get; set; }
    }
}
