namespace Infrastructure.BLL.Services.Voucherify.Models.EarningRules.Requests
{
    public class GetEarningRuleRequest
    {
        public string CampaignId { get; set; } = null!;
        public string EarningRuleId { get; set; } = null!;
    }
}
