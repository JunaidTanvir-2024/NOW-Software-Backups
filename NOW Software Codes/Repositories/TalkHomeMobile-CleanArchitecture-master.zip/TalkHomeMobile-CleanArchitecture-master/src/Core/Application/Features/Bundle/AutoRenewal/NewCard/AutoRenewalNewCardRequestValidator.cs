namespace Application.Features.Bundle.AutoRenewal.NewCard;

public class AutoRenewalNewCardRequestValidator : AbstractValidator<AutoRenewalNewCardRequest>
{
    public AutoRenewalNewCardRequestValidator(ICommonService commonService)
    {
        // Payment Card properties validation
        RuleFor(p => p.PaymentCardInfo.CardNumber).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MaximumLength(19);
        RuleFor(p => p.PaymentCardInfo.ExpiryMonth).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(2).MaximumLength(2);
        RuleFor(p => p.PaymentCardInfo.ExpiryYear).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(2).MaximumLength(2);
        RuleFor(p => p.PaymentCardInfo.NameOnCard).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.PaymentCardInfo.SecurityCode).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(3).MaximumLength(4);

        // Bundle auto renewal properties validation
        RuleFor(p => p.Msisdn)
            .Cascade(CascadeMode.Stop)
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid Msisdn");
        RuleFor(p => p.BundleId).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.IsAutoRenew).Cascade(CascadeMode.Stop).NotNull();
    }
}
