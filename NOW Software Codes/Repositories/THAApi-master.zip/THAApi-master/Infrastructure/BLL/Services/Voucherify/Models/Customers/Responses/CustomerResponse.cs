﻿using Models.Common;
using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Customers.Responses
{
    public class CustomerResponse
    {
        [JsonPropertyName("sourceId")]
        public string SourceId { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }

        [JsonPropertyName("phone")]
        public string Phone { get; set; }

        [JsonPropertyName("city")]
        public string City { get; set; }

        [JsonPropertyName("state")]
        public string State { get; set; }

        [JsonPropertyName("addressLine1")]
        public string AddressLine1 { get; set; }

        [JsonPropertyName("addressLine2")]
        public string AddressLine2 { get; set; }

        [JsonPropertyName("country")]
        public string Country { get; set; }

        [JsonPropertyName("postalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("points")]
        public int Points { get; set; }
        
        [JsonPropertyName("redeemedPoints")]
        public int RedeemedPoints { get; set; }

        [JsonPropertyName("referredCustomers")]
        public int ReferredCustomers { get; set; }

        [JsonPropertyName("metadata")]
        public Metadata Metadata { get; set; }
        
        [JsonPropertyName("loyaltyCard")]
        public string LoyaltyCard { get; set; }
    }
}
