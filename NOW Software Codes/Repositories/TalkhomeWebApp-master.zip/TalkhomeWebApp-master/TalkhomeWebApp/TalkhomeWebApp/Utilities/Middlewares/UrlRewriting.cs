﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Rewrite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Utilities.Middlewares
{
    public class UrlRewriting
    {
        private readonly RequestDelegate _next;

        public UrlRewriting(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext httpContext)
        {
            return _next(httpContext);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class MyUrlRewritingExtensions
    {
        public static IApplicationBuilder UseUrlRewriting(this IApplicationBuilder builder)
        {
            var options = new RewriteOptions();
            
            options.AddRedirect("^((?i)about-us.jsp(?i)|(?i)about(?i))$", "about-us", (int)HttpStatusCode.MovedPermanently);
            //options.AddRedirect("^((?i)rates.jsp(?i)|(?i)rates(?i))$", "calling-rates", (int)HttpStatusCode.MovedPermanently);
            options.AddRedirect("^((?i)howitworks.jsp(?i))$", "how-it-works", (int)HttpStatusCode.MovedPermanently);
            options.AddRedirect("^((?i)faqs(?i))$", "help/faqs", (int)HttpStatusCode.MovedPermanently);
            options.AddRedirect("^((?i)bundles.jsp(?i))$", "bundles", (int)HttpStatusCode.MovedPermanently);
            options.AddRedirect("^((?i)offers.jsp(?i))$", "/", (int)HttpStatusCode.MovedPermanently);
            options.AddRedirect("^((?i)help.jsp(?i))$", "help/faqs", (int)HttpStatusCode.MovedPermanently);
            //options.AddRedirect("^((?i)download.jsp(?i)|(?i)download(?i))$", "download-app", (int)HttpStatusCode.MovedPermanently);
            options.AddRedirect("^((?i)topup.jsp(?i)|(?i)topup(?i))$", "top-up", (int)HttpStatusCode.MovedPermanently);
            //options.AddRedirect("^((?i)product(?i))$", "why-talkhomeapp", (int)HttpStatusCode.MovedPermanently);
            options.AddRedirect("^((?i)join(?i))$", "join-talkhome", (int)HttpStatusCode.MovedPermanently);
            options.AddRedirect("^((?i)privacy(?i))$", "privacy-policy", (int)HttpStatusCode.MovedPermanently);
            //options.AddRedirect("^((?i)terms(?i))$", "terms-and-conditions", (int)HttpStatusCode.MovedPermanently);

            builder.UseRewriter(options);

            return builder.UseMiddleware<UrlRewriting>();
        }
    }
}

