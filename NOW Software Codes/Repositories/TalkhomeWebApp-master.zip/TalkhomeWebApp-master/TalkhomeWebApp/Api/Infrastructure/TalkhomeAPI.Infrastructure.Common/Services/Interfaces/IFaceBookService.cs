﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Airship;
using TalkhomeAPI.Infrastructure.Common.Services.Models.FaceBook;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface IFaceBookService
    {
        Task HandleTopupEvents(string advertiserID,bool IsSuccess, bool? IsCard, decimal Amount, string currency, string origination,bool IsAutoTopUp);
        Task HandleBundlePurchaseEvents(string advertiserID, string origination, string destination, int BundleType, bool IsSuccess, bool? IsCard, decimal Amount, decimal RemainingBalance, string currency);

        Task HandleIntTopupEvents(string advertiserID, string origination, string destination, bool IsSuccess, bool? IsCard, decimal Amount, decimal RemainingBalance, string currency);
        //Task AddCustomEvent(CustomFbEventsRequest data);
        Task CreateCustomEvent(string advertiserID, List<EventDetailsModel> eventDetails);

    }
}
