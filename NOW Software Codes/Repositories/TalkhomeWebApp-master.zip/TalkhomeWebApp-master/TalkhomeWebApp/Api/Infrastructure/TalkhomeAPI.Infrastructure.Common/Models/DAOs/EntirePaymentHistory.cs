﻿using System;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class EntirePaymentHistory
    {
        public DateTime TransDate { get; set; }
        public decimal Amount { get; set; }
        public string Method { get; set; }
        public string Type { get; set; }
        public string Reference { get; set; }
        public bool Successfull { get; set; }
        public string BundleName { get; set; }
        public string BundleId { get; set; }
        public int BundleType { get; set; }
        public string BundleTypeName { get; set; }
        public int BundleCategory { get; set; }
        public string BundleCategoryName { get; set; }
        public string Msisdn { get; set; }
    }
}
