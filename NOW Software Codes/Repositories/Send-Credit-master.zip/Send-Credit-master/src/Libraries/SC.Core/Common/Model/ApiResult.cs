﻿

using System.Text.Json.Serialization;

namespace SC.Core.Common.Model;
public class ApiResult<T> : BaseApiResult
{
    [JsonPropertyName("payload")]
    public T Payload { get; set; }
}

