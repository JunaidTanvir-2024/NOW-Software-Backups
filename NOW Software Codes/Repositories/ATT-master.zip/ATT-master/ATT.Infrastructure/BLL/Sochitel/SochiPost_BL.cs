﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Net;
using Serilog;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Sochitel.Response;
using ATT.Models.Contracts.Sochitel.Request;
using ATT.Models.Configurations;
using Microsoft.Extensions.Options;

namespace ATT.Infrastructure.BLL.Sochitel
{
    //   This module communicates with backend SochiTel endpoint. It needs Authentication object which is a seperate module injected in this 
    //   module through Autofac.   Each request object is appended Auth object return by SochiTelAuth 

    public class SochiPost_BL : ISochiPost_BL
    {
        private ILogger _loggerExternalAPIExceptions;
        private ILogger _loggerAPIAccess;
        private ISochiTelAuth_BL _SochiTelAuth;
        private SochitelConfig SochitelConf;


        //private string _SOCHITEL_ENDPOINT = ConfigurationManager.AppSettings["Sochitel_APIEndpoint"];

        //  SochiTelAuth is Infrastructure Security module defined in TalkHome.WebServices project
        //  Injected in this controller through AutoFac. Review AutofacConfig.cs in TalkHome.WebServices.App_Start
        public SochiPost_BL(ISochiTelAuth_BL sochiTelAuth, ILogger appLoggers, IOptions<SochitelConfig> sochitelConf)
        {
            _SochiTelAuth = sochiTelAuth;
            _loggerExternalAPIExceptions = appLoggers;
            _loggerAPIAccess = appLoggers;
            SochitelConf = sochitelConf.Value;
        }



        //  This method prepares Http request and send it to SochiTel endpoint. It receives the JSON string
        //  Return type is the JSON in string form
        private async Task<string> postRequestToSochiTelEndPoint(string json)
        {
            HttpClient SochitelHttpClient = new HttpClient();

            SochitelHttpClient.BaseAddress = new Uri(SochitelConf.AttApiEndPoint);

            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

            string returnData = "";
            try
            {
                var httpResponse = await SochitelHttpClient.PostAsync(SochitelConf.AttApiEndPoint, httpContent);

                if (httpResponse.Content != null)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    Exception ex = new Exception($"Sochitel API Call Exception - Empty Contents Received - {json}");
                    throw ex;
                }
            }
            catch (WebException wex)
            {
                _loggerExternalAPIExceptions.Debug($"\"Post  Sochitel API Web Access\"     Failed      Data:{json}     Message:{wex.ToString()}");
                throw wex;
            }
            catch (Exception ex)
            {
                _loggerExternalAPIExceptions.Debug($"\"Post  Sochitel API\"  Failed       Generasl Exception       Data:{json}      Message:{ex.ToString()}");
                throw ex;
            }

            return returnData;
        }




        /*
                Following steps are taken in each Sochitel API call
                
                1.  Prepare the relevent request object.
                2.  Set required parameters 
                3.  Append SochiTel Auth object 
                4.  Call SochiTel endpoint through postJSONToEndPoint function
                5.  Receive JSON in string format
                6.  Review response code.    SochiTel returns 3 status codes.    0 = Successs        1 = Transaction is Pending         2 = Failure      
                7.  Based on status code  prepare the GenericApiResponse with required object.     
                            If operation was successful then extract the Result from JSON and add it in GenericApiResponse
        */



        public async Task<GenericApiResponse<Balance>> getBalance(string Currency)
        {
            // Review API - getBalance selection at bottom which is the sample JSON returned by sochitel 

            GetBalanceRequest JSONRequestObject = new GetBalanceRequest();              // Prepare the request
            JSONRequestObject.auth = _SochiTelAuth.getAuthJSONObject(Currency);        // Add Sochitel Auth credentials 

            GenericApiResponse<Balance> returnResult = null;
            try
            {
                Task<String> HttpSochitelPostService = postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(JSONRequestObject));
                string strResponseJSON = await HttpSochitelPostService;                 // Send request to Sochitel and receive JSON

                if (SochitelConf.JsonResponseLogging == true)
                    _loggerAPIAccess.Information("Get /getBalance " + strResponseJSON);

                JToken json = JObject.Parse(strResponseJSON);

                if (json["status"]["type"].ToObject<int>() == 0)               //API call was success and required information is in result part of JSON
                {
                    returnResult = GenericApiResponse<Balance>.Success(json["result"].ToObject<Balance>());
                }
                else if (json["status"]["type"].ToObject<int>() == 2)          //API call failed. More details about failure are in status type and typeName
                {
                    returnResult = GenericApiResponse<Balance>.Failure(json["status"]["name"].ToObject<string>());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return returnResult;
        }




        public async Task<GenericApiResponse<Dictionary<string, Operator>>> GetOperators(string strCountry, int intlocal, int productType, string currency)
        {
            // Review  API - getOperators  at bottom which is the sample JSON return by this service

            GetOperatorsRequest JSONRequestObject = new GetOperatorsRequest();              // Prepare the request
            JSONRequestObject.auth = _SochiTelAuth.getAuthJSONObject(currency);            // Add Auth credentials to request 
            JSONRequestObject.country = strCountry;                                         // Select Country
            JSONRequestObject.local = intlocal;                                             // 0 = All operators      1 = only local     2 = only non local
            JSONRequestObject.productType = productType;                                    // 1 = Mobile Top Up     2 = Mobile PIN        3 = Bill Payment      4 = Mobile Data

            GenericApiResponse<Dictionary<string, Operator>> returnResult = null;
            try
            {
                Task<String> HttpSochitelPostService = postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(JSONRequestObject));
                string strResponseJSON = await HttpSochitelPostService;                     // Send the request to Sochitel and receive JSON 

                if (SochitelConf .JsonResponseLogging== true)
                    _loggerAPIAccess.Information("Get /GetOperators " + strResponseJSON);

                JToken json = JObject.Parse(strResponseJSON);

                if (json["status"]["type"].ToObject<int>() == 0)               //API call was success and required information is in result part of JSON
                {
                    if (json["result"].Count() == 0)
                        returnResult = GenericApiResponse<Dictionary<string, Operator>>.Failure("No Operators Found");      // API return no products
                    else
                        returnResult = GenericApiResponse<Dictionary<string, Operator>>.Success(json["result"].ToObject<Dictionary<string, Operator>>());
                }
                else if (json["status"]["type"].ToObject<int>() == 2)      //API call failed. More details about failure are in status type and typeName
                {
                    returnResult = GenericApiResponse<Dictionary<string, Operator>>.Failure(json["status"]["name"].ToObject<string>());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return returnResult;
        }




        public async Task<GenericApiResponse<ParseMSISDNResponse>> parseMSISDN(string msisdn, string currency)
        {
            // Review API - getOperatorProducts at bottom which is the sample JSON return by this service

            ParseMSISDNRequest getMSISDNRequest = new ParseMSISDNRequest();
            getMSISDNRequest.msisdn = msisdn;

            GenericApiResponse<ParseMSISDNResponse> returnResult = null;

            try
            {
                getMSISDNRequest.auth = _SochiTelAuth.getAuthJSONObject(currency);
                Task<String> HttpSochitelPostServiceForMSISDN = postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(getMSISDNRequest));
                string strParsedMSISDNResponse = await HttpSochitelPostServiceForMSISDN;

                if (SochitelConf.JsonResponseLogging == true)
                    _loggerAPIAccess.Information("Get /parseMSISDN " + strParsedMSISDNResponse);

                JToken parsedMSISDNJSON = JObject.Parse(strParsedMSISDNResponse);

                if (parsedMSISDNJSON["status"]["type"].ToObject<int>() == 0)
                {
                    returnResult = GenericApiResponse<ParseMSISDNResponse>.Success(parsedMSISDNJSON["result"].ToObject<ParseMSISDNResponse>());
                }
                else if (parsedMSISDNJSON["status"]["type"].ToObject<int>() == 2)          //API call failed. More details about failure are in status type and typeName
                {
                    returnResult = GenericApiResponse<ParseMSISDNResponse>.Failure(parsedMSISDNJSON["status"]["name"].ToObject<string>());
                    //_loggerExternalAPIExceptions.Debug($"\"GET getOperatorProducts\"    Failed   Source:Sochitel API    Error:{parsedMSISDNJSON["status"]["id"]} - {parsedMSISDNJSON["status"]["name"]}  Parameters:msisdn{msisdn}");
                    return returnResult;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return returnResult;
        }







        public async Task<GenericApiResponse<OperatorProducts>> getOperatorProductsOperatorID(string operatorID, string currency)
        {
            GenericApiResponse<OperatorProducts> returnResult = null;

            GetOperatorProductsRequest JSONRequestObject = new GetOperatorProductsRequest();       // Prepare the request 
            JSONRequestObject.auth = _SochiTelAuth.getAuthJSONObject(currency);                    // Add Auth credentials to request
            JSONRequestObject.@operator = operatorID;                     // Select the operator of which products are needed 

            try
            {
                Task<String> HttpSochitelPostService = postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(JSONRequestObject));
                string strResponseJSON = await HttpSochitelPostService;                             // Send request to SochiTel and receive JSON response 

                if (SochitelConf.JsonResponseLogging == true)
                    _loggerAPIAccess.Information("Get /getOperatorProductsOperatorID " + strResponseJSON);

                JToken json = JObject.Parse(strResponseJSON);

                if (json["status"]["type"].ToObject<int>() == 0)               //API call was success and required information is in result part of JSON
                {
                    returnResult = GenericApiResponse<OperatorProducts>.Success(json["result"].ToObject<OperatorProducts>());
                }
                else if (json["status"]["type"].ToObject<int>() == 2)          //API call failed. More details about failure are in status type and typeName
                {
                    returnResult = GenericApiResponse<OperatorProducts>.Failure(json["status"]["name"].ToObject<string>());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return returnResult;
        }


        //Working 
        public async Task<GenericApiResponse<GetTransactionResponse>> getTransaction(string userReference, string userCurrency)
        {           

            try
            {
                GetTransactionRequest JSONRequestObject = new GetTransactionRequest();
                JSONRequestObject.auth = _SochiTelAuth.getAuthJSONObject(userCurrency);
                JSONRequestObject.userReference = userReference;
                GenericApiResponse<GetTransactionResponse> returnResult = new GenericApiResponse<GetTransactionResponse>();
                Task<String> HttpSochitelPostService = postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(JSONRequestObject));
                string strResponseJSON = await HttpSochitelPostService;
                JToken json = JObject.Parse(strResponseJSON);

                if (json["status"]["type"].ToObject<int>() == 0)               //API call was success and required information is in result part of JSON
                {
                    returnResult = GenericApiResponse<GetTransactionResponse>.Success(json["result"].ToObject<GetTransactionResponse>());
                }
                else if (json["status"]["type"].ToObject<int>() == 2)          //API call failed. More details about failure are in status type and typeName
                {
                    returnResult = GenericApiResponse<GetTransactionResponse>.Failure(json["status"]["name"].ToString());
                    _loggerExternalAPIExceptions.Debug($"\"POST getTransaction\"  Failed  Source:Sochitel API  Error:{json["status"]["id"]} - {json["status"]["name"]}      Parameters:userReference-{userReference} , Currency - {userCurrency}");
                }
                return returnResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        

        public async Task<GenericApiResponse<ProductDetails>> GetProduct(int productId, string currency)
        {
            GetProductRequest JSONRequestObject = new GetProductRequest();              // Prepare the request 
            JSONRequestObject.auth = _SochiTelAuth.getAuthJSONObject(currency);        // Add Sochitel Auth object to credentials 
            JSONRequestObject.productId = productId;                                    // Select the product id 

            GenericApiResponse<ProductDetails> returnResult = null;
            try
            {
                Task<String> HttpSochitelPostService = postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(JSONRequestObject));
                string strResponseJSON = await HttpSochitelPostService;                 // Send request to Sochitel and receive JSON response

                JToken json = JObject.Parse(strResponseJSON);

                if (json["status"]["type"].ToObject<int>() == 0)               //API call was success and required information is in result part of JSON
                {
                    returnResult = GenericApiResponse<ProductDetails>.Success(json["result"].ToObject<ProductDetails>());
                }
                else if (json["status"]["type"].ToObject<int>() == 2)          //API call failed. More details about failure are in status type and typeName
                {
                    returnResult = GenericApiResponse<ProductDetails>.Failure();
                    _loggerExternalAPIExceptions.Debug($"\"POST GetProduct\"  Failed  Source:Sochitel API  Error:{json["status"]["id"]} - {json["status"]["name"]}      Parameters:ProductID-{productId}");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;
        }
        

        private string generateUniqueTransactionCode()
        {
            string s = Guid.NewGuid().ToString("N").ToUpper();
            return s.Substring(0, 30);
        }
        

        public async Task<GenericApiResponse<OperatorProducts>> getOperatorProductsMSISDN(string msisdn, string currency)
        {
            // Review API - getOperatorProducts at bottom which is the sample JSON return by this service

            ParseMSISDNRequest ParseMSISDNRequest = new ParseMSISDNRequest();
            ParseMSISDNRequest.msisdn = msisdn;

            GenericApiResponse<OperatorProducts> returnResult = null;

            ParseMSISDNResponse parsedMSISDNJSONResult = null;
            try
            {
                ParseMSISDNRequest.auth = _SochiTelAuth.getAuthJSONObject(currency);
                Task<String> HttpSochitelPostServiceForMSISDN = postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(ParseMSISDNRequest));
                string strParsedMSISDNResponse = await HttpSochitelPostServiceForMSISDN;

                if (SochitelConf.JsonResponseLogging == true)
                    _loggerAPIAccess.Information("Get /parseMSISDN " + strParsedMSISDNResponse);

                JToken parsedMSISDNJSON = JObject.Parse(strParsedMSISDNResponse);

                if (parsedMSISDNJSON["status"]["type"].ToObject<int>() == 0)
                {
                    parsedMSISDNJSONResult = parsedMSISDNJSON["result"].ToObject<ParseMSISDNResponse>();
                }
                else if (parsedMSISDNJSON["status"]["type"].ToObject<int>() == 2)          //API call failed. More details about failure are in status type and typeName
                {
                    returnResult = GenericApiResponse<OperatorProducts>.Failure(parsedMSISDNJSON["status"]["name"].ToObject<string>());
                    return returnResult;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


            try
            {
                if (parsedMSISDNJSONResult.@operator != null)              //in case no operator found then return error message
                {
                    returnResult = await getOperatorProductsOperatorID(parsedMSISDNJSONResult.@operator.id, currency);
                    if (returnResult.Status == 0)
                    {
                        returnResult.Result.CountryName = parsedMSISDNJSONResult.country.name;
                        returnResult.Result.OperatorID = parsedMSISDNJSONResult.@operator.id;
                        returnResult.Result.OperatorName = parsedMSISDNJSONResult.@operator.name;
                        returnResult.Result.OperatorLogo = "https://media.sochitel.com/img/operators/" + parsedMSISDNJSONResult.@operator.brandid + ".png";
                        returnResult.Result.CountryLogo = "https://media.sochitel.com/img/flags/" + parsedMSISDNJSONResult.country.id + ".png";
                    }
                    else if (returnResult.Status == 2)          //API call failed. More details about failure are in status type and typeName
                    {
                        returnResult = GenericApiResponse<OperatorProducts>.Failure(returnResult.Message);
                        return returnResult;
                    }
                }
                else
                {
                    returnResult = GenericApiResponse<OperatorProducts>.Failure("Operator not found");
                    return returnResult;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return returnResult;
        }
        

        public async Task<GenericApiResponse<ExecTransaction>> execTransaction(string fromMsisdn, string toMsisdn, string amount, string currency, string operatorid, string success_sms_quote, string transactionReference)
        {
            /*
                Following informaiton is necessary       operator        msisdn          amount          
                product id can be ommitted but its better to give this information
                
                user currency can be  USD   GBP   EUR

                Following information is not necessary     
                smsText             optional sms that will be send to receiver in case transaction is successful
                userReference       optional transaction reference that will be return by the API
            */

            GenericApiResponse<ExecTransaction> returnResult = null;

            /*ParseMSISDNRequest getMSISDNRequest = new ParseMSISDNRequest();
            getMSISDNRequest.msisdn = toMsisdn;

            ParseMSISDNResponse parsedMSISDNJSONResult = null;
            try
            {
                getMSISDNRequest.auth = _SochiTelAuth.getAuthJSONObject(currency);
                Task<String> HttpSochitelPostServiceForMSISDN = postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(getMSISDNRequest));
                string strParsedMSISDNResponse = await HttpSochitelPostServiceForMSISDN;

                if (ConfigurationManager.AppSettings["Turn_On_JSON_Response_Logging"] == "True")
                    _loggerAPIAccess.Information("Get /parseMSISDN " + strParsedMSISDNResponse);

                JToken parsedMSISDNJSON = JObject.Parse(strParsedMSISDNResponse);

                if (parsedMSISDNJSON["status"]["type"].ToObject<int>() == 0)
                {
                    parsedMSISDNJSONResult = parsedMSISDNJSON["result"].ToObject<ParseMSISDNResponse>();
                }
                else if (parsedMSISDNJSON["status"]["type"].ToObject<int>() == 2)          //API call failed. More details about failure are in status type and typeName
                {
                    returnResult = GenericApiResponse<ExecTransaction>.Failure(parsedMSISDNJSON["status"]["name"].ToObject<string>());
                    _loggerExternalAPIExceptions.Debug($"\"POST executeTransaction\"  Failed  Source:Sochitel API  Error:{parsedMSISDNJSON["status"]["id"]} - {parsedMSISDNJSON["status"]["name"]}    Parameters:fromMsisdn-{fromMsisdn}   toMsisdn-{toMsisdn}    Amount-{amount}   Currency{currency}");
                    return returnResult;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }*/



            //Prepare the request     send to Sochitel backend  and get responses in JSON string
            ExecTransactionRequest JSONRequestObject = new ExecTransactionRequest();
            JSONRequestObject.auth = _SochiTelAuth.getAuthJSONObject(currency);
            //JSONRequestObject.@operator = parsedMSISDNJSONResult.@operator.id;
            JSONRequestObject.@operator = operatorid;
            JSONRequestObject.msisdn = toMsisdn;
            JSONRequestObject.amount = amount;
            

            if (SochitelConf.AttSimulationMode == true)
                JSONRequestObject.simulate = true;
            else
                JSONRequestObject.simulate = false;

            //JSONRequestObject.userReference = generateUniqueTransactionCode();
            JSONRequestObject.userReference = transactionReference;

            JSONRequestObject.smsText = success_sms_quote;

            try
            {
                
                string strResponseJSON = await postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(JSONRequestObject));

                if (SochitelConf.JsonResponseLogging == true)
                    _loggerAPIAccess.Information("Post /execTransaction" + strResponseJSON);

                JToken json = JObject.Parse(strResponseJSON);

                if (json["status"]["type"].ToObject<int>() == 0)               //API call was success and required information is in result part of JSON
                {
                    returnResult = GenericApiResponse<ExecTransaction>.Success(json["result"].ToObject<ExecTransaction>());
                    returnResult.ATTTransactionReference = json["reference"].ToObject<string>();
                    returnResult.APITransactionReference = JSONRequestObject.userReference;
                }
                else if (json["status"]["type"].ToObject<int>() == 2)          //API call failed. More details about failure are in id
                {
                    returnResult = GenericApiResponse<ExecTransaction>.Failure(json["status"]["name"].ToString());
                    returnResult.ATTTransactionReference = json["reference"].ToObject<string>();
                    returnResult.APITransactionReference = JSONRequestObject.userReference;
                }
                else if (json["status"]["type"].ToObject<int>() == 1)      //Operator retuens pending status code
                {
                    returnResult = GenericApiResponse<ExecTransaction>.Pending();
                    returnResult.ATTTransactionReference = json["reference"].ToObject<string>();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;
        }



        public async Task<GenericApiResponse<SMSTransaction>> sendSMS(string MSISDN, string SMSContent, string currency)
        {
            /*
                Following informaiton is necessary       operator        msisdn          amount          
                product id can be ommitted but its better to give this information
                
                user currency can be  USD   GBP   EUR

                Following information is not necessary     
                smsText             optional sms that will be send to receiver in case transaction is successful
                userReference       optional transaction reference that will be return by the API
            */

            GenericApiResponse<SMSTransaction> returnResult = null;

            /*ParseMSISDNRequest getMSISDNRequest = new ParseMSISDNRequest();
            getMSISDNRequest.msisdn = toMsisdn;

            ParseMSISDNResponse parsedMSISDNJSONResult = null;
            try
            {
                getMSISDNRequest.auth = _SochiTelAuth.getAuthJSONObject(currency);
                Task<String> HttpSochitelPostServiceForMSISDN = postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(getMSISDNRequest));
                string strParsedMSISDNResponse = await HttpSochitelPostServiceForMSISDN;

                if (ConfigurationManager.AppSettings["Turn_On_JSON_Response_Logging"] == "True")
                    _loggerAPIAccess.Information("Get /parseMSISDN " + strParsedMSISDNResponse);

                JToken parsedMSISDNJSON = JObject.Parse(strParsedMSISDNResponse);

                if (parsedMSISDNJSON["status"]["type"].ToObject<int>() == 0)
                {
                    parsedMSISDNJSONResult = parsedMSISDNJSON["result"].ToObject<ParseMSISDNResponse>();
                }
                else if (parsedMSISDNJSON["status"]["type"].ToObject<int>() == 2)          //API call failed. More details about failure are in status type and typeName
                {
                    returnResult = GenericApiResponse<ExecTransaction>.Failure(parsedMSISDNJSON["status"]["name"].ToObject<string>());
                    _loggerExternalAPIExceptions.Debug($"\"POST executeTransaction\"  Failed  Source:Sochitel API  Error:{parsedMSISDNJSON["status"]["id"]} - {parsedMSISDNJSON["status"]["name"]}    Parameters:fromMsisdn-{fromMsisdn}   toMsisdn-{toMsisdn}    Amount-{amount}   Currency{currency}");
                    return returnResult;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }*/



            //Prepare the request     send to Sochitel backend  and get responses in JSON string
            SMSRequest JSONRequestObject = new SMSRequest();
            JSONRequestObject.auth = _SochiTelAuth.getAuthJSONObject(currency);
            JSONRequestObject.msisdn = MSISDN;
            JSONRequestObject.smsText = SMSContent;

            /**
            if (SochitelConf.AttSimulationMode == true)
                JSONRequestObject.simulate = true;
            else
                JSONRequestObject.simulate = false; **/

            //JSONRequestObject.userReference = generateUniqueTransactionCode();

            /**
            JSONRequestObject.userReference = transactionReference;

            JSONRequestObject.smsText = success_sms_quote; **/

            try
            {

                string strResponseJSON = await postRequestToSochiTelEndPoint(JsonConvert.SerializeObject(JSONRequestObject));

                if (SochitelConf.JsonResponseLogging == true)
                    _loggerAPIAccess.Information("Post /execTransaction" + strResponseJSON);

                JToken json = JObject.Parse(strResponseJSON);

                if (json["status"]["type"].ToObject<int>() == 0)               //API call was success and required information is in result part of JSON
                {
                    returnResult = GenericApiResponse<SMSTransaction>.Success(json["result"].ToObject<SMSTransaction>());
                    returnResult.ATTTransactionReference = json["reference"].ToObject<string>();
                   //returnResult.APITransactionReference = JSONRequestObject.userReference;
                }
                else if (json["status"]["type"].ToObject<int>() == 2)          //API call failed. More details about failure are in id
                {
                    returnResult = GenericApiResponse<SMSTransaction>.Failure(json["status"]["name"].ToString());
                    returnResult.ATTTransactionReference = json["reference"].ToObject<string>();
                    //returnResult.APITransactionReference = JSONRequestObject.userReference;
                }
                else if (json["status"]["type"].ToObject<int>() == 1)      //Operator retuens pending status code
                {
                    returnResult = GenericApiResponse<SMSTransaction>.Pending();
                    returnResult.ATTTransactionReference = json["reference"].ToObject<string>();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnResult;
        }




    }
}



/*

    ------------------------------------------------------------------------------------------------
    SochiTel API JSON responses section.     This section contain JSON return for each API call
    ------------------------------------------------------------------------------------------------


        API - getBalance
        <Balance>
            <currency>EUR</currency>
            <value>0</value>
        </Balance>





        API - getOperators


                        {
                          "status": {
                            "id": 0,
                            "name": "Successful",
                            "type": 0,
                            "typeName": "Success"
                          },
                          "command": "getOperators",
                          "timestamp": 1497632911,
                          "reference": 1334721867,
                          "result": {
                            "175": {
                              "id": "175",
                              "name": "Pakistan Mobilink",
                              "brandId": "74",
                              "productType": {
                                "id": "1",
                                "name": "Mobile Top Up"
                              },
                              "productTypes": [
                                "1"
                              ],
                              "currency": "PKR",
                              "locations": [
                                "3"
                              ],
                              "prefixes": [
                                "9230",
                                "9235"
                              ],
                              "country": {
                                "id": "PK",
                                "name": "Pakistan",
                                "prefixes": [
                                  "92"
                                ],
                                "operatorPrefixes": [
                                  "9230",
                                  "9231",
                                  "9232",
                                  "9233",
                                  "9234",
                                  "9235",
                                  "9236",
                                  "9237",
                                  "9238",
                                  "9239"
                                ],
                                "msisdnLength": {
                                  "min": "12",
                                  "max": "12"
                                }
                              }
                            },
                            "176": {
                              "id": "176",
                              "name": "Pakistan Telenor",
                              "brandId": "114",
                              "productType": {
                                "id": "1",
                                "name": "Mobile Top Up"
                              },
                              "productTypes": [
                                "1"
                              ],
                              "currency": "PKR",
                              "locations": [
                                "3"
                              ],
                              "prefixes": [
                                "9234",
                                "9236"
                              ],
                              "country": {
                                "id": "PK",
                                "name": "Pakistan",
                                "prefixes": [
                                  "92"
                                ],
                                "operatorPrefixes": [
                                  "9230",
                                  "9231",
                                  "9232",
                                  "9233",
                                  "9234",
                                  "9235",
                                  "9236",
                                  "9237",
                                  "9238",
                                  "9239"
                                ],
                                "msisdnLength": {
                                  "min": "12",
                                  "max": "12"
                                }
                              }
                            },
                            "177": {
                              "id": "177",
                              "name": "Pakistan Ufone",
                              "brandId": "126",
                              "productType": {
                                "id": "1",
                                "name": "Mobile Top Up"
                              },
                              "productTypes": [
                                "1"
                              ],
                              "currency": "PKR",
                              "locations": [
                                "3"
                              ],
                              "prefixes": [
                                "9233",
                                "9237"
                              ],
                              "country": {
                                "id": "PK",
                                "name": "Pakistan",
                                "prefixes": [
                                  "92"
                                ],
                                "operatorPrefixes": [
                                  "9230",
                                  "9231",
                                  "9232",
                                  "9233",
                                  "9234",
                                  "9235",
                                  "9236",
                                  "9237",
                                  "9238",
                                  "9239"
                                ],
                                "msisdnLength": {
                                  "min": "12",
                                  "max": "12"
                                }
                              }
                            },
                            "178": {
                              "id": "178",
                              "name": "Pakistan Warid",
                              "brandId": "144",
                              "productType": {
                                "id": "1",
                                "name": "Mobile Top Up"
                              },
                              "productTypes": [
                                "1"
                              ],
                              "currency": "PKR",
                              "locations": [
                                "3"
                              ],
                              "prefixes": [
                                "9232",
                                "9238"
                              ],
                              "country": {
                                "id": "PK",
                                "name": "Pakistan",
                                "prefixes": [
                                  "92"
                                ],
                                "operatorPrefixes": [
                                  "9230",
                                  "9231",
                                  "9232",
                                  "9233",
                                  "9234",
                                  "9235",
                                  "9236",
                                  "9237",
                                  "9238",
                                  "9239"
                                ],
                                "msisdnLength": {
                                  "min": "12",
                                  "max": "12"
                                }
                              }
                            },
                            "179": {
                              "id": "179",
                              "name": "Pakistan ZONG",
                              "brandId": "151",
                              "productType": {
                                "id": "1",
                                "name": "Mobile Top Up"
                              },
                              "productTypes": [
                                "1"
                              ],
                              "currency": "PKR",
                              "locations": [
                                "3"
                              ],
                              "prefixes": [
                                "9231",
                                "9239"
                              ],
                              "country": {
                                "id": "PK",
                                "name": "Pakistan",
                                "prefixes": [
                                  "92"
                                ],
                                "operatorPrefixes": [
                                  "9230",
                                  "9231",
                                  "9232",
                                  "9233",
                                  "9234",
                                  "9235",
                                  "9236",
                                  "9237",
                                  "9238",
                                  "9239"
                                ],
                                "msisdnLength": {
                                  "min": "12",
                                  "max": "12"
                                }
                              }
                            }
                          }
                        }            







        API - getOperatorProducts

                {
	                "status": {
		                "id": 0,
		                "name": "Successful",
		                "type": 0,
		                "typeName": "Success"
	                },
	                "command": "getOperatorProducts",
	                "timestamp": 1497681246,
	                "reference": 953460070,
	                "result": {
		                "type": {
			                "id": "1",
			                "name": "Mobile Top Up"
		                },
		                "productTypes": ["1"],
		                "products": {
			                "3051": {
				                "id": "3051",
				                "productType": {
					                "id": "1",
					                "name": "Mobile Top Up"
				                },
				                "priceType": "range",
				                "name": "50-5000PKR Top Up",
				                "price": {
					                "min": {
						                "operator": "50.00",
						                "user": "0.46"
					                },
					                "max": {
						                "operator": "5000.00",
						                "user": "45.03"
					                }
				                }
			                }
		                },
		                "currency": {
			                "user": "EUR",
			                "operator": "PKR"
		                }
	                }
                }                








        API - getOperatoProducts

        <ProductDetails">

            <currency>
                <operator>PKR</operator>
                <user>EUR</user>
            </currency>

            <operator>
                <id>175</id>
                <name>Pakistan Mobilink</name>
            </operator>

            <product>
                <id>3051</id>
                
                <name>50-5000PKR Top Up</name>
                
                <price>
                    <max>
                        <operator>5000.00</operator>
                        <user>45.03</user>
                    </max>
                    <min>
                        <operator>50.00</operator>
                        <user>0.46</user>
                    </min>
                </price>

                <priceType>range</priceType>

                <productType>
                    <id>1</id>
                    <name>Mobile Top Up</name>
                </productType>
            </product>

        </ProductDetails>






*/
