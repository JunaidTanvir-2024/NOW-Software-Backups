using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;


namespace JM.Core.Features.Auth.Expense;

public abstract class RemoveExpense
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long Id { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IMediator _mediator = mediator;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            _unitOfWork.ExpenseRepository.RemoveExpenseCategory(new Entities.ExpenseCategory()
            {
                Id = query.Id
            });
            _unitOfWork.SaveChanges();

            return await ValueTask.FromResult(ResultWrapper.Success(AppConstant.StatusKey.Success, AppConstant.StatusCode.Success));
        }
    }
    #endregion
}
