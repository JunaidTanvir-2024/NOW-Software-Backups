﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Products.Requests
{
    public class GetProductSkuRequest
    {
        public string SkuNameOrId { get; set; }
    }
}
