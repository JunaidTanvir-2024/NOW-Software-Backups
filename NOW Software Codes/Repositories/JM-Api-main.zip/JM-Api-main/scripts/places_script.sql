-- Place 1
INSERT INTO "jm"."Place" ("Name", "Description", "Latitude", "Longitude", "Type", "ImageUrl", "IsActive", "IsDeleted", "CreatedAt")
VALUES ('Place 1', 'Description for Place 1', 40.7128, -74.0060, 'Park', 'https://example.com/image1.jpg', true, false, now());

-- Place 2
INSERT INTO "jm"."Place" ("Name", "Description", "Latitude", "Longitude", "Type", "ImageUrl", "IsActive", "IsDeleted", "CreatedAt")
VALUES ('Place 2', 'Description for Place 2', 34.0522, -118.2437, 'Museum', 'https://example.com/image2.jpg', true, false, now());

-- Place 3
INSERT INTO "jm"."Place" ("Name", "Description", "Latitude", "Longitude", "Type", "ImageUrl", "IsActive", "IsDeleted",  "CreatedAt")
VALUES ('Place 3', 'Description for Place 3', 51.5074, -0.1278, 'Restaurant', 'https://example.com/image3.jpg', true, false, now());

-- Place 4
INSERT INTO "jm"."Place" ("Name", "Description", "Latitude", "Longitude", "Type", "ImageUrl", "IsActive", "IsDeleted", "CreatedAt")
VALUES ('Place 4', 'Description for Place 4', -33.8688, 151.2093, 'Beach', 'https://example.com/image4.jpg', true, false, now());

-- Place 5
INSERT INTO "jm"."Place" ("Name", "Description", "Latitude", "Longitude", "Type", "ImageUrl", "IsActive", "IsDeleted", "CreatedAt")
VALUES ('Place 5', 'Description for Place 5', 35.6895, 139.6917, 'Landmark', 'https://example.com/image5.jpg', true, false, now());
