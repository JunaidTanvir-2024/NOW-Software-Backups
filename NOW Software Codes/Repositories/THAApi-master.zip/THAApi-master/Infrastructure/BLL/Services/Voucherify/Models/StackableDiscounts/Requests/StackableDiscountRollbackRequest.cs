﻿namespace Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Requests
{
    public class StackableDiscountRollbackRequest
    {
        public string RedemptionId { get; set; }
    }
}
