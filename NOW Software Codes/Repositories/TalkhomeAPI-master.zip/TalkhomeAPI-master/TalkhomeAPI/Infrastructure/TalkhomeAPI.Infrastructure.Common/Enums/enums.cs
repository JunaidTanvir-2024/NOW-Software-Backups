﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeAPI.Enums
{
    public enum Fullfillmenttype
    {
        Pay360 = 1,
        Pay360Paypal = 2,
        DirectPaypal = 3
    }
    public enum CheckOutTypes
    {
        TopUp = 1,
        Bundle = 2,
        DirectTransfer = 3
    }

    public enum Currency
    {
        GBP,
        USD,
        EUR,
        PKR
    }

    public enum ProductCode
    {
        THA
    }

    public enum ApiStatusCodes
    {
        InvalidNumber = 1,
        UserNotRegistered,
        InternalServerError,
        InvalidPinNumber,
        InvalidToken,
        SignUpFailed,
        DTOneServiceError,
        DenominationsNotAvailable,
        DenominationBlocked,
        OperatorBlocked,
        PaymentServiceError,
        TopupNumberLimitExceed,
        Pending3dSecure,
        TopupAmountLimitExceed,
        DestinationMsisdnOutOfRange,
        InvalidNowtelReferenceOrProduct,
        InsufficientBalance,
        NoAddressFound,
        CustomerNotExist,
        PaymentCreationFailed_Pay360,
        PaymentCreationFailed_PayPal,
        TransactionUnSuccessful,
        DailyLimitExceeded,
        MissingPersonDetails,
        UserAlreadyRegistered,
        RecordNotFound,
        EmailAlreadyVerified,
        VoucherRechargeFailed,
        RatesNotFound,
        BundlePurchasedFailed,
        UserNotAuthorized,
        InvalidBundle,
        BundleLimitExceeded,
        TransferNotAuthorized
    }

    public enum ATTStatusCodes
    {
        DenominationsNotAvailable = 301,
        DenominationBlocked = 310,
        OperatorBlocked = 311,
        TopupNumberLimitExceed = 230,
        TopupAmountLimitExceed = 231,
        DestinationMsisdnOutOfRange = 101
    }

    public enum PaymentType
    {
        Paypal = 1,
        Card = 2,
        Voucher = 3,
        AccountBalance = 4
    }

    public enum TransferTransactionStatus
    {
        Success = 1,
        Failure = 2,
        Pending = 3
    }
    public enum ProductItemCode
    {
        THAATW,
        THADTW
    }

    public enum PaymentStatusCode
    {

    }

    public enum TransferValidationResponse
    {
        Valid = 0,
        DailyLimitExceeded = 1,
        Unauthorized = 2
    }

    public enum PayPalPaymentType
    {
        Direct,
        ViaPay360
    }

    public enum SmsTypeId
    {
        Login = 1,
        Resend
    }

    public enum PromotionType
    {
        Discount = 1,
        ExtraBalance = 2
    }
    public enum AudienceType
    {
        All = 1,
        Web = 2,
        Android = 3,
        IOS = 4
    }
    public enum PromotionDependentTypes
    {
        AutoTopup = 1,
        Topup = 2,
        InternationalTopup = 3
    }
    public enum OfferUnitTypes
    {
        Percentage = 1,
        Value = 2
    }
    public enum PaymentMethodTypes
    {
        Card = 1,
        Voucher = 2,
        Paypal = 3,
        AccountBalance = 4
    }
}
