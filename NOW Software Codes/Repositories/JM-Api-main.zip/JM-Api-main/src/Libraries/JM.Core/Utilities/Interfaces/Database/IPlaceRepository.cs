using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;

public interface IPlaceRepository : ResolveAs.IScoped
{
	Task<Place> AddPlace(Place place);
	void UpdatePlace(Place place);
	Task<Place?> GetPlace(Expression<Func<Place, bool>> expression);
	Task<IEnumerable<TripPlace>> GetPlaceList(Expression<Func<TripPlace, bool>> expression = default!);
	Task<IEnumerable<Place>> GetPlaceList(Expression<Func<Place, bool>> expression = default!);
}
