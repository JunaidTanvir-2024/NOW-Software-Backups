﻿using BasketWebPanel.Areas.Dashboard.Models;
using BasketWebPanel.Areas.Dashboard.Models.ApiRequest.Admin;
using BasketWebPanel.Areas.Dashboard.Models.ApiResponse.Admin;
using BasketWebPanel.BindingModels;
using BasketWebPanel.ViewModels;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using static BasketWebPanel.Utility;

namespace BasketWebPanel.Areas.Dashboard.Controllers
{
    [Authorize]
    public class AdminController : Controller
    {
        //[HttpPost]
        //public JsonResult DeleteImageOnEdit()
        //{
        //    return Json("Success");
        //}

        //[HttpPost]
        //public JsonResult UploadImage(HttpPostedFileBase file)
        //{
        //    if (Request.Files.Count == 1)
        //    {
        //        Request.RequestContext.HttpContext.Session.Remove("AddAdminImage");
        //        Request.RequestContext.HttpContext.Session.Add("AddAdminImage", Request.Files[0]);

        //        Request.RequestContext.HttpContext.Session.Remove("ImageDeletedOnEdit");
        //        Request.RequestContext.HttpContext.Session.Add("ImageDeletedOnEdit", false);
        //    }
        //    return Json("Success");
        //}

        //[HttpPost]
        //public JsonResult DeleteImage()
        //{
        //    Request.RequestContext.HttpContext.Session.Remove("AddAdminImage");
        //    Request.RequestContext.HttpContext.Session.Add("ImageDeletedOnEdit", true);
        //    return Json("Session Cleared");
        //}

        //public ActionResult Index(int? AdminId)
        //{
        //    Request.RequestContext.HttpContext.Session.Remove("AddAdminImage");
        //    Request.RequestContext.HttpContext.Session.Remove("ImageDeletedOnEdit");
        //    AddAdminViewModel model = new AddAdminViewModel();

        //    model.StoreOptions = Utility.GetStoresOptions(User);
        //    model.SetSharedData(User);

        //    if (model.Role == BasketWebPanel.Utility.RoleTypes.SubAdmin)
        //    {
        //        AdminId = model.Id;
        //    }

        //    if (AdminId.HasValue)
        //    {
        //        var responseAdmin = AsyncHelpers.RunSync<JObject>(() => ApiCall.CallApi("api/GetEntityById", User, null, true, false, null, "EntityType=" + (int)BasketEntityTypes.Admin, "Id=" + AdminId.Value));
        //        if (responseAdmin == null || responseAdmin is Error)
        //            ;
        //        else
        //        {
        //            model.Admin = responseAdmin.GetValue("Result").ToObject<AdminViewModel>();
        //        }
        //    }


        //    model.RoleOptions = new SelectList(
        //        new List<SelectListItem> {
        //            new SelectListItem { Text = Utility.RoleTypes.SubAdmin.ToString(), Value = Utility.RoleTypes.SubAdmin.ToString("D") },
        //            new SelectListItem { Text = Utility.RoleTypes.SuperAdmin.ToString(), Value = Utility.RoleTypes.SuperAdmin.ToString("D") }
        //        });


        //    return View(model);
        //}

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<ActionResult> Index(AddAdminViewModel model)
        //{
        //    model.SetSharedData(User);

        //    if (model.Admin.Id == 0)
        //    {
        //        if (!ModelState.IsValid)
        //        {
        //            return View(model);
        //        }
        //    }


        //    MultipartFormDataContent content;

        //    bool FileAttached = (Request.RequestContext.HttpContext.Session["AddAdminImage"] != null);
        //    bool ImageDeletedOnEdit = false;
        //    var imgDeleteSessionValue = Request.RequestContext.HttpContext.Session["ImageDeletedOnEdit"];
        //    if (imgDeleteSessionValue != null)
        //    {
        //        ImageDeletedOnEdit = Convert.ToBoolean(imgDeleteSessionValue);
        //    }
        //    byte[] fileData = null;
        //    var ImageFile = (HttpPostedFileWrapper)Request.RequestContext.HttpContext.Session["AddAdminImage"];
        //    if (FileAttached)
        //    {
        //        using (var binaryReader = new BinaryReader(ImageFile.InputStream))
        //        {

        //            fileData = binaryReader.ReadBytes(ImageFile.ContentLength);
        //        }
        //    }

        //    ByteArrayContent fileContent;
        //    JObject response;

        //    bool firstCall = true;
        //callAgain: content = new MultipartFormDataContent();
        //    if (FileAttached)
        //    {
        //        fileContent = new ByteArrayContent(fileData);
        //        fileContent.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment") { FileName = ImageFile.FileName };
        //        content.Add(fileContent);
        //    }

        //    if (model.Admin.Id > 0)
        //        content.Add(new StringContent(model.Admin.Id.ToString()), "Id");

        //    if (model.Admin.Store_Id.HasValue)
        //        content.Add(new StringContent(model.Admin.Store_Id.Value.ToString()), "Store_Id");

        //    content.Add(new StringContent(model.Admin.FirstName), "FirstName");
        //    content.Add(new StringContent(model.Admin.LastName), "LastName");
        //    content.Add(new StringContent(model.Admin.Email), "Email");
        //    content.Add(new StringContent(model.Admin.Phone), "Phone");

        //    content.Add(new StringContent(model.Admin.Role.ToString()), "Role");


        //    if (model.Admin.Id == 0)
        //        content.Add(new StringContent(model.Admin.Password), "Password");

        //    content.Add(new StringContent(Convert.ToString(ImageDeletedOnEdit)), "ImageDeletedOnEdit");
        //    response = await ApiCall.CallApi("api/Admin/AddAdmin", User, isMultipart: true, multipartContent: content);

        //    if (firstCall && response.ToString().Contains("UnAuthorized"))
        //    {
        //        firstCall = false;
        //        goto callAgain;
        //    }
        //    else if (response.ToString().Contains("UnAuthorized"))
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, "UnAuthorized Error");
        //    }

        //    if (response is Error)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
        //    }
        //    else
        //    {
        //        model.Admin = response.GetValue("Result").ToObject<AdminViewModel>();
        //        var claimIdentity = ((ClaimsIdentity)User.Identity);
        //        if (model.Admin.Id == Convert.ToInt32(claimIdentity.Claims.FirstOrDefault(x => x.Type == "AdminId").Value))
        //        {
        //            User.AddUpdateClaim("FullName", model.Admin.FirstName + " " + model.Admin.LastName);
        //            User.AddUpdateClaim("ProfilePictureUrl", model.Admin.ImageUrl);
        //        }
        //        model.SetSharedData(User);

        //        if (model.Role == RoleTypes.SuperAdmin)
        //        {
        //            if (model.Admin.Id > 0)
        //                TempData["SuccessMessage"] = "The admin has been updated successfully.";
        //            else
        //                TempData["SuccessMessage"] = "The admin has been added successfully.";
        //        }
        //        else
        //        {
        //            TempData["SuccessMessage"] = "Your profile has been updated successfully.";
        //        }

        //        return Json(new { success = true, responseText = "Success" }, JsonRequestBehavior.AllowGet);
        //        //return RedirectToAction("Index");
        //    }
        //}

        //public ActionResult ManageAdmins()
        //{
        //    Global.sharedDataModel.SetSharedData(User);
        //    return View(Global.sharedDataModel);
        //}

        //public ActionResult SearchAdmin()
        //{
        //    SearchAdminModel returnModel = new SearchAdminModel();

        //    var responseStores = AsyncHelpers.RunSync<JObject>(() => ApiCall.CallApi("api/GetAllStores", User, GetRequest: true));
        //    if (responseStores == null || responseStores is Error)
        //    {
        //    }
        //    else
        //    {
        //        var Stores = responseStores.GetValue("Result").ToObject<List<StoreBindingModel>>();
        //        IEnumerable<SelectListItem> selectList = from store in Stores
        //                                                 select new SelectListItem
        //                                                 {
        //                                                     Selected = false,
        //                                                     Text = store.Name,
        //                                                     Value = store.Id.ToString()
        //                                                 };
        //        Stores.Insert(0, new StoreBindingModel { Id = 0, Name = "All" });

        //        returnModel.StoreOptions = new SelectList(selectList);
        //    }
        //    return PartialView("_SearchAdmin", returnModel);
        //}

        //public ActionResult SearchAdminResults(SearchAdminModel model)
        //{
        //    SearchAdminsViewModel returnModel = new SearchAdminsViewModel();
        //    var response = AsyncHelpers.RunSync<JObject>(() => ApiCall.CallApi("api/Admin/SearchAdmins", User, null, true, false, null, "FirstName=" + model.FirstName + "", "LastName=" + model.LastName, "Email=" + model.Email, "Phone=" + model.Phone, "StoreId=" + model.StoreId));
        //    if (response is Error)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
        //    }
        //    else
        //    {
        //        returnModel = response.GetValue("Result").ToObject<SearchAdminsViewModel>();
        //    }
        //    foreach (var admin in returnModel.Admins)
        //    {
        //        admin.RoleName = ((RoleTypes)admin.Role).ToString();
        //    }
        //    returnModel.SetSharedData(User);
        //    return PartialView("_SearchAdminResults", returnModel);
        //}

        //public JsonResult DeleteAdmin(int AdminId)
        //{
        //    try
        //    {
        //        var response = AsyncHelpers.RunSync<JObject>(() => ApiCall.CallApi("api/Admin/DeleteEntity", User, null, true, false, null, "EntityType=" + (int)BasketEntityTypes.Admin, "Id=" + AdminId));
        //        if (response is Error)
        //            return Json("An error has occurred, error code : 500", JsonRequestBehavior.AllowGet);
        //        else
        //            return Json("Success", JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw;
        //    }
        //}

        //public ActionResult ManageEarnings()
        //{
        //    EarningStatisticsViewModel returnModel = new EarningStatisticsViewModel();

        //    //var responseAdmin = AsyncHelpers.RunSync<JObject>(() => ApiCall.CallApi("api/Admin/GetEarningStatistics", User, null, true, false, null));
        //    //if (responseAdmin == null || responseAdmin is Error)
        //    //    ;
        //    //else
        //    //{
        //    //    returnModel.PaymentMethodOptions = Utility.GetPaymentMethodOptions("All");
        //    //    model.Admin = responseAdmin.GetValue("Result").ToObject<AdminViewModel>();
        //    //}

        //    //returnModel.PaymentMethodOptions = Utility.GetPaymentMethodOptions("All");
        //    returnModel.SetSharedData(User);
        //    return View("ManageEarnings", returnModel);
        //}

        //public ActionResult EarningsStatistics()
        //{
        //    EarningStatisticsViewModel returnModel = new EarningStatisticsViewModel();

        //    var startOfMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
        //    returnModel.StartDate = startOfMonth.ToString("dd/MM/yyyy");
        //    returnModel.EndDate = DateTime.Now.ToString("dd/MM/yyyy");

        //    returnModel.SetSharedData(User);
        //    //Providing CategoryList
        //    returnModel.Categories = Utility.GetAllCategoryOptions(User, "All");

        //    returnModel.PaymentMethodOptions = Utility.GetPaymentMethodOptions("All");

        //    return PartialView("_EarningsStatistics", returnModel);
        //}

        //public ActionResult SearchEarningResults(int? CategoryId, int? PaymentMethod, DateTime? StartDate, DateTime? EndDate)
        //{
        //    var response = AsyncHelpers.RunSync<JObject>(() => ApiCall.CallApi("api/Admin/GetEarningStatistics", User, null, true, false, null, "CategoryId=" + CategoryId + "&PaymentMethod=" + PaymentMethod + "&StartDate=" + StartDate + "&EndDate=" + EndDate));

        //    //EarningStatisticsViewModel returnView = new EarningStatisticsViewModel();
        //    EarninigsListViewModel returnView = new EarninigsListViewModel();

        //    if (response is Error)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
        //    }
        //    else
        //    {
        //        returnView = response.GetValue("Result").ToObject<EarninigsListViewModel>();
        //        foreach (var stat in returnView.Statistics)
        //        {
        //            stat.PaymentMethodName = Utility.GetPaymentMethodName(stat.PaymentMethod);

        //        }
        //    }



        //    returnView.SetSharedData(User);
        //    return PartialView("_SearchEarningResults", returnView);
        //}


        #region Register_Admins

        [HttpGet]
        public ActionResult RegisterAdmin(int id = 0)
        {
            if (id == 0)
            {
                var model = new BasketWebPanel.Areas.Dashboard.ViewModels.AdminViewModel();
                model.SetSharedData(User);

                return View(model);
            }
            else
            {
                return View(new BasketWebPanel.Areas.Dashboard.ViewModels.AdminViewModel());
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> RegisterAdmin(BasketWebPanel.Areas.Dashboard.ViewModels.AdminViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    SaveUpdateAdminRequestModel request = new SaveUpdateAdminRequestModel()
                    {
                        adminData = new Admin()
                        {
                            Firstname = model.Firstname,
                            Lastname = model.Lastname,
                            Email = model.Email,
                            Password = model.Password,
                            RoleId = model.RoleId,
                            Address = model.Address,
                            isActive = true,
                            CreatedBy = int.Parse(HttpContext.User.GetClaimValue("AdminId").ToString()),
                            LastUpdatedBy = int.Parse(HttpContext.User.GetClaimValue("AdminId").ToString()),
                        }
                    };

                    var response = await ApiCall.CallApi("api/Admin/SaveUpdateAdmin", User, request, false);
                    if (response != null)
                    {
                        return Json(response.GetValue("payload").ToObject<bool>(), JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return new HttpStatusCodeResult((int)HttpStatusCode.InternalServerError, "Ooops! Some Error Occured");
                    }
                }
                else
                {
                    Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    return Json(new { errors = ModelState.Values.SelectMany(v => v.Errors) }, JsonRequestBehavior.AllowGet);
                };
            }
            catch (Exception ex)
            {
                Utility.LogError(ex);
                return new HttpStatusCodeResult((int)HttpStatusCode.InternalServerError, "Ooops! Some Error Occured");
            }
        }

        #endregion

        #region Manage_Admins

        [HttpGet]
        public ActionResult ManageAllAdmins()
        {
            try
            {
                Global.sharedDataModel.SetSharedData(User);
                return View(Global.sharedDataModel);
            }
            catch (Exception ex)
            {
                return new HttpStatusCodeResult(Utility.LogError(ex), "Internal Server Error");
            }
        }

        public async Task<JsonResult> GetAllAdmins()
        {
            try
            {
                var Email = string.IsNullOrEmpty(Request.Form["Email"]) ? null : Request.Form["Email"];
                var Name = string.IsNullOrEmpty(Request.Form["Name"]) ? null : Request.Form["Name"];
                var RoleTypeID = string.IsNullOrEmpty(Request.Form["RoleTypeID"]) ? 0 : Convert.ToInt32(Request.Form["RoleTypeID"]);

                var response = await ApiCall.CallApi("api/Admin/GetAllAdmins", User, GetRequest: true, parameters: "Email=" + Email + "&RoleTypeID=" + RoleTypeID + "&Name=" + Name);
                if (response == null || response is Error)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    return Json("Error", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    var responseData = response.GetValue("payload").ToObject<GetAllAdminsResponse>();
                    return Json(responseData.AdminsList, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                Utility.LogError(ex);
                return Json(null, JsonRequestBehavior.DenyGet);
            }
        }

        public async Task<ActionResult> UpdateAdminStatus(int StatusID, int AdminID)
        {
            try
            {
                var request = new UpdateAdminStatusRequestModel()
                {
                    adminData = new Admin()
                    {
                        isActive = Convert.ToBoolean(StatusID),
                        Id = AdminID,
                        LastUpdatedBy = int.Parse(HttpContext.User.GetClaimValue("AdminId").ToString())
                    }
                };
                var response = await ApiCall.CallApi("api/Admin/UpdateAdminStatus", User, request);
                if (response == null || response is Error)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    return Json("Error", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    var responseData = response.GetValue("payload").ToObject<bool>();
                    if (responseData == true)
                    {
                        return Json("Success", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        return Json("Error", JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.LogError(ex);
                return Json(null, JsonRequestBehavior.DenyGet);
            }
        }

        #endregion


    }
}