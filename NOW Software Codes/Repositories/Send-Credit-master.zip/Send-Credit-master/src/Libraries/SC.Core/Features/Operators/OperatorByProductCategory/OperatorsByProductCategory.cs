﻿using MapsterMapper;
using RW.Models;
using SC.Core.Vendors.FusionHub;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SC.Core.Features.Operators.OperatorByProductCategory;

public static class OperatorsByProductCategory
{
    public sealed record Query : IRequest<IResultWrapper>
    {

        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public OperatorsByProductCategoryFilter? OperatorFilters { get; set; }

        public sealed record OperatorsByProductCategoryFilter
        {

            public string? CategoryAliasName { get; set; }
            public string? CountryIsoCode { get; set; }
            public string? CurrencyCode { get; set; }
        }
    }


    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Page).GreaterThan(0);
        }
    }

    #region response
    public sealed record Response
    {
        [JsonPropertyName("operator")]
        public OperatorInfo Operator { get; set; } = new OperatorInfo();
        [JsonPropertyName("category")]
        public CategoryInfo Category { get; set; } = new CategoryInfo();
        [JsonPropertyName("country")]
        public CountryInfo Country { get; set; } = new CountryInfo();
        public sealed record OperatorInfo
        {
            [JsonPropertyName("operatorId")]
            public long OperatorId { get; set; }
            [JsonPropertyName("operatorName")]
            public string? OperatorName { get; set; }
            [JsonPropertyName("description")]
            public string? Description { get; set; }
            [JsonPropertyName("shortCode")]
            public string? ShortCode { get; set; }
            [JsonPropertyName("logo")]
            public string? Logo { get; set; }
        }
        public sealed record CategoryInfo
        {
            [JsonPropertyName("categoryName")]
            public string? CategoryName { get; set; }
            [JsonPropertyName("categoryAliasName")]
            public string? CategoryAliasName { get; set; }
        }

        public sealed record CountryInfo
        {
            [JsonPropertyName("countryName")]
            public string? CountryName { get; set; }
            [JsonPropertyName("countryIsoCode2")]
            public string? CountryIsoCode2 { get; set; }
        }

    }

    #endregion
    #region Handler
    internal sealed class Handler : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IFusionHubService _fusionHubService;
        private readonly IMapper _mapper;
        public Handler(IFusionHubService fusionHubService, IMapper mapper)
        {
            _fusionHubService = fusionHubService;
            _mapper = mapper;
        }
        public async Task<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var response = await _fusionHubService.GetOperatorsByProductCategoryAsync(request);
            if (response?.Payload == null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
            }
            return ResultWrapper.Success(response.Payload, new Pagination(response?.PaginationInfo.TotalCount, response?.PaginationInfo.PageCount, response?.PaginationInfo.CurrentPage, response?.PaginationInfo.PageSize));
        }
    }
    #endregion
}

