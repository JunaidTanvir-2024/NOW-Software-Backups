﻿namespace Application.Features.Payment.Card.Models;

public class CardPaymentRequest
{
    public string Msisdn { get; set; } = default!;
    public string Email { get; set; } = default!;
    public PaymentAddressInfo Address { get; set; } = default!;
    public CheckOutType CheckoutType { get; set; } = default!;
    public string? BundleUuid { get; set; }
    public float BundleAmount { get; set; }
    public float EarlyTerminationAmount { get; set; }
    public float TopupAmount { get; set; }
    public string IpAddress { get; set; } = default!;
    public PaymentExistingCardInfo? PaymentExistingCardInfo { get; set; }
    public PaymentNewCardInfo? PaymentNewCardInfo { get; set; }
    public bool IsRecurring { get; set; }
    public bool OverrideValidation { get; set; }
}

public class CardPaymentResponse
{
    public bool Need3dSecure { get; set; }
    public ThreeDSecureData? ThreeDSecureData { get; set; }
    public string? TransactionId { get; set; }
    public bool IsRecurring { get; set; }
    public bool IsSuccess { get; set; }
    public int ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }
}

public class ThreeDSecureData
{
    public string? ReturnUrl { get; set; }
    public string? RedirectUrl { get; set; }
    public string? Pareq { get; set; }
    public string? TransactionId { get; set; }
    public string? Type { get; set; }
    public string? ThreeDSServerTransId { get; set; }
}