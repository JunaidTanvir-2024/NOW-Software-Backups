using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.SimBundle;

public sealed class SimBundleRequestHandler : IRequestHandler<SimBundleRequest, Result<List<BundleInfo>>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<SimBundleRequestHandler> _localizer;
    private readonly IMapper _mapper;

    public SimBundleRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<SimBundleRequestHandler> localizer,
        IMapper mapper)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
    }

    public async Task<Result<List<BundleInfo>>> Handle(SimBundleRequest request, CancellationToken cancellationToken)
    {
        var bundles = _mapper.Map<List<BundleInfo>>(await _uow.BundleRepo.GetSimBundles(request));
        return Result<List<BundleInfo>>.Success(bundles, _localizer[CustomStatusKey.Success]);
    }
}
