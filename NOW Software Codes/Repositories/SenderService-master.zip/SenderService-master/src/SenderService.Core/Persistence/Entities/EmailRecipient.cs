﻿using SenderService.Core.Common.Enums;

namespace SenderService.Core.Persistence.Entities;

//public class EmailRecipient
//{
//    public long Id { get; set; }

//    public long EmailId { get; set; }

//    public byte RecipientType { get; set; }

//    public string EmailAddress { get; set; } = null!;

//    public string? RecipientName { get; set; }

//    public bool IsSent { get; set; }

//    public DateTime? SentDateTimeUtc { get; set; }

//    public DateTime? LastAttemptDateTimeUtc { get; set; }

//    public string? ErrorMessage { get; set; }

//    public virtual Email Email { get; set; } = null!;
//}

public class EmailRecipient
{
    public long Id { get; set; }

    public long EmailId { get; set; }

    public byte RecipientType { get; set; }

    public string EmailAddress { get; set; } = null!;

    public string? RecipientName { get; set; }

    public virtual Email Email { get; set; } = null!;
}