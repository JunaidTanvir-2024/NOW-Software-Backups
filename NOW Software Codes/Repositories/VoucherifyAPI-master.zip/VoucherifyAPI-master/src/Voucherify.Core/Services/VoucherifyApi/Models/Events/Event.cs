using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;
using Voucherify.Core.Services.VoucherifyApi.Models.Loyalties;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Events;

public class Event
{
    [JsonPropertyName("object")]
    public string? Object { get; set; }
    [JsonPropertyName("type")]
    public string? Type { get; set; }
    [JsonPropertyName("customer")]
    public Customer? Customer { get; set; }
    [JsonPropertyName("loyalty")]
    public Loyalty? Loyalty { get; set; }
    [JsonPropertyName("referral")]
    public Referral? Referral { get; set; }
}