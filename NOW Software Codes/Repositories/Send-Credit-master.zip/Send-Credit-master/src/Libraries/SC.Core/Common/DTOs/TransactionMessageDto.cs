﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MessageBrokerModel;
public sealed record TransactionMessageDto
{
    public required string Publisher { get; set; }
    public required string TransactionReference { get; set; }
    public required TransactionItem TransactionItems { get; set; }
    public sealed record TransactionItem
    {
        public required string ProductVendorCode { get; set; }
        public required string CartReference { get; set; }
        public required long ProductId { get; set; }
        public required string Status { get; set; }
    }
}