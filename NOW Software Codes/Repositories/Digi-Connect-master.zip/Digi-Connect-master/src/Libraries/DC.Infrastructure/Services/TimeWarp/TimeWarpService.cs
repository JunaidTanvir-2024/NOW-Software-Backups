namespace DC.Infrastructure.Services.TimeWarp;

internal sealed class TimeWarpService : ITimeWarpService
{
    public DateTime UtcNow => DateTime.UtcNow;
}
