﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Configurations
{
    public class SerilogConfig
    {
        public string FilePath { get; set; }
    }
}
