﻿namespace SenderService.Core.Common.Enums;
public enum RecipientType
{
    To = 1,
    CC = 2,
    BCC = 3,
}