﻿using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.ResponseWrappers;
using THCC.Domain.Entities;

namespace THCC.Application.Features.User.ForgotPassword.ForgotPasswod;

public class ForgotPasswordRequestHandler : IRequestHandler<ForgotPasswordRequest, object>
{
    #region Fields

    private readonly IUserRepository _userRepo;
    private readonly ILegacyRepository _legacyRepo;
    private readonly IMailService _mailService;
    private readonly ILogger _logger;
    private readonly IUserService _userService;
    private readonly IOtpService _otpService;

    #endregion

    #region Ctors

    public ForgotPasswordRequestHandler(
        IUserRepository userRepository,
        ILegacyRepository legacyRepository,
        IMailService mailService,
        ILogger logger,
        IUserService userService,
        IOtpService otpService)
    {
        _userRepo = userRepository;
        _legacyRepo = legacyRepository;
        _mailService = mailService;
        _logger = logger;
        _userService = userService;
        _otpService = otpService;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(ForgotPasswordRequest request, CancellationToken cancellationToken)
    {
        request.Email = request.Email.Trim();

        var user = await _userRepo.GetUserByEmailAsync(request.Email);
        if (user == null)
        {
            //Check if user exists in legacy db
            var legacyUser = await _legacyRepo.GetUserByEmail(request.Email);
            if (legacyUser==null || legacyUser?.IsConfirmedUser == false)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
            }

            //Register this user in new db 
            var signupResponse = await _userService.SignUpAsync(
                legacyUser!.FirstName.Trim(),
                legacyUser.LastName.Trim(),
                request.Email.Trim(),
                null!,
                UserRole.Customer,
                true);

            if (!signupResponse.IsSuccess)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
            }

            //Get legacy user product
            var legacyUserProduct = await _legacyRepo.GetUserProducts(legacyUser!.Id);

            //Register products in new db
            if (legacyUserProduct != null)
            {
                (bool isProductAdded, int errorCode, string errorMessage) = await _userRepo.CreateProduct(
                        legacyUserProduct.ProductRef!,
                        signupResponse.Id!,
                        legacyUserProduct.DateCreated);
                if (!isProductAdded)
                {
                    _logger.Error(
                        $"Failied {legacyUser.Email} product registration to new DB with errorCode: " +
                        $"{errorCode} {errorMessage}");
                }
            }
            user = await _userRepo.GetUserByEmailAsync(request.Email);
        }

        if (user?.EmailConfirmed == false)
        {
            return ErrorResult.Failure(
                CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
        }

        var token = await _userRepo.GeneratePasswordResetTokenAsync(user!)!;
        var emailOtp = await _otpService.SaveToken(request.Email, token!, OtpType.ForgotPassword);
        await _mailService.SendForgotPasswordEmail(request.Email, emailOtp);

        return Unit.Value;
    }

    #endregion
}