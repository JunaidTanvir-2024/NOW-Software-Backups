﻿using MediatR;

namespace TestServiceApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BaseApiController : Controller
{
    private ISender _mediator = null!;
    protected ISender Mediator => _mediator ??= HttpContext.RequestServices.GetRequiredService<ISender>();
}
