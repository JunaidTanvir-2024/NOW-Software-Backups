﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs.Digitalk
{
    public class DigitalkBundle
    {
        public int AllowancePeriodsElapsed { get; set; }
        public object AllowanceRenewalDate { get; set; }
        public CallingPackage CallingPackage { get; set; }
        public int ChargePeriodsElapsed { get; set; }
        public CommonAllowance CommonAllowance { get; set; }
        public DateTime Expired { get; set; }
        public GPRSAllowance GPRSAllowance { get; set; }
        public int Id { get; set; }
        public DateTime LastAllowancePaymentDate { get; set; }
        public DateTime LastChargePaymentDate { get; set; }
        public MMSAllowance MMSAllowance { get; set; }
        public object NoticePeriodEnd { get; set; }
        public SMSAllowance SMSAllowance { get; set; }
        public DateTime Started { get; set; }
        public int State { get; set; }
        public int Type { get; set; }
        public VoiceAllowance VoiceAllowance { get; set; }
    }

    public class CallingPackage
    {
        public int ServiceType { get; set; }
        public string PackageId { get; set; }
        public int PackageType { get; set; }
        public int PackageCategory { get; set; }
        public string PackageName { get; set; }
        public string BrandedName { get; set; }
        public string PIC { get; set; }
        public string Description { get; set; }
        public decimal SubscriptionCharge { get; set; }
        public decimal RecurringCharge { get; set; }
        public int ChargePeriodLength { get; set; }
        public int ChargePeriodType { get; set; }
        public int ChargeRecurrence { get; set; }
        public bool ChargeAtEndOfPeriod { get; set; }
        public int AllowancePeriodType { get; set; }
        public int AllowancePeriodLength { get; set; }
        public int AllowanceRecurrence { get; set; }
        public string FullType { get; set; }
        public decimal InitialCharge { get; set; }
        public CommonAllowance CommonAllowance { get; set; }
        public VoiceAllowance VoiceAllowance { get; set; }
        public SMSAllowance SMSAllowance { get; set; }
        public MMSAllowance MMSAllowance { get; set; }
        public GPRSAllowance GPRSAllowance { get; set; }
    }

    public class CommonAllowance
    {
        public string Spend { get; set; }
        public int SpendMode { get; set; }
        public string SpendText { get; set; }
    }

    public class GPRSAllowance
    {
        public string Spend { get; set; }
        public int SpendMode { get; set; }
        public string SpendText { get; set; }
        public long Bytes { get; set; }
        public int BytesMode { get; set; }
        public string BytesText { get; set; }
    }

    public class MMSAllowance
    {
        public string Spend { get; set; }
        public int SpendMode { get; set; }
        public string SpendText { get; set; }
        public int Messages { get; set; }
        public int MessagesMode { get; set; }
        public string MessagesText { get; set; }
    }

    public class SMSAllowance
    {
        public string Spend { get; set; }
        public int SpendMode { get; set; }
        public string SpendText { get; set; }
        public int Messages { get; set; }
        public int MessagesMode { get; set; }
        public string MessagesText { get; set; }
    }

    public class VoiceAllowance
    {
        public string Spend { get; set; }
        public int SpendMode { get; set; }
        public string SpendText { get; set; }
        public int Calls { get; set; }
        public int CallsMode { get; set; }
        public string CallsText { get; set; }
        public int Seconds { get; set; }
        public int SecondsMode { get; set; }
        public string SecondsText { get; set; }
    }
}
