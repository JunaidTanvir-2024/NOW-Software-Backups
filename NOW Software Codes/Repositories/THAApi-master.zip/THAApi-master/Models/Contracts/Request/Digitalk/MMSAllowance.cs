﻿namespace Models.Contracts.Request.Digitalk
{
	public class MMSAllowance
	{
		public string Spend { get; set; }
		public int SpendMode { get; set; }
		public string SpendText { get; set; }
		public int Messages { get; set; }
		public int MessagesMode { get; set; }
		public string MessagesText { get; set; }
	}
}