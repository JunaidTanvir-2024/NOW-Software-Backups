﻿
using Application.Common.Settings;
using Application.Features.Bundle.CancelBundle;
using Application.Features.Bundle.Model;
using Microsoft.Extensions.Options;

namespace Application.Features.Bundle.CancelBundleDetail;
public sealed class CancelBundleDetailRequestHandler : IRequestHandler<CancelBundleDetailRequest, Result<CancelBundleDetails>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<CancelBundleDetailRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly IBundleService _bundleService;
    public CancelBundleDetailRequestHandler
    (
        IUnitOfWork uow,
        IStringLocalizer<CancelBundleDetailRequestHandler> localizer,
        IMapper mapper,
        IBundleService bundleService)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
        _bundleService = bundleService;
    }

    public async Task<Result<CancelBundleDetails>> Handle(CancelBundleDetailRequest request, CancellationToken cancellationToken)
    {
        var msisdnDetails = await _uow.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdnDetails == null)
        {
            return Result<CancelBundleDetails>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }

        var subscribeBundlesList = _mapper.Map<List<SubscribedBundleInfo>>(await _uow.UserRepo.GetSubscribedBundlesV3(msisdnDetails.AccountId!));

        var subscribedBundle = subscribeBundlesList.FirstOrDefault(t => t.Id.ToString() == request.BundleId);

        if (subscribedBundle == null || Convert.ToString(subscribedBundle!.Id!) != request.BundleId)
        {
            return Result<CancelBundleDetails>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }
        var bundleInfo = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(subscribedBundle.Id.ToString()));
        if (bundleInfo == null)
        {
            return Result<CancelBundleDetails>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }
        
        CancelBundleDetails cancelBundleDetails = _bundleService.CalculateCancelPlanCharges(subscribedBundle, bundleInfo);
        return Result<CancelBundleDetails>.Success(cancelBundleDetails, _localizer[CustomStatusKey.Success]);
    }
}
