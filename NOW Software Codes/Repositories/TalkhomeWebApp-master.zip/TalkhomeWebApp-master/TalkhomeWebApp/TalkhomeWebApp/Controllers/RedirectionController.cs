﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace TalkhomeWebApp.Controllers
{
    public class RedirectionController : Controller
    {
        [HttpGet]
        [Route("gr")]
        [Route("fr")]
        [Route("it")]
        public IActionResult Redirection()
        {
            return RedirectPermanent("~/");
        }
    }
}
