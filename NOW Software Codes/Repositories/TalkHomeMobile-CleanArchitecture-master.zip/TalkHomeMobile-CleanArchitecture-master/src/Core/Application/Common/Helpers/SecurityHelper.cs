﻿using System.Security.Cryptography;
using System.Text;

namespace Application.Common.Helpers;

public static class SecurityHelper
{
    public static string HashPassword(string password, string hashingAlgorithm = "SHA512")
    {
        return SHA.ComputeHash(password, hashingAlgorithm);
    }

    public static UserCredentials CreateUserCredentials(Dictionary<string, string> saltDict, Dictionary<string, byte[]> encryptedSaltDict, string password)
    {
        var user = new UserCredentials();

        var fullPassword = ConstructPassword(password, saltDict);
        var hashedFullPassword = HashPassword(fullPassword);

        user.Password = Convert.FromBase64String(hashedFullPassword);
        user.PasswordPrefix = encryptedSaltDict["prefix"];
        user.PasswordSuffix = encryptedSaltDict["suffix"];
        user.Key = encryptedSaltDict["key"];
        user.IV = encryptedSaltDict["iv"];

        return user;
    }
    public static UserCredentials GetUserCredentials(string password)
    {
        var saltDict = CreatePasswordAppendages();
        var encryptedSaltDict = EncryptPasswordAppendages(saltDict);
        return CreateUserCredentials(saltDict, encryptedSaltDict, password);
    }
    public static Dictionary<string, string> CreatePasswordAppendages()
    {
        // Define min and max salt sizes.
        int minSaltSize = 4;
        int maxSaltSize = 8;

        // Generate a random number for the size of the salt.
        Random random = new();
        int saltSize = random.Next(minSaltSize, maxSaltSize);

        // Allocate a byte array, which will hold the salt.
        byte[] saltBytesPrefix = new byte[saltSize];
        byte[] saltBytesSuffix = new byte[saltSize];

        // Initialize a random number generator.
#pragma warning disable SYSLIB0023 // Type or member is obsolete
        using (RNGCryptoServiceProvider rng = new())
        {

            // Fill the salt with cryptographically strong byte values.
            rng.GetNonZeroBytes(saltBytesPrefix);
            rng.GetNonZeroBytes(saltBytesSuffix);
        }
#pragma warning restore SYSLIB0023 // Type or member is obsolete

        Dictionary<string, string> passwordAppendages = new()
        {
            { "prefix", Convert.ToBase64String(saltBytesPrefix) },
            { "suffix", Convert.ToBase64String(saltBytesSuffix) }
        };

        return passwordAppendages;
    }

    public static Dictionary<string, byte[]> EncryptPasswordAppendages(Dictionary<string, string> passwordAppendagesDict)
    {
#pragma warning disable SYSLIB0022 // Type or member is obsolete
        using RijndaelManaged myRijndael = new();
#pragma warning restore SYSLIB0022 // Type or member is obsolete

        myRijndael.GenerateKey();
        myRijndael.GenerateIV();

        //string initVector = "@1B2c3D4e5F6g7H8"; // must be 16 bytes
        var cipherText = string.Empty;
        Dictionary<string, byte[]> encryptedAppendages = new Dictionary<string, byte[]>();
        byte[] aesKey, aesIv;

        aesKey = myRijndael.Key;
        aesIv = myRijndael.IV;

        foreach (var kvp in passwordAppendagesDict)
        {
            switch (kvp.Key.ToUpper())
            {
                case "PREFIX":
                    var prefixCipherText = RijndaelEnhanced.EncryptStringToBytes(kvp.Value, aesKey, aesIv);
                    encryptedAppendages.Add("prefix", prefixCipherText);
                    break;
                case "SUFFIX":
                    var suffixCipherText = RijndaelEnhanced.EncryptStringToBytes(kvp.Value, aesKey, aesIv);
                    encryptedAppendages.Add("suffix", suffixCipherText);
                    break;
            }
        }

        encryptedAppendages.Add("key", aesKey);
        encryptedAppendages.Add("iv", aesIv);
        return encryptedAppendages;
    }

    public static Dictionary<string, string> DecryptPasswordAppendages(Dictionary<string, byte[]> passwordAppendagesDict)
    {
        Dictionary<string, string> decryptedAppendages = new();
        byte[] key = passwordAppendagesDict["key"];
        byte[] iv = passwordAppendagesDict["iv"];

        foreach (var kvp in passwordAppendagesDict)
        {
            //RijndaelEnhanced rijndaelKey = new RijndaelEnhanced(kvp.Value, initVector);

            switch (kvp.Key.ToUpper())
            {
                case "PREFIX":
                    var prefixCipherText = RijndaelEnhanced.DecryptStringFromBytes(kvp.Value, key, iv);
                    decryptedAppendages.Add("prefix", prefixCipherText);
                    break;
                case "SUFFIX":
                    var suffixCipherText = RijndaelEnhanced.DecryptStringFromBytes(kvp.Value, key, iv);
                    decryptedAppendages.Add("suffix", suffixCipherText);
                    break;
            }
        }
        return decryptedAppendages;
    }

    public static string ConstructPassword(string password, Dictionary<string, string> passwordAppendagesDict)
    {
        string passwordWithAppendages;
        if (passwordAppendagesDict.ContainsKey("prefix") && passwordAppendagesDict.ContainsKey("suffix"))
        {
            passwordWithAppendages = passwordAppendagesDict["prefix"] + password + passwordAppendagesDict["suffix"];
        }
        else
        {
            throw new Exception("Prefix & suffix not found.");
        }

        return passwordWithAppendages;
    }

    public static bool IsValid(string receivedPasswordWithDecryptedSalt, string hashedPasswordFromDb, string hashingAlgorithm = "SHA512")
    {
        var isValid = SHA.VerifyHash(receivedPasswordWithDecryptedSalt, hashingAlgorithm, hashedPasswordFromDb);
        return isValid;
    }
    #region Utilities

    public static bool CheckPassword(string pasword, User user)
    {
        //Decrypt password
        Dictionary<string, byte[]> passwordAppendages = new()
        {
            { "prefix", user.PasswordPrefix },
            { "suffix", user.PasswordSuffix },
            { "key", user.Key },
            { "iv", user.IV }
        };

        var dPasswordAppendages = SecurityHelper.DecryptPasswordAppendages(passwordAppendages);
        var fullPassword = SecurityHelper.ConstructPassword(pasword, dPasswordAppendages);
        fullPassword = fullPassword.Replace("\0", "");

        //Check password validity
        bool isAuthenticated = SecurityHelper.IsValid(fullPassword, Convert.ToBase64String(user.Password));
        return isAuthenticated;
    }

    #endregion
}

public static class SHA
{
    #region GenerateHashDescription
    /// <summary>
    /// Generates a hash for the given plain text value and returns a
    /// base64-encoded result.
    /// </summary>
    ///
    ///
    ///
    /// <param name="plainText">
    /// Plaintext value to be hashed. The function does not check whether
    /// this parameter is null.
    /// </param>
    ///
    ///
    ///
    /// <param name="hashAlgorithm">
    /// Name of the hash algorithm. Allowed values are: "MD5", "SHA1",
    /// "SHA256", "SHA384", and "SHA512" (if any other value is specified
    /// MD5 hashing algorithm will be used). This value is case-insensitive.
    /// </param>
    ///
    ///
    /// <returns>
    /// Hash value formatted as a base64-encoded string.
    /// </returns>
    #endregion
    public static string ComputeHash(string plainText, string hashAlgorithm)
    {
        // Convert plain text into a byte array.
        byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
#pragma warning disable SYSLIB0021 // Type or member is obsolete
        HashAlgorithm hash = hashAlgorithm.ToUpper() switch
        {
            "SHA1" => new SHA1Managed(),
            "SHA256" => new SHA256Managed(),
            "SHA384" => new SHA384Managed(),
            "SHA512" => new SHA512Managed(),
            _ => new MD5CryptoServiceProvider(),
        };
#pragma warning restore SYSLIB0021 // Type or member is obsolete
        byte[] hashBytes = hash.ComputeHash(plainTextBytes);
        string hashValue = Convert.ToBase64String(hashBytes);

        return hashValue;
    }

    #region VerifyHashDescription
    /// <summary>
    /// Compares a hash of the specified plain text value to a given hash
    /// value.
    /// </summary>
    ///
    /// <param name="plainText">
    /// Plain text to be verified against the specified hash. The function
    /// does not check whether this parameter is null.
    /// </param>
    ///
    /// <param name="hashAlgorithm">
    /// Name of the hash algorithm. Allowed values are: "MD5", "SHA1", 
    /// "SHA256", "SHA384", and "SHA512" (if any other value is specified,
    /// MD5 hashing algorithm will be used). This value is case-insensitive.
    /// </param>
    ///
    /// <param name="hashValue">
    /// Base64-encoded hash value produced by ComputeHash function. This value
    /// includes the original salt appended to it.
    /// </param>
    ///
    ///
    /// <returns>
    /// If computed hash mathes the specified hash the function the return
    /// value is true; otherwise, the function returns false.
    /// </returns>
    ///
    #endregion
    public static bool VerifyHash(string plainText, string hashAlgorithm, string hashValue)
    {
        // Convert base64-encoded hash value into a byte array.
        byte[] hashWithSaltBytes = Convert.FromBase64String(hashValue);

        // We must know size of hash (without salt).
        int hashSizeInBytes;

        // Make sure that hashing algorithm name is specified.
        if (hashAlgorithm == null)
        {
            hashAlgorithm = "";
        }

        var hashSizeInBits = hashAlgorithm.ToUpper() switch
        {
            "SHA1" => 160,
            "SHA256" => 256,
            "SHA384" => 384,
            "SHA512" => 512,
            // Must be MD5
            _ => 128,
        };

        // Convert size of hash from bits to bytes.
        hashSizeInBytes = hashSizeInBits / 8;

        // Make sure that the specified hash value is long enough.
        if (hashWithSaltBytes.Length < hashSizeInBytes)
        {
            return false;
        }

        // Compute a new hash string.
        string expectedHashString = ComputeHash(plainText, hashAlgorithm);

        // If the computed hash matches the specified hash,
        // the plain text value must be correct.
        return (hashValue == expectedHashString);
    }
}

public static class RijndaelEnhanced
{
    public static byte[] EncryptStringToBytes(string plainText, byte[] Key, byte[] IV)
    {
        // Check arguments.
        if (plainText == null || plainText.Length <= 0)
        {
            throw new ArgumentNullException("plainText");
        }

        if (Key == null || Key.Length <= 0)
        {
            throw new ArgumentNullException("Key");
        }

        if (IV == null || IV.Length <= 0)
        {
            throw new ArgumentNullException("Key");
        }

        byte[] encrypted;
        // Create an RijndaelManaged object
        // with the specified key and IV.
#pragma warning disable SYSLIB0022 // Type or member is obsolete
        using (RijndaelManaged rijAlg = new())
        {
            rijAlg.Key = Key;
            rijAlg.IV = IV;
            rijAlg.Mode = CipherMode.CBC;
            rijAlg.Padding = PaddingMode.Zeros;

            // Create a decrytor to perform the stream transform.
            ICryptoTransform encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);

            // Create the streams used for encryption.
            using MemoryStream msEncrypt = new();
            using CryptoStream csEncrypt = new(msEncrypt, encryptor, CryptoStreamMode.Write);
            using (StreamWriter swEncrypt = new(csEncrypt))
            {

                //Write all data to the stream.
                swEncrypt.Write(plainText);
            }
            encrypted = msEncrypt.ToArray();
        }
#pragma warning restore SYSLIB0022 // Type or member is obsolete


        // Return the encrypted bytes from the memory stream.
        return encrypted;

    }

    public static string DecryptStringFromBytes(byte[] cipherText, byte[] Key, byte[] IV)
    {
        // Check arguments.
        if (cipherText == null || cipherText.Length <= 0)
        {
            throw new ArgumentNullException("cipherText");
        }

        if (Key == null || Key.Length <= 0)
        {
            throw new ArgumentNullException("Key");
        }

        if (IV == null || IV.Length <= 0)
        {
            throw new ArgumentNullException("Key");
        }

        // Declare the string used to hold
        // the decrypted text.
        string? plaintext = null;

        // Create an RijndaelManaged object
        // with the specified key and IV.


#pragma warning disable SYSLIB0022 // Type or member is obsolete
        using (RijndaelManaged rijAlg = new())
        {
            rijAlg.Key = Key;
            rijAlg.IV = IV;
            rijAlg.Mode = CipherMode.CBC;
            rijAlg.Padding = PaddingMode.Zeros;

            // Create a decrytor to perform the stream transform.
            ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

            // Create the streams used for decryption.
            using MemoryStream msDecrypt = new(cipherText);
            using CryptoStream csDecrypt = new(msDecrypt, decryptor, CryptoStreamMode.Read);
            using StreamReader srDecrypt = new(csDecrypt);

            // Read the decrypted bytes from the decrypting stream
            // and place them in a string.
            plaintext = srDecrypt.ReadToEnd();

        }
#pragma warning restore SYSLIB0022 // Type or member is obsolete

        return plaintext;
    }
   
}

public class UserCredentials
{
    public byte[] Password { get; set; } = default!;
    public byte[] PasswordPrefix { get; set; } = default!;
    public byte[] PasswordSuffix { get; set; } = default!;
    public byte[] Key { get; set; } = default!;
    public byte[] IV { get; set; } = default!;
}