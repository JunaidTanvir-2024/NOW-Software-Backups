﻿using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface IOffer_DL
    {
        Task<bool> AddGreeceTopupOffer(UserAccount userAccount);
    }
}
