﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants;
public static partial class AppEnums
{
    public enum PaymentCardType : byte
    {
        NewCard = 1,
        ExistingCard = 2
    }
    public enum PaymentMethod
    {
        Pay360 = 1,
        Paypal = 2
    }
}

