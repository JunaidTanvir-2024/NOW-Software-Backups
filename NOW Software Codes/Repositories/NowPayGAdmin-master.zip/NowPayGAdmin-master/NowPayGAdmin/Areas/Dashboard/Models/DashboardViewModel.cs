﻿using BasketWebPanel.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models
{
    public class DashboardViewModel : BaseViewModel
    {
        public int TotalStores { get; set; }

    }
}