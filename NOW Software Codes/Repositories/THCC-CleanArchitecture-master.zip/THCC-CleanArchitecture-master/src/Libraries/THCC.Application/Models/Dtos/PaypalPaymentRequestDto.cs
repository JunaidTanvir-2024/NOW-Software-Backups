﻿namespace THCC.Application.Models.Dtos
{
    public class PaypalPaymentRequestDto
    {
        public string Email { get; set; } = default!;
        public ProductType ProductType { get; set; } = default!;
        public string IpAddress { get; set; } = default!;
        public bool IsRecurring { get; set; }
        public string? CardPin { get; set; }
        public string? CardNumber { get; set; }
        public decimal Amount { get; set; } = default!;
        public long OrderId { get; set; }
    }
}