﻿using AspNetCore.Identity.Dapper;
using Dapper;
using Microsoft.AspNetCore.Identity;


namespace SC.Api.Data.Tables;

public class ExtendedRolesTable : RolesTable<ExtendedIdentityRole, string, IdentityRoleClaim<string>>
{
    public ExtendedRolesTable(IDbConnectionFactory dbConnectionFactory) : base(dbConnectionFactory) { }
}

