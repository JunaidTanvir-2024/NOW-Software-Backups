﻿namespace SC.Api;

public static class ConfigureDependencies
{
    public static IServiceCollection AddApiDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddControllers();
        services.AddCoreDependencies(configuration);
        services.AddInfrastructureDependencies(configuration);
        return services;
    }
}
