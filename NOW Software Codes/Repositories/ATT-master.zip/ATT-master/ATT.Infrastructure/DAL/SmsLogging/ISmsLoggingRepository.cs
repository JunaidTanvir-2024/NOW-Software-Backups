﻿using ATT.Models.Database;
using System.Threading.Tasks;

namespace ATT.Infrastructure.DAL.SmsLogging
{
    public interface ISmsLoggingRepository
    {
        Task<int> InsertSmsLog(AttSmsLogging attSmsLogging);
        Task<AttSmsLogging> GetLogBySmsSID(string smsSID);
    }
}
