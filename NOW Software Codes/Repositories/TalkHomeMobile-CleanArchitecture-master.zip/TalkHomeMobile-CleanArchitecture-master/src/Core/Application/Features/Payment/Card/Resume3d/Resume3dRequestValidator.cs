﻿namespace Application.Features.Payment.Card.Resume3d;

public class Resume3dRequestValidator : AbstractValidator<Resume3dRequest>
{
    public Resume3dRequestValidator()
    {
        RuleFor(p => p.MD).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.OrderId).Cascade(CascadeMode.Stop).NotNull().NotEmpty().Must(x => x >= 0);
    }
}