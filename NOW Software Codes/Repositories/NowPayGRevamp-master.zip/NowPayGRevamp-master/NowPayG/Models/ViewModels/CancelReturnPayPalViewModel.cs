﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class CancelReturnPayPalViewModel
    {
        public string token { get; set; }
    }
}
