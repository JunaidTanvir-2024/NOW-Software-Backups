﻿using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IStaticList_BL
    {
        Task<GenericApiResponse<ApiGetSingleListRespose>> GetSingleList (GetSingleListRequest request);
        Task<GenericApiResponse<ApiGetAllListsResponse>> GetAllLists(GetAllListsRequest request);
        Task<GenericApiResponse<string>> DownloadListContent(DownloadListContentRequest request);
        Task<GenericApiResponse<string>> AddList(AddListRequest request);

    }
}
