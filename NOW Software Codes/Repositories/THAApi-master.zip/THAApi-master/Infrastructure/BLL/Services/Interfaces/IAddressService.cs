﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface IAddressService
    {
        Task<HttpResponseMessage> GetAddress(string postCode);
    }
}
