using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

public class VoucherAssets
{
    [JsonPropertyName("qr")]
    public QR? QR { get; set; }

    [JsonPropertyName("barcode")]
    public Barcode? Barcode { get; set; }
}
