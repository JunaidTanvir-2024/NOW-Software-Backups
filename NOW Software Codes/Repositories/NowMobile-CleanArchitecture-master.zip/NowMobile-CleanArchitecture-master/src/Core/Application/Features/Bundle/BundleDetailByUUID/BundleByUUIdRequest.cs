using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.BundleDetailByUUID;

public sealed class BundleByUUIdRequest : IRequest<Result<BundleInfo>>
{
    public string Id { get; set; } = default!;
}