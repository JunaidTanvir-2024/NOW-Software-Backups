﻿namespace Application.Common.Enums;
public enum RatingSources : byte
{
    APP = 1,
    Web = 2
}
