﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Serilog;
using TalkHomeContactSyncApi.Infrastructure.ContactSync;
using TalkHomeContactSyncApi.MiddleWare;
using TalkHomeContactSyncApi.Models.Configuration;

namespace TalkHomeContactSyncApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton((Serilog.ILogger)new LoggerConfiguration()
            .MinimumLevel.Debug()
            .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "TalkHomeContactSyncApi-log-{Date}.txt"))
            .CreateLogger());
            services.Configure<ConnectionStrings>(Configuration.GetSection("ConnectionStrings"));
            services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));

            services.AddTransient(typeof(IContactSyncPost), typeof(ContactSyncPost));
            services.AddTransient(typeof(IContactSyncDB), typeof(ContactSyncDB));

            services.AddMvc();
            
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            // Logging middleware for capturing response time and other Request & Response details
            app.UseMiddleware<DogStatsDMiddleware>();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseMvc();
        }
    }
}
