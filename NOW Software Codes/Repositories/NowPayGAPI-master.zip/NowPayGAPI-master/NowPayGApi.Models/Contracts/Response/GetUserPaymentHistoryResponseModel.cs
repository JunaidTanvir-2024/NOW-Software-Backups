﻿using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetUserPaymentHistoryResponseModel
    {
        public IEnumerable<DBPaymentHistory> PaymentHistory { get; set; }
        public int PaymentHisotryTotalRecords { get; set; }
    }
}
