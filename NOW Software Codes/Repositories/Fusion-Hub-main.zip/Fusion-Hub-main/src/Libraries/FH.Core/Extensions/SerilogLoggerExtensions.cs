namespace FH.Core.Extensions;
public static class SerilogLoggerExtensions
{
    public static void ErrorLog(this Serilog.ILogger logger, Exception ex, string className, string methodName)
    {
        logger.Error("An error occurred at",
        new
        {
            Class = className,
            Method = methodName,
            TimeStamp = DateTime.UtcNow,
            Error = ex.StackTrace
        });
    }
    public static void ErrorLog(this Serilog.ILogger logger, Exception ex)
    {
        logger.Error("An error occurred at",
        new
        {
            TimeStamp = DateTime.UtcNow,
            Error = ex.StackTrace,
            Message = ex.Message
        });
    }
}
