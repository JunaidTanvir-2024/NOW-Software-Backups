﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models
{
    public class VoucherRechargeRequest
    {
        [Required(ErrorMessage = "Enter Voucher Code"), MaxLength(length: 11, ErrorMessage = "Maximum 11 characters allowed"),
            MinLength(length: 11, ErrorMessage = "Minimum 11 characters allowed")]
        public string VoucherCode { get; set; }

        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        public string Msisdn { get; set; }
    }
}
