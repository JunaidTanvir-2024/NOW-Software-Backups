﻿namespace Application.Features.Payment.Card.MakeCardDefault;

public class MakeCardDefaultRequestValidator : AbstractValidator<MakeCardDefaultRequest>
{
    public MakeCardDefaultRequestValidator()
    { 
        RuleFor(p => p.CardToken).NotEmpty().NotNull();
        RuleFor(p => p.CardCv2).NotEmpty().NotNull();
    }
}