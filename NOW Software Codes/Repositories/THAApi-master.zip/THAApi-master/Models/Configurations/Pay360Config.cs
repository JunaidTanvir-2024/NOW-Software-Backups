﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{

	public class Pay360Config
	{
		public const string SectionName = "Pay360";
		public string ApiEndPoint { get; set; }
		public string TopupAmount { get; set; }
		public string AutoTopupThresholdAmount { get; set; }
		public float AutoTopupMaxSpendLimit { get; set; }
		public string AutoTopupAmount { get; set; }
		public bool IsAuthorization { get; set; }
		public bool TransferIsAuthorization { get; set; }
		public string[] PaymentCaptureFailureEmail { get; set; }

		public bool Do3DSecure { get; set; }
		public bool IsDirectFullfilment { get; set; }
		public bool IsBillingAndCustomerAddressSame { get; set; }
		public decimal TestPaymentAmount { get; set; }
		public bool sendPay360Email { get; set; }
		public List<TopupAmount> TopupAmounts { get; set; }
	}
	public class TopupAmount
	{
		public int Amount { get; set; }
		public int RewardPoints { get; set; }
	}
}
