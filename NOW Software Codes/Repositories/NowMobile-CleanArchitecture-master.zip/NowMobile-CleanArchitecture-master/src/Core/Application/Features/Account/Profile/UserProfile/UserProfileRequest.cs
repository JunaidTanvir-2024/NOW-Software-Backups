﻿namespace Application.Features.Account.Profile.UserProfile;
public class UserProfileRequest : IRequest<Result<UserInfo>>
{
}
