using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class ChatMessage : IBaseEntity<long>
{
    public long Id { get; set; }
    public string Content { get; set; } = null!;
    public DateTime Timestamp { get; set; }
    public long ChatRoomId { get; set; }
    public ChatRoom ChatRoom { get; set; } = null!;
    public long SenderId { get; set; }
    public User Sender { get; set; } = null!;
    public long ReceiverId { get; set; }
    public User Receiver { get; set; } = null!;
}
