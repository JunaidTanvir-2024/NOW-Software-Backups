﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using TalkhomeWebApp.Models.ApiContracts.Response;
using TalkhomeWebApp.Models.Configurations;
using TalkhomeWebApp.Utilities;
using TalkhomeWebApp.Utilities.SitemapBuilder;

namespace TalkhomeWebApp.Controllers
{
    public class SitemapController : Controller
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IOptions<EndPoints> _endpoints;
		private readonly ApiClient _apiClient;

		public SitemapController(IHttpContextAccessor httpContextAccessor, IOptions<EndPoints> Endpoints,
            ApiClient apiClient)
        {
            _httpContextAccessor = httpContextAccessor;
            _endpoints = Endpoints;
			this._apiClient = apiClient;
		}

        [Route("sitemap")]
        public async Task<IActionResult> SitemapAsync()
        {
            string baseUrl = _httpContextAccessor.HttpContext.Request.Scheme + "://" + _httpContextAccessor.HttpContext.Request.Host.Value;

            // get last modified date of the home page
            var siteMapBuilder = new SitemapBuilder();

            // add the home page to the sitemap
            siteMapBuilder.AddUrl(baseUrl, modified: null, changeFrequency: null, priority: null);


            var siteLinks = new string[]
            {
                "bundles",
                "rates",
                "account-top-up",
                "mobile-top-up",
                "account-summary",
                "account-details",
                "about",
                "contact",
                "FAQs",
                "how-it-works",
                "privacy",
                "terms",
                "product",
                "complaints-procedure",
                "login",
                "join",
                "top-up",
                "send-credit"
            };


            foreach (var link in siteLinks)
            {
                siteMapBuilder.AddUrl(baseUrl + "/" + link, modified: null, changeFrequency: null, priority: null);
            }
            foreach (var link in await GetSendCreditByCountryUrlsAsync())
            {
                siteMapBuilder.AddUrl($"{baseUrl}{link.Url}", modified: null, changeFrequency: null, priority: null);
            }
            // generate the sitemap xml
            string xml = siteMapBuilder.ToString();
            return Content(xml, "text/xml");
        }
        private async Task<List<SitemapUrl>> GetSendCreditByCountryUrlsAsync()
        {
            var urls = new List<SitemapUrl>();
            string continent = null;
            var transferCountriesResponse = await _apiClient.CallApi(_endpoints.Value.TalkHomeAPIEndPoint +
                "Transfer/TransferCountries?continent=" + continent?.Replace("-", " "), User, ApiCallType.Bearer, GetRequest: true);
            if (transferCountriesResponse.IsSuccessStatusCode)
            {
                var accountResponseJson = JObject.Parse(transferCountriesResponse.Content.ReadAsStringAsync().Result);
                int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                if (errorCode == 0)
                {

                    var response = accountResponseJson.GetValue("payload").ToObject<TransferCountriesResponse>();
                    if (response != null)
                    {
                        var tasks = new List<Task<List<SitemapUrl>>>();
                        foreach (var e in response.Countries)
                        {
                            urls.Add(new SitemapUrl
                            {
                                ChangeFrequency = ChangeFrequency.Weekly,
                                Priority = 0.9,
                                Url = Url.Action("SendCreditByCountry", "Home", new { continent = e.Continent.Replace(' ', '-'), countryName = e.Name.Replace(' ', '-') })
                            });
                            tasks.Add(GetSendCreditByOperatorUrlsAsync(e.Name));
                        }
                        await Task.WhenAll(tasks);
                        urls.AddRange(tasks.SelectMany(e => e.Result));
                    }
                }
            }
            return urls;
        }

        private async Task<List<SitemapUrl>> GetSendCreditByOperatorUrlsAsync(string countryName)
        {
            var currency = "GBP";
            var urls = new List<SitemapUrl>();
            var transferCountriesResponse = await _apiClient.CallApi(_endpoints.Value.TalkHomeAPIEndPoint +
                $"Transfer/TransferOperators?currency={currency}&countryName={countryName.Replace("-", " ")}", User, ApiCallType.Bearer, GetRequest: true);
            if (transferCountriesResponse.IsSuccessStatusCode)
            {
                var accountResponseJson = JObject.Parse(transferCountriesResponse.Content.ReadAsStringAsync().Result);
                int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();
                if (errorCode == 0)
                {
                    var response = accountResponseJson.GetValue("payload").ToObject<TransferOperatorsResponse>();
                    if (response != null)
                    {
                        urls = response.Operators.Select(e => new SitemapUrl
                        {
                            ChangeFrequency = ChangeFrequency.Weekly,
                            Priority = 0.9,
                            Url = Url.Action("SendCreditByOperator", "Home",
                            new
                            {
                                continent = e.Continent.Replace(' ', '-'),
                                country = e.countryName.Replace(' ', '-'),
                                OperatorName = e.operatorName.Trim().Replace(' ', '-')+"-recharge"
                            })
                        }).ToList();
                    }
                }
            }
            return urls;
        }
    }
}