﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants;
public static partial class AppEnums
{
    public enum UserTypeEnum
    {
        Customer = 1,
        Admin = 2,
        Guest = 3
    }
}
