﻿using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class UserProductsResponseModel
    {
        public int Id { get; set; }
        public ProductType ProductName { get; set; }
        public int UserId { get; set; }
        public string ProductRef { get; set; }
        public DateTime AddedDatetime { get; set; }
        public bool IsActive { get; set; }
        public string AccountId { get; set; }
    }
}
