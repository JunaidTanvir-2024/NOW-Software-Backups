﻿namespace THCC.Application.Models.Dtos
{
    public class ServerDirectoriesModel
    {
        public List<DomainPath> DomainPath { get; set; } = new List<DomainPath>();
        public Uri? DomainName { get; set; } = default!;
    }
    public class DomainPath
    {
        public string? VirtualPath { get; set; }
        public string? PhysicalPath { get; set; }
    }
}
