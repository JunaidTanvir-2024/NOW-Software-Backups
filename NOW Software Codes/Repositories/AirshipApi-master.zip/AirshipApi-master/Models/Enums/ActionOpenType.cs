﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
   
    public enum ActionOpenType
    {
        deep_link = 1,
        url = 2,
        landing_page = 3      
    }
}
