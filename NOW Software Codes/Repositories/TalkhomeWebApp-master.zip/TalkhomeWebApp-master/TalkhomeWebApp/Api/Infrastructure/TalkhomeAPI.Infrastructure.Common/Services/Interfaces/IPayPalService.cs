﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.PaypalApiContracts;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface IPayPalService
    {
        Task<GenericApiResponse<PayPalCreateSalePaymentResponse>> PayPalCreateSalePayment(PayPalCreateSalePaymentRequest request);
        Task<GenericApiResponse<PayPalExecuteSalePaymentResponse>> PayPalExecuteSalePayment(PayPalExecuteSalePaymentRequest request);
        Task<GenericPayPalApiResponse<PayPalByPay360CSPaymentResponse>> PayPalByPay360CS(PayPalByPay360CSPaymentRequest request);
        Task<GenericPayPalApiResponse<PayPalByPay360ESPaymentResponse>> PayPalByPay360ES(PayPalByPay360ESPaymentRequest request);
        Task<GenericPayPalApiResponse<PaypalRefundResponse>> PaypalRefund(RefundFullPaymentRequestModel request);
    }
}
