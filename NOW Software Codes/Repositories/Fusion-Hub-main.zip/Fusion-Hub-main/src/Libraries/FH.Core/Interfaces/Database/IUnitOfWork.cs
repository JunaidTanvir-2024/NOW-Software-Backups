using FH.Core.DependencyResolver;

namespace FH.Core.Interfaces.Database;

public interface IUnitOfWork : IDisposable, ServiceType.IScoped
{
    IAppLoggerRepository AppLoggerRepository { get; }
    ICountryRepository CountryRepository { get; }
    ICurrencyRepository CurrencyRepository { get; }
    IDataDumpRepository DataDumpRepository { get; }
    IOperatorRepository OperatorRepository { get; }
    IProductRepository ProductRepository { get; }
    ITransactionRepository TransactionRepository { get; }
    IVendorRepository VendorRepository { get; }
    ICategoryRepository CategoryRepository { get; }

    void BeginTransaction();

    void Commit();

    void Rollback();
}
