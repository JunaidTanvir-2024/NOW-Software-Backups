using FluentValidation;

using Voucherify.Api.Features.Customers.Requests;

namespace Voucherify.Api.Features.Vouchers.Requests;

public class RedeemVoucherRequest
{
    public string VoucherCode { get; set; } = null!;
    public AddCustomerRequest Customer { get; set; } = null!;
}
internal class RedeemVoucherRequestValidator : AbstractValidator<RedeemVoucherRequest>
{
    public RedeemVoucherRequestValidator()
    {
        RuleFor(p => p.VoucherCode).NotNull().NotEmpty();
        RuleFor(p => p.Customer).NotNull().NotEmpty();
    }
}