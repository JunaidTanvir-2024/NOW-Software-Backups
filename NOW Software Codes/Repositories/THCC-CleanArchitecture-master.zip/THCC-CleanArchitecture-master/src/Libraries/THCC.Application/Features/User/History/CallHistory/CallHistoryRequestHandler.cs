﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.History.CallHistory
{
    public class CallHistoryRequestHandler : IRequestHandler<CallHistoryRequest, object>
    {
        #region Fields

        private readonly ICurrentUser _currentUser;
        private readonly IUserRepository _userRepository;
        private readonly ICallingCardRepository _callingCardRepository;
        private readonly IPhoneNumberService _phoneNumberService;

        #endregion

        #region Ctor

        public CallHistoryRequestHandler(
            ICurrentUser currentUser,
            IUserRepository userRepository,
            ICallingCardRepository callingCardRepository,
            IPhoneNumberService phoneNumberService)
        {
            _currentUser = currentUser;
            _userRepository = userRepository;
            _callingCardRepository = callingCardRepository;
            _phoneNumberService = phoneNumberService;
        }

        #endregion

        #region Method

        public async Task<object> Handle(CallHistoryRequest request, CancellationToken cancellationToken)
        {
            request.CardPin = request.CardPin.Trim();
            var type = request.CardPin.Split("-");
            request.CardPin = type[1];

            var response = new CallHistoryResponse() { CallHistory = new List<CallHistory>() };

            //Get Rechargeable card data
            if (type[0].Equals(nameof(ProductItemCode.THRCC)))
            {
                //Check rechargeable card 
                var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
                if (userProduct != null)
                {
                    var cardNumberInfo = await _userRepository.GetAccountDetails(userProduct!.Product!);
                    if (cardNumberInfo?.PinNumber!.Trim().Equals(request.CardPin) == true)
                    {
                        var historyResponse = await _callingCardRepository.GetRechargableCardCallHistory(request.CardPin);
                        if (historyResponse?.Count > 0)
                        {
                            var callHistoryData = historyResponse.ConvertAll(item => new CallHistory()
                            {
                                AccessNumber = item.ADA!.Trim(),
                                Country = _phoneNumberService.GetCountry(item.Dialed_Number!).Result,
                                DateTime = item.DateTime.ToString(),
                                DialedNumber = item.AOA!.Trim(),
                                ReceiverNumber = item.Dialed_Number!.Substring(2).Trim(),
                                Duration = TimeSpan.FromSeconds(item.Duration).ToString(@"hh\:mm\:ss\:fff"),
                            }).ToList();

                            response.CallHistory = callHistoryData;
                        }
                        return response;
                    }
                }
            }

            //Get classic card data
            //1.First Call active
            //2.Active
            //3.Suspended
            //4.Dormant
            //5.Inactive
            if (type[0].Equals(nameof(ProductItemCode.THCC)))
            {
                var isUserPin = await _callingCardRepository.IsUserPinNumber(
                                                request.CardPin, _currentUser.GetUserId());
                if (isUserPin)
                {
                    var historyResponse = await _callingCardRepository.GetClassicCardCallHistory(request.CardPin);//"8909331591"
                    if (historyResponse?.Count > 0)
                    {
                        var callHistoryData = historyResponse.ConvertAll(item => new CallHistory()
                        {
                            AccessNumber = item.ADA!.Trim(),
                            Country = _phoneNumberService.GetCountry(item.Dialed_Number!).Result,
                            DateTime = item.DateTime.ToString(),
                            DialedNumber = item.AOA!.Trim(),
                            ReceiverNumber = item.Dialed_Number!.Substring(2).Trim(),
                            Duration = TimeSpan.FromSeconds(item.Duration).ToString(@"hh\:mm\:ss\:fff"),
                        }).ToList();

                        response.CallHistory = callHistoryData;
                    }
                    return response;
                }
            }

            return ErrorResult.Failure(CustomStatusKey.InvalidPin, CustomStatusCode.BadRequest);
        }

        #endregion
    }
}
