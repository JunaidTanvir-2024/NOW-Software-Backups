﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class TalkHomeService : ITalkHomeService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger _logger;
        private readonly TalkHomeConfig _talkHomeConfig;

        public TalkHomeService(HttpClient httpClient,
                            IOptions<TalkHomeConfig> talkHomeConfig,
                            ILogger logger)
        {
            _httpClient = httpClient;
            _logger = logger;
            _talkHomeConfig = talkHomeConfig.Value;
        }

        public async Task<GenericApiResponse<SignUpResponse>> SignUp(SignUpRequest request)
        {
            string endpoint = _talkHomeConfig.ApiEndPoint + "useraccount/create";

            var Json = JsonConvert.SerializeObject(request);

            _httpClient.DefaultRequestHeaders.Add("NowtelAuth", _talkHomeConfig.NowtelAuthToken);

            var content = new StringContent(Json, Encoding.UTF8, "application/json");

            var output = await _httpClient.PostAsync(endpoint, content);

            _logger.Error($"Class: AccountController, Method: SignUp, " +
                $"ResponseCode :{ JsonConvert.SerializeObject(output.StatusCode)}, Request: {JsonConvert.SerializeObject(request)}" );

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<GenericApiResponse<SignUpResponse>>(outputData);
            }

            return null;
        }
    }
}
