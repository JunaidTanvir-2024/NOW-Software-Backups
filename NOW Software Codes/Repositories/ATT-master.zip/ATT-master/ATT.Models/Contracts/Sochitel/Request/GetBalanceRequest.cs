﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ATT.Models.Contracts.Sochitel.Request
{
    public class GetBalanceRequest : BaseRequest 
    {
        public string command = "getBalance";
    }
}
