﻿using SC.Core.Common.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Users;
internal class ÚpdateAccountDetailHandler : IRequestHandler<ÚpdateAccountDetailRequest, IResultWrapper>
{
    private readonly IUserRepository _userRepository;
    private readonly ICommonService _commonService;
    private readonly IHelperService _helperService;
    public ÚpdateAccountDetailHandler(
      IUserRepository IUserRepository, ICommonService commonService, IHelperService helperService)
    {
        _userRepository = IUserRepository;
        _commonService = commonService;
        _helperService = helperService;
    }

    public async Task<IResultWrapper> Handle(ÚpdateAccountDetailRequest request, CancellationToken cancellationToken)
    {
        var dateParsed = _helperService.ConvertToDateFormat(request.DateOfBirth, out DateTime result);
        if (!dateParsed)
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);

        var response = await _userRepository.ÚpdateAccountDetail(new UserAccountDto()
        {
            UserID = _commonService.GetUserID(),
            FirstName = request.FirstName,
            LastName = request.LastName,
            FrontName = request.FrontName,
            DateOfBirth = result,
            Gender = request.Gender,
            Avatar = request.Avatar
        });
        return ResultWrapper.Success(new { IsUpdated = response });
    }
}

