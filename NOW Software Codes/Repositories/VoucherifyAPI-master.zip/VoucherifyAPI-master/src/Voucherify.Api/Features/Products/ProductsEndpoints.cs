using Voucherify.Api.Features.Products.Requests;
using Voucherify.Core.Commons.Filters;

namespace Voucherify.Api.Features.Products;

public static class ProductsEndpoints
{
    private const string EndpointPrefix = "/api/products";
    private const string EndpointTag = "Products Endpoints";

    public static void AddProductsEndpoints(this WebApplication app)
    {
        var productsEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);

        productsEndpoints
            .MapGet("", GetProducts)
            .AddEndpointFilter<FluentValidationFilter<GetProductsRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        productsEndpoints
        .MapGet("/{ProductNameOrId}", GetProduct)
        .AddEndpointFilter<FluentValidationFilter<GetProductRequest>>()
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound);

        productsEndpoints
        .MapGet("/skus", GetSkus)
        .AddEndpointFilter<FluentValidationFilter<GetSkusRequest>>()
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound);

        productsEndpoints
       .MapGet("/skus/{skuNameOrId}", GetSku)
       .AddEndpointFilter<FluentValidationFilter<GetProductSkuRequest>>()
       .Produces(StatusCodes.Status400BadRequest)
       .Produces(StatusCodes.Status200OK)
       .Produces(StatusCodes.Status404NotFound);

    }
    private static async Task<IResult> GetProducts(IProductsHandler productsHandler, [AsParameters] GetProductsRequest request)
    {
        var result = await productsHandler.GetProducts(request);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetProduct(IProductsHandler productsHandler, [AsParameters] GetProductRequest request)
    {
        var result = await productsHandler.GetSpecificProduct(request);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetSkus(IProductsHandler productsHandler, [AsParameters] GetSkusRequest request)
    {
        var result = await productsHandler.GetProductSkus(request);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetSku(IProductsHandler productsHandler, [AsParameters] GetProductSkuRequest request)
    {
        var result = await productsHandler.GetSpecificSkus(request);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
}
