﻿using ATT.Models.Contracts;
using ATT.Models.Contracts.TransferTo.Response;
using ATT.Models.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.TransferTo
{
    public interface ITransfertoAutomation_BL
    {
        Task<JsonOperatorProductResponse> transferToGetOperatorProductsMSISDN(string destinationMSISDN, string account, int originDestinationId);

        Task<JsonOperatorProductResponse> transferToGetOperatorProductsMSISDN(string destinationMSISDN, string account, int originDestinationId, string sourceMSISDN);

        Task<JsonOperatorProductResponse> transferToDirectGetOperatorProductsMSISDN(string sourceMSISDN, string destinationMSISDN, string account,string productItem=null,string productItemCode = null);
        Task<JsonOperatorProductResponse> CRM_ATT_transferToDirectGetOperatorProductsMSISDN(string fromMSISDN, string account, string ToMsisdn, int? cdsp_config_id, string productCode, string productItemCode, string ProductId, int selectedCarrierNumber);
        Task<JsonATTCRMOperatorProductResponse> transferToATTCRMDirectGetOperatorProductsMSISDN(string sourceMSISDN, string destinationMSISDN, string account, string productId);

        Task<JsonOperatorProductResponse> transferToDirectGetOperatorProductsMSISDN(string sourceMSISDN, string destinationMSISDN, string account, string product);

        Task<TransfertoDataBundlesProductsJsonResponse> transferToGetDataBundlesOperatorProductsMSISDN(string destinationMSISDN, string account, int originDestinationId);

        Task<JsonOperatorProductResponse> transferToFreeSwitchGetOperatorProductsMSISDN(string sourceMSISDN, string destinationMSISDN, string account, string productCode, string productItemCode);
        Task<JsonATTCRMOperatorProductResponse> transferToATTCRMFreeSwitchGetOperatorProductsMSISDN(string destinationMSISDN, string account);

        Task<JsonOperatorProductResponse> DTOneDirectGetOperatorProductsMSISDN(string sourceMSISDN, string destinationMSISDN, string account, string product, string productItemCode);

        Task<object> ExecuteTransactionFreeSwitch(ExecuteData data);
    }
}
