﻿using BasketWebPanel.Areas.Dashboard.Models.ApiRequest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models
{
    public class PlansApiResponseModel
    {
        public IEnumerable<Addplan> Plans { get; set; }
    }
}