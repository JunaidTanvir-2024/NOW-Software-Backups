﻿using SmsOutReachCallBackUrlApi.Contracts.Poppayouts.Request;
using SmsOutReachCallBackUrlApi.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SmsOutReachCallBackUrlApi.Infrastructure.Poppayouts
{
    public interface IPoppayoutsPost
    {
        Task<DbResult> InsertUpdateSmsCallBackUrlData(PoppayoutsSmsCallBackUrlRequest deliveryReport);
    }
}
