﻿namespace THCC.Domain.Aggregates
{
    public class PinDetail
    {
        public string? Account { get; set; }
        public string? Pin { get; set; }
    }
}