﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Airship.Request;
using Models.Contracts.Airship.Response;
using Models.Contracts.Pay360.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using RestSharp;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class Channel_BL : IChannel_BL
    {

        private IApiCall ApiCall;
        private readonly ILogger Logger;
        private IChannel_DL ChannelDb;
        

        public Channel_BL(ILogger logger, IApiCall apiCall, IChannel_DL channelDb)
        {
            Logger = logger;
            ApiCall = apiCall;
            ChannelDb = channelDb;
        }

        public async Task<GenericApiResponse<string>> AddChannel(AddChannelRequest request)
        {

            try
            {
                GetChannelRequest chRequest = new GetChannelRequest() { ChannelId = request.ChannelId, ProductCode = request.ProductCode };
                GenericApiResponse<ApiGetChannelByIdResponse> chResponse = await GetChannelById(chRequest);
                if(chResponse.errorCode == 0) // Success
                {
                    ApiGetChannelByIdResponse channelData = chResponse.payload;
                    var dbResult = await ChannelDb.AddChannel(channelData.channel, request.ProductCode);
                    if(dbResult.Status == Status.Success)
                    {
                        return GenericApiResponse<string>.Success("Success");
                    }
                    else // Failure
                    {
                        return GenericApiResponse<string>.Failure(dbResult.ErrorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }
                else // Error
                {
                    return GenericApiResponse<string>.Failure(chResponse.message, ApiStatusCodes.UnSuccessful);
                }                

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class:  Channel_BL, Method: AddChannel, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }

        public async Task<GenericApiResponse<string>> AddChannelTags(AddChannelTagsRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<string>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/channels/tags";
                Dictionary<string, List<string>> tags = new Dictionary<string, List<string>>();
                tags.Add(request.TagGroup, request.Tags);
                ApiAddChannelTagsRequest apiRequest = new ApiAddChannelTagsRequest() { audience = new ApiAddChannelTagsAudience() {  amazon_channel = request.ChannelId, android_channel = request.ChannelId, channel = request.ChannelId, ios_channel = request.ChannelId, deviceType = request.DeviceType }, add = tags };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest);
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Channel_BL, Method: AddChannelTags, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<string>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiOkResponse apiResponseModel = JsonConvert.DeserializeObject<ApiOkResponse>(responseJson);
                        if (apiResponseModel.Ok == true)
                        {

                            var dbResult = await ChannelDb.AddChannelTags(request);
                            if (dbResult.Status == Status.Success)
                            {
                                return GenericApiResponse<string>.Success(null, "Success");
                            }
                            else
                            {
                                return GenericApiResponse<string>.Failure(dbResult.ErrorMessage, ApiStatusCodes.UnSuccessful);
                            }

                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<string>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Channel_BL, Method: AddChannelTags, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }

        public async Task<GenericApiResponse<ApiGetChannelByIdResponse>> GetChannelById(GetChannelRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<ApiGetChannelByIdResponse>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/channels/" + request.ChannelId;               
                IRestResponse httpResponse = await ApiCall.Get(url, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Channel_BL, Method: GetChannelById, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<ApiGetChannelByIdResponse>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiGetChannelByIdResponse apiResponseModel = JsonConvert.DeserializeObject<ApiGetChannelByIdResponse>(responseJson);
                        if (apiResponseModel.ok == true)
                        {
                            return GenericApiResponse<ApiGetChannelByIdResponse>.Success(apiResponseModel, "Success");
                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<ApiGetChannelByIdResponse>.Failure("Unsuccessfull", ApiStatusCodes.UnSuccessful);
                        }

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        ApiStatusCodes code = (httpResponse.StatusCode == System.Net.HttpStatusCode.NotFound ? ApiStatusCodes.InvalidChannel : ApiStatusCodes.UnSuccessful);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetChannelByIdResponse>.Failure(errorMessage, code);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetChannelByIdResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class:  Channel_BL, Method: GetChannelById, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApiGetChannelByIdResponse>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericApiResponse<ApiGetChannelsResponse>> GetChannels(GetAllChannelsRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<ApiGetChannelsResponse>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/channels";
                IRestResponse httpResponse = await ApiCall.Get(url, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Channel_BL, Method: GetChannels, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<ApiGetChannelsResponse>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiGetChannelsResponse apiResponseModel = JsonConvert.DeserializeObject<ApiGetChannelsResponse>(responseJson);
                       
                            return GenericApiResponse<ApiGetChannelsResponse>.Success(apiResponseModel, "Success");
                                                
                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        ApiStatusCodes code = (httpResponse.StatusCode == System.Net.HttpStatusCode.NotFound ? ApiStatusCodes.InvalidChannel : ApiStatusCodes.UnSuccessful);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetChannelsResponse>.Failure(errorMessage, code);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetChannelsResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class:  Channel_BL, Method: GetChannels, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApiGetChannelsResponse>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }

    }
}
