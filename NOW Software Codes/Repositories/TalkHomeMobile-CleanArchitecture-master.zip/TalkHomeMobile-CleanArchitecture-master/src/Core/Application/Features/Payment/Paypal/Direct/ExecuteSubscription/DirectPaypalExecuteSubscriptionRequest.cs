﻿using Application.Features.Payment.Paypal.Models;

namespace Application.Features.Payment.Paypal.Direct.ExecuteSubscription;

public class DirectPaypalExecuteSubscriptionRequest : IRequest<Result<PaypalResponse>>
{
    public int OrderId { get; set; }
    public string? CustomerUniqueRef { get; set; }
    public string? Subscription_Id { get; set; }
    public string? Ba_Token { get; set; }
    public string? Token { get; set; }
    //public string? PayerId { get; set; }
    //public string? PaymentId { get; set; }
    public bool IsFastTopup { get; set; } = false;

}