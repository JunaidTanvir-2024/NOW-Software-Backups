﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class ReSendTokenViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
