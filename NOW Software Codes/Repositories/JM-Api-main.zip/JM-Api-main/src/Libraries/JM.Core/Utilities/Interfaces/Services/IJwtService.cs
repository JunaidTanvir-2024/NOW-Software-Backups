using System.Security.Claims;
using System.Security.Cryptography;

using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Services;

public interface IJwtService : ResolveAs.IScoped
{
    (string jwtToken, DateTime jwtTokenExpiry, string refreshToken, DateTime refreshTokenExpiry) GetTokensAsync(string fullName, string email, long id);
    ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
    ECDsa GetSecurityKeyViaFile(string filePath);
}
