﻿using System.Globalization;

using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

namespace THCC.Application.Features.User.AccountSummary;

public class AccountSummaryRequestHandler : IRequestHandler<AccountSummaryRequest, object>
{
    #region Fields 

    private readonly IUserRepository _userRepo;
    private readonly IMapper _mapper;
    private readonly ITopupRepository _topupRepo;
    private readonly IPointsRepository _pointsRepo;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly ProfileSettings _profileSetting;
    private readonly TopupSettings _topupSettings;

    #endregion

    #region Ctors
    public AccountSummaryRequestHandler(
        IUserRepository userRepo,
        IMapper mapper,
        ITopupRepository topupRepo,
        IPointsRepository pointsRepo,
        ICurrentUser currentUser,
        ICommonService commonService,
        IOptions<ProfileSettings> profileSetting,
        IOptions<TopupSettings> options)
    {
        _userRepo = userRepo;
        _mapper = mapper;
        _topupRepo = topupRepo;
        _pointsRepo = pointsRepo;
        _currentUser = currentUser;
        _commonService = commonService;
        _profileSetting = profileSetting.Value;
        _topupSettings = options.Value;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(AccountSummaryRequest request, CancellationToken cancellationToken)
    {
        var userProduct = await _userRepo.GetUserProducts(_currentUser.GetUserId());
        if (userProduct == null)
        {
            return ErrorResult.Failure(CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
        }

        var accountDetail = await _userRepo.GetAccountDetails(userProduct!.Product!);
        var lasttopupInfo = await _userRepo.GetLastTopup(userProduct.Product!);
        if (!string.IsNullOrEmpty(lasttopupInfo.Date))
        {
            DateTime dateTime = DateTime.ParseExact(lasttopupInfo.Date, "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
            lasttopupInfo.Date = dateTime.ToString("dd MMM yyyy");
        }
        var autoTopup = await _topupRepo.GetAutoTopup(userProduct!.Product!, _currentUser.GetUserEmail()!);
        if (autoTopup!=null)
        {
            autoTopup.ThresHold /= 100;
        }
        var user = await _userRepo.GetUserByEmailAsync(_currentUser.GetUserEmail());
        if (!string.IsNullOrEmpty(user?.ProfileImage))
        {
            user!.ProfileImage = !string.IsNullOrEmpty(user?.ProfileImage!.Trim()) ? $"{_commonService.GetHostRequestUrl()}{_profileSetting.VirtualDirectoryName}/{user!.Id}/{user.ProfileImage}" : null;
        }
        var response = new AccountSummaryDto
        {
            UserInfo = _mapper.Map<UserDto>(user!),
            ProductInfo = new ProductDto
            {
                CardNumber = accountDetail.CardNumber!.Trim(),
                PinNumber = accountDetail.PinNumber!.Trim(),
                Credit = CurrencySymbol.GBP + accountDetail.Credit!,
                LastTopup = new LastTopupDto()
                {
                    Amount = CurrencySymbol.GBP + lasttopupInfo.Amount,
                    Date = lasttopupInfo.Date
                }
            },
            AutoTopupInfo = autoTopup == null ? new AutoTopupResponseDto()
            {
                Status = false,
                Threshold = _topupSettings.AutoTopupSettings.ThresholdAmount
            } :  _mapper.Map<AutoTopupResponseDto>(autoTopup!),
            Points = await _pointsRepo.GetPoints(userProduct!.Product!),
            MinimumRedeemablePoints = 500
        };

        if (response.Points >= 500)
        {
            int totalPoints = 500;
            while (totalPoints <= response.Points)
            {
                response.RedeemablePoints.Add(new KeyValuePair<int, string>(totalPoints, $"{totalPoints} Points - {CurrencySymbol.GBP}{totalPoints / 100}"));
                totalPoints += totalPoints;
            }
        }
        return response;
    }

    #endregion
}
