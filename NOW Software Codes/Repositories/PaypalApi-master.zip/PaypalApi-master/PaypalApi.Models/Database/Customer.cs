﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Database
{
    
    public class Customer
    {
       
        public int Id { get; set; }
        public string Name { get; set; }
        public string MerchantRef { get; set; }
        public string ProductCode { get; set; }        
        public string Email { get; set; }
        public string Msisdn { get; set; }
        public string DefaultCurrency { get; set; }       
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }      
        public string City { get; set; }
        public string State { get; set; }
        public string PostCode { get; set; }       
        public string CountryCode { get; set; }
        public string Phone { get; set; }
        
    }
}
