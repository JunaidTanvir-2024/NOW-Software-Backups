using Application.Features.Account.History.Models;

namespace Application.Features.Account.History.Data;
public class PaymentUsageHistoryRequestHandler : IRequestHandler<DataUsageHistoryRequest, Result<DataHistoryResponse>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<PaymentUsageHistoryRequestHandler> _localizer;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;
    public PaymentUsageHistoryRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<PaymentUsageHistoryRequestHandler> localizer,
        ICommonService commonService,
        IUserService userService)
    {
        _uow = uow;
        _localizer = localizer;
        _commonService = commonService;
        _userService = userService;
    }
    public async Task<Result<DataHistoryResponse>> Handle(DataUsageHistoryRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();
        if (IsAppRequest)
        {
            request.StartDate = DateTime.UtcNow.Date;
            request.EndDate = DateTime.UtcNow.Date.AddDays(7);
            request.PageNo = 1;
            request.PageSize = 20;
        }
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<DataHistoryResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var dataHistory = await _uow.UserRepo.DataHistory(request.Msisdn, request.StartDate, request.EndDate, request.PageNo, request.PageSize);
        var dataHistoryResponse = new DataHistoryResponse()
        {
            History = dataHistory,
            TotalCount = dataHistory.Select(x => x.TotalCount).FirstOrDefault(),
            PageNo = request.PageNo,
            RecordsFiltered = dataHistory.Count()
        };
        return Result<DataHistoryResponse>.Success(dataHistoryResponse, _localizer[CustomStatusKey.Success]);
    }
}