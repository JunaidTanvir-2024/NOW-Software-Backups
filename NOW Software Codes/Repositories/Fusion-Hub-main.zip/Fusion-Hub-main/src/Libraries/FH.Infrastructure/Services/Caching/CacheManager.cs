using Microsoft.Extensions.Caching.Distributed;

namespace FH.Infrastructure.Services.Caching;

internal sealed class CacheManager(IDistributedCache distributedCache) : ICacheManager
{
	private readonly IDistributedCache _distributedCache = distributedCache;

	public async Task StoreInCache(string? cacheKey, string? cacheValue, string? expiryInMinutes)
	{

		var cacheOptions = new DistributedCacheEntryOptions
		{
			AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(Convert.ToInt64(expiryInMinutes)),
		};
		if (!string.IsNullOrEmpty(cacheValue) && !string.IsNullOrEmpty(cacheKey))
		{
			await _distributedCache.SetStringAsync(cacheKey, cacheValue, cacheOptions);
		}
	}
	public async Task<string?> RetrieveFromCache(string? cacheKey)
	{
		return !string.IsNullOrEmpty(cacheKey) ? await _distributedCache.GetStringAsync(cacheKey) : string.Empty;
	}
}
