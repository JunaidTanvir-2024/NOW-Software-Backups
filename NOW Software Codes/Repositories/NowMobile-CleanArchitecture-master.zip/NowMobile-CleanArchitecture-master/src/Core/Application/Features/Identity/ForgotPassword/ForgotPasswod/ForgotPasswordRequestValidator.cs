﻿namespace Application.Features.Identity.ForgotPassword.ForgotPasswod;

public class ForgotPasswordRequestValidator : AbstractValidator<ForgotPasswordRequest>
{
    public ForgotPasswordRequestValidator(ICommonService commonService)
    {
        RuleFor(data => data.EmailAddress)
            .Cascade(CascadeMode.Stop)
            .NotNull().NotEmpty()
            .Must(p => commonService.IsValidEmailAddress(p))
            .WithMessage("Invalid Email Address");
    }
}
