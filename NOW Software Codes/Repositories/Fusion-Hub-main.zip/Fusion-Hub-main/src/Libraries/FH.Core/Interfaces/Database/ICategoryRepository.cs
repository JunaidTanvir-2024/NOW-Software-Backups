using FH.Core.DependencyResolver;
using FH.Core.DTOs.Database;

namespace FH.Core.Interfaces.Database;

public interface ICategoryRepository : ServiceType.IScoped
{
    Task<IEnumerable<SubCategoryDto.Response>> GetSubCategoryName(SubCategoryDto.Request request);
}
