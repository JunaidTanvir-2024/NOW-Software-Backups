﻿using Models.Contracts.Response;
using Models.Database;
using System;
using System.Collections.Generic;

namespace Models.Contracts.Request
{
    public class UserAccount
    {
        public UserAccount()
        {
            this.UserAccountBalance = new UserAccountBalance();

            this.UserAccountDetails = new UserAccountDetails();

            this.UserAccountBundles = new UserAccountBundles();
        }

        public JwtToken jwt { get; set; }

        public long SignupPoints { get; set; } // Property Specific to voucherify
        
        public IEnumerable<LocalAccessNumber2> localaccess { get; set; }
        public IEnumerable<string> stunServers { get; set; }
        public string Msisdn { get; set; }

        public string AccountID { get; set; }

        public int SubscriberId { get; set; }

        public string Pin { get; set; }

        public string Serial { get; set; }

        public bool canEnterReferralCode { get; set; }

        public bool isSIPCallLockedIPV6 { get; set; }

        public bool isIPV6MsgDisplay { get; set; }

        public bool isReturningUser { get; set; }

        public string scdisable { get; set; }

        public bool canShowApp2APP { get; set; }
        public bool multiStepFO { get; set; }
        public ForceUpdateMessage forceUpdateMessage { get; set; }

        public PaidCallSettings PaidCallSettings { get; set; }
        public a2aCallSettings A2ACallSettings { get; set; }

        private string sipUserName;

        public string SipUserName
        {
            get
            {
                return String.Format("THA{0}", this.Msisdn);
            }
            set { this.sipUserName = value; }
        }

        public string SipPassword { get; set; }

        public UserAccountBalance UserAccountBalance { get; set; }

        public UserAccountDetails UserAccountDetails { get; set; }

        public UserAccountBundles UserAccountBundles { get; set; }

        public useremailRegistration emailRegistration { get; set; }

        public Profile userProfile { get; set; }
    }


    public class a2aCallSettings
    {
        public string port { get; set; }
        public bool isTLS { get; set; }
        public string url { get; set; }
    }

    public class UserWebAddress
    {
        public string title { get; set; }

        public string lname { get; set; }

        public string fname { get; set; }

        public string email { get; set; }

        public string addr1 { get; set; }

        public string addr4 { get; set; }

        public string addr5 { get; set; }

        public string postal_code { get; set; }

        public string country { get; set; }

        public string currency { get; set; }

        public string pin { get; set; }


    }

    public class LocaleSettings
    {

        public string Locale { get; set; }

        public string AppLanguage { get; set; }

        public string AccountType { get; set; }


    }

    public class InAppDetails
    {
        public string title { get; set; }

        public string lname { get; set; }

        public string fname { get; set; }

        public string email { get; set; }

        public string addr1 { get; set; }

        public string addr4 { get; set; }

        public string addr5 { get; set; }

        public string postal_code { get; set; }

        public string country { get; set; }

        public string currency { get; set; }

        public string pin { get; set; }

        public string Locale { get; set; }

        public string AppLanguage { get; set; }

        public string AccountType { get; set; }

        public string CountryCode { get; set; }

        public string CurrencySymbol { get; set; }
    }

    public class UserAccountInformation
    {
        public string Na_Service_Id { get; set; }

        public string Currency { get; set; }

        public string Msisdn { get; set; }

        public string AccountID { get; set; }

    }

    public class MsisdnInfomation
    {

        public string Msisdn { get; set; }

        public bool isexistingUser { get; set; }
        public bool isPreAuthVerified { get; set; }

    }
    public class PaidCallSettings
    {
        public string port { get; set; }
        public bool isTLS { get; set; }
        public string realmIPV4 { get; set; }
        public string realmIPV6 { get; set; }
        public bool is_somme_user { get; set; }
        public string transport { get; set; }
    }

}
