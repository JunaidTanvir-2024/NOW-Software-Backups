﻿using System.Text.Json.Serialization;

namespace CallingCode.Mvc.Common.Models;

public class CountriesData
{
    public static string[] PopularCountries = new string[] { "United States", "Spain", "Canada", "France", "Germany", "Ireland", "Australia", "South Africa", "Italy", "Greece", "India", "Portugal", "Poland", "Malaysia", "Ghana", "China", "Pakistan", "Russia", "Nigeria", "Norway" };
    public List<Country> Countries { get; set; } = new List<Country>();
}
public class Country
{
    [JsonPropertyName("name")]
    public Name? Name { get; set; }
    [JsonPropertyName("cities")]
    public List<City>? Cities { get; set; }

    [JsonPropertyName("tld")]
    public string[]? Tld { get; set; }

    [JsonPropertyName("cca2")]
    public string? Cca2 { get; set; }

    [JsonPropertyName("ccn3")]
    public string? Ccn3 { get; set; }

    [JsonPropertyName("cca3")]
    public string? Cca3 { get; set; }

    [JsonPropertyName("cioc")]
    public string? Cioc { get; set; }

    [JsonPropertyName("independent")]
    public bool Independent { get; set; }

    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("unMember")]
    public bool UnMember { get; set; }

    [JsonPropertyName("currencies")]
    public Currencies? Currencies { get; set; }

    [JsonPropertyName("idd")]
    public Idd? Idd { get; set; }

    [JsonPropertyName("capital")]
    public string[]? Capital { get; set; }

    [JsonPropertyName("altSpellings")]
    public string[]? AltSpellings { get; set; }

    [JsonPropertyName("region")]
    public string? Region { get; set; }

    [JsonPropertyName("subregion")]
    public string? Subregion { get; set; }

    [JsonPropertyName("languages")]
    public Languages? Languages { get; set; }

    [JsonPropertyName("translations")]
    public Dictionary<string, Translation>? Translations { get; set; }

    [JsonPropertyName("latlng")]
    public double[]? Latlng { get; set; }

    [JsonPropertyName("landlocked")]
    public bool Landlocked { get; set; }

    [JsonPropertyName("borders")]
    public string[]? Borders { get; set; }

    [JsonPropertyName("area")]
    public double Area { get; set; }

    [JsonPropertyName("demonyms")]
    public Demonyms? Demonyms { get; set; }

    [JsonPropertyName("flag")]
    public string? Flag { get; set; }

    [JsonPropertyName("maps")]
    public Maps? Maps { get; set; }

    [JsonPropertyName("population")]
    public long Population { get; set; }

    [JsonPropertyName("gini")]
    public Gini? Gini { get; set; }

    [JsonPropertyName("fifa")]
    public string? Fifa { get; set; }

    [JsonPropertyName("car")]
    public Car? Car { get; set; }

    [JsonPropertyName("timezones")]
    public string[]? Timezones { get; set; }

    [JsonPropertyName("continents")]
    public string[]? Continents { get; set; }

    [JsonPropertyName("flags")]
    public Flags? Flags { get; set; }

    [JsonPropertyName("coatOfArms")]
    public CoatOfArms? CoatOfArms { get; set; }

    [JsonPropertyName("startOfWeek")]
    public string? StartOfWeek { get; set; }

    [JsonPropertyName("capitalInfo")]
    public CapitalInfo? CapitalInfo { get; set; }

    [JsonPropertyName("postalCode")]
    public PostalCode? PostalCode { get; set; }
}

public partial class CapitalInfo
{
    [JsonPropertyName("latlng")]
    public double[]? Latlng { get; set; }
}

public partial class Car
{
    [JsonPropertyName("signs")]
    public string[]? Signs { get; set; }

    [JsonPropertyName("side")]
    public string? Side { get; set; }
}

public partial class CoatOfArms
{
    [JsonPropertyName("png")]
    public Uri? Png { get; set; }

    [JsonPropertyName("svg")]
    public Uri? Svg { get; set; }
}

public partial class Currencies
{
    [JsonPropertyName("GTQ")]
    public Gtq? Gtq { get; set; }
}

public partial class Gtq
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("symbol")]
    public string? Symbol { get; set; }
}

public partial class Demonyms
{
    [JsonPropertyName("eng")]
    public Eng? Eng { get; set; }

    [JsonPropertyName("fra")]
    public Eng? Fra { get; set; }
}

public partial class Eng
{
    [JsonPropertyName("f")]
    public string? F { get; set; }

    [JsonPropertyName("m")]
    public string? M { get; set; }
}

public partial class Flags
{
    [JsonPropertyName("png")]
    public Uri? Png { get; set; }

    [JsonPropertyName("svg")]
    public Uri? Svg { get; set; }

    [JsonPropertyName("alt")]
    public string? Alt { get; set; }
}

public partial class Gini
{
    [JsonPropertyName("2014")]
    public double The2014 { get; set; }
}

public partial class Idd
{
    [JsonPropertyName("root")]
    public string? Root { get; set; }

    [JsonPropertyName("suffixes")]
    public string[]? Suffixes { get; set; }
}

public partial class Languages
{
    [JsonPropertyName("spa")]
    public string? Spa { get; set; }
}

public partial class Maps
{
    [JsonPropertyName("googleMaps")]
    public Uri? GoogleMaps { get; set; }

    [JsonPropertyName("openStreetMaps")]
    public Uri? OpenStreetMaps { get; set; }
}

public partial class Name
{
    [JsonPropertyName("common")]
    public string? Common { get; set; }

    [JsonPropertyName("official")]
    public string? Official { get; set; }

    [JsonPropertyName("nativeName")]
    public NativeName? NativeName { get; set; }
}

public partial class NativeName
{
    [JsonPropertyName("spa")]
    public Translation? Spa { get; set; }
}

public partial class Translation
{
    [JsonPropertyName("official")]
    public string? Official { get; set; }

    [JsonPropertyName("common")]
    public string? Common { get; set; }
}
public partial class City
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }
    [JsonPropertyName("code")]
    public string? Code { get; set; }
}
public partial class PostalCode
{
    [JsonPropertyName("format")]
    public string? Format { get; set; }

    [JsonPropertyName("regex")]
    public string? Regex { get; set; }
}