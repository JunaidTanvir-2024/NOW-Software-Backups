﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBITopUpHistory
    {
        public string AccountId { get; set; }
        public string PaymentTypeId { get; set; }
        public string PaymentRef { get; set; }
        public string StatusId { get; set; }
        public string NowtelRef { get; set; }
        public string ClientCurrency { get; set; }
        public string ReceiverCurrency { get; set; }
        public string Product { get; set; }
        public string ItemPrice { get; set; }
        public string OperaterID { get; set; }
        public string TotalPrice { get; set; }
        public string FromMsisdn { get; set; }
        public string ToMsisdn { get; set; }
        public string OperatorCountryName { get; set; }
        public string CountryCode { get; set; }
        public string OperatorName { get; set; }
        public string OperatorLogoURL { get; set; }
        public string IsActive { get; set; }
        public string TransferRef { get; set; }
        public DateTime TransactionDateTime { get; set; }
        public string MediumTypeId { get; set; }
    }
}
