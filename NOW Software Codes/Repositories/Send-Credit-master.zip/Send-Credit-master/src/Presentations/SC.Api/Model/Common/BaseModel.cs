﻿using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Model.Common;
public class BaseModel
{
    public int Page { get; set; } = default(int);
    public bool IsActive { get; set; } = default(bool);
    public bool IsDeleted { get; set; } = default;
    public int RecordsPerPage { get; set; } = 25;


}

