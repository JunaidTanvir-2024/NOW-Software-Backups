namespace Voucherify.Api.Features.Promotions.Responses;

public class PromotionTierValidationResponse
{
    public bool IsValid { get; set; }

    public string? PromotionTierId { get; set; }
}
