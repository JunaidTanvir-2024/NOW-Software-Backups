﻿using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetAllAdminsResponse
    {
        public IEnumerable<DBAdmin> AdminsList { get; set; }
    }
}
