﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using TalkHomeContactSyncApi.Contracts;
using TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Request;
using TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Response;
using TalkHomeContactSyncApi.Infrastructure.ContactSync;

namespace TalkHomeContactSyncApi.Controllers
{
    [Authorize]
    public class ContactSyncController : Controller
    {
        private readonly IContactSyncPost Post;
        private readonly ILogger Ilogger;
        public ContactSyncController(ILogger logger, IContactSyncPost post)
        {
            this.Ilogger = logger;
            this.Post = post;
        }

        [HttpPost]
        [Route("TalkHomeContacts_Or_Not")]
        async public Task<IActionResult> TalkHomeContacts_Or_Not()
        {
            Ilogger.Information($"Processing - Post: ContactSync/TalkHomeContacts_Or_Not ");
            string requestJsonData = "";
            try
            {

                using (StreamReader reader = new StreamReader(Request.Body, Encoding.UTF8))
                {
                    requestJsonData = await reader.ReadToEndAsync();
                }
                ContactSyncRequest Contacts;
                if (requestJsonData.Contains("["))
                {
                    Contacts = JsonConvert.DeserializeObject<ContactSyncRequest>(requestJsonData);
                }
                else
                {
                    Contacts = new ContactSyncRequest();
                    if (requestJsonData != "")
                    {
                        ContactSyncRequest req = JsonConvert.DeserializeObject<ContactSyncRequest>(requestJsonData);
                        Contacts = req;
                    }
                    else
                    {
                        return BadRequest();
                    }
                }
                GenericApiResponse<IList<ContactSyncResponse>> result = await Post.GetFilteredTalkHomeContacts(Contacts);

                return Json(result);


            }
            catch (Exception ex)
            {
                Ilogger.Error($"Exception - Post: ContactSync/TalkHomeContacts_Or_Not, Parameters --> Contacts: {requestJsonData}, ExceptionMessage: {ex.Message}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}