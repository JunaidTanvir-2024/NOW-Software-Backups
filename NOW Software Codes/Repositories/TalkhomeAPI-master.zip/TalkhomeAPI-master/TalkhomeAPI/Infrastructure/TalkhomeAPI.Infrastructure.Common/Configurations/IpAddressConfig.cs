﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class IpAddressConfig
    {
        public int requestsLimit { get; set; }
        public int requestsLimitMinutes { get; set; }
    }
}
