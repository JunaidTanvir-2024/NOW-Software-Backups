﻿var ProgressClass_sum = "";
var TextClass_sum = "";

$(document).ready(function () {

    ShowUserSummary_sum($("#dplUserProducts").val());

    $("#dplUserProducts").change(function () {
        ShowUserSummary_sum($("#dplUserProducts").val());
        $('#TopUp_Msisdn_AccountSummary').val($("#dplUserProducts").val());
    });

});

function ShowUserSummary_sum(ID) {
    $.ajax({
        url: "/Account/GetUserSummary",
        type: "POST",
        data: { ProductRef: ID },
        beforeSend: function (xhr) {
            $('#UserSummaryFailureAlert').slideUp();
            $('.loading-bar').show();
        },
        success: function (response) {
            if (response != null) {
                if (response.status == true && response.data != null) {


                    if (response.data.bundleList != null && response.data.bundleList.length > 0) {

                        var html = '';

                        $.each(response.data.bundleList, function (key, val) {
                            if (val.packageCategory != 8) {
                                if (val.expiry != null) {

                                    var percentageMinute = parseFloat(100 - parseFloat((((parseInt(val.minutes) - parseInt(val.remainingMinutes)) * 100) / parseInt(val.minutes)))).toFixed(0);
                                    var percentageText = parseFloat(100 - parseFloat((((parseInt(val.texts) - parseInt(val.remainingTexts)) * 100) / parseInt(val.texts)))).toFixed(0);
                                    var percentageData = parseFloat(100 - parseFloat((((parseInt(val.data) - parseInt(val.remainingData)) * 100) / parseInt(val.data)))).toFixed(0);


                                    if (new Date() < new Date(val.expiry)) {

                                        html += "<div class=\"block\" style=\"padding-bottom:30px;\">";

                                        html += CommonCardsHtml_sum(val);

                                        html += "<div class=\"clearfix\">" +
                                            "<div class=\"plan-name float-none float-md-left red\">Expires in " + ((new Date(val.expiry) - new Date()) / 86400000).toFixed(0) + " day(s)</div>" +

                                            //"<div class=\"float-none float-md-right\">" +
                                            //"<button type=\"button\" class=\"btn btn-primary btn-primary-2 BtnSavSettings_autoRenew\"  data-Uuid=" + val.uuid + "><i class=\"fa fa-spinner fa-spin Spinner_SavSettings_autoRenew\" data-Uuid=" + val.uuid + "  style=\"display: none\"></i> Save</button>" +
                                            //"</div>" +

                                            "</div>";




                                        if (val.minutes != 0 || val.texts != 0 || val.data != 0) {
                                            html += "<hr/>";
                                        }

                                        html += "<div class=\"row AllCardsRow\">";

                                        if (val.minutes != 0) {
                                            AddProgressClass_sum(percentageMinute);
                                            html += NotExpiredCards_sum(val.minutes, val.remainingMinutes, percentageMinute, "Minutes");
                                        }
                                        if (val.texts != 0) {
                                            AddProgressClass_sum(percentageText);
                                            html += NotExpiredCards_sum(val.texts, val.remainingTexts, percentageText, "Texts");
                                        }
                                        if (val.data != 0) {
                                            AddProgressClass_sum(percentageData);
                                            html += NotExpiredCards_sum(val.data, val.remainingData, percentageData, "Data");
                                        }

                                        html += "</div></div></div>";

                                    }
                                    else {

                                        html += "<div class=\"block red-bg expired\">";
                                        html += CommonCardsHtml_sum(val);

                                        //html += "<div class=\"clearfix\">" +
                                        //    "<div class=\"plan-name float-none float-md-left\">Expired</div>" +
                                        //    "</div>";

                                        if (val.minutes != 0 || val.texts != 0 || val.data != 0) {
                                            html += "<hr/>";
                                        }

                                        html += "<div class=\"row\">";

                                        if (val.minutes != 0) {
                                            AddProgressClass_sum(percentageMinute);
                                            html += ExpiredCards(val.minutes, val.remainingMinutes, percentageMinute, "Minutes");
                                        }
                                        if (val.texts != 0) {
                                            AddProgressClass_sum(percentageText);
                                            html += ExpiredCards(val.texts, val.remainingTexts, percentageText, "Texts");
                                        }
                                        if (val.data != 0) {
                                            AddProgressClass_sum(percentageData);
                                            html += ExpiredCards(val.data, val.remainingData, percentageData, "Data");
                                        }

                                        html += "</div></div></div>";
                                    }
                                }
                                //html += "<div class=\"block\">" +

                                //    "</div>";


                                //html += "<div class=\"form-row AutoTopUpContent_topup\" style=\"\">" +
                                //    "   <div class=\"col-8 col-md-6 col-lg-6\" >" +
                                //    "      <div class=\"auto-renew pt-2\">" +
                                //    //"         <div class=\"custom-control custom-switch\">" +
                                //    //"            <input type=\"checkbox\" class=\"custom-control-input\" data-val=\"true\" data-val-required=\"The isAutoTopup field is required.\" id=\"isAutoTopup\" name=\"isAutoTopup\" value=\"true\">" +
                                //    //"               <label class=\"custom-control-label cursor\" for=\"isAutoTopup\">Auto-Topup Enabled</label>"+
                                //    //"          </div>" +
                                //    "     </div>" +
                                //    "</div>" +
                                //    " <div class=\"col-4 col-md-6 col-lg-6\">" +
                                //    "    <div class=\"button float-right\">" +
                                //     "<button type=\"button\" class=\"btn btn-primary btn-primary-2 BtnSavSettings_autoRenew\"  data-Uuid=" + val.uuid + "><i class=\"fa fa-spinner fa-spin Spinner_SavSettings_autoRenew\" data-Uuid=" + val.uuid + "  style=\"display: none\"></i> Save</button>" +
                                //    "  </div>" +
                                //    " </div>" +
                                //    "</div >";


                                html += "  <div class=\"form-row\">" +
                                    "<div class=\"col-12 mt-2 mb-2 SavSettingsFailureAlert_autoRenew\" data-Uuid=" + val.uuid + "  style=\"display: none\" >" +
                                    "   <div class=\"alert alert-danger\">" +
                                    "      <span class=\"SavSettingsFailureMessage_autoRenew\" data-Uuid=" + val.uuid + "></span>" +
                                    " </div>" +
                                    "</div >" +

                                    " <div class=\"col-12 mt-2 SavSettingsSuccessAlert_autoRenew\" data-Uuid=" + val.uuid + "  style=\"display: none\">" +
                                    "    <div class=\"alert alert-success\">" +
                                    "       <span class=\"SavSettingsSuccessMessage_autoRenew\" data-Uuid=" + val.uuid + "></span>" +
                                    "  </div>" +
                                    "</div>" +
                                    " </div >";
                            }
                        });

                        $('#PlansContent_Summary').html('');
                        $('#PlansContent_Summary').css('padding', "20px");
                        $('#PlansContent_Summary').html(html);

                        AddColumnClass_sum();
                    }
                    else {
                        $('#PlansContent_Summary').css('padding', "20px").css('padding-left', "70px");
                        $('#PlansContent_Summary').html('No Records were found.');
                    }

                    //if (response.data.callingHisotryTotalRecords == 0
                    //    || response.data.callingHistory == null
                    //    || response.data.callingHistory.length < 1) {
                    //    $('#callHistorySection_Summary').html('No Record found');
                    //}
                    //else {
                    //    var IsFirstTimeLoaded_Callhistory = true;
                    //    $('#pagination_callhistory_summary').twbsPagination({
                    //        totalPages: Math.ceil(parseInt(response.data.callingHisotryTotalRecords) / 10),
                    //        visiblePages: Math.ceil(parseInt(response.data.callingHisotryTotalRecords) / 10),
                    //        next: 'Next',
                    //        prev: 'Prev',
                    //        onPageClick: function (event, page) {
                    //            if (!IsFirstTimeLoaded_Callhistory) {
                    //                $('#content_callHistorySection_Summary').html();
                    //            }
                    //            else {
                    //                IsFirstTimeLoaded_Callhistory = false;
                    //                $('#tableCallhistory_Summary').html(GenerateTableCallHistory_sum(response.data.callingHistory));
                    //            }
                    //        }
                    //    });
                    //}
                }
                else {

                    $('#UserSummaryFailureAlert').slideDown().delay(4000).slideUp();
                }
            }
            else {

                $('#UserSummaryFailureAlert').slideDown().delay(4000).slideUp();
            }
        },
        complete: function (xhr, status) {
            $('.loading-bar').hide();
        },
        error: function (xhr, status, error) {

            $('#UserSummaryFailureAlert').slideDown().delay(4000).slideUp();
        }
    });
}


function AddProgressClass_sum(percentage) {

    if (percentage >= 0 && percentage <= 50) {
        ProgressClass_sum = "bg-danger";
        TextClass_sum = "text-danger";
    }
    else if (percentage >= 50 && percentage <= 75) {
        ProgressClass_sum = "bg-warning";
        TextClass_sum = "text-warning";
    }
    else {
        ProgressClass_sum = "bg-success";
        TextClass_sum = "text-success";
    }

}

function NotExpiredCards_sum(Total, Remaining, percentage, Text) {

    if (Text == "Data") {
        Text = Text + " MB";
    }

    return "<div class=\"col-lg-4\"><h6>" + Text + " (" + Remaining + " of " + Total + ")</h6>" +
        "<div class=\"pt-1\">" +
        "<div class=\"progress\">" +
        "<div class=\"progress-bar progress-bar-striped " + ProgressClass_sum + "\" role=\"progressbar\" style=\"width:" + percentage + "%\" aria-valuenow=" + percentage + " aria-valuemin=\"0\" aria-valuemax=\"100\">" + percentage + "%</div>" +
        "</div>" +
        "</div></div>";
}

function ExpiredCards(Total, Remaining, percentage, Text) {

    if (Text == "Data") {
        Text = Text + " MB";
    }

    return "<div class=\"col-lg-4\"><h6>" + Text + " (" + Remaining + " of " + Total + ")</h6>" +
        "<div class=\"pt-1\">" +
        "<div class=\"progress\">" +
        "<div class=\"progress-bar progress-bar-striped " + ProgressClass_sum + "\" role=\"progressbar\" style=\"width:" + percentage + "%\" aria-valuenow=" + percentage + " aria-valuemin=\"0\" aria-valuemax=\"100\">" + percentage + "%</div>" +
        "</div>" +
        "</div></div>";

}

function CommonCardsHtml_sum(val) {
    var returnHtml = "";
    var isRenew = val.isRenew == true ? '  Checked' : '';
    returnHtml += "<div class=\"clearfix\">";

    if (new Date() < new Date(val.expiry)) {
        returnHtml += "<div class=\"plan-name  float-none float-md-left\"><b>" + val.brandedName + "</b></div>";
    } else {
        returnHtml += "<div class=\"float-none float-md-left  text-white\"><b>" + val.brandedName + "</b></div><div class=\"plan-name float-none float-md-right  text-white\">Expired</div>";
    }
    if (val.packageCategory != 8) {
        returnHtml += "<div class=\"float-none float-md-right\">" +
            "<label class=\"switch float-left\">" +
            "<input type=\"checkbox\" class=\"isAutoRenew\" value=\"true\" name=\"isAutoRenew\" data-Uuid=" + val.uuid + "   " + isRenew + "   data-totalCostPence=" + val.totalCostPence + ">" +
            "<span class=\"slider round\"></span>" +
            "<input type=\"hidden\" value=\"false\" name=\"isAutoRenew\">" +
            "</label>" +
            "<div class=\"package-price autoRenewSwitchText float-left\">Auto Renew</div>" +
            "<div class=\"help pl-2  float-left autorenewText\">" +
            "<a class=\"popup-with-move-anim\" href=\"#auto-renew\" >" +
            "<i class=\"fas fa-info-circle\"></i>" +
            "</a >" +
            "</div >" +
            //"<button type=\"button\" class=\"btn btn-primary btn-primary-2\" onclick=\"BuyPlanAgain_AccSum(this)\" data-id=" + val.id + " >Buy again £" + val.totalCostPence + "</button>" +
            "</div>";
    }
    returnHtml += "</div>";

    return returnHtml;
}

function AddColumnClass_sum() {

    for (var i = 0; i < $('.AllCardsRow').length; i++) {

        var childrenlength = $(".AllCardsRow")[i].children.length;
        if (childrenlength > 0) {

            if (childrenlength == 1) {
                $(".AllCardsRow")[i].children[0].className = 'col-lg-12'
            }
            else if (childrenlength == 2) {
                $(".AllCardsRow")[i].children[0].className = 'col-lg-6';
                $(".AllCardsRow")[i].children[1].className = 'col-lg-6';

            }
            else if (childrenlength == 3) {
                $(".AllCardsRow")[i].children[0].className = 'col-lg-4';
                $(".AllCardsRow")[i].children[1].className = 'col-lg-4';
                $(".AllCardsRow")[i].children[2].className = 'col-lg-4';
            }
        }
        else {
            continue;
        }
    }
}

function BuyPlanAgain_AccSum(current) {
    $('#SelectedPlanId_AccSum').val(current.dataset.id);
    $('#BundleBuyForm_AccSum').submit();
}

function GenerateTableCallHistory_sum(data) {

    let HistoryBodyHtml = '';

    $.each(data, function (key, val) {
        HistoryBodyHtml += "<tr>" +
            "<td>" + val.called_party_number + "</td>" +
            "<td>" + val.start_time + "</td>" +
            "<td>" + val.duration + "</td>" +
            "<td>" + val.inbound + "</td>" +
            "<td>" + val.subscriber_charge + "</td>" +
            "</tr>";
    });

    return HistoryBodyHtml;
}

$(document).on('click', ".BtnSavSettings_autoRenew", function () {

    var Uuid = $(this).attr('data-Uuid');
    SetBundleAutoRenewal(Uuid);

});

function SetBundleAutoRenewal(bundle_id) {
    var Uuid = bundle_id;
    var isAutoRenew = $(".isAutoRenew[data-Uuid=" + Uuid + "]:first-child").is(':checked');
    var totalCostPence = $(".isAutoRenew[data-Uuid=" + Uuid + "]:first-child").attr('data-totalCostPence');

    $.ajax({
        url: "/Account/SetBundleAutoRenewal",
        type: "POST",
        data: {
            Msisdn: $('#dplUserProducts').val(),
            Uuid: Uuid,
            isAutoRenew: isAutoRenew,
            BundleAmount: totalCostPence

        },
        beforeSend: function (xhr) {
            $('.SavSettingsFailureAlert_autoRenew, .SavSettingsSuccessAlert_autoRenew').hide();
            $('.BtnSavSettings_autoRenew[data-Uuid=' + Uuid + ']').attr('disabled', true);
            $('.Spinner_SavSettings_autoRenew[data-Uuid=' + Uuid + ']').fadeIn();
        },
        success: function (response) {

            if (response != null) {

                if (response.status == true) {
                    $('.SavSettingsSuccessMessage_autoRenew[data-Uuid=' + Uuid + ']').text(response.message);
                    $('.SavSettingsSuccessAlert_autoRenew[data-Uuid=' + Uuid + ']').slideDown().delay(3000).slideUp();
                }
                else {
                    $('.SavSettingsFailureMessage_autoRenew[data-Uuid=' + Uuid + ']').text(response.message);
                    $('.SavSettingsFailureAlert_autoRenew[data-Uuid=' + Uuid + ']').slideDown().delay(5000).slideUp();
                }

            }
            else {
                $('.SavSettingsFailureMessage_autoRenew[data-Uuid=' + Uuid + ']').text('Something went wrong on server.');
                $('.SavSettingsFailureAlert_autoRenew[data-Uuid=' + Uuid + ']').slideDown().delay(3000).slideUp();
            }
        },
        complete: function (xhr, status) {

            $('.BtnSavSettings_autoRenew[data-Uuid=' + Uuid + ']').attr('disabled', false);
            $('.Spinner_SavSettings_autoRenew[data-Uuid=' + Uuid + ']').hide();
        },
        error: function (xhr, status, error) {
            $('.SavSettingsFailureMessage_autoRenew[data-Uuid=' + Uuid + ']').text('Something went wrong on server.');
            $('.SavSettingsFailureAlert_autoRenew[data-Uuid=' + Uuid + ']').slideDown().delay(3000).slideUp();
        }
    });
}


$(document).on('change', ".isAutoRenew", function () {
    var Uuid = $(this).attr('data-Uuid');
    var sameBundles = $(".isAutoRenew[data-Uuid=" + Uuid + "]");

    $(sameBundles).prop("checked", $(this).is(':checked'));

    SetBundleAutoRenewal(Uuid);
});

$(document).on('click', '.autorenewText', function () {
    var theGoodStuff = $("#auto-renew-model");
    $.magnificPopup.open({
        items: {
            src: theGoodStuff
        },
        type: 'inline',
        preloader: false,
        focus: '#username',
        modal: true,
        fixedContentPos: false
    });

});
