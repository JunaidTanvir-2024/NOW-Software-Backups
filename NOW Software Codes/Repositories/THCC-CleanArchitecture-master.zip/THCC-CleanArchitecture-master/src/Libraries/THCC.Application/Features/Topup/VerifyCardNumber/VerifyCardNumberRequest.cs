﻿namespace THCC.Application.Features.Topup.VerifyCardNumber
{
    public class VerifyCardNumberRequest : IRequest<object>
    {
        public string CardNumber { get; set; } = default!;
    }

    public class VerifyCardNumberValidator : AbstractValidator<VerifyCardNumberRequest>
    {
        public VerifyCardNumberValidator()
        {
            RuleFor(data => data.CardNumber)
                .NotNull()
                .NotEmpty()
                .MaximumLength(20).WithMessage("Your card number length must not exceed 20.");
        }
    }
}
