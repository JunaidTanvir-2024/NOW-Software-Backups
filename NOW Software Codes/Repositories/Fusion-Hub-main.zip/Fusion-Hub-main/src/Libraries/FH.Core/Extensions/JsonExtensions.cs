using System.Text.Json;
using System.Text.Json.Serialization;

using FH.Core.Extensions.DTOs;

namespace FH.Core.Extensions;
public sealed class JsonExtensions
{
    public class RangeSerializer : JsonConverter<RangeObject>
    {
        public override RangeObject Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            using JsonDocument doc = JsonDocument.ParseValue(ref reader);
            var root = doc.RootElement;

            if (root.ValueKind == JsonValueKind.Number)
            {
                return new RangeObject
                {
                    Value = root.GetDecimal(),
                    Min = 0,
                    Max = 0
                };
            }
            else if (root.TryGetProperty("min", out JsonElement minElement) && root.TryGetProperty("max", out JsonElement maxElement))
            {
                return new RangeObject
                {
                    Min = minElement.GetDecimal(),
                    Max = maxElement.GetDecimal(),
                    Value = 0
                };
            }
            else
            {
                throw new JsonException("Unexpected JSON structure for 'Amount' field.");
            }
        }

        public override void Write(Utf8JsonWriter writer, RangeObject value, JsonSerializerOptions options)
        {
            if (value.Value != default)
            {
                writer.WriteNumberValue(value.Value);
            }
            else
            {
                writer.WriteStartObject();
                writer.WriteNumber("min", value.Min);
                writer.WriteNumber("max", value.Max);
                writer.WriteEndObject();
            }
        }
    }
    public class DateTimeOffsetSerializer : JsonConverter<DateTimeOffset>
    {
        public override DateTimeOffset Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.String)
            {
                if (DateTimeOffset.TryParse(reader.GetString(), out DateTimeOffset dateTimeOffset))
                {
                    return dateTimeOffset;
                }
            }

            return DateTimeOffset.MinValue; // You can modify this behavior based on your requirements.
        }

        public override void Write(Utf8JsonWriter writer, DateTimeOffset value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToString("yyyy-MM-dd HH:mm:ss"));
        }
    }
}
