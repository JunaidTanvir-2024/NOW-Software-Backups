﻿using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts.Pay360.Response.User
{
    public class UserTransactionResponseModel
    {
        public ApiPaymentResponse Transaction { get; set; }
    }

    public class UserTransactionsResponseModel
    {
        public List<ApiPaymentResponse> Transactions { get; set; }
    }


    public class MERCHANTREF
    {
        public string MerchantRef { get; set; }
    }
}
