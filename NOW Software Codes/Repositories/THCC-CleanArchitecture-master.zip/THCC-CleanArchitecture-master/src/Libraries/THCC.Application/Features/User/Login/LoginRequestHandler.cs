﻿using Microsoft.CodeAnalysis.CSharp;

using THCC.Application.Extensions.Security;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

namespace THCC.Application.Features.User.Login;

public class LoginRequestHandler : IRequestHandler<LoginRequest, object>
{
    #region Fields

    private readonly IUserRepository _userRepo;
    private readonly ILegacyRepository _legacyRepo;
    private readonly ILogger _logger;
    private readonly ICommonService _commonService;
    private readonly ProfileSettings _profileSetting;
    private readonly IUserService _userService;
    private readonly ILegacySecurityService _legacySecurityService;
    private readonly IAirshipService _airshipService;
    private readonly IMapper _mapper;

    #endregion

    #region Ctor

    public LoginRequestHandler(
        IMapper mapper,
        IUserRepository userRepository,
        ILegacyRepository legacyRepository,
        ILogger logger,
        IOptions<ProfileSettings> profileSetting,
        ICommonService commonService,
        IUserService userService,
        ILegacySecurityService legacySecurityService,
        IAirshipService airshipService)
    {
        _mapper = mapper;
        _userRepo = userRepository;
        _legacyRepo = legacyRepository;
        _logger = logger;
        _commonService = commonService;
        _profileSetting = profileSetting.Value;
        _userService = userService;
        _legacySecurityService = legacySecurityService;
        _airshipService = airshipService;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(LoginRequest request, CancellationToken cancellationToken)
    {
        request.Email = request.Email.Trim();
        request.Password = request.Password.Trim();

        var user = await _userRepo.GetUserByEmailAsync(request.Email);
        if (user == null)
        {
            //Check if user exists in legacy db
            var legacyUser = await _legacyRepo.GetUserByEmail(request.Email);
            if (legacyUser == null)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
            }

            if (!legacyUser.IsConfirmedUser)
            {
                _logger.Debug($"Legacy user no confirmed: {legacyUser.Email}");
                return ErrorResult.Failure(
                    CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
            }

            //Validate Password
            bool isAuthenticated = _legacySecurityService.CheckPassword(request.Password, legacyUser);
            if (!isAuthenticated)
            {
                _logger.Debug($"Invalid login attempt from legacy Db: {legacyUser.Email}");
                return ErrorResult.Failure(
                    CustomStatusKey.InvalidCredentials, CustomStatusCode.BadRequest);
            }

            //Register this user in new db 
            var signupResponse = await _userService.SignUpAsync(
                    legacyUser.FirstName.Trim(),
                    legacyUser.LastName.Trim(),
                    request.Email.Trim(),
                    request.Password,
                    UserRole.Customer,
                    true);

            if (!signupResponse.IsSuccess)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
            }

            //Get legacy user product
            var legacyUserProduct = await _legacyRepo.GetUserProducts(legacyUser.Id);

            //Register products in new db
            if (legacyUserProduct != null)
            {
                (bool isProductSuccess, int errorCode, string errorMessage) = await _userRepo.CreateProduct(
                        legacyUserProduct.ProductRef!,
                        signupResponse.Id!,
                        legacyUserProduct.DateCreated);
                if (!isProductSuccess && errorCode > 0)
                {
                    _logger.Error(
                        $"Failied {legacyUser.Email} product registration to new DB with errorCode: " +
                        $"{errorCode} {errorMessage}");

                    //return ErrorResult.Failure(
                    //    CustomStatusKey.CardNumberAlreadyRegistered, CustomStatusCode.BadRequest);
                }
            }
            user = await _userRepo.GetUserByEmailAsync(request.Email);
        }

        //Check if user have password or not
        if (string.IsNullOrEmpty(user!.PasswordHash))
        {
            //Check if user exists in legacy db
            var legacyUser = await _legacyRepo.GetUserByEmail(request.Email);
            if (legacyUser != null)
            {
                //Validate Password
                bool isAuthenticated = _legacySecurityService.CheckPassword(request.Password, legacyUser);
                if (!isAuthenticated)
                {
                    _logger.Debug($"Invalid login attempt with no password-no match from legacy Db: {legacyUser.Email}");
                    return ErrorResult.Failure(
                        CustomStatusKey.InvalidCredentials, CustomStatusCode.BadRequest);
                }
                //Update password with 
                await _userService.AddPasswordAsync(user, request.Password);
            }
            else
            {
                if (await _userRepo.IsSocialLoginUser(user))
                {
                    _logger.Debug($"Invalid login attempt with no password from social login: {request.Email}");
                    return ErrorResult.Failure(
                        CustomStatusKey.InvalidCredentials, CustomStatusCode.BadRequest);
                }
                return ErrorResult.Failure(
                       CustomStatusKey.InvalidCredentials, CustomStatusCode.BadRequest);
            }
        }

        var loginResponse = await _userService.LoginAsync(user!, request.Password, true);
        if (!loginResponse.IsSuccess)
        {
            return ErrorResult.Failure(loginResponse.ErrorMessage!, loginResponse.ErrorCode);
        }
        if (!string.IsNullOrEmpty(user?.ProfileImage))
        {
            user!.ProfileImage = !string.IsNullOrEmpty(user?.ProfileImage!.Trim()) ? $"{_commonService.GetHostRequestUrl()}{_profileSetting.VirtualDirectoryName}/{user!.Id}/{user.ProfileImage}" : null;
        }

        await _airshipService.CreateEmailChannelAndAssociation(user!.Email!);

        return new LoginResponse()
        {
            User = _mapper.Map<UserDto>(user!),
            RefreshToken = loginResponse.RefreshToken!,
            Token = loginResponse.Token!
        };
    }

    #endregion
}