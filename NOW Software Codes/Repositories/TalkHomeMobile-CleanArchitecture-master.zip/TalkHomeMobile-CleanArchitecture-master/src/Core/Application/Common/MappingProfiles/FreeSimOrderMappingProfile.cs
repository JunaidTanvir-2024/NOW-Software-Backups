﻿using Application.Features.Sim;
using Mapster;

namespace Application.Common.MappingProfiles;

internal sealed class FreeSimOrderMappingProfile : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<(SimAddressInfo, User, string Gclid), FreeSimOrder>
       .NewConfig()
       .Map(simOrder => simOrder.UserId, data => $"{data.Item2.Id}")
       .Map(simOrder => simOrder.Email, data => $"{data.Item2.Email}")
       .Map(simOrder => simOrder.FirstName, data => $"{data.Item2.FirstName}")
       .Map(simOrder => simOrder.LastName, data => $"{data.Item2.LastName}")
       .Map(simOrder => simOrder.AddressL1, data => $"{data.Item1.AddressL1}")
       .Map(simOrder => simOrder.AddressL2, data => $"{data.Item1.AddressL2}")
       .Map(simOrder => simOrder.PostCode, data => $"{data.Item1.PostCode}")
       .Map(simOrder => simOrder.City, data => $"{data.Item1.City}")
       .Map(simOrder => simOrder.County, data => $"{data.Item1.County}")
       .Map(simOrder => simOrder.Gclid, data => $"{data.Item3}");
    }
}
