﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class GetAllProductsByUserIDRequestModel
    {
        public int UserId { get; set; }
    }
}
