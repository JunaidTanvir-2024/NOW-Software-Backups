﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.InAppModels
{
    /// <summary>
    /// Provides allowed error styles
    /// </summary>
    public class AlertStyles
    {
        public const string Error = "error";

        public const string Success = "success";
    }

    public class InAppAlert
    {
        public const string TempDataKey = "TempDataAlerts";

        public string AlertStyle { get; set; }

        public bool Dismissable { get; set; }

        public string Message { get; set; }

        public InAppAlert() { }

        public InAppAlert(string alertStyle, string message)
        {
            AlertStyle = alertStyle;

            Message = message;
        }
    }
}
