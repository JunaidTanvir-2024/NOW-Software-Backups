﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATTDaemon.Models.DB
{
    public class at_Operators
    {
      public int operatorRecordID { get; set; }
      public int serviceProviderOperatorID { get; set; }
      public int serviceProviderID { get; set; }
      public string currency { get; set; }
      public string name { get; set; }
      public int countryID { get; set; }
      public string iconUri { get; set; }
      public bool isFixed { get; set; }
    }
}
