﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts.Pay360.Response.User
{
    public class BasketItemsResponse
    {
        public string ProductItemCode { get; set; }
        public bool IsFullFilled { get; set; }
        public string Pin { get; set; }
        public string Card { get; set; }
    }
}
