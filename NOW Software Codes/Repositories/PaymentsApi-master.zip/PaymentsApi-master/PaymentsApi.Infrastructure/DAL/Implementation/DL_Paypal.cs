﻿using Dapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PaymentsApi.Infrastructure.DAL.Database;
using PaymentsApi.Infrastructure.DAL.Interfaces;
using PaymentsApi.Models.Configurations;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.DatabaseConnections;
using PaymentsApi.Models.Utility;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentsApi.Infrastructure.DAL.Implementation
{
    public class DL_Paypal : IDL_Paypal
    {
        private readonly ILogger Logger;
        private readonly IDbConnectionSettings DbConnection;
        private readonly IDbConnectionSettings ThmConnection;
        private readonly IDbConnectionSettings ThrccConnection;
        private readonly IDbConnectionSettings ThccConnection;
        private readonly IDbConnectionSettings ItsaConnection;
        private readonly IDbConnectionSettings TalkHomePaymentsConnection;
        private readonly IDbConnectionSettings ThaConnection;

        public DL_Paypal(
            ILogger logger,
            IOptions<ConnectionString> connectionString)
        {
            Logger = logger;
            DbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
            ThmConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThmConnection));
            ThrccConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThrccConnection));
            ThccConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThccConnection));
            ItsaConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ItsaConnection));
            TalkHomePaymentsConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomePaymentsConnection));
            ThaConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThaConnection));
        }

        public async Task<int> PaypalFraudValidation(string customerMerchantRef, string email, string ipAddress, string productCode, string productItemCode)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@product_code", productCode);
                parameters.Add("@product_item_code", productItemCode);
                parameters.Add("@customer_merchant_ref", customerMerchantRef);
                parameters.Add("@email", email);
                parameters.Add("@ip_address", ipAddress);
                parameters.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);
                var result = await DbConnection.SqlConnection.QueryAsync("Paypal_Api_Validation", parameters, commandType: CommandType.StoredProcedure);

                int ErrorCode = parameters.Get<int>("@error_code");
                string ErrorMessage = parameters.Get<string>("@error_msg");

                return ErrorCode;

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Paypal, Method: PaypalFraudValidation, Parameters => customerMerchantRef: {customerMerchantRef}, email: {email}, ipAddress: {ipAddress}, productCode: {productCode}, productItemCode: {productItemCode}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return 500;
            }

        }

        public async Task<bool> PaypalIsUserWhitelisted(string merchantRef)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@merchantRef", merchantRef);
                parameters.Add("@isWhiteListed", dbType: DbType.Boolean, direction: ParameterDirection.Output);
                var result = await DbConnection.SqlConnection.ExecuteAsync("Paypal_Api_IsUserWhitelisted", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<bool>("@isWhiteListed");
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Paypal, Method: PaypalIsUserWhitelisted, Parameters => email: {merchantRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return false;
            }
        }

        public async Task<DbResult<int>> AddUpdatePaypalCustomer(Customer customer)
        {
            DbResult<int> result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@DisplayName", customer.DisplayName);
                parameters.Add("@MerchantRef", customer.MerchantRef);
                parameters.Add("@Email", customer.Email);
                parameters.Add("@Msisdn", customer.Msisdn);
                parameters.Add("@ProductCode", customer.ProductCode);
                parameters.Add("@AddressLine1", customer.AddressLine1);
                parameters.Add("@AddressLine2", customer.AddressLine2);
                parameters.Add("@AddressLine3", customer.AddressLine3);
                parameters.Add("@AddressLine4", customer.AddressLine4);
                parameters.Add("@City", customer.City);
                parameters.Add("@Region", customer.Region);
                parameters.Add("@PostCode", customer.PostCode);
                parameters.Add("@CountryCode", customer.CountryCode);

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("Paypal_Api_AddUpdateCustomer", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<int>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Paypal, Method: AddUpdatePaypalCustomer, Parameters=> customer: {JsonConvert.SerializeObject(customer)}, ErrorMessage: {ex.Message}, DBErrorMessage: {result.DBErrorMessage}");
                return result;
            }
        }

        public async Task<DbResult<long>> AddTransaction(PaypalTransaction transaction, ProductBasket[] basket, bool AddSummaryTransaction = false)
        {
            DbResult<long> result;
            try
            {

                DataTable items = new DataTable();
                items.Columns.Add("ProductItemCode", typeof(string));
                items.Columns.Add("Amount", typeof(float));
                DataColumn productColumn = items.Columns.Add("ProductRef", typeof(string));
                productColumn.AllowDBNull = true;
                DataColumn bundleColumn = items.Columns.Add("BundleRef", typeof(string));
                bundleColumn.AllowDBNull = true;

                for (int i = 0; i < basket.Length; i++)
                {
                    DataRow row = items.NewRow();
                    row["ProductItemCode"] = basket[i].ProductItemCode;
                    row["Amount"] = basket[i].Amount;
                    row["ProductRef"] = ((string.IsNullOrWhiteSpace(basket[i].ProductRef)) == true ? null : basket[i].ProductRef);
                    row["BundleRef"] = ((string.IsNullOrWhiteSpace(basket[i].BundleRef)) == true ? null : basket[i].BundleRef);
                    items.Rows.Add(row);
                }

                #region Parameters
                var parameters = new DynamicParameters();
                parameters.Add("@Pay360CustomerId", transaction.Pay360CustomerId);
                parameters.Add("@TransactionMerchantRef", transaction.TransactionMerchantRef);
                parameters.Add("@Pay360TransactionId", transaction.Pay360TransactionId);
                parameters.Add("@TransactionDescription", transaction.TransactionDescription);
                parameters.Add("@TransactionStatus_Id", transaction.TransactionStatus_Id);
                parameters.Add("@TransactionType_Id", transaction.TransactionType_Id);
                parameters.Add("@TransactionAmount", transaction.TransactionAmount);
                parameters.Add("@TransactionCurrency", transaction.TransactionCurrency);
                parameters.Add("@TransactionTime", transaction.TransactionTime);
                parameters.Add("@TransactionReceivedTime", transaction.TransactionReceivedTime);
                parameters.Add("@RequestTime", transaction.RequestTime);
                parameters.Add("@OutcomeStatus", transaction.OutcomeStatus);
                parameters.Add("@OutcomeReasonCode", transaction.OutcomeReasonCode);
                parameters.Add("@OutcomeReasonMessage", transaction.OutcomeReasonMessage);
                parameters.Add("@AuthAcquirerName", transaction.AuthAcquirerName);
                parameters.Add("@AuthGatewayReference", transaction.AuthGatewayReference);
                parameters.Add("@AuthGatewayMessage", transaction.AuthGatewayMessage);
                parameters.Add("@Customer_Id", transaction.Customer_Id);
                parameters.Add("@CustomerMerchantRef", transaction.CustomerMerchantRef);
                parameters.Add("@RelatedTransactionId", transaction.RelatedTransactionId);
                parameters.Add("@ClientRedirectUrl", transaction.ClientRedirectUrl);
                parameters.Add("@PaypalPayerID", transaction.PaypalPayerID);
                parameters.Add("@PaypalPayerEmail", transaction.PaypalPayerEmail);
                parameters.Add("@PaypalAccountVerified", transaction.PaypalAccountVerified);
                parameters.Add("@PaypalCheckoutToken", transaction.PaypalCheckoutToken);
                parameters.Add("@AddSummaryTransaction", AddSummaryTransaction);
                parameters.Add("@UserRequestJson", transaction.UserRequestJson);
                parameters.Add("@RequestJsonToPay360", transaction.RequestJsonToPay360);
                parameters.Add("@ResponseJsonFromPay360", transaction.ResponseJsonFromPay360);
                parameters.Add("@ApiInstallationIdCashierApi", transaction.ApiInstallationIdCashierApi);
                parameters.Add("@IsDirectFullfilment", transaction.IsDirectFullfilment);
                if (!string.IsNullOrWhiteSpace(transaction.IpAddress))
                {
                    parameters.Add("@IpAddress", transaction.IpAddress);
                }
                parameters.Add("@TransactionItems", items.AsTableValuedParameter("Pay360TransactionItemType"));
                #endregion


                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<long>>("Paypal_Api_AddTransaction_v1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<long>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Paypal, Method: AddTransaction, Parameters=> AddSummaryTransaction: {AddSummaryTransaction}, BasketJson: {JsonConvert.SerializeObject(basket)},  TransactionJson: {JsonConvert.SerializeObject(transaction)}, ErrorMessage: {ex.Message}");
                return result;
            }

        }

        public async Task<DbResult<long>> AddResumeTransaction(PaypalTransaction transaction)
        {
            DbResult<long> result;
            try
            {


                #region Parameters
                var parameters = new DynamicParameters();
                parameters.Add("@TransactionMerchantRef", transaction.TransactionMerchantRef);
                parameters.Add("@Pay360TransactionId", transaction.Pay360TransactionId);
                parameters.Add("@TransactionDescription", transaction.TransactionDescription);
                parameters.Add("@TransactionStatus_Id", transaction.TransactionStatus_Id);
                parameters.Add("@TransactionType_Id", transaction.TransactionType_Id);
                parameters.Add("@TransactionAmount", transaction.TransactionAmount);
                parameters.Add("@TransactionCurrency", transaction.TransactionCurrency);
                parameters.Add("@TransactionTime", transaction.TransactionTime);
                parameters.Add("@TransactionReceivedTime", transaction.TransactionReceivedTime);
                parameters.Add("@RequestTime", transaction.RequestTime);
                parameters.Add("@OutcomeStatus", transaction.OutcomeStatus);
                parameters.Add("@OutcomeReasonCode", transaction.OutcomeReasonCode);
                parameters.Add("@OutcomeReasonMessage", transaction.OutcomeReasonMessage);
                parameters.Add("@AuthAcquirerName", transaction.AuthAcquirerName);
                parameters.Add("@AuthGatewayReference", transaction.AuthGatewayReference);
                parameters.Add("@AuthGatewayMessage", transaction.AuthGatewayMessage);
                parameters.Add("@Customer_Id", transaction.Customer_Id);
                parameters.Add("@CustomerMerchantRef", transaction.CustomerMerchantRef);
                parameters.Add("@RelatedTransactionId", transaction.RelatedTransactionId);
                parameters.Add("@ClientRedirectUrl", transaction.ClientRedirectUrl);
                parameters.Add("@PaypalPayerID", transaction.PaypalPayerID);
                parameters.Add("@PaypalPayerEmail", transaction.PaypalPayerEmail);
                parameters.Add("@PaypalAccountVerified", transaction.PaypalAccountVerified);
                parameters.Add("@PaypalCheckoutToken", transaction.PaypalCheckoutToken);
                parameters.Add("@UserRequestJson", transaction.UserRequestJson);
                parameters.Add("@RequestJsonToPay360", transaction.RequestJsonToPay360);
                parameters.Add("@ResponseJsonFromPay360", transaction.ResponseJsonFromPay360);
                parameters.Add("@ApiInstallationIdCashierApi", transaction.ApiInstallationIdCashierApi);
                parameters.Add("@IsDirectFullfilment", transaction.IsDirectFullfilment);
                if (!string.IsNullOrWhiteSpace(transaction.IpAddress))
                {
                    parameters.Add("@IpAddress", transaction.IpAddress);
                }
                #endregion


                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<long>>("Paypal_Api_AddResumeTransaction_V1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<long>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Paypal, Method: AddResumeTransaction, Parameters=> TransactionJson: {JsonConvert.SerializeObject(transaction)}, ErrorMessage: {ex.Message}");
                return result;
            }

        }

        public async Task<PaypalTransactionSummary> GetResumeSummaryTran(string paypalCheckoutToken)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@PaypalCheckoutToken", paypalCheckoutToken);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<PaypalTransactionSummary>("Paypal_Api_GetResumeSummaryTran_v1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Paypal, Method: GetResumeSummaryTran, Parameters=> paypalCheckoutToken: {paypalCheckoutToken}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<List<TransactionItems>> GetTransactionItemsForFullfilment(string transactionId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@TransactionId", transactionId);
                var result = await DbConnection.SqlConnection.QueryAsync<TransactionItems>("Paypal_Api_GetTransactionItemsForFullfilment", parameters, commandType: CommandType.StoredProcedure);
                return result.ToList();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Paypal, Method: GetTransactionItemsForFullfilment, Parameters=> transactionId: {transactionId}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<PaypalTransactionSummary> GetSummaryByPay360TransactionId(string pay360TransactionId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Pay360TransactionId", pay360TransactionId);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<PaypalTransactionSummary>("Paypal_Api_GetSummaryByPay360TransactionId_V1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Paypal, Method: GetSummaryByPay360TransactionId, Parameters=> pay360TransactionId: {pay360TransactionId}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<DbResult<long>> AddRefundTransaction(PaypalTransaction transaction)
        {
            DbResult<long> result;
            try
            {


                #region Parameters
                var parameters = new DynamicParameters();
                parameters.Add("@TransactionMerchantRef", transaction.TransactionMerchantRef);
                parameters.Add("@Pay360TransactionId", transaction.Pay360TransactionId);
                parameters.Add("@TransactionDescription", transaction.TransactionDescription);
                parameters.Add("@TransactionStatus_Id", transaction.TransactionStatus_Id);
                parameters.Add("@TransactionType_Id", transaction.TransactionType_Id);
                parameters.Add("@TransactionAmount", transaction.TransactionAmount);
                parameters.Add("@TransactionCurrency", transaction.TransactionCurrency);
                parameters.Add("@TransactionTime", transaction.TransactionTime);
                parameters.Add("@TransactionReceivedTime", transaction.TransactionReceivedTime);
                parameters.Add("@RequestTime", transaction.RequestTime);
                parameters.Add("@OutcomeStatus", transaction.OutcomeStatus);
                parameters.Add("@OutcomeReasonCode", transaction.OutcomeReasonCode);
                parameters.Add("@OutcomeReasonMessage", transaction.OutcomeReasonMessage);
                parameters.Add("@AuthAcquirerName", transaction.AuthAcquirerName);
                parameters.Add("@AuthGatewayReference", transaction.AuthGatewayReference);
                parameters.Add("@AuthGatewayMessage", transaction.AuthGatewayMessage);
                parameters.Add("@Customer_Id", transaction.Customer_Id);
                parameters.Add("@CustomerMerchantRef", transaction.CustomerMerchantRef);
                parameters.Add("@RelatedTransactionId", transaction.RelatedTransactionId);
                parameters.Add("@ClientRedirectUrl", transaction.ClientRedirectUrl);
                parameters.Add("@PaypalPayerID", transaction.PaypalPayerID);
                parameters.Add("@PaypalPayerEmail", transaction.PaypalPayerEmail);
                parameters.Add("@PaypalAccountVerified", transaction.PaypalAccountVerified);
                parameters.Add("@PaypalCheckoutToken", transaction.PaypalCheckoutToken);
                parameters.Add("@UserRequestJson", transaction.UserRequestJson);
                parameters.Add("@ApiInstallationIdCashierApi", transaction.ApiInstallationIdCashierApi);
                parameters.Add("@RequestJsonToPay360", transaction.RequestJsonToPay360);
                parameters.Add("@ResponseJsonFromPay360", transaction.ResponseJsonFromPay360);
                parameters.Add("@IsDirectFullfilment", transaction.IsDirectFullfilment);
                if (!string.IsNullOrWhiteSpace(transaction.IpAddress))
                {
                    parameters.Add("@IpAddress", transaction.IpAddress);
                }
                #endregion


                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<long>>("Paypal_Api_AddRefundTransaction_v1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<long>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Paypal, Method: AddRefundTransaction, Parameters=> TransactionJson: {JsonConvert.SerializeObject(transaction)}, ErrorMessage: {ex.Message}");
                return result;
            }

        }

        public async Task<FullfilmentResponse> ThmStraightCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef, string customerEmail, string productItemCode)
        {
            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@amount", Decimal.Parse(amount));
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@ProductCode", productItemCode);
                parameters.Add("@Email", customerEmail);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

                var result = await ThmConnection.SqlConnection.QueryAsync<THRCCAudit>("thm_paypal_accountupdatebalance_v3", parameters, commandType: CommandType.StoredProcedure);

                if (result != null)
                {
                    int ErrorCode = parameters.Get<int>("@errorcode");
                    string ErrorMessage = parameters.Get<string>("@errormsg");

                    if (ErrorCode == 0)
                    {
                        var audit = result.FirstOrDefault<THRCCAudit>();
                        response.ErrorCode = 0;
                        response.ErrorMessage = "Success";
                        response.Audit = audit;
                    }
                    else
                    {
                        response.ErrorCode = 2;
                        response.ErrorMessage = ErrorMessage;
                        response.Audit = null;
                    }
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "Topup failed";
                    response.Audit = null;
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 1;
                response.ErrorMessage = "Code Exception: " + ex.Message;
                Logger.Error($"Class: DL_Paypal, Method: ThmStraightCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> ThccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);


                var result = await ThccConnection.SqlConnection.QueryAsync<THCCPin>("thcc_getNextPIN_paypal_v1", parameters, commandType: CommandType.StoredProcedure);

                var thpin = result.FirstOrDefault<THCCPin>();

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                }
                else
                {
                    response.ErrorCode = 111;
                    response.ErrorMessage = "Null response received from stored procedure 'thcc_getNextPIN_paypal_v1'";
                    response.Pin = "";
                    Logger.Error($"Class: DL_Paypal, Method: ThccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: Null response received from stored procedure 'thcc_getNextPIN_paypal_v1'");
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = "Getting Next PIN is failed";
                response.Pin = "";
                Logger.Error($"Class: DL_Paypal, Method: ThccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> ThrccCustomerFullfilment(string transactionId, string amount, string productRef, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {

                if (string.IsNullOrEmpty(productRef))
                    productRef = "";

                if (productRef == "")
                {
                    THRCCPin trccPin = await GetNextRCCPin(email, firstname, transactionId);
                    if (trccPin != null && trccPin.account != null)
                    {
                        productRef = trccPin.account.Trim();
                    }
                }


                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }



                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@amount", denomination);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@productref", productRef);
                parameters.Add("@thccpin", null, DbType.String, direction: ParameterDirection.Output, size: 150);
                parameters.Add("@errorcode", null, DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", null, DbType.String, direction: ParameterDirection.Output, size: 200);
                parameters.Add("@account", null, DbType.String, direction: ParameterDirection.Output, size: 50);

                //var result = await ThrccConnection.SqlConnection.QueryAsync<THRCCAudit>("thcc_paypal_accountupdatebalance", parameters, commandType: CommandType.StoredProcedure);
                var result = await ThrccConnection.SqlConnection.QueryAsync<THRCCAudit>("thcc_paypal_accountupdatebalance_v1", parameters, commandType: CommandType.StoredProcedure);

                if (result != null)
                {
                    response.ErrorCode = parameters.Get<int>("@errorcode");
                    response.ErrorMessage = parameters.Get<string>("@errormsg");
                    response.Pin = parameters.Get<string>("@thccpin").Trim();
                    response.productRef = productRef;
                    response.Audit = result.FirstOrDefault<THRCCAudit>();
                    response.Card = parameters.Get<string>("@account").Trim();

                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "PIN Topup failed";
                    response.Pin = "";
                    response.Card = "";
                    response.Audit = null;
                }
            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = "";
                Logger.Error($"Class: DL_Paypal, Method: ThrccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, productRef: {productRef}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        private async Task<THRCCPin> GetNextRCCPin(string email, string firstName, string th_transaction_reference)
        {
            THRCCPin trccPin = new THRCCPin();

            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@email", email);
                parameters.Add("@firstName", firstName);
                parameters.Add("@th_transaction_reference", th_transaction_reference);
                parameters.Add("@pin", null, DbType.String, direction: ParameterDirection.Output, size: 20);
                parameters.Add("@pan", null, DbType.String, direction: ParameterDirection.Output, size: 38);

                var thcc = await ThccConnection.SqlConnection.ExecuteAsync("get_pin_webAPI_v1", parameters, commandType: CommandType.StoredProcedure);

                trccPin.pin = Convert.ToString(parameters.Get<dynamic>("@pin")).Trim();
                trccPin.account = Convert.ToString(parameters.Get<dynamic>("@pan"));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Paypal, Method: GetNextRCCPin, Parameters => th_transaction_reference: {th_transaction_reference}, email: {email}, firstName: {firstName}, ErrorMessage: " + ex.ToString());

            }

            return trccPin;
        }

        public async Task<FullfilmentResponse> NowStraightCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef)
        {
            if (string.IsNullOrEmpty(bundleRef))
                bundleRef = "";

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@amount", Decimal.Parse(amount));
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@bundlename", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ThmConnection.SqlConnection.QueryFirstOrDefaultAsync<THRCCAudit>("now_pay360_accountupdatebalance_v1", parameters, commandType: CommandType.StoredProcedure);

                if (result != null)
                {
                    response.BundleName = parameters.Get<string>("@bundlename");
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Audit = result;
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "Topup failed";
                    response.Audit = null;
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = "Service Not Available ";
                Logger.Error($"Class: DL_Paypal, Method: NowStraightCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> WtccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<WTCCPin>("wtcc_getNextPIN_paypal_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure 'wtcc_getNextPIN_WebAPI_v1'";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Paypal, Method: WtccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> ThaStraightCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef)
        {


            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@amount", Decimal.Parse(amount));
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@ccAuthCode", transactionId);
                parameters.Add("@bundlename", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
                parameters.Add("@error_code", null, DbType.Int32, ParameterDirection.Output);
                parameters.Add("@error_msg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

                var result = await ThaConnection.SqlConnection.QueryAsync<THRCCAudit>("tha_paypal_account_update_balance_add_bundle_v1", parameters, commandType: CommandType.StoredProcedure);
                int errorCode = parameters.Get<int>("@error_code");
                if (errorCode == 0) // Fullfilment Successfull
                {
                    var audit = result.FirstOrDefault();
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Audit = audit;
                    response.BundleName = parameters.Get<string>("@bundlename");
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "Topup failed";
                    response.Audit = null;
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = "Fullfilment failed";
                Logger.Error($"Class: DL_Paypal, Method: ThaStraightCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> StccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<WTCCPin>("stcc_getNextPIN_WebAPI_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Paypal.cs, Method: StccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> BtccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<WTCCPin>("btcc_getNextPIN_WebAPI_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Paypal, Method: BtccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> MtccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<WTCCPin>("xtcc_getNextPIN_WebAPI_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Paypal, Method: MtccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> TdccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<WTCCPin>("tdcc_getNextPIN_WebAPI_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Paypal, Method: TdccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<int> UpdateTransactionItem(int Id, string FullfillmentError, bool IsSmsSent, bool IsEmailSent, bool IsFullfilled, DateTime? SmsSent_DateTime, DateTime? EmailSent_DateTime, DateTime? FulfilmentDateTime)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", Id);
                parameters.Add("@FullfillmentError", FullfillmentError);
                parameters.Add("@IsSmsSent", IsSmsSent);
                parameters.Add("@IsEmailSent", IsEmailSent);
                parameters.Add("@IsFullfilled", IsFullfilled);
                parameters.Add("@SmsSent_DateTime", SmsSent_DateTime);
                parameters.Add("@EmailSent_DateTime", EmailSent_DateTime);
                parameters.Add("@FulfilmentDateTime", FulfilmentDateTime);
                var result = await DbConnection.SqlConnection.ExecuteAsync("Paypal_Api_UpdateTransactionItem", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Paypal, Method: UpdateTransactionItem, Parameters => Id: {Id}, FullfillmentError: {FullfillmentError}, IsFullfilled: {IsFullfilled}, FulfilmentDateTime: {FulfilmentDateTime}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return 0;
            }
        }

        public async Task<int> UpdateTransactionSummaryFullfilmentStatus(string Pay360TransactionId, int transactionStatusId, DateTime fulfilmentDate)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@pay360TransactionId", Pay360TransactionId);
                parameters.Add("@transactionStatusId", transactionStatusId);
                parameters.Add("@fulfilmentDatetime", fulfilmentDate);

                var result = await DbConnection.SqlConnection.ExecuteAsync("Paypal_Api_UpdateTransactionSummary", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Paypal, Method: UpdateTransactionSummaryFullfilmentStatus, Parameters=> Pay360TransactionId: {Pay360TransactionId}, transactionStatusId: {transactionStatusId}, DateTime: {fulfilmentDate} ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<Customer> GetCustomerByMerchantRef(string merchantRef)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@MerchantRef", merchantRef);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<Customer>("Paypal_Api_GetCustomerByMerchantRef", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Paypal, Method: GetCustomerByMerchantRef, Parameters=> merchantRef: {merchantRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }
    }
}
