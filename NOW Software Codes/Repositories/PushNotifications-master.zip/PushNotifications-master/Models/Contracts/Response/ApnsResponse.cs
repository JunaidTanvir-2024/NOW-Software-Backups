﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class ApnsResponse
    {
        public string DeviceToken { get; set; }
        public string Reason { get; set; }
    }
    public class ApnsApiResponse
    {
        public bool IsSuccess { get; set; }

        public ApnsError Error { get; set; }
    }

    public class ApnsError
    {
        public string DeviceToken { get; set; }
        public ApiStatusCodes Reason { get; set; }
        public long? Timestamp { get; set; }
    }

    /// <summary>
    /// https://developer.apple.com/library/archive/documentation/NetworkingInternet/Conceptual/RemoteNotificationsPG/CommunicatingwithAPNs.html#//apple_ref/doc/uid/TP40008194-CH11-SW15
    /// </summary>

}
