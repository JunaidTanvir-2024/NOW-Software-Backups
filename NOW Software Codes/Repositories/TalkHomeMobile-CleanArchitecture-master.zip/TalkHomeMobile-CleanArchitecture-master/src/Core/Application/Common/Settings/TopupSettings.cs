namespace Application.Common.Settings;

//public sealed class TopupSettings
//{
//    public TopupConfig TopupConfig { get; set; } = new TopupConfig();
//}
public sealed class TopupSettings
{
    public const string SectionName = "TopupSettings";
    public static TopupSettings Bind = new TopupSettings();
    public List<float> TopUpAmounts { get; set; } = default!;
    public List<float> AutoTopupThresholdAmounts { get; set; } = default!;
    public float ThresholdAmount { get; set; }
    public float AutoTopupMonthlyMaxLimit { get; set; }
}