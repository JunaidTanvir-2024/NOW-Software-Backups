namespace Voucherify.Api.Features.StackableDiscounts.Responses;

public class StackableDiscountRollbackResponse
{
    public bool IsRollback { get; set; }
}
