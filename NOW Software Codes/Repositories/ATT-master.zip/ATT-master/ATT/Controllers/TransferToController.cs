﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Formatting;
using System.Threading.Tasks;
using System.Xml;
using ATT.Infrastructure.BLL.Common;
using ATT.Infrastructure.BLL.Ding;
using ATT.Infrastructure.BLL.Mobiquity;
using ATT.Infrastructure.BLL.Reloady;
using ATT.Infrastructure.BLL.TransferTo;
using ATT.Infrastructure.DAL;
using ATT.Models.Configurations;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Common;
using ATT.Models.Contracts.TransferTo.Response;
using ATT.Models.Database;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using ServiceProvider = ATT.Models.Database.ServiceProvider;

namespace ATT.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class TransferToController : ControllerBase
    {

        private ITransfertoPost_BL _TransferToPost;
        private ITransfertoAutomation_BL _TransfertoAutomation;
        private ILogger _loggerAPIAccess;
        private IAttDb_DL _appDB;
        private ITransfertoAuth_BL TransferToAuth;
        private TransferToConfig TransferToConf;
        private IDingPost_BL _dingPost_BL;
        private IReloadlyPost_BL _reloadlyPost_BL;
        private IMobiquityPost_BL _mobiquityPost_BL;
        private ICommon_BL _common_BL;
        private readonly SmtpConfig SmtpConfig;
            
        public TransferToController(ITransfertoAutomation_BL transfertoAutomation, ITransfertoPost_BL post, ILogger appLoggers, ICommon_BL common_BL, IAttDb_DL _db, ITransfertoAuth_BL transferToAuth, IOptions<TransferToConfig> transferToConf, IDingPost_BL dingPost_BL, IReloadlyPost_BL reloadlyPost_BL, IMobiquityPost_BL mobiquityPost_BL, IOptions<SmtpConfig> smpt)
        {
            _TransferToPost = post;
            _TransfertoAutomation = transfertoAutomation;
            _loggerAPIAccess = appLoggers;
            _appDB = _db;
            TransferToAuth = transferToAuth;
            TransferToConf = transferToConf.Value;
            _dingPost_BL = dingPost_BL;
            _reloadlyPost_BL = reloadlyPost_BL;
            _mobiquityPost_BL = mobiquityPost_BL;
            SmtpConfig = smpt.Value;
            _common_BL = common_BL;           
        }



        [HttpGet]
        [Route("transferToParseMSISDN")]
        public async Task<IActionResult> transferToParseMSISDNFunction(string currency, string msisdn)
        {
            try
            {
                GenericApiResponse<TransferToMSISDNInfoResponse> s = await _TransferToPost.transfertoParseMSISDN(msisdn, currency);

                var resultPayload = new { data = s.Result };
                var errorResult = new { errorCode = 0, status = "Success", payLoad = resultPayload.data };
                return Ok(errorResult);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToParseMSISDN\"  Failed  Source:General  Parameters-  currency:{currency}     msisdn={msisdn}    Message:{ex.ToString()}");
                var resultPayload = new { reason = "General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                return StatusCode(500, errorResult);
            }
        }


        [HttpGet]
        [Route("transferToReserveID")]
        public async Task<IActionResult> transferToReserveIDFunction(string currency)
        {
            try
            {
                GenericApiResponse<string> s = await _TransferToPost.transfertoReserveID(currency);

                var resultPayload = new { data = s };
                var result = new { errorCode = 0, status = "Success", payLoad = resultPayload.data };
                return Ok(result);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToReserveID\"  Failed  Source:General  Parameters-  currency:{currency}    Message:{ex.ToString()}");
                var resultPayload = new { reason = "General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                return StatusCode(500, errorResult);
            }
        }



        [HttpGet]
        [Route("transferToGetBalance")]
        public async Task<IActionResult> transferToGetCurrentAccountBalance(string currency)
        {
            try
            {
                // GenericApiResponse<string> s = await _TransferToPost.transferToCheckService(currency);

                GenericApiResponse<decimal> bal = await _TransferToPost.transferToGetAccountBalance(currency);
                if (bal.Status == 0)
                {
                    var resultPayload = new { balance = bal.Result };
                    var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
                    return Ok(result);
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToGetBalance\"  Failed  Source:General  Parameters-  currency:{currency}    Message:{bal.Message}");
                    var resultPayload = new { reason = bal.Message };
                    var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToGetBalance\"  Failed  Source:General  Parameters-  currency:{currency}    Message:{ex.ToString()}");
                var resultPayload = new { reason = "General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                return StatusCode(500, errorResult);
            }
        }

        [HttpGet]
        [Route("DtOneGetPromotions")]
        public async Task<IActionResult> DtOneGetPromotions()
        {
            try
            {
                GenericApiResponse<DtOnePromotionsResponse> promotions = await _TransferToPost.DtOneGetPromotions();
                if (promotions.Status == 0)
                {
                    var result = new { errorCode = 0, status = "Success", message = "Success", payLoad = promotions };
                    return Ok(result);
                }
                else
                {
                    var errorResult = new { errorCode = 2, status = "Failure", message = promotions.Message };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($" TransferToController \"GET /DtOneGetPromotions\"  Failed  ,ErrorMessage:{ex.ToString()}");
                var errorResult = new { errorCode = 1, status = "Failure", message = ex.ToString() };
                return StatusCode(500, errorResult);
            }
        }
        [HttpGet]
        [Route("DTOneCountriesList")]
        public async Task<IActionResult> DTOneCountriesList(string currency, string productCode)
        {
            try
            {
                GenericApiResponse<Dictionary<string, string>> countrylist = await _TransferToPost.transfertoCountryList(currency, productCode);
                if (countrylist.Status == 0)
                {
                    var resultPayload = new { countries = countrylist.Result };
                    var result = new { errorCode = 0, status = "Success", message = "Success", payLoad = resultPayload };
                    return Ok(result);
                }
                else
                {
                    var errorResult = new { errorCode = 2, status = "Failure", message = countrylist.Message };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /DTOneCountriesList\"  Failed  Source:General  Parameters-  currency:{currency}, productCode: {productCode},  ErrorMessage:{ex.ToString()}");
                var errorResult = new { errorCode = 1, status = "Failure", message = ex.ToString() };
                return StatusCode(500, errorResult);
            }
        }
        [HttpGet, Route("TransferToCountriesWithOperatorNames")]
        public async Task<IActionResult> TransferToCountriesWithOperatorNames(string continent)
        {
            var countries = await _appDB.GetTransferToCountriesWithOperatorNames(continent);
            //var promotions = await _TransferToPost.DtOneGetPromotions();
            //var countryPromotions = promotions.Result.channel.item.Where(e => countries.Any(f => f.TransferToCountryId == e.countryId)).ToList();
            var result = new
            {
                errorCode = 0,
                status = "Success",
                message = "Success",
                payLoad = new
                {
                    //promotions= countryPromotions,
                    countries = countries
                }
            };

            return Ok(result);
        }
        [HttpGet, Route("TransferToOperatorsWithPromotions")]
        public async Task<IActionResult> TransferToOperatorsWithPromotions(string countryName)
        {
            var operators = await _appDB.GetTransferToOperators(countryName);
            if (operators == null || !operators.Any())
            {
                var onlineCountries = await _TransferToPost.transfertoCountryList("GBP", "THA");
                var countryId = onlineCountries.Result.FirstOrDefault(e => e.Value.Equals(countryName, StringComparison.InvariantCultureIgnoreCase)).Key;
                if (countryId == null)
                {
                    var errorResult = new
                    {
                        errorCode = 1,
                        status = "Failure",
                        message = "Country not found",
                    };
                    return Ok(errorResult);
                }
                var onlineOperators = await _TransferToPost.DTOneOperatorListbyCountry("GBP", int.Parse(countryId), "THA");
                if (onlineOperators != null && onlineOperators.Result.Operators.Any())
                {
                    await _appDB.UpdateTransferToOperators(int.Parse(countryId), onlineOperators.Result.Operators);
                    operators = await _appDB.GetTransferToOperators(countryName);
                }
            }
            var promotions = await _TransferToPost.DtOneGetPromotions();
            var operatorPromotions = from p in promotions.Result.channel.item
                                     join o in operators on p.operatorId equals o.TransferToOperatorId
                                     select new Item()
                                     {
                                         operatorId = p.operatorId,
                                         countryId = p.countryId,
                                         countryName = p.countryName,
                                         dateFrom = p.dateFrom,
                                         dateTo = p.dateTo,
                                         denomination = p.denomination,
                                         denominationLocal = p.denominationLocal,
                                         description = p.description,
                                         promotionstatus = p.promotionstatus,
                                         operatorImageUrl = o.OperatorImageUrl,
                                         operatorName = o.OperatorName,
                                         pubDate = p.pubDate,
                                         subOperatorId = p.subOperatorId,
                                         title = p.title,
                                         title2 = p.title2,
                                     };
            var result = new
            {
                errorCode = 0,
                status = "Success",
                message = "Success",
                payLoad = new
                {
                    operators = operators.GroupBy(e => e.OperatorName).Select(e => e.FirstOrDefault()),
                    promotions = operatorPromotions
                }
            };

            return Ok(result);
        }
        [HttpGet, Route("TransferToOperatorDetails")]
        public async Task<IActionResult> TransferToOperatorDetails(string countryName, string operatorName)
        {
            var operatorDetails = await _appDB.GetTransferToOperatorDetails(countryName, operatorName);
            if (operatorDetails == null)
            {
                var errorResult = new
                {
                    errorCode = 1,
                    status = "Failure",
                    message = "Operator not found",
                };
                return Ok(errorResult);
            }
            var promotions = await _TransferToPost.DtOneGetPromotions();
            var operatorPromotions = promotions.Result.channel.item.Where(e => e.operatorId == operatorDetails.TransferToOperatorId).ToList();
            operatorPromotions.ForEach(e => e.operatorImageUrl = operatorDetails.OperatorImageUrl);
            var operators = await _appDB.GetTransferToOperators(countryName);
            var result = new
            {
                errorCode = 0,
                status = "Success",
                message = "Success",
                payLoad = new
                {
                    operatorDetails,
                    operators = operators.GroupBy(e => e.OperatorName).Select(e => e.FirstOrDefault()),
                    promotions = operatorPromotions
                }
            };

            return Ok(result);
        }
        [HttpGet, Route("SyncTransferToOperators")]
        public async Task<IActionResult> UpdateTransferToOperators()
        {
            var onlineCountriesUSD = await _TransferToPost.transfertoCountryList("USD", "THA");
            var onlineCountriesGBP = await _TransferToPost.transfertoCountryList("GBP", "THA");
            var onlineCountriesEUR = await _TransferToPost.transfertoCountryList("EUR", "THA");
            var onlineCountries = onlineCountriesUSD.Result
                                    .Union(onlineCountriesGBP.Result)
                                    .Union(onlineCountriesEUR.Result)
                                    .GroupBy(e => e.Key).Select(e => e.FirstOrDefault());
            foreach (var item in onlineCountries)
            {
                var operators = await _appDB.GetTransferToOperatorsByCountryId(item.Key);
                if (operators == null || !operators.Any())
                {
                    var onlineOperatorsGBP = (await _TransferToPost.DTOneOperatorListbyCountry("GBP", int.Parse(item.Key), "THA"))?.Result?.Operators ?? new List<OperatorsByCountry>();
                    var onlineOperatorsUSD = (await _TransferToPost.DTOneOperatorListbyCountry("USD", int.Parse(item.Key), "THA"))?.Result?.Operators ?? new List<OperatorsByCountry>();
                    var onlineOperatorsEUR = (await _TransferToPost.DTOneOperatorListbyCountry("EUR", int.Parse(item.Key), "THA"))?.Result?.Operators ?? new List<OperatorsByCountry>();
                    var onlineOperators = onlineOperatorsEUR
                                            .Union(onlineOperatorsUSD)
                                            .Union(onlineOperatorsGBP)
                                            .GroupBy(e => e.OperatorId).Select(e => e.FirstOrDefault())
                                            .ToList();
                    await _appDB.UpdateTransferToOperators(int.Parse(item.Key), onlineOperators);
                }
            }
            return Ok("Data updated successfully");
        }
        [HttpGet]
        [Route("DTOneOperatorListbyCountry")]
        public async Task<IActionResult> DTOneOperatorListbyCountry(string currency, int CountryID, string productCode)
        {
            try
            {
                GenericApiResponse<TransferToOperatorsByCountryId> operatorlist = await _TransferToPost.DTOneOperatorListbyCountry(currency, CountryID, productCode);
                if (operatorlist.Status == 0)
                {

                    var result = new { errorCode = 0, status = "Success", message = "Success", payLoad = operatorlist.Result };
                    return Ok(result);
                }
                else
                {
                    var errorResult = new { errorCode = 2, status = "Failure", message = operatorlist.Message };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /DTOneOperatorListbyCountry\"  Failed  Source:General  Parameters-  currency:{currency}, CountryID: {CountryID}, productCode: {productCode},  ErrorMessage:{ex.ToString()}");
                var errorResult = new { errorCode = 1, status = "Failure", message = ex.ToString() };
                return StatusCode(500, errorResult);
            }
        }


        [HttpGet]
        [Route("transferToOperatorPriceList")]
        public async Task<IActionResult> transferToOperatorPriceListFunction(int OperatorID, string currency)
        {
            try
            {
                GenericApiResponse<string> s = await _TransferToPost.transferToOperatorPriceList(currency, OperatorID);

                var resultPayload = new { data = s.Result };
                var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
                return Ok(result);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToOperatorPriceList\"  Failed  Source:General  Parameters-  currency:{currency}    Message:{ex.ToString()}");
                var resultPayload = new { reason = "General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                return StatusCode(500, errorResult);
            }
        }



        [HttpGet]
        [Route("getTransferToOperatorsAndProducts")]
        public async Task<IActionResult> transferToOperatorsListFunction(int country, string account)
        {
            try
            {
                GenericApiResponse<Dictionary<string, string>> countryOperators = await _TransferToPost.transferToOperatorsList(account, country);

                if (countryOperators.Status == 0)
                {
                    if (countryOperators.Result.Count > 0)
                    {


                        PayLoad payload = new PayLoad();
                        JsonOperatorProductResponse result = new JsonOperatorProductResponse();
                        result.message = "Operators found";
                        result.status = "Success";
                        result.errorCode = 0;
                        List<AttOperator> operators = new List<AttOperator>();

                        foreach (KeyValuePair<string, string> opr in countryOperators.Result)
                        {
                            GenericApiResponse<string> operatorProductsXML = await _TransferToPost.transferToOperatorPriceList(account, int.Parse(opr.Key));

                            List<AttProduct> products = new List<AttProduct>();
                            AttOperator operatorDetails = new AttOperator();

                            if (operatorProductsXML.Status == 0)
                            {
                                XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                                xmlDoc.LoadXml(operatorProductsXML.Result); // Load the XML document from the specified file

                                XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                                if (xmlproductslist.Count == 0)
                                {
                                    continue;
                                }
                                string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                                XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                                string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                                XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                                string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');


                                string GUID = Guid.NewGuid().ToString();
                                operatorDetails.id = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;         //OperatorID
                                operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                                operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name
                                operatorDetails.nowtelTransactionReference = GUID;
                                operatorDetails.iconUri = "https://operator-logo.transferto.com/logo-" + xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText + "-1.png";       //operator logo

                                for (int a = 0; a < productslist.Length; a++)
                                {
                                    products.Add(_appDB.GetProduct(
                                        account,         //clientccy
                                        xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                        productslist[a],     //product
                                        wholesalespricelist[a],  //itemPriceClientccy
                                        retailpricelist[a]   //totalPriceClientccy
                                    ));

                                }

                                operatorDetails.products = products;
                                operators.Add(operatorDetails);
                                //operatorDetails.isFixed = "True";
                            }
                            else
                            {
                                //some error occured while access current operator's products from Sochitel Log this error
                                //just log this error and do not return any error message
                                _loggerAPIAccess.Debug($" \"GET /transferToOperatorsProductsList\"  Failed  Source:TransferTo API           Reason-Error Occured while accessing products of OperatorID:{opr.Key}  TransferTo return this error message :{operatorProductsXML.Message}");
                            }
                        }

                        payload.operators = operators;
                        result.payload = payload;
                        _loggerAPIAccess.Information($"  \"GET /transferToOperatorsProductsList\"  Success  Parameters-country={country}  currency={account}");
                        return Ok(result);
                    }
                    else
                    {
                        _loggerAPIAccess.Debug($"  \"GET /transferToOperatorsProductsList\"  Failed  Parameters-country={country}  currency={account}  Reason=No operators found");
                        var resultPayload = new { reason = "No Operators Found" };
                        var result = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                        return Ok(result);
                    }
                }
                else
                {
                    //Error ocured in Transferto API while getting operator products from backend   
                    _loggerAPIAccess.Debug($"  \"GET /transferToOperatorsProductsList\"  Failed  Source:Sochitel API     Parameters-country:{country}   currency={account}   Reason={countryOperators.Message} ");
                    var resultPayload = new { reason = countryOperators.Message };
                    var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToOperatorsProductsList\"  Failed  Source:General  Parameters-country:{country}   currency:{account}    Message:{ex.ToString()}");
                var resultPayload = new { reason = "General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                return StatusCode(500, errorResult);
            }

        }

        [HttpGet]
        [Route("getTransferToDirectOperatorsAndProducts")]
        public async Task<IActionResult> transferToDirectOperatorsListFunction(int countryCode, string account)
        {
            try
            {

                int countryId = await _appDB.GetTransferToCountryIdByCallingCode(countryCode);
                if (countryId == -1)
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:ATT API  Pasameters:      countryCode={countryCode}      currency-{account}     Reason=Service Not Found ");
                    var result2 = new { errorCode = 2, status = "Failure", message = "Service Not Found For this  countryCode" };
                    return Ok(result2);
                }
                else
                {

                    GenericApiResponse<Dictionary<string, string>> countryOperators = await _TransferToPost.transferToOperatorsList(account, countryId);

                    if (countryOperators.Status == 0)
                    {
                        if (countryOperators.Result.Count > 0)
                        {


                            PayLoad payload = new PayLoad();
                            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
                            result.message = "Operators found";
                            result.status = "Success";
                            result.errorCode = 0;
                            List<AttOperator> operators = new List<AttOperator>();

                            foreach (KeyValuePair<string, string> opr in countryOperators.Result)
                            {
                                GenericApiResponse<string> operatorProductsXML = await _TransferToPost.transferToOperatorPriceList(account, int.Parse(opr.Key));

                                List<AttProduct> products = new List<AttProduct>();
                                AttOperator operatorDetails = new AttOperator();

                                if (operatorProductsXML.Status == 0)
                                {
                                    XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                                    xmlDoc.LoadXml(operatorProductsXML.Result); // Load the XML document from the specified file

                                    XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                                    if (xmlproductslist.Count == 0)
                                    {
                                        continue;
                                    }
                                    string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                                    XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                                    string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                                    XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                                    string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');


                                    string GUID = Guid.NewGuid().ToString();
                                    operatorDetails.id = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;         //OperatorID
                                    operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                                    operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name
                                    operatorDetails.nowtelTransactionReference = GUID;
                                    operatorDetails.iconUri = "https://operator-logo.transferto.com/logo-" + xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText + "-1.png";       //operator logo

                                    for (int a = 0; a < productslist.Length; a++)
                                    {
                                        products.Add(_appDB.GetProduct(
                                            account,         //clientccy
                                            xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                            productslist[a],     //product
                                            wholesalespricelist[a],  //itemPriceClientccy
                                            retailpricelist[a]   //totalPriceClientccy
                                        ));

                                    }

                                    operatorDetails.products = products;
                                    operators.Add(operatorDetails);
                                    //operatorDetails.isFixed = "True";
                                }
                                else
                                {
                                    //some error occured while access current operator's products from Sochitel Log this error
                                    //just log this error and do not return any error message
                                    _loggerAPIAccess.Debug($" \"GET /transferToOperatorsProductsList\"  Failed  Source:TransferTo API           Reason-Error Occured while accessing products of OperatorID:{opr.Key}  TransferTo return this error message :{operatorProductsXML.Message}");
                                }
                            }

                            payload.operators = operators;
                            result.payload = payload;
                            _loggerAPIAccess.Information($"  \"GET /transferToOperatorsProductsList\"  Success  Parameters-country={countryId}  currency={account}");
                            return Ok(result);
                        }
                        else
                        {
                            _loggerAPIAccess.Debug($"  \"GET /transferToOperatorsProductsList\"  Failed  Parameters-country={countryId}  currency={account}  Reason=No operators found");
                            var resultPayload = new { reason = "No Operators Found" };
                            var result = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                            return Ok(result);
                        }
                    }
                    else
                    {
                        //Error ocured in Transferto API while getting operator products from backend   
                        _loggerAPIAccess.Debug($"  \"GET /transferToOperatorsProductsList\"  Failed  Source:Sochitel API     Parameters-country:{countryId}   currency={account}   Reason={countryOperators.Message} ");
                        var resultPayload = new { reason = countryOperators.Message };
                        var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                        return Ok(errorResult);
                    }
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToOperatorsProductsList\"  Failed  Source:General  Parameters-countryCode:{countryCode}   currency:{account}    Message:{ex.ToString()}");
                var resultPayload = new { reason = "General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                return StatusCode(500, errorResult);
            }

        }



        //FInalized APIs  ----------------------------------------------------------------------------------------------------------------------------------------


        [HttpGet]
        [Route("transferToGetOperatorProductsMSISDN")]
        public async Task<IActionResult> transferToGetOperatorProductsMSISDN(int nsid, string destinationMSISDN, string account)
        {
            ServiceProvider serviceProviderRecord = await _appDB.getServiceProviderRecord(nsid, destinationMSISDN);
            if (serviceProviderRecord != null)
            {
                var result = await _TransfertoAutomation.transferToGetOperatorProductsMSISDN(destinationMSISDN, account, serviceProviderRecord.OriginDestinationId); ;
                return Ok(result);
            }
            else
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:ATT API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}  NSID--{nsid}     Reason=Service Not Found ");
                var result2 = new { errorCode = 2, status = "Failure", message = "Service Not Found For this  MSISDN" };
                return Ok(result2);
            }
        }

        [HttpGet]
        [Route("DTOneProducts")]
        public async Task<IActionResult> transferToDirectGetOperatorProductsMSISDN(string fromMSISDN, string destinationMSISDN, string account, string product, string productItemCode = null)
        {
            var result = await _TransfertoAutomation.DTOneDirectGetOperatorProductsMSISDN(fromMSISDN, destinationMSISDN, account, product, productItemCode);
            return Ok(result);
        }


        [HttpGet]
        [Route("transferToDirectGetOperatorProductsMSISDN")]
        public async Task<IActionResult> transferToDirectGetOperatorProductsMSISDNs(string fromMSISDN, string destinationMSISDN, string account)
        {
            //Donot add any validation or code there change in THAGetOperatorProductsMSISDN,This is being used by LEgacy THA APi
            return await THAGetOperatorProductsMSISDN(fromMSISDN, destinationMSISDN, account, "THA", "THADTA");//await _TransfertoAutomation.transferToDirectGetOperatorProductsMSISDN(fromMSISDN, destinationMSISDN, account);
        }

        // For FreeSwitch Daemon
        //[HttpGet]
        //[Route("transferToFreeSwitchGetOperatorProductsMSISDN")]
        //public async Task<IActionResult> transferToFreeSwitchGetOperatorProductsMSISDN(string fromMSISDN, string destinationMSISDN, string account)
        //{
        //    var result = await _TransfertoAutomation.transferToFreeSwitchGetOperatorProductsMSISDN(fromMSISDN, destinationMSISDN, account); 
        //    return Ok(result);
        //}

        [HttpPost]
        [Route("DTOneExecute")]
        public async Task<IActionResult> DTOneExecute(ExecuteData data)
        {
            return await DtOneExecute(data);
        }

        private async Task<IActionResult> DtOneExecute(ExecuteData data)
        {
            try
            {
                string[] Credentials;
                string nowtelTransactionReference = data.nowtelTransactionReference;
                string operatorid = data.operatorid;
                string product = data.product;
                string messageToRecipient = data.messageToRecipient;
                string fromMSISDN = data.fromMSISDN;

                //APIAccessGUID guidReferneceRecord = await _appDB.getTransactionGUIDRecord_v2(nowtelTransactionReference, product);
                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(nowtelTransactionReference, product);

                if (guidReferneceRecord == null)
                {
                    _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return Ok(result);
                }

                // Validating fraud customers , at_check_fraud
                try
                {

                    bool isPermitted = await _appDB.CheckFraudUser(guidReferneceRecord.productCode, guidReferneceRecord.tomsisdn, fromMSISDN);
                    if (isPermitted == false)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Fraud detected. Access Blocked." };
                        return Ok(result);
                    }

                }
                catch (Exception ex)
                {
                    _loggerAPIAccess.Error($"  \"POST /DtOneExecute\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {fromMSISDN}, destinationMSISDN: {guidReferneceRecord.tomsisdn}, productCode:{guidReferneceRecord.productCode},    ErrorMessage:{ex.Message}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return Ok(result);

                }

                try
                {


                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn, data.nowtelTransactionReference.Remove(0, 14), data.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return Ok(result);
                    }
                }
                catch (Exception ex)
                {
                    _loggerAPIAccess.Error($"  \"GET /DtOneExecute\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return Ok(result);
                }

                long RequestKey = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;

                if (guidReferneceRecord.productCode.ToUpper() == "TRH")
                    Credentials = TransferToAuth.GetAttCredentials_TRH(guidReferneceRecord.account, guidReferneceRecord.productCode);
                else
                    Credentials = TransferToAuth.GetAttCredentials(guidReferneceRecord.account);

                try
                {
                    GenericApiResponse<transfertoExecuteTransaction> execTransactionResponse;

                    if (guidReferneceRecord.productCode.ToUpper() == "TRH")
                        execTransactionResponse = await _TransferToPost.transfertoTransaction_TRH(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, RequestKey, guidReferneceRecord.productCode);

                    else
                        execTransactionResponse = await _TransferToPost.transfertoTransaction(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, RequestKey);


                    if (execTransactionResponse.Status == 0)
                    {
                        //Successful transaction
                        try
                        {
                            await _appDB.insertAirTimeTransferTransaction(
                                DateTime.Now.ToString(),
                                Credentials[0], // Username
                                guidReferneceRecord.selling_price,         // Customer Charge Value
                                execTransactionResponse.Result.wholesale_price,  // Actual Charge Value
                                decimal.Parse(execTransactionResponse.Result.product_requested),
                                execTransactionResponse.Result.originating_currency,
                                execTransactionResponse.Result.destination_currency,
                                execTransactionResponse.Result.country,
                                "Success",
                                "",
                                execTransactionResponse.Result.operatorid,
                                execTransactionResponse.Result.product_requested,
                                execTransactionResponse.Result.@operator,
                                RequestKey.ToString(),
                                execTransactionResponse.Result.transactionid,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                2,
                                messageToRecipient,
                                nowtelTransactionReference,
                                 $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}, RequestKey:{RequestKey}",
                                JsonConvert.SerializeObject(execTransactionResponse.Result),
                                 guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                guidReferneceRecord.discountPercentage.ToString(),
                                guidReferneceRecord.orignalAmount
                                );
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }


                        _loggerAPIAccess.Information($"  \"POST /transfertoExecuteTransaction\"   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.selling_price,         // Customer Charge Value
                            currency = execTransactionResponse.Result.originating_currency,
                            reference = execTransactionResponse.Result.transactionid
                        };
                        return Ok(result);
                    }
                    else
                    {
                        try
                        {
                            await _appDB.insertAirTimeTransferTransaction(
                            DateTime.Now.ToString(),
                            Credentials[0], // Username
                            guidReferneceRecord.selling_price,         // Customer Charge Value
                            -1,
                            decimal.Parse(product),
                            guidReferneceRecord.account,
                            "",
                            "",
                            "Failure",
                            execTransactionResponse.Message,
                            operatorid,
                            product,
                            "",
                            RequestKey.ToString(),
                            "",
                            fromMSISDN,
                            guidReferneceRecord.tomsisdn,
                            2,
                            messageToRecipient,
                            nowtelTransactionReference,
                            $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}, RequestKey:{RequestKey}",
                            JsonConvert.SerializeObject(execTransactionResponse.Result),
                            guidReferneceRecord.productCode,
                            guidReferneceRecord.ProductItemCode,
                            guidReferneceRecord.discountPercentage.ToString(),
                            guidReferneceRecord.orignalAmount);
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                        _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}          Reason={execTransactionResponse.Message}");
                        var result = new { errorCode = 2, errorCodeDtOne = execTransactionResponse.Status, status = "Failure", message = execTransactionResponse.Message };
                        return Ok(result);
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        await _appDB.insertAirTimeTransferTransaction(
                        DateTime.Now.ToString(),
                        Credentials[0], // Username
                        guidReferneceRecord.selling_price,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        "",
                        "",
                        "FailureException",
                        ex.Message,
                        operatorid,
                        product,
                        "",
                        RequestKey.ToString(),
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        2,
                        messageToRecipient,
                        nowtelTransactionReference,
                        $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}, RequestKey:{RequestKey}",
                             ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                             guidReferneceRecord.productCode,
                             guidReferneceRecord.ProductItemCode,
                             guidReferneceRecord.discountPercentage.ToString(),
                             guidReferneceRecord.orignalAmount);
                    }
                    catch (Exception dbException)
                    {
                        _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return Ok(errorResult);
            }
        }

        //private async Task<IActionResult> DTOne_Execute_Old(ExecuteData data)
        //{
        //    try
        //    {
        //        string nowtelTransactionReference = data.nowtelTransactionReference;
        //        string operatorid = data.operatorid;
        //        string product = data.product;
        //        string messageToRecipient = data.messageToRecipient;
        //        string fromMSISDN = data.fromMSISDN;

        //        APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(nowtelTransactionReference, product);

        //        if (guidReferneceRecord == null)
        //        {
        //            _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
        //            var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
        //            return Ok(result);
        //        }

        //        long RequestKey = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
        //        string[] Credentials = TransferToAuth.GetAttCredentials(guidReferneceRecord.account);

        //        try
        //        {

        //            GenericApiResponse<transfertoExecuteTransaction> execTransactionResponse = await _TransferToPost.transfertoTransaction(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, RequestKey);


        //            if (execTransactionResponse.Status == 0)
        //            {
        //                //Successful transaction
        //                try
        //                {
        //                    await _appDB.insertAirTimeTransferTransaction(
        //                        DateTime.Now.ToString(),
        //                        Credentials[0], // Username
        //                        decimal.Parse(guidReferneceRecord.CustomerChargeValue),         // Customer Charge Value
        //                        execTransactionResponse.Result.wholesale_price,  // Actual Charge Value
        //                        decimal.Parse(execTransactionResponse.Result.product_requested),
        //                        execTransactionResponse.Result.originating_currency,
        //                        execTransactionResponse.Result.destination_currency,
        //                        execTransactionResponse.Result.country,
        //                        "Success",
        //                        "",
        //                        execTransactionResponse.Result.operatorid,
        //                        execTransactionResponse.Result.product_requested,
        //                        execTransactionResponse.Result.@operator,
        //                        RequestKey.ToString(),
        //                        execTransactionResponse.Result.transactionid,
        //                        fromMSISDN,
        //                        guidReferneceRecord.tomsisdn,
        //                        2,
        //                        messageToRecipient);
        //                }
        //                catch (Exception ex)
        //                {
        //                    _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
        //                }


        //                _loggerAPIAccess.Information($"  \"POST /transfertoExecuteTransaction\"   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}   ");
        //                var result = new
        //                {
        //                    errorCode = 0,
        //                    status = "Success",
        //                    message = "Your funds have been sent",
        //                    amount = guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
        //                    currency = execTransactionResponse.Result.originating_currency,
        //                    reference = execTransactionResponse.Result.transactionid
        //                };
        //                return Ok(result);
        //            }
        //            else
        //            {
        //                try
        //                {
        //                    await _appDB.insertAirTimeTransferTransaction(
        //                    DateTime.Now.ToString(),
        //                    Credentials[0], // Username
        //                    decimal.Parse(guidReferneceRecord.CustomerChargeValue),         // Customer Charge Value
        //                    -1,
        //                    decimal.Parse(product),
        //                    guidReferneceRecord.account,
        //                    "",
        //                    "",
        //                    "Failure",
        //                    execTransactionResponse.Message,
        //                    operatorid,
        //                    product,
        //                    "",
        //                    RequestKey.ToString(),
        //                    "",
        //                    fromMSISDN,
        //                    guidReferneceRecord.tomsisdn,
        //                    2,
        //                    messageToRecipient);
        //                }
        //                catch (Exception ex)
        //                {
        //                    _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
        //                }


        //                //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
        //                _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}          Reason={execTransactionResponse.Message}");
        //                var result = new { errorCode = 2, status = "Failure", message = execTransactionResponse.Message };
        //                return Ok(result);
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            try
        //            {
        //                await _appDB.insertAirTimeTransferTransaction(
        //                DateTime.Now.ToString(),
        //                Credentials[0], // Username
        //                decimal.Parse(guidReferneceRecord.CustomerChargeValue),         // Customer Charge Value
        //                -1,
        //                decimal.Parse(product),
        //                guidReferneceRecord.account,
        //                "",
        //                "",
        //                "FailureException",
        //                ex.Message,
        //                operatorid,
        //                product,
        //                "",
        //                RequestKey.ToString(),
        //                "",
        //                fromMSISDN,
        //                guidReferneceRecord.tomsisdn,
        //                2,
        //                messageToRecipient);
        //            }
        //            catch (Exception dbException)
        //            {
        //                _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
        //            }
        //            _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
        //            var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
        //            return Ok(errorResult);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
        //        var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
        //        return Ok(errorResult);
        //    }
        //}

        [HttpPost]
        [Route("Execute")]
        public async Task<IActionResult> transfertoTransaction(ExecuteData data)
        {
            //Donot add any validation or code there change in THAExecute,This is being used by LEgacy THA APi
            return await THAExecute(data); //Execute(data);
        }

        private async Task<IActionResult> Execute(ExecuteData data)
        {
            try
            {
                string nowtelTransactionReference = data.nowtelTransactionReference;
                string operatorid = data.operatorid;
                string product = data.product;
                string messageToRecipient = data.messageToRecipient;
                string fromMSISDN = data.fromMSISDN;

                //APIAccessGUID guidReferneceRecord = await _appDB.getTransactionGUIDRecord_v2(nowtelTransactionReference, product);
                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(nowtelTransactionReference, product);

                if (guidReferneceRecord == null)
                {
                    _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return Ok(result);
                }
                try
                {
                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn, data.nowtelTransactionReference.Remove(0, 14), data.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return Ok(result);
                    }
                }
                catch (Exception ex)
                {
                    _loggerAPIAccess.Error($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return Ok(result);
                }

                long RequestKey = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;

                string[] Credentials;
                if (guidReferneceRecord.productCode.ToUpper() == "TRH")
                    Credentials = TransferToAuth.GetAttCredentials_TRH(guidReferneceRecord.account, guidReferneceRecord.productCode);
                else
                    Credentials = TransferToAuth.GetAttCredentials(guidReferneceRecord.account, long.Parse(data.fromMSISDN));

                try
                {
                    var TopUpApiStartTime = DateTime.Now;
                    GenericApiResponse<transfertoExecuteTransaction> execTransactionResponse;

                    if (guidReferneceRecord.productCode.ToUpper() == "TRH")
                        execTransactionResponse = await _TransferToPost.transfertoTransaction_TRH(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, RequestKey, guidReferneceRecord.productCode);
                    else
                        execTransactionResponse = await _TransferToPost.transfertoTransaction(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, RequestKey);

                    var TopUpApiEndTime = DateTime.Now;



                    if (execTransactionResponse.Status == 0)
                    {
                        //Successful transaction
                        try
                        {                            

                            await _appDB.insertAirTimeTransferTransaction(
                                DateTime.Now.ToString(),
                                Credentials[0], // Username
                                guidReferneceRecord.selling_price,         // Customer Charge Value
                                execTransactionResponse.Result.wholesale_price,  // Actual Charge Value
                                decimal.Parse(execTransactionResponse.Result.product_requested),
                                execTransactionResponse.Result.originating_currency,
                                execTransactionResponse.Result.destination_currency,
                                execTransactionResponse.Result.country,
                                "Success",
                                "",
                                execTransactionResponse.Result.operatorid,
                                execTransactionResponse.Result.product_requested,
                                execTransactionResponse.Result.@operator,
                                RequestKey.ToString(),
                                execTransactionResponse.Result.transactionid,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                2,
                                messageToRecipient,
                                nowtelTransactionReference,
                                 $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}, RequestKey:{RequestKey}",
                                JsonConvert.SerializeObject(execTransactionResponse.Result),
                                guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                guidReferneceRecord.discountPercentage.ToString(),
                                guidReferneceRecord.orignalAmount,
                                TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                );
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }


                        _loggerAPIAccess.Information($"  \"POST /transfertoExecuteTransaction\"   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.selling_price,         // Customer Charge Value
                            currency = execTransactionResponse.Result.originating_currency,
                            reference = execTransactionResponse.Result.transactionid,
                            pinCode= execTransactionResponse.Result.pin
                        };
                        return Ok(result);
                    }
                    else
                    {
                        try
                        {
                            await _appDB.insertAirTimeTransferTransaction(
                            DateTime.Now.ToString(),
                            Credentials[0], // Username
                            guidReferneceRecord.selling_price,         // Customer Charge Value
                            -1,
                            decimal.Parse(product),
                            guidReferneceRecord.account,
                            "",
                            "",
                            "Failure",
                            execTransactionResponse.Message,
                            operatorid,
                            product,
                            "",
                            RequestKey.ToString(),
                            "",
                            fromMSISDN,
                            guidReferneceRecord.tomsisdn,
                            2,
                            messageToRecipient,
                            nowtelTransactionReference,
                            $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}, RequestKey:{RequestKey}",
                            JsonConvert.SerializeObject(execTransactionResponse.Result),
                            guidReferneceRecord.productCode,
                            guidReferneceRecord.ProductItemCode,
                            guidReferneceRecord.discountPercentage.ToString(),
                            guidReferneceRecord.orignalAmount
                            );

                            if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                            {
                                await _common_BL.SendEmail(new EmailTransactionModel()
                                {
                                    accessGUID = nowtelTransactionReference,
                                    DestinationCountry = guidReferneceRecord.destination_country,
                                    ErrorMessage = execTransactionResponse.Message,
                                    Status = "Failure",
                                    FromMsisdn = data.fromMSISDN,
                                    ToMsisdn = guidReferneceRecord.tomsisdn,
                                    OperatorId = guidReferneceRecord.operatorCode,
                                    OperatorName = data.operatorid,
                                    ProductCode = guidReferneceRecord.productCode,
                                    ProductItemCode = guidReferneceRecord.ProductItemCode,
                                    ServiceProviderName = Models.Contracts.Common.ServiceProvider.TransferTo.ToString(),
                                    TransationType = TransationType.Execute
                                });
                            }
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                        _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}          Reason={execTransactionResponse.Message}");
                        var result = new { errorCode = 2, status = "Failure", message = execTransactionResponse.Message };
                        return Ok(result);
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        await _appDB.insertAirTimeTransferTransaction(
                        DateTime.Now.ToString(),
                        Credentials[0], // Username
                        guidReferneceRecord.selling_price,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        "",
                        "",
                        "FailureException",
                        ex.Message,
                        operatorid,
                        product,
                        "",
                        RequestKey.ToString(),
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        2,
                        messageToRecipient,
                         nowtelTransactionReference,
                            $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}, RequestKey:{RequestKey}",
                             ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                             guidReferneceRecord.productCode,
                             guidReferneceRecord.ProductItemCode,
                             guidReferneceRecord.discountPercentage.ToString(),
                             guidReferneceRecord.orignalAmount
                        );

                        if (SmtpConfig.sendErrorExecuteTransactionEmail)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                accessGUID = nowtelTransactionReference,
                                DestinationCountry = guidReferneceRecord.destination_country,
                                ErrorMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                                Status = "FailureException",
                                FromMsisdn = data.fromMSISDN,
                                ToMsisdn = guidReferneceRecord.tomsisdn,
                                OperatorId = guidReferneceRecord.operatorCode,
                                OperatorName = data.operatorid,
                                ProductCode = guidReferneceRecord.productCode,
                                ProductItemCode = guidReferneceRecord.ProductItemCode,
                                ServiceProviderName = Models.Contracts.Common.ServiceProvider.TransferTo.ToString(),
                                TransationType = TransationType.Execute

                            });
                        }
                    }
                    catch (Exception dbException)
                    {
                        _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return Ok(errorResult);
            }
        }

        // For_FreeSwitch_Daemon
        #region For_FreeSwitch_Daemon

        [HttpPost]
        [Route("transfertoExecuteTransactionFreeSwitch")]
        public async Task<IActionResult> transfertoExecuteTransactionFreeSwitch(ExecuteData data)
        {
            return await ExecuteTransactionFreeSwitch(data);
        }

        private async Task<IActionResult> ExecuteTransactionFreeSwitch(ExecuteData data)
        {
            try
            {
                string nowtelTransactionReference = data.nowtelTransactionReference;
                string operatorid = data.operatorid;
                string product = data.product;
                string messageToRecipient = data.messageToRecipient;
                string fromMSISDN = data.fromMSISDN;

                //APIAccessGUID guidReferneceRecord = await _appDB.getTransactionGUIDRecord(nowtelTransactionReference, product);
                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(nowtelTransactionReference, product);

                if (guidReferneceRecord == null)
                {
                    _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return Ok(result);
                }
                try
                {


                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn, data.nowtelTransactionReference.Remove(0, 14), data.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return Ok(result);
                    }
                }
                catch (Exception ex)
                {
                    _loggerAPIAccess.Error($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return Ok(result);
                }
                long RequestKey = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;

                try
                {
                    GenericApiResponse<transfertoExecuteTransaction> execTransactionResponse = await _TransferToPost.transfertoExecuteTransactionFreeSwitch(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, RequestKey);

                    if (execTransactionResponse.Status == 0)
                    {
                        //Successful transaction
                        try
                        {
                            await _appDB.insertAirTimeTransferTransaction(
                                DateTime.Now.ToString(),
                                TransferToConf.AttFreeSwitchUsernameEUR,  // Username
                                guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                                execTransactionResponse.Result.wholesale_price,  // Actual Charge Value
                                decimal.Parse(execTransactionResponse.Result.product_requested),
                                execTransactionResponse.Result.originating_currency,
                                execTransactionResponse.Result.destination_currency,
                                execTransactionResponse.Result.country,
                                "Success",
                                "",
                                execTransactionResponse.Result.operatorid,
                                execTransactionResponse.Result.product_requested,
                                execTransactionResponse.Result.@operator,
                                RequestKey.ToString(),
                                execTransactionResponse.Result.transactionid,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                2,
                                messageToRecipient);
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }


                        _loggerAPIAccess.Information($"  \"POST /transfertoExecuteTransaction\"   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                            currency = execTransactionResponse.Result.originating_currency,
                            reference = execTransactionResponse.Result.transactionid
                        };
                        return Ok(result);
                    }
                    else
                    {
                        try
                        {
                            await _appDB.insertAirTimeTransferTransaction(
                            DateTime.Now.ToString(),
                            TransferToConf.AttFreeSwitchUsernameEUR,  // Username
                            guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                            -1,
                            decimal.Parse(product),
                            guidReferneceRecord.account,
                            "",
                            "",
                            "Failure",
                            execTransactionResponse.Message,
                            operatorid,
                            product,
                            "",
                            RequestKey.ToString(),
                            "",
                            fromMSISDN,
                            guidReferneceRecord.tomsisdn,
                            2,
                            messageToRecipient);
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                        _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}          Reason={execTransactionResponse.Message}");
                        var result = new { errorCode = 2, status = "Failure", message = execTransactionResponse.Message };
                        return Ok(result);
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        await _appDB.insertAirTimeTransferTransaction(
                        DateTime.Now.ToString(),
                        TransferToConf.AttFreeSwitchUsernameEUR,  // Username
                        guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        "",
                        "",
                        "FailureException",
                        ex.Message,
                        operatorid,
                        product,
                        "",
                        RequestKey.ToString(),
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        2,
                        messageToRecipient);
                    }
                    catch (Exception dbException)
                    {
                        _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return Ok(errorResult);
            }
        }


        #endregion For_FreesSwitchDaemon


        [HttpPost]
        [Route("transfertoQueue")]
        public async Task<IActionResult> TransfertoQueue(TransferToQueue userRequest)
        {
            GenericApiResponse<string> response;
            try
            {

                int result = await _appDB.AddTransferToQueue(userRequest);
                if (result > 0)
                {
                    response = GenericApiResponse<string>.Success("Request Saved To Queue");
                }
                else
                {
                    response = GenericApiResponse<string>.Failure("Error in Request Saving.");
                }
            }
            catch (Exception ex)
            {
                response = GenericApiResponse<string>.Failure(ex.Message);
            }
            return Ok(response);
        }

        //[HttpPost]
        //[Route("DTOneExecute")]
        //public async Task<IActionResult> dtOnetoTransaction(FormDataCollection data)
        //{
        //    return await ExecuteTransaction(data);
        //}

        [HttpPost]
        [Route("transfertoExecuteTransaction")]
        public async Task<IActionResult> transfertoTransaction(FormDataCollection data)
        {
            return await ExecuteTransaction(data);
        }

        private async Task<IActionResult> ExecuteTransaction(FormDataCollection data)
        {
            try
            {
                string nowtelTransactionReference = Convert.ToString(data.Get("nowtelTransactionReference"));
                string operatorid = Convert.ToString(data.Get("operatorid"));
                string product = Convert.ToString(data.Get("product"));
                string messageToRecipient = Convert.ToString(data.Get("messageToRecipient"));

                string fromMSISDN = Convert.ToString(data.Get("fromMSISDN"));

                APIAccessGUID guidReferneceRecord = await _appDB.getTransactionGUIDRecord(nowtelTransactionReference, product);
                string[] Credentials = TransferToAuth.GetAttCredentials(guidReferneceRecord.account);

                if (guidReferneceRecord == null)
                {
                    _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return Ok(result);
                }

                long RequestKey = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;

                try
                {
                    GenericApiResponse<transfertoExecuteTransaction> execTransactionResponse = await _TransferToPost.transfertoTransaction(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, RequestKey);

                    if (execTransactionResponse.Status == 0)
                    {
                        //Successful transaction
                        try
                        {
                            await _appDB.insertAirTimeTransferTransaction(
                                DateTime.Now.ToString(),
                                Credentials[0],
                                guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                                execTransactionResponse.Result.wholesale_price,  // Actual Charge Value
                                decimal.Parse(execTransactionResponse.Result.product_requested),
                                execTransactionResponse.Result.originating_currency,
                                execTransactionResponse.Result.destination_currency,
                                execTransactionResponse.Result.country,
                                "Success",
                                "",
                                execTransactionResponse.Result.operatorid,
                                execTransactionResponse.Result.product_requested,
                                execTransactionResponse.Result.@operator,
                                RequestKey.ToString(),
                                execTransactionResponse.Result.transactionid,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                2,
                                messageToRecipient);
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }


                        _loggerAPIAccess.Information($"  \"POST /transfertoExecuteTransaction\"   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                            currency = execTransactionResponse.Result.originating_currency,
                            reference = execTransactionResponse.Result.transactionid
                        };
                        return Ok(result);
                    }
                    else
                    {
                        try
                        {
                            await _appDB.insertAirTimeTransferTransaction(
                            DateTime.Now.ToString(),
                           Credentials[0],
                            guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                            -1,
                            decimal.Parse(product),
                            guidReferneceRecord.account,
                            "",
                            "",
                            "Failure",
                            execTransactionResponse.Message,
                            operatorid,
                            product,
                            "",
                            RequestKey.ToString(),
                            "",
                            fromMSISDN,
                            guidReferneceRecord.tomsisdn,
                            2,
                            messageToRecipient);
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                        _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}          Reason={execTransactionResponse.Message}");
                        var result = new { errorCode = 2, status = "Failure", message = execTransactionResponse.Message };
                        return Ok(result);
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        await _appDB.insertAirTimeTransferTransaction(
                        DateTime.Now.ToString(),
                        Credentials[0],
                        guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        "",
                        "",
                        "FailureException",
                        ex.Message,
                        operatorid,
                        product,
                        "",
                        RequestKey.ToString(),
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        2,
                        messageToRecipient);
                    }
                    catch (Exception dbException)
                    {
                        _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return Ok(errorResult);
            }
        }


        [HttpGet]
        [Route("transfertoGetTransactionFromTransactionId")]
        public async Task<IActionResult> transfertoGetTransactionDetailFromTransactionId(string transactionId, string account)
        {

            TransferToJsonGetTransactionResponse response = new TransferToJsonGetTransactionResponse();
            try
            {
                GenericApiResponse<TransferToGetTransactionResponse> result = await _TransferToPost.transfertoGetTransactionDetailFromTransactionId(transactionId, account);
                if (result.Status == 0)
                {
                    response.errorCode = 0;
                    response.status = "Success";
                    response.message = "Successfully executed.";
                    response.payload = result.Result;
                }
                else
                {
                    response.errorCode = 2;
                    response.status = "Failure";
                    response.message = result.Message;
                }

            }
            catch (Exception ex)
            {
                response.errorCode = 2;
                response.status = "Failure";
                response.message = ex.Message;
            }
            return Ok(response);
        }

        [HttpGet]
        [Route("transfertoGetTransactionFromKey")]
        public async Task<IActionResult> transfertoGetTransactionDetailFromKey(string transactionKey, string account)
        {

            TransferToJsonGetTransactionResponse response = new TransferToJsonGetTransactionResponse();
            try
            {
                GenericApiResponse<TransferToGetTransactionResponse> result = await _TransferToPost.transfertoGetTransactionDetailFromKey(transactionKey, account);
                if (result.Status == 0)
                {
                    response.errorCode = 0;
                    response.status = "Success";
                    response.message = "Successfully executed.";
                    response.payload = result.Result;
                }
                else
                {
                    response.errorCode = 2;
                    response.status = "Failure";
                    response.message = result.Message;
                }

            }
            catch (Exception ex)
            {
                response.errorCode = 2;
                response.status = "Failure";
                response.message = ex.Message;
            }
            return Ok(response);
        }

        //[HttpGet]
        //[Route("transferToGetDataBundleProductsMSISDN")]
        //public async Task<IHttpActionResult> transferToGetDataBundleProductsMSISDN(string destinationMSISDN, string account)
        //{
        //    // need to get from database table as configured
        //    GenericApiResponse<TransferToMSISDNInfoResponse> parsedMSISDNobject = await _TransferToPost.transfertoParseMSISDN(destinationMSISDN, account);

        //    //GenericApiResponse<string> mSISDNobject = await _TransferToPost.transfertoGoodsServiceParseMsisdn(destinationMSISDN, "678", "7", account);

        //    if (parsedMSISDNobject.Status == 0)
        //    {

        //        // in future we first check in database then and get products from database 

        //        int serviceId = 7;
        //        int operatorId = parsedMSISDNobject.Result.operatorid;//1449;
        //        int countryId = parsedMSISDNobject.Result.countryid;//678;
        //        try
        //        {
        //            GenericApiResponse<TransfertoDataBundleProductList> servicelist = await _TransferToPost.transfertoDataBundleProductList(account, serviceId, operatorId, countryId);

        //            // configuration with database save response in database in accessdatanudledetaisl table 

        //            // and return final response according to database rates after comaprsion with api rates  
        //            if (servicelist.Result.fixed_value_recharges != null && servicelist.Result.fixed_value_recharges.Count > 0)
        //            {
        //                var resultPayload = new { data = servicelist.Result.fixed_value_recharges };
        //                var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
        //                return Json(result);
        //            }
        //            else
        //            {
        //                var resultPayload = new { reason = "No Data Bundle Products available." };
        //                var result = new { errorCode = 0, status = "Failed", payLoad = resultPayload };
        //                return Json(result);
        //            }

        //        }
        //        catch (Exception ex)
        //        {
        //            _loggerAPIAccess.Debug($"  \"GET /transferToGetDataBundleProductsMSISDN \"  Failed  Source:General  Parameters-  currency:{account} serviceId:{serviceId} , operatorId:{operatorId}  , countryId:{countryId}    Message:{ex.ToString()}");
        //            var resultPayload = new { reason = "General API Access Error. Check log for details" };
        //            var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
        //            return Json(errorResult);
        //        }
        //    }
        //    else
        //    {
        //        var resultPayload = new { reason = parsedMSISDNobject.Message };
        //        var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
        //        return Json(errorResult);
        //    }


        //}



        [HttpGet]
        [Route("THAGetOperatorProductsMSISDN")]
        public async Task<IActionResult> THAGetOperatorProductsMSISDN(string fromMSISDN, string destinationMSISDN, string account, string productCode, string productItemCode)
        {
            try
            {
                string toNumber = destinationMSISDN.Replace("+", "");
                toNumber = toNumber.StartsWith("00") == true ? toNumber.Remove(0, 2) : toNumber;
                THADestinationServiceProvider serviceProviderRecord = await _appDB.GetTHAServiceProvider(toNumber, fromMSISDN, productCode, productItemCode);
                if (serviceProviderRecord != null)
                {

                    if (serviceProviderRecord.service_provider_id == 2) //transferto
                    {
                        var result = await _TransfertoAutomation.transferToDirectGetOperatorProductsMSISDN(fromMSISDN, toNumber, account, productCode, productItemCode);
                        return Ok(result);
                    }
                    //else
                    if (serviceProviderRecord.service_provider_id == 3) //Ding
                    {
                        var result = await _dingPost_BL.DingTHAGetPhoneOperator(fromMSISDN, account, toNumber, serviceProviderRecord.use_db_rates, serviceProviderRecord.csdp_config_id, productCode, productItemCode);
                        result.payload?.operators.ForEach(x => x.id = "-1");
                        return Ok(result);
                    }
                    else if (serviceProviderRecord.service_provider_id == 4) //Reloadly
                    {
                        var result = await _reloadlyPost_BL.ReloadlyTHAGetPhoneOperator(fromMSISDN, account, toNumber, serviceProviderRecord.use_db_rates, serviceProviderRecord.csdp_config_id, productCode, productItemCode);
                        result.payload?.operators.ForEach(x => x.id = "-1");
                        return Ok(result);
                    }
                    else if (serviceProviderRecord.service_provider_id == 5) //Mobiquity
                    {
                        var result = await _mobiquityPost_BL.MobiquityTHAGetPhoneOperator(fromMSISDN, account, toNumber, serviceProviderRecord.use_db_rates, serviceProviderRecord.csdp_config_id, productCode, productItemCode);
                        result.payload?.operators.ForEach(x => x.id = "-1");
                        return Ok(result);
                    }
                    else  // Use TransferTo
                    {
                        var result = await _TransfertoAutomation.transferToDirectGetOperatorProductsMSISDN(fromMSISDN, toNumber, account, productCode, productItemCode);
                        return Ok(result);
                    }
                }
                else // Use TransferTo
                {
                    var result = await _TransfertoAutomation.transferToDirectGetOperatorProductsMSISDN(fromMSISDN, toNumber, account, productCode, productItemCode);
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($" ATTController, \"GET /THAGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                var errorResult = new { errorCode = 2, status = "Failure", message = ex.Message };
                return Ok(errorResult);
            }
        }


        [HttpPost]
        [Route("THAExecute")]
        public async Task<IActionResult> THAExecute(ExecuteData data)
        {
            try
            {
                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(data.nowtelTransactionReference, data.product);

                string toNumber = guidReferneceRecord.tomsisdn.Replace("+", "");
                toNumber = toNumber.StartsWith("00") == true ? toNumber.Remove(0, 2) : toNumber;
                THADestinationServiceProvider serviceProviderRecord = await _appDB.GetTHAServiceProvider(toNumber, guidReferneceRecord.frommsisdn, guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);
                if (serviceProviderRecord != null)
                {
                    //if (serviceProviderRecord.service_provider_id == 1) // Sochitel
                    //{
                    //    var result = await _SochiTelAutomation.FreeSwitch_Execute(data);
                    //    return Ok(result);

                    //}
                    //else 
                    if (serviceProviderRecord.service_provider_id == 2) //transferto
                    {
                        return await Execute(data);
                    }
                    else if (serviceProviderRecord.service_provider_id == 3) //Ding
                    {
                        var result = await _dingPost_BL.DingTHATopUp(data);
                        return Ok(result);
                    }
                    else if (serviceProviderRecord.service_provider_id == 4) //Reloadly
                    {
                        var result = await _reloadlyPost_BL.ReloadlyTHATopUp(data);
                        return Ok(result);
                    }
                    else if (serviceProviderRecord.service_provider_id == 5) //Mobiquity
                    {
                        var result = await _mobiquityPost_BL.MobiquityTHATopUp(data);
                        return Ok(result);
                    }
                    else  // Use TransferTo
                    {
                        return await Execute(data);
                    }
                }
                else // Use TransferTo
                {
                    return await Execute(data);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($" ATTController, \"POST /THAExecute\"  Failed  Source:General  Parameters-  RequestJson:{JsonConvert.SerializeObject(data)},    Message:{ex.ToString()}");
                var errorResult = new { errorCode = 2, status = "Failure", message = ex.Message };
                return Ok(errorResult);
            }

        }
    }
}