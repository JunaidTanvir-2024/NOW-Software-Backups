﻿using Dapper;
using SmsOutReachCallBackUrlApi.Contracts.Poppayouts.Request;
using SmsOutReachCallBackUrlApi.Models;
using SmsOutReachCallBackUrlApi.Models.Connections;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace SmsOutReachCallBackUrlApi.Infrastructure.Poppayouts
{
    public class PoppayoutsDb :IPoppayoutsDb
    {
        private IDbConnectionSettings DbConnection;


        public PoppayoutsDb(string connectionString)
        {

            DbConnection = new DbConnectionSettings(new SqlConnection(connectionString));

        }

        async public Task<DbResult> InsertUpdateSmsCallBackUrlData(PoppayoutsSmsCallBackUrlRequest deliveryReport)
        {
            DbResult result = null;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@DeliveryStatus", deliveryReport.deliverystatus);
                parameters.Add("@Queue", deliveryReport.queue);
                parameters.Add("@SmsLogID", deliveryReport.smslog_id);
                parameters.Add("@TimeStamp", deliveryReport.timestamp);
                parameters.Add("@DeliveryDatetime", deliveryReport.deliverydatetime);
                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult>("Sp_Api_InsertUpdatePoppayoutsSmsCallBackUrlData", parameters , commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                return result;
            }
        }
    }
}
