﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request.Rating
{
    public class AddCustomerRatingRequest
    {
        [Required]
        public int CustomerRating { get; set; }
        [Required]
        public int TotalRating { get; set; }
        [Required]
        public string RatingEvent { get; set; }
        public RatingSources RatingSource { get; set; } 
        public string MSISDN { get; set; }
        public string Email { get; set; }
    }
}
