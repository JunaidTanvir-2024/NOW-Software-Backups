using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;

public interface IOtpRepository : ResolveAs.IScoped
{
    Task<Otp> AddOtp(Otp otp);
    Otp DeleteOtp(Otp otp);
    Task<long> GetOtpCount(Expression<Func<Otp, bool>> predicate);
    void UpdateOtp(Otp otp);
    Task<Otp?> GetOtp(Expression<Func<Otp, bool>> predicate);
}
