﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Models.Enums
{
    public enum CustomEvents
    {
        topup5_app,
        topup10_app,
        topup15_app,
        topup20_app,
        topup25_app,
        purchase_success,
        purchase_failure,
    }
}
