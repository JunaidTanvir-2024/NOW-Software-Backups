﻿using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Request;
using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface IPush_DL
    {
        Task<PushRegistration> GetPushRegistration(string msisdn);
         Task<bool> SetPushRegistration(PushRegistration registration);
         Task<GenericResult<string>> GetFCMToken(string msisdn);
         Task<GenericResult<APNSToken>> GetAPNSToken(string msisdn);
    }
}
