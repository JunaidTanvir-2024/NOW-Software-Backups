using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants;

public static partial class AppConstants
{
    public static class ProductPurchaseType
    {
        public const string Topup = "AIRTIME";
        public const string Bundle = "BUNDLE";
        public const string InternetData = "DATA";
        public const string GiftCard = "GIFT CARDS";
    }
}
