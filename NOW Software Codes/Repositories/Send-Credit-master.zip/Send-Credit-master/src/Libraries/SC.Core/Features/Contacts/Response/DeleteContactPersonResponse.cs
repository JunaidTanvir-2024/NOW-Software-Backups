﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Contacts.Response
{
    public class DeleteContactPersonResponse
    {
        public int result { get; set; }
    }
}