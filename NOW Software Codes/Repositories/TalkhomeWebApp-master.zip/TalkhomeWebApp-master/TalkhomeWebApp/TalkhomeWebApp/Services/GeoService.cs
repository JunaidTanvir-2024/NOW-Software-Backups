﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using TalkhomeWebApp.Models;
using TalkhomeWebApp.Utilities.Extension;

namespace TalkhomeWebApp.Services
{
    public class GeoService : IGeoService
    {
        private readonly ILogger _logger;
        public GeoService(ILogger logger)
        {
            _logger = logger;
        }
        public async Task<GeoInfo> GetGeoInfo(HttpContext context)
        {
            var Ip = CommonExtentionMethods.GetRemoteIPAddress(context);

            try
            {
                using var client = new HttpClient { BaseAddress = new Uri("https://ipinfo.io/" + Ip + "?token=8846473981a4d0") };
                HttpResponseMessage response = await client.GetAsync("");
                response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<GeoInfo>(json);
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: GetGeoInfo, " +
                                      $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                      $"StackTrace: {ex.StackTrace}");

                return null;
            }
        }
    }
}
