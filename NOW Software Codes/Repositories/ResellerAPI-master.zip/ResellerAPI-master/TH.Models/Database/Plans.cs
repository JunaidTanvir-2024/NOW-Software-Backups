﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TH.Models.Database
{
    public class Plans
    {
        public string PackageId { get; set; }
        public string branded_name { get; set; }       
    }
   
}
