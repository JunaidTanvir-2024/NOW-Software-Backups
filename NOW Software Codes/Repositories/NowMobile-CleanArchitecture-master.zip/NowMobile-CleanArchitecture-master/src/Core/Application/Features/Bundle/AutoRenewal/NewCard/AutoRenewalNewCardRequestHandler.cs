using Application.Common.Interfaces.Payment;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;

namespace Application.Features.Bundle.AutoRenewal.NewCard;

public class AutoRenewalNewCardRequestHandler : IRequestHandler<AutoRenewalNewCardRequest, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;

    public AutoRenewalNewCardRequestHandler(
        IPaymentService paymentService,
        ICurrentUser currentUser,
        IMapper mapper)
    {
        _paymentService = paymentService;
        _currentUser = currentUser;
        _mapper = mapper;
    }
    public async Task<Result<CardResponse>> Handle(AutoRenewalNewCardRequest request, CancellationToken cancellationToken)
    {
        request.PaymentCardInfo.SaveCard = true;
        request.PaymentCardInfo.MakeDefault = true;
        var bundleInfo = _mapper.Map<PaymentBundleInfo>(request);
        return await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: request.PaymentCardInfo,
            paymentExistingCardInfo: null!,
            paymentAddressInfo: request.PaymentAddressInfo,
            topupInfo: null!,
            bundleInfo: bundleInfo,
            creditSimInfo: null!,
            msisdn: request.Msisdn,
            email: _currentUser.GetUserEmail()!,
            ipAddress: request.IpAddress,
            cardMaskedPan: null!,
            cardScheme: null!,
            isAuthorizeOnly: true
            );
    }
}