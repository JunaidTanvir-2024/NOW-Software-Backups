using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;


namespace JM.Core.Features.Friendship;

public abstract class AcceptFriendship
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public long UserId { get; set; }
		public long FriendId { get; set; }
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.UserId).GreaterThan(0);
			RuleFor(x => x.FriendId).GreaterThan(0);
		}
		#endregion
	}
	#region Response
	public sealed record Response
	{
		public required UserInfo User { get; set; }
		public required UserInfo Friend { get; set; }
		public required string Status { get; set; }

		public sealed record UserInfo
		{
			public required long Id { get; set; }
			public required string Email { get; set; }
			public required string Username { get; set; }
			public string? FullName { get; set; }
		}
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		private readonly IMediator _mediator = mediator;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{
			var getFriendshipResult = (await _mediator.Send(new GetFriendship.Query()
			{
				UserId = query.UserId,
				Status = AppEnum.FriendshipStatus.Pending
			}, cancellationToken));

			var friendshipInfo = getFriendshipResult.IsSuccess ? getFriendshipResult.TypedPayload<GetFriendship.Response>() : null;

			if (friendshipInfo is not null && friendshipInfo.Status.Equals(nameof(AppEnum.FriendshipStatus.Pending)))
			{
				friendshipInfo.Status = nameof(AppEnum.FriendshipStatus.Accepted);
				_unitOfWork.SaveChanges();

				return ResultWrapper.Success(new Response()
				{
					Status = friendshipInfo?.Status!,
					User = new Response.UserInfo()
					{
						Id = friendshipInfo?.Initiator?.Id ?? default,
						Email = friendshipInfo?.Initiator?.Email!,
						Username = friendshipInfo?.Initiator?.Username!,
						FullName = friendshipInfo?.Initiator?.FullName,
					},
					Friend = new Response.UserInfo()
					{
						Id = friendshipInfo?.Responder?.Id ?? default,
						Email = friendshipInfo?.Responder?.Email!,
						Username = friendshipInfo?.Responder?.Username!,
						FullName = friendshipInfo?.Responder?.FullName,
					},
				});
			}

			return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
		}
	}
	#endregion
}
