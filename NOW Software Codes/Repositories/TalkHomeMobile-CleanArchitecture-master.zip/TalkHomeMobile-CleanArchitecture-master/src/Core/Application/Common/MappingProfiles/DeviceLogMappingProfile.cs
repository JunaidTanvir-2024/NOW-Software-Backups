﻿using Application.Features.Identity.Tokens.Token;
using Mapster;

namespace Application.Common.MappingProfiles;
internal sealed class DeviceLogMappingProfile : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<(TokenRequest tokenRequest, User user), UserDeviceLog>
        .NewConfig()
        .Map(userDeviceLog => userDeviceLog.ActionExecuted, src => src.tokenRequest.AppInfo.ActionExecuted)
        .Map(userDeviceLog => userDeviceLog.AppLanguage, src => src.tokenRequest.AppInfo.AppLanguage)
        .Map(userDeviceLog => userDeviceLog.AppVersion, src => src.tokenRequest.AppInfo.AppVersion)
        .Map(userDeviceLog => userDeviceLog.CpuArchitecture, src => src.tokenRequest.AppInfo.CpuArchitecture)
        .Map(userDeviceLog => userDeviceLog.DeviceLanguage, src => src.tokenRequest.AppInfo.DeviceLanguage)
        .Map(userDeviceLog => userDeviceLog.DeviceMake, src => src.tokenRequest.AppInfo.DeviceMake)
        .Map(userDeviceLog => userDeviceLog.DeviceModel, src => src.tokenRequest.AppInfo.DeviceModel)
        .Map(userDeviceLog => userDeviceLog.DeviceOS, src => src.tokenRequest.AppInfo.DeviceOS)
        .Map(userDeviceLog => userDeviceLog.DeviceOSVersion, src => src.tokenRequest.AppInfo.DeviceOSVersion)
         .Map(userDeviceLog => userDeviceLog.DevicePersistentID, src => src.tokenRequest.AppInfo.DevicePersistentID)
         .Map(userDeviceLog => userDeviceLog.UserId, src => src.user.Id);
    }
}