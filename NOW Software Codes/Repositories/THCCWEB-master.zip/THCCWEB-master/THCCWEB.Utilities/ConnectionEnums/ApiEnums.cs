﻿using System;
using System.Collections.Generic;
using System.Text;

namespace THCCWEB.Utilities.ConnectionEnums
{
    public class ApiEnums
    {
        public enum ApiCallType
        {
            BasicAuth,
            Bearer,
            NoHeader
        }
        public enum ProductType
        {
            THCC = 1,
            THRCC = 2
        }
    }
}
