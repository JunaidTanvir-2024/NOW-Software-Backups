﻿using Application.Common.Models;
using Microsoft.AspNetCore.Http;

namespace Application.Common.Interfaces.Infrastructure;

public interface IFileService : ISerivcesType.ITransientService
{
    Task<(string fileName, bool isSuccess, string errorMessage)> FileUploaderAsync(IFormFile file, string path);
    string PathNormalizer(string path);
    bool FileExtensionValidator(IFormFile file);
    bool FileSizeValidator(IFormFile file);
    ServerDirectoriesModel GetVirtualDirectoriesBySite(string siteName = "HomeNow");
    string? VirtualPathGenerator(string fileName, string virtualDirectoryName, string siteName = "HomeNow");
}