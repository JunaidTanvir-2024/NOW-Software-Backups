﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.PaypalApiContracts
{
	public class RefundFullPaymentRequestModel
	{
		public string transactionId { get; set; }
	}
}
