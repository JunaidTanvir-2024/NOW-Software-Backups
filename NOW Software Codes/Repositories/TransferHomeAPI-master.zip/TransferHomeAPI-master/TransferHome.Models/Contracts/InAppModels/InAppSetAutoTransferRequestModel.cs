﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TransferHome.Models.Contracts.Service.Pay360ApiContracts;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.InAppModels
{
    public class InAppSetAutoTransferRequestModel
    {
        public InAppPay360CardPostModel CardData { get; set; }

        [Required]
        public RegularityType RegularityType { get; set; }
    }
}
