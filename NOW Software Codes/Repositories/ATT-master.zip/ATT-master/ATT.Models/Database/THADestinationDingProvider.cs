﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Database
{
   public class THADestinationDingProvider
    {
        public string ding_operator_code { get; set; }
        public string country_code { get; set; }
        public string operator_name { get; set; }
        public string country_name { get; set; }
    }
}
