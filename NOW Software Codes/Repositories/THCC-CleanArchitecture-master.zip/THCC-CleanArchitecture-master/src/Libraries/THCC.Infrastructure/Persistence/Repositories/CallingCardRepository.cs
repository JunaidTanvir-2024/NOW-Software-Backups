﻿using Dapper;

using Microsoft.Extensions.Configuration;

using Serilog;

using System.Data;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.Dtos;
using THCC.Domain.Aggregates;
using THCC.Domain.Entities;
using THCC.Infrastructure.Persistence.DapperConfigurations;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Infrastructure.Persistence.Repositories
{
    public class CallingCardRepository : ICallingCardRepository
    {
        #region Fields

        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;

        #endregion

        #region Ctors

        public CallingCardRepository(IConfiguration configuration,
            ILogger logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        #endregion

        #region Methods

        public async Task<PinDetail> GetPinInfo(string pin)
        {
            var p = new DynamicParameters();
            p.Add("@pin", pin, dbType: DbType.String);
            return await DapperWrapper.QueryFirstOrDefaultAsync<PinDetail>(
                StoredProcedures.GetPinInfo, p, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.BackHome));
        }
        public async Task<PinDetail> GetCardInfo(string cardNumber)
        {
            var p = new DynamicParameters();
            p.Add("@cardNumber", cardNumber, dbType: DbType.String);
            return await DapperWrapper.QueryFirstOrDefaultAsync<PinDetail>(
                StoredProcedures.GetCardNumberInfo, p, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.BackHome));
        }
        public async Task<string> GetFirstUseDate(string cardNumber)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Pan", cardNumber);
            return await DapperWrapper.QueryFirstOrDefaultAsync<string>(
                StoredProcedures.GetCardPurchaseDate, parameters, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.TalkHomeRechargeableCard));
        }
        public async Task<ClassicPinDetail> GetClassicPinDetails(string pinNumber)
        {
            var p = new DynamicParameters();
            p.Add("@CardPin", pinNumber, dbType: DbType.String);
            return await DapperWrapper.QueryFirstOrDefaultAsync<ClassicPinDetail>(
                StoredProcedures.GetClassicPinDetails, p, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.TalKHome));
        }
        public async Task<bool> IsUserPinNumber(string pinNumber, string userId)
        {
            var p = new DynamicParameters();
            p.Add("@UserId", userId, dbType: DbType.String);
            p.Add("@CardPinNumber", pinNumber, dbType: DbType.String);
            p.Add("@IsValid", dbType: DbType.Boolean, direction: ParameterDirection.Output);
            await DapperWrapper.ExecuteAsync(
               StoredProcedures.IsUserPinNumber, p, commandType: CommandType.StoredProcedure,
               _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
            return p.Get<bool>("@IsValid");
        }
        public async Task<List<CardCallHistory>> GetClassicCardCallHistory(string pinNumber)
        {
            var p = new DynamicParameters();
            p.Add("@Pin", pinNumber, dbType: DbType.String);
            return (await DapperWrapper.QueryAsync<CardCallHistory>(
                StoredProcedures.GetClassicCardCallHistory, p, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.TalKHome))).ToList();
        }
        public async Task<List<CardCallHistory>> GetRechargableCardCallHistory(string pinNumber)
        {
            var p = new DynamicParameters();
            p.Add("@Pin", pinNumber, dbType: DbType.String);
            return (await DapperWrapper.QueryAsync<CardCallHistory>(
                StoredProcedures.GetClassicCardCallHistory, p, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.BackHome))).ToList();
        }

        public async Task<bool> IsCardNumberRegistered(string cardNumber)
        {
            var p = new DynamicParameters();
            p.Add("@CardNumber", cardNumber, dbType: DbType.String);
            p.Add("@IsRegisterd", dbType: DbType.Boolean, direction: ParameterDirection.Output);
            await DapperWrapper.ExecuteAsync(
               StoredProcedures.IsCardNumberRegistered, p, commandType: CommandType.StoredProcedure,
               _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
            return p.Get<bool>("@IsRegisterd");
        }

        public async Task<List<CallingCardConsumption>> GetClassicCardConsumptionHistory()
        {
            return (await DapperWrapper.QueryAsync<CallingCardConsumption>(
                StoredProcedures.GetClassicCardConsumptionHistory, null!, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.CallingCardConsumption))).ToList();
        }
        


        public async Task UpdateClassicCardConsumptionItems(long id, float percentage)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@id", id);
                parameters.Add("@percentage", percentage);
                int result=await DapperWrapper.ExecuteReturnAsync(StoredProcedures.UpdateClassicCardConsumptionItems, parameters,
                    commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.CallingCardConsumption));

                if (result==0)
                {
                    _logger.Error($"Class: CallingCardRepository," +
                        $" Method: UpdateClassicCardConsumptionItems," +
                        $" ErrorMessage:Record not updated. Id: {id} , Percentage: {percentage}");
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: CallingCardRepository, Method: UpdateClassicCardConsumptionItems, ErrorMessage: {ex.Message} ");
            }
        }

        public async Task<List<CallingCardCDRHistory>> GetClassicCardCDRHistory()
        {
            return (await DapperWrapper.QueryAsync<CallingCardCDRHistory>(
                StoredProcedures.GetClassicCardCallingHistory, null!, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.CallingCardConsumption))).ToList();
        }

        public async Task UpdateClassicCardCDRItem(long id)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@id", id);
                
                int result = await DapperWrapper.ExecuteReturnAsync(StoredProcedures.UpdateClassicCardCallingItem, parameters,
                    commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.CallingCardConsumption));

                if (result == 0)
                {
                    _logger.Error($"Class: CallingCardRepository," +
                        $" Method: UpdateClassicCardDestinationItems," +
                        $" ErrorMessage:Record not updated. Id: {id} ");
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: CallingCardRepository, Method: UpdateClassicCardDestinationItems, ErrorMessage: {ex.Message} ");
            }
        }
        public async Task<List<CallingCardCDRHistory>> GetTHRCCCDRHistory()
        {
            return (await DapperWrapper.QueryAsync<CallingCardCDRHistory>(
                StoredProcedures.GetTHRCCConsumptionHistory, null!, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.BackHome))).ToList();
        }

        public async Task UpdateTHRCCCDRItem(long id)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@id", id);

                int result = await DapperWrapper.ExecuteReturnAsync(StoredProcedures.UpdateTHRCCConsumptionItem, parameters,
                    commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.BackHome));

                if (result == 0)
                {
                    _logger.Error($"Class: CallingCardRepository," +
                        $" Method: UpdateTHRCCCDRItem," +
                        $" ErrorMessage:Record not updated. Id: {id} ");
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: CallingCardRepository, Method: UpdateTHRCCCDRItem, ErrorMessage: {ex.Message} ");
            }
        }

        #endregion
    }
}