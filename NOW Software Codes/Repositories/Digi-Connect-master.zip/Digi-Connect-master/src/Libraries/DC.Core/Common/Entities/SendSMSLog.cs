using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DC.Core.Common.Entities;
public class SendSMSLog
{
    public int SmsCategoryId { get; set; }
    public string SmsRequest { get; set; }
    public string SMSSentStatus { get; set; }
    public DateTime CreatedOn { get; set; }
    public string CreatedBy { get; set; }
    public string Cadence { get; set; }
    public string Msisdn { get; set; }
}
