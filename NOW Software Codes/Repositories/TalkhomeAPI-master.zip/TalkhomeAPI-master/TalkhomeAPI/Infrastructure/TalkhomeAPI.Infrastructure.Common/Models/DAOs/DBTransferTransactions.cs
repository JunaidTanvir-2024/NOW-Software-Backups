﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBTransferTransaction
    {
        public int Id { get; set; }
        public string AccountId { get; set; }
        public TransferTransactionStatus StatusId { get; set; }
        public PaymentType PaymentTypeId { get; set; }
        public string FromMsisdn { get; set; }
        public string ToMsisdn { get; set; }
        public string ClientCurrecny { get; set; }
        public string ReceiverCurrecny { get; set; }
        public decimal Product { get; set; }
        public decimal ItemPrice { get; set; }
        public decimal TotalPrice { get; set; }
        public string OperatorName { get; set; }
        public string OperatorLogoUrl { get; set; }
        public string OperatorCountryName { get; set; }
        public string CountryCode { get; set; }
        public string TransferRef { get; set; }
        public string PaymentRef { get; set; }
        public string NowtelRef { get; set; }
    }
}
