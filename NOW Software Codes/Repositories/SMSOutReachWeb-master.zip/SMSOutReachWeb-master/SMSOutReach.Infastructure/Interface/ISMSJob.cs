﻿using SMSOutReach.Modal.Configurations;
using SMSOutReach.Modal.Xeebi;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace SMSOutReach.Infastructure.Interface
{
    public interface ISMSJob
    {

        Task<List<ViewSmsJob>> GetSMSJobs();

        Task<List<ViewSmsJob>> GetAllSMSJobs();

        Task<List<ViewSmsJob>> GetPendingSMSJobs(DateTime jobStartDate, int carrierId);

        Task<ViewSmsJob> GetSelectedSMSJobDetail(int SelectedJobId);

         Task<DBResult> UpdateSmsJobStatus(int jobId, int NewJobStatusId,int currentJobStatus);

        Task<DBResult> InsertSmsJob(SMSJob job, DataTable JobDetails);

        Task<DBResult> InsertSmsJobApi(SMSJob job, string UserMsisdn);

       
    }

  
}
