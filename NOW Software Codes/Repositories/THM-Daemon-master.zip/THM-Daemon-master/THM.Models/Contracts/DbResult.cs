﻿using System;
using System.Collections.Generic;
using System.Text;
using THM.Models.Enums;

namespace THM.Models.Contracts
{
    public class DbResult<T>
    {
        public DbStatus DBStatus { get; set; }
        public int ErrorCode { get; set; }
        public string DBErrorMessage { get; set; }
        public T Data { get; set; }
    }
}
