namespace FH.Core.DTOs.Database;
public sealed class OperatorByVendorCodeDto
{
    public sealed record Request
    {
        public required string? VendorCode { get; set; }
    }
    public sealed record Response
    {
        public required string OperatorId { get; set; }
        public required string OperatorName { get; set; }
        public required long CountryId { get; set; }
        public required string CountryName { get; set; }
        public required string CountryIsoCode { get; set; }
    }
}
