using FH.Core.Definitions;
using FH.Infrastructure;
using FH.UseCases;

using Hangfire;

namespace FH.Api;

public static class ConfigureDependencies
{
    public static IServiceCollection AddApiDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHangfire(x => x.UseSqlServerStorage(configuration.GetConnectionString(AppConstants.Database.Name.FusionHub)));
        services.AddHangfireServer();
        services.AddControllers();
        services.AddUseCasesDependencies(configuration);
        services.AddInfrastructureDependencies(configuration);
        return services;
    }
}
