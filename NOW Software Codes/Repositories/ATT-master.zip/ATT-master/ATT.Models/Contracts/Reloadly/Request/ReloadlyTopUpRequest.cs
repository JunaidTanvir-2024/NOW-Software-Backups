﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Reloadly.Request
{
    public class ReloadlyTopUpRequest
    {
        public string operatorId { get; set; }
        public string amount { get; set; }
        public bool useLocalAmount { get; set; }
        public string customIdentifier { get; set; }
        public RelaodlyPhoneDetails recipientPhone { get; set; }
        public string recipientEmail { get; set; }
        public RelaodlyPhoneDetails senderPhone { get; set; }

    }

    public class RelaodlyPhoneDetails
    {
        public string countryCode { get; set; }
        public string number { get; set; }
    }
}
