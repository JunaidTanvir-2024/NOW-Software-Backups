﻿namespace Application.Common.Settings;

public class LoginSettings
{
    public const string SectionName = "SecuritySettings:LoginSettings";
    public static LoginSettings Bind = new LoginSettings();
    public InvalidLoginSettings InvalidLogin { get; set; } = default!;
}

public class InvalidLoginSettings
{
    public const string SectionName = "SecuritySettings:LoginSettings:InvalidLoginSettings";
    public static InvalidLoginSettings Bind = new InvalidLoginSettings();
    public bool IsActive { get; set; }
    public byte AttemptCount { get; set; }
    public int DisableTimeInMinutes { get; set; }
}