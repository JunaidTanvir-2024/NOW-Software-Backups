namespace Application.Features.Bundle.Model;

public sealed class AddBundleResponse
{
    public int ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }
}
public class GetBundleAutoRenewalStatus
{
    public string Account { get; set; }
    public string Msisdn { get; set; }
    public string CallingPackageId { get; set; }
    public bool IsRenew { get; set; }
    public string PaymentMethod { get; set; }
    public string Email { get; set; }
    public string MaskedPan { get; set; }
    public string InitialTransactionId { get; set; }
}
