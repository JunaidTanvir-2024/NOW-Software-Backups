﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TransferHome.Models.Contracts.InAppModels;

namespace TransferHomeAPI.Interfaces
{
    public interface IAddressService
    {
        Task<AddressIoResponse> GetAddresses(string postCode);

        List<I18nCountry> GetCountryList();
    }
}
