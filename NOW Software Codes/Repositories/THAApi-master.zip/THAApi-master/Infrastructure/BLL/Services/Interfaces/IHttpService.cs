﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface IHttpService
    {
        Task<string> GetAsync(string address);

        Task<string> GetAsync(string address, string username, string password);

        Task<string> PostAsync(string address, string json);

        Task<string> PostAsync(string address, string json, string username, string password);
    }
}
