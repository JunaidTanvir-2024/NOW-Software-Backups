using JM.Api.Controllers.Common;
using JM.Core.Features.User;
using JM.Core.Utilities.Definitions;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using RW.Common;
using RW.Failures;
using RW.Models;
using RW.Successes;

namespace JM.Api.Controllers.V1;

public sealed class UserController : V1ApiController
{
    [HttpGet]
    [ProducesResponseType<SuccessPayload<GetUserList.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    [AllowAnonymous]
    public async Task<ActionResult> GetUsers()
    {
        var result = await Mediator.Send(new GetUserList.Query(), HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpGet("email")]
    [ProducesResponseType<SuccessPayload<GetUserList.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    [AllowAnonymous]
    public async Task<ActionResult> GetUser([FromQuery] GetUser.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpPost("profile")]
    [ProducesResponseType<SuccessPayload<Profile.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.InternalServerError)]
    [Authorize]
    public async Task<ActionResult> Profile([FromForm] Profile.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
}
