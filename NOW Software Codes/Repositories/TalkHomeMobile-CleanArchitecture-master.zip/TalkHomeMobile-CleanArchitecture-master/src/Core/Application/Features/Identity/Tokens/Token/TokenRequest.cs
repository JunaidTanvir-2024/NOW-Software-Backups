﻿namespace Application.Features.Identity.Tokens.Token;

public class TokenRequest : IRequest<Result<TokenResponse>>
{
    public TokenRequest()
    {
        UserInfo = new UserInfo();
        AppInfo = new AppInfo();
    }

    public UserInfo UserInfo { get; set; } = default!;

    public AppInfo AppInfo { get; set; } = default!;

    [JsonIgnore]
    public string? IpAddress { get; set; } = null;
}

public sealed class UserInfo
{
    public string EmailOrPhone { get; set; } = default!;

    public string Password { get; set; } = default!;
}