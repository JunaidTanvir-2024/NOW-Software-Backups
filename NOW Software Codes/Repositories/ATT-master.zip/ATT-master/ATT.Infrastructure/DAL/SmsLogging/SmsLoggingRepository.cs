﻿using Dapper;
using System.Data;
using System.Threading.Tasks;
using System;
using ATT.Models.Configurations;
using Serilog;
using ATT.Models.DbConnections;
using Microsoft.Extensions.Options;
using System.Data.SqlClient;
using ATT.Models.Database;
using System.Data.Common;

namespace ATT.Infrastructure.DAL.SmsLogging
{
    public class SmsLoggingRepository : ISmsLoggingRepository
    {
        private IDbConnectionSettings _smsLoggingDbConnection;
        public SmsLoggingRepository(ILogger logger, IOptions<ConnectionString> connectionString)
        {
            _smsLoggingDbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.SmsLoggingDbConnection));
        }
        public async Task<int> InsertSmsLog(AttSmsLogging attSmsLogging)
        {
            int result;
            try
            {

                var parameters = new DynamicParameters();
                parameters.Add("@transaction_id", attSmsLogging.TransactionId);
                parameters.Add("@sender_msisdn", attSmsLogging.SenderMsisdn);
                parameters.Add("@receiver_msisdn", attSmsLogging.ReceiverMsisdn);
                parameters.Add("@pin_code", attSmsLogging.PinCode);
                parameters.Add("@sms_text", attSmsLogging.SmsText);
                parameters.Add("@sms_status", attSmsLogging.SmsStatus);
                parameters.Add("@sms_error", attSmsLogging.SmsError);
                parameters.Add("@unix_time_stamp", attSmsLogging.UnixTimeStamp);
                parameters.Add("@sms_sid", attSmsLogging.SmsSid);

                result = await _smsLoggingDbConnection.Connection.ExecuteAsync("add_att_sms_log", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<AttSmsLogging> GetLogBySmsSID(string smsSID)
        {
            AttSmsLogging result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@smsSID", smsSID);

                result = await _smsLoggingDbConnection.Connection.QueryFirstOrDefaultAsync<AttSmsLogging>("get_log_by_smsSID", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
