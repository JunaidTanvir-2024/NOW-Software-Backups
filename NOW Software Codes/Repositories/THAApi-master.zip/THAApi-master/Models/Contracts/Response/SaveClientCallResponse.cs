﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class SaveClientCallDbResponse
    {
        public int ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public bool isAdded { get; set; }
    }

    public class ClientCallResponse
    {
        public bool isAdded { get; set; }
    }
}
