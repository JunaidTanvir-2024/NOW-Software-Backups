﻿using Dapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PaymentsApi.Infrastructure.DAL.Database;
using PaymentsApi.Infrastructure.DAL.Interfaces;
using PaymentsApi.Models.Configurations;
using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.DatabaseConnections;
using PaymentsApi.Models.Utility;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace PaymentsApi.Infrastructure.DAL.Implementation
{
    public class DL_Pay360 : DL_IPay360
    {
        private readonly ILogger Logger;
        private IDbConnectionSettings DbConnection;
        private IDbConnectionSettings DigiTalkDbConnection;
        private IDbConnectionSettings ThmConnection;
        private IDbConnectionSettings ThrccConnection;
        private IDbConnectionSettings ThccConnection;
        private IDbConnectionSettings ItsaConnection;
        private IDbConnectionSettings TalkHomePaymentsConnection;
        private IDbConnectionSettings ThaConnection;

        public DL_Pay360(ILogger logger, IOptions<ConnectionString> connectionString)
        {
            Logger = logger;
            DbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
            DigiTalkDbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigiTalkConnection));
            ThmConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThmConnection));
            ThrccConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThrccConnection));
            ThccConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThccConnection));
            ItsaConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ItsaConnection));
            TalkHomePaymentsConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomePaymentsConnection));
            ThaConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThaConnection));
        }

        public async Task<FullfilmentResponse> TdccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<WTCCPin>("tdcc_getNextPIN_WebAPI_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Pay360.cs, Method: TdccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> MtccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<WTCCPin>("xtcc_getNextPIN_WebAPI_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Pay360.cs, Method: MtccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> BtccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<WTCCPin>("btcc_getNextPIN_WebAPI_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Pay360.cs, Method: BtccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> StccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<WTCCPin>("stcc_getNextPIN_WebAPI_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Pay360.cs, Method: StccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> WtccCustomerFullfilment(string transactionId, string amount, string email, string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<WTCCPin>("wtcc_getNextPIN_WebAPI_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure 'wtcc_getNextPIN_WebAPI_v1'";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Pay360.cs, Method: WtccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> ThaIvrCustomerFullfilment(string msisdn, string amount, string ccsTransId, string ccAuthCode)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@amount", amount);
                parameters.Add("@reference", ccsTransId);
                parameters.Add("@ccAuthCode", ccAuthCode);

                var result = await ThaConnection.SqlConnection.QueryFirstOrDefaultAsync<AccountBalance>("tha_account_update_ivr_topup_pay_360", parameters, commandType: CommandType.StoredProcedure);
                if (result != null && result.audit_id > 0) // Fullfilment Successfull
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.audit_id = result.audit_id;
                    response.new_balance = (int)result.new_balance;
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "Topup failed";
                    response.audit_id = 0;
                }


            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: ThaIvrCustomerFullfilment, Parameters=> msisdn: {msisdn}, amount: {amount}, ccsTransId: {ccsTransId}, ccAuthCode: {ccAuthCode}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
            }

            return response;
        }

        public async Task<FullfilmentResponse> ThaCustomerFullfilment(string msisdn, string amount, string ccsTransId, string ccAuthCode, string bundleRef)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@amount", amount);
                parameters.Add("@reference", ccsTransId);
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@ccAuthCode", ccAuthCode);
                parameters.Add("@bundlename", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
                parameters.Add("@error_code", null, DbType.Int32, ParameterDirection.Output);
                parameters.Add("@error_msg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 255);


                var result = await ThaConnection.SqlConnection.QueryFirstOrDefaultAsync<AccountBalance>("tha_account_update_topup_add_bundle_pay_360", parameters, commandType: CommandType.StoredProcedure);
                //if (result != null && result.audit_id > 0) // Fullfilment Successfull

                int errorCode = parameters.Get<int>("@error_code");
                if (errorCode == 0) // Fullfilment Successfull
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.audit_id = result.audit_id;
                    response.Audit = new THRCCAudit() { audit_id = result.audit_id, new_balance = Convert.ToDecimal(result.new_balance) };
                    response.BundleName = parameters.Get<string>("@bundlename");
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = parameters.Get<string>("@error_msg");
                    response.audit_id = 0;
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: ThaCustomerFullfilment, Parameters=> msisdn: {msisdn}, bundleRef: {bundleRef}, amount: {amount}, ccsTransId: {ccsTransId}, ccAuthCode: {ccAuthCode}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
            }
            return response;

        }

        public async Task<FullfilmentResponse> NowStraightCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef)
        {
            if (string.IsNullOrEmpty(bundleRef))
                bundleRef = "";

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@amount", Decimal.Parse(amount));
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@bundlename", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ThmConnection.SqlConnection.QueryFirstOrDefaultAsync<THRCCAudit>("now_pay360_accountupdatebalance_v1", parameters, commandType: CommandType.StoredProcedure);

                if (result != null)
                {
                    response.BundleName = parameters.Get<string>("@bundlename");
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Audit = result;
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "Topup failed";
                    response.Audit = null;
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message);
                response.ErrorCode = 111;
                response.ErrorMessage = errorMessage;
                Logger.Error($"Class: DL_Pay360, Method: NowStraightCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {errorMessage}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> NowCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {

                var storedProcedure = "now_pay360_accountupdatebalance_queue_v1";

                if (string.IsNullOrEmpty(bundleRef)) bundleRef = "";

                var parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@amount", decimal.Parse(amount));
                parameters.Add("@bundlename", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ThmConnection.SqlConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                response.ErrorCode = 0;
                response.BundleName = parameters.Get<string>("@bundlename");
                response.ErrorMessage = "Success";

            }
            catch (Exception ex)
            {
                response.ErrorCode = 1;
                response.ErrorMessage = "Code Exception: " + ex.Message;
                Logger.Error($"Class: DL_Pay360, Method: NowCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {ex.Message}");
            }
            return response;
        }

        public async Task<bool> CustomerExistsByMerchantRefAsync(string merchantRef)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@MerchantRef", merchantRef);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<bool>("Pay360_Api_CustomerExistOrNotbyMerchantRef", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customer> GetCustomerByMerchantRef(string merchantRef)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@MerchantRef", merchantRef);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<Customer>("Pay360_Api_GetCustomerByMerchantRef_v1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetCustomerByMerchantRef, Parameters=> merchantRef: {merchantRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        public async Task<ValidateRes> NowPayGProductRefValidation(string productItemCode, string productRef, string bundleRef)
        {


            ValidateRes valRes = new ValidateRes();
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@productref", productRef);

                bundleRef = string.IsNullOrWhiteSpace(bundleRef) ? "" : bundleRef;
                parameters.Add("@bundleRef", bundleRef);
                parameters.Add("@tamount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ThmConnection.SqlConnection.ExecuteAsync("now_pay360_validate_msisdn_v2", parameters, commandType: CommandType.StoredProcedure);

                valRes.Errorcode = parameters.Get<Int32>("@errorcode");
                valRes.Errormsg = parameters.Get<string>("@errormsg");
                valRes.Tamount = parameters.Get<Int32>("@tamount");

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: NowPayGProductRefValidation, Parameters => productItemCode: {productItemCode}, productRef: {productRef}, bundleRef: {bundleRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");

            }

            return valRes;

        }

        public async Task<ValidateRes> ThaProductRefValidation(string productItemCode, string productRef)
        {

            //return 0; // For Testing Purpose Only. Comment this for Live and Un-Comment below code for live
            ValidateRes valRes = new ValidateRes();
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@productref", productRef);
                parameters.Add("@tamount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ThaConnection.SqlConnection.ExecuteAsync("tha_pay360_validate_msisdn_v1", parameters, commandType: CommandType.StoredProcedure);

                valRes.Errorcode = parameters.Get<Int32>("@errorcode");
                valRes.Errormsg = parameters.Get<string>("@errormsg");
                valRes.Tamount = parameters.Get<Int32>("@tamount");

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: ThaProductRefValidation, Parameters => productItemCode: {productItemCode}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");

            }

            return valRes;

        }

        public async Task<ValidateRes> ThmProductRefValidation(string productItemCode, string productRef)
        {

            //return 0; // For Testing Purpose Only. Comment this for Live and Un-Comment below code for live
            ValidateRes valRes = new ValidateRes();
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@productref", productRef);
                parameters.Add("@tamount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ThmConnection.SqlConnection.ExecuteAsync("thm_pay360_validate_msisdn_v1", parameters, commandType: CommandType.StoredProcedure);

                valRes.Errorcode = parameters.Get<Int32>("@errorcode");
                valRes.Errormsg = parameters.Get<string>("@errormsg");
                valRes.Tamount = parameters.Get<Int32>("@tamount");

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: ThmProductRefValidation, Parameters => productItemCode: {productItemCode}, productRef: {productRef}, ErrorMessage: {ex.Message}");
                valRes.Errorcode = 1;
                valRes.Errormsg = ex.Message;
            }

            return valRes;

        }

        public async Task<ValidateRes> ThmProductRefValidation(string productItemCode, string productRef, string bundleRef)
        {

            //return 0; // For Testing Purpose Only. Comment this for Live and Un-Comment below code for live
            ValidateRes valRes = new ValidateRes();
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@productref", productRef);

                bundleRef = string.IsNullOrWhiteSpace(bundleRef) ? "" : bundleRef;
                parameters.Add("@bundleRef", bundleRef);
                parameters.Add("@tamount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ThmConnection.SqlConnection.ExecuteAsync("thm_pay360_validate_msisdn_v2", parameters, commandType: CommandType.StoredProcedure);

                valRes.Errorcode = parameters.Get<Int32>("@errorcode");
                valRes.Errormsg = parameters.Get<string>("@errormsg");
                valRes.Tamount = parameters.Get<Int32>("@tamount");

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: ThmProductRefValidation, Parameters => productItemCode: {productItemCode}, productRef: {productRef}, bundleRef: {bundleRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                valRes.Errorcode = 1;
                valRes.Errormsg = ex.Message;
            }

            return valRes;

        }

        public async Task<ValidateRes> ThrccProductRefValidation(string productItemCode, string productRef)
        {


            //return 0; // For Testing Purpose Only. Comment this for Live and Un-Comment below code for live
            ValidateRes valRes = new ValidateRes();
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@productref", productRef);
                parameters.Add("@tamount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ThrccConnection.SqlConnection.ExecuteAsync("thrcc_pay360_validate_cc_v1", parameters, commandType: CommandType.StoredProcedure);

                valRes.Tamount = parameters.Get<Int32>("@tamount");
                valRes.Errorcode = parameters.Get<Int32>("@errorcode");
                valRes.Errormsg = parameters.Get<string>("@errormsg");

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: ThrccProductRefValidation, Parameters => productItemCode: {productItemCode}, productRef: {productRef}, ErrorMessage: {ex.Message}");
                valRes.Errorcode = 1;
                valRes.Errormsg = ex.Message;
            }

            return valRes;

        }

        public async Task<DbResult<int>> AddCustomer(Customer customer)
        {
            DbResult<int> result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@DisplayName", customer.DisplayName);
                parameters.Add("@MerchantRef", customer.MerchantRef);
                parameters.Add("@Email", customer.Email);
                parameters.Add("@Msisdn", customer.Msisdn);
                parameters.Add("@ProductCode", customer.ProductCode);
                parameters.Add("@AddressLine1", customer.AddressLine1);
                parameters.Add("@AddressLine2", customer.AddressLine2);
                parameters.Add("@AddressLine3", customer.AddressLine3);
                parameters.Add("@AddressLine4", customer.AddressLine4);
                parameters.Add("@City", customer.City);
                parameters.Add("@Region", customer.Region);
                parameters.Add("@PostCode", customer.PostCode);
                parameters.Add("@CountryCode", customer.CountryCode);

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("Pay360_Api_AddCustomer", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<int>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Pay360, Method: AddCustomer, Parameters=> customer: {JsonConvert.SerializeObject(customer)}, ErrorMessage: {ex.Message}, DBErrorMessage: {result.DBErrorMessage}");
                //throw;
                return result;
            }
        }

        public async Task<DbResult<long>> AddTransaction(Pay360Transaction transaction, ProductBasket[] basket, bool isDirectFullfilment, Pay360SummaryTransactionTypes controllerActionType = Pay360SummaryTransactionTypes.NEWCUSTOMER, bool AddSummaryTransaction = false, string ipAddress = null)
        {
            DbResult<long> result;
            try
            {

                DataTable items = new DataTable();
                items.Columns.Add("ProductItemCode", typeof(string));
                items.Columns.Add("Amount", typeof(float));
                DataColumn productColumn = items.Columns.Add("ProductRef", typeof(string));
                productColumn.AllowDBNull = true;
                DataColumn bundleColumn = items.Columns.Add("BundleRef", typeof(string));
                bundleColumn.AllowDBNull = true;

                for (int i = 0; i < basket.Length; i++)
                {
                    DataRow row = items.NewRow();
                    row["ProductItemCode"] = basket[i].ProductItemCode;
                    row["Amount"] = basket[i].Amount;
                    row["ProductRef"] = ((string.IsNullOrWhiteSpace(basket[i].ProductRef)) == true ? null : basket[i].ProductRef);
                    row["BundleRef"] = ((string.IsNullOrWhiteSpace(basket[i].BundleRef)) == true ? null : basket[i].BundleRef);
                    items.Rows.Add(row);
                }

                #region Parameters
                var parameters = new DynamicParameters();
                parameters.Add("@TransactionMerchantRef", transaction.TransactionMerchantRef);
                parameters.Add("@Pay360TransactionId", transaction.Pay360TransactionId);
                parameters.Add("@TransactionDescription", transaction.TransactionDescription);
                parameters.Add("@TransactionStatus_Id", transaction.TransactionStatus_Id);
                parameters.Add("@TransactionType_Id", transaction.TransactionType_Id);
                parameters.Add("@TransactionAmount", transaction.TransactionAmount);
                parameters.Add("@TransactionCurrency", transaction.TransactionCurrency);
                parameters.Add("@TransactionCommerceType", transaction.TransactionCommerceType);
                parameters.Add("@TransactionChannel", transaction.TransactionChannel);
                parameters.Add("@TransactionTime", transaction.TransactionTime);
                parameters.Add("@TransactionReceivedTime", transaction.TransactionReceivedTime);
                parameters.Add("@RequestTime", transaction.RequestTime);
                parameters.Add("@OutcomeStatus", transaction.OutcomeStatus);
                parameters.Add("@OutcomeReasonCode", transaction.OutcomeReasonCode);
                parameters.Add("@OutcomeReasonMessage", transaction.OutcomeReasonMessage);
                parameters.Add("@AuthStatusCode", transaction.AuthStatusCode);
                parameters.Add("@AuthMessage", transaction.AuthMessage);
                parameters.Add("@AuthCode", transaction.AuthCode);
                parameters.Add("@AuthGatewayReference", transaction.AuthGatewayReference);
                parameters.Add("@AuthGatewaySettlement", transaction.AuthGatewaySettlement);
                parameters.Add("@AuthGatewayCode", transaction.AuthGatewayCode);
                parameters.Add("@AuthGatewayMessage", transaction.AuthGatewayMessage);
                parameters.Add("@AuthAvsAddressCheck", transaction.AuthAvsAddressCheck);
                parameters.Add("@AuthAvsPostCodeCheck", transaction.AuthAvsPostCodeCheck);
                parameters.Add("@AuthCv2Check", transaction.AuthCv2Check);
                parameters.Add("@AuthStatus", transaction.AuthStatus);
                parameters.Add("@Route", transaction.Route);
                parameters.Add("@Customer_Id", transaction.Customer_Id);
                parameters.Add("@CardMaskedPan", transaction.CardMaskedPan);
                parameters.Add("@PaymentMethod_Id", transaction.PaymentMethod_Id);
                parameters.Add("@PaypalId", transaction.PaypalId);
                parameters.Add("@FinancialServicesDob", transaction.FinancialServicesDob);
                parameters.Add("@FinancialServicesSurName", transaction.FinancialServicesSurName);
                parameters.Add("@FinancialServicesAccountNumber", transaction.FinancialServicesAccountNumber);
                parameters.Add("@FinancialServicesPostCode", transaction.FinancialServicesPostCode);
                parameters.Add("@RelatedTransactionId", transaction.RelatedTransactionId);
                parameters.Add("@RelatedTransactionMerchantRef", transaction.RelatedTransactionMerchantRef);
                parameters.Add("@ClientRedirectPaReq", transaction.ClientRedirectPaReq);
                parameters.Add("@ClientRedirectUrl", transaction.ClientRedirectUrl);
                parameters.Add("@ClientRirectType", transaction.ClientRirectType);
                parameters.Add("@Is3DSecure", transaction.Is3DSecure);
                parameters.Add("@ThreeDSecureAuthenticationIndicator", transaction.ThreeDSecureAuthenticationIndicator);
                parameters.Add("@ThreeDSecureAuthenticationStatus", transaction.ThreeDSecureAuthenticationStatus);
                parameters.Add("@ThreeDSecureAvv", transaction.ThreeDSecureAvv);
                parameters.Add("@ThreeDSecureEci", transaction.ThreeDSecureEci);
                parameters.Add("@ThreeDSecureEnrolmentDateTime", transaction.ThreeDSecureEnrolmentDateTime);
                parameters.Add("@ThreeDSecureEnrolmentIndicator", transaction.ThreeDSecureEnrolmentIndicator);
                parameters.Add("@ThreeDSecureEnrolmentStatus", transaction.ThreeDSecureEnrolmentStatus);
                parameters.Add("@ThreeDSecureScheme", transaction.ThreeDSecureScheme);
                parameters.Add("@ThreeDSecureStatus", transaction.ThreeDSecureStatus);
                parameters.Add("@ThreeDSecureXid", transaction.ThreeDSecureXid);
                parameters.Add("@ControllerActionId", controllerActionType);
                parameters.Add("@AddSummaryTransaction", AddSummaryTransaction);
                parameters.Add("@RequestJsonToPay360", transaction.RequestJsonToPay360);
                parameters.Add("@ResponseJsonFromPay360", transaction.ResponseJsonFromPay360);
                parameters.Add("@IsDirectFullfilment", isDirectFullfilment);
                parameters.Add("@ApiInstallationIdCashierApi", transaction.ApiInstallationIdCashierApi);
                if (!string.IsNullOrWhiteSpace(ipAddress))
                {
                    parameters.Add("@IpAddress", ipAddress);
                }
                parameters.Add("@TransactionItems", items.AsTableValuedParameter("Pay360TransactionItemType"));
                #endregion

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<long>>("Pay360_Api_AddTransaction_V4", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<long>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Pay360, Method: AddTransaction, Parameters=> transaction: {JsonConvert.SerializeObject(transaction)}, ErrorMessage: {ex.Message}");
                //throw;
                return result;
            }

        }

        public async Task<DbResult<long>> AddTransactionWithoutBasket(Pay360Transaction transaction, Pay360SummaryTransactionTypes controllerActionType = Pay360SummaryTransactionTypes.NEWCUSTOMER, bool AddSummaryTransaction = false, string ipAddress = null)
        {
            DbResult<long> result;
            try
            {

                #region Parameters
                var parameters = new DynamicParameters();
                parameters.Add("@TransactionMerchantRef", transaction.TransactionMerchantRef);
                parameters.Add("@Pay360TransactionId", transaction.Pay360TransactionId);
                parameters.Add("@TransactionDescription", transaction.TransactionDescription);
                parameters.Add("@TransactionStatus_Id", transaction.TransactionStatus_Id);
                parameters.Add("@TransactionType_Id", transaction.TransactionType_Id);
                parameters.Add("@TransactionAmount", transaction.TransactionAmount);
                parameters.Add("@TransactionCurrency", transaction.TransactionCurrency);
                parameters.Add("@TransactionCommerceType", transaction.TransactionCommerceType);
                parameters.Add("@TransactionChannel", transaction.TransactionChannel);
                parameters.Add("@TransactionTime", transaction.TransactionTime);
                parameters.Add("@TransactionReceivedTime", transaction.TransactionReceivedTime);
                parameters.Add("@RequestTime", transaction.RequestTime);
                parameters.Add("@OutcomeStatus", transaction.OutcomeStatus);
                parameters.Add("@OutcomeReasonCode", transaction.OutcomeReasonCode);
                parameters.Add("@OutcomeReasonMessage", transaction.OutcomeReasonMessage);
                parameters.Add("@AuthStatusCode", transaction.AuthStatusCode);
                parameters.Add("@AuthMessage", transaction.AuthMessage);
                parameters.Add("@AuthCode", transaction.AuthCode);
                parameters.Add("@AuthGatewayReference", transaction.AuthGatewayReference);
                parameters.Add("@AuthGatewaySettlement", transaction.AuthGatewaySettlement);
                parameters.Add("@AuthGatewayCode", transaction.AuthGatewayCode);
                parameters.Add("@AuthGatewayMessage", transaction.AuthGatewayMessage);
                parameters.Add("@AuthAvsAddressCheck", transaction.AuthAvsAddressCheck);
                parameters.Add("@AuthAvsPostCodeCheck", transaction.AuthAvsPostCodeCheck);
                parameters.Add("@AuthCv2Check", transaction.AuthCv2Check);
                parameters.Add("@AuthStatus", transaction.AuthStatus);
                parameters.Add("@Route", transaction.Route);
                parameters.Add("@Customer_Id", transaction.Customer_Id);
                parameters.Add("@CardMaskedPan", transaction.CardMaskedPan);
                parameters.Add("@PaymentMethod_Id", transaction.PaymentMethod_Id);
                parameters.Add("@PaypalId", transaction.PaypalId);
                parameters.Add("@FinancialServicesDob", transaction.FinancialServicesDob);
                parameters.Add("@FinancialServicesSurName", transaction.FinancialServicesSurName);
                parameters.Add("@FinancialServicesAccountNumber", transaction.FinancialServicesAccountNumber);
                parameters.Add("@FinancialServicesPostCode", transaction.FinancialServicesPostCode);
                parameters.Add("@RelatedTransactionId", transaction.RelatedTransactionId);
                parameters.Add("@RelatedTransactionMerchantRef", transaction.RelatedTransactionMerchantRef);
                parameters.Add("@ClientRedirectPaReq", transaction.ClientRedirectPaReq);
                parameters.Add("@ClientRedirectUrl", transaction.ClientRedirectUrl);
                parameters.Add("@ClientRirectType", transaction.ClientRirectType);
                parameters.Add("@Is3DSecure", transaction.Is3DSecure);
                parameters.Add("@ThreeDSecureAuthenticationIndicator", transaction.ThreeDSecureAuthenticationIndicator);
                parameters.Add("@ThreeDSecureAuthenticationStatus", transaction.ThreeDSecureAuthenticationStatus);
                parameters.Add("@ThreeDSecureAvv", transaction.ThreeDSecureAvv);
                parameters.Add("@ThreeDSecureEci", transaction.ThreeDSecureEci);
                parameters.Add("@ThreeDSecureEnrolmentDateTime", transaction.ThreeDSecureEnrolmentDateTime);
                parameters.Add("@ThreeDSecureEnrolmentIndicator", transaction.ThreeDSecureEnrolmentIndicator);
                parameters.Add("@ThreeDSecureEnrolmentStatus", transaction.ThreeDSecureEnrolmentStatus);
                parameters.Add("@ThreeDSecureScheme", transaction.ThreeDSecureScheme);
                parameters.Add("@ThreeDSecureStatus", transaction.ThreeDSecureStatus);
                parameters.Add("@ThreeDSecureXid", transaction.ThreeDSecureXid);
                parameters.Add("@ControllerActionId", controllerActionType);
                parameters.Add("@AddSummaryTransaction", AddSummaryTransaction);
                parameters.Add("@RequestJsonToPay360", transaction.RequestJsonToPay360);
                parameters.Add("@ResponseJsonFromPay360", transaction.ResponseJsonFromPay360);
                parameters.Add("@ApiInstallationIdCashierApi", transaction.ApiInstallationIdCashierApi);
                if (!string.IsNullOrWhiteSpace(ipAddress))
                {
                    parameters.Add("@IpAddress", ipAddress);
                }

                #endregion

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<long>>("Pay360_Api_AddTransactionWithoutBasket_v2", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<long>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Pay360, Method: AddTransactionWithoutBasket, Parameters=> transaction: {JsonConvert.SerializeObject(transaction)}, ErrorMessage: {ex.Message}");
                //throw;
                return result;
            }

        }

        public async Task<List<ProductItems>> GetProductItems(string msisdn)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                var result = await DbConnection.SqlConnection.QueryAsync<ProductItems>("Pay360_Api_GetProductItems_v1", parameters, commandType: CommandType.StoredProcedure);
                return result.ToList();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetProductItems, ErrorMessage: {ex.Message}");
                return null;
            }
        }

        public async Task<List<ProductItems>> GetProductItems()
        {
            try
            {
                var result = await DbConnection.SqlConnection.QueryAsync<ProductItems>("Pay360_Api_GetProductItems", commandType: CommandType.StoredProcedure);
                return result.ToList();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetProductItems, ErrorMessage: {ex.Message}");
                return null;
            }
        }


        public async Task<DbResult<string>> UpdateCustomerEmail(string merchantRef, string email)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@MerchantRef", merchantRef);
                parameters.Add("@Email", email);

                var result = await DbConnection.SqlConnection.QueryAsync<DbResult<string>>("Pay360_Api_UpdateCustomerEmailByMerchantRef", parameters, commandType: CommandType.StoredProcedure);
                return result.ToList()[0];
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: UpdateCustomerEmail, Parameters=> merchantRef: {merchantRef}, email: {email}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<DbResult<string>> UpdateCustomerDefaultCv2(string merchantRef, string cv2, string encryptionKey)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@MerchantRef", merchantRef);
                parameters.Add("@DefaultCardCV2", cv2);
                parameters.Add("@CV2EncryptionKey", encryptionKey);

                var result = await DbConnection.SqlConnection.QueryAsync<DbResult<string>>("Pay360_Api_UpdateCustomerCv2ByMerchantRef", parameters, commandType: CommandType.StoredProcedure);
                return result.ToList()[0];
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: UpdateCustomerDefaultCv2, Parameters=> merchantRef: {merchantRef}, cv2: {cv2}, encryptionKey: {encryptionKey}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task UpdateCustomerIdAndCV2(string merchantRef, long Pay360CustomerId, bool UpdateDefaultCV2 = false, string cV2 = "", string encryptionKey = "")
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@MerchantRef", merchantRef);
                parameters.Add("@Pay360CustomerId", Pay360CustomerId);
                if (UpdateDefaultCV2)
                {
                    parameters.Add("@DefaultCardCV2", cV2);
                    parameters.Add("@CV2EncryptionKey", encryptionKey);
                }
                var result = await DbConnection.SqlConnection.ExecuteAsync("Pay360_Api_UpdateCustomerIdAndCV2ByMerchantRef", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: UpdateCustomerIdAndCV2, Parameters=> merchantRef: {merchantRef}, Pay360CustomerId: {Pay360CustomerId}, encryptionKey: {JsonConvert.SerializeObject(encryptionKey)}, CV2: {cV2}, UpdateDefaultCV2: {UpdateDefaultCV2} ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<GenericApiResponse<UserResponseGetAutoTopup>> GetCustomerAutoTopup(string msisdn, string email, string productCode)
        {

            GenericApiResponse<UserResponseGetAutoTopup> res = new GenericApiResponse<UserResponseGetAutoTopup>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Msisdn", msisdn);
                parameters.Add("@Email", email);
                parameters.Add("@ProductCode", productCode);

                var result = await ThmConnection.SqlConnection.QueryAsync<UserResponseGetAutoTopup>("Pay360_Api_GetCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);

                res.payload = result.FirstOrDefault<UserResponseGetAutoTopup>();
                res.message = "Success";
                res.status = "Success";

                return res;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetCustomerAutoTopup, Parameters=>  msisdn: {msisdn}, email:{email}, productCode:{productCode}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        public async Task<GenericApiResponse<UserResponseGetAutoTopup>> GetCustomerAutoTopup_old(string msisdn)
        {

            GenericApiResponse<UserResponseGetAutoTopup> res = new GenericApiResponse<UserResponseGetAutoTopup>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Msisdn", msisdn);

                var result = await DigiTalkDbConnection.SqlConnection.QueryAsync<UserResponseGetAutoTopup>("Pay360_Api_GetCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);

                res.payload = result.FirstOrDefault<UserResponseGetAutoTopup>();
                res.message = "Success";
                res.status = "Success";

                return res;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetCustomerAutoTopup, Parameters=>  msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        public async Task<GenericApiResponse<UserResponseGetAutoTopup>> ValidateMSISDN(string msisdn)
        {

            GenericApiResponse<UserResponseGetAutoTopup> res = new GenericApiResponse<UserResponseGetAutoTopup>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Msisdn", msisdn);

                var result = await DigiTalkDbConnection.SqlConnection.QueryAsync<UserResponseGetAutoTopup>("Pay360_Api_GetCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);

                res.payload = result.FirstOrDefault<UserResponseGetAutoTopup>();
                res.message = "Success";
                res.status = "Success";

                return res;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetCustomerAutoTopup, Parameters=>  msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        public async Task<int> UpdateCustomerAutoTopup(float autoTopupTheresholdAmount, bool isAutoTopup, string msisdn, decimal topupAmount, string topupCurrency, string email, string productCode)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@AutoTopupTheresholdAmount", autoTopupTheresholdAmount);
                parameters.Add("@IsAutoTopup", isAutoTopup);
                parameters.Add("@Msisdn", msisdn);
                parameters.Add("@TopupAmount", topupAmount);
                parameters.Add("@TopupCurrency", topupCurrency);
                parameters.Add("@Email", email);
                parameters.Add("@ProductCode", productCode);


                var result = await ThmConnection.SqlConnection.ExecuteAsync("Pay360_Api_UpdateCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: UpdateCustomerAutoTopup, Parameters=> productCode:{productCode}, autoTopupTheresholdAmount: {autoTopupTheresholdAmount}, isAutoTopup: {isAutoTopup}, msisdn: {msisdn}, topupAmount: {topupAmount}, topupCurrency: {topupCurrency}, email:{email}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        public async Task<int> UpdateCustomerAutoTopup_old(float autoTopupTheresholdAmount, bool isAutoTopup, string msisdn, decimal topupAmount, string topupCurrency)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@AutoTopupTheresholdAmount", autoTopupTheresholdAmount);
                parameters.Add("@IsAutoTopup", isAutoTopup);
                parameters.Add("@Msisdn", msisdn);
                parameters.Add("@TopupAmount", topupAmount);
                parameters.Add("@TopupCurrency", topupCurrency);

                var result = await DigiTalkDbConnection.SqlConnection.ExecuteAsync("Pay360_Api_UpdateCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: UpdateCustomerAutoTopup, Parameters=> autoTopupTheresholdAmount: {autoTopupTheresholdAmount}, isAutoTopup: {isAutoTopup}, msisdn: {msisdn}, topupAmount: {topupAmount}, topupCurrency: {topupCurrency}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        public async Task<DbResult<int>> UpdateSummaryThreeDSecureCompleted(long Id)
        {
            DbResult<int> result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Id", Id);
                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("Pay360_Api_UpdateSummaryThreeDSecureCompleted", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<int>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Pay360, Method: UpdateSummaryThreeDSecureCompleted, Parameters=> Id: {Id}, ErrorMessage: {ex.Message}, DBErrorMessage: {result.DBErrorMessage}");
                //throw;
                return result;
            }
        }

        public async Task<DbResult<int>> UpdateSummaryThreeDSecureFailed(long Id)
        {
            DbResult<int> result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Id", Id);
                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("Pay360_Api_UpdateSummaryThreeDSecureFailed", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<int>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Pay360, Method: UpdateSummaryThreeDSecureFailed, Parameters=> Id: {Id}, ErrorMessage: {ex.Message}, DBErrorMessage: {result.DBErrorMessage}");
                //throw;
                return result;
            }
        }


        public async Task<Customer> GetCustomerByCustomerId(int customerId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@CustomerId", customerId);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<Customer>("Pay360_Api_GetCustomerByCustomerId_v1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetCustomerByCustomerId, Parameters=> customerId: {customerId}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<Customer> GetCustomerByPay360CustomerId(long customerId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@CustomerId", customerId);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<Customer>("Pay360_Api_GetCustomerByPay360CustomerId_v1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetCustomerByPay360CustomerId, Parameters=> customerId: {customerId}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<Pay360Transaction> GetTransactionByPay360TransactionId(string transactionId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@TransactionId", transactionId);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<Pay360Transaction>("Pay360_Api_GetTransactionByPay360TransactionId_v2", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetTransactionByPay360TransactionId, Parameters=> transactionId: {transactionId}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<Pay360Transaction> GetCardInstallationIdInfoByTransactionId(string transactionId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@TransactionId", transactionId);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<Pay360Transaction>("Pay360_Api_GetTransactionByPay360TransactionId_v1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetTransactionByPay360TransactionId, Parameters=> transactionId: {transactionId}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<TransactionDetail> GetTransactionDetail(string pay360TransactionId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@TransactionId", pay360TransactionId);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<TransactionDetail>("Pay360_Api_GetTransactionDetail", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetTransactionDetail, Parameters=> pay360TransactionId: {pay360TransactionId}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<ProductBasket[]> GetTransactionItems(string transactionId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@TransactionId", transactionId);
                var result = await DbConnection.SqlConnection.QueryAsync<ProductBasket>("Pay360_Api_GetTransactionItems", parameters, commandType: CommandType.StoredProcedure);
                return result.ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetTransactionItems, Parameters=> transactionId: {transactionId}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<List<TransactionItems>> GetTransactionItemsForFullfilment(string transactionId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@TransactionId", transactionId);
                var result = await DbConnection.SqlConnection.QueryAsync<TransactionItems>("Pay360_Api_GetTransactionItemsForFullfilment", parameters, commandType: CommandType.StoredProcedure);
                return result.ToList();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetTransactionItemsForFullfilment, Parameters=> transactionId: {transactionId}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<Pay360TransactionSummary> GetTransactionSummaryByPay360TransactionId(string transactionId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@TransactionId", transactionId);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<Pay360TransactionSummary>("Pay360_Api_GetTransactionSummaryByPay360TransactionId_v1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetTransactionSummaryByPay360TransactionId, Parameters=> customerId: {transactionId}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<DbResult<int>> UpdateTransactionSummary(string Pay360TransactionId, long TransactionId, Pay360SummaryTransactionStatuses status, DateTime utcNow, bool isFailed)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Pay360TransactionId", Pay360TransactionId);
                parameters.Add("@TransactionId", TransactionId);
                parameters.Add("@TransactionStatus_Id", status);
                parameters.Add("@DateTime", utcNow);
                parameters.Add("@IsFailed", isFailed);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("Pay360_Api_UpdateSummaryCaptured_V1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: UpdateTransactionSummary, Parameters=> Pay360TransactionId: {Pay360TransactionId}, TransactionId: {TransactionId}, TransactionStatus_Id: {status}, DateTime: {utcNow} ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<int> UpdateTransactionSummaryFullfilmentStatus(string Pay360TransactionId, int transactionStatusId, DateTime fulfilmentDate)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@pay360TransactionId", Pay360TransactionId);
                parameters.Add("@transactionStatusId", transactionStatusId);
                parameters.Add("@fulfilmentDatetime", fulfilmentDate);

                var result = await DbConnection.SqlConnection.ExecuteAsync("Pay360_Api_UpdateTransactionSummary_V1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: UpdateTransactionSummaryFullfilmentStatus, Parameters=> Pay360TransactionId: {Pay360TransactionId}, transactionStatusId: {transactionStatusId}, DateTime: {fulfilmentDate} ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<DbResult<int>> UpdateTransactionSummaryStatus(string Pay360TransactionId, long TransactionId, DateTime transactionDatetime, Pay360SummaryTransactionStatuses status)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Pay360TransactionId", Pay360TransactionId);
                parameters.Add("@TransactionStatus_Id", status);
                parameters.Add("@Transaction_Id", TransactionId);
                parameters.Add("@Transaction_DateTime", transactionDatetime);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("Pay360_Api_UpdateSummaryStatus", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: UpdateTransactionSummaryStatus, Parameters=> Pay360TransactionId: {Pay360TransactionId}, TransactionStatus_Id: {status}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        public async Task<DbResult<bool>> ValidateTopUp(string customerMsisdn, float transactionAmount)
        {
            try
            {
                DigitalkValidationResponse validationResponse = await DigiTalkValidation(customerMsisdn);
                if (validationResponse != null && validationResponse.ErrorCode == 0)
                {
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@MerchantRef", customerMsisdn);
                    parameters.Add("@Amount", transactionAmount);
                    var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<bool>>("Pay360_Api_TopUpValidations", parameters, commandType: CommandType.StoredProcedure);
                    return result;
                }
                else
                {
                    DbResult<bool> result = new DbResult<bool> { DBStatus = 4, DBErrorMessage = "Unfortunately we cann't complete the transaction now. Contact Customer service." };
                    return result;
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: ValidateTopUp, Parameters=> CustomerMsisdn: {customerMsisdn}, TransactionAmount: {transactionAmount}, ErrorMessage: {ex.Message}");
                throw;
            }
        }

        private async Task<DigitalkValidationResponse> DigiTalkValidation(string msisdn)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@errorCode", ParameterDirection.Output);
                parameters.Add("@errorMsg", ParameterDirection.Output);

                var result = await DigiTalkDbConnection.SqlConnection.QueryFirstOrDefaultAsync<DigitalkValidationResponse>("tha_topup_digitalk_validation", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: DigiTalkValidation, Parameters=> msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }


        public async Task<FullfilmentResponse> ThmStraightCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef, string customerEmail, string productCode)
        {

            if (string.IsNullOrEmpty(bundleRef))
                bundleRef = "";

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@amount", Decimal.Parse(amount));
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@bundlename", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
                parameters.Add("@ProductCode", productCode);
                parameters.Add("@Email", customerEmail);
                parameters.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

                var result = await ThmConnection.SqlConnection.QueryFirstOrDefaultAsync<THRCCAudit>("thm_pay360_accountupdatebalance_v3", parameters, commandType: CommandType.StoredProcedure);
                if (result != null)
                {
                    int ErrorCode = parameters.Get<int>("@error_code");
                    string ErrorMessage = parameters.Get<string>("@error_msg");

                    if (ErrorCode == 0)
                    {
                        response.BundleName = parameters.Get<string>("@bundlename");
                        response.ErrorCode = 0;
                        response.ErrorMessage = "Success";
                        response.Audit = result;
                    }
                    else
                    {
                        response.ErrorCode = 2;
                        response.ErrorMessage = ErrorMessage;
                        response.Audit = null;
                    }
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "Topup failed";
                    response.Audit = null;
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Pay360.cs, Method: ThmStraightCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;

            //FullfilmentResponse response = new FullfilmentResponse();
            //try
            //{

            //    var storedProcedure = "thm_pay360_accountupdatebalance_queue_v1";

            //    if (string.IsNullOrEmpty(bundleRef)) bundleRef = "";

            //    var parameters = new DynamicParameters();
            //    parameters.Add("@bundleref", bundleRef);
            //    parameters.Add("@productref", productRef);
            //    parameters.Add("@transactionid", transactionId);
            //    parameters.Add("@amount", decimal.Parse(amount));
            //    parameters.Add("@bundlename", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

            //    var result = await ThmConnection.SqlConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

            //    response.ErrorCode = 0;
            //    response.BundleName = parameters.Get<string>("@bundlename");
            //    response.ErrorMessage = "Success";

            //    //DynamicParameters parameters = new DynamicParameters();
            //    //parameters.Add("@bundleref", bundleRef);
            //    //parameters.Add("@amount", amount);
            //    //parameters.Add("@transactionid", transactionId);
            //    //parameters.Add("@productref", productRef);
            //    //parameters.Add("@errorcode", ParameterDirection.Output, DbType.Int32);
            //    //parameters.Add("@errormsg", ParameterDirection.Output, DbType.String);

            //    //var result = await ThmConnection.SqlConnection.QueryAsync("thm_pay360_accountupdatebalance", parameters, commandType: CommandType.StoredProcedure);
            //    //response.ErrorCode = parameters.Get<int>("@errorcode");
            //    //response.ErrorMessage = parameters.Get<string>("@errormsg");

            //}
            //catch (Exception ex)
            //{
            //    response.ErrorCode = 1;
            //    response.ErrorMessage = "Code Exception: " + ex.Message;
            //    Logger.Error($"Class: DL_Pay360, Method: ThmCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {ex.Message}");
            //}
            //return response;
        }

        public async Task<FullfilmentResponse> ThccCustomerFullfilment(string transactionId,
           string amount,
           string email,
           string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", amount);
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                var thpin = await ThccConnection.SqlConnection.QueryFirstOrDefaultAsync<THCCPin>("thcc_getNextPIN_pay360_v1", parameters, commandType: CommandType.StoredProcedure);

                if (thpin != null)
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Pin = thpin.pin.Trim();
                    response.new_balance = int.Parse(thpin.credit.ToString());
                }
                else
                {
                    response.ErrorCode = 1;
                    response.ErrorMessage = "Null response received from strored procedure 'thcc_getNextPIN_pay360_v1'";
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                response.Pin = "";
                Logger.Error($"Class: DL_Pay360.cs, Method: ThccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }


        public async Task<FullfilmentResponse> ThrccCustomerFullfilment(string transactionId,
        string amount,
        string productRef,
        string email,
        string firstname)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {

                if (productRef == null || string.IsNullOrEmpty(productRef))
                    productRef = "";

                if (productRef == "")
                {
                    THRCCPin trccPin = await GetNextRCCPin(email, firstname, transactionId);
                    if (trccPin != null && trccPin.account != null)
                    {
                        productRef = trccPin.account.Trim();
                    }
                }


                int denomination = 0;
                if (!string.IsNullOrEmpty(amount))
                    denomination = int.Parse(amount);
                else
                    denomination = 0;

                if (denomination == 0)
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "failed";
                    response.Pin = "";

                    return response;
                }



                //DynamicParameters parameters = new DynamicParameters();
                //parameters.Add("@amount", denomination);
                //parameters.Add("@transactionid", transactionId);
                //parameters.Add("@productref", productRef);
                //parameters.Add("@thccpin", null, DbType.String, direction: ParameterDirection.Output, size: 150);
                //parameters.Add("@errorcode", null, DbType.Int32, direction: ParameterDirection.Output);
                //parameters.Add("@errormsg", null, DbType.String, direction: ParameterDirection.Output, size: 200);

                //var result = await ThrccConnection.SqlConnection.QueryFirstOrDefaultAsync<THRCCAudit>("thcc_pay360_accountupdatebalance", parameters, commandType: CommandType.StoredProcedure);

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@amount", amount);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@productref", productRef);
                parameters.Add("@thccpin", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 150);
                parameters.Add("@errorcode", null, dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 200);
                parameters.Add("@account", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 50);

                //var result = await ThrccConnection.SqlConnection.QueryAsync("thm_pay360_accountupdatebalance", parameters, commandType: CommandType.StoredProcedure);
                var result = await ThrccConnection.SqlConnection.QueryFirstOrDefaultAsync<FullfilmentResponse>("thcc_pay360_accountupdatebalance_v1", parameters, commandType: CommandType.StoredProcedure);


                if (result != null)
                {
                    response.ErrorCode = parameters.Get<int>("@errorcode");
                    response.ErrorMessage = parameters.Get<string>("@errormsg");
                    response.Pin = parameters.Get<string>("@thccpin").Trim();
                    response.audit_id = result.audit_id;
                    response.new_balance = result.new_balance;
                    response.productRef = productRef;
                    response.Card = parameters.Get<string>("@account").Trim();

                    //response.ErrorCode = parameters.Get<int>("@errorcode");
                    //response.ErrorMessage = parameters.Get<string>("@errormsg");
                    //response.Pin = parameters.Get<string>("@thccpin");

                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "PIN Topup failed";
                    response.Pin = "";
                    response.Audit = null;
                }
            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
                Logger.Error($"Class: DL_Pay360, Method: ThrccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }


        private async Task<THRCCPin> GetNextRCCPin(string email, string firstName, string th_transaction_reference)
        {
            THRCCPin trccPin = new THRCCPin();

            try
            {



                var parameters = new DynamicParameters();
                parameters.Add("@email", email);
                parameters.Add("@firstName", firstName);
                parameters.Add("@th_transaction_reference", th_transaction_reference);
                parameters.Add("@pin", null, DbType.String, direction: ParameterDirection.Output, size: 20);
                parameters.Add("@pan", null, DbType.String, direction: ParameterDirection.Output, size: 38);



                var thcc = await ThccConnection.SqlConnection.ExecuteAsync("get_pin_webAPI_v1", parameters, commandType: CommandType.StoredProcedure);


                trccPin.pin = Convert.ToString(parameters.Get<dynamic>("@pin")).Trim();
                trccPin.account = Convert.ToString(parameters.Get<dynamic>("@pan"));
            }
            catch (Exception ex)
            {
                Logger.Error("Exception occured while getting the Recharageble card \n" + ex.ToString());

            }


            return trccPin;
        }

        //public async Task<FullfilmentResponse> ThccCustomerFullfilment(string transactionId, string amount)
        //{

        //    FullfilmentResponse response = new FullfilmentResponse();
        //    try
        //    {
        //        DynamicParameters parameters = new DynamicParameters();
        //        parameters.Add("@amount", amount);
        //        parameters.Add("@transactionid", transactionId);
        //        parameters.Add("@thccpin", ParameterDirection.Output, DbType.String);
        //        parameters.Add("@errorcode", ParameterDirection.Output, DbType.Int32);
        //        parameters.Add("@errormsg", ParameterDirection.Output, DbType.String);

        //        var result = await ThccConnection.SqlConnection.QueryAsync("thm_pay360_accountupdatebalance", parameters, commandType: CommandType.StoredProcedure);
        //        response.ErrorCode = parameters.Get<int>("@errorcode");
        //        response.ErrorMessage = parameters.Get<string>("@errormsg");
        //        response.Pin = parameters.Get<string>("@thccpin");
        //    }
        //    catch (Exception ex)
        //    {
        //        response.ErrorCode = 1;
        //        response.ErrorMessage = "Code Exception: " + ex.Message;
        //        Logger.Error($"Class: DL_Pay360, Method: ThccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, ErrorMessage: {ex.Message}");
        //    }
        //    return response;
        //}

        //public async Task<FullfilmentResponse> ThrccCustomerFullfilment(string transactionId, string amount, string productRef)
        //{

        //    FullfilmentResponse response = new FullfilmentResponse();
        //    try
        //    {
        //        DynamicParameters parameters = new DynamicParameters();
        //        parameters.Add("@amount", amount);
        //        parameters.Add("@transactionid", transactionId);
        //        parameters.Add("@productref", productRef);
        //        parameters.Add("@thccpin", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 150);
        //        parameters.Add("@errorcode", null, dbType: DbType.Int32, direction: ParameterDirection.Output);
        //        parameters.Add("@errormsg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 200);
        //        parameters.Add("@account", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 50);

        //        //var result = await ThrccConnection.SqlConnection.QueryAsync("thm_pay360_accountupdatebalance", parameters, commandType: CommandType.StoredProcedure);
        //        var result = await ThrccConnection.SqlConnection.QueryAsync("thcc_pay360_accountupdatebalance_v1", parameters, commandType: CommandType.StoredProcedure);
        //        response.ErrorCode = parameters.Get<int>("@errorcode");
        //        response.ErrorMessage = parameters.Get<string>("@errormsg");
        //        response.Pin = parameters.Get<string>("@thccpin");
        //        response.Card = parameters.Get<string>("@account");

        //    }
        //    catch (Exception ex)
        //    {
        //        response.ErrorCode = 1;
        //        response.ErrorMessage = "Code Exception: " + ex.Message;
        //        Logger.Error($"Class: DL_Pay360, Method: ThrccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, productRef: {productRef}, ErrorMessage: {ex.Message}");
        //    }
        //    return response;
        //}

        public async Task<int> UpdateTransactionItem(int Id, string FullfillmentError, bool IsSmsSent, bool IsEmailSent, bool IsFullfilled, DateTime? SmsSent_DateTime, DateTime? EmailSent_DateTime, DateTime? FulfilmentDateTime)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", Id);
                parameters.Add("@FullfillmentError", FullfillmentError);
                parameters.Add("@IsSmsSent", IsSmsSent);
                parameters.Add("@IsEmailSent", IsEmailSent);
                parameters.Add("@IsFullfilled", IsFullfilled);
                parameters.Add("@SmsSent_DateTime", SmsSent_DateTime);
                parameters.Add("@EmailSent_DateTime", EmailSent_DateTime);
                parameters.Add("@FulfilmentDateTime", FulfilmentDateTime);
                var result = await DbConnection.SqlConnection.ExecuteAsync("Pay360_Api_UpdateTransactionItem", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public async Task<int> UpdateCustomerAutoTopup_THRCC(float thresholdBalanceAmount, bool isAutoTopup, string productRef, decimal topupAmount, string topupCurrency, string email, string productCode)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@AutoTopupTheresholdAmount", thresholdBalanceAmount);
                parameters.Add("@account", productRef);
                parameters.Add("@TopupAmount", topupAmount);
                parameters.Add("@TopupCurrency", topupCurrency);
                parameters.Add("@IsAutoTopup", isAutoTopup);
                parameters.Add("@Email", email);
                parameters.Add("@ProductCode", productCode);


                var result = await ThrccConnection.SqlConnection.ExecuteAsync("Pay360_Api_UpdateCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: UpdateCustomerAutoTopup_ThRCC, Parameters=> account: {productRef}, productCode:{productCode}, autoTopupTheresholdAmount: {thresholdBalanceAmount}, isAutoTopup: {isAutoTopup}, msisdn: {productRef}, topupAmount: {topupAmount}, topupCurrency: {topupCurrency}, email:{email}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        public async Task<int> UpdateCustomerAutoTopup_THA(float autoTopupTheresholdAmount, bool isAutoTopup, string msisdn, decimal topupAmount, string topupCurrency)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@AutoTopupTheresholdAmount", autoTopupTheresholdAmount);
                parameters.Add("@IsAutoTopup", isAutoTopup);
                parameters.Add("@Msisdn", msisdn);
                parameters.Add("@TopupAmount", topupAmount);
                parameters.Add("@TopupCurrency", topupCurrency);

                var result = await ThaConnection.SqlConnection.ExecuteAsync("Pay360_Api_UpdateCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: UpdateCustomerAutoTopup_THA, Parameters=> autoTopupTheresholdAmount: {autoTopupTheresholdAmount}, isAutoTopup: {isAutoTopup}, msisdn: {msisdn}, topupAmount: {topupAmount}, topupCurrency: {topupCurrency}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        public async Task<GenericApiResponse<UserResponseGetAutoTopup_THRCC>> GetCustomerAutoTopup_THRCC(string msisdn, string email, string productCode)
        {
            GenericApiResponse<UserResponseGetAutoTopup_THRCC> res = new GenericApiResponse<UserResponseGetAutoTopup_THRCC>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@account", msisdn);
                parameters.Add("@Email", email);
                parameters.Add("@ProductCode", productCode);

                var result = await ThrccConnection.SqlConnection.QueryAsync<UserResponseGetAutoTopup_THRCC>("Pay360_Api_GetCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);

                res.payload = result.FirstOrDefault<UserResponseGetAutoTopup_THRCC>();
                res.message = "Success";
                res.status = "Success";

                return res;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetCustomerAutoTopup_THRCC, Parameters=>  account: {msisdn}, email:{email}, productCode:{productCode}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        public async Task<GenericApiResponse<UserResponseGetAutoTopup>> GetCustomerAutoTopup_THA(string msisdn)
        {

            GenericApiResponse<UserResponseGetAutoTopup> res = new GenericApiResponse<UserResponseGetAutoTopup>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Msisdn", msisdn);

                var result = await ThaConnection.SqlConnection.QueryAsync<UserResponseGetAutoTopup>("Pay360_Api_GetCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);

                res.payload = result.FirstOrDefault<UserResponseGetAutoTopup>();
                res.message = "Success";
                res.status = "Success";

                return res;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetCustomerAutoTopup_THA, Parameters=>  msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        // ITSA Validations
        //public async Task<DbResult<bool>> ItsaValidateTopUp(string customerMsisdn, float transactionAmount)
        //{
        //    try
        //    {
        //        DigitalkValidationResponse validationResponse = await ItsaDigiTalkValidation(customerMsisdn);
        //        if (validationResponse != null && validationResponse.ErrorCode == 0)
        //        {
        //            DynamicParameters parameters = new DynamicParameters();
        //            parameters.Add("@MerchantRef", customerMsisdn);
        //            parameters.Add("@Amount", transactionAmount);
        //            var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<bool>>("Pay360_Api_ItsaTopUpValidations", parameters, commandType: CommandType.StoredProcedure);
        //            return result;
        //        }
        //        else
        //        {
        //            DbResult<bool> result = new DbResult<bool> { DBStatus = 4, DBErrorMessage = "Unfortunately we cann't complete the transaction now. Contact Customer service." };
        //            return result;
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Error($"Class: DL_Pay360, Method: ItsaValidateTopUp, Parameters=> CustomerMsisdn: {customerMsisdn}, TransactionAmount: {transactionAmount}, ErrorMessage: {ex.Message}");
        //        throw;
        //    }
        //}

        // ITSA Validations

        // ITSA Validations
        public async Task<DbResult<bool>> ItsaValidations(string customerMsisdn, float transactionAmount)
        {
            try
            {

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@MerchantRef", customerMsisdn);
                parameters.Add("@productCode", "ITSA");
                var valLimit = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<ValidationLimit>("Pay360_Api_TopUpValidations_Limit_v1", parameters, commandType: CommandType.StoredProcedure);

                if (valLimit != null)
                {
                    ValidateRes result = await ItsaProductRefValidation(customerMsisdn, "");

                    if (result.Errorcode == 1) // Not Valid ProductRef
                    {
                        DbResult<bool> result1 = new DbResult<bool> { DBStatus = 3, DBErrorMessage = $"Invalid ProductRef: {customerMsisdn}" };
                        return result1;
                    }
                    else if (result.Errorcode == 2)
                    {
                        DbResult<bool> result1 = new DbResult<bool> { DBStatus = 21, DBErrorMessage = $"You have reached the maximum number of bundles" };
                        return result1;

                    }
                    else if (result.Errorcode != 0) // Not Valid ProductRef
                    {

                        DbResult<bool> result1 = new DbResult<bool> { DBStatus = 22, DBErrorMessage = $"Topup denied for MSISDN : {customerMsisdn}" };
                        return result1;

                    }
                    else if (transactionAmount != 0 && result.Tamount != 0 && valLimit.AmountLimit < (float.Parse(result.Tamount.ToString()) + transactionAmount))
                    {

                        DbResult<bool> result1 = new DbResult<bool> { DBStatus = 5, DBErrorMessage = $"You exceeded daily the limit" };
                        return result1;
                    }
                    else
                    {
                        DbResult<bool> result1 = new DbResult<bool> { DBStatus = 0, DBErrorMessage = $"Success" };
                        return result1;
                    }
                }
                else
                {

                    DbResult<bool> result = new DbResult<bool> { DBStatus = 7, DBErrorMessage = "Unfortunately we cann't complete the transaction now. Contact Customer service." };
                    return result;
                }


            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: ValidateTopUp, Parameters=> CustomerMsisdn: {customerMsisdn}, TransactionAmount: {transactionAmount}, ErrorMessage: {ex.Message}");
                DbResult<bool> result = new DbResult<bool> { DBStatus = 7, DBErrorMessage = "Unfortunately we cann't complete the transaction now. Contact Customer service." };
                return result;
            }
        }
        public async Task<ValidateRes> ItsaProductRefValidation(string productRef, string bundleRef)
        {

            //return 0; // For Testing Purpose Only. Comment this for Live and Un-Comment below code for live
            ValidateRes valRes = new ValidateRes();
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@productref", productRef);

                bundleRef = string.IsNullOrWhiteSpace(bundleRef) ? "" : bundleRef;
                parameters.Add("@bundleRef", bundleRef);
                parameters.Add("@tamount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ItsaConnection.SqlConnection.ExecuteAsync("itsa_pay360_validate_msisdn_v2", parameters, commandType: CommandType.StoredProcedure);

                valRes.Errorcode = parameters.Get<Int32>("@errorcode");
                valRes.Errormsg = parameters.Get<string>("@errormsg");
                valRes.Tamount = parameters.Get<Int32>("@tamount");

                valRes.Tamount = valRes.Tamount / 100;

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: ItsaProductRefValidation, Parameters => productRef: {productRef}, bundleRef: {bundleRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                valRes.Errorcode = 1;
                valRes.Errormsg = ex.Message;
            }

            return valRes;

        }

        public async Task<int> GetPoints(string account)
        {
            //var storedprocedure = "th_get_points";
            var storedprocedure = "th_get_web_points_by_account_revised";
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@account", account);
                //parameter.Add("@errorcode", null, DbType.Int32, direction: ParameterDirection.Output);
                //parameter.Add("@errormsg", null, DbType.String, direction: ParameterDirection.Output, size: 255);

                //return await TalkHomePaymentsConnection.SqlConnection.QueryFirstOrDefaultAsync<int>(storedprocedure, parameter, commandType: CommandType.StoredProcedure);
                return await ThrccConnection.SqlConnection.QueryFirstOrDefaultAsync<int>(storedprocedure, parameter, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetPoints, Parameters=> {account} , ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        public async Task<int> THRCCAddRewardPoints(int auditId, string account, float amount)
        {
            var storedprocedure = "th_get_points_by_account_v5";
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@account", account);
                parameter.Add("@auditId", auditId);
                parameter.Add("@amount", amount);

                var rewardPointsResponse = await ThrccConnection.SqlConnection.QueryFirstOrDefaultAsync<RewardPointsSummary>(storedprocedure, parameter, commandType: CommandType.StoredProcedure);

                if (rewardPointsResponse != null)
                {
                    parameter = new DynamicParameters();
                    parameter.Add("@account", account);
                    parameter.Add("@points", rewardPointsResponse.tpoints);

                    var updateResponse = await TalkHomePaymentsConnection.SqlConnection.ExecuteAsync("trc_update_points", parameter, commandType: CommandType.StoredProcedure);

                    if (updateResponse != 1)
                    {
                        Logger.Error($"Class: DL_Pay360, Method: THRCCAddRewardPoints, Parameters=> Account:{account}, Points: {rewardPointsResponse.tpoints} , ErrorMessage: Unable to Update Points");
                    }

                    return updateResponse;
                }
                else
                {
                    Logger.Error($"Class: DL_Pay360, Method: THRCCAddRewardPoints, Parameters=> Account:{account}, Audit-Id: {auditId}, Amount:{amount} , ErrorMessage: Unable to Get Points");
                    return 0;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: THRCCAddRewardPoints, Parameters=> {account} , ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }


        //private async Task<DigitalkValidationResponse> ItsaDigiTalkValidation(string msisdn)
        //{
        //    try
        //    {
        //        DynamicParameters parameters = new DynamicParameters();
        //        parameters.Add("@msisdn", msisdn);
        //        parameters.Add("@errorCode", ParameterDirection.Output);
        //        parameters.Add("@errorMsg", ParameterDirection.Output);

        //        var result = await ItsaConnection.SqlConnection.QueryFirstOrDefaultAsync<DigitalkValidationResponse>("Itsa_topup_digitalk_validation", parameters, commandType: CommandType.StoredProcedure);
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Error($"Class: DL_Pay360, Method: ItsaDigiTalkValidation, Parameters=> msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
        //        throw;
        //    }
        //}

    }
}
