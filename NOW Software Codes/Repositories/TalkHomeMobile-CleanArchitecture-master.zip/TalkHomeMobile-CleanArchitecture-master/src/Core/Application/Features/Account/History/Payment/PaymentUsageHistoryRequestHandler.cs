using Application.Common.Settings;
using Application.Features.Account.History.Models;
using Application.Features.Bundle.Model;
using Application.Features.Payment.Models;

using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;

namespace Application.Features.Account.History.Payment;
public class PaymentUsageHistoryRequestHandler : IRequestHandler<PaymentUsageHistoryRequest, Result<PaymentHistoryResponse>>
{
    private readonly IUnitOfWork _uow;
    private readonly ILogger _logger;
    private readonly IStringLocalizer<PaymentUsageHistoryRequestHandler> _localizer;
    private readonly ICommonService _commonService;
    private readonly CallBackSettings _callbackSettings;
    private readonly IUserService _userService;
    private readonly IMapper _mapper;

    public PaymentUsageHistoryRequestHandler(
        IUnitOfWork uow,
        ILogger logger,
        IMapper mapper,
        IStringLocalizer<PaymentUsageHistoryRequestHandler> localizer,
        ICommonService commonService,
        IOptions<CallBackSettings> callbackSettings,
        IUserService userService)
    {
        _uow = uow;
        _logger = logger;
        _localizer = localizer;
        _commonService = commonService;
        _userService = userService;
        _mapper = mapper;
        _callbackSettings = callbackSettings.Value;
    }

    public async Task<Result<PaymentHistoryResponse>> Handle(PaymentUsageHistoryRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();
        if (IsAppRequest)
        {
          
            request.StartDate = DateTime.UtcNow.Date;
            request.EndDate = DateTime.UtcNow.Date.AddDays(7);
            request.PageNo = 1;
            request.PageSize = 20;
        }
       
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<PaymentHistoryResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var paymentHistory = await _uow.UserRepo.PaymentHistory(request.Msisdn, request.StartDate, request.EndDate, request.PageNo, request.PageSize);
        List<PaymentHistoryInfo> paymentHistoryInfo = new List<PaymentHistoryInfo>();
        foreach (var item in paymentHistory)
        {
            string CardMaskedPan = "", ImageURL = "", GoodyBagColorCode = "";
            if (!String.IsNullOrEmpty(item.OrderData))
            {
                var orderData = JsonConvert.DeserializeObject<OrderData>(item.OrderData!)!;
                if (orderData != null)
                {
                    if (item.PaymentMethodType == (int) PaymentMethod.Card)
                    {
                        CardMaskedPan = string.IsNullOrEmpty(orderData.CardMaskedPan)
                        ? "Card Payment" : orderData.CardMaskedPan;
                        ImageURL = (IsAppRequest ? _callbackSettings.AppBaseUrl! : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(orderData.CardScheme!);
                    }
                    if (orderData.BundleInfo != null)
                    {
                        if (!String.IsNullOrEmpty(orderData!.BundleInfo!.GoodyBagColorCode))
                        {
                            GoodyBagColorCode =  orderData!.BundleInfo!.GoodyBagColorCode ;
                        }
                        else
                        {
                            var bundle = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(item?.BundleId!));
                            if (bundle != null)
                            {
                                GoodyBagColorCode = bundle?.GoodyBagColorCode!;
                            }
                            else
                            {
                                GoodyBagColorCode = "basic";
                            }
                        }
                    }
                    else
                    {
                        if (item.TransactionType == (int) TransactionType.Bundle && item.IsAuto)
                        {
                            var bundle = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(item?.BundleId!));
                            if (bundle != null)
                            {
                                GoodyBagColorCode = bundle?.GoodyBagColorCode!;
                            }
                        }
                        else if (item.TransactionType == (int) TransactionType.Bundle || item.TransactionType == (int) TransactionType.CancelBundleRefund|| item.TransactionType == (int) TransactionType.EarlyTerminationCharges)
                        {
                            var bundle = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(item?.BundleId!));
                            if (bundle != null)
                            {
                                GoodyBagColorCode = bundle?.GoodyBagColorCode!;
                            }
                        }
                    }
                }
            }
            else
            {
                CardMaskedPan = "Card Payment";
                ImageURL = (IsAppRequest ? _callbackSettings.AppBaseUrl! : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(null!);
                if (!string.IsNullOrEmpty(item.BundleId))
                {
                    var bundle = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(item?.BundleId!));
                    if (bundle != null)
                    {
                        GoodyBagColorCode = bundle?.GoodyBagColorCode!;
                    }
                    else
                    {
                        GoodyBagColorCode = "basic";
                    }
                }
            }
            var  vatAmount =Math.Round(  Convert.ToDouble(item.Amount.Replace("�", "")) - (Convert.ToDouble(item.Amount.Replace("�", "")) / 1.2), Convert.ToDouble(item.Amount.Replace("�", "")) <0.01 ?3:2 );
            
            PaymentHistoryInfo vm = new PaymentHistoryInfo
            {
                Amount ="�" + Convert.ToDouble(Math.Round((Convert.ToDouble(item.Amount.Replace("�", ""))-vatAmount), Convert.ToDouble(item.Amount.Replace("�", "")) < 0.01 ? 3 : 2)),
                VatAmount= "�" + vatAmount.ToString(),
                BundleCountryCode = item.BundleCountryCode,
                BundleName = item.BundleName,
                Discount = item.Discount,
                Msisdn = item.Msisdn,
                OrderID = item.OrderID,
                PaymentMethodType = item.PaymentMethodType,
                TotalAmount = item.TotalAmount,
                TotalCount = item.TotalCount,
                TransactionDate = item.TransactionDate,
                TransactionId = item.TransactionId,
                TransactionItemType = item.TransactionItemType,
                TransactionType = item.TransactionType,
                CardMaskedPan = CardMaskedPan,
                ImageURL = ImageURL,
                GoodyBagColorCode = GoodyBagColorCode,
                IsAuto = item.IsAuto,
                OrderStatus = ((int) item.OrderStatus).ToString()
            };
            paymentHistoryInfo.Add(vm);
        }
        //paymentHistoryInfo = _mapper.Map<List<PaymentHistoryInfo>>(paymentHistory);
        var paymentHistoryResponse = new PaymentHistoryResponse()
        {
            History = paymentHistoryInfo,
            TotalCount = paymentHistory.Select(x => x.TotalCount).FirstOrDefault(),
            PageNo = request.PageNo,
            RecordsFiltered = paymentHistory.Count()
        };
        return Result<PaymentHistoryResponse>.Success(paymentHistoryResponse, _localizer[CustomStatusKey.Success]);
    }
}