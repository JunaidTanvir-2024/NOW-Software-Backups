﻿
namespace Application.Features.Discount;
public class DiscountRequestHandler : IRequestHandler<DiscountRequest, Result<DiscountResponse>>
{
    #region Fields

    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<DiscountRequest> _localizer;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly IDiscountService _discountService;

    #endregion

    #region Ctors

    public DiscountRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<DiscountRequest> localizer,
        ICurrentUser currentUser,
        ICommonService commonService,
        IDiscountService discountService
    )
    {
        _uow = uow;
        _localizer = localizer;
        _currentUser = currentUser;
        _commonService = commonService;
        _discountService = discountService;
    }

    #endregion

    #region Method

    public async Task<Result<DiscountResponse>> Handle(DiscountRequest request, CancellationToken cancellationToken)
    {
        DateTime? LastTopupDate = null;

        if (!string.IsNullOrEmpty(request.Msisdn))
        {
            // Get Msisdn details
            request.Msisdn = _commonService.FormatMsisdn(request.Msisdn!);
            MsisdnDetails? msisdnDetails = await _uow.UserRepo.GetMsisdnDetail(request.Msisdn);
            if (msisdnDetails == null)
            {
                return Result<DiscountResponse>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            }
            var lastTopup = await _uow.UserRepo.GetUserLastTopupInfo(msisdnDetails.AccountId!);
            if (lastTopup != null)
            {
                LastTopupDate = lastTopup.Date;
            }
        }

        // Get discount
        var discountAmount = _discountService.GetDiscount(LastTopupDate, request.TopupAmount, request.CheckoutType);
        var response = new DiscountResponse
        {
            Discount = discountAmount
        };
        return Result<DiscountResponse>.Success(response, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
