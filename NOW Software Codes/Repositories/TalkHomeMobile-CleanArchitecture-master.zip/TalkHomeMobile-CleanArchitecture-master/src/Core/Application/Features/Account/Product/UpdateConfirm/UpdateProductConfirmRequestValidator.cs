﻿namespace Application.Features.Account.Product.UpdateConfirm;

public class UpdateProductConfirmValidator : AbstractValidator<UpdateProductConfirmRequest>
{
    public UpdateProductConfirmValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");

        RuleFor(p => p.ProductId).Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .Must(x => x > 0)
            .WithMessage("Invalid Product Ref");

        RuleFor(p => p.Otp).Cascade(CascadeMode.Stop)
            //.NotEmpty()
            .NotNull();
    }
}
