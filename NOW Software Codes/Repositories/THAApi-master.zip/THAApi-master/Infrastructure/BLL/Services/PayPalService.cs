﻿using Infrastructure.BLL.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.PaypalApiContracts;
using Models.Contracts.Response;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Infrastructure.BLL.Services
{
	public class PayPalService : IPayPalService
	{
		#region Fields

		private readonly PayPalConfig _paypalSettings;
		private readonly CallBackSettings _callBackSettings;
		private readonly ILogger _logger;
		private readonly HttpClient _httpClient;
		private readonly InAppPageConfig inAppConfig;

		#endregion

		#region Ctor

		public PayPalService(
			IOptions<PayPalConfig> paypalSettings,
			IOptions<CallBackSettings> callBackSettings,
			ILogger logger,
			HttpClient httpClientFactory,
			IOptions<InAppPageConfig> inAppConfig)
		{
			_paypalSettings = paypalSettings.Value;
			_callBackSettings = callBackSettings.Value;
			_logger = logger;
			_httpClient = httpClientFactory;
			this.inAppConfig = inAppConfig.Value;
		}

		#endregion

		#region Methods

		#region Public
		public async Task<PaypalPaymentResponse> PayPalCreateSalePayment(PaypalPaymentRequest request, PaypalPaymentCallbackData returnUrlQueryStirng)
		{
			//Handle Direct Paypal Payment Request
			var paymentRquest = CreateDirectPaypalRequest(request,returnUrlQueryStirng);

			//handle Direct Paypal Payment Response 
			return await DirectPaypalCreateSalePayment(paymentRquest);
		}
		public async Task<PaypalPaymentResponse> PayPalCreateSalePaymentWithSubscription(PaypalPaymentRequest request, bool subscriptionWithInitialSale = false)
		{
			//Handle Direct Paypal Payment Request
			var paymentRquest = CreateDirectPaypalRequestWithSubscription(request, subscriptionWithInitialSale);
			paymentRquest.SubscriptionWithInitialSale = subscriptionWithInitialSale;
			if (subscriptionWithInitialSale)
			{
				paymentRquest.SubscriptionStartDate = DateTime.UtcNow.AddSeconds(5);
			}
			else
			{
				paymentRquest.SubscriptionStartDate = DateTime.UtcNow.AddDays(30);
			}
			//handle Direct Paypal Payment Response 
			return await DirectPaypalCreateSalePaymentWithSubscription(paymentRquest);
		}
		public async Task<PaypalPaymentResponse> PayPalCancelSubscription(PaypalSuspendSubscriptionRequest request)
		{
			//Handle Direct Paypal Payment Request
			var paymentRquest = CreateDirectPaypalCancelSubscription(request);
			//handle Direct Paypal Payment Response 
			return await DirectPaypalCancelSubscription(paymentRquest);
		}

		public async Task<PaypalPaymentResponse> DirectPayPalExecuteSalePayment(
			string customerUniqueRef,
			string payerId,
			string paymentId)
		{
			var Json = JsonConvert.SerializeObject(new PayPalDirectExecuteSalePaymentRequest()
			{
				CustomerUniqueRef = customerUniqueRef,
				IsDirectFullfilment = _paypalSettings.IsDirectFullfilment,
				Payer_id = payerId,
				Payment_id = paymentId,
				ProductCode = ProductCode.THA.ToString()
			});
			var content = new StringContent(Json, Encoding.UTF8, "application/json");
			var output = await _httpClient.PostAsync(_paypalSettings.PayPalApiEndpoint + "Paypal/ExecuteSalePayment", content);
			string outputData = await output.Content.ReadAsStringAsync();
			if (output.IsSuccessStatusCode)
			{
				var paypalPaymentResponse = new PaypalPaymentResponse();
				var response = JsonConvert.DeserializeObject
					<GenericApiResponse<PayPalDirectExecuteSalePaymentResponse>>(outputData)!;
				if (response.ErrorCode > 0)
				{
					//log here the complete response
					paypalPaymentResponse.IsSuccess = false;
					if (response.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.DailyPaymentLimitExceeded;
					}
					else if (response.ErrorCode == (int)Pay360StatusCodes.limitExceed_MaximumBundle)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.BundlePurchaseLimitExceeded;
					}
					else if (response.ErrorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.PaymentProviderError;
						paypalPaymentResponse.ErrorMessage = response.Message;
					}
					else
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.PaymentServiceError;
					}
					return paypalPaymentResponse;
				};
				paypalPaymentResponse.IsSuccess = true;
				paypalPaymentResponse.TransactionId = response.Payload!.PaypalTransactionId;
				return paypalPaymentResponse;
			}
			else
			{
				_logger.Error(
				   $"Class: PayPalService, " +
				   $"Method: PayPalExecuteSalePayment" +
				   $"Status Code: {output.StatusCode}" +
				   $"Request: {Json}" +
				   $"Response: {outputData}");
			}
			return null!;
		}
		public async Task<PayPalUpdateSubscriptionResponse> UpdatePayPalSubscriptionProductRef(
			string subscriptionId,
			string productRef)
		{
			var Json = JsonConvert.SerializeObject(new PayPalDirectUpdateSubscriptionRequest()
			{
				SubscriptionId = subscriptionId,
				ProductRef = productRef
			});
			var content = new StringContent(Json, Encoding.UTF8, "application/json");
			var output = await _httpClient.PostAsync(_paypalSettings.PayPalApiEndpoint + "Paypal/UpdateSubscription", content);
			string outputData = await output.Content.ReadAsStringAsync();
			if (output.IsSuccessStatusCode)
			{
				var paypalPaymentResponse = new PayPalUpdateSubscriptionResponse();
				var response = JsonConvert.DeserializeObject
					<GenericApiResponse<object>>(outputData)!;
				if (response.ErrorCode > 0)
				{
					//log here the complete response
					paypalPaymentResponse.IsSuccess = false;
					if (response.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.DailyPaymentLimitExceeded;
					}
					else if (response.ErrorCode == (int)Pay360StatusCodes.limitExceed_MaximumBundle)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.BundlePurchaseLimitExceeded;
					}
					else if (response.ErrorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.PaymentProviderError;
						paypalPaymentResponse.ErrorMessage = response.Message;
					}
					else
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.PaymentServiceError;
					}
					return paypalPaymentResponse;
				};
				paypalPaymentResponse.IsSuccess = true;
				return paypalPaymentResponse;
			}
			else
			{
				_logger.Error(
				   $"Class: PayPalService, " +
				   $"Method: UpdatePayPalSubscriptionProductRef" +
				   $"Status Code: {output.StatusCode}" +
				   $"Request: {Json}" +
				   $"Response: {outputData}");
			}
			return null!;
		}

		#endregion

		#region Private

		private async Task<PaypalPaymentResponse> DirectPaypalCreateSalePayment(PayPalDirectCreateSalePaymentRequest request)
		{
			var Json = JsonConvert.SerializeObject(request);
			var content = new StringContent(Json, Encoding.UTF8, "application/json");
			var output = await _httpClient.PostAsync(_paypalSettings.PayPalApiEndpoint + "Paypal/CreateSalePayment", content);
			string outputData = await output.Content.ReadAsStringAsync();
			if (output.IsSuccessStatusCode)
			{
				var paypalPaymentResponse = new PaypalPaymentResponse();
				var response = JsonConvert.DeserializeObject
					<GenericApiResponse<PayPalDirectCreateSalePaymentResponse>>(outputData)!;
				if (response.ErrorCode > 0)
				{
					//log here the complete response
					paypalPaymentResponse.IsSuccess = false;
					if (response.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.DailyPaymentLimitExceeded;
					}
					else if (response.ErrorCode == (int)Pay360StatusCodes.limitExceed_MaximumBundle)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.BundlePurchaseLimitExceeded;
					}
					else if (response.ErrorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.PaymentProviderError;
						paypalPaymentResponse.ErrorMessage = response.Message;
					}
					else
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.PaymentServiceError;
					}
					return paypalPaymentResponse;
				};
				paypalPaymentResponse.IsSuccess = true;
				paypalPaymentResponse.RedirectUrl = response.Payload!.RedirectUrl;
				paypalPaymentResponse.TransactionId = response.Payload.TransactionID;
				return paypalPaymentResponse;
			}
			else
			{
				_logger.Error(
				   $"Class: PayPalService, " +
				   $"Method: DirectPaypalCreateSalePayment" +
				   $"Status Code: {output.StatusCode}" +
				   $"Request: {Json}" +
				   $"Response: {outputData}");
			}
			return null!;
		}
		private async Task<PaypalPaymentResponse> DirectPaypalCreateSalePaymentWithSubscription(PayPalDirectCreateSalePaymentWithSubscriptionRequest request)
		{
			var Json = JsonConvert.SerializeObject(request);
			var content = new StringContent(Json, Encoding.UTF8, "application/json");
			var output = await _httpClient.PostAsync(_paypalSettings.PayPalApiEndpoint + "Paypal/CreateSalePaymentWithSubscription", content);
			string outputData = await output.Content.ReadAsStringAsync();
			if (output.IsSuccessStatusCode)
			{
				var paypalPaymentResponse = new PaypalPaymentResponse();
				var response = JsonConvert.DeserializeObject
					<GenericApiResponse<PayPalDirectCreateSalePaymentWithSubscriptionResponse>>(outputData)!;
				if (response.ErrorCode > 0)
				{
					//log here the complete response
					paypalPaymentResponse.IsSuccess = false;
					if (response.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.DailyPaymentLimitExceeded;
					}
					else if (response.ErrorCode == (int)Pay360StatusCodes.limitExceed_MaximumBundle)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.BundlePurchaseLimitExceeded;
					}
					else if (response.ErrorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.PaymentProviderError;
						paypalPaymentResponse.ErrorMessage = response.Message;
					}
					else
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.PaymentServiceError;
					}
					return paypalPaymentResponse;
				};
				paypalPaymentResponse.IsSuccess = true;
				paypalPaymentResponse.RedirectUrl = response.Payload!.RedirectUrl;
				paypalPaymentResponse.TransactionId = response.Payload.TransactionID;
				paypalPaymentResponse.SubscriptionId = response.Payload.SubscriptionId;
				return paypalPaymentResponse;
			}
			else
			{
				_logger.Error(
				   $"Class: PayPalService, " +
				   $"Method: DirectPaypalCreateSalePaymentWithSubscription" +
				   $" Status Code: {output.StatusCode}" +
				   $" Request: {Json}" +
				   $" Response: {outputData}");
			}
			return null!;
		}
		private async Task<PaypalPaymentResponse> DirectPaypalCancelSubscription(PayPalDirectSuspendSubscriptionRequest request)
		{
			var Json = JsonConvert.SerializeObject(request);
			var content = new StringContent(Json, Encoding.UTF8, "application/json");
			var output = await _httpClient.PostAsync(_paypalSettings.PayPalApiEndpoint + "Paypal/CancelSubscription", content);
			string outputData = await output.Content.ReadAsStringAsync();
			if (output.IsSuccessStatusCode)
			{
				var paypalPaymentResponse = new PaypalPaymentResponse();
				var response = JsonConvert.DeserializeObject
					<GenericApiResponse<PayPalDirectCreateSalePaymentWithSubscriptionResponse>>(outputData)!;
				if (response.ErrorCode > 0)
				{
					//log here the complete response
					paypalPaymentResponse.IsSuccess = false;
					if (response.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.DailyPaymentLimitExceeded;
					}
					else if (response.ErrorCode == (int)Pay360StatusCodes.limitExceed_MaximumBundle)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.BundlePurchaseLimitExceeded;
					}
					else if (response.ErrorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.PaymentProviderError;
						paypalPaymentResponse.ErrorMessage = response.Message;
					}
					else
					{
						paypalPaymentResponse.ErrorCode = PaypalApiStatusCodes.PaymentServiceError;
					}
					return paypalPaymentResponse;
				};
				paypalPaymentResponse.IsSuccess = true;
				return paypalPaymentResponse;
			}
			else
			{
				_logger.Error(
				   $"Class: PayPalService, " +
				   $"Method: DirectPaypalSuspendSubscription" +
				   $"Status Code: {output.StatusCode}" +
				   $"Request: {Json}" +
				   $"Response: {outputData}");
			}
			return null!;
		}

		private PayPalDirectCreateSalePaymentRequest CreateDirectPaypalRequest(PaypalPaymentRequest request, PaypalPaymentCallbackData returnUrlQueryData)
		{

			#region Create Basket
			var baskets = new List<Basket>();
			
			if (request.CheckoutType == CheckOutTypes.Bundle)
			{
				baskets.Add(new Basket()
				{
					Discount=request.BundleDiscount,
					ChargeAmount = request.BundleAmount,
					BundleRef = request.BundleUuid!,
					ProductItemCode = ProductItemCode.THAATA.ToString(),
					ProductRef = request.Msisdn,
				});
			}
			if (request.CheckoutType == CheckOutTypes.TopUp)
			{
				baskets.Add(new Basket()
				{
					Discount=request.TopupDiscount,
					ChargeAmount = request.TopupAmount,
					BundleRef = "",
					ProductItemCode = ProductItemCode.THAATA.ToString(),
					ProductRef = request.Msisdn
				});
			}
			if (request.CheckoutType == CheckOutTypes.Transfer)
			{
				baskets.Add(new Basket()
				{
					Discount=request.TransferDiscount,
					ChargeAmount = request.TransferAmount,
					BundleRef = "",
					ProductItemCode = ProductItemCode.THADTA.ToString(),
					ProductRef = request.Msisdn
				});
			}
			#endregion
			var callBackAction = _paypalSettings.AppPaymentCallBackUrl;
			var cancelCallBackAction = _paypalSettings.AppCancelCallBackUrl;
			if (request.CheckoutType == CheckOutTypes.Transfer)
			{
				callBackAction = _paypalSettings.AppPaymentTransferCallBackUrl;
				cancelCallBackAction = _paypalSettings.AppCancelTransferCallBackUrl;
			}
			request.Email = request.Email.Trim();
			return new PayPalDirectCreateSalePaymentRequest()
			{
				CustomerEmail = request.Email,
				CustomerMsisdn = request.Msisdn,
				CustomerName = string.IsNullOrEmpty(request.CustomerName) ? request.Email : request.CustomerName,
				CustomerUniqueRef = request.Msisdn,
				Basket = baskets,
				ProductCode = ProductCode.THA.ToString(),
				RedirectUrl = new PayPalRedirectUrls()
				{
					ReturnUrl = request.IsAppRequest
					? inAppConfig.BaseUrl + callBackAction + "?orderId=" + request.OrderId + $"&{returnUrlQueryData.ToQueryString()}"
					: _callBackSettings.WebBaseUrl + _paypalSettings.WebPaymentCallBackUrl + "?orderId=" + request.OrderId + $"&{returnUrlQueryData.ToQueryString()}",
					CancelUrl = request.IsAppRequest
					? inAppConfig.BaseUrl + cancelCallBackAction + "?orderId=" + request.OrderId
					: _callBackSettings.WebBaseUrl + _paypalSettings.WebCancelCallBackUrl + "?orderId=" + request.OrderId ,
				},
				Transaction = new PayPalTransactions()
				{
					Amount = new PayPalAmounts()
					{
						Total = baskets.Sum(x => x.ChargeAmount),
						Currency = request.Currency
					},
					Description = $"{Enum.GetName(typeof(CheckOutTypes), request.CheckoutType)!} payment from THA"
				}
			};
		}
		private PayPalDirectCreateSalePaymentWithSubscriptionRequest CreateDirectPaypalRequestWithSubscription(PaypalPaymentRequest request, bool subscriptionRequestWithInitalSale)
		{
			#region Create Basket

			var baskets = new List<PaypalSubscriptionBasket>();

			
			if (request.CheckoutType == CheckOutTypes.Bundle)
			{
				baskets.Add(new PaypalSubscriptionBasket()
				{
					ChargeAmount = request.BundleAmount,
					BundleRef = request.BundleUuid!,
					ProductItemCode = ProductItemCode.THADTA.ToString(),
					ProductRef = request.Msisdn,
					Discount = request.BundleDiscount,
					NoOfCycles = request.NoOfCycles,
					//FollowedByBundleAmount = request.FollowedByBundleAmount,
					FollowedByBundleNoOfCycles = request.FollowedByBundleNoOfCycles,
					FollowedByBundleRef = request.FollowedByBundleRef
				});
			}
			if (request.CheckoutType == CheckOutTypes.TopUp)
			{
				baskets.Add(new PaypalSubscriptionBasket()
				{
					ChargeAmount = request.TopupAmount,
					BundleRef = "",
					ProductItemCode = ProductItemCode.THAATA.ToString(),
					ProductRef = request.Msisdn,
					Discount = request.TopupDiscount
				});
			}

			#endregion

			request.Email = request.Email.Trim();
			return new PayPalDirectCreateSalePaymentWithSubscriptionRequest()
			{
				CustomerEmail = request.Email,
				CustomerMsisdn = request.Msisdn,
				CustomerName = string.IsNullOrEmpty(request.CustomerName) ? request.Email : request.CustomerName,
				CustomerUniqueRef = request.Email,
				Basket = baskets,
				ProductCode = ProductCode.THA.ToString(),
				RedirectUrl = new PayPalRedirectUrls()
				{
					ReturnUrl = request.IsAppRequest
					? _callBackSettings.AppBaseUrl + _paypalSettings.AppSubscriptionCallBackUrl + "?orderId=" + request.OrderId + "&customerUniqueRef=" + request.Email + "&IsDashboardRequest=" + !subscriptionRequestWithInitalSale
					: _callBackSettings.WebBaseUrl + _paypalSettings.WebSubscriptionCallBackUrl + "?orderId=" + request.OrderId + "&customerUniqueRef=" + request.Email + "&IsDashboardRequest=" + !subscriptionRequestWithInitalSale,
					CancelUrl = request.IsAppRequest
					? _callBackSettings.AppBaseUrl + _paypalSettings.AppCancelCallBackUrl + "?orderId=" + request.OrderId + "&customerUniqueRef=" + request.Email
					: _callBackSettings.WebBaseUrl + _paypalSettings.WebCancelCallBackUrl + "?orderId=" + request.OrderId,
				},
				Transaction = new PayPalTransactions()
				{
					Amount = new PayPalAmounts()
					{
						Total = baskets.Sum(x => x.ChargeAmount),
						Currency = request.Currency
					},
					Description = $"{Enum.GetName(typeof(CheckOutTypes), request.CheckoutType)!} payment from THM"
				}
			};
		}
		private PayPalDirectSuspendSubscriptionRequest CreateDirectPaypalCancelSubscription(PaypalSuspendSubscriptionRequest request)
		{
			return new PayPalDirectSuspendSubscriptionRequest()
			{
				ProductCode = ProductCode.THA.ToString(),
				SubscriptionId = request.SubscriptionId
			};
		}

		#endregion


		#endregion
	}
}
