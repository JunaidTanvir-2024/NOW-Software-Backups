using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.Bundle;

public sealed class BundlesRequestHandler : IRequestHandler<BundlesRequest, Result<List<BundleInfo>>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<BundlesRequestHandler> _localizer;
    private readonly ICommonService _commonService;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;
    private readonly IUserService _userService;

    public BundlesRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<BundlesRequestHandler> localizer,
        ICommonService commonService,
        IMapper mapper,
        ICurrentUser currentUser,
        IUserService userService)
    {
        _uow = uow;
        _localizer = localizer;
        _commonService = commonService;
        _mapper = mapper;
        _currentUser = currentUser;
        _userService = userService;
    }

    public async Task<Result<List<BundleInfo>>> Handle(BundlesRequest request, CancellationToken cancellationToken)
    {
        var bundles = new List<BundleInfo>();
        (bool IsMobileRequest, DeviceType? DeviceType, MediumType MediumType) = _commonService.IsAppRequest();
        bool hasChangePlan = false;
        bool has12MonthFollowPlan = false;
        bool has12MonthsSub = false;
        bool hasAutoRenewAvailable = false;

        if (!string.IsNullOrEmpty(request.Msisdn))
        {
            request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        }

        if (_currentUser.IsAuthenticated() && !string.IsNullOrEmpty(request.Msisdn))
        {
            request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
            if (!await _userService.IsUserMsisdn(request.Msisdn))
            {
                return Result<List<BundleInfo>>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            }
        }
        //national and data bundles sorting by price
        var nationalBundles = _mapper.Map<List<BundleInfo>>(await _uow.BundleRepo.GetBundles(request))
         .OrderBy(x => x.TotalPrice).Where(x => x.Category != 2).ToList();

        // international bundles sorting by name
        var internationalBundles = _mapper.Map<List<BundleInfo>>(await _uow.BundleRepo.GetBundles(request))
            .Where(x => x.Category == 2).ToList();

        //concat both lists
        bundles = nationalBundles.Concat(internationalBundles).ToList();

        if (bundles.Any() && string.IsNullOrEmpty(request.Msisdn) && IsMobileRequest)
        {
            bundles.ForEach(x => x.IsAvailable = false);
        }
        if (_currentUser.IsAuthenticated() && !string.IsNullOrEmpty(request.Msisdn))
        {
            var msisdnDetails = await _uow.UserRepo.GetMsisdnDetail(request.Msisdn!);
            if (msisdnDetails == null)
            {
                return Result<List<BundleInfo>>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            }
            var productSummaryResponse = _mapper.Map<List<SubscribedBundleInfo>>(await _uow.UserRepo.GetSubscribedBundlesV3(msisdnDetails!.AccountId!));
            if (productSummaryResponse != null)
            {
                var AffiliateSub = productSummaryResponse.FirstOrDefault(x => x.Category == BundleCategory.Affiliate);
                if (AffiliateSub != null)
                {
                    var IsFollowedByPlan12MonthContract = await _uow.UserRepo.IsFollowedByPlan12MonthContract(AffiliateSub.Id.ToString());
                    if (IsFollowedByPlan12MonthContract)
                    {
                        has12MonthFollowPlan = true;
                    }
                }
                var subscribe12MonthBundlesList = productSummaryResponse!.FirstOrDefault(x => x.Category == BundleCategory.TwelveMonthsContract);
                if (subscribe12MonthBundlesList != null)
                {
                    has12MonthsSub = true;
                    hasAutoRenewAvailable = subscribe12MonthBundlesList.IsAutoRenew;
                    var changePlan = _mapper.Map<SubscribedBundleInfo>(await _uow.BundleRepo.GetChangePlanBundleByMsisdn(request.Msisdn!));
                    DateTime? newBillingDate = null;
                    foreach (var item in bundles)
                    {
                        if (item.UuId.ToString().Trim().ToLower() == subscribe12MonthBundlesList!.Id.ToString().ToLower())
                        {
                            item.ShowChangePlan = true;
                            item.ShowCancelPlan = true;
                            item.IsSubscribed = true;
                            newBillingDate = Convert.ToDateTime(subscribe12MonthBundlesList.Expiry.ToString("yyyy-MM-ddTHH:mm:ss"));
                            //newBillingDate = Convert.ToDateTime(subscribe12MonthBundlesList.SubscriptionDate.AddMonths((subscribe12MonthBundlesList.GrantedCount == 0 ? 1 : subscribe12MonthBundlesList.GrantedCount)).ToString("yyyy-MM-ddTHH:mm:ss"));
                            item.NewBillingDate = (newBillingDate != null ? Convert.ToDateTime(newBillingDate!.Value.ToString("yyyy-MM-ddTHH:mm:ss")) : null);
                        }
                        if (changePlan != null)
                        {
                            hasChangePlan = true;
                            if (item.UuId.ToString().Trim().ToLower() == changePlan.Id.ToString().ToLower())
                            {
                                item.IsChangePlan = true;
                            }
                        }
                    }
                    if (newBillingDate != null)
                    {
                        var bundle = bundles.FirstOrDefault(x => x.IsChangePlan);
                        if (bundle != null)
                        {
                            bundle.NewBillingDate = Convert.ToDateTime(newBillingDate!.Value.ToString("yyyy-MM-ddTHH:mm:ss"));
                        }
                    }
                }
                if (has12MonthFollowPlan || (has12MonthsSub && IsMobileRequest))
                {
                    bundles.Where(x => x.Category == (int) BundleCategory.TwelveMonthsContract).ToList().ForEach(x => x.IsAvailable = false);
                }
                else if (has12MonthsSub && hasAutoRenewAvailable == false && hasChangePlan == false)
                {
                    bundles.Where(x => x.Category == (int) BundleCategory.TwelveMonthsContract).ToList().ForEach(x => x.IsAvailable = false);
                }
                else if (has12MonthsSub && hasChangePlan == false)
                {
                    bundles.Where(x => x.Category == (int) BundleCategory.TwelveMonthsContract).ToList().ForEach(x => x.IsAvailable = true);
                }
                else
                {
                    bundles.Where(x => x.Category == (int) BundleCategory.TwelveMonthsContract).ToList().ForEach(x => x.IsAvailable = true);
                }
            }
        }
        return Result<List<BundleInfo>>.Success(bundles, _localizer[CustomStatusKey.Success]);
    }
}