﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.InAppModels
{
    public class PaypalTransferPostModel
    {
        [Required]
        public string Currency { get; set; }
        [Required]
        public decimal Amount { get; set; }

        [Required]
        public string nowtelTransactionReference { get; set; }
        [Required]
        public string operatorid { get; set; }
        [Required]
        public string product { get; set; }
        [Required]
        public string messageToRecipient { get; set; }
        [Required]
        public string fromMSISDN { get; set; }
    }

}
