﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class GetProductsRequestModel
    {
        [Required]
        public string DestinationMsisdn { get; set; }
        [Required]
        public string DestinationCountryCode { get; set; }
    }
}
