﻿
using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.PayPal.Topup
{
    public class PaypalTopupRequestHandler : IRequestHandler<PaypalTopupRequest, object>
    {
        #region Fields

        private readonly IPaymentService _paymentService;
        private readonly ICurrentUser _currentUser;
        private readonly IUserRepository _userRepository;
        private readonly ICallingCardRepository _callingCardRepository;

        #endregion

        #region Ctor

        public PaypalTopupRequestHandler(IPaymentService paymentService,
           ICurrentUser currentUser,
           IUserRepository userRepository,
           ICallingCardRepository callingCardRepository)
        {
            _paymentService = paymentService;
            _currentUser = currentUser;
            _userRepository = userRepository;
            _callingCardRepository = callingCardRepository;
        }

        #endregion

        #region Methods

        public async Task<object> Handle(PaypalTopupRequest request, CancellationToken cancellationToken)
        {
            var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
            if (userProduct == null)
            {
                return ErrorResult.Failure(
                        CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
            }

            if (!userProduct.Product.Equals(
                request.CardNumber, StringComparison.InvariantCultureIgnoreCase))
            {
                return ErrorResult.Failure(
                        CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
            }

            var cardNumber = await _callingCardRepository.GetCardInfo(request?.CardNumber!);
            if (cardNumber == null || string.IsNullOrEmpty(cardNumber.Pin))
            {
                return ErrorResult.Failure(
                            CustomStatusKey.InvalidCardNumnber, CustomStatusCode.BadRequest);
            }

            return await _paymentService.HandlePaypalPaymentRequest(
                productType: ProductType.Topup,
                userInfo: new UserDto()
                {
                    Id = _currentUser.GetUserId(),
                    Email = _currentUser.GetUserEmail()
                },
                amount: request!.Amount,
                cardNumber: request!.CardNumber!);
        }

        #endregion
    }
}
