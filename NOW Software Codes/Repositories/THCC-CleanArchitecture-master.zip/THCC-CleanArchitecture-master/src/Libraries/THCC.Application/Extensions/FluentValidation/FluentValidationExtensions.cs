﻿using FluentValidation.Validators;

using Myrmec;

using THCC.Application.Settings;

namespace THCC.Application.Extensions.FluentValidation;

public static class FluentValidatorExtensions
{
    public static IRuleBuilderOptions<T, IFormFile> FileSmallerThan<T>(this IRuleBuilder<T, IFormFile> ruleBuilder, long max)
    {
        return ruleBuilder.SetValidator(new FileSizeValidator<T>(max));
    }
    public static IRuleBuilderOptions<T, IFormFile> FileExtensionAllowed<T>(this IRuleBuilder<T, IFormFile> ruleBuilder, IOptions<FileUploadSettings> fileSettings)
    {
        return ruleBuilder.SetValidator(new FileExtensionValidator<T>(fileSettings));
    }

    #region File Size Validator
    public class FileSizeValidator<T> : PropertyValidator<T, IFormFile>
    {
        public long Max { get; } // 1

        public FileSizeValidator(long max) => Max = max; // 2

        public override bool IsValid(ValidationContext<T> context, IFormFile file) // 3
        {
            if (file is null)
            {
                return true;
            }

            if (file.Length <= Max)
            {
                return true;
            }

            context.MessageFormatter
                .AppendArgument("MaxFilesize", Max);
            return false;
        }
        public override string Name => "FileSizeValidator"; // 4

        protected override string GetDefaultMessageTemplate(string errorCode) // 5
            => "Maximum file size is {MaxFilesize}.";
    }

    #endregion

    #region File Extension Validator
    public class FileExtensionValidator<T> : PropertyValidator<T, IFormFile>
    {
        private readonly IOptions<FileUploadSettings> _fileSettings;

        public FileExtensionValidator(IOptions<FileUploadSettings> fileSettings)
        {
            _fileSettings = fileSettings;
        }

        public override string Name => "FileExtensionValidator";

        public override bool IsValid(ValidationContext<T> context, IFormFile file)
        {
            var supportedFiles = new List<Record>();

            foreach (var fileExtension in _fileSettings.Value.SupportedExtensions)
            {
                var result = SupportedFileTypes.FileTypeSupported().Where(x => x.FileTypeName.Contains(fileExtension.ToLower()));
                foreach (var item in result)
                {
                    //if (!supportedFiles.Any(x => x.Extentions == item.FileTypeName))
                    //{
                    supportedFiles.Add(new Record(item.FileTypeName, item.FileHeaderValue));
                    // }
                }
            }

            var sniffer = new Sniffer();
            sniffer.Populate(supportedFiles);

            if (string.IsNullOrEmpty(Path.GetExtension(file.FileName)))
            {
                context.MessageFormatter.AppendArgument("AllowedFileExtension", string.Join(", ", _fileSettings.Value.SupportedExtensions));
                return false;
            }

            using (var fs = new BinaryReader(file.OpenReadStream()))
            {
                var bytes = new byte[20];
                fs.Read(bytes, 0, 20);
                byte[] fileHead = bytes;
                var matchHeaderTypes = sniffer.Match(fileHead);

                if (matchHeaderTypes.Count == 0)
                {
                    context.MessageFormatter.AppendArgument("AllowedFileExtension", string.Join(", ", _fileSettings.Value.SupportedExtensions));
                    return false;
                }
            }

            return true;
        }


        protected override string GetDefaultMessageTemplate(string errorCode) // 5
            => "File type {AllowedFileExtension} is supported.";
    }
    #endregion
}