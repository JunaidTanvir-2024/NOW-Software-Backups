﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.BLL.Services.Voucherify.Models.MetadataModels;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Constants;
using Models.Contracts.Request;
using Models.Contracts.Request.Bundle;
using Models.Contracts.Request.CountryDestination;
using Models.Contracts.Request.Rate;
using Models.Contracts.Response;
using Models.Database;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using Serilog.Events;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class Bundle_BL : IBundle_BL
    {
        private readonly ILogger Logger;
        private readonly IBundle_DL BundleDL;
        private readonly IUserAccount_BL UserAccountBL;
        private readonly IBalance_DL BalanceDL;
        private readonly IUserAccount_DL UserAccountDL;
        private readonly IHelper_BL HelperService;
        private readonly IStringLocalizer Localizer;
        private readonly IPay360Service Pay360Service;
        private readonly ITopup_DL TopupDL;
        private readonly IAirShipService AirShipService;
        private readonly IFaceBookService FaceBookService;
        private readonly IAppsFlyerService AppsFlyerService;
        private readonly IVoucherify_BL _voucherifyBL;
        private readonly IAutoTopup_DL _autoTopup_DL;
        private readonly VoucherifyConfig _voucherifyConfig;
        private readonly Pay360Config pay360Settings;
        private readonly IConfiguration Config;
        public Bundle_BL(
            IConfiguration config,
            IBalance_DL balanceDL,
            ILogger logger,
            IBundle_DL bundleDL,
            IUserAccount_DL userAccountDL,
            IUserAccount_BL userAccountBL,
            IHelper_BL helperService,
            IStringLocalizer localizer,
            IPay360Service pay360Service,
            ITopup_DL topupDL,
            IAirShipService airShipService,
            IFaceBookService faceBookService,
            IAppsFlyerService appsFlyerService,
            IOptions<Pay360Config> pay360Settings,
            IVoucherify_BL voucherify_BL,
            IOptions<VoucherifyConfig> options,
            IAutoTopup_DL autoTopup_DL)
        {
            Logger = logger;
            BundleDL = bundleDL;
            UserAccountBL = userAccountBL;
            UserAccountDL = userAccountDL;
            HelperService = helperService;
            Localizer = localizer;
            Pay360Service = pay360Service;
            TopupDL = topupDL;
            AirShipService = airShipService;
            FaceBookService = faceBookService;
            AppsFlyerService = appsFlyerService;
            _voucherifyBL = voucherify_BL;
            this._autoTopup_DL = autoTopup_DL;
            _voucherifyConfig = options.Value;
            this.pay360Settings = pay360Settings.Value;
            BalanceDL = balanceDL;
            Config = config;
        }
        public async Task<bool> IsOfferBUndle(string callingPackageId)
        {
            return await BundleDL.IsOfferBundle(callingPackageId);
        }
        public async Task<GenericApiResponse<string>> SetBundleAutoRenewal(bool isAutoRenew, string Msisdn, string bundleId, string Email)
        {
            var accountInfo = await UserAccountBL.GetUserAccountInfoCatche(HelperService.GetSipUserName(Msisdn));
            var bundleInfo = await BundleDL.GetBundleById(bundleId, accountInfo.AccountID);
            if (bundleInfo == null || bundleInfo.TotalCostPence <= 0)
            {
                return GenericApiResponse<string>.Failure(
                   Localizer["TopupInfoMissing"],
                   ApiStatusCodes.BadRequest);
            }
            if (bundleInfo.BundleType == BundleType.Monthly && isAutoRenew == false)
            {
                return GenericApiResponse<string>.Failure("Auto renewal cannot be disabled for monthly bundles.", ApiStatusCodes.BadRequest);
            }
            //var bundleAmount = bundleInfo.TotalCostPence / 100;
            var bundleDest = bundleInfo.Description.Replace(" ", "").Replace(",", "");
            var result = await BundleDL.SetBundleAutoRenewal(isAutoRenew, Msisdn, accountInfo.AccountID, bundleId);
            if (result.isValid)
            {
                //Handle Airship Events
                await AirShipService.HandleAutoRenew(Msisdn, isAutoRenew, bundleDest, bundleInfo.BundleType);

                return GenericApiResponse<string>.Success(result.errorMessage);
            }
            else
            {
                return GenericApiResponse<string>.Failure(result.errorMessage, ApiStatusCodes.BadRequest);
            }
        }
        public async Task<GenericApiResponse<string>> SetBundleAutoRenewalV2(bool isAutoRenew, string Msisdn, string bundleId, string Email)
        {
            var accountInfo = await UserAccountBL.GetUserAccountInfoCatche(HelperService.GetSipUserName(Msisdn));
            var bundleInfo = await BundleDL.GetBundleById(bundleId, accountInfo.AccountID);
            if (bundleInfo == null || bundleInfo.TotalCostPence <= 0)
            {
                return GenericApiResponse<string>.Failure(
                   Localizer["TopupInfoMissing"],
                   ApiStatusCodes.BadRequest);
            }
            if (bundleInfo.BundleType == BundleType.Monthly && isAutoRenew == false)
            {
                return GenericApiResponse<string>.Failure("Auto renewal cannot be disabled for monthly bundles.", ApiStatusCodes.BadRequest);
            }
            //var bundleAmount = bundleInfo.TotalCostPence / 100;
            var bundleDest = bundleInfo.Description.Replace(" ", "").Replace(",", "");
            var result = await BundleDL.SetBundleAutoRenewal(isAutoRenew, Msisdn, accountInfo.AccountID, bundleId);
            if (result.isValid)
            {
                //Handle Airship Events
                await AirShipService.HandleAutoRenew(Msisdn, isAutoRenew, bundleDest, bundleInfo.BundleType);

                return GenericApiResponse<string>.Success(result.errorMessage);
            }
            else
            {
                return GenericApiResponse<string>.Failure(result.errorMessage, ApiStatusCodes.BadRequest);
            }
        }
        public async Task<GenericApiResponse<IEnumerable<DataBundleDetail>>> GetDataBundlesProducts(string sourceMSISDN, string destinationMSISDN)
        {
            GenericApiResponse<IEnumerable<DataBundleDetail>> db = new GenericApiResponse<IEnumerable<DataBundleDetail>>();
            var sipUsername = $"tha{sourceMSISDN}";
            var accountInfo = await UserAccountBL.GetUserAccountInfoCatche(sipUsername);

            List<DataBundleDetail> dbList = new List<DataBundleDetail>();
            var na_service_id = accountInfo.Na_Service_Id;

            var currency = accountInfo.Currency;
            var msisdn = destinationMSISDN;
            try
            {

                var client = new HttpClient
                {
                    BaseAddress = new Uri(Config["local_databundle_uri"])
                };
                client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
                client.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");
                var result = await client.GetAsync($"GetDataBundlesOperatorProductsMSISDN?nsid={na_service_id}&account={currency}&destinationMSISDN={msisdn}");

                if (result.IsSuccessStatusCode)
                {
                    var airtimeproducts = JsonConvert.DeserializeObject<DataBundlesProducts>(await result.Content.ReadAsStringAsync());
                    if (airtimeproducts != null && airtimeproducts.payload != null && airtimeproducts.payload.operators != null)
                    {

                        dbList = airtimeproducts.payload.operators;

                        //List<DataBundleDetail> lstDBT = new List<DataBundleDetail>();
                        //foreach (DataBundleDetail dbt in lstDBT)
                        //{
                        //    DataBundleDetail dbtIn = new DataBundleDetail();
                        //    dbtIn.id = dbt.id;
                        //    dbtIn.name = dbt.name;
                        //    dbtIn.country = dbt.country;
                        //    dbtIn.country_id = dbt.country_id;
                        //    dbtIn.nowtelTransactionReference = dbt.nowtelTransactionReference;
                        //    List<DataBundleProductList> lstDBProd = new List<DataBundleProductList>();
                        //    foreach(DataBundleProductList dbpL in dbtIn.products)
                        //    {
                        //        DataBundleProductList dbpL2 = new DataBundleProductList();
                        //    }
                        //}


                        db.Message = "success";
                        db.Status = "success";
                        db.Payload = dbList;
                    }
                    else
                    {
                        db.Message = $"No products are available for number {destinationMSISDN}";
                        db.Status = "Failure";
                    }
                }
            }
            catch (Exception)
            {
                db.Message = $"No products are available for number {destinationMSISDN}";
                db.Status = "Failure";
            }

            return db;
        }
        public async Task<IEnumerable<AccountBundleDetails>> GetAccountBundlesViaSQL(string msisdn, string currency, string accountId)
        {
            try
            {
                var bundles = await BundleDL.GetAccountDigitalkBundlesViaSQL(accountId);
                var countries = await GetCountriesAsync();
                var accountBundles = bundles
                                    .Select(bundle =>
                                    {
                                        var bundleDetails = new AccountBundleDetails

                                        {
                                            Id = bundle.Id.ToString(),
                                            Name = bundle.Name,
                                            Expiry = bundle.Expiry,
                                            CountryName = countries.FirstOrDefault(e => e.IsoTwoCharacterCode == bundle.Description)?.Name ?? string.Empty,
                                            CountryCode = bundle.Description,
                                            IsAutoRenew = bundle.IsAutoRenew,
                                            TotalMinutes = bundle.Minutes,
                                            RemainingMinutes = bundle.RemainingMinutes,
                                            ValidityDays = bundle.ChargePeriodDays,
                                            DiscountPercentage = bundle.DiscountPercentage,
                                            IsOffer = false,
                                            Price = HelperService.ToMonetaryUnit(bundle.TotalCostPence / 100, currency),
                                            BundleCategory = (int)bundle.BundleCategory,
                                            BundleCategoryName = Localizer[bundle.BundleCategory.ToString()],
                                            BundleType = (int)bundle.BundleType,
                                            BundleTypeName = Localizer[bundle.BundleType.ToString()],
                                        };

                                        bundleDetails.Allowances.Add(new BundleAllowance
                                        {
                                            Remaining = $"{bundle.RemainingMinutes} {Localizer["Minutes"]}",
                                        });

                                        return bundleDetails;
                                    });
                return accountBundles;
            }
            catch (Exception ex)
            {
                Logger.Write(LogEventLevel.Warning, "Digitalk Get Account Bundle Failed  : " + ex.ToString());
            }

            return null;
        }
        public async Task<IEnumerable<AccountBundleDetailsV2>> GetAccountBundlesViaSQLV2(string msisdn, string currency, string accountId)
        {
            try
            {
                var bundles = await BundleDL.GetAccountDigitalkBundlesViaSQL(accountId);
                var countries = await GetCountriesAsync();
                var accountBundles = bundles
                                    .Where(x=> x.BundleType!=BundleType.Welcome || x.RemainingMinutes!=0)
                                    .Select(bundle =>
                                    {
                                        var bundleDetails = new AccountBundleDetailsV2

                                        {
                                            Id = bundle.Id.ToString(),
                                            Name = bundle.Name,
                                            Terms = bundle.BundleType == BundleType.Welcome ? Localizer["WelcomeBundleTerms", $"{bundle.ChargePeriodDays} {Localizer["Days"]}", HelperService.ToMonetaryUnit(10, currency)] : string.Empty,
                                            Description = bundle.BundleType == BundleType.Welcome ? Localizer["WelcomeBundleDescription", $"{bundle.Minutes} {Localizer["Minutes"]}", HelperService.GetCountryNamebyCoutryISCode(bundle.Description)] : string.Empty,
                                            Expiry = bundle.Expiry,
                                            CountryName = countries.FirstOrDefault(e => e.IsoTwoCharacterCode == bundle.Description)?.Name ?? string.Empty,
                                            CountryCode = bundle.Description,
                                            IsAutoRenew = bundle.IsAutoRenew,
                                            TotalMinutes = bundle.Minutes,
                                            RemainingMinutes = bundle.RemainingMinutes,
                                            ValidityDays = bundle.ChargePeriodDays,
                                            DiscountPercentage = bundle.DiscountPercentage,
                                            IsOffer = false,
                                            Price = HelperService.ToMonetaryUnit(bundle.TotalCostPence / 100, currency),
                                            BundleCategory = (int)bundle.BundleCategory,
                                            BundleCategoryName = Localizer[bundle.BundleCategory.ToString()],
                                            BundleType = (int)bundle.BundleType,
                                            BundleTypeName = Localizer[bundle.BundleType.ToString()],
                                            PaymentMethod=bundle.PaymentMethod,
                                            CardMaskedPAN=bundle.CardMaskedPAN,
                                            IsLastRenewalFailed=bundle.IsLastRenewalFailed
                                        };

                                        bundleDetails.Allowances.Add(new BundleAllowance
                                        {
                                            Remaining = $"{bundle.RemainingMinutes} {Localizer["Minutes"]}",
                                        });

                                        return bundleDetails;
                                    });
                return accountBundles;
            }
            catch (Exception ex)
            {
                Logger.Write(LogEventLevel.Warning, "Digitalk Get Account Bundle Failed  : " + ex.ToString());
            }

            return null;
        }
        public async Task<AccountSubscriptionDetails> GetAccountSubscriptionsViaSQL(string msisdn, string email)
        {
            try
            {
                var sipuserName = $"THA{msisdn}";

                var userAccount = await UserAccountBL.GetUserAccountInfoCatche(sipuserName);
                var currency = !string.IsNullOrEmpty(userAccount.Currency) ? userAccount.Currency : "USD";
                var bundles = await BundleDL.GetAccountDigitalkBundlesViaSQL(userAccount.AccountID);
                var countries = await GetCountriesAsync();
                var accountBundles = bundles
                                    //Only return AutoRenewal bundles as Requested by @Nouman from mobile team
                                    .Where(e => e.IsAutoRenew)
                                    .Select(bundle =>
                                    {
                                        var bundleDetails = new AccountBundleDetails

                                        {
                                            Id = bundle.Id.ToString(),
                                            Name = bundle.Name,
                                            Expiry = bundle.Expiry,
                                            BundleCategory = (int)bundle.BundleCategory,
                                            BundleCategoryName = Localizer[bundle.BundleCategory.ToString()],
                                            CountryName = countries.FirstOrDefault(e => e.IsoTwoCharacterCode == bundle.Description)?.Name ?? string.Empty,
                                            CountryCode = bundle.Description,
                                            IsAutoRenew = bundle.IsAutoRenew,
                                            TotalMinutes = bundle.Minutes,
                                            RemainingMinutes = bundle.RemainingMinutes,
                                            ValidityDays = bundle.ChargePeriodDays,
                                            DiscountPercentage = bundle.DiscountPercentage,
                                            IsOffer = false,
                                            Price = HelperService.ToMonetaryUnit(bundle.TotalCostPence / 100, currency),
                                            BundleType = (int)bundle.BundleType,
                                            BundleTypeName = Localizer[bundle.BundleType.ToString()]
                                        };

                                        bundleDetails.Allowances.Add(new BundleAllowance
                                        {
                                            Remaining = $"{bundle.RemainingMinutes} {Localizer["Minutes"]}",
                                        });

                                        return bundleDetails;
                                    });

                //var lastTopup = await TopupDL.GetLastTopUpPayment(userAccount.AccountID);
                var autoTopup = await Pay360Service.GetAutoTopUp(msisdn, email);
                //lastTopup ??= new LastTopup();
                //lastTopup.AutoTopUp = autoTopup.Payload;
                return new AccountSubscriptionDetails()
                {
                    Bundles = accountBundles,
                    //Topup = lastTopup
                };
            }
            catch (Exception ex)
            {
                Logger.Write(LogEventLevel.Warning, "Digitalk Get Account Bundle Failed  : " + ex.ToString());
            }

            return null;
        }
        public async Task<AccountSubscriptionDetailsV2> GetAccountSubscriptionsViaSQLV2(string msisdn, string email)
        {
            try
            {
                var sipuserName = $"THA{msisdn}";

                var userAccount = await UserAccountBL.GetUserAccountInfoCatche(sipuserName);
                var currency = !string.IsNullOrEmpty(userAccount.Currency) ? userAccount.Currency : "USD";
                var bundles = await BundleDL.GetAccountDigitalkBundlesViaSQL(userAccount.AccountID);
                var countries = await GetCountriesAsync();
                var accountBundles = bundles
                                    //Only return AutoRenewal bundles as Requested by @Nouman from mobile team
                                    .Where(e => e.IsAutoRenew)
                                    .Select(bundle =>
                                    {
                                        var bundleDetails = new AccountBundleDetailsV2

                                        {
                                            Id = bundle.Id.ToString(),
                                            Name = bundle.Name,
                                            Terms = bundle.BundleType == BundleType.Welcome ? Localizer["WelcomeBundleTerms", $"{bundle.ChargePeriodDays} {Localizer["Days"]}", HelperService.ToMonetaryUnit(10, currency)] : string.Empty,
                                            Description = bundle.BundleType == BundleType.Welcome ? Localizer["WelcomeBundleDescription", $"{bundle.Minutes} {Localizer["Minutes"]}", HelperService.GetCountryNamebyCoutryISCode(bundle.Description)] : string.Empty,
                                            Expiry = bundle.Expiry,
                                            BundleCategory = (int)bundle.BundleCategory,
                                            BundleCategoryName = Localizer[bundle.BundleCategory.ToString()],
                                            CountryName = countries.FirstOrDefault(e => e.IsoTwoCharacterCode == bundle.Description)?.Name ?? string.Empty,
                                            CountryCode = bundle.Description,
                                            IsAutoRenew = bundle.IsAutoRenew,
                                            TotalMinutes = bundle.Minutes,
                                            RemainingMinutes = bundle.RemainingMinutes,
                                            ValidityDays = bundle.ChargePeriodDays,
                                            DiscountPercentage = bundle.DiscountPercentage,
                                            IsOffer = false,
                                            Price = HelperService.ToMonetaryUnit(bundle.TotalCostPence / 100, currency),
                                            BundleType = (int)bundle.BundleType,
                                            BundleTypeName = Localizer[bundle.BundleType.ToString()],
                                            PaymentMethod = bundle.PaymentMethod,
                                            CardMaskedPAN = bundle.CardMaskedPAN,
                                            IsLastRenewalFailed = bundle.IsLastRenewalFailed
                                        };

                                        bundleDetails.Allowances.Add(new BundleAllowance
                                        {
                                            Remaining = $"{bundle.RemainingMinutes} {Localizer["Minutes"]}",
                                        });

                                        return bundleDetails;
                                    });

                //var lastTopup = await TopupDL.GetLastTopUpPayment(userAccount.AccountID);
                var autoTopup = await UserAccountBL.GetAutoTopupDetails(msisdn);
                return new AccountSubscriptionDetailsV2()
                {
                    Bundles = accountBundles,
                    AutoTopup = autoTopup?.Payload
                };
            }
            catch (Exception ex)
            {
                Logger.Write(LogEventLevel.Warning, "Digitalk Get Account Bundle Failed  : " + ex.ToString());
            }

            return null;
        }
        private string GetBundleCategoryFromName(Bundle bundle)
        {
            if (string.IsNullOrEmpty(bundle.Name))
                bundle.Name = bundle.BrandedName;
            if (bundle.Name.Contains("Platinium", StringComparison.InvariantCultureIgnoreCase))
                return "Platinium";
            else if (bundle.Name.Contains("Gold", StringComparison.InvariantCultureIgnoreCase))
                return "Gold";
            else if (bundle.Name.Contains("Silver", StringComparison.InvariantCultureIgnoreCase))
                return "Silver";
            else
                return "Bronze";
        }
        public async Task<GenericApiResponse<bool>> ValidateBundle(string accountId, string bundleId)
        {
            try
            {
                var validationResponse = await BundleDL.OfferBundleValidation(accountId, bundleId);

                return new GenericApiResponse<bool>()
                {
                    ErrorCode = validationResponse.Item1,
                    Message = validationResponse.Item2,
                    Status = "Success",
                    Payload = validationResponse.Item1 == 0
                };
            }
            catch (Exception)
            {
                return GenericApiResponse<bool>.Failure("Failure", ApiStatusCodes.InternalServerError);
            }
        }
        public async Task<GenericApiResponse<CountryDestinationBundle>> Get(string msisdn, string id)
        {
            try
            {
                Logger.Write(LogEventLevel.Warning, $"Bundle Request {msisdn}{id}");

                var countryDestinationDetails = new CountryBundleDetails();

                var userAccount = await UserAccountDL.GetUserAccountInfo("THA" + msisdn);

                var guid = new Guid(id);

                var countryrates = await BundleDL.GetCountryRatesWithBudle(int.Parse(userAccount.Na_Service_Id));

                var bundleData = await BundleDL.GetBundleById(id, userAccount.AccountID);

                var bundle = new Bundle()
                {
                    Id = bundleData.ID,
                    BrandedName = bundleData.BrandedName,
                    Description = bundleData.Description,
                    //PackageType = bundleData.PackageType,
                    //PackageCategory = bundleData.PackageCategory,
                    TotalCostPence = bundleData.TotalCostPence,
                    ChargePeriodDays = bundleData.ChargePeriodDays,
                    Texts = bundleData.Texts,
                    Seconds = bundleData.Seconds,
                    Minutes = bundleData.Minutes,
                    Remarks = bundleData.Remarks,
                    IsTrial = bundleData.IsTrial,
                    TrialId = bundleData.TrialId,
                    BundleCategory = bundleData.BundleCategory,
                    BundleType = bundleData.BundleType,
                    DiscountPercentage = bundleData.DiscountPercentage,
                };

                var isOfferAndDiscount = await BundleDL.GetOfferBundlesInfo(new List<string>() { bundle.Id.ToString() });

                bundle.Landline = countryrates.Where(x => x.BundleCountryCode == bundle.Description).FirstOrDefault().Landline;
                bundle.Mobile = countryrates.Where(x => x.BundleCountryCode == bundle.Description).FirstOrDefault().Mobile;
                bundle.SMS = countryrates.Where(x => x.BundleCountryCode == bundle.Description).FirstOrDefault().SMS;
                //bundle.IsOffer = isOfferAndDiscount.FirstOrDefault(x => x.BundleGuid == bundle.Id)?.IsOffer ?? false;
                bundle.DiscountPercentage = isOfferAndDiscount.FirstOrDefault(x => x.BundleGuid == bundle.Id)?.DiscountPercentage ?? 0;
                var bundles = GetCountryDestinationBundle(bundle, userAccount.AccountID, userAccount.Currency);

                return GenericApiResponse<CountryDestinationBundle>.Success(bundles, "Success");
            }
            catch (Exception ex)
            {
                Logger.Write(LogEventLevel.Warning, "Get Bundle failed : " + ex.ToString());

                return GenericApiResponse<CountryDestinationBundle>.Failure("Failure", ApiStatusCodes.InternalServerError);
            }
        }
        public async Task<GenericApiResponse<CountryBundleDetails>> GetBundleDetails(string ISOCode, string msisdn, string currency)
        {
            var response = new GenericApiResponse<CountryBundleDetails>();

            if (currency == "GBP")
            {
                currency = "p/min";
            }
            else
            {
                currency = "c/min";
            }

            var countryDestinationDetails = new CountryBundleDetails();

            var sipusername = $"THA{msisdn}";

            var userAccount = await UserAccountDL.GetUserAccountInfo(sipusername);

            var accountCurrency = userAccount.Currency;

            int na_service_id = int.Parse(userAccount.Na_Service_Id);

            IEnumerable<Bundle> compatibleBundles = null;

            var countryrates = await BundleDL.GetCountryRatesWithBudle(na_service_id);

            compatibleBundles = await BundleDL.GetCompatibleBundlesViaSQL(na_service_id, userAccount.AccountID);

            //var isOfferAndDiscount = await BundleDL.GetOfferBundlesInfo(compatibleBundles.Select(x => x.Id.ToString()).ToList());

            var isNewUser = await UserAccountDL.IsNewUser(msisdn);

            foreach (var item in compatibleBundles)
            {
                item.Landline = countryrates.Where(x => x.BundleCountryCode == item.Description).FirstOrDefault().Landline;
                item.Mobile = countryrates.Where(x => x.BundleCountryCode == item.Description).FirstOrDefault().Mobile;
                item.SMS = countryrates.Where(x => x.BundleCountryCode == item.Description).FirstOrDefault().SMS;
                //item.IsOffer = isOfferAndDiscount.FirstOrDefault(x => x.BundleGuid == item.Id)?.IsOffer ?? false;
                //item.DiscountPercentage = isOfferAndDiscount.FirstOrDefault(x => x.BundleGuid == item.Id)?.DiscountPercentage ?? 0;
            }

            if (CanUseBundles(msisdn))
            {
                if (compatibleBundles != null && compatibleBundles.Count() > 0)
                {
                    //Get bundles for this destination only...
                    var countryCode = (!String.IsNullOrEmpty(ISOCode)) ? ISOCode : "";

                    if (!String.IsNullOrEmpty(countryCode))
                    {
                        var destinationBundles = compatibleBundles
                        .Where(x => x.Description != null)
                        .Where(x => x.Description.Contains(countryCode));

                        if (!isNewUser)
                        {
                            destinationBundles = destinationBundles.Where(e => e.BundleType != BundleType.Welcome);
                        }
                        countryDestinationDetails.Bundles = destinationBundles.Select(x => GetCountryDestinationBundle(x, userAccount.AccountID, accountCurrency));
                        countryDestinationDetails.BundleDestinationRates.SMS = ((float.TryParse(destinationBundles.Select(x => x.SMS).FirstOrDefault(), NumberStyles.Number, CultureInfo.InvariantCulture, out var sms) ? sms : 0) * 100).ToString() + currency;
                        countryDestinationDetails.BundleDestinationRates.Landline = ((float.TryParse(destinationBundles.Select(x => x.Landline).FirstOrDefault(), NumberStyles.Number, CultureInfo.InvariantCulture, out var landline) ? landline : 0) * 100).ToString() + currency;
                        countryDestinationDetails.BundleDestinationRates.Mobile = ((float.TryParse(destinationBundles.Select(x => x.Mobile).FirstOrDefault(), NumberStyles.Number, CultureInfo.InvariantCulture, out var mobile) ? mobile : 0) * 100).ToString() + currency;
                    }
                }
            }

            if (countryDestinationDetails != null)
            {
                response.Payload = countryDestinationDetails;
                response.Message = "Success";
                response.Status = "Success";
            }

            return response;

        }
        public async Task<GenericApiResponse<CountryBundleDetailsV2>> GetBundleDetailsV2(string ISOCode, string msisdn, string currencyISO, string welcomeBundleDescription, string paygBundleDescription, string globalCreditDescription)
        {
            //var topupAmounts = Config["Pay360:TopupAmount"].Split(",").Select(e => decimal.Parse(e)).ToArray();

            var topupAmounts = pay360Settings.TopupAmounts;

            var response = new GenericApiResponse<CountryBundleDetailsV2>();
            var currency = string.Empty;

            var welcomeBundlePopup = new PopupInfo()
            {
                Heading = Localizer["WelcomeBundleHeading"],
                Description = welcomeBundleDescription
            };
            var paygBundlePopup = new PopupInfo()
            {
                Heading = Localizer["PaygBundleHeading"],
                Description = paygBundleDescription
            };
            var globalCreditPopup = new PopupInfo()
            {
                Heading = Localizer["GlobalCreditHeading"],
                Description = globalCreditDescription,
            };

            if (currencyISO == "GBP")
            {
                currency = "p/min";
            }
            else
            {
                currency = "c/min";
            }

            var countryDestinationDetails = new CountryBundleDetailsV2();

            var sipusername = $"THA{msisdn}";

            var userAccount = await UserAccountDL.GetUserAccountInfo(sipusername);

            var accountCurrency = userAccount.Currency;

            int na_service_id = int.Parse(userAccount.Na_Service_Id);

            IEnumerable<Bundle> compatibleBundles = Enumerable.Empty<Bundle>();

            var countryrates = await BundleDL.GetCountryRatesWithBudle(na_service_id);
            var countryCallingRate = countryrates.FirstOrDefault(e => e.BundleCountryCode == ISOCode);
            var bundlesList = await BundleDL.GetCompatibleBundlesViaSQLV2(na_service_id, userAccount.AccountID);
            compatibleBundles = bundlesList.Select(x =>
            {
                x.RewardPoints = _voucherifyConfig.EndpointConfig.BundleReward == false ? 0 : x.RewardPoints;
                return x;
            });
            //var isOfferAndDiscount = await BundleDL.GetOfferBundlesInfo(compatibleBundles.Select(x => x.Id.ToString()).ToList());

            var isNewUser = await UserAccountDL.IsNewUser(msisdn);

            foreach (var item in compatibleBundles)
            {
                item.Landline = countryrates.Where(x => x.BundleCountryCode == item.Description).FirstOrDefault().Landline;
                item.Mobile = countryrates.Where(x => x.BundleCountryCode == item.Description).FirstOrDefault().Mobile;
                item.SMS = countryrates.Where(x => x.BundleCountryCode == item.Description).FirstOrDefault().SMS;
                //item.IsOffer = isOfferAndDiscount.FirstOrDefault(x => x.BundleGuid == item.Id)?.IsOffer ?? false;
                //item.DiscountPercentage = isOfferAndDiscount.FirstOrDefault(x => x.BundleGuid == item.Id)?.DiscountPercentage ?? 0;
            }

            if (CanUseBundles(msisdn))
            {
                if (compatibleBundles != null && compatibleBundles.Any())
                {
                    //Get bundles for this destination only...
                    var countryCode = (!String.IsNullOrEmpty(ISOCode)) ? ISOCode : "";

                    if (!String.IsNullOrEmpty(countryCode))
                    {
                        var destinationBundles = compatibleBundles
                        .Where(x => x.Description != null)
                        .Where(x => x.Description.Contains(countryCode));

                        if (!isNewUser)
                        {
                            destinationBundles = destinationBundles.Where(e => e.BundleType != BundleType.Welcome);
                        }
                        countryDestinationDetails.Bundles = destinationBundles.Where(e => e.BundleType != BundleType.Welcome)
                            .Select(x =>
                            {
                                var bundle = GetCountryDestinationBundle(x, userAccount.AccountID, accountCurrency);
                                x.RewardPoints = _voucherifyConfig.EndpointConfig.BundleReward == false ? 0 : bundle.RewardPoints;
                                return bundle;
                            });

                        countryDestinationDetails.WelcomeBundles = destinationBundles
                            .Where(e => e.BundleType == BundleType.Welcome)
                            .Select(x =>
                            {
                                var welcomeBundle = GetCountryDestinationWelcomeBundle(x, userAccount.AccountID, accountCurrency);
                                x.RewardPoints = _voucherifyConfig.EndpointConfig.BundleReward == false ? 0 : welcomeBundle.RewardPoints;
                                return welcomeBundle;
                            });

                        countryDestinationDetails.BundleDestinationRates.SMS = FormatCallingRate(destinationBundles.Select(x => x.SMS).FirstOrDefault(), currency);
                        countryDestinationDetails.BundleDestinationRates.Landline = FormatCallingRate(destinationBundles.Select(x => x.Landline).FirstOrDefault(), currency);
                        countryDestinationDetails.BundleDestinationRates.Mobile = FormatCallingRate(destinationBundles.Select(x => x.Mobile).FirstOrDefault(), currency);
                    }
                }
            }
            var mobileCallingRateFormatted = FormatCallingRate(countryCallingRate.Mobile, currency);
            var landlineCallingRateFormatted = FormatCallingRate(countryCallingRate.Landline, currency);
            countryDestinationDetails.GlobalCredit = new CountryDestinationGlobalCredit
            {
                Title = Localizer["GlobalCreditTitle"],
                Description = Localizer["GlobalCreditDescription", HelperService.GetCountryNamebyCoutryISCode(ISOCode), mobileCallingRateFormatted],
                MobileRate = mobileCallingRateFormatted,
                LandlineRate = landlineCallingRateFormatted,
                Topups = topupAmounts.Select(x => new CountryDestinationTopup
                {
                    Price = HelperService.ToMonetaryUnit(x.Amount, currencyISO),
                    RewardPoints = _voucherifyConfig.EndpointConfig.BundleReward == false ? 0 : x.RewardPoints,
                    MobileMinutes = $"{Math.Round((x.Amount / decimal.Parse(countryCallingRate.Mobile)), 0)} {Localizer["Minutes"]}",
                    LandlineMinutes = $"{Math.Round((x.Amount / decimal.Parse(countryCallingRate.Landline)), 0)} {Localizer["Minutes"]}",
                })
            };
            if (countryDestinationDetails != null)
            {
                response.Payload = countryDestinationDetails;
                response.Payload.WelcomeBundlePopup = welcomeBundlePopup;
                response.Payload.PaygBundlePopup = paygBundlePopup;
                response.Payload.GlobalCreditPopup = globalCreditPopup;
                response.Message = "Success";
                response.Status = "Success";
            }

            return response;

        }
        private string FormatCallingRate(string rate, string currency)
        {
            var callingRate = (decimal.TryParse(rate, NumberStyles.Number, CultureInfo.InvariantCulture, out var _mobile) ? _mobile : 0);
            return $"{(Math.Round(callingRate * 100, 1))}{currency}";
        }
        public async Task<GenericApiResponse<Rates>> GetRateDetails(string id, string msisdn)
        {
            var response = new GenericApiResponse<Rates>();

            var rates = new Rates();

            var sipusername = $"THA{msisdn}";

            var userAccount = await UserAccountDL.GetUserAccountInfo(sipusername);

            int na_service_id = int.Parse(userAccount.Na_Service_Id);

            var countryrates = await BundleDL.GetCountryRates(na_service_id, int.Parse(id));

            var countryRate = countryrates.FirstOrDefault(x => x.Id == Convert.ToInt32(id));

            if (countryRate == null)
            {
                response.Payload = null;
                response.Message = "No rates found";
                response.Status = "Failure";
                return response;
            }

            var accountCurrency = HelperService.GetAccountCurrency(msisdn);

            rates.rate = await GetCountryDestinationRate(countryRate, accountCurrency, na_service_id, msisdn);

            if (rates != null)
            {
                response.Payload = rates;
                response.Message = "Success";
                response.Status = "Success";
            }

            return response;

        }
        public async Task<GenericApiResponse<IEnumerable<CountryDestination>>> GetAllRates(string msisdn)
        {

            int destref = 0;

            var response = new GenericApiResponse<IEnumerable<CountryDestination>>();

            var sipUserName = $"THA{msisdn}";

            var userAccount = await UserAccountDL.GetUserAccountInfo(sipUserName);

            var currency = "USD";

            if (userAccount != null)
            {
                currency = userAccount.Currency != null ? userAccount.Currency : "USD";
            }

            int na_service_id = int.Parse(userAccount.Na_Service_Id);

            var rates = await BundleDL.GetCountryRatesWithBudle(na_service_id, msisdn);


            var countryDestinations = rates
                .Select(x =>
                new CountryDestination
                (x.Id.ToString(),
                x.Destination,
                x.FlagImageUrl,
                x.isBundleAvailable,
                false,
                x.showOffpeak,
                HelperService.ToMonetaryUnit(x.Landline, currency),
                HelperService.ToMonetaryUnit(x.Mobile, currency),
                HelperService.ToMonetaryUnit(x.SMS, currency),
                x.OffPeakLandline == null ? null : HelperService.ToMonetaryUnit(x.OffPeakLandline, currency),
                x.OffPeakMobile == null ? null : HelperService.ToMonetaryUnit(x.OffPeakMobile, currency),
                x.OffPeakSMS == null ? null : HelperService.ToMonetaryUnit(x.OffPeakSMS, currency),
                Localizer["Landline"],
                Localizer["Mobile"],
                Localizer["SMS"],
                x.ISOCode
                ));

            if (countryDestinations.Any())
            {

                response.Payload = countryDestinations;
                response.Message = "Success";
                response.Status = "Success";
            }
            else
            {
                response.Message = "Failure";
                response.Status = "Failure";
            }

            Logger.Debug($"End time stamp of destination {destref} " + DateTime.Now.ToLongTimeString());
            return response;

        }
        public async Task<GenericApiResponse<RatesView>> GetCountryWithBundles(string msisdn)
        {

            int destref = 0;
            RatesView rv = new RatesView();

            var response = new GenericApiResponse<RatesView>();

            var sipUserName = $"THA{msisdn}";

            var userAccount = await UserAccountDL.GetUserAccountInfo(sipUserName);

            var currency = "USD";

            if (userAccount != null)
            {
                currency = userAccount.Currency != null ? userAccount.Currency : "USD";
            }

            int na_service_id = int.Parse(userAccount.Na_Service_Id);

            var rates = await BundleDL.GetCountryRatesWithBudle(na_service_id, msisdn);

            var countryDestinations = Enumerable.Empty<CountryDestination>();

            countryDestinations = rates
                .Select(x =>
                new CountryDestination
                (x.Id.ToString(),
                x.Destination,
                x.FlagImageUrl,
                x.isBundleAvailable,
                x.ISOCode
                ));

            rv.countryDestinations = countryDestinations.Where(s => s.HasBundles == true);

            if (countryDestinations.Any())
            {

                response.Payload = rv;
                response.Message = "Success";
                response.Status = "Success";
            }
            else
            {
                response.Message = "Failure";
                response.Status = "Failure";
            }

            Logger.Debug($"End time stamp of destination {destref} " + DateTime.Now.ToLongTimeString());
            return response;

        }
        private async Task<List<CountryModel>> GetCountriesAsync()
        {
            var filePath = Path.Combine("wwwroot/json/CountriesName.json");
            return JsonConvert.DeserializeObject<List<CountryModel>>(await System.IO.File.ReadAllTextAsync(filePath));
        }
        private CountryDestinationBundle GetCountryDestinationBundle(Bundle bundle, string account, string currency)
        {
            var minorCurrencyUnit = string.Empty;
            if (currency == "GBP")
            {
                minorCurrencyUnit = "p/min";
            }
            else
            {
                minorCurrencyUnit = "c/min";
            }
            var countryDestinationBundle = new CountryDestinationBundle();

            countryDestinationBundle.Id = bundle.Id.ToString();
            countryDestinationBundle.Name = bundle.BrandedName;
            // countryDestinationBundle.isOffer = bundle.IsOffer;
            //countryDestinationBundle.DiscountPercentage = bundle.DiscountPercentage;
            var rate = (decimal)bundle.TotalCostPence / bundle.Minutes;
            countryDestinationBundle.bundleMobileRate = $"{Math.Round(rate, 1)}{minorCurrencyUnit}";
            if (bundle.Minutes > 0)
            {
                countryDestinationBundle.Details.Add($"{bundle.Minutes} {Localizer["Minutes"]}");
            }

            if (bundle.Texts > 0)
            {
                countryDestinationBundle.Details.Add($"{bundle.Texts} {Localizer["Texts"]}");
            }

            if (bundle.ChargePeriodDays > 0)
            {
                countryDestinationBundle.Details.Add($"{bundle.ChargePeriodDays} {Localizer["Days"]}");
            }

            var bundleCost = Convert.ToDecimal(bundle.TotalCostPence / 100, CultureInfo.InvariantCulture);
            countryDestinationBundle.Price = HelperService.ToMonetaryUnit(bundleCost, currency);

            if (bundle.IsTrial && bundle.TrialId != null)
            {
                var trialBundle = BundleDL.GetBundleById(bundle.TrialId.ToString(), account).Result;
                countryDestinationBundle.TrialBundle = new TrialBundle()
                {
                    IsAvailable = true,
                    Minutes = $"{trialBundle.Minutes} {Localizer["Minutes"]}",
                    Days = $"{trialBundle.ChargePeriodDays} {Localizer["Days"]}",
                    IsMinutesExpired = false
                };
            }
            else
            {
                countryDestinationBundle.TrialBundle = new TrialBundle()
                {
                    IsAvailable = false,
                    IsMinutesExpired = bundle.IsTrialMinutesExpired
                };
            }
            countryDestinationBundle.Category = (int)bundle.BundleCategory;
            countryDestinationBundle.CategoryName = Localizer[bundle.BundleCategory.ToString()];
            countryDestinationBundle.Type = (int)bundle.BundleType;
            countryDestinationBundle.TypeName = Localizer[bundle.BundleType.ToString()];
            countryDestinationBundle.DiscountPercentage = bundle.DiscountPercentage;
            countryDestinationBundle.RewardPoints = bundle.RewardPoints;
            return countryDestinationBundle;
        }
        private CountryDestinationWelcomeBundle GetCountryDestinationWelcomeBundle(Bundle bundle, string account, string currency)
        {
            var minorCurrencyUnit = string.Empty;
            if (currency == "GBP")
            {
                minorCurrencyUnit = "p/min";
            }
            else
            {
                minorCurrencyUnit = "c/min";
            }
            var countryDestinationBundle = new CountryDestinationWelcomeBundle();

            countryDestinationBundle.Id = bundle.Id.ToString();
            countryDestinationBundle.Name = bundle.BrandedName;
            // countryDestinationBundle.isOffer = bundle.IsOffer;
            //countryDestinationBundle.DiscountPercentage = bundle.DiscountPercentage;
            var rate = (decimal)bundle.TotalCostPence / bundle.Minutes;
            countryDestinationBundle.Description = Localizer["WelcomeBundleDescription", $"{bundle.Minutes} {Localizer["Minutes"]}", HelperService.GetCountryNamebyCoutryISCode(bundle.DestinationISOCode)];
            countryDestinationBundle.Terms = Localizer["WelcomeBundleTerms", $"{bundle.ChargePeriodDays} {Localizer["Days"]}", HelperService.ToMonetaryUnit(10, currency)];
            var bundleCost = Convert.ToDecimal(bundle.TotalCostPence / 100, CultureInfo.InvariantCulture);
            countryDestinationBundle.Price = HelperService.ToMonetaryUnit(bundleCost, currency);
            countryDestinationBundle.Category = (int)bundle.BundleCategory;
            countryDestinationBundle.CategoryName = Localizer[bundle.BundleCategory.ToString()];
            countryDestinationBundle.DiscountPercentage = bundle.DiscountPercentage;
            countryDestinationBundle.Expiry = $"{bundle.ChargePeriodDays} {Localizer["Days"]}";
            countryDestinationBundle.MobileLandlineMinutes = $"{bundle.Minutes} {Localizer["Minutes"]}";
            countryDestinationBundle.DestinationISOCode = bundle.DestinationISOCode;
            countryDestinationBundle.DestinationFlag = bundle.DestinationFlag;
            countryDestinationBundle.Type = (int)bundle.BundleType;
            countryDestinationBundle.TypeName = Localizer[bundle.BundleType.ToString()];
            countryDestinationBundle.RewardPoints = bundle.RewardPoints;
            return countryDestinationBundle;
        }
        private async Task<CountryDestinationRate> GetCountryDestinationRate(RateRev rate, string currency, int na_service, string msisdn)
        {
            var countryDestinationRate = new CountryDestinationRate();

            countryDestinationRate.Id = rate.Id.ToString();
            countryDestinationRate.Destination = rate.Destination;

            countryDestinationRate.showOffpeak = await BundleDL.GetDispayOffPeak(msisdn, na_service);

            if (countryDestinationRate.showOffpeak)
            {

                rate.OffPeakLandline = string.IsNullOrEmpty(rate.OffPeakLandline) ? rate.Landline : rate.OffPeakLandline;
                rate.OffPeakMobile = string.IsNullOrEmpty(rate.OffPeakMobile) ? rate.Mobile : rate.OffPeakMobile;
                rate.OffPeakSMS = string.IsNullOrEmpty(rate.OffPeakSMS) ? rate.SMS : rate.OffPeakSMS;

                countryDestinationRate.Rates.Add(new CountryDestinationRateDetails
                {
                    Name = Localizer["Landline"],
                    Price = HelperService.ToMonetaryUnit(rate.Landline, currency),
                    offpeakPrice = HelperService.ToMonetaryUnit(rate.OffPeakLandline, currency)
                });

                countryDestinationRate.Rates.Add(new CountryDestinationRateDetails
                {
                    Name = Localizer["Mobile"],
                    Price = HelperService.ToMonetaryUnit(rate.Mobile, currency),
                    offpeakPrice = HelperService.ToMonetaryUnit(rate.OffPeakMobile, currency)
                });

                countryDestinationRate.Rates.Add(new CountryDestinationRateDetails
                {
                    Name = Localizer["SMS"],
                    Price = HelperService.ToMonetaryUnit(rate.SMS, currency),
                    offpeakPrice = HelperService.ToMonetaryUnit(rate.OffPeakSMS, currency)
                });

            }
            else
            {

                countryDestinationRate.Rates.Add(new CountryDestinationRateDetails
                { Name = Localizer["Landline"], Price = HelperService.ToMonetaryUnit(rate.Landline, currency) });

                countryDestinationRate.Rates.Add(new CountryDestinationRateDetails
                { Name = Localizer["Mobile"], Price = HelperService.ToMonetaryUnit(rate.Mobile, currency) });

                countryDestinationRate.Rates.Add(new CountryDestinationRateDetails
                { Name = Localizer["SMS"], Price = HelperService.ToMonetaryUnit(rate.SMS, currency) });

            }

            countryDestinationRate.FlagImageUrl = rate.FlagImageUrl;

            return countryDestinationRate;
        }
        public async Task<GenericApiResponse<RatesView>> GetRatesAndTopRates(string msisdn)
        {

            int destref = 0;

            var response = new GenericApiResponse<RatesView>();
            var ratesView = new RatesView();
            var sipUserName = $"THA{msisdn}";

            var userAccount = await UserAccountDL.GetUserAccountInfo(sipUserName);

            var currency = "USD";

            if (userAccount != null)
            {
                currency = userAccount.Currency != null ? userAccount.Currency : "USD";
            }

            int na_service_id = int.Parse(userAccount.Na_Service_Id);

            var rates = await BundleDL.GetCountryRatesWithBudle(na_service_id, msisdn);

            var countryDestinations = rates
                .Select(x =>
                new CountryDestination
                (x.Id.ToString(),
                x.Destination,
                x.FlagImageUrl,
                x.isBundleAvailable,
                false,
                x.showOffpeak,
                HelperService.ToMonetaryUnit(x.Landline, currency),
                HelperService.ToMonetaryUnit(x.Mobile, currency),
                HelperService.ToMonetaryUnit(x.SMS, currency),
                x.OffPeakLandline == null ? null : HelperService.ToMonetaryUnit(x.OffPeakLandline, currency),
                x.OffPeakMobile == null ? null : HelperService.ToMonetaryUnit(x.OffPeakMobile, currency),
                x.OffPeakSMS == null ? null : HelperService.ToMonetaryUnit(x.OffPeakSMS, currency),
                Localizer["Landline"],
                Localizer["Mobile"],
                Localizer["SMS"],
                x.ISOCode
                ));

            ratesView.countryDestinations = countryDestinations;

            var result = await BundleDL.GetuserTopBundles(na_service_id, msisdn);
            if (result != null)
            {
                var lIsoCodes = result.Select(s => s.dest_iso_code);
                ratesView.topCountryDestinations = countryDestinations.Where(r => lIsoCodes.Contains(r.ISOCode));
            }


            if (ratesView.countryDestinations.Any())
            {

                response.Payload = ratesView;
                response.Message = "Success";
                response.Status = "Success";
            }
            else
            {
                response.Message = "Failure";
                response.Status = "Failure";
            }

            return response;

        }
        public async Task<GenericApiResponse<RatesView>> GetCountryWithBundlesAndTopBundles(string msisdn, List<string> countryCodes)
        {

            int destref = 0;
            RatesView rv = new RatesView();

            Logger.Information($"Start time stamp of destination {destref} " + DateTime.Now.ToLongTimeString());
            var response = new GenericApiResponse<RatesView>();

            var sipUserName = $"THA{msisdn}";

            var userAccount = await UserAccountDL.GetUserAccountInfo(sipUserName);

            var currency = "USD";
            var currencyUnit = "c/min";

            if (userAccount != null)
            {
                currency = userAccount.Currency != null ? userAccount.Currency : "USD";
                currencyUnit = userAccount.Currency != null ? "p/min" : currencyUnit;
            }

            int na_service_id = int.Parse(userAccount.Na_Service_Id);
            var isNewUser = await UserAccountDL.IsNewUser(msisdn);

            var rates = await BundleDL.GetCountryRatesWithBudle(na_service_id, msisdn);

            var countryDestinations = Enumerable.Empty<CountryDestination>();

            countryDestinations = rates
                .Select(x =>
                new CountryDestination
                (x.Id.ToString(),
                x.Destination,
                x.FlagImageUrl,
                x.isBundleAvailable,
                x.ISOCode
                ));

            rv.countryDestinations = countryDestinations.Where(s => s.HasBundles == true);

            //var result = await BundleDL.GetuserTopBundles(na_service_id, msisdn);Old method
            var result = await BundleDL.GetCompatibleBundlesViaSQLV2(na_service_id, userAccount.AccountID);
            IEnumerable<Bundle> filteredBundles = Enumerable.Empty<Bundle>();
            //Filter destination bundles
            var callingHistory = await UserAccountDL.GetCallingHistory(userAccount.AccountID);
            if (callingHistory != null && callingHistory.Count() >= 10)
            {
                //Get recommend bundles from calling history top destinations
                var topCallingDestinations = (from ch in callingHistory
                                              select HelperService.GetCountryCode(ch.Destination))
                                          .GroupBy(e => e)
                                          .Select(e => new
                                          {
                                              Destination = e.Key,
                                              Count = e.Count()
                                          })
                                          .OrderByDescending(e => e.Count)
                                          .Select(e => e.Destination);
                                          
                filteredBundles = result.Where(e => topCallingDestinations.Contains(e.DestinationISOCode));
            }
            else if (countryCodes != null && countryCodes.Any())
            {
                //Get recommended bundles of requested country codes

                filteredBundles = result.Where(e => countryCodes.Contains(e.DestinationISOCode));
            }
            if (filteredBundles == null || !filteredBundles.Any())
            {
                filteredBundles = result.Where(e => e.IsTop);
            }
            filteredBundles = filteredBundles.Take(5);
            rv.topBundleDestinations = (from item in filteredBundles
                                        select new TopDestinationBundleDetails()
                                        {
                                            bundle_days = $"{item.BundlePeriodDays} {Localizer["Days"]}",
                                            bundle_minutes = $"{item.Minutes} {Localizer["Minutes"]}",
                                            IsOffer = false,
                                            DiscountPercentage = item.DiscountPercentage,
                                            Type = (int)item.BundleType,
                                            TypeName = Localizer[item.BundleType.ToString()],
                                            Category = (int)item.BundleCategory,
                                            CategoryName = Localizer[item.BundleCategory.ToString()],
                                            bundleMobileRate = $"{Math.Round((decimal)item.TotalCostPence / item.Minutes, 1)}{currencyUnit}",
                                            //bundleMobileRate = (float.Parse(rates.FirstOrDefault(x => x.ISOCode == item.DestinationISOCode).Mobile, CultureInfo.InvariantCulture) * 100).ToString(CultureInfo.InvariantCulture) + currencyUnit,
                                            TrialBundle = new TrialBundle
                                            {
                                                IsAvailable = item.IsTrial,
                                                Id = item.TrialId,
                                                IsMinutesExpired = item.IsTrialMinutesExpired,
                                            },
                                            bundle_id = item.Id.ToString(),
                                            bundle_name = item.BrandedName,
                                            bundle_price = HelperService.ToMonetaryUnit(item.TotalCostPence / 100, currency),
                                            flagImageUrl = item.DestinationFlag,
                                            dest_iso_code = item.DestinationISOCode,
                                            dest_country_name = HelperService.GetCountryNamebyCoutryISCode(item.DestinationISOCode),
                                        });
            foreach (var b in rv.topBundleDestinations)
            {
                var trialBundle = b.TrialBundle.IsAvailable && b.TrialBundle.Id != null ? await BundleDL.GetBundleById(b.TrialBundle.Id.ToString(), userAccount.AccountID) : null;
                b.TrialBundle = new TrialBundle()
                {
                    Minutes = trialBundle != null ? $"{trialBundle.Minutes} {Localizer["Minutes"]}" : "",
                    Days = trialBundle != null ? $"{trialBundle.ChargePeriodDays} {Localizer["Days"]}" : ""
                };
            }

            if (countryDestinations.Any())
            {

                response.Payload = rv;
                response.Message = "Success";
                response.Status = "Success";
            }
            else
            {
                response.Message = "Failure";
                response.Status = "Failure";
            }

            Logger.Debug($"End time stamp of destination {destref} " + DateTime.Now.ToLongTimeString());
            return response;

        }
        public async Task<GenericApiResponse<BundlesWithTopDestinations>> GetCountryWithBundlesAndTopBundlesV2(string msisdn, List<string> countryCodes, string welcomeBundleDescription, string paygBundleDescription)
        {

            int destref = 0;
            var rv = new BundlesWithTopDestinations();
            rv.WelcomeBundlePopup = new PopupInfo()
            {
                Description = welcomeBundleDescription,
                Heading = Localizer["WelcomeBundleHeading"]
            };
            rv.PaygBundlePopup = new PopupInfo()
            {
                Description = paygBundleDescription,
                Heading = Localizer["PaygBundleHeading"]
            };


            Logger.Information($"Start time stamp of destination {destref} " + DateTime.Now.ToLongTimeString());
            var response = new GenericApiResponse<BundlesWithTopDestinations>();

            var sipUserName = $"THA{msisdn}";

            var userAccount = await UserAccountDL.GetUserAccountInfo(sipUserName);

            var currency = "USD";
            var currencyUnit = "c/min";

            if (userAccount != null)
            {
                currency = userAccount.Currency != null ? userAccount.Currency : "USD";
                currencyUnit = userAccount.Currency != null ? "p/min" : currencyUnit;
            }

            int na_service_id = int.Parse(userAccount.Na_Service_Id);
            var isNewUser = await UserAccountDL.IsNewUser(msisdn);

            var rates = await BundleDL.GetCountryRatesWithBudle(na_service_id, msisdn);


			var countryDestinations = rates
                .Select(x =>
                new CountryDestination
                (x.Id.ToString(),
                x.Destination,
                x.FlagImageUrl,
                x.isBundleAvailable,
                x.ISOCode
                ));
            rv.countryDestinations = countryDestinations;

            //var result = await BundleDL.GetuserTopBundles(na_service_id, msisdn);Old method
            var result = await BundleDL.GetCompatibleBundlesViaSQLV2(na_service_id, userAccount.AccountID);
            IEnumerable<Bundle> filteredBundles = Enumerable.Empty<Bundle>();
            //Filter destination bundles
            var callingHistory = await UserAccountDL.GetCallingHistory(userAccount.AccountID);
            if (callingHistory != null && callingHistory.Count() >= 10)
            {
                //Get recommend bundles from calling history top destinations
                var topCallingDestinations = (from ch in callingHistory
                                              select HelperService.GetCountryCode(ch.Destination))
                                          .GroupBy(e => e)
                                          .Select(e => new
                                          {
                                              Destination = e.Key,
                                              Count = e.Count()
                                          })
                                          .OrderByDescending(e => e.Count)
                                          .Select(e => e.Destination);
                filteredBundles = result.Where(e => topCallingDestinations.Contains(e.DestinationISOCode));
            }
            else if (countryCodes != null && countryCodes.Any())
            {
                //Get recommended bundles of requested country codes

                filteredBundles = result.Where(e => countryCodes.Contains(e.DestinationISOCode));
            }
            if (filteredBundles == null || !filteredBundles.Any())
            {
                //Get top bundles if not recommended bundle found
                filteredBundles = result.Where(e => e.IsTop);
            }                           
                //filteredBundles = filteredBundles.Take(5).ToList();
                /*rv.topWelcomeBundleDestinations = (from item in filteredBundles
                                               where item.BundleType == BundleType.Welcome && isNewUser == true
                                                   select GetCountryDestinationWelcomeBundle(item, userAccount.AccountID, currency)
                                        )
                                        .Take(5);*/

            rv.topWelcomeBundleDestinations = (from item in filteredBundles
                                               where item.BundleType == BundleType.Welcome && isNewUser == true
                                               let countryDestinationBundle = GetCountryDestinationWelcomeBundle(item, userAccount.AccountID, currency)
                                               select new CountryDestinationWelcomeBundle
                                               {
                                                   Category = countryDestinationBundle.Category,
                                                   Description = countryDestinationBundle.Description,
                                                   CategoryName = countryDestinationBundle.CategoryName,
                                                   DestinationFlag = countryDestinationBundle.DestinationFlag,
                                                   DestinationISOCode = countryDestinationBundle.DestinationISOCode,
                                                   DiscountPercentage = countryDestinationBundle.DiscountPercentage,
                                                   Expiry = countryDestinationBundle.Expiry,
                                                   Id = countryDestinationBundle.Id,
                                                   MobileLandlineMinutes = countryDestinationBundle.MobileLandlineMinutes,
                                                   Name = countryDestinationBundle.Name,
                                                   Price = countryDestinationBundle.Price,
                                                   RewardPoints = _voucherifyConfig.EndpointConfig.BundleReward == false ? 0 : countryDestinationBundle.RewardPoints,
                                                   Terms = countryDestinationBundle.Terms,
                                                   Type = countryDestinationBundle.Type,
                                                   TypeName = countryDestinationBundle.TypeName,
                                               })
                                               .Take(5);

            rv.topBundleDestinations = (from item in filteredBundles
                                        where item.BundleType != BundleType.Welcome
                                        select new TopDestinationBundleDetails()
                                        {
                                            bundle_days = $"{item.BundlePeriodDays} {Localizer["Days"]}",
                                            bundle_minutes = $"{item.Minutes} {Localizer["Minutes"]}",
                                            IsOffer = false,
                                            DiscountPercentage = item.DiscountPercentage,
                                            Type = (int)item.BundleType,
                                            TypeName = Localizer[item.BundleType.ToString()],
                                            Category = (int)item.BundleCategory,
                                            CategoryName = Localizer[item.BundleCategory.ToString()],
                                            bundleMobileRate = $"{Math.Round((decimal)item.TotalCostPence / item.Minutes, 1)}{currencyUnit}",
                                            //bundleMobileRate = (float.Parse(rates.FirstOrDefault(x => x.ISOCode == item.DestinationISOCode).Mobile, CultureInfo.InvariantCulture) * 100).ToString(CultureInfo.InvariantCulture) + currencyUnit,
                                            TrialBundle = new TrialBundle
                                            {
                                                IsAvailable = item.IsTrial,
                                                Id = item.TrialId,
                                                IsMinutesExpired = item.IsTrialMinutesExpired,
                                            },
                                            bundle_id = item.Id.ToString(),
                                            bundle_name = item.BrandedName,
                                            bundle_price = HelperService.ToMonetaryUnit(item.TotalCostPence / 100, currency),
                                            flagImageUrl = item.DestinationFlag,
                                            dest_iso_code = item.DestinationISOCode,
                                            dest_country_name = HelperService.GetCountryNamebyCoutryISCode(item.DestinationISOCode),
                                            RewardPoints = _voucherifyConfig.EndpointConfig.BundleReward == false ? 0 : item.RewardPoints,
                                        })
                                        .Take(5 - rv.topWelcomeBundleDestinations.Count());
            foreach (var b in rv.topBundleDestinations)
            {
                var trialBundle = b.TrialBundle.IsAvailable && b.TrialBundle.Id != null ? await BundleDL.GetBundleById(b.TrialBundle.Id.ToString(), userAccount.AccountID) : null;
                b.TrialBundle = new TrialBundle()
                {
                    Minutes = trialBundle != null ? $"{trialBundle.Minutes} {Localizer["Minutes"]}" : "",
                    Days = trialBundle != null ? $"{trialBundle.ChargePeriodDays} {Localizer["Days"]}" : ""
                };
            }

            if (countryDestinations.Any())
            {

                response.Payload = rv;
                response.Message = "Success";
                response.Status = "Success";
            }
            else
            {
                response.Message = "Failure";
                response.Status = "Failure";
            }

            Logger.Debug($"End time stamp of destination {destref} " + DateTime.Now.ToLongTimeString());
            return response;

        }
        public bool CanUseBundles(string msisdn)
        {
            if (
                msisdn.StartsWith("1") ||
                msisdn.StartsWith("+1") ||
                msisdn.StartsWith("+44") ||
                msisdn.StartsWith("44") ||
                msisdn.StartsWith("39") ||
                msisdn.StartsWith("+39") ||
                msisdn.StartsWith("+33") ||
                msisdn.StartsWith("33") ||
                msisdn.StartsWith("+30") ||
                msisdn.StartsWith("30") ||
                msisdn.StartsWith("+43") ||
                msisdn.StartsWith("43") ||
                msisdn.StartsWith("+351") ||
                msisdn.StartsWith("351") ||
                msisdn.StartsWith("+357") ||
                msisdn.StartsWith("357") ||
                msisdn.StartsWith("+31") ||
                msisdn.StartsWith("31") ||
                msisdn.StartsWith("+971") ||
                msisdn.StartsWith("971") ||
                msisdn.StartsWith("+90") ||
                msisdn.StartsWith("90") ||
                msisdn.StartsWith("355") ||
                msisdn.StartsWith("376") ||
                msisdn.StartsWith("375") ||
                msisdn.StartsWith("32") ||
                msisdn.StartsWith("387") ||
                msisdn.StartsWith("359") ||
                msisdn.StartsWith("385") ||
                msisdn.StartsWith("420") ||
                msisdn.StartsWith("45") ||
                msisdn.StartsWith("372") ||
                msisdn.StartsWith("298") ||
                msisdn.StartsWith("358") ||
                msisdn.StartsWith("49") ||
                msisdn.StartsWith("350") ||
                msisdn.StartsWith("36") ||
                msisdn.StartsWith("354") ||
                msisdn.StartsWith("353") ||
                msisdn.StartsWith("371") ||
                msisdn.StartsWith("423") ||
                msisdn.StartsWith("370") ||
                msisdn.StartsWith("352") ||
                msisdn.StartsWith("356") ||
                msisdn.StartsWith("373") ||
                msisdn.StartsWith("377") ||
                msisdn.StartsWith("47") ||
                msisdn.StartsWith("48") ||
                msisdn.StartsWith("40") ||
                msisdn.StartsWith("378") ||
                msisdn.StartsWith("421") ||
                msisdn.StartsWith("386") ||
                msisdn.StartsWith("34") ||
                msisdn.StartsWith("46") ||
                msisdn.StartsWith("41") ||
                msisdn.StartsWith("380") ||
                msisdn.StartsWith("+355") ||
                msisdn.StartsWith("+376") ||
                msisdn.StartsWith("+375") ||
                msisdn.StartsWith("+32") ||
                msisdn.StartsWith("+387") ||
                msisdn.StartsWith("+359") ||
                msisdn.StartsWith("+385") ||
                msisdn.StartsWith("+420") ||
                msisdn.StartsWith("+45") ||
                msisdn.StartsWith("+372") ||
                msisdn.StartsWith("+298") ||
                msisdn.StartsWith("+358") ||
                msisdn.StartsWith("+49") ||
                msisdn.StartsWith("+350") ||
                msisdn.StartsWith("+36") ||
                msisdn.StartsWith("+354") ||
                msisdn.StartsWith("+353") ||
                msisdn.StartsWith("+371") ||
                msisdn.StartsWith("+423") ||
                msisdn.StartsWith("+370") ||
                msisdn.StartsWith("+352") ||
                msisdn.StartsWith("+356") ||
                msisdn.StartsWith("+373") ||
                msisdn.StartsWith("+377") ||
                msisdn.StartsWith("+47") ||
                msisdn.StartsWith("+48") ||
                msisdn.StartsWith("+40") ||
                msisdn.StartsWith("+378") ||
                msisdn.StartsWith("+421") ||
                msisdn.StartsWith("+386") ||
                msisdn.StartsWith("+34") ||
                msisdn.StartsWith("+46") ||
                msisdn.StartsWith("+41") ||
                msisdn.StartsWith("+380")
                )
            {
                return true;
            }
            return false;
        }
        public async Task<GenericApiResponse<TopBundlesView>> GetuserTopBundles(string msisdn)
        {
            try
            {
                TopBundlesView topBundlesView = new TopBundlesView();
                var sipusername = $"THA{msisdn}";

                var userAccount = await UserAccountDL.GetUserAccountInfo(sipusername);

                var currency = "USD";

                if (userAccount != null)
                {
                    currency = userAccount.Currency ?? "USD";
                }

                int na_service_id = int.Parse(userAccount.Na_Service_Id);

                var result = await BundleDL.GetuserTopBundles(na_service_id, msisdn);
                if (result != null)
                {
                    if (result.Count() == 0)
                    {
                        return GenericApiResponse<TopBundlesView>.Success(topBundlesView, "Top bundles not found");
                    }

                    topBundlesView.bundles = result;
                    var lIsoCodes = result.Select(s => s.dest_iso_code);
                    var rates = await BundleDL.GetCountryRatesWithBudle(na_service_id, msisdn);
                    rates = rates.Where(r => lIsoCodes.Contains(r.ISOCode));

                    //var countryDestinations = (List<CountryDestination>)null;
                    var countryDestinations = rates
                        .Select(x =>
                        new CountryDestination
                        (x.Id.ToString(),
                        x.Destination,
                        x.FlagImageUrl,
                        x.isBundleAvailable,
                        false,
                        x.showOffpeak,
                        HelperService.ToMonetaryUnit(x.Landline, currency),
                        HelperService.ToMonetaryUnit(x.Mobile, currency),
                        HelperService.ToMonetaryUnit(x.SMS, currency),
                        x.OffPeakLandline == null ? null : HelperService.ToMonetaryUnit(x.OffPeakLandline, currency),
                        x.OffPeakMobile == null ? null : HelperService.ToMonetaryUnit(x.OffPeakMobile, currency),
                        x.OffPeakSMS == null ? null : HelperService.ToMonetaryUnit(x.OffPeakSMS, currency),
                        Localizer["Landline"],
                        Localizer["Mobile"],
                        Localizer["SMS"],
                        x.ISOCode
                        ));

                    topBundlesView.rates = countryDestinations;

                    return GenericApiResponse<TopBundlesView>.Success(topBundlesView, "Top bundles get successfully");
                }
                else
                {
                    return GenericApiResponse<TopBundlesView>.Failure("Unable to get top bundles", ApiStatusCodes.NotFound);
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Bundle_BL, Method: GetuserTopBundles, Parameters: msisdn: {msisdn} ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<TopBundlesView>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }
        }
        public async Task<GenericApiResponse<TopBundlesView>> GetUserSuggestedBundles(string msisdn, SuggestedBundleRequest request)
        {
            try
            {
                TopBundlesView topBundlesView = new TopBundlesView();
                var sipusername = $"THA{msisdn}";

                var userAccount = await UserAccountDL.GetUserAccountInfo(sipusername);

                var currency = "USD";

                if (userAccount != null)
                {
                    currency = userAccount.Currency ?? "USD";
                }

                int na_service_id = int.Parse(userAccount.Na_Service_Id);

                var result = await BundleDL.GetCompatibleBundlesViaSQL(na_service_id, userAccount.AccountID);
                //Filter destination bundles
                var callingHistory = await UserAccountDL.GetCallingHistory(userAccount.AccountID);
                if (callingHistory != null && callingHistory.Count() >= 10)
                {
                    //Get recommend bundles from calling history top destinations
                    var topCallingDestinations = (from ch in callingHistory
                                                  select HelperService.GetCountryCode(ch.Destination))
                                              .GroupBy(e => e)
                                              .Select(e => new
                                              {
                                                  Destination = e.Key,
                                                  Count = e.Count()
                                              })
                                              .OrderByDescending(e => e.Count)
                                              .Select(e => e.Destination);
                    result = result.Where(e => topCallingDestinations.Contains(e.DestinationISOCode));
                }
                else
                {
                    //Get recommended bundles of requested country codes
                    result = result.Where(e => request.CountryCodes.Contains(e.DestinationISOCode));
                }

                result = result.Take(5);

                if (result != null)
                {
                    if (!result.Any())
                    {
                        return GenericApiResponse<TopBundlesView>.Success(topBundlesView, "Top bundles not found");
                    }

                    topBundlesView.bundles = result.Select(e => new TopDestinationBundleDetails
                    {
                        bundle_id = e.Id.ToString(),
                        bundle_days = $"{e.ChargePeriodDays} Days",
                        Category = (int)e.BundleCategory,
                        Type = (int)e.BundleType,
                        dest_iso_code = e.DestinationISOCode,
                        flagImageUrl = e.DestinationFlag,
                        bundle_name = e.Name,
                        bundle_price = HelperService.ToMonetaryUnit(e.TotalCostPence / 100, currency),
                        dest_country_name = HelperService.GetCountryNamebyCoutryISCode(e.DestinationISOCode),
                        DiscountPercentage = e.DiscountPercentage,
                        bundle_minutes = $"{e.Minutes} Minutes",
                        IsOffer = false,
                        TypeName = e.BundleType.ToString(),
                        CategoryName = e.BundleCategory.ToString(),
                    });


                    var lIsoCodes = result.Select(s => s.DestinationISOCode);
                    var rates = await BundleDL.GetCountryRatesWithBudle(na_service_id, msisdn);
                    rates = rates.Where(r => lIsoCodes.Contains(r.ISOCode));

                    //var countryDestinations = (List<CountryDestination>)null;
                    var countryDestinations = rates
                        .Select(x =>
                        new CountryDestination
                        (x.Id.ToString(),
                        x.Destination,
                        x.FlagImageUrl,
                        x.isBundleAvailable,
                        false,
                        x.showOffpeak,
                        HelperService.ToMonetaryUnit(x.Landline, currency),
                        HelperService.ToMonetaryUnit(x.Mobile, currency),
                        HelperService.ToMonetaryUnit(x.SMS, currency),
                        x.OffPeakLandline == null ? null : HelperService.ToMonetaryUnit(x.OffPeakLandline, currency),
                        x.OffPeakMobile == null ? null : HelperService.ToMonetaryUnit(x.OffPeakMobile, currency),
                        x.OffPeakSMS == null ? null : HelperService.ToMonetaryUnit(x.OffPeakSMS, currency),
                        Localizer["Landline"],
                        Localizer["Mobile"],
                        Localizer["SMS"],
                        x.ISOCode
                        ));

                    topBundlesView.rates = countryDestinations;

                    return GenericApiResponse<TopBundlesView>.Success(topBundlesView, "Top bundles get successfully");
                }
                else
                {
                    return GenericApiResponse<TopBundlesView>.Failure("Unable to get top bundles", ApiStatusCodes.NotFound);
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Bundle_BL, Method: GetuserTopBundles, Parameters: msisdn: {msisdn} ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<TopBundlesView>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }
        }
        public async Task<GenericApiResponse<UserAccountBalance>> PurchaseBundle(string AppsFlyerId, DeviceType DeviceType, string advertiserID, string msisdn, string bundleId, bool isBundleAutoRenew, string email)
        {
            var response = new GenericApiResponse<UserAccountBalance>();

            try
            {
                string Currency = "";
                var userAccount = await UserAccountBL.GetUserAccountWithoutCaching(msisdn);
                Currency = userAccount.UserAccountBalance.Currency;
                var bundle_details = await BundleDL.GetBundleById(bundleId, userAccount.AccountID);
                var beforeBundles = await BundleDL.GetAccountDigitalkBundlesViaSQL(userAccount.AccountID);
                //"Exceeded the limit on bundle purchase"
                if (beforeBundles.Count() >= 10)
                {
                    response.Message = Localizer["MaxNumberOfBundlesPurchased"];
                    response.Status = "Failure";
                    return response;
                }
                if (bundle_details == null)
                {
                    response.Message = Localizer["InvalidBundle"];
                    response.Status = "Failure";
                    return response;
                }
                if (bundle_details.BundleType == BundleType.Monthly)
                {
                    //Montly bundles cannot be purchased via balance
                    response.Message = Localizer["InvalidBundle"];
                    response.Status = "Failure";
                    return response;
                }
                var bundlePrice = Convert.ToDecimal(bundle_details.TotalCostPence / 100, CultureInfo.InvariantCulture);
                var bundleDest = bundle_details.Description.Replace(" ", "").Replace(",", "");

                if (decimal.Parse(userAccount.UserAccountBalance.Balance, CultureInfo.InvariantCulture) < bundlePrice)
                {
                    //Handle AirShip Events
                    await AirShipService.HandleBundleTagsAndEvents(
                        new Models.Services.Airship.BundleInfoAirShip()
                        {
                            BundleType = bundle_details.BundleType,
                            Destination = bundle_details.Description.Replace(" ", "").Replace(",", ""),
                            IsCard = null,
                            IsSuccess = false,
                            Msisdn = msisdn,
                            Origination = HelperService.GetCountryCode(msisdn),
                            Amount = bundlePrice
                        });

                    //Handle FaceBook Events
                    await FaceBookService.HandleBundlePurchaseEvents(advertiserID, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, false, null, bundlePrice, Currency);

                    //Handle AppsFLyer Events
                    await AppsFlyerService.HandleBundlePurchaseEvents(AppsFlyerId, DeviceType, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, false, null, bundlePrice, Currency);


                    response.Message = Localizer["InsufficientBalance"];
                    response.Status = "Failure";
                    return response;
                }


                //if (apiConfig.Enable_SQL_Calls)
                //{

                StandardResponse sr = await BundleDL.AddDigitalkBundlesViaSQL(userAccount.AccountID, bundleId);

                if (sr.ErrorCode == 0)
                {
                    //var autoRenewResp = await BundleDL.SetBundleAutoRenewal(
                    //      isBundleAutoRenew, msisdn, userAccount.AccountID, bundleId);
                    //if (autoRenewResp.isValid)
                    //{
                    //    //Handle Airship Events
                    //    await AirShipService.HandleAutoRenew(msisdn, isBundleAutoRenew, bundleDest, bundle_details.BundleType);
                    //}

                    await BundleDL.SaveBundlePurchaseData(
                        true,
                        bundle_details.BrandedName,
                        bundle_details.ID.ToString(),
                        (float)bundlePrice,
                        userAccount.AccountID,
                        null);

                    //Handle AirShip Events
                    await AirShipService.HandleBundleTagsAndEvents(
                        new Models.Services.Airship.BundleInfoAirShip()
                        {
                            BundleType = bundle_details.BundleType,
                            Destination = bundle_details.Description.Replace(" ", "").Replace(",", ""),
                            IsCard = null,
                            IsSuccess = true,
                            Msisdn = msisdn,
                            Origination = HelperService.GetCountryCode(msisdn),
                            Amount = bundlePrice
                        });

                    //Handle FaceBook Events
                    await FaceBookService.HandleBundlePurchaseEvents(advertiserID, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, true, null, bundlePrice, Currency);

                    //Handle AppsFLyer Events
                    await AppsFlyerService.HandleBundlePurchaseEvents(AppsFlyerId, DeviceType, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, true, null, bundlePrice, Currency);

                    var userAccountBalance = await BalanceDL.GetUserAccountBalance(msisdn);

                    response.Payload = userAccountBalance;
                    response.Message = Localizer["BundlePurchasedSuccessfully"];
                    response.Status = "Success";
                    return response;
                }
                else
                {
                    //Handle AirShip Events
                    await AirShipService.HandleBundleTagsAndEvents(
                        new Models.Services.Airship.BundleInfoAirShip()
                        {
                            BundleType = bundle_details.BundleType,
                            Destination = bundle_details.Description.Replace(" ", "").Replace(",", ""),
                            IsCard = null,
                            IsSuccess = false,
                            Msisdn = msisdn,
                            Origination = HelperService.GetCountryCode(msisdn),
                            Amount = bundlePrice
                        });

                    //Handle FaceBook Events
                    await FaceBookService.HandleBundlePurchaseEvents(advertiserID, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, false, null, bundlePrice, Currency);

                    //Handle AppsFLyer Events
                    await AppsFlyerService.HandleBundlePurchaseEvents(AppsFlyerId, DeviceType, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, false, null, bundlePrice, Currency);


                    await BundleDL.SaveBundlePurchaseData(false, bundle_details.BrandedName, bundle_details.ID.ToString(),
                            (float)bundlePrice, userAccount.AccountID, sr.ErrorMsg);

                    var userAccountBalance = await BalanceDL.GetUserAccountBalance(msisdn);
                    response.Payload = userAccountBalance;
                    if (sr.ErrorCode == 1111)
                        response.Message = Localizer["ExceedTBundlePurchaseLimitPreviouslyPurchased"];
                    else
                        response.Message = Localizer["MaxNumberOfBundlesPurchased"];

                    response.Status = "Failure";
                    return response;
                }

                //}
                //else
                //{


                //    var body = JsonConvert.SerializeObject(new { PackageId = bundleId }, new JsonSerializerSettings
                //    {
                //        ContractResolver = new DefaultContractResolver()
                //    });



                //    try
                //    {
                //        var requestMessage = new HttpRequestMessage(HttpMethod.Post,
                //            $"subscribers/{userAccount.SubscriberId}/subscriptions/0/bundles")
                //        {
                //            Content = new StringContent(body, Encoding.UTF8, "application/json")
                //        };

                //        var result = await client.SendAsync(requestMessage);

                //        if (result.IsSuccessStatusCode)
                //        {
                //            var userAccountBalance = await balanceService.GetUserAccountBalance(msisdn);
                //            response.Payload = userAccountBalance;
                //            response.Message = "Success";
                //            response.Status = "Success";
                //            return response;
                //        }

                //    }
                //    catch (Exception ex)
                //    {
                //        bundleLogger.Write(LogEventLevel.Warning, "PurchaseBundle Failed  : " + ex.ToString());
                //    }

                //}


                //if (apiConfig.Enable_SQL_Calls)
                //{
                //    var afterBundles = await bundleDL.GetAccountDigitalkBundlesViaSQL(userAccount.AccountID);

                //    if (afterBundles.Any(i => string.Equals(i.Id.ToString(), bundleId, StringComparison.InvariantCultureIgnoreCase)))
                //    {
                //        var userAccountBalance = await balanceDL.GetUserAccountBalance(msisdn);
                //        response.Payload = userAccountBalance;
                //        response.Message = "Success";
                //        response.Status = "Success";
                //        return response;
                //    }

                //}
                //else
                //{
                //    var afterBundles = await bundleDL.GetAccountDigitalkBundles(msisdn);

                //    if (afterBundles.Any(i => string.Equals(i.CallingPackage.PackageId, bundleId, StringComparison.InvariantCultureIgnoreCase)))
                //    {
                //        var userAccountBalance = await balanceDL.GetUserAccountBalance(msisdn);
                //        response.Payload = userAccountBalance;
                //        response.Message = "Success";
                //        response.Status = "Success";
                //        return response;
                //    }

                //}

                //return null;

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Bundle_BL, Method: PurchaseBundle, Parameters: msisdn: {msisdn},bundleId: {bundleId} ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }

            return null;
        }

        public async Task<GenericApiResponse<UserAccountBalance>> PurchaseBundleV2(string AppsFlyerId, DeviceType DeviceType, string advertiserID, string msisdn, string bundleId, bool isBundleAutoRenew, string email)
        {
            var response = new GenericApiResponse<UserAccountBalance>();

            try
            {
                string Currency = "";
                var userAccount = await UserAccountBL.GetUserAccountWithoutCaching(msisdn);
                Currency = userAccount.UserAccountBalance.Currency;
                var bundle_details = await BundleDL.GetBundleById(bundleId, userAccount.AccountID);
                var bundleRewardPoints = bundle_details.RewardPoints;
                var beforeBundles = await BundleDL.GetAccountDigitalkBundlesViaSQL(userAccount.AccountID);
                //"Exceeded the limit on bundle purchase"
                if (beforeBundles.Count() >= 10)
                {
                    response.Message = Localizer["MaxNumberOfBundlesPurchased"];
                    response.Status = "Failure";
                    return response;
                }
                if (bundle_details == null)
                {
                    response.Message = Localizer["InvalidBundle"];
                    response.Status = "Failure";
                    return response;
                }
                if (bundle_details.BundleType == BundleType.Monthly)
                {
                    //Montly bundles cannot be purchased via balance
                    response.Message = Localizer["InvalidBundle"];
                    response.Status = "Failure";
                    return response;
                }
                var bundlePrice = Convert.ToDecimal(bundle_details.TotalCostPence / 100, CultureInfo.InvariantCulture);
                var bundleDest = bundle_details.Description.Replace(" ", "").Replace(",", "");
                
                if (decimal.Parse(userAccount.UserAccountBalance.Balance, CultureInfo.InvariantCulture) < bundlePrice)
                {
                    //Handle AirShip Events
                    await AirShipService.HandleBundleTagsAndEvents(
                        new Models.Services.Airship.BundleInfoAirShip()
                        {
                            BundleType = bundle_details.BundleType,
                            Destination = bundle_details.Description.Replace(" ", "").Replace(",", ""),
                            IsCard = null,
                            IsSuccess = false,
                            Msisdn = msisdn,
                            Origination = HelperService.GetCountryCode(msisdn),
                            Amount = bundlePrice
                        });

                    //Handle FaceBook Events
                    await FaceBookService.HandleBundlePurchaseEvents(advertiserID, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, false, null, bundlePrice, Currency);

                    //Handle AppsFLyer Events
                    await AppsFlyerService.HandleBundlePurchaseEvents(AppsFlyerId, DeviceType, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, false, null, bundlePrice, Currency);


                    response.Message = Localizer["InsufficientBalance"];
                    response.Status = "Failure";
                    return response;
                }


                //if (apiConfig.Enable_SQL_Calls)
                //{

                StandardResponse sr = await BundleDL.AddDigitalkBundlesViaSQL(userAccount.AccountID, bundleId);

                if (sr.ErrorCode == 0)
                {
                    //trigger voucherify event
                    if (bundle_details.BundleType == BundleType.Welcome)
                    {
                        await _voucherifyBL.PurchaseEvent(msisdn, VoucherifyEventsNames.WelcomeBundle, new VoucherifyEventsMetadata
                        {
                            ChargeAmount = bundlePrice,
                            Timestamp = DateTime.UtcNow,
                            LoyaltyPoints = bundle_details.RewardPoints
                        });
                    }
                    if (bundle_details.BundleType == BundleType.PAYG)
                    {
                        await _voucherifyBL.PurchaseEvent(msisdn, VoucherifyEventsNames.PayGBundle, new VoucherifyEventsMetadata
                        {
                            ChargeAmount = bundlePrice,
                            Timestamp = DateTime.UtcNow,
                            LoyaltyPoints = bundle_details.RewardPoints
                        });
                    }
                    //var autoRenewResp = await BundleDL.SetBundleAutoRenewal(
                    //      isBundleAutoRenew, msisdn, userAccount.AccountID, bundleId);
                    //if (autoRenewResp.isValid)
                    //{
                    //    //Handle Airship Events
                    //    await AirShipService.HandleAutoRenew(msisdn, isBundleAutoRenew, bundleDest, bundle_details.BundleType);
                    //}

                    await BundleDL.SaveBundlePurchaseData(
                        true,
                        bundle_details.BrandedName,
                        bundle_details.ID.ToString(),
                        (float)bundlePrice,
                        userAccount.AccountID,
                        null);

                    //Handle AirShip Events
                    await AirShipService.HandleBundleTagsAndEvents(
                        new Models.Services.Airship.BundleInfoAirShip()
                        {
                            BundleType = bundle_details.BundleType,
                            Destination = bundle_details.Description.Replace(" ", "").Replace(",", ""),
                            IsCard = null,
                            IsSuccess = true,
                            Msisdn = msisdn,
                            Origination = HelperService.GetCountryCode(msisdn),
                            Amount = bundlePrice
                        });

                    //Handle FaceBook Events
                    await FaceBookService.HandleBundlePurchaseEvents(advertiserID, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, true, null, bundlePrice, Currency);

                    //Handle AppsFLyer Events
                    await AppsFlyerService.HandleBundlePurchaseEvents(AppsFlyerId, DeviceType, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, true, null, bundlePrice, Currency);

                    var userAccountBalance = await BalanceDL.GetUserAccountBalance(msisdn);
                    
                    userAccountBalance.RewardPoints = bundleRewardPoints;
                    
                    response.Payload = userAccountBalance;
                    response.Message = Localizer["BundlePurchasedSuccessfully"];
                    response.Status = "Success";
                    return response;
                }
                else
                {
                    //Handle AirShip Events
                    await AirShipService.HandleBundleTagsAndEvents(
                        new Models.Services.Airship.BundleInfoAirShip()
                        {
                            BundleType = bundle_details.BundleType,
                            Destination = bundle_details.Description.Replace(" ", "").Replace(",", ""),
                            IsCard = null,
                            IsSuccess = false,
                            Msisdn = msisdn,
                            Origination = HelperService.GetCountryCode(msisdn),
                            Amount = bundlePrice
                        });

                    //Handle FaceBook Events
                    await FaceBookService.HandleBundlePurchaseEvents(advertiserID, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, false, null, bundlePrice, Currency);

                    //Handle AppsFLyer Events
                    await AppsFlyerService.HandleBundlePurchaseEvents(AppsFlyerId, DeviceType, HelperService.GetCountryCode(msisdn), bundle_details.Description.Replace(" ", "").Replace(",", ""), bundle_details.BundleType, false, null, bundlePrice, Currency);


                    await BundleDL.SaveBundlePurchaseData(false, bundle_details.BrandedName, bundle_details.ID.ToString(),
                            (float)bundlePrice, userAccount.AccountID, sr.ErrorMsg);

                    var userAccountBalance = await BalanceDL.GetUserAccountBalance(msisdn);
                    response.Payload = userAccountBalance;
                    if (sr.ErrorCode == 1111)
                        response.Message = Localizer["ExceedTBundlePurchaseLimitPreviouslyPurchased"];
                    else
                        response.Message = Localizer["MaxNumberOfBundlesPurchased"];

                    response.Status = "Failure";
                    return response;
                }

                //}
                //else
                //{


                //    var body = JsonConvert.SerializeObject(new { PackageId = bundleId }, new JsonSerializerSettings
                //    {
                //        ContractResolver = new DefaultContractResolver()
                //    });



                //    try
                //    {
                //        var requestMessage = new HttpRequestMessage(HttpMethod.Post,
                //            $"subscribers/{userAccount.SubscriberId}/subscriptions/0/bundles")
                //        {
                //            Content = new StringContent(body, Encoding.UTF8, "application/json")
                //        };

                //        var result = await client.SendAsync(requestMessage);

                //        if (result.IsSuccessStatusCode)
                //        {
                //            var userAccountBalance = await balanceService.GetUserAccountBalance(msisdn);
                //            response.Payload = userAccountBalance;
                //            response.Message = "Success";
                //            response.Status = "Success";
                //            return response;
                //        }

                //    }
                //    catch (Exception ex)
                //    {
                //        bundleLogger.Write(LogEventLevel.Warning, "PurchaseBundle Failed  : " + ex.ToString());
                //    }

                //}


                //if (apiConfig.Enable_SQL_Calls)
                //{
                //    var afterBundles = await bundleDL.GetAccountDigitalkBundlesViaSQL(userAccount.AccountID);

                //    if (afterBundles.Any(i => string.Equals(i.Id.ToString(), bundleId, StringComparison.InvariantCultureIgnoreCase)))
                //    {
                //        var userAccountBalance = await balanceDL.GetUserAccountBalance(msisdn);
                //        response.Payload = userAccountBalance;
                //        response.Message = "Success";
                //        response.Status = "Success";
                //        return response;
                //    }

                //}
                //else
                //{
                //    var afterBundles = await bundleDL.GetAccountDigitalkBundles(msisdn);

                //    if (afterBundles.Any(i => string.Equals(i.CallingPackage.PackageId, bundleId, StringComparison.InvariantCultureIgnoreCase)))
                //    {
                //        var userAccountBalance = await balanceDL.GetUserAccountBalance(msisdn);
                //        response.Payload = userAccountBalance;
                //        response.Message = "Success";
                //        response.Status = "Success";
                //        return response;
                //    }

                //}

                //return null;

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Bundle_BL, Method: PurchaseBundle, Parameters: msisdn: {msisdn},bundleId: {bundleId} ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }

            return null;
        }

        public async Task<GenericApiResponse<DestinationRate>> GetDestinationRate(string sourceMsisdn, string destinationMsisdn)
        {
            var destinationRates = await UserAccountDL.GetDestinationRate(sourceMsisdn, destinationMsisdn);
            if (destinationRates != null)
                return GenericApiResponse<DestinationRate>.Success(destinationRates, "Success");
            else
                return GenericApiResponse<DestinationRate>.Failure("Failure", ApiStatusCodes.NotFound);
        }
        private BundleDetails GetBundleDetails(Bundle bundle, string currency)
        {
            try
            {
                var details = new BundleDetails
                {

                    Id = bundle.Id.ToString(),
                    Name = bundle.BrandedName,
                    Price = ToMonetaryUnit(bundle.TotalCostPence / 100, currency),
                    Destinations = bundle.Description.Split(',').Select(GetCountryName).Where(i => i != null).ToList(),
                    CountryCode = bundle.Description,
                    PriceValue = bundle.TotalCostPence / 100,
                    ChargePeriod = bundle.ChargePeriodDays.ToString() + Localizer["Days"],
                    BundleCategory = GetBundleCategoryFromName(bundle)
                };

                if (bundle.Texts != 0)
                {
                    details.Details.Add($"{bundle.Texts.ToString()} {Localizer["Texts"]}\n");
                }

                if (bundle.Minutes != 0)
                {
                    details.Details.Add($"{bundle.Minutes.ToString()} {Localizer["Minutes"]}");
                }

                if (bundle.ChargePeriodDays != 0)
                {
                    details.Details.Add($"{bundle.ChargePeriodDays.ToString()} {Localizer["Days"]}");
                }

                if (bundle.Remarks != null && bundle.Remarks != "")
                {
                    details.Details.Add($"{bundle.Remarks}");
                }
                details.IsAutoRenew = bundle.IsAutoRenew;
                //details.IsOffer = bundle.IsOffer;
                details.DiscountPercentage = bundle.DiscountPercentage;
                return details;
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Bundle_BL, Method: GetBundleDetails failed, Parameters: name: {bundle.Name},bundleId: {bundle.Id} ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return null;
        }
        public string GetCountryName(string countryCode)
        {


            if (countryCode.ToLower() == "ug")
            {
                return "Uganda";

            }
            else if (countryCode.ToLower() == "sy")
            {
                return "Syria";

            }
            else if (countryCode.ToLower() == "pt")
            {
                return "Portugal";

            }
            else if (countryCode.ToLower() == "pk")
            {
                return "Pakistan";

            }
            else if (countryCode.ToLower() == "ng")
            {
                return "Nigeria";

            }
            else if (countryCode.ToLower() == "ke")
            {
                return "Kenya";

            }
            else if (countryCode.ToLower() == "jm")
            {
                return "Jamaica";

            }
            else if (countryCode.ToLower() == "it")
            {
                return "Italy";
            }
            else if (countryCode.ToLower() == "in")
            {
                return "India";
            }
            else if (countryCode.ToLower() == "gr")
            {
                return "Greece";
            }
            else if (countryCode.ToLower() == "gb")
            {
                return "United Kingdom";
            }
            else if (countryCode.ToLower() == "es")
            {
                return "Spain";
            }
            else if (countryCode.ToLower() == "de")
            {
                return "Germany";
            }
            else if (countryCode.ToLower() == "bd")
            {
                return "Bangladesh";
            }
            else if (countryCode.ToLower() == "at")
            {
                return "Austria";
            }
            else if (countryCode.ToLower() == "ph")
            {
                return "Philippines";
            }
            else if (countryCode.ToLower() == "sl")
            {
                return "Sierra Leone";
            }
            else if (countryCode.ToLower() == "gh")
            {
                return "Ghana";
            }
            else if (countryCode.ToLower() == "ci")
            {
                return "Ivory Coast";
            }
            else if (countryCode.ToLower() == "gn")
            {
                return "Guinea";
            }
            else if (countryCode.ToLower() == "ug")
            {
                return "Uganda";
            }
            else if (countryCode.ToLower() == "cd")
            {
                return "DRC";
            }
            else if (countryCode.ToLower() == "ht")
            {
                return "haiti";
            }
            else if (countryCode.ToLower() == "ml")
            {
                return "Mali";
            }
            else if (countryCode.ToLower() == "cm")
            {
                return "Cameroon";
            }
            else if (countryCode.ToLower() == "eg")
            {
                return "Egypt";
            }
            else if (countryCode.ToLower() == "mu")
            {
                return "Mauritius";
            }
            else if (countryCode.ToLower() == "sn")
            {
                return "Senegal";
            }
            else if (countryCode.ToLower() == "lk")
            {
                return "Sri Lanka";
            }
            else if (countryCode.ToLower() == "cy")
            {
                return "Cyprus";
            }
            else if (countryCode.ToLower() == "fr")
            {
                return "France";
            }
            else if (countryCode.ToLower() == "gm")
            {
                return "Gambia";
            }

            return null;
        }
        public string ToMonetaryUnit(decimal amount, string currency)
        {
            return DetermineMonetaryUnit(amount, currency);
        }
        private string DetermineMonetaryUnit(decimal amount, string currency)
        {
            if (amount >= 1)
            {
                var monetaryAmount = amount.ToString();
                var currencyUnit = GetMajorCurrencyUnit(currency);
                return FormattableString.Invariant($"{currencyUnit}{monetaryAmount}");
            }
            else
            {
                var monetaryAmount = Math.Round((amount * 100));
                var currencyUnit = GetMinorCurrencyUnit(currency);
                return FormattableString.Invariant($"{monetaryAmount}{currencyUnit}");
            }
        }
        private string GetMajorCurrencyUnit(string currency)
        {
            switch (currency)
            {
                case "GBP":
                    return "£";
                case "EUR":
                    return "€";
                case "USD":
                    return "$";
            }
            return string.Empty;
        }
        private string GetMinorCurrencyUnit(string currency)
        {
            switch (currency)
            {
                case "GBP":
                    return "p";
                case "EUR":
                    return "c";
                case "USD":
                    return "c";
            }
            return string.Empty;
        }
    }
}
