﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Services.Interfaces;

namespace TalkhomeAPI.Services.Services
{
    public class BundleService : IBundleService
    {
        private readonly IBundleRepository _bundleRepository;
        private readonly IAccountRepository _accountRepository;
        private readonly IPaymentService _paymentService;

        public BundleService(IBundleRepository bundleRepository, IAccountRepository accountRepository,IPaymentService paymentService)
        {
            _bundleRepository = bundleRepository;
            this._accountRepository = accountRepository;
            this._paymentService = paymentService;
        }
        public async Task<GenericApiResponse<bool>> ValidateBundlePurchase(string accountId,string msisdn,string bundleId,bool startTrial)
        {
            var result = await _bundleRepository.ValidateBundlePurchase(accountId, msisdn, bundleId,startTrial);
            if (result)
            {
                return GenericApiResponse<bool>.Success(true, "You are eligible to buy this bundle");
            }
            else
            {
                return GenericApiResponse<bool>.Failure(false, "Your are not eligible to purchase this bundle", ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }
        }
        public async Task<IEnumerable<BundlesCountries>> GetCountriesByBundle()
        {
            return await _bundleRepository.GetCountriesByBundle();
        }
        public async Task<bool> AnyActiveAutoBundleRenwal(string account)
        {
            return await _bundleRepository.AnyActiveAutoBundleRenwal(account);
        }
        public async Task<IEnumerable<Bundles>> GetBundleByCountry(string ServiceId, string account)
        {
            var compatibleBundles = await _bundleRepository.GetBundleByCountry(ServiceId, account);
            
            return compatibleBundles;
        }
        public async Task<IEnumerable<Bundles>> GetBundleByDestinationCountry(string ServiceId,string toCountryCode, string account)
        {
            var compatibleBundles = await _bundleRepository.GetBundleByCountry(ServiceId, account);
            if (!string.IsNullOrEmpty(account) && !await _accountRepository.IsNewUser(account))
            {
                compatibleBundles = compatibleBundles.Where(e => e.BundleType != BundleType.Welcome);
            }
            return compatibleBundles.Where(e=>e.Description.Equals(toCountryCode,StringComparison.InvariantCultureIgnoreCase));
        }
        public async Task<Bundles> GetBundleById(string Id)
        {
            return await _bundleRepository.GetBundleById(Id);
        }
        public async Task<GenericApiResponse<bool>> SetAutoRenew(bool isRenew, string msisdn, string bundleId, bool isTrial = false)
        {
            var account = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            var bundle = await _bundleRepository.GetBundleById(bundleId);
            //if ((bundle.BundleType == Enums.BundleType.Monthly || bundle.BundleType == BundleType.Trial || bundle.BundleType == BundleType.Welcome) && isRenew == false)
            //{
            //    return GenericApiResponse<bool>.Failure("Monthly bundles auto renew cannot be disabled, please contact customer support center.", ApiStatusCodes.InvalidBundle);
            //}
            if (isRenew)
            {
                var savedCards = await _paymentService.Pay360GetCards(msisdn);
                if (!savedCards.payload.paymentMethodResponses.Any(e=>e.isPrimary))
                {
                    return GenericApiResponse<bool>.Failure("Bundles auto renew cannot be enabled because there is no default payment method.", ApiStatusCodes.InvalidBundle);
                }
            }
            var response = await _bundleRepository.SetBundleAutoRenewal(isRenew, msisdn, account.AccountID, bundleId, isTrial,PaymentMethods.Card,null,null,null);
            if (response > 0)
                return GenericApiResponse<bool>.Success("Auto renew couldn't be updated successfully");
            else
                return GenericApiResponse<bool>.Success("Auto renew updated successfully!");
        }
    }
}
