﻿namespace SenderService.Core.Features.Domain.Response;
public class BlockedDomainResponse
{
    public string? Domain { get; set; }
    public DateTimeOffset BlockDate { get; set; }
}
