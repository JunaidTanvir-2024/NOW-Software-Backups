﻿namespace Models.Contracts.Request.Digitalk
{
	public class GPRSAllowance
	{
		public string Spend { get; set; }
		public int SpendMode { get; set; }
		public string SpendText { get; set; }
		public int Bytes { get; set; }
		public int BytesMode { get; set; }
		public string BytesText { get; set; }
	}
}