﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using TalkhomeWebApp.Models.ApiContracts.Response;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class CheckOutViewModel
    {
        public Pay360CardsData UserCards { get; set; }
        public CardViewModel UserCard { get; set; }
        public UserAccountDetails UserAccount { get; set; }
        public BundleDetails Bundle { get; set; }
        public PromotionsDetails PromotionsDetails { get; set; }

        public CheckOutTypes CheckoutType { get; set; }

        [Required(ErrorMessage = "Enter Security Code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [Range(0, int.MaxValue, ErrorMessage = "Only numbers allowed.")]
        public string SecurityCode { get; set; }

        [Range(typeof(bool), "true", "true", ErrorMessage = "You have to agree to terms & conditions.")]
        public bool AgreeTerms { get; set; }

        [Required(ErrorMessage = "Enter email address")]
        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address")]
        public string EmailAddress { get; set; }

        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        [Remote(action: "VerifyMsisdn", controller: "Account", ErrorMessage = "Please enter a valid number")]
        [MaxLength(20, ErrorMessage = "Maximum length exceeded")]
        public string Msisdn { get; set; }

        public bool IsEmailVerified { get; set; } = true;

        public int TopupAmount { get; set; }


        //Extra
        public CountriesResponseModel ListOfCountries { get; set; }

        [Required(ErrorMessage = "Enter Address"), StringLength(maximumLength: 1000, ErrorMessage = "Maximum Length Exceeded")]
        public string AddressL1 { get; set; }
        public string AddressL2 { get; set; }
        public string AddressL3 { get; set; }
        public string AddressL4 { get; set; }
        [Required(ErrorMessage = "Enter City"), StringLength(maximumLength: 1000, ErrorMessage = "Maximum Length Exceeded")]
        public string City { get; set; }

        [Required(ErrorMessage = "Enter Post Code")]
        [StringLength(maximumLength: 10, ErrorMessage = "Max length exceeded")]
        public string PostCode { get; set; }
        public string Region { get; set; }
        public bool ShouldSave { get; set; }


        [Required(ErrorMessage = "Enter Voucher Code"), MaxLength(length: 11, ErrorMessage = "Maximum 11 characters allowed"),
            MinLength(length: 11, ErrorMessage = "Minimum 11 characters allowed")]
        public string VoucherCode { get; set; }

        public float AutoToupThreshold { get; set; }
        public bool ShowAutoTopup { get; set; } = false;
    }

    public class UserAccountDetails
    {
        public decimal AccountBalance { get; set; }
        public string BalanceCurrencySymbol { get; set; }
    }

    public class BundleDetails
    {
        public string FromCountryName { get; set; }
        public string FromCountryISOCode { get; set; }
        public string ToCountryName { get; set; }
        public string ToCountryISOCode { get; set; }
        public string Minutes { get; set; }
        public string Amount { get; set; }
        public string BundleId { get; set; }
        public string Name { get; set; }
        public BundleCategory BundleCategory { get; set; }
        public BundleType BundleType { get; set; }
        public string OffPercentage { get; set; }
    }

    public class Pay360CardsData
    {
        public List<PaymentMethodData> paymentMethodResponses { get; set; }
        public CountriesResponseModel countries { get; set; }
    }

    public class CardData
    {
        public string cardFingerprint { get; set; }
        public string cardToken { get; set; }
        public string cardType { get; set; }

        [JsonProperty(PropertyName = "new")]
        public bool newCard { get; set; }
        public string cardUsageType { get; set; }
        public string cardScheme { get; set; }
        public string maskedPan { get; set; }
        public string expiryDate { get; set; }
        public string issuer { get; set; }
        public string issuerCountry { get; set; }
        public string cardHolderName { get; set; }

    }

    public class PaymentMethodData
    {
        public bool registered { get; set; }
        public bool isPrimary { get; set; }
        public CardData card { get; set; }
        public string paymentClass { get; set; }
    }
}
