﻿using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.ForgotPassword.NewPassword;

public class NewPasswordHandler : IRequestHandler<NewPasswordRequest, object>
{
    #region Fields

    private readonly ILogger _logger;
    private readonly IUserRepository _userRepo;
    private readonly IOtpService _otpService;
    private readonly IUserService _userService;
    private readonly ILegacyRepository _legacyRepo;

    #endregion

    #region Ctor

    public NewPasswordHandler(
        ILogger logger,
       ILegacyRepository legacyRepo,
        IUserRepository userRepository,
        IOtpService otpService,
        IUserService userService
      )
    {
        _logger = logger;

        _legacyRepo = legacyRepo;
        _userRepo = userRepository;
        _otpService = otpService;
        _userService = userService;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(NewPasswordRequest request, CancellationToken cancellationToken)
    {
        request.Email = request.Email.Trim();
        request.Password = request.Password.Trim();
        request.Otp = request.Otp.Trim();

        var user = await _userRepo.GetUserByEmailAsync(request.Email);
        if (user == null)
        {
            return ErrorResult.Failure(
                CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
        }

        var emailToken = await _otpService.GetTokenAgainstOtp(
                request.Email, request.Otp!, OtpType.ForgotPassword);

        if (string.IsNullOrEmpty(emailToken))
        {
            return ErrorResult.Failure(
                CustomStatusKey.InvalidOtp, CustomStatusCode.BadRequest);
        }

        if (!(await _userRepo.IsValidToken(user, emailToken, OtpType.ForgotPassword)))
        {
            return ErrorResult.Failure(
                CustomStatusKey.InvalidOtp, CustomStatusCode.BadRequest);
        }

        var response = await _userRepo.PasswordResetAsync(user!, emailToken, request.Password);
        if (response == null || response?.Succeeded == false)
        {
            foreach (var error in response!.Errors)
            {
                _logger.Error("NewPassword=> " + error.Code + "_" + error.Description);
            }
            return ErrorResult.Failure(
                CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
        }

        return Unit.Value;
    }

    #endregion
}