﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Resources;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using TalkhomeWebApp.Models.Configurations;

namespace TalkhomeWebApp.Utilities.Extension
{
    public static class CommonExtentionMethods
    {
        private static IHttpContextAccessor _httpContextAccessor;

        public static void Configure(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public static bool ClaimExists(this IPrincipal principal, string claimType)
        {
            var ci = principal as ClaimsPrincipal;
            if (ci == null)
            {
                return false;
            }

            var claim = ci.Claims.FirstOrDefault(x => x.Type == claimType);

            return claim != null;
        }

        public static void Put<T>(this ITempDataDictionary tempData, string key, T value) where T : class
        {
            //foreach (var item in tempData) { tempData.Remove(item.Key); }
            if (tempData.ContainsKey(key))
                tempData.Remove(key);

            tempData[key] = JsonConvert.SerializeObject(value);
        }
        public static void Add<T>(this ITempDataDictionary tempData, string key, T value) where T : class
        {
            tempData[key] = JsonConvert.SerializeObject(value);
        }

        public static T Get<T>(this ITempDataDictionary tempData, string key) where T : class
        {
            object o;
            tempData.TryGetValue(key, out o);
            return o!=null? JsonConvert.DeserializeObject<T>((string)o):null;
        }
        public static T GetPeek<T>(this ITempDataDictionary tempData, string key) where T : class
        {
            var o=tempData.Peek(key);
            return o != null ? JsonConvert.DeserializeObject<T>((string)o) : null;
        }

        public static string GetRemoteIPAddress(this HttpContext context, bool allowForwarded = true)
        {
            if (allowForwarded)
            {
                string header = (context.Request.Headers["CF-Connecting-IP"].FirstOrDefault() ?? context.Request.Headers["X-Forwarded-For"].FirstOrDefault());
                if (IPAddress.TryParse(header, out IPAddress ip))
                {
                    return ip.MapToIPv4().ToString();
                }
            }
            return context.Connection.RemoteIpAddress.MapToIPv4().ToString();
        }
        public static string EncryptString(string key, string plainText)
        {
            byte[] iv = new byte[16];
            byte[] array;

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = iv;

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                        {
                            streamWriter.Write(plainText);
                        }

                        array = memoryStream.ToArray();
                    }
                }
            }

            return Convert.ToBase64String(array);
        }

        public static string DecryptString(string key, string cipherText)
        {
            byte[] iv = new byte[16];
            byte[] buffer = Convert.FromBase64String(cipherText);

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = iv;
                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream(buffer))
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader streamReader = new StreamReader((Stream)cryptoStream))
                        {
                            return streamReader.ReadToEnd();
                        }
                    }
                }
            }
        }
        public static string GetCurrencySymbol(this string currency)
        {
            switch (currency)
            {
                case "USD":
                case "usd":
                    return "$";
                case "EUR":
                case "eur":
                    return "€";
                case "GBP":
                case "gbp":
                    return "£";
                default:
                    return "";
            }
        }

        public static string GetMinorCurrencyUnit(this string currency)
        {
            switch (currency)
            {
                case "GBP":
                    return "p";
                case "EUR":
                    return "c";
                case "USD":
                    return "c";
                default:
                    return "c";
            }
        }

        public static string GetCurrencyUnit(this string currency)
        {
            switch (currency)
            {
                case "GBP":
                    return "GBP";
                case "EUR":
                    return "EUR";
                case "USD":
                    return "USD";
                default:
                    return "USD";
            }
        }

        public static string GetUTMParams()
        {
            var utm_params = new UTMParamasConfig();

            utm_params.utm_source = GetCookieFromResponse("tha_utm_source");
            if (string.IsNullOrEmpty(utm_params.utm_source))
                utm_params.utm_source = GetCookieFromRequest("tha_utm_source");

            utm_params.utm_medium = GetCookieFromResponse("tha_utm_medium");
            if (string.IsNullOrEmpty(utm_params.utm_medium))
                utm_params.utm_medium = GetCookieFromRequest("tha_utm_medium");

            utm_params.utm_campaign = GetCookieFromResponse("tha_utm_campaign");
            if (string.IsNullOrEmpty(utm_params.utm_campaign))
                utm_params.utm_campaign = GetCookieFromRequest("tha_utm_campaign");

            utm_params.utm_term = GetCookieFromResponse("tha_utm_term");
            if (string.IsNullOrEmpty(utm_params.utm_term))
                utm_params.utm_term = GetCookieFromRequest("tha_utm_term");

            utm_params.utm_content = GetCookieFromResponse("tha_utm_content");
            if (string.IsNullOrEmpty(utm_params.utm_content))
                utm_params.utm_content = GetCookieFromRequest("tha_utm_content");

            string queryStringParms = GetQueryString(utm_params);

            return string.IsNullOrEmpty(queryStringParms) ? "" : "&" + queryStringParms;
        }


        public static string GetCookieFromResponse(string cookieName)
        {
            var cookieSetHeader = _httpContextAccessor.HttpContext.Response.GetTypedHeaders().SetCookie;
            var cookie = cookieSetHeader?.FirstOrDefault(x => x.Name == cookieName && !string.IsNullOrEmpty(x.Value.ToString()));
            var cookieValue = cookie?.Value.ToString();
            if (!string.IsNullOrEmpty(cookieValue))
            {
                cookieValue = Uri.UnescapeDataString(cookieValue);
                return cookieValue;
            }
            return "";
        }

        public static string GetCookieFromRequest(string cookieName)
        {
            return _httpContextAccessor.HttpContext.Request.Cookies.FirstOrDefault(x => x.Key.Equals(cookieName)).Value;
        }

        public static string GetQueryString(object obj)
        {
            var result = new List<string>();
            var props = obj.GetType().GetProperties().Where(p => p.GetValue(obj, null) != null);
            foreach (var p in props)
            {
                var value = p.GetValue(obj, null);
                var enumerable = value as ICollection;
                if (enumerable != null)
                {
                    result.AddRange(from object v in enumerable select string.Format("{0}={1}", p.Name, HttpUtility.UrlEncode(v.ToString())));
                }
                else
                {
                    result.Add(string.Format("{0}={1}", p.Name, HttpUtility.UrlEncode(value.ToString())));
                }
            }

            return string.Join("&", result.ToArray());
        }

        public static string GetMessageFromResourceFile(string key)
        {
            var resourceManager = new ResourceManager("TalkhomeWebApp.Resources.MessagesResource", Assembly.GetExecutingAssembly());

            resourceManager.IgnoreCase = true;

            return resourceManager.GetString(key);
        }

        public static ThemeMode ThemeMode(this HttpContext context)
        {
            try
            {
                return (ThemeMode)Enum.Parse(typeof(ThemeMode), context.Request.Query.FirstOrDefault(e => e.Key.Equals("ThemeMode", StringComparison.InvariantCultureIgnoreCase)).Value.ToString());
            }
            catch
            {
                return Utilities.ThemeMode.Light;
            }
        }
        public static string ComputeSha256Hash(string rawData)
        {
            // Create a SHA256   
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

                // Convert byte array to a string   
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
