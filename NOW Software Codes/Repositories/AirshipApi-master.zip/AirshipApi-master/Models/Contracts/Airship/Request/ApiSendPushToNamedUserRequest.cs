﻿using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Airship.Request
{
    public class ApiSendPushToNamedUserRequest
    {
        [JsonProperty("device_types")]
        [EnumDataType(typeof(DeviceType))]
        public List<DeviceType> DeviceTypes { get; set; }

        [JsonProperty("audience")]
        public ApiNamedUserAudience NamedUserAudience { get; set; }

        [JsonProperty("notification")]
        public ApiNamedUserNotification Notification { get; set; }
    }

    public class ApiNamedUserNotification
    {
        [JsonProperty("alert")]
        [Required]
        public string Alert { get; set; }

        [JsonProperty("actions")]
        public ApiNamedUserAction Actions { get; set; }

        public bool ShouldSerializeActions()
        {
            // don't serialize the TagGroup property if it is NULL or Empty
            if (RequestActions == null)
            {
                return false;
            }
            else
            {
                Actions = new ApiNamedUserAction() { Open = new ApiNamedUserOpen() { Type = RequestActions.Open.Type.ToString(), Content = RequestActions.Open.Content, FallbackUrl = RequestActions.Open.FallbackUrl, LandingPageContent = new ApiNamedUserLandingPageContent() { Body = RequestActions.Open.Content, ContentType = "text/html" } } };
                return true;
            }
        }


        [JsonIgnore]
        public Contracts.Request.NamedUserAction RequestActions { get; set; }
    }

    public class ApiNamedUserAudience
    {
       
        [JsonProperty("named_user")]
        public List<string> NamedUser { get; set; }
       
    }

    public class ApiNamedUserAction
    {
        [JsonProperty("open")]
        public ApiNamedUserOpen Open { get; set; }
    }

    public class ApiNamedUserOpen
    {
        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("content")]
        public string Content { get; set; }

        public bool ShouldSerializeContent()
        {

            if (Type == "deep_link" || Type == "url")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonProperty("LandingPageContent")]
        public ApiNamedUserLandingPageContent LandingPageContent { get; set; }

        public bool ShouldSerializeLandingPageContent()
        {

            if (Type == "landing_page")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonProperty("fallback_url")]
        public string FallbackUrl { get; set; }

        public bool ShouldSerializeFallbackUrl()
        {

            if (!string.IsNullOrWhiteSpace(FallbackUrl) && (Type == "deep_link" || Type == "landing_page"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public class ApiNamedUserLandingPageContent
    {
        [JsonProperty("body")]
        public string Body { get; set; }

        [JsonProperty("content_type")]
        public string ContentType { get; set; }
    }

}
