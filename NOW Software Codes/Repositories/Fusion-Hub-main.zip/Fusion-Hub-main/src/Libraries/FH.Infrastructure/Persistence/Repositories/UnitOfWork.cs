using System.Data;

using FH.Core.Definitions;
using FH.Core.Interfaces.Database;

using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

using Serilog;

namespace FH.Infrastructure.Persistence.Repositories;

internal class UnitOfWork(
    IConfiguration configuration,
    ILogger logger,
    IVendorRepository vendorRepository,
    ICountryRepository countryRepository,
    IOperatorRepository operatorRepository,
    ICurrencyRepository currencyRepository,
    IProductRepository productRepository,
    IDataDumpRepository dataDumpRepository,
    IAppLoggerRepository appLoggerRepository,
    ITransactionRepository transactionRepository,
    ICategoryRepository subCategoryRepository) : IUnitOfWork
{
    private IDbTransaction? _transaction;
    private readonly ILogger _logger = logger;
    private readonly IDbConnection _connection = new SqlConnection(configuration.GetConnectionString(AppConstants.Database.Name.FusionHub));
    private readonly Lazy<IVendorRepository> _vendorRepository = new Lazy<IVendorRepository>(() => vendorRepository);
    private readonly Lazy<ICountryRepository> _countryRepository = new Lazy<ICountryRepository>(() => countryRepository);
    private readonly Lazy<IOperatorRepository> _operatorRepository = new Lazy<IOperatorRepository>(() => operatorRepository);
    private readonly Lazy<ICurrencyRepository> _currencyRepository = new Lazy<ICurrencyRepository>(() => currencyRepository);
    private readonly Lazy<IProductRepository> _productRepository = new Lazy<IProductRepository>(() => productRepository);
    private readonly Lazy<IDataDumpRepository> _dataDumpRepository = new Lazy<IDataDumpRepository>(() => dataDumpRepository);
    private readonly Lazy<IAppLoggerRepository> _appLoggerRepository = new Lazy<IAppLoggerRepository>(() => appLoggerRepository);
    private readonly Lazy<ITransactionRepository> _transactionRepository = new Lazy<ITransactionRepository>(() => transactionRepository);
    private readonly Lazy<ICategoryRepository> _subCategoryRepository = new Lazy<ICategoryRepository>(() => subCategoryRepository);
    private bool _disposed;

    public IVendorRepository VendorRepository => _vendorRepository!.Value;
    public ICountryRepository CountryRepository => _countryRepository!.Value;
    public IOperatorRepository OperatorRepository => _operatorRepository!.Value;
    public ICurrencyRepository CurrencyRepository => _currencyRepository!.Value;
    public IProductRepository ProductRepository => _productRepository!.Value;
    public IDataDumpRepository DataDumpRepository => _dataDumpRepository!.Value;
    public IAppLoggerRepository AppLoggerRepository => _appLoggerRepository!.Value;
    public ITransactionRepository TransactionRepository => _transactionRepository!.Value;
    // public ISubCategoryRepository subCategoryRepository => _subCategoryRepository!.Value;

    public ICategoryRepository CategoryRepository => _subCategoryRepository!.Value;

    public void BeginTransaction()
    {
        if (_transaction == null)
        {
            if (_connection.State == ConnectionState.Closed)
            {
                _connection.Open();
            }

            _transaction = _connection.BeginTransaction();
        }
        else
        {
            throw new InvalidOperationException("Transaction already started.");
        }
    }

    public void Commit()
    {
        try
        {
            _transaction?.Commit();
        }
        catch (Exception ex)
        {
            _logger.Error("Transaction commit failed: {Exception}", ex);
            Rollback();
            throw; // Re-throw the exception after rollback
        }
    }

    public void Rollback()
    {
        try
        {
            _transaction?.Rollback();
        }
        catch (Exception ex)
        {
            _logger.Error("Transaction rollback failed: {Exception}", ex);
            throw; // Throw the exception to indicate the failure in rollback
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposed)
        {
            if (disposing)
            {
                _transaction?.Dispose();
                _connection.Dispose();
            }
            _disposed = true;
        }
    }
}
