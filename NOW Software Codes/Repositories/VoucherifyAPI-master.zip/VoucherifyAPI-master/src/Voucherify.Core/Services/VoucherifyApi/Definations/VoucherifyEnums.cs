namespace Voucherify.Core.Services.VoucherifyApi.Definations;

public partial class VoucherifyEnums
{
    private VoucherifyEnums() { }

    public enum VoucherType
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "DISCOUNT_VOUCHER")]
        DiscountVoucher,

        [VoucherifyAttributes.JsonEnumValue(Value = "GIFT_VOUCHER")]
        GiftVoucher,

        [VoucherifyAttributes.JsonEnumValue(Value = "LOYALTY_CARD")]
        LoyaltyCard
    }
    public enum OrderStatus
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "CREATED")]
        Created,

        [VoucherifyAttributes.JsonEnumValue(Value = "PAID")]
        Paid,

        [VoucherifyAttributes.JsonEnumValue(Value = "CANCELED")]
        Canceled,

        [VoucherifyAttributes.JsonEnumValue(Value = "FULFILLED")]
        Fulfilled
    }
    public enum DiscountType
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "AMOUNT")]
        Amount,

        [VoucherifyAttributes.JsonEnumValue(Value = "PERCENT")]
        Percent,

        [VoucherifyAttributes.JsonEnumValue(Value = "UNIT")]
        Unit,

        [VoucherifyAttributes.JsonEnumValue(Value = "FIXED")]
        Fixed
    }
    public enum DiscountCodeType
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "voucher")]
        Voucher = 1,

        [VoucherifyAttributes.JsonEnumValue(Value = "promotion_tier")]
        Promotion = 2,

        [VoucherifyAttributes.JsonEnumValue(Value = "voucher")]
        ExtraBalance = 3,
    }
    public enum DiscountEffect
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "APPLY_TO_ORDER")]
        ApplyToOrder,

        [VoucherifyAttributes.JsonEnumValue(Value = "APPLY_TO_ITEMS")]
        ApplyToItems,

        [VoucherifyAttributes.JsonEnumValue(Value = "APPLY_TO_ITEMS_PROPORTIONALLY")]
        ApplyToItemsProportionally,

        [VoucherifyAttributes.JsonEnumValue(Value = "APPLY_TO_ITEMS_PROPORTIONALLY_BY_QUANTITY")]
        ApplyToItemsProportionallyByQuantity,

        [VoucherifyAttributes.JsonEnumValue(Value = "ADD_NEW_ITEMS")]
        AddNewItems,

        [VoucherifyAttributes.JsonEnumValue(Value = "ADD_MISSING_ITEMS")]
        AddMissingItems
    }
    public enum RedemptionResult
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "SUCCESS")]
        Success,

        [VoucherifyAttributes.JsonEnumValue(Value = "FAILURE")]
        Failure
    }
    public enum CampaignExtensionType
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "STATIC")]
        Static,

        [VoucherifyAttributes.JsonEnumValue(Value = "AUTO_UPDATE")]
        AutoUpdate
    }
    public enum CampaignType
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "DISCOUNT_COUPONS")]
        DISCOUNT_COUPONS,

        [VoucherifyAttributes.JsonEnumValue(Value = "GIFT_VOUCHERS")]
        GIFT_VOUCHERS,

        [VoucherifyAttributes.JsonEnumValue(Value = "PROMOTION")]
        PROMOTION,

        [VoucherifyAttributes.JsonEnumValue(Value = "REFERRAL_PROGRAM")]
        REFERRAL_PROGRAM,

        [VoucherifyAttributes.JsonEnumValue(Value = "LOYALTY_PROGRAM")]
        LOYALTY_PROGRAM,

        [VoucherifyAttributes.JsonEnumValue(Value = "LUCKY_DRAW")]
        LUCKY_DRAW
    }
    public enum CampaignVoucherGenerationStatus
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "IN_PROGRESS")]
        InProgress,

        [VoucherifyAttributes.JsonEnumValue(Value = "DONE")]
        Done,

        [VoucherifyAttributes.JsonEnumValue(Value = "ERROR")]
        Error
    }
    public enum FailureCode
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "resource_not_found")]
        ResourceNotFound,

        [VoucherifyAttributes.JsonEnumValue(Value = "voucher_not_active")]
        VoucherNotActive,

        [VoucherifyAttributes.JsonEnumValue(Value = "voucher_expired")]
        VoucherExpired,

        [VoucherifyAttributes.JsonEnumValue(Value = "voucher_disabled")]
        VoucherDisabled,

        [VoucherifyAttributes.JsonEnumValue(Value = "quantity_exceeded")]
        QuantityExceeded,

        [VoucherifyAttributes.JsonEnumValue(Value = "gift_amount_exceeded")]
        GiftAmountExceeded,

        [VoucherifyAttributes.JsonEnumValue(Value = "customer_rules_violated")]
        CustomerRulesViolated,

        [VoucherifyAttributes.JsonEnumValue(Value = "order_rules_violated")]
        OrderRulesViolated,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_order")]
        InvalidOrder,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_payload")]
        InvalidPayload,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_amount")]
        InvalidAmount,

        [VoucherifyAttributes.JsonEnumValue(Value = "missing_amount")]
        MissingAmount,

        [VoucherifyAttributes.JsonEnumValue(Value = "missing_order_items")]
        MissingOrderItems,

        [VoucherifyAttributes.JsonEnumValue(Value = "missing_customer")]
        MissingCustomer,

        [VoucherifyAttributes.JsonEnumValue(Value = "already_rolled_back")]
        AlreadyRolledBack,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_voucher")]
        InvalidVoucher,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_gift")]
        InvalidGift,

        [VoucherifyAttributes.JsonEnumValue(Value = "duplicate_resource_key")]
        DuplicateResourceKey,

        [VoucherifyAttributes.JsonEnumValue(Value = "no_voucher_suitable_for_publication")]
        NoVoucherSuitableForPublication,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_add_balance_params")]
        InvalidAddBalanceParams,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_campaign_params")]
        InvalidCampaignParams,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_code_config")]
        InvalidCodeConfig,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_customer")]
        InvalidCustomer,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_export_params")]
        InvalidExportParams,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_product")]
        InvalidProduct,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_publish_params")]
        InvalidpublishParams,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_rollback_params")]
        InvalidRollbackParams,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_sku")]
        InvalidSku,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_validation_rules")]
        InvalidCalidationRules,

        [VoucherifyAttributes.JsonEnumValue(Value = "invalid_query_params")]
        InvalidQueryParams
    }
    public enum RewardType
    {
        [VoucherifyAttributes.JsonEnumValue(Value = "MATERIAL")]
        Material,

        [VoucherifyAttributes.JsonEnumValue(Value = "CAMPAIGN")]
        Campaign,

        [VoucherifyAttributes.JsonEnumValue(Value = "COIN")]
        Coin
    }
}
