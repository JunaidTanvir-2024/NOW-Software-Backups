﻿using System.ComponentModel.DataAnnotations;
using TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class VerifyPinRequestModel
    {
        [Required(ErrorMessage = "phone number is required")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "country code is required")]
        public string PhoneNumberCountryCode { get; set; }

        [Required(ErrorMessage = "Pin is required")]
        public string PinNumber { get; set; }

        [Required]
        [MaxLength(50)]
        public string IpAddress { get; set; }
		public SignUpRequestModel SignupRequest { get; set; }
	}
    public class LoginRequest
    {
        public AppInfo AppInfo { get; set; }
        public bool IsAndroid { get; set; }
        public bool IsIOS { get; set; }
        public string IOSAllowedVersion { get; set; }
        public string AndroidAllowedVersion { get; set; }

    }
}
