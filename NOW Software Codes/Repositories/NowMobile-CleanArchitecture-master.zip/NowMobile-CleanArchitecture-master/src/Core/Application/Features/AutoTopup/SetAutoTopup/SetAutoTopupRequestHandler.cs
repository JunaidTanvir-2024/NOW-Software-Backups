﻿namespace Application.Features.AutoTopup.SetAutoTopup;

public class SetAutoTopupRequestHandler : IRequestHandler<SetAutoTopupRequest, Result<object>>
{
    private readonly IStringLocalizer<SetAutoTopupRequestHandler> _localizer;
    private readonly IAutoTopupService _autoTopupService;
    private readonly ICurrentUser _currentUser;
    private readonly IUserService _userService;
    private readonly IUnitOfWork _unitOfWork;

    public SetAutoTopupRequestHandler(
        IStringLocalizer<SetAutoTopupRequestHandler> localizer,
        IAutoTopupService autoTopupService,
        ICurrentUser currentUser,
        IUserService userService,
        IUnitOfWork unitOfWork)
    {
        _localizer = localizer;
        _autoTopupService = autoTopupService;
        _currentUser = currentUser;
        _userService = userService;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<object>> Handle(SetAutoTopupRequest request, CancellationToken cancellationToken)
    {
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

         await _unitOfWork.TopupRepo.SetAutoTopup(
           request.Status,
           request.Msisdn,
           _currentUser.GetUserEmail()!,
           request.TopupAmount,
           Currency.GBP.ToString(),
           request.ThresholdAmount,
           PaymentMethod.Card);

        var responseMessage = _localizer[CustomStatusKey.SetAutoTopupSuccess].ToString();

        return Result<object>.Success(null!, responseMessage.Replace("{status}", request.Status ? "enabled" : "disabled"));
    }
}
