﻿using Application.Common.Interfaces.Payment;
using Application.Features.Payment.Card.Models;

namespace Application.Features.Payment.Card.ExistingCardPayment;

public class ExistingCardPaymentRequestHandler : IRequestHandler<ExistingCardPaymentRequest, Result<CardResponse>>
{
    private readonly IStringLocalizer<ExistingCardPaymentRequestHandler> _localizer;
    private readonly IPaymentService _paymentService;
    private readonly ICardService _cardService;
    private readonly ICurrentUser _currentUser;

    public ExistingCardPaymentRequestHandler(
        IStringLocalizer<ExistingCardPaymentRequestHandler> localizer,
        IPaymentService paymentService,
        ICardService cardService,
        ICurrentUser currentUser)
    {
        _localizer = localizer;
        _paymentService = paymentService;
        _cardService = cardService;
        _currentUser = currentUser;
    }

    public async Task<Result<CardResponse>> Handle(ExistingCardPaymentRequest request, CancellationToken cancellationToken)
    {
        string existigCardNumber, cardScheme;

        //Check if card is user own card
        var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
        if (cards == null || cards != null &&
            !cards.Any(x => x.CardToken.Equals(
                request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)))
        {
            return Result<CardResponse>.Failure(
                _localizer[CustomStatusKey.InvalidPaymentCard], CustomStatusCode.InvalidPaymentCard);
        }

        existigCardNumber = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).MaskedPan;

        cardScheme = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).CardScheme;


        return await _paymentService.HandleCardPaymentRequest(
                null!,
                request.PaymentCardInfo,
                null!,
                request.TopupInfo!,
                request.BundleInfo!,
                null!,
                request.Msisdn!,
                request.Email!,
                request.IpAddress!,
                existigCardNumber,
                cardScheme);
    }
}