namespace FH.Core.DTOs.Database;
public sealed record OperatorDto
{
    public sealed record Request
    {
        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public OperatorFilter? OperatorFilters { get; set; }

        public sealed record OperatorFilter
        {
            public string? OperatorName { get; set; }
            public string? CountryIsoCode { get; set; }
        }
    }

    public sealed record Response
    {
        public long OperatorId { get; set; }
        public string? OperatorName { get; set; }
        public string? Description { get; set; }
        public string? OperatorLogo { get; set; }
        public string? CountryName { get; set; }
        public string? CountryIsoCode { get; set; }
    }
}

