using Application.Features.Sim.Porting.CancelPorting;
using Application.Features.Sim.Porting.Models;
using Application.Features.Sim.Porting.PortIn;
using Application.Features.Sim.Porting.PortInNew;
using Application.Features.Sim.Porting.PortOut;
using Application.Features.Sim.Porting.Switching;

namespace Application.Common.Interfaces.Infrastructure.Services;

public interface IPortingService : ISerivcesType.IScopedService
{
    Task<GenericApiResponse<bool>?> CancelPorting(CancelPortingRequest model);
    Task<PortingRequestsResponse> GetPorting(string email, string msisdn);
    Task<GenericApiResponse<SwitchingInfoResponse>?> GetSwitchingInfo(SwitchingInfoRequest model);
    Task<GenericApiResponse<bool>?> PortIn(string email, PortInRequest model);
    Task<GenericApiResponse<bool>?> PortInNew(PortInNewRequest model);
    Task<GenericApiResponse<bool>?> PortOut(string email, PortOutRequest model);
}
