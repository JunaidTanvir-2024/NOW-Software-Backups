﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public partial class Paypal
    {
        public Paypal()
        {
            Pay360Transaction = new HashSet<Pay360Transaction>();
        }

        public int Id { get; set; }

        public ICollection<Pay360Transaction> Pay360Transaction { get; set; }
    }
}
