﻿namespace Infrastructure.Services.Models
{
    internal class HttpResponseLogEntry
    {
        public DateTime Timestamp { set; get; }
        public string RequestPath { set; get; }
        public string RequestMethod { set; get; }
        public string RequestBody { set; get; }
        public string ResponseBody { set; get; }
        public int StatusCode { set; get; }
        public long Duration { set; get; }
        public string ClientIP { set; get; }
        public string UserAgent { set; get; }
        public int ResponseSize { set; get; }
        public string ErrorMessage { set; get; }
        public string CorrelationId { set; get; }
        public string Headers { set; get; }
        public string QueryString { set; get; }
    }
}
