namespace RW.Models;

/// <summary>
/// Represents pagination information.
/// </summary>
public readonly record struct PaginationDto
{
    public required uint TotalRecords { get; init; }
    public required uint TotalPages { get; init; }
    public required uint CurrentPage { get; init; }
    public required uint PageSize { get; init; }
}
