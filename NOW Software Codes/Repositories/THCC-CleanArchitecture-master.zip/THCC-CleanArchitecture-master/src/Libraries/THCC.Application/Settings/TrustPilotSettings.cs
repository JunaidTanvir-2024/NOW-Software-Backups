﻿namespace THCC.Application.Settings
{
    public class TrustPilotSettings
    {
        public const string SectionName = nameof(TrustPilotSettings);
        public static TrustPilotSettings Bind = new TrustPilotSettings();
        public string? Rating { get; set; }
    }
}
