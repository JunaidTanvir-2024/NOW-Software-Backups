﻿using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class ApplicableTo
{
    [JsonPropertyName("data")]
    public object[]? Data { get; set; }

    [JsonPropertyName("total")]
    public long Total { get; set; }

    [JsonPropertyName("data_ref")]
    public string? DataRef { get; set; }

    [JsonPropertyName("object")]
    public string? Object { get; set; }
}
