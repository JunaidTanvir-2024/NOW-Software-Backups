﻿using Application.Common.Enums;
using Application.Common.Models.ResponseWrappers;
using Application.Features.Account.AccountSummary;
using Application.Features.Account.Balance;
using Application.Features.Account.ChangePassword;

using Application.Features.Account.Product.Add;
using Application.Features.Account.Product.AddConfirm;
using Application.Features.Account.Product.AddResend;
using Application.Features.Account.Product.Get;
using Application.Features.Account.Product.MakeDefault;
using Application.Features.Account.Product.Rename;
using Application.Features.Account.Product.Replace;
using Application.Features.Account.Product.Update;
using Application.Features.Account.Product.UpdateConfirm;
using Application.Features.Account.Product.UpdateResend;
using Application.Features.Account.ProductSummary;
using Application.Features.Account.Profile.UpdateProfileImage;
using Application.Features.Account.Profile.UpdateUserProfile;
using Application.Features.Account.Profile.UserProfile;
using Application.Features.Identity.ForgotPassword.ForgotPasswod;
using Application.Features.Identity.ForgotPassword.ForgotPasswordConfirm;
using Application.Features.Identity.ForgotPassword.ForgotPasswordResend;
using Application.Features.Identity.ForgotPassword.NewPassword;
using Application.Features.Identity.Signup.Signup;
using Application.Features.Identity.Signup.SignupConfirm;
using Application.Features.Identity.Signup.SignupResend;
using Application.Features.Identity.SocialLogin;
using Application.Features.Identity.Tokens;
using Application.Features.Sim.FreeSim.Confirm;

namespace NowMobile.Api.Controllers.Identity;

public class UserController : VersionedApiController
{
    #region Forgot Password

    [HttpPost("forgotpassword"), AllowAnonymous, OpenApiOperation("Forgot Password by using email.", "")]
    public async Task<IActionResult> ForgotPasswordAsync([FromBody] ForgotPasswordRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("forgotpassword/confirm"), AllowAnonymous, OpenApiOperation("Forgot Password by using email.", "")]
    public async Task<IActionResult> ForgotPasswordConfirmation([FromBody] ForgotPasswordConfirmRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("forgotpassword/confirm/resend"), AllowAnonymous, OpenApiOperation("Forgot Password Resend OTP by using email.", "")]
    public async Task<IActionResult> ForgotPasswordResendAsync([FromBody] ForgotPasswordResendRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("forgotpassword/newpassword"), AllowAnonymous, OpenApiOperation("new password.", "")]
    public async Task<IActionResult> NewPasswordAsync([FromBody] NewPasswordRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    #endregion

    #region SignUp

    [HttpPost("signup"), AllowAnonymous, OpenApiOperation("Register user.", "")]
    public async Task<IActionResult> SignupAsync([FromBody] SignupRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("signup/confirm"), AllowAnonymous, OpenApiOperation("Confirm registeration.", "")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Result<TokenResponse>))]
    public async Task<IActionResult> SignupConfirmAsync([FromBody] SignupConfirmRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("signup/confirm/resend"), AllowAnonymous, OpenApiOperation("Resend OTP.", "")]
    public async Task<IActionResult> SignupConfirmResendAsync([FromBody] SignupResendRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    #endregion

    #region User Products

    #region GetProduct
    [HttpGet("account/Product"), OpenApiOperation("Get User Product", "")]
    public async Task<IActionResult> GetProduct()
    {
          return Ok(await Mediator.Send(new GetProductRequest()));
    }
    #endregion

    #region Add Product

    [HttpPost("account/Product"), OpenApiOperation("Add User Product", "")]
    public async Task<IActionResult> AddProduct([FromBody] AddProductRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("account/Product/Confirm"), OpenApiOperation("Confirm add user product", "")]
    public async Task<IActionResult> AddProductConfirm([FromBody] AddProductConfirmRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("account/Product/Confirm/Resend"), OpenApiOperation("Resend conformation otp for add product", "")]
    public async Task<IActionResult> AddProductConfirmResend([FromBody] AddProductResendRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    #endregion

    #region Update Product

    [HttpPut("account/Product"), OpenApiOperation("For Free Sim, add User Product", "")]
    public async Task<IActionResult> UpdateProduct([FromBody] UpdateProductRequest request) => Ok(await Mediator.Send(request));

    [HttpPut("account/Product/Confirm"), OpenApiOperation("For Free Sim, add User Product", "")]
    public async Task<IActionResult> UpdateProductConfirm([FromBody] UpdateProductConfirmRequest request) => Ok(await Mediator.Send(request));

    [HttpPut("account/Product/Confirm/Resend"), OpenApiOperation("For Free Sim, add User Product", "")]
    public async Task<IActionResult> UpdateProductConfirmResend([FromBody] UpdateProductResendRequest request) => Ok(await Mediator.Send(request));

    #endregion

    #region Rename Product

    [HttpPost("account/Product/Rename"), OpenApiOperation("Rename User Product", "")]
    public async Task<IActionResult> RenameProduct([FromBody] RenameProductRequest request) => Ok(await Mediator.Send(request));

    #endregion

    #region Set Default Product

    [HttpPost("account/Product/Default"), OpenApiOperation("Set Default User Product", "")]
    public async Task<IActionResult> DefaultProduct([FromBody] DefaultProductRequest request) => Ok(await Mediator.Send(request));

    #endregion

    #region Replace

    [HttpPost("account/Product/Replace"), OpenApiOperation("Replace sim", "")]
    public async Task<IActionResult> ReplacementSimAsync([FromBody] ReplaceProductRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    #endregion

    #endregion

    #region User Account Details / Profile

    [HttpGet("account/Summary"), OpenApiOperation("Get user account detail", "")]
    public async Task<IActionResult> AccountSummary()
    {
        return Ok(await Mediator.Send(new AccountSummaryRequest()));
    }

    [HttpGet("account/{Msisdn}/Summary"), OpenApiOperation("Get user msisdn info by msisdn", "")]
    public async Task<IActionResult> ProductSummary([FromRoute] ProductSummaryRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpGet("account/{Msisdn}/balance"), OpenApiOperation("Get balance info by msisdn", "")]
    public async Task<IActionResult> AccountBalance([FromRoute] AccountBalanceRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
   

    //[HttpDelete("account/delete"), OpenApiOperation("Delete user account", "")]
    //public async Task<IActionResult> DeleteAccount([FromBody] DeleteAccountRequest request)
    //{
    //    return Ok(await Mediator.Send(request));
    //}

    [HttpGet("profile"), OpenApiOperation("Get user profile.", "")]
    public async Task<IActionResult> ProfileAsync()
    {
        return Ok(await Mediator.Send(new UserProfileRequest()));
    }

    [HttpPut("profile"), OpenApiOperation("update profile.", "")]
    public async Task<IActionResult> UpdateProfileAsync([FromBody] UpdateUserProfileRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPut("profile/password"), OpenApiOperation("update password.", "")]
    public async Task<IActionResult> ChangePasswordAsync([FromBody] ChangePasswordRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPut("profile/update/image"), OpenApiOperation("update profile.", "")]
    public async Task<IActionResult> UpdateProfileImageAsync([FromForm] UpdateProfileImageRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    #endregion
    private string GetIpAddress() =>
    Request.Headers.ContainsKey("X-Forwarded-For")
        ? Request.Headers["X-Forwarded-For"]
        : HttpContext.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "N/A";
}
