﻿namespace Application.Features.Bundle.PurchaseBundle;

public class PurchaseBundleResponse
{
    public int OrderId { get; set; }
}
