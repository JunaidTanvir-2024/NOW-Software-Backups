﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Database
{
    public class DBCountriesWithOperatorNames
    {
        public string TransferToCountryId { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string Continent { get; set; }
        public string OperatorNames { get; set; }
        public int OperatorCount { get; set; }
    }
    public class DBOperators
    {
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public string Continent { get; set; }
        public string TransferToOperatorId { get; set; }
        public string OperatorName { get; set; }
        public string OperatorImageUrl { get; set; }
    }

    public class DBResponse
    {
        public int DBStatus { get; set; } // 1 for Success and 0 for Failure
        public string DBErrorSP { get; set; } // Error Stored Procedure Name
        public string DBErrorMessage { get; set; } // Error Message
        public int InsertId { get; set; } // Table insertion identity column(id) value 
    }
}
