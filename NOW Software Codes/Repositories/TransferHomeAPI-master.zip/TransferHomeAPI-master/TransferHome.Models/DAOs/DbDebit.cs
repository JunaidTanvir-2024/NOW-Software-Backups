﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.DAOs
{
    public class DbDebit
    {
        public int UseId { get; set; }
        public decimal Amount { get; set; }
        public TopUpType type { get; set; }
        public string Currency { get; set; }
    }
}
