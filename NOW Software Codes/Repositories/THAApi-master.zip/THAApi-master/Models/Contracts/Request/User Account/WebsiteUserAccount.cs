﻿namespace Models.Contracts.Request
{
    public class WebsiteUserAccount
    {
        public WebsiteUserAccount()
        {
            this.UserAccountBalance = new UserAccountBalance();

            this.History = new UserAccountHistory();
        }

        public string Msisdn { get; set; }

        public string AccountID { get; set; }

        public string Pin { get; set; }

        public UserAccountBalance UserAccountBalance { get; set; }

        public UserAccountHistory History { get; set; }
    }
}
