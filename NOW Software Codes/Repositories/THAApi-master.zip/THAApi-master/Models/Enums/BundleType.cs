﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;

namespace Models.Enums
{
    public enum BundleType
    {
        Welcome = 1,
        Monthly,
        PAYG,
        Trial
    }
}
