using JM.Api.Controllers.Common;
using JM.Core.Features.Auth.Login;
using JM.Core.Features.Auth.Otp;
using JM.Core.Features.Auth.Password;
using JM.Core.Features.Auth.Register;
using JM.Core.Utilities.Definitions;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using RW.Common;
using RW.Failures;
using RW.Models;
using RW.Successes;

namespace JM.Api.Controllers.V1;

public sealed class AuthController : V1ApiController
{
    [AllowAnonymous]
    [HttpPost("login")]
    [ProducesResponseType<SuccessPayload<Login.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.Unauthorized)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.Forbidden)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    public async Task<ActionResult> Login([FromBody] Login.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [AllowAnonymous]
    [HttpPost("login/social")]
    [ProducesResponseType<SuccessPayload<Login.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.Unauthorized)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.Forbidden)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    public async Task<ActionResult> SocialLogin([FromBody] SocialLogin.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [AllowAnonymous]
    [HttpPost("register")]
    [ProducesResponseType<SuccessStatus<IResultBase>>(AppConstant.StatusCode.Created)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.Conflict)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.InternalServerError)]
    public async Task<ActionResult> Register([FromBody] Register.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Created, result);
        }
        return StatusCode(result.Code, result);
    }
    [AllowAnonymous]
    [HttpPost("password/reset")]
    [ProducesResponseType<SuccessStatus<IResultBase>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.InternalServerError)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    public async Task<ActionResult> ResetPassword([FromBody] ResetPassword.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(AppConstant.StatusCode.InternalServerError, result);
    }
    [AllowAnonymous]
    [HttpPost("otp/send")]
    [ProducesResponseType<SuccessStatus<IResultBase>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.TooManyRequests)]
    public async Task<ActionResult> GetOtp([FromBody] GetOtp.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        return StatusCode(result.Code, result);
    }
    [AllowAnonymous]
    [HttpPost("otp/verify")]
    [ProducesResponseType<SuccessStatus<IResultBase>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.TooManyRequests)]
    public async Task<ActionResult> VerifyOtp([FromBody] VerifyOtp.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        return StatusCode(result.Code, result);
    }
    [AllowAnonymous]
    [HttpPost("token/refresh")]
    [ProducesResponseType<SuccessStatus<RefreshToken.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.BadRequest)]
    public async Task<ActionResult> Token([FromBody] RefreshToken.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        return StatusCode(result.Code, result);
    }
}
