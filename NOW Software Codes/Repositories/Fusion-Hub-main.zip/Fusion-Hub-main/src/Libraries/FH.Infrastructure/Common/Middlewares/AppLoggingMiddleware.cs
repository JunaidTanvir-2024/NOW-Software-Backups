using System.Diagnostics;
using System.Text;
using System.Text.Json;

using FH.Core.Definitions;
using FH.Core.Entities;
using FH.Core.Extensions;
using FH.Core.Helpers;
using FH.Core.Interfaces.Database;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;

using Serilog;

namespace FH.Infrastructure.Common.Middlewares;

public class AppLoggingMiddleware(RequestDelegate next, ILogger logger)
{
    private const int BUFFER_SIZE = 4096;
    private const string CORRELATION_ID = "Correlation_Id";

    public async Task Invoke(HttpContext context, IUnitOfWork unitOfWork)
    {
        var stopwatch = Stopwatch.StartNew();

        var originalRequestBody = context.Request.Body;
        var originalResponseBody = context.Response.Body;

        // Read the request body
        var requestBody = await ReadRequestBody(context.Request);

        var responseStream = new MemoryStream();

        var responseBody = string.Empty;

        context.Items[CORRELATION_ID] = AppHelpers.GetCorrelationId();
        try
        {
            // Replace the request body with a new memory stream
            context.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(requestBody));

            // Capture the response
            context.Response.Body = responseStream;

            // Continue processing the request
            await next(context);

            // Log the response
            responseStream.Seek(0, SeekOrigin.Begin);
            responseBody = await ReadResponseBody(context, originalResponseBody, responseStream);

            //Calculating Response Size
            var responseSize = Encoding.UTF8.GetByteCount(responseBody);

            // Save log entry to the database
            UpsertAppLogs(context, stopwatch, context.Response.StatusCode, requestBody, responseBody, responseSize, string.Empty, unitOfWork);
        }
        catch (Exception ex)
        {
            logger.ErrorLog(ex);

            // Set the error message in the log entry
            UpsertAppLogs(context, stopwatch, StatusCodes.Status500InternalServerError, requestBody, responseBody, 0, ex.StackTrace?.ToString(), unitOfWork);

            // Re-throw the exception to allow proper error handling by Exception middleware
            throw;
        }
        finally
        {
            // Reset the request body stream
            await ResetRequestBodyStream(context, originalRequestBody, originalResponseBody, responseStream);
        }
    }

    private void UpsertAppLogs(HttpContext context, Stopwatch stopwatch, int statusCode, string requestBody, string? responseBody, int responseSize, string? errorStackTrace, IUnitOfWork unitOfWork)
    {
        (string serializedHeaders, string uniqueReference, string productCode, string productItemCode) = SerializeHeaders(context!.Request.Headers);

        if (string.IsNullOrEmpty(uniqueReference))
        {
            logger.Debug($"{nameof(AppEnums.ClientInformation.UniqueReference)} is not found against this request {requestBody}");
        }

        var logEntry = new AppLogEntity()
        {
            Timestamp = DateTimeOffset.UtcNow,
            RequestPath = context.Request.GetDisplayUrl(),
            RequestMethod = context.Request.Method,
            RequestBody = requestBody,
            ResponseBody = responseBody,
            StatusCode = statusCode,
            Duration = stopwatch.ElapsedMilliseconds,
            ClientIP = context?.Connection.RemoteIpAddress?.ToString(),
            UserAgent = context?.Request.Headers.UserAgent,
            ResponseSize = responseSize,
            ErrorReason = errorStackTrace,
            CorrelationId = Convert.ToString(context?.Items["Correlation_Id"])!,
            Headers = serializedHeaders,
            QueryString = context?.Request.QueryString.ToString(),
            UniqueReference = uniqueReference,
            ProductCode = productCode,
            ProductItemCode = productItemCode
        };

        // Save log entry to the database using your preferred data access method (e.g., Dapper, Entity Framework, etc.)
        unitOfWork.AppLoggerRepository.AppLogUpsert(logEntry);
    }

    private static async Task<string> ReadRequestBody(HttpRequest request)
    {
        request.EnableBuffering();

        var body = request.Body;

        using (var memoryStream = new MemoryStream())
        {
            await body.CopyToAsync(memoryStream);
            memoryStream.Seek(0, SeekOrigin.Begin);

            using (var reader = new StreamReader(memoryStream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true, bufferSize: BUFFER_SIZE, leaveOpen: true))
            {
                var requestBody = await reader.ReadToEndAsync();
                request.Body.Seek(0, SeekOrigin.Begin);
                return requestBody;
            }
        }
    }

    private static async Task<string> ReadResponseBody(HttpContext context, Stream originalResponseBody, MemoryStream responseStream)
    {
        string responseBody = await new StreamReader(responseStream).ReadToEndAsync();
        responseStream.Seek(0, SeekOrigin.Begin);
        context.Response.Body = originalResponseBody;
        return responseBody;
    }

    private static async Task ResetRequestBodyStream(HttpContext context, Stream originalRequestBody, Stream originalResponseBody, MemoryStream responseStream)
    {
        context.Request.Body = originalRequestBody;
        context.Response.Body = originalResponseBody;
        responseStream.Seek(0, SeekOrigin.Begin);
        await responseStream.CopyToAsync(originalResponseBody);
    }

    private static (string serializedHeaders, string uniqueReference, string productCode, string productItemCode) SerializeHeaders(IHeaderDictionary headers)
    {
        var serializedHeaders = new Dictionary<string, string>();

        foreach (var header in headers)
        {
            serializedHeaders[header.Key] = header.Value.ToString();
        }

        string uniqueReference = serializedHeaders.TryGetValue(nameof(AppEnums.ClientInformation.UniqueReference), out var uniqueReferenceValue)
            ? uniqueReferenceValue
            : string.Empty;

        string productCode = serializedHeaders.TryGetValue(nameof(AppEnums.ClientInformation.ProductCode), out var productCodeValue)
            ? productCodeValue
            : string.Empty;

        string productItemCode = serializedHeaders.TryGetValue(nameof(AppEnums.ClientInformation.ProductItemCode), out var productItemCodeValue)
            ? productItemCodeValue
            : string.Empty;

        return (JsonSerializer.Serialize(serializedHeaders), uniqueReference, productCode, productItemCode);
    }
}
