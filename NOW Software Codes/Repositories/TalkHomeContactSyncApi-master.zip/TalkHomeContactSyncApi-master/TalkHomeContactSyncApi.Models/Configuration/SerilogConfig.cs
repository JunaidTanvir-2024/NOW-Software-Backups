﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkHomeContactSyncApi.Models.Configuration
{
    public class SerilogConfig
    {
        public string FilePath { get; set; }
    }
}
