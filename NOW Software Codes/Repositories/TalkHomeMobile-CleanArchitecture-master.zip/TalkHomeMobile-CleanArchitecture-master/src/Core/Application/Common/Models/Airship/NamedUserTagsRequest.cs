﻿using Newtonsoft.Json;

namespace Application.Common.Models.Airship;

public class NamedUserTagsRequest
{
    [JsonProperty("NamedUser")]
    public string NamedUser { get; set; } = string.Empty;

    [JsonProperty("ProductCode")]
    public string ProductCode { get; set; } = "THM";

    [JsonProperty("TagGroup")]
    public string TagGroup { get; set; } = string.Empty;

    [JsonProperty("Tags")]
    public List<string>? Tags { get; set; }
}
