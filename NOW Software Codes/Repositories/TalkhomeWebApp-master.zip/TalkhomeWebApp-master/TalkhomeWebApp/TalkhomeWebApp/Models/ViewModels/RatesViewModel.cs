﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class RatesViewModel
    {
        public IList<Rates> Rates { get; set; }
        public string MinorCurrencyunit { get; set; }
    }
}
