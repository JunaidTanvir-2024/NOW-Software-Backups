﻿using ATT.Models.Contracts.Common;
using ATT.Models.Contracts.TransferTo.Response;
using ATT.Models.Database;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.Sms
{
    public interface ISmsSendingService
    {
        Task SendTopupSmsDetailsToRecipients(TopupSmsDetailsModel topupSmsDetailsModel);

    }
}
