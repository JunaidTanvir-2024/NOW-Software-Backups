namespace JM.Core.Utilities.DependencyResolver;

public abstract class ResolveAs
{
    public interface IScoped { }
    public interface ISingleton { }
    public interface ITransient { }
}
