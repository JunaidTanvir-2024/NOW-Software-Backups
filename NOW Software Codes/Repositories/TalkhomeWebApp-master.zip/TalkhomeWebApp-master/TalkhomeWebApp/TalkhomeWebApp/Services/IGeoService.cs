﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Models;

namespace TalkhomeWebApp.Services
{
    public interface IGeoService
    {
        public Task<GeoInfo> GetGeoInfo(HttpContext context);
    }
}
