﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PaymentsApi.Infrastructure.BLL.Interfaces.Pay360;
using PaymentsApi.Infrastructure.DAL.Database;
using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using Serilog;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace PaymentsApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    //public class Pay360CashierApiController : ControllerBase
    public class Pay360CashierApiController : Controller
    {

        private readonly ILogger Logger;
        private BL_IPay360CashierApi Pay360;

        public Pay360CashierApiController(ILogger logger, BL_IPay360CashierApi pay360)
        {
            Logger = logger;
            Pay360 = pay360;
        }

        [HttpPost("Validate")]
        public async Task<ActionResult> ValidateRequest(Validate userRequest)
        {

            GenericApiResponse<TAmount> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360.Validate(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<TAmount>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CashierApiController, Method: Validate, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }


        [HttpPost("NewCustomerPayment")]
        public async Task<ActionResult> NewCustomerPayment(UserPaymentRequestNewCustomer userRequest)
        {

            GenericApiResponse<UserResponseModels> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360.NewCustomerPayment(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserResponseModels>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CashierApiController, Method: PaymentNewCustomer, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("ExistingCustomerPaymentDefaultCard")]
        public async Task<ActionResult> ExistingCustomerPaymentDefaultCard(UserPaymentRequestExistingCustomerDefaultCard userRequest)
        {

            GenericApiResponse<UserResponseModels> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360.ExistingCustomerPaymentDefaultCard(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserResponseModels>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message),
                    payload = null
                };
                Logger.Error($"Controller: Pay360CashierApiController, Method: ExistingCustomerPaymentDefaultCard, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("ExistingCustomerPaymentNewCard")]
        public async Task<ActionResult> ExistingCustomerPaymentNewCard(UserPaymentRequestExistingCustomerNewCard userRequest)
        {

            GenericApiResponse<UserResponseModels> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360.ExistingCustomerPaymentNewCard(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserResponseModels>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CashierApiController, Method: ExistingCustomerPaymentNewCard, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }


        [HttpPost("Resume3DSecureTransaction")]
        public async Task<ActionResult> Resume3DSecureTransaction(UserRequestResume3DSecureTransaction userRequest)
        {

            GenericApiResponse<UserResponseModels> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360.Resume3DSecureTransaction(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserResponseModels>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CashierApiController, Method: Resume3DSecureTransaction, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("Resume3DsV2")]
        public async Task<ActionResult> Resume3DsV2(UserRequestResume3DsV2 userRequest)
        {

            GenericApiResponse<UserResponseModels> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360.Resume3DsV2(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserResponseModels>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CashierApiController, Method: Resume3DsV2, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost]
        [Route("ThreeDsV2Redirect_Test")]
        public async Task<ActionResult> ThreeDsV2Redirect_Test(string pay360TranId)
        {
            string requestJsonData;
            using (StreamReader reader = new StreamReader(Request.Body, Encoding.UTF8))
            {
                requestJsonData = await reader.ReadToEndAsync();
            }

            return Ok(requestJsonData);
        }

        [HttpPost("PaymentToken")]
        public async Task<ActionResult> ExistingCustomerPaymentCardToken(UserPaymentRequestCardToken userRequest)
        {

            GenericApiResponse<UserResponseModels> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360.ExistingCustomerPaymentCardToken(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserResponseModels>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CashierApiController, Method: ExistingCustomerPaymentCardToken, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("RepeatTransaction")]
        public async Task<ActionResult> RepeatTransaction(UserRequestRepeatTransaction userRequest)
        {

            GenericApiResponse<UserResponseModels> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360.RepeatTransaction(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserResponseModels>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CashierApiController, Method: RepeatTransaction, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("UpdateCustomerCard")]
        public async Task<ActionResult> UpdateCustomerCard(UpdateCustomerCardRequest updateCustomerCardRequest)
        {

              GenericApiResponse<UpdatePaymentMethodResponseModel> response;

            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

               response = await Pay360.UpdateCustomerCard(updateCustomerCardRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UpdatePaymentMethodResponseModel>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CashierApiController, Method: UpdateCustomerCard, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(updateCustomerCardRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }



            return Ok(response);
        }


    }

}



#region Deprecated
//[HttpPost("Payment")]
//public async Task<ActionResult> Payment(RequestModel model)
//{
//    try
//    {
//        if (!ModelState.IsValid)
//        {
//            return BadRequest(ModelState);
//        }

//        HttpResponseMessage response;
//        ResponseModel responseModel;

//        var customer = _dbContext.Customers.FirstOrDefault(x => x.MSISDN == model.MSISDN);

//        bool newCustomer = customer == null ? true : false;

//        if (newCustomer)
//        {
//            //New User
//            RequestModel_NewCustomer requestModel = new RequestModel_NewCustomer
//            {
//                Customer = model.Customer,
//                PaymentMethod = model.PaymentMethod,
//                Transaction = model.Transaction
//            };

//            response = await _apiCall.Post("https://api.mite.pay360.com/acceptor/rest/transactions/5304834/payment", requestModel);
//            if (response.StatusCode == System.Net.HttpStatusCode.Created)
//            {
//                responseModel = JsonConvert.DeserializeObject<ResponseModel>(response.Content.ReadAsStringAsync().Result);
//                customer = new Customers();
//                customer.CustomerId_Pay360 = Convert.ToInt32(responseModel.Customer.Id);
//                customer.MerchantRef = responseModel.Customer.MerchantRef;
//                customer.MSISDN = model.MSISDN;
//            }
//            else
//            {
//                //return Error
//                return Ok();
//            }
//        }
//        else
//        {
//            // Existing User
//            RequestModel_ExistingCustomer requestModel = new RequestModel_ExistingCustomer
//            {
//                Transaction = model.Transaction,
//                Customer = new CustomerRequestModel_ExistingCustomer
//                {
//                    MerchantRef = model.Customer.MerchantRef
//                },
//                PaymentMethod = new PaymentMethodRequestModel_ExistingCustomer
//                {
//                    FromCustomer = new ContractsAndModels.Pay360.Requests.NestedModels.CardRequestModel_ExistingCustomer { CV2 = model.PaymentMethod.Card.CV2 }
//                }
//            };

//            response = await _apiCall.Post("https://api.mite.pay360.com/acceptor/rest/transactions/5304834/payment", requestModel);
//            responseModel = JsonConvert.DeserializeObject<ResponseModel>(response.Content.ReadAsStringAsync().Result);
//        }

//        customer.Transactions.Add(new Transactions
//        {
//            TransactionId = responseModel.Transaction.TransactionId,
//            Amount = responseModel.Transaction.Amount,
//            Status = responseModel.Transaction.Status.ToEnum<Pay360TransactionStatuses>(),
//            Type = responseModel.Transaction.Type.ToEnum<TransactionTypes>(),
//            Currency = responseModel.Transaction.Currency,
//            TransactionTime = DateTimeOffset.Parse(responseModel.Transaction.TransactionTime).UtcDateTime,
//            ReceivedTime = DateTimeOffset.Parse(responseModel.Transaction.TransactionTime).UtcDateTime,
//            Outcome_ReasonCode = responseModel.Outcome.ReasonCode,
//            Outcome_ReasonMessage = responseModel.Outcome.ReasonMessage,
//            Outcome_Status = responseModel.Outcome.Status
//        });

//        if (newCustomer)
//        {
//            _dbContext.Customers.Add(customer);
//        }

//        _dbContext.SaveChanges();

//        return Ok();
//    }
//    catch (Exception ex)
//    {
//        throw;
//    }
//} 
#endregion
