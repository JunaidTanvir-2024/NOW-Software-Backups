﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Utility
{
    public enum PaymentAPIStatusCodes
    {
        Success = 0,
        Basket_Isempty = 1,
        BasketTotal_TransactionAmount_NotSame = 2,
        Invalid_ProductRef_ProductItem_THM = 3,
        Invalid_ProductRef_ProductItem_THRCC = 4,
        DailyLimitExceed = 5,
        ProductItemNotConfigured = 6,
        Basketitem_THCC_NotAvailable = 7,
        Basketitem_THCC_AmountExceedLimit = 8,
        InvalidProduct = 9,
        PaymentCreationFailed_Pay360End = 10,
        TransactionSuccesfull_DatabaseUpdateFailed = 11,
        TransactionUnSuccessful = 12,
        TransactionUnSuccesfull_DatabaseInsertionError = 13,
        DatabaseError = 14,
        TransactionFailure_DatabaseUpdateFailed = 15,
        ThreeDSAuthenticationFailed = 16,
        Resume3DSFailed = 17,
        InvalidTransaction = 20,
        limitExceed_MaximumBundle = 21,
        TopupDenied_ContactCS = 22,
        CustomerNotExist = 23,
        InvalidProductRef_ProductItem_THA = 24,
        AccessTokenError = 25,
        FullFilmentError = 26,
        InvalidProductRefTransferHome = 27,
        ServiceNotAvailable = 111
    }
}
