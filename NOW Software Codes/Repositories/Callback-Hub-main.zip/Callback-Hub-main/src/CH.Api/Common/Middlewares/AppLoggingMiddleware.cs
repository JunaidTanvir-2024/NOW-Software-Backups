using System.Diagnostics;
using System.Text;

using CH.Api.Common.Repositories;
using CH.Api.Common.Repositories.DTOs;

using Microsoft.AspNetCore.Http.Extensions;

namespace CH.Api.Common.Middlewares;

public class AppLoggingMiddleware(RequestDelegate next, Serilog.ILogger logger)
{
    private readonly RequestDelegate _next = next;
    private readonly Serilog.ILogger _logger = logger;
    private const string CORRELATION_ID = "Correlation_Id";

    public async Task Invoke(HttpContext context, ILoggerRepository loggerRepository)
    {
        var stopwatch = Stopwatch.StartNew();

        var originalRequestBody = context.Request.Body;
        var originalResponseBody = context.Response.Body;

        // Read the request body
        var requestBody = await ReadRequestBody(context.Request);

        var responseStream = new MemoryStream();

        var responseBody = string.Empty;

        context.Items[CORRELATION_ID] = Guid.NewGuid().ToString();
        try
        {
            // Replace the request body with a new memory stream
            context.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(requestBody));

            // Capture the response
            context.Response.Body = responseStream;

            // Continue processing the request
            await _next(context);

            // Log the response
            responseStream.Seek(0, SeekOrigin.Begin);
            responseBody = await ReadResponseBody(context, originalResponseBody, responseStream);

            //Calculating Response Size
            var responseSize = Encoding.UTF8.GetByteCount(responseBody);

            // Save log entry to the database
            await UpsertAppLogs(context, stopwatch, context.Response.StatusCode, requestBody, responseBody, responseSize, string.Empty, loggerRepository);
        }
        catch (Exception ex)
        {
            _logger.Error(ex, $"Message: {ex.Message}, StackTrace: {ex.StackTrace?.ToString()}");

            // Set the error message in the log entry
            await UpsertAppLogs(context, stopwatch, StatusCodes.Status500InternalServerError, requestBody, responseBody, 0, ex.StackTrace?.ToString(), loggerRepository);

            // Re-throw the exception to allow proper error handling by Exception middleware
            throw;
        }
        finally
        {
            // Reset the request body stream
            await ResetRequestBodyStream(context, originalRequestBody, originalResponseBody, responseStream);
        }
    }


    private static async Task UpsertAppLogs(HttpContext context, Stopwatch stopwatch, int statusCode, string requestBody, string? responseBody, int responseSize, string? errorStackTrace, ILoggerRepository loggerRepository)
    {
        var logEntry = new AppLogDto()
        {
            Timestamp = DateTimeOffset.UtcNow,
            RequestPath = context.Request.GetDisplayUrl(),
            RequestMethod = context.Request.Method,
            RequestBody = requestBody,
            ResponseBody = responseBody,
            StatusCode = statusCode,
            Duration = stopwatch.ElapsedMilliseconds,
            ClientIP = context?.Connection.RemoteIpAddress?.ToString(),
            UserAgent = context?.Request.Headers.UserAgent,
            ResponseSize = responseSize,
            ErrorReason = errorStackTrace,
            CorrelationId = Convert.ToString(context?.Items[CORRELATION_ID])!,
            QueryString = context?.Request.QueryString.ToString(),
        };

        // Save log entry to the database using your preferred data access method (e.g., Dapper, Entity Framework, etc.)
        await loggerRepository.AppLogUpsertAsync(logEntry);
    }
    private static async Task<string> ReadRequestBody(HttpRequest request)
    {
        request.EnableBuffering();

        var body = request.Body;

        using (var memoryStream = new MemoryStream())
        {
            await body.CopyToAsync(memoryStream);
            memoryStream.Seek(0, SeekOrigin.Begin);

            using (var reader = new StreamReader(memoryStream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true, bufferSize: 4096, leaveOpen: true))
            {
                var requestBody = await reader.ReadToEndAsync();
                request.Body.Seek(0, SeekOrigin.Begin);
                return requestBody;
            }
        }
    }

    private static async Task<string> ReadResponseBody(HttpContext context, Stream originalResponseBody, MemoryStream responseStream)
    {
        string responseBody = await new StreamReader(responseStream).ReadToEndAsync();
        responseStream.Seek(0, SeekOrigin.Begin);
        context.Response.Body = originalResponseBody;
        return responseBody;
    }

    private static async Task ResetRequestBodyStream(HttpContext context, Stream originalRequestBody, Stream originalResponseBody, MemoryStream responseStream)
    {
        context.Request.Body = originalRequestBody;
        context.Response.Body = originalResponseBody;
        responseStream.Seek(0, SeekOrigin.Begin);
        await responseStream.CopyToAsync(originalResponseBody);
    }
}
