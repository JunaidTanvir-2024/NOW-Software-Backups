using RW;

using Voucherify.Api.Features.Campaigns.Responses;
using Voucherify.Api.Features.Loyalties.Requests;
using Voucherify.Api.Features.Loyalties.Responses;
using Voucherify.Core.Domain.Definitions;
using Voucherify.Core.Services.VoucherifyApi;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;
using Voucherify.Core.Services.VoucherifyApi.Models.Events;
using Voucherify.Core.Services.VoucherifyApi.Models.Rewards;

namespace Voucherify.Api.Features.Loyalties;

public interface ILoyaltiesHandler
{
    Task<IResultWrapper<AddLoyaltyPointsResponse>> GiveLoyaltyPointsToCustomer(AddLoyaltyPointsRequest request);
    Task<IResultWrapper> GetLoyaltyRewardsByCampaignId(GetLoyaltyRewardsByCampaignIdRequest request);
    Task<IResultWrapper> GetLoyaltyByCampaignName(GetLoyaltyByCampaignNameRequest request);
    Task<IResultWrapper> GetLoyalties(GetLoyaltiesRequest request);
}

internal class LoyaltiesHandler : ILoyaltiesHandler
{
    private const string LoyaltyCampaign = "Loyalty Campaign";
    private readonly IVoucherifyImplementation _voucherifyImplementation;

    public LoyaltiesHandler(IVoucherifyImplementation voucherifyImplementation)
    {
        _voucherifyImplementation = voucherifyImplementation;
    }

    public async Task<IResultWrapper<AddLoyaltyPointsResponse>> GiveLoyaltyPointsToCustomer(AddLoyaltyPointsRequest request)
    {
        var eventData = new EventCreate()
        {
            Name = request.EventName,
            Customer = new Customer()
            {
                Metadata = request.CustomerMetadata,
                SourceId = request.CustomerNameOrId
            },
            Metadata = request.EventMetadata,
        };
        var result = await _voucherifyImplementation.CreateVoucherifyEvent(eventData);

        return result != null
            ? ResultWrapper.Success(new AddLoyaltyPointsResponse()
            {
                CustomerId = result.Customer?.SourceId,
                EventName = result?.Type
            })
            : ResultWrapper.Failure<AddLoyaltyPointsResponse>(AppConstants.StatusMessages.BadRequest, AppConstants.StatusCodes.BadRequest);
    }
    public async Task<IResultWrapper> GetLoyaltyRewardsByCampaignId(GetLoyaltyRewardsByCampaignIdRequest request)
    {
        var result = await _voucherifyImplementation.GetLoyaltyRewards(request?.CampaignId);

        return result != null
            ? ResultWrapper.Success(result)
            : ResultWrapper.Failure<RewardAssignment>(AppConstants.StatusMessages.BadRequest, AppConstants.StatusCodes.BadRequest);
    }
    public async Task<IResultWrapper> GetLoyalties(GetLoyaltiesRequest request)
    {
        var loyaltyCampaigns = await _voucherifyImplementation.GetLoyalties(request.PageNumber, request.PageSize);

        if (loyaltyCampaigns != null)
        {
            var result = loyaltyCampaigns?.Select(campaign => new CampaignResponse()
            {
                Name = campaign.Name,
                Description = campaign.Description,
                Id = campaign.Id,
                PromotionTiers = campaign.Promotion?.Tiers?.ConvertAll(promotion => new Promotions.Responses.PromotionTierResponse()
                {
                    PromotionId = promotion.Id,
                    Name = promotion.Name,
                    Banner = promotion.Banner,
                    Metadata = promotion.Metadata,
                    Category = promotion.Category,
                    CategoryId = promotion.CategoryId,
                    CampaignId = promotion.Campaign?.Id,
                    CampaignStartDate = promotion.Campaign?.StartDate,
                    IsCampaignActive = promotion.Campaign?.Active,
                    CampaignExpirationDate = promotion.Campaign?.ExpirationDate,
                    AmountOff = promotion.Action?.Discount?.AmountOff,
                    PercentOff = promotion.Action?.Discount?.PercentOff,
                    UnitOff = promotion.Action?.Discount?.UnitOff,
                    UnitType = promotion.Action?.Discount?.UnitType,
                    AmountLimit = promotion.Action?.Discount?.AmountLimit,
                    DiscountEffect = Convert.ToString(promotion.Action?.Discount?.Effect),
                    DiscountType = Convert.ToString(promotion.Action?.Discount?.Type),
                }),
                Active = campaign.Active,
                ExpirationDate = campaign.ExpirationDate,
                Metadata = campaign.Metadata,
                StartDate = campaign.StartDate,
                CampaignType = Convert.ToString(campaign.CampaignType)
            }).ToList();

            return ResultWrapper.Success(result);
        }
        return ResultWrapper.Failure<List<CampaignResponse>>(AppConstants.StatusMessages.LoyaltyCampaignNotFound, AppConstants.StatusCodes.LoyaltyCampaignNotFound);
    }
    public async Task<IResultWrapper> GetLoyaltyByCampaignName(GetLoyaltyByCampaignNameRequest request)
    {
        var loyaltyCampaign = await _voucherifyImplementation.GetLoyalty(request.CampaignIdOrName);

        return loyaltyCampaign != null ?
        ResultWrapper.Success(new CampaignResponse()
        {
            Name = loyaltyCampaign.Name,
            Description = loyaltyCampaign.Description,
            Id = loyaltyCampaign.Id,
            PromotionTiers = loyaltyCampaign.Promotion?.Tiers?.ConvertAll(promotion => new Promotions.Responses.PromotionTierResponse()
            {
                PromotionId = promotion.Id,
                Name = promotion.Name,
                Banner = promotion.Banner,
                Metadata = promotion.Metadata,
                Category = promotion.Category,
                CategoryId = promotion.CategoryId,
                CampaignId = promotion.Campaign?.Id,
                CampaignStartDate = promotion.Campaign?.StartDate,
                IsCampaignActive = promotion.Campaign?.Active,
                CampaignExpirationDate = promotion.Campaign?.ExpirationDate,
                AmountOff = promotion.Action?.Discount?.AmountOff,
                PercentOff = promotion.Action?.Discount?.PercentOff,
                UnitOff = promotion.Action?.Discount?.UnitOff,
                UnitType = promotion.Action?.Discount?.UnitType,
                AmountLimit = promotion.Action?.Discount?.AmountLimit,
                DiscountType = Convert.ToString(promotion.Action?.Discount?.Type),
                DiscountEffect = Convert.ToString(promotion.Action?.Discount?.Effect)
            }),
            Active = loyaltyCampaign.Active,
            ExpirationDate = loyaltyCampaign.ExpirationDate,
            Metadata = loyaltyCampaign.Metadata,
            StartDate = loyaltyCampaign.StartDate,
            CampaignType = Convert.ToString(loyaltyCampaign.CampaignType)
        }) :
            ResultWrapper.Failure<CampaignResponse>(AppConstants.StatusMessages.LoyaltyCampaignNotFound, AppConstants.StatusCodes.LoyaltyCampaignNotFound);
    }
}
