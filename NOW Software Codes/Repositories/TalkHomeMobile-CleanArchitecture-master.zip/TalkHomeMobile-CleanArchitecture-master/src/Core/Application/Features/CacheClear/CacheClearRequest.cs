﻿
namespace Application.Features.CacheClear;
public class CacheClearRequest : IRequest<Result<object>>
{
}
