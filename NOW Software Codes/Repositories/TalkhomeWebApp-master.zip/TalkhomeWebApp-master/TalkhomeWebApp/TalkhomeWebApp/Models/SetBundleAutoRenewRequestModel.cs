﻿using System.ComponentModel.DataAnnotations;

namespace TalkhomeWebApp.Models
{
    public class SetBundleAutoRenewRequestModel
    {
        [Required]
        public string BundleId { get; set; }
        public bool IsAutoRenew { get; set; }
    }
}
