﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using TalkhomeWebApp.Models;
using TalkhomeWebApp.Models.ViewModels;
using TalkhomeWebApp.Utilities;
using TalkhomeWebApp.Utilities.Extension;
using TalkhomeWebApp.Models.Configurations;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Http;
using System.Web;
using Microsoft.AspNetCore.DataProtection;
using TalkhomeWebApp.Services;
using System.IO;
using ExcelDataReader;
using GemBox.Spreadsheet;
using System.Text;
using Syncfusion.XlsIO;
using Microsoft.Extensions.Hosting;
using IHostingEnvironment = Microsoft.Extensions.Hosting.IHostingEnvironment;
using System.Net;
using TalkhomeWebApp.Models.AirShip;
using System.Security.Claims;
using TalkhomeWebApp.Models.ApiContracts.Response;
using System.Security.Principal;
using Microsoft.AspNetCore.SignalR.Protocol;

namespace TalkhomeWebApp.Controllers
{
    public class LandingPagesController : Controller
    {
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly ILogger _logger;
        private readonly IHelperService _helperService;
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly EndPoints _endpoints;
        private readonly IBundleService _bundleService;
        private readonly IRatesService _ratesService;
        private readonly IGeoService _geoService;
        private readonly IAirshipService _airshipService;
        private readonly IOptions<TopUpConfig> topupConfig;
		private readonly ApiClient _apiClient;

		public LandingPagesController(IWebHostEnvironment hostEnvironment,
            ILogger logger,
            IHelperService helperService,
            IOptions<BasicAuthConfig> basicAuthConfig,
            IOptions<EndPoints> Endpoints,
            IDataProtectionProvider provider,
            IBundleService bundleService,
            IRatesService ratesService,
            IGeoService geoService,
             IAirshipService airshipService,
             IOptions<TopUpConfig> topupConfig,
             ApiClient apiClient)
        {
            _hostEnvironment = hostEnvironment;
            _logger = logger;
            _basicAuthConfig = basicAuthConfig.Value;
            _endpoints = Endpoints.Value;
            _bundleService = bundleService;
            _ratesService = ratesService;
            _geoService = geoService;
            _airshipService = airshipService;
            this.topupConfig = topupConfig;
			this._apiClient = apiClient;
			_helperService = helperService;
        }

        [Route("top-up")]
        public IActionResult TopUpLandingPage()
        {
            return View();
        }
        [Route("send-credit")]
        public IActionResult SendCreditLandingPage()
        {
            return RedirectToActionPermanent("SendCreditCountries", "Home");
            //try
            //{
            //    return View();
            //    //return RedirectToAction("SendCreditCountries", "Home");
            //}
            //catch (Exception ex)
            //{
            //    _logger.Error($"Class: LandingPagesController, Method: SendCreditLandingPage, ErrorMessage: " +
            //        $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            //    throw ex;
            //}
        }
        [Route("ramadan")]
        public IActionResult Ramadan()
        {
            return View();
        }

        [Route("calling-rates/call-{countryname}")]
        public IActionResult CountryLandingPage_old(string CountryName)
        {
            return RedirectToActionPermanent("CountryLandingPage", new { CountryName = CountryName });
        }
        [Route("rates/call-{countryname}")]
        public async Task<IActionResult> CountryLandingPage(string CountryName)
        {
            try
            {
                if (String.IsNullOrEmpty(CountryName))
                {
                    return RedirectToAction("PageNotFound", "Home");
                }
                var model = new LandingPageModel();
                string countryCode = "";
                #region Fetch Country Data

                if (CountryName == "united-arab-emirates" || CountryName == "dubai" || CountryName == "uae") { CountryName = "united arab emirates"; }
                if (CountryName == "united-states" || CountryName == "united-states-of-america") { CountryName = "usa"; }
                if (CountryName == "uk") { CountryName = "united kingdom"; }
                CountryName = CountryName.Replace("-", " ");


                string countriesNameFilePath = _hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json";
                var countriesDatajson = System.IO.File.ReadAllText(countriesNameFilePath);
                model.CountryData = JsonConvert.DeserializeObject<CountriesModel>(countriesDatajson).countries
                    .Where(x => x.Name.ToLower() == CountryName).FirstOrDefault();
                if (model.CountryData == null)
                {
                    return RedirectToAction("PageNotFound", "Home");
                }

                #endregion
                #region Rates Data Fetch

                if (User.Identity.IsAuthenticated)
                {
                    countryCode = User.Claims.Where(x => x.Type == "iso_two_country").FirstOrDefault().Value;
                }
                else
                {
                    var geoLocation = await _geoService.GetGeoInfo(HttpContext);

                    _logger.Information($"Class: LandingPagesController, Method: CountryLandingPage, GeoLocation: {JsonConvert.SerializeObject(geoLocation)}");

                    countryCode = geoLocation != null && !string.IsNullOrEmpty(geoLocation.CountryCode) ? geoLocation.CountryCode.ToUpper() : "GB";
                }
                model.CountryContent.CountryName = _helperService.GetCountryNameByCountryCode(countryCode);
                IList<Rates> payload = await _ratesService.GetRates(countryCode, User);

                if (payload.Count > 0)
                {
                    payload = payload.OrderBy(x => x.Destination).ToList();
                    model.CountryRates = payload.Where(r => r.ISO2Code.Equals(model.CountryData.IsoTwoCharacterCode, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();
                }

                //var countryRates = (decimal)10.00;
                //if (model.CountryRates.Mobile != 0)
                //{
                //    countryRates = model.CountryRates.Mobile;
                //}
                //else if (model.CountryRates.Landline != 0)
                //{
                //    countryRates = model.CountryRates.Landline;
                //}
                var topupuAmount = topupConfig.Value.TopUpAmounts;
                foreach (var item in topupuAmount)
                {
                    model.Topups.Add(new LandingPageModel.Topup
                    {
                        Minutes = (int)Math.Round(item * 100 / model.CountryRates.Mobile),
                        Price = item
                    });
                }

                #region Currency Get

                if (User.Identity.IsAuthenticated)
                {
                    model.MinorCurrencyunit = CommonExtentionMethods.GetMinorCurrencyUnit(
                                                                User.Claims.Where(x => x.Type == "currency").First().Value);
                    model.CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(
                                                               User.Claims.Where(x => x.Type == "currency").First().Value);
                    model.CurrentCurreny = User.Claims.Where(x => x.Type == "currency").First().Value;
                }
                else
                {
                    var CountryJson = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountryCurrency.json");
                    var _countriesCurrency = JsonConvert.DeserializeObject<AllCurrenciesModel>(CountryJson);

                    if (!string.IsNullOrEmpty(countryCode))
                    {
                        var currentCountry = _countriesCurrency.Currencies.Where(x => x.ContainsKey(countryCode)).FirstOrDefault();
                        if (currentCountry != null)
                        {
                            model.CurrentCurreny = CommonExtentionMethods.GetCurrencyUnit(currentCountry[countryCode]);
                            model.MinorCurrencyunit = model.CurrentCurreny.GetMinorCurrencyUnit();
                            model.CurrencySymbol = model.CurrentCurreny.GetCurrencySymbol();
                        }
                        else
                        {
                            model.CurrentCurreny = "USD";
                            model.MinorCurrencyunit = model.CurrentCurreny.GetMinorCurrencyUnit();
                            model.CurrencySymbol = model.CurrentCurreny.GetCurrencySymbol();
                        }
                    }
                    else
                    {
                        model.CurrentCurreny = "USD";
                        model.MinorCurrencyunit = model.CurrentCurreny.GetMinorCurrencyUnit();
                        model.CurrencySymbol = model.CurrentCurreny.GetCurrencySymbol();
                    }
                }

                //if (model.CountryRates != null && json.Contains("{CountryRateValue}"))
                //{
                //    json = json.Replace("{CountryRateValue}", model.CountryRates.Landline.ToString());
                //    json = json.Replace("{CountryCurrencyValue}", model.MinorCurrencyunit.ToString());

                //}
                //model.CountryContent = JsonConvert.DeserializeObject<CountryContent>(json);
                #endregion

                #endregion
                #region Bundles


                string Na_Service_Id = "";
                string account = string.Empty;
                if (User.Identity.IsAuthenticated)
                {
                    Na_Service_Id = User.Claims.Where(x => x.Type == "service_id").FirstOrDefault().Value;
                    account = User.Claims.Where(x => x.Type == "account_id").First().Value;
                }
                else
                {
                    account = null;
                    var CountriesData = await _bundleService.GetBundlesCountries(User);

                    var country = CountriesData.Where(c => c.ISO_Code.Equals
                                        (countryCode, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

                    if (country != null)
                    {
                        Na_Service_Id = country.Na_Service_Id;
                    }
                }

                model.Bundles = (await _bundleService.GetBundleByDestinationCountry(Na_Service_Id, countryCode, model.CountryData.IsoTwoCharacterCode, account, User))
                    .ToList();


                #endregion
                #region Get Operators
                var sendcreditCountries = new SendCreditByCountryViewModel();
                sendcreditCountries.CountryCode = model.CountryData.IsoTwoCharacterCode;
                sendcreditCountries.CountryName = model.CountryData.Name;
                var transferCountriesResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                $"Transfer/TransferOperators?currency={model.CurrentCurreny}&countryName={model.CountryData.Name.Replace("-", " ")}", User, ApiCallType.Bearer, GetRequest: true);
                if (transferCountriesResponse.IsSuccessStatusCode)
                {

                    var accountResponseJson = JObject.Parse(await transferCountriesResponse.Content.ReadAsStringAsync());
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var response = accountResponseJson.GetValue("payload").ToObject<TransferOperatorsResponse>();
                        if (response == null)
                        {
                            sendcreditCountries.Operators = new List<OperatorViewModel>();
                            sendcreditCountries.Promotions = new List<Item>();
                        }
                        else
                        {
                            sendcreditCountries.Operators = response.Operators.Select(e => new OperatorViewModel()
                            {
                                Id = e.TransferToOperatorId,
                                ImageUrl = e.operatorImageUrl,
                                Name = e.operatorName,
                                CountryName = e.countryName,
                                CountryCode = e.countryCode,
                                Continent = e.Continent,
                            }).ToList();
                            sendcreditCountries.Promotions = response.Promotions;
                        }
                    }
                }
                model.sendCreditByCountry = sendcreditCountries;
                #endregion
                #region Airship
                if (User.Identity.IsAuthenticated)
                {
                    string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;

                    //events
                    var customEventsRequest = new CustomEventsRequest()
                    {
                        ProductCode = "THA",
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = namedUserId,
                        CustomEventName = $"clicked_explore_{countryCode.ToLower()}_web"
                    };
                    await _airshipService.AddCustomEvent(customEventsRequest);
                }
                #endregion
                return View(model);
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: LandingPagesController, Method: CountryLandingPage, " +
                                      $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                      $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }
        [Route("pakistan-T20")]
        public async Task<IActionResult> PakistanT20LandingPage()
        {
            try
            {


                string jsonFilePath = _hostEnvironment.ContentRootPath + "/wwwroot/json/T20landingPage/pakistan.json";
                if (!System.IO.File.Exists(jsonFilePath))
                {
                    return RedirectToAction("PageNotFound", "Home");
                }

                var model = new LandingPageModel();

                var json = System.IO.File.ReadAllText(jsonFilePath);

                model.CountryContent = JsonConvert.DeserializeObject<CountryContent>(json);

                #region Rates Data Fetch

                string CountryCode = "";
                if (User.Identity.IsAuthenticated)
                {
                    CountryCode = User.Claims.Where(x => x.Type == "iso_two_country").FirstOrDefault().Value;

                }
                else
                {
                    var geoLocation = await _geoService.GetGeoInfo(HttpContext);

                    _logger.Information($"Class: LandingPagesController, Method: PakistanT20LandingPage, GeoLocation: {JsonConvert.SerializeObject(geoLocation)}");

                    CountryCode = geoLocation != null && !string.IsNullOrEmpty(geoLocation.CountryCode) ? geoLocation.CountryCode.ToUpper() : "";

                }
                IList<Rates> payload = await _ratesService.GetRates(CountryCode, User);

                if (payload.Count > 0)
                {
                    payload = payload.OrderBy(x => x.Destination).ToList();
                    model.CountryRates = payload.Where(r => r.Destination.Equals(model.CountryData.Name, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();
                }


                //
                //if (model.CountryRates != null)
                //{
                //    json = json.Replace("{CountryRateValue}", model.CountryRates.Landline.ToString());
                //    json = json.Replace("{CountryCurrencyValue}", model.MinorCurrencyunit.ToString());

                //}
                #region Currency Get

                if (User.Identity.IsAuthenticated)
                {
                    model.MinorCurrencyunit = CommonExtentionMethods.GetMinorCurrencyUnit(
                                                                User.Claims.Where(x => x.Type == "currency").First().Value);
                    model.CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(
                                                               User.Claims.Where(x => x.Type == "currency").First().Value);
                    model.CurrentCurreny = User.Claims.Where(x => x.Type == "currency").First().Value;
                }
                else
                {
                    var CountryJson = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountryCurrency.json");
                    var _countriesCurrency = JsonConvert.DeserializeObject<AllCurrenciesModel>(CountryJson);

                    if (!string.IsNullOrEmpty(CountryCode))
                    {
                        var currentCountry = _countriesCurrency.Currencies.Where(x => x.ContainsKey(CountryCode)).FirstOrDefault();

                        if (currentCountry != null)
                        {
                            model.MinorCurrencyunit = CommonExtentionMethods.GetMinorCurrencyUnit(currentCountry[CountryCode]);
                            model.CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(currentCountry[CountryCode]);
                            model.CurrentCurreny = CommonExtentionMethods.GetCurrencyUnit(currentCountry[CountryCode]);
                        }
                        else
                        {
                            model.CurrentCurreny = "USD";
                            model.MinorCurrencyunit = "c";
                            model.CurrencySymbol = "";
                        }
                    }
                    else
                    {
                        model.CurrentCurreny = "USD";
                        model.MinorCurrencyunit = "c";
                        model.CurrencySymbol = "";
                    }
                }

                if (model.CountryRates != null && json.Contains("{CountryRateValue}"))
                {
                    json = json.Replace("{CountryRateValue}", model.CountryRates.Landline.ToString());
                    json = json.Replace("{CountryCurrencyValue}", model.MinorCurrencyunit.ToString());

                }
                model.CountryContent = JsonConvert.DeserializeObject<CountryContent>(json);
                #endregion

                #endregion

                #region Bundles


                string Na_Service_Id = string.Empty;
                if (User.Identity.IsAuthenticated)
                {
                    Na_Service_Id = User.Claims.Where(x => x.Type == "service_id").FirstOrDefault().Value;
                }
                else
                {
                    var CountriesData = await _bundleService.GetBundlesCountries(User);

                    var country = CountriesData.Where(c => c.ISO_Code.Equals
                                        (CountryCode, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

                    if (country != null)
                    {
                        Na_Service_Id = country.Na_Service_Id;
                    }
                }

                model.Bundles = (await _bundleService.GetBundleByCountry(Na_Service_Id, model.CountryContent.CountryCode, null, User))
                    .Where(b => b.Description.Equals(model.CountryContent.CountryCode, StringComparison.CurrentCultureIgnoreCase)).ToList();


                #endregion

                //var json = System.IO.File.ReadAllText(jsonFilePath);


                //json = json.Replace("{CountryCurrencyValue}", model.MinorCurrencyunit.ToString());

                //model.CountryContent = JsonConvert.DeserializeObject<CountryContent>(json);

                var _countries = JsonConvert.DeserializeObject<CountriesModel>(System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json"));
                // setting ISO property for every destination object in order to display flags in frontened
                //foreach (var PopularDestination in model.CountryContent.PopularDestinations)
                //{
                //    PopularDestination.DestinationISO = _countries.countries.Where(c => c.Name.Equals(PopularDestination.DestinationName, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault() == null ? "" : _countries.countries.Where(c => c.Name.Equals(PopularDestination.DestinationName, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault().IsoTwoCharacterCode;
                //}
                return View(model);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: LandingPagesController, Method: PakistanT20LandingPage, " +
                                      $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                      $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [Route("calling-code/{countryname}")]
        public async Task<IActionResult> CallingCodes(string CountryName)
        {
            //return RedirectToAction("PageNotFound", "Home");

            try
            {
                if (String.IsNullOrEmpty(CountryName))
                {
                    return RedirectToAction("PageNotFound", "Home");
                }

                string jsonFilePath = _hostEnvironment.ContentRootPath + "/wwwroot/json/CallingCodeLandingPagesData/" + CountryName + ".json";


                // If you are using the Professional version, enter your serial key below.
                //SpreadsheetInfo.SetLicense("FREE-LIMITED-KEY");

                //var workbook = ExcelFile.Load("wwwroot/Excel/callingcode.xlsx");

                //var sb = new StringBuilder();

                //// Iterate through all worksheets in an Excel workbook.
                //foreach (var worksheet in workbook.Worksheets)
                //{
                //    sb.AppendLine();
                //    sb.AppendFormat("{0} {1} {0}", new string('-', 25), worksheet.Name);

                //    // Iterate through all rows in an Excel worksheet.
                //    foreach (var row in worksheet.Rows)
                //    {
                //        sb.AppendLine();

                //        // Iterate through all allocated cells in an Excel row.
                //        foreach (var cell in row.AllocatedCells)
                //            if (cell.ValueType != CellValueType.Null)
                //                sb.Append(string.Format("{0} [{1}]", cell.Value, cell.ValueType).PadRight(25));
                //            else
                //                sb.Append(new string(' ', 25));
                //    }
                //}

                //New instance of ExcelEngine is created 
                //Equivalent to launching Microsoft Excel with no workbooks open
                //Instantiate the spreadsheet creation engine
                //ExcelEngine excelEngine = new ExcelEngine();

                ////Instantiate the Excel application object
                //IApplication application = excelEngine.Excel;

                ////Assigns default application version
                //application.DefaultVersion = ExcelVersion.Excel2013;

                ////A existing workbook is opened.              
                //string basePath = _hostEnvironment.WebRootPath + @"/Excel/callingcode.xlsx";
                //FileStream sampleFile = new FileStream(basePath, FileMode.Open);

                //IWorkbook workbook = application.Workbooks.Open(sampleFile);

                ////Access first worksheet from the workbook.
                //IWorksheet worksheet = workbook.Worksheets[0];

                ////Set Text in cell A3.
                //worksheet.Range["A3"].Text = "Hello World";

                ////Defining the ContentType for excel file.
                //string ContentType = "Application/msexcel";

                ////Define the file name.
                //string fileName = "Output.xlsx";

                ////Creating stream object.
                //MemoryStream stream = new MemoryStream();

                ////Saving the workbook to stream in XLSX format
                //workbook.SaveAs(stream);

                //stream.Position = 0;

                ////Closing the workbook.
                //workbook.Close();

                ////Dispose the Excel engine
                //excelEngine.Dispose();

                ////Creates a FileContentResult object by using the file contents, content type, and file name.
                //var x = File(stream, ContentType, fileName);

                ////Console.WriteLine(sb.ToString());

                //var result = new HttpResponseMessage(HttpStatusCode.OK)
                //{
                //    Content = new ByteArrayContent(stream.ToArray())
                //};
                //result.Content.Headers.ContentDisposition =
                //    new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                //    {
                //        FileName = "CertificationCard.pdf"
                //    };
                //result.Content.Headers.ContentType =
                //    new MediaTypeHeaderValue("application/octet-stream");

                //return (IActionResult)result;


                if (!System.IO.File.Exists(jsonFilePath))
                {
                    return RedirectToAction("PageNotFound", "Home");
                }

                var model = new CallingCodesLandingPageViewMOdel();

                string CountryCode = "";

                if (User.Identity.IsAuthenticated)
                {
                    CountryCode = User.Claims.Where(x => x.Type == "iso_two_country").FirstOrDefault().Value;
                }
                else
                {
                    var geoLocation = await _geoService.GetGeoInfo(HttpContext);

                    _logger.Information($"Class: LandingPagesController, Method: CountryLandingPage, GeoLocation: {JsonConvert.SerializeObject(geoLocation)}");

                    CountryCode = geoLocation != null && !string.IsNullOrEmpty(geoLocation.CountryCode) ? geoLocation.CountryCode.ToUpper() : "";
                }

                var jsondata = System.IO.File.ReadAllText(jsonFilePath);

                model.LandingPageContent = JsonConvert.DeserializeObject<CallingCodesCountryContent>(jsondata);

                string Na_Service_Id = "";

                if (User.Identity.IsAuthenticated)
                {
                    Na_Service_Id = User.Claims.Where(x => x.Type == "service_id").FirstOrDefault().Value;
                }
                else
                {
                    var CountriesData = await _bundleService.GetBundlesCountries(User);

                    var country = CountriesData.Where(c => c.ISO_Code.Equals(model.LandingPageContent.CountryCode, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

                    if (country != null)
                    {
                        Na_Service_Id = country.Na_Service_Id;
                    }
                }

                // Currency Get

                if (User.Identity.IsAuthenticated)
                {
                    model.CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(User.Claims.Where(x => x.Type == "currency").First().Value);
                }
                else
                {
                    var CountryJson = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountryCurrency.json");
                    var _countriesCurrency = JsonConvert.DeserializeObject<AllCurrenciesModel>(CountryJson);
                    if (!string.IsNullOrEmpty(CountryCode))
                    {
                        var currentCountry = _countriesCurrency.Currencies.Where(x => x.ContainsKey(CountryCode)).FirstOrDefault();
                        if (currentCountry != null)
                        {
                            model.CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(currentCountry[CountryCode]);
                        }
                        else
                        {
                            model.CurrencySymbol = "";
                        }
                    }
                    else
                    {
                        model.CurrencySymbol = "";
                    }
                }

                model.Bundles = (await _bundleService.GetBundleByCountry(Na_Service_Id, model.LandingPageContent.CountryCode, null, User)).Where(b => b.Description.Equals(model.LandingPageContent.CountryCode, StringComparison.CurrentCultureIgnoreCase)).ToList();

                return View(model);
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: LandingPagesController, Method: CallingCodes, " +
                                      $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                      $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }

        }

        [Route("IsLandingPage")]
        [HttpGet]
        public IActionResult IsLandingPageAvailabel(string countryname)
        {
            //if (countryname == "United Arab Emirates") { countryname = "uae"; }
            countryname = countryname.Replace("-", " ");
            string countriesNameFilePath = _hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json";
            var countriesDatajson = System.IO.File.ReadAllText(countriesNameFilePath);
            var CountryData = JsonConvert.DeserializeObject<CountriesModel>(countriesDatajson).countries
                 .Where(x => x.Name == countryname).FirstOrDefault();
            //string jsonFilePath = _hostEnvironment.ContentRootPath + "/wwwroot/json/CallingRatesLandingPagesData/" + countryname + ".json";

            if (CountryData == null)
            {
                return Json(new { errorCode = 0, result = false });
            }
            else
            {
                return Json(new { errorCode = 0, result = true });
            }
        }

        [Route("psl")]
        public IActionResult PSL()
        {
            return RedirectToAction("Index", "Home");

            //string countryCode = "";
            //var Na_Service_Id = "";
            //var destinationCountryCode = "PK";
            //var destinationCountryName = "Pakistan";
            //var model = new PSLLandingPageViewModel();
            //if (User.Identity.IsAuthenticated)
            //{
            //    countryCode = User.Claims.Where(x => x.Type == "iso_two_country").FirstOrDefault().Value;
            //    Na_Service_Id = User.Claims.Where(x => x.Type == "service_id").FirstOrDefault().Value;
            //    model.CurrencyCode = User.Claims.Where(x => x.Type == "currency").First().Value;
            //}
            //else
            //{
            //    var geoLocation = await _geoService.GetGeoInfo(HttpContext);
            //    countryCode = geoLocation != null && !string.IsNullOrEmpty(geoLocation.CountryCode) ? geoLocation.CountryCode.ToUpper() : "";
            //    var CountriesData = await _bundleService.GetBundlesCountries(User);

            //    var country = CountriesData.Where(c => c.ISO_Code.Equals
            //                        (countryCode, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

            //    Na_Service_Id = country?.Na_Service_Id;
            //    model.CurrencyCode = country?.Currency ?? "GBP";
            //}
            //model.CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(model.CurrencyCode);
            //model.Bundles = (await _bundleService.GetBundleByCountry(Na_Service_Id, countryCode, null, User))
            //    .Where(b => b.Description.Equals(destinationCountryCode, StringComparison.CurrentCultureIgnoreCase)).ToList();
            //var rates = await _ratesService.GetRates(countryCode, User);
            //model.Rate = rates.Where(e => e.Destination.Equals(destinationCountryName, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();
            //return View(model);
        }
    }
}