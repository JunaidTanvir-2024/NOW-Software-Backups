﻿using Application.Common.Interfaces.Infrastructure.Identity;
using Application.Common.Mailing;

namespace Application.Features.Device.ConfirmDeviceResend;

public class ConfirmDeviceResendRequestHandler : IRequestHandler<ConfirmDeviceResendRequest, Result<object>>
{
    #region Fields

    private readonly IStringLocalizer<RefreshTokenRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly IOtpService _otpService;
    private readonly ISmsService _smsService;
    private readonly IMailService _mailService;

    #endregion

    #region Ctor

    public ConfirmDeviceResendRequestHandler(
        IStringLocalizer<RefreshTokenRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService,
        IOtpService otpService,
        ISmsService smsService,
        IMailService mailService)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _otpService = otpService;
        _smsService = smsService;
        _mailService = mailService;
    }

    #endregion

    #region Methods

    public async Task<Result<object>> Handle(ConfirmDeviceResendRequest request, CancellationToken cancellationToken)
    {
        //Check if request is from App
        (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();
        User? user;
        LoginType loginType;

        request.EmailOrPhone = request.EmailOrPhone.Trim().Normalize();

        if (_commonService.IsValidEmailAddress(request.EmailOrPhone))
        {
            user = await _unitOfWork.UserRepo.GetUserByEmail(request.EmailOrPhone);
            loginType = LoginType.Email;
        }
        else
        {
            request.EmailOrPhone = _commonService.FormatMsisdn(request.EmailOrPhone);
            user = await _unitOfWork.UserRepo.GetUserByMsisdn(request.EmailOrPhone);
            loginType = LoginType.PhoneNumber;
        }

        //User not registered
        if (user == null)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidCredentials],
                CustomStatusCode.InvalidCredentials);
        }

        //Check user for any type of deactivation

        //string? currentMsisdn = String.Empty;
        //if (loginType == LoginType.PhoneNumber)
        //{
        //    currentMsisdn = request.EmailOrPhone;
        //}
        //else
        //{
        //    //Get user current default msisdn for sending message
        //    var userProds = await _unitOfWork.UserRepo.GetUserProducts(user.Id);
        //    if (userProds.Any())
        //    {
        //        currentMsisdn = userProds.Any(x => x.IsDefault)
        //            ? userProds.First(x => x.IsDefault).Msisdn :
        //            userProds.First().Msisdn;
        //    }
        //}

        //if (!string.IsNullOrEmpty(currentMsisdn))
        //{

        //Send otp message
        var (Otp, otpModel) = await _otpService.CreateOtp(request.EmailOrPhone + "-" + request.DeviceId, OtpType.Device, null);
        if (otpModel.StatusCode != CustomStatusCode.OtpIsNotCreated)
        {
            if (loginType == LoginType.Email)
            {
                await _mailService.SendSignupEmailOtpAsync(request.EmailOrPhone, Otp, null);
            }
            else
            {
                await _smsService.SendOtpMessage(request.EmailOrPhone, Otp.ToString()!);
            }
        }
        //}

        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}