﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrasnferHome.Models.Configurations
{
    public class ConnectionString
    {
        public string TransferHomeDbConnection { get; set; }
        public string ATTDbConnection { get; set; }
    }
}
