﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Infrastructure.BLL.Interfaces;
using TransferHome.Infrastructure.DAL.Interfaces;
using TransferHome.Models.Configurations;
using TransferHome.Models.Contracts.Apple;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.Contracts.Response;
using TrasnferHome.Infrastructure.DAL.Interfaces;
using TrasnferHome.Models.Contracts;
using TrasnferHome.Models.Utility;

namespace TransferHome.Infrastructure.BLL.Implementation
{
    public class Bl_Common : IBL_Common
    {
        private readonly IDL_Common Dl;
        private readonly IDL_User DL_User;
        private readonly IDL_Transfer DL_Transfer;
        private readonly InAppPurchaseConfig InAppPurchaseConfig;
        private readonly ReceiptVerificationConfig ReceiptVerificationConfig;

        public Bl_Common(IDL_Common dl, IDL_User dL_User, IOptions<InAppPurchaseConfig> inAppPurchaseConfig, IOptions<ReceiptVerificationConfig> receiptVerificationConfig, IDL_Transfer dL_Transfer)
        {
            ReceiptVerificationConfig = receiptVerificationConfig.Value;
            Dl = dl;
            DL_User = dL_User;
            DL_Transfer = dL_Transfer;
            InAppPurchaseConfig = inAppPurchaseConfig.Value;
        }

        public async Task<GenericApiResponse<GetTopupAmountsResponseModel>> GetTopupAmounts()
        {
            try
            {
                var response = await Dl.TopUpAmounts();
                if (response != null && response.Count() > 0)
                {
                    var data = new GetTopupAmountsResponseModel()
                    {
                        TopUpAmounts = response.Select(item => new TopupAmount()
                        {
                            Amount = item.Amount,
                            Id = item.Id,
                            IsActive = item.IsActive
                        })
                    };
                    return GenericApiResponse<GetTopupAmountsResponseModel>.Success(data, "Found topup amounts");
                }
                else
                {
                    return GenericApiResponse<GetTopupAmountsResponseModel>.Failure(new GetTopupAmountsResponseModel() { TopUpAmounts = new List<TopupAmount>() }, "Topup amounts not found", ApiStatusCodes.TopUpAmountsNotFound);
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<InAppPurchaseConfig>> GetInAppPurchaseOptions(GetInAppPurchaseOptionsRequestModel model, string userId)
        {
            var user = await DL_User.GetUserById(Convert.ToInt32(userId));
            GenericApiResponse<InAppPurchaseConfig> response;

            if (InAppPurchaseConfig.IOSAppversion == model.version)
            {
                InAppPurchaseConfig ResponseInAppPurchaseConfig = new InAppPurchaseConfig
                {
                    ApiVersion = InAppPurchaseConfig.ApiVersion,
                    IOSAppversion = InAppPurchaseConfig.IOSAppversion,
                    inAppPurchase = InAppPurchaseConfig.inAppPurchase.Where(c => c.currency == user.BalanceCurrency).ToArray(),
                    topup_options = new topup_options[] { },
                    transfer_options = new transfer_options[] { InAppPurchaseConfig.transfer_options[0] }
                };
                response = GenericApiResponse<InAppPurchaseConfig>.Success(ResponseInAppPurchaseConfig, "Success");
            }
            else
            {
                InAppPurchaseConfig ResponseInAppPurchaseConfig = new InAppPurchaseConfig
                {
                    ApiVersion = InAppPurchaseConfig.ApiVersion,
                    IOSAppversion = InAppPurchaseConfig.IOSAppversion,
                    topup_options = InAppPurchaseConfig.topup_options,
                    inAppPurchase = new InAppPurchase[] { },
                    transfer_options=InAppPurchaseConfig.transfer_options
                };
                response = GenericApiResponse<InAppPurchaseConfig>.Success(ResponseInAppPurchaseConfig, "Success");
            }
            return response;
        }

        public async Task<GenericApiResponse<ValidateAppleRecieptResponseModel>> ValidateAppleReciept(ValidateAppleRecieptRequestModel model)
        {
            ValidateAppleRecieptResponseModel response = new ValidateAppleRecieptResponseModel() ;

            try
            {
                string base64Encoded = model.Token;
                string base64Decoded;
                byte[] data = System.Convert.FromBase64String(base64Encoded);
                base64Decoded = System.Text.ASCIIEncoding.ASCII.GetString(data);

                string Url = string.Empty;

                if (ReceiptVerificationConfig.IsLive == AppleReceiptValidationEnvironment.Live)
                {
                    Url = ReceiptVerificationConfig.LiveUrl;
                }
                else
                {
                    Url = ReceiptVerificationConfig.SandboxUrl;
                }

                var json = new JObject(new JProperty("receipt-data", model.Token)).ToString();

                using (var httpRequest = new HttpRequestMessage(HttpMethod.Post, Url))
                {
                    httpRequest.Content = new StringContent(json, Encoding.UTF8, "application/json");


                    using (var httpClient = new HttpClient())
                    {
                        var result = await httpClient.SendAsync(httpRequest);

                        if (result.IsSuccessStatusCode)
                        {
                            var responseString = await result.Content.ReadAsStringAsync();
                            var responseModel = JsonConvert.DeserializeObject<InAppPurchaseReceipt>(responseString);
                            var inappModel = responseModel.Receipt.InApp.FirstOrDefault();
                            var product = inappModel.ProductId.Split("_");
                            var currency = product[0];
                            var transactionNumber = inappModel.TransactionId;
                            decimal price = Convert.ToDecimal(product[1]);
                            //return true;

                            var newBalance = await DL_Transfer.CreditUserBalance(new Models.DAOs.DBCredit
                            {
                                Amount = price,
                                Currency = currency,
                                UseId = model.UserId,
                                TransactionNumber = transactionNumber,
                                type = TopUpType.ApplePay
                            });

                            response = new ValidateAppleRecieptResponseModel() { NewBalance = newBalance.ToString(), TopUpAmount = price.ToString(), TransactionId = transactionNumber  };
                            return GenericApiResponse<ValidateAppleRecieptResponseModel>.Success(response, $"you successfully top up of amount{currency} {price}");
                        }
                        else
                        {
                            return GenericApiResponse<ValidateAppleRecieptResponseModel>.Failure(response, "Sorry your Top Up failed.", ApiStatusCodes.ApplePayTopUpFailed);

                            // Use result.StatusCode to handle failure
                            // Your custom error handler here
                            //Logger.Error($"Error sending notification. Status Code: {result.StatusCode}, Message : {result.ReasonPhrase}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return GenericApiResponse<ValidateAppleRecieptResponseModel>.Failure(response, "Sorry your Top Up failed.", ApiStatusCodes.ApplePayTopUpFailed);
            }

        }

        /*public async Task<GenericApiResponse<object>> ValidateAppleReciept(int userId, decimal topUpAmpunt, string currency,string transactionNumber)
        {
            ValidateAppleRecieptResponseModel response;

            try
            {
                
                //step 1 : 
                //if (request == null || request.AppVersion == null || request.AppVersion != ConfigurationManager.AppSettings["payment:itunes:only:version"])
                //    return response;

                var verifyReceiptResponse = new VerifyReceiptResponse();



                    //Check that receipt doesn't exist in database already first
                    
                    if (await ReceiptDoesNotExist(request.Receipt))
                    {
                        var json = new JObject(new JProperty("receipt-data", request.Receipt)).ToString();

                        var result = await httpService.Post(ReceiptVerificationProductionEndpoint, json);

                        var inAppPurchaseReceipt = JsonConvert.DeserializeObject<InAppPurchaseReceipt>(result);

                        var itunesTransactionStatus = "Failed";
                        var itunesStatus = "COMPLETED";
                        var itunesReason = String.Format("Failed - {0}", inAppPurchaseReceipt.Status);
                        var topupAmount = 0m;

                        if (inAppPurchaseReceipt.Status == 21007 && platformTesterService.CanTestInAppPurchase(request.Msisdn))
                        {
                            //Valid sandbox receipt and tester
                            //Try again using the sandbox endpoint
                            result = await httpService.Post(ReceiptVerificationSandboxEndpoint, json);

                            inAppPurchaseReceipt = JsonConvert.DeserializeObject<InAppPurchaseReceipt>(result);
                        }

                        if (inAppPurchaseReceipt.Status == 0 &&
                            !String.IsNullOrEmpty(inAppPurchaseReceipt.Receipt.Bid) &&
                            inAppPurchaseReceipt.Receipt != null &&
                            !String.IsNullOrEmpty(inAppPurchaseReceipt.Receipt.Bid) &&
                            inAppPurchaseReceipt.Receipt.Bid == "com.distribution.talkhomeapps")
                        {
                            var productId = inAppPurchaseReceipt.Receipt.ProductId;
                            var purchaseAmount = productId.Substring(4, productId.Length - 4);
                            topupAmount = Convert.ToDecimal(purchaseAmount);
                            itunesTransactionStatus = "Success";
                            itunesReason = "Success";

                            var success = await StoreInAppPurchaseData(request, inAppPurchaseReceipt, topupAmount,
                                itunesTransactionStatus, itunesStatus, itunesReason);

                            //Update account balance here!
                            var userAccount = await userAccountService.GetUserAccount(request.Msisdn);

                            success =
                                await ApplyInAppPurchaseCredit(topupAmount, inAppPurchaseReceipt.Receipt.TransactionId, userAccount);

                            userAccount = await userAccountService.GetUserAccountBalance(request.Msisdn);
                            verifyReceiptResponse.Credit = topupAmount.ToString();
                            verifyReceiptResponse.Balance = userAccount.UserAccountBalance.Balance.ToString();
                            verifyReceiptResponse.TransactionId = Guid.NewGuid().ToString();
                            response.Status = "Success";
                            response.Message = languageProvider.Message.InAppPurchaseSuccessful();
                            response.Payload = verifyReceiptResponse;
                        }
                        else
                        {
                            var success = await StoreInAppPurchaseData(request, inAppPurchaseReceipt, topupAmount,
                                itunesTransactionStatus, itunesStatus, itunesReason);

                            verifyReceiptResponse.TransactionId = Guid.NewGuid().ToString();
                            response.Status = "Failure";
                            response.Message = languageProvider.Message.ReceiptVerificationFailed();
                            response.Payload = verifyReceiptResponse;
                        }
                    }


                var newBalance = await DL_Transfer.CreditUserBalance(new Models.DAOs.DBCredit
                {
                    Amount = topUpAmpunt,
                    Currency = currency,
                    UseId = userId,
                    TransactionNumber = transactionNumber,
                    type = TopUpType.ApplePay
                });
                response = new ValidateAppleRecieptResponseModel() { NewBalance = newBalance.ToString(), TopUpAmount = topUpAmpunt.ToString() };
                return GenericApiResponse<object>.Success(response, $"you successfully top up of amount{currency} {topUpAmpunt}");
            }
            catch
            {
                return GenericApiResponse<object>.Failure(new { },"Sorry your Top Up failed.",ApiStatusCodes.ApplePayTopUpFailed);
            }

        }*/
    }
}
