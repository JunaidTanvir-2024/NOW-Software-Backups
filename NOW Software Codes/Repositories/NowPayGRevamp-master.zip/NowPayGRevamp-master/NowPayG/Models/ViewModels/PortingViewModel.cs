﻿using Microsoft.AspNetCore.Mvc.Rendering;
using NowPayG.Models.Porting;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class PortingViewModel : BaseViewModel
    {
        public PortinViewModel PortIn { get; set; }
        public PortOutViewModel PortOut { get; set; }

        public IEnumerable<SelectListItem> UserProductsList { get; set; }
    }

    public class PortinViewModel
    {
        public string Email { get; set; }
        public string NTMsisdn { get; set; }
        [Required(ErrorMessage = "Select Date"), DataType(DataType.Date, ErrorMessage = "Invalid Date")]
        public string UserPortingDate { get; set; }
        [Required(ErrorMessage = "Enter Port Msisdn"), MaxLength(length: 12, ErrorMessage = "Maximum 12 characters allowed"), MinLength(length: 10, ErrorMessage = "Minimum 10 characters allowed")]
        public string PortMsisdn { get; set; }
        [Required(ErrorMessage = "Enter Authorization Code"), StringLength(maximumLength: 10, ErrorMessage = "Maximum Length Exceeds")]
        public string Code { get; set; }
        public Products Product { get; set; }
        public MediumTypes Medium { get; set; }
        [Required(ErrorMessage = "Select Reason")]
        public PortReason Reason { get; set; }
    }

    public class PortOutViewModel
    {
        public string Email { get; set; }
        [Required(ErrorMessage = "Enter Port Msisdn"), MaxLength(length: 12, ErrorMessage = "Maximum 12 characters allowed"), MinLength(length: 10, ErrorMessage = "Minimum 10 characters allowed")]
        public string NTMsisdn { get; set; }
        [Required(ErrorMessage = "Select Date"), DataType(DataType.Date, ErrorMessage = "Invalid Date")]
        public string UserPortingDate { get; set; }
        public int ReasonId { get; set; }
        public Products Product { get; set; }
        public MediumTypes Medium { get; set; }
        public CodeTypes CodeType { get; set; }
    }
}
