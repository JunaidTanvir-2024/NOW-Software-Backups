﻿using Newtonsoft.Json;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using PaymentsApi.Models.Contracts.Paypal.Response.Api;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts.Paypal.Response.User
{
    public class UserPaypalResumeResponse
    {
        [JsonProperty("customerId")]
        public string CustomerId { get; set; }
        [JsonProperty("transactionId")]
        public string TransactionId { get; set; }
        [JsonProperty("transactionAmount")]
        public string TransactionAmount { get; set; }

        [JsonProperty("outcome")]
        public OutcomeModel OutcomeModel { get; set; }       

        [JsonProperty("paymentMethod")]
        public PaypalPaymentMethodResponse PaymentMethod { get; set; }

        [JsonProperty("basketResponse")]
        public List<BasketItemsResponse> BasketResponse { get; set; }
    }
}
