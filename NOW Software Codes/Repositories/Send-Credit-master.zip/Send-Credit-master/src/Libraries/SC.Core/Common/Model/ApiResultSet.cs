﻿
using System.Text.Json.Serialization;

namespace SC.Core.Common.Model;
public class ApiResultSet<T> : BaseApiResult
{
    [JsonPropertyName("paginationInfo")]
    public  PaginationInfo PaginationInfo { get; set; }

    [JsonPropertyName("payload")]
    public List<T> Payload { get; set; }
}

