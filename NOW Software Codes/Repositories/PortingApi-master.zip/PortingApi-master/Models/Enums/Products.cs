﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum Products
    {
        TalkHome=1,
        NowPayg=2
    }
}
