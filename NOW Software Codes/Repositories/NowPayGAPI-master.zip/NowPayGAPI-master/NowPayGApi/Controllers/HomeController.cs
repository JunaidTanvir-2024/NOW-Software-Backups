﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayGApi.Controllers
{
    public class HomeController : Controller
    {
        [Route("healthcheck")]
        public async Task<IActionResult> HealthCheck()
        {
            return Ok();
        }
    }
}
