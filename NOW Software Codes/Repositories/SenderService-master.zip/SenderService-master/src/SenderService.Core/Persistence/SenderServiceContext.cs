using Microsoft.EntityFrameworkCore;
using SenderService.Core.Common.Models;
using SenderService.Core.Features.EmailValidation.Response;
using SenderService.Core.Persistence.Entities;

namespace SenderService.Core.Persistence;

public class SenderServiceContext : DbContext
{
    public SenderServiceContext(DbContextOptions<SenderServiceContext> options) : base(options)
    {
    }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<EmailStatus>().HasNoKey();
        //modelBuilder.ApplyConfiguration(new EmailConfiguration());
        //modelBuilder.ApplyConfiguration(new EmailRecipientConfiguration());
        //modelBuilder.ApplyConfiguration(new EmailValidationConfiguration());
        //modelBuilder.ApplyConfiguration(new ProductCodeConfiguration());
        //modelBuilder.ApplyConfiguration(new BlockDomainConfiguration());
    }
    public virtual DbSet<Email> Emails { get; set; }

    public virtual DbSet<EmailRecipient> EmailRecipients { get; set; }

    public virtual DbSet<EmailValidation> EmailValidations { get; set; }

    public virtual DbSet<ProductCode> ProductCodes { get; set; }

    public virtual DbSet<Entities.BlockDomain> BlockedDomains { get; set; }
    public virtual DbSet<EmailData> EmailData { get; set; }

}
