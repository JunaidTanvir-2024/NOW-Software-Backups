﻿using SC.Core.Features.Lookups;
using SC.Core.Features.Operators.OperatorByProductCategory;
using static SC.Core.Features.Operators.GetOperatorsRequest;

namespace SC.Api.Model.Operator;
public class MsisdnLookupModel
{
    public string Msisdn { get; set; } = default!;
    public int Vendor { get; set; }
    public MsisdnLookup.Query map()
    {
        return new MsisdnLookup.Query
        {
            Msisdn = Msisdn,
            Vendor = Vendor,
        };
    }
}

