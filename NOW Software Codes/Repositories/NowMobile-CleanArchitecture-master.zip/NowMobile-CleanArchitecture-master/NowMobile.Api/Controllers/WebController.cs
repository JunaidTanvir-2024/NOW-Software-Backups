﻿

using Application.Features.Web.WebLinks;

namespace NowMobile.Api.Controllers;

public class WebController : VersionedApiController
{
    [HttpGet("links"), AllowAnonymous, OpenApiOperation("Get Weblinks", "")]
    public async Task<IActionResult> GetWebLinks()
    {
        return Ok(await Mediator.Send(new WebLinksRequest()));
    }
}