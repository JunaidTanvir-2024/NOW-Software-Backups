﻿using SC.Core.Features.CustomerOrder.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerCard.Request;
public sealed class MarkCardDefaultRequest : IRequest<IResultWrapper>
{

    public long CardID { get; set; } = default!;

}
public sealed class MarkCardDefaultRequestValidator : AbstractValidator<MarkCardDefaultRequest>
{
    public MarkCardDefaultRequestValidator()
    {
        RuleFor(x => x.CardID).NotEmpty();
    }
}
