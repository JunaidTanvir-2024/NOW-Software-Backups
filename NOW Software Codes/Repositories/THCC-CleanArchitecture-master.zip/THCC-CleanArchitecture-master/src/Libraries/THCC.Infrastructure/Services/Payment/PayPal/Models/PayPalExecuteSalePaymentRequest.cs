﻿
using System.ComponentModel.DataAnnotations;

using Newtonsoft.Json;

namespace THCC.Infrastructure.Services.Payment.PayPal.Models
{
    public class PayPalExecuteSalePaymentRequest
    {
        [JsonProperty("payer_id")]
        [Required]
        public string? PayerId { get; set; }

        [JsonProperty("payment_id")]
        [Required]
        public string? PaymentId { get; set; }

        [JsonProperty("customerUniqueRef")]
        [Required]
        public string? CustomerUniqueRef { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string? ProductCode { get; set; }

        [JsonProperty("isDirectFullfilment")]
        [Required]
        public bool IsDirectFullfilment { get; set; } = false;
    }
}
