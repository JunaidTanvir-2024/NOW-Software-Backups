﻿using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.StackableDiscounts.Common;

public class StackableDiscountOrderInfo
{
    public long? Amount { get; set; } = 1;
    public string? SkuId { get; set; }
    public int? Quantity { get; set; } = 1;
    public Metadata? Metadata { get; set; }
}
