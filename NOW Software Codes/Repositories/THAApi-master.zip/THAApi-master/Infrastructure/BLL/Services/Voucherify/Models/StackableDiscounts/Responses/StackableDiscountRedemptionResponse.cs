﻿using System.Text.Json.Serialization;
using static Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common.StackableDiscountResponse;

namespace Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Responses
{
	public class StackableDiscountRedemptionResponse
    {
        [JsonPropertyName("redemptionId")]
        public string RedemptionId { get; set; }
        
        [JsonPropertyName("referrer")]
        public ReferrerInfo Referrer { get; set; }
        
        [JsonPropertyName("order")]
        public ApplicableOrder Order { get; set; }

        [JsonPropertyName("campaignName")]
        public string CampaignName { get; set; }

        public class ReferrerInfo
        {
            [JsonPropertyName("id")]
            public string Id { get; set; }
            
            [JsonPropertyName("name")]
            public string Name { get; set; }
            
            [JsonPropertyName("email")]
            public string Email { get; set; }
            
            [JsonPropertyName("sourceId")]
            public string SourceId { get; set; }
        }
    }
}
