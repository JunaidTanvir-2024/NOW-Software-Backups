using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;
using JM.Core.Utilities.Interfaces.Services;
using JM.Core.Utilities.Settings;

using Mediator;

using Microsoft.Extensions.Options;

using RW;

namespace JM.Core.Features.Auth.Otp;

public abstract class VerifyOtp
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public string Code { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public AppEnum.OtpType Type { get; set; }
    }

    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Code).NotNull().NotEmpty();
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {

    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IOptions<OtpSetting> otpSetting, ITimeWarpService timeWarpService) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly ITimeWarpService _timeWarpService = timeWarpService;
        private readonly OtpSetting _otpSetting = otpSetting.Value;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var userInfo = await _unitOfWork.UserRepository.GetUser(x => x.NormalizedEmail!.Equals(query.Email.ToUpperInvariant()));

            if (userInfo is null)
            {
                return ResultWrapper.Failure(AppConstant.StatusKey.OtpInvalid, AppConstant.StatusCode.BadRequest);
            }

            var otpInfo = await _unitOfWork.OtpRepository.GetOtp(x => x.Code == query.Code && x.Type == (ushort)query.Type && x.UserId == userInfo.Id);

            if (otpInfo is null)
            {
                return ResultWrapper.Failure(AppConstant.StatusKey.OtpInvalid, AppConstant.StatusCode.BadRequest);
            }

            var unblockTime = GetOtpUnblockTime(otpInfo?.BlockTime);

            if (otpInfo?.Code != query.Code
                || unblockTime > _timeWarpService.UtcNow
                || otpInfo.IsAlreadyUsed
                || otpInfo.UsageCount > _otpSetting.CreationLimit)
            {
                otpInfo!.UsageCount++;

                UpdateOtpInfo(otpInfo);
                return ResultWrapper.Failure(AppConstant.StatusKey.OtpInvalid, AppConstant.StatusCode.BadRequest);
            }

            // As Otp verified, Making it IsAlreadyUsed true to update in database.
            otpInfo.IsAlreadyUsed = true;

            // Mark user active on otp verification - By default it is inactive
            userInfo!.EmailConfirmed = query.Type == AppEnum.OtpType.Signup || userInfo!.EmailConfirmed;

            _unitOfWork.BeginTransaction();
            try
            {
                _unitOfWork.OtpRepository.UpdateOtp(otpInfo);
                _unitOfWork.UserRepository.UpdateUser(userInfo);
                _unitOfWork.SaveChanges();
                _unitOfWork.Commit();
            }
            catch (Exception)
            {
                _unitOfWork.Rollback();
                throw;
            }

            return ResultWrapper.Success(AppConstant.StatusKey.OtpValid, AppConstant.StatusCode.Success);
        }

        private DateTime? GetOtpUnblockTime(DateTime? blockTime)
        {
            var remainingBlockTime = blockTime?.AddMinutes(_otpSetting.BlockTimeInMinutes) - _timeWarpService.UtcNow;

            var retryAfterTime = remainingBlockTime?.TotalMinutes ?? 0;

            return _timeWarpService.UtcNow.AddMinutes(retryAfterTime);
        }
        private void UpdateOtpInfo(Entities.Otp? otpInfo)
        {
            var unblockTime = GetOtpUnblockTime(otpInfo?.BlockTime);

            if (otpInfo is not null)
            {
                if (otpInfo.UsageCount >= _otpSetting.RetryLimit)
                {
                    if (unblockTime <= _timeWarpService.UtcNow && otpInfo.IsBlocked == true)
                    {
                        _unitOfWork.OtpRepository.DeleteOtp(otpInfo);
                        _unitOfWork.SaveChanges();
                    }

                    otpInfo.IsRetryLimitExceeded = true;
                    otpInfo.IsBlocked = true;
                    otpInfo.BlockTime = _timeWarpService.UtcNow.AddMinutes(_otpSetting.BlockTimeInMinutes);
                }
                _unitOfWork.OtpRepository.UpdateOtp(otpInfo);
                _unitOfWork.SaveChanges();
            }
        }
    }
    #endregion
}
