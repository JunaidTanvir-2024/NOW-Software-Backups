﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Mobiquity.Request
{
    public class MobiquityTopUpRequest
    {
        public MobiquityTopUpRequest()
        {

        }
        public string serviceCode { get; set; }
        public string transactionAmount { get; set; }
        public string initiator { get; set; }
        public string bearerCode { get; set; }
        public string language { get; set; }
        public string currency { get; set; }
        public string custRefNo { get; set; }
        public string RechargeType { get; set; }
        public string remarks { get; set; }
        public transactor transactor { get; set; }
        public receiver receiver { get; set; }
        public rechargeReceiver rechargeReceiver { get; set; }
    }


    public class transactor
    {
        public string idType { get; set; }
        public string productId { get; set; }
        public string idValue { get; set; }
        public string mpin { get; set; }
        public string bundle { get; set; }
    }

    public class receiver
    {
        public string idType { get; set; }
        public string idValue { get; set; }
    }
    public class rechargeReceiver
    {
        public string idType { get; set; }
        public string idValue { get; set; }
    }

}
