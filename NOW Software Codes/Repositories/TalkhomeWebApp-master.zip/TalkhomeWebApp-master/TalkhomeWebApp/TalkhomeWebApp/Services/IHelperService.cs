﻿
using TalkhomeWebApp.Models;

namespace TalkhomeWebApp.Services
{
    public interface IHelperService
    {
        string GetCountryCode(string msisdn);
        string GetCountryNameByCountryCode(string code);
        string GetCountryCodeByCountryName(string name);
        Country GetCountryByCountryName(string name);
        TopupCountryVariation GetTopupCountry(string countryCode,string countryName);
        RateLandingPageVariation GetLandingPageContent(string countryCode, string countryName,string callingRate,string minorCurrencyUnit);
    }
}