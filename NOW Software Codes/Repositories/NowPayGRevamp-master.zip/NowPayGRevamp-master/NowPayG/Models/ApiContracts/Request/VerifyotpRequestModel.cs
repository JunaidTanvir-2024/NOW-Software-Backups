﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Request
{
    public class VerifyotpRequestModel
    {
        [Required]
        public string Email { get; set; }

        [Required]
        public string Otpcode { get; set; }
        
    }
}
