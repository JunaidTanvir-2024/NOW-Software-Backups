namespace MM.Core.Common.Definitions.Constants;
public static partial class AppEnums
{
    public enum Vendors
    {
        DTOne = 1
    }
}
