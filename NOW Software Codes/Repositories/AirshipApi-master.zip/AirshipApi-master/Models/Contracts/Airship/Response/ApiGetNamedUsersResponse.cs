﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Response
{
    public class ApiGetNamedUsersResponse
    {
        public bool ok { get; set; }
        public List<NamedUsers> named_users { get; set; }
    }


    public class NamedUsers
    {
        public string named_user_id { get; set; }
        public Dictionary<string, List<string>> tags { get; set; }
        public DateTime? created { get; set; }
        public DateTime? last_modified { get; set; }
        public List<Channel> channels { get; set; }
    }

}
