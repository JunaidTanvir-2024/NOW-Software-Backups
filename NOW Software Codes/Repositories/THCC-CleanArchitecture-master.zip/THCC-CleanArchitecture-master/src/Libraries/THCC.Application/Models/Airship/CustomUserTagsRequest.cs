﻿
using Newtonsoft.Json;

namespace THCC.Application.Models.Airship;

public class CustomUserTagsRequest
{
    [JsonProperty("NamedUser")]
    public string NamedUser { get; set; } = string.Empty;

    [JsonProperty("ProductCode")]
    public string ProductCode { get; set; } = "THCC";

    [JsonProperty("TagGroup")]
    public string TagGroup { get; set; } = string.Empty;

    [JsonProperty("Tags")]
    public List<string>? Tags { get; set; }
}
