﻿using Application.Features.Payment.Card.CustomerCards;

namespace Application.Features.Payment.Card.MakeCardDefault;

public class MakeCardDefaultRequest : IRequest<Result<List<CustomerCard>>>
{
    public string CardCv2 { get; set; } = default!;
    public string CardToken { get; set; } = default!;
}
