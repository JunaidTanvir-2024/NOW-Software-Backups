using FH.Core.DependencyResolver;
using FH.Core.DTOs.Database;

namespace FH.Core.Interfaces.Database;
public interface ITransactionRepository : ServiceType.IScoped
{
    Task TransactionInsert(ProductTransactionInsertDto.Request request);
    Task<ProductTransactionUpdateDto.Response?> TransactionUpdate(ProductTransactionUpdateDto.Request request);
}
