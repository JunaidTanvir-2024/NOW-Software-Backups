﻿using Application.Common.Interfaces.Payment;
using Application.Features.Payment.Card.Models;

namespace Application.Features.Payment.Card.NewCardPayment;

public class NewCardPaymentRequestHandler : IRequestHandler<NewCardPaymentRequest, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;

    public NewCardPaymentRequestHandler(IPaymentService paymentService)
    {
        _paymentService = paymentService;
    }

    public async Task<Result<CardResponse>> Handle(NewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        request.PaymentCardInfo.CardNumber = request.PaymentCardInfo.CardNumber!.Trim().Replace(" ", "");
        
        return await _paymentService.HandleCardPaymentRequest(
                request.PaymentCardInfo,
                null!,
                request.PaymentAddressInfo,
                request.TopupInfo!,
                request.BundleInfo!,
                request.CreditSimInfo!,
                request.Msisdn!,
                request.Email!,
                request.IpAddress!,
                null!,
                null!,
                false,
                request.ConversionID,
                (int)request.ConversionPlatFormID);
    }
}