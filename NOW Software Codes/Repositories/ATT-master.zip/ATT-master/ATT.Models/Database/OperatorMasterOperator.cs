﻿namespace ATT.Models.Database
{
    public class OperatorMasterOperator
    {
        public int Id { get; set; }
        public int OperatorId { get; set; }
        // public int ServiceProviderID { get; set; }
        public int MasterOperatorId { get; set; }
    }

    public class SochitelCustomerRate
    {
        public int OperatorId { get; set; }

        public string OperatorMasterID { get; set; }
        public decimal DestinationReceiveValue { get; set; }
        public string ActualChargeValue { get; set; }
        public bool isActive { get; set; }
        public decimal CustomerChargeValue { get; set; }
    }
}
