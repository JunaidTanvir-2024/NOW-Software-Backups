﻿using System.ComponentModel.DataAnnotations;

namespace SenderService.Core.Features.Email.Request;

public class GetSpecificEmailRecordRequest
{
    [EmailAddress]
    public string? Email { get; set; }
}
