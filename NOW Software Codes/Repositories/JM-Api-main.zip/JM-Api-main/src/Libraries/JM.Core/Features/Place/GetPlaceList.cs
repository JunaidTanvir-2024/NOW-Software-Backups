using System.Data;

using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;
using JM.Core.Utilities.Interfaces.Services;

using Mediator;

using RW;
namespace JM.Core.Features.Place;

public abstract class GetPlaceList
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long? TripId { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public required string Name { get; set; }
        public string? Description { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public string? Type { get; set; }
        public string? ImageUrl { get; set; }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IGooglePlacesIntegration googlePlacesIntegration) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IGooglePlacesIntegration _googlePlacesIntegration = googlePlacesIntegration;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            if (query.TripId <= 0 || query.TripId is null)
            {
                var places = await _unitOfWork.PlaceRepository.GetPlaceList(x => x.IsActive);

                if (places is not null)
                {
                    return ResultWrapper.Success(places.Select(x => new Response()
                    {
                        Id = x.Id,
                        Name = x.Name,
                        Description = x.Description,
                        ImageUrl = x.ImageUrl,
                        Latitude = x.Latitude,
                        Longitude = x.Longitude
                    }));
                }
                return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
            }

            var tripList = await _unitOfWork.PlaceRepository.GetPlaceList(x => x.TripId == query.TripId);

            if (tripList is not null)
            {
                return ResultWrapper.Success(tripList.Select(x => new Response()
                {
                    Id = x.Id,
                    Name = x.Place.Name,
                    Description = x.Place.Description,
                    ImageUrl = x.Place.ImageUrl,
                    Latitude = x.Place.Latitude,
                    Longitude = x.Place.Longitude
                }));
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
    }
    #endregion
}
