﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.DAO
{
    public class GetTempMsisdnDbResponse
    {
        public string Msisdn { get; set; }
        public int ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
    }
}
