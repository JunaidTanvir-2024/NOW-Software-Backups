using FluentValidation;

namespace Voucherify.Api.Features.Products.Requests;

public class GetProductRequest
{
    public string? ProductNameOrId { get; set; }
}

internal class GetProductRequestValidator : AbstractValidator<GetProductRequest>
{
    public GetProductRequestValidator()
    {
        RuleFor(p => p.ProductNameOrId).NotEmpty().NotNull();
    }
}