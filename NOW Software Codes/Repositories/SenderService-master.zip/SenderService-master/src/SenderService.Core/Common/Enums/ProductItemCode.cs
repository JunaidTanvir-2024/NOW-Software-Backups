﻿namespace SenderService.Core.Common.Enums;
public enum ProductItemCode
{
    THM
}