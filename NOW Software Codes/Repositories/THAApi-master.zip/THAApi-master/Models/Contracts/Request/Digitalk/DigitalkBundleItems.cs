﻿using System.Collections.Generic;

namespace Models.Contracts.Request.Digitalk
{
	public class DigitalkBundleItems
	{
		public List<DigitalkBundle> Items { get; set; }
	}
}
