﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class ValidateAppleRecieptResponseModel
    {
        public string TopUpAmount { get; set; }
        public string NewBalance { get; set; }
        public string TransactionId { get; set; }
    }
}
