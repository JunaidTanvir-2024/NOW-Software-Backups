using Application.Common.Interfaces.Repositories;
using Application.Common.Settings;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;
using CancelBundleApi.Models.ResponseModels;
using Domain.Aggregate;
using MapsterMapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Application.Features.Payment.Invoice;

public class InvoiceRequestHandler : IRequestHandler<InvoiceRequest, Result<InvoiceResponse>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<InvoiceRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly CallBackSettings _callbackSettings;

    public InvoiceRequestHandler(
        IUnitOfWork uow,
        IMapper mapper,
        ICommonService commonService,
        IOptions<CallBackSettings> callbackSettings,
        IStringLocalizer<InvoiceRequestHandler> localizer)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
        _commonService = commonService;
        _callbackSettings = callbackSettings.Value;
    }

    public async Task<Result<InvoiceResponse>> Handle(InvoiceRequest request, CancellationToken cancellationToken)
    {
        InvoiceResponse invoiceResponse = new InvoiceResponse();
        var (isSuccess, orderDetails, orderItemDetails) = await _uow.PaymentRepo.GetOrderDetails(request.OrderId);
        if (isSuccess)
        {
            (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();
            invoiceResponse.InvoiceDetails = _mapper.Map<InvoiceDetails>(orderDetails);
            invoiceResponse.InvoiceDetails.PaymentMethodTypeName = _commonService.GetPaymentMethodName(orderDetails.PaymentMethodType);
            invoiceResponse.InvoiceDetails.TransactionTypeName = _commonService.GetTransactionTypeName(orderDetails.TransactionType);

            InvoiceBundleInfo invoiceBundleInfo = new InvoiceBundleInfo();
            InvoiceTopupInfo invoiceTopupInfo = new InvoiceTopupInfo();
            InvoiceSIMInfo invoiceSIMInfo = new InvoiceSIMInfo();
            InvoiceCardInfo invoiceCardInfo = new InvoiceCardInfo();
            float VatAmount = 0;
            foreach (var item in orderItemDetails)
            {
                if (item.BundleId != Guid.Empty && item.BundleId != null)
                {
                    Domain.Entities.Bundle bundleInfo = new Domain.Entities.Bundle();
                    bundleInfo = await _uow.BundleRepo.GetBundleById(Convert.ToString(item.BundleId)!);
                    invoiceBundleInfo.BundleInfo = bundleInfo;
                    //invoiceBundleInfo.Amount = item.Amount;
                    invoiceBundleInfo.Discount = item.Discount;
                    invoiceBundleInfo.TotalAmount = item.TotalAmount;
                    invoiceResponse.InvoiceBundleInfo = invoiceBundleInfo;
                    invoiceBundleInfo.VatAmount = (float) Math.Round((item.Amount - (item.Amount / 1.2)), item.Amount<0.01?3:2);
                    invoiceBundleInfo.Amount = item.Amount - invoiceBundleInfo.VatAmount;
                }
                if (item.BundleId == null)
                {
                    // invoiceTopupInfo.Amount = item.Amount;
                    invoiceTopupInfo.VatAmount = (float) Math.Round((item.Amount - (item.Amount / 1.2)), item.Amount < 0.01 ? 3 : 2);
                    invoiceTopupInfo.Amount = item.Amount - invoiceTopupInfo.VatAmount;
                    invoiceTopupInfo.Discount = item.Discount;
                    invoiceTopupInfo.TotalAmount = item.TotalAmount;


                    invoiceResponse.InvoiceTopupInfo = invoiceTopupInfo;
                }
            }
            if (invoiceResponse.InvoiceDetails.TransactionType == (int) TransactionType.SIMWithPlan
                || invoiceResponse.InvoiceDetails.TransactionType == (int) TransactionType.SIMWithCreditandPlan
                || invoiceResponse.InvoiceDetails.TransactionType == (int) TransactionType.SIMWithCredit)
            {
                invoiceSIMInfo.Description = "Free 5G SIM";
                invoiceResponse.InvoiceSIMInfo = invoiceSIMInfo;
            }
            if (!String.IsNullOrEmpty(orderDetails.OrderData))
            {
                var orderData = JsonConvert.DeserializeObject<OrderData>(orderDetails.OrderData!)!;
                if (orderData != null)
                {
                    if (orderDetails.PaymentMethodType == (int) PaymentMethod.Card)
                    {
                        invoiceCardInfo.CardMaskedPan = String.IsNullOrEmpty(orderData.CardMaskedPan)
                            ? "Card Payment" : orderData.CardMaskedPan;
                        invoiceCardInfo.ImageURL = (IsAppRequest ? _callbackSettings.AppBaseUrl!
               : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(orderData.CardScheme!);
                        invoiceResponse.InvoiceCardInfo = invoiceCardInfo;
                    }
                    if (orderData.AutoTopupInfo != null)
                    {
                        VatAmount = (float) Math.Round((orderData.AutoTopupInfo.TopupAmount - (orderData.AutoTopupInfo.TopupAmount / 1.2)), orderData.AutoTopupInfo.TopupAmount < 0.01 ? 3 : 2);
                        if (IsAppRequest)
                        {
                            if (orderData.AutoTopupInfo.Status)
                            {
                                invoiceResponse.InvoiceAutoTopupInfo = new InvoiceAutoTopupInfo
                                {
                                   // Amount = orderData.AutoTopupInfo.TopupAmount,
                                    VatAmount= VatAmount,
                                    Amount= orderData.AutoTopupInfo.TopupAmount - VatAmount
                                };
                        }
                        }
                        else
                        {
                            invoiceResponse.InvoiceAutoTopupInfo = new InvoiceAutoTopupInfo
                            {
                                // Amount = orderData.AutoTopupInfo.TopupAmount
                                VatAmount = VatAmount,
                                Amount = orderData.AutoTopupInfo.TopupAmount - VatAmount
                            };
                        }

                    }
                }
            }
            else
            {
                if (orderDetails.PaymentMethodType == (int) PaymentMethod.Card)
                {
                    invoiceCardInfo.ImageURL = (IsAppRequest ? _callbackSettings.AppBaseUrl!
               : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(null!);
                    invoiceCardInfo.CardMaskedPan = "Card Payment";
                    invoiceResponse.InvoiceCardInfo = invoiceCardInfo;
                }
            }
        }

        return Result<InvoiceResponse>.Success(invoiceResponse!, _localizer[CustomStatusKey.Success]);
    }
}