﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.DependencyInjection.DependencyModules
{
    public static class Extensions
    {
        public static IServiceCollection AddTalkHomeServices(this IServiceCollection services, IConfiguration configuration)
        {
            ConfigurationModule.Configure(services, configuration);
            ServiceModule.Configure(services);
            RepositoryModules.Configure(services);
            return services;
        }
    }
}
