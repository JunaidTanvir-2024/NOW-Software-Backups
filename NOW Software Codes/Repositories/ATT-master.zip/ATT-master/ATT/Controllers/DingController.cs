﻿using ATT.Infrastructure.BLL.Ding;
using ATT.Models.Database;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Threading.Tasks;

namespace ATT.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class DingController : ControllerBase
    {
        private IDingPost_BL _dingPost_BL;
        private ILogger _logger;

        public DingController(IDingPost_BL dingPost_BL, ILogger logger)
        {
            _dingPost_BL = dingPost_BL;
            _logger = logger;
        }

        //#region GetOperatorProducts

        //[HttpGet]
        //[Route("GetFreeSwitchOperatorProducts")]
        //public async Task<IActionResult> GetFreeSwitchOperatorProducts(string destinationMSISDN, string account, string fromMSISDN, string productCode, string productItemCode = null)
        //{
        //    try
        //    {
        //        var response = await _dingPost_BL.DingGetFreeSwitchPhoneOperator(fromMSISDN, account, destinationMSISDN, productCode, productItemCode);

        //        return Ok(response);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Debug($"DingGetFreeSwitchPhoneOperator  Failed  Source:General   Parameters: destinationMSISDN{destinationMSISDN}  account{account} fromMSISDN{fromMSISDN} productCode{productCode} productItemCode{productItemCode}    Message:{ex.ToString()}");
        //        var result = new { errorCode = 1, Message = "API Error" };
        //        return Ok(result);
        //    }

        //}

        //#endregion
        //#region topup

        //[HttpPost]
        //[Route("topup")]
        //public async Task<IActionResult> DingExecuteTopup(ExecuteData request)
        //{
        //    try
        //    {
        //        var response = await _dingPost_BL.DingTopUp(request);

        //        return Ok(response);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Debug($"  DingExecuteTopup  Failed  Source:General   Parameters:{JsonConvert.SerializeObject(request)}   Message:{ex.ToString()}");
        //        var result = new { errorCode = 1, Message = "API Error" };
        //        return Ok(result);
        //    }

        //}

        //#endregion

        [HttpGet]
        [Route("DingGetPromotions")]
        public async Task<IActionResult> DingGetPromotions(string fromMSISDN)
        {
            try
            {
                var response = await _dingPost_BL.DingGetPromotions(fromMSISDN);

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.Debug($"DingGetPromotions  Failed  Source:General   Parameters:     fromMSISDN={fromMSISDN}   Message:{ex.ToString()}");
                var result = new { errorCode = 1, Message = "API Error" };
                return Ok(result);
            }

        }

    }
}