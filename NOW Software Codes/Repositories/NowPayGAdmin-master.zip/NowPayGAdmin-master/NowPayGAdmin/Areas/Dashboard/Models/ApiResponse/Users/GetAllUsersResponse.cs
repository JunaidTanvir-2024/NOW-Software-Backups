﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models.ApiResponse.Users
{
    public class GetAllUsersResponse
    {
        public List<BasketWebPanel.Areas.Dashboard.Models.User> UserList { get; set; }
    }
}