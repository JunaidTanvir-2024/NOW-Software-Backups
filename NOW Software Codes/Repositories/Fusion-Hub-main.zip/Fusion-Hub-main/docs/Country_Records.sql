GO
SET IDENTITY_INSERT [dbo].[country] ON 
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (1, N'AF', N'AFG', 93, N'Afghanistan', N'004', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:40.980' AS DateTime), CAST(N'2023-11-07T03:18:40.980' AS DateTime), N'e44278ae-7078-455b-8d44-eb9845068e90')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (2, N'AL', N'ALB', 355, N'Albania', N'008', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:40.980' AS DateTime), CAST(N'2023-11-07T03:18:40.980' AS DateTime), N'405ae2f3-71ec-40f4-9f8d-f7a3710892e2')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (3, N'DZ', N'DZA', 213, N'Algeria', N'012', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:40.980' AS DateTime), CAST(N'2023-11-07T03:18:40.980' AS DateTime), N'1723e13e-2cc5-4e0b-8d7c-10a1bcd8a284')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (4, N'AS', N'ASM', 1684, N'American Samoa', N'016', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:40.983' AS DateTime), CAST(N'2023-11-07T03:18:40.983' AS DateTime), N'aa8782e9-dd0f-44b0-b6b9-b1450b27bf21')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (5, N'AD', N'AND', 376, N'Andorra', N'020', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:40.983' AS DateTime), CAST(N'2023-11-07T03:18:40.983' AS DateTime), N'bc4c7a52-4430-4de4-ab16-ba25260098cc')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (6, N'AO', N'AGO', 244, N'Angola', N'024', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:40.983' AS DateTime), CAST(N'2023-11-07T03:18:40.983' AS DateTime), N'19ee1951-aa5e-4106-857c-ec93d806b4c1')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (7, N'AI', N'AIA', 1264, N'Anguilla', N'660', N'North America', 1, 0, CAST(N'2023-11-07T03:18:40.983' AS DateTime), CAST(N'2023-11-07T03:18:40.983' AS DateTime), N'6425c216-563b-451b-8731-5549e73d4681')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (8, N'AQ', N'ATA', 672, N'Antarctica', N'010', N'Antarctica', 1, 0, CAST(N'2023-11-07T03:18:40.983' AS DateTime), CAST(N'2023-11-07T03:18:40.983' AS DateTime), N'577e50a4-73f7-4a24-a050-dd407bc54a48')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (9, N'AG', N'ATG', 1268, N'Antigua and Barbuda', N'028', N'North America', 1, 0, CAST(N'2023-11-07T03:18:40.983' AS DateTime), CAST(N'2023-11-07T03:18:40.983' AS DateTime), N'638bd59f-4f78-4070-928b-d568d82549ac')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (10, N'AR', N'ARG', 54, N'Argentina', N'032', N'South America', 1, 0, CAST(N'2023-11-07T03:18:40.987' AS DateTime), CAST(N'2023-11-07T03:18:40.987' AS DateTime), N'd4e452f7-a12d-4ee3-8707-6517b80e6034')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (11, N'AM', N'ARM', 374, N'Armenia', N'051', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:40.987' AS DateTime), CAST(N'2023-11-07T03:18:40.987' AS DateTime), N'42e055ab-068a-4027-8cb1-ebddd04e2f78')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (12, N'AW', N'ABW', 297, N'Aruba', N'533', N'North America', 1, 0, CAST(N'2023-11-07T03:18:40.987' AS DateTime), CAST(N'2023-11-07T03:18:40.987' AS DateTime), N'8fcefac5-2657-482e-beb5-5231bd08fe5f')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (13, N'AU', N'AUS', 61, N'Australia', N'036', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:40.987' AS DateTime), CAST(N'2023-11-07T03:18:40.987' AS DateTime), N'467be32a-5d38-44a6-8f21-de18ff27b2dc')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (14, N'AT', N'AUT', 43, N'Austria', N'040', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:40.987' AS DateTime), CAST(N'2023-11-07T03:18:40.987' AS DateTime), N'f4aee0d7-10f8-4d0c-8eb2-e76cc974f778')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (15, N'AZ', N'AZE', 994, N'Azerbaijan', N'031', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:40.987' AS DateTime), CAST(N'2023-11-07T03:18:40.987' AS DateTime), N'd8667e7b-9464-469f-abbf-d30be4f1b811')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (16, N'BS', N'BHS', 1242, N'Bahamas', N'044', N'North America', 1, 0, CAST(N'2023-11-07T03:18:40.990' AS DateTime), CAST(N'2023-11-07T03:18:40.990' AS DateTime), N'250d91f5-bf3f-4a1c-afa1-faa5209ff294')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (17, N'BH', N'BHR', 973, N'Bahrain', N'048', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:40.990' AS DateTime), CAST(N'2023-11-07T03:18:40.990' AS DateTime), N'25a1397b-d354-49d9-837b-ac554ac03f1b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (18, N'BD', N'BGD', 880, N'Bangladesh', N'050', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:40.990' AS DateTime), CAST(N'2023-11-07T03:18:40.990' AS DateTime), N'1220d7c8-428e-456d-981a-fb3f5d4a6d9e')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (19, N'BB', N'BRB', 1246, N'Barbados', N'052', N'North America', 1, 0, CAST(N'2023-11-07T03:18:40.990' AS DateTime), CAST(N'2023-11-07T03:18:40.990' AS DateTime), N'b02c5148-2c51-4d9b-aefe-dfe317b63879')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (20, N'BY', N'BLR', 375, N'Belarus', N'112', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:40.990' AS DateTime), CAST(N'2023-11-07T03:18:40.990' AS DateTime), N'cc6034e4-0d40-4093-8be3-caf94cfdb03c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (21, N'BE', N'BEL', 32, N'Belgium', N'056', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:40.990' AS DateTime), CAST(N'2023-11-07T03:18:40.990' AS DateTime), N'2e4dcd0c-7030-42b1-8633-c6dfddeaa177')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (22, N'BZ', N'BLZ', 501, N'Belize', N'084', N'North America', 1, 0, CAST(N'2023-11-07T03:18:40.990' AS DateTime), CAST(N'2023-11-07T03:18:40.990' AS DateTime), N'56a44225-8f4d-44e8-b731-34a6cc002f1b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (23, N'BJ', N'BEN', 229, N'Benin', N'204', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:40.990' AS DateTime), CAST(N'2023-11-07T03:18:40.990' AS DateTime), N'2d74d98a-a0ba-4455-b9cc-095746a4eedc')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (24, N'BM', N'BMU', 1441, N'Bermuda', N'060', N'North America', 1, 0, CAST(N'2023-11-07T03:18:40.993' AS DateTime), CAST(N'2023-11-07T03:18:40.993' AS DateTime), N'f619f1ae-5219-45c3-b4e8-11462301551d')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (25, N'BT', N'BTN', 975, N'Bhutan', N'064', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:40.993' AS DateTime), CAST(N'2023-11-07T03:18:40.993' AS DateTime), N'01175307-a5f5-4814-9521-b66a4a2cfeb7')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (26, N'BO', N'BOL', 591, N'Bolivia', N'068', N'South America', 1, 0, CAST(N'2023-11-07T03:18:40.993' AS DateTime), CAST(N'2023-11-07T03:18:40.993' AS DateTime), N'a92ec113-584b-4bb6-92ad-c784a3d1f11a')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (27, N'BA', N'BIH', 387, N'Bosnia and Herzegovina', N'070', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:40.993' AS DateTime), CAST(N'2023-11-07T03:18:40.993' AS DateTime), N'691b1b99-f56b-4caa-9227-a193b2f79e04')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (28, N'BW', N'BWA', 267, N'Botswana', N'072', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:40.993' AS DateTime), CAST(N'2023-11-07T03:18:40.993' AS DateTime), N'58f9cd0e-8f8d-4936-832c-28627dbe16e8')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (29, N'BV', N'BVT', 55, N'Bouvet Island', N'074', N'Antarctica', 1, 0, CAST(N'2023-11-07T03:18:40.993' AS DateTime), CAST(N'2023-11-07T03:18:40.993' AS DateTime), N'172a5260-3c53-4d27-b68e-bd9202c2b1f2')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (30, N'BR', N'BRA', 55, N'Brazil', N'076', N'South America', 1, 0, CAST(N'2023-11-07T03:18:40.997' AS DateTime), CAST(N'2023-11-07T03:18:40.997' AS DateTime), N'd7ea2b78-95ac-4a06-b6bb-6b9bcdaae355')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (31, N'IO', N'IOT', 246, N'British Indian Ocean Territory', N'086', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:40.997' AS DateTime), CAST(N'2023-11-07T03:18:40.997' AS DateTime), N'cb5387b4-72b0-4748-a5f9-95fc00f95ab9')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (32, N'BN', N'BRN', 673, N'Brunei', N'096', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:40.997' AS DateTime), CAST(N'2023-11-07T03:18:40.997' AS DateTime), N'20606c1d-dd73-4ba8-b540-82f70f0ec80a')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (33, N'BG', N'BGR', 359, N'Bulgaria', N'100', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:40.997' AS DateTime), CAST(N'2023-11-07T03:18:40.997' AS DateTime), N'6c598fcb-2d97-444c-a586-70a83fa287fe')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (34, N'BF', N'BFA', 226, N'Burkina Faso', N'854', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:40.997' AS DateTime), CAST(N'2023-11-07T03:18:40.997' AS DateTime), N'069a648a-fc73-4b85-93b3-2fe247538010')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (35, N'BI', N'BDI', 257, N'Burundi', N'108', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:40.997' AS DateTime), CAST(N'2023-11-07T03:18:40.997' AS DateTime), N'76c62f18-8b3c-4d84-aa51-51669aa1dba8')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (36, N'KH', N'KHM', 855, N'Cambodia', N'116', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.000' AS DateTime), CAST(N'2023-11-07T03:18:41.000' AS DateTime), N'acd44d25-18cf-4b86-bc06-ca19af8d70d4')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (37, N'CM', N'CMR', 237, N'Cameroon', N'120', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.000' AS DateTime), CAST(N'2023-11-07T03:18:41.000' AS DateTime), N'9cf98624-37b9-4662-ab06-0f279af91eb2')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (38, N'CA', N'CAN', 1, N'Canada', N'124', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.000' AS DateTime), CAST(N'2023-11-07T03:18:41.000' AS DateTime), N'c2b698ab-0ed3-463b-8610-0cde533df096')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (39, N'CV', N'CPV', 238, N'Cape Verde', N'132', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.000' AS DateTime), CAST(N'2023-11-07T03:18:41.000' AS DateTime), N'0f639419-7485-45da-b027-c02c14045418')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (40, N'KY', N'CYM', 1345, N'Cayman Islands', N'136', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.000' AS DateTime), CAST(N'2023-11-07T03:18:41.000' AS DateTime), N'9bb1763c-5d3f-44ad-a26d-828cd94656b5')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (41, N'CF', N'CAF', 236, N'Central African Republic', N'140', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.000' AS DateTime), CAST(N'2023-11-07T03:18:41.000' AS DateTime), N'0618aa85-c310-49f8-9972-0963b5711fc4')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (42, N'TD', N'TCD', 235, N'Chad', N'148', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.000' AS DateTime), CAST(N'2023-11-07T03:18:41.000' AS DateTime), N'e286387d-ad0e-4c70-a5d2-b1c014456b5a')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (43, N'CL', N'CHL', 56, N'Chile', N'152', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.000' AS DateTime), CAST(N'2023-11-07T03:18:41.000' AS DateTime), N'9a38a21a-f8ac-42b6-920d-a3075076b9cd')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (44, N'CN', N'CHN', 86, N'China', N'156', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.000' AS DateTime), CAST(N'2023-11-07T03:18:41.000' AS DateTime), N'bf665845-56eb-44cc-9164-dde5462b71ec')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (45, N'CX', N'CXR', 61, N'Christmas Island', N'162', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.003' AS DateTime), CAST(N'2023-11-07T03:18:41.003' AS DateTime), N'6a7045db-0716-4bca-9bf5-e06da9237e3d')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (46, N'CC', N'CCK', 61, N'Cocos (Keeling) Islands', N'166', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.003' AS DateTime), CAST(N'2023-11-07T03:18:41.003' AS DateTime), N'4d8edc96-cec0-49eb-a3ef-bf4281367db5')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (47, N'CO', N'COL', 57, N'Colombia', N'170', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.003' AS DateTime), CAST(N'2023-11-07T03:18:41.003' AS DateTime), N'63ce5cc0-0fd0-4f1e-88e5-0e0bc8246bd9')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (48, N'KM', N'COM', 269, N'Comoros', N'174', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.003' AS DateTime), CAST(N'2023-11-07T03:18:41.003' AS DateTime), N'f3fd079b-3c4f-4ff2-83b6-46344b4f6b90')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (49, N'CG', N'COG', 242, N'Congo', N'178', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.003' AS DateTime), CAST(N'2023-11-07T03:18:41.003' AS DateTime), N'bb5d1947-f548-4283-9af0-961755fb42a1')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (50, N'CK', N'COK', 682, N'Cook Islands', N'184', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.003' AS DateTime), CAST(N'2023-11-07T03:18:41.003' AS DateTime), N'949aec2f-782b-4a7e-9e1e-f23e9edaa43d')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (51, N'CR', N'CRI', 506, N'Costa Rica', N'188', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.007' AS DateTime), CAST(N'2023-11-07T03:18:41.007' AS DateTime), N'0618e851-47f8-4654-b844-a40b0b516797')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (52, N'HR', N'HRV', 385, N'Croatia', N'191', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.007' AS DateTime), CAST(N'2023-11-07T03:18:41.007' AS DateTime), N'1fc5d75d-8936-4265-81f3-63da593e2d18')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (53, N'CU', N'CUB', 53, N'Cuba', N'192', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.007' AS DateTime), CAST(N'2023-11-07T03:18:41.007' AS DateTime), N'f9606eab-e53e-4e3b-a779-509499e687f6')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (54, N'CY', N'CYP', 357, N'Cyprus', N'196', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.007' AS DateTime), CAST(N'2023-11-07T03:18:41.007' AS DateTime), N'f71c1592-f0be-446e-8f91-d5fd48eb335b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (55, N'CZ', N'CZE', 420, N'Czech Republic', N'203', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.007' AS DateTime), CAST(N'2023-11-07T03:18:41.007' AS DateTime), N'2d49686d-b8ac-40e0-9e2a-db21238056c9')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (56, N'DK', N'DNK', 45, N'Denmark', N'208', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.007' AS DateTime), CAST(N'2023-11-07T03:18:41.007' AS DateTime), N'7feba072-858f-41af-a944-fc2556d4f67c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (57, N'DJ', N'DJI', 253, N'Djibouti', N'262', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.010' AS DateTime), CAST(N'2023-11-07T03:18:41.010' AS DateTime), N'eb68bbd7-9c8b-44d3-907d-14bdd0dd58f9')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (58, N'DM', N'DMA', 1767, N'Dominica', N'212', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.010' AS DateTime), CAST(N'2023-11-07T03:18:41.010' AS DateTime), N'dda1ff1b-5e13-4201-9e71-b2ad3746fb16')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (59, N'DO', N'DOM', 1849, N'Dominican Republic', N'214', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.010' AS DateTime), CAST(N'2023-11-07T03:18:41.010' AS DateTime), N'693ad8b0-1144-4e64-8b02-37c4f56db7c5')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (60, N'TL', N'TLS', 670, N'East Timor', N'626', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.010' AS DateTime), CAST(N'2023-11-07T03:18:41.010' AS DateTime), N'd280808d-0512-48f3-9010-3ba7f1496c7f')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (61, N'EC', N'ECU', 593, N'Ecuador', N'218', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.010' AS DateTime), CAST(N'2023-11-07T03:18:41.010' AS DateTime), N'afd90a72-3835-4ecd-82b4-52006b316e2c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (62, N'EG', N'EGY', 20, N'Egypt', N'818', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.010' AS DateTime), CAST(N'2023-11-07T03:18:41.010' AS DateTime), N'9140f78e-4e6d-4227-8b26-4e4475d431ac')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (63, N'SV', N'SLV', 503, N'El Salvador', N'222', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.010' AS DateTime), CAST(N'2023-11-07T03:18:41.010' AS DateTime), N'8182f252-8c89-483b-8931-16942088f274')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (64, N'GB', N'GBR', 44, N'England', N'826', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.010' AS DateTime), CAST(N'2023-11-07T03:18:41.010' AS DateTime), N'5db0d9e2-b28d-4b21-a3ba-22568e261cf3')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (65, N'GQ', N'GNQ', 240, N'Equatorial Guinea', N'226', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.013' AS DateTime), CAST(N'2023-11-07T03:18:41.013' AS DateTime), N'731ebddd-8918-4bbe-badc-8c41eaf7bd1a')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (66, N'ER', N'ERI', 291, N'Eritrea', N'232', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.013' AS DateTime), CAST(N'2023-11-07T03:18:41.013' AS DateTime), N'946791c9-9805-416b-b7d5-16bc344122e8')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (67, N'EE', N'EST', 372, N'Estonia', N'233', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.013' AS DateTime), CAST(N'2023-11-07T03:18:41.013' AS DateTime), N'2084db98-0682-44e1-a15b-d6d908e13858')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (68, N'ET', N'ETH', 251, N'Ethiopia', N'231', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.013' AS DateTime), CAST(N'2023-11-07T03:18:41.013' AS DateTime), N'b934178b-769f-44d7-9bc5-091c80ea5bce')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (69, N'FK', N'FLK', 500, N'Falkland Islands', N'238', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.013' AS DateTime), CAST(N'2023-11-07T03:18:41.013' AS DateTime), N'188d71a8-66ef-48cd-8674-72b3a716d8e3')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (70, N'FO', N'FRO', 298, N'Faroe Islands', N'234', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.013' AS DateTime), CAST(N'2023-11-07T03:18:41.013' AS DateTime), N'a849687d-cd56-47a5-a10c-03cac91c8f9a')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (71, N'FJ', N'FJI', 679, N'Fiji Islands', N'242', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.017' AS DateTime), CAST(N'2023-11-07T03:18:41.017' AS DateTime), N'6f44d537-c60c-43c9-9de7-bb2f91cbefc3')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (72, N'FI', N'FIN', 358, N'Finland', N'246', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.017' AS DateTime), CAST(N'2023-11-07T03:18:41.017' AS DateTime), N'3112bc9b-f6c1-4b23-ae86-dcd9acb6ed6f')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (73, N'FR', N'FRA', 33, N'France', N'250', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.017' AS DateTime), CAST(N'2023-11-07T03:18:41.017' AS DateTime), N'980622f0-95d7-4304-9992-863a94228fde')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (74, N'GF', N'GUF', 594, N'French Guiana', N'254', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.017' AS DateTime), CAST(N'2023-11-07T03:18:41.017' AS DateTime), N'7d481841-c2f9-42d3-bc3e-2a017dad445f')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (75, N'PF', N'PYF', 689, N'French Polynesia', N'258', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.017' AS DateTime), CAST(N'2023-11-07T03:18:41.017' AS DateTime), N'bcea1c32-53d0-43da-9371-f70c858f0b0b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (76, N'TF', N'ATF', 262, N'French Southern territories', N'260', N'Antarctica', 1, 0, CAST(N'2023-11-07T03:18:41.017' AS DateTime), CAST(N'2023-11-07T03:18:41.017' AS DateTime), N'47f896e8-580d-4c06-9dd6-a3584d747446')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (77, N'GA', N'GAB', 241, N'Gabon', N'266', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.020' AS DateTime), CAST(N'2023-11-07T03:18:41.020' AS DateTime), N'64852f5b-59c8-4638-baf4-a5948da5eaca')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (78, N'GM', N'GMB', 220, N'Gambia', N'270', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.020' AS DateTime), CAST(N'2023-11-07T03:18:41.020' AS DateTime), N'3e7023eb-3104-48c5-b6bd-e5bab99d7fe5')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (79, N'GE', N'GEO', 995, N'Georgia', N'268', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.020' AS DateTime), CAST(N'2023-11-07T03:18:41.020' AS DateTime), N'9308aa4c-b3f1-4b74-91f3-cd387c1edb33')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (80, N'DE', N'DEU', 49, N'Germany', N'276', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.020' AS DateTime), CAST(N'2023-11-07T03:18:41.020' AS DateTime), N'23102397-fb46-411e-b352-db7c53fc4d5a')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (81, N'GH', N'GHA', 233, N'Ghana', N'288', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.020' AS DateTime), CAST(N'2023-11-07T03:18:41.020' AS DateTime), N'9ecbf6a1-69fb-45e6-8979-9fa42eef4cc3')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (82, N'GI', N'GIB', 350, N'Gibraltar', N'292', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.020' AS DateTime), CAST(N'2023-11-07T03:18:41.020' AS DateTime), N'05d54314-056a-4554-ba55-4b850f8c6717')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (83, N'GR', N'GRC', 30, N'Greece', N'300', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.020' AS DateTime), CAST(N'2023-11-07T03:18:41.020' AS DateTime), N'4f25ff70-77ea-412e-9265-728cc533317f')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (84, N'GL', N'GRL', 299, N'Greenland', N'304', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.020' AS DateTime), CAST(N'2023-11-07T03:18:41.020' AS DateTime), N'8c5d9e33-d1b2-4938-979e-82efea8b6753')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (85, N'GD', N'GRD', 1473, N'Grenada', N'308', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.023' AS DateTime), CAST(N'2023-11-07T03:18:41.023' AS DateTime), N'138511c8-980a-4df6-ae13-04e4ab09b47e')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (86, N'GP', N'GLP', 590, N'Guadeloupe', N'312', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.023' AS DateTime), CAST(N'2023-11-07T03:18:41.023' AS DateTime), N'fb540404-889e-409b-b03e-58a3d6996720')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (87, N'GU', N'GUM', 1671, N'Guam', N'316', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.023' AS DateTime), CAST(N'2023-11-07T03:18:41.023' AS DateTime), N'c546e928-876f-412d-abf6-fe7dceab9224')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (88, N'GT', N'GTM', 502, N'Guatemala', N'320', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.023' AS DateTime), CAST(N'2023-11-07T03:18:41.023' AS DateTime), N'9ea11190-3633-46f5-9d7a-5a4649acee96')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (89, N'GN', N'GIN', 224, N'Guinea', N'324', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.023' AS DateTime), CAST(N'2023-11-07T03:18:41.023' AS DateTime), N'74126879-6e02-4268-abe1-a8ca9b07ab36')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (90, N'GW', N'GNB', 245, N'Guinea-Bissau', N'624', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.023' AS DateTime), CAST(N'2023-11-07T03:18:41.023' AS DateTime), N'6bb61b1e-df8c-4145-a299-16be699596a4')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (91, N'GY', N'GUY', 592, N'Guyana', N'328', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.023' AS DateTime), CAST(N'2023-11-07T03:18:41.023' AS DateTime), N'167b7732-019c-4659-9624-f6d885f80baf')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (92, N'HT', N'HTI', 509, N'Haiti', N'332', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.027' AS DateTime), CAST(N'2023-11-07T03:18:41.027' AS DateTime), N'6c3564f3-9e11-42c8-884b-8eeda876c8df')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (93, N'HM', N'HMD', 672, N'Heard Island and McDonald Islands', N'334', N'Antarctica', 1, 0, CAST(N'2023-11-07T03:18:41.027' AS DateTime), CAST(N'2023-11-07T03:18:41.027' AS DateTime), N'24989679-f7e7-41ea-b25c-dfa3217e2376')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (94, N'VA', N'VAT', 379, N'Holy See (Vatican City State)', N'336', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.027' AS DateTime), CAST(N'2023-11-07T03:18:41.027' AS DateTime), N'831bf186-b186-40f1-9fb9-894b2b09cd3a')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (95, N'HN', N'HND', 504, N'Honduras', N'340', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.027' AS DateTime), CAST(N'2023-11-07T03:18:41.027' AS DateTime), N'89041c15-1cae-4478-b670-c0dabffc7352')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (96, N'HK', N'HKG', 852, N'Hong Kong', N'344', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.027' AS DateTime), CAST(N'2023-11-07T03:18:41.027' AS DateTime), N'e4a4940c-d8ac-4fce-8b4f-b0600a0b89cd')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (97, N'HU', N'HUN', 36, N'Hungary', N'348', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.027' AS DateTime), CAST(N'2023-11-07T03:18:41.027' AS DateTime), N'5b14d62f-fb06-4d04-9d41-8d6c39488fcb')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (98, N'IS', N'ISL', 354, N'Iceland', N'352', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.030' AS DateTime), CAST(N'2023-11-07T03:18:41.030' AS DateTime), N'b6640734-eb88-4536-80db-7af303e8a8a1')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (99, N'IN', N'IND', 91, N'India', N'356', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.030' AS DateTime), CAST(N'2023-11-07T03:18:41.030' AS DateTime), N'867a0688-a3f6-4b84-95c6-c91eb3bdfc4c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (100, N'ID', N'IDN', 62, N'Indonesia', N'360', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.030' AS DateTime), CAST(N'2023-11-07T03:18:41.030' AS DateTime), N'790141f2-8057-4c28-8a49-5d225332ee9e')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (101, N'IR', N'IRN', 98, N'Iran', N'364', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.030' AS DateTime), CAST(N'2023-11-07T03:18:41.030' AS DateTime), N'c1b2d439-bb90-4e3a-bc4e-cd56668a92ca')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (102, N'IQ', N'IRQ', 964, N'Iraq', N'368', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.030' AS DateTime), CAST(N'2023-11-07T03:18:41.030' AS DateTime), N'28b99304-a409-43bd-a04d-28eaa2f0ff79')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (103, N'IE', N'IRL', 353, N'Ireland', N'372', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.030' AS DateTime), CAST(N'2023-11-07T03:18:41.030' AS DateTime), N'f5a33948-93c9-457e-8d22-8f9fba9f24e2')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (104, N'IL', N'ISR', 972, N'Israel', N'376', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.030' AS DateTime), CAST(N'2023-11-07T03:18:41.030' AS DateTime), N'edb8a4b6-a15b-485c-86ca-497a49cf5f8d')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (105, N'IT', N'ITA', 39, N'Italy', N'380', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.030' AS DateTime), CAST(N'2023-11-07T03:18:41.030' AS DateTime), N'0df4ce27-d511-44ff-b785-8ea0a261c942')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (106, N'CI', N'CIV', 225, N'Ivory Coast', N'384', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.033' AS DateTime), CAST(N'2023-11-07T03:18:41.033' AS DateTime), N'ff880cae-f945-471e-8ee9-5745d6fb8b49')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (107, N'JM', N'JAM', 1876, N'Jamaica', N'388', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.033' AS DateTime), CAST(N'2023-11-07T03:18:41.033' AS DateTime), N'c0c97107-3658-4761-a014-324c2a31fb89')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (108, N'JP', N'JPN', 81, N'Japan', N'392', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.033' AS DateTime), CAST(N'2023-11-07T03:18:41.033' AS DateTime), N'3b69a227-54f4-4ccd-baf9-8078dee72de3')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (109, N'JO', N'JOR', 962, N'Jordan', N'400', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.033' AS DateTime), CAST(N'2023-11-07T03:18:41.033' AS DateTime), N'f6f59b7a-564f-4c44-aa0e-f1e344b076b0')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (110, N'KZ', N'KAZ', 7, N'Kazakhstan', N'398', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.033' AS DateTime), CAST(N'2023-11-07T03:18:41.033' AS DateTime), N'8306d50e-fbaf-4fc2-a6c5-85890e27d1e6')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (111, N'KE', N'KEN', 254, N'Kenya', N'404', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.033' AS DateTime), CAST(N'2023-11-07T03:18:41.033' AS DateTime), N'391e60ca-eef9-46b0-8d3a-f917b00c06d2')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (112, N'KI', N'KIR', 686, N'Kiribati', N'296', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.037' AS DateTime), CAST(N'2023-11-07T03:18:41.037' AS DateTime), N'00dfa4c4-caee-4440-8eda-9aeeec341b8c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (113, N'KW', N'KWT', 965, N'Kuwait', N'414', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.037' AS DateTime), CAST(N'2023-11-07T03:18:41.037' AS DateTime), N'35e37d1e-ae2f-416f-b341-6d2a5300865b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (114, N'KG', N'KGZ', 996, N'Kyrgyzstan', N'417', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.037' AS DateTime), CAST(N'2023-11-07T03:18:41.037' AS DateTime), N'd5faf36d-24f3-467e-a37c-9a0158929370')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (115, N'LA', N'LAO', 856, N'Laos', N'418', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.037' AS DateTime), CAST(N'2023-11-07T03:18:41.037' AS DateTime), N'6ab8219b-0e52-42c0-a927-6c2bb0d4bd06')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (116, N'LV', N'LVA', 371, N'Latvia', N'428', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.037' AS DateTime), CAST(N'2023-11-07T03:18:41.037' AS DateTime), N'a0360467-56e1-48bb-893b-2aa5674e458c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (117, N'LB', N'LBN', 961, N'Lebanon', N'422', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.037' AS DateTime), CAST(N'2023-11-07T03:18:41.037' AS DateTime), N'e5ffc1ea-f3db-4645-9b67-0c08d1e4e084')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (118, N'LS', N'LSO', 266, N'Lesotho', N'426', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.040' AS DateTime), CAST(N'2023-11-07T03:18:41.040' AS DateTime), N'060b2a13-9c06-4668-b6df-eb13a107ed2a')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (119, N'LR', N'LBR', 231, N'Liberia', N'430', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.040' AS DateTime), CAST(N'2023-11-07T03:18:41.040' AS DateTime), N'5e9cc37a-fb72-4f93-a9c3-85ec94f96557')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (120, N'LY', N'LBY', 218, N'Libyan Arab Jamahiriya', N'434', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.040' AS DateTime), CAST(N'2023-11-07T03:18:41.040' AS DateTime), N'e0c5f9a6-a525-4ec7-9d47-f813435adc99')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (121, N'LI', N'LIE', 423, N'Liechtenstein', N'438', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.040' AS DateTime), CAST(N'2023-11-07T03:18:41.040' AS DateTime), N'e7cf817b-6d4f-4c8c-9f3b-f26d232a6a3c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (122, N'LT', N'LTU', 370, N'Lithuania', N'440', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.040' AS DateTime), CAST(N'2023-11-07T03:18:41.040' AS DateTime), N'a6f4681f-c6cf-481e-90c0-824f48a7c50b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (123, N'LU', N'LUX', 352, N'Luxembourg', N'442', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.040' AS DateTime), CAST(N'2023-11-07T03:18:41.040' AS DateTime), N'16fee33a-28e5-41c7-a61f-5ec7e7bddb60')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (124, N'MO', N'MAC', 853, N'Macao', N'446', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.040' AS DateTime), CAST(N'2023-11-07T03:18:41.040' AS DateTime), N'f8cfc23b-4130-42bd-9224-725147b7aded')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (125, N'MK', N'MKD', 389, N'North Macedonia', N'807', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.040' AS DateTime), CAST(N'2023-11-07T03:18:41.040' AS DateTime), N'38904a81-7ef0-4d1f-9e75-6634a1f0d1a6')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (126, N'MG', N'MDG', 261, N'Madagascar', N'450', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.040' AS DateTime), CAST(N'2023-11-07T03:18:41.040' AS DateTime), N'f6c2b0aa-8a38-4bc3-9d88-0e8eb1ddf868')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (127, N'MW', N'MWI', 265, N'Malawi', N'454', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.043' AS DateTime), CAST(N'2023-11-07T03:18:41.043' AS DateTime), N'0f686b31-998f-4667-af3f-b82ebe7001ef')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (128, N'MY', N'MYS', 60, N'Malaysia', N'458', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.043' AS DateTime), CAST(N'2023-11-07T03:18:41.043' AS DateTime), N'721f3c6a-4482-48c5-82a1-6bc3c98f5bfa')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (129, N'MV', N'MDV', 960, N'Maldives', N'462', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.043' AS DateTime), CAST(N'2023-11-07T03:18:41.043' AS DateTime), N'ef252a6b-3991-4055-bf5b-24906e21d3e0')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (130, N'ML', N'MLI', 223, N'Mali', N'466', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.043' AS DateTime), CAST(N'2023-11-07T03:18:41.043' AS DateTime), N'02f65a0c-eb09-4625-b6e8-46b93e0f53b2')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (131, N'MT', N'MLT', 356, N'Malta', N'470', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.043' AS DateTime), CAST(N'2023-11-07T03:18:41.043' AS DateTime), N'dfd7d220-3b88-4b6a-87f7-727debe467e0')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (132, N'MH', N'MHL', 692, N'Marshall Islands', N'584', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.043' AS DateTime), CAST(N'2023-11-07T03:18:41.043' AS DateTime), N'4d65f706-a6c3-42b2-96a6-ba2771607cc9')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (133, N'MQ', N'MTQ', 596, N'Martinique', N'474', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.047' AS DateTime), CAST(N'2023-11-07T03:18:41.047' AS DateTime), N'1fa013d4-db6b-4643-b942-f8afc9ba5686')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (134, N'MR', N'MRT', 222, N'Mauritania', N'478', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.047' AS DateTime), CAST(N'2023-11-07T03:18:41.047' AS DateTime), N'b339d654-49c8-43d9-96bf-d82033b9d31f')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (135, N'MU', N'MUS', 230, N'Mauritius', N'480', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.047' AS DateTime), CAST(N'2023-11-07T03:18:41.047' AS DateTime), N'53511cdd-eba6-41a2-acea-8b601d354709')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (136, N'YT', N'MYT', 262, N'Mayotte', N'175', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.047' AS DateTime), CAST(N'2023-11-07T03:18:41.047' AS DateTime), N'bdc89f6d-08d8-46c5-b526-a020579e36df')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (137, N'MX', N'MEX', 52, N'Mexico', N'484', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.047' AS DateTime), CAST(N'2023-11-07T03:18:41.047' AS DateTime), N'69e70864-aca8-41a1-b35f-f6d978be9d44')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (138, N'FM', N'FSM', 691, N'Micronesia, Federated States of', N'583', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.047' AS DateTime), CAST(N'2023-11-07T03:18:41.047' AS DateTime), N'729d5550-09ad-471e-9f09-f6ed991df0d9')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (139, N'MD', N'MDA', 373, N'Moldova', N'498', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.050' AS DateTime), CAST(N'2023-11-07T03:18:41.050' AS DateTime), N'd42c6440-36d5-40db-ba05-464c20e9fa69')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (140, N'MC', N'MCO', 377, N'Monaco', N'492', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.050' AS DateTime), CAST(N'2023-11-07T03:18:41.050' AS DateTime), N'325ffed3-1b47-4fc9-801d-ce5c19055e72')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (141, N'MN', N'MNG', 976, N'Mongolia', N'496', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.050' AS DateTime), CAST(N'2023-11-07T03:18:41.050' AS DateTime), N'7366d88d-ec32-4b01-9b0f-422fbf2b66b5')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (142, N'MS', N'MSR', 1664, N'Montserrat', N'500', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.050' AS DateTime), CAST(N'2023-11-07T03:18:41.050' AS DateTime), N'3287ae86-3f17-49cb-a6ae-b40f209936ec')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (143, N'MA', N'MAR', 212, N'Morocco', N'504', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.050' AS DateTime), CAST(N'2023-11-07T03:18:41.050' AS DateTime), N'6e30b61f-e151-43d2-9148-663f3787346c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (144, N'MZ', N'MOZ', 258, N'Mozambique', N'508', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.050' AS DateTime), CAST(N'2023-11-07T03:18:41.050' AS DateTime), N'32b32b58-9b83-4d5d-9be7-d5630dc5c33f')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (145, N'MM', N'MMR', 95, N'Myanmar', N'104', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.050' AS DateTime), CAST(N'2023-11-07T03:18:41.050' AS DateTime), N'd336270b-8a96-4414-a15c-dcc616514532')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (146, N'NA', N'NAM', 264, N'Namibia', N'516', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.050' AS DateTime), CAST(N'2023-11-07T03:18:41.050' AS DateTime), N'72599198-49f9-4e5d-a015-ed810a37f900')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (147, N'NR', N'NRU', 674, N'Nauru', N'520', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.053' AS DateTime), CAST(N'2023-11-07T03:18:41.053' AS DateTime), N'60f04d57-00c3-4a20-8bd7-e478ec7c88e5')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (148, N'NP', N'NPL', 977, N'Nepal', N'524', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.053' AS DateTime), CAST(N'2023-11-07T03:18:41.053' AS DateTime), N'a1edeaea-9025-4e28-9a0b-62e7fab9dd23')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (149, N'NL', N'NLD', 31, N'Netherlands', N'528', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.053' AS DateTime), CAST(N'2023-11-07T03:18:41.053' AS DateTime), N'e48029fa-9089-4ad8-8489-6af909574cef')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (150, N'AN', N'ANT', 599, N'Netherlands Antilles', N'530', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.053' AS DateTime), CAST(N'2023-11-07T03:18:41.053' AS DateTime), N'deea805f-626f-4a59-9d0b-4bbbe9be02a0')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (151, N'NC', N'NCL', 687, N'New Caledonia', N'540', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.053' AS DateTime), CAST(N'2023-11-07T03:18:41.053' AS DateTime), N'abecd887-2e45-47af-87e3-3e961840a74b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (152, N'NZ', N'NZL', 64, N'New Zealand', N'554', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.053' AS DateTime), CAST(N'2023-11-07T03:18:41.053' AS DateTime), N'a203bf6a-9845-40ab-981b-b90c24197967')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (153, N'NI', N'NIC', 505, N'Nicaragua', N'558', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.057' AS DateTime), CAST(N'2023-11-07T03:18:41.057' AS DateTime), N'ae7f0c67-4bca-4d3f-b094-8539992c6da5')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (154, N'NE', N'NER', 227, N'Niger', N'562', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.057' AS DateTime), CAST(N'2023-11-07T03:18:41.057' AS DateTime), N'37714446-4134-4fac-8040-133e23d0f25f')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (155, N'NG', N'NGA', 234, N'Nigeria', N'566', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.057' AS DateTime), CAST(N'2023-11-07T03:18:41.057' AS DateTime), N'd94b6c3c-61ab-4988-be6e-ecb798b30511')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (156, N'NU', N'NIU', 683, N'Niue', N'570', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.057' AS DateTime), CAST(N'2023-11-07T03:18:41.057' AS DateTime), N'ddc552c0-f7f1-4c94-81cd-d9efea140ffc')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (157, N'NF', N'NFK', 672, N'Norfolk Island', N'574', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.057' AS DateTime), CAST(N'2023-11-07T03:18:41.057' AS DateTime), N'f31cc14d-42f8-477f-a34d-0dd77e6e0a6b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (158, N'KP', N'PRK', 850, N'North Korea', N'408', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.057' AS DateTime), CAST(N'2023-11-07T03:18:41.057' AS DateTime), N'522fea73-3bfc-4413-85fc-7ea428bdb3bb')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (159, N'GB', N'GBR', 44, N'Northern Ireland', N'826', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.060' AS DateTime), CAST(N'2023-11-07T03:18:41.060' AS DateTime), N'5e7cc7e2-37db-4024-b589-b79df550b2df')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (160, N'MP', N'MNP', 1670, N'Northern Mariana Islands', N'580', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.060' AS DateTime), CAST(N'2023-11-07T03:18:41.060' AS DateTime), N'cc1c453f-ccd8-4323-8eb3-6f77aafe9a63')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (161, N'NO', N'NOR', 47, N'Norway', N'578', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.060' AS DateTime), CAST(N'2023-11-07T03:18:41.060' AS DateTime), N'd81c2c50-0574-4e69-8159-b4111e142c2f')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (162, N'OM', N'OMN', 968, N'Oman', N'512', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.060' AS DateTime), CAST(N'2023-11-07T03:18:41.060' AS DateTime), N'af166c96-04cf-429c-b599-5846c3e426a6')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (163, N'PK', N'PAK', 92, N'Pakistan', N'586', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.060' AS DateTime), CAST(N'2023-11-07T03:18:41.060' AS DateTime), N'b2c667e7-a7d5-4ea5-9f51-c3eb119ba908')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (164, N'PW', N'PLW', 680, N'Palau', N'585', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.060' AS DateTime), CAST(N'2023-11-07T03:18:41.060' AS DateTime), N'add2489f-ff79-4e1e-b671-06b183f39010')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (165, N'PS', N'PSE', 970, N'Palestine', N'275', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.060' AS DateTime), CAST(N'2023-11-07T03:18:41.060' AS DateTime), N'4e57c947-8f49-48d0-80ec-06d11bea60ea')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (166, N'PA', N'PAN', 507, N'Panama', N'591', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.060' AS DateTime), CAST(N'2023-11-07T03:18:41.060' AS DateTime), N'03239516-7fc4-4e46-8ddd-caf99aab2c5c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (167, N'PG', N'PNG', 675, N'Papua New Guinea', N'598', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.060' AS DateTime), CAST(N'2023-11-07T03:18:41.060' AS DateTime), N'df381d62-a67b-4b6d-a1ae-c3865345a47e')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (168, N'PY', N'PRY', 595, N'Paraguay', N'600', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.063' AS DateTime), CAST(N'2023-11-07T03:18:41.063' AS DateTime), N'0474ad8c-63a3-41b9-9c6b-b1fa266ff7cf')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (169, N'PE', N'PER', 51, N'Peru', N'604', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.063' AS DateTime), CAST(N'2023-11-07T03:18:41.063' AS DateTime), N'257fc86c-c046-4823-8b03-2773400fa456')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (170, N'PH', N'PHL', 63, N'Philippines', N'608', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.063' AS DateTime), CAST(N'2023-11-07T03:18:41.063' AS DateTime), N'7713de5c-d4a6-4c86-9642-e8d05732ea8b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (171, N'PN', N'PCN', 64, N'Pitcairn', N'612', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.063' AS DateTime), CAST(N'2023-11-07T03:18:41.063' AS DateTime), N'06eacca9-e636-4283-b86c-09ae271cf5a6')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (172, N'PL', N'POL', 48, N'Poland', N'616', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.063' AS DateTime), CAST(N'2023-11-07T03:18:41.063' AS DateTime), N'fd347e30-8576-427e-988a-740e31aa0b4d')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (173, N'PT', N'PRT', 351, N'Portugal', N'620', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.063' AS DateTime), CAST(N'2023-11-07T03:18:41.063' AS DateTime), N'33657397-3820-4bf7-9a6e-be76d0c4c440')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (174, N'PR', N'PRI', 1939, N'Puerto Rico', N'630', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.067' AS DateTime), CAST(N'2023-11-07T03:18:41.067' AS DateTime), N'9dc32d24-83c0-4328-873d-a7fcd56a26c7')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (175, N'QA', N'QAT', 974, N'Qatar', N'634', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.067' AS DateTime), CAST(N'2023-11-07T03:18:41.067' AS DateTime), N'fe322bca-a1b5-4f44-b8c2-9b5cd64bef06')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (176, N'RE', N'REU', 262, N'Reunion', N'638', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.067' AS DateTime), CAST(N'2023-11-07T03:18:41.067' AS DateTime), N'46353153-f58e-4916-9646-7acc2bbc8972')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (177, N'RO', N'ROU', 40, N'Romania', N'642', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.067' AS DateTime), CAST(N'2023-11-07T03:18:41.067' AS DateTime), N'392e4420-a03c-4794-b0da-4fbcbe92ab35')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (178, N'RU', N'RUS', 7, N'Russian Federation', N'643', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.067' AS DateTime), CAST(N'2023-11-07T03:18:41.067' AS DateTime), N'61180cd4-a4f0-4fb4-b0bb-0f1474411ec4')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (179, N'RW', N'RWA', 250, N'Rwanda', N'646', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.067' AS DateTime), CAST(N'2023-11-07T03:18:41.067' AS DateTime), N'6269bf4d-751c-4599-8374-dacb7fef2f32')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (180, N'SH', N'SHN', 290, N'Saint Helena', N'654', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.070' AS DateTime), CAST(N'2023-11-07T03:18:41.070' AS DateTime), N'aeb36091-a0d8-444c-ba64-00bfb512dfcf')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (181, N'KN', N'KNA', 1869, N'Saint Kitts and Nevis', N'659', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.070' AS DateTime), CAST(N'2023-11-07T03:18:41.070' AS DateTime), N'78d39358-c214-4577-a33a-6e17379c51c8')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (182, N'LC', N'LCA', 1758, N'Saint Lucia', N'662', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.070' AS DateTime), CAST(N'2023-11-07T03:18:41.070' AS DateTime), N'8a9236bc-1fda-4a2d-b1e0-f560528a2563')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (183, N'PM', N'SPM', 508, N'Saint Pierre and Miquelon', N'666', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.070' AS DateTime), CAST(N'2023-11-07T03:18:41.070' AS DateTime), N'e49d8322-e7f5-42aa-8aba-2ae638cff3f3')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (184, N'VC', N'VCT', 1784, N'Saint Vincent and the Grenadines', N'670', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.070' AS DateTime), CAST(N'2023-11-07T03:18:41.070' AS DateTime), N'4612c233-ed2f-4777-aca8-925a5219e979')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (185, N'WS', N'WSM', 685, N'Samoa', N'882', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.070' AS DateTime), CAST(N'2023-11-07T03:18:41.070' AS DateTime), N'e5908bf2-d48b-48e5-9fe1-bfe9c2c140af')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (186, N'SM', N'SMR', 378, N'San Marino', N'674', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.070' AS DateTime), CAST(N'2023-11-07T03:18:41.070' AS DateTime), N'30cc5ea6-269c-4a9f-9772-ed361ab363e6')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (187, N'ST', N'STP', 239, N'Sao Tome and Principe', N'678', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.070' AS DateTime), CAST(N'2023-11-07T03:18:41.070' AS DateTime), N'e386d3cb-3303-4b8f-9bda-f92289be7462')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (188, N'SA', N'SAU', 966, N'Saudi Arabia', N'682', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.070' AS DateTime), CAST(N'2023-11-07T03:18:41.070' AS DateTime), N'2328db43-59d4-48ad-81ae-ba9e7ff08a5d')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (189, N'GB', N'GBR', 44, N'Scotland', N'826', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.073' AS DateTime), CAST(N'2023-11-07T03:18:41.073' AS DateTime), N'6d0328b9-f11b-4cfc-abe3-1d862b043f37')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (190, N'SN', N'SEN', 221, N'Senegal', N'686', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.073' AS DateTime), CAST(N'2023-11-07T03:18:41.073' AS DateTime), N'2dd98daf-65bb-42b2-9c6d-02849bd3f21d')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (191, N'RS', N'SRB', 381, N'Serbia', N'688', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.073' AS DateTime), CAST(N'2023-11-07T03:18:41.073' AS DateTime), N'3a84c533-bad7-483c-9d6a-98e0474c7757')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (192, N'SC', N'SYC', 248, N'Seychelles', N'690', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.073' AS DateTime), CAST(N'2023-11-07T03:18:41.073' AS DateTime), N'1a36dcd4-5008-40b1-8839-0f32e84d74f7')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (193, N'SL', N'SLE', 232, N'Sierra Leone', N'694', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.073' AS DateTime), CAST(N'2023-11-07T03:18:41.073' AS DateTime), N'297d1322-5a89-4fa1-a93d-4528bbd241f5')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (194, N'SG', N'SGP', 65, N'Singapore', N'702', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.073' AS DateTime), CAST(N'2023-11-07T03:18:41.073' AS DateTime), N'c500ba50-c81d-4328-bc6b-b0cf7ab4cd44')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (195, N'SK', N'SVK', 421, N'Slovakia', N'703', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.073' AS DateTime), CAST(N'2023-11-07T03:18:41.073' AS DateTime), N'6905f58d-d146-4e38-8dc9-0f5715019013')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (196, N'SI', N'SVN', 386, N'Slovenia', N'705', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.077' AS DateTime), CAST(N'2023-11-07T03:18:41.077' AS DateTime), N'a132fccd-d1f9-47d1-8c19-e908d8957543')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (197, N'SB', N'SLB', 677, N'Solomon Islands', N'90', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.077' AS DateTime), CAST(N'2023-11-07T03:18:41.077' AS DateTime), N'30452312-4206-4820-b6f5-0c58ac5dfed0')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (198, N'SO', N'SOM', 252, N'Somalia', N'706', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.077' AS DateTime), CAST(N'2023-11-07T03:18:41.077' AS DateTime), N'08632874-7b6b-45e7-a951-eef103f92870')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (199, N'ZA', N'ZAF', 27, N'South Africa', N'710', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.077' AS DateTime), CAST(N'2023-11-07T03:18:41.077' AS DateTime), N'b876e3ed-1703-4348-a23e-f443e91a8cb7')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (200, N'GS', N'SGS', 500, N'South Georgia and the South Sandwich Islands', N'239', N'Antarctica', 1, 0, CAST(N'2023-11-07T03:18:41.077' AS DateTime), CAST(N'2023-11-07T03:18:41.077' AS DateTime), N'60a7e95f-aab6-4f48-be32-a1c6591bde07')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (201, N'KR', N'KOR', 82, N'South Korea', N'410', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.077' AS DateTime), CAST(N'2023-11-07T03:18:41.077' AS DateTime), N'51ce2e7d-8db1-4a10-ade9-dff99a90059d')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (202, N'SS', N'SSD', 211, N'South Sudan', N'728', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.077' AS DateTime), CAST(N'2023-11-07T03:18:41.077' AS DateTime), N'801a0e29-388f-42cd-bd35-ca9ac7818526')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (203, N'ES', N'ESP', 34, N'Spain', N'724', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.080' AS DateTime), CAST(N'2023-11-07T03:18:41.080' AS DateTime), N'9084a6c0-a636-43b3-81ae-edeb1793a113')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (204, N'LK', N'LKA', 94, N'Sri Lanka', N'144', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.080' AS DateTime), CAST(N'2023-11-07T03:18:41.080' AS DateTime), N'79d48790-c57b-4ac1-bea1-347ad3e5112c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (205, N'SD', N'SDN', 249, N'Sudan', N'729', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.080' AS DateTime), CAST(N'2023-11-07T03:18:41.080' AS DateTime), N'fc10f799-57c3-4bcd-b462-af77756b4432')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (206, N'SR', N'SUR', 597, N'Suriname', N'740', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.080' AS DateTime), CAST(N'2023-11-07T03:18:41.080' AS DateTime), N'0ecc52a9-bfb5-44f5-84ce-50be88dea428')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (207, N'SJ', N'SJM', 47, N'Svalbard and Jan Mayen', N'744', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.080' AS DateTime), CAST(N'2023-11-07T03:18:41.080' AS DateTime), N'912135c8-f562-4176-b124-439d4223b839')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (208, N'SZ', N'SWZ', 268, N'Swaziland', N'748', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.080' AS DateTime), CAST(N'2023-11-07T03:18:41.080' AS DateTime), N'6ae1bdc3-cb78-4da9-a6c7-370fda4bd72b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (209, N'SE', N'SWE', 46, N'Sweden', N'752', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.080' AS DateTime), CAST(N'2023-11-07T03:18:41.080' AS DateTime), N'adb1abf1-1ade-4dee-940e-5c81d20ab212')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (210, N'CH', N'CHE', 41, N'Switzerland', N'756', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.080' AS DateTime), CAST(N'2023-11-07T03:18:41.080' AS DateTime), N'2ea15def-148b-4554-b6cc-9755f7a68e1e')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (211, N'SY', N'SYR', 963, N'Syria', N'760', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.080' AS DateTime), CAST(N'2023-11-07T03:18:41.080' AS DateTime), N'64f86e89-1c4d-4863-a689-f43959ca128a')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (212, N'TJ', N'TJK', 992, N'Tajikistan', N'762', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.083' AS DateTime), CAST(N'2023-11-07T03:18:41.083' AS DateTime), N'c5fc957d-8e34-4594-80f0-cc7fb3598550')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (213, N'TZ', N'TZA', 255, N'Tanzania', N'834', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.083' AS DateTime), CAST(N'2023-11-07T03:18:41.083' AS DateTime), N'fd572df9-926b-4351-be02-03684d7c8f61')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (214, N'TH', N'THA', 66, N'Thailand', N'764', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.083' AS DateTime), CAST(N'2023-11-07T03:18:41.083' AS DateTime), N'1e260448-568c-4d89-a46a-a43b68f198fa')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (215, N'CD', N'COD', 243, N'The Democratic Republic of Congo', N'180', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.083' AS DateTime), CAST(N'2023-11-07T03:18:41.083' AS DateTime), N'd18c3b56-4e35-48c9-af55-25e3a37748fa')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (216, N'TG', N'TGO', 228, N'Togo', N'768', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.083' AS DateTime), CAST(N'2023-11-07T03:18:41.083' AS DateTime), N'fb2602f6-a0fe-4609-be5b-c6785030e823')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (217, N'TK', N'TKL', 690, N'Tokelau', N'772', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.083' AS DateTime), CAST(N'2023-11-07T03:18:41.083' AS DateTime), N'9d123a45-eecb-4dd4-9aff-f2f32c101f41')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (218, N'TO', N'TON', 676, N'Tonga', N'776', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.083' AS DateTime), CAST(N'2023-11-07T03:18:41.083' AS DateTime), N'c6626393-4cb6-47b5-ba32-32fd8d63060b')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (219, N'TT', N'TTO', 1868, N'Trinidad and Tobago', N'780', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.087' AS DateTime), CAST(N'2023-11-07T03:18:41.087' AS DateTime), N'd8f51bb7-8829-495c-afc3-8af1e06c1126')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (220, N'TN', N'TUN', 216, N'Tunisia', N'788', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.087' AS DateTime), CAST(N'2023-11-07T03:18:41.087' AS DateTime), N'992d2e7f-5439-464a-966f-13cd18b46ed5')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (221, N'TR', N'TUR', 90, N'Turkey', N'792', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.087' AS DateTime), CAST(N'2023-11-07T03:18:41.087' AS DateTime), N'215805b9-422f-4e28-939b-3c1a2175abc4')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (222, N'TM', N'TKM', 993, N'Turkmenistan', N'795', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.087' AS DateTime), CAST(N'2023-11-07T03:18:41.087' AS DateTime), N'2dbeda31-cc99-49bc-86ed-e24c8c18afaf')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (223, N'TC', N'TCA', 1649, N'Turks and Caicos Islands', N'796', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.087' AS DateTime), CAST(N'2023-11-07T03:18:41.087' AS DateTime), N'58f59484-4c9c-4e4e-9a3f-f2d45f2f3569')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (224, N'TV', N'TUV', 688, N'Tuvalu', N'798', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.087' AS DateTime), CAST(N'2023-11-07T03:18:41.087' AS DateTime), N'c84cdd40-302c-428a-8c75-996ff0796155')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (225, N'UG', N'UGA', 256, N'Uganda', N'800', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.087' AS DateTime), CAST(N'2023-11-07T03:18:41.087' AS DateTime), N'0304bf87-f48c-408a-bd1d-cbdec4cd9d6c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (226, N'UA', N'UKR', 380, N'Ukraine', N'804', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.090' AS DateTime), CAST(N'2023-11-07T03:18:41.090' AS DateTime), N'f1e359a3-67f2-4220-8f51-aa06562a52ba')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (227, N'AE', N'ARE', 971, N'United Arab Emirates', N'784', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.090' AS DateTime), CAST(N'2023-11-07T03:18:41.090' AS DateTime), N'bbf2bd30-a4d2-4671-b08d-7384eab1b181')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (228, N'GB', N'GBR', 44, N'United Kingdom', N'826', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.090' AS DateTime), CAST(N'2023-11-07T03:18:41.090' AS DateTime), N'9a00c8fe-cd73-4826-b4c9-516635bffd91')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (229, N'US', N'USA', 1, N'United States', N'840', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.090' AS DateTime), CAST(N'2023-11-07T03:18:41.090' AS DateTime), N'36b98969-292d-48ee-bb75-ece13372ad8d')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (230, N'UM', N'UMI', 1, N'United States Minor Outlying Islands', N'581', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.090' AS DateTime), CAST(N'2023-11-07T03:18:41.090' AS DateTime), N'2721991c-cc42-4613-b946-cd4ac57c0473')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (231, N'UY', N'URY', 598, N'Uruguay', N'858', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.090' AS DateTime), CAST(N'2023-11-07T03:18:41.090' AS DateTime), N'672d8090-c30f-4302-ab29-a5f323e7b2ca')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (232, N'UZ', N'UZB', 998, N'Uzbekistan', N'860', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.090' AS DateTime), CAST(N'2023-11-07T03:18:41.090' AS DateTime), N'f96651dc-5f87-43d0-9659-bb8fe5f2178c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (233, N'VU', N'VUT', 678, N'Vanuatu', N'548', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.090' AS DateTime), CAST(N'2023-11-07T03:18:41.090' AS DateTime), N'7a58c43f-e091-4b39-9779-59b00ecbe994')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (234, N'VE', N'VEN', 58, N'Venezuela', N'862', N'South America', 1, 0, CAST(N'2023-11-07T03:18:41.090' AS DateTime), CAST(N'2023-11-07T03:18:41.090' AS DateTime), N'81e3d8c4-2cc2-4b1d-ab1d-37c29f749dc7')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (235, N'VN', N'VNM', 84, N'Vietnam', N'704', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.093' AS DateTime), CAST(N'2023-11-07T03:18:41.093' AS DateTime), N'877b9136-f329-4c34-bb4e-28895e020710')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (236, N'VG', N'VGB', 1, N'Virgin Islands, British', N'92', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.093' AS DateTime), CAST(N'2023-11-07T03:18:41.093' AS DateTime), N'446baa16-06bc-4169-8fb9-89e5d2e28086')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (237, N'VI', N'VIR', 1, N'Virgin Islands, U.S.', N'850', N'North America', 1, 0, CAST(N'2023-11-07T03:18:41.093' AS DateTime), CAST(N'2023-11-07T03:18:41.093' AS DateTime), N'32ff9bd0-3b8b-4e27-b0a6-bb96329ab1f0')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (238, N'GB', N'GBR', 44, N'Wales', N'826', N'Europe', 1, 0, CAST(N'2023-11-07T03:18:41.093' AS DateTime), CAST(N'2023-11-07T03:18:41.093' AS DateTime), N'3bef0361-85c4-459c-ad8e-2197e402e4c9')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (239, N'WF', N'WLF', 681, N'Wallis and Futuna', N'876', N'Oceania', 1, 0, CAST(N'2023-11-07T03:18:41.093' AS DateTime), CAST(N'2023-11-07T03:18:41.093' AS DateTime), N'6cfe523f-cf21-42c1-a247-b67a847188cf')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (240, N'EH', N'ESH', 212, N'Western Sahara', N'732', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.093' AS DateTime), CAST(N'2023-11-07T03:18:41.093' AS DateTime), N'933e8ada-ec3a-4675-99d4-38ea9842e2a6')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (241, N'YE', N'YEM', 967, N'Yemen', N'887', N'Asia', 1, 0, CAST(N'2023-11-07T03:18:41.093' AS DateTime), CAST(N'2023-11-07T03:18:41.093' AS DateTime), N'f74c6bc6-fedf-4abe-b018-84514f67f51c')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (242, N'ZM', N'ZMB', 260, N'Zambia', N'894', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.093' AS DateTime), CAST(N'2023-11-07T03:18:41.093' AS DateTime), N'fa367aa0-2dd7-4b77-921a-2bb6c7b8122e')
GO
INSERT [dbo].[country]
  ([country_id], [iso_code2], [iso_code3], [calling_code], [name], [iso_numeric_code], [continent], [is_active], [is_deleted], [created_at], [updated_at], [row_guid])
VALUES
  (243, N'ZW', N'ZWE', 263, N'Zimbabwe', N'716', N'Africa', 1, 0, CAST(N'2023-11-07T03:18:41.097' AS DateTime), CAST(N'2023-11-07T03:18:41.097' AS DateTime), N'8deea695-7313-4414-bff7-327ac26f635b')
GO
SET IDENTITY_INSERT [dbo].[country] OFF
GO
