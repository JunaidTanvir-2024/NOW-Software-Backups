﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Models.Pay360ApiContracts
{
    public class GenericPay360ApiResponse<T>
    {
        public string status { get; set; }
        public string message { get; set; }
        public T payload { get; set; }
        public int errorCode { get; set; }
        public string pay360ApiCode { get; set; }

        public static GenericPay360ApiResponse<T> Success(T payload, string message)
        {
            return new GenericPay360ApiResponse<T>
            {
                errorCode = 0,
                status = "Success",
                message = message,
                payload = payload
            };
        }
        public static GenericPay360ApiResponse<T> Success(string message)
        {
            return new GenericPay360ApiResponse<T>
            {
                errorCode = 0,
                status = "Success",
                message = message
            };
        }
        public static GenericPay360ApiResponse<T> Failure(string message, ApiStatusCodes errorCode)
        {
            return new GenericPay360ApiResponse<T>
            {
                errorCode = (int)errorCode,
                status = "Failure",
                message = message

            };
        }
        public static GenericPay360ApiResponse<T> Failure(T payload, string message, ApiStatusCodes errorCode)
        {
            return new GenericPay360ApiResponse<T>
            {
                errorCode = (int)errorCode,
                status = "Failure",
                message = message,
                payload = payload
            };
        }
    }
}
