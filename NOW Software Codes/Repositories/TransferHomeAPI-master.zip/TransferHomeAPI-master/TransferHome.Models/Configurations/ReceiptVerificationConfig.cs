﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Configurations
{
    public class ReceiptVerificationConfig
    {
        public string LiveUrl { get; set; }
        public string SandboxUrl { get; set; }
        public AppleReceiptValidationEnvironment IsLive { get; set; }
    }
}
