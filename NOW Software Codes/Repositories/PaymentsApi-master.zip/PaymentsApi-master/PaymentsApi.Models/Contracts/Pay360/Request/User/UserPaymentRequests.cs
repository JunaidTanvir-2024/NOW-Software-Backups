﻿using Newtonsoft.Json;
using PaymentsApi.Models.Contracts.Pay360.Request.Api;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PaymentsApi.Models.Contracts.Pay360.Request.User
{
    public class UserPaymentRequestNewCustomer
    {
        [JsonProperty("customerName")]
        [Required]
        public string CustomerName { get; set; }

        [JsonProperty("customerMsisdn")]
        public string CustomerMsisdn { get; set; }

        [JsonProperty("customerUniqueRef")]
        [Required]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("customerEmail")]
        public string CustomerEmail { get; set; }

        [JsonProperty("sendPay360Email")]
        public bool SendPay360Email { get; set; } = true;

        [JsonProperty("transactionCurrency")]
        [Required]
        public string TransactionCurrency { get; set; }

        [JsonProperty("transactionAmount")]
        [Required]
        public float TransactionAmount { get; set; }

        [JsonProperty("cardPan")]
        [Required]
        public string CardPan { get; set; }

        [JsonProperty("cardCv2")]
        [Required]
        public string CardCv2 { get; set; }

        [JsonProperty("cardExpiryDate")]
        [Required]
        public string CardExpiryDate { get; set; }

        [JsonProperty("isDefaultCard")]
        [Required]
        public bool IsDefaultCard { get; set; }

        [JsonProperty("isAuthorizationOnly")]
        [Required]
        public bool IsAuthorizationOnly { get; set; }

        [JsonProperty("recurring")]
        [Required]
        public bool Recurring { get; set; }

        [JsonProperty("do3DSecure")]
        [Required]
        public bool Do3DSecure { get; set; }

        [JsonProperty("isDirectFullfilment")]
        [Required]
        public bool IsDirectFullfilment { get; set; }

        [JsonProperty("ipAddress")]
        [Required]
        public string IpAddress { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("basket")]
        [Required]
        public ProductBasket[] Basket { get; set; }

        [JsonProperty("billingAddress")]
        public BillingAddress BillingAddress { get; set; }

        [JsonProperty("customerBillingAddress")]
        public CustomerBillingAddress CustomerBillingAddress { get; set; } 

        [JsonProperty("shippingAddress")]
        public ShippingAddress ShippingAddress { get; set; }        

        [JsonProperty("financialServices")]
        public UserFinancialServicesModel FinancialServices { get; set; }

        [JsonProperty("customFields")]
        public CustomFields CustomFields { get; set; }

        public bool SaveCard { get; set; } = true;
        [JsonProperty("commerceType")]
        public string CommerceType { get; set; } = "ECOM";
        [JsonProperty("overrideValidation")]
        public bool OverrideValidation { get; set; }
    }

    public class UserPaymentRequestExistingCustomerDefaultCard
    {
        [JsonProperty("customerMsisdn")]
        public string CustomerMsisdn { get; set; }

        [JsonProperty("CustomerEmail")]
        public string CustomerEmail { get; set; }

        [JsonProperty("sendPay360Email")]
        public bool SendPay360Email { get; set; } = true;

        [JsonProperty("customerUniqueRef")]
        [Required]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("transactionCurrency")]
        [Required]
        public string TransactionCurrency { get; set; }

        [JsonProperty("transactionAmount")]
        [Required]
        public float TransactionAmount { get; set; }

        [JsonProperty("cardCv2")]
        [Required]
        public string CardCv2 { get; set; }

        [JsonProperty("recurring")]
        [Required]
        public bool Recurring { get; set; }

        [JsonProperty("isAuthorizationOnly")]
        [Required]
        public bool IsAuthorizationOnly { get; set; }
        [JsonProperty("do3DSecure")]
        [Required]
        public bool Do3DSecure { get; set; }

        [JsonProperty("isDirectFullfilment")]
        [Required]
        public bool IsDirectFullfilment { get; set; }

        [JsonProperty("ipAddress")]
        [Required]
        public string IpAddress { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("basket")]
        [Required]
        public ProductBasket[] Basket { get; set; }

        [JsonProperty("financialServices")]
        public UserFinancialServicesModel FinancialServices { get; set; }

        [JsonProperty("shippingAddress")]
        public ShippingAddress ShippingAddress { get; set; }

        [JsonProperty("customFields")]
        public CustomFields CustomFields { get; set; }
        [JsonProperty("commerceType")]
        public string CommerceType { get; set; } = "ECOM";
        [JsonProperty("overrideValidation")]
        public bool OverrideValidation { get; set; }
    }

    public class UserPaymentRequestExistingCustomerNewCard
    {
        [JsonProperty("customerMsisdn")]
        public string CustomerMsisdn { get; set; }

        [JsonProperty("customerEmail")]
        public string CustomerEmail { get; set; }

        [JsonProperty("sendPay360Email")]
        public bool SendPay360Email { get; set; } = true;

        [JsonProperty("customerUniqueRef")]
        [Required]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("transactionCurrency")]
        [Required]
        public string TransactionCurrency { get; set; }

        [JsonProperty("transactionAmount")]
        [Required]
        public float TransactionAmount { get; set; }

        [JsonProperty("customerName")]
        [Required]
        public string CustomerName { get; set; }

        [JsonProperty("cardPan")]
        [Required]
        public string CardPan { get; set; }

        [JsonProperty("cardCv2")]
        [Required]
        public string CardCv2 { get; set; }

        [JsonProperty("cardExpiryDate")]
        [Required]
        public string CardExpiryDate { get; set; }

        [JsonProperty("isDefaultCard")]
        [Required]
        public bool IsDefaultCard { get; set; }

        [JsonProperty("recurring")]
        [Required]
        public bool Recurring { get; set; }

        [JsonProperty("isAuthorizationOnly")]
        [Required]
        public bool IsAuthorizationOnly { get; set; }
        [JsonProperty("do3DSecure")]
        [Required]
        public bool Do3DSecure { get; set; }

        [JsonProperty("isDirectFullfilment")]
        [Required]
        public bool IsDirectFullfilment { get; set; }

        [JsonProperty("ipAddress")]
        [Required]
        public string IpAddress { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("basket")]
        [Required]
        public ProductBasket[] Basket { get; set; }

        [JsonProperty("billingAddress")]
        public BillingAddress BillingAddress { get; set; }

        [JsonProperty("shippingAddress")]
        public ShippingAddress ShippingAddress { get; set; }

        [JsonProperty("financialServices")]
        public UserFinancialServicesModel FinancialServices { get; set; }

        [JsonProperty("customFields")]
        public CustomFields CustomFields { get; set; }
        public bool SaveCard { get; set; } = true;
        [JsonProperty("commerceType")]
        public string CommerceType { get; set; } = "ECOM";
        [JsonProperty("overrideValidation")]
        public bool OverrideValidation { get; set; }
    }

    public class UserPaymentRequestCardToken
    {
        [JsonProperty("customerMsisdn")]
        public string CustomerMsisdn { get; set; }

        [JsonProperty("customerUniqueRef")]
        [Required]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("customerEmail")]
        public string CustomerEmail { get; set; }

        [JsonProperty("sendPay360Email")]
        public bool SendPay360Email { get; set; } = true;

        [JsonProperty("transactionCurrency")]
        [Required]
        public string TransactionCurrency { get; set; }

        [JsonProperty("transactionAmount")]
        [Required]
        public float TransactionAmount { get; set; }

        [JsonProperty("cardToken")]
        [Required]
        public string CardToken { get; set; }

        [JsonProperty("cardCv2")]
        [Required]
        public string CardCv2 { get; set; }

        [JsonProperty("recurring")]
        [Required]
        public bool Recurring { get; set; }

        [JsonProperty("isAuthorizationOnly")]
        [Required]
        public bool IsAuthorizationOnly { get; set; }

        [JsonProperty("do3DSecure")]
        [Required]
        public bool Do3DSecure { get; set; }

        [JsonProperty("isDirectFullfilment")]
        [Required]
        public bool IsDirectFullfilment { get; set; }

        [JsonProperty("ipAddress")]
        [Required]
        public string IpAddress { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("basket")]
        [Required]
        public ProductBasket[] Basket { get; set; }

        [JsonProperty("financialServices")]
        public UserFinancialServicesModel FinancialServices { get; set; }

        [JsonProperty("shippingAddress")]
        public ShippingAddress ShippingAddress { get; set; }

        [JsonProperty("customFields")]
        public CustomFields CustomFields { get; set; }
        [JsonProperty("commerceType")]
        public string CommerceType { get; set; } = "ECOM";
        [JsonProperty("overrideValidation")]
        public bool OverrideValidation { get; set; }
    }

    public class CustomFields
    {

        [JsonProperty("fieldState")]
        [Required]
        public List<FieldState> FieldState { get; set; }
    }
    public class FieldState
    {

        [JsonProperty("name")]
        [Required]
        public string Name { get; set; }

        [JsonProperty("value")]
        public string Value { get; set; }

        [JsonProperty("transient")]
        public bool Transient { get; set; }
    }

   
    public class UserFinancialServicesModel
    {
        [JsonProperty("dateOfBirth")]
        public string DateOfBirth { get; set; }
        [JsonProperty("surname")]
        public string Surname { get; set; }
        [JsonProperty("accountNumber")]
        public string AccountNumber { get; set; }
        [JsonProperty("postCode")]
        public string PostCode { get; set; }
    }

    public class ProductBasket
    {
        [JsonProperty("productItemCode")]
        [Required]
        public string ProductItemCode { get; set; }

        [JsonProperty("amount")]
        [Required]
        public float Amount { get; set; }

        [JsonProperty("productRef")]
        public string ProductRef { get; set; }

        [JsonProperty("bundleRef")]
        public string BundleRef { get; set; }

    }

    public class BillingAddress
    {
        [JsonProperty("line1")]
        [Required]
        public string Line1 { get; set; }

        [JsonProperty("line2")]
        public string Line2 { get; set; }

        [JsonProperty("line3")]
        public string Line3 { get; set; }

        [JsonProperty("line4")]
        public string Line4 { get; set; }

        [JsonProperty("city")]
        //[Required]
        public string City { get; set; }

        [JsonProperty("region")]
        //[Required]
        public string Region { get; set; }

        [JsonProperty("postCode")]
        //[Required]
        public string PostCode { get; set; }

        [JsonProperty("countryCode")]
        //[Required]
        [MaxLength(3)]
        public string CountryCode { get; set; }

    }

    public class CustomerBillingAddress
    {
        [JsonProperty("line1")]
        //[Required]
        public string Line1 { get; set; }

        [JsonProperty("line2")]
        public string Line2 { get; set; }

        [JsonProperty("line3")]
        public string Line3 { get; set; }

        [JsonProperty("line4")]
        public string Line4 { get; set; }

        [JsonProperty("city")]
        //[Required]
        public string City { get; set; }

        [JsonProperty("region")]
        //[Required]
        public string Region { get; set; }

        [JsonProperty("postCode")]
        //[Required]
        public string PostCode { get; set; }

        [JsonProperty("countryCode")]
        //[Required]
        [MaxLength(3)]
        public string CountryCode { get; set; }

    }

    public class ShippingAddress
    {
        [JsonProperty("name")]
        //[Required]
        public string Name { get; set; }

        [JsonProperty("line1")]
        //[Required]
        public string Line1 { get; set; }

        [JsonProperty("line2")]
        public string Line2 { get; set; }

        [JsonProperty("line3")]
        public string Line3 { get; set; }

        [JsonProperty("line4")]
        public string Line4 { get; set; }

        [JsonProperty("city")]
        //[Required]
        public string City { get; set; }

        [JsonProperty("region")]
        //[Required]
        public string Region { get; set; }

        [JsonProperty("postcode")]
        //[Required]
        public string PostCode { get; set; }

        [JsonProperty("countryCode")]
        // [Required]
        [MaxLength(3)]
        public string CountryCode { get; set; }

    }

    public class UserRequestUpdateCard
    {
        [JsonProperty("defaultCardCV2")]
        [Required]
        public string DefaultCardCV2 { get; set; }

        [JsonProperty("pay360CustomerID")]
        [Required]
        public string Pay360CustomerID { get; set; }

        [JsonProperty("cardToken")]
        [Required]
        public string CardToken { get; set; }
    }

    public class UserRequestRefundPartialPayment
    {
        [Required]
        [JsonProperty("transactionId")]
        public string TransactionId { get; set; }
        [Required]
        [JsonProperty("amount")]
        public double Amount { get; set; }
        [Required]
        [JsonProperty("currency")]
        public string Currency { get; set; }
        ///// <summary>
        ///// This is Pay360CustomerId
        ///// </summary>
        //[Required]
        //[JsonProperty("customerId")]
        //public long CustomerId { get; set; }
    }

    public class UserRequestRefundFullPayment
    {
        /// <summary>
        /// TransactionId of the transaction to be refunded
        /// </summary>
        [Required]
        [JsonProperty("transactionId")]
        public string TransactionId { get; set; }

        ///// <summary>
        ///// This will be Pay360CustomerId.
        ///// </summary>
        //[Required]
        //[JsonProperty("customerId")]
        //public long CustomerId { get; set; }
    }

    public class UserRequestCaptureOrCancelTransaction
    {
        /// <summary>
        /// Pay360TransactionId of the transaction to be refunded
        /// </summary>
        [Required]
        [JsonProperty("transactionId")]
        public string TransactionId { get; set; }

    }

    public class UserRequestResume3DSecureTransaction
    {
        [Required]
        [JsonProperty("pay360TransactionId")]
        public string Pay360TransactionId { get; set; }
        [Required]
        [JsonProperty("pareq")]
        public string Pareq { get; set; }

        [JsonProperty("customerEmail")]
        public string CustomerEmail { get; set; }
    }
       
    public class UserRequestRepeatTransaction
    {
        /// <summary>
        /// Pay360TransactionId of the transaction to be refunded
        /// </summary>
        [Required]
        [JsonProperty("pay360TransactionId")]
        public string Pay360TransactionId { get; set; }

        //[Required]
        //[JsonProperty("customerMsisdn")]
        //public string CustomerMsisdn { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }
        [Required]
        [JsonProperty("amount")]
        public float Amount { get; set; }
        [JsonProperty("commerceType")]
        public string CommerceType { get; set; } = "MOTO";
    }

    public class UserRequestSetAutoTopup
    {
        [JsonProperty("productRef")]
        [Required]
        public string ProductRef { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("productItemCode")]
        [Required]
        public string ProductItemCode { get; set; }

        [JsonProperty("thresholdBalanceAmount")]
        [Required]
        [Range(0, 999999999)]
        public float ThresholdBalanceAmount { get; set; }

        [JsonProperty("isAutoTopup")]
        [Required]
        public bool IsAutoTopup { get; set; }

        [JsonProperty("topupAmount")]
        [Required]
        [Range(0, 999999999)]
        public decimal TopupAmount { get; set; }

        [JsonProperty("topupCurrency")]
        [Required]
        public string TopupCurrency { get; set; }

        [JsonProperty("email")]
        [Required]
        public string Email { get; set; }

    }

    public class UserRequestRemoveCard
    {
        [JsonProperty("cardToken")]
        [Required]
        public string CardToken { get; set; }

        [JsonProperty("pay360CustomerID")]
        [Required]
        public string Pay360CustomerID { get; set; }
    }

    public class UpdateCustomerCardRequest
    {
        [JsonProperty("cardToken")]
        [Required]
        public string CardToken { get; set; }

        [JsonProperty("pay360CustomerID")]
        [Required]
        public string Pay360CustomerID { get; set; }

        [JsonProperty("isPrimary")]
        [Required]
        public bool IsPrimary { get; set; }
        public Card card { get; set; }


    }

    public class UpdateCustomerCardModel
    {
        public bool isPrimary { get; set; }
        public Card card { get; set; }
    }

    public class Card
    {

        [JsonProperty("expiryDate")]
        public string ExpiryDate { get; set; }

       

    }

    public class Validate
    {
        [JsonProperty("msisdn")]
        [Required]
        [Phone]
        public string Msisdn { get; set; }

        [JsonProperty("product")]
        [Required]
        public string Product { get; set; }

        [JsonProperty("amount")]
        [Required]
        public float Amount { get; set; }


    }

    public class UserRequestGetAutoTopup
    {
        [JsonProperty("msisdn")]
        [Required]
        [Phone]
        public string Msisdn { get; set; }

        [JsonProperty("email")]
        [Required]
        public string Email { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }

    }

    public class UserResponseGetAutoTopup
    {
        public string Msisdn { get; set; }
        public float ThresHold { get; set; }
        public float Topup { get; set; }
        public string Currency { get; set; }
        public bool Status { get; set; }

    }

    public class UserResponseGetAutoTopup_THRCC
    {
        public string account { get; set; }
        public float ThresHold { get; set; }
        public float Topup { get; set; }
        public string Currency { get; set; }
        public bool Status { get; set; }

    }

    public class UserRequestGetCustomerPaymentMethodsByCustomerUniqueRef
    {
        [JsonProperty("customerUniqueRef")]
        [Required]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }
    }

    public class UserRequestGetCustomerByCustomerUniqueRef
    {
        [JsonProperty("customerUniqueRef")]
        [Required]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }
    }

    public class UserRequestResume3DsV2
    {
        [Required]
        [JsonProperty("pay360TransactionId")]
        public string Pay360TransactionId { get; set; }


        [JsonProperty("OverallStatus")]
        public string OverallStatus { get; set; }

        [JsonProperty("customerEmail")]
        public string CustomerEmail { get; set; }
    }
    public class V23DsRedirect_TestData
    {
        public string transactionId { get; set; }
        public string md { get; set; }
        public string overallStatus { get; set; }
    }

    public class RedirectRequest3DsV2_Test
    {

        [JsonProperty("transactionId")]
        public string TransactionId { get; set; }


        [JsonProperty("MD")]
        public string MD { get; set; }

        [JsonProperty("overallStatus")]
        public string OverallStatus { get; set; }
    }
}
