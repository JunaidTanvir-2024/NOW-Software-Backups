﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants;
public static partial class AppEnums
{
    public enum OrderStatusEnum
    {
        [Key("init")]
        Init = 1,
        [Key("checkout")]
        Checkout = 2,
        [Key("processing Payment")]
        ProcessingPayment = 3,
        [Key("completed")]
        Completed = 4,
        [Key("cancelled")]
        Cancelled = 5,
        [Key("pending")]
        Pending = 6,

    }
    public enum CartItemStatus
    {
        [Key("Active")]
        Active = 1,
        [Key("Inactive")]
        Inactive = 2,

    }
    public enum CartItemState
    {
        [Key("Cart")]
        Cart = 1,
        [Key("No Longer Exist")]
        NoLongerExist = 2,

    }
}

