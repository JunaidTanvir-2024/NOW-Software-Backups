﻿var selectedCountryData;
var cardrate;
$(document).ready(function () {
    var selectedCountry = $("#CountryDDL option:selected").text();
    selectedCountryData = RatesJson.filter(function (x) {
        return x.Destination == selectedCountry
    });
    Rates.RenderRates(10);
    addCuntoryTags($('#CountryDDL').val());
    $('#CountryDDL').change(function () {
        var val = this.value;
        addCuntoryTags(val);
        selectedCountryData = RatesJson.filter(function (x) {
            return x.Destination == val
        });
        var denomination = $('.radioCC:checked').val();
        Rates.RenderRates(denomination);
    });
    $('.radioCC').change(function () {
        var denomination = $('.radioCC:checked').val();
        Rates.RenderRates(denomination);

    });

 
});

$("#buycard").on("click", function (event) {
    window.location.href = "/callingcardcheckout/" + cardrate;
});

var Rates = {
    RenderRates: function (val) {
        cardrate = val;
        if (val == 10) {
            $('#TotalMinLL').html(selectedCountryData[0].Landline_TotalMins10GBP + ' <span>mins</span>');
            $('#LandLineRate').html(selectedCountryData[0].Landline_rate + 'p<span>/min</span>');
            $('#TotalMinMob').html(selectedCountryData[0].Mobile_TotalMins10GBP + ' <span>mins</span>');
            $('#MobileRate').html(selectedCountryData[0].Mobile_rate + 'p<span>/min</span>');
            $('#BuyBtn').html(val);
            $('#CardValidity').html("60 days");
        }
        else if (val == 5) {
            $('#TotalMinLL').html(selectedCountryData[0].Landline_TotalMins5GBP + ' <span>mins</span>');
            $('#LandLineRate').html(selectedCountryData[0].Landline_rate + 'p<span>/min</span>');
            $('#TotalMinMob').html(selectedCountryData[0].Mobile_TotalMins5GBP + ' <span>mins</span>');
            $('#MobileRate').html(selectedCountryData[0].Mobile_rate + 'p<span>/min</span>');
            $('#BuyBtn').html(val);
            $('#CardValidity').html("30 days");
        }
        else if (val == 20) {
            $('#TotalMinLL').html(selectedCountryData[0].Landline_TotalMins20GBP + ' <span>mins</span>');
            $('#LandLineRate').html(selectedCountryData[0].Landline_rate + 'p<span>/min</span>');
            $('#TotalMinMob').html(selectedCountryData[0].Mobile_TotalMins20GBP + ' <span>mins</span>');
            $('#MobileRate').html(selectedCountryData[0].Mobile_rate + 'p<span>/min</span>');
            $('#BuyBtn').html(val);
            $('#CardValidity').html("90 days");
        }
    }
}