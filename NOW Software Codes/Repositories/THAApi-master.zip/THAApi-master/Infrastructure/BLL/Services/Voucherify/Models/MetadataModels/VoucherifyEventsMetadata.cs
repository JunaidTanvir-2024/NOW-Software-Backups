﻿using System;

namespace Infrastructure.BLL.Services.Voucherify.Models.MetadataModels
{
	public class VoucherifyEventsMetadata
	{
        public decimal ChargeAmount { get; set; }
        public DateTime Timestamp { get; set; }
        public int LoyaltyPoints { get; set; }
    }
}
