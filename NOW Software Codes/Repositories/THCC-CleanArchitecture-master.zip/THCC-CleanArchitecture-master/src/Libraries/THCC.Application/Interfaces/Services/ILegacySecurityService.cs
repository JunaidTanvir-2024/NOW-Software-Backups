﻿namespace THCC.Application.Interfaces.Services
{
    public interface ILegacySecurityService : ServiceType.ITransient
    {
        bool CheckPassword(string pasword, LegacyUser user);
    }
}
