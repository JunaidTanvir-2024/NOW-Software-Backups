﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.ATTApiContracts;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class ATTService : IATTService
    {
        private readonly HttpClient _httpClient;
        private readonly ATTConfig _attConfig;

        public ATTService(HttpClient httpClient,
                            IOptions<ATTConfig> attConfig)
        {
            _httpClient = httpClient;
            _attConfig = attConfig.Value;
        }

        public async Task<GetProductResponse> GetProducts(string fromMsisdn, string toMsisdn, string currencyAccount)
        {
            string endpoint = _attConfig.ApiEndPoint + "DTOneProducts?fromMSISDN=" + fromMsisdn + "&destinationMSISDN=" + toMsisdn + "&account=" + currencyAccount + "&product=THA" + "&productItemCode=" + ProductItemCode.THADTW;

            var output = await _httpClient.GetAsync(endpoint);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<GetProductResponse>(outputData);
            }

            return null;
        }

        public async Task<ExecuteDataResponse> Execute(ExecuteDataRequest request)
        {
            string endPoint = $"{_attConfig.ApiEndPoint}DTOneExecute";

            var Json = JsonConvert.SerializeObject(request);

            var content = new StringContent(Json, Encoding.UTF8, "application/json");

            var output = await _httpClient.PostAsync(endPoint, content);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<ExecuteDataResponse>(outputData);
            }

            return null;
        }
    }
}
