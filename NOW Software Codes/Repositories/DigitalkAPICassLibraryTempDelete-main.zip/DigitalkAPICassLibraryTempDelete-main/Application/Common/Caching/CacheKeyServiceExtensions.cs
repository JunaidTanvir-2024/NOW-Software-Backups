﻿namespace Application.Common.Caching;

public static class CacheKeyServiceExtensions
{
    public static string GetCacheKey<TEntity>(this ICacheKeyService cacheKeyService, string id) 
        => cacheKeyService.GetCacheKey(typeof(TEntity).Name, id);
}