﻿namespace CancelBundleApi.Settings.Database
{
    public class DigitalkSettings
    {
        public const string SectionName = "Digitalk";
        public static DigitalkSettings Bind = new DigitalkSettings();
        public string? ApiEndPoint { get; set; }
        public string? UserName { get; set; }
        public string? Password { get; set; }

    }
}
