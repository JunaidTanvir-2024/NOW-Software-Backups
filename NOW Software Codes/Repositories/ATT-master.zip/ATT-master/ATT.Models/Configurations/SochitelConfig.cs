﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{
    public class SochitelConfig
    {
        public string AttApiEndPoint { get; set; }
        public bool AttSimulationMode { get; set; }
        public string AttUsernameGBP { get; set; }
        public string AttAppPasswordGBP { get; set; }
        public string AttUsernameEUR { get; set; }
        public string AttAppPasswordEUR { get; set; }
        public string AttUsernameUSD { get; set; }
        public string AttAppPasswordUSD { get; set; }
        public string AuthStringForSaltGeneration { get; set; }
        public bool JsonResponseLogging { get; set; }
        public string RangeToProductConversionPercentages { get; set; }
        public bool SendSmsToSender { get; set; }
        public string SmsTemplate { get; set; }
    }
}
