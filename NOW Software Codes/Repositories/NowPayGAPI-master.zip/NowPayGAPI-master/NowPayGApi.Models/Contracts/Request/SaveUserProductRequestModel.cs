﻿using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class SaveUserProductRequestModel
    {
        [Required]
        public string ProductRef { get; set; }
        [Required]
        public string PUKCode { get; set; }
        public int UserId { get; set; }
    }
}
