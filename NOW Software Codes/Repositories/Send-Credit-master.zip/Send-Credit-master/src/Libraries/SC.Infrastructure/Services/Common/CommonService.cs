﻿using SC.Infrastructure.Vendors.Payment.Common;

namespace SC.Infrastructure.Services;

internal sealed class CommonService : ICommonService
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly DefaultRegionSetting _defaultRegionSetting;
    private readonly PaymentHubSetting _paymentHubSetting;
    public CommonService(IHttpContextAccessor httpContextAccessor, IOptions<DefaultRegionSetting> defaultRegionSetting, IOptions<PaymentHubSetting> paymenthubsettting)
    {
        _httpContextAccessor = httpContextAccessor;
        _defaultRegionSetting = defaultRegionSetting.Value;
        _paymentHubSetting = paymenthubsettting.Value;
    }

    public string GenerateRequestID()
    {
        return "SC_" + Guid.NewGuid();
    }

    public string GetRequestID()

    {
        var RequestID = _httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(x => x.Type == AppConstants.SecurityHeaders.RequestID)?.Value;
        return RequestID;
    }

    public string GetUserID()
    {
        var userID = _httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
        return userID;
    }

    public string GetUserEmail()
    {
        var Email = _httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(x => x.Type == ClaimTypes.Email)?.Value;
        return Email;
    }

    public string GetDefaultCountryISO()
    {
        return _defaultRegionSetting.Country;
    }

    public string GetDefaultCurrency()
    {
        return _defaultRegionSetting.Currency;
    }
    public string[] GetAllowedCurrencies()
    {
        return _defaultRegionSetting.ValidCurrencies;
    }
    public string GetIpAddress()
    {
        return _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "N/A";
    }
    public string GetUserAgent()
    {
        return _httpContextAccessor.HttpContext?.Request?.Headers?.UserAgent!;
    }

    public bool Do3DSecure()
    {
        return _paymentHubSetting.Do3DSecure;
    }
}