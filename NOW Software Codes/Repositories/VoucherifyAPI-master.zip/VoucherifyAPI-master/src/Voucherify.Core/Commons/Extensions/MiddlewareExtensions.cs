using Microsoft.AspNetCore.Builder;

using Voucherify.Core.Commons.Middlewares;

namespace Voucherify.Core.Commons.Extensions;
public static class MiddlewareExtensions
{
    public static IApplicationBuilder UseAppLoggingMiddleware(this WebApplication app)
    {
        return app.UseMiddleware<AppLoggingMiddleware>();
    }
    public static IApplicationBuilder UseExceptionMiddleware(this WebApplication app)
    {
        return app.UseMiddleware<ExceptionMiddleware>();
    }
}
