using System.Text.Json;

using Microsoft.Extensions.Options;

using Serilog;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Services.Http;
using Voucherify.Core.Services.VoucherifyApi.Definations;
using Voucherify.Core.Services.VoucherifyApi.Models.Campaigns;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;
using Voucherify.Core.Services.VoucherifyApi.Models.EarningRules;
using Voucherify.Core.Services.VoucherifyApi.Models.Events;
using Voucherify.Core.Services.VoucherifyApi.Models.Orders;
using Voucherify.Core.Services.VoucherifyApi.Models.Products;
using Voucherify.Core.Services.VoucherifyApi.Models.Promotions;
using Voucherify.Core.Services.VoucherifyApi.Models.Redemptions;
using Voucherify.Core.Services.VoucherifyApi.Models.Rewards;
using Voucherify.Core.Services.VoucherifyApi.Models.StackableDiscounts;
using Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

using static Voucherify.Core.Services.Http.HttpService;

namespace Voucherify.Core.Services.VoucherifyApi;

public class VoucherifyImplementation : IVoucherifyImplementation
{
    private const string AppIdKey = "X-App-Id";
    private const string AppTokenKey = "X-App-Token";
    private readonly VoucherifySetting _voucherifySetting;
    private readonly IHttpService _httpService;
    private readonly ILogger _logger;

    public VoucherifyImplementation(
        IOptions<VoucherifySetting> voucherifySetting,
        IHttpService httpService,
        ILogger logger)
    {
        _voucherifySetting = voucherifySetting.Value;
        _httpService = httpService
            .WithHeaders(GetVoucherifyHeaders())
            .EnableLogging();
        _logger = logger;
    }

    private List<HttpServiceKeyValues> GetVoucherifyHeaders()
    {
        return new List<HttpServiceKeyValues>() {
            new HttpServiceKeyValues() {Key = AppIdKey, Value =_voucherifySetting.AppId},
            new HttpServiceKeyValues() {Key = AppTokenKey, Value =_voucherifySetting.AppToken}
        };
    }

    // Voucher Api Endpoint
    public async Task<List<Voucher>?> GetVouchers(int pageNumber, int pageSize)
    {
        var targetUrl = $"{_voucherifySetting.ApiEndpoint}{VoucherifyConstants.Endpoints.Vouchers}?limit={pageSize}&page={pageNumber}";
        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            var vouchers = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("vouchers").ToString();
            return JsonSerializerExtensions.Deserialize<List<Voucher>>(vouchers);
        }
        return null;
    }

    public async Task<List<Voucher>?> GetLoyaltyCards(string? customerSourceId = null, string? campaignId = null)
    {
        var targetUrl = $"{_voucherifySetting.ApiEndpoint}{VoucherifyConstants.Endpoints.Vouchers}?customer={customerSourceId}&campaign_id={campaignId}";

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            var vouchers = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("vouchers").ToString();
            return JsonSerializerExtensions.Deserialize<List<Voucher>>(vouchers);
        }
        return null;
    }
    public async Task<Voucher?> GetVoucher(string voucherId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Vouchers + voucherId;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Voucher>(ResponseBody);
        }
        return null;
    }
    public async Task<Voucher?> CreateVoucher(string? voucherCode, VoucherCreate? request)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Vouchers + voucherCode;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, request);

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Voucher>(ResponseBody);
        }
        return null;
    }
    public async Task<Voucher?> UpdateVoucher(string voucherId, VoucherUpdate voucherUpdate)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Vouchers + voucherId;

        var (StatusCode, ResponseBody) = await _httpService.PutAsync(targetUrl, voucherUpdate);

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Voucher>(ResponseBody);
        }
        return null;
    }
    public async Task<bool> DeleteVoucher(string voucherId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Vouchers + voucherId;

        var (StatusCode, _) = await _httpService.DeleteAsync(targetUrl);

        return StatusCode;
    }
    public async Task<Voucher?> EnableVoucher(string voucherCode)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.EnableVoucher, voucherCode);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl);

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Voucher>(ResponseBody);
        }
        return null;
    }
    public async Task<Voucher?> DisableVoucher(string voucherCode)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.DisableVoucher, voucherCode);

        var request = new HttpRequestMessage(HttpMethod.Post, targetUrl);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Voucher>(ResponseBody);
        }
        return null;
    }
    public async Task<Models.Validations.Validation?> ValidateVoucher(string? voucherCode, Customer? customer = null)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.ValidateVoucher, voucherCode);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, new { customer });

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Models.Validations.Validation>(ResponseBody);
        }
        return null;
    }
    public async Task<Redemption?> RedeemVoucher(string? voucherCode, CustomerCreate? newCustomer)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.RedeemVoucher, voucherCode);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, new
        {
            customer = newCustomer
        });
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Redemption>(ResponseBody);
        }
        return null;
    }

    // Get Promotion

    public async Task<List<PromotionTier>?> GetPromotionTiers(int pageNumber, int pageSize)
    {

        var targetUrl = $"{_voucherifySetting.ApiEndpoint}{VoucherifyConstants.Endpoints.Promotions}?limit={pageSize}&page={pageNumber}";

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            var promotionTiers = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("tiers").ToString();
            return JsonSerializerExtensions.Deserialize<List<PromotionTier>>(promotionTiers);
        }
        return null;
    }
    public async Task<PromotionTier?> GetPromotionTierById(string promotionTierId)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Promotions + promotionTierId;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<PromotionTier>(ResponseBody);
        }
        return null;
    }
    public async Task<Redemption?> RedeemPromotion(string? promotionTierId, CustomerCreate? newCustomer)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.RedeemPromotion, promotionTierId);
        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, new { customer = newCustomer });

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Redemption>(ResponseBody);
        }
        return null;
    }
    public async Task<Models.Validations.Validation?> ValidatePromotion(string? promotionTierId, Customer? customer = null)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.ValidatePromotion, promotionTierId);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, new { customer });

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Models.Validations.Validation>(ResponseBody);
        }
        return null;
    }
    public async Task<List<PromotionTier>?> GetValidPromotions(Customer customer, OrderCreate order, Metadata? redemptionMetadata)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.ValidatePromotionList;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, new { customer, order, metadata = redemptionMetadata });

        if (StatusCode)
        {
            var promotions = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("promotions").ToString();
            var result = JsonSerializerExtensions.Deserialize<PromotionTier[]>(promotions);
            return result?.ToList();
        }
        return null;
    }

    // Campaign Api Endpoints
    public async Task<List<Campaign>?> GetCampaigns(int pageNumber, int pageSize)
    {
        var targetUrl = $"{_voucherifySetting.ApiEndpoint}{VoucherifyConstants.Endpoints.Campaigns}?limit={pageSize}&page={pageNumber}";

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            var campaigns = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("campaigns").ToString();
            return JsonSerializerExtensions.Deserialize<List<Campaign>>(campaigns);
        }
        return null;
    }
    public async Task<Campaign?> GetCampaign(string campaignId)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Campaigns + campaignId;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Campaign>(ResponseBody);
        }
        return null;
    }

    public async Task<Campaign?> CreateCampaign(CampaignCreate newCampaign)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Campaigns;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, newCampaign);

        if (StatusCode)
        {

            return JsonSerializerExtensions.Deserialize<Campaign>(ResponseBody);
        }
        return null;
    }

    public async Task<Campaign?> UpdateCampaign(string campaignId, CampaignUpdate campaignUpdate)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Campaigns + campaignId;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, campaignUpdate);

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Campaign>(ResponseBody);
        }
        return null;
    }
    public async Task<bool> DeleteCampaign(string campaignId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Campaigns + campaignId;

        var (StatusCode, ResponseBody) = await _httpService.DeleteAsync(targetUrl);

        return StatusCode;
    }
    public async Task<List<Campaign>?> GetCampaignsAgainstCustomer(Customer? customer)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.ExamineCampaigns;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, new { customer });

        if (StatusCode)
        {

            var campaigns = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("data").ToString();
            return JsonSerializerExtensions.Deserialize<List<Campaign>>(campaigns);
        }
        return null;
    }
    public async Task<Campaign?> EnableCampaign(string? campaignId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.EnableVoucher, campaignId);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Campaign>(ResponseBody);
        }
        return null;
    }
    public async Task<Campaign?> DisableCampaign(string? campaignId)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.DisableVoucher, campaignId);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl);
        if (StatusCode)
        {

            return JsonSerializerExtensions.Deserialize<Campaign>(ResponseBody);
        }
        return null;
    }

    // Earning Rules Endpoint
    public async Task<EarningRule?> GetEarningRule(string campaignId, string earningRuleId)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.EarningRule, campaignId) + earningRuleId;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<EarningRule>(ResponseBody);
        }
        return null;
    }
    public async Task<List<EarningRule>?> GetEarningRules(string campaignId, int pageNumber, int pageSize)
    {

        var targetUrl = $"{_voucherifySetting.ApiEndpoint}{string.Format(VoucherifyConstants.Endpoints.EarningRule, campaignId)}?limit ={pageSize}&page ={pageNumber}";

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            var earningRules = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("data").ToString();
            return JsonSerializerExtensions.Deserialize<List<EarningRule>>(earningRules);
        }
        return null;
    }
    public async Task<EarningRule?> EnableEarningRule(string campaignId, string earningRuleId)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.EnableEarningRule, campaignId, earningRuleId);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<EarningRule>(ResponseBody);
        }
        return null;
    }
    public async Task<EarningRule?> DisableEarningRule(string campaignId, string earningRuleId)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.DisableEarningRule, campaignId, earningRuleId);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<EarningRule>(ResponseBody);
        }
        return null;
    }
    // Reward Api Endpoints
    public async Task<List<Reward>?> GetRewards()
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Rewards;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {

            var rewards = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("data").ToString();
            return JsonSerializerExtensions.Deserialize<List<Reward>>(rewards);
        }
        return null;
    }
    public async Task<Reward?> GetReward(string rewardId)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Rewards + rewardId;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Reward>(ResponseBody);
        }
        return null;
    }
    public async Task<Reward?> UpdateReward(string rewardId, RewardUpdate rewardUpdate)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Rewards + rewardId;

        var (StatusCode, ResponseBody) = await _httpService.PutAsync(targetUrl, rewardUpdate);

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Reward>(ResponseBody);
        }
        return null;
    }
    public async Task<Reward?> CreateReward(RewardCreate rewardCreate)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Rewards;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, rewardCreate);

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Reward>(ResponseBody);
        }
        return null;
    }
    public async Task<bool> DeleteReward(string rewardId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Rewards + rewardId;

        var (StatusCode, ResponseBody) = await _httpService.DeleteAsync(targetUrl);

        return StatusCode;
    }
    public async Task<Redemption?> RedeemReward(string? campaignId, string? memberId, RewardRedeem? rewardRedeem)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.RedeemReward, campaignId, memberId);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, rewardRedeem);

        if (StatusCode)
        {

            return JsonSerializerExtensions.Deserialize<Redemption>(ResponseBody);
        }
        return null;
    }


    // Customers Endpoints
    public async Task<Customer?> CreateCustomer(CustomerCreate newCustomer)
    {


        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Customers;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, newCustomer);

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Customer>(ResponseBody);
        }
        return null;
    }
    public async Task<Customer?> GetCustomer(string customerId)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Customers + customerId;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Customer>(ResponseBody);
        }
        return null;
    }
    public async Task<List<Customer>?> GetCustomers(int pageNumber, int pageSize)
    {
        var targetUrl = $"{_voucherifySetting.ApiEndpoint}{VoucherifyConstants.Endpoints.Customers}?limit={pageSize}&page={pageNumber}";

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            var customers = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("customers").ToString();
            return JsonSerializerExtensions.Deserialize<List<Customer>>(customers);
        }
        return null;
    }
    public async Task<Customer?> UpdateCustomer(string customerId, CustomerUpdate updateCustomer)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Customers + customerId;

        var (StatusCode, ResponseBody) = await _httpService.PutAsync(targetUrl, updateCustomer);

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Customer>(ResponseBody);
        }
        return null;
    }
    public async Task<bool> DeleteCustomer(string customerId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Customers + customerId;

        var (StatusCode, ResponseBody) = await _httpService.DeleteAsync(targetUrl);

        return StatusCode;
    }

    // Order Api Endpoints
    public async Task<Order?> CreateOrder(OrderCreate newOrder)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Orders;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, newOrder);

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Order>(ResponseBody);
        }
        return null;
    }
    public async Task<Order?> GetOrder(string orderId)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Orders + orderId;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Order>(ResponseBody);
        }
        return null;
    }
    public async Task<Order?> GetOrder(string orderId, Order order)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Orders + orderId;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, order);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Order>(ResponseBody);
        }
        return null;
    }
    public async Task<List<Order>?> GetOrders(int pageNumber, int pageSize)
    {
        var targetUrl = $"{_voucherifySetting.ApiEndpoint}{VoucherifyConstants.Endpoints.Orders}?limit={pageSize}&page={pageNumber}";

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            var customers = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("orders").ToString();
            return JsonSerializerExtensions.Deserialize<List<Order>>(customers);
        }
        return null;
    }
    public async Task<Order?> UpdateOrder(string orderId, OrderUpdate order)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Orders + orderId;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, order);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Order>(ResponseBody);
        }
        return null;
    }

    // Stackable Discounts API
    public async Task<StackableDiscountValidation?> ValidateStackableDiscounts(Customer customer, RedeemableDiscounts redeemableDiscounts, OrderCreate order)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.StackableDiscountValidations;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, new { customer, redeemables = redeemableDiscounts.Redeemable, order });

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<StackableDiscountValidation>(ResponseBody);
        }
        return null;
    }
    public async Task<StackableDiscountRedemption?> RedeemStackableDiscounts(Customer customer, RedeemableDiscounts redeemableDiscounts, OrderCreate order)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.StackableDiscountRedemptions;


        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, new { customer = customer, redeemables = redeemableDiscounts.Redeemable, order, options = new VoucherifyExtendedResponse() });

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<StackableDiscountRedemption>(ResponseBody);
        }
        return null;
    }
    public async Task<StackableDiscountRollback?> RollbackStackableDiscounts(string? redemptionId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.StackableDiscountRollback, redemptionId);

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl);

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<StackableDiscountRollback>(ResponseBody);
        }
        return null;
    }


    public async Task<Product?> GetProduct(string? productNameOrId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Products + productNameOrId;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Product>(ResponseBody);
        }
        return null;
    }
    public async Task<List<Product>?> GetProducts(int pageNumber, int pageSize)
    {
        var targetUrl = $"{_voucherifySetting.ApiEndpoint}{VoucherifyConstants.Endpoints.Products}?limit={pageSize}&page={pageNumber}";

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            var products = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("products").ToString();
            return JsonSerializerExtensions.Deserialize<List<Product>>(products);
        }
        return null;
    }

    public async Task<Sku?> GetSKU(string? skuNameOrId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Skus + skuNameOrId;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Sku>(ResponseBody);
        }
        return null;
    }
    public async Task<List<Sku>?> GetSKUs(string? productNameOrId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Products + productNameOrId + VoucherifyConstants.Endpoints.Skus;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {

            var skusData = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("skus").ToString();

            var skus = JsonSerializerExtensions.Deserialize<Sku[]>(skusData);
            return skus?.ToList();
        }
        return null;
    }

    public async Task<List<Campaign>?> GetLoyalties(int pageNumber, int pageSize)
    {

        var targetUrl = $"{_voucherifySetting.ApiEndpoint}{VoucherifyConstants.Endpoints.Loyalties}?limit={pageSize}&page={pageNumber}";

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {

            var vouchers = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("campaigns").ToString();
            return JsonSerializerExtensions.Deserialize<List<Campaign>>(vouchers);
        }
        return null;
    }
    public async Task<Campaign?> GetLoyalty(string? campaignId)
    {

        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Loyalties + campaignId;

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Campaign>(ResponseBody);
        }
        return null;
    }

    public async Task<List<RewardAssignment>?> GetLoyaltyRewards(string? campaignId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + string.Format(VoucherifyConstants.Endpoints.LoyaltiesRewards, campaignId);

        var (StatusCode, ResponseBody) = await _httpService.GetAsync(targetUrl);
        if (StatusCode)
        {
            var rewardAssignment = JsonDocument.Parse(ResponseBody).RootElement.GetProperty("data").ToString();
            return JsonSerializerExtensions.Deserialize<List<RewardAssignment>>(rewardAssignment);
        }
        return null;
    }

    public async Task<Event?> CreateVoucherifyEvent(EventCreate eventData)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Events;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, eventData);

        if (StatusCode)
        {

            return JsonSerializerExtensions.Deserialize<Event>(ResponseBody);
        }
        return null;
    }
    public async Task<Publication?> CreatePublication(string? campaignName, string? customerSourceId)
    {
        var targetUrl = _voucherifySetting.ApiEndpoint + VoucherifyConstants.Endpoints.Publications;

        var (StatusCode, ResponseBody) = await _httpService.PostAsync(targetUrl, new { campaign = new { name = campaignName }, customer = new { source_id = customerSourceId } });

        if (StatusCode)
        {
            return JsonSerializerExtensions.Deserialize<Publication>(ResponseBody);
        }
        return null;
    }
}
