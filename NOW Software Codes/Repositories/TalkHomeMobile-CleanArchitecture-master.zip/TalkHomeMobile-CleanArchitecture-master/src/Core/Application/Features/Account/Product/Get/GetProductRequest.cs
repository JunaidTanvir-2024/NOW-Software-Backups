﻿namespace Application.Features.Account.Product.Get;
public class GetProductRequest : IRequest<Result<IEnumerable<UserProductInfo>>> { }
