using DC.Api.Controllers.Common;

using Microsoft.AspNetCore.Authorization;


namespace DC.Api.Controllers.V1;
public class BundlesController : BaseApiController
{
    [HttpPost, AllowAnonymous]
    public async Task<ActionResult> GetBundles()
    {
        return Ok("Hello");


    }
}
