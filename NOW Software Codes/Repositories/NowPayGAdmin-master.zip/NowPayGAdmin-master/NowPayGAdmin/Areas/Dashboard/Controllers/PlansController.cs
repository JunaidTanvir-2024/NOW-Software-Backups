﻿using BasketWebPanel.Areas.Dashboard.Models;
using BasketWebPanel.Areas.Dashboard.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using BasketWebPanel.Areas.Dashboard.Models.ApiRequest;
using BasketWebPanel.Areas.Dashboard.Models.ApiResponse;
using BasketWebPanel.Areas.Dashboard.Models.ApiRequest.Plans;


namespace BasketWebPanel.Areas.Dashboard.Controllers
{

    
    public class PlansController : Controller
    {
        // GET: Dashboard/Plans
      
        public async Task<int> AddPlans(Addplan model)
        {

            try
            {
                var AddPlanResponse = await ApiCall.CallApi("api/Admin/AddPlan", User, model, false);
                var AddPlan = AddPlanResponse.GetValue("payload").ToObject<bool>();
                if (AddPlan == true)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
                
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        //[CustomAuthorize(Roles = "Admin")]
        public async Task<int> UpdatePlan(Addplan model)
        {

            try
            {
                var AddPlanResponse = await ApiCall.CallApi("api/Admin/UpdatePlan", User, model, false);
                var AddPlan = AddPlanResponse.GetValue("payload").ToObject<bool>();
                if (AddPlan == true)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //[CustomAuthorize(Roles = "Admin")]
        public async Task<ActionResult> Index()
        {
            try
            {
                var claimIdentity = ((ClaimsIdentity)User.Identity);
                WebDashboardStatsViewModel model = new WebDashboardStatsViewModel();
                model.SetSharedData(User);
                //if (!ModelState.IsValid)
                //{
                //    return View(model);
                //}
                AddplansViewModel AddPlanViewModel = new AddplansViewModel();
                // GetCountries
                var CountryResponse = await ApiCall.CallApi("api/CommonServices/GetCountries", User, null, true);
                var Countries = CountryResponse.GetValue("payload").ToObject<CountriesApiResponseModel>();
                AddPlanViewModel.Countries = Countries.Countries;

                // GetPlanCategories
                var PlanCategoriesResponse = await ApiCall.CallApi("api/CommonServices/GetPlanCategories", User, null, true);
                var PlanCategories = PlanCategoriesResponse.GetValue("payload").ToObject<PlanCategoryApiResponseModel>();
                AddPlanViewModel.PlanCategories = PlanCategories.PlanCategories;
                // GetProduct
                var ProductResponse = await ApiCall.CallApi("api/CommonServices/GetProduct", User, null, true);
                var Product = ProductResponse.GetValue("payload").ToObject<ProductApiResponseModel>();
                AddPlanViewModel.Products = Product.Products;
                // GetCurrency
                var CurrencyResponse = await ApiCall.CallApi("api/CommonServices/GetCurrency", User, null, true);
                var Currency = CurrencyResponse.GetValue("payload").ToObject<CurrencyResponseModel>();
                AddPlanViewModel.Currencies = Currency.Currencies;

                //if (response == null)
                //{
                //    return new HttpStatusCodeResult(HttpStatusCode.ServiceUnavailable);
                //}
                //if (response is Error)
                //{
                //    ModelState.AddModelError("", (response as Error).ErrorMessage);
                //    //return View("Login", model);
                //}
                AddPlanViewModel.SetSharedData(User);
                return View("AddPlans",AddPlanViewModel);

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<ActionResult> ManagePlans()
        {

            try
            {
                var claimIdentity = ((ClaimsIdentity)User.Identity);
                GetplansApiResponseModel GetPlans = new GetplansApiResponseModel();
                //var AddPlanResponse = await ApiCall.CallApi("api/CommonServices/GetPlans", User, null, true);
                //var AddPlan = AddPlanResponse.GetValue("payload").ToObject<PlansApiResponseModel>();
                //GetPlans.GetPlans = AddPlan.Plans;
                GetPlans.SetSharedData(User);
               // return Json(AddPlan.Plans);
                return View(GetPlans);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public async Task<ActionResult> GetPlanById(int Id)
        {
            IdModel model = new IdModel
            {
                Id = Id
            };


            try
            {
                var claimIdentity = ((ClaimsIdentity)User.Identity);
                var AddPlanResponse = await ApiCall.CallApi("api/CommonServices/GetPlanById", User, model, false);
                var PlanById = AddPlanResponse.GetValue("payload").ToObject<Addplan>();
                Addplan plans =new Addplan();
               
                return Json(PlanById, JsonRequestBehavior.AllowGet);
                // return View("ManagePlans", GetPlans);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //[Authorize(Roles = "Admin")]
        public async Task<ActionResult> UpdatePlanStatus(int StatusID,int UserID)
        {
            UpdatePlanStatusModel model = new UpdatePlanStatusModel()
            {
                StatusID = StatusID,
                UserID = UserID
            };


            try
            {
                var claimIdentity = ((ClaimsIdentity)User.Identity);
                var AddPlanResponse = await ApiCall.CallApi("api/Admin/UpdatePlanStatus", User, model);
                var PlanActive_Deactive = AddPlanResponse.GetValue("payload").ToObject<bool>();
             

                return Json(PlanActive_Deactive, JsonRequestBehavior.AllowGet);
                // return View("ManagePlans", GetPlans);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        
        public async Task<ActionResult> GetJsonPlan()
        {
            try
            {
                var claimIdentity = ((ClaimsIdentity)User.Identity);
                GetplansApiResponseModel GetPlans = new GetplansApiResponseModel();
                var AddPlanResponse = await ApiCall.CallApi("api/CommonServices/GetAllPlans", User, null,true);
                var AddPlan = AddPlanResponse.GetValue("payload").ToObject<PlansApiResponseModel>();
                GetPlans.GetPlans = AddPlan.Plans;
                GetPlans.SetSharedData(User);
                return Json(GetPlans.GetPlans, JsonRequestBehavior.AllowGet);
                // return Json(AddPlan.Plans);
                //return View("ManagePlans", GetPlans);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<ActionResult> GetLists()
        {

            try
            {
                AddplansViewModel AddPlanViewModel = new AddplansViewModel();
                // GetCountries
                var CountryResponse = await ApiCall.CallApi("api/CommonServices/GetCountries", User, null, true);
                var Countries = CountryResponse.GetValue("payload").ToObject<CountriesApiResponseModel>();
                AddPlanViewModel.Countries = Countries.Countries;

                // GetPlanCategories
                var PlanCategoriesResponse = await ApiCall.CallApi("api/CommonServices/GetPlanCategories", User, null, true);
                var PlanCategories = PlanCategoriesResponse.GetValue("payload").ToObject<PlanCategoryApiResponseModel>();
                AddPlanViewModel.PlanCategories = PlanCategories.PlanCategories;
                // GetProduct
                var ProductResponse = await ApiCall.CallApi("api/CommonServices/GetProduct", User, null, true);
                var Product = ProductResponse.GetValue("payload").ToObject<ProductApiResponseModel>();
                AddPlanViewModel.Products = Product.Products;
                // GetCurrency
                var CurrencyResponse = await ApiCall.CallApi("api/CommonServices/GetCurrency", User, null, true);
                var Currency = CurrencyResponse.GetValue("payload").ToObject<CurrencyResponseModel>();
                AddPlanViewModel.Currencies = Currency.Currencies;



                return Json(AddPlanViewModel, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
       

        public ActionResult ShowAllPlans()
        {
            return View();
        }
    }
}