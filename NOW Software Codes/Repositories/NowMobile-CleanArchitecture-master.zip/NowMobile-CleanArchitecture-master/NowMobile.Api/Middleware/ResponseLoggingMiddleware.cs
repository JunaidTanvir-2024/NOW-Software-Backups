using Application.Common.Interfaces.Shared;
using Serilog;
using Serilog.Context;
using System.Text;

namespace NowMobile.Api.Middleware;
internal sealed class ResponseLoggingMiddleware : IMiddleware
{
    private readonly ICurrentUser _currentUser;

    public ResponseLoggingMiddleware(ICurrentUser currentUser) => _currentUser = currentUser;

    public async Task InvokeAsync(HttpContext httpContext, RequestDelegate next)
    {
        httpContext.Request.EnableBuffering();
        await next(httpContext);
        string responseBody = "";
        if (httpContext.Request.Path.ToString().Contains("tokens"))
        {
            responseBody = "[Redacted] Contains Sensitive Information.";
        }
        else
        {
            try
            {
                httpContext.Request.Body.Position = 0;
                using (StreamReader reader
                  = new StreamReader(httpContext.Request.Body, Encoding.UTF8, true, 1024, true))
                {
                    responseBody = await reader.ReadToEndAsync();
                }
            }
            catch (Exception)
            {
                httpContext.Request.Body.Position = 0;
            }
        }

        string email = _currentUser.GetUserEmail() is string userEmail ? userEmail : "Anonymous";
        var userId = _currentUser.GetUserId();
        if (userId != 0)
        {
            LogContext.PushProperty("UserId", userId);
        }

        LogContext.PushProperty("UserEmail", email);
        LogContext.PushProperty("StatusCode", httpContext.Response.StatusCode);
        LogContext.PushProperty("ResponseTimeUTC", DateTime.UtcNow);
        Log.ForContext("ResponseHeaders", httpContext.Response.Headers.ToDictionary(h => h.Key, h => h.Value.ToString()), destructureObjects: true)
       .ForContext("ResponseBody", responseBody)
       .Information("HTTP {RequestMethod} Request to {RequestPath} by {RequesterEmail} has Status Code {StatusCode}.", httpContext.Request.Method, httpContext.Request.Path, string.IsNullOrEmpty(email) ? "Anonymous" : email, httpContext.Response.StatusCode);
    }
}

internal static class ResponseLoggingMiddlewareExtensions
{
    internal static IApplicationBuilder UseResponseLogging(this IApplicationBuilder app, bool isEnableHttpsLogging)
    {
        if (isEnableHttpsLogging)
        {
            app.UseMiddleware<ResponseLoggingMiddleware>();
        }
        return app;
    }
}