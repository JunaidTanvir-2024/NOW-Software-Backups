using FluentValidation;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Loyalties.Requests;

public class AddLoyaltyPointsRequest
{
    public string EventName { get; set; } = null!;
    public int Points { get; set; }
    public string CustomerNameOrId { get; set; } = null!;
    public Metadata? CustomerMetadata { get; set; }
    public Metadata? EventMetadata { get; set; }
}

internal class AddLoyaltyPointsRequestValidator : AbstractValidator<AddLoyaltyPointsRequest>
{
    public AddLoyaltyPointsRequestValidator()
    {
        RuleFor(p => p.Points).GreaterThan(0);
        RuleFor(p => p.EventName).NotNull().NotEmpty();
        RuleFor(p => p.CustomerNameOrId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.CustomerNameOrId = phoneNumber);
    }
}
