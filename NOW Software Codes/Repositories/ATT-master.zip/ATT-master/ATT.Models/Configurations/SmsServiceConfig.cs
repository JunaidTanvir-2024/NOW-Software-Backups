﻿namespace ATT.Models.Configurations
{
    public class SmsServiceConfig
    {
        public bool EnableSmsSendingService { set; get; }
    }
}
