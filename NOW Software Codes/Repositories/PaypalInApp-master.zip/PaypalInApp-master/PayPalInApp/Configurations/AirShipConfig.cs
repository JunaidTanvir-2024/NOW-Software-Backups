﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Configurations
{
    public class AirShipConfig
    {
        public bool IsActive { get; set; }
        public string PaymentTagGroupName { get; set; }
        public string CustomerTagGroupName { get; set; }
    }
}
