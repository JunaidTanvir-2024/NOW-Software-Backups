﻿namespace CallingCode.Mvc.Common.Enums;

public class WmoCodes
{

    public enum WeatherCondition
    {
        ClearSky = 0,
        MainlyClear = 1,
        PartlyCloudy = 2,
        Overcast = 3,
        Fog = 45,
        DepositRimeFog = 48,
        DrizzleLight = 51,
        DrizzleModerate = 53,
        DrizzleDense = 55,
        FreezingDrizzleLight = 56,
        FreezingDrizzleDense = 57, 
        RainSlight = 61,
        RainModerate = 63,
        RainHeavy = 65,
        FreezingRainLight = 66,
        FreezingRainHeavy = 67,
        SnowFallSlight = 71,
        SnowFallModerate = 73,
        SnowFallHeavy = 75,
        SnowGrains = 77,
        RainShowersSlight = 80,
        RainShowersModerate = 81,
        RainShowersViolent = 82,
        SnowShowersSlight = 85,
        SnowShowersHeavy = 86,
        ThunderstormSlight = 95,
        ThunderstormModerate = 95,
        ThunderstormHeavy = 95,
        ThunderstormSlightHail = 96,
        ThunderstormHeavyHail = 99
    }

    public static readonly Dictionary<long, WeatherCondition> WeatherCodeMap = new Dictionary<long, WeatherCondition>
    {
        { 0, WeatherCondition.ClearSky },
        { 1, WeatherCondition.MainlyClear },
        { 2, WeatherCondition.PartlyCloudy },
        { 3, WeatherCondition.Overcast },
        { 45, WeatherCondition.Fog },
        { 48, WeatherCondition.DepositRimeFog },
        { 51, WeatherCondition.DrizzleLight },
        { 53, WeatherCondition.DrizzleModerate },
        { 55, WeatherCondition.DrizzleDense },
        { 56, WeatherCondition.FreezingDrizzleLight },
        { 57, WeatherCondition.FreezingDrizzleDense },
        { 61, WeatherCondition.RainSlight },
        { 63, WeatherCondition.RainModerate },
        { 65, WeatherCondition.RainHeavy },
        { 66, WeatherCondition.FreezingRainLight },
        { 67, WeatherCondition.FreezingRainHeavy },
        { 71, WeatherCondition.SnowFallSlight },
        { 73, WeatherCondition.SnowFallModerate },
        { 75, WeatherCondition.SnowFallHeavy },
        { 77, WeatherCondition.SnowGrains },
        { 80, WeatherCondition.RainShowersSlight },
        { 81, WeatherCondition.RainShowersModerate },
        { 82, WeatherCondition.RainShowersViolent },
        { 85, WeatherCondition.SnowShowersSlight },
        { 86, WeatherCondition.SnowShowersHeavy },
        { 95, WeatherCondition.ThunderstormSlight },
        { 96, WeatherCondition.ThunderstormSlightHail },
        { 99, WeatherCondition.ThunderstormHeavyHail }
    };
}