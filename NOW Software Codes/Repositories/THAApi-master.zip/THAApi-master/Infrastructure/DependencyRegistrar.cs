﻿using Infrastructure.BLL.Implementation;
using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.BLL.Services.Voucherify;
using Infrastructure.DAL.Implementation;
using Infrastructure.DAL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Models.Configurations;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace Infrastructure
{
	public static class DependencyRegistrar
    {
        //Business Layer Services
        public static void RegisterBLServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddTransient<IPayment_BL, Payment_BL>();
            services.AddTransient<IATT_BL, ATT_BL>();
            services.AddTransient<IPush_BL, Push_BL>();
            services.AddTransient<IPush_BL, Push_BL>();
            services.AddTransient<IHslSms_BL, HslSms_BL>();
            services.AddTransient<IBundle_BL, Bundle_BL>();
            services.AddTransient<IUserAccount_BL, UserAccount_BL>();
            services.AddTransient<ITopup_BL, Topup_BL>();
            services.AddTransient<IOneSignalPush_BL, OneSignalPush_BL>();
            services.AddTransient<IClxSms_BL, ClxSms_BL>();
            services.AddTransient<ITransfer_BL, Transfer_BL>();
            services.AddTransient<IHistory_BL, History_BL>();
            services.AddTransient<ISMS_BL, SMS_BL>();
            services.AddTransient<ITwillioService, TwillioService>();
            services.AddTransient<IJwt_BL, Jwt_BL>();
            services.AddSingleton<ICulture_BL, Culture_BL>();
            services.AddTransient<IPhoneNumberService, PhoneNumberService>();
            services.AddTransient<ICommon_BL, Common_BL>();
            services.AddTransient<IEmailService, EmailService>();
            services.AddTransient<IPay360Service, Pay360Service>();
            services.AddTransient<IHelper_BL, Helper_BL>();
            services.AddTransient<IPlatformTesterService, PlatformTesterService>();
            services.AddTransient<IPaymentFullfillment_DL, PaymentFullfillment_DL>();
            services.AddTransient<IFaceBookService, FaceBookService>();
            services.AddTransient<ICustomerRatingService, CustomerRatingService>();
            services.AddScoped<IVoucherify_BL, Voucherify_BL>();
            services.AddTransient<IVoucherifyService, VoucherifyService>();
            services.AddTransient<ICustomerRating_BL, CustomerRating_BL>();
            services.AddSingleton<IInternationalTopupServiceFeeCalculator, InternationalTopupServiceFeeCalculator>();
            services.AddTransient<IAutoTopup_DL,AutoTopup_DL>();
            //Http clients
            services.AddHttpClient<IPayPalPay360Service, PayPalPay360Service>(client =>
            {
                client.BaseAddress = new Uri(configuration["PayPal:PayPalByP630ApiEndpoint"]);
            });
            services.AddHttpClient<IPayPalService, PayPalService>(client =>
            {
                client.BaseAddress = new Uri(configuration["PayPal:PayPalApiEndpoint"]);
            });
            services.AddHttpClient<IApiCall, ApiCall>();
            services.AddHttpClient<IHttpService, HttpService>(client =>
            {
                client.Timeout = TimeSpan.FromSeconds(60);
            });
            services.AddHttpClient<IAirShipService, AirShipService>(client =>
            {
                client.BaseAddress = new Uri(configuration["AirShipConfig:ApiEndpoint"]);
            });
            //services.AddHttpClient<IFaceBookService, FaceBookService>(client =>
            //{
            //    client.BaseAddress = new Uri(configuration["FaceBookConfig:ApiEndpoint"]);
            //});
            services.AddHttpClient<IAppsFlyerService, AppsFlyerService>(client =>
            {
                client.BaseAddress = new Uri(configuration["AppsFlyerConfig:ApiEndpoint"]);
            });
            services.AddHttpClient<IAddressService, AddressService>(client =>
            {
                client.BaseAddress = new Uri(configuration["AddressApiConfig:ApiEndpoint"]);
                String encodedBaiscAuthToken = Convert.ToBase64String(
                    Encoding.GetEncoding("ISO-8859-1").GetBytes(configuration["AddressApiConfig:ApiKey"]));
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + encodedBaiscAuthToken);
            });
            services.AddHttpClient<IATTService, ATTService>(client =>
            {
                client.BaseAddress = new Uri(configuration["ATTApi:ApiEndpoint"]);
            });
            services.AddHttpClient<ISapSmsService, SapSmsService>(client =>
            {
                client.BaseAddress = new Uri(configuration["SmsApi:sms_sap_local_uri"]);
            });
        }
        //Data Layer Services
        public static void RegisterDLServices(this IServiceCollection services)
        {
            services.AddHttpClient<IUserAccount_DL, UserAccount_DL>(client =>
            {
                client.BaseAddress = new Uri("http://172.20.120.134/");
                client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
                client.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue(
                        "Basic",
                        Convert.ToBase64String(Encoding.ASCII.GetBytes("NowtelAPIUser:trR_911@54FD")));
            });
            services.AddTransient<IBundle_DL, Bundle_DL>();
            services.AddTransient<IOffer_DL, Offer_DL>();
            services.AddTransient<IAppConfig_DL, AppConfig_DL>();
            services.AddTransient<ITransaction_DL, Transaction_DL>();
            services.AddTransient<ITopup_DL, Topup_DL>();
            services.AddTransient<IHistory_DL, History_DL>();
            services.AddTransient<IPush_DL, Push_DL>();
            services.AddTransient<IBalance_DL, Balance_DL>();
            services.AddTransient<IATT_DL, ATT_DL>();
            services.AddTransient<ISMS_DL, SMS_DL>();
        }
    }
}
