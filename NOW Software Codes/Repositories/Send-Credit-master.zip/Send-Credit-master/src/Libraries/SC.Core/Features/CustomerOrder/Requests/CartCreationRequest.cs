﻿

using SC.Core.Common.Interfaces.Services;
using System.Data.SqlTypes;
using System.Text.Json.Serialization;

namespace SC.Core.Features.CustomerOrder.Requests;
public sealed class CartCreationRequest : IRequest<IResultWrapper>
{
    public long CustomerCartID { get; set; } = default!;
    public long ProductID { get; set; } = default!;
    public long CustomerOrderID { get; set; } = default!;
    public string CustomerID { get; set; } = default!;
    public string ProductName { get; set; } = default!;
    public int Quantity { get; set; } = default!;
    public string DiscountType { get; set; } = default!;
    public decimal DiscountAmount { get; set; } = decimal.Zero;
    public decimal Price { get; set; } = decimal.Zero;
    public string Currency { get; set; } = default!;
    public string Status { get; set; } = default!;
    public string State { get; set; } = default!;
    public bool isDeleted { get; set; } = false;
    public bool isActive { get; set; } = true;
    public bool IsGuestUser { get; set; } = default!;
    public string? UserID { get; set; } = default!;
    public decimal ProductPrice { set; get; }=default!;
}
public sealed class CartCreationRequestValidator : AbstractValidator<CartCreationRequest>
{
    private readonly ICommonService _commonService;
    private readonly IHelperService _client;
    public CartCreationRequestValidator(ICommonService commonService, IHelperService client)
    {
        _commonService = commonService;
        _client = client;
        RuleFor(x => x.ProductID).GreaterThan(0);
        RuleFor(x => x.Currency).NotNull().NotEmpty().WithMessage("Currency cannot be empty.")
            .Must(IsValidCurrency).WithMessage("Invalid currency value.");
        RuleFor(x => x.UserID).MustAsync(async (userId, cancellation) => await _client.ValidateGuestUser(userId)).WithMessage("User ID does not exist in system, must be a valid user").When(x => x.IsGuestUser);
      
    }
    private bool IsValidCurrency(string currency)
    {
        return _commonService.GetAllowedCurrencies().Contains(currency.ToUpper());
    }
}

