using FluentValidation;

namespace Voucherify.Api.Features.Loyalties.Requests;

public class GetLoyaltyRewardsByCampaignIdRequest
{
    public string? CampaignId { get; set; }
}
internal class GetLoyaltyRewardsByCampaignIdRequestValidator : AbstractValidator<GetLoyaltyRewardsByCampaignIdRequest>
{
    public GetLoyaltyRewardsByCampaignIdRequestValidator()
    {
        RuleFor(p => p.CampaignId).NotNull().NotEmpty();
    }
}
