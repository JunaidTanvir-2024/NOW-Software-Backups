﻿using System;

namespace Models.Contracts.Request
{
    public class UserAccountCallHistory
    {
        public string Destination { get; set; }

        public string Type { get; set; }

        public string Duration { get; set; }

        public string Charge { get; set; }

        public DateTime DateTime { get; set; }
    }
}
