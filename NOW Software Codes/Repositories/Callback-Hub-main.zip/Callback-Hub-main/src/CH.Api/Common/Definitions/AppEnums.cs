namespace CH.Api.Common.Definitions;

public static class AppEnums
{
    public enum Vendor
    {
        FusionHub = 1,
    }
    public enum ClientInformation
    {
        ProductCode,
        ProductItemCode,
        UniqueReference
    }
}
