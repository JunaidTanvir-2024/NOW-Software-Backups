﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IATT_BL
    {
        Task<GenericApiResponse<ProductsForTransactionOutputArray>> GetProductsNew(UserAccountBalance userAccount, string destination, string clientMSISDN, string sendTopupDescription);
        Task<DBProduct> GetProductByNowtelTransactionReference(string nowtelref, string product);
        Task<GenericApiResponse<AirtimeTransferExecute>> ExecuteTransactionByBalance(TransFerTotransferConfirm request, string fromMsisdn);
        Task<GenericApiResponse<AirtimeTransferExecute>> ExecuteTransactionByBalanceV2(TransFerTotransferConfirmV2 request, string fromMsisdn);
        Task<GenericApiResponse<ATTTransactions>> GetAttHistoryAsync(TransferToTransactionsListRequest request,string account);
        Task<bool> IsFirstInternationalTopup(string accountId);
    }
}
