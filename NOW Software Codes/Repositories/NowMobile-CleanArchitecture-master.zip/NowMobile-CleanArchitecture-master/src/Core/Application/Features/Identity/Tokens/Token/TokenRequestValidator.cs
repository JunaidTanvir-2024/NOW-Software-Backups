﻿namespace Application.Features.Identity.Tokens.Token;

public class RefreshTokenRequestValidator : AbstractValidator<TokenRequest>
{
    public RefreshTokenRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.UserInfo).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.UserInfo.EmailOrPhone).Cascade(CascadeMode.Stop).NotNull().NotEmpty().MaximumLength(50).When(p => p.UserInfo != null);
        RuleFor(p => p.UserInfo.Password).Cascade(CascadeMode.Stop).NotNull().NotEmpty().MaximumLength(50).When(p => p.UserInfo != null);
        RuleFor(p => p.UserInfo.EmailOrPhone).Cascade(CascadeMode.Stop)
            .Must(p => commonService.IsValidEmailAddress(p))
                .When(p => p.UserInfo != null && !string.IsNullOrEmpty(p.UserInfo.EmailOrPhone) && !p.UserInfo.EmailOrPhone.All(char.IsDigit), ApplyConditionTo.CurrentValidator)
                .WithMessage("Invalid Email Address")
            .Must(p => commonService.IsValidMsisdn(p))
                .When(p => p.UserInfo != null && !string.IsNullOrEmpty(p.UserInfo.EmailOrPhone) && p.UserInfo.EmailOrPhone.All(char.IsDigit), ApplyConditionTo.CurrentValidator)
                .WithMessage("Invalid Phone Number");


        //RuleFor(p => p.AppInfo.CpuArchitecture).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.ActionExecuted).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DeviceOS).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DeviceOSVersion).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DeviceMake).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DeviceModel).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DeviceLanguage).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DevicePersistentID).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.AppVersion).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.AppLanguage).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
    }
}
