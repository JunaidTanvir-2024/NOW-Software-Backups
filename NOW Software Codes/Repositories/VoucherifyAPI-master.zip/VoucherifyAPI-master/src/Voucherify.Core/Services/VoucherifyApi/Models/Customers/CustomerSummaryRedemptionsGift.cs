using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Customers;

public class CustomerSummaryRedemptionsGift
{
    [JsonPropertyName("redeemed_amount")]
    public long RedeemedAmount { get; set; }

    [JsonPropertyName("amount_to_go")]
    public long AmountToGo { get; set; }
}