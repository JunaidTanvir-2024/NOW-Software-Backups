﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class GetAddressByPostCodeRequestModel
    {
        [MaxLength(50)]
        public string PostCode { get; set; }
    }

    public class GetAddressByPostCodeResponseModel
    {
        public AddressModel AddressData { get; set; }
    }

    public class AddressModel
    {
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public IList<string> Addresses { get; set; }
        public string Message { get; set; }
    }
}
