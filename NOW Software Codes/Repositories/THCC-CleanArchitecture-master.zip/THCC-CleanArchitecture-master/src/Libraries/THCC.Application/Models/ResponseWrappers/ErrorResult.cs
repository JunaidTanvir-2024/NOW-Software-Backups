﻿namespace THCC.Application.Models.ResponseWrappers
{
    public class ErrorResult
    {
        public ErrorResult()
        {
            Errors = new List<ErrorDto>();
        }
        public List<ErrorDto> Errors { get; set; } = default!;
        public static ErrorResult Failure(string message, int errorCode)
        {
            return new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto() { Code = errorCode, Message = message }
                }
            };
        }
    }
    public class ErrorDto
    {
        public int Code { get; set; }
        public string? Message { get; set; }
    }
}
