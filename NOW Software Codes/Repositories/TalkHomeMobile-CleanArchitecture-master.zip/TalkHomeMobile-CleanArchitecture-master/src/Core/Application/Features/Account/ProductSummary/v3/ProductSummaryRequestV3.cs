﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Account.ProductSummary.v3;
public class ProductSummaryRequestV3 : IRequest<Result<ProductSummaryResponse>>
{
    public string Msisdn { get; set; } = default!;
}
