﻿using FluentValidation;

namespace Voucherify.Api.Features.Promotions.Requests;

public class GetPromotionTierByIdRequest
{
    public string PromotionTierId { get; set; } = null!;
}

internal class GetPromotionTierByIdRequestValidator : AbstractValidator<GetPromotionTierByIdRequest>
{
    public GetPromotionTierByIdRequestValidator()
    {
        RuleFor(p => p.PromotionTierId).NotNull().NotEmpty();
    }
}