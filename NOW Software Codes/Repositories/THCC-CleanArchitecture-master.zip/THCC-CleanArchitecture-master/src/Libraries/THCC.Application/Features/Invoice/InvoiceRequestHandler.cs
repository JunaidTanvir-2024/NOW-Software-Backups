﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

namespace THCC.Application.Features.Invoice;

public class InvoiceRequestHandler : IRequestHandler<InvoiceRequest, object>
{
    #region Fields 

    private readonly IPaymentRepository _paymentRepo;
    private readonly IUserRepository _userRepo;
    private readonly ILogger _logger;
    private readonly ITemplateService _templateService;
    private readonly ICurrentUser _currentUser;

    #endregion

    #region Ctors

    public InvoiceRequestHandler(
          IPaymentRepository paymentRepository,
          IUserRepository userRepository,
          ILogger logger,
          ITemplateService emailService,
          ICurrentUser currentUser)
    {
        _paymentRepo = paymentRepository;
        _userRepo = userRepository;
        _logger = logger;
        _templateService = emailService;
        _currentUser = currentUser;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(InvoiceRequest request, CancellationToken cancellationToken)
    {
        request.EmailAddress = request.EmailAddress.Trim();

        var invoiceInfo = new InvoiceDto();

        //Get Order Details
        var orderDetails = await _paymentRepo.GetOrderDetails(null, request.ReferenceId.Trim());
        if (orderDetails == null)
        {
            _logger.Debug($"Invoice => No order found with {request.EmailAddress} {request.ReferenceId}");
            return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
        }

        var orderUserData = await _userRepo.GetUserByIdAsync(orderDetails.UserId!);
        if (orderDetails.ProductType == ProductType.FastTopup)
        {
            if (!orderUserData!.Email!.Equals(request.EmailAddress))
            {
                _logger.Debug($"Invoice => FastTopup email order not matched {request.EmailAddress} {orderUserData.Email} {request.ReferenceId}");
                return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
            }
        }
        else if (orderDetails.ProductType == ProductType.CallingCard)
        {
            if (!orderUserData!.Email!.Equals(request.EmailAddress))
            {
                _logger.Debug($"Invoice => Guest Checkout Calling Card email order not matched {request.EmailAddress} {orderUserData.Email} {request.ReferenceId}");
                return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
            }
        }
        else
        {
            if (!_currentUser.IsAuthenticated())
            {
                _logger.Debug($"Invoice => user no authenticated {request.EmailAddress} {request.ReferenceId}");
                return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
            }

            if (!_currentUser.GetUserId().Equals(orderUserData!.Id))
            {
                _logger.Debug($"Invoice => user not matched {_currentUser.GetUserId()} {request.EmailAddress} {request.ReferenceId}");
                return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
            }
        }

        // bind invoice info
        invoiceInfo.Email = orderUserData?.Email;
        invoiceInfo.FirstName = orderUserData?.FirstName!;
        invoiceInfo.LastName = orderUserData?.LastName!;
        invoiceInfo.OrderDate = $"{orderDetails.OrderDateTime:dd/MM/yyyy}";
        invoiceInfo.OrderTime = orderDetails.OrderDateTime.ToShortTimeString();
        invoiceInfo.TransactionId = orderDetails.OrderReference;
        invoiceInfo.PaymentMethod = orderDetails.PaymentMethodId == PaymentMethod.Card ? "Credit Card" :
            orderDetails.PaymentMethodId == PaymentMethod.Paypal ? "Paypal" :
            orderDetails.PaymentMethodId == PaymentMethod.Points ? $"Redeem Points - {(int)orderDetails.OpeningPoints! - (int)orderDetails.ClosingPoints!} Points" : null;
        invoiceInfo.Product = orderDetails.ProductType == ProductType.CallingCard ? "Classic Card" :
             orderDetails.ProductType == ProductType.RechargeableCallingCard ? "Rechargeable Card" :
             orderDetails.ProductType == ProductType.AutoTopupTransaction ? "Auto Recharge" :
             orderDetails.ProductType == ProductType.FastTopup ? "Fast Recharge" : "Card Recharged";
        invoiceInfo.RechargeAmount = CurrencySymbol.GBP + orderDetails.Amount;
        invoiceInfo.TotalAmount = CurrencySymbol.GBP + orderDetails.TotalAmount;
        invoiceInfo.PinNumber = orderDetails.CardPin;
        invoiceInfo.CardNumber = orderDetails.CardNumber;

        if (orderDetails.ProductType == ProductType.FastTopup)
        {
            var userProduct = await _userRepo.GetUserProducts(orderDetails.UserId!);
            if (userProduct == null
                || userProduct.Product != invoiceInfo.CardNumber
                || !orderDetails.UserId!.Equals(orderDetails.PaymentUserId))
            {
                invoiceInfo.IsGuestUser = true;
            }
        }

        if (!invoiceInfo.IsGuestUser)
        {
            invoiceInfo.OpeningBalance = CurrencySymbol.GBP + orderDetails.OpeningBalance;
            invoiceInfo.ClosingBalance = CurrencySymbol.GBP + orderDetails.ClosingBalance!;
            invoiceInfo.OpeningPoints = (int)orderDetails.OpeningPoints!;
            invoiceInfo.RewardPoints = (int)orderDetails.PointsReceived!;
            invoiceInfo.ClosingPoints = (int)orderDetails.ClosingPoints!;
        }

        await _paymentRepo.SaveOrderHistory(orderDetails.Id, OrderHistoryConstants.InvoiceDownloaded);

        var htmlbody = _templateService.GenerateTemplate(
            TemplateNames.Invoice, new
            {
                invoiceInfo
            });

        return htmlbody!;
    }

    #endregion
}
