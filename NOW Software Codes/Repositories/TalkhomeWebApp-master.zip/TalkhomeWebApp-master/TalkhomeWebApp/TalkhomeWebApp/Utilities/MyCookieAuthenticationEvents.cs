﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Utilities
{
    public class MyCookieAuthenticationEvents : CookieAuthenticationEvents
    {
        private readonly bool isDevelopment;

        public MyCookieAuthenticationEvents(bool IsDevelopment)
        {
            isDevelopment = IsDevelopment;
        }

        public override Task RedirectToLogin(RedirectContext<CookieAuthenticationOptions> context)
        {
            if (!string.IsNullOrEmpty(context.RedirectUri) && !context.RedirectUri.StartsWith("https") && !isDevelopment)
            {
                context.RedirectUri = context.RedirectUri.Replace("http", "https");
            }
            return base.RedirectToLogin(context);
        }
    }
}
