﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class TransferByPayPalCallBackV2RequestModel
    {
        public string Token { get; set; }
        public string IpAddress { get; set; }

        //Transfer Related Data
        public string NowtelRef { get; set; }
        public string Product { get; set; }
        public string OperatorId { get; set; }
    }
}
