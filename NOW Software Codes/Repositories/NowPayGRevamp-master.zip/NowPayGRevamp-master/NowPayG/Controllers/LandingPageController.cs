﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NowPayG.Configurations;
using NowPayG.Models.ApiContracts.Response;
using NowPayG.Models.ViewModels;
using Serilog;

namespace NowPayG.Controllers
{
    public class LandingPageController : Controller
    {
        private readonly string NowPayGApiEndPoint;
        private readonly ILogger Logger;

        public LandingPageController(IOptions<EndPoints> endPoints, ILogger logger)
        {
            NowPayGApiEndPoint = endPoints.Value.NowPaygApiEndPoint;
            Logger = logger;
        }

        [HttpGet]
        [Route("free-sim-card-pakistan")]
        [AllowAnonymous]
        public async Task<IActionResult> Pakistan()
        {
            try
            {
                PakistanLandingPageViewModel model = new PakistanLandingPageViewModel();
                await model.SetSharedDataAsync(User);

                var Plan = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);
                if (Plan != null)
                {
                    if (Plan is Error)
                    {
                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        PlansResponseModel Plans = Plan.GetValue("payload").ToObject<PlansResponseModel>();
                        model.Plans = Plans;
                    }
                }

                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: LandingPageController, Method: Pakistan, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("free-sim-card-pakistan/plan-10")]
        [Route("free-sim-card-pakistan/plan-15")]
        [Route("free-sim-card-pakistan/plan-20")]
        [AllowAnonymous]
        public async Task<IActionResult> PakistanSingle()
        {

            try
            {
                double amount = 0;
                if (HttpContext.Request.Path.Value.Contains("plan-10"))
                {
                    amount = 10;
                }
                else if (HttpContext.Request.Path.Value.Contains("plan-15"))
                {
                    amount = 15;
                }
                else if (HttpContext.Request.Path.Value.Contains("plan-20"))
                {
                    amount = 20;
                }

                PakistanLandingPageViewModel model = new PakistanLandingPageViewModel();
                await model.SetSharedDataAsync(User);

                var Plan = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);
                if (Plan != null)
                {
                    if (Plan is Error)
                    {
                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        PlansResponseModel Plans = Plan.GetValue("payload").ToObject<PlansResponseModel>();

                        foreach (var item in Plans.Plans.Where(x => x.CountryId == 179 && x.Price == amount)) //===>179-Pakistan
                        {
                            model.Plan = item;
                        }
                    }
                }
                return View(model);
            }

            catch (Exception ex)
            {
                Logger.Error($"Class: LandingPageController, Method: PakistanSingle, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("free-sim-card-nigeria")]
        [AllowAnonymous]
        public async Task<IActionResult> Nigeria()
        {
            try
            {
                NigeriaLandingPageViewMOdel model = new NigeriaLandingPageViewMOdel();
                await model.SetSharedDataAsync(User);

                var Plan = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);
                if (Plan != null)
                {
                    if (Plan is Error)
                    {
                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        PlansResponseModel Plans = Plan.GetValue("payload").ToObject<PlansResponseModel>();
                        model.Plans = Plans;
                    }
                }

                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: LandingPageController, Method: Nigeria, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("free-sim-card-nigeria/plan-10")]
        [Route("free-sim-card-nigeria/plan-20")]
        [AllowAnonymous]
        public async Task<IActionResult> NigeriaSingle()
        {
            try
            {
                double amount = 0;
                if (HttpContext.Request.Path.Value.Contains("plan-10"))
                {
                    amount = 10;
                }
                else if (HttpContext.Request.Path.Value.Contains("plan-20"))
                {
                    amount = 20;
                }

                NigeriaLandingPageViewMOdel model = new NigeriaLandingPageViewMOdel();
                await model.SetSharedDataAsync(User);

                var Plan = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);
                if (Plan != null)
                {
                    if (Plan is Error)
                    {
                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        PlansResponseModel Plans = Plan.GetValue("payload").ToObject<PlansResponseModel>();

                        foreach (var item in Plans.Plans.Where(x => x.CountryId == 167 && x.Price == amount)) //===>167- Nigeria
                        {
                            model.Plan = item;
                        }
                    }
                }
                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: LandingPageController, Method: NigeriaSingle, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("free-sim-card-bangladesh")]
        [AllowAnonymous]
        public async Task<IActionResult> Bangladesh()
        {
            try
            {
                BangladeshLandingPageViewModel model = new BangladeshLandingPageViewModel();
                await model.SetSharedDataAsync(User);

                var Plan = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);
                if (Plan != null)
                {
                    if (Plan is Error)
                    {
                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        PlansResponseModel Plans = Plan.GetValue("payload").ToObject<PlansResponseModel>();
                        model.Plans = Plans;
                    }
                }
                return View(model);
            }

            catch (Exception ex)
            {
                Logger.Error($"Class: LandingPageController, Method: Bangladesh, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("free-sim-card-bangladesh/plan-10")]
        [Route("free-sim-card-bangladesh/plan-20")]
        [AllowAnonymous]
        public async Task<IActionResult> BangladeshSingle()

        {
            try
            {
                double amount = 0;
                if (HttpContext.Request.Path.Value.Contains("plan-10"))
                {
                    amount = 10;
                }
                else if (HttpContext.Request.Path.Value.Contains("plan-20"))
                {
                    amount = 20;
                }

                BangladeshLandingPageViewModel model = new BangladeshLandingPageViewModel();
                await model.SetSharedDataAsync(User);

                var Plan = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);
                if (Plan != null)
                {
                    if (Plan is Error)
                    {
                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        PlansResponseModel Plans = Plan.GetValue("payload").ToObject<PlansResponseModel>();

                        foreach (var item in Plans.Plans.Where(x => x.CountryId == 25 && x.Price == amount))  //===>25 - Bangladesh
                        {
                            model.Plan = item;
                        }
                    }
                }
                return View(model);
            }


            catch (Exception ex)
            {
                Logger.Error($"Class: LandingPageController, Method: BangladeshSingle, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }
    }
}