using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;


namespace JM.Core.Features.Subscription;

public abstract class GetSubscriptionList
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper> { }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query> { }
    #endregion

    #region Response
    public sealed record Response
    {
        public decimal Price { get; set; }
        public DateTime ExpiryDate { get; set; }
        public IEnumerable<SubscriptionBenefit> Benefits { get; set; } = [];
        public sealed record SubscriptionBenefit
        {
            public long Id { get; set; }
            public required string Type { get; set; }
            public required string UnitType { get; set; }
            public int Unit { get; set; }
            public required string AdsFreeExperience { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var subscriptionList = await _unitOfWork.SubscriptionRepository.GetSubscriptionList();

            if (subscriptionList is not null)
            {
                return ResultWrapper.Success(subscriptionList.Select(x => new Response()
                {
                    Price = x.Price,
                    ExpiryDate = x.ExpiryDate,
                    Benefits = x.Benefits.Select(x => new Response.SubscriptionBenefit()
                    {
                        Id = x.Id,
                        AdsFreeExperience = Enum.GetName(typeof(AppEnum.AdsFreeExperience), x.AdsFreeExperience)!,
                        Type = Enum.GetName(typeof(AppEnum.SubscriptionType), x.Type)!,
                        Unit = x.Unit,
                        UnitType = Enum.GetName(typeof(AppEnum.SubscriptionUnitType), x.UnitType)!
                    })
                }));
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
        }
    }
    #endregion
}
