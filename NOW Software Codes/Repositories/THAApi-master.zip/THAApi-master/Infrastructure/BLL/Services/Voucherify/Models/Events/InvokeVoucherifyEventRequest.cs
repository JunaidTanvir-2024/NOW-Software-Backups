﻿using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.Events
{
    public class InvokeVoucherifyEventRequest
    {
        public string EventName { get; set; }
        public string CustomerSourceId { get; set; }
        public Metadata Metadata { get; set; }
    }
}
