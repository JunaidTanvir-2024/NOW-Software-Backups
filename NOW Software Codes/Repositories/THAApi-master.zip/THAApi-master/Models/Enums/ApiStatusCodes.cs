﻿namespace Models.Enums
{
    public static class PaypalApiStatusCodes
    {
		public const int DailyPaymentLimitExceeded = 100125;
		public const int PaymentProviderError = 100126;
		public const int PaymentServiceError = 100127;
		public const int BundlePurchaseLimitExceeded = 100123;

	}
	public enum ApiStatusCodes
    {
        BadCollapseId = 1,
        BadDeviceToken = 2,
        BadExpirationDate = 3,
        BadMessageId = 4,
        BadPriority = 5,
        BadTopic = 6,
        DeviceTokenNotForTopic = 7,
        DuplicateHeaders = 8,
        IdleTimeout = 9,
        MissingDeviceToken = 10,
        MissingTopic = 11,
        PayloadEmpty = 12,
        TopicDisallowed = 13,
        BadCertificate = 14,
        BadCertificateEnvironment = 15,
        ExpiredProviderToken = 16,
        Forbidden = 17,
        InvalidProviderToken = 18,
        MissingProviderToken = 19,
        BadPath = 20,
        MethodNotAllowed = 21,
        Unregistered = 22,
        PayloadTooLarge = 23,
        TooManyProviderTokenUpdates = 24,
        TooManyRequests = 25,
        InternalServerError = 26,
        ServiceUnavailable = 27,
        Shutdown = 28,
        CodeException = 29,
        UnSuccessful = 30,
        TokenNotFound = 31,
        BadRequest = 32,
        NotFound = 33,
        InvalidLogin = 34,
        DataNotAvailable = 35,
        MsisdnNotExists = 36,
        Pay360Error = 37,
        NoAddressFound = 38,
        InvalidImageFormat = 39,
        InvalidBundle = 40,
        BundleLimitExceeded = 41,
        PaymentServiceError = 42,
        DailyLimitExceeded = 43,
        Pending3dSecure = 44,
        BothAccountsMustBeTalkHomeUsers = 45,
        NotEligibleForReferralCampaign = 46,
        VoucherCodeInvalid = 47,
        VoucherCodeExpired = 48,
        CustomerNotEligible = 49,
        CustomerNotFound = 50,
        InsufficientPoints = 51,
        PromotionNotFound = 52,
        EventNotInvoked = 53,
        PointsNotRedeemed = 54,
        ReferralCodeNotCreated = 55,
        VoucherifyCustomerNotCreated = 56,
        UnAuthorizedAccess=57
    }
}
