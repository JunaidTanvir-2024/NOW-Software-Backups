﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TransferHome.Models.Contracts.Service.Pay360ApiContracts
{
    public class Pay360Resume3DRequest
    {
        public string pay360TransactionId { get; set; }
        public string pareq { get; set; }
    }
}
