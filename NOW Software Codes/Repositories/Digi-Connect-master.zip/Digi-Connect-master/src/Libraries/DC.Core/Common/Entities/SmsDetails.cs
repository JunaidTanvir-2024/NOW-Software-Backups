
namespace DC.Core.Common.Entities;

public sealed record SmsDetails
{
    public int SMSContent { get; set; }
    public string SmsCategory { get; set; }
    public string SmsSubCategory { get; set; }
    public string SmsContent { get; set; }
    public string Cadence { get; set; }
    public string ProductCode { get; set; }
    public bool IsActive { get; set; }

}

