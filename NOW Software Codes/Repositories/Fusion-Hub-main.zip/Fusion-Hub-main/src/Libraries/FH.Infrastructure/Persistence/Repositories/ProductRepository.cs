using System.Data;

using Dapper;

using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Entities;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;

using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

using Serilog;

namespace FH.Infrastructure.Persistence.Repositories;

internal sealed class ProductRepository(IConfiguration configuration, ILogger logger) : IProductRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private readonly ILogger _logger = logger;

    public async Task<IEnumerable<ProductEntity>> ProductUpsert(IEnumerable<ProductEntity> productDtos)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("name", typeof(string));
                table.Columns.Add("description", typeof(string));
                table.Columns.Add("operator_id", typeof(long));
                table.Columns.Add("product_price_id", typeof(long));
                table.Columns.Add("vendor_operator_code", typeof(string));
                table.Columns.Add("vendor_product_code", typeof(string));
                table.Columns.Add("currency_unit_id", typeof(long));
                table.Columns.Add("product_category_id", typeof(long));
                table.Columns.Add("product_subcategory_id", typeof(long));
                table.Columns.Add("validity_unit", typeof(string));
                table.Columns.Add("validity_value", typeof(int));
                table.Columns.Add("vendor_id", typeof(int));
                table.Columns.Add("product_type", typeof(bool));

                foreach (var pd in productDtos)
                {
                    table.Rows.Add(pd.Name, pd.Description, pd.OperatorId, pd.ProductPriceId, pd.VendorOperatorCode, pd.VendorProductCode, pd.CurrencyUnitId, pd.ProductCategoryId, pd.ProductSubCategoryId, pd.ValidityUnit, pd.ValidityValue, pd.VendorId, pd.ProductType);
                }

                var parameters = new DynamicParameters();
                parameters.Add("product_data", table.AsTableValuedParameter(AppConstants.Database.TableType.Product));

                return await connection.QueryAsync<ProductEntity>(AppConstants.Database.StoreProcedure.ProductBulkInsert, parameters, commandType: CommandType.StoredProcedure);

            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), nameof(ProductUpsert));
            return default!;
        }
    }

    public async Task<IEnumerable<ProductCategoryEntity>> ProductCategoryUpsert(IEnumerable<ProductCategoryEntity> productCategoryDtos)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("name", typeof(string));
                table.Columns.Add("description", typeof(string));

                foreach (var pc in productCategoryDtos)
                {
                    table.Rows.Add(pc.Name, pc.Description);
                }

                var parameters = new DynamicParameters();
                parameters.Add("category_data", table.AsTableValuedParameter(AppConstants.Database.TableType.ProductCategory));

                return await connection.QueryAsync<ProductCategoryEntity>(AppConstants.Database.StoreProcedure.ProductCategoryBulkInsert, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), nameof(ProductCategoryUpsert));
            return default!;
        }
    }

    public async Task<IEnumerable<ProductSubCategoryEntity>> ProductSubCategoryUpsert(IEnumerable<ProductSubCategoryEntity> productSubCategories)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("name", typeof(string));
                table.Columns.Add("description", typeof(string));
                table.Columns.Add("product_category_id", typeof(long));

                foreach (var pc in productSubCategories)
                {
                    table.Rows.Add(pc.Name, pc.Description, pc.ProductCategoryId);
                }

                var parameters = new DynamicParameters();
                parameters.Add("subcategory_data", table.AsTableValuedParameter(AppConstants.Database.TableType.ProductSubCategory));

                return await connection.QueryAsync<ProductSubCategoryEntity>(AppConstants.Database.StoreProcedure.ProductSubCategoryBulkInsert, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), nameof(ProductSubCategoryUpsert));
            return default!;
        }
    }

    public async Task<IEnumerable<ProductPriceEntity>> ProductPriceUpsert(IEnumerable<ProductPriceEntity> productPriceDtos)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("data_dump_reference", typeof(string));
                table.Columns.Add("price", typeof(decimal));
                table.Columns.Add("tax", typeof(decimal));
                table.Columns.Add("discount_percentage", typeof(decimal));
                table.Columns.Add("fee", typeof(decimal));
                table.Columns.Add("range_min_price", typeof(decimal));
                table.Columns.Add("range_max_price", typeof(decimal));
                table.Columns.Add("effective_from", typeof(DateTime));
                table.Columns.Add("effective_to", typeof(DateTime));

                foreach (var pp in productPriceDtos)
                {
                    table.Rows.Add(pp.DataDumpReference, pp.Price, pp.Tax, pp.DiscountPercentage, pp.Fee, pp.RangeMinPrice, pp.RangeMaxPrice, pp.EffectiveFrom, pp.EffectiveTo);
                }

                var parameters = new DynamicParameters();
                parameters.Add("price_data", table.AsTableValuedParameter(AppConstants.Database.TableType.ProductPrice));

                return await connection.QueryAsync<ProductPriceEntity>(AppConstants.Database.StoreProcedure.ProductPriceBulkInsert, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), nameof(ProductPriceUpsert));
            return default!;
        }
    }

    public async Task<IEnumerable<ProductBenefitEntity>> ProductBenefitUpsert(IEnumerable<ProductBenefitEntity> productBenefitDtos)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("data_dump_reference", typeof(string));
                table.Columns.Add("description", typeof(string));
                table.Columns.Add("benefit_with_tax", typeof(decimal));
                table.Columns.Add("benefit_without_tax", typeof(decimal));
                table.Columns.Add("range_min_benefit_with_tax", typeof(decimal));
                table.Columns.Add("range_max_benefit_with_tax", typeof(decimal));
                table.Columns.Add("range_min_benefit_without_tax", typeof(decimal));
                table.Columns.Add("range_max_benefit_without_tax", typeof(decimal));
                table.Columns.Add("unit", typeof(string));
                table.Columns.Add("unit_type", typeof(string));
                table.Columns.Add("benefit_type", typeof(string));
                table.Columns.Add("product_id", typeof(long));

                foreach (var pb in productBenefitDtos)
                {
                    table.Rows.Add(pb.DataDumpReference, pb.Description,
                        pb.BenefitWithTax, pb.BenefitWithoutTax,
                        pb.RangeMinBenefitWithTax, pb.RangeMaxBenefitWithTax,
                        pb.RangeMinBenefitWithoutTax, pb.RangeMaxBenefitWithoutTax,
                        pb.Unit, pb.UnitType, pb.BenefitType, pb.ProductId);
                }

                var parameters = new DynamicParameters();
                parameters.Add("benefit_data", table.AsTableValuedParameter(AppConstants.Database.TableType.ProductBenefit));

                return await connection.QueryAsync<ProductBenefitEntity>(AppConstants.Database.StoreProcedure.ProductBenefitBulkInsert, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), nameof(ProductBenefitUpsert));
            return default!;
        }
    }

    public async Task<(IEnumerable<ProductDto.Response> products, DatabasePaginationDto pagination)> GetProducts(ProductDto.Request productRequestDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("country_iso_code", typeof(string));
                table.Columns.Add("currency_code", typeof(string));
                table.Columns.Add("calling_code", typeof(int));
                table.Columns.Add("validity_unit", typeof(string));
                table.Columns.Add("operator_id", typeof(int));
                table.Columns.Add("product_id", typeof(int));
                table.Columns.Add("product_category_id", typeof(int));
                table.Columns.Add("product_alias_name", typeof(string));
                table.Columns.Add("operator_name", typeof(string));
                table.Columns.Add("product_subcategory_name", typeof(string));

                table.Rows.Add(productRequestDto?.Filters?.CountryIsoCode, productRequestDto?.Filters?.CurrencyCode, productRequestDto?.Filters?.CallingCode, productRequestDto?.Filters?.ValidityUnit, productRequestDto?.Filters?.OperatorId, productRequestDto?.Filters?.ProductId, productRequestDto?.Filters?.ProductCategoryId, productRequestDto?.Filters?.ProductAliasName, productRequestDto?.Filters?.OperatorShortCode, productRequestDto?.Filters?.ProductSubCategoryShortCode);

                var operatorParameters = new DynamicParameters();
                operatorParameters.Add("filters", table.AsTableValuedParameter(AppConstants.Database.TableType.ProductFilter));
                operatorParameters.Add("is_active", productRequestDto?.IsActive);
                operatorParameters.Add("is_deleted", productRequestDto?.IsDeleted);
                operatorParameters.Add("page", productRequestDto?.Page);
                operatorParameters.Add("records_per_page", productRequestDto?.RecordsPerPage);
                operatorParameters.Add("total_pages", 0, direction: ParameterDirection.Output);
                operatorParameters.Add("total_records", 0, direction: ParameterDirection.Output);

                var products = await connection.QueryAsync<ProductDto.Response>(AppConstants.Database.StoreProcedure.ProductsGet, operatorParameters, commandType: CommandType.StoredProcedure);

                // Read the output parameters
                var totalRecords = operatorParameters.Get<int>("total_records");
                var totalPages = operatorParameters.Get<int>("total_pages");

                return (products, new DatabasePaginationDto() { TotalPages = totalPages, TotalRecords = totalRecords });
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), nameof(GetProducts));
            return default;
        }
    }

    public async Task<ProductDetailDto.Response?> GetProductDetail(ProductDetailDto.Request request)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var productTransactionParameters = new DynamicParameters();
                productTransactionParameters.Add("productId", request.ProductId);
                productTransactionParameters.Add("product_vendor_code", request.ProductVendorCode);

                return await connection.QueryFirstOrDefaultAsync<ProductDetailDto.Response>(AppConstants.Database.StoreProcedure.ProductDetailGet, productTransactionParameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), methodName: nameof(GetProductDetail));
            return default!;
        }
    }

    public async Task<IEnumerable<ProductStatusDto.Response>?> CheckProductsAvailability(ProductStatusDto.Request productStatusRequestDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("ProductId", typeof(long));

                foreach (var productId in productStatusRequestDto.ProductIds!)
                {
                    table.Rows.Add(productId);
                }

                var operatorParameters = new DynamicParameters();
                operatorParameters.Add("product_status", table.AsTableValuedParameter(AppConstants.Database.TableType.ProductStatusType));

                var productStatuses = await connection.QueryAsync<ProductStatusDto.Response>(AppConstants.Database.StoreProcedure.ProductStatusGet, operatorParameters, commandType: CommandType.StoredProcedure);

                return productStatuses;
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), nameof(GetProducts));
            return default;
        }
    }

    public async Task UpdateProductsAliases(IEnumerable<ProductAliasDto.Request> request)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("product_id", typeof(long));
                table.Columns.Add("name_alias", typeof(string));
                table.Columns.Add("description", typeof(string));

                foreach (var product in request)
                {
                    table.Rows.Add(product.ProductId, product.ProductNameAlias, product.ProductDescription);
                }

                var operatorParameters = new DynamicParameters();
                operatorParameters.Add("products", table.AsTableValuedParameter(AppConstants.Database.TableType.ProductAliasType));

                await connection.ExecuteAsync(AppConstants.Database.StoreProcedure.ProductAliasesUpdate, operatorParameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), nameof(UpdateProductsAliases));
        }
    }

    public async Task<(IEnumerable<ProductByOperatorDto.Response> products, DatabasePaginationDto pagination)> GetSingleProductByEachOperator(ProductByOperatorDto.Request productRequestDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
 

                var productsParamenters = new DynamicParameters();
                productsParamenters.Add("price ", productRequestDto?.Price);
                productsParamenters.Add("country_iso_code", productRequestDto?.CountryIsoCode);
                productsParamenters.Add("currency", productRequestDto?.CurrencyCode);
                productsParamenters.Add("category", productRequestDto?.Category);
                productsParamenters.Add("sub_category", productRequestDto?.SubCategory);
                productsParamenters.Add("operator", productRequestDto?.Operator);

                productsParamenters.Add("is_active", productRequestDto?.IsActive);
                productsParamenters.Add("is_deleted", productRequestDto?.IsDeleted);
                productsParamenters.Add("page", productRequestDto?.Page);
                productsParamenters.Add("records_per_page", productRequestDto?.RecordsPerPage);
                productsParamenters.Add("total_pages", 0, direction: ParameterDirection.Output);
                productsParamenters.Add("total_records", 0, direction: ParameterDirection.Output);

                var products = await connection.QueryAsync<ProductByOperatorDto.Response>(AppConstants.Database.StoreProcedure.ProductsByOperatorGet, productsParamenters, commandType: CommandType.StoredProcedure);

                // Read the output parameters
                var totalRecords = productsParamenters.Get<int>("total_records");
                var totalPages = productsParamenters.Get<int>("total_pages");

                return (products, new DatabasePaginationDto() { TotalPages = totalPages, TotalRecords = totalRecords });
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), nameof(GetSingleProductByEachOperator));
            return default;
        }
    }

    public async Task<IEnumerable<ProductByCategoryDto.Response>> GetProductSubCategoryByCategory(ProductByCategoryDto.Request request)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {

                var table = new DataTable();
                table.Columns.Add("country_isocode2", typeof(string));
                table.Columns.Add("currency_code", typeof(string));
                table.Columns.Add("category_name_alias", typeof(string));

                table.Rows.Add(request?.CategoryFilters?.CountryIsoCode2, request?.CategoryFilters?.CurrencyCode, request?.CategoryFilters?.CategoryAliasName);

                var subCategoryParamenters = new DynamicParameters();
                subCategoryParamenters.Add("SubCategoryFilters", table.AsTableValuedParameter(AppConstants.Database.TableType.ProductByCategoryType));
                subCategoryParamenters.Add("is_active", request?.IsActive);
                subCategoryParamenters.Add("is_deleted", request?.IsDeleted);


                var products = await connection.QueryAsync<ProductByCategoryDto.Response>(AppConstants.Database.StoreProcedure.ProductSubCategoryByCategory, subCategoryParamenters, commandType: CommandType.StoredProcedure);


                return products;
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), methodName: nameof(GetProductSubCategoryByCategory));
            return default!;
        }
    }


}
