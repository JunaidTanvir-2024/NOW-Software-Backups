﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class CancelReturnPayPalViewModel
    {
        public string token { get; set; }
    }
}
