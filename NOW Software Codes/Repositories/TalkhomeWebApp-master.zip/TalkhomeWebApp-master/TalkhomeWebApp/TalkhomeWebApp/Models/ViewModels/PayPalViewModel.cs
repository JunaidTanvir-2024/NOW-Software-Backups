﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class PayPalViewModel
    {
        public string EmailAddress { get; set; }
        public float Amount { get; set; }
        public string Msisdn { get; set; }
        public CheckOutTypes CheckoutPaymentType { get; set; }
        public string IPAddress { get; set; }
    }
}
