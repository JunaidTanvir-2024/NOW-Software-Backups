﻿namespace Models.Enums
{
    public enum AccountDeleteStatus
    {
        Requested = 1,
        Pending,
        Approved,
        Deleted,
        Cancelled

    }
}
