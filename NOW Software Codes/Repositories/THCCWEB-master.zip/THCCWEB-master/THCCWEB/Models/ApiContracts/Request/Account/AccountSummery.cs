﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request.Account
{
    public class AccountSummery
    {
        public string cardnumber { get; set; }

        public string pinnumber { get; set; }

        public string accountID { get; set; }

        public string subscriberId { get; set; }

        public string credit { get; set; }

        public int points { get; set; }

        public string joinedDate { get; set; }

        public string firstDate { get; set; }
        public DateTime? lastTopDate { get; set; }
        public decimal lastTopUp { get; set; }
    }
}
