# NowPayGRevamp Features

1.	Sign Up
2.	Login
3.	Social Sign Up & Social Logins
4.	Add Product – User can have n number of Sims
5.	Top Up
6.	Fast Top Up
7.	Auto Top Up
8.	Bundles
9.	Rates
10.	Get free 4G Sim
11.	My Account
a.	List all Sims associated with user
b.	Select a Sim, then show settings, balance etc.
