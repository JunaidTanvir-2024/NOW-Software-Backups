using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MM.Infrastructure.Common.Settings;
public class SmsMarketing
{
    public const string SectionName = "SmsMarketing";
    public static SmsMarketing Bind = new SmsMarketing();
    public string? ApiUrl { get; set; }
    public string? Username { get; set; }
    public string? Password { get; set; }
    public bool IsActive { get; set; }
    public string? From { get; set; }
    public string? To { get; set; }
    public string? Message { get; set; }
}
