﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum FCMNotificationTypes
    {
        FCMNotificationMessage = 1,
        FCMDataMessage = 2,
        FCMXMPPNotificationMessage = 3,
    }

    public enum APNSNotificationTypes
    {
        APNSRemotePushNotification = 1,
        APNSVoipPushNotification = 2,
        APNSXMPPRemotePushNotification=3
    }

    //For Both
    public enum NotificationTypes
    {
        Notification = 1,
        Silent = 2,
        XMPP=3
    }

 
}
