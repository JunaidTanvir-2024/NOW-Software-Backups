﻿namespace Application.Features.Account.History.All;

internal class AllHistoryRequestValidator : AbstractValidator<AllHistoryRequest>
{
    public AllHistoryRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid Msisdn");
    }
}
