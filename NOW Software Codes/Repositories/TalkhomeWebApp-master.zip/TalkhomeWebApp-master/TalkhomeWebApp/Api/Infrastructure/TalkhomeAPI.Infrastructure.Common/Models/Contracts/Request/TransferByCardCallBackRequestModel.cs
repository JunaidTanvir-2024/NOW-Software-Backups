﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class TransferByCardCallBackRequestModel
    {
        [Required]
        public string nowtelRef { get; set; }

        [Required]
        public string product { get; set; }

        [Required]
        public string operatorId { get; set; }

        [Required]
        public string MD { get; set; }

        //[Required]
        public string PaRes { get; set; }

        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [EmailAddress(ErrorMessage = "Invalid email")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        public string customerEmail { get; set; }

        public string IpAddress { get; set; }
        
        public string clientRedirectType { get; set; }

        public string customerMsisdn { get; set; }
    }
}
