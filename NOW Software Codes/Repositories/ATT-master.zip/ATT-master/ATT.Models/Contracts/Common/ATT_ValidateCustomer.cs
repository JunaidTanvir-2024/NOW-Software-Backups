﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Common
{
    public class ATT_ValidateCustomer
    {
        public int isAllowed { get; set; }
        public string Message { get; set; }
    }
}
