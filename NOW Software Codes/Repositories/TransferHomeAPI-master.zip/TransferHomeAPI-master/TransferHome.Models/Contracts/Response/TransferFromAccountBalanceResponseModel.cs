﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class TransferFromAccountBalanceResponseModel
    {
        public decimal RemainingBalance  { get; set; }
        public string BalanceCurrency { get; set; }
        public string BalanceCurrencySymbol { get; set; }
        public string DestinationMsisdn { get; set; }
        public string DestinationCountry { get; set; }
        public string transferAmount { get; set; }
        public string transferAmountCurrency { get; set; }
        public string OperatorName { get; set; }
    }
}
