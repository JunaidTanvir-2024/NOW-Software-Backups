﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBResultValidateMsisdn
    {
        public decimal? card_credit { get; set; }
        public int? voucher_id { get; set; }
        public string voucher_currency { get; set; }
        public int error_code { get; set; }
        public string error_msg { get; set; }
    }
}
