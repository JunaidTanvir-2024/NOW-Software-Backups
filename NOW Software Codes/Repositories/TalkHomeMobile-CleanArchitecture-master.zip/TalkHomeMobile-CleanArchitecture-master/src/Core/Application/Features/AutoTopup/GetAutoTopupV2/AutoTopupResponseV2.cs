namespace Application.Features.AutoTopup.GetAutoTopupV2;

public class AutoTopupResponseV2
{
    public AutoTopupInfoV2 AutoTopup { get; set; } = new AutoTopupInfoV2();
    public List<float> TopUpAmounts { get; set; } = new List<float>();
    public float? AutoTopupMonthlyMaxLimit { get; set; }
}
