﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NowPayG.Models.Porting
{
    public enum Resolution
    {
        Cancelled,
        Failure,
        Success
    }

    public enum PortType
    {
        [Display(Name = "Number Port In")]
        PortIn,
        [Display(Name = "Number Port Out")]
        PortOut,
        [Display(Name = "Number No Port")]
        NoPort
    }

    public enum PortReason
    {
        [Display(Name = "Call Quality")]
        CallQuality,
        [Display(Name = "Coverage")]
        Coverage,
        [Display(Name = "Customer Service")]
        CustomerService,
        [Display(Name = "Other")]
        Other,
        [Display(Name = "Promotion")]
        Promotion,
        [Display(Name = "Rates")]
        Rates,
        [Display(Name = "Subscription Change")]
        SubscriptionChange
    }

    public class PortItem
    {
        public string ExpiryDate { get; set; }
        public string Title { get; set; }
        public string PortingMsisdn { get; set; }                
        public PortType PortType { get; set; }
        public string PAC { get; set; }
        public string NPAC { get; set; }
        

        public int Status { get; set; }
        public string Message { get; set; }

    }
}
