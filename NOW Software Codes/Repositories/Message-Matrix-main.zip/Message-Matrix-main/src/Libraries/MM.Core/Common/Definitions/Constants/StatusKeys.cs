namespace MM.Core.Common.Definitions.Constants;

public static partial class AppConstants
{
    public static class StatusKeys
    {
        public const string Success = "Congratulations! Your request was fulfilled successfully.";
        public const string BadRequest = "Whoops! Something went wrong with your request. Please try again.";
        public const string Forbidden = "Sorry, you don't have permission to access this resource.";
        public const string NotFound = "Hmmm, we couldn't find what you're looking for.";
        public const string Unauthorized = "Oops! You need to be authorized to access this resource.";
        public const string InternalServerError = "Whoops! Something went wrong on our end. Please try again later.";
        // Token
        public const string JwtTokenMissing = "Uh oh! Token is missing. Please try again with a valid token.";
        public const string JwtTokenExpired = "Whoops! Your token has expired. Please request a new one.";
        public const string JwtTokenInvalid = "Whoops! Your authorization token is invalid. Please try again with a valid token.";
    }
}
