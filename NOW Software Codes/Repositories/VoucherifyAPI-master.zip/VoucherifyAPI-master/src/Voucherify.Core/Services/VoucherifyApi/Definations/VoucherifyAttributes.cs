namespace Voucherify.Core.Services.VoucherifyApi.Definations;

public sealed class VoucherifyAttributes
{
    private VoucherifyAttributes() { }

    [AttributeUsage(AttributeTargets.Field)]
    public class JsonEnumValueAttribute : Attribute
    {
        public string? Value { get; set; }
    }
}