
using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using Microsoft.AspNetCore.Hosting;

using RW;
namespace JM.Core.Features.Media;

public abstract class RemoveMedia
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public long Id { get; set; }
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.Id).GreaterThan(0);
		}
	}
	#endregion

	#region Response
	public sealed record Response
	{
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork, IWebHostEnvironment webHostEnvironment) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		private readonly IWebHostEnvironment _webHostEnvironment = webHostEnvironment;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{
			var media = await _unitOfWork.MediaRepository.GetMedia(x => x.Id.Equals(query.Id) && x.IsActive);

			if (media is not null)
			{
				media.IsActive = false;
				media.IsDeleted = true;
				media.DeletedAt = DateTime.UtcNow;
				_unitOfWork.SaveChanges();

				return ResultWrapper.Success(AppConstant.StatusKey.Success, AppConstant.StatusCode.Success);
			}

			return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
		}
	}
	#endregion
}
