﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.IISIntegration;
using SC.Api.Model.CustomerCard;
using SC.Api.Model.CustomerOrder;
using SC.Core.Common.Helpers;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerCard.Request;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.Notification.Request;
using SC.Core.Interfaces.Repositories;

using Sentry;

namespace SC.Api.Controllers.V1;
[ApiVersion(1.0)]
public sealed class CustomerCardController : BaseApiController
{
    private readonly UserManager<IdentityUser> _userManager;
    private readonly ICommonService _commonService;
    private readonly IConfiguration _configuration;
    private readonly IUserRepository _userRepository;

    public CustomerCardController(UserManager<IdentityUser> userManager,
                                    ICommonService commonService,
                                    IConfiguration configuration,
                                    IUserRepository userRepository)
    {
        _userManager = userManager;
        _commonService = commonService;
        _configuration = configuration;
        _userRepository = userRepository;
    }

    [Authorize]
    [HttpPost("AddCustomerCard")]
    public async Task<ActionResult> AddCustomerCard(CustomerCardModel model)
    {
        var result = await Mediator.Send(new AddCustomerCardRequest()
        {
            Pan = model.Pan,
            NameOnCard = model.NameOnCard,
            CardType = model.CardType,
            Expiry = model.Expiry,
            IsDefault = model.IsDefault,
        });
        if (result.IsSuccess)
        {
            var userId = _commonService.GetUserID();
            var userEmail = _commonService.GetUserEmail();

            var userDetailsDto = await _userRepository.GetUserDetailByUserID(userId);

            var firstName = userDetailsDto?.FirstName;
            var lastName = userDetailsDto?.LastName;

            var userName = $"{firstName} {lastName}";

            var paramsTemplate = new Dictionary<string, string>()
                    {
                        { "{F_NAME}" ,userName  },
                    };
            await SendNotification(userEmail, AppConstants.EmailSubjects.AddPaymentCard, AppConstants.EmailTemplates.AddPaymentCard, paramsTemplate);

            return Ok(result);
        }
        return BadRequest(result);

    }
    [Authorize]
    [HttpPost("RemoveCustomerCard")]
    public async Task<ActionResult> RemoveCustomerCard(long CustomerCardId)
    {
        var result = await Mediator.Send(new RemoveCardRequest() { 
         CardID = CustomerCardId
        });


        var userId = _commonService.GetUserID();
        var userEmail = _commonService.GetUserEmail();
        var userDetailsDto = await _userRepository.GetUserDetailByUserID(userId);

        var firstName = userDetailsDto?.FirstName;
        var lastName = userDetailsDto?.LastName;

        var userName = $"{firstName} {lastName}";

        var paramsTemplate = new Dictionary<string, string>()
                                                {
                                                    { "{F_NAME}" ,userName  },
                                                };
        await SendNotification(userEmail, AppConstants.EmailSubjects.RemovePaymentCard, AppConstants.EmailTemplates.RemovePaymentCard, paramsTemplate);




        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);
    }
    [Authorize]
    [HttpGet("GetCustomerCards")]
    public async Task<ActionResult> GetCustomerCards()
    {
        var result = await Mediator.Send(new GetCustomerCardRequest());
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);

    }
    [Authorize]
    [HttpPost("MarkCardDefault")]
    public async Task<ActionResult> MarkCardDefault(long CustomerCardId)
    {
        var result = await Mediator.Send(new MarkCardDefaultRequest()
        {
            CardID = CustomerCardId
        });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);
    }




    // private Methods

    private async Task SendNotification(string email, string subject, string templateName, Dictionary<string, string> paramsTemplate)
    {
        var user = await _userManager.FindByEmailAsync(email);

        var emailTemplatePath = _configuration.GetSection("EmailTemplatePath").Value;

        var body = EmailHelper.GenerateEmailContent(templateName, paramsTemplate, emailTemplatePath!);

        var notificationResponse = await Mediator.Send(new SendNotificationRequest()
        {
            To = email,
            EmailBody = body,
            ProductCode = "SC",
            Subject = subject,
            EmailType = 1
        });

    }

}


