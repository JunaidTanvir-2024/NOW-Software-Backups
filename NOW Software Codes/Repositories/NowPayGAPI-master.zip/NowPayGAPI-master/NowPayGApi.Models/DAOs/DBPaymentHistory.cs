﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBPaymentHistory
    {
        public string PaymentDate { get; set; }
        public string Amount { get; set; }
        public string Reason { get; set; }
    }
}
