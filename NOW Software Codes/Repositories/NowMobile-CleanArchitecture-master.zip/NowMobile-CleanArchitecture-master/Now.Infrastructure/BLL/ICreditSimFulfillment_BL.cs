﻿

using Now.Infrastructure.Services;

namespace Now.Infrastructure.BLL;

public interface ICreditSimFulfillment_BL:ISerivcesType.ITransientService
{
    Task StartFulfillment();
}
