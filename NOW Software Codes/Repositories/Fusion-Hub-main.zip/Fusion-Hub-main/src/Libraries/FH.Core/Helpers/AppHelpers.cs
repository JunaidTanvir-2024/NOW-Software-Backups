using System.Text.Json;

namespace FH.Core.Helpers;
public static class AppHelpers
{
    public static string GetRowGuid()
    {
        return Guid.NewGuid().ToString();
    }
    public static string GetCorrelationId()
    {
        return Guid.NewGuid().ToString();
    }
    public static string GenerateUniqueReference()
    {
        return Guid.NewGuid().ToString();
    }
    public static (string firstName, string lastName) SplitNames(string fullName)
    {
        var parts = fullName.Split('_');

        return (parts[0], parts[1]);
    }

    public static bool IsJsonList(string jsonString)
    {
        try
        {
            JsonDocument doc = JsonDocument.Parse(jsonString);

            return doc.RootElement.ValueKind == JsonValueKind.Array;
        }
        catch (JsonException)
        {
            return false;
        }
    }
}
