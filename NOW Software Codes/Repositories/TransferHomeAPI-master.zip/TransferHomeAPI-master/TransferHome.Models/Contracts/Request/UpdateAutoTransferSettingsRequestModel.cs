﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class UpdateAutoTransferSettingsRequestModel
    {
        [Required]
        public int Id { get; set; }
        [Required]
        [Range(1, 2, ErrorMessage = "Invalid Regualrity Type")]
        public int RegularityTypeId { get; set; }
    }
}
