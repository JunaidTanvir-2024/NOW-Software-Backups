using System.Text.Json;

using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;

using Microsoft.AspNetCore.Http;

using Serilog;
using Microsoft.AspNetCore.Mvc;
using FH.Core.Definitions;

namespace FH.Core.Extensions;

public static class FileExtensions
{
    public static T? CsvFileToJson<T>(this IFormFile file)
    {
        var data = new List<Dictionary<string, object>>(); // Use object as the value type

        try
        {
            using (var stream = file.OpenReadStream())
            using (var reader = new StreamReader(stream))
            {
                // Assuming the first line is the header
                var headers = reader.ReadLine()?.Split(',');

                while (!reader.EndOfStream)
                {
                    var fields = reader.ReadLine()?.Split(',');

                    if (fields != null && headers != null && fields.Length == headers.Length)
                    {
                        var rowData = new Dictionary<string, object>(); // Use object as the value type

                        for (int i = 0; i < headers.Length; i++)
                        {
                            rowData[headers[i]] = ParseFieldValue(fields[i]);
                        }

                        data.Add(rowData);
                    }
                }
            }

            var serializedCSVFile = JsonSerializer.Serialize(data);
            return JsonSerializer.Deserialize<T>(serializedCSVFile);
        }
        catch (Exception ex)
        {
            Log.Logger.ErrorLog(ex, nameof(FileExtensions), nameof(CsvFileToJson));
            return default!;
        }
    }

    private static object ParseFieldValue(string field)
    {
        if (int.TryParse(field, out int intValue))
        {
            return intValue;
        }
        else if (long.TryParse(field, out long longValue))
        {
            return longValue;
        }
        else if (double.TryParse(field, out double doubleValue))
        {
            return doubleValue;
        }
        else
        {
            return field; 
        }
    }

    private static bool CheckObjectType(object value)
    {
        return value is int || value is long || value is double || value is float || value is decimal;
    }
    public static FileContentResult ConvertToCsvFile<T>(this IEnumerable<T> data, string fileName)
    {
        try
        {
            var stream = new MemoryStream();
            using (var spreadsheetDocument = SpreadsheetDocument.Create(stream, SpreadsheetDocumentType.Workbook))
            {
                var workbookPart = spreadsheetDocument.AddWorkbookPart();
                var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
                var sheetData = new SheetData();

                var sheets = new Sheets();
                var sheet = new Sheet() { Id = spreadsheetDocument.WorkbookPart?.GetIdOfPart(worksheetPart), SheetId = 1, Name = "Sheet1" };

                sheets.Append(sheet);

                var workbook = new Workbook();
                workbook.Append(sheets);

                worksheetPart.Worksheet = new Worksheet(sheetData);
                workbookPart.Workbook = workbook;

                var headerRow = new Row();

                var properties = typeof(T).GetProperties();

                foreach (var property in properties)
                {
                    var cell = new Cell() { DataType = CellValues.String, CellValue = new CellValue(property.Name) };
                    headerRow.AppendChild(cell);
                }

                sheetData.AppendChild(headerRow);

                foreach (var item in data)
                {
                    var dataRow = new Row();

                    foreach (var property in properties)
                    {
                        var cell = new Cell();

                        var value = property?.GetValue(item)?.ToString() ?? string.Empty;

                        if (property?.PropertyType == typeof(DateTime))
                        {
                            cell.DataType = CellValues.Date;
                            cell.CellValue = new CellValue(Convert.ToDateTime(value).ToOADate().ToString());
                        }
                        if (property?.PropertyType == typeof(int)
                            || property?.PropertyType == typeof(long)
                            || property?.PropertyType == typeof(double)
                            || property?.PropertyType == typeof(float))
                        {
                            cell.DataType = CellValues.Number;
                            cell.CellValue = new CellValue(value);
                        }
                        else
                        {
                            cell.DataType = CellValues.String;
                            cell.CellValue = new CellValue(value?.ToString()!);
                        }
                        dataRow.AppendChild(cell);
                    }

                    sheetData.AppendChild(dataRow);
                }

                // Close the workbook part to save changes
                workbookPart.Workbook.Save();
            }

            return new FileContentResult(stream.ToArray(), AppConstants.ContentType.XlsxFile)
            {
                FileDownloadName = $"{fileName}{new Random().Next(1, 99)}.xlsx"
            };
        }
        catch (Exception ex)
        {
            Log.Logger.ErrorLog(ex, nameof(FileExtensions), nameof(ConvertToCsvFile));
            return default!;
        }
    }

}
