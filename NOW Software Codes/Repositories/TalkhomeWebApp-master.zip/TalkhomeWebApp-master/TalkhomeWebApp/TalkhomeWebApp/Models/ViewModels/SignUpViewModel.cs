﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class SignUpViewModel
    {
        [Required(ErrorMessage = "Enter first name", AllowEmptyStrings = false)]
        [MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid first name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Enter last name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid last name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Enter email address"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [EmailAddress(ErrorMessage = "Email is invalid")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Email is invalid")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Enter your phone number")]
        [MaxLength(length: 50, ErrorMessage = "Maximum length exceeded")]
        public string SignUpPhoneNumber { get; set; }

        [Required]
        [MaxLength(length: 5, ErrorMessage = "Maximum length exceeded")]
        public string SignUpPhoneNumberCC { get; set; }

        //[Required(ErrorMessage = "Valid reCaptcha response is required")]
        //public string captchaResponse { get; set; }
        public string Token { get; set; }

        public bool EmailSubscription { get; set; }

        public bool RememberMe { get; set; }
        public string ReturnUrl { get; set; }
    }
}
