using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using PhoneNumbers;

using THCC.Infrastructure.Persistence;
using THCC.Infrastructure.Services.Jwt;

namespace THCC.Infrastructure;

public static class ConfigureInfrastructure
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        services
           .AddPersistenceConfiguration(configuration)
           .AddJwtConfiguration(configuration);

        services.AddSingleton(PhoneNumberUtil.GetInstance());
        
        return services;
    }
}
