﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NowPayGApi.Models.DbConnections
{
    public interface IDbConnectionSettings
    {
        IDbConnection SqlConnection { get; }
    }
}
