using JM.Core.Entities;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace JM.Infrastructure.Persistence.Migrations;

public sealed class DatabaseSchema
{
	#region Schema Configuration
	public sealed class UserSchemaConfigurations : IEntityTypeConfiguration<User>
	{
		public void Configure(EntityTypeBuilder<User> builder)
		{
			builder.ToTable(nameof(User));
			builder.Property(ud => ud.RefreshToken).HasMaxLength(500);
			builder.Property(ud => ud.RefreshTokenExpiry);
			builder.Property(ud => ud.RefreshTokenExpiry);
			builder.Property(ud => ud.IsActive).IsRequired().HasDefaultValue(true);
			builder.Property(ud => ud.IsDeleted).IsRequired().HasDefaultValue(false);
			builder.Property(ud => ud.CreatedAt).IsRequired();
			builder.Property(ud => ud.UpdatedAt);
			builder.Property(ud => ud.DeletedAt);

			// foreign key
			builder
			.HasOne(ud => ud.UserDetail)
			.WithOne(u => u.User)
			.HasForeignKey<UserDetail>(ud => ud.UserId)
			.OnDelete(DeleteBehavior.Restrict)
			.HasConstraintName($"FK_{nameof(UserDetail)}_{nameof(User)}_{nameof(User)}Id");
		}
	}
	public sealed class UserDetailSchemaConfigurations : IEntityTypeConfiguration<UserDetail>
	{
		public void Configure(EntityTypeBuilder<UserDetail> builder)
		{
			builder.ToTable(nameof(UserDetail)).HasKey(ud => ud.Id);
			builder.Property(ud => ud.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(ud => ud.FullName).HasMaxLength(255);
			builder.Property(ud => ud.ProfilePhoto).HasMaxLength(255);
			builder.Property(ud => ud.UserId).IsRequired();
			builder.Property(ud => ud.CountryId).IsRequired();

			// foreign key
			builder
			.HasOne(c => c.Country)
			.WithMany(ud => ud.UserDetails)
			.HasForeignKey(ud => ud.CountryId)
			.OnDelete(DeleteBehavior.Restrict)
			.HasConstraintName($"FK_{nameof(UserDetail)}_{nameof(Country)}_{nameof(Country)}Id");
		}
	}
	public sealed class CountrySchemaConfigurations : IEntityTypeConfiguration<Country>
	{
		public void Configure(EntityTypeBuilder<Country> builder)
		{
			builder.ToTable(nameof(Country)).HasKey(c => c.Id);
			builder.Property(c => c.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(c => c.IsoCode2).IsRequired().HasMaxLength(2);
			builder.Property(c => c.IsoCode3).IsRequired().HasMaxLength(3);
			builder.Property(c => c.CallingCode).IsRequired();
			builder.Property(c => c.Name).IsRequired().HasMaxLength(50);
			builder.Property(c => c.NumericCode).IsRequired().HasMaxLength(5);
		}
	}
	public sealed class VendorSchemaConfigurations : IEntityTypeConfiguration<Vendor>
	{
		public void Configure(EntityTypeBuilder<Vendor> builder)
		{
			builder.ToTable(nameof(Vendor)).HasKey(v => v.Id);
			builder.Property(v => v.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(v => v.Name).IsRequired().HasMaxLength(50);
			builder.Property(v => v.Description).HasMaxLength(int.MaxValue).IsRequired(false);
		}
	}
	public sealed class AppLogSchemaConfigurations : IEntityTypeConfiguration<AppLog>
	{
		public void Configure(EntityTypeBuilder<AppLog> builder)
		{
			builder.ToTable(nameof(AppLog)).HasKey(al => al.Id);
			builder.Property(al => al.Id).UseIdentityColumn();
			builder.Property(al => al.RequestReference).IsRequired().HasMaxLength(50);
			builder.Property(al => al.RequestPath).IsRequired().HasMaxLength(255);
			builder.Property(al => al.RequestMethod).IsRequired().HasMaxLength(10);
			builder.Property(al => al.RequestBody).IsRequired().HasMaxLength(int.MaxValue);
			builder.Property(al => al.StatusCode).IsRequired();
			builder.Property(al => al.ProcessDuration).IsRequired();
			builder.Property(al => al.ClientIp).IsRequired().HasMaxLength(50);
			builder.Property(al => al.UserAgent).IsRequired().HasMaxLength(255);
			builder.Property(al => al.ErrorReason).HasMaxLength(int.MaxValue).IsRequired(false);
			builder.Property(al => al.RequestHeaders).IsRequired().HasMaxLength(3000);
			builder.Property(al => al.ResponseBody).IsRequired().HasMaxLength(int.MaxValue);
			builder.Property(al => al.ProductReference).IsRequired().HasMaxLength(50);
			builder.Property(al => al.RequestTimestamp).IsRequired().HasColumnType("TIMESTAMP WITH TIME ZONE");
		}
	}

	public sealed class VendorLogSchemaConfigurations : IEntityTypeConfiguration<VendorLog>
	{
		public void Configure(EntityTypeBuilder<VendorLog> builder)
		{
			builder.ToTable(nameof(VendorLog)).HasKey(vl => vl.Id);
			builder.Property(vl => vl.Id).UseIdentityColumn();
			builder.Property(vl => vl.RequestPath).HasMaxLength(255);
			builder.Property(vl => vl.RequestMethod).HasMaxLength(10);
			builder.Property(vl => vl.RequestBody).HasMaxLength(1000);
			builder.Property(vl => vl.RequestReference).IsRequired().HasMaxLength(50);
			builder.Property(vl => vl.ProductReference).IsRequired().HasMaxLength(15);
			builder.Property(vl => vl.ResponseBody).HasMaxLength(int.MaxValue);
			builder.Property(vl => vl.StatusCode);
			builder.Property(vl => vl.ProcessDuration);
			builder.Property(vl => vl.ErrorReason).HasMaxLength(1000);
			builder.Property(vl => vl.RequestHeaders).HasMaxLength(2000);
			builder.Property(vl => vl.RequestTimeStamp).IsRequired().HasColumnType("TIMESTAMP WITH TIME ZONE");

			// foreign key
			builder
				.HasOne(vl => vl.Vendor)
				.WithMany(v => v.VendorLogs)
				.HasForeignKey(vl => vl.VendorId)
				.OnDelete(DeleteBehavior.Restrict)
				.HasConstraintName($"FK_{nameof(VendorLog)}_{nameof(Vendor)}_{nameof(Vendor)}Id");
		}
	}
	public sealed class OtpSchemaConfigurations : IEntityTypeConfiguration<Otp>
	{
		public void Configure(EntityTypeBuilder<Otp> builder)
		{
			builder.ToTable(nameof(Otp)).HasKey(o => o.Id);
			builder.Property(o => o.Id).UseIdentityColumn();
			builder.Property(o => o.Code).IsRequired().HasMaxLength(6);
			builder.Property(o => o.Type).IsRequired();
			builder.Property(o => o.UsageCount).IsRequired();
			builder.Property(o => o.IsAlreadyUsed).IsRequired().HasDefaultValue(false);
			builder.Property(o => o.IsBlocked).IsRequired().HasDefaultValue(false);
			builder.Property(o => o.IsRetryLimitExceeded).IsRequired().HasDefaultValue(false);
			builder.Property(o => o.BlockTime).IsRequired(false);
			builder.Property(o => o.ExpiryTime).IsRequired();
			builder.Property(o => o.UserId).IsRequired();

			// foreign key
			builder
				.HasOne(u => u.User)
				.WithMany(o => o.Otps)
				.HasForeignKey(u => u.UserId)
				.HasConstraintName($"FK_{nameof(Otp)}_{nameof(User)}_{nameof(User)}Id")
				.OnDelete(DeleteBehavior.Restrict);
		}
	}
	public sealed class TripSchemaConfigurations : IEntityTypeConfiguration<Trip>
	{
		public void Configure(EntityTypeBuilder<Trip> builder)
		{
			builder.ToTable(nameof(Trip)).HasKey(t => t.Id);
			builder.Property(t => t.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(t => t.Name).IsRequired().HasMaxLength(255);
			builder.Property(t => t.StartingDate).IsRequired();
			builder.Property(t => t.EndingDate).IsRequired();
			builder.Property(t => t.Thumbnail).HasMaxLength(255);
			builder.Property(t => t.IsActive).IsRequired().HasDefaultValue(true);
			builder.Property(t => t.IsDeleted).IsRequired().HasDefaultValue(false);
			builder.Property(t => t.UpdatedAt);
			builder.Property(t => t.DeletedAt);
			builder.Property(t => t.CreatedAt).IsRequired().HasColumnType("TIMESTAMP WITH TIME ZONE");
			builder.Property(t => t.CreatorId).IsRequired();
			builder.Property(t => t.CurrencyId).IsRequired();
		}
	}

	public sealed class PlaceSchemaConfigurations : IEntityTypeConfiguration<Place>
	{
		public void Configure(EntityTypeBuilder<Place> builder)
		{
			builder.ToTable(nameof(Place)).HasKey(p => p.Id);
			builder.Property(p => p.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(p => p.Name).IsRequired().HasMaxLength(255);
			builder.Property(p => p.Description).HasMaxLength(int.MaxValue);
			builder.Property(p => p.Latitude).IsRequired().HasColumnType("decimal(9, 6)");
			builder.Property(p => p.Longitude).IsRequired().HasColumnType("decimal(9, 6)");
			builder.Property(p => p.Type).HasMaxLength(255);
			builder.Property(p => p.ImageUrl).HasMaxLength(255);
			builder.Property(p => p.IsActive).IsRequired().HasDefaultValue(true);
			builder.Property(p => p.IsDeleted).IsRequired().HasDefaultValue(false);
			builder.Property(p => p.UpdatedAt);
			builder.Property(p => p.DeletedAt);
			builder.Property(p => p.CreatedAt).IsRequired().HasColumnType("TIMESTAMP WITH TIME ZONE");
		}
	}

	public sealed class ExpenseCategorySchemaConfigurations : IEntityTypeConfiguration<ExpenseCategory>
	{
		public void Configure(EntityTypeBuilder<ExpenseCategory> builder)
		{
			builder.ToTable(nameof(ExpenseCategory)).HasKey(ec => ec.Id);
			builder.Property(ec => ec.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(ec => ec.Name).IsRequired().HasMaxLength(50);
			builder.Property(ec => ec.IsActive).IsRequired().HasDefaultValue(true);
			builder.Property(ec => ec.IsDeleted).IsRequired().HasDefaultValue(false);
			builder.Property(ec => ec.UpdatedAt);
			builder.Property(ec => ec.DeletedAt);
			builder.Property(ec => ec.CreatedAt).IsRequired().HasColumnType("TIMESTAMP WITH TIME ZONE");
		}
	}

	public sealed class TravelerSchemaConfigurations : IEntityTypeConfiguration<Traveler>
	{
		public void Configure(EntityTypeBuilder<Traveler> builder)
		{
			builder.ToTable(nameof(Traveler));
			builder.HasKey(t => t.Id);
			builder.Property(t => t.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(t => t.UserId).IsRequired();
			builder.Property(t => t.TripId).IsRequired();

			// foreign key
			builder
			.HasOne(t => t.User)
			.WithMany(t => t.Travelers)
			.HasForeignKey(t => t.UserId)
			.HasConstraintName($"FK_{nameof(Traveler)}_{nameof(User)}_{nameof(User)}Id")
			.OnDelete(DeleteBehavior.Restrict);

			// foreign key
			builder
			.HasOne(t => t.Trip)
			.WithMany(t => t.Travelers)
			.HasForeignKey(t => t.TripId)
			.HasConstraintName($"FK_{nameof(Traveler)}_{nameof(Trip)}_{nameof(Trip)}Id")
			.OnDelete(DeleteBehavior.Restrict);
		}
	}
	public sealed class MediaSchemaConfigurations : IEntityTypeConfiguration<Media>
	{
		public void Configure(EntityTypeBuilder<Media> builder)
		{
			builder.ToTable(nameof(Media));
			builder.HasKey(m => m.Id);
			builder.Property(m => m.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(m => m.TravelerId).IsRequired();
			builder.Property(m => m.TripId).IsRequired();
			builder.Property(m => m.Type).IsRequired().HasMaxLength(50);
			builder.Property(m => m.Url).IsRequired().HasMaxLength(255);
			builder.Property(m => m.IsActive).IsRequired().HasDefaultValue(true);
			builder.Property(m => m.IsDeleted).IsRequired().HasDefaultValue(false);
			builder.Property(m => m.UpdatedAt).IsRequired(false);
			builder.Property(m => m.DeletedAt).IsRequired(false);
			builder.Property(m => m.CreatedAt).IsRequired().HasColumnType("TIMESTAMP WITH TIME ZONE");

			// foreign key
			builder
			.HasOne(m => m.Trip)
			.WithMany(m => m.Media)
			.HasForeignKey(m => m.TripId)
			.HasConstraintName($"FK_{nameof(Media)}_{nameof(Trip)}_{nameof(Trip)}Id")
			.OnDelete(DeleteBehavior.Restrict);

			// foreign key
			builder
			.HasOne(m => m.Traveler)
			.WithMany(m => m.Media)
			.HasForeignKey(m => m.TravelerId)
			.HasConstraintName($"FK_{nameof(Media)}_{nameof(Traveler)}_{nameof(Traveler)}Id")
			.OnDelete(DeleteBehavior.Restrict);
		}
	}
	public sealed class ExpenseSchemaConfigurations : IEntityTypeConfiguration<Expense>
	{
		public void Configure(EntityTypeBuilder<Expense> builder)
		{
			builder.ToTable(nameof(Expense)).HasKey(e => e.Id);
			builder.Property(e => e.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(e => e.TravelerId).IsRequired();
			builder.Property(e => e.TripId).IsRequired();
			builder.Property(e => e.Description).IsRequired().HasMaxLength(int.MaxValue);
			builder.Property(e => e.Amount).IsRequired().HasColumnType("decimal(18,2)");
			builder.Property(e => e.CategoryId).IsRequired();
			builder.Property(e => e.IsActive).IsRequired().HasDefaultValue(true);
			builder.Property(e => e.IsDeleted).IsRequired().HasDefaultValue(false);
			builder.Property(e => e.UpdatedAt);
			builder.Property(e => e.DeletedAt);
			builder.Property(e => e.CreatedAt).IsRequired().HasColumnType("TIMESTAMP WITH TIME ZONE");
		}
	}


	public sealed class PrivateChatRoomSchemaConfigurations : IEntityTypeConfiguration<ChatRoom>
	{
		public void Configure(EntityTypeBuilder<ChatRoom> builder)
		{
			builder.ToTable(nameof(ChatRoom)).HasKey(p => p.Id);
			builder.Property(p => p.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(p => p.Name).IsRequired().HasMaxLength(50);
			builder.Property(p => p.IsPrivate).IsRequired();
			builder.Property(p => p.TripId).IsRequired();

			// foreign key
			builder
			.HasOne(p => p.Trip)
			.WithOne(p => p.ChatRoom)
			.HasForeignKey<ChatRoom>(p => p.TripId)
			.HasConstraintName($"FK_{nameof(ChatRoom)}_{nameof(Trip)}_{nameof(Trip)}Id");
		}
	}

	public sealed class ChatMessageSchemaConfigurations : IEntityTypeConfiguration<ChatMessage>
	{
		public void Configure(EntityTypeBuilder<ChatMessage> builder)
		{
			builder.ToTable(nameof(ChatMessage)).HasKey(c => c.Id);
			builder.Property(c => c.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(c => c.ChatRoomId).IsRequired();
			builder.Property(c => c.SenderId).IsRequired();
			builder.Property(c => c.ReceiverId).IsRequired();
			builder.Property(c => c.Content).IsRequired().IsUnicode(true).HasMaxLength(int.MaxValue);
			builder.Property(c => c.Timestamp).IsRequired();

			// foreign key
			builder
				.HasOne(c => c.ChatRoom)
				.WithMany(c => c.ChatMessages)
				.HasForeignKey(c => c.ChatRoomId)
				.HasConstraintName($"FK_{nameof(ChatMessage)}_{nameof(ChatRoom)}_{nameof(ChatRoom)}Id")
				.OnDelete(DeleteBehavior.Cascade);

			// foreign key
			builder
				.HasOne(c => c.Sender)
				.WithMany(c => c.SenderChatMessages)
				.HasForeignKey(c => c.SenderId)
				.HasConstraintName($"FK_{nameof(ChatMessage)}_{nameof(ChatMessage.Sender)}_{nameof(ChatMessage.Sender)}Id")
				.OnDelete(DeleteBehavior.Cascade);

			// foreign key
			builder
				.HasOne(c => c.Receiver)
				.WithMany(c => c.ReceiverChatMessages)
				.HasForeignKey(c => c.ReceiverId)
				.HasConstraintName($"FK_{nameof(ChatMessage)}_{nameof(ChatMessage.Receiver)}_{nameof(ChatMessage.Receiver)}Id")
				.OnDelete(DeleteBehavior.Cascade);
		}
	}

	public sealed class SubscriptionSchemaConfigurations : IEntityTypeConfiguration<Subscription>
	{
		public void Configure(EntityTypeBuilder<Subscription> builder)
		{
			builder.ToTable(nameof(Subscription)).HasKey(c => c.Id);
			builder.Property(c => c.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(c => c.Price).IsRequired().HasColumnType("decimal(18,2)");
			builder.Property(c => c.IsActive).IsRequired().HasDefaultValue(true);
			builder.Property(c => c.IsDeleted).IsRequired().HasDefaultValue(false);
			builder.Property(c => c.CreatedAt).IsRequired().HasColumnType("TIMESTAMP WITH TIME ZONE");
			builder.Property(c => c.UpdatedAt).IsRequired(false);
			builder.Property(c => c.StartDate).IsRequired();
			builder.Property(c => c.ExpiryDate).IsRequired();
			builder.Property(c => c.DeletedAt).IsRequired(false);
		}
	}
	public sealed class SubscriptionBenefitSchemaConfigurations : IEntityTypeConfiguration<SubscriptionBenefit>
	{
		public void Configure(EntityTypeBuilder<SubscriptionBenefit> builder)
		{
			builder.ToTable(nameof(SubscriptionBenefit)).HasKey(c => c.Id);
			builder.Property(c => c.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(c => c.Type).IsRequired();
			builder.Property(c => c.UnitType).IsRequired();
			builder.Property(c => c.Unit).IsRequired();
			builder.Property(c => c.AdsFreeExperience).IsRequired();
			builder.Property(c => c.SubscriptionId).IsRequired();

			// foreign key
			builder
				.HasOne(c => c.Subscription)
				.WithMany(c => c.Benefits)
				.HasForeignKey(c => c.SubscriptionId)
				.HasConstraintName($"FK_{nameof(SubscriptionBenefit)}_{nameof(Subscription)}_{nameof(Subscription)}Id")
				.OnDelete(DeleteBehavior.Cascade);
		}
	}
	public sealed class UserSubscriptionSchemaConfigurations : IEntityTypeConfiguration<UserSubscription>
	{
		public void Configure(EntityTypeBuilder<UserSubscription> builder)
		{
			builder.ToTable(nameof(UserSubscription)).HasKey(us => us.Id);
			builder.Property(us => us.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(us => us.UserId).IsRequired();
			builder.Property(us => us.SubscriptionId).IsRequired();

			// foreign key
			builder
				.HasOne(us => us.User)
				.WithMany(us => us.UserSubscriptions)
				.HasForeignKey(us => us.UserId)
				.HasConstraintName($"FK_{nameof(UserSubscription)}_{nameof(User)}_{nameof(User)}Id")
				.OnDelete(DeleteBehavior.Restrict);

			// foreign key
			builder
				.HasOne(us => us.Subscription)
				.WithMany(us => us.UserSubscriptions)
				.HasForeignKey(us => us.SubscriptionId)
				.HasConstraintName($"FK_{nameof(UserSubscription)}_{nameof(Subscription)}_{nameof(Subscription)}Id")
				.OnDelete(DeleteBehavior.Restrict);
		}
	}

	public sealed class FriendshipSchemaConfigurations : IEntityTypeConfiguration<Friendship>
	{
		public void Configure(EntityTypeBuilder<Friendship> builder)
		{
			builder.ToTable(nameof(Friendship)).HasKey(f => f.Id);
			builder.Property(f => f.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(f => f.Status).IsRequired().HasMaxLength(50);
			builder.Property(f => f.InitiatorId).IsRequired();
			builder.Property(f => f.ResponderId).IsRequired();

			// foreign key
			builder
				.HasOne(f => f.Initiator)
				.WithMany(f => f.FriendshipInitiators)
				.HasForeignKey(f => f.InitiatorId)
				.HasConstraintName($"FK_{nameof(Friendship)}_{nameof(Core.Entities.Friendship.Initiator)}_{nameof(Core.Entities.Friendship.Initiator)}Id")
				.OnDelete(DeleteBehavior.Restrict);

			// foreign key
			builder
				.HasOne(f => f.Responder)
				.WithMany(f => f.FriendshipResponders)
				.HasForeignKey(f => f.ResponderId)
				.HasConstraintName($"FK_{nameof(Friendship)}_{nameof(Core.Entities.Friendship.Responder)}_{nameof(Core.Entities.Friendship.Responder)}Id")
				.OnDelete(DeleteBehavior.Restrict);
		}
	}
	public sealed class TripPlaceSchemaConfigurations : IEntityTypeConfiguration<TripPlace>
	{
		public void Configure(EntityTypeBuilder<TripPlace> builder)
		{
			builder.ToTable(nameof(TripPlace)).HasKey(tp => tp.Id);
			builder.Property(tp => tp.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(tp => tp.TripId).IsRequired();
			builder.Property(tp => tp.PlaceId).IsRequired();

			// foreign key
			builder
				.HasOne(tp => tp.Trip)
				.WithMany(tp => tp.TripPlaces)
				.HasForeignKey(tp => tp.TripId)
				.HasConstraintName($"FK_{nameof(TripPlace)}_{nameof(Trip)}_{nameof(Trip)}Id")
				.OnDelete(DeleteBehavior.Restrict);

			// foreign key
			builder
				.HasOne(tp => tp.Place)
				.WithMany(tp => tp.TripPlaces)
				.HasForeignKey(tp => tp.PlaceId)
				.HasConstraintName($"FK_{nameof(TripPlace)}_{nameof(Place)}_{nameof(Place)}Id")
				.OnDelete(DeleteBehavior.Restrict);
		}
	}

	public sealed class CurrencySchemaConfigurations : IEntityTypeConfiguration<Currency>
	{
		public void Configure(EntityTypeBuilder<Currency> builder)
		{
			builder.ToTable(nameof(Currency)).HasKey(cr => cr.Id);
			builder.Property(cr => cr.Id).ValueGeneratedOnAdd().UseIdentityColumn();
			builder.Property(cr => cr.Name).IsRequired().HasMaxLength(255);
			builder.Property(cr => cr.Symbol).IsRequired().IsUnicode(true).HasMaxLength(10);
			builder.Property(cr => cr.Code).IsRequired().HasMaxLength(5);

			// Define the relationship with Trip
			builder.HasMany(c => c.Trips)
				.WithOne(t => t.Currency)
				.HasForeignKey(t => t.CurrencyId)
				.HasConstraintName($"FK_{nameof(Currency)}_{nameof(Trip)}_{nameof(Trip)}Id")
				.OnDelete(DeleteBehavior.Restrict);
		}
	}

	#endregion

	public static void Migrate(IServiceProvider serviceProvider, IConfiguration configuration)
	{
		using var scope = serviceProvider.CreateScope();
		var database = scope.ServiceProvider.GetService<AppDbContext>()?.Database;
		if (database?.GetPendingMigrations().Any() == true)
		{
			database.Migrate();
		}
	}
}
