﻿using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface ICustomEvents_DL
    {
        Task<GenericResult<bool>> AddCustomEvents(AddCustomEventsRequest request, ApiCustomEventResponse apiResponseModel, string airShipRequestJson, HttpStatusCode statusCode, bool isSuccess);
        Task<GenericResult<bool>> AddCustomEventsError(AddCustomEventsRequest request, string airShipResponseJson, string airShipRequestJson, HttpStatusCode statusCode, bool isSuccess);
    }
}
