﻿$(document).ready(function () {

    $('#overlay').hide();

    var settngs = $.data($('#checkOut-form')[0], 'validator').settings;
    settngs.ignore = ".ignore";


    if ($('input[name="NoCards"]').val() == "Yes") {
        $(".cardsData").removeClass('ignore');
        $('#SecurityCode').addClass('ignore');
    }
    else {
        if ($('input[name="AllCards"]').is(':checked')) {
            $('#Token').val($('input[name="AllCards"]:checked').val());
        }
        $('#SecurityCode').removeClass('ignore');
        $(".cardsData").addClass('ignore');
    }

    $('#btnTransferSubmit').click(function () {

        if ($('#checkOut-form').valid()) {

            $('#overlay').show();

            //Save Card
            if ($('#chk_SaveCard').is(':checked')) {
                $('#IsRegistered').val(true);
            }
            else {
                $('#IsRegistered').val(false);
            }

            $('#checkOut-form').submit();
        } else {
            return false;
        }
    });


    $('input[name="AllCards"]').click(function () {
        if ($(this).is(':checked')) {
            $('#NewCardSection').hide();
            $('#Token').val($('input[name="AllCards"]:checked').val());
            $("#new-card").prop("checked", false);
            $('#ExistingCardSecurityCodeSection_transfer').show();
            $(".cardsData").addClass('ignore');
            $('#SecurityCode').removeClass('ignore');
        }
    });

    $('#new-card').click(function () {
        if ($(this).is(':checked')) {
            $('#NewCardSection').show();
            $('input[name="AllCards"]').prop("checked", false);
            $('#Token').val('');
            $('#ExistingCardSecurityCodeSection_transfer').hide();
            $(".cardsData").removeClass('ignore');
            $('#SecurityCode').addClass('ignore');
        }
    });

});