﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Models.Contracts.Request;
using Models.Contracts.Request.AndroidInAppPayment;
using Models.Contracts.Response;
using Models.Database;
using Models.Enums;
using Models.Services.Airship;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class Topup_BL : ITopup_BL
    {
        private readonly IHelper_BL HelperService;
        private readonly ILogger Logger;
        private readonly IUserAccount_BL UserAccountBL;
        private readonly IUserAccount_DL UserAccountDL;
        private readonly ITopup_DL TopupDL;
        private readonly IPay360Service Pay360Service;
        private readonly IAirShipService _airShipService;
        private readonly IFaceBookService _faceBookService;
        private readonly IAppsFlyerService _appsFlyerService;
        private readonly IStringLocalizer Localizer;
        private readonly IOffer_DL OfferDL;
        private readonly IConfiguration Config;
        private readonly IPlatformTesterService PlatformTesterService;
        private readonly IHttpService HttpService;

        //private const string ReceiptVerificationProductionEndpoint = "https://buy.itunes.apple.com/verifyReceipt";
        //private const string ReceiptVerificationSandboxEndpoint = "https://sandbox.itunes.apple.com/verifyReceipt";

        public Topup_BL(
            IHttpService httpService,
            IPlatformTesterService platformTesterService,
            IConfiguration config,
            IUserAccount_DL userAccount_DL,
            IOffer_DL offer_DL,
            IHelper_BL helperService,
            ILogger logger,
            IUserAccount_BL userAccount_BL,
            ITopup_DL topup_DLL,
            IStringLocalizer localizer,
            IPay360Service pay360_BL,
            IAirShipService airShipService,
            IFaceBookService faceBookService,
            IAppsFlyerService appsFlyerService)
        {
            HelperService = helperService;
            Logger = logger;
            UserAccountBL = userAccount_BL;
            TopupDL = topup_DLL;
            Localizer = localizer;
            OfferDL = offer_DL;
            UserAccountDL = userAccount_DL;
            Config = config;
            PlatformTesterService = platformTesterService;
            HttpService = httpService;
            Pay360Service = pay360_BL;
            _airShipService = airShipService;
            _faceBookService = faceBookService;
            _appsFlyerService = appsFlyerService;
        }

        public async Task<GenericApiResponse<LastTopup>> GetLastTopUp(string accountNumber, string msisdn, string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                var userInfo = await UserAccountDL.GetUserProfile(msisdn);
                if (userInfo.Status == Models.Enums.Status.Success)
                {
                    if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
                        email = userInfo.Data.email.Trim();
                }
            }

            var result = await TopupDL.GetLastTopUpPayment(msisdn);

            if (result != null)
            {
                var response = await Pay360Service.GetAutoTopUp(msisdn, email);
                result.AutoTopUp = response.ErrorCode == 0 ? response.Payload : null;
                return GenericApiResponse<LastTopup>.Success(result, "Last Topup Found!");
            }
            return GenericApiResponse<LastTopup>.Success(result, "No Record Found");

        }
        public async Task<GenericApiResponse<TopUpPaymentHistoryResponseModel>> GetTopUpPaymentHistory(string accountNumber)
        {
            var result = await TopupDL.GetTopUpPaymentHistory(accountNumber);

            return GenericApiResponse<TopUpPaymentHistoryResponseModel>.Success(
                          new TopUpPaymentHistoryResponseModel()
                          {
                              TopUpHistory = result
                          }, result.Count() > 0 ? "Found topup history" : "TopUp history not found");

        }
        public async Task<GenericApiResponse<VerifyReceiptResponse>> VerifyInAppPurchaseReceipt(VerifyReceiptRequest request)
        {
            var response = new GenericApiResponse<VerifyReceiptResponse>();

            if (request == null || request.AppVersion == null || request.AppVersion != Config["ApiConfig:payment_itunes_only_version"])
                return response;

            var verifyReceiptResponse = new VerifyReceiptResponse();



            //Check that receipt doesn't exist in database already first
            if (await TopupDL.ReceiptDoesNotExist(request.Receipt))
            {
                var json = new JObject(new JProperty("receipt-data", request.Receipt)).ToString();

                var result = await HttpService.PostAsync(Config["ReceiptVerificationProductionEndpoint"], json);

                var inAppPurchaseReceipt = JsonConvert.DeserializeObject<InAppPurchaseReceipt>(result);

                var itunesTransactionStatus = "Failed";
                var itunesStatus = "COMPLETED";
                var itunesReason = String.Format("Failed - {0}", inAppPurchaseReceipt.Status);
                var topupAmount = 0m;

                if (inAppPurchaseReceipt.Status == 21007 && PlatformTesterService.CanTestInAppPurchase(request.Msisdn))
                {
                    //Valid sandbox receipt and tester
                    //Try again using the sandbox endpoint
                    result = await HttpService.PostAsync(Config["ReceiptVerificationSandboxEndpoint"], json);

                    inAppPurchaseReceipt = JsonConvert.DeserializeObject<InAppPurchaseReceipt>(result);
                }

                if (inAppPurchaseReceipt.Status == 0 &&
                    !String.IsNullOrEmpty(inAppPurchaseReceipt.Receipt.Bid) &&
                    inAppPurchaseReceipt.Receipt != null &&
                    !String.IsNullOrEmpty(inAppPurchaseReceipt.Receipt.Bid) &&
                    inAppPurchaseReceipt.Receipt.Bid == "com.distribution.talkhomeapps")
                {
                    var productId = inAppPurchaseReceipt.Receipt.InAppData[0].ProductId;
                    var purchaseAmount = productId.Substring(4, productId.Length - 4);
                    topupAmount = Convert.ToDecimal(purchaseAmount, CultureInfo.InvariantCulture);
                    itunesTransactionStatus = "Success";
                    itunesReason = "Success";

                    await TopupDL.StoreInAppPurchaseData(request, inAppPurchaseReceipt, topupAmount,
                         itunesTransactionStatus, itunesStatus, itunesReason);

                    //Update account balance here!
                    var userAccount = await UserAccountDL.GetUserAccount(request.Msisdn);

                    await TopupDL.ApplyInAppPurchaseCredit(topupAmount, inAppPurchaseReceipt.Receipt.InAppData[0].TransactionId, userAccount);

                    userAccount = await UserAccountDL.GetUserAccountWithBalance(request.Msisdn);
                    verifyReceiptResponse.Credit = topupAmount.ToString(CultureInfo.InvariantCulture);
                    verifyReceiptResponse.Balance = userAccount.UserAccountBalance.Balance.ToString(CultureInfo.InvariantCulture);
                    verifyReceiptResponse.TransactionId = Guid.NewGuid().ToString();
                    response.Status = "Success";
                    response.Message = Localizer["InAppPurchaseSuccessful"];
                    response.Payload = verifyReceiptResponse;
                }
                else
                {
                    var success = await TopupDL.StoreInAppPurchaseData(request, inAppPurchaseReceipt, topupAmount,
                        itunesTransactionStatus, itunesStatus, itunesReason);

                    verifyReceiptResponse.TransactionId = Guid.NewGuid().ToString();
                    response.Status = "Failure";
                    response.Message = Localizer["ReceiptVerificationFailed"];
                    response.Payload = verifyReceiptResponse;
                }
            }
            else
            {

                await TopupDL.StoreDuplicateReceipt(request);

                response.Status = "Failure";
                response.Message = $"{Localizer["ReceiptVerificationFailed"]} - Code Red";
                //Ensure we return a transaction id for the failed attempt, 
                //to ensure that iOS doesnt keep retrying.
                verifyReceiptResponse.TransactionId = Guid.NewGuid().ToString();
                response.Payload = verifyReceiptResponse;
            }
            return response;
        }
        public async Task<GenericApiResponse<ValidateResponse>> ValidateCustomer(string msisdn, string typePayment)
        {
            GenericApiResponse<ValidateResponse> gr = new GenericApiResponse<ValidateResponse>();
            ValidateResponse vres = new ValidateResponse();
            vres.isValid = false;
            vres.errorCode = 3;
            vres.errorMessage = "Validation failed";

            gr.Payload = vres;
            gr.Status = "failed";
            gr.Message = "Validation process failed";

            try
            {
                var res = await TopupDL.Validate(msisdn, typePayment.ToLower());

                if (res != null)
                {
                    gr.Payload = res;
                    gr.Status = "success";
                    gr.Message = "successfully executed the validation process";
                }


                return gr;

            }
            catch (Exception ex)
            {
                Logger.Error("Customer Validation exception {Ex}", ex.ToString());
                Debug.Write("Customer Validation exception: " + ex.ToString());
            }

            return gr;
        }
        public async Task<GenericApiResponse<InAppPurchaseOptions>> GetInAppIosPurchaseOptions1(string msisdn, string version)
        {
            var msisdnCountry = HelperService.GetISOCurrencyCode(msisdn);

            var list = new List<InAppPurchase>()
            {
                new InAppPurchase()
                {
                    Credit = "2.80",
                    Currency = "USD",
                },
                new InAppPurchase()
                {
                    Credit = "4.90",
                    Currency = "USD"
                },
                new InAppPurchase()
                {
                    Credit = "9.80",
                    Currency = "USD",
                }

            };

            var response = new GenericApiResponse<InAppPurchaseOptions>();
            var inAppPurchaseOptions = new InAppPurchaseOptions();


            if (version != null && Config["ApiConfig:payment_itunes_only_version"].ToString(CultureInfo.InvariantCulture) == version)
            {
                list = list.Where(x => x.Currency == "USD").ToList();

                inAppPurchaseOptions.inAppPurchase = list;

                if (inAppPurchaseOptions.Buttons?.Count > 0 || list.Count > 0 || inAppPurchaseOptions.Ivr?.Length > 0)
                {
                    response.Status = "Success";
                    response.Message = "Success";
                    response.Payload = inAppPurchaseOptions;
                }
                else
                {
                    response.Status = "Failure";
                    response.Message = "Failure";
                }

                return response;
            }


            list = list.Where(x => x.Currency == msisdnCountry).ToList();

            //inAppPurchaseOptions.inAppPurchase = list;

            var locale = Localizer["Locale"]; ;

            var ivrNumber = await TopupDL.GetIVRTopupNumber(locale, msisdn);

            inAppPurchaseOptions.Ivr = ivrNumber;

            var userAccount = await UserAccountDL.GetUserAccount(msisdn);

            PaymentConfigurations pc = await TopupDL.GetPaymentConfig(userAccount.UserAccountDetails.Na_Service_Id);

            inAppPurchaseOptions.Voucher = pc.ShowVoucherPayment;

            inAppPurchaseOptions.Buttons = ConfigurePaymentButtons1(pc, userAccount, ivrNumber);

            if (inAppPurchaseOptions.Buttons.Count == 0)
                inAppPurchaseOptions.inAppPurchase = list;
            else
                inAppPurchaseOptions.inAppPurchase = new List<InAppPurchase>();

            //inAppPurchaseOptions.CardUrl = pc.ShowCardPayment ? ConfigureCardPaymentUrl(userAccount.UserAccountBalance.Currency, languageProvider.Message.GetLocale(), userAccount.Msisdn) : "";

            if (inAppPurchaseOptions.Buttons?.Count > 0 || list.Count > 0 || inAppPurchaseOptions.Ivr?.Length > 0)
            {
                response.Status = "Success";
                response.Message = "Success";
                response.Payload = inAppPurchaseOptions;
            }
            else
            {
                response.Status = "Failure";
                response.Message = "Failure";
            }

            return response;
        }
        public async Task<GenericApiResponse<IList<PaymentButtons>>> GetAndroidPurchaseOptions(string msisdn)
        {
            var response = new GenericApiResponse<IList<PaymentButtons>>();
            response.Status = "Success";
            response.Message = "Success";
            try
            {
                var userAccount = await UserAccountDL.GetUserAccount(msisdn);

                var locale = Localizer["Locale"]; ;

                PaymentConfigurations pc = await TopupDL.GetPaymentConfigAndroid(userAccount.UserAccountDetails.Na_Service_Id);

                var ivrNumber = await TopupDL.GetIVRTopupNumber(locale, msisdn);

                IList<PaymentButtons> pbList = ConfigurePaymentButtonsNeW(pc, userAccount, ivrNumber);

                response.Payload = pbList;

            }
            catch (Exception)
            {
                response.Status = "Failure";
                response.Message = "Failure";

            }

            return response;
        }
        public async Task<GenericApiResponse<VoucherTopupResponse>> VoucherTopup(VoucherTopupRequest request)
        {
            /*Error codes
		    RET_UNKNOWN_ERROR				= -1
		    RET_SUCCESS						= 0
		    RET_ACCOUNT_INVALID				= -101
		    RET_VOUCHER_PIN_INVALID			= -201
		    RET_VOUCHER_TERMINATED			= -202
		    RET_VOUCHER_INACTIVE			= -203
		    RET_VOUCHER_IN_USE				= -204
		    RET_VOUCHER_HAS_BEEN_USED		= -205
		    RET_VOUCHER_INVALID_ID			= -206
		    RET_BATCH_INVALID				= -301 -- Used for both invalid batch no. and expired batches
		    RET_BATCH_LIFETIME_EXCEEDED		= -302
		    RET_BATCH_INACTIVE				= -303
		    RET_BATCH_INCOMPATIBLE_CURRENCY	= -304
		    RET_BATCH_INCOMPATIBLE_BUNDLE	= -305
		    RET_BATCH_MAX_BUNDLES			= -306
		    RET_BATCH_VOUCHERS_NOT_ENABLED	= -307
		    RET_CARD_ORDER_INACTIVE			= -401
		    RET_VOUCHER_DATABASE_INVALID	= -402
		    RET_BATCH_INVALID_BUNDLE		= -403
		    RET_VOUCHER_RECHARGING_DISABLED	= -404
		    */

            var msisdnOrigin = HelperService.GetCountryCode(request.Msisdn);
            request.Msisdn = HelperService.StripLeadingZeros(request.Msisdn);

            DeviceType deviceType = (DeviceType)request.DeviceType;

            var response = new GenericApiResponse<VoucherTopupResponse>();

            var userAccount = await UserAccountBL.GetUserAccountWithoutCaching(request.Msisdn);

            if (userAccount != null && !string.IsNullOrEmpty(userAccount.AccountID) && userAccount.Msisdn == request.Msisdn)
            {
                //Set the balance before and after to the same, until the transaction completes
                var voucherTopupResponse = new VoucherTopupResponse();
                voucherTopupResponse.BalanceBefore = userAccount.UserAccountBalance.Balance;
                voucherTopupResponse.BalanceAfter = userAccount.UserAccountBalance.Balance;
                voucherTopupResponse.CreditApplied = string.Empty;

                if (userAccount.Pin == request.Pin && await TopupDL.IsEligible(request.Msisdn, request.VoucherCode))
                {
                    if (await TopupDL.VerifyVoucherCode(request.VoucherCode))
                    {
                        var topupResultMessage = await TopupDL.ApplyVoucherCode(request.VoucherCode, userAccount, voucherTopupResponse);

                        bool offerApplied = false;
                        if (topupResultMessage.ToLower() == "success")
                        {
                            var creditApplied = voucherTopupResponse.CreditApplied;

                            if (EligibleForGreeceTopupOffer(userAccount.Msisdn, creditApplied))
                            {

                                offerApplied = await OfferDL.AddGreeceTopupOffer(userAccount);
                            }

                            //Topup successful, apply new balance to response
                            userAccount = await UserAccountBL.GetUserAccountWithoutCaching(request.Msisdn);
                            voucherTopupResponse.BalanceAfter = userAccount.UserAccountBalance.Balance;

                            if (offerApplied)
                            {
                                voucherTopupResponse.CreditApplied = GetVoucherAndOfferCreditApplied(voucherTopupResponse);
                                response.Message = Localizer["VoucherAndOfferTopupSuccessful"];
                            }
                            else
                            {
                                response.Message = Localizer["VoucherTopupSuccessful"];
                            }

                            response.Status = "Success";
                            response.Payload = voucherTopupResponse;
                        }
                        else
                        {
                            response.Status = "Failure";
                            response.Message = Localizer["VoucherCodeInvalid"];
                            response.Payload = voucherTopupResponse;
                        }
                    }
                    else
                    {
                        response.Status = "Failure";
                        response.Message = Localizer["VoucherCodeInvalid"];
                        response.Payload = voucherTopupResponse;
                    }
                }
                else
                {

                    response.Status = "Failure";
                    response.Message = Localizer["VoucherTopupNotEligible"];
                    response.Payload = voucherTopupResponse;
                }
            }


            //Handle Airship
            if (response.Payload != null)
            {
                if (!string.IsNullOrEmpty(response.Payload.CreditApplied)
                                    && (response.Payload.BalanceBefore != response.Payload.BalanceAfter))
                {

                    var voucherAmount = ((int)Math.Round(float.Parse(response.Payload.BalanceAfter, CultureInfo.InvariantCulture) - float.Parse(response.Payload.BalanceBefore, CultureInfo.InvariantCulture))).ToString(CultureInfo.InvariantCulture);

                    await _airShipService.HandleTopupTagsAndEvents(
                        new TopupInfoAirship()
                        {
                            Amount = voucherAmount,
                            IsCard = null,
                            Origination = msisdnOrigin,
                            IsSuccess = true,
                            Msisdn = request.Msisdn
                        });


                    //Handle FaceBook Events
                    await _faceBookService.HandleTopupEvents(request.advertiserID, true, null, Convert.ToDecimal(voucherAmount, CultureInfo.InvariantCulture), userAccount.UserAccountBalance.Currency, msisdnOrigin);
                    //Handle AppsFlyer Events
                    await _appsFlyerService.HandleTopupEvents(request.AppsFlyerId, deviceType, true, null, Convert.ToDecimal(voucherAmount, CultureInfo.InvariantCulture), userAccount.UserAccountBalance.Currency, msisdnOrigin);
                }
                else
                {
                    await _airShipService.HandleTopupTagsAndEvents(
                        new TopupInfoAirship()
                        {
                            Amount = null,
                            Origination = msisdnOrigin,
                            IsCard = null,
                            IsSuccess = false,
                            Msisdn = request.Msisdn
                        });

                    //Handle FaceBook Events
                    await _faceBookService.HandleTopupEvents(request.advertiserID, false, null, 0, userAccount.UserAccountBalance.Currency, msisdnOrigin);
                    //Handle AppsFlyer Events
                    await _appsFlyerService.HandleTopupEvents(request.AppsFlyerId, deviceType, false, null, 0, userAccount.UserAccountBalance.Currency, msisdnOrigin);
                }
            }

            return response;
        }
        public bool EligibleForGreeceTopupOffer(string msisdn, string voucherTopupAmount)
        {
            if (!string.IsNullOrEmpty(msisdn) && !string.IsNullOrEmpty(voucherTopupAmount))
            {
                var previousVoucherTopupAmount = Convert.ToDecimal(voucherTopupAmount, CultureInfo.InvariantCulture);

                var formattedMsisdn = HelperService.FormatMsisdn(msisdn);

                var country = HelperService.GetCountryName(formattedMsisdn);

                var offerEndDate = new DateTime(2016, 07, 10);

                if (country == "Greece" && previousVoucherTopupAmount >= 5.00m && DateTime.Now.Date <= offerEndDate)
                {
                    return true;
                }
            }
            return false;
        }
        private string GetVoucherAndOfferCreditApplied(VoucherTopupResponse voucherTopupResponse)
        {
            var before = Convert.ToDecimal(voucherTopupResponse.BalanceBefore, CultureInfo.InvariantCulture);
            var after = Convert.ToDecimal(voucherTopupResponse.BalanceAfter, CultureInfo.InvariantCulture);
            var totalCreditApplied = after - before;
            return totalCreditApplied.ToString(CultureInfo.InvariantCulture);
        }
        private IList<PaymentButtons> ConfigurePaymentButtonsNeW(PaymentConfigurations pc, UserAccount userAccount, string ivrNumber)
        {
            List<PaymentButtons> pbs = new List<PaymentButtons>();
            var locale = Localizer["Locale"]; ;



            if (pc.ShowVoucherPayment)
            {

                PaymentButtons pbVoucher = new PaymentButtons();
                pbVoucher.title = Localizer["Voucher"];
                pbVoucher.link = "app://voucher";
                pbVoucher.colour = "#004389";
                pbs.Add(pbVoucher);
            }

            if (pc.ShowCardPayment)
            {

                PaymentButtons pbCard = new PaymentButtons();
                pbCard.title = Localizer["TopupbyCard"];
                pbCard.link = ConfigureCardPaymentNewUrl(userAccount.UserAccountBalance.Currency, locale, userAccount.Msisdn);
                pbCard.colour = "#797977";
                pbs.Add(pbCard);
            }

            if (pc.ShowPaypalPayment)
            {
                PaymentButtons pbPP = new PaymentButtons();
                pbPP.title = Localizer["TopupbyPaypal"];
                pbPP.link = ConfigurePaypalPaymentUrl(userAccount.UserAccountBalance.Currency, locale, userAccount.Msisdn);
                pbPP.colour = "#009cde";
                pbs.Add(pbPP);
            }

            if (pc.ShowIvrPayment && (ivrNumber != null && ivrNumber != ""))
            {
                PaymentButtons pbIvr = new PaymentButtons();
                pbIvr.title = Localizer["CalltoTopUp"];
                pbIvr.link = "ivr:" + ivrNumber;
                pbIvr.colour = "#004389";
                pbs.Add(pbIvr);
            }
            if (pc.InAppPayment)
            {
                PaymentButtons pbAA = new PaymentButtons();
                pbAA.title = Localizer["InAppTransfer"];
                pbAA.link = "app://inapp_transfer";
                pbAA.colour = "#474747";
                pbs.Add(pbAA);
            }

            return pbs;
        }
        private IList<PaymentButtons> ConfigurePaymentButtons1(PaymentConfigurations pc, UserAccount userAccount, string ivrNumber)
        {
            List<PaymentButtons> pbs = new List<PaymentButtons>();
            var locale = Localizer["Locale"]; ;

            if (pc.ShowVoucherPayment)
            {

                PaymentButtons pbVoucher = new PaymentButtons();
                pbVoucher.title = Localizer["Voucher"];
                pbVoucher.link = "app://voucher";
                pbVoucher.colour = "#012169";
                pbs.Add(pbVoucher);
            }

            if (pc.ShowCardPayment)
            {

                PaymentButtons pbCard = new PaymentButtons();
                pbCard.title = Localizer["TopupbyCard"];
                pbCard.link = ConfigureCardPaymentUrl(userAccount.UserAccountBalance.Currency, locale, userAccount.Msisdn);
                pbCard.colour = "#34d9cd";
                pbs.Add(pbCard);
            }

            if (pc.ShowPaypalPayment)
            {
                PaymentButtons pbPP = new PaymentButtons();
                pbPP.title = Localizer["TopupbyPaypal"];
                pbPP.link = ConfigurePaypalPaymentUrl(userAccount.UserAccountBalance.Currency, locale, userAccount.Msisdn);
                pbPP.colour = "#00c8ff";
                pbs.Add(pbPP);
            }

            if (pc.ShowIvrPayment && (ivrNumber != null && ivrNumber != ""))
            {
                PaymentButtons pbIvr = new PaymentButtons();
                pbIvr.title = Localizer["CalltoTopUp"];
                pbIvr.link = "ivr:" + ivrNumber;
                pbIvr.colour = "#012169";
                pbs.Add(pbIvr);
            }

            if (pc.InAppPayment)
            {
                PaymentButtons pbAA = new PaymentButtons();
                pbAA.title = Localizer["InAppTransfer"];
                pbAA.link = "app://inapp_transfer";
                pbAA.colour = "#474747";
                pbs.Add(pbAA);
            }



            return pbs;
        }
        private string ConfigureCardPaymentUrl(string currency, string locale, string msisdn)
        {
            string url = "";
            //Payment:New:Prefix
            if (Config["Payment_New"].ToString(CultureInfo.InvariantCulture).Equals("1"))
            {
                url = Config["Payment_Card_Url_New_1"].ToString(CultureInfo.InvariantCulture) + "/TopUp/Card?msisdn=" + msisdn + "&currency=" + currency + "&language=" + locale;
                return url;
            }

            if (Config["Payment_New"].ToString(CultureInfo.InvariantCulture).Equals("2"))
            {
                url = Config["Payment_Card_Url_New_2"].ToString(CultureInfo.InvariantCulture) + "/TopUp/Card?msisdn=" + msisdn + "&currency=" + currency + "&language=" + locale;
            }
            else
            {
                if (locale.Equals("en"))
                    url = Config["Payment_Card_Url"].ToString(CultureInfo.InvariantCulture) + "app_topUp_secundus.jsp?accountType=" + currency + "&currency=" + currency + "&msisdn=" + msisdn;
                else
                    url = Config["Payment_Card_Url"].ToString(CultureInfo.InvariantCulture) + locale + "/app_topUp_secundus.jsp?accountType=" + currency + "&currency=" + currency + "&msisdn=" + msisdn;
            }

            return url;
        }
        private string ConfigureCardPaymentNewUrl(string currency, string locale, string msisdn)
        {
            string url = "";
            //
            //
            //(ConfigurationManager.AppSettings["Payment:New"].ToString(CultureInfo.InvariantCulture).Equals("1") && msisdn.StartsWith("33"))

            if (Config["Payment_New"].ToString(CultureInfo.InvariantCulture).Equals("1"))
            {
                url = Config["Payment_Card_Url_New_1"].ToString(CultureInfo.InvariantCulture) + "/TopUp/Card?msisdn=" + msisdn + "&currency=" + currency + "&language=" + locale;
                return url;
            }



            if (Config["Payment_New"].ToString(CultureInfo.InvariantCulture).Equals("2"))
            {
                url = Config["Payment_Card_Url_New_2"].ToString(CultureInfo.InvariantCulture) + "/TopUp/Card?msisdn=" + msisdn + "&currency=" + currency + "&language=" + locale;
            }
            else
            {
                if (locale.Equals("en"))
                    url = Config["Payment_Card_Url"].ToString(CultureInfo.InvariantCulture) + "app_topUp_secundus.jsp?accountType=" + currency + "&currency=" + currency + "&msisdn=" + msisdn;
                else
                    url = Config["Payment_Card_Url"].ToString(CultureInfo.InvariantCulture) + locale + "/app_topUp_secundus.jsp?accountType=" + currency + "&currency=" + currency + "&msisdn=" + msisdn;
            }

            return url;
        }
        private string ConfigurePaypalPaymentUrl(string currency, string locale, string msisdn)
        {
            string url = Config["Payment_Paypal_Url"].ToString(CultureInfo.InvariantCulture) + msisdn + "&currency=" + currency + "&i18n=" + locale;

            return url;
        }
    }
}
