﻿using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class UserSIMOrderRequestModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int UserAddessId { get; set; }
        [Required]
        public ProductType Product { get; set; }
        public bool IsReplacement { get; set; }
    }
}
