﻿using MapsterMapper;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerCard.Request;
using SC.Core.Features.CustomerCard.Response;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.CustomerOrder.Responses;
using SC.Core.Interfaces.Services;
using SC.Core.Models.Dtos.CustomerCard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MessageBrokerModel;
using static MessageBrokerModel.TransactionMessageDto;

namespace SC.Core.Features.CustomerCard;
internal sealed class GetCustomerCardHandler : IRequestHandler<GetCustomerCardRequest, IResultWrapper>
{
    private readonly ICustomerCardRepository _customerCardRespository;
    private readonly ICommonService _commonService;
    private readonly IMapper _mapper;
    private readonly IMessagePublisher _messagePublisher;
    public GetCustomerCardHandler(ICustomerCardRepository customerCardRespository, ICommonService commonservice, IMapper mapper, IMessagePublisher messagePublisher)
    {
        _customerCardRespository = customerCardRespository;
        _commonService = commonservice;
        _mapper = mapper;
        _messagePublisher = messagePublisher;
    }
    public async Task<IResultWrapper> Handle(GetCustomerCardRequest request, CancellationToken cancellationToken)
    {
        await _messagePublisher.PublishMessage(new MessageBrokerModel.TransactionMessageDto()
        {
            Publisher = "test",
            TransactionReference = "tesklklkkl",
            TransactionItems = new TransactionItem()
            {
                CartReference = "tessasdfasdfsfasd01",
                ProductId = 456465,
                ProductVendorCode = "6vendorcode",
                Status = "Done"
            },
        });

        var Cards = await _customerCardRespository.GetCustomerCardsAsync(_commonService.GetUserID());
        var CardsList = _mapper.Map<List<GetCustomerCardResponse>>(Cards);
        return ResultWrapper.Success(CardsList);
    }
}

