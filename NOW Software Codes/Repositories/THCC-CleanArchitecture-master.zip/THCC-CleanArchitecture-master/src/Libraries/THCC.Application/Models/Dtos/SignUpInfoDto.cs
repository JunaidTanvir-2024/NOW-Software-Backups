﻿namespace THCC.Application.Models.Dtos
{
    public class SignUpInfoDto
    {
        public string? Id { get; set; }
        public bool IsSuccess { get; set; }
        public IEnumerable<IdentityErrorDto>? Errors { get; set; }
    }
}