using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Validations;

public class ValidationError
{
    [JsonPropertyName("key")]
    public string? Key { get; set; }

    [JsonPropertyName("code")]
    public int? ErrorCode { get; set; }

    [JsonPropertyName("message")]
    public string? Message { get; set; }

    [JsonPropertyName("request_id")]
    public string? RequestId { get; set; }
}
