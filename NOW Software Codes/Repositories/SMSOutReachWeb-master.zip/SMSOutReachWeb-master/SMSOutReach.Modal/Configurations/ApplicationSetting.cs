﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSOutReach.Model.Configurations
{
   public class ApplicationSetting
    {
        public string JobPriority { get; set; }
    }
}
