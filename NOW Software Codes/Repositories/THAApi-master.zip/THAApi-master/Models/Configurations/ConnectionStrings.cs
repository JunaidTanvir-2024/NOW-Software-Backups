﻿namespace Models.Configurations
{
    public class ConnectionStrings
    {
        public string TalkHomeAppDb { get; set; }
         public string TalkHomeAppsAccountsDb { get; set; }
        public string TalkHomeAppDigiTalkDb { get; set; }
        public string EjabberdRosterDb { get; set; }
        public string RosterDb { get; set; }
        public string SmsServiceDb { get; set; }
        public string THAClientLogsDb { get; set; }
        public string AttDb { get; set; }
        public string DigitalkAppsRepDb { get; set; }
        public string CmsCarouselDb { get; set; }
        public string TransferToDb { get; set; }
        public string CentralisedPaymentConnection { get; set; }
    }
}
