﻿namespace Application.Features.Payment.Models;

public class PaymentBundleInfo
{
    public int BundleId { get; set; }
    public bool IsRenewable { get; set; }
}
