﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TrasnferHome.Models.Utility
{
    public enum Roles
    {
        Guest = 1,
        User = 2,
        Admin = 3,
        Owner = 4
    }

    public enum AppleReceiptValidationEnvironment
    {
        Sandbox = 1,
        Live = 2
    }

    public enum SmsGateway
    {
        Twilio = 1,
        Xeebi = 2,
        Sap = 3
    }

    public enum UserTokenTypes
    {
        PhoneNumberVerificationToken = 1,
        ForgotPasswordVerificationToken = 2,
        EmailVerificationToken = 3
    }

    public enum TwoFactorTokenTypes
    {
        PhoneNumberToken = 1,
        EmailToken = 2
    }

    public enum SignUpType
    {
        Google = 1,
        Facebook = 2,
        Email = 3,
        PhoneNumber = 4
    }

    public enum LoginType
    {
        Google = 1,
        Facebook = 2,
        Email = 3,
        PhoneNumber = 4
    }

    public enum ProductType
    {
        TransferHome = 1
    }

    public enum TransferTransactionType
    {
        [Display(Name = "Transfer Home Account Topup")]
        TRHAT = 1,
        [Display(Name = "Transfer Home Through Account Balance")]
        TRHA = 2,
        [Display(Name = "Transfer Home Direct Transfer")]
        TRHDT = 3,
        [Display(Name = "Transfer Home Auto Direct Transfer")]
        TRHADT = 4,
    }

    public enum PaymentType
    {
        Paypal = 1,
        Card = 2,
        Voucher = 3,
        AccountBalance = 4
    }

    public enum TransferTransactionStatus
    {
        Success = 1,
        Failure = 2,
        Pending = 3
    }

    public enum Currency
    {
        GBP,
        USD,
        EUR,
        PKR
    }

    public enum CheckOutTypes
    {
        TopUp = 1,
        DirectTransfer = 2
    }

    public enum ProductCode
    {
        TRH
    }

    public enum ProductItemCode
    {
        TRHA,
        TRHAT,
        TRHDT
    }

    public enum TopUpType
    {
        Voucher = 1,
        Pay360 = 2,
        Paypal = 3,
        DebitTransfer = 4,
        ApplePay = 5
    }

    public enum DeviceType
    {
        Android = 1,
        IOS = 2
    }

    public enum RegularityType
    {
        Weekly = 1,
        Monthly = 2
    }

}
