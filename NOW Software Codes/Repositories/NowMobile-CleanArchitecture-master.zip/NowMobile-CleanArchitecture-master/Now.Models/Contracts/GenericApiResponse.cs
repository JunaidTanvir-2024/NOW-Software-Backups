﻿
namespace Now.Models.Contracts;

    public class GenericApiResponse<T>
    {
        public string? Message { get; set; }
        public string? Status { get; set; }
        public int ErrorCode { get; set; }
        public T? Payload { get; set; }
    }
