﻿using Application.Common.Interfaces.Infrastructure.Identity;
using Application.Common.Interfaces.Shared;

namespace Application.Features.Account.Product.Update;
internal class UpdateProductRequestHandler : IRequestHandler<UpdateProductRequest, Result<object>>
{
    #region Fields

    private readonly IStringLocalizer<UpdateProductRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly IOtpService _otpService;
    private readonly ISmsService _smsService;
    private readonly ICurrentUser _currentUser;


    #endregion

    #region Ctor

    public UpdateProductRequestHandler(
        IStringLocalizer<UpdateProductRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService,
        IOtpService otpService,
        ISmsService smsService,
        ICurrentUser currentUser)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _otpService = otpService;
        _smsService = smsService;
        _currentUser = currentUser;
    }

    #endregion

    #region Method

    public async Task<Result<object>> Handle(UpdateProductRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        //Check number is valid THM number
        var msisdn = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdn == null)
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Check number msisdn is not already attached
        if (await _unitOfWork.UserRepo.IsProductAlreadyAttached(request.Msisdn))
        {
            return Result<object>.Failure(
                _localizer[CustomStatusKey.MsisdnAlreadyRegistered], CustomStatusCode.MsisdnAlreadyRegistered);
        }

        //Check if product id exists user products
        var userProducts = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        if (!userProducts.Any(x => x.Id.Equals(request.ProductId)))
        {
            return Result<object>.Failure(
                _localizer[CustomStatusKey.InvalidProductReference], CustomStatusCode.InvalidProductReference);
        }

        //Crete verification Otp
        var otp = await _otpService.CreateOtp(request.Msisdn, OtpType.UpdateProduct, false);
        await _smsService.SendOtpMessage(request.Msisdn, otp.ToString());

        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
