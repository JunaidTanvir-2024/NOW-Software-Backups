using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Customers;

public class CustomerLoyalty
{
    [JsonPropertyName("points")]
    public int Points { get; set; }

    [JsonPropertyName("referred_customers")]
    public int ReferredCustomers { get; set; }

    [JsonPropertyName("campaigns")]
    public Metadata? Campaigns { get; set; }
}