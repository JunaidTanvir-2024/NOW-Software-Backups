﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static NowPayG.Models.ATTContracts.ATTModels;

namespace NowPayG.Services.Interfaces
{
    public interface IATTService
    {
        Task<ExecuteDataResponse> Execute(ExecuteDataRequest request);
        Task<GetProductResponse> GetProducts(GetProductRequest request);
    }
}
