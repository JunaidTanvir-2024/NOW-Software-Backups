﻿namespace SC.Api.Model.CustomerCard;
public record CustomerCardModel
{
    public string Pan { get; set; } = default!;
    public string NameOnCard { get; set; } = default!;
    public string CardType { get; set; } = default!;
    public string Expiry { get; set; } = default!;
    public bool IsDefault { get; set; } = default!;
}

