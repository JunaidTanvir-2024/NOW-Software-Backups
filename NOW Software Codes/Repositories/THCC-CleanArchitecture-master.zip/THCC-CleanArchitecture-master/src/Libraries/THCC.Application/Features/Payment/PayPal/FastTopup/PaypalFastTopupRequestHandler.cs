﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.PayPal.FastTopup
{
    public class PaypalFastTopupRequestHandler : IRequestHandler<PaypalFastTopupRequest, object>
    {
        #region Fields
        private readonly IPaymentService _paymentService;
        private readonly ICurrentUser _currentUser;
        private readonly IUserRepository _userRepository;
        private readonly ILogger _logger;
        private readonly IAirshipService _airshipService;
        private readonly IUserService _userService;
        #endregion

        #region Ctor

        public PaypalFastTopupRequestHandler(IPaymentService paymentService,
            ICurrentUser currentUser,
            IUserRepository userRepository,
            ILogger logger,
            IAirshipService airshipService,
            IUserService userService)
        {
            _paymentService = paymentService;
            _currentUser = currentUser;
            _userRepository = userRepository;
            _logger = logger;
            _airshipService = airshipService;
            _userService = userService;
        }

        #endregion

        #region Method

        public async Task<object> Handle(PaypalFastTopupRequest request, CancellationToken cancellationToken)
        {
            request.CardNumber = request.CardNumber.Trim();
            request.EmailAddress = request.EmailAddress != null ? request.EmailAddress!.Trim() : null;
            var userData = new UserDto();
            var productUser = await _userRepository.GetUserByProduct(request.CardNumber);
            if (_currentUser.IsAuthenticated())
            {
                if (productUser != null)
                {
                    //Check if the card number is logged-in user card number
                    if (productUser.Id.Equals(_currentUser.GetUserId(), StringComparison.InvariantCultureIgnoreCase))
                    {
                        userData.Email = _currentUser.GetUserEmail();
                        userData.Id = _currentUser.GetUserId();
                    }
                    else
                    {
                        userData.Email = productUser.Email!;
                        userData.Id = productUser.Id;
                    }
                }
                else
                {
                    //User must have to provide email address when card number is not registered
                    if (string.IsNullOrEmpty(request.EmailAddress))
                    {
                        _logger.Error("FastTopupNewCardPaymentRequestHandler => card number not registerd and email not provided: " + request.CardNumber);
                        return ErrorResult.Failure(
                                CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
                    }

                    //Check user is registered
                    var dbUser = await _userRepository.GetUserByEmailAsync(request.EmailAddress);
                    if (dbUser != null)
                    {
                        userData.Id = dbUser.Id;
                        userData.Email = dbUser.Email!;
                    }
                    else
                    {
                        var signupResponse = await _userService.SignUpAsync(
                             null!,
                             null!,
                             request!.EmailAddress,
                             null!,
                             UserRole.Guest,
                             false);

                        if (!signupResponse.IsSuccess)
                        {
                            return ErrorResult.Failure(CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
                        }

                        userData.Id = signupResponse!.Id!;
                        userData.Email = request!.EmailAddress;
                    }
                }
            }
            else
            {
                if (productUser != null)
                {
                    userData.Email = productUser.Email!;
                    userData.Id = productUser.Id;
                }
                else
                {
                    //User must have to provide email address when card number is not registered
                    if (string.IsNullOrEmpty(request.EmailAddress))
                    {
                        _logger.Error("FastTopupNewCardPaymentRequestHandler => card number not registerd and email not provided: " + request.CardNumber);
                        return ErrorResult.Failure(
                                CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
                    }

                    //Check user is registered
                    var dbUser = await _userRepository.GetUserByEmailAsync(request.EmailAddress);
                    if (dbUser != null)
                    {
                        userData.Id = dbUser.Id;
                        userData.Email = dbUser.Email!;
                    }
                    else
                    {
                        var signupResponse = await _userService.SignUpAsync(
                             null!,
                             null!,
                             request!.EmailAddress,
                             null!,
                             UserRole.Guest,
                             false);

                        if (!signupResponse.IsSuccess)
                        {
                            return ErrorResult.Failure(CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
                        }

                        userData.Id = signupResponse!.Id!;
                        userData.Email = request!.EmailAddress;
                    }
                }
            }

            #region Airship

            await _airshipService.CreateEmailChannelAndAssociation(userData.Email!);

            #endregion
            return await _paymentService.HandlePaypalPaymentRequest(
                productType: ProductType.FastTopup,
                userInfo: new UserDto()
                {
                    Id = userData.Id!,
                    Email = userData.Email!
                },
                amount: request!.Amount,
                cardNumber: request!.CardNumber!);
        }

        #endregion
    }
}
