﻿using System.Net;

namespace SenderService.Core.Common;
public class ApiResult<ReturnType>
{
    private const string _successMessage = "Congrats: Request fulfilled successfully";
    private const string _errorMessage = "Oops: An error occured while processing your request";
    public string? Message { get; set; }
    public bool Status { get; set; }
    public ReturnType? Payload { get; set; }
    public int StatusCode { get; set; }
    public Dictionary<string, string>? Errors { get; set; } = new Dictionary<string, string>();

    public static ApiResult<ReturnType> Success(string message = _successMessage, int successCode = (int) HttpStatusCode.OK, ReturnType? data = default, bool status = true)
    {
        return new ApiResult<ReturnType>
        {
            Message = message,
            Status = status,
            Payload = data,
            StatusCode = successCode,
        };
    }
    public static ApiResult<ReturnType> Failure(string message = _errorMessage, int errorCode = (int) HttpStatusCode.BadRequest,
    Dictionary<string, string>? errors = null, ReturnType? data = default, bool status = false)
    {
        return new ApiResult<ReturnType>
        {
            Message = message,
            Status = status,
            StatusCode = errorCode,
            Errors = errors,
            Payload = data,
        };
    }
}
