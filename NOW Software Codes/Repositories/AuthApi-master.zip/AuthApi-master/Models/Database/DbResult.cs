﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    public class DbResult<T>
    {
        public DbStatus ErrorCode { get; set; } // 1 = Success,  2 = Error
        public string ErrorMessage { get; set; }
        public T Data { get; set; }
    }

    public enum DbStatus
    {
        Success = 1,
        Error = 2,
        RatesNotAvailable = 3,
        CodeException = 4

    }


}
