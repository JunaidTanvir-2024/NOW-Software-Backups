﻿namespace Application.Common.Settings;
public class WebLinksSettings
{
    public const string SectionName = "WebLinksSettings";
    public static WebLinksSettings Bind = new WebLinksSettings();
    public string? TermsAndConditions { get; set; }
    public string? PrivacyPolicy { get; set; }
    public string? HelpCenter { get; set; }
    public string? AcceptanceUsage { get; set; }
    public string? ContactSupport { get; set; }
    public string? FaceBook { get; set; }
    public string? Twitter { get; set; }
    public string? Instagram { get; set; }
}