global using MM.Api;
global using Serilog;
global using MediatR;
global using Microsoft.AspNetCore.Mvc;
global using MM.Core;
global using MM.Infrastructure;
global using Asp.Versioning;
global using MM.Api.Controllers.Common; 
