﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class GetTransferCreditHistoryResponseModel
    {
        public IEnumerable<TransferCreditHistory> TransferCreditHistory { get; set; }
    }

    public class TransferCreditHistory
    {
        public int TransactionReferenceNumber { get; set; }
        public int TransactionTypeId { get; set; }
        public decimal Amount { get; set; }
        public string AmountCurrency { get; set; }
        public string OperatorName { get; set; }
        public string OperatorLogoUrl { get; set; }
        public string OperatorCountry { get; set; }
        public string CountryCode { get; set; }
        public string ReceiverNumber { get; set; }
        public string ReceiverCurrency { get; set; }
        public decimal ReceiverAmount { get; set; }
        public DateTime TransactionDateTime { get; set; }
        public int StatusId { get; set; }

        public string NowtelTransactionReference { get; set; }
        public int OperatorId { get; set; }

    }
}
