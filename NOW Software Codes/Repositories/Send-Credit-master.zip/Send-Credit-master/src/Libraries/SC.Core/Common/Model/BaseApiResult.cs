﻿using System.Text.Json.Serialization;

namespace SC.Core.Common.Model;
public class BaseApiResult
{
    [JsonPropertyName("message")]
    public string Message { get; set; }
    [JsonPropertyName("code")]
    public int Code { get; set; }
}

