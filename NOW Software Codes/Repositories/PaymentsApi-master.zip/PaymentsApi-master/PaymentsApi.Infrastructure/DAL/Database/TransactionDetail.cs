﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public class TransactionDetail
    {
        public string Id { get; set; }
        public string TransactionMerchantRef { get; set; }
        public string Pay360TransactionId { get; set; }
        public float TransactionAmount { get; set; }
        public string TransactionCurrency { get; set; }
        public int Customer_Id { get; set; }
        public bool Is3DSecure { get; set; }
        public int SummaryTranStatusId { get; set; }
        public bool IsDirectFullfilment { get; set; }       
        
    }
}
