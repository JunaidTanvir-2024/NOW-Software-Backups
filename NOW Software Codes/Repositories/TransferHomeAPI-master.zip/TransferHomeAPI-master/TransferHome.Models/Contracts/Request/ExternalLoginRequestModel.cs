﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class ExternalLoginRequestModel
    {
        [Required]
        public string accessToken { get; set; }
        [Required]
        public int socialLoginType { get; set; }
        [Required]
        public bool MailSubscription { get; set; }
    }
}
