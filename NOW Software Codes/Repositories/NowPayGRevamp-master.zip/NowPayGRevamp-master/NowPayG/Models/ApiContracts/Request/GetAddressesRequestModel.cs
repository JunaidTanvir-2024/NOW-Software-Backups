﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Request
{
    public class GetAddressesRequestModel
    {
        public string postCode { get; set; }
    }
}
