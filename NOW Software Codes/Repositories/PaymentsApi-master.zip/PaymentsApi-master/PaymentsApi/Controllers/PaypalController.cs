﻿using Serilog;
using Microsoft.AspNetCore.Mvc;
using PaymentsApi.Infrastructure.BLL.Interfaces.Paypal;
using System.Threading.Tasks;
using PaymentsApi.Models.Contracts.Paypal.Request.User;
using System;
using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Paypal.Response.User;
using Newtonsoft.Json;

namespace PaymentsApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PaypalController : ControllerBase
    {
        private readonly ILogger Logger;
        private IBL_Paypal PaypalBL;

        public PaypalController(ILogger logger, IBL_Paypal paypalBL)
        {
            Logger = logger;
            PaypalBL = paypalBL;
        }


        [HttpPost("Payment")]
        public async Task<ActionResult> PaypalPayment(UserPaypalPaymentRequest userRequest)
        {

            GenericApiResponse<UserPaypalPaymentResponse> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await PaypalBL.PaypalPayment(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserPaypalPaymentResponse>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: PaypalController, Method: PaypalPayment, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("Resume")]
        public async Task<ActionResult> PaypalResume(UserPaypalResumeRequest userRequest)
        {

            GenericApiResponse<UserPaypalResumeResponse> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await PaypalBL.PaypalResume(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserPaypalResumeResponse>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: PaypalController, Method: PaypalResume, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("Refund")]
        public async Task<ActionResult> PaypalRefund(UserPaypalRefundRequest userRequest)
        {

            GenericApiResponse<UserPaypalRefundResponse> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await PaypalBL.PaypalRefund(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserPaypalRefundResponse>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: PaypalController, Method: PaypalRefund, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

    }
}