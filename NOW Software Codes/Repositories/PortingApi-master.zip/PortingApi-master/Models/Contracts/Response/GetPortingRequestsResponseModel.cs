﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class GetPortingRequestsResponseModel
    {
        public IEnumerable<PortResponseModel> PortingRequestList { get; set; }
    }
}
