using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Promotions;

public class PromotionTierAction
{
    [JsonPropertyName("discount")]
    public Discount? Discount { get; set; }
}
