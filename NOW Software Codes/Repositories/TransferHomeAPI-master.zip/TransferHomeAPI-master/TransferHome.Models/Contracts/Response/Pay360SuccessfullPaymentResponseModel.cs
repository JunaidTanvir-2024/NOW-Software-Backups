﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class Pay360SuccessfullPaymentResponseModel
    {
        public decimal TopupAmount { get; set; }
        public decimal CurrentBalance { get; set; }
    }
}
