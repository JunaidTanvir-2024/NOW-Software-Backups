using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Subscription;

public abstract class UpdateSubscription
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long Id { get; set; }
        public decimal Price { get; set; }
        public DateTime ExpiryDate { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query> { }
    #endregion

    #region Response
    public sealed record Response
    {

    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var subscription = await _unitOfWork.SubscriptionRepository.GetSubscription(x => x.IsActive && x.Id
            == query.Id);

            if (subscription is null)
            {
                return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
            }

            subscription.Price = query.Price;
            subscription.ExpiryDate = query.ExpiryDate.ToUniversalTime();

            // foreach (var updatedBenefit in query.Benefits)
            // {
            //     var existingBenefit = subscription.Benefits.FirstOrDefault(x => x.Id == updatedBenefit.Id);

            //     if (existingBenefit != null)
            //     {
            //         existingBenefit.AdsFreeExperience = (int)updatedBenefit.AdsFreeExperience;
            //         existingBenefit.Unit = updatedBenefit.Unit;
            //         existingBenefit.UnitType = (int)updatedBenefit.UnitType;
            //         existingBenefit.Type = (int)updatedBenefit.Type;
            //     }
            // }
            _unitOfWork.SaveChanges();

            return ResultWrapper.Failure(AppConstant.StatusKey.Success, AppConstant.StatusCode.Success);
        }
    }
    #endregion
}
