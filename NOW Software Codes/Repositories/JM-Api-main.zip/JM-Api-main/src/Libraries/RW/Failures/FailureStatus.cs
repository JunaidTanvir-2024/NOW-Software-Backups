using RW.Common;

namespace RW.Failures;

/// <summary>
/// Represents a failure result of an operation without errors.
/// </summary>
/// <typeparam name="T">The type of the errors.</typeparam>
/// <remarks>
/// Initializes a new instance of the <see cref="FailureStatus{T}"/> class with the specified error message and error code.
/// </remarks>
/// <param name="errorMessage">The error message.</param>
/// <param name="errorCode">The error code.</param>
public class FailureStatus<T>(string errorMessage, int errorCode) : IResultWrapper<T>
{
    /// <inheritdoc/>
    bool IResultStatus.IsSuccess { get; set; }

    /// <summary>
    /// Gets or sets the error message associated with the failure result.
    /// </summary>
    public string Message { get; set; } = errorMessage;

    /// <summary>
    /// Gets or sets the error code associated with the failure result.
    /// </summary>
    public int Code { get; set; } = errorCode;

    /// <inheritdoc/>
    T? IResultWrapper<T>.Payload { get; set; }

    /// <inheritdoc/>
    T? IResultWrapper<T>.Errors { get; set; }

    /// <inheritdoc/>
    object? IResultWrapper.Payload { get; set; }

    /// <inheritdoc/>
    object? IResultWrapper.Errors { get; set; }
}
