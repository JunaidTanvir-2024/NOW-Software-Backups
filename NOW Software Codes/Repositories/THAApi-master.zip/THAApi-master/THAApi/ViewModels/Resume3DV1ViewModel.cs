﻿namespace THAApi.ViewModels
{
    public class Resume3DV1ViewModel
    {
        public string TransactionId { get; set; }
        public string ReturnUrl { get; set; }
        public string Url { get; set; }
        public string Pareq { get; set; }
    }
}
