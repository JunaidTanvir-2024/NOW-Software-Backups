﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    
    public class FullfilmentResponse
    {
       
        public string ErrorMessage { get; set; }
        public int ErrorCode { get; set; }
        public int? audit_id { get; set; }
        public int new_balance { get; set; }
        public string Pin { get; set; }
        public string productRef { get; set; }
        public string BundleName { get; set; }
        public THRCCAudit Audit { get; set; }
        public string Card { get; set; }
    }

    public class CreditBalance
    {
        public decimal new_balance { get; set; }
        public int audit_id { get; set; }
    }

    public class THCCPin
    {
        public string pin { get; set; }
        public float credit { get; set; }
        public int serial { get; set; }
    }

    public class WTCCPin
    {
        public string pin { get; set; }
        public float credit { get; set; }
        public int serial { get; set; }
    }

    public class THRCCPin
    {
        public string pin { get; set; }
        public string account { get; set; }
    }

    public class THRCCAudit
    {
        public decimal new_balance { get; set; }
        public int audit_id { get; set; }
    }
}
