﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.BLL.Services.Voucherify.Models.MetadataModels;
using Infrastructure.DAL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using MimeKit;
using MimeKit.Encodings;
using Models.Configurations;
using Models.Constants;
using Models.Contracts;
using Models.Contracts.Request;
using Models.Contracts.Request.AndroidInAppPayment;
using Models.Contracts.Request.PreAuth;
using Models.Contracts.Request.User_Account;
using Models.Contracts.Response;
using Models.Contracts.Response.AndroidInAppPayment;
using Models.Contracts.Response.PreAuth;
using Models.Database;
using Models.Enums;
using Newtonsoft.Json;
using PhoneNumbers;
using Serilog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Principal;
using System.Threading.Tasks;
using Twilio.TwiML.Messaging;
using static Models.Configurations.ATTConfig;
using Status = Models.Enums.Status;

namespace Infrastructure.BLL.Implementation
{
    public class UserAccount_BL : IUserAccount_BL
    {
        private readonly ILogger Logger;
        private readonly IUserAccount_DL UserAccount_DL;
        private readonly IHelper_BL HelperService;
        private readonly IAirShipService AirShipService;
        private readonly IATT_DL attDL;
        private readonly IPay360Service _pay360Service;
        private readonly IVoucherify_BL _voucherify_BL;
        private readonly IAutoTopup_DL _autoTopupDL;
        private readonly Pay360Config _pay360Config;
        private readonly VoucherifyConfig _voucherifyConfig;
        private readonly AirShipConfig AirShipConfig;
        private readonly ITwillioService TwillioService_BL;
        private readonly ISapSmsService SapSmsService_BL;
        private readonly IConfiguration Config;
        private readonly IClxSms_BL ClxSms;
        private readonly IApiCall apiCall;
        private readonly IHostingEnvironment HostingEnv;
        private readonly IEmailService EmailServ;
        private readonly IStringLocalizer Localizer;
        private readonly IJwt_BL Jwt_BL;
        private const string TalkHomeSMSFrom = "TALK HOME";
        private readonly JwtConfig JwtConfig;
        private readonly preAuthConfig preAuthConfig;
        private readonly ApiConfig ApiConfig;
        private readonly AccountDeleteSettings _accountDeleteSettings;
        public UserAccount_BL(
            IEmailService emailServ,
            IStringLocalizer localizer,
            IHostingEnvironment hostingEnv,
            IApiCall api,
            IOptions<preAuthConfig> preAuthOptions,
            IClxSms_BL clxSms,
            IConfiguration config,
            IOptions<JwtConfig> jwtConfig,
            IJwt_BL jwt_BL,
            ISapSmsService sapSmsService_BL,
            ITwillioService twillioService_BL,
            IOptions<ApiConfig> apiConfig,
            ILogger logger,
            IUserAccount_DL userAccount_DL,
            IHelper_BL helperService,
            IAirShipService airShipService,
            IOptions<AirShipConfig> airShipConfig,
            IATT_DL aTTDL,
            IPay360Service pay360Service,
            IVoucherify_BL voucherify_BL,
            IOptions<VoucherifyConfig> options,
            IAutoTopup_DL autoTopup_DL,
            IOptions<Pay360Config> pay360Config,
            IOptions<AccountDeleteSettings> accountDeleteSettings)
        {
            Logger = logger;
            UserAccount_DL = userAccount_DL;
            HelperService = helperService;
            AirShipService = airShipService;
            attDL = aTTDL;
            _pay360Service = pay360Service;
            _voucherify_BL = voucherify_BL;
            _autoTopupDL = autoTopup_DL;
            _pay360Config = pay360Config.Value;
            _voucherifyConfig = options.Value;
            AirShipConfig = airShipConfig.Value;
            ApiConfig = apiConfig.Value;
            TwillioService_BL = twillioService_BL;
            SapSmsService_BL = sapSmsService_BL;
            apiCall = api;
            preAuthConfig = preAuthOptions.Value;
            Jwt_BL = jwt_BL;
            JwtConfig = jwtConfig.Value;
            Config = config;
            ClxSms = clxSms;
            HostingEnv = hostingEnv;
            EmailServ = emailServ;
            Localizer = localizer;
            _accountDeleteSettings = accountDeleteSettings.Value;
        }
        public async Task<GenericApiResponse<VerifyEmailReponse>> SendEmailVerificationLink(VerifyEmailRequest model, string msisdn)
        {
            model.email = model.email.ToLower().Trim();

            var dbResponse = await UserAccount_DL.GetUserProfile(msisdn);
            if (dbResponse.ErrorCode == 0)
            {
                if (dbResponse.Data.email.Trim() == model.email.Trim() && dbResponse.Data.emailVerified == true)
                {
                    return GenericApiResponse<VerifyEmailReponse>.Success(
                        new VerifyEmailReponse() { isAlreadyVerified = true }, Localizer["EmailAlreadyVerified"]);
                }
                else
                {
                    var token = Guid.NewGuid();
                    await UserAccount_DL.InsertEmailVerificationToken(msisdn, token.ToString());
                    await EmailServ.SendUserRegistrationEmail(model.email, dbResponse.Data.firstName + " " + dbResponse.Data.lastName, token.ToString());
                    return GenericApiResponse<VerifyEmailReponse>.Success(
                        new VerifyEmailReponse() { isAlreadyVerified = false }, Localizer["VerificationEmailSent"]);
                }
            }
            else //When there is no user data add the user with email
            {
                await UserAccount_DL.UpdateUserProfile(
                           new UpdateUserProfileResponse() { Email = model.email }, msisdn);

                var token = Guid.NewGuid();
                await UserAccount_DL.InsertEmailVerificationToken(msisdn, token.ToString());
                try
                {
                    var builder = new BodyBuilder();
                    using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\email-successful-verification.html").Replace("~\\", ""))))
                    {
                        builder.HtmlBody = SourceReader.ReadToEnd();
                    }

                    string messageBody = builder.HtmlBody
                        .Replace("%FIRST_NAME%", dbResponse.Data.firstName);

                    await EmailServ.SendEmail(model.email, messageBody, true, "Email Verification Successful");
                }
                catch (Exception)
                {
                }
                return GenericApiResponse<VerifyEmailReponse>.Success(new VerifyEmailReponse() { isAlreadyVerified = false }, Localizer["VerificationEmailSent"]);
            }
        }
        public async Task<GenericApiResponse<UserNotifications>> GetUserNotifications(string msisdn)
        {

            try
            {

                var result = await UserAccount_DL.GetUserNotifications(msisdn);
                if (result.Status == Status.Success)
                {

                    return GenericApiResponse<UserNotifications>.Success(result.Data, "Success.");
                }
                else
                {
                    return GenericApiResponse<UserNotifications>.Failure(result.ErrorMessage, (result.ErrorCode == 1 ? ApiStatusCodes.DataNotAvailable : ApiStatusCodes.CodeException));
                }
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: GetUserNotifications, Parameters: msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<UserNotifications>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericApiResponse<UserNotifications>> UpdateUserNotifications(UserNotifications request, string msisdn)
        {

            try
            {

                var result = await UserAccount_DL.UpdateUserNotifications(request, msisdn);
                if (result.Status == Status.Success)
                {

                    return GenericApiResponse<UserNotifications>.Success(request, "Data Updated Successfully.");
                }
                else
                {
                    return GenericApiResponse<UserNotifications>.Failure(result.ErrorMessage, (result.ErrorCode == 1 ? ApiStatusCodes.MsisdnNotExists : ApiStatusCodes.CodeException));
                }
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: UpdateUserProfile, Parameters: {JsonConvert.SerializeObject(request)}, msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<UserNotifications>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericApiResponse<UpdateUserProfileResponse>> UpdateUserProfile(UpdateUserProfileRequest request, string msisdn)
        {
            if (!string.IsNullOrEmpty(request.Email))
                request.Email = request.Email.ToLower().Trim();

            var userProfile = await UserAccount_DL.GetUserProfile(msisdn);

            string imagePath = null;
            if (request.Image != null && request.Image.Length > 0)
            {
                var webRoot = HostingEnv.WebRootPath;
                var extResponse = GetImageExtension(request.Image.ContentType);
                if (extResponse.Status == Status.Failure)
                    return GenericApiResponse<UpdateUserProfileResponse>.Failure(
                                extResponse.ErrorMessage, ApiStatusCodes.InvalidImageFormat);
                string fileExtension = extResponse.Data;
                string fileName = msisdn + "." + fileExtension;
                imagePath = "/userprofile/image/" + fileName + "?v=" + DateTime.Now.Ticks;
                var imagePhysicalPath = Path.Combine(webRoot + "\\userprofile\\image\\", fileName);
                using var stream = new FileStream(imagePhysicalPath, FileMode.Create);
                request.Image.CopyTo(stream);
            }

            var response = new UpdateUserProfileResponse()
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                DobDay = request.DobDay,
                DobMonth = request.DobMonth,
                DobYear = request.DobYear,
                Email = request.Email,
                Image = imagePath
            };
            var result = await UserAccount_DL.UpdateUserProfile(response, msisdn);
            if (result.Status == Status.Success)
            {
                if (userProfile.ErrorCode == 0)
                {
                    if (!userProfile.Data.email.Equals(request.Email, StringComparison.InvariantCultureIgnoreCase))
                    {
                        var token = Guid.NewGuid().ToString();
                        await UserAccount_DL.InsertEmailVerificationToken(msisdn, token);
                        await EmailServ.SendUserRegistrationEmail(request.Email, $"{request.FirstName} {request.LastName}", token);
                        await AirShipService.AddNamedUserTags(
                            new NamedUserTagsRequest()
                            {
                                NamedUser = msisdn,
                                TagGroup = AirShipConfig.ActivityTagGroupName,
                                Tags = new List<string>() { "email_added" }
                            });
                    }
                }
                else
                {
                    var token = Guid.NewGuid().ToString();
                    await UserAccount_DL.InsertEmailVerificationToken(msisdn, token);
                    await EmailServ.SendUserRegistrationEmail(request.Email, $"{request.FirstName} {request.LastName}", token);
                    await AirShipService.AddNamedUserTags(
                        new NamedUserTagsRequest()
                        {
                            NamedUser = msisdn,
                            TagGroup = AirShipConfig.ActivityTagGroupName,
                            Tags = new List<string>() { "email_added" }
                        });
                }
                try
                {
                    int calculatedage = 0;
                    if (request.DobYear != 0 && request.DobMonth != 0 && request.DobDay != 0)
                    {
                        DateTime birthdate = CreateDateFromTime(request.DobYear, request.DobMonth, request.DobDay);
                        calculatedage = CalculateAge(birthdate);
                        await AirShipService.AddNamedUserTags(new NamedUserTagsRequest()
                        {
                            NamedUser = msisdn,
                            TagGroup = AirShipConfig.ActivityTagGroupName,
                            Tags = new List<string>() { "birthday" },
                            Attributes = new AttributeDetailModel()
                            {
                                first_name = request.FirstName,
                                last_name = request.LastName,
                                birthdate = birthdate,
                                age = calculatedage
                            }
                        });
                    }
                }
                catch (Exception ex)
                {
                    string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                    Logger.Error($"Class: UserAccount_BL, Method: UpdateUserProfile, Parameters: msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                }

                return GenericApiResponse<UpdateUserProfileResponse>.Success(response, Localizer["ProfileUpdatedSuccessfully"]);
            }
            else
            {
                return GenericApiResponse<UpdateUserProfileResponse>.Failure(Localizer["TryAgainLater"], (result.ErrorCode == 1 ? ApiStatusCodes.MsisdnNotExists : ApiStatusCodes.CodeException));
            }
        }

        public async Task<GenericApiResponse<UpdateUserProfileResponse>> UpdateUserProfileV2(UpdateUserProfileRequestV2 request, string msisdn)
        {
            if (!string.IsNullOrEmpty(request.Email))
            {
                request.Email = request.Email.ToLower().Trim();
            }

            var userProfile = await UserAccount_DL.GetUserProfileV2(msisdn);

            if (request.Image != null && request.Image.Length > 0)
            {
                var webRoot = HostingEnv.WebRootPath;
                var extResponse = GetImageExtension(request.Image.ContentType);

                if (extResponse.Status == Status.Failure)
                {
                    return GenericApiResponse<UpdateUserProfileResponse>.Failure(
                                extResponse.ErrorMessage, ApiStatusCodes.InvalidImageFormat);
                }

                string fileExtension = extResponse.Data;
                string fileName = msisdn + "." + fileExtension;

                userProfile.Data.imageUrl = "/userprofile/image/" + fileName + "?v=" + DateTime.Now.Ticks;

                var imagePhysicalPath = Path.Combine(webRoot + "\\userprofile\\image\\", fileName);

                using var stream = new FileStream(imagePhysicalPath, FileMode.Create);

                request.Image.CopyTo(stream);
            }

            var response = new UpdateUserProfileResponse()
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                DobDay = request.DobDay,
                DobMonth = request.DobMonth,
                DobYear = request.DobYear,
                Email = request.Email,
                Image = request.IsImageDelete ? null : userProfile.Data.imageUrl
            };

            // I will update IsProfileCompleted only when it is not already been updated, else will not do this everytime. So if this is already updated with true then no need to update again

            var isProfileCompleted = userProfile.Data.IsProfileCompleted == false ? CommonHelpers.IsUserProfileCompleted(response.FirstName, response.LastName, response.Email, userProfile.Data.emailVerified, response.Image, response.DobDay) : true;

            var result = await UserAccount_DL.UpdateUserProfileV2(response, msisdn, isProfileCompleted);

            if (result.Status == Status.Success)
            {
                if (userProfile.ErrorCode == 0)
                {
                    if (!userProfile.Data.email.Equals(request.Email, StringComparison.InvariantCultureIgnoreCase))
                    {
                        var token = Guid.NewGuid().ToString();
                        await UserAccount_DL.InsertEmailVerificationToken(msisdn, token);
                        await EmailServ.SendUserRegistrationEmail(request.Email, $"{request.FirstName} {request.LastName}", token);

                        await AirShipService.AddNamedUserTags(
                            new NamedUserTagsRequest()
                            {
                                NamedUser = msisdn,
                                TagGroup = AirShipConfig.ActivityTagGroupName,
                                Tags = new List<string>() { "email_added" }
                            });
                    }
                }
                else
                {
                    var token = Guid.NewGuid().ToString();
                    await UserAccount_DL.InsertEmailVerificationToken(msisdn, token);
                    await EmailServ.SendUserRegistrationEmail(request.Email, $"{request.FirstName} {request.LastName}", token);
                    await AirShipService.AddNamedUserTags(
                        new NamedUserTagsRequest()
                        {
                            NamedUser = msisdn,
                            TagGroup = AirShipConfig.ActivityTagGroupName,
                            Tags = new List<string>() { "email_added" }
                        });
                }
                try
                {
                    int calculatedage = 0;
                    if (request.DobYear != 0 && request.DobMonth != 0 && request.DobDay != 0)
                    {
                        DateTime birthdate = CreateDateFromTime(request.DobYear, request.DobMonth, request.DobDay);
                        calculatedage = CalculateAge(birthdate);
                        await AirShipService.AddNamedUserTags(new NamedUserTagsRequest()
                        {
                            NamedUser = msisdn,
                            TagGroup = AirShipConfig.ActivityTagGroupName,
                            Tags = new List<string>() { "birthday" },
                            Attributes = new AttributeDetailModel()
                            {
                                first_name = request.FirstName,
                                last_name = request.LastName,
                                birthdate = birthdate,
                                age = calculatedage
                            }
                        });
                    }
                }
                catch (Exception ex)
                {
                    string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                    Logger.Error($"Class: UserAccount_BL, Method: UpdateUserProfile, Parameters: msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                }

                // Check is UserProfile is already Completed or not, if not then we need to verify either it is completed or not after updating profile
                if (!userProfile.Data.IsProfileCompleted)
                {
                    var updatedUserProfile = await UserAccount_DL.GetUserProfileV2(msisdn);

                    if (updatedUserProfile.Data.IsProfileCompleted)
                    {
                        await _voucherify_BL.InvokeEvent(msisdn, VoucherifyEventsNames.ProfileComplete, new VoucherifyEventsMetadata()
                        {
                            Timestamp = DateTime.UtcNow,
                            LoyaltyPoints = _voucherifyConfig.LoyaltyEarningRules.ProfileComplete.Points
                        });
                    }
                }
                return GenericApiResponse<UpdateUserProfileResponse>.Success(response, Localizer["ProfileUpdatedSuccessfully"]);
            }
            else
            {
                return GenericApiResponse<UpdateUserProfileResponse>.Failure(Localizer["TryAgainLater"], (result.ErrorCode == 1 ? ApiStatusCodes.MsisdnNotExists : ApiStatusCodes.CodeException));
            }
        }
        public GenericResult<string> GetImageExtension(string contentType)
        {
            string[] contentTypeArray = new[] { "image/jpg", "image/jpeg", "image/jpe", "image/png", "image/gif", "image/bmp", "image/tiff", "image/tif" };
            if (contentTypeArray.Contains(contentType.ToLower()))
            {
                return new GenericResult<string>() { ErrorCode = 0, ErrorMessage = "Success", Status = Status.Success, Data = contentType.Replace("image/", "") };
            }
            else
            {
                return new GenericResult<string>() { ErrorCode = 1, ErrorMessage = "Invalid image format. Valid image formats are image/jpg, image/jpeg, image/jpe, image/png, image/gif, image/bmp, image/tiff, image/tif", Status = Status.Failure, Data = null };
            }
        }
        public async Task<GenericApiResponse<Profile>> GetUserProfile(string msisdn)
        {

            try
            {
                var result = await UserAccount_DL.GetUserProfileV2(msisdn);

                if (result.Data.IsProfileCompleted == false)
                {
                    bool isProfileCompleted = CommonHelpers.IsUserProfileCompleted(result.Data.firstName, result.Data.lastName, result.Data.email, result.Data.emailVerified, result.Data.imageUrl, result.Data.dobDay);

                    if (isProfileCompleted)
                    {
                        var response = new UpdateUserProfileResponse()
                        {
                            FirstName = result.Data.firstName,
                            LastName = result.Data.lastName,
                            DobDay = result.Data.dobDay,
                            DobMonth = result.Data.dobMonth,
                            DobYear = result.Data.dobYear,
                            Email = result.Data.email,
                            Image = result.Data.imageUrl
                        };

                        var updateResult = await UserAccount_DL.UpdateUserProfileV2(response, msisdn, isProfileCompleted);

                        await _voucherify_BL.InvokeEvent(msisdn, VoucherifyEventsNames.ProfileComplete, new VoucherifyEventsMetadata()
                        {
                            Timestamp = DateTime.UtcNow,
                            LoyaltyPoints = _voucherifyConfig.LoyaltyEarningRules.ProfileComplete.Points
                        });
                    }
                }



                if (result.Status == Status.Success)
                {

                    return GenericApiResponse<Profile>.Success(result.Data, "Success.");
                }
                else
                {
                    return GenericApiResponse<Profile>.Failure(Localizer["TryAgainLater"], (result.ErrorCode == 1 ? ApiStatusCodes.DataNotAvailable : ApiStatusCodes.CodeException));
                }
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: GetUserProfile, Parameters: msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<Profile>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericApiResponse<SmsResult>> SendPinReminder(string msisdn, AppInfo appInfo)
        {
            var tags = new string[] { $"msisdn:{msisdn}" };

            var response = new GenericApiResponse<SmsResult>();

            var userAccount = await UserAccount_DL.GetUserAccount(msisdn);

            if (!string.IsNullOrEmpty(userAccount?.Pin))
            {
                var outgoingMessage = Localizer["PinReminderMessage", userAccount.Pin];

                response.Status = "Success";
                response.Message = "Success";

                var smsResult = await ClxSms.Send(TalkHomeSMSFrom, msisdn, outgoingMessage, false, true);
                if (smsResult.Success)
                {
                }
                else
                {
                    var errorTag = new string[] { $"{smsResult.ErrorCode.ToString()} {smsResult.ErrorMessage}" };
                    var unifiedTags = tags.Union(errorTag).ToArray();
                }

                response.Payload = smsResult;

                return response;
            }

            response.Status = "Failure";
            response.Message = Localizer["AccountDoesNotExist"];
            return response;
        }
        public async Task<FeedbackResponse> FeedbackIsActive(string msisdn)
        {
            return new FeedbackResponse
            {
                Message = Localizer["HowWasYourAudioQuality"],
                Active = await UserAccount_DL.IsEnabledForUser(msisdn),
                MinimumDuration = 5,
                AutoDismiss = 10,
                Buttons = new[]
                {
                    new FeedbackButton
                    {
                        Title = Localizer["Good"],
                        Quality = "good"
                    },
                    new FeedbackButton
                    {
                        Title = Localizer["Bad"],
                        Quality = "bad"
                    }
                }
            };
        }
        public async Task<GenericApiResponse<RSS>> GetPromotions(string msisdn)
        {
            GenericApiResponse<RSS> gr = new GenericApiResponse<RSS>();

            try
            {
                var cls = new HttpClient()
                {
                    BaseAddress = new Uri(Config["ATTApi:local_promotions_uri"])
                };
                cls.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
                cls.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");

                var result = await cls.GetAsync("api/TransferToPromotions");

                if (result.IsSuccessStatusCode)
                {

                    var rss = JsonConvert.DeserializeObject<RSS>(await result.Content.ReadAsStringAsync());
                    var rssResults = await UserAccount_DL.GetPromotionAlerts(msisdn);
                    var transferToCountries = await attDL.GetTranferToCountries();

                    var rssCountry = rss.country;
                    var rssAlerts = rssResults.Payload;


                    var leftOuterQuery = from country in rssCountry
                                         join countryAlerts in rssAlerts on country.countryId equals countryAlerts.countryId into countryGroup
                                         select countryGroup.DefaultIfEmpty(new Country() { countryId = country.countryId, countryName = country.countryName, status = country.status });


                    var x = leftOuterQuery.ToList();

                    rss.country = x.SelectMany(d => d).ToList();
                    rss.country.ForEach(x =>
                    {
                        x.countryCode = transferToCountries.Where(y => y.TransfertoCountryID == x.countryId).FirstOrDefault()?.ISOCode2 ?? "";
                    });

                    rss.defaultCountry = new Country { countryId = "661", countryName = "Afghanistan", countryCode = "AF" };
                    //var itm = (from it in rss.channel.item orderby it.countryName ascending select it).ToList();                    
                    rss.channel.item = rss.channel.item.OrderBy(itt => itt.countryName).ToList();
                    try
                    {
                        if (Config["ATTApi:only_dtOne_promotions"] == "0")
                        {

                            var clientNew = new HttpClient()
                            {
                                BaseAddress = new Uri(Config["ATTApi:ApiEndpoint"])
                            };
                            cls.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
                            cls.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");

                            var dingResult = await clientNew.GetAsync($"Ding/DingGetPromotions?fromMSISDN={msisdn}");

                            if (dingResult.IsSuccessStatusCode)
                            {
                                var dingPromotions = JsonConvert.DeserializeObject<DingPromoResponse>(await dingResult.Content.ReadAsStringAsync());

                                if (dingPromotions.payload != null)
                                {
                                    var dingCountries = dingPromotions.payload.dingCountries;
                                    rss.channel.item.RemoveAll(r => dingCountries.Contains(r.countryName));

                                    //Create Country if not exists in countries list
                                    var existingCountries = rss.country.Select(s => s.countryName).ToList();
                                    var dingCountriesWithPromoNotInList = dingPromotions.payload.item.Where(s => !existingCountries.Contains(s.countryName)).Select(s => s.countryName).Distinct().ToList();

                                    var maxCountryId = Int32.Parse(rss.country.Max(s => s.countryId));

                                    foreach (var dingCountry in dingCountriesWithPromoNotInList)
                                    {
                                        maxCountryId++;
                                        rss.country.Add(new Country { countryId = maxCountryId.ToString(CultureInfo.InvariantCulture), countryName = dingCountry });
                                    }

                                    rss.country = rss.country.OrderBy(s => s.countryName).ToList();

                                    dingPromotions.payload.item.ForEach(xx => xx.countryId = (rss.country.FirstOrDefault(s => s.countryName == xx.countryName)?.countryId));
                                    rss.channel.item.AddRange(dingPromotions.payload.item);

                                }
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Warning(ex, "Failed to GetDingPromotions from ATT api", msisdn);
                    }
                    gr.Status = "Success";
                    gr.Message = "Success";


                    gr.Payload = rss;
                }


                return gr;
            }
            catch (Exception ex)
            {
                gr.Status = "Failure";
                gr.Message = "Failure";

                Logger.Warning(ex, "Failed to GetPromotions from api", msisdn);
            }

            return gr;

        }
        public async Task<UserAccountInformation> GetUserAccountInfoCatche(string sipUserName)
        {
            try
            {

                var UserAccountInformation = await UserAccount_DL.GetUserAccountInfo(sipUserName);

                return UserAccountInformation;

            }
            catch (Exception ex)
            {
                Logger.Error(ex.ToString());
                return null;
            }
        }
        public async Task<bool> AuthenticateAsync(string msisdn, string pin)
        {

            var isUserBlocked = await UserAccount_DL.IsUserBlockedAsync(msisdn);

            if (isUserBlocked)
            {
                return false;
            }

            var dbPin = await UserAccount_DL.GetPinAsync(msisdn);

            //var dbPin = GetPinViaSQL(msisdn);

            return dbPin != null && pin.Equals(dbPin.Trim(), StringComparison.InvariantCulture);
        }
        public async Task<GenericApiResponse<UserAccount>> Login(string msisdn, AppInfo info, string remoteIp, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null)
        {
            try
            {
                var response = new GenericApiResponse<UserAccount>();

                string persistenID = "";

                if (info != null && info.DevicePersistentID != null)
                {
                    persistenID = info.DevicePersistentID;
                }
                //var userAccount = await GetUserAccount(msisdn, persistenID);

                var validationResp = await UserAccount_DL.ValidateDeviceAndIpAddressAsync(persistenID, remoteIp);
                if (validationResp.ValidationType != 1)
                {
                    response.Message = Localizer["ServiceNotAvailable"];
                    response.ErrorCode = (int)ApiStatusCodes.UnSuccessful;
                    return response;
                }

                UserAccount userAccount = await UserAccount_DL.GetUserAccount(msisdn, info, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);
                if (userAccount == null)
                {
                    var accountCurrency = HelperService.GetAccountCurrency(msisdn);
                    var account = await UserAccount_DL.GetUnallocatedAccount(msisdn, accountCurrency);

                    await UserAccount_DL.UnallocatedAccountObtained(msisdn);

                    var userAccountNew = await UserAccount_DL.GetUserAccountResult(msisdn, account);

                    //userAccount.stunServers = await UserAccount_DL.GetStunServers();

                    userAccountNew.Msisdn = msisdn;

                    await UserAccount_DL.UpdateSignUpAccount2(userAccountNew);

                    await UserAccount_DL.SubscriberUpdatesApplied(msisdn);

                    await UserAccount_DL.GetUnallocatedIMUserAccount(msisdn, account);

                    await UserAccount_DL.HandleAppInfo(userAccountNew, info, remoteIp, accountCurrency);

                    await UserAccount_DL.AppInfoHandled(msisdn);

                    await UserAccount_DL.ConfigureRateSheet(msisdn, account);

                    await UserAccount_DL.RatesSheetConfigured(msisdn);

                    await ProcessSignUpPromotion(account, msisdn, userAccountNew.SubscriberId);

                    userAccount = await UserAccount_DL.GetUserAccount(msisdn, info, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);

                    //TODO:Fire signup event for voucherify
                    var isRegisterdVoucherify = await _voucherify_BL.CreateVoucherifyNewUser(msisdn);

                    if (isRegisterdVoucherify)
                    {
                        var signupPoints = _voucherifyConfig.LoyaltyEarningRules.Signup.Points;
                        userAccount.SignupPoints = signupPoints;
                        await _voucherify_BL.InvokeEvent(msisdn, VoucherifyEventsNames.Signup, new VoucherifyEventsMetadata() { Timestamp = DateTime.UtcNow, LoyaltyPoints = signupPoints });
                    }
                }

                var generalLA = await UserAccount_DL.Get2(msisdn, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);
                userAccount.localaccess = generalLA.Payload;
                //await UserAccount_DL.HandleAppInfo(userAccount, info);
                if (userAccount != null)
                {
                    //Check if destination user have loged deleted request and still in pending
                    var destinationMsisdnDeleteRequest = await UserAccount_DL.GetDeleteAccountLogRequest(msisdn);
                    if (destinationMsisdnDeleteRequest != null && destinationMsisdnDeleteRequest.AccountDeleteStatus != AccountDeleteStatus.Deleted && destinationMsisdnDeleteRequest.AccountDeleteStatus != AccountDeleteStatus.Cancelled && destinationMsisdnDeleteRequest.AccountDeleteRequestDate != null)
                    {
                        response.Message = Localizer["AccountDeleteInProgressErrorMessage"];
                        response.ErrorCode = (int)ApiStatusCodes.BothAccountsMustBeTalkHomeUsers;
                        response.Status = "Failure";
                        return response;
                    }
                    //await userJourneyService.Login(msisdn);

                    if (JwtConfig.IsJwtOn == true)
                    {
                        JwtToken token = Jwt_BL.GenerateToken(userAccount, persistenID, remoteIp);
                        userAccount.jwt = token;
                    }
                    response.Status = "Success";
                    response.Message = "Success";
                    response.Payload = userAccount;
                }
                else
                {
                    response.Status = "Failure";
                    response.Message = Localizer["AccountDoesNotExist"];
                }

                return response;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: Login, Parameters=> requestJson: MSISDN {msisdn} AppInfo{JsonConvert.SerializeObject(info)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }

        public async Task<GenericApiResponse<MsisdnInfomation>> Create(UserInf signup, string remoteIp)
        {
            string msisdn = signup.Msisdn;
            AppInfo appInfo = new AppInfo
            {
                DevicePersistentID = signup.deviceInf.DevicePersistentID,
                cpuArchitecture = signup.deviceInf.cpuArchitecture,
                ActionExecuted = signup.deviceInf.ActionExecuted,
                DeviceOS = signup.deviceInf.DeviceOS,
                DeviceOSVersion = signup.deviceInf.DeviceOSVersion,
                DeviceMake = signup.deviceInf.DeviceMake,
                DeviceModel = signup.deviceInf.DeviceModel,
                DeviceLanguage = signup.deviceInf.DeviceLanguage,
                AppVersion = signup.appInf.AppVersion,
                AppLanguage = signup.appInf.AppLanguage

            };

            //request.Msisdn, appInfo, isTrusted, remoteIp, request.appInf.ProductCode, request.appInf.ProductItemCode, request.AuthTx, false

            bool isTrusted = signup.deviceInf.isTrusted;
            bool isLegacySignup = false;
            string productCode = signup.appInf.ProductCode;
            string productItemCode = signup.appInf.ProductItemCode;
            string AuthTx = signup.AuthTx;

            if (!isLegacySignup && preAuthConfig.PreAuthEnabled)
            {
                var preAuthRequest = new PreAuthRequest()
                {
                    AuthTx = AuthTx,
                    productCode = productCode,
                    productItemCode = productItemCode
                };

                string jsonRequest = JsonConvert.SerializeObject(preAuthRequest);

                var httpResponse = await apiCall.PostAsync(
                        preAuthConfig.ApiUrl + "/Auth/VerifyPreAuth", jsonRequest);

                if (httpResponse.IsSuccessStatusCode)
                {
                    string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                    var apiResponseModel = JsonConvert.DeserializeObject<PreAuthResponse>(responseJson);
                    if (apiResponseModel.errorCode != 0) // failure
                        return GenericApiResponse<MsisdnInfomation>.Failure(Localizer["ServiceNotAvailable"], ApiStatusCodes.UnSuccessful);
                }
                else
                {
                    string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                    Logger.Error($"Method:VerifyPreAuth, StatusCode:{httpResponse.StatusCode}, ResponseMessage:{responseJson}, Msisdn:{msisdn}, Token:{AuthTx} AppInfo:{JsonConvert.SerializeObject(appInfo)}");
                    return GenericApiResponse<MsisdnInfomation>.Failure(Localizer["ServiceNotAvailable"], ApiStatusCodes.UnSuccessful);
                }
            }

            int userType = 1; //SignUp
            var userData = await GetUserAccountWithoutCaching(msisdn);
            if (userData != null)
            {
                userType = 2; //login
            }

            var fraudSignup = await UserAccount_DL.ValidateAsyncUser(msisdn, remoteIp, userType);
            if (fraudSignup != null)
            {
                return GenericApiResponse<MsisdnInfomation>.Failure(Localizer["ServiceNotAvailable"], ApiStatusCodes.UnSuccessful);
            }

            var validationResp = await UserAccount_DL.ValidateDeviceAndIpAddressAsync(appInfo.DevicePersistentID, remoteIp);
            if (validationResp.ValidationType != 1)
                return GenericApiResponse<MsisdnInfomation>.Failure(Localizer["ServiceNotAvailable"], ApiStatusCodes.UnSuccessful);


            var accountCurrency = HelperService.GetAccountCurrency(msisdn);
            var existingAccount = await GetUserAccountWithoutCaching(msisdn);
            var existingUserDeletedAccountRequest = await UserAccount_DL.GetDeleteAccountLogRequest(msisdn);
            if (existingAccount != null)
            {
                //Login case
                var _userAccount = await UserAccount_DL.GetUserAccountResult(msisdn, existingAccount.AccountID);

                //check if user try to login allowed after delete request submitted and account is in progress state
                if (existingUserDeletedAccountRequest != null && existingUserDeletedAccountRequest.AccountDeleteStatus != AccountDeleteStatus.Deleted && existingUserDeletedAccountRequest.AccountDeleteStatus != AccountDeleteStatus.Cancelled && existingUserDeletedAccountRequest.AccountDeleteRequestDate != null)
                {
                    return GenericApiResponse<MsisdnInfomation>.Failure(Localizer["AccountDeleteInProgressErrorMessage"], ApiStatusCodes.UnSuccessful);
                }

                _userAccount.Msisdn = msisdn;

                await UserAccount_DL.UpdateSignUpAccount(_userAccount);

                Logger.Information("Existing user signing up with {Msisdn}", msisdn);

                //Account already exists
                var existingAccountMessage = Localizer["SignUpMessage", existingAccount.Pin];

                await SendSignupSmsToUntrustedUser(isTrusted, msisdn, existingAccountMessage, existingAccount.UserAccountDetails.Na_Service_Id, remoteIp, true);

                var msisdnInfo = new MsisdnInfomation { isexistingUser = true, Msisdn = msisdn };
                //Pre Auth set to true if enabled and verified
                if (preAuthConfig.PreAuthEnabled)
                {
                    msisdnInfo.isPreAuthVerified = true;
                }
                return GenericApiResponse<MsisdnInfomation>.Success(msisdnInfo, Localizer["AccountAlreadyExistsButThatsOk"]);
            }
            //Don't allow user to delete account more than 3 times because it may shorten our AccountIDs
            var deletedAccountLimit = int.Parse(Config["DeletedAccountLimit"]);
            if (await UserAccount_DL.CountDeletedAccountAsync(msisdn) >= deletedAccountLimit && existingUserDeletedAccountRequest != null && existingUserDeletedAccountRequest.AccountDeleteRequestDate == null)// added date check to validate if the request of delete is request by the old bulid 
            {
                return GenericApiResponse<MsisdnInfomation>.Failure("Account cannot be created!, please contact with customer support.", ApiStatusCodes.UnSuccessful);
            }
            //check if user try to login allowed sign in during the deleted request date
            if (existingUserDeletedAccountRequest != null &&
                existingUserDeletedAccountRequest.AccountDeleteStatus == AccountDeleteStatus.Deleted &&
                DateTime.UtcNow < existingUserDeletedAccountRequest?.AllowedSignUpDate)
            {
                return GenericApiResponse<MsisdnInfomation>.Failure(Localizer["AccountRecentlyDeletedErrorMessage"], ApiStatusCodes.UnSuccessful);
            }

            Logger.Information("New user signing up with {Msisdn}", msisdn);

            //This call is changed to new intermediate sign up process 
            var pin = await UserAccount_DL.GetTemporaryAccount(signup, accountCurrency, remoteIp);

            //await UserAccount_DL.UnallocatedAccountObtained(msisdn);

            // var userAccount = await UserAccount_DL.GetUserAccountResult(msisdn, account);

            //userAccount.Msisdn = msisdn;

            //await UserAccount_DL.UpdateSignUpAccount(userAccount);

            //await UserAccount_DL.SubscriberUpdatesApplied(msisdn);

            //await UserAccount_DL.GetUnallocatedIMUserAccount(msisdn, account);

            //await UserAccount_DL.HandleAppInfo(userAccount, appInfo);

            //await UserAccount_DL.AppInfoHandled(msisdn);

            //await UserAccount_DL.ConfigureRateSheet(msisdn, account);

            //await UserAccount_DL.RatesSheetConfigured(msisdn);

            //await ProcessSignUpPromotion(account, msisdn, userAccount.SubscriberId);

            //var signedUpUserAccount = await UserAccount_DL.GetUserAccount(msisdn);

            //Logger.Information("User {Msisdn} signed up with account id {AccountId} ", msisdn, userAccount.AccountID);

            var outgoingMessage = Localizer["SignUpMessage", pin];
            int? Id = await UserAccount_DL.DetermineRateSheet(msisdn);

            int ratesheetId = Id == null ? 0 : (int)Id;

            await SendSignupSmsToUntrustedUser(isTrusted, msisdn, outgoingMessage, ratesheetId, remoteIp);
            
            var newUserInfo = new MsisdnInfomation { isexistingUser = false, Msisdn = msisdn };

            var response = GenericApiResponse<MsisdnInfomation>.Success(newUserInfo, "Success");
            //Pre Auth set to true if enabled and verified
            if (preAuthConfig.PreAuthEnabled)
            {
                response.Payload.isPreAuthVerified = true;
            }
            return response;
        }
        public async Task<GenericApiResponse<MsisdnInfomation>> Create(string msisdn, AppInfo appInfo, bool isTrusted, string remoteIp, string productCode, string productItemCode, string AuthTx = null, bool isLegacySignup = true)
        {
            if (!isLegacySignup && preAuthConfig.PreAuthEnabled)
            {
                var preAuthRequest = new PreAuthRequest()
                {
                    AuthTx = AuthTx,
                    productCode = productCode,
                    productItemCode = productItemCode
                };

                string jsonRequest = JsonConvert.SerializeObject(preAuthRequest);

                var httpResponse = await apiCall.PostAsync(
                        preAuthConfig.ApiUrl + "/Auth/VerifyPreAuth", jsonRequest);

                if (httpResponse.IsSuccessStatusCode)
                {
                    string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                    var apiResponseModel = JsonConvert.DeserializeObject<PreAuthResponse>(responseJson);
                    if (apiResponseModel.errorCode != 0) // failure
                        return GenericApiResponse<MsisdnInfomation>.Failure(Localizer["ServiceNotAvailable"], ApiStatusCodes.UnSuccessful);
                }
                else
                {
                    string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                    Logger.Error($"Method:VerifyPreAuth, StatusCode:{httpResponse.StatusCode}, ResponseMessage:{responseJson}, Msisdn:{msisdn}, Token:{AuthTx} AppInfo:{JsonConvert.SerializeObject(appInfo)}");
                    return GenericApiResponse<MsisdnInfomation>.Failure(Localizer["ServiceNotAvailable"], ApiStatusCodes.UnSuccessful);
                }
            }


            int userType = 1; //SignUp
            var userData = await GetUserAccountWithoutCaching(msisdn);
            if (userData != null)
            {
                userType = 2; //login
            }

            var fraudSignup = await UserAccount_DL.ValidateAsyncUser(msisdn, remoteIp, userType);
            if (fraudSignup != null)
            {
                return GenericApiResponse<MsisdnInfomation>.Failure(Localizer["ServiceNotAvailable"], ApiStatusCodes.UnSuccessful);
            }

            var validationResp = await UserAccount_DL.ValidateDeviceAndIpAddressAsync(appInfo.DevicePersistentID, remoteIp);
            if (validationResp.ValidationType != 1)
                return GenericApiResponse<MsisdnInfomation>.Failure(Localizer["ServiceNotAvailable"], ApiStatusCodes.UnSuccessful);

            //await userJourneyService.BeginSignup(msisdn, isTrusted);

            var accountCurrency = HelperService.GetAccountCurrency(msisdn);
            var existingAccount = await GetUserAccountWithoutCaching(msisdn);
            if (existingAccount != null)
            {
                var _userAccount = await UserAccount_DL.GetUserAccountResult(msisdn, existingAccount.AccountID);
                _userAccount.Msisdn = msisdn;
                await UserAccount_DL.UpdateSignUpAccount(_userAccount);
                Logger.Information("Existing user signing up with {Msisdn}", msisdn);
                //Account already exists
                var existingAccountMessage = Localizer["SignUpMessage", existingAccount.Pin];

                await SendSignupSmsToUntrustedUser(isTrusted, msisdn, existingAccountMessage, existingAccount.UserAccountDetails.Na_Service_Id, remoteIp, true);

                var msisdnInfo = new MsisdnInfomation { isexistingUser = true, Msisdn = msisdn };
                //Pre Auth set to true if enabled and verified
                if (preAuthConfig.PreAuthEnabled)
                {
                    msisdnInfo.isPreAuthVerified = true;
                }
                return GenericApiResponse<MsisdnInfomation>.Success(msisdnInfo, Localizer["AccountAlreadyExistsButThatsOk"]);
            }
            //Don't allow user to delete account more than 3 times because it may shorten our AccountIDs
            var deletedAccountLimit = int.Parse(Config["DeletedAccountLimit"]);
            if (await UserAccount_DL.CountDeletedAccountAsync(msisdn) >= deletedAccountLimit)
            {
                return GenericApiResponse<MsisdnInfomation>.Failure("Account cannot be created!, please contact with customer support.", ApiStatusCodes.UnSuccessful);
            }
            Logger.Information("New user signing up with {Msisdn}", msisdn);

            var account = await UserAccount_DL.GetUnallocatedAccount(msisdn, accountCurrency);

            await UserAccount_DL.UnallocatedAccountObtained(msisdn);

            var userAccount = await UserAccount_DL.GetUserAccountResult(msisdn, account);

            //userAccount.stunServers = await UserAccount_DL.GetStunServers();

            userAccount.Msisdn = msisdn;

            await UserAccount_DL.UpdateSignUpAccount(userAccount);

            await UserAccount_DL.SubscriberUpdatesApplied(msisdn);

            await UserAccount_DL.GetUnallocatedIMUserAccount(msisdn, account);

            await UserAccount_DL.HandleAppInfo(userAccount, appInfo);

            await UserAccount_DL.AppInfoHandled(msisdn);

            await UserAccount_DL.ConfigureRateSheet(msisdn, account);

            await UserAccount_DL.RatesSheetConfigured(msisdn);

            await ProcessSignUpPromotion(account, msisdn, userAccount.SubscriberId);

            var signedUpUserAccount = await UserAccount_DL.GetUserAccount(msisdn);

            Logger.Information("User {Msisdn} signed up with account id {AccountId} ", msisdn, userAccount.AccountID);

            //await userJourneyService.CompleteSignup(msisdn);

            var outgoingMessage = Localizer["SignUpMessage", userAccount.Pin];

            await SendSignupSmsToUntrustedUser(isTrusted, msisdn, outgoingMessage, signedUpUserAccount.UserAccountDetails.Na_Service_Id, remoteIp);

            var newUserInfo = new MsisdnInfomation { isexistingUser = false, Msisdn = msisdn };

            var response = GenericApiResponse<MsisdnInfomation>.Success(newUserInfo, "Success");
            //Pre Auth set to true if enabled and verified
            if (preAuthConfig.PreAuthEnabled)
            {
                response.Payload.isPreAuthVerified = true;
            }
            return response;
        }
        public async Task ProcessSignUpPromotion(string account, string msisdn, int SubscriberId)
        {
            if (await UserAccount_DL.AccountHasPromo(account, msisdn))
            {

                //var isSignupPro = await AccountHasSignupPromo(account, msisdn);

                SignupPromo sp = await UserAccount_DL.GetSignupPromo(msisdn);


                if (sp.is_unit_Promo)
                {
                    await UserAccount_DL.AddSignUpPromo(account, msisdn);
                }

                //Add Bundle at Signup unit promotion  , display rates standard way
                if (sp.is_bundle_Promo)
                {
                    var PoundbundleId = await UserAccount_DL.GetBundlePoundPromoGuid(msisdn);
                    if (PoundbundleId != "")
                    {

                        await UserAccount_DL.AddBundlePromo(PoundbundleId, SubscriberId);
                    }
                }

                //Add bundle rate promotion , display special rates
                var bundleId = await UserAccount_DL.GetBundleRatePromoGuid(msisdn);
                if (bundleId != "")
                {

                    await UserAccount_DL.AddBundlePromo(bundleId, SubscriberId);
                }

                int prefix = 0;

                //Add # bundle if configured
                if ((prefix = UserAccount_DL.CheckBundlePromo(msisdn)) > 0)
                {
                    var bundlePromoId = await UserAccount_DL.GetBundlePromoGuid(prefix);

                    await UserAccount_DL.AddBundlePromo(bundlePromoId, SubscriberId);
                }


            }
        }
        private async Task<bool> SendSignupSmsToUntrustedUser(bool isTrusted, string msisdn, string outgoingMessage, int na_service_id, string remoteIp, bool existingAccount = false, string language = "en")
        {
            try
            {
                int smsCount = await UserAccount_DL.GetSMSCount(msisdn, remoteIp);
                bool isFraud = false;

                if (string.IsNullOrEmpty(language))
                    language = "en";

                if (smsCount > 2)
                {
                    isFraud = true;
                }



                if (!isTrusted && !isFraud)
                {
                    string dogStatName = string.Empty;
                    if (existingAccount)
                    {
                        dogStatName = "UserAccount.Signup.Existing.SendSms";
                    }
                    else
                    {
                        dogStatName = "UserAccount.Signup.New.SendSms";
                    }

                    var tags = new string[] { $"sender:{TalkHomeSMSFrom}", $"receiver:{msisdn}" };

                    int smsOperatorId = await UserAccount_DL.GetSMSOperator(na_service_id, msisdn);

                    if (smsOperatorId == 1)
                    {

                        await TwillioService_BL.Send(msisdn, outgoingMessage, true);
                        //string validityPeriod = ConfigurationManager.AppSettings["sms:local:validity"].ToString(CultureInfo.InvariantCulture);
                        //string op = ConfigurationManager.AppSettings["sms:local:operator"].ToString(CultureInfo.InvariantCulture);

                        //await LocalSMSService.Send(TalkHomeSMSFrom, msisdn, outgoingMessage, validityPeriod, op);

                    }
                    else if (smsOperatorId == 2)
                    {
                        var smsResult = await SapSmsService_BL.Send(TalkHomeSMSFrom, msisdn, outgoingMessage, false, true, language);
                        if (smsResult.Success)
                        {
                        }
                        else
                        {
                            var errorTag = new string[] { $"{smsResult.ErrorCode.ToString()} {smsResult.ErrorMessage}" };
                            var unifiedTags = tags.Union(errorTag).ToArray();
                        }
                    }
                    else
                    {

                        await TwillioService_BL.Send(msisdn, outgoingMessage, true);

                        //var smsResult = await smsService.Send(TalkHomeSMSFrom, msisdn, outgoingMessage, false, true);
                        //if (smsResult.Success)
                        //{
                        //    DogStatsd.Increment(dogStatName, sampleRate: 0.4, tags: tags);
                        //}
                        //else
                        //{
                        //    var errorTag = new string[] { $"{smsResult.ErrorCode.ToString(CultureInfo.InvariantCulture)} {smsResult.ErrorMessage}" };
                        //    var unifiedTags = tags.Union(errorTag).ToArray();
                        //    DogStatsd.Increment(dogStatName, sampleRate: 0.4, tags: unifiedTags);
                        //}
                    }

                }
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Class:{nameof(UserAccount_BL)}, Method:{nameof(SendSignupSmsToUntrustedUser)}, Message={ex.Message}, StackTrace:{ex.StackTrace}");
                return false;
            }
        }
        public async Task<GenericApiResponse<UserAccount>> Login(string msisdn, AppInfo info)
        {
            try
            {

                var response = new GenericApiResponse<UserAccount>();

                string persistenID = "";

                if (info != null && info.DevicePersistentID != null)
                {
                    persistenID = info.DevicePersistentID;
                }
                //var userAccount = await GetUserAccount(msisdn, persistenID);

                var userAccount = await UserAccount_DL.GetUserAccount(msisdn, info);

                await UserAccount_DL.HandleAppInfo(userAccount, info);

                if (userAccount != null)
                {

                    //await userJourneyService.Login(msisdn);

                    response.Status = "Success";
                    response.Message = "Success";
                    response.Payload = userAccount;
                }
                else
                {
                    response.Status = "Failure";
                    response.Message = Localizer["AccountDoesNotExist"];
                }

                return response;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: Login, Parameters=> msisdn: {msisdn},AppInfo: {JsonConvert.SerializeObject(info)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public async Task<GenericApiResponse<CallQualityResponse>> SaveCallQuality(CallQualityRequest request, string msisdn)
        {
            try
            {
                var response = new GenericApiResponse<CallQualityResponse>();
                var result = await UserAccount_DL.SaveCallQuality(request, msisdn);
                if (result == true)
                {

                    //await userJourneyService.Login(msisdn);

                    response.Status = "Success";
                    response.Message = "Success";
                    response.Payload = new CallQualityResponse { isAdded = true };
                }
                else
                {
                    response.Status = "Failure";
                    response.Message = "Failure";
                    response.Payload = new CallQualityResponse { isAdded = false };
                    response.ErrorCode = (int)ApiStatusCodes.NotFound;
                }


                return response;
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                //Logger.Error($"Class: UserAccount_BL, Method: SaveCallQuality, Parameters:msisdn {msisdn} {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public async Task<GenericApiResponse<ClientCallResponse>> SaveClientCallLogs(SaveClientCallRequest request, string msisdn)
        {
            try
            {
                var response = new GenericApiResponse<ClientCallResponse>();

                //commented and returned dummy response to temp fix 

                if (ApiConfig.ClientCallLogs)
                {
                    var result = await UserAccount_DL.SaveClientCallLogs(request, msisdn);
                    if (result.isAdded == true)
                    {

                        //await userJourneyService.Login(msisdn);

                        response.Status = "Success";
                        response.Message = "Success";
                        response.Payload = new ClientCallResponse { isAdded = true };
                    }
                    else
                    {
                        response.Status = "Failure";
                        response.Message = result.ErrorMessage;
                        response.Payload = new ClientCallResponse { isAdded = false };
                        response.ErrorCode = result.ErrorCode;
                    }
                }
                else
                {
                    response.Status = "Failure";
                    response.Message = "Logs deact";
                    response.Payload = new ClientCallResponse { isAdded = false };
                }
                //response.Status = "Success";
                //response.Message = "Success Not inserted in db due to performace issue. Dummy Success";
                //response.Payload = new ClientCallResponse { isAdded = true };

                return response;
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                //Logger.Error($"Class: UserAccount_BL, Method: SaveClientCallLogs, Parameters:msisdn {msisdn} {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public async Task<GenericApiResponse<AndroidInAppPaymentResponse>> getAndriodPaymentOptions(string currency)
        {
            try
            {
                var response = new GenericApiResponse<AndroidInAppPaymentResponse>();
                var result = await UserAccount_DL.getAndriodPaymentOptions(currency);
                if (result != null)
                {
                    response.Status = "Success";
                    response.Message = "Success";

                    response.Payload = new AndroidInAppPaymentResponse() { inAppPurchase = result };
                }
                else
                {
                    response.Status = "Failure";
                    response.Message = "Failure";
                    response.Payload = null;
                    response.ErrorCode = (int)ApiStatusCodes.NotFound;
                }


                return response;
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: getAndriodPaymentOptions, Parameters: currency {currency}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public async Task<GenericApiResponse<AndroidPaymentVerificationResponse>> AndrionPaymentVerification(AndroidPaymentVerificationRequest request, string msisdn)
        {
            try
            {
                var response = new GenericApiResponse<AndroidPaymentVerificationResponse>();

                var option = await UserAccount_DL.getAndriodPaymentOption(request.productId);

                if (option.HasValue)
                {

                    string ccAuthCode = null;
                    var CssTransId = request.orderId;
                    var amount = option.Value * 100;
                    var prodRef = msisdn;
                    string bundleRef = null;

                    var result = await UserAccount_DL.ThaGooglePayCustomerFullfilment(prodRef, amount.ToString(CultureInfo.InvariantCulture), CssTransId, ccAuthCode, bundleRef);
                    if (result != null)
                    {
                        response.Status = "Success";
                        response.Message = "Success";

                        //response.Payload = new AndroidInAppPaymentResponse() { inAppPurchase = result };
                    }
                    else
                    {
                        response.Status = "Failure";
                        response.Message = "Failure";
                        response.Payload = null;
                        response.ErrorCode = (int)ApiStatusCodes.NotFound;
                    }
                }
                else
                {
                    response.Status = "Failure";
                    response.Message = "Failure";
                    response.Payload = null;
                    response.ErrorCode = (int)ApiStatusCodes.NotFound;
                }

                return response;
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: AndrionPaymentVerification, Parameters:msisdn {msisdn} {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public async Task<UserAccount> GetUserAccountWithoutCaching(string msisdn)
        {

            var sipUserName = HelperService.GetSipUserName(msisdn);

            var userAccount = await UserAccount_DL.GetRawUserAccount(sipUserName);

            if (userAccount != null)
            {
                var accountId = userAccount.AccountID;
                userAccount.Msisdn = msisdn;

                var UserSubscriberDetails = await UserAccount_DL.GetUserSubscriberDetails(accountId);

                userAccount.SubscriberId = UserSubscriberDetails.SubscriberID;
                userAccount.UserAccountBalance = UserSubscriberDetails.UserAccountBalance;
                userAccount.UserAccountDetails = UserSubscriberDetails.UseSubscriberDetails;
                userAccount.canEnterReferralCode = await UserAccount_DL.CanUseReferralCodeRevised(userAccount.UserAccountDetails.Na_Service_Id, msisdn);
                userAccount.UserAccountDetails.referralCode = await UserAccount_DL.GetReferralCode(msisdn);
                userAccount.A2ACallSettings = new a2aCallSettings { isTLS = true, port = "5061", url = ApiConfig.app_app_call_url };

                return userAccount;
            }

            return null;
        }
        public async Task<UserAccount> GetATTUserAccountWithoutCaching(string msisdn)
        {


            var sipUserName = HelperService.GetSipUserName(msisdn);

            var userAccount = await UserAccount_DL.GetRawUserAccount(sipUserName);

            if (userAccount != null)
            {
                var accountId = userAccount.AccountID;
                userAccount.Msisdn = msisdn;

                var UserSubscriberDetails = await UserAccount_DL.GetUserSubscriberDetails(accountId);

                userAccount.SubscriberId = UserSubscriberDetails.SubscriberID;
                userAccount.UserAccountBalance = UserSubscriberDetails.UserAccountBalance;
                userAccount.UserAccountDetails = UserSubscriberDetails.UseSubscriberDetails;
                userAccount.canEnterReferralCode = await UserAccount_DL.CanUseReferralCodeRevised(userAccount.UserAccountDetails.Na_Service_Id, msisdn);
                userAccount.UserAccountDetails.referralCode = await UserAccount_DL.GetReferralCode(msisdn);
                userAccount.A2ACallSettings = new a2aCallSettings { isTLS = true, port = "5061", url = ApiConfig.app_app_call_url };
                var sipSettings = await UserAccount_DL.GetSipConfigurations(msisdn);
                userAccount.PaidCallSettings = new PaidCallSettings { transport = sipSettings.transport, is_somme_user = sipSettings.is_somme_user, isTLS = sipSettings.is_tls, port = sipSettings?.Port, realmIPV4 = sipSettings?.realm_ipv4, realmIPV6 = sipSettings?.realm_ipv6 };
                return userAccount;
            }

            return null;
        }
        public Task<GenericApiResponse<ReferralCode>> CreateReferralCode(string msisdn, string name)
        {
            try
            {
                return UserAccount_DL.CreateReferralCode(msisdn, name);
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: CreateReferralCode, Parameters:msisdn {msisdn} name {name}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public Task<GenericApiResponse<string>> UpdateReferralCode(string msisdn, ReferralCode referralCode)
        {
            try
            {
                return UserAccount_DL.UpdateReferralCode(msisdn, referralCode);
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: UpdateReferralCode, Parameters:msisdn {msisdn} referralCode {referralCode}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public Task<GenericApiResponse<bool>> SetPromotions(string msisdn, Promotion promotion)
        {
            try
            {
                return UserAccount_DL.SetPromotions(msisdn, promotion);
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: SetPromotions, Parameters:msisdn {msisdn} promotion {promotion}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public Task<GenericApiResponse<bool>> SetEmail(string msisdn, Email email)
        {
            try
            {
                return UserAccount_DL.SetEmail(msisdn, email);
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: SetEmail, Parameters:msisdn {msisdn} email {email}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public Task<GenericApiResponse<string>> ExecuteWebCallthrough(string msisdn, string destination, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null)
        {
            try
            {
                return UserAccount_DL.ExecuteWebCallthrough(msisdn, destination, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: ExecuteWebCallthrough, Parameters:msisdn {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public Task<GenericApiResponse<useremailRegistration>> getEmail(string msisdn)
        {
            try
            {
                return UserAccount_DL.getEmail(msisdn);
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: getEmail, Parameters:msisdn {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public async Task<GenericApiResponse<GetAutoTopupDetailsResponse>> GetAutoTopupDetails(string msisdn)
        {
            var autoTopupDetails = await _autoTopupDL.Get(msisdn);
            var paypload = new GetAutoTopupDetailsResponse
            {
                UserAutoTopup = new GetAutoTopupDetailsResponse.UserAutoTopupDetails
                {
                    TopupAmount = autoTopupDetails.Topup,
                    CardMaskedPAN = autoTopupDetails.CardMaskedPAN,
                    PaymentMethod = autoTopupDetails.PaymentMethod,
                    Status = autoTopupDetails.Status,
                    Threshold = autoTopupDetails.ThresHold,
                    LastAutoTopupFailed = autoTopupDetails.LastAutoTopupFailed,
                    MaximumSpendLimit = _pay360Config.AutoTopupMaxSpendLimit,
                },
                AutoTopupOptions = new GetAutoTopupDetailsResponse.AutoTopupOptionDetails
                {
                    TopupAmounts = _pay360Config.AutoTopupAmount.Split(","),
                    ThresholdAmounts = _pay360Config.AutoTopupThresholdAmount.Split(","),
                }
            };
            return GenericApiResponse<GetAutoTopupDetailsResponse>.Success(paypload, "Success");
        }
        public async Task<GenericApiResponse<bool>> SetFCMToken(FCMToKenReq fcmToken, string msisdn)
        {
            try
            {
                return await UserAccount_DL.SetFCMToken(fcmToken, msisdn);
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: SetFCMToken, Parameters:msisdn {msisdn} fcmToken {fcmToken}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public Task<UserAccountBalance> GetUserAccountBalance(string msisdn)
        {
            try
            {
                return UserAccount_DL.GetUserAccountBalanceAsync(msisdn);
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: GetUserAccountBalance, Parameters:msisdn {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public Task<GenericApiResponse<Referrals>> GetReferrals(string msisdn)
        {
            try
            {
                return UserAccount_DL.GetReferrals(msisdn);
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccount_BL, Method: GetReferrals, Parameters:msisdn {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        public async Task<GenericApiResponse<DeleteAccountResponseModel>> DeleteAccountAsync(string account, string msisdn)
        {
            var response = new DeleteAccountResponseModel();
            //Remove payment methods
            var removeCardsResult = await _pay360Service.RemoveAllCardsAsync(msisdn);
            if (removeCardsResult.Payload != null && removeCardsResult.Payload.FailedToRemoveCards.Count > 0)
                return GenericApiResponse<DeleteAccountResponseModel>.Failure("Unknown error occured, please try again!", ApiStatusCodes.InternalServerError);
            //Soft delete necessary stuff from database
            var merchantRef = msisdn;
            var paypalMerchantRef = "P_THA_" + msisdn;
            var result = await UserAccount_DL.SoftDeleteAccountAsync(msisdn, account, merchantRef, paypalMerchantRef);
            response.FeedbackUrl = $"{Config["FeedbackUrl"]}?msisdn={msisdn}";
            if (result)
            {
                return GenericApiResponse<DeleteAccountResponseModel>.Success(response, "Account deleted successfully!");
            }
            else
            {
                return GenericApiResponse<DeleteAccountResponseModel>.Failure("Unknown error occured, please try again!", ApiStatusCodes.InternalServerError);
            }
        }
        private static DateTime CreateDateFromTime(int year, int month, int day)
        {
            DateTime time = new DateTime();
            return new DateTime(year, month, day, time.Hour, time.Minute, 0);
        }
        private static int CalculateAge(DateTime dateOfBirth)
        {
            int age = 0;
            age = DateTime.Now.Year - dateOfBirth.Year;
            if (DateTime.Now.DayOfYear < dateOfBirth.DayOfYear)
                age = age - 1;

            return age;
        }
        public async Task<GenericApiResponse<bool>> CreateDeleteAccountRequest(DeleteAccountLogRequestModel model)
        {

            //getting the user information to extract the registeration date
            var userInfo = await UserAccount_DL.GetUserProfile(model.Msisdn);
            if (userInfo == null)
            {
                return GenericApiResponse<bool>.Failure("Account couldn't be found.", ApiStatusCodes.NotFound);
            }

            model.AccountActivationDate = userInfo.Data.registration_date;

            var signUpAllowedAfterDays = _accountDeleteSettings.SignUpAllowedAfterDays;
            model.AllowedSignUpDate = DateTime.UtcNow.AddDays(signUpAllowedAfterDays);

            var result = await UserAccount_DL.CreateDeleteAccountRequest(model);
            if (result == 1)
            {
                if (!string.IsNullOrEmpty(userInfo.Data.email))//email will be sent to the user for the account delete request
                {
                    await SendDeleteAccountEmail(userInfo.Data);
                }
                return GenericApiResponse<bool>.Success(true, "Account delete request logged successfully!");
            }
            else
            {
                return GenericApiResponse<bool>.Failure("Account delete request couldn't be logged. Please contact customer support service.", ApiStatusCodes.InternalServerError);
            }
        }
        public async Task<GenericApiResponse<List<DeleteAccountReason>>> GetDeleteAccountReasons(string languageName)
        {
            var _deleteAccountReasons = await UserAccount_DL.GetDeleteAccountReasons(languageName);
            if (_deleteAccountReasons.Any())
            {
                return GenericApiResponse<List<DeleteAccountReason>>.Success(_deleteAccountReasons, "Delete account reasons found.");

            }
            return GenericApiResponse<List<DeleteAccountReason>>.Failure("Delete account reasons not found.", ApiStatusCodes.NotFound);
        }

        public async Task<GenericApiResponse<bool>> UpdateDeletedAccountStatus(DeleteAccountLogRequestModel model)
        {
            var result = await UserAccount_DL.UpdateDeletedAccountStatus(model);
            if (result == true)
            {
                return GenericApiResponse<bool>.Success(true, "Status updated successfully.");

            }
            return GenericApiResponse<bool>.Failure("Unable to update the status.", ApiStatusCodes.BadRequest);
        }
        /// <summary>
        /// This method is used by the recurring job to delete the accounts, This method is called from the THA.Daemon Service
        /// </summary>
        /// <returns></returns>
        public async Task DeleteAccountsRequestsAsync()
        {
            string msisdn = null, account = null;
            try
            {
                var deleteAcccountLogRequests = await UserAccount_DL.GetDeleteAccountLogRequestsList();
                if (deleteAcccountLogRequests.Any())
                {
                    foreach (var deleteRequest in deleteAcccountLogRequests)
                    {
                        var accountDeletePeriod = _accountDeleteSettings.AccountDeletePeriodInDays;

                        var resultingDate = DateTime.UtcNow.Subtract(deleteRequest.AccountDeleteRequestDate.Value);

                        msisdn = deleteRequest.Msisdn;
                        account = deleteRequest.AccountId;

                        if (resultingDate.Days > accountDeletePeriod)
                        {
                            await DeleteAccountAsync(deleteRequest.AccountId, deleteRequest.Msisdn);//Deleting the user information from the database completely                          
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);

                Logger.Error($"Class: UserAccount_BL, Method: DeleteAccountsRequestsAsync, " +
                    $"Parameters:msisdn: {msisdn},account: {account}, " +
                    $"ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                throw;
            }
        }
        private async Task SendDeleteAccountEmail(Profile userProfile)
        {
            try
            {
                if (!userProfile.emailVerified)
                    return;
                var builder = new BodyBuilder();
                using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\Delete-Account.html").Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();
                }

                string messageBody = builder.HtmlBody
                    .Replace("%FIRST_NAME%", userProfile?.firstName);

                await EmailServ.SendEmail(userProfile.email, messageBody, true, "Account delete request");
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);

                Logger.Error($"Class: UserAccount_BL, Method: SendDeleteAccountEmail, " +
                   $"Parameters:user profile: {JsonConvert.SerializeObject(userProfile)}, " +
                   $"ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
        }
    }
}
