﻿using Application.Common.Extensions.DependencyResolver;
using Application.Common.Interfaces.Shared;
using System.Threading.Tasks;

namespace Application.Common.Interfaces.Infrastructure.Services;
public interface IPaypalFulfillmentService: IServicesType.IScopedService
{
    Task StartSubscriptionFulfillmentService();
}
