using FH.Core.DependencyResolver;

using MessageBrokerModel;

namespace FH.Core.Interfaces.Services;
public interface IMessagePublisher : ServiceType.IScoped
{
    Task PublishMessage(TransactionMessageDto message);
}
