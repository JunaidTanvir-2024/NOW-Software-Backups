using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.NationalPayAsYouGoBundle;

public sealed class NationalPayAsYouGoBundleRequest : IRequest<Result<List<BundleInfo>>>
{
    public string Msisdn { get; set; } = default!;
}
