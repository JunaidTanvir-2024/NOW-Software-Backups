﻿using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Domain.Entities
{
    public class OrderPayment
    {
        public long Id { get; set; }
        public PaymentMethod PaymentMethodId { get; set; }
        public PaymentStatus Stauts { get; set; }
        public string? PaymentUserId { get; set; }
        public string? TransacitonId { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
