namespace Application.Features.Account.History.Data;
public class DataUsageHistoryRequestValidator : AbstractValidator<DataUsageHistoryRequest>
{
    public DataUsageHistoryRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
    }
}