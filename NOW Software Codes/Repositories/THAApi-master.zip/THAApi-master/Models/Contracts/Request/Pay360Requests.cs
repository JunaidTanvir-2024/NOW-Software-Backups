﻿using Models.Contracts.Request.Voucherify;
using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace Models.Contracts.Request
{
    public class NewCustomerPaymentRequestModel
    {
        public TopupInfoRequest TopupInfo { get; set; }
        public BundleInfo BundleInfo { get; set; }
        public PaymentCardModel CardInfo { get; set; }
        public BillingAddressModel AddressInfo { get; set; }
        //public AppsFlyerInfo AppsFlyerInfo { get; set; }
        public string AppsFlyerId { get; set; }
        public int DeviceType { get; set; }
        public UtmParamsInfo UtmParamsInfo { get; set; }
        public Enums.CheckOutTypes CheckoutType { get; set; }
    }
    public class NewCustomerPaymentRequestModelV2: NewCustomerPaymentRequestModel
	{
		public string DiscountCode { get; set; }
		public DiscountCodeType DiscountCodeType { get; set; }
        public bool IsRetry { get; set; } = false;
    }
	public class ExistingCardPaymentRequestModel
	{
		[Required]
		[MaxLength(300)]
		public string CardToken { get; set; }

		[Required(ErrorMessage = "Enter Security Code"),
			StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
		[RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
		public string SecurityCode { get; set; }
		public TopupInfoRequest TopupInfo { get; set; }
		public BundleInfo BundleInfo { get; set; }
		//public AppsFlyerInfo AppsFlyerInfo { get; set; }
		public UtmParamsInfo UtmParamsInfo { get; set; }
		public Enums.CheckOutTypes CheckoutType { get; set; }
		public string AppsFlyerId { get; set; }
		public int DeviceType { get; set; }
		public bool IsDefaultCard { get; set; }
	}
	public class ExistingCardPaymentRequestModelV2: ExistingCardPaymentRequestModel
	{
		public string DiscountCode { get; set; }
		public DiscountCodeType DiscountCodeType { get; set; }
        public bool IsRetry { get; set; } = false;
    }

    public class ActivateBundleRequestModel
    {
        public BundleInfo BundleInfo { get; set; }
        //public AppsFlyerInfo AppsFlyerInfo { get; set; }
        public UtmParamsInfo UtmParamsInfo { get; set; }
        public string AppsFlyerId { get; set; }
        public int DeviceType { get; set; }
    }

    public class UtmParamsInfo
    {
        public UtmParamsInfo()
        {
            this.utm_source = "";
            this.utm_campaign = "";
            this.utm_medium = "";
        }
        public string utm_campaign { get; set; }
        public string utm_medium { get; set; }
        public string utm_source { get; set; }
    }


    public class AppsFlyerInfo
    {
        public AppsFlyerInfo(string AppsFlyerId,DeviceType DeviceType)
        {
            this.AppsFlyerId = AppsFlyerId;
            this.DeviceType = DeviceType;
        }
        public string AppsFlyerId { get; set; }
        public DeviceType DeviceType { get; set; }
    }

    public class BundleInfo
    {
        public string BundleId { get; set; }
        public bool IsBundleAutoRenew { get; set; }
    }

    public class TopupInfoRequest
    {
        public decimal TopUpAmount { get; set; }
        public SetAutoTopUpRequestModel AutoTopupInfo { get; set; }
    }

    public class BillingAddressModel
    {
        [Required(ErrorMessage = "Select country")]
        public string CountryCode { get; set; }

        [Required(ErrorMessage = "Enter address"), StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL1 { get; set; }

        [StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL2 { get; set; }

        [StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL3 { get; set; }

        [StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL4 { get; set; }

        [StringLength(maximumLength: 200, ErrorMessage = "Maximum length exceeded")]
        public string City { get; set; }

        [StringLength(maximumLength: 200, ErrorMessage = "Maximum length exceeded")]
        public string Region { get; set; }

        public string PostCode { get; set; }
    }
    public class PaymentCardModel
    {
        [Required(ErrorMessage = "Enter name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid Name")]
        public string NameOnCard { get; set; }

        [Required(ErrorMessage = "Enter card number")]
        [StringLength(maximumLength: 19, ErrorMessage = "Length must be between (16-19)", MinimumLength = 16)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string CardNumber { get; set; }

        [Required(ErrorMessage = "Enter date")]
        public string ExpiryDate { get; set; }

        [Required(ErrorMessage = "Enter security code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string SecurityCode { get; set; }

        public bool ShouldSaveCard { get; set; }
        public bool IsDefaultCard { get; set; }
    }
    public class SetAutoTopupWithCardRequestModel
    {
		public AutoTopupInfoModel AutoTopupInfo { get; set; }
		public NewCardModel NewCardInfo { get; set; }
		public ExistingCardModel ExistingCardInfo { get; set; }
		public BillingAddressModel AddressInfo { get; set; }
		public string AppsFlyerId { get; set; }
		public int DeviceType { get; set; }
        public class AutoTopupInfoModel
        {
            public float ThresholdAmount { get; set; }
            public float TopupAmount { get; set; }
        }
	}
    public class NewCardModel
    {
		[Required(ErrorMessage = "Enter name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
		[RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid Name")]
		public string NameOnCard { get; set; }

		[Required(ErrorMessage = "Enter card number")]
		[StringLength(maximumLength: 19, ErrorMessage = "Length must be between (16-19)", MinimumLength = 16)]
		[RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
		public string CardNumber { get; set; }

		[Required(ErrorMessage = "Enter date")]
		public string ExpiryDate { get; set; }

		[Required(ErrorMessage = "Enter security code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
		[RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
		public string SecurityCode { get; set; }
	}
    public class ExistingCardModel
    {
		[Required]
		[MaxLength(300)]
		public string CardToken { get; set; }

		[Required(ErrorMessage = "Enter Security Code"),
			StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
		[RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
		public string SecurityCode { get; set; }
	}
    public class SetAutoTopUpRequestModel
    {
        [Required(ErrorMessage = "Select Threshold Amount")]
        public float thresholdBalanceAmount { get; set; }

        [Required(ErrorMessage = "Select TopUp Amount")]
        public float amount { get; set; }
        public bool isActive { get; set; }
        public string AppsFlyerId { get; set; }
        public DeviceType DeviceType { get; set; }
    }

    public class Pay360SetAutoTopUpRequest
    {
        public string productRef { get; set; }
        public string productCode { get; set; }
        public string productItemCode { get; set; }
        public float thresholdBalanceAmount { get; set; }
        public bool isAutoTopup { get; set; }
        public float topupAmount { get; set; }
        public string topupCurrency { get; set; }
        public string Email { get; set; }
    }
    public class Pay360GetAutoTopUpRequest
    {
        public string Msisdn { get; set; }
        public string Email { get; set; }
        public string ProductCode { get; set; }
    }
    public class PaymentMethodsRequest
    {
        [JsonProperty("customerUniqueRef")]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("productCode")]
        public string ProductCode { get; set; }
    }

    public class RemoveCardUserRequest
    {
        [JsonProperty("cardToken")]
        [Required]
        public string CardToken { get; set; }
    }

    public class GetCustomerRequest
    {
        [JsonProperty("customerUniqueRef")]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("productCode")]
        public string ProductCode { get; set; }
    }

    public class RemoveCardRequest
    {

        [JsonProperty("pay360CustomerID")]
        public string Pay360CustomerID { get; set; }

        [JsonProperty("cardToken")]
        public string CardToken { get; set; }
    }

    public class SetDefaultCardUserRequest
    {
        [JsonProperty("cv2")]
        [Required]
        public string CV2 { get; set; }

        [JsonProperty("cardToken")]
        [Required]
        public string CardToken { get; set; }
    }

    public class SetDefaultCardRequest
    {
        [JsonProperty("defaultCardCV2")]
        public string DefaultCardCV2 { get; set; }

        [JsonProperty("pay360CustomerID")]
        public string Pay360CustomerID { get; set; }

        [JsonProperty("cardToken")]
        public string CardToken { get; set; }
    }

    public class Pay360PaymentRequestModel
    {
        public CardPaymentRequestModel UserCard { get; set; }
        public float Amount { get; set; }
        public string Msisdn { get; set; }
        public string SecurityCode { get; set; }
        public Pay360PaymentType Pay360PaymentType { get; set; }

        public Enums.CheckOutTypes CheckoutPaymentType { get; set; }

        public string UUID { get; set; }
        public string BundleName { get; set; }

        public string CustomerEmail { get; set; }

        public bool AutoTopUp { get; set; }
        public string AccountId { get; set; }
        public bool isAutoRenew { get; set; }
        public string EmailAddress { get; set; }
        public string AddressL1 { get; set; }
        public string AddressL2 { get; set; }
        public string AddressL3 { get; set; } = "AddressL3";
        public string AddressL4 { get; set; } = "AddressL4";
        public string City { get; set; }
        public string County { get; set; }
        public string PostCode { get; set; }
        public string Region { get; set; }
        public bool ShouldSave { get; set; }
    }
    public class CardPaymentRequestModel
    {
        public string NameOnCard { get; set; }
        public string CardNumber { get; set; }
        public string ExpiryMonth { get; set; }
        public string ExpiryYear { get; set; }
        public string SecurityCode { get; set; }
        public string Token { get; set; }
        public List<string> CountryCode { get; set; }
        public string SelectedCountry { get; set; }
    }
    public class Pay360Resume3DRequest
    {
        public string pay360TransactionId { get; set; }
        public string pareq { get; set; }
        public string customerEmail { get; set; }
        public string overallStatus { get; set; }
    }
    public class CaptureTransactionRequestModel
    {
        public string transactionId { get; set; }
    }
    public class CancelTransactionRequestModel
    {
        public string transactionId { get; set; }
    }

    public class Resume3DPaymentRequest
    {
        public string MD { get; set; }
        public string PaRes { get; set; }
        public string OverallStatus { get; set; }
        public string TransactionId { get; set; }
    }

    public class Resume3DPaymentDataRequest
    {
        public Enums.CheckOutTypes CheckoutType { get; set; }
        public ThemeMode ThemeMode { get; set; }

        public string CustomerEmail { get; set; }
        public string CustomerMsisdn { get; set; }
        public string Currency { get; set; }
        public string Secure3dType { get; set; }
        public string Ip { get; set; }
        public bool SaveCard { get; set; }
        //Bundle Auto Renewal
        public bool IsAutoRenewal { get; set; }
        public string BundleId { get; set; }
        
        //Auto Topup Settings
        public bool IsAutoTopUp { get; set; }
        public float AutoToupAmount { get; set; }
        public float AutoTopupThreshold { get; set; }

        //Payment Transaction Id
        public int PTId { get; set; }

        //Apps Flyer
        public int DeviceType { get; set; }
        public string AppsFlyerId { get; set; }

        //Utm Params
        public string UtmCampaign { get; set; }
        public string UtmMedium { get; set; }
        public string UtmSource { get; set; }

        // FaceBook 
        public string advertiserID { get; set; }
        //Airship
        public bool airshipEventsDisable { get; set; }
	}
    public class Resume3DPaymentDataRequestV2: Resume3DPaymentDataRequest
    {
		public DiscountCodeType DiscountCodeType { get; set; }
		public string DiscountCode { get; set; }
        public decimal TopupAmount { get; set; }
    }
    public class SetAutoRenewalCardRequestModel
    {
        public AutoRenewalInfoModel AutoRenewalInfo { get; set; }
        public NewCardModel NewCardInfo { get; set; }
        public ExistingCardModel ExistingCardInfo { get; set; }
        public BillingAddressModel AddressInfo { get; set; }
        public string AppsFlyerId { get; set; }
        public int DeviceType { get; set; }
        public class AutoRenewalInfoModel
        {            
            public string BundleId { get; set; }   
        }
    }
}
