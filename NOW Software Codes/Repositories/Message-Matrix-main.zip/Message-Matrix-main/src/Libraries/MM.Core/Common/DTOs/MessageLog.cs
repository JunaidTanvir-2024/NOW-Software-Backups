using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MM.Core.Common.DTOs;


[Table("message_logging")]
public class MessageLog
{
    public int MessageLoggingId { get; set; }
    public string Sender { get; set; }
    public string Receiver { get; set; }
    public string Message { get; set; }
    public bool MessageStatus { get; set; }
    public string MessageError { get; set; } 
    public string CreatedBy { get; set; }
    public DateTime CurrentTime { get; set; }
    public Guid Guid { get; set; } 
    public string TransactionId { get; set; }
    public string MessageSid { get; set; }

}


