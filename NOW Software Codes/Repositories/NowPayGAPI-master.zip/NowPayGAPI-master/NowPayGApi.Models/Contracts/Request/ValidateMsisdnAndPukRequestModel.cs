﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class ValidateMsisdnAndPukRequestModel
    {
        [Required]
        public string Msisdn { get; set; }
        [Required]
        [StringLength(8, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        public string PUK { get; set; }
    }
}
