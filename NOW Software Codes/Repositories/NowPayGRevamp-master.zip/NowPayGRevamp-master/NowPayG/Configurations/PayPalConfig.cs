﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Configurations
{
    public class PayPalConfig
    {
        public string PayPalApiEndpoint { get; set; }
        public string Pay360PayPalApiEndpoint { get; set; }
    }
}
