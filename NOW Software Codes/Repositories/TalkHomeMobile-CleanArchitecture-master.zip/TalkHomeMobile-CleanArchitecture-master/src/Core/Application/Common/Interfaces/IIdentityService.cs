﻿using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces;

public interface IIdentityService : IServicesType.ITransientService
{
}
