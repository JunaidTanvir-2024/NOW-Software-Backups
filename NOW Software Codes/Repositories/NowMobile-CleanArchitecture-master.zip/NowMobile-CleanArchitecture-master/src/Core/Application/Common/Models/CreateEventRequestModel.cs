﻿
namespace Application.Common.Models;
public class CreateEventRequestModel
{
    public string? CustomerUserId { get; set; }
    public string? Ip { get; set; }
    public string? EventName { get; set; }
    public string? EventRevenenuCurrency { get; set; }
    public decimal EventRevenue { get; set; }
    public object EventValue { get; set; } = new object();
    public string ProductCode { get; set; } = "NOW-WEB";
    public string BaseProductCode { get; set; } = "NOW";
}
