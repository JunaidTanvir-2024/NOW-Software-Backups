﻿using Application.Common.Interfaces.HttpService;
using Application.Common.Settings;
using Application.Features.Bundle.Bundle;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.Net;

namespace Infrastructure.Services;
internal class BundleService : IBundleService
{
    private readonly IHttpService _httpService;
    private readonly DigitalkSettings _digiTalkSettings;
    private readonly Serilog.ILogger _logger;
    public BundleService(IHttpService httpService, IOptions<DigitalkSettings> digiTalkSettings, Serilog.ILogger logger)
    {
        _httpService = httpService;
        _digiTalkSettings = digiTalkSettings.Value;
        _httpService.WithBasicAuth(_digiTalkSettings.UserName, _digiTalkSettings.Password).EnableLogging();
        _logger = logger;
    }
    public async Task<bool> UnSubscribeBundle(string subscriber_id, string packageId)
    {
        string endPoint = string.Empty;
        int statusCode = 0;
        string outPutData = string.Empty;

        endPoint = _digiTalkSettings.ApiEndPoint + $"/subscribers/{subscriber_id}/subscriptions/2/bundles?type=1";

        var bundlesResponse = await _httpService.GetAsync(endPoint);

        if (!bundlesResponse.IsSuccessStatusCode)
        {
            statusCode = bundlesResponse.StatusCode;
            outPutData = bundlesResponse.ResponseBody.ToString();
            LogError(statusCode, endPoint, outPutData);
            return await Task.FromResult(false);
        }
        var bundlesList = JsonConvert.DeserializeObject<BundleItems>(bundlesResponse.ResponseBody);

        var bundleItem = bundlesList.Items.FirstOrDefault(t => t.CallingPackage.PackageId == packageId);

        endPoint = _digiTalkSettings.ApiEndPoint + $"/subscribers/{subscriber_id}/subscriptions/2/bundles/{bundleItem?.Type}";

        var removeBundleResponse = await _httpService.DeleteAsync(endPoint);
        if (!removeBundleResponse.IsSuccessStatusCode)
        {
            statusCode = removeBundleResponse.StatusCode;
            outPutData = removeBundleResponse.ResponseBody.ToString();
            LogError(statusCode, endPoint, outPutData);
            return await Task.FromResult(false);
        }

        return await Task.FromResult(true);

    }
    private void LogError(int StatusCode, string endpoint, string outputData)
    {

        _logger.Error(
           $"Class: PortingService, " +
           $"Method: GetPortRequests, " +
           $"Status Code: {StatusCode}" +
           $"Request: {endpoint}" +
           $"Response: {outputData}");

    }
}

