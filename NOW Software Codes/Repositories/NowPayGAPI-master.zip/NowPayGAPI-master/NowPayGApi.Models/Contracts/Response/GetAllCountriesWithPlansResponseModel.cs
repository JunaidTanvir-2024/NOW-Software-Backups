﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetAllCountriesWithPlansResponseModel
    {
        public IEnumerable<CountryResponseModel> CountriesList { get; set; }
    }
}
