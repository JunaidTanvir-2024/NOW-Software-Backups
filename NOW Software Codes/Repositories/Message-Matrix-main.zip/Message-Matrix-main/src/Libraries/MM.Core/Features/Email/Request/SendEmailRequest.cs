using MM.Core.Common.Definitions.Enums;

namespace MM.Core.Features.Email.Request;
public class SendEmailRequest : IRequest<IResultWrapper>
{
    public string? To { get; set; }
    public string? EmailBody { get; set; }
    public string? ProductCode { get; set; }
    public string? Subject { get; set; }
}
