﻿using PaypalApi.Models.Contracts.Request.User;
using PaypalApi.Models.Contracts.Response.Api;
using PaypalApi.Models.Contracts.Response.User;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PaypalApi.Infrastructure.BLL
{
    public interface IPaypal_BL
    {
        Task<GenericApiResponse<UserCreateSalePaymentResponse>> CreateSalePayment(UserCreateSalePaymentRequest userRequest);
        Task<GenericApiResponse<UserExecuteSalePaymentResponse>> ExecuteSalePayment(UserExecuteSalePaymentRequest userRequest);
    }
}
