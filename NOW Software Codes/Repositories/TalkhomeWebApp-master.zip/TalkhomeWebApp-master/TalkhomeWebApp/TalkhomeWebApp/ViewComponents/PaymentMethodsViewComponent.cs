﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.ApiContracts.Response;
using TalkhomeWebApp.Models.Configurations;
using TalkhomeWebApp.Models.ViewModels;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.ViewComponents
{
    public class PaymentMethodsViewComponent : ViewComponent
    {
        private readonly EndPoints _Endpoints;
        private readonly ILogger _logger;
        private readonly IHostingEnvironment _hostingEnvironment;
		private readonly ApiClient _apiClient;

		public PaymentMethodsViewComponent(IOptions<EndPoints> Endpoints, ILogger logger,IHostingEnvironment hostingEnvironment,
            ApiClient apiClient)
        {
            _Endpoints = Endpoints.Value;
            this._logger = logger;
            this._hostingEnvironment = hostingEnvironment;
			this._apiClient = apiClient;
		}
        public async Task<IViewComponentResult> InvokeAsync()
        {
            try
            {
                var result = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Payment/GetCustomerCards", User,
					ApiCallType.Bearer, GetRequest: true);

                //Get Countries List
                var json = System.IO.File.ReadAllText(_hostingEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json");
                var _countries = JsonConvert.DeserializeObject<CountriesResponseModel>(json);

                if (result.IsSuccessStatusCode)
                {
                    var response = JObject.Parse(await result.Content.ReadAsStringAsync());

                    var errorCode = response.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = response.GetValue("payload").ToObject<Pay360CardsData>();
                        payload.countries = _countries;
                        return View(payload);
                    }
                }
                return View(new Pay360CardsData
                {
                    paymentMethodResponses=new System.Collections.Generic.List<PaymentMethodData>(),
                    countries=_countries
                });
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetCustomerCards, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return View(null);
            }
        }

    }
}
