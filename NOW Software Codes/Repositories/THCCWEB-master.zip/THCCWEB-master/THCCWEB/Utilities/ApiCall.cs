﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using static THCCWEB.Utilities.Enum;

namespace THCCWEB.Utilities
{
    public class Api
    {
        static HttpClient client;
        public static async Task<HttpResponseMessage> CallApi(string Uri, IPrincipal User, ApiCallType callType, object model = null, bool GetRequest = false, bool isMultipart = false, MultipartFormDataContent multipartContent = null, string basicauthtoken = null, params string[] parameters)
        {
            try
            {
                HttpResponseMessage response;
                string paramString = parameters.Count() > 0 ? "?" : String.Empty;
                using (client = new HttpClient())
                {
                    foreach (var param in parameters)
                    {
                        paramString += param + "&";
                    }
                    paramString = paramString.TrimEnd('&');

                    if (callType == ApiCallType.Bearer && User.Identity.IsAuthenticated)
                    {
                        var claimsIdentity = (ClaimsIdentity)User.Identity;
                        var access_token = claimsIdentity.FindFirst("bearer_token");

                        if (access_token != null)
                        {
                            if (isMultipart)
                            {
                                client.DefaultRequestHeaders.Accept.Clear();
                                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", access_token.Value);
                            }
                            else
                            {
                                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", access_token.Value);
                            }
                        }
                    }
                    else if (callType == ApiCallType.BasicAuth)
                    {
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", basicauthtoken);
                    }


                    if (isMultipart)
                    {
                        response = await client.PostAsync(Uri, multipartContent);
                    }
                    else
                    {
                        if (GetRequest)
                        {
                            response = await client.GetAsync(Uri + paramString);
                        }
                        else
                        {
                            response = await client.PostAsync(Uri, new JsonContent(model));
                        }
                    }
                    return response;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
    [JsonObject(Title = "Error")]
    class Error : JObject
    {
        [JsonProperty("message")]
        public string ErrorMessage { get; set; }
        [JsonProperty("errorCode")]
        public int ErrorCode { get; set; }

    }
    public class JsonContent : StringContent
    {
        public JsonContent(object obj) :
            base(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json")
        { }
    }
}
