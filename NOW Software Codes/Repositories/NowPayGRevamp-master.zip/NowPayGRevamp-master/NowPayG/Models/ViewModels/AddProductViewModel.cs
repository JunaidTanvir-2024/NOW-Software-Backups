﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class AddProductViewModel : BaseViewModel
    {
        [Required(ErrorMessage = "Enter Number"), MaxLength(length: 12, ErrorMessage = "Maximum 12 characters allowed"), MinLength(length: 10, ErrorMessage = "Minimum 10 characters allowed")]
        public string MobileNumber { get; set; }
        [Required(ErrorMessage = "Enter PUK Code"), StringLength(maximumLength: 8, ErrorMessage = "Maximum Length Exceeded")]
        public string PUKCode { get; set; }
    }
}
