﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class PaypalPaymentRequestModel
    {

        [CollectionValidation(values: new int[] { 0, 5, 10, 15, 20, 25 })]
        public int TopUpAmount { get; set; }
        public string BundleId { get; set; }

        [Required]
        [Range(1, 2)]
        public CheckOutTypes CheckoutType { get; set; }

        [Required]
        public string ipAddress { get; set; }


        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [EmailAddress(ErrorMessage = "Invalid email")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        public string EmailAddress { get; set; }

        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        public string Msisdn { get; set; }

        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }
    }
}
