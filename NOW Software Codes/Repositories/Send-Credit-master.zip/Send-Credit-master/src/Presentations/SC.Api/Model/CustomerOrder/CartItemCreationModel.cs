﻿using System.ComponentModel.DataAnnotations;

namespace SC.Api.Model.CustomerOrder;
public class CartItemCreationModel
{
    public string receiverEmail { get; set; } = default!;
    public string receiverMobile { get; set; } = default!;
    public string receiverPin { get; set; } = default!;
    public string customMessage { get; set; } = default!;
    public bool isRenewal { get; set; } = default!;
    public string senderId { get; set; } = default!;
    public string senderName { get; set; } = default!;
    public string senderEmail { get; set; } = default!;
    public string senderMobile { get; set; } = default!;
    [Required(ErrorMessage = "The {0} field is required.")]
    public long productId { get; set; } = default!;
    [Required(ErrorMessage = "The {0} field is required.")]
    public long customerCartId { get; set; } = default!;
    public bool isActive { get; set; } = default!;
    public bool isDeleted { get; set; } = default!;
}

