using JM.Core.Entities.Common;

using Microsoft.AspNetCore.Identity;

namespace JM.Core.Entities;

public sealed class User : IdentityUser<long>, IAuditEntity
{
	public string? RefreshToken { get; set; }
	public DateTime? RefreshTokenExpiry { get; set; }
	public bool IsActive { get; set; } = true;
	public bool IsDeleted { get; set; } = false;
	public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
	public DateTime? UpdatedAt { get; set; }
	public DateTime? DeletedAt { get; set; }
	public UserDetail UserDetail { get; set; } = null!;
	public ICollection<Otp> Otps { get; set; } = [];
	public ICollection<Traveler> Travelers { get; set; } = [];
	public ICollection<ChatMessage> SenderChatMessages { get; set; } = [];
	public ICollection<ChatMessage> ReceiverChatMessages { get; set; } = [];
	public ICollection<UserSubscription> UserSubscriptions { get; set; } = [];
	public ICollection<Friendship> FriendshipInitiators { get; set; } = [];

	public ICollection<Friendship> FriendshipResponders { get; set; } = [];
}
