using Application.Features.Rate.Model;

namespace Application.Features.Rate.International;

public class InternationalRatesRequest : IRequest<Result<List<InternationalRate>>> { }
