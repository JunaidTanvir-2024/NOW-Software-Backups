namespace FH.Core.DTOs.Database;
public sealed class ProductDetailDto
{
    public sealed record Request
    {
        public required long ProductId { get; set; }
        public required string ProductVendorCode { get; set; }
    }

    public sealed record Response
    {
        public long ProductId { get; set; }
        public required string ProductVendorCode { get; set; }
        public required string VendorName { get; set; }
        public decimal Price { get; set; }
        public decimal Tax { get; set; }
        public decimal Fee { get; set; }
        public decimal RangeMinPrice { get; set; }
        public decimal RangeMaxPrice { get; set; }
    }
}
