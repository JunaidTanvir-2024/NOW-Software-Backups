using FluentValidation;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Vouchers.Requests;

public class ValidateVoucherRequest
{
    public string VoucherCode { get; set; } = null!;
    public string CustomerSourceId { get; set; } = null!;
    public Metadata? CustomerMetadata { get; set; }
}
internal class ValidateVoucherRequestValidator : AbstractValidator<ValidateVoucherRequest>
{
    public ValidateVoucherRequestValidator()
    {
        RuleFor(p => p.VoucherCode).NotNull().NotEmpty();
        RuleFor(p => p.CustomerSourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.CustomerSourceId = phoneNumber);
    }
}
