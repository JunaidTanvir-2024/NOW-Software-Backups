namespace Infrastructure.BLL.Services.Voucherify.Models.EarningRules.Requests
{
    public class DisableEarningRuleRequest
    {
        public string CampaignId { get; set; } = null!;
        public string EarningRuleId { get; set; } = null!;
    }
}
