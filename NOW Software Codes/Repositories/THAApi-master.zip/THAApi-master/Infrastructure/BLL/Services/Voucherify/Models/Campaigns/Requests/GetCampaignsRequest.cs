﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Campaigns.Requests
{
    public class GetCampaignsRequest
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
