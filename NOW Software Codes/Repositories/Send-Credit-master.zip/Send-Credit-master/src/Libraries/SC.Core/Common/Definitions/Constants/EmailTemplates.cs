﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants
{
    public static partial class AppConstants
    {
        public static class EmailTemplates
        {
            public const string SignUpOtp = "signup-otp-email";
            public const string WelcomeEmail = "welcome-email";
            public const string ResetPasswordOtp = "password-reset-otp-email";
            public const string ResetPasswordSuccess = "password-reset-successfully-email";
            public const string AddPaymentCard = "paymet-details-updated-email";
            public const string RemovePaymentCard = "paymet-details-removed-email";
            public const string PurchaseConfirmation = "purchase-confirmation-email";
            public const string PurchaseFailure = "purchase-failure-email";
        }

        public static class EmailSubjects
        {
            public const string SignUpOtp = "Send Credit Email verification OTP";
            public const string WelcomeEmail = "welcome-email to Send Credit";
            public const string ResetPasswordOtp = "One-Time Password for Password Reset";
            public const string ResetPasswordSuccess = "Password Reset Successfully Completed";
            public const string AddPaymentCard = "Payment Card Successfully Added to Your Account";
            public const string RemovePaymentCard = "Payment Card Successfully Removed from Your Account!";
            public const string PurchaseConfirmation = "Order Successfully Processed. Your Order # ";
            public const string PurchaseFailure = "Sorry! Order failed to process# ";
        }
    }
}