namespace Application.Common.Interfaces;

public interface ITokenService : ISerivcesType.ITransientService
{
    Task<TokenResponse> GetTokenAsync(User user, string ipAddress, CancellationToken cancellationToken);

    Task<TokenResponse> RefreshTokenAsync(RefreshTokenRequest request, string ipAddress);
}