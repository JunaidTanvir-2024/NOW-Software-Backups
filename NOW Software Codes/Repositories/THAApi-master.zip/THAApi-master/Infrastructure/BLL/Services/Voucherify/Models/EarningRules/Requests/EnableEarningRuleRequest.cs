namespace Infrastructure.BLL.Services.Voucherify.Models.EarningRules.Requests
{
    public class EnableEarningRuleRequest
    {
        public string CampaignId { get; set; } = null!;
        public string EarningRuleId { get; set; } = null!;
    }
}
