﻿namespace THCC.Application.Models.Dtos;

public class PaymentNewCardDto
{
    public string NameOnCard { get; set; } = default!;
    public string CardNumber { get; set; } = default!;
    public string ExpiryMonth { get; set; } = default!;
    public string ExpiryYear { get; set; } = default!;
    public string SecurityCode { get; set; } = default!;
    public bool SaveCard { get; set; } = false;
    public bool MakeDefault { get; set; } = false;
}

public class PaymentExistingCardDto
{
    public string CardToken { get; set; } = default!;
    public string SecurityCode { get; set; } = default!;
}