﻿namespace Application.Common.Interfaces;

public interface IUserService : ISerivcesType.IScopedService
{
    Task<bool> IsUserMsisdn(string msisdn);
}