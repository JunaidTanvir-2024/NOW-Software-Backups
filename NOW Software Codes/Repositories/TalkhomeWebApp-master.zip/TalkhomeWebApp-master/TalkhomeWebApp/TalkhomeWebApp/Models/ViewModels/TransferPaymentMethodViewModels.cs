﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.ApiContracts.Response;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class TransferPaymentMethodViewModels
    {
        public decimal AmountToCharge { get; set; }
        public decimal AccountBalance { get; set; }
        public List<CustomerPaymentMethod> Cards { get; set; }
        public List<CountryModel> Countries { get; set; }


        //For Existing Card
        [Required(ErrorMessage = "Enter security code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid number")]
        public string SecurityCode { get; set; }

        //For New Card
        public NewPaymentCardViewModel NewCard { get; set; }

        //Billing Address
        public BillingAddressViewModel BillingAddress { get; set; }
    }

    public class NewPaymentCardViewModel
    {
        [Required(ErrorMessage = "Enter card holder name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid Name")]
        public string NameOnCard { get; set; }

        [Required(ErrorMessage = "Enter card number")]
        [StringLength(maximumLength: 19, ErrorMessage = "Length must be between (14-19)", MinimumLength = 14)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string CardNumber { get; set; }
        

        [Required(ErrorMessage = "Enter security code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string SecurityCode { get; set; }

        public bool ShouldSaveCard { get; set; }
        [Required(ErrorMessage = "Enter card expiry date")]
        public string ExpiryDate { set; get; }
    }

    public class BillingAddressViewModel
    {
        [Required(ErrorMessage = "Select country")]
        public string CountryCode { get; set; }

        [Required(ErrorMessage = "Enter address"), StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL1 { get; set; }

        [StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL2 { get; set; }

        [StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL3 { get; set; }

        [StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL4 { get; set; }

        [Required,StringLength(maximumLength: 200, ErrorMessage = "Maximum length exceeded")]
        public string City { get; set; }

        [StringLength(maximumLength: 200, ErrorMessage = "Maximum length exceeded")]
        public string Region { get; set; }

        [Required(ErrorMessage = "Enter post code")]
        [StringLength(maximumLength: 10, ErrorMessage = "Maximum length exceeded")]
        public string PostCode { get; set; }
    }
}
