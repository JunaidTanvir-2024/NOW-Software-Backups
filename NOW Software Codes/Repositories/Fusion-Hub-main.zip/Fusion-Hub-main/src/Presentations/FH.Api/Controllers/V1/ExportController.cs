using Asp.Versioning;

using FH.Api.Controllers.Common;
using FH.UseCases.Exports;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.V1;
[ApiVersion(1.0)]
public sealed class ExportController : BaseApiController
{
    [HttpPost("operators")]
    public async Task<IActionResult> OperatorsCsvFile([FromBody] OperatorAliasFile.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return result.TypedPayload<FileContentResult>()!;
        }
        return BadRequest(result);
    }
    [HttpPost("products")]
    public async Task<IActionResult> ProductsCsvFile([FromBody] ProductAliasFile.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return result.TypedPayload<FileContentResult>()!;
        }
        return BadRequest(result);
    }
}
