namespace FH.Core.DTOs.Database;

public sealed record ProductByCategoryDto
{
    public sealed record Request
    {
    
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public CategoryBySubCategoryFilter? CategoryFilters { get; set; }

        public sealed record CategoryBySubCategoryFilter
        {
            public string? CountryIsoCode2 { get; set; }
            public string? CurrencyCode { get; set; }
            public string? CategoryAliasName { get; set; }
        }
    }

    public sealed record Response
    {
        public string? CountryName { get; set; }
        public string? OperatorShortCode { get; set; }
        public string? CurrencyCode { get; set; }
        public long ProductId { get; set; }
        public string? ProductAliasName { get; set; }
        public string? ProductType { get; set; }
        public string? CategoryName { get; set; }
        public string? SubCategoryName { get; set; }

        //ProductPriceInfo
        public decimal? Price { get; set; }
        public decimal? Tax { get; set; }
        public decimal? Fee { get; set; }
        public decimal? MaxPrice { get; set; }
        public decimal? MinPrice { get; set; }
    }
}

