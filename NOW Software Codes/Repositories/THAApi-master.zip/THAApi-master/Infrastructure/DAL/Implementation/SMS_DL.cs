﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class SMS_DL : ISMS_DL
    {
        private readonly ConnectionStrings _dbConnections;
        public SMS_DL(IOptions<ConnectionStrings> dbConnections)
        {
            _dbConnections = dbConnections.Value;
        }

        /// <summary>
        /// Count SMS Resend
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<int> CountSMSResend(string msisdn)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", msisdn);
            //parameters.Add("@account_no", dbType: DbType.String, direction: ParameterDirection.Output);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                return await dbConnection.QueryFirstOrDefaultAsync<int>("tha_sms_resend_count", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        /// <summary>
        /// Update SMS Resend
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task UpdateSMSResend(string msisdn)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", msisdn);
            //parameters.Add("@account_no", dbType: DbType.String, direction: ParameterDirection.Output);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                await dbConnection.ExecuteAsync("tha_sms_resend_insert", parameters, commandType: CommandType.StoredProcedure);
            }
        }
    }
}
