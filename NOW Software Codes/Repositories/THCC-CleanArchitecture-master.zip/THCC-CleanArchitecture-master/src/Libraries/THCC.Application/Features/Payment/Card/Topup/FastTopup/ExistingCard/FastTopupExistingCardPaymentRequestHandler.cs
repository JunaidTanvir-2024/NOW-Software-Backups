﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.Card.Topup.FastTopup.ExistingCard
{
    public class FastTopupExistingCardPaymentRequestHandler : IRequestHandler<FastTopupExistingCardPaymentRequest, object>
    {
        #region Fields

        private readonly IPaymentService _paymentService;
        private readonly IUserRepository _userRepository;
        private readonly IUserService _userService;
        private readonly ILogger _logger;
        private readonly ICurrentUser _currentUser;
        private readonly IAirshipService _airshipService;

        #endregion

        #region Ctors

        public FastTopupExistingCardPaymentRequestHandler(
            IPaymentService paymentService,
            IUserRepository userRepository,
            IUserService userService,
            ILogger logger,
            ICurrentUser currentUser,
            IAirshipService airshipService)
        {
            _paymentService = paymentService;
            _userRepository = userRepository;
            _userService = userService;
            _logger = logger;
            _currentUser = currentUser;
            _airshipService = airshipService;
        }

        #endregion

        #region Methods

        public async Task<object> Handle(FastTopupExistingCardPaymentRequest request, CancellationToken cancellationToken)
        {
            //Trim all the request properties
            request.CardNumber = request.CardNumber.Trim();
            request.EmailAddress = request.EmailAddress != null ? request.EmailAddress!.Trim() : null;
            request.PaymentCardInfo.CardToken = request.PaymentCardInfo.CardToken.Trim();
            request.PaymentCardInfo.SecurityCode = request.PaymentCardInfo.SecurityCode.Trim();

            var userData = new UserDto();
            var productUser = await _userRepository.GetUserByProduct(request.CardNumber);
            if (productUser != null)
            {
                //Check if the card number is logged-in user card number
                if (productUser.Id.Equals(_currentUser.GetUserId(),
                                StringComparison.InvariantCultureIgnoreCase))
                {
                    userData.Email = _currentUser.GetUserEmail();
                    userData.Id = _currentUser.GetUserId();
                }
                else
                {
                    userData.Email = productUser.Email!;
                    userData.Id = productUser.Id;
                }
            }
            else
            {
                //User must have to provide email address when card number is not registered
                if (string.IsNullOrEmpty(request.EmailAddress))
                {
                    _logger.Error("FastTopupNewCardPaymentRequestHandler => card number not registerd and email not provided: " + request.CardNumber);
                    return ErrorResult.Failure(
                            CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
                }

                //Check user is registered
                var dbUser = await _userRepository.GetUserByEmailAsync(request.EmailAddress);
                if (dbUser != null)
                {
                    userData.Id = dbUser.Id;
                    userData.Email = dbUser.Email!;
                }
                else
                {
                    var signupResponse = await _userService.SignUpAsync(
                         null!,
                         null!,
                         request!.EmailAddress,
                         null!,
                         UserRole.Guest,
                         false);

                    if (!signupResponse.IsSuccess)
                    {
                        return ErrorResult.Failure(
                            CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
                    }

                    userData.Id = signupResponse!.Id!;
                    userData.Email = request!.EmailAddress;
                }
            }

            #region Airship

            await _airshipService.CreateEmailChannelAndAssociation(userData.Email!);

            #endregion

            return await _paymentService.HandleCardPaymentRequest(
                paymentNewCardInfo: null!,
                paymentAddressInfo: null!,
                paymentExistingCardInfo: request.PaymentCardInfo,
                autoTopupInfo: null!,
                userInfo: userData,
                productType: ProductType.FastTopup,
                amount: request.Amount,
                cardNumber: request.CardNumber);
        }

        #endregion
    }
}