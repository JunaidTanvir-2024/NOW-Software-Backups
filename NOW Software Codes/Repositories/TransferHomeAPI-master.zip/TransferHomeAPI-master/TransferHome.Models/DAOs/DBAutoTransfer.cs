﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.DAOs
{
    public class DBAutoTransfer
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public PaymentType PaymentType { get; set; }
        public int PaymentTypeId { get; set; }
        public RegularityType RegularityType { get; set; }
        public int RegularityId { get; set; }
        public string NowtelTransactionReference { get; set; }
        public string OperatorId { get; set; }
        public string Product { get; set; }
        public string FromMsisdn { get; set; }
        public DateTime RequestDateTime { get; set; }
        public DateTime LastTransactionExecutionDateTime { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public bool IsOn { get; set; }
    }
}
