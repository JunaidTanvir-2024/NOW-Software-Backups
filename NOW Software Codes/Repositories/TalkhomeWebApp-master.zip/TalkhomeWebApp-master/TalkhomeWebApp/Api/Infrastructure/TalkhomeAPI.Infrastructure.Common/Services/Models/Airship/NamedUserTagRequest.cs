﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.Airship
{
    public class NamedUserTagsRequest
    {
        [JsonProperty("NamedUser")]
        [Required]
        public string NamedUser { get; set; }

        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; } = "THA";

        [JsonProperty("TagGroup")]
        [Required]
        public string TagGroup { get; set; }

        [JsonProperty("Tags")]
        [Required]
        public List<string> Tags { get; set; }
    }
}
