﻿using SC.Api.Model.Common;
using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Model.Operator;
public class OperatorModel : BaseModel
{

    public OperatorRequestType RequestType { get; set; } = default(OperatorRequestType);
    public string? IsoCode { get; set; } = default!;
    public string CurrencyCode { get; set; } = default!;

}

