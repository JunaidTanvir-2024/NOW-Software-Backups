﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.PreAuth
{
    public class PreAuthRequest
    {
        public string AuthTx { get; set; }
        public string productCode { get; set; }
        public string productItemCode { get; set; }
    }
}
