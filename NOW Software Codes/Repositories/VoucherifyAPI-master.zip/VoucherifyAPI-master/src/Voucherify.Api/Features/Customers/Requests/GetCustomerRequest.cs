using FluentValidation;

using Voucherify.Core.Commons.Extensions;

namespace Voucherify.Api.Features.Customers.Requests;

public class GetCustomerRequest
{
    public string CustomerSourceId { get; set; } = null!;
    public string? LoyaltyCampaignId { get; set; }
}

internal class CustomerByIdRequestValidator : AbstractValidator<GetCustomerRequest>
{
    public CustomerByIdRequestValidator()
    {
        RuleFor(p => p.CustomerSourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.CustomerSourceId = phoneNumber);
    }
}
