namespace Application.Common.Enums;

public enum MediumTypes
{
    Web = 1,
    Sms = 2
}
