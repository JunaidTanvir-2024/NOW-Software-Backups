﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class CancelPortingRequestModel
    {
        [Required(ErrorMessage = "RequestID is required to Cancel the request.")]
        public string RequestID { get; set; }
    }
}
