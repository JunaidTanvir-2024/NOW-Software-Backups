using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.AspNetCore.Http;

using Serilog;

using THCC.Application.Interfaces.Services;

using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Services;

internal sealed class CommonService : ICommonService
{
    #region Fields

    private readonly ILogger _logger;
    private readonly IHttpContextAccessor _httpContextAccessor;
    public static readonly string EmailValidation_Regex = @"^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$";
    public static readonly Regex EmailValidation_Regex_Compiled = new(EmailValidation_Regex, RegexOptions.IgnoreCase);
    public static readonly string EmailValidation_Regex_JS = $"/{EmailValidation_Regex}/";

    #endregion

    #region Ctor

    public CommonService( 
        ILogger logger,
        IHttpContextAccessor httpContextAccessor)
    {
        _logger = logger;
        _httpContextAccessor = httpContextAccessor;
    }

    #endregion

    #region Methods

    public bool IsValidEmailAddress(string email, bool useRegEx = false, bool requireDotInDomainName = false)
    {
        try
        {
            var isValid = useRegEx
                     // see RegEx comments
                     ? email is not null && EmailValidation_Regex_Compiled.IsMatch(email)

        // ref.: https://stackoverflow.com/a/33931538/1233379
        : new EmailAddressAttribute().IsValid(email);

            if (isValid && requireDotInDomainName)
            {
                var arr = email?.Split('@', StringSplitOptions.RemoveEmptyEntries);
                isValid = arr?.Length == 2 && arr[1].Contains('.');
            }
            return isValid;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return false;
        }
    }

    public string GetIpAddress()
    {
        try
        {
#pragma warning disable CS8602 // Dereference of a possibly null reference.
            string ipAddress = _httpContextAccessor?.HttpContext?.Connection?.RemoteIpAddress?.ToString()!;
            if (IPAddress.IsLoopback(IPAddress.Parse(ipAddress)))
            {
                ipAddress = Dns.GetHostEntry(Dns.GetHostName())
                    .AddressList
                    .FirstOrDefault(x => x.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    .ToString();
            }
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            return ipAddress;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return "";
        }
    }

    public string GetCardScheme(string cardNumber)
    {
        if (Regex.Match(cardNumber, @"^4[0-9]{12}(?:[0-9]{3})?$").Success)
        {
            return "VISA";
        }

        if (Regex.Match(cardNumber, @"^(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}$").Success)
        {
            return "MASTERCARD";
        }

        if (Regex.Match(cardNumber, @"^3[47][0-9]{13}$").Success)
        {
            return "AMEX";
        }

        if (Regex.Match(cardNumber, @"^6(?:011|5[0-9]{2})[0-9]{12}$").Success)
        {
            return "DISCOVER";
        }

        if (Regex.Match(cardNumber, @"^(?:2131|1800|35\d{3})\d{11}$").Success)
        {
            return "JCB";
        }

        return "N/A";
    }

    public string GetCardMaskedPan(string cardNumber)
    {
        try
        {
            StringBuilder sb_masked = new StringBuilder(cardNumber.Length);
            var lastDigits = cardNumber.Substring(cardNumber.Length - 4, 4);
            for (int i = 0; i < cardNumber.Length - 4; i++)
            {
                if (i < 6)
                {
                    sb_masked.Append(cardNumber[i]);
                }
                else
                {
                    sb_masked.Append('*');
                }
            }
            sb_masked.Append(lastDigits);
            return sb_masked.ToString();
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return cardNumber;
        }
    }

    public string GetHostRequestUrl()
    {
        return $"{_httpContextAccessor.HttpContext!.Request.Scheme}://{_httpContextAccessor.HttpContext.Request.Host}/";
    }

    public string GetOriginRequestUrl()
    {
        return $"{_httpContextAccessor.HttpContext!.Request.Headers.Origin}/";
    }

    #endregion
}