﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Services.Interfaces
{
    public interface IBundleService
    {
        Task<IEnumerable<BundlesCountries>> GetCountriesByBundle();
        Task<IEnumerable<Bundles>> GetBundleByCountry(string ServiceId);
        Task<Bundles> GetBundleById(string Id);
    }
}
