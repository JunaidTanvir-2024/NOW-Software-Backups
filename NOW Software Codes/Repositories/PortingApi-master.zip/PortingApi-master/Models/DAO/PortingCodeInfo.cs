﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.DAO
{
    public class PortingCodeInfo
    {
        public int IsValid { get; set; }
        public string Code { get; set; }
        public CodeTypes CodeType { get; set; }
        public DateTime ExpiryDate { get; set; }
    }
}
