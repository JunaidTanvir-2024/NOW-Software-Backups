﻿namespace Application.Features.Address;

public class AddressRequestHandler : IRequestHandler<AddressRequest, Result<AddressResponseModel>>
{
    private readonly IStringLocalizer<AddressRequestHandler> _localizer;
    private readonly IAddressService _addressService;

    public AddressRequestHandler(
        IStringLocalizer<AddressRequestHandler> localizer,
        IAddressService addressService)
    {
        _localizer = localizer;
        _addressService = addressService;
    }

    public async Task<Result<AddressResponseModel>> Handle(AddressRequest request, CancellationToken cancellationToken)
    {

        if (!String.IsNullOrEmpty(request.PostCode))
        {
            var response = await _addressService.GetAddresses(request.PostCode.Trim());
            if (response == null)
            {
                return Result<AddressResponseModel>.Failure(null!, _localizer[CustomStatusKey.AddressNotFound], CustomStatusCode.AddressNotFound);
            }

            return Result<AddressResponseModel>.Success(response, _localizer[CustomStatusKey.Success]);
        }
        return Result<AddressResponseModel>.Failure(null!, _localizer[CustomStatusKey.AddressNotFound], CustomStatusCode.AddressNotFound);
    }
}
