using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Products;

public class ProductSkuList
{
    [JsonPropertyName("object")]
    public string? Object { get; set; }

    [JsonPropertyName("data")]
    public List<Sku>? Entries { get; set; }
}
