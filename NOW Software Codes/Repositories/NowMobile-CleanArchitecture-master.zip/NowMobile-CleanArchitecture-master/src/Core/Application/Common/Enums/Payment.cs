﻿namespace Application.Common.Enums;

public enum PaymentMethod
{
    Card = 1,
    Paypal,
    Balance,
    Voucher
}

public enum OrderStatus
{
    Create = 1,
    Success,
    Failure,
    Refunded
}

public enum CheckOutType
{
    TopUp = 1,
    Bundle = 2,
    CreditSim = 3,
    TopupBundle = 4,
    TopupSubscriptio=5,
    BundleSubscription=6
}

public enum BasketItemType
{
    TopUp = 1,
    Bundle = 2
}

public enum Currency
{
    GBP
}

public enum ProductItemCode
{
    NOWCRSIM,
    NOW_Bundle,
    NOW_Topup,
    NOWPG
}

public enum ProductCode
{
    NOWPAYG
}

public enum TransactionType
{
    Topup = 1,
    Bundle,
    SIMWithPlan,
    SIMWithCredit,
    SIMWithCreditandPlan,
    TopupBundle
}

public enum Fullfillmenttype
{
    Pay360 = 1,
    Pay360Paypal = 2,
    DirectPaypal = 3
}