using System.Text.Json;
using System.Text.Json.Serialization;

using THCC.Application.Common.Interfaces.Services;

namespace THCC.Infrastructure.Services.Serilizer;

public class JsonSerilizerService : IJsonSerilizerService
{
    /// <summary>
    /// This will use the JsonSerializer class from System.Text.Json to deserialize the
    /// JSON string to an object of type T.
    /// </summary>
    /// <param name="text"></param>
    /// <typeparam name="T"></typeparam>
    /// <returns></returns>
    public T? Deserialize<T>(string text)
    {
        // This will use the JsonSerializer class from System.Text.Json to deserialize the JSON string to an object of type T.
        return JsonSerializer.Deserialize<T>(text);
    }
    /// <summary>
    /// This will use the JsonSerializer class from System.Text.Json to serialize the
    /// object to a JSON string.
    /// </summary>
    /// <param name="obj"></param>
    /// <typeparam name="T"></typeparam>
    /// <returns></returns>
    public string Serialize<T>(T obj)
    {
        // The JsonSerializerOptions object allows you to customize the serialization process, such as using camel case for property names and ignoring null values.It also includes a JsonStringEnumConverter to convert enum values to camel case strings.
        var jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            Converters =
            {
            new JsonStringEnumConverter(JsonNamingPolicy.CamelCase)
            }
        };
        // Serialize method of the JsonSerializer class allows you to specify the type of the object to be serialized, which is useful if you want to serialize an object as a base type or interface.
        return JsonSerializer.Serialize(obj, jsonSerializerOptions);
    }
    /// <summary>
    /// This will use the JsonSerializer class from System.Text.Json to serialize the
    /// object to a JSON string. The JsonSerializerOptions object allows you to
    /// customize the serialization process, but in this case it is not being used as
    /// it is an empty object.
    /// </summary>
    /// <param name="obj"></param>
    /// <param name="type"></param>
    /// <typeparam name="T"></typeparam>
    /// <returns></returns>
    public string Serialize<T>(T obj, Type type)
    {
        // Serialize method of the JsonSerializer class allows you to specify the type of the object to be serialized, which is useful if you want to serialize an object as a base type or interface.
        return JsonSerializer.Serialize(obj, type, new JsonSerializerOptions());
    }
}
