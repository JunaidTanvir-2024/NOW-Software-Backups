﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants;
public static partial class AppEnums
{
    public enum ProductPurchaseType
    {
        Topup = 1,
        Bundle = 2,
        InternetData = 3,
        GiftCard = 4
    }
    public enum TransactionStatus
    {
        Created = 1001,// call back wait
        Cancelled = 1002,// failed
        Rejected = 1003, // failed
        Declined = 1004, // failed
        Completed = 1005,// Success
        Reversed = 1006, // Call back wait--processing
        Confirmed = 1007,// call back wait--processing
        Submitted = 1008// call back wait--processing
    }

}