﻿using Application.Common.Enums;
using Application.Common.Models.ResponseWrappers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Localization;
using System.Text;

namespace NowMobile.Api.Filters;

public class ValidateModelStateAttribute : ActionFilterAttribute
{
    private readonly IStringLocalizer<ValidateModelStateAttribute> _localizer;
    public ValidateModelStateAttribute(IStringLocalizer<ValidateModelStateAttribute> localizer)
    {
        _localizer = localizer;
       
    }
    public override void OnActionExecuting(ActionExecutingContext context)
    {
        if (!context.ModelState.IsValid)
        {
            var errorsData = new Dictionary<string, string>();

            foreach (var keyModelStatePair in context.ModelState)
            {
                var key = keyModelStatePair.Key;
                if (key.Contains('.'))
                {
                    key = key.Split('.').Last();
                }

                var errors = keyModelStatePair.Value.Errors;
                if (errors != null && errors.Count > 0)
                {
                    foreach (var item in errors)
                    {
                        if (!errorsData.ContainsKey(key))
                        {
                            errorsData.Add(key, item.ErrorMessage);
                        }
                    }
                }
            }

            var response = Result<object>.Failure(
                 _localizer.GetString(CustomStatusKey.BadRequest),
                 CustomStatusCode.BadRequest,
                 errorsData
                 );

            context.Result = new JsonResult(response) { StatusCode = 400 };
        }
    }
}
