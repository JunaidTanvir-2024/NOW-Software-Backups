﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Contacts.Requests
{
    public class GetContactPersonRequest : IRequest<IResultWrapper>
    {
        public ContactFilter Contactfilters { get; set; } = new ContactFilter();
        public sealed record ContactFilter
        {
            public string? FirstName { get; set; }
            public string? LastName { get; set; }
            public string? Email { get; set; }
            public string? MobileNo { get; set; }
        }

    }

    public class GetContactPersonRequestValidator : AbstractValidator<GetContactPersonRequest>
    {
        public GetContactPersonRequestValidator()
        {
        }
    }
}