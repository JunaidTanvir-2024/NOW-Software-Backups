﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants;
public static partial class AppEnums
{
    public enum PaymentActionEnum
    {
        [Key("Payment")]
        Payment = 1,
        [Key("Cancel")]
        Cancel = 2,
        [Key("Refund")]
        Refund = 3,
        [Key("PartialRefund")]
        PartialRefund = 4,
        [Key("Resume")]
        Resume = 5,

    }
}
