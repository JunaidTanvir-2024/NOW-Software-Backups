﻿namespace Application.Common.Settings;
public class CancelBundlesSettings
{
    public const string SectionName = "CancelBundlesSettings";
    public static CancelBundlesSettings Bind = new CancelBundlesSettings();
    public decimal VATPercentage { get; set; }
}
