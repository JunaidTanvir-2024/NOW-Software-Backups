﻿using FluentValidation;

namespace Voucherify.Api.Features.Promotions.Requests;

public class DeletePromotionTierRequest
{
    public string PromotionTierId { get; set; } = null!;
}

internal class DeletePromotionTierRequestValidator : AbstractValidator<DeletePromotionTierRequest>
{
    public DeletePromotionTierRequestValidator()
    {
        RuleFor(p => p.PromotionTierId).NotNull().NotEmpty();
    }
}