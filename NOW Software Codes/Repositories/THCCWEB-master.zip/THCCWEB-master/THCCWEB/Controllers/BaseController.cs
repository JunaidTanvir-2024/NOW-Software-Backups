﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using THCCWEB.Models.ApiContracts;
using THCCWEB.Utilities.Extension;

namespace THCCWEB.Controllers
{
    public class BaseController : Controller
    {
        private readonly ILogger _logger;

        public BaseController(ILogger logger)
        {
            _logger = logger;
        }
        public IActionResult HandleErrorResponse<T>(T model, int errorCode, string errorMessage = null)
        {
            _logger.Error($"Class: BaseController, Method: HandleErrorResponse, " +
                                            $"Model: {JsonConvert.SerializeObject(model)}, ErrorCode:{errorCode}, Message:{ errorMessage }");
            switch (errorCode)
            {
                case (int)ApiStatusCodes.InvalidNowtelReferenceOrProduct:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InvalidNowtelReferenceOrProduct" });

                case (int)ApiStatusCodes.UserNotRegistered:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "UserNotRegistered" });

                case (int)ApiStatusCodes.InsufficientBalance:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InsufficientBalance" });

                case (int)ApiStatusCodes.InternalServerError:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });

                case (int)ApiStatusCodes.TopupNumberLimitExceed:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "TopupNumberLimitExceed" });

                case (int)ApiStatusCodes.TopupAmountLimitExceed:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "TopupAmountLimitExceed" });

                case (int)ApiStatusCodes.DenominationsNotAvailable:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "DenominationsNotAvailable" });

                case (int)ApiStatusCodes.DenominationBlocked:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "DenominationBlocked" });

                case (int)ApiStatusCodes.OperatorBlocked:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "OperatorBlocked" });

                case (int)ApiStatusCodes.PaymentServiceError:
                    //TempData.Put("Payment-Service-Error", errorMessage);
                    return RedirectToAction("ErrorMessage", "Home", new { key = "PaymentServiceError" });

                case (int)ApiStatusCodes.DailyLimitExceeded:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "DailyLimitExceeded" });

                case (int)ApiStatusCodes.BundlePurchasedFailed:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "BundlePurchasedFailed" });

                case (int)ApiStatusCodes.BundleLimitExceeded:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "BundleLimitExceeded" });

                case (int)ApiStatusCodes.InvalidBundle:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InvalidBundle" });

                case (int)ApiStatusCodes.DTOneServiceError:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "TransferServiceError" });

                case (int)ApiStatusCodes.TransferNotAuthorized:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "TransferNotAuthorized" });
                case (int)ApiStatusCodes.PaymentUnableToProcess:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "PaymentUnableToProcess" });
                default:
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }
    }
}
