﻿namespace Models.Contracts.PaypalApiContracts
{
	public class PaypalSuspendSubscriptionRequest
	{
		public string SubscriptionId { get; set; } = string.Empty;
	}
}
