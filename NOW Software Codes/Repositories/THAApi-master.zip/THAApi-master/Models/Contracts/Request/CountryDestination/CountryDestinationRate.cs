﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.CountryDestination
{
	public class Rates
	{
		public CountryDestinationRate rate { get; set; }
	}
	public class CountryDestinationRate
	{
		public CountryDestinationRate()
		{
			Rates = new List<CountryDestinationRateDetails>();
		}

		public string Id { get; set; }

		public string Destination { get; set; }

		public string bundlesms { get; set; }

		public bool showOffpeak { get; set; }

		public string bundlesmstitle { get; set; }

		public List<CountryDestinationRateDetails> Rates { get; set; }

		public string FlagImageUrl { get; set; }
	}

	public class CountryDestinationRateDetails
	{
		public string Name { get; set; }

		public string Price { get; set; }

		public string offpeakPrice { get; set; }

	}
}
