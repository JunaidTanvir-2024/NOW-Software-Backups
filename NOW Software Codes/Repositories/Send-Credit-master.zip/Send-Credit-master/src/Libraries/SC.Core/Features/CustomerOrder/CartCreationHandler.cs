﻿using MapsterMapper;

using MediatR;
using SC.Core.Common.Definitions.Enums;
using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.CustomerOrder.Responses;
using SC.Core.Features.Products;
using SC.Core.Features.Products.Requests;
using SC.Core.Features.Products.Responses;
using SC.Core.Vendors.FusionHub;

using Sentry;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder;

internal sealed class CartCreationHandler : IRequestHandler<CartCreationRequest, IResultWrapper>
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly ICommonService _commonService;
    private readonly ICustomerOrderService _customerOrderService;
    private readonly IFusionHubService _fusionHubService;
    private readonly IMapper _mapper;
    private readonly ISystemConfigurationRepository _systemConfigurationRepository;

    public CartCreationHandler(ICustomerCartRespository customerCartRespository, ICommonService commonService
                        , ICustomerOrderService customerOrderService, IFusionHubService fusionHubService, IMapper mapper, ISystemConfigurationRepository systemConfigurationRepository)
    {
        _customerCartRespository = customerCartRespository;
        _commonService = commonService;
        _customerOrderService = customerOrderService;
        _fusionHubService = fusionHubService;
        _mapper = mapper;
        _systemConfigurationRepository = systemConfigurationRepository;
    }

    public async Task<IResultWrapper> Handle(CartCreationRequest request, CancellationToken cancellationToken)
    {
        string GuestUserID = string.Empty;
        bool IsGuestCreated = false;
        if (request.IsGuestUser && string.IsNullOrEmpty(request.UserID))
        {
            var result = await _customerCartRespository.CreateGuestUserAsync();
            if (string.IsNullOrEmpty(result))
                return ResultWrapper.Failure(AppConstants.StatusKeys.GuestUserCreationError, 404);
            GuestUserID = result;
            IsGuestCreated = true;
        }
        string Order_userID = string.Empty;
        if (IsGuestCreated)
            Order_userID = GuestUserID;
        else if (request.IsGuestUser && !string.IsNullOrEmpty(request.UserID))
            Order_userID = request.UserID;
        else
            Order_userID = _commonService.GetUserID();

        if (string.IsNullOrEmpty(Order_userID))
            return ResultWrapper.Failure(AppConstants.StatusKeys.UserNotProvided, 404);
        // Get Customer Previous pending order
        long CustomerOrderID = 0;
        decimal CustomerOrderPrice = 0;
        //GetCustomerOrderDto? Order = await GetCustomerExistingInitializedOrder(Order_userID);
        CustomerOrderDetailDto? Order = await GetCustomerOrderDetail(Order_userID);
        CustomerOrderID = Order != null ? Order.CustomerOrderID : CustomerOrderID;
        // Create Customer Cart
        if (CustomerOrderID == 0)
            CustomerOrderID = await CreateCustomerOrder(request, Order_userID);
        if (CustomerOrderID == 0)
        {
            return ResultWrapper.Failure(AppConstants.StatusKeys.OrderCreationError, 404);
        }

        var getProductRequest = new GetProductsRequest()
        {
            Page = 1,
            RecordsPerPage = 200,
            Filters = new Common.Model.Filter() { ProductId = (int)request.ProductID }
        };

        var productresponse = await _fusionHubService.GetProductAsync(getProductRequest);
        if (productresponse?.Payload == null)
        {
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
        }
        var productResult = _mapper.Map<List<GetProductsResponse>>(productresponse.Payload);

        string productName = string.Empty;
        string currencyCode = string.Empty;
        string productType = string.Empty;

        decimal? productPrice = 0;
        if (productResult == null || productResult.Count == 0)
            return ResultWrapper.Failure(AppConstants.StatusKeys.ProductCommonFailureMessage, 404);        

        productName = productResult.First().Product.ProductName!;
        currencyCode = productResult.First().Product.ProductCurrency?.CurrencyCode!;
        productType = productResult.First().Product.ProductType!;

        ProductType _productType = GetProductType(productType);        
        if (_productType == ProductType.Ranged)
        {           
            //checking if the ranged productPrice value is in the range of fetched product min price and max price
            if (request.ProductPrice < productResult.First().Product.ProductPrice?.MaxPrice ||
                request.ProductPrice > productResult.First().Product.ProductPrice?.MinPrice)
            {
                return ResultWrapper.Failure(AppConstants.StatusKeys.InvalidProductInCart, 400);
            }
            productPrice = request.ProductPrice;
        }
        else
        {            
            if (productResult.First().Product.ProductPrice?.SellingPrice < request.ProductPrice)
            {
                return ResultWrapper.Failure(AppConstants.StatusKeys.InvalidProductInCart, 400);
            }
            productPrice = productResult.First().Product.ProductPrice?.SellingPrice;
        }

        #region validation
        (bool isValid, string message) = await ValidateOrderLimitConfiguration(Order, productResult.First(), Order_userID,(decimal)productPrice);
        if (!isValid)
            return ResultWrapper.Failure(message, 404);
        #endregion
       

        decimal serviceFeeAmount = await _customerOrderService.CalculateServiceFeeAmount(productType, productPrice);
        if ((request.ProductPrice + serviceFeeAmount) < productPrice)
        {
            return ResultWrapper.Failure(AppConstants.StatusKeys.InvalidProductInCart, 400);
        }

        var cart = new CartCreationDto()
        {
            CustomerCartID = request.CustomerCartID,
            CustomerOrderID = CustomerOrderID,
            DiscountType = AppEnums.DiscountTypeEnum.FlatItem.Getkey(),// will be set later
            DiscountAmount = request.DiscountAmount,
            ProductID = request.ProductID,
            ProductName = productName,
            Quantity = 1,
            Price = (decimal)productPrice!,
            Status = AppEnums.CartItemStatus.Active.Getkey(),
            Currency = request.Currency,
            State = AppEnums.CartItemState.Cart.Getkey(),
            isDeleted = false,
            isActive = true,
            CustomerID = Order_userID,
            ServiceFeeAmount = serviceFeeAmount,
            ProductPriceType = _productType.ToString(),
            ProductPrice = request.ProductPrice
        };
        var cartID = await _customerCartRespository.CartCreationAsync(cart);
        CustomerOrderPrice = await _customerOrderService.CalculateCustomerOrderPrice(Order_userID);

        CartCreationResponse response = new CartCreationResponse()
        {
            CartID = cartID,
            TotalOrderPrice = CustomerOrderPrice,
            UserID = Order_userID
        };
        return ResultWrapper.Success(response);
    }
    private async Task<(bool isValid, string message)> ValidateOrderLimitConfiguration(CustomerOrderDetailDto? orderDetail, GetProductsResponse productresult, string userID,decimal productPrice)
    {
        bool IsValid = true;
        decimal todayCompletedOrderAmount = 0;
        decimal currentOrderTotalAmount = orderDetail != null && orderDetail!.CustomerOrderID > 0 ? orderDetail.TotalOrderAmount : 0;
        string message = string.Empty;
        string productCategory = string.Empty;
        string productSubCategory = string.Empty;
        string currencyCode = string.Empty;
        //decimal? productPrice = 0;
        var orderLimitconfiguration = await _systemConfigurationRepository.GetOrderLimitConfigurationAsync(currencyCode);
        todayCompletedOrderAmount = await _customerCartRespository.GetTotalOrderAmountPerDay(userID, OrderStatusEnum.Checkout.Getkey(), DateTime.UtcNow);
        if (orderLimitconfiguration == null)
            return (true, string.Empty);
        productCategory = productresult.Product.ProductCategory.CategoryName!;
        productSubCategory = productresult.Product.ProductSubCategory.SubCategoryName!;
        currencyCode = productresult.Product.ProductCurrency?.CurrencyCode!;
        //productPrice = productresult.Product.ProductPrice?.SellingPrice != null ? productresult.Product.ProductPrice?.SellingPrice : productPrice;

        if (orderDetail != null && orderDetail.CustomerOrderID > 0)
        {
            int occurrences = orderDetail.CartDetail.Count(item => item.ProductId == productresult.Product.ProductId);
            if (occurrences >= orderLimitconfiguration!.ProductRepeatedInOrder)
            {
                IsValid = false;
                message = string.Format(AppConstants.StatusKeys.ProductRepeatedInOrder, orderLimitconfiguration.ProductRepeatedInOrder);
                return (IsValid, message);
            }
        }

        if (productCategory == "Gift Cards" && orderLimitconfiguration != null && productPrice > orderLimitconfiguration.GiftCardMaxValue)
        {
            IsValid = false;
            message = string.Format(AppConstants.StatusKeys.MaximumAllowedGiftCard, orderLimitconfiguration.GiftCardMaxValue);
            return (IsValid, message);
        }

        if (productCategory == "Mobile" && productSubCategory == "Airtime" && orderLimitconfiguration != null && productPrice > orderLimitconfiguration.MobileTopUpMaxValue)
        {
            IsValid = false;
            message = string.Format(AppConstants.StatusKeys.MaximumAllowedMobileTopup, orderLimitconfiguration.MobileTopUpMaxValue);
            return (IsValid, message);
        }
        if (productCategory == "Mobile" && productSubCategory == "Airtime" && orderLimitconfiguration != null && productPrice > orderLimitconfiguration.MobileTopUpMaxValue)
        {
            IsValid = false;
            message = string.Format(AppConstants.StatusKeys.MaximumAllowedMobileTopup, orderLimitconfiguration.MobileTopUpMaxValue);
            return (IsValid, message);
        }
        if (orderLimitconfiguration != null && (currentOrderTotalAmount + productPrice) > orderLimitconfiguration.PerTransactionOrderMaxValue)
        {
            IsValid = false;
            message = string.Format(AppConstants.StatusKeys.PerOrderMaxValue, orderLimitconfiguration.PerTransactionOrderMaxValue);
            return (IsValid, message);
        }
        if (orderLimitconfiguration != null && (todayCompletedOrderAmount + currentOrderTotalAmount + productPrice) > orderLimitconfiguration.CustomerPerDayOrderMaxValue)
        {
            IsValid = false;
            message = string.Format(AppConstants.StatusKeys.PerOrderMaxValuePerDay, orderLimitconfiguration.CustomerPerDayOrderMaxValue);
            return (IsValid, message);
        }







        return (IsValid, message);

    }

    private async Task<GetCustomerOrderDto> GetCustomerExistingInitializedOrder(string UserID)
    {
        return await _customerCartRespository.GetCustomerOrder(UserID, AppEnums.OrderStatusEnum.Init.Getkey());
    }
    private async Task<CustomerOrderDetailDto> GetCustomerOrderDetail(string UserID)
    {
        return await _customerCartRespository.GetCustomerOrderDetail(UserID, AppEnums.OrderStatusEnum.Init.Getkey());

    }

    private async Task<long> CreateCustomerOrder(CartCreationRequest request, string UserID)
    {
        var order = new OrderCreationDto()
        {
            CustomerOrderID = 0,
            PromoCode = "",// discussion pending about this value
            DiscountTypeId = null,// AppEnums.DiscountTypeEnum.FlatOrder.Getkey(),// discussion pending about this value
            DiscountAmount = 0,// discussion pending about this value
            ServiceFee = 0,// discussion pending about this value
            TaxAmount = 0,// discussion pending about this value
            TaxInclusiveAmount = 0,// discussion pending about this value
            TaxExclusiveAmount = 0,// discussion pending about this value
            TotalOrderAmount = 0,// discussion pending about this value
            Currency = string.IsNullOrEmpty(request.Currency) ? _commonService.GetDefaultCurrency() : request.Currency,
            OrderStatus = OrderStatusEnum.Init.Getkey(),
            isDeleted = false,
            isActive = true,
            UserID = UserID,
            RequestId = _commonService.GetRequestID()
        };
        var orderID = await _customerCartRespository.OrderCreationAsync(order);
        return orderID;
    }       
    private ProductType GetProductType(string productType)
    {
        return productType == "True" ? ProductType.Ranged : ProductType.Fixed;
    }
}