using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.EntityFrameworkCore;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;

public class SubscriptionRepository(AppDbContext context, ILogger logger) : ISubscriptionRepository
{
	private readonly AppDbContext _context = context;
	private readonly ILogger _logger = logger;

	public async Task<Subscription> AddSubscription(Subscription subscription)
	{
		try
		{
			var addedSubscription = await _context.Set<Subscription>().AddAsync(subscription);
			return addedSubscription.Entity;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(SubscriptionRepository), nameof(AddSubscription));
			return default!;
		}
	}
	public async Task AddSubscriptionBenefits(IEnumerable<SubscriptionBenefit> subscriptionBenefits)
	{
		try
		{
			await _context.Set<SubscriptionBenefit>().AddRangeAsync(subscriptionBenefits);
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(SubscriptionRepository), nameof(AddSubscriptionBenefits));
		}
	}
	public void UpdateSubscription(Subscription subscription)
	{
		try
		{
			_context.Entry(subscription).CurrentValues.SetValues(subscription);
			_context.Entry(subscription).State = EntityState.Modified;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(SubscriptionRepository), nameof(UpdateSubscription));
		}
	}
	public async Task<Subscription?> GetSubscription(Expression<Func<Subscription, bool>> expression)
	{
		try
		{
			return await _context.Set<Subscription>()
				.Where(expression)
				.Include(x => x.Benefits)
				.FirstOrDefaultAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(SubscriptionRepository), nameof(GetSubscription));
			return default!;
		}
	}
	public async Task<IEnumerable<Subscription>> GetSubscriptionList()
	{
		try
		{
			return await _context.Set<Subscription>()
				.Where(x => x.IsActive == true)
				.Include(x => x.Benefits)
				.ToListAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(SubscriptionRepository), nameof(GetSubscriptionList));
			return default!;
		}
	}
}
