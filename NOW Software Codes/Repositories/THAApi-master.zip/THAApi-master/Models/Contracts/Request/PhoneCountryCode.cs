﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class PhoneIsoCode
    {
        public string msisdn { get; set; }
        public string IsoCode { get; set; }
    }

    public class IsoCodeCount
    {
        public string IsoCode { get; set; }
        public int Count { get; set; }
    }

}
