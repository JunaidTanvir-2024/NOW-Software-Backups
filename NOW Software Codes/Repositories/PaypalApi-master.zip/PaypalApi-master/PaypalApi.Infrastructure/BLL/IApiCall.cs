﻿using PaypalApi.Models.Contracts.Request.Api;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PaypalApi.Infrastructure.BLL
{
    public interface IApiCall
    {
        Task<HttpResponseMessage> Get(string Uri, TokenType authTokenType, string authToken, params string[] parameters);
        Task<HttpResponseMessage> Post(string Uri, TokenType authTokenType, string authToken, object postDataModel);
        Task<HttpResponseMessage> PostUrlEncoded(string Uri, TokenType authTokenType, string authToken, List<KeyValuePair<string, string>> postDataModel);
    }
}
