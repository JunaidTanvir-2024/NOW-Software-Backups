using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;
using FH.Core.Interfaces.Vendors;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;

namespace FH.UseCases.Products;

public static class GetProductStatus
{
	#region Query

	public sealed record Query : IRequest<IResultWrapper>
	{
		public required IEnumerable<long> ProductIds { get; set; }
	}

	#endregion

	#region Validator

	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.ProductIds).NotEmpty().NotNull();
		}
	}

	#endregion

	#region Response

	public sealed record Response
	{
		public required string IsActive { get; set; }
		public required ProductInfo Product { get; set; }
		public sealed record ProductInfo
		{
			public long Id { get; set; }
			public required string VendorCode { get; set; }
			public required string NameAlias { get; set; }
			public required OperatorInfo Operator { get; set; }
			public required CategoryInfo Category { get; set; }
			public required SubCategoryInfo SubCategory { get; set; }
			public sealed record OperatorInfo
			{
				public required long Id { get; set; }
				public required string NameAlias { get; set; }
			}
			public sealed record CategoryInfo
			{
				public required long Id { get; set; }
				public required string Name { get; set; }
			}
			public sealed record SubCategoryInfo
			{
				public required long Id { get; set; }
				public required string Name { get; set; }
			}
		}
	}
	#endregion

	#region Handler
	internal sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork, IDTOneService dTOneService, IReloadlyService reloadlyService) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IMapper _mapper = mapper;
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		private readonly IDTOneService _dTOneService = dTOneService;
		private readonly IReloadlyService _reloadlyService = reloadlyService;

		async ValueTask<IResultWrapper> IRequestHandler<Query, IResultWrapper>.Handle(Query request, CancellationToken cancellationToken)
		{
			var productStatuses = await _unitOfWork.ProductRepository.CheckProductsAvailability(new ProductStatusDto.Request()
			{
				ProductIds = request.ProductIds
			});

			//if (productStatuses?.Any() is true)
			//{
			//    foreach (var product in productStatuses)
			//    {
			//        if (product.VendorId == (int)AppEnums.Vendor.DTOne)
			//        {
			//            //var status = _dTOneService.
			//        }

			//    }
			//}

			if (productStatuses is null)
			{
				return ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
			}

			var availableProducts = productStatuses.Select(x => new Response()
			{
				IsActive = x.IsActive,
				Product = new Response.ProductInfo()
				{
					Id = x.ProductId,
					VendorCode = x.ProductVendorCode,
					NameAlias = x.ProductNameAlias,
					Operator = new Response.ProductInfo.OperatorInfo()
					{
						Id = x.OperatorId,
						NameAlias = x.OperatorNameAlias
					},
					Category = new Response.ProductInfo.CategoryInfo()
					{
						Id = x.ProductCategoryId,
						Name = x.ProductCategory
					},
					SubCategory = new Response.ProductInfo.SubCategoryInfo()
					{
						Id = x.ProductSubcategoryId,
						Name = x.ProductSubcategory
					}
				}
			});
			return ResultWrapper.Success(availableProducts);
		}
	}
	#endregion
}
