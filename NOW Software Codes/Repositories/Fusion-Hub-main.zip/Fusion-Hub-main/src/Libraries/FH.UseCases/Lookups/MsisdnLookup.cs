using FH.Core.DTOs.Vendors.DTOne;
using FH.Core.Interfaces.Vendors;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;

namespace FH.UseCases.Lookups;
public sealed class MsisdnLookup
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public required string Msisdn { get; set; }
		public int Vendor { get; set; }
	}

	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.Msisdn).NotNull().NotEmpty();
		}
	}

	#endregion

	#region Response
	public sealed record Response
	{
		public OperatorInfo Operator { get; set; } = null!;
		public CountryInfo Country { get; set; } = null!;

		public sealed record OperatorInfo
		{
			public long Id { get; set; }
			public string? Name { get; set; }
		}
		public sealed record CountryInfo
		{
			public long Id { get; set; }
			public string? Name { get; set; }
			public string? IsoCode { get; set; }
		}
	}

	#endregion

	#region Handler
	internal sealed class Handler(IDTOneService dTOneService, IMapper mapper) : IRequestHandler<Query, IResultWrapper>
	{
		public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
		{
			var result = await dTOneService.MsisdnLookup(new LookupMsisdnOperator.Request
			{
				Msisdn = request.Msisdn,
				Vendor = request.Vendor,
			});

			if (result is not null)
			{
				var response = mapper.Map<Response>(result);

				return ResultWrapper.Success(response);
			}

			return ResultWrapper.Failure("Operator info not found", 404);
		}
	}
	#endregion
}
