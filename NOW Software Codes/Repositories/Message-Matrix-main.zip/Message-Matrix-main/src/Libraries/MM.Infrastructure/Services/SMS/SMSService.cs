using Twilio.Rest.Api.V2010.Account;
using Twilio;
using MM.Core.Common.Definitions.Enums;
using Twilio.TwiML.Messaging;
using MM.Core.Common.DTOs;
using System;
using MM.Core.Common.Interfaces.Database;
namespace MM.Infrastructure.Services.SMS;


public class SMSService : ISMSService
{
    private readonly ILogger _logger;
    private readonly ISmsLogRepository _messageLogRepository;
    private readonly PhishingSetting _phishingSetting;
    private readonly SMSServiceSetting _sMSServiceSetting;
    private readonly SmsMarketing _smsMarketing;


    public SMSService(ILogger logger,
        IOptions<SMSServiceSetting> sMSServiceSetting, IOptions<SmsMarketing> smsMarketing, ISmsLogRepository messageLogRepository, IOptions<PhishingSetting> phishingSetting)
    {
        _logger = logger;
        _messageLogRepository = messageLogRepository;
        _phishingSetting = phishingSetting.Value;
        _sMSServiceSetting = sMSServiceSetting.Value;
        _smsMarketing = smsMarketing.Value;

    }

    public async Task<bool> SendMarketingSms(SmsRequestDTO smsRequest)
    {
        string Url = $"{_smsMarketing.ApiUrl}?username={_smsMarketing.Username}&password={_smsMarketing.Password}&from={_smsMarketing.From}&to={smsRequest.To}&text={smsRequest.TextMessage}";

        var IsActive = false;
        using (HttpClient client = new HttpClient())
        {
            var messageLog = new MessageLog
            {
                Receiver = smsRequest.To,
                Sender = _smsMarketing.From,
                Message = smsRequest.TextMessage,
                CurrentTime = DateTime.UtcNow,
                Guid = Guid.NewGuid(),
                CreatedBy = "MM SMS Service",
                TransactionId = Guid.NewGuid().ToString(),
                MessageSid = Guid.NewGuid().ToString(),

            };

            try
            {
                HttpResponseMessage response = await client.GetAsync(Url);

                if (response.IsSuccessStatusCode)
                {
                    IsActive = true;
                }
                else
                {
                    IsActive = false;
                    messageLog.MessageError=($"Failed to send SMS. Status Code: {response.IsSuccessStatusCode}");
                }
                messageLog.MessageStatus = IsActive;
            }
            catch (Exception ex)
            {
                messageLog.MessageError = ex.ToString();
            }
            await _messageLogRepository.InsertSmsLog(messageLog);
        }
        return IsActive;
    }
    public async Task<bool> SendTwilioSms(SmsRequestDTO twilioSmsRequest)
    {
        bool isSmsSent = default;
        Twilio.Types.PhoneNumber from;

        // Normalize the recipient number
        twilioSmsRequest.To = NormalizePhoneNumber(twilioSmsRequest.To);

        // Check if it's a restricted country and update the 'from' number if necessary
        bool isRestrictedCountry = IsRestrictedCountry(twilioSmsRequest.To, _sMSServiceSetting.TwilioFromNumberCountries);

        // Ensure the 'to' number is in international format
        twilioSmsRequest.To = EnsureInternationalFormat(twilioSmsRequest.To);

        // Determine the 'fromText' based on 'ProductCode'
        string fromText = GetFromText(twilioSmsRequest);

        // Try sending the SMS
        try
        {
            bool isLimitExceed = await _messageLogRepository.GetMessageSent(_phishingSetting.SmsLimit, _phishingSetting.SmsTimeLimitSec, _sMSServiceSetting.TwilioNumber);
            if (!isLimitExceed)
            {
                TwilioClient.Init(_sMSServiceSetting.Sid, _sMSServiceSetting.AuthToken);

                from = isRestrictedCountry ? new Twilio.Types.PhoneNumber(_sMSServiceSetting.TwilioNumber) : null!;

                MessageResource? message = await SendMessageAsync(twilioSmsRequest, from, fromText);
                var phoneNumber = message.From;
                var errorCode = message.ErrorCode;
                var errorMessage = message.ErrorMessage;
                MessageResource.StatusEnum? status = message.Status;

                if (nameof(status).Equals("canceled", StringComparison.InvariantCultureIgnoreCase) ||
                    nameof(status).Equals("failed", StringComparison.InvariantCultureIgnoreCase))
                {
                    isSmsSent = false;
                }
                else
                {
                    isSmsSent = true;

                }
                HandleSendTwilioSmsRequestResponse(twilioSmsRequest, message, Convert.ToString(from), fromText);

                var smsLogDTo = new MessageLog
                {
                    Receiver = message.To,
                    Message = message.Body,
                    MessageSid = message.Sid,
                    TransactionId = message.MessagingServiceSid ?? "23434",
                    MessageError = message.ErrorMessage,
                    MessageStatus = isSmsSent,
                    Sender = message.From.ToString(),
                    CurrentTime = DateTime.UtcNow,
                    Guid = Guid.NewGuid(),
                };

                await _messageLogRepository.InsertSmsLog(smsLogDTo);
                return isSmsSent;
            }
            return isSmsSent;
        }
        catch (Exception ex)
        {
            HandleSendTwilioSmsException(twilioSmsRequest, ex);
            return isSmsSent;
        }
    }

    private string NormalizePhoneNumber(string phoneNumber)
    {
        return phoneNumber.StartsWith("00") ? phoneNumber.Substring(2) : phoneNumber;
    }

    private bool IsRestrictedCountry(string phoneNumber, IEnumerable<string> restrictedCountries)
    {
        if (restrictedCountries != null && restrictedCountries.Count() > 0)
            return restrictedCountries.Any(item => phoneNumber.StartsWith(item));
        else
            return false;

    }

    private string EnsureInternationalFormat(string phoneNumber)
    {
        if (!phoneNumber.StartsWith("+"))
        {
            phoneNumber = "+" + phoneNumber;
        }
        return phoneNumber;
    }

    private string GetFromText(SmsRequestDTO twilioSmsRequest)
    {


        if (!string.IsNullOrWhiteSpace(twilioSmsRequest.ProductCode))
        {
            return twilioSmsRequest.ProductCode == FromTextEnum.TRH.ToString() ? FromTextEnum.TransHome.ToString() : FromTextEnum.TalkHome.ToString();
        }
        return FromTextEnum.TransHome.ToString();
    }
    // REMOVE THIS, CREATE ENUM and get code from the enum 
    private async Task<MessageResource> SendMessageAsync(SmsRequestDTO twilioSmsRequest, Twilio.Types.PhoneNumber from, string fromText)
    {
        var message = await MessageResource.CreateAsync(
            body: twilioSmsRequest.TextMessage,
            from: from != null ? from : fromText,
            to: new Twilio.Types.PhoneNumber(twilioSmsRequest.To));

        return message;

    }

    private void HandleSendTwilioSmsException(SmsRequestDTO twilioSmsRequest, Exception ex)
    {
        string requestParameters = $"to: {twilioSmsRequest.To}, textMessage: {twilioSmsRequest.TextMessage},productCode: {twilioSmsRequest.ProductCode}";
        _logger.Error($"DingPost_BL - Method: SendTwilioSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
    }
    private void HandleSendTwilioSmsRequestResponse(SmsRequestDTO twilioSmsRequest, MessageResource? message, string from, string fromText)
    {
        string requestParameters = $"to: {twilioSmsRequest.To}, textMessage: {twilioSmsRequest.TextMessage}, productCode: {twilioSmsRequest.ProductCode},from: {from}, fromText: {fromText}";
        _logger.Error($"DingPost_BL - Method: SendTwilioSms, Parameters --> {requestParameters}, Response: {message}");
    }

}


