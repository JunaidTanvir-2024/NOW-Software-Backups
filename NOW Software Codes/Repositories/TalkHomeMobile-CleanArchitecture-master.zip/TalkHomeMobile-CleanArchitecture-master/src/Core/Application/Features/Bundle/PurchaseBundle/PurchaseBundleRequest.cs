﻿namespace Application.Features.Bundle.PurchaseBundle;

public class PurchaseBundleRequest
{
    public string BundleId { get; set; } = default!;
    public string Msisdn { get; set; }= default!;
    public bool IsAutoRenew { get; set; }
    public long UserId { get; set; }
    public string AccountId { get; set; } = default!;
    public string UserEmail { get; set; } = default!;
}
