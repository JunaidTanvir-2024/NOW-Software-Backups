﻿using Application.Features.Payment.Card.Models;


namespace Application.Features.Payment.Card.AddCard;
public class AddCardRequest : IRequest<Result<CardResponse>>
{
    public string? Msisdn { get; set; }
    public PaymentNewCardInfo PaymentCardInfo { get; set; } = default!;

    public PaymentAddressInfo PaymentAddressInfo { get; set; } = default!;

    [JsonIgnore]
    public string? Email { get; set; }

    [JsonIgnore]
    public string? IpAddress { get; set; }
   
}
public class AddCardRequestValidator : AbstractValidator<AddCardRequest>
{
    public AddCardRequestValidator()
    {
        RuleFor(p => p.PaymentCardInfo.CardNumber).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MaximumLength(19);
        RuleFor(p => p.PaymentCardInfo.ExpiryMonth).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(2).MaximumLength(2);
        RuleFor(p => p.PaymentCardInfo.ExpiryYear).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(2).MaximumLength(2);
        RuleFor(p => p.PaymentCardInfo.NameOnCard).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.PaymentCardInfo.SecurityCode).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(3).MaximumLength(4);

        RuleFor(p => p.PaymentAddressInfo.AddressL1).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.PaymentAddressInfo.City).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.PaymentAddressInfo.PostCode).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.PaymentAddressInfo.CountryCode).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
    }
}

