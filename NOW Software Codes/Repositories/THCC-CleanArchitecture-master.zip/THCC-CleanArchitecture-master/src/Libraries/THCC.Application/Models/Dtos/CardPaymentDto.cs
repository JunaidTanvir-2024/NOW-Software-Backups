﻿namespace THCC.Application.Models.Dtos;

public class CardPaymentRequestDto
{
    public PaymentExistingCardDto? PaymentExistingCardInfo { get; set; }
    public PaymentNewCardDto? PaymentNewCardInfo { get; set; }
    public PaymentDefaultCardDto? PaymentDefaultCardInfo { get; set; }
    public PaymentAddressDto? Address { get; set; }
    public string Email { get; set; } = default!;
    public string IpAddress { get; set; } = default!;
    public bool IsRecurring { get; set; }
    public string? CardPin { get; set; }
    public string? CardNumber { get; set; }
    public decimal Amount { get; set; } = default!;
    public ProductType TransactionType { get; set; }
}

public class CardPaymentResponseDto
{
    public bool Require3dSecure { get; set; }
    public ThreeDSecureDataDto? ThreeDSecureData { get; set; }
    public string? TransactionId { get; set; }
    public bool IsRecurring { get; set; }
    public bool IsSuccess { get; set; }
    public int ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }
}

public class ThreeDSecureDataDto
{
    public string? ReturnUrl { get; set; }
    public string? RedirectUrl { get; set; }
    public string? Pareq { get; set; }
    public string? TransactionId { get; set; }
    public string? Type { get; set; }
    public string? ThreeDSServerTransId { get; set; }
}