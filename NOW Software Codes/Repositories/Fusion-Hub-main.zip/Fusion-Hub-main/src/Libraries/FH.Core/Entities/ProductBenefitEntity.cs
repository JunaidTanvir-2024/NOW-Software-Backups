namespace FH.Core.Entities;
public sealed record ProductBenefitEntity : BaseEntity<long>
{
    public required string DataDumpReference { get; set; }
    public string? Description { get; set; }
    public decimal? BenefitWithTax { get; set; }
    public decimal? BenefitWithoutTax { get; set; }
    public decimal? RangeMinBenefitWithTax { get; set; }
    public decimal? RangeMaxBenefitWithTax { get; set; }
    public decimal? RangeMinBenefitWithoutTax { get; set; }
    public decimal? RangeMaxBenefitWithoutTax { get; set; }
    public string? Unit { get; set; }
    public string? BenefitType { get; set; }
    public string? UnitType { get; set; }
    public long ProductId { get; set; }
}
