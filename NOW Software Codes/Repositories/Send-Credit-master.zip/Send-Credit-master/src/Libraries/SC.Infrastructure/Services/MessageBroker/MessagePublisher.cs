﻿using MassTransit;
using SC.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MessageBrokerModel;

namespace SC.Infrastructure.Services.MessageBroker;
internal class MessagePublisher(IBus bus, MessageBrokerDbContext messageBrokerDbContext) : IMessagePublisher
{
    private readonly IBus _bus = bus;
    private readonly MessageBrokerDbContext _messageBrokerDbContext = messageBrokerDbContext;

    public async Task PublishMessage(TransactionMessageDto message)
    {
        await _bus.Publish(message);
       var response= await _messageBrokerDbContext.SaveChangesAsync();
    }
}

