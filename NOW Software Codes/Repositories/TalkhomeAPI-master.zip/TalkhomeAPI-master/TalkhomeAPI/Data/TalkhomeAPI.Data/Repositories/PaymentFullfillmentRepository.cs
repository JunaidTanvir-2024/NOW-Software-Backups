﻿using Dapper;
using Microsoft.Extensions.Options;
using PaymentsApi.Infrastructure.DAL.Database;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.DbConnections;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Pay360ApiContracts;

namespace TalkhomeAPI.Data.Repositories
{
    public class PaymentFullfillmentRepository : IPaymentFullfillmentRepository
    {
        private readonly ILogger _logger;
        private readonly IDbConnectionSettings ThaConnection;
        private readonly IDbConnectionSettings DigiTalkDbConnection;
        private readonly IDbConnectionSettings ThaDbConnection;

        public PaymentFullfillmentRepository(ILogger logger, IOptions<ConnectionString> connectionString)
        {
            _logger = logger;
            ThaConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThaConnection));
            DigiTalkDbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigitalkDbConnection));
            ThaDbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppDbConnection));
        }

        public async Task<FullfilmentResponse> ThaPay360cardCustomerFullfilment(string msisdn, decimal amount, string ccsTransId, string ccAuthCode, string bundleRef)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@amount", amount);
                parameters.Add("@reference", ccsTransId);
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@ccAuthCode", ccAuthCode);
                parameters.Add("@bundlename", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
                parameters.Add("@error_code", null, DbType.Int32, ParameterDirection.Output);
                parameters.Add("@error_msg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 255);


                var result = await ThaConnection.SqlConnection.QueryFirstOrDefaultAsync<AccountBalance>("tha_account_update_topup_add_bundle_pay_360", parameters, commandType: CommandType.StoredProcedure);
                //if (result != null && result.audit_id > 0) // Fullfilment Successfull

                int errorCode = parameters.Get<int>("@error_code");
                if (errorCode == 0) // Fullfilment Successfull
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.audit_id = result.audit_id;
                    response.Audit = new THRCCAudit() { audit_id = result.audit_id, new_balance = Convert.ToDecimal(result.new_balance) };
                    response.BundleName = parameters.Get<string>("@bundlename");
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = parameters.Get<string>("@error_msg");
                    response.audit_id = 0;
                }

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: DL_Pay360, Method: ThaCustomerFullfilment, Parameters=> msisdn: {msisdn}, bundleRef: {bundleRef}, amount: {amount}, ccsTransId: {ccsTransId}, ccAuthCode: {ccAuthCode}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
            }
            return response;

        }
        public async Task<FullfilmentResponse> ThaPay360paypalStraightCustomerFullfilment(string transactionId, string bundleRef, decimal amount, string productRef)
        {


            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@amount", amount);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@ccAuthCode", transactionId);
                parameters.Add("@bundlename", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
                parameters.Add("@error_code", null, DbType.Int32, ParameterDirection.Output);
                parameters.Add("@error_msg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

                var result = await ThaConnection.SqlConnection.QueryAsync<THRCCAudit>("tha_paypal_account_update_balance_add_bundle_v1", parameters, commandType: CommandType.StoredProcedure);
                int errorCode = parameters.Get<int>("@error_code");
                if (errorCode == 0) // Fullfilment Successfull
                {
                    var audit = result.FirstOrDefault();
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Audit = audit;
                    response.BundleName = parameters.Get<string>("@bundlename");
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "Topup failed";
                    response.Audit = null;
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = "Fullfilment failed";
                _logger.Error($"Class: DL_Paypal, Method: ThaStraightCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }
        public async Task<FullfilmentResponse> ThaDirectPaypalStraightCustomerFullfilment(string transactionId, string bundleRef, decimal amount, string productRef)
        {


            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@amount", amount);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@ccAuthCode", transactionId);
                parameters.Add("@bundlename", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
                parameters.Add("@error_code", null, DbType.Int32, ParameterDirection.Output);
                parameters.Add("@error_msg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

                var result = await DigiTalkDbConnection.SqlConnection.QueryAsync<THRCCAudit>("tha_paypal_account_update_balance_add_bundle_v1", parameters, commandType: CommandType.StoredProcedure);
                int errorCode = parameters.Get<int>("@error_code");
                if (errorCode == 0) // Fullfilment Successfull
                {
                    var audit = result.FirstOrDefault();
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Audit = audit;
                    response.BundleName = parameters.Get<string>("@bundlename");
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "Topup failed";
                    response.Audit = null;
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = "Fullfilment failed";
                _logger.Error($"Class: PaypalDb_DL, Method: ThaStraightCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<IEnumerable<TransactionbaketitemsResponseModel>> Getbasketitem(string id)
        {
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@tID", id);

                var basket = await ThaDbConnection.SqlConnection.QueryAsync<TransactionbaketitemsResponseModel>("tha_web_Gettransaction_basketitems", parameter, commandType: CommandType.StoredProcedure);

                return basket;
            }

            catch (Exception ex)
            {
                return null;
            }
        }
        public async Task<int> UpdatePaymenttransactionsItems(bool isfullfilled, int id, string msg, bool isemailsent)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@isfullfillment", isfullfilled);
                parameters.Add("@idtoupdate", id);
                parameters.Add("@msg", msg);
                parameters.Add("@isemailsent", isemailsent);
                return await ThaDbConnection.SqlConnection.ExecuteScalarAsync<int>("tha_web_update_Payment_transactions_Items", parameters, commandType: CommandType.StoredProcedure);
            }

            catch
            {
                return 0;
            }
        }
        public async Task<int> InsertTransactionPayment(List<basket> basket, string transactionCurrency, string customerEmail, string productCode, string transactionId, string productRef, Fullfillmenttype type, int promotionid)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("PaymentTransactionId", typeof(int));
            dt.Columns.Add("ProductItemCode");
            dt.Columns.Add("Bundleref");
            dt.Columns.Add("Prodref");
            dt.Columns.Add("Amount");
            dt.Columns.Add("Isfullfillment");
            dt.Columns.Add("CreatedatDateTime", typeof(DateTime));
            dt.Columns.Add("LastUpdateDateTime", typeof(DateTime));
            dt.Columns.Add("Email");
            dt.Columns.Add("FullfillmentDateTime", typeof(DateTime));
            dt.Columns.Add("Transactioncurrency");
            basket.ForEach(x => dt.Rows.Add(0, x.productItemCode, x.bundleRef == "" ? null : x.bundleRef, productRef, (float)x.amount, 0, Convert.ToDateTime(DateTime.UtcNow), Convert.ToDateTime(DateTime.UtcNow), customerEmail, null, transactionCurrency));

            var param = new DynamicParameters();
            param.Add("@table", dt.AsTableValuedParameter("dbo.tha_Transactionitems_tabletype"));
            param.Add("@TransactionId", transactionId);
            param.Add("@prodcode", "THAATW");
            param.Add("@fullfillmenttype", type);
            param.Add("@promotionid", promotionid);
            param.Add("@id", dbType: DbType.Int32, direction: ParameterDirection.Output);

            int result = await ThaDbConnection.SqlConnection.ExecuteAsync("tha_web_InsertTransaction_and_transactionitems", param, commandType: CommandType.StoredProcedure);
            return param.Get<int>("@id");
        }
        public async Task<int> InsertPaypalTransactionPayment(List<PayPalByPay360Basket> basket, string transactionCurrency, string customerEmail, string productCode, string transactionId, string productRef, Fullfillmenttype type, int promotionid)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("PaymentTransactionId", typeof(int));
            dt.Columns.Add("ProductItemCode");
            dt.Columns.Add("Bundleref");
            dt.Columns.Add("Prodref");
            dt.Columns.Add("Amount");
            dt.Columns.Add("Isfullfillment");
            dt.Columns.Add("CreatedatDateTime", typeof(DateTime));
            dt.Columns.Add("LastUpdateDateTime", typeof(DateTime));
            dt.Columns.Add("Email");
            dt.Columns.Add("FullfillmentDateTime", typeof(DateTime));
            dt.Columns.Add("Transactioncurrency");
            basket.ForEach(x => dt.Rows.Add(0, x.productItemCode, x.bundleRef == "" ? null : x.bundleRef, productRef, (float)x.amount, 0, Convert.ToDateTime(DateTime.UtcNow), Convert.ToDateTime(DateTime.UtcNow), customerEmail, null, transactionCurrency));

            var param = new DynamicParameters();
            param.Add("@table", dt.AsTableValuedParameter("dbo.tha_Transactionitems_tabletype"));
            param.Add("@TransactionId", transactionId);
            param.Add("@prodcode", "THAATW");
            param.Add("@fullfillmenttype", type);
            param.Add("@promotionid", promotionid);
            param.Add("@id", dbType: DbType.Int32, direction: ParameterDirection.Output);

            int result = await ThaDbConnection.SqlConnection.ExecuteAsync("tha_web_InsertTransaction_and_transactionitems", param, commandType: CommandType.StoredProcedure);
            return param.Get<int>("@id");
        }
    }
}
