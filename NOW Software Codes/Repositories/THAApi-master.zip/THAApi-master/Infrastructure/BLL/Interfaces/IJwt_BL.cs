﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IJwt_BL
    {
        JwtToken GenerateToken(UserAccount userAccount, string devicePersistentId, string remoteIp);
        JwtTokenValidationResponse ValidateToken(string token);
    }
}
