﻿namespace Application.Common.Enums;

public enum PaymentMethod
{
    Card = 1,
    Paypal,
    Balance,
    Voucher
}

public enum OrderStatus
{
    Create = 1,
    Success,
    Failure,
    Refunded,
    Pending,
    CancelBundleRefunded
}
public static class PaypalSubscriptionSaleFulfillmentStatus
{
    public const string Pending = "PENDING";
    public const string Granted = "GRANTED";
    public const string Failed = "FAILED";
}
public enum CheckOutType
{
    TopUp = 1,
    Bundle = 2,
    CreditSim = 3,
    TopupBundle = 4,
    TopupSubscription=5,
    BundleSubscription=6,
    ChangePlan=7,
    EarlyTerminationCharges = 8,
    CancelBundleRefund =9
    
}

public enum BasketItemType
{
    TopUp = 1,
    Bundle = 2
}

public enum Currency
{
    GBP
}

public enum ProductItemCode
{
    THM,
    THMCRSIM,
    THM_Bundle,
    THM_Topup
}

public enum ProductCode
{
    THM
}

public enum TransactionType
{
    Topup = 1,
    Bundle,
    SIMWithPlan,
    SIMWithCredit,
    SIMWithCreditandPlan,
    TopupBundle,
    ChangePlan,
    EarlyTerminationCharges,
    CancelBundleRefund

}

public enum Fullfillmenttype
{
    Pay360 = 1,
    Pay360Paypal = 2,
    DirectPaypal = 3
}