﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.ContactUs
{
    public class ContactUsRequest:IRequest<object>
    {
        public string Name { get; set; } = default!;
        public string Email { get; set; } = default!;
        public string? PhoneNumber { get; set; }
        public string Message { get; set; } = default!;
    }

    public class ContactUsRequestValidator : AbstractValidator<ContactUsRequest>
    {
        private readonly ICommonService _commonService;

        public ContactUsRequestValidator(ICommonService commonService)
        {
            _commonService = commonService;

            RuleFor(p => p.Name)
             .NotNull()
             .NotEmpty();
             //.MaximumLength(255).WithMessage("Your name length must not exceed {0}");

            RuleFor(p => p.Message)
             .NotNull()
             .NotEmpty();
             //.MaximumLength(5000).WithMessage("Your message length must not exceed 5000.");

            RuleFor(p => p.Email)
             .NotNull()
             .NotEmpty()
             //.MaximumLength(255).WithMessage("Your email length must not exceed {0}")
             .Must(p => _commonService.IsValidEmailAddress(p)).WithMessage("Invalid Email Address");
        }
    }
}
