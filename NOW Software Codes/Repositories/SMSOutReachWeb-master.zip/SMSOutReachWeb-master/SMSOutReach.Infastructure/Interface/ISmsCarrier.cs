﻿using SMSOutReach.Modal.Xeebi;
using System;
using System.Collections.Generic;
using System.Text;

namespace SMSOutReach.Infastructure.Interface
{
    public interface ISMSCarrier
    {
        List<SMSCarrier> GetAllSMSCarriers();
    }
}
