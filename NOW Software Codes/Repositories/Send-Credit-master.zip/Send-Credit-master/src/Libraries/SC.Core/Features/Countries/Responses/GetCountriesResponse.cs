﻿

using System.Text.Json.Serialization;

namespace SC.Core.Features.Countries;
public sealed class GetCountriesResponse
{
    [JsonPropertyName("countryId")]
    public long CountryId { get; set; } = default!;
    [JsonPropertyName("isoCode2")]
    public string IsoCode2 { get; set; } = default!;
    [JsonPropertyName("isoCode3")]
    public string IsoCode3 { get; set; } = default!;
    [JsonPropertyName("callingCode")]
    public int CallingCode { get; set; } = default!;
    [JsonPropertyName("countryName")]
    public string CountryName { get; set; } = default!;
    [JsonPropertyName("isoNumericCode")]
    public int IsoNumericCode { get; set; } = default!;
    [JsonPropertyName("continent")]
    public string Continent { get; set; } = default!;
    [JsonPropertyName("countryLogo")]
    public string? CountryLogo { get; set; }
}

