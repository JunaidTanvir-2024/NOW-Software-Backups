﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.Dtos;
public record CartCreationDto
{
    public long CustomerCartID { get; set; } = default!;
    public long ProductID { get; set; } = default!;
    public long CustomerOrderID { get; set; } = default!;
    public string CustomerID { get; set; } = default!;
    public string ProductName { get; set; } = default!;
    public int Quantity { get; set; } = default!;
    public string DiscountType { get; set; } = default!;
    public decimal DiscountAmount { get; set; } = decimal.Zero;
    public decimal Price { get; set; } = decimal.Zero;
    public string Currency { get; set; } = default!;
    public string Status { get; set; } = default!;
    public string State { get; set; } = default!;
    public bool isDeleted { get; set; } = default!;
    public bool isActive { get; set; } = default!;
    public decimal ServiceFeeAmount { get; set; }
    public string ProductPriceType { get; set; } = default!;
    public decimal ProductPrice { set; get; }
}

