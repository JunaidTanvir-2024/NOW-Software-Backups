﻿//Detect Enter Button
$(document).keypress(function (e) {
    if (e.which == 13) {
        if ($('.mfp-content').is(":visible")) {       //Detect Login/Register Modal
            if ($('#register-form').is(":visible")) {     //Detect Register Form
                $('#RegisterBtn').click();
            }
            else if ($('#forgot-form').is(":visible")) {  //Detect Forgot Password Form
                $('#ForgetPasswordbtn').click();
            }
            else {                          //SignIn Form
                $('#LoginBtn').click();
            }
        }
        else {
            $('#LoginBtnLoginPage').click();
        }
    }
});