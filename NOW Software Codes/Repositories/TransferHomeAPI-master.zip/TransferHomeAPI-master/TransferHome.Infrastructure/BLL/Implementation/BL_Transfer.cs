﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Infrastructure.BLL.Interfaces;
using TransferHome.Infrastructure.Services.Interfaces;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.Contracts.Response;
using TransferHome.Models.Contracts.Service;
using TrasnferHome.Models.Contracts;
using TrasnferHome.Models.Utility;
using System.Linq;
using PhoneNumbers;
using TransferHome.Infrastructure.DAL.Interfaces;
using TrasnferHome.Infrastructure.DAL.Interfaces;
using TransferHome.Models.DAOs;
using System.Globalization;
using MimeKit;
using System.IO;
using System.Net.Mail;
using TrasnferHome.Models.Configurations;
using Microsoft.Extensions.Options;
using System.Net;
using TransferHome.Models.Configurations;
using TransferHome.Models.Utility;
using TransferHome.Models.Resources;
using Serilog;
using Newtonsoft.Json;

namespace TransferHome.Infrastructure.BLL.Implementation
{
    public class BL_Transfer : IBL_Transfer
    {
        private readonly IATTService ATTService;
        private readonly IDL_Transfer TransferDL;
        private readonly IDL_User UserDL;
        private readonly SmtpConfig SmtpConfig;
        private readonly ISmsService SmsService;
        private readonly TwoFactorAuthenticationConfig TwoFactorConfig;
        private readonly ILogger Logger;

        public BL_Transfer(ILogger logger, IATTService attService, IDL_Transfer transferDL, IDL_User userDL, IOptions<SmtpConfig> smtpConfig, ISmsService smsService, IOptions<TwoFactorAuthenticationConfig> twoFactorConfig)
        {
            Logger = logger;
            ATTService = attService;
            TransferDL = transferDL;
            UserDL = userDL;
            SmtpConfig = smtpConfig.Value;
            SmsService = smsService;
            TwoFactorConfig = twoFactorConfig.Value;
        }

        public async Task<GenericApiResponse<GetProductsResponseModel>> GetProducts(GetProductsRequestModel model, string userId)
        {
            string CurrencyCode = "USD";
            string FromMsisdn = "";

            //Need to Validate Msisdn
            try
            {
                var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                PhoneNumber Number = phoneNumberUtil.Parse(model.DestinationMsisdn, model.DestinationCountryCode);

                var isValid = phoneNumberUtil.IsValidNumber(Number);

                if (isValid)
                {
                    model.DestinationMsisdn = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164).Replace("+", "").Trim();

                    if (userId != null)
                    {
                        var userResponse = await UserDL.GetUserById(Convert.ToInt32(userId));
                        if (userResponse != null)
                        {
                            CurrencyCode = userResponse.BalanceCurrency;
                            FromMsisdn = userResponse.PhoneNumber;
                        }
                    }
                }
                else
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null, "Country Code or Number is invalid.", ApiStatusCodes.InvalidNumber);
                }
            }
            catch
            {
                return GenericApiResponse<GetProductsResponseModel>.Failure(null, "Country Code or Number is invalid.", ApiStatusCodes.InvalidNumber);
            }

            //Get Products
            var productsResponse = await ATTService.GetProducts(new GetProductRequest()
            {
                destinationMSISDN = model.DestinationMsisdn,
                account = CurrencyCode,
                product = "TRH",
                fromMSISDN=FromMsisdn
            });

            if (productsResponse != null && productsResponse.errorCode == 0 && productsResponse.errorCodeDtOne == 0
                  && productsResponse.payload != null && productsResponse.payload.operators != null)
            {
                var responseData = productsResponse.payload.operators.FirstOrDefault();

                if (responseData != null && responseData.products != null)
                {
                    var response = new GetProductsResponseModel()
                    {
                        Operator = new ATTOperator()
                        {
                            Accessid = responseData.accessid,
                            Country = responseData.country,
                            IconUri = responseData.iconUri,
                            Id = responseData.id,
                            Name = responseData.name,
                            NowtelTransactionReference = responseData.nowtelTransactionReference
                        }
                    };

                    if (responseData.products.Count > 0)
                    {
                        response.Products = responseData.products.Select(item => new ATTProduct()
                        {
                            ClientCurrecny = item.clientccy,
                            ItemPriceClientCurrency = item.itemPriceClientccy,
                            Product = item.product,
                            ReceiverCurrecny = item.receiverccy,
                            TotalPriceClientCurrency = item.totalPriceClientccy,
                            TransactionFeeClientCurrency = item.transactionfeeClientccy
                        });
                    };

                    return GenericApiResponse<GetProductsResponseModel>.Success(response, "Operators found");
                }
                else
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null, "Transfer service for this number is not available at the moment. Please, try again later.", ApiStatusCodes.DTOneServiceError);
                }
            }
            else
            {
                if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.DenominationsNotAvailable)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.DenominationsNotAvailable.ToString()), ApiStatusCodes.DenominationsNotAvailable);
                }
                else if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.DenominationBlocked)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.DenominationBlocked.ToString()), ApiStatusCodes.DenominationBlocked);
                }
                else if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.OperatorBlocked)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.OperatorBlocked.ToString()), ApiStatusCodes.OperatorBlocked);
                }
                else
                {
                    if (productsResponse != null)
                    {
                        Logger.Error($"Class: BL_Transfer, Method: GetProducts, Parameters=> Model : {JsonConvert.SerializeObject(model)}, ErrorMessage: {productsResponse.message}");
                    }
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null, "Transfer service for this number is not available at the moment. Please, try again later.", ApiStatusCodes.DTOneServiceError);
                }
            }
        }

        public async Task<GenericApiResponse<TransferFromAccountBalanceResponseModel>> TransferFromAccountBalance(TransferFromAccountBalanceRequestModel model, int userId)
        {
            //Get Products 
            var productsResponse = await TransferDL.GetProductByNowtelTransactionReference(model.NowtelTransactionReference, model.Product);
            if (productsResponse != null)
            {
                var userResponse = await UserDL.GetUserById(userId);
                if (userResponse != null && !string.IsNullOrEmpty(productsResponse.CustomerChargeValue))
                {
                    //replace fromMsisdn with user number
                    model.FromMsisdn = userResponse.PhoneNumber;

                    if (userResponse.Balance >= Convert.ToDecimal(productsResponse.CustomerChargeValue))
                    {
                        var validationResponse = await TransferDL.ValidateTransferRequest(userResponse.Id, Convert.ToDecimal(productsResponse.CustomerChargeValue));
                        if (validationResponse == 0)
                        {
                            var transferResponse = await ATTService.Execute(new ExecuteDataRequest()
                            {
                                fromMSISDN = model.FromMsisdn,
                                messageToRecipient = model.MessageToRecipient,
                                nowtelTransactionReference = model.NowtelTransactionReference,
                                operatorid = model.OperatorId,
                                product = model.Product
                            });

                            string validationMsisdn = productsResponse.tomsisdn;

                            if (!validationMsisdn.StartsWith('+'))
                            {
                                validationMsisdn = "+" + validationMsisdn;
                            }

                            PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();

                            // phone must begin with '+'
                            PhoneNumber numberProto = phoneUtil.Parse(validationMsisdn, "");
                            var countryCode = phoneUtil.GetRegionCodeForCountryCode(numberProto.CountryCode);


                            //Save Transaction
                            var saveTransactionRequest = new DBTransferTransactions()
                            {
                                UserId = userId,
                                TransactionTypeId = TransferTransactionType.TRHA,
                                PaymentTypeId = PaymentType.AccountBalance,
                                NowtelTransactionReference = productsResponse.GUID.ToString(),
                                OperatorId = model.OperatorId,
                                ClientCurrecny = productsResponse.fromCurrency,
                                ReceiverCurrecny = productsResponse.toCurrency,
                                Product = (string.IsNullOrEmpty(productsResponse.product) ? 0 : Convert.ToDecimal(productsResponse.product)),
                                ItemPrice = (string.IsNullOrEmpty(productsResponse.fromAmount) ? 0 : Convert.ToDecimal(productsResponse.fromAmount)),
                                TotalPrice = (string.IsNullOrEmpty(productsResponse.CustomerChargeValue) ? 0 : Convert.ToDecimal(productsResponse.CustomerChargeValue)),
                                StatusId = transferResponse.errorCode.Equals("0") ? TransferTransactionStatus.Success : TransferTransactionStatus.Failure,
                                ExecuteReferenceNumber = transferResponse.reference,
                                OperatorCountryName = productsResponse.operatorCountryName,
                                CountryCode = countryCode,
                                OperatorLogoUrl = productsResponse.operatorLogoUrl,
                                OperatorName = productsResponse.operatorName,
                                FromMsisdn = model.FromMsisdn,
                                ToMsisdn = productsResponse.tomsisdn
                            };

                            await TransferDL.SaveTransferTransaction(saveTransactionRequest);

                            if (transferResponse != null && transferResponse.errorCode.Equals("0"))
                            {
                                await TransferDL.DebitUserBalance(new DbDebit() { Currency = productsResponse.fromCurrency, Amount = Convert.ToDecimal(transferResponse.amount), type = TopUpType.DebitTransfer, UseId = userId });

                                var user = await UserDL.GetUserById(userId);

                                if (user != null)
                                {
                                    return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Success(new TransferFromAccountBalanceResponseModel { RemainingBalance = user.Balance, BalanceCurrency = user.BalanceCurrency, BalanceCurrencySymbol = user.BalanceCurrencySymbol }, "Transferred Credit" + Environment.NewLine + "Successfully");
                                }
                                else
                                {
                                    return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Success(null, "Transferred Credit <br/> Successfully");
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(transferResponse.errorCodeDtOne) && !transferResponse.errorCode.Equals("0"))
                                {
                                    int AttErrorCode = Convert.ToInt32(transferResponse.errorCodeDtOne);

                                    if (AttErrorCode == (int)ATTStatusCodes.TopupNumberLimitExceed)
                                    {
                                        return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.TopupNumberLimitExceed.ToString()), ApiStatusCodes.TopupNumberLimitExceed);
                                    }
                                    else if (AttErrorCode == (int)ATTStatusCodes.TopupAmountLimitExceed)
                                    {
                                        return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.TopUpAmountsNotFound.ToString()), ApiStatusCodes.TopupAmountLimitExceed);
                                    }
                                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationsNotAvailable)
                                    {
                                        return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.DenominationsNotAvailable.ToString()), ApiStatusCodes.DenominationsNotAvailable);
                                    }
                                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationBlocked)
                                    {
                                        return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.DenominationBlocked.ToString()), ApiStatusCodes.DenominationBlocked);
                                    }
                                    else if (AttErrorCode == (int)ATTStatusCodes.OperatorBlocked)
                                    {
                                        return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.OperatorBlocked.ToString()), ApiStatusCodes.OperatorBlocked);
                                    }
                                }

                                Logger.Error($"Class: BL_Transfer, Method: TransferFromAccountBalance, Parameters=> Model : {JsonConvert.SerializeObject(model)}, ErrorMessage: {transferResponse.message}");

                                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, "Transfer service for this number is not available at the moment. Please, try again later.", ApiStatusCodes.DTOneServiceError);
                            }
                        }
                        else
                        {
                            if (validationResponse == 1 || validationResponse == 3) //1- number lmilit exceed;  2- number limit exceed- white listed user
                            {
                                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, "Your daily limit exceeded", ApiStatusCodes.TopupNumberLimitExceed);
                            }
                            else if (validationResponse == 2 || validationResponse == 4) // 1 - amount lmilit exceed; 2 - amount limit exceed-white listed user
                            {
                                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, "Your daily limit exceeded", ApiStatusCodes.TopupAmountLimitExceed);
                            }
                        }
                    }
                    return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, "Insufficient balance in your account", ApiStatusCodes.InsufficientBalanceInAccount);
                }
                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, "User not found", ApiStatusCodes.UserNotFound);
            }
            return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, "Transfer service for this number is not available at the moment. Please, try again later.", ApiStatusCodes.DTOneServiceError);
        }

        public async Task<GenericApiResponse<TransferFromAccountBalanceResponseModel>> ExecuteDirectTransfer(ExecuteDirectTransferRequestModel model)
        {
            //Get Products 
            var productsResponse = await TransferDL.GetProductByNowtelTransactionReference(model.nowtelTransactionReference, model.product);
            if (productsResponse != null)
            {
                if (productsResponse.product == model.product)
                {
                    //Execute 
                    var transferResponse = await ATTService.Execute(new ExecuteDataRequest()
                    {
                        nowtelTransactionReference = model.nowtelTransactionReference,
                        product = model.product,
                        fromMSISDN = model.fromMSISDN,
                        messageToRecipient = model.messageToRecipient,
                        operatorid = model.operatorid
                    });

                    string validationMsisdn = productsResponse.tomsisdn;
                    if (!validationMsisdn.StartsWith('+'))
                    {
                        validationMsisdn = "+" + validationMsisdn;
                    }

                    PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();

                    // phone must begin with '+'
                    PhoneNumber numberProto = phoneUtil.Parse(validationMsisdn, "");
                    var countryCode = phoneUtil.GetRegionCodeForCountryCode(numberProto.CountryCode);

                    //Save Transaction
                    var saveTransactionRequest = new DBTransferTransactions()
                    {
                        TransactionTypeId = model.TransactionType,
                        PaymentTypeId = model.PaymentType,
                        NowtelTransactionReference = productsResponse.GUID.ToString(),
                        ClientCurrecny = productsResponse.fromCurrency,
                        ReceiverCurrecny = productsResponse.toCurrency,
                        Product = (string.IsNullOrEmpty(productsResponse.product) ? 0 : Convert.ToDecimal(productsResponse.product)),
                        ItemPrice = (string.IsNullOrEmpty(productsResponse.fromAmount) ? 0 : Convert.ToDecimal(productsResponse.fromAmount)),
                        TotalPrice = (string.IsNullOrEmpty(productsResponse.CustomerChargeValue) ? 0 : Convert.ToDecimal(productsResponse.CustomerChargeValue)),
                        StatusId = transferResponse.errorCode.Equals("0") ? TransferTransactionStatus.Success : TransferTransactionStatus.Failure,
                        ExecuteReferenceNumber = transferResponse.reference,
                        OperatorCountryName = productsResponse.operatorCountryName,
                        CountryCode = countryCode,
                        OperatorLogoUrl = productsResponse.operatorLogoUrl,
                        OperatorName = productsResponse.operatorName,
                        FromMsisdn = model.fromMSISDN,
                        ToMsisdn = productsResponse.tomsisdn,
                        OperatorId = model.operatorid,
                        UserId = model.UserId
                    };

                    await TransferDL.SaveTransferTransaction(saveTransactionRequest);

                    if (transferResponse != null && transferResponse.errorCode.Equals("0"))
                    {
                        return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Success(new TransferFromAccountBalanceResponseModel() { BalanceCurrency = productsResponse.fromCurrency, transferAmountCurrency = productsResponse.fromCurrency, DestinationCountry = productsResponse.operatorCountryName, DestinationMsisdn = productsResponse.tomsisdn, OperatorName = productsResponse.operatorName, transferAmount = productsResponse.fromAmount }, "Transferred Credit <br/> Successfully");
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(transferResponse.errorCodeDtOne) && !transferResponse.errorCode.Equals("0"))
                        {
                            int AttErrorCode = Convert.ToInt32(transferResponse.errorCodeDtOne);

                            if (AttErrorCode == (int)ATTStatusCodes.TopupNumberLimitExceed)
                            {
                                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.TopupNumberLimitExceed.ToString()), ApiStatusCodes.TopupNumberLimitExceed);
                            }
                            else if (AttErrorCode == (int)ATTStatusCodes.TopupAmountLimitExceed)
                            {
                                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.TopUpAmountsNotFound.ToString()), ApiStatusCodes.TopupAmountLimitExceed);
                            }
                            else if (AttErrorCode == (int)ATTStatusCodes.DenominationsNotAvailable)
                            {
                                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.DenominationsNotAvailable.ToString()), ApiStatusCodes.DenominationsNotAvailable);
                            }
                            else if (AttErrorCode == (int)ATTStatusCodes.DenominationBlocked)
                            {
                                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.DenominationBlocked.ToString()), ApiStatusCodes.DenominationBlocked);
                            }
                            else if (AttErrorCode == (int)ATTStatusCodes.OperatorBlocked)
                            {
                                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, ApiMessage.ResourceManager.GetString(ApiStatusCodes.OperatorBlocked.ToString()), ApiStatusCodes.OperatorBlocked);
                            }
                        }

                        Logger.Error($"Class: BL_Transfer, Method: ExecuteDirectTransfer, Parameters=> Model : {JsonConvert.SerializeObject(model)}, ErrorMessage: {transferResponse.message}");

                        return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, "Transfer service for this number is not available at the moment. Please, try again later.", ApiStatusCodes.DTOneServiceError);
                    }
                }
                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, "Product is invalid.", ApiStatusCodes.InvalidProduct);
            }
            return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure(null, "Transfer service for this number is not available at the moment. Please, try again later.", ApiStatusCodes.DTOneServiceError);
        }

        public async Task<DBProduct> GetTransferTransactionByNowtelTransactionReference(string nowtelTransactionReference, string product)
        {
            return await TransferDL.GetProductByNowtelTransactionReference(nowtelTransactionReference, product);
        }

        public Task<decimal> CreditBalance(DBCredit model)
        {
            return TransferDL.CreditUserBalance(model);
        }

        public async Task<GenericApiResponse<object>> GenerateTwoFactorAuthenticationToken(int userId, string NowtelTransactionReference)
        {
            var userResponse = await UserDL.GetUserById(userId);

            if (userResponse == null)
            {
                return GenericApiResponse<object>.Failure(new { }, "User not found", ApiStatusCodes.UserNotFound);
            }

            Random RandNum = new Random();
            DBTwoFactorAuthenticationToken twoFactorToken = new DBTwoFactorAuthenticationToken()
            {
                Token = RandNum.Next(1000, 9999).ToString(),
                UserId = userId,
                NowtelTransactionReference = NowtelTransactionReference,
                TokenTypeId = !string.IsNullOrEmpty(userResponse.PhoneNumber) ? TwoFactorTokenTypes.PhoneNumberToken : TwoFactorTokenTypes.EmailToken,

            };

            var tokenResponse = await TransferDL.SaveTwoFactorAuthenticationToken(twoFactorToken);

            if (twoFactorToken.TokenTypeId == TwoFactorTokenTypes.EmailToken)
            {
                var builder = new BodyBuilder();
                using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\TwoFactorAuthenticationTemplate.html").Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();
                }
                string messageBody = string.Format(builder.HtmlBody, userResponse.Email, twoFactorToken.Token);
                SendEmailToCustomer(userResponse.Email, messageBody, "Balance Transfer Authentication - Transfer Home");

                return GenericApiResponse<object>.Pending(new TwoFactorAuthenticationResponseModel() { TokenTypeId = (int)TwoFactorTokenTypes.EmailToken }, $"OTAC sent to your email {userResponse.Email} successfully. Please check your inbox and verify", ApiStatusCodes.TransferPendingTwoFactorAuthentication);
            }
            else
            {
                SmsService.SendSms(userResponse.PhoneNumber, $"{twoFactorToken.Token} is your TransferHome verification code for balance transfer");

                return GenericApiResponse<object>.Pending(new TwoFactorAuthenticationResponseModel() { TokenTypeId = (int)TwoFactorTokenTypes.PhoneNumberToken }, $"OTAC sent to {userResponse.PhoneNumber} successfully. Please check sms and verify the pin", ApiStatusCodes.TransferPendingTwoFactorAuthentication);
            }
        }

        private async Task<bool> SendEmailToCustomer(string customerEmail, string Message, string Subject)
        {
            SmtpClient client = new SmtpClient(SmtpConfig.server);

            if (!string.IsNullOrEmpty(SmtpConfig.userName) && !string.IsNullOrEmpty(SmtpConfig.password))
            {
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
            }
            else
            {
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
            }

            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress(SmtpConfig.fromForTransferHome);
            mailMessage.To.Add(customerEmail);
            mailMessage.Body = Message;
            mailMessage.Subject = Subject;
            mailMessage.IsBodyHtml = true;
            await client.SendMailAsync(mailMessage);

            return true;
        }

        public async Task<GenericApiResponse<TransferFromAccountBalanceResponseModel>> ResumeTransferTransaction(ResumeTransferTransactionRequestModel model, int userId)
        {
            var tokenResponse = await TransferDL.VerifyTwoFactorToken(new DBTwoFactorAuthenticationToken()
            {
                UserId = userId,
                Token = model.Token,
                NowtelTransactionReference = model.NowtelTransactionReference,
                TokenTypeId = (TwoFactorTokenTypes)model.TokenTypeId,
                ExpiryMinutes = TwoFactorConfig.TokenExpiryMinutes
            });

            if (tokenResponse > 0)
            {
                return await TransferFromAccountBalance(new TransferFromAccountBalanceRequestModel()
                {

                    FromMsisdn = model.FromMsisdn,
                    MessageToRecipient = model.MessageToRecipient,
                    NowtelTransactionReference = model.NowtelTransactionReference,
                    OperatorId = model.OperatorId,
                    Product = model.Product
                }, userId);
            }
            else
            {
                return GenericApiResponse<TransferFromAccountBalanceResponseModel>.Failure("Token is invalid or expired", ApiStatusCodes.TokenExpiredorInvalid);
            }
        }

        public async Task<GenericApiResponse<object>> SaveAutoTransferSettings(SaveAutoTransferSettingsRequestModel model, int userId)
        {
            var response = await TransferDL.SaveAutoTransferSettings(new DBAutoTransfer()
            {
                PaymentType = model.PaymentType,
                UserId = userId,
                FromMsisdn = model.fromMSISDN,
                LastTransactionExecutionDateTime = model.LastTransactionExecutionDateTime,
                NowtelTransactionReference = model.nowtelTransactionReference,
                OperatorId = model.operatorid,
                Product = model.product,
                RegularityType = model.RegularityType,
                RequestDateTime = model.RequestDateTime
            });

            if (response > 0)
            {
                return GenericApiResponse<object>.Success(new { }, "Auto transfer settings saved successfully");
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Failed to save auto transfer settings", ApiStatusCodes.DBError);
            }
        }

        public async Task<GenericApiResponse<object>> GetUserAutoTransferNumbers(int userId)
        {
            var numbers = await TransferDL.GetUserAutoTransferNumbers(userId);
            if (numbers.Count() > 0)
            {
                List<AutoTransferNumbersResponseModel> list = new List<AutoTransferNumbersResponseModel>();
                List<DBAutoTransfer> dblist = numbers.ToList();

                bool IsSuccess = true;

                for (int i = 0; i < dblist.Count; i++)
                {
                    var data = await TransferDL.GetProductByNowtelTransactionReference(dblist[i].NowtelTransactionReference, dblist[i].Product);

                    var Regions = CultureInfo.GetCultures(CultureTypes.SpecificCultures).Select(x => new RegionInfo(x.LCID));
                    var countryCode = Regions.FirstOrDefault(region => region.EnglishName == data.operatorCountryName)?.Name;

                    if (data != null)
                    {
                        list.Add(new AutoTransferNumbersResponseModel()
                        {
                            ToMsisdn = data.tomsisdn,
                            Amount = Convert.ToDecimal(data.CustomerChargeValue),
                            CreatedDateTime = dblist[i].CreatedDateTime,
                            Id = dblist[i].Id,
                            ToMsisdnCountryCode = countryCode,
                            PaymentTypeId = dblist[i].PaymentTypeId,
                            RegularityTypeId = dblist[i].RegularityId,
                            AmountCurrency = data.fromCurrency,
                            UserId = dblist[i].UserId,
                            IsOn = dblist[i].IsOn
                        });
                    }
                    else
                    {
                        IsSuccess = false;
                        break;
                    }
                }
                if (IsSuccess)
                {
                    return GenericApiResponse<object>.Success(new GetUserAutoTransferNumbersResponseModel()
                    {
                        Numbers = list
                    }, "Found auto transfer numbers");
                }
                return GenericApiResponse<object>.Failure(new { }, "Failed to get auto transfer numbers", ApiStatusCodes.DTOneServiceError);
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Numbers not found", ApiStatusCodes.AutoTransferNumbersNotFound);
            }
        }

        public async Task<GenericApiResponse<object>> UpdateAutoTransferStatus(UpdateAutoTransferStatusRequestModel model, int userId)
        {
            var response = await TransferDL.UpdateAutoTransferStatus(model.Id, model.Status, userId);
            if (response != null)
            {
                return GenericApiResponse<object>.Success(new UpdateAutoTransferStatusResponseModel() { status = response.IsOn }, "Auto Transfer status updated successfully against this record");
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Record not found", ApiStatusCodes.RecordNotFound);
            }
        }

        public async Task<GenericApiResponse<object>> RemoveAutoTransferNumber(RemoveAutoTransferNumberRequestModel model, int userId)
        {
            var response = await TransferDL.RemoveAutoTransferNumber(model.Id, userId);
            if (response > 0)
            {
                return GenericApiResponse<object>.Success(new { }, "Number deleted successfully");
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Record not found", ApiStatusCodes.RecordNotFound);
            }
        }

        public async Task<GenericApiResponse<object>> UpdateAutoTransferSettings(UpdateAutoTransferSettingsRequestModel model, int userId)
        {
            var response = await TransferDL.UpdateAutoTransferSettings(model, userId);
            if (response > 0)
            {
                return GenericApiResponse<object>.Success(new { }, "Auto Transfer settings updated successfully");
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Record not found", ApiStatusCodes.RecordNotFound);
            }
        }

        public async Task<int> ValidateTrasnferRequest(int userId, decimal amount)
        {
            return await TransferDL.ValidateTransferRequest(userId, amount);
        }
    }
}