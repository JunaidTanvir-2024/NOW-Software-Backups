﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Enums;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System;
using THAApi.Utilities;
using Serilog;
using Microsoft.Extensions.Options;
using System.Net;

namespace THAApi.Controllers
{
    [ApiController]
    public class DeleteAccountController : Controller
    {
        private readonly IUserAccount_BL UserAccountBL;
        private readonly IStringLocalizer localizer;
        private readonly preAuthConfig _preAuthConfig;
        private readonly ForceUpdateConfig ForceUpdateConfig;
        private readonly ILogger Logger;

        public DeleteAccountController(
            IUserAccount_BL userAccountBL,
            IStringLocalizer localizer,
            ILogger logger,
            IOptions<preAuthConfig> preAuthConfig)
        {
            UserAccountBL = userAccountBL;
            this.localizer = localizer;
            Logger = logger;
            this._preAuthConfig = preAuthConfig.Value;
        }
        /// <summary>
        /// This method will log the account delete request
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("DeleteAccount/CreateDeleteAccountRequest")]
        public async Task<IActionResult> CreateDeleteAccountRequest(DeleteAccountLogRequestModel model)
        {
            try
            {
                model.AccountId = User.Account();
                model.Msisdn = User.Msisdn();
                return Ok(await UserAccountBL.CreateDeleteAccountRequest(model));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DeleteAccountController, Method: CreateDeleteAccountRequest, RequestJson: {JsonConvert.SerializeObject(model)}, ErrorMessage: " + ex.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, GenericApiResponse<bool>.Failure(ex.Message, ApiStatusCodes.InternalServerError));                
            }
        }
        /// <summary>
        /// This method will return the list of delete account reasons based on the language code
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("DeleteAccount/GetDeleteAccountReasons")]       
        public async Task<IActionResult> GetDeleteAccountReasons()
        {
            try
            {              
                string languageISOCode = HttpContext.GetLanguageISOCode();
                return Ok(await UserAccountBL.GetDeleteAccountReasons(languageISOCode));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DeleteAccountController, Method: GetDeleteAccountReasons, ErrorMessage: " + ex.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, GenericApiResponse<bool>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }
        }
        /// <summary>
        /// This method will update the delete account request status 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("DeleteAccount/UpdateDeletedAccountStatus")]
        public async Task<IActionResult> UpdateDeletedAccountStatus(DeleteAccountLogRequestModel model)
        {
            try
            {
                return Ok(await UserAccountBL.UpdateDeletedAccountStatus(model));

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DeleteAccountController, Method: UpdateDeletedAccountStatus, ErrorMessage: " + ex.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, GenericApiResponse<bool>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }
        }
    }
}
