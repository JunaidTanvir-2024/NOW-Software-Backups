﻿using Models.Enums;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IApiCall
    {
        Task<HttpResponseMessage> GetAsync(string Uri, TokenType authTokenType, string authToken, params string[] parameters);
        Task<HttpResponseMessage> GetAsync(string Uri, TokenType authTokenType, string authToken);
        Task<HttpResponseMessage> GetAsync(string Uri);
        Task<HttpResponseMessage> PostAsync(string Uri, TokenType authTokenType, string authToken, string requestJson);
        Task<HttpResponseMessage> PostAsync(string Uri, string requestJson);
        Task<HttpResponseMessage> PostUrlEncodedAsync(string Uri, TokenType authTokenType, string authToken, List<KeyValuePair<string, string>> postDataModel);
    }
}
