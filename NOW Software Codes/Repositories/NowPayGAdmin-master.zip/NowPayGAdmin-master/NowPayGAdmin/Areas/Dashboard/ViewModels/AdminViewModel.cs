﻿using BasketWebPanel.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.ViewModels
{
    public class AdminViewModel : BaseViewModel
    {
        public int AdminId { get; set; }
        [Required(ErrorMessage = "Required"), StringLength(50, ErrorMessage = "Maximum Length is 50 Characters.")]
        public string Firstname { get; set; }
        [Required(ErrorMessage = "Required"), StringLength(50, ErrorMessage = "Maximum Length is 50 Characters.")]
        public string Lastname { get; set; }
        [StringLength(50, ErrorMessage = "Maximum Length is 500 Characters.")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Required")]
        public int RoleId { get; set; }
        [Required(ErrorMessage = "Required"), StringLength(50, ErrorMessage = "Maximum Length is 50 Characters.")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Required"), StringLength(50, ErrorMessage = "Maximum Length is 150 Characters.")]
        public string Password { get; set; }
    }
}