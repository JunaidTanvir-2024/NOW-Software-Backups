﻿

namespace SC.Core.Extensions;
public static class HttpServiceExtensions
{
    public static (int totalPages, int totalRecords) GetPaginationInfoFromHeader(this HttpResponseMessage httpResponseMessage, string? _totalPagesHeaderKey, string? _totalRecordHeaderKey)
    {
        int totalPages = 0;
        int totalRecords = 0;

        if (httpResponseMessage.Headers.TryGetValues(_totalPagesHeaderKey!, out IEnumerable<string>? totalPagesValue))
        {
            totalPages = Convert.ToInt32(totalPagesValue.First());
        }

        if (httpResponseMessage.Headers.TryGetValues(_totalRecordHeaderKey!, out IEnumerable<string>? totalRecordsValue))
        {
            totalRecords = Convert.ToInt32(totalRecordsValue.First());
        }
        return (totalPages, totalRecords);
    }
}

