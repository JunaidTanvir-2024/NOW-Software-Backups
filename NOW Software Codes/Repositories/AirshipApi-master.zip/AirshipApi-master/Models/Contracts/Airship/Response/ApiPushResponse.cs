﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Response
{
    public class ApiPushResponse
    {
        [JsonProperty("ok")]
        public bool Ok { get; set; }

        [JsonProperty("operation_id")]
        public string OperationId { get; set; }

        [JsonProperty("push_ids")]
        public List<string> PushIds { get; set; }

        [JsonProperty("message_ids")]
        public List<string> MessageIds { get; set; }

        [JsonProperty("content_urls")]
        public List<string> ContentUrls { get; set; }

        [JsonProperty("localized_ids")]
        public List<string> LocalizedIds { get; set; }
   
    }
}
