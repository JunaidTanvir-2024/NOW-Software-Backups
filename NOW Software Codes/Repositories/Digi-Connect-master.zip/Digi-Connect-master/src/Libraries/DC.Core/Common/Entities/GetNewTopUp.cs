using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DC.Core.Common.Entities;
public class GetNewTopUp
{
    public string Msisdn { get; set; }
    public float AvailableBalance { get; set; }
    public DateTime TopUpDate { get; set; }
    public float TopUpAmount { get; set; }
    public string CreatedBy { get; set; }
    public string Cadence { get; set; }
    public string SmsStatus { get; set; }

}
