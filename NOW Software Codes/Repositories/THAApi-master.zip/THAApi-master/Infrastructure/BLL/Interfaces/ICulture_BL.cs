﻿namespace Infrastructure.BLL.Interfaces
{
    public interface ICulture_BL
    {
        string GetCountryName(string countryCode);

        string GetAlphaTwoCountryCode(string countryName);

        string ISOCurrencyCode(string countryCode);
    }
}