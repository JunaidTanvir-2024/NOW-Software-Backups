﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBPromotionsDetails
    {
        public DBPromotionsDetails()
        {
            Promotions = new List<DBPromotions>();
            PromotionPaymentMethods = new List<DBPromotionPaymentMethods>();
        }
        public IEnumerable<DBPromotions> Promotions { get; set; }
        public IEnumerable<DBPromotionPaymentMethods> PromotionPaymentMethods { get; set; }

    }
}
