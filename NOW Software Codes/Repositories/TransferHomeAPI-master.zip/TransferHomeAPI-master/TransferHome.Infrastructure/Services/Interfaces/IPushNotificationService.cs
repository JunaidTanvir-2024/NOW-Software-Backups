﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TrasnferHome.Models.DAOs;

namespace TransferHome.Infrastructure.Services.Interfaces
{
    public interface IPushNotificationService
    {
        Task SendPushNotificationToAll(string Title, string Text);
        Task SendPushNotificationToSpecificUsers(List<string> userMsisdns, string Title, string Text);
        Task SendPushNotificationToSpecificTokens(List<DBUserTokens> userDevices, string Title, string Text);
    }
}
