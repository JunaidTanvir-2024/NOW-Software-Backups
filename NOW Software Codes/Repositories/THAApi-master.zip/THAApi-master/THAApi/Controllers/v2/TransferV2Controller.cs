﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using Models.Contracts.Response;
using System;
using Serilog;
using System.Linq;
using System.Threading.Tasks;
using THAApi.Utilities;
using THAApi.ViewModels;
using Models.Enums;
using Infrastructure.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Localization;
using Newtonsoft.Json;
using Models.Contracts.PaypalApiContracts;
using Models.Configurations;
using Microsoft.Extensions.Options;
using Infrastructure.BLL;
using System.Runtime.InteropServices;
using Models.Contracts.Request.Voucherify;
using Models.Database;
using Models.Services.Airship;

namespace THAApi.Controllers.v2
{
    [ApiController]
    [ApiVersion("2.0")]
    [Route("v{v:apiVersion}/transfer")]
    public class TransferV2Controller : Controller
    {
        private readonly ILogger _logger;
        private readonly IATT_BL _attBl;
        private readonly IPayment_BL _paymentBl;
        private readonly IStringLocalizer _localizer;
        private readonly IHelper_BL _helper_BL;
        private readonly VoucherifyConfig _voucherifyConfig;

        public TransferV2Controller(
            ILogger logger,
            IATT_BL aTT_BL,
            IPayment_BL paymentService,
            IStringLocalizer localizer,
            IHelper_BL helper_BL,
            IOptions<VoucherifyConfig> options
            )
        {
            _logger = logger;
            _attBl = aTT_BL;
            _paymentBl = paymentService;
            _localizer = localizer;
            _helper_BL = helper_BL;
            _voucherifyConfig = options.Value;
        }

        [HttpPost]
        [Route("Airtime/DoTransfer")]
        public async Task<IActionResult> ATTDoTransfer([FromBody] TransFerTotransferConfirmV2 request)
        {
            if (string.IsNullOrEmpty(request.DiscountCode))
            {
                request.DiscountCode = null;
                request.DiscountCodeType = DiscountCodeType.None;
            }
            request.advertiserID = HttpContext.GetAdvertiserID();
            var executeRes = await _attBl.ExecuteTransactionByBalanceV2(request, User.Msisdn());
            return Ok(executeRes);
        }

        [Route("TransferByPaypal")]
        [HttpPost]
        public async Task<IActionResult> TransferByPaypal([FromBody] TransferByPayPalRequestModelV2 request)
        {
            if (string.IsNullOrEmpty(request.DiscountCode))
            {
                request.DiscountCode = null;
                request.DiscountCodeType = DiscountCodeType.None;
            }
            string advertiserID = HttpContext.GetAdvertiserID();
            var response = await _paymentBl.TransferByPayPalV2Async(
                request,
                User.Currency(),
                HttpContext.GetRemoteIPAddress(),
                User.Msisdn(),
                advertiserID);
            return Ok(response);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        [Route("TransferByPaypalReturn")]
        public async Task<IActionResult> TransferByPaypalReturn([FromQuery] PaypalPaymentCallbackData request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.DiscountCode))
                {
                    request.DiscountCode = null;
                    request.DiscountCodeType = DiscountCodeType.None;
                }
                var response = await _paymentBl.TransferByPayPalCallbackV2Async(request);
                var productDetails = await _attBl.GetProductByNowtelTransactionReference(request.TransferNowtelRef, request.TransferProduct);
                if (response.ErrorCode > 0)
                {
                    return View(Pages.ErrorPageV2,
                            new ErrorViewModel()
                            {
                                PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal,
                                Type = CheckOutTypes.Transfer,
                                Origination = _helper_BL.GetCountryCode(request.Msisdn),
                                Message = response.Message,
                                ThemeMode = (ThemeMode)request.ThemeMode,
                            });
                }
                var internationalTopupPoints = Utility.CalculateInternationalTopupRewardPointsRange(response.Payload.FromAmount, _voucherifyConfig.LoyaltyEarningRules.International);

                var model = new SuccessViewModel()
                {
                    Type = SuccessViewModel.CheckoutType.InternationalTopup,
                    ThemeMode = (ThemeMode)request.ThemeMode,
                    Origination = _helper_BL.GetCountryCode(request.Msisdn),
                    InternationalTopupInfo =
                            new SuccessViewModel.InternationalTopup
                            {
                                Amount = response.Payload.TopupAmount,
                                PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal,
                                Currency = response.Payload.Currency,
                                Destination = _helper_BL.GetCountryCode(productDetails.tomsisdn),
                                IsTransferRequest = request.IsTransferRequest
                            },
                    VoucherifyInfo = Utility.GetVoucherifyInfo(response.Payload.CampaignName, CheckOutTypes.Transfer, request.DiscountCodeType, response.Payload.IsFirstInternationalTopup, internationalTopupPoints: internationalTopupPoints, isRedeemedSuccess: response.Payload.IsRedeemedSuccess),
                };
                return View(Pages.SuccessPage, model);
            }
            catch (Exception ex)
            {
                _logger.Error(
                    $"Controller: ATTController, " +
                    $"Method: TransferByPaypalReturnV2 , " +
                    $"Request: {JsonConvert.SerializeObject(request)} , " +
                    $"ErrorMessage: {ex.Message}, " +
                    $"StackTrace: {ex.StackTrace}");
                return View(Pages.ErrorPageV2,
                    new ErrorViewModel()
                    {
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal,
                        Type = CheckOutTypes.Transfer,
                        Origination = _helper_BL.GetCountryCode(request.Msisdn),
                        Message = _localizer["SomethingWentWrong"],
                        ThemeMode = (ThemeMode)request.ThemeMode,
                    });
            }
        }

        [AllowAnonymous]
        [Route("TransferByPaypalCancel"), HttpGet]
        public IActionResult TransferByPaypalCancelV2([FromQuery] ThemeMode themeMode)
        {
            return View(Pages.ErrorPageV2, new ErrorViewModel()
            {
                Message = _localizer["PaymentError"],
                ThemeMode = themeMode,
                Type = CheckOutTypes.Transfer,
                PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal
            });
        }

        [Route("TransferByNewCustomer")]
        [HttpPost]
        public async Task<IActionResult> TransferByNewCustomer([FromBody] TransferByNewCustomerRequestModelV2 request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.DiscountCode))
                {
                    request.DiscountCode = null;
                    request.DiscountCodeType = DiscountCodeType.None;
                }
                string advertiserID = HttpContext.GetAdvertiserID();
                var response = await _paymentBl.TransferByNewCardV2Async(
                    request,
                    User.Currency(),
                    HttpContext.GetRemoteIPAddress(),
                    User.Msisdn(),
                    User.Email(),
                    advertiserID);

                if (response.ErrorCode == 0)
                {
                    var internationalTopupPoints = Utility.CalculateInternationalTopupRewardPointsRange(response.Payload.FromAmount, _voucherifyConfig.LoyaltyEarningRules.International);

                    var successModel = new SuccessViewModel()
                    {
                        Type = SuccessViewModel.CheckoutType.InternationalTopup,
                        ThemeMode = HttpContext.ThemeMode(),
                        Origination = _helper_BL.GetCountryCode(User.Msisdn()),
                        CustomerMsisdn = User.Msisdn(),
                        InternationalTopupInfo = new SuccessViewModel.InternationalTopup
                        {
                            PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                            Amount = response.Payload.intTopupInfo.TopupAmount,
                            Currency = response.Payload.intTopupInfo.Currency,
                            Destination = _helper_BL.GetCountryCode(response.Payload.transferData?.toMsisdn),
                            IsTransferRequest = request.IsTransferRequest
                        },
                        VoucherifyInfo = Utility.GetVoucherifyInfo(response.Payload.CampaignName, CheckOutTypes.Transfer, request.DiscountCodeType, response.Payload.IsFirstInternationalTopup, internationalTopupPoints: internationalTopupPoints, isRedeemedSuccess: response.Payload.IsRedeemedSuccess),
                    };
                    var successView = await this.RenderViewAsync(Pages.SuccessPage, successModel);
                    return Ok(GenericApiResponse<object>.Success(new { html = successView }, response.Message));
                }

                if (response.ErrorCode == (int)ApiStatusCodes.Pending3dSecure)
                {
                    if (response.Payload.threeDSecureData.type.Contains("V2", StringComparison.InvariantCultureIgnoreCase))
                    {
                        var model = new Resume3DV2ViewModel()
                        {
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                            ThreeDSServerTransId = response.Payload.threeDSecureData.threeDSServerTransId,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                        };
                        model.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        model.ReturnUrl += $"&advertiserID={advertiserID}";
                        var Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV2Page, model);
                        return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, "success"));
                    }
                    else
                    {
                        var model = new Resume3DV1ViewModel()
                        {
                            Pareq = response.Payload.threeDSecureData.pareq,
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                        };

                        model.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        model.ReturnUrl += $"&advertiserID={advertiserID}";
                        var Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV1Page, model);
                        return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, "success"));
                    }
                }
                else
                {
                    return Ok(GenericApiResponse<object>.Failure(response.Message, ApiStatusCodes.PaymentServiceError));
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: ATTController, " +
                              $"Method: TransferByNewCustomer, " +
                              $"Request:{JsonConvert.SerializeObject(request)}, " +
                              $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}," +
                              $"StackTrace: {ex.StackTrace}");

                var resp = GenericApiResponse<object>.Failure(
                    null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

                return Ok(resp);
            }
        }

        [Route("TransferByExistingCustomer")]
        [HttpPost]
        public async Task<IActionResult> TransferByExistingCustomer([FromBody] TransferByExistingCustomerRequestModelV2 request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.DiscountCode))
                {
                    request.DiscountCode = null;
                    request.DiscountCodeType = DiscountCodeType.None;
                }
                string advertiserID = HttpContext.GetAdvertiserID();
                var response = await _paymentBl.TransferByExistingCardV2Async(
                    request,
                    User.Currency(),
                    HttpContext.GetRemoteIPAddress(),
                    User.Msisdn(),
                    User.Email(),
                    advertiserID);

                if (response.ErrorCode == 0)
                {
                    var internationalTopupPoints = Utility.CalculateInternationalTopupRewardPointsRange(response.Payload.FromAmount, _voucherifyConfig.LoyaltyEarningRules.International);

                    var successModel = new SuccessViewModel()
                    {
                        Type = SuccessViewModel.CheckoutType.InternationalTopup,
                        ThemeMode = HttpContext.ThemeMode(),
                        Origination = _helper_BL.GetCountryCode(User.Msisdn()),
                        CustomerMsisdn = User.Msisdn(),
                        InternationalTopupInfo = new SuccessViewModel.InternationalTopup
                        {
                            PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                            Amount = response.Payload.intTopupInfo.TopupAmount,
                            Currency = response.Payload.intTopupInfo.Currency,
                            Destination = _helper_BL.GetCountryCode(response.Payload.transferData?.toMsisdn),
                            IsTransferRequest = request.IsTransferRequest
                        },
                        VoucherifyInfo = Utility.GetVoucherifyInfo(response.Payload.CampaignName, CheckOutTypes.Transfer, request.DiscountCodeType, response.Payload.IsFirstInternationalTopup, internationalTopupPoints: internationalTopupPoints, isRedeemedSuccess: response.Payload.IsRedeemedSuccess),
                    };
                    var successView = await this.RenderViewAsync(Pages.SuccessPage, successModel);
                    return Ok(GenericApiResponse<object>.Success(new { html = successView }, response.Message));
                }

                if (response.ErrorCode == (int)ApiStatusCodes.Pending3dSecure)
                {
                    if (response.Payload.threeDSecureData.type.Contains("V2", StringComparison.InvariantCultureIgnoreCase))
                    {
                        var model = new Resume3DV2ViewModel()
                        {
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                            ThreeDSServerTransId = response.Payload.threeDSecureData.threeDSServerTransId,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                        };
                        model.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        model.ReturnUrl += $"&advertiserID={advertiserID}";
                        var Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV2Page, model);
                        return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, "success"));
                    }
                    else
                    {
                        var model = new Resume3DV1ViewModel()
                        {
                            Pareq = response.Payload.threeDSecureData.pareq,
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                        };
                        model.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        model.ReturnUrl += $"&advertiserID={advertiserID}";
                        var Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV1Page, model);
                        return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, "success"));
                    }
                }
                else
                {
                    return Ok(GenericApiResponse<object>.Failure(response.Message, ApiStatusCodes.Pay360Error));
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: ATTController, " +
                              $"Method: TransferByExistingCustomer, " +
                              $"Request:{JsonConvert.SerializeObject(request)}, " +
                              $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}," +
                              $"StackTrace: {ex.StackTrace}");

                var resp = GenericApiResponse<object>.Failure(
                    null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

                return Ok(resp);
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        [Route("Resume3DTransaction")]
        public async Task<IActionResult> Resume3DTransaction([FromForm] Resume3DPaymentRequest request,
                                                             [FromQuery] TransferByPay360Resume3DDataV2 data)
        {
            try
            {
                if (string.IsNullOrEmpty(data.DiscountCode))
                {
                    data.DiscountCode = null;
                    data.DiscountCodeType = DiscountCodeType.None;
                }
                HttpContext.Request.Headers["AirshipEventsDisable"] = data.AirshipEventsDisable ? "1" : "0";
                var response = await _paymentBl.TransferByCardResume3DTransactionCallbackV2Async(data, request, User.Account());
                if (response.ErrorCode == 0)
                {
                    var internationalTopupPoints = Utility.CalculateInternationalTopupRewardPointsRange(response.Payload.FromAmount, _voucherifyConfig.LoyaltyEarningRules.International);
                    var product = await _attBl.GetProductByNowtelTransactionReference(data.nowtelRef, data.product);
                    return View(Pages.SuccessPage, new SuccessViewModel()
                    {
                        ThemeMode = data.ThemeMode,
                        Origination = _helper_BL.GetCountryCode(data.msisdn),
                        Type = SuccessViewModel.CheckoutType.InternationalTopup,
                        CustomerMsisdn = data.msisdn,
                        InternationalTopupInfo = new SuccessViewModel.InternationalTopup
                        {
                            PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                            Amount = response.Payload.TopupAmount,
                            Currency = response.Payload.Currency,
                            Destination = _helper_BL.GetCountryCode(product.tomsisdn),
                            IsTransferRequest = data.IsTransferRequest
                        },
                        VoucherifyInfo = Utility.GetVoucherifyInfo(response.Payload.CampaignName, CheckOutTypes.Transfer, data.DiscountCodeType, response.Payload.IsFirstInternationalTopup, internationalTopupPoints: internationalTopupPoints, isRedeemedSuccess: response.Payload.IsRedeemedSuccess),
                    });
                }
                else
                {
                    return View(Pages.ErrorPageV2, new ErrorViewModel()
                    {
                        Message = response.Message,
                        ThemeMode = data.ThemeMode,
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                        Type = CheckOutTypes.Transfer,
                        Origination = _helper_BL.GetCountryCode(data.msisdn),
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: ATTController, " +
                              $"Method: Resume3DTransaction, " +
                              $"Request:{JsonConvert.SerializeObject(request)}, " +
                              $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}," +
                              $"StackTrace: {ex.StackTrace}");

                return View(Pages.ErrorPageV2,
                    new ErrorViewModel()
                    {
                        Message = _localizer["SomethingWentWrong"],
                        ThemeMode = data.ThemeMode,
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                        Type = CheckOutTypes.TopUp,
                        Origination = _helper_BL.GetCountryCode(data.msisdn)
                    });
            }
        }
    }
}
