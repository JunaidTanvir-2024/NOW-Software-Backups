﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Localization;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Extensions.Localization;
using THAApi.Resources;
using System.Security.Claims;
using System.Globalization;

namespace THAApi.Utilities
{
    public static class ExtensionMethods
    {
        public static T ToEnum<T>(this string value)
        {
            return (T)Enum.Parse(typeof(T), value, true);
        }
        public static string Msisdn(this ClaimsPrincipal claimsPrincipal)
        {
            return claimsPrincipal.Claims.FirstOrDefault(c => c.Type.Equals("msisdn"))?.Value;
        }
        public static string Email(this ClaimsPrincipal claimsPrincipal)
        {
            return claimsPrincipal.Claims.FirstOrDefault(e => e.Type.Equals("email"))?.Value;
        }
        public static string Currency(this ClaimsPrincipal claimsPrincipal)
        {
            return claimsPrincipal.Claims.FirstOrDefault(c => c.Type.Equals("currency"))?.Value;
        }
        public static string Account(this ClaimsPrincipal claimsPrincipal)
        {
            return claimsPrincipal.Claims.FirstOrDefault(c => c.Type.Equals("acc"))?.Value;
        }

        public static string GetRemoteIPAddress(this HttpContext context, bool allowForwarded = true)
        {
           return context.Request.Headers.ContainsKey("X-Forwarded-For")
    ? context.Request.Headers["X-Forwarded-For"].ToString()
    : context.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "0.0.0.1";





            //string IpAddress;
            //if (allowForwarded)
            //{
            //    string header = (context.Request.Headers["CF-Connecting-IP"].FirstOrDefault() ?? context.Request.Headers["X-Forwarded-For"].FirstOrDefault());
            //    if (IPAddress.TryParse(header, out IPAddress ip))
            //    {
            //        IpAddress = ip.MapToIPv4().ToString();
            //    }
            //}
            //IpAddress = context.Connection.RemoteIpAddress.MapToIPv4().ToString();
            //if (string.IsNullOrEmpty(IpAddress))
            //{
            //    IpAddress = "0.0.0.1";
            //}
            //return IpAddress;
        }

        public static string GetCurrencySymbol(string currency)
        {
            switch (currency)
            {
                case "USD":
                    return "$";
                case "EUR":
                    return "€";
                case "GBP":
                    return "£";
                default:
                    return "";
            }
        }
        public static string GetLanguageISOCode(this HttpContext context)
        {
            return context.Request.Headers.ContainsKey("Accept-Language")? context.Request.Headers["Accept-Language"].ToString():null ;

        }        
    }

    public static class ControllerExtensions
    {
        public static async Task<string> RenderViewAsync<TModel>(this Controller controller, string viewName, TModel model, bool partial = false)
        {
            if (string.IsNullOrEmpty(viewName))
            {
                viewName = controller.ControllerContext.ActionDescriptor.ActionName;
            }

            controller.ViewData.Model = model;

            using (var writer = new StringWriter())
            {
                IViewEngine viewEngine = controller.HttpContext.RequestServices.GetService(typeof(ICompositeViewEngine)) as ICompositeViewEngine;
                ViewEngineResult viewResult = GetViewEngineResult(controller, viewName, partial, viewEngine);

                if (viewResult.Success == false)
                {
                    return $"A view with the name {viewName} could not be found";
                }

                ViewContext viewContext = new ViewContext(
                    controller.ControllerContext,
                    viewResult.View,
                    controller.ViewData,
                    controller.TempData,
                    writer,
                    new HtmlHelperOptions()
                );

                await viewResult.View.RenderAsync(viewContext);

                return writer.GetStringBuilder().ToString();
            }
        }
        private static ViewEngineResult GetViewEngineResult(Controller controller, string viewName, bool isPartial, IViewEngine viewEngine)
        {
            if (viewName.StartsWith("~/"))
            {
                var hostingEnv = controller.HttpContext.RequestServices.GetService(typeof(IWebHostEnvironment)) as IWebHostEnvironment;
                return viewEngine.GetView(hostingEnv.WebRootPath, viewName, !isPartial);
            }
            else
            {
                return viewEngine.FindView(controller.ControllerContext, viewName, !isPartial);

            }
        }
    }
}
