using Microsoft.AspNetCore.Mvc;

using Voucherify.Api.Features.EarningRules.Requests;

using Voucherify.Core.Commons.Filters;

namespace Voucherify.Api.Features.EarningRules;

public static class EarningRulesEndpoints
{
    private const string EndpointPrefix = "/api/earningRules";
    private const string EndpointTag = "Earning Rules Endpoints";

    public static void AddEarningRulesEndpoints(this WebApplication app)
    {
        var earningRulesEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);

        earningRulesEndpoints.MapGet("", GetEarningRules)
            .AddEndpointFilter<FluentValidationFilter<GetEarningRulesRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        earningRulesEndpoints.MapGet("/{earningRuleId}/{campaignNameOrId}", GetEarningRule)
            .AddEndpointFilter<FluentValidationFilter<GetEarningRuleRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        earningRulesEndpoints.MapPost("/enable", EnableEarningRule)
                    .AddEndpointFilter<FluentValidationFilter<EnableEarningRuleRequest>>()
                    .Produces(StatusCodes.Status400BadRequest)
                    .Produces(StatusCodes.Status200OK);

        earningRulesEndpoints.MapPost("/disable", DisableEarningRule)
            .AddEndpointFilter<FluentValidationFilter<DisableEarningRuleRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK);
    }
    private static async Task<IResult> GetEarningRules(IEarningRulesHandler earningRulesHandler, [AsParameters] GetEarningRulesRequest request)
    {
        var result = await earningRulesHandler.GetEarningRules(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetEarningRule(IEarningRulesHandler earningRulesHandler, [AsParameters] GetEarningRuleRequest request)
    {
        var result = await earningRulesHandler.GetEarningRule(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> EnableEarningRule(IEarningRulesHandler earningRulesHandler, [FromBody] EnableEarningRuleRequest request)
    {
        var result = await earningRulesHandler.EnableEarningRule(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.BadRequest(result);
    }
    private static async Task<IResult> DisableEarningRule(IEarningRulesHandler earningRulesHandler, [FromBody] DisableEarningRuleRequest request)
    {
        var result = await earningRulesHandler.DisableEarningRule(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.BadRequest(result);
    }
}
