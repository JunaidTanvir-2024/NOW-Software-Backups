﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using NowPayG.Configurations;
using NowPayG.Utility;
using NowPayG.Services;
using NowPayG.Services.Interfaces;
using Serilog;

namespace NowPayG
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(options =>
            {
                options.LoginPath = "/login/";
            });

            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.ConsentCookie.Name = "NowPayGAcceptCookie";
                //options.ConsentCookie.IsEssential = true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.Configure<CookieTempDataProviderOptions>(options => {
                options.Cookie.IsEssential = true;
            });

            services.Configure<EndPoints>(Configuration.GetSection("EndPoints"));
            services.Configure<Pay360Config>(Configuration.GetSection("Pay360Config"));
            services.Configure<PayPalConfig>(Configuration.GetSection("PayPalConfig"));
            services.Configure<ATTConfig>(options => Configuration.GetSection("ATTConfig").Bind(options));

            services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));

            services.AddTransient<IPortService, PortService>();
            services.AddTransient<IPay360Service, Pay360Service>();
            services.AddTransient<IPayPalService, PayPalService>();

            services.AddSingleton((ILogger)new LoggerConfiguration()
             .MinimumLevel.Debug()
             .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "NowPayG-log-{Date}.txt"))
             .CreateLogger());

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2).AddSessionStateTempDataProvider();
            services.AddSession(options =>
            {
                options.Cookie.IsEssential = true;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseStatusCodePagesWithReExecute("/Error/{0}");
                app.UseExceptionHandler("/SystemError");
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.UseStaticFiles();
            app.UseCookiePolicy();
            app.UseAuthentication();
            app.UseSession();
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });

        }
    }
}
