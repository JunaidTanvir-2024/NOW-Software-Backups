﻿namespace Application.Common.Settings;
public sealed class PaymentRenewalSettings
{
    public const string SectionName = "PaymentRenewalSettings";
    public static PaymentRenewalSettings Bind = new PaymentRenewalSettings();
    public bool IsDefaultCard { get; set; }
    public bool IsNewCard { get; set; }
    public bool IsPaypal { get; set; }
}
