﻿using CancelBundleApi.Models.DbModels;

namespace CancelBundleApi.Repositories.Interfaces
{
    public interface IServiceLoggerRepository
    {
        Task<LkptService> GetServiceDetailsByName(string serviceName);
        Task<int> InsertServiceApiLog(ServiceApiAuditTrail serviceLog);
    }
}
