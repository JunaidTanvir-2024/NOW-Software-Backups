using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Products;

public class SkuUpdate
{
    [JsonPropertyName("sku")]
    public string? SkuValue { get; set; }

    [JsonPropertyName("price")]
    public long? Price { get; set; }

    [JsonPropertyName("attributes")]
    public Metadata? Attributes { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    public static SkuUpdate FromEmpty()
    {
        return new SkuUpdate();
    }

    public static SkuUpdate FromSku(Sku sku)
    {
        Metadata? metadata = null;
        if (sku.Metadata != null)
        {
            metadata = new Metadata();

            foreach (var key in sku.Metadata.Keys)
            {
                metadata.Add(key, sku.Metadata[key]);
            }
        }

        Metadata? attributes = null;

        if (sku.Attributes != null)
        {
            attributes = new Metadata();

            foreach (var key in sku.Attributes.Keys)
            {
                attributes.Add(key, sku.Attributes[key]);
            }
        }

        return new SkuUpdate()
        {
            SkuValue = sku.SkuValue,
            Price = sku.Price,
            Attributes = attributes,
            Metadata = metadata
        };
    }

    public SkuUpdate WithSkuValue(string skuValue)
    {
        SkuValue = skuValue;
        return this;
    }

    public SkuUpdate WithPrice(long? price)
    {
        Price = price;
        return this;
    }

    public SkuUpdate WithAttributes(Metadata attributes)
    {
        Attributes = attributes;
        return this;
    }

    public SkuUpdate WithMetadata(Metadata metadata)
    {
        Metadata = metadata;
        return this;
    }
}
