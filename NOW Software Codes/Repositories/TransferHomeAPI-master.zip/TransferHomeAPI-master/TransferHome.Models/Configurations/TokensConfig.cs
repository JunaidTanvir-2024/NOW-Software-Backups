﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrasnferHome.Models.Configurations
{
    public class TokensConfig
    {
        public int EmailTokenExpiryMinutes { get; set; }
        public int MobileTokenExpiryMinutes { get; set; }
    }
}
