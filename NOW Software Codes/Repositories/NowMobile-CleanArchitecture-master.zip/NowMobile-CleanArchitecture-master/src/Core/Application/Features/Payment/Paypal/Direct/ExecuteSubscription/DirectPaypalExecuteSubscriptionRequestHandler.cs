﻿using Application.Common.Interfaces.Payment;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;
using Domain.Aggregate;
using Mapster;
using Newtonsoft.Json;

namespace Application.Features.Payment.Paypal.Direct.ExecuteSubscription;

public class DirectPaypalExecuteSubscriptionRequestHandler : IRequestHandler<DirectPaypalExecuteSubscriptionRequest, Result<PaypalResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly IUnitOfWork _uow;
    private readonly ICurrentUser _currentUser;
    private readonly IUnitOfWork _unitOfWork;

    public DirectPaypalExecuteSubscriptionRequestHandler(IPaymentService paymentService,
        IUnitOfWork uow,
        ICurrentUser currentUser,
        IUnitOfWork unitOfWork)
    {
        _paymentService = paymentService;
        _uow = uow;
        _currentUser = currentUser;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<PaypalResponse>> Handle(
        DirectPaypalExecuteSubscriptionRequest request, CancellationToken cancellationToken)
    {
        (bool isTrue, Domain.Aggregate.OrderDetails orderDetails, IEnumerable<Domain.Aggregate.OrderItemDetails> orderItemDetails) = await _uow.PaymentRepo.GetOrderDetails(request.OrderId);
        if (orderDetails != null && orderItemDetails.Any())
        {

            var orderData = JsonConvert.DeserializeObject<OrderData>(orderDetails.OrderData!);
            if (orderData.BundleInfo != null && orderData.BundleInfo.IsRenewable == true)
            {
                var BundleInfo = await _unitOfWork.BundleRepo.GetBundleById(new Bundle.BundleDetail.BundleByIdRequest { Id = orderData.BundleInfo.BundleId.ToString() });
                var misdnDetials = await _uow.UserRepo.GetMsisdnDetail(orderDetails.Msisdn);
                // Missing Account Id
                await _uow.BundleRepo.SetBundleAutoRenewal(orderData.BundleInfo!.IsRenewable,
                    orderDetails.Msisdn, misdnDetials.AccountId!,
                    BundleInfo.UuId,
                    orderDetails.Email,
                    PaymentMethod.Paypal,
                    orderData.CardMaskedPan!);
            }
            if (orderData.AutoTopupInfo != null && orderData.AutoTopupInfo.Status == true)
            {
                await _uow.TopupRepo.SetAutoTopup(
               orderData.AutoTopupInfo.Status, orderDetails.Msisdn, orderDetails.Email, orderData!.AutoTopupInfo.TopupAmount, orderData.AutoTopupInfo.CurrencySymbol,
               orderData.AutoTopupInfo.ThresHoldAmount, PaymentMethod.Paypal);
            }
            return Result<PaypalResponse>.Success("Subscription Activated successfully!");
        }
        return Result<PaypalResponse>.Failure(CustomStatusKey.InternalServerError,CustomStatusCode.InternalServerError);
    }
}