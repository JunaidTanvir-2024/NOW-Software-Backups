﻿namespace THCC.Infrastructure.Services.Mailing.External.Models;
public enum RecipientType
{
    To = 1,
    CC = 2,
    BCC = 3,
}