﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmsOutReachCallBackUrlApi.Contracts.Poppayouts.Request
{
    public class PoppayoutsSmsCallBackUrlRequest
    {
        //public string to { get; set; }
        public string queue { get; set; }
        public string smslog_id { get; set; }
        public string timestamp { get; set; }
        public string deliverystatus { get; set; }
        public DateTime? deliverydatetime { get; set; }
    }
}
