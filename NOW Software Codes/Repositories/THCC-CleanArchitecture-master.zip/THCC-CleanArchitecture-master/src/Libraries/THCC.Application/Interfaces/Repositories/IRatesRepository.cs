﻿using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Repositories
{
    public interface IRatesRepository : ServiceType.IScoped
    {
        Task<IEnumerable<Rate>> GetRates();

    }
}
