using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Features.User.Login;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Services;

public interface IJwtService : ServiceType.IScoped
{
    Task<TokenInfoDto> GetToken(User user, string? ipAddress);
    Task<LoginResponse?> RefreshTokenAsync(string token, string refreshToken);
    ECDsa GetSecurityKeyViaFile(string? filePath);
}