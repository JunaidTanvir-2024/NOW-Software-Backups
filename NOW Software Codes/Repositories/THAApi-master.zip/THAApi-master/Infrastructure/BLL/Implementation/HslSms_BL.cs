﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{

	public class HslSms_BL : IHslSms_BL
	{
		private readonly IUserAccount_DL UserAccount_DL;
		private readonly HslSmsConfig _config;
		private readonly IHelper_BL helper_BL;

		public HslSms_BL(IUserAccount_DL userAccount_DL, IOptions<HslSmsConfig> config, IHelper_BL helper_BL)
		{
			UserAccount_DL = userAccount_DL;
			this._config = config.Value;
			this.helper_BL = helper_BL;
		}
		private string ParseNumber(string number)
		{
			var returnNumber = number.Replace("+", "");

			return returnNumber.StartsWith("00") ? returnNumber.Remove(0, 2) : returnNumber;
		}

		public static int GetMessageCount(string message, string encoding)
		{
			if (encoding == "GSM7")
			{
				return (int)Math.Ceiling(message.Length / 160d);
			}

			return (int)Math.Ceiling(message.Length / 70d);
		}

		public static string GetEncoding(string message)
		{
			const string charSet = "@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞ\x1bÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?" +
								   "¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ`¿abcdefghijklmnopqrstuvwxyzäöñüà";

			return message.Select(c => charSet.IndexOf(c)).Any(index => index == -1) ? "UCS2" : "GSM7";
		}
		public async Task<SmsResult> Send1(string sentFrom, string sentTo, string message, bool paid, bool isSignupPinSms = false, string language = "en")
		{

			if (string.IsNullOrEmpty(sentFrom))
				throw new ArgumentException("Value cannot be null or empty.", nameof(sentFrom));
			if (string.IsNullOrWhiteSpace(sentTo))
				throw new ArgumentException("Value cannot be null or whitespace.", nameof(sentTo));
			if (string.IsNullOrWhiteSpace(message))
				throw new ArgumentException("Value cannot be null or whitespace.", nameof(message));

			var receivedToMsisdn = sentTo;
			var messageCount = 0;

			sentTo = sentTo.Trim();
			sentTo = ParseNumber(sentTo);

			sentFrom = sentFrom.Trim();

			string formattedFrom = sentFrom;
			string formattedTo = sentTo;

			if (!isSignupPinSms)
			{
				formattedFrom = ParseNumber(sentFrom);
				if (formattedFrom.ToLower() != "talk home")
				{
					formattedTo = PhoneNumberFixer.Fix(formattedTo);
				}
			}

			Sms smsStatus = null;

			smsStatus = new Sms
			{
				Provider = Provider.Xeebi,
				Sender = formattedFrom,
				To = formattedTo,
				Status = Status.Pending,
				Sent = DateTime.UtcNow,
				ProviderError = null,
				ProviderId = null
			};

			int result = await UserAccount_DL.SaveSms(smsStatus);
			if (result < 1)
			{
				await UserAccount_DL.SmsDbContextSaveFailed(receivedToMsisdn);
			}

			//try
			//{
			//    //Record our version
			//    smsStatus = smsContext.SmsData.Add(new WebServices.Contracts.Sms
			//    {
			//        Provider = WebServices.Models.Provider.Xeebi,
			//        Sender = formattedFrom,
			//        To = formattedTo,
			//        Status = WebServices.Contracts.Status.Pending,
			//        Sent = DateTime.UtcNow
			//    });

			//    await smsContext.SaveChangesAsync();
			//}
			//catch (Exception ex)
			//{
			//    await userJourneyService.SmsDbContextSaveFailed(receivedToMsisdn);

			//    Debug.WriteLine(ex.ToString());
			//}

			HttpResponseMessage response = null;
			string queryString = string.Empty;
			string encodingType = string.Empty;

			try
			{
				encodingType = GetEncoding(message);

				messageCount = GetMessageCount(message, encodingType);

				if (paid)
				{
					var balance = await UserAccount_DL.GetUserAccountBalanceAsync(sentFrom);


					var totalMessageCost = 0.10m;

					if (decimal.Parse(balance.Balance, CultureInfo.InvariantCulture) < totalMessageCost)
					{
						return SmsResult.Error(sentTo, SmsErrorCode.InsufficentBalance);
					}

					var wasUserCharged = await UserAccount_DL.ChargeUser1(sentFrom, sentTo, messageCount);

					if (!wasUserCharged)
					{
						return SmsResult.Error(sentTo, SmsErrorCode.InsufficentBalance);
					}
				}


			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.ToString());
			}

			var tags = new string[] { $"sender:{smsStatus.Sender}", $"receiver:{smsStatus.To}" };

			string XeebiId = string.Empty;
			string clxError = string.Empty;


			string[] destinations = new string[] { sentTo };
			var countryBase = _config.CountryBaseSenders;
			var destination = helper_BL.GetCountryCode(sentTo);
			if (countryBase.ContainsKey(destination))
			{
				sentFrom = countryBase[destination];
			}
			//Actually send the SMS
			var body = JsonConvert.SerializeObject(new
			{
				destination = destinations,
				origination = sentFrom,
				message = message
			}, new JsonSerializerSettings
			{
				ContractResolver = new DefaultContractResolver()
			});


			var requestMessage = new HttpRequestMessage(HttpMethod.Post,
						$"api/HslSms/SendSms")
			{
				Content = new StringContent(body, Encoding.UTF8, "application/json")
			};

			HttpClient client = new HttpClient();
			client.BaseAddress = new Uri(_config.sms_sap_local_uri);
			var result2 = await client.SendAsync(requestMessage);

			if (result2.IsSuccessStatusCode)
			{
				//var content = await result.Content.ReadAsStringAsync();

				//XeebiSendSmsResponse varXeebi = JsonConvert.DeserializeObject<XeebiSendSmsResponse>(content);

				//XeebiId = varXeebi.message_id;
				//smsStatus.Provider = WebServices.Models.Provider.Xeebi;
				//smsStatus.ProviderId = XeebiId;
				//smsStatus.Status = WebServices.Contracts.Status.Pending;
				//DogStatsd.Increment("clx.pending");

				//DogStatsd.Increment("ClxService.Send.Successful", sampleRate: 0.4, tags: tags);

				//await smsContext.SaveChangesAsync();
				return SmsResult.Ok(smsStatus.To);
			}


			//smsStatus.Provider = WebServices.Models.Provider.Xeebi;
			//smsStatus.ProviderId = XeebiId;
			//smsStatus.ProviderError = clxError;
			//smsStatus.Status = WebServices.Contracts.Status.Error;
			//await smsContext.SaveChangesAsync();

			var errorTag = new[] { $"error:{clxError}" };

			var unifiedTags = tags.Union(errorTag).ToArray();

			return SmsResult.Error(smsStatus.To, SmsErrorCode.ProviderError, "Service unavailable");
		}

	}
}
