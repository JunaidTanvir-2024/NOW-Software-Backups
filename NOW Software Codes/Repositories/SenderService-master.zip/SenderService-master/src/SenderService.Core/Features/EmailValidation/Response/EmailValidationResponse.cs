﻿namespace SenderService.Core.Features.EmailValidation.Response;
public class EmailValidationResponse
{
    public bool IsEmailValid { get; set; }
}
