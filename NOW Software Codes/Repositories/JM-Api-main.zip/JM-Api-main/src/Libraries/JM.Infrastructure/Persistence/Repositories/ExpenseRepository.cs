using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.EntityFrameworkCore;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;

public class ExpenseRepository(AppDbContext context, ILogger logger) : IExpenseRepository
{
    private readonly AppDbContext _context = context;
    private readonly ILogger _logger = logger;

    public async Task<Expense> AddExpense(Expense expense)
    {
        try
        {
            var addedExpense = await _context.Set<Expense>().AddAsync(expense);
            return addedExpense.Entity;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ExpenseRepository), nameof(AddExpense));
            return default!;
        }
    }
    public async Task<ExpenseCategory> AddExpenseCategory(ExpenseCategory expenseCategoryse)
    {
        try
        {
            var addedExpense = await _context.Set<ExpenseCategory>().AddAsync(expenseCategoryse);
            return addedExpense.Entity;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ExpenseRepository), nameof(AddExpenseCategory));
            return default!;
        }
    }
    public void UpdateExpenseCategory(ExpenseCategory expenseCategory)
    {
        try
        {
            _context.Entry(expenseCategory).CurrentValues.SetValues(expenseCategory);
            _context.Entry(expenseCategory).State = EntityState.Modified;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ExpenseRepository), nameof(UpdateExpenseCategory));
        }
    }
    public async Task<ExpenseCategory?> GetExpenseCategory(Expression<Func<ExpenseCategory, bool>> expression)
    {
        try
        {
            return await _context.Set<ExpenseCategory>()
                .Where(expression)
                .FirstOrDefaultAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ExpenseRepository), nameof(GetExpenseCategory));
            return default!;
        }
    }
    public async Task<IEnumerable<ExpenseCategory>> GetExpenseCategoryList()
    {
        try
        {
            return await _context.Set<ExpenseCategory>()
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ExpenseRepository), nameof(GetExpenseCategoryList));
            return default!;
        }
    }
    public void UpdateExpense(Expense expense)
    {
        try
        {
            _context.Entry(expense).CurrentValues.SetValues(expense);
            _context.Entry(expense).State = EntityState.Modified;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ExpenseRepository), nameof(UpdateExpense));
        }
    }
    public ExpenseCategory RemoveExpenseCategory(ExpenseCategory expenseCategory)
    {
        try
        {
            var removedExpense = _context.Set<ExpenseCategory>().Remove(expenseCategory);
            return removedExpense.Entity;
        }

        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ExpenseRepository), nameof(RemoveExpenseCategory));
            return default!;
        }
    }
    public async Task<Expense?> GetExpense(Expression<Func<Expense, bool>> expression)
    {
        try
        {
            return await _context.Set<Expense>()
                .Where(expression)
                .Include(x => x.Traveler)
                .ThenInclude(x => x.User)
                .Include(x => x.Category)
                .FirstOrDefaultAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ExpenseRepository), nameof(GetExpense));
            return default!;
        }
    }
    public async Task<IEnumerable<Expense>> GetExpenseList(Expression<Func<Expense, bool>> expression = default!)
    {
        try
        {
            var query = _context.Set<Expense>()
                   .Include(x => x.Traveler)
                    .ThenInclude(x => x.User)
                    .Include(x => x.Category);
            return expression is null ? await query.Where(x => x.IsActive).ToListAsync() : await query.Where(expression).ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ExpenseRepository), nameof(GetExpenseList));
            return default!;
        }
    }
}
