﻿using Application.Common.Enums;
using Application.Common.Interfaces.Payment;
using Application.Common.Interfaces.Repositories;
using Application.Common.Settings;
using Application.Features.Account.Product.Get;
using Application.Features.Payment.Card.CustomerCards;
using Application.Features.Payment.Card.Models;
using MediatR;
using Microsoft.Extensions.Options;

namespace Application.Features.Payment.Card.RemoveCard;

public class RemoveCardRequestHandler : IRequestHandler<RemoveCardRequest, Result<List<CustomerCard>>>
{
    private readonly IStringLocalizer<RemoveCardRequestHandler> _localizer;
    private readonly ICardService _cardService;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly CallBackSettings _callbackSettings;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ITopupRepository _topupRepository;

    public RemoveCardRequestHandler(
        IStringLocalizer<RemoveCardRequestHandler> localizer,
        ICardService cardService,
        ICurrentUser currentUser,
        ICommonService commonService,
        IUnitOfWork unitOfWork,
        IOptions<CallBackSettings> callbackSettings,
        ITopupRepository topupRepository)
    {
        _localizer = localizer;
        _cardService = cardService;
        _currentUser = currentUser;
        _commonService = commonService;
        _unitOfWork = unitOfWork;
        _topupRepository = topupRepository;
        _callbackSettings = callbackSettings.Value;
    }

    public async Task<Result<List<CustomerCard>>> Handle(RemoveCardRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();
        //Get all user numbers    
        var productResponse = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        productResponse = productResponse.Where(x => x.Status == (int) SimStatus.Completed).ToList();
        //Get Customer Cards
        var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
        //If this is last card to remove
        if (cards.Count == 1)
        {
            foreach (var missdn in productResponse)
            {
                if (!string.IsNullOrEmpty(missdn.AccountId))
                {
                    //If any Rolling bundle renewal is on then show error otherwise remove card
                    var isMonthlyRenewalActive = await _unitOfWork.PaymentRepo.AnyActiveMonthlyAutoRenewal(missdn?.AccountId!);
                    if (isMonthlyRenewalActive)
                    {
                        return Result<List<CustomerCard>>.Failure(_localizer[CustomStatusKey.RemoveCardAutoRenewalOnError], CustomStatusCode.InternalServerError);
                    }
                    else
                    {
                        await _unitOfWork.PaymentRepo.SetOffAllAutoTopupAutoRenewalWithCard(missdn?.AccountId!, missdn?.Msisdn!);
                    }
                }
            }
        }
        //Recurring: this logic is to handle remove card for recurring autoRenewals and autoTopups
        foreach (var missdn in productResponse)
        {
            if (!string.IsNullOrEmpty(missdn.AccountId))
            {
                var card = cards.FirstOrDefault(e => e.CardToken == request.CardToken);
                if (card == null)
                {
                    return Result<List<CustomerCard>>.Failure(_localizer[CustomStatusKey.RemoveCardError], CustomStatusCode.InternalServerError);
                }
                //Set CardPan and InitialTransactionId to null if AutoTopup is active with Recurring
                var autoTopupInfo = await _topupRepository.GetAutoTopup(missdn.Msisdn!, _currentUser.GetUserEmail()!);
                if (autoTopupInfo!=null && autoTopupInfo.Status && autoTopupInfo.PaymentMethod?.Equals("Card")==true && autoTopupInfo.MaskedPan?.Equals(card.MaskedPan)==true)
                {
                    await _topupRepository.SetAutoTopup(autoTopupInfo.Status, missdn.Msisdn!, _currentUser.GetUserEmail()!, autoTopupInfo.Topup, autoTopupInfo.Currency!, autoTopupInfo.ThresHold, PaymentMethod.Card);
                }
                //
                await _unitOfWork.PaymentRepo.ValidateRemoveCard(missdn?.AccountId!, missdn?.Msisdn!, card.MaskedPan);
                //if (!cardRemoveValid)
                //{
                //    return Result<List<CustomerCard>>.Failure(_localizer[CustomStatusKey.RemoveCardAutoRenewalOnError], CustomStatusCode.InternalServerError);
                //}

            }
        }
        //Remove Card
        var iscardRemoved = await _cardService.RemoveCard(request.CardToken, _currentUser.GetUserEmail()!);
        if (!iscardRemoved)
        {
            return Result<List<CustomerCard>>.Failure(_localizer[CustomStatusKey.RemoveCardError], CustomStatusCode.InternalServerError);
        }
        cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
        if (cards != null)
        {
            foreach (var card in cards)
            {
                card.ImageUrl = (IsAppRequest ? _callbackSettings.AppBaseUrl!
                : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(card.CardScheme);
            }
        }
        return Result<List<CustomerCard>>.Success(cards, _localizer[CustomStatusKey.RemoveCardSuccess]);
    }
}