﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using ATT.Infrastructure.BLL.Sochitel;
using ATT.Infrastructure.BLL.TransferTo;
using ATT.Infrastructure.DAL;
using ATT.Models.Configurations;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Sochitel.Request;
using ATT.Models.Contracts.Sochitel.Response;
using ATT.Models.Database;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using Serilog;

namespace ATT.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class SochitelController : ControllerBase
    {

        private ISochiPost_BL _SochiTelPost;
        private ISochitelAutomation_BL _SochiTelAutomation;
        private ILogger _loggerAPIAccess;
        private IAttDb_DL _dbATT;
        private ITransfertoPost_BL _TransferToPost;
        private SochitelConfig SochitelConf;
        private ISochiTelAuth_BL SochitelAuth;


        public SochitelController(ISochitelAutomation_BL sochiTelAutomation, ISochiPost_BL post, ITransfertoPost_BL transferToPost, ILogger appLoggers, IAttDb_DL _db, IOptions<SochitelConfig> sochitelConf, ISochiTelAuth_BL sochitelAuth)
        {
            _SochiTelAutomation = sochiTelAutomation;
            _SochiTelPost = post;
            _TransferToPost = transferToPost;
            _loggerAPIAccess = appLoggers;
            _dbATT = _db;
            SochitelConf = sochitelConf.Value;
            SochitelAuth = sochitelAuth;
        }

        #region sochitelGetOperatorProductsMSISDN

        [HttpGet]
        [Route("SochitelGetProducts")] 
        public async Task<IActionResult> GetFreeSwitchOperatorProducts(string destinationMSISDN, string account, string fromMSISDN, string productCode, string productItemCode)
        {
            try
            {
                var result = await _SochiTelAutomation.GetFreeSwitchOperatorProducts(fromMSISDN, destinationMSISDN, account, productCode, productItemCode);
                return Ok(result);
            }
            catch(Exception ex)
            {
                _loggerAPIAccess.Debug($" SochitelController:  \"GET /GetFreeSwitchOperatorProducts\"  ,Pasameters: msisdn={destinationMSISDN}, currency-{account}, ErrorMessage: {ex.Message} ");
                var result2 = new { errorCode = 2, status = "Failure", message = ex.Message };
                return Ok(result2);
            }
        }



        #endregion sochitelGetOperatorProductsMSISDN



        // ------------------------------------------------------------------------------------------------------------------------------------------------------------------

        #region getOperatorsAndProducts_ForDaemon

        [HttpGet]
        [Route("getOperatorsAndProducts")]
        public async Task<IActionResult> SochiGetOperatorsAPICall(string country, string account)
        {
            try
            {
                GenericApiResponse<Dictionary<string, Operator>> operatorsResponse = await _SochiTelPost.GetOperators(country, 0, 0, account);

                if (operatorsResponse.Status == 0)
                {
                    if (operatorsResponse.Result.Count > 0)
                    {

                        PayLoad payload = new PayLoad();
                        JsonOperatorProductResponse result = new JsonOperatorProductResponse();
                        result.message = "Operators found";
                        result.status = "Success";
                        result.errorCode = 0;
                        List<AttOperator> operators = new List<AttOperator>();


                        //now loop through each operator and get its products and prepare the response
                        foreach (KeyValuePair<string, Operator> opr in operatorsResponse.Result)
                        {
                            GenericApiResponse<OperatorProducts> operatorProductsResponse = await _SochiTelPost.getOperatorProductsOperatorID(opr.Key, account);

                            List<AttProduct> products = new List<AttProduct>();
                            AttOperator operatorDetails = new AttOperator();


                            if (operatorProductsResponse.Status == 0) // Success
                            {
                                operatorProductsResponse.Result.CountryName = opr.Value.country.name;
                                operatorProductsResponse.Result.OperatorID = opr.Value.id;
                                operatorProductsResponse.Result.OperatorName = opr.Value.name;
                                operatorProductsResponse.Result.OperatorLogo = "https://media.sochitel.com/img/operators/" + opr.Value.brandId + ".png";
                                operatorProductsResponse.Result.CountryLogo = "https://media.sochitel.com/img/flags/" + opr.Value.country.id + ".png";

                                // Range type product checking
                                if (operatorProductsResponse.Result.products.Count == 1 && operatorProductsResponse.Result.products.First().Value.priceType == "range")
                                {
                                    decimal SochitelMinimumUserValue = decimal.Parse(operatorProductsResponse.Result.products.First().Value.price.min.user.ToString());
                                    decimal SochitelMaximumUserValue = decimal.Parse(operatorProductsResponse.Result.products.First().Value.price.max.user.ToString());
                                    decimal SOchitelMinMaxUserValueDifference = SochitelMaximumUserValue - SochitelMinimumUserValue;

                                    decimal SochitelMinimumOperatorValue = decimal.Parse(operatorProductsResponse.Result.products.First().Value.price.min.@operator.ToString());
                                    decimal SochitelMaximumOperatorValue = decimal.Parse(operatorProductsResponse.Result.products.First().Value.price.max.@operator.ToString());
                                    decimal SochitelMinMaxOperatorValueDifference = SochitelMaximumOperatorValue - SochitelMinimumOperatorValue;

                                    bool varTransferToAPIAccessed = true;
                                    GenericApiResponse<string> transferToOperatorProducts = null;
                                    //get master operator from master table based on sochitel operator id
                                    OperatorMasterOperator operatorMasterOperatorRecord = await _dbATT.getOperatorMasterOperatorRecord(int.Parse(opr.Key));

                                    if (operatorMasterOperatorRecord == null)
                                        varTransferToAPIAccessed = false;
                                    else
                                    {
                                        //get corresponding TransferTo operator from master table based on master operator id
                                        operatorMasterOperatorRecord = await _dbATT.getMasterServiceProviderRecord(2, operatorMasterOperatorRecord.MasterOperatorId);

                                        if (operatorMasterOperatorRecord == null)
                                            varTransferToAPIAccessed = false;
                                        else
                                        {
                                            // get TransferTo operator products
                                            transferToOperatorProducts = await _TransferToPost.transferToOperatorPriceList(account, operatorMasterOperatorRecord.OperatorId);

                                            // if TransferTo operator products not found
                                            if (transferToOperatorProducts.Status != 0)
                                                varTransferToAPIAccessed = false;
                                        }
                                    }


                                    // if TransferTo operator products found
                                    if (varTransferToAPIAccessed == true)
                                    {
                                        XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                                        xmlDoc.LoadXml(transferToOperatorProducts.Result); // Load the XML document from the specified file

                                        XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                                        if (xmlproductslist.Count == 0)
                                        {
                                            // return empty reply
                                        }
                                        string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                                        XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                                        string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                                        XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                                        string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');

                                        string GUID = Guid.NewGuid().ToString();
                                        operatorDetails.id = operatorProductsResponse.Result.OperatorID;
                                        operatorDetails.name = operatorProductsResponse.Result.OperatorName;
                                        operatorDetails.country = operatorProductsResponse.Result.CountryName;
                                        operatorDetails.nowtelTransactionReference = GUID;
                                        operatorDetails.iconUri = operatorProductsResponse.Result.OperatorLogo;

                                        for (int a = 0; a < productslist.Length; a++)
                                        {
                                            //include only those products that has product values between min and max range of sochitel
                                            if (decimal.Parse(retailpricelist[a]) >= SochitelMinimumUserValue && decimal.Parse(retailpricelist[a]) <= SochitelMaximumUserValue)
                                            {
                                                decimal sochiCalculatedValue = Math.Round((((decimal.Parse(productslist[a]) - SochitelMinimumOperatorValue) / SochitelMinMaxOperatorValueDifference) * SOchitelMinMaxUserValueDifference) + SochitelMinimumUserValue, 2);

                                                products.Add(_dbATT.GetProduct(
                                                    account,         //clientccy
                                                    xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                                    productslist[a],     //product
                                                    sochiCalculatedValue.ToString(),  //itemPriceClientccy
                                                    sochiCalculatedValue.ToString()   //totalPriceClientccy
                                                ));
                                            }
                                        }

                                        operatorDetails.products = products;
                                        operators.Add(operatorDetails);
                                    }

                                    // TransferTo operator products not found. Make customized range based products using different percentages.
                                    else
                                    {

                                        string[] breakdownPercentages = SochitelConf.RangeToProductConversionPercentages.Split(',');

                                        string GUID = Guid.NewGuid().ToString();
                                        operatorDetails.id = operatorProductsResponse.Result.OperatorID;
                                        operatorDetails.name = operatorProductsResponse.Result.OperatorName;
                                        operatorDetails.country = operatorProductsResponse.Result.CountryName;
                                        operatorDetails.nowtelTransactionReference = GUID;
                                        operatorDetails.iconUri = operatorProductsResponse.Result.OperatorLogo;

                                        foreach (string percent in breakdownPercentages)
                                        {
                                            decimal percentValue = decimal.Parse(percent) / 100;

                                            products.Add(_dbATT.GetProduct(
                                                account,         //clientccy
                                                operatorProductsResponse.Result.currency.@operator,    //receiverccy
                                                Math.Round(((SochitelMinMaxOperatorValueDifference * percentValue) + SochitelMinimumOperatorValue), 2).ToString(),     //product
                                                Math.Round(((SOchitelMinMaxUserValueDifference * percentValue) + SochitelMinimumUserValue), 2).ToString(),  //itemPriceClientccy
                                                Math.Round(((SOchitelMinMaxUserValueDifference * percentValue) + SochitelMinimumUserValue), 2).ToString()   //totalPriceClientccy
                                            ));
                                        }
                                        operatorDetails.products = products;
                                        operators.Add(operatorDetails);
                                    }
                                }

                                // Fixed type products (Not Range type).
                                else
                                {

                                    AttOperator attOperator = convertOperatorProducts(operatorProductsResponse.Result, account, "", false);
                                    operators.Add(attOperator);
                                }
                            }
                            else
                            {
                                //some error occured while access current operator's products from Sochitel Log this error
                                //just log this error and do not return any error message

                                _loggerAPIAccess.Debug($" \"GET /getOperatorsAndProducts\"  Failed  Source:Sochitel API           Reason-Error Occured while accessing products of OperatorID:{opr.Key}  SOhitel return this error message :{operatorProductsResponse.Message}");
                            }
                        }

                        payload.operators = operators;
                        result.payload = payload;
                        _loggerAPIAccess.Information($"  \"GET /getOperatorsAndProducts\"  Success  Parameters-country={country}  currency={account}");
                        return Ok(result);
                    }
                    else
                    {
                        _loggerAPIAccess.Debug($"  \"GET /getOperatorsAndProducts\"  Failed  Parameters-country={country}  currency={account}  Reason=No operators found");
                        var resultPayload = new { reason = "No Operators Found" };
                        var result = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                        return Ok(result);
                    }
                }
                else
                {
                    //Error ocured in Sochitel API while getting operator products from backend   
                    _loggerAPIAccess.Debug($"  \"GET /getOperatorsAndProducts\"  Failed  Source:Sochitel API  Parameters-country:{country}   currency={account}   Reason={operatorsResponse.Message} ");
                    var resultPayload = new { reason = operatorsResponse.Message };
                    var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /getOperatorsAndProducts\"  Failed  Source:General  Parameters-country:{country}   currency:{account}    Message:{ex.ToString()}");
                var resultPayload = new { reason = "General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                return Ok(errorResult);
            }
        }

        private AttOperator convertOperatorProducts(OperatorProducts operatorProductsResponse, string account, string msisdn, bool insertAPIReferenceInDB)
        {

            List<AttProduct> products = new List<AttProduct>();
            string GUID = Guid.NewGuid().ToString();
            AttOperator operatorDetails = new AttOperator();
            operatorDetails.id = operatorProductsResponse.OperatorID;
            operatorDetails.name = operatorProductsResponse.OperatorName;
            operatorDetails.country = operatorProductsResponse.CountryName;
            operatorDetails.nowtelTransactionReference = GUID;
            operatorDetails.iconUri = operatorProductsResponse.OperatorLogo;

            foreach (KeyValuePair<string, Product> product in operatorProductsResponse.products)
            {

                if (product.Value.priceType == "fixed")
                {

                    products.Add(_dbATT.GetProduct(
                        operatorProductsResponse.currency.user,         //clientccy
                        operatorProductsResponse.currency.@operator,    //receiverccy
                        product.Value.price.@operator,     //product
                        product.Value.price.user,  //itemPriceClientccy
                        product.Value.price.user   //totalPriceClientccy
                    ));

                }

            }

            operatorDetails.products = products;
            return operatorDetails;
        }

        #endregion getOperatorsAndProducts_ForDaemon


        #region sochitelGetOperatorProductsMSISDN

        [HttpGet]
        [Route("sochitelGetOperatorProductsMSISDN")]
        public async Task<IActionResult> SochiGetOperatorProductsAPICall(int nsid, string destinationMSISDN, string account)
        {
            ServiceProvider serviceProviderRecord = await _dbATT.getServiceProviderRecord(nsid, destinationMSISDN);
            if (serviceProviderRecord != null)
            {
                var result = await _SochiTelAutomation.sochitelGetOperatorProductsMSISDN(destinationMSISDN, account, serviceProviderRecord.OriginDestinationId);
                return Ok(result);
            }
            else
            {
                _loggerAPIAccess.Debug($"  \"GET /sochitelGetOperatorProductsMSISDN\"  Failed  Source:ATT API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}  NSID--{nsid}     Reason=Service Not Found ");
                var result2 = new { errorCode = 2, status = "Failure", message = "Service Not Found For this  MSISDN" };
                return Ok(result2);
            }
        }


        #endregion sochitelGetOperatorProductsMSISDN

        #region sendSMS

        

        [HttpPost]
        [Route("sendSMS")]
        public async Task<IActionResult> sendSMS([FromBody]SochitelSMSReq data)
        {
            GenericApiResponse<SMSTransaction> execTransactionResponse = null;

            try
            {
                 execTransactionResponse = await _SochiTelPost.sendSMS(data.MSISDN, data.SMSContent, data.Currency);
                return Ok(execTransactionResponse);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /sochitelExecuteTransaction\"  Failed   Source:General    Pasameters:         Message:{ex.ToString()}  -   Product JSON does not contain valid JSON, API GUID was not found or deleted from database");
                var result = new
                {
                    errorCode = 2,
                    status = "Failure",
                    message = "Product JSON does not contain valid JSON, API GUID was not found or deleted from database"
                };
                return Ok(result);
            }

                
           
        }

        #endregion


                #region sochitelExecuteTransaction

        [HttpPost]
        [Route("sochitelExecuteTransaction")]
        public async Task<IActionResult> SochiExecuteTransactionAPICall([FromBody]SochitelExeReq data)
        {

            try
            {

                string nowtelTransactionReference = data.nowtelTransactionReference;
                string operatorid = data.operatorid.ToString();
                string operatorProduct = data.product;
                string messageToRecipient = data.messageToRecipient;
                string fromMSISDN = data.fromMSISDN;
                string product = "";

                APIAccessGUID guidReferneceRecord = await _dbATT.getTransactionGUIDRecord(nowtelTransactionReference, operatorProduct);

                try
                {
                    JToken json = JObject.Parse(guidReferneceRecord.ProductsJSON);
                    product = json[operatorProduct].ToObject<string>();
                }
                catch (Exception ex)
                {
                    _loggerAPIAccess.Debug($"  \"GET /sochitelExecuteTransaction\"  Failed   Source:General    Pasameters:         Message:{ex.ToString()}  -   Product JSON does not contain valid JSON, API GUID was not found or deleted from database");
                    var result = new
                    {
                        errorCode = 2,
                        status = "Failure",
                        message = "Product JSON does not contain valid JSON, API GUID was not found or deleted from database"
                    };
                    return Ok(result);
                }


                if (guidReferneceRecord == null)
                {
                    _loggerAPIAccess.Debug($"  \"GET /sochitelExecuteTransaction\"  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return Ok(result);
                }
                string[] Credentials = SochitelAuth.GetSochitelAttCredentials(guidReferneceRecord.account);

                string transactionReference = Guid.NewGuid().ToString("N").ToUpper();
                transactionReference = transactionReference.Substring(0, 30);
                try
                {
                    GenericApiResponse<ExecTransaction> execTransactionResponse = await _SochiTelPost.execTransaction("", guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, transactionReference);

                    if (execTransactionResponse.Status == 0)
                    {
                        try
                        {
                            //Successful transaction
                            await _dbATT.insertAirTimeTransferTransaction(DateTime.Now.ToString(),
                                Credentials[0],  // Sochitel Username
                                guidReferneceRecord.CustomerChargeValue,      // Customer Charge Value
                                execTransactionResponse.Result.amount.user,   // Actual Charge Value
                                execTransactionResponse.Result.amount.@operator,
                                execTransactionResponse.Result.currency.user,
                                execTransactionResponse.Result.currency.@operator,
                                execTransactionResponse.Result.country.name,
                                "Success",
                                "",
                                execTransactionResponse.Result.@operator.id.ToString(),
                                execTransactionResponse.Result.productId.ToString(),
                                execTransactionResponse.Result.@operator.name,
                                execTransactionResponse.APITransactionReference,
                                execTransactionResponse.ATTTransactionReference,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                1,
                                messageToRecipient);

                            //await
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /sochitelExecuteTransaction\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }

                        _loggerAPIAccess.Information($"  \"POST /execTransaction\"   Success    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   SochiReference-{execTransactionResponse.ATTTransactionReference}       APIReference-{execTransactionResponse.APITransactionReference}");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.CustomerChargeValue,      // Customer Charge Value
                            currency = execTransactionResponse.Result.currency.user,
                            reference = execTransactionResponse.ATTTransactionReference

                        };
                        return Ok(result);
                    }
                    if (execTransactionResponse.Status == 1)
                    {
                        try
                        {
                            //Pending transaction
                            await _dbATT.insertAirTimeTransferTransaction(DateTime.Now.ToString(),
                                Credentials[0],  // Sochitel Username
                               guidReferneceRecord.CustomerChargeValue,      // Customer Charge Value
                               execTransactionResponse.Result.amount.user,   // Actual Charge Value
                               execTransactionResponse.Result.amount.@operator,
                               execTransactionResponse.Result.currency.user,
                               execTransactionResponse.Result.currency.@operator,
                               execTransactionResponse.Result.country.name,
                               "Pending",
                               "",
                               execTransactionResponse.Result.@operator.id.ToString(),
                               execTransactionResponse.Result.productId.ToString(),
                               execTransactionResponse.Result.@operator.name,
                               execTransactionResponse.APITransactionReference,
                               execTransactionResponse.ATTTransactionReference,
                               fromMSISDN,
                               guidReferneceRecord.tomsisdn,
                               1,
                               messageToRecipient);
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /sochitelExecuteTransaction\"  Database error occured while registering the Pending transaction    Exception {ex.ToString()} ");
                        }

                        _loggerAPIAccess.Information($"  \"POST /execTransaction\"   Pending   Pasameters:   tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   SochiReference-{execTransactionResponse.ATTTransactionReference}       APIReference-{execTransactionResponse.APITransactionReference}");
                        var result = new { errorCode = 1, status = "Pending", message = "Your transaction is pending" };
                        return Ok(result);
                    }
                    else if (execTransactionResponse.Status == 2)
                    {
                        try
                        {
                            await _dbATT.insertAirTimeTransferTransaction(DateTime.Now.ToString(),
                            Credentials[0],  // Sochitel Username
                            guidReferneceRecord.CustomerChargeValue,     // Customer Charge Value
                            decimal.Parse(product), decimal.Parse(operatorProduct), guidReferneceRecord.account, "", "", "Failure", execTransactionResponse.Message, operatorid, "", "",
                            execTransactionResponse.APITransactionReference,
                            execTransactionResponse.ATTTransactionReference,
                            fromMSISDN, guidReferneceRecord.tomsisdn, 1, messageToRecipient);
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /sochitelExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }

                        //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                        _loggerAPIAccess.Debug($"  \"POST /sochitelExecuteTransaction\"  Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   SochiReference-{execTransactionResponse.ATTTransactionReference}     APIReference-{execTransactionResponse.APITransactionReference}        Reason={execTransactionResponse.Message}");
                        var result = new { errorCode = 2, status = "Failure", message = execTransactionResponse.Message };
                        return Ok(result);
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        await _dbATT.insertAirTimeTransferTransaction(DateTime.Now.ToString(),
                         Credentials[0],  // Sochitel Username
                        guidReferneceRecord.CustomerChargeValue,      // Customer Charge Value
                        decimal.Parse(product), decimal.Parse(operatorProduct), guidReferneceRecord.account, "", "", "FailureException", ex.Message, operatorid, "", "",
                        transactionReference,
                        "",
                        fromMSISDN, guidReferneceRecord.tomsisdn, 1, messageToRecipient);
                    }
                    catch (Exception dbException)
                    {
                        _loggerAPIAccess.Debug($"  \"POST /sochitelExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }

                    //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                    _loggerAPIAccess.Debug($"  \"POST /sochitelExecuteTransaction\"  Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   SochiReference-{transactionReference}     APIReference-{""}        Reason={ex.Message}");
                    var result = new { errorCode = 2, status = "Failure", message = ex.Message };
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /sochitelExecuteTransaction\"  Failed   Source:General    Pasameters:         Message:{ex.ToString()}");
                var result = new { errorCode = 2, status = "Failure", message = ex.ToString() };
                return Ok(result);
            }


            //control will not fall till here but to remove the error message for this function that function should return something following command has been added
            return BadRequest("API Error");
        }


        #endregion sochitelExecuteTransaction


        #region sochitelGetBalance

        [HttpGet]
        [Route("sochitelGetBalance")]
        public async Task<IActionResult> SochiGetBalanceAPICall(string currency)
        {
            try
            {
                GenericApiResponse<Balance> accountBalanceResponse = await _SochiTelPost.getBalance(currency);

                if (accountBalanceResponse.Status == 0)
                {
                    _loggerAPIAccess.Information($"  \"GET /getBalance\" Success  Parameters:currency:{accountBalanceResponse.Result.currency}");
                    var resultPayload = new { currency = accountBalanceResponse.Result.currency, balance = accountBalanceResponse.Result.value };
                    var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
                    return Ok(result);
                }
                else
                {
                    //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access       
                    _loggerAPIAccess.Debug($"  \"GET /getBalance\"  Failed  Source:Sochitel API   Parameters:currency:{currency}    Reason:{accountBalanceResponse.Message}");
                    var resultPayload = new { reason = accountBalanceResponse.Message };
                    var result = new { errorCode = 1, status = "Failure", payLoad = resultPayload };
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /getBalance\"  Failed  Source:General   Parameters:currency:{currency}   Message:{ex.ToString()}");
                var result = new { errorCode = 1, Message = "API Error" };
                return Ok(result);
            }

        }

        #endregion sochitelGetBalance


        #region SochitelGetTransaction

        /***
    *  Created by : ShahidAkbar
    *  Date :      28-Nov-2017
    *  Purpose :  Get transaction records from  Socitel API .
    *  Summary :  This method is used to get the transaction record from Socitel API and returns the result in json format. 
    * 
    * */

        [HttpGet]
        [Route("sochitelGetTransaction")]
        public async Task<IActionResult> SochitelGetTransaction(string userReference, string currency)
        {
            // example 35CE3B3451604E569242EF80545730
            try
            {
                GenericApiResponse<GetTransactionResponse> response = await _SochiTelPost.getTransaction(userReference, currency);

                if (response.Status == 0)
                {

                    _loggerAPIAccess.Information($"  \"POST /sochitelGetTransaction\"   Success  Parameters:   userReference-{userReference}   currency-{currency} ");
                    JsonGetTransactionResponse JsonResponse = new JsonGetTransactionResponse();
                    JsonResponse.errorCode = 0;
                    JsonResponse.status = "Success";
                    JsonResponse.message = "Executed Successfully.";
                    JsonResponse.payload = response.Result;
                    return Ok(JsonResponse);
                }
                else if (response.Status == 2)
                {
                    //Ding API Fatal Exception is already been logged in SochiPost. Here just log the API access
                    _loggerAPIAccess.Debug($"  \"POST /sochitelGetTransaction\"  Failed    Message: {response.Message}  Parameters:     userReference-{userReference}   currency-{currency} ");
                    var result = new { errorCode = 2, status = "Failure", message = response.Message, payload = "{}" };
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /dingListTransferRecords\"  Failed   Source:General    Pasameters:         Message:{ex.ToString()}");
                var result = new { errorCode = 2, status = "Failure", message = ex.ToString(), payload = "{}" };
                return Ok(result);
            }


            //control will not fall till here but to remove the error message for this function that function should return something following command has been added
            return BadRequest("API Error");
        }

        #endregion SochitelGetTransaction




        /*      [HttpGet]
                [Route("getOperators")]
                public async Task<IHttpActionResult> SochiGetOperatorsAPICall(string country, string currency, int local = 0, int productType = 0)
                {
                    try
                    { 
                        GenericApiResponse<Dictionary<string, Operator>> operatorsResponse = await _SochiTelPost.GetOperators(country, local, productType, currency);

                        if (operatorsResponse.Status == 0)
                        {
                            _loggerAPIAccess.Information($"\"GET /getOperators\"  Success  Parameters-country={country} local={local}");
                            return Ok(operatorsResponse.Result);
                        }
                        else
                        {
                            //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                            _loggerAPIAccess.Debug($"\"GET /getOperators\"  Failed  Source:Sochitel API  Parameters-country:{country}  local:{local}");
                            return BadRequest("API Error");
                        }
                    }
                    catch (Exception ex)
                    {
                        _loggerAPIAccess.Debug($"\"GET /getOperators\"  Failed  Source:General  Parameters-country:{country}, local:{local}, productType:{productType}   Message:{ex.ToString()}");
                        return BadRequest("API Error");
                    }
                }

        */


        /*
        [HttpGet]
        [Route("getProduct")]
        public async Task<IHttpActionResult> SochiGetProductAPICall(int productId, string currency)
        {
            try
            {
                GenericApiResponse<ProductDetails> productResponse = await _SochiTelPost.GetProduct(productId, currency);

                if (productResponse.Status == 0)
                {
                    _loggerAPIAccess.Information($"\"GET /getProduct\"  Success  Parameters-productid={productId}");
                    return Ok(productResponse.Result);
                }
                else
                {
                    //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                    _loggerAPIAccess.Debug($"\"GET /getProduct\"  Failed  Source:Sochitel API  Parameters-productid:{productId}");
                    return BadRequest("API Error");
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"GET /getProduct\" Failed  Source:General  Parameters-productid:{productId}  Message:{ex.ToString()}");
                return BadRequest("API Error");
            }
        }
        */


    }
}