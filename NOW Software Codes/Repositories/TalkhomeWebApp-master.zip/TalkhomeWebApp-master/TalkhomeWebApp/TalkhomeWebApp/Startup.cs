using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.CookiePolicy;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Polly;
using Serilog;
using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TalkhomeWebApp.Models.Configurations;
using TalkhomeWebApp.Services;
using TalkhomeWebApp.Utilities;
using TalkhomeWebApp.Utilities.Extension;
using TalkhomeWebApp.Utilities.Middlewares;

namespace TalkhomeWebApp
{
	public class Startup
	{
		public Startup(IConfiguration configuration, IWebHostEnvironment env)
		{
			Configuration = configuration;
			Environment = env;
		}

		public IConfiguration Configuration { get; }
		private IWebHostEnvironment Environment { get; set; }


		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			services.Configure<RouteOptions>(options =>
			{
				options.AppendTrailingSlash = false;
				options.LowercaseUrls = true;
				options.LowercaseQueryStrings = true;
			});

			services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).
				AddCookie(options =>
				{
					options.LoginPath = "/login";
					options.Cookie.Name = "THA-Web-Cookie";
					options.Events = new MyCookieAuthenticationEvents(Environment.IsDevelopment());
				});

			services.AddAntiforgery(opts => opts.Cookie.Name = "THA-Web-Anti-Forgery-Cookie");

			services.Configure<EndPoints>(Configuration.GetSection("EndPoints"));
			services.Configure<BasicAuthConfig>(Configuration.GetSection("BasicAuthConfig"));
			services.Configure<AppsFlyerConfig>(Configuration.GetSection("AppsFlyerConfig"));
			services.Configure<AirshipConfig>(Configuration.GetSection("AirshipConfig"));
			services.Configure<FacebookConfig>(Configuration.GetSection("FaceBookConfig"));
			services.Configure<GoogleRecaptchaSettings>(Configuration.GetSection("GoogleRecaptchaSettings"));
			services.Configure<TopUpConfig>(Configuration.GetSection("TopUpConfig"));
			services.Configure<TestNumbersByCurrencyConfig>(Configuration.GetSection("TestNumbersByCurrency"));
			services.AddControllersWithViews(options =>
			{
				options.Filters.Add(new ResponseCacheAttribute() { NoStore = true, Location = ResponseCacheLocation.None });
			});

			services.AddSingleton((ILogger)new LoggerConfiguration()
			   .MinimumLevel.Debug()
			   .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "THA-Web-log-{Date}.txt"))
			   .WriteTo.Sentry()
			   .CreateLogger());

			services.AddHttpContextAccessor();

			services.AddRazorPages().AddRazorRuntimeCompilation();

			services.AddResponseCompression(options =>
			{
				options.Providers.Add<BrotliCompressionProvider>();
				options.Providers.Add<GzipCompressionProvider>();
				options.MimeTypes =
					ResponseCompressionDefaults.MimeTypes.Concat(
						new[] {
								"text/plain",
								"text/html",
								"text/css",
								"text/json",
								"font/woff2",
								"application/javascript",
								"application/json",
								"image/x-icon",
								"image/png",
								"image/jpeg",
								"image/jpg",
						});
			});

			services.Configure<BrotliCompressionProviderOptions>(options =>
			{
				options.Level = CompressionLevel.Fastest;
			});

			services.Configure<GzipCompressionProviderOptions>(options =>
			{
				options.Level = CompressionLevel.Fastest;
			});
			services.AddScoped<IBundleService, BundleService>();
			services.AddScoped<IRatesService, RatesService>();
			services.AddScoped<IHelperService, HelperService>();
			services.AddScoped<IGeoService, GeoService>();
			services.AddTransient<IAppsFlyerService, AppsFlyerService>();
			services.AddTransient<IAirshipService, AirshipService>();
			services.AddHttpClient<IFacebookService, FacebookService>();
			services.AddHttpClient<ApiClient>()
				.AddTransientHttpErrorPolicy(builder =>
				{
					return builder.WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
				});
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}
			else
			{
				app.UseExceptionHandler("/error/system/500");
				app.Use(async (context, next) =>
				{
					await next();
					if (context.Response.StatusCode == 404)
					{
						context.Request.Path = "/error/system/404";
						await next();
					}
				});
				//app.UseHttpsRedirection();
			}

			app.UseTrailingSlashAndLowerCaseUrlMiddleware();

			app.UseUrlRewriting();

			app.UseGCLIDMiddleware();

			app.UseCookiePolicy(new CookiePolicyOptions()
			{
				MinimumSameSitePolicy = SameSiteMode.Lax,
				HttpOnly = HttpOnlyPolicy.Always,
				CheckConsentNeeded = context => false,
				Secure = env.IsDevelopment() ? CookieSecurePolicy.SameAsRequest : CookieSecurePolicy.Always
			});

			app.UseResponseCompression();

			app.UseStaticFiles();

			app.UseRouting();

			app.UseSentryTracing();

			app.UseAuthentication();

			app.UseAuthorization();

			CommonExtentionMethods.Configure(app.ApplicationServices.GetRequiredService<IHttpContextAccessor>());

			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllerRoute(
					name: "default",
					pattern: "{controller=Home}/{action=Index}/{id?}");
			});
		}
	}
}
