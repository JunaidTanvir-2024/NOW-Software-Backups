﻿using System.Text.Json.Serialization;
using static CallingCode.Mvc.Common.Enums.WmoCodes;

namespace CallingCode.Mvc.Common.Models;

public class WeatherForecastModel
{
    [JsonPropertyName("latitude")]
    public double Latitude { get; set; }

    [JsonPropertyName("longitude")]
    public double Longitude { get; set; }

    [JsonPropertyName("generationtime_ms")]
    public double GenerationtimeMs { get; set; }

    [JsonPropertyName("utc_offset_seconds")]
    public long UtcOffsetSeconds { get; set; }

    [JsonPropertyName("timezone")]
    public string? Timezone { get; set; }

    [JsonPropertyName("timezone_abbreviation")]
    public string? TimezoneAbbreviation { get; set; }

    [JsonPropertyName("elevation")]
    public double Elevation { get; set; }

    [JsonPropertyName("current_weather")]
    public CurrentWeather? CurrentWeather { get; set; }

    [JsonPropertyName("hourly_units")]
    public HourlyUnits? HourlyUnits { get; set; }

    [JsonPropertyName("hourly")]
    public Hourly? Hourly { get; set; }
}

public partial class CurrentWeather
{
    [JsonPropertyName("temperature")]
    public double Temperature { get; set; }

    [JsonPropertyName("windspeed")]
    public double Windspeed { get; set; }

    [JsonPropertyName("winddirection")]
    public double Winddirection { get; set; }

    [JsonPropertyName("weathercode")]
    public long Weathercode { get; set; }

    [JsonPropertyName("time")]
    public string? Time { get; set; }

    public WeatherCondition CurrentCondition { get; set; }
}

public partial class Hourly
{
    [JsonPropertyName("time")]
    public string[]? Time { get; set; }

    [JsonPropertyName("temperature_2m")]
    public double[]? Temperature2M { get; set; }

    [JsonPropertyName("weathercode")]
    public long[]? Weathercode { get; set; }
}

public partial class HourlyUnits
{
    [JsonPropertyName("time")]
    public string? Time { get; set; }

    [JsonPropertyName("temperature_2m")]
    public string? Temperature2M { get; set; }

    [JsonPropertyName("weathercode")]
    public string? Weathercode { get; set; }
}
