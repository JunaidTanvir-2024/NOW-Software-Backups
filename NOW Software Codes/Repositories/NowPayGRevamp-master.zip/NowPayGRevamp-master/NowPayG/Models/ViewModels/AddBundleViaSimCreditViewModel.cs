﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class AddBundleViaSimCreditViewModel
    {
        public string Msisdn { get; set; }
        public string Amount { get; set; }
        public string UUID { get; set; }
        public bool isAutoRenew { get; set; }
        public string BundleName { get; set; }
    }
}
