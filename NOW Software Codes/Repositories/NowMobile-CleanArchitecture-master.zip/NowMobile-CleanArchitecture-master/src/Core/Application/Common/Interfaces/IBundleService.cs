﻿using Application.Features.Bundle.PurchaseBundle;

namespace Application.Common.Interfaces;

public interface IBundleService : ISerivcesType.IScopedService
{
    Task<(int errorCode, string errorMessage)> BundlePurchaseValidation(string userAccountId, string bundleUuId);
    Task<(int errorCode, string errorMessage, int orderId)> AddBundleBySimCredit(PurchaseBundleRequest request);
}
