using Application.Features.Payment.Card.Models;

namespace Application.Features.AutoTopup.Card.New;

public class SetAutoTopupNewCardRequest : IRequest<Result<CardResponse>>
{
    public string Msisdn { get; set; } = default!;
    public float TopupAmount { get; set; } = default!;
    [JsonIgnore]
    public bool Status { get; set; }
    [JsonIgnore]
    public string IpAddress { get; set; } = string.Empty;
    public PaymentNewCardInfo PaymentCardInfo { get; set; } = new PaymentNewCardInfo();
    public PaymentAddressInfo PaymentAddressInfo { get; set; } = new PaymentAddressInfo();
}