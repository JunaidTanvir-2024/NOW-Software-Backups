﻿using Application.Features.Payment.Card.Models;

namespace Application.Features.Payment.Paypal.Models;
public class PaypalResponse
{
    public int OrderId { get; set; }
    public string? RedirectUrl { get; set; }
}
