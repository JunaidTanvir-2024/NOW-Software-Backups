﻿namespace THAApi.ViewModels
{
    public class Resume3DV2ViewModel
    {
        public string ThreeDSServerTransId { get; set; }
        public string TransactionId { get; set; }
        public string ReturnUrl { get; set; }
        public string Url { get; set; }
    }
}
