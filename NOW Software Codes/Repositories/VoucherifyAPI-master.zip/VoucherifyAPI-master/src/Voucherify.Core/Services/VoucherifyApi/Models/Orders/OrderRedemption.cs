using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Orders;

public class OrderRedemption
{
    [JsonPropertyName("date")]
    public DateTime? Date { get; set; }

    [JsonPropertyName("related_object_id")]
    public string? RelatedObjectId { get; set; }

    [JsonPropertyName("related_object_type")]
    public string? RelatedObjectType { get; set; }

    [JsonPropertyName("stacked")]
    public List<string>? Stacked { get; set; }
}
