﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Configurations
{
    public class EndPoints
    {
        public string NowPaygApiEndPoint { get; set; }
        public string PortingApiEndpoint { get; set; }
    }
}
