﻿using MapsterMapper;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.CustomerOrder.Responses;
using SC.Core.Features.Products.Requests;
using SC.Core.Features.Products.Responses;
using SC.Core.Vendors.FusionHub;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder;
internal sealed class GetCustomerOrdersHandler : IRequestHandler<GetCustomerOrdersRequest, IResultWrapper>
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly IFusionHubService _fusionHubService;
    private readonly ICustomerOrderService _customerOrderService;
    public GetCustomerOrdersHandler(ICustomerCartRespository customerCartRespository, IMapper mapper, ICommonService commonService, IFusionHubService fusionHubService, ICustomerOrderService customerOrderService)
    {
        _customerCartRespository = customerCartRespository;
        _mapper = mapper;
        _commonService = commonService;
        _fusionHubService = fusionHubService;
        _customerOrderService = customerOrderService;
    }
    public async Task<IResultWrapper> Handle(GetCustomerOrdersRequest request, CancellationToken cancellationToken)
    {
        var response = await _customerCartRespository.GetCustomerOrders(_commonService.GetUserID(), string.Empty);
        var Orders = _mapper.Map<List<GetCustomerOrdersResponse>>(response);
        return ResultWrapper.Success(Orders);

    }
}

