﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using THCCWEB.Configurations;
using THCCWEB.ExtendedContoller;
using THCCWEB.Extension;
using THCCWEB.Models.ApiContracts;
using THCCWEB.Models.ApiContracts.Request.Pay360;
using THCCWEB.Models.ApiContracts.Response;
using THCCWEB.Models.ApiContracts.Response.NewFolder;
using THCCWEB.Models.ViewModels;
using THCCWEB.Models.ViewModels.Account;
using THCCWEB.Models.ViewModels.CheckOutView;
using THCCWEB.Resources;
using THCCWEB.Utilities;
using THCCWEB.Utilities.Extension;
using static THCCWEB.Utilities.Enum;

namespace THCCWEB.Controllers
{
    public class HomeController : ExtendedController
    {
        private readonly ILogger _logger;
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly string _thccWebApiEndPoint;
        private readonly string baseAouthString = string.Empty;

        public HomeController(ILogger logger,
            IOptions<EndPointsConfig> endPoints,
            IOptions<BasicAuthConfig> basicAuthConfig,
            IWebHostEnvironment hostEnvironment) : base(logger)
        {
            _logger = logger;
            _hostEnvironment = hostEnvironment;
            _thccWebApiEndPoint = endPoints.Value.THCCWebApiEndPoint;
            _basicAuthConfig = basicAuthConfig.Value;
            baseAouthString = Bas64Convertor.Base64Encode(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password);
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        [Route("order-a-calling-card")]
        public IActionResult Orderrechageablecallingcard()       
        {
            var route = Request.Path.Value;
            if (route == "/order-a-calling-card/") 
            {
                 return RedirectPermanent("/order-a-calling-card");
            }
            return View();
        }

        [HttpPost]
        [Route("buy-rechargeable-calling-card")]
        public async Task<IActionResult> BuyrechargeablecallingcardAsyncPost(string ammount, string Email)
        {
            try
            {
                ammount = ValidateCallingCardPrice(ammount);
                var model = new CheckoutViewModel { PageType = "THRCC" };
                if (ammount != null) { model.CardPrice = ammount; model.CallingCardPrice = int.Parse(ammount); }
                if (Email != null) { model.EmailAddress = Email; }
                if (User.Identity.IsAuthenticated)
                {
                    //Get User Cards
                    var cardsResponse = await Api.CallApi(_thccWebApiEndPoint +
                                                "Pay360Account/GetCustomerCards", User, ApiCallType.Bearer, GetRequest: true);

                    if (cardsResponse.IsSuccessStatusCode)
                    {
                        if (cardsResponse.IsSuccessStatusCode)
                        {
                            var cardsResponseJson = JObject.Parse(cardsResponse.Content.ReadAsStringAsync().Result);
                            int errorCode = cardsResponseJson.GetValue("errorCode").ToObject<int>();

                            if (errorCode == 0)
                            {
                                var payload = cardsResponseJson.GetValue("payload").ToObject<Pay360CardsData>();
                                if (payload != null && payload.paymentMethodResponses.Count > 0)
                                {
                                    payload.paymentMethodResponses = payload.paymentMethodResponses.OrderByDescending(x => x.isPrimary).ToList();
                                }
                                model.UserCards = payload;
                            }
                        }
                        else if (cardsResponse.StatusCode == HttpStatusCode.Unauthorized)
                        {
                            return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                        }
                        else
                        {
                            throw new Exception("Topup - Error while getting data from API: StatusCode" + cardsResponse.StatusCode);
                        }
                    }
                }
                model.ListOfCountries = GetCountries();

                ModelState.Clear();

                return View("~/Views/CheckOut.cshtml", model);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: BuyrechargeablecallingcardAsync, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("CallingCardCheckout/{id?}")]
        public async Task<IActionResult> Buycallingcard(string id)
        {
            try
            {   
                var model = new CheckoutViewModel { PageType = "THCCN" };

                if (id != null) { model.Iscollonical_checkout = true; }

                id = ValidateCallingCardPrice(id); 
                
                if (id != null) { model.CardPrice = id; }

                if (User.Identity.IsAuthenticated)
                {
                    //Get User Cards
                    var cardsResponse = await Api.CallApi(_thccWebApiEndPoint +
                                                "Pay360Account/GetCustomerCards", User, ApiCallType.Bearer, GetRequest: true);

                    if (cardsResponse.IsSuccessStatusCode)
                    {
                        var cardsResponseJson = JObject.Parse(cardsResponse.Content.ReadAsStringAsync().Result);
                        int errorCode = cardsResponseJson.GetValue("errorCode").ToObject<int>();

                        if (errorCode == 0)
                        {
                            var payload = cardsResponseJson.GetValue("payload").ToObject<Pay360CardsData>();
                            if (payload != null && payload.paymentMethodResponses.Count > 0)
                            {
                                payload.paymentMethodResponses = payload.paymentMethodResponses.OrderByDescending(x => x.isPrimary).ToList();
                            }
                            model.UserCards = payload;
                        }
                    }
                    else if (cardsResponse.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                    }
                    else
                    {
                        throw new Exception("Topup - Error while getting data from API: StatusCode" + cardsResponse.StatusCode);
                    }
                }
                model.ListOfCountries = GetCountries();
                return View("~/Views/CheckOut.cshtml", model);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: Buycallingcard, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }



        [Route("checkout")]
        public async Task<IActionResult> Topupcallingcard(CheckoutViewModel model)
        {
            return RedirectPermanent("/top-up");
        }


        [Route("top-up")]
        public async Task<IActionResult> TopupcallingcardAsync(CheckoutViewModel model)
        {
            try
            {
                //var model = new CheckoutViewModel();
                if (model.RechargePIN == null)
                {
                    model.PageType = "Topup";
                    if (User.Identity.IsAuthenticated)
                    {
                        if (User.Claims.Where(x => x.Type == "AccountNumber").FirstOrDefault().Value == "0")
                        {
                            return RedirectToAction("addproduct", "Account");
                        }
                    }
                }
                else
                {
                    model.PageType = "Fasttopup";
                    model.DynamicModelValidation(ModelState, RequestModelTypes.FastTopUp);
                    if (!ModelState.IsValid)
                    {
                        return BadRequest();
                    }
                    model.CallingCardPrice = model.CallingCardPrice;
                    model.RechargePIN = model.RechargePIN;
                }


                if (User.Identity.IsAuthenticated)
                {
                    var autoTopupResponse = await Api.CallApi(_thccWebApiEndPoint +
                                           "Pay360Account/GetAutoTopup", User, ApiCallType.BasicAuth, new Pay360GetAutoTopUpRequest()
                                           {
                                               Msisdn = User.Claims.Where(x => x.Type == "AccountNumber").FirstOrDefault().Value,
                                               Email = User.Claims.Where(x => x.Type == ClaimTypes.Email).FirstOrDefault().Value,
                                               ProductCode = ProductType.THCC.ToString()
                                           }, basicauthtoken: baseAouthString);
                    if (autoTopupResponse.IsSuccessStatusCode)
                    {
                        var autoTopupResponseJson = JObject.Parse(autoTopupResponse.Content.ReadAsStringAsync().Result);
                        int errorCode = autoTopupResponseJson.GetValue("errorCode").ToObject<int>();
                        if (errorCode == 0)
                        {
                            var payload = autoTopupResponseJson.GetValue("payload").ToObject<Pay360GetAutoTopUpResponse>();
                            model.IsAutoToupEnabled = payload.Status;
                        }
                    }
                    //Get User Cards
                    var cardsResponse = await Api.CallApi(_thccWebApiEndPoint +
                                            "Pay360Account/GetCustomerCards", User, ApiCallType.Bearer, GetRequest: true);

                    if (cardsResponse.IsSuccessStatusCode)
                    {
                        var cardsResponseJson = JObject.Parse(cardsResponse.Content.ReadAsStringAsync().Result);
                        int errorCode = cardsResponseJson.GetValue("errorCode").ToObject<int>();

                        if (errorCode == 0)
                        {
                            var payload = cardsResponseJson.GetValue("payload").ToObject<Pay360CardsData>();
                            if (payload != null && payload.paymentMethodResponses.Count > 0)
                            {
                                payload.paymentMethodResponses = payload.paymentMethodResponses.OrderByDescending(x => x.isPrimary).ToList();
                            }
                            model.UserCards = payload;
                        }
                    }
                    else if (cardsResponse.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                    }
                    else
                    {
                        throw new Exception("Topup - Error while getting data from API: StatusCode" + cardsResponse.StatusCode);
                    }
                }
                model.ListOfCountries = GetCountries();
                ModelState.Clear();
                return View("~/Views/CheckOut.cshtml", model);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: TopupcallingcardAsync, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("fast-top-up-calling-card")]
        public async Task<IActionResult> FastTopupcallingcardAsync(CheckoutViewModel model)
        {
            try
            {
                model.DynamicModelValidation(ModelState, RequestModelTypes.FastTopUp);
                if (!ModelState.IsValid)
                {
                    return BadRequest();
                }

                model.PageType = "Fasttopup";
                if (User.Identity.IsAuthenticated)
                {
                    var autoTopupResponse = await Api.CallApi(_thccWebApiEndPoint +
                                           "Pay360Account/GetAutoTopup", User, ApiCallType.BasicAuth, new Pay360GetAutoTopUpRequest()
                                           {
                                               Msisdn = User.Claims.Where(x => x.Type == "AccountNumber").FirstOrDefault().Value,
                                               Email = User.Claims.Where(x => x.Type == ClaimTypes.Email).FirstOrDefault().Value,
                                               ProductCode = ProductType.THCC.ToString()
                                           }, basicauthtoken: baseAouthString);
                    if (autoTopupResponse.IsSuccessStatusCode)
                    {
                        var cautoTopupResponseJson = JObject.Parse(autoTopupResponse.Content.ReadAsStringAsync().Result);
                        int errorCode = cautoTopupResponseJson.GetValue("errorCode").ToObject<int>();
                        if (errorCode == 0)
                        {
                            var payload = cautoTopupResponseJson.GetValue("payload").ToObject<Pay360GetAutoTopUpResponse>();
                            model.IsAutoToupEnabled = payload.Status;
                        }
                    }
                    //Get User Cards
                    var cardsResponse = await Api.CallApi(_thccWebApiEndPoint +
                                                    "Pay360Account/GetCustomerCards", User, ApiCallType.Bearer, GetRequest: true);

                    if (cardsResponse.IsSuccessStatusCode)
                    {
                        var cardsResponseJson = JObject.Parse(cardsResponse.Content.ReadAsStringAsync().Result);
                        int errorCode = cardsResponseJson.GetValue("errorCode").ToObject<int>();

                        if (errorCode == 0)
                        {
                            var payload = cardsResponseJson.GetValue("payload").ToObject<Pay360CardsData>();
                            if (payload != null && payload.paymentMethodResponses.Count > 0)
                            {
                                payload.paymentMethodResponses = payload.paymentMethodResponses.OrderByDescending(x => x.isPrimary).ToList();
                            }
                            model.UserCards = payload;
                        }
                    }
                    else if (cardsResponse.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                    }
                    else
                    {
                        throw new Exception("Topup - Error while getting data from API: StatusCode" + cardsResponse.StatusCode);
                    }
                }
                model.ListOfCountries = GetCountries();
                return View("~/Views/CheckOut.cshtml", model);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: FastTopupcallingcardAsync, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }

        }

        [Route("Error/{key}")]
        public IActionResult ErrorMessage(string key)
        {
            if (string.IsNullOrEmpty(key)) { return NotFound(); }
            return View(new ErrorMessageViewModel() { Key = key });
        }

        [Route("Error/System/{StatusCode}")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error(int StatusCode)
        {
            var exceptionHandlerPathFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            if (exceptionHandlerPathFeature != null)
                _logger.Error(
                    $"Class: HomeController, " +
                    $"Method: Error, " +
                    $"Data: {JsonConvert.SerializeObject(exceptionHandlerPathFeature.Error.Message)}, " +
                    $"StackTrace: {JsonConvert.SerializeObject(exceptionHandlerPathFeature.Error.StackTrace)}");

            var model = new ErrorMessageViewModel();
            model.ErrorCode = StatusCode;

            switch (StatusCode)
            {
                case 500:
                    model.Message = "We’re sorry, something went wrong on server, please go back to our homepage.";
                    break;
                case 404:
                    model.Message = "We’re sorry, the page you requested could not be found, please go back to our homepage.";
                    break;
                default:
                    model.Message = "We’re sorry, something went wrong on server, please go back to our homepage.";
                    break;
            }

            return View("Error", model);
        }

        [Route("Error")]
        public IActionResult Error()
        {
            return View();
        }

        [Route("Success/{key}")]
        public async Task<IActionResult> SuccessMessage(string key)
        {
            var result = TempData.Get<SuccessMessageViewModel>("SuccessModel");

            if (User.Identity.IsAuthenticated && key == "THRCCNC".ToLower() && GetProfile().AccountNumber == "0")
            {
                var refreashToken = await Api.CallApi(_thccWebApiEndPoint + "Authenticate/GetToken", User, ApiCallType.Bearer, null, true);
                if (refreashToken.IsSuccessStatusCode)
                {
                    var resultJson = JObject.Parse(refreashToken.Content.ReadAsStringAsync().Result);
                    int errorCode1 = resultJson.GetValue("errorCode").ToObject<int>();
                    if (errorCode1 == 0)
                    {
                        var tokenString = resultJson.GetValue("payload").ToObject<string>();
                        if (!string.IsNullOrEmpty(tokenString))
                        {
                            RefreashClaims(new UserProfileViewModel
                            {
                                AccountNumber = result.CardNumber,
                                Token = tokenString
                            });
                        }
                       
                    }
                }

            }
            TempData.Keep();
            if (result == null)
            {
                result = new SuccessMessageViewModel();
            }
            result.Key = key;
            return View(result);
        }
        
        private CountriesResponseModel GetCountries()
        {
            try
            {
                var json = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json");
                return JsonConvert.DeserializeObject<CountriesResponseModel>(json);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: GetCountries, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null;
            }

        }

        [HttpGet]
        [Route("GetAddressByPostCode")]
        //[Authorize]
        public async Task<IActionResult> GetAddressByPostCode(string postCode)
        {
            try
            {
                string encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                            _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                //Get address by postCode
                var addressResponse = await Utilities.Api.CallApi(_thccWebApiEndPoint +
                                                 "Common/GetAddressByPostCode", User, ApiCallType.BasicAuth, basicauthtoken: encoded,
                                                  GetRequest: true, parameters: new string[] { "PostCode=" + postCode });

                if (addressResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(addressResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = accountResponseJson.GetValue("payload").
                                         ToObject<GetAddressByPostCodeResponseModel>().AddressData;
                        return Json(new { errorCode = 0, payload });
                    }
                    else if (errorCode == (int)ApiStatusCodes.NoAddressFound)
                    {
                        return Json(new { errorCode = 1, message = "No Address found against given Post Code. Please enter manually" });
                    }
                    else
                    {
                        return Json(new { errorCode, message = "Something went wrong on server" });
                    }
                }
                else
                {
                    return StatusCode((int)addressResponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: GetAddressByPostCode, ErrorMessage:" +
                                    $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                    $"StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        [Route("getusercards")]
        public async Task<IActionResult> GetUserCards()
        {
            try
            {
                //Get User Cards
                var cardsResponse = await Api.CallApi(_thccWebApiEndPoint + "Pay360Account/GetCustomerCards", User, ApiCallType.Bearer, GetRequest: true);

                if (cardsResponse.IsSuccessStatusCode)
                {
                    var cardsResponseJson = JObject.Parse(cardsResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = cardsResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = cardsResponseJson.GetValue("payload").ToObject<Pay360CardsData>();

                        if (payload != null && payload.paymentMethodResponses.Count > 0)
                        {
                            payload.paymentMethodResponses = payload.paymentMethodResponses.OrderByDescending(x => x.isPrimary).ToList();
                        }
                        return Json(payload);


                    }
                    else
                    {
                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: GetUserCards, ErrorMessage:" +
                                    $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                    $"StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }

        }

        [HttpGet]
        [Route("callingcardrates")]
        public async Task<IActionResult> Rates()
        {
            try
            {
                string encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                                _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                //Get address by postCode
                var RatesResponse = await Utilities.Api.CallApi(_thccWebApiEndPoint +
                                                 "Account/GetRates", User, ApiCallType.BasicAuth, basicauthtoken: encoded,
                                                  GetRequest: true);
                if (RatesResponse.IsSuccessStatusCode)
                {
                    var ResponseJson = JObject.Parse(RatesResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = ResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = ResponseJson.GetValue("payload").
                                         ToObject<List<RatesViewModel>>();
                        return View(payload);
                    }
                    else
                    {
                        return RedirectToAction("ErrorMessage", new { key = "InternalServerError" });
                    }

                }
                else
                {
                    return RedirectToAction("ErrorMessage", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: HomeController, Method: callingcardrates, ErrorMessage:" +
                                     $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                     $"StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("CallingCardHowToBuy")]
        public IActionResult CallingCardHowToBuy()
        {
            return RedirectPermanent("/how-to-buy");
        }
        
        [HttpGet]
        [Route("how-to-buy")]
        public IActionResult HowToBuy()
        {
            return View();
        }

        [HttpGet]
        [Route("CallingCardsHowItWorks")]
        public IActionResult HowItWorks()
        {
            return View();
        }

        [HttpGet]
        [Route("CallingCardsPoints")]
        public IActionResult Points()
        {
            return View();
        }

        [HttpGet]
        [Route("ContactUsCallingCards")]
        public IActionResult ContactUs()
        {
            return View();
        }

        [HttpGet]
        [Route("help/calling-cards")]
        public IActionResult FAQs()
        {
            return View();
        }

        [HttpGet]
        [Route("terms-and-conditions/calling-cards")]
        public IActionResult TermsAndConditions()
        {
            var route = Request.Path.Value;
            if (route == "/terms-and-conditions/calling-cards/")
            {
                return RedirectPermanent("/terms-and-conditions/calling-cards");
            }
            return View();
        }

        [HttpGet]
        [Route("privacy-policy/calling-cards")]
        public IActionResult PrivacyPolicy()
        {
            return View();
        }

        [HttpGet]
        [Route("/cookie-policy")]
        public IActionResult CookiePolicy()
        {
            return View();
        }

        [HttpGet]
        [Route("complaints-procedure")]
        public IActionResult ComplaintsProcedure()
        {
            return View();
        }

        [HttpGet]
        [Route("/help")]
        public IActionResult QuickLinks()
        {
            return View();
        }

        [HttpGet]
        [Route("logincallingcards")]
        public IActionResult Logincallingcards()
        {
            return RedirectPermanent("/Login");
        }
        [HttpGet]
        [Route("signupcallingcards")]
        public IActionResult Signupcallingcards()
        {
            return RedirectPermanent("/register-for-my-account");
        }
        [HttpGet]
        [Route("unsubscribe")]
        public IActionResult Unsubscribe()
        {
            return View();
        }

        private string ValidateCallingCardPrice(string value)
        {
            string val = "10";
            switch (value)
            {
                case "5": val = "5"; break;
                case "10": val = "10"; break;
                case "20": val = "20"; break;
                default:
                    break;
            }
            return val;
        }

        [Route("hellotalkhome@nowtel.co.uk")]
        public IActionResult hellotalkhome()
        {
            return RedirectPermanent("/");
        }

    }
}
