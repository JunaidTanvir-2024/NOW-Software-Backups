﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Service.Pay360ApiContracts
{
    public class StartPay360RequestModel
    {

        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        [Display(Name = "City")]
        public string City { get; set; }

        public string CountyOrProvince { get; set; }

        public string CountryCode { get; set; }

        public string PostalCode { get; set; }

        [DataType(DataType.EmailAddress)]
        public string EmailAddress { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string PaymentMethod { get; set; }

        public string CardId { get; set; }

        public string Unreg { get; set; }

        public string Msisdn { get; set; }

        public string Currency { get; set; }

        public int Amount { get; set; }

        public string CustId { get; set; }

        public string NoCards { get; set; }



        public string NameOnCard { get; set; }

        public string CardNumber { get; set; }

        public string CardExpiryMonth { get; set; }

        public string CardExpiryYear { get; set; }

        public string SecurityCode { get; set; }

        public string CardCv2 { get; set; }

        public string Default { get; set; }
    }
}
