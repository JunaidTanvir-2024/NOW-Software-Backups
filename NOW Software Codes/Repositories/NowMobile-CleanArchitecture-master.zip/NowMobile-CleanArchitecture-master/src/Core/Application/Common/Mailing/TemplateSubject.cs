﻿
namespace Application.Common.Mailing;
public static class TemplateSubject
{
    public const string ForgetPassword = "Forget Password";
    public const string SignUp = "User SignUp";
    public const string SendFreeSimOrderEmail = "Sim Order Success";
    public const string Topup = "Topup";
    public const string Bundle = "Bundle";
    public const string CreditSim = "Credit Sim Order Success";
    public const string FullfilmentFailed = "Fullfillment Failed";
}
