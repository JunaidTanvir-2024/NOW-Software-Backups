﻿namespace Models.Contracts.Request
{
    public class Referral
    {

        public string msisdn { get; set; }

        public decimal amount { get; set; }

        public string Date { get; set; }


    }

    public class ReferralOut
    {

        public string msisdn { get; set; }

        public string amount { get; set; }

        public string date { get; set; }

    }
}
