using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;
namespace JM.Core.Features.Friendship;

public abstract class CreateFriendship
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public long InitiatorId { get; set; }
		public long ResponderId { get; set; }
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.InitiatorId).GreaterThan(0);
			RuleFor(x => x.ResponderId).GreaterThan(0);
		}
		#endregion
	}
	#region Response
	public sealed record Response
	{
		public required UserInfo Initiator { get; set; }
		public required UserInfo Responder { get; set; }
		public required string Status { get; set; }

		public sealed record UserInfo
		{
			public required long Id { get; set; }
			public required string Email { get; set; }
			public required string Username { get; set; }
			public string? FullName { get; set; }
		}
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		private readonly IMediator _mediator = mediator;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{

			var getFriendshipResult = await _mediator.Send(new GetFriendship.Query()
			{
				UserId = query.InitiatorId,
				Status = AppEnum.FriendshipStatus.Pending
			}, cancellationToken);

			var friendshipInfo = getFriendshipResult.IsSuccess ? getFriendshipResult.TypedPayload<GetFriendship.Response>() : null;

			if (friendshipInfo?.Status.Equals(nameof(AppEnum.FriendshipStatus.Accepted)) == true
			|| friendshipInfo?.Status.Equals(nameof(AppEnum.FriendshipStatus.Blocked)) == true)
			{
				return ResultWrapper.Failure(AppConstant.StatusKey.AlreadyFriend, AppConstant.StatusCode.Success);
			}

			if (friendshipInfo?.Status.Equals(nameof(AppEnum.FriendshipStatus.Pending)) == true)
			{
				return ResultWrapper.Failure(AppConstant.StatusKey.FriendshipPending, AppConstant.StatusCode.Success);
			}

			var newFriendship = new Entities.Friendship
			{
				InitiatorId = query.InitiatorId,
				ResponderId = query.ResponderId,
				Status = nameof(AppEnum.FriendshipStatus.Pending)
			};
			var friendship = await _unitOfWork.FriendshipRepository.AddFriendship(newFriendship);
			_unitOfWork.SaveChanges();

			if (friendship is not null)
			{
				return ResultWrapper.Success(new Response()
				{
					Status = friendship.Status,
					Initiator = new Response.UserInfo()
					{
						Id = friendship.Initiator.Id,
						Email = friendship.Initiator.Email!,
						Username = friendship.Initiator?.UserName!,
						FullName = friendship.Initiator?.UserDetail?.FullName,
					},
					Responder = new Response.UserInfo()
					{
						Id = friendship.Responder.Id,
						Email = friendship.Responder.Email!,
						Username = friendship.Responder?.UserName!,
						FullName = friendship.Responder?.UserDetail?.FullName,
					},
				});
			}
			return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
		}
	}
	#endregion
}
