﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Serilog;
using StatsdClient;
using System;
using System.Net;
using System.Threading.Tasks;
using TH.Models.Configurations;

namespace TH.Middleware
{

    public class DogStatsDMiddleware
    {
        private readonly RequestDelegate Next;
        private static string SerilogFilePath;
        private readonly ILogger Logger;

        public DogStatsDMiddleware(RequestDelegate next, IOptions<SerilogConfig> serilogConfig)
        {
            Next = next;
            SerilogFilePath = serilogConfig.Value.FilePath;
            if (Logger == null)
            {
                Logger = new LoggerConfiguration()
                        .MinimumLevel.Information()
                        .WriteTo.RollingFile(SerilogFilePath + "\\DogStatsD\\DogStatsD-log-{Date}.txt")
                        .CreateLogger();
            }
        }

        public async Task InvokeAsync(HttpContext context)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            // Call the next delegate/middleware in the pipeline
            await this.Next(context);

            stopwatch.Stop();

            var date = DateTime.UtcNow.ToString("s", System.Globalization.CultureInfo.InvariantCulture);
            var client = context.Request.Headers["X-Forwarded-For"].ToString() ?? context.Connection.RemoteIpAddress.ToString();
            var method = context.Request.Method;
            var path = context.Request.Path.ToString();
            var responseTime = stopwatch.ElapsedMilliseconds();
            var StatusCode = context.Response.StatusCode;
            var StatusDescription = ((HttpStatusCode)StatusCode).ToString();

            DogStatsd.Increment("ActionExecuted");
            DogStatsd.Increment($"ActionExecuted.StatusCode.{StatusCode}_{StatusDescription}");
            DogStatsd.Histogram("ActionExecuted.ResponseTime", responseTime);

            var message = $"{date} {client} \"{method} {path}\" Status: {StatusCode} {StatusDescription} ResponseTime: {responseTime}ms";

#if !RELEASE
            Console.WriteLine(message);
#endif
            Logger.Information(message);

            // Call the next delegate/middleware in the pipeline
            //return this.Next(context);
        }


    }

}
