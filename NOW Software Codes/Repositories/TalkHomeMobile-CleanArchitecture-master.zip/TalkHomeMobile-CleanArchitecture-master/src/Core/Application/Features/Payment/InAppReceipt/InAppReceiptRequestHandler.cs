﻿using Application.Common.Interfaces.Payment;
namespace Application.Features.Payment.InAppReceipt;
public class InAppReceiptRequestHandler : IRequestHandler<InAppReceiptRequest, Result<InAppReceiptResponse>>
{
    private readonly IStringLocalizer<InAppReceiptRequestHandler> _localizer;
    private readonly IPaymentService _paymentService;

    public InAppReceiptRequestHandler(
         IStringLocalizer<InAppReceiptRequestHandler> localizer,
         IPaymentService paymentService
       )
    {
        _localizer = localizer;
        _paymentService = paymentService;
    }

    public async Task<Result<InAppReceiptResponse>> Handle(InAppReceiptRequest request, CancellationToken cancellationToken)
    {
        var result = await _paymentService.VerifyInAppPurchaseReceipt(request);
        var response = new InAppReceiptResponse
        {
            Balance = result.Data?.Balance,
            Credit = result.Data?.Credit,
            TransactionId = result.Data?.TransactionId
        };
        if (!result.Status)
        {
            return Result<InAppReceiptResponse>.Failure(response, _localizer[CustomStatusKey.PaymentServiceError], CustomStatusCode.PaymentServiceError);
        }
        return Result<InAppReceiptResponse>.Success(response, _localizer[CustomStatusKey.Success]);
    }
}

