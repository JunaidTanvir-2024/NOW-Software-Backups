﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using TalkhomeWebApp.Models;

namespace TalkhomeWebApp.Services
{
    public interface IRatesService
    {
        public Task<List<Rates>> GetRates(string countryCode, IPrincipal User);
    }
}
