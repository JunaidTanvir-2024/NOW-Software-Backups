﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;

namespace TalkhomeAPI.Infrastructure.DependencyInjection.DependencyModules
{
    public static class ConfigurationModule
    {
        public static void Configure(IServiceCollection services, IConfiguration configuration)
        {
            
        }
    }
}
