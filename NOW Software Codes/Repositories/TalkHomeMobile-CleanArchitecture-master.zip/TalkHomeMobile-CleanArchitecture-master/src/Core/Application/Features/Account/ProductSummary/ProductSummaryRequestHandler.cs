﻿using Application.Common.Models.Airship;
using Application.Common.Settings;
using Application.Features.Bundle.Bundle;
using Application.Features.Bundle.Model;
using Application.Features.Bundle.SuggestedBundle;
using Microsoft.Extensions.Options;

namespace Application.Features.Account.ProductSummary;
public class ProductSummaryRequestHandler : IRequestHandler<ProductSummaryRequest, Result<ProductSummaryResponse>>
{
    private readonly IStringLocalizer<ProductSummaryRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;
    private readonly IAirshipService _airshipService;
    private readonly BundleLimitSettings _bundleLimitSettings;


    public ProductSummaryRequestHandler(
         IStringLocalizer<ProductSummaryRequestHandler> localizer,
         IUnitOfWork unitOfWork,
         IMapper mapper,
         ICurrentUser currentUser,
         ICommonService commonService,
         IAirshipService airshipService,
         IOptions<BundleLimitSettings> bundleLimitSettings,
         IUserService userService
       )
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _currentUser = currentUser;
        _commonService = commonService;
        _userService = userService;
        _airshipService = airshipService;
        _bundleLimitSettings = bundleLimitSettings.Value;
    }

    public async Task<Result<ProductSummaryResponse>> Handle(ProductSummaryRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();
        string userEmail = _currentUser.GetUserEmail()!;
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<ProductSummaryResponse>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdnDetails == null)
        {
            return Result<ProductSummaryResponse>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var lastTopup = await _unitOfWork.UserRepo.GetUserLastTopupInfo(msisdnDetails.AccountId!);
        var subscribeBundlesList = _mapper.Map<List<SubscribedBundleInfo>>(await _unitOfWork.UserRepo.GetSubscribedBundles(msisdnDetails.AccountId!));
        if (IsAppRequest)
        {
            subscribeBundlesList = subscribeBundlesList.Where(x => !x.IsRetry).ToList();
            foreach (var item in subscribeBundlesList)
            {
                if (item.Category == BundleCategory.Affiliate)
                {
                    item.ShowChangePlan = false;
                    item.ShowCancel = true;
                }

                if (item.Category == BundleCategory.TwelveMonthsContract)
                {
                    item.ShowChangePlan = true;
                    item.ShowCancel = true;
                    item.SubscriptionDate = item.Expiry;

                    var changePlan = _mapper.Map<SubscribedBundleInfo>(await _unitOfWork.BundleRepo.GetChangePlanBundleByMsisdn(msisdnDetails.Msisdn!));
                    if (changePlan != null)
                    {
                        var bundle = _mapper.Map<BundleInfo>(await _unitOfWork.BundleRepo.GetBundleById(changePlan.Id.ToString()));
                        if (bundle != null)
                        {
                            item.IsChangePlan = true;
                            item.NewPlan = bundle;
                        }
                    }
                }
            }
        }
        var bundles = _mapper.Map<List<BundleInfo>>(await _unitOfWork.BundleRepo.GetBundles(new BundlesRequest()));

        if (subscribeBundlesList != null && subscribeBundlesList.Any())
        {
            foreach (var item in subscribeBundlesList)
            {
                if (item.GprsDataBytes >= 0)
                {
                    item.RemainingGprsDataBytesConverted = _commonService.GetDataSize(item.RemainingGprsDataBytes);
                    item.RemainingGprsDataBytesConvertedWithoutUnit = _commonService.GetTotalDataSize(item.RemainingGprsDataBytes);
                    item.GprsDataBytesConverted = _commonService.GetTotalDataSize(item.GprsDataBytes);
                }
                item.IsAllowancewbundle = false;
                var result = bundles.FirstOrDefault(x => x.UuId.Trim().ToLower() == item.Id.ToString().ToLower());
                if (result == null)
                {
                    item.IsAllowancewbundle = true;
                    item.PlanName = item.BrandedName;
                }
                else
                {
                    item.PlanName = result.Name;
                    item.Price = result.Price;
                    item.Bundleid = result.Id;
                    item.GoodyBagColorCode = result!.GoodyBagColorCode!;
                }
                item.NoOfDays = Convert.ToInt32((item.Expiry - DateTime.UtcNow).TotalDays);
                item.ShowAutoRenew = item.Type != BundleType.Rolling;
            }
        }
        #region Events
        if (!IsAppRequest)
        {
            try
            {
                decimal totalMinutes = 0, totalSMS = 0, totalData = 0, totalRemainingMinutes = 0, totalRemainingSMS = 0, totalRemainingData = 0;
                decimal totalcallPercentage = 0, totalsmsPercentage = 0, totaldataPercentage = 0;
                List<decimal> bundleLimits = _bundleLimitSettings.Percentage;
                if ( subscribeBundlesList != null && subscribeBundlesList.Any())
                {
                    foreach (var item in subscribeBundlesList)
                    {
                        decimal callPercentage = 0, smsPercentage = 0, dataPercentage = 0;
                        totalMinutes = totalMinutes + Convert.ToDecimal(item.Minutes);
                        totalRemainingMinutes = totalRemainingMinutes + Convert.ToDecimal(item.RemainingMinutes);
                        totalSMS = totalSMS + Convert.ToDecimal(item.Texts);
                        totalRemainingSMS = totalRemainingSMS + Convert.ToDecimal(item.RemainingTexts);
                        if (item.GprsDataBytesConverted != "0 Bytes")
                        {
                            totalData = totalData + Convert.ToDecimal(item.GprsDataBytesConverted);
                        }
                        if (item.RemainingGprsDataBytesConvertedWithoutUnit != "0 Bytes")
                        {
                            totalRemainingData = totalRemainingData + Convert.ToDecimal(item.RemainingGprsDataBytesConvertedWithoutUnit);
                        }
                        if (Convert.ToInt32(item.Minutes) > 0)
                        {
                            callPercentage = (Convert.ToDecimal(item.RemainingMinutes) / Convert.ToDecimal(item.Minutes)) * 100;
                            callPercentage = 100 - callPercentage;
                        }
                        if (Convert.ToInt32(item.Texts) > 0)
                        {
                            smsPercentage = (Convert.ToDecimal(item.RemainingTexts) / Convert.ToDecimal(item.Texts)) * 100;
                            smsPercentage = 100 - smsPercentage;
                        }
                        if (item.GprsDataBytes > 0)
                        {
                            dataPercentage = (Convert.ToDecimal(item.RemainingGprsDataBytes) / Convert.ToDecimal(item.GprsDataBytes)) * 100;
                            dataPercentage = 100 - dataPercentage;
                        }
                        string bundleType = _commonService.GetBundleType(Convert.ToInt32(item.Category), Convert.ToInt32(item.Type));
                        if (callPercentage != 0 || smsPercentage != 0 || dataPercentage != 0)
                        {
                            foreach (var limit in bundleLimits)
                            {
                                if (callPercentage != 0 && callPercentage == limit)
                                {
                                    await _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                    {
                                        EventName = $"plan_{bundleType}_mins_{limit}_dash",
                                        Value = 0,
                                        Email = userEmail,
                                        InteractionType = "Home-Page",
                                        TagGroupName = "newProduct"
                                    });
                                }
                                if (smsPercentage != 0 && smsPercentage == limit)
                                {
                                    await _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                    {
                                        EventName = $"plan_{bundleType}_sms_{limit}_dash",
                                        Value = 0,
                                        Email = userEmail,
                                        InteractionType = "Home-Page",
                                        TagGroupName = "newProduct"
                                    });
                                }
                                if (dataPercentage != 0 && dataPercentage == limit)
                                {
                                    await _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                    {
                                        EventName = $"plan_{bundleType}_data_{limit}_dash",
                                        Value = 0,
                                        Email = userEmail,
                                        InteractionType = "Home-Page",
                                        TagGroupName = "newProduct"
                                    });
                                }
                            }

                        }
                    }

                    if (totalMinutes > 0)
                    {
                        totalcallPercentage = (Convert.ToDecimal(totalRemainingMinutes) / Convert.ToDecimal(totalMinutes)) * 100;
                        totalcallPercentage = 100 - totalcallPercentage;
                    }
                    if (totalSMS > 0)
                    {
                        totalsmsPercentage = (Convert.ToDecimal(totalRemainingSMS) / Convert.ToDecimal(totalSMS)) * 100;
                        totalsmsPercentage = 100 - totalsmsPercentage;
                    }
                    if (totalData > 0)
                    {
                        totaldataPercentage = (Convert.ToDecimal(totalRemainingData) / Convert.ToDecimal(totalData)) * 100;
                        totaldataPercentage = 100 - totaldataPercentage;
                    }
                    if (totalcallPercentage != 0 || totalsmsPercentage != 0 || totaldataPercentage != 0)
                    {
                        foreach (var limit in bundleLimits)
                        {
                            if (totalcallPercentage != 0 && totalcallPercentage == limit)
                            {
                                await _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                {
                                    EventName = $"plan_mins_{limit}_dash",
                                    Value = 0,
                                    Email = userEmail,
                                    InteractionType = "Home-Page",
                                    TagGroupName = "newProduct"
                                });
                            }
                            if (totalsmsPercentage != 0 && totalsmsPercentage == limit)
                            {
                                await _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                {
                                    EventName = $"plan_sms_{limit}_dash",
                                    Value = 0,
                                    Email = userEmail,
                                    InteractionType = "Home-Page",
                                    TagGroupName = "newProduct"
                                });
                            }
                            if (totaldataPercentage != 0 && totaldataPercentage == limit)
                            {
                                await _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                {
                                    EventName = $"plan_data_{limit}_dash",
                                    Value = 0,
                                    Email = userEmail,
                                    InteractionType = "Home-Page",
                                    TagGroupName = "newProduct"
                                });
                            }
                        }

                    }

                }
            }
            catch (Exception ex)
            {

            }
        }
        #endregion
        var suggestedBundles = _mapper.Map<List<BundleInfo>>
            (await _unitOfWork.BundleRepo.GetSuggestedBundles(new SuggestedBundleRequest() { Msisdn = request.Msisdn }));

        var response = new ProductSummaryResponse
        {
            SuggestedBundlesInfo = suggestedBundles,
            SubscribedBundlesInfo = subscribeBundlesList,
            MsisdnInfo = new MsisdnInfo()
            {
                LastTopUpAmount = lastTopup != null ? lastTopup.Amount : 0,
                LastTopUpDate = lastTopup?.Date.ToString("MM-dd-yyyy"),
                Credit = msisdnDetails.Credit!,
                FirstDate = msisdnDetails.FirstDate != null ? Convert.ToDateTime(msisdnDetails.FirstDate).ToString("MM-dd-yyyy") : null
            },
            Carousel = await _unitOfWork.PromotionRepo.GetPromotionCarousel(_currentUser.GetUserId(), request.Msisdn, null)
        };

        return Result<ProductSummaryResponse>.Success(response, _localizer[CustomStatusKey.Success]);
    }
}
