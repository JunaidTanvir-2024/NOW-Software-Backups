﻿using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Customers.Responses
{
    public class CustomerLoyaltyCardResponse
    {
        [JsonPropertyName("customerId")]
        public string? CustomerId { get; set; }
        [JsonPropertyName("loyaltyCard")]
        public string? LoyaltyCard { get; set; }
    }
}
