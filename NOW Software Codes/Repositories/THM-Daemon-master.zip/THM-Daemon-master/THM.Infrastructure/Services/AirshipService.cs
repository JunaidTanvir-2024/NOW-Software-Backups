﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using THM.Models.AirShip;
using THM.Models.Configurations;

namespace THM.Infrastructure.Services
{
    public interface IAirshipService
    {
        bool IsActive { get; }
        string AccountTagGroupName { get; }
        string CartTagGroupName { get; }
        string UserTagGroupName { get; }
        string PurchaseTagGroupName { get; }
        string ActivityTagGroupName { get; }
        Task AssociateNamedUserWeb(string channelId, string msisdn);
        Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress);
        Task AddEmailChannel(string emailAddress);
        Task AddNamedUserTags(NamedUserTagsRequest data);
        Task AddCustomEvent(CustomEventsRequest data);
        Task AddEmailChannelCommercial(string emailAddress);
        Task RemoveEmailChannelCommercial(string emailAddress);
        Task DisassociationNamedUserFromWebChannel(string namedUserId, string channelId);
    }

    public class AirshipService : IAirshipService
    {
        private readonly AirShipConfig _airShipConfig;
        private readonly HttpClient _httpClient;

        public bool IsActive { get; }
        public string AccountTagGroupName { get; }
        public string CartTagGroupName { get; }
        public string UserTagGroupName { get; }
        public string PurchaseTagGroupName { get; }
        public string ActivityTagGroupName { get; }

        public AirshipService(IOptions<AirShipConfig> airShipConfig, HttpClient httpClient)
        {
            _airShipConfig = airShipConfig.Value;
            _httpClient = httpClient;
            IsActive = airShipConfig.Value.IsActive;
            AccountTagGroupName = airShipConfig.Value.AccountTagGroupName;
            CartTagGroupName = airShipConfig.Value.CartTagGroupName;
            UserTagGroupName = airShipConfig.Value.UserTagGroupName;
            PurchaseTagGroupName = airShipConfig.Value.PurchaseTagGroupName;
            ActivityTagGroupName = airShipConfig.Value.ActivityTagGroupName;
        }

        public async Task AssociateNamedUserWeb(string channelId, string msisdn)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "NamedUser/Channel/WebAssociation")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        ChannelId = channelId,
                        NamedUserId = msisdn,
                        ProductCode = "THM"
                    }), Encoding.UTF8, "application/json")
                };

                await _httpClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "NamedUser/EmailAssociationWithNamedUser")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        EmailAddress = emailAddress,
                        NamedUserId = namedUserId,
                        ProductCode = "THM"
                    }), Encoding.UTF8, "application/json")
                };

                await _httpClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task AddEmailChannel(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THM"
                    }), Encoding.UTF8, "application/json")
                };

                await _httpClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task AddEmailChannelCommercial(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THM",
                        commercialOptedIn = DateTime.UtcNow
                    }), Encoding.UTF8, "application/json")
                };

                await _httpClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task RemoveEmailChannelCommercial(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THM",
                        commercialOptedOut = DateTime.UtcNow
                    }), Encoding.UTF8, "application/json")
                };

                await _httpClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task DisassociationNamedUserFromWebChannel(string namedUserId, string channelId)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "NamedUser/Channel/Disassociation")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        ChannelId = channelId,
                        NamedUserId = namedUserId,
                        DeviceType = 4,
                        ProductCode = "THM"
                    }), Encoding.UTF8, "application/json")
                };

                await _httpClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task AddNamedUserTags(NamedUserTagsRequest data)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "NamedUser/AddNuserTags")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json")
                };

                await _httpClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task AddCustomEvent(CustomEventsRequest data)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "CustomEvent/AddCustomEvent")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json")
                };

                await _httpClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
