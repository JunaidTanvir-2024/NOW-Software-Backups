﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts
{
    
    public class EmailTransactionModel
    {
        public string msisdn { get; set; }
        public string description { get; set; }
        public string status { get; set; }
        public string transactionId { get; set; }
        public string amount { get; set; }
    }
}
