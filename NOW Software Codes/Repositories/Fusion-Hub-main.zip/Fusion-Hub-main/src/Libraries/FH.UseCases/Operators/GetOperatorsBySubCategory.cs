using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;

namespace FH.UseCases.Operators;


public sealed class GetOperatorsBySubCategory
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {

        public string? CountryIsoCode { get; set; }
        public string? CurrencyCode { get; set; }
        public string? ProductCategoryAliasName { get; set; }
        public string? ProductSubCategoryAliasName { get; set; }
        public int Limit { get; set; }

    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {

        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public string? SubCategoryName { get; set; }
        public List<OperatorInfo> Operators { get; set; } = new List<OperatorInfo>();

        public sealed record OperatorInfo
        {
            public string? OperatorName { get; set; }
            public string? OperatorAliasName { get; set; }
            public string? OperatorShortCode { get; set; }
            public string? OperatorDescription { get; set; }
            public string? Logo { get; set; }
            public string? CountryIsoCode { get; set; }
            public string? CurrencyCode { get; set; }
            public CategoryInfo Category { get; set; } = new CategoryInfo();
            public sealed record CategoryInfo
            {
                public string? CategoryName { get; set; }
                public string? SubCategoryName { get; set; }
            }
        }


  

    }
    #endregion

    #region Handler
    internal sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IMapper _mapper = mapper;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var getOperatorsRequest = _mapper.Map<OperatorBySubCategoryDto.Request>(request);

            // Setting Default Values
            getOperatorsRequest.IsActive = true;
            getOperatorsRequest.IsDeleted = false;

            IEnumerable<OperatorBySubCategoryDto.Response> operators = await _unitOfWork.OperatorRepository.GetOperatorBySubCategory(getOperatorsRequest);

            if (operators is null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
            }


            var groupedOperators = operators
                .GroupBy(x => x.SubCategoryName)
                .Select(group => new GetOperatorsBySubCategory.Response()
                {
                    SubCategoryName = group.Key,
                    Operators = group.Select(operatorItem => new Response.OperatorInfo()
                    {
                        OperatorName = operatorItem.OperatorName,
                        OperatorAliasName = operatorItem.OperatorAliasName,
                        OperatorShortCode = operatorItem.OperatorShortCode,
                        OperatorDescription = operatorItem.OperatorDescription,
                        Logo = operatorItem.Logo,
                        CountryIsoCode = operatorItem.CountryIsoCode,
                        CurrencyCode = operatorItem.CurrencyCode,
                        Category = new Response.OperatorInfo.CategoryInfo()
                        {
                            CategoryName = operatorItem.CategoryName,
                            SubCategoryName = operatorItem.SubCategoryName
                        }
                    }).ToList()
                }).ToList();



            return ResultWrapper.Success(groupedOperators);
        }
    }
    #endregion
}



