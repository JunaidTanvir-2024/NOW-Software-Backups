namespace DC.Api.Controllers.Common;

[ApiController]
[ApiExplorerSettings(GroupName = "FushionHub")]
[Route("api/v{version:apiVersion}/[controller]")]
public abstract class BaseApiController : ControllerBase
{
    private ISender _mediator = null!;
    protected ISender Mediator => _mediator ??= HttpContext.RequestServices.GetRequiredService<ISender>();
}
