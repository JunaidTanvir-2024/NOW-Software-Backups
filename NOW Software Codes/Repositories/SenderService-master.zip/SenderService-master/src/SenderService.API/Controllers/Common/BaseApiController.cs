﻿using Microsoft.AspNetCore.Mvc;

namespace SenderService.API.Controllers.Common;
[ApiController]
[Route("[controller]")]
public abstract class BaseApiController : ControllerBase { }
