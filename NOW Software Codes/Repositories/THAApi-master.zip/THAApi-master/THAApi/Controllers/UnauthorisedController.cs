﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Response;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using THAApi.Utilities;
using THAApi.ViewModels;

using Twilio.Rest.Trunking.V1;

namespace THAAPI.Controllers
{
    [ApiController]
    public class UnauthorisedController : Controller
    {
        private readonly IUserAccount_BL UserAccountBL;
        private readonly IStringLocalizer localizer;
        private readonly preAuthConfig _preAuthConfig;
		private readonly ForceUpdateConfig ForceUpdateConfig;
        
        public UnauthorisedController(
            IOptions<ForceUpdateConfig> forceUpdateConfig,
            IUserAccount_BL userAccountBL,
            IStringLocalizer localizer,
            IOptions<preAuthConfig> preAuthConfig)
        {
            ForceUpdateConfig = forceUpdateConfig.Value;
            UserAccountBL = userAccountBL;
            this.localizer = localizer;
            this._preAuthConfig = preAuthConfig.Value;
		}

        [HttpGet]
        [Route("forceupdate")]
        public IActionResult Forceupdate()
        {
            return Ok(ForceUpdateConfig);
        }

        [HttpPost]
        [Route("useraccount/pinreminder")]
        public async Task<IActionResult> PinReminder([FromBody] PinReminderRequest request)
        {
            var tags = new string[] { $"msisdn:{request.Msisdn}", $"appversion:{request.AppInfo.AppVersion}", $"deviceos:{request.AppInfo.DeviceOS}" };
            return Ok(await UserAccountBL.SendPinReminder(request.Msisdn, request.AppInfo));
        }

        [HttpPost]
        [Route("useraccount/pre-auth")]
        public async Task<IActionResult> CreateWithPreAuthV2(UserInf request)
        {
            bool isTrusted = request.deviceInf.isTrusted;
            var remoteIp = string.Empty;
            var webAppRequestPrivateKey = HttpContext.Request.Headers["PrivateAccessKey"];
			if (webAppRequestPrivateKey.Equals(_preAuthConfig.PrivateAccessKey))
			{
                //trusted consumer, use ip sent by consumer
                remoteIp = HttpContext.Request.Headers["PrivateAccessIpAddress"];
			}
			else
			{
                //not trusted user, use ip address from request
                remoteIp = HttpContext.GetRemoteIPAddress();
            }
            AppInfo appInfo = new AppInfo
            {
                DevicePersistentID = request.deviceInf.DevicePersistentID,
                cpuArchitecture = request.deviceInf.cpuArchitecture,
                ActionExecuted = request.deviceInf.ActionExecuted,
                DeviceOS = request.deviceInf.DeviceOS,
                DeviceOSVersion = request.deviceInf.DeviceOSVersion,
                DeviceMake = request.deviceInf.DeviceMake,
                DeviceModel = request.deviceInf.DeviceModel,
                DeviceLanguage = request.deviceInf.DeviceLanguage,
                AppVersion = request.appInf.AppVersion,
                AppLanguage = request.appInf.AppLanguage
            };

            var result = await UserAccountBL.Create(request, remoteIp);


            if (result != null)
            {
                return Ok(result);
            }

            return StatusCode((int)HttpStatusCode.InternalServerError);
        }

        [HttpPost]
        [Route("users/{AuthTx}/pre-auth")]
        public IActionResult CreateWithPreAuth(SignUpRequest request, string AuthTx)
        {
            bool isTrusted = request.isTrusted;
            var remoteIp = HttpContext.GetRemoteIPAddress();

            MsisdnInfomation Minfo = new MsisdnInfomation();
            Minfo.Msisdn = request.Msisdn;
            Minfo.isPreAuthVerified = true;
            Minfo.isexistingUser = true;

            var result = GenericApiResponse<MsisdnInfomation>.Success(Minfo, "Success");

            //var result = await UserAccountBL.Create(request.Msisdn, request.AppInfo, isTrusted, remoteIp, request.ProductCode, request.ProductItemCode, AuthTx, false);

            if (result != null)
            {
                return Ok(result);
            }

            return StatusCode((int)HttpStatusCode.InternalServerError);
        }

        [AllowAnonymous]
        [HttpGet]
        [Route("healthCheck")]
        public IActionResult HealthCheck()
        {
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("PurchaseSuccess")]
        public IActionResult PurchaseSuccess([FromForm] SuccessViewModel model)
        {
            //return View("~/Views/PurchaseSuccess.cshtml", model);
            return View("~/Views/PurchaseSuccessV2.cshtml", model);
        }
    }
}