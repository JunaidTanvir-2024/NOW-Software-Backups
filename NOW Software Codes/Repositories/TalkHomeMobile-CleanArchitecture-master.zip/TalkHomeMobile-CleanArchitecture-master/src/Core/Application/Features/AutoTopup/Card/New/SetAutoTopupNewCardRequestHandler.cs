using Application.Common.Interfaces.Payment;
using Application.Common.Settings;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;
using Microsoft.Extensions.Options;

namespace Application.Features.AutoTopup.Card.New;

public class SetAutoTopupNewCardRequestHandler : IRequestHandler<SetAutoTopupNewCardRequest, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly IPayPalService _payPalService;
    private readonly ITopupRepository _topupRepo;
    private readonly TopupSettings _topupSettings;

    public SetAutoTopupNewCardRequestHandler(
        IPaymentService paymentService,
        ICurrentUser currentUser,
        IMapper mapper,
        IOptions<TopupSettings> topupSettings,
        IPayPalService payPalService,
        ITopupRepository topupRepo)
    {
        _paymentService = paymentService;
        _currentUser = currentUser;
        _mapper = mapper;
        _payPalService = payPalService;
        _topupRepo = topupRepo;
        _topupSettings = topupSettings.Value;
    }
    public async Task<Result<CardResponse>> Handle(SetAutoTopupNewCardRequest request, CancellationToken cancellationToken)
    {
        request.PaymentCardInfo.SaveCard = true;
        request.PaymentCardInfo.MakeDefault = true;
        var paymentTopupInfo = _mapper.Map<PaymentTopupInfo>(request);
        paymentTopupInfo.AutoTopupInfo.ThresHoldAmount = _topupSettings.ThresholdAmount;
        //Suspend PayPal subscription if Autotopup is already setuped with paypal
        //var autoTopup = await _topupRepo.GetAutoTopup(request.Msisdn!, _currentUser.GetUserEmail()!);
        //if (autoTopup?.Status == true && autoTopup.PaymentMethod?.Equals("paypal", StringComparison.InvariantCultureIgnoreCase) == true)
        //{
        //    await _payPalService.PayPalCancelSubscription(new PaypalSuspendSubscriptionRequest
        //    {
        //        SubscriptionId = autoTopup.InitialTransactionId!,
        //    });
        //}
        return await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: request.PaymentCardInfo,
            paymentExistingCardInfo: null!,
            paymentAddressInfo: request.PaymentAddressInfo,
            topupInfo: paymentTopupInfo,
            bundleInfo: null!,
            creditSimInfo: null!,
            msisdn: request.Msisdn,
            email: _currentUser.GetUserEmail()!,
            ipAddress: request.IpAddress,
            cardMaskedPan: null!,
            cardScheme: null!,
            isAuthorizeOnly: true
            );
    }
}