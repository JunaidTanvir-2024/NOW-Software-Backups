﻿using ATT.Models.Contracts;
using ATT.Models.Contracts.Reloadly.Request;
using ATT.Models.Contracts.Reloadly.Response;
using ATT.Models.Database;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.Reloady
{
    public interface IReloadlyPost_BL
    {
        Task<JsonOperatorProductResponse> ReloadlyFreeSwitchGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, string productCode, string productItemCode);
        Task<object> ReloadlyFreeSwitchTopUp(ExecuteData request);
        Task<JsonOperatorProductResponse> ReloadlyTHAGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, bool useDbRates, int? cdsp_config_id, string productCode, string productItemCode);
        Task<JsonOperatorProductResponse> Com_ATT_ReloadlyGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, int? cdsp_config_id, string productCode, string productItemCode, string ProductId, int selectedCarrierNumber);
        Task<JsonATTCRMOperatorProductResponse> ReloadlyATTCRMGetPhoneOperator(string account, string ToMsisdn, string productID);
        Task<object> ReloadlyTHATopUp(ExecuteData request);
        Task<object> CRM_ATT_ReloadlyTopUp(ExecuteData request, CRM_ATT_APIAccessGUID guidReferneceRecord);
    }
}
