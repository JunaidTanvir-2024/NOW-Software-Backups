﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class CaptureTransactionRequestModel
    {
        public string transactionId { get; set; }
    }
}
