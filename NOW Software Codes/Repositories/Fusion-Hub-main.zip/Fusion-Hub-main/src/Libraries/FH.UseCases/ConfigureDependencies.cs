using System.Reflection;

using FH.Core;
using FH.UseCases.Common.Behaviors;
using FH.UseCases.Countries;
using FH.UseCases.Operators;

using FluentValidation;

using Mapster;

using MapsterMapper;

using Mediator;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace FH.UseCases;
public static class ConfigureDependencies
{
    public static IServiceCollection AddUseCasesDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddCoreDependencies(configuration);
        services.RegisterMediatorBehaviors();
        services.RegisterRequestValidators();
        services.RegisterMapsterConfiguration();
        return services;
    }
    private static IServiceCollection RegisterMediatorBehaviors(this IServiceCollection services)
    {
        services.AddMediator(cfg =>
        {
            cfg.ServiceLifetime = ServiceLifetime.Scoped;
        });
        services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
        return services;
    }
    private static IServiceCollection RegisterRequestValidators(this IServiceCollection services)
    {
        services.AddScoped<IValidator<GetCountryByIsoCode.Query>, GetCountryByIsoCode.Validator>();
        services.AddScoped<IValidator<GetOperators.Query>, GetOperators.Validator>();
        services.AddScoped<IValidator<GetOperatorByName.Query>, GetOperatorByName.Validator>();

        return services;
    }
    private static IServiceCollection RegisterMapsterConfiguration(this IServiceCollection services)
    {
        var mapperConfiguration = TypeAdapterConfig.GlobalSettings;
        mapperConfiguration.Scan(Assembly.GetExecutingAssembly());
        services.AddSingleton(mapperConfiguration);
        services.AddScoped<IMapper, ServiceMapper>();
        return services;
    }
}
