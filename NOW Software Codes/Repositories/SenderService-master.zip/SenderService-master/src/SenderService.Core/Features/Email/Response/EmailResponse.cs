﻿using SenderService.Core.Persistence.Entities;

namespace SenderService.Core.Features.Email.Response;

public class EmailResponse
{
    public long Id { get; set; }
    public string? FromEmail { get; set; }
    public string? FromName { get; set; }
    public List<EmailRecipientInfo>? EmailRecipients { get; set; } = new List<EmailRecipientInfo>();
    public string? ProductItemCode { get; set; }
    public bool IsSent { get; set; }
}

public class EmailRecipientInfo
{
    public long Id { get; set; }

    public long EmailId { get; set; }

    public byte RecipientType { get; set; }

    public string EmailAddress { get; set; } = null!;

    public string? RecipientName { get; set; }
}