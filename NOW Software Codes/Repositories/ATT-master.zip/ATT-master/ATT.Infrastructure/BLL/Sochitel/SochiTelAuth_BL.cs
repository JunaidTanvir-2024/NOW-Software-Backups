﻿using System;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using ATT.Models.Contracts.Sochitel.Request;
using ATT.Models.Configurations;
using Microsoft.Extensions.Options;

namespace ATT.Infrastructure.BLL.Sochitel
{
    public class SochiTelAuth_BL : ISochiTelAuth_BL
    {

        private SochitelConfig SochitelConf;

        public SochiTelAuth_BL(IOptions<SochitelConfig> sochitelConf)
        {
            SochitelConf = sochitelConf.Value;
        }

        public string[] GetSochitelAttCredentials(string currency)
        {
            string[] Credentials = new string[] { "", "" };
            if (currency.ToUpper() == "GBP")
            {
                Credentials[0] = SochitelConf.AttUsernameGBP;
                Credentials[1] = SochitelConf.AttAppPasswordGBP;
            }
            else if (currency.ToUpper() == "EUR")
            {
                Credentials[0] = SochitelConf.AttUsernameEUR;
                Credentials[1] = SochitelConf.AttAppPasswordEUR;
            }
            else if (currency.ToUpper() == "USD") // USD
            {
                Credentials[0] = SochitelConf.AttUsernameUSD;
                Credentials[1] = SochitelConf.AttAppPasswordUSD;
            }
            return Credentials;
        }

        public Auth getAuthJSONObject(string strCurrency)
        {
            //Based on currency parameter   return Sochitel account credentials from configurations    
            //Parameters can be  GBP, USD  or EUR

            Auth auth = new Auth();
            string salt = RandomString(40);
            string[] Credentials = GetSochitelAttCredentials(strCurrency);

            /*if (strCurrency == "Default")
            {
                auth.username = ConfigurationManager.AppSettings["Sochitel_Security_Username_" + ConfigurationManager.AppSettings["Sochitel_Security_Default_Currency"]];
                auth.password = SHA1HashStringForUTF8String(salt + SHA1HashStringForUTF8String(ConfigurationManager.AppSettings["Sochitel_Security_Password_" + ConfigurationManager.AppSettings["Sochitel_Security_Default_Currency"]]));
            }
            else
            {*/
                auth.username = Credentials[0];
                auth.password = SHA1HashStringForUTF8String(salt + SHA1HashStringForUTF8String(Credentials[1]));
            //}

            auth.salt = salt;

            return auth;
        }


        private static string SHA1HashStringForUTF8String(string s)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(s);

            var sha1 = SHA1.Create();
            byte[] hashBytes = sha1.ComputeHash(bytes);

            return HexStringFromBytes(hashBytes);
        }


        private static string HexStringFromBytes(byte[] bytes)
        {
            var sb = new StringBuilder();
            foreach (byte b in bytes)
            {
                var hex = b.ToString("x2");
                sb.Append(hex);
            }
            return sb.ToString();
        }


        
        private string RandomString(int length)
        {
            Random random = new Random();
            string chars = SochitelConf.AuthStringForSaltGeneration;
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }


    }

}
