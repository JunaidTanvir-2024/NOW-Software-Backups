using System.Net;
using System.Net.Mail;
using System.Text;

using Microsoft.Extensions.Options;

using Newtonsoft.Json;

using Serilog;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Application.Settings;
using THCC.Domain.Aggregates;
using THCC.Infrastructure.Services.Mailing.External.Models;

using static THCC.Domain.Constants.ThccConstants;
using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Services.Mailing;

internal sealed class SmtpMailService : IMailService
{
    #region Fields

    private readonly MailSettings _settings;
    private readonly TopupSettings _topupSettings;
    private readonly ILogger _logger;
    private readonly ITemplateService _templateService;
    private readonly IUserRepository _userRepository;
    private readonly IPointsRepository _pointsRepository;
    private readonly ICommonService _commonService;
    private readonly IHttpClientFactory _httpClientFactory;

    #endregion

    #region Ctor

    public SmtpMailService(
        IOptions<MailSettings> settings,
        IOptions<TopupSettings> topupSettings,
        ILogger logger,
        ITemplateService emailTemplateService,
        IUserRepository userRepository,
        IPointsRepository pointsRepository,
        ICommonService commonService,
        IHttpClientFactory httpClientFactory)
    {
        _settings = settings.Value;
        _topupSettings = topupSettings.Value;
        _logger = logger;
        _templateService = emailTemplateService;
        _userRepository = userRepository;
        _pointsRepository = pointsRepository;
        _commonService = commonService;
        _httpClientFactory = httpClientFactory;
    }

    #endregion

    #region Account Management Emails

    public async Task<bool> SendForgotPasswordEmail(string toEmail, string otp)
    {
        if (!_settings.IsActive) { return false; }

        try
        {
            var user = await _userRepository.GetUserByEmailAsync(toEmail);
            var htmlbody = _templateService.GenerateTemplate(
                TemplateNames.ForgetPassword, new
                {
                    Name = $"{user?.FirstName}",
                    Otp = Convert.ToString(otp)
                });

            await SendEmailAsync(
                toEmail,
                _settings.ForgotPassword.From!,
                _settings.ForgotPassword.DisplayName!,
                _settings.ForgotPassword.Subject!,
                htmlbody);

            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return false;
        }
    }
    public async Task<bool> SendChangePasswordEmail(string toEmail, string browser, string ipAddress, string location)
    {
        if (!_settings.IsActive) { return false; }

        try
        {
            var user = await _userRepository.GetUserByEmailAsync(toEmail);
            var htmlbody = _templateService.GenerateTemplate(
                TemplateNames.ChangePasswordSuccess, new
                {
                    Name = user?.FirstName,
                    Email = toEmail,
                    Browser = browser,
                    IpAddress = ipAddress,
                    Location = location,
                    Time = DateTime.UtcNow
                });

            await SendEmailAsync(
                toEmail,
                _settings.ChangePasswordSuccess.From!,
                _settings.ChangePasswordSuccess.DisplayName!,
                _settings.ChangePasswordSuccess.Subject!,
                htmlbody);
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return false;
        }
    }
    public async Task<bool> SendEmailVerificationEmail(string toEmail, string otp)
    {
        if (!_settings.IsActive) { return false; }

        try
        {
            var user = await _userRepository.GetUserByEmailAsync(toEmail);
            var htmlbody = _templateService.GenerateTemplate(
                TemplateNames.EmailVerification, new
                {
                    Name = user?.FirstName,
                    Otp = otp
                });
            await SendEmailAsync(
                toEmail,
                _settings.VerifyEmail.From!,
                _settings.VerifyEmail.DisplayName!,
                _settings.VerifyEmail.Subject!,
                htmlbody);
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return false;
        }
    }
    public async Task<bool> SendSignupSuccessEmail(string toEmail)
    {
        if (!_settings.IsActive) { return false; }

        try
        {
            var user = await _userRepository.GetUserByEmailAsync(toEmail);
            var htmlbody = _templateService.GenerateTemplate(
                TemplateNames.SignUpSuccessEmail, new
                {
                    Name = user?.FirstName,
                    Email = toEmail
                });

            await SendEmailAsync(
                toEmail,
                _settings.SignUpSuccess.From!,
                _settings.SignUpSuccess.DisplayName!,
                _settings?.SignUpSuccess?.Subject?.Replace("{Name}", user?.FirstName)!,
                htmlbody);

            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return false;
        }
    }
    public async Task<bool> IsValidEmailAddress(string email)
    {
        try
        {
            if (_settings.RequireEmailValidation)
            {
                var client = _httpClientFactory.CreateClient();
                var request = new ValidateEmailRequest()
                {
                    Email = email,
                    ProductCode = nameof(ProductItemCode.THCC),
                    IpAddress = _commonService.GetIpAddress()
                };
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                var emailValidationEndpoint = $"{_settings.EmailServiceBaseUrl}Email/Validation";
                var response = await client.PostAsync(emailValidationEndpoint, content);
                var outputData = await response.Content.ReadAsStringAsync();
                _logger.Debug("SmtpMailService:VerifyEmailAddress => " + outputData);
                return JsonConvert.DeserializeObject<EmailVerificationDto>(outputData)!.Payload.IsEmailValid;
            }
            else
            {
                return true;
            }
        }
        catch (Exception ex)
        {
            _logger.Error(ex, "SmtpMailService:VerifyEmailAddress => " + ex.Message);
            return true;
        }
    }

    #endregion

    #region Transactions Email

    public async Task<bool> SendTHRCCFastRechargeEmail(OrderDetail orderDetails)
    {
        if (!_settings.IsActive) { return false; }
        try
        {
            bool isNewUser = true;
            bool isSectionShow = false;
            var user = await _userRepository.GetUserByIdAsync(orderDetails.UserId!);
            var userProduct = await _userRepository.GetUserProducts(orderDetails.UserId!);
            if (userProduct?.Product.Equals(orderDetails.CardNumber, StringComparison.OrdinalIgnoreCase) == true)
            {
                isSectionShow = true;
                isNewUser = false;
            }
            var htmlbody = _templateService.GenerateTemplate(TemplateNames.THRCCFastRecharge, new
            {
                CustomerEmail = user?.Email,
                FirstName = user?.FirstName!,
                TransactionId = orderDetails.OrderReference!,
                TimeStamp = $"{orderDetails.OrderDateTime:dd/MM/yyyy HH:mm:ss}",
                Browser = orderDetails.Device,
                orderDetails.IpAddress,
                Location = orderDetails.DeviceLocation,
                orderDetails.CardNumber,
                Cardpin = orderDetails.CardPin,
                TotalAmount = orderDetails.TotalAmount!.ToString("F"),
                OpeningBalance = orderDetails.OpeningBalance.ToString("F"),
                ClosingBalance = orderDetails.ClosingBalance.ToString("F"),
                PaymentMethod = orderDetails.PaymentMethodId!.ToString(),
                EarnedPoints = orderDetails.PointsReceived.ToString("F"),
                OpeningPoints = orderDetails.OpeningPoints.ToString("F"),
                ClosingPoints = orderDetails.ClosingPoints.ToString("F"),
                IsNewUser = isNewUser,
                IsSectionShow = isSectionShow
            });
            await SendEmailAsync(
                 user?.Email!,
                 _settings.THRCCFastRecharge.From!,
                 _settings.THRCCFastRecharge.DisplayName!,
                 _settings.THRCCFastRecharge.Subject!,
                 htmlbody);
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return false;
        }
    }
    public async Task<bool> SendTHRCCRechargeEmail(OrderDetail orderDetails)
    {
        if (!_settings.IsActive) { return false; }
        try
        {
            var user = await _userRepository.GetUserByIdAsync(orderDetails.UserId!);
            var htmlbody = _templateService.GenerateTemplate(TemplateNames.THRCCRecharge, new
            {
                CustomerEmail = user?.Email,
                FirstName = user?.FirstName!,
                TransactionId = orderDetails.OrderReference!,
                TimeStamp = $"{orderDetails.OrderDateTime!:dd/MM/yyyy HH:mm:ss}",
                Browser = orderDetails.Device!,
                orderDetails.IpAddress,
                Location = orderDetails.DeviceLocation,
                orderDetails.CardNumber,
                Cardpin = orderDetails.CardPin,
                TotalAmount = orderDetails.TotalAmount!.ToString("F"),
                OpeningBalance = orderDetails.OpeningBalance.ToString("F"),
                ClosingBalance = orderDetails.ClosingBalance.ToString("F"),
                PaymentMethod = orderDetails!.PaymentMethodId!.ToString(),
                EarnedPoints = orderDetails.PointsReceived.ToString("F"),
                OpeningPoints = orderDetails.OpeningPoints.ToString("F"),
                ClosingPoints = orderDetails.ClosingPoints.ToString("F"),
            });
            await SendEmailAsync(
                 user?.Email!,
                 _settings.THRCCRecharge.From!,
                 _settings.THRCCRecharge.DisplayName!,
                 _settings.THRCCRecharge.Subject!,
                 htmlbody);
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return false;
        }
    }
    public async Task<bool> SendRedeemEmail(OrderDetail orderDetails)
    {
        if (!_settings.IsActive) { return false; }
        try
        {
            var user = await _userRepository.GetUserByIdAsync(orderDetails.UserId!);
            var htmlbody = _templateService.GenerateTemplate(TemplateNames.RedeemEmail, new
            {
                CustomerEmail = user?.Email,
                FirstName = user?.FirstName!,
                TimeStamp = $"{orderDetails.OrderDateTime:dd/MM/yyyy HH:mm:ss}",
                TransactionId = orderDetails.OrderReference,
                Browser = orderDetails.Device,
                orderDetails.IpAddress,
                Location = orderDetails.DeviceLocation,
                orderDetails.CardNumber,
                Cardpin = orderDetails.CardPin,
                TotalAmount = orderDetails?.TotalAmount!.ToString("F"),
                OpeningBalance = orderDetails!.OpeningBalance.ToString("F"),
                ClosingBalance = orderDetails.ClosingBalance.ToString("F"),
                PaymentMethod = orderDetails!.PaymentMethodId!.ToString(),
                OpeningPoints = orderDetails.OpeningPoints.ToString("F"),
                EarnedPoints = orderDetails.PointsReceived.ToString("F"),
                ClosingPoints = orderDetails.ClosingPoints.ToString("F"),
            });
            await SendEmailAsync(
                 user?.Email!,
                 _settings.RedeemPoints.From!,
                 _settings.RedeemPoints.DisplayName!,
                 _settings.RedeemPoints.Subject!,
                 htmlbody);
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return false;
        }
    }
    public async Task<bool> SendTHRCCPurchaseEmail(OrderDetail orderDetails)
    {
        if (!_settings.IsActive) { return false; }
        try
        {
            var user = await _userRepository.GetUserByIdAsync(orderDetails.UserId!);

            var htmlbody = _templateService.GenerateTemplate(TemplateNames.THRCCPurchase, new
            {
                CustomerEmail = user?.Email,
                FirstName = user?.FirstName!,
                TransactionId = orderDetails.OrderReference!,
                TimeStamp = $"{orderDetails.OrderDateTime:dd/MM/yyyy HH:mm:ss}",
                Browser = orderDetails.Device,
                orderDetails.IpAddress,
                Location = orderDetails.DeviceLocation,
                orderDetails.CardNumber,
                Cardpin = orderDetails.CardPin,
                TotalAmount = orderDetails?.TotalAmount!.ToString("F"),
                OpeningBalance = orderDetails?.Amount.ToString("F"),
                PaymentMethod = orderDetails!.PaymentMethodId!.ToString(),
                EarnedPoints = _topupSettings.FirstRechargePoints + _topupSettings.Amounts.First(x => x.Amount == orderDetails.Amount).Points,
            });
            await SendEmailAsync(
                 user?.Email!,
                 _settings.THRCCPurchase.From!,
                 _settings.THRCCPurchase.DisplayName!,
                 _settings.THRCCPurchase.Subject!,
                 htmlbody);
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return false;
        }
    }
    public async Task<bool> SendTHCCPurchaseEmail(OrderDetail orderDetails)
    {
        if (!_settings.IsActive) { return false; }
        try
        {
            var user = await _userRepository.GetUserByIdAsync(orderDetails.UserId!);
            var htmlbody = _templateService.GenerateTemplate(TemplateNames.THCCPurchase, new
            {
                CustomerEmail = user?.Email,
                FirstName = user?.FirstName!,
                TransactionId = orderDetails.OrderReference!,
                TimeStamp = $"{orderDetails.OrderDateTime:dd/MM/yyyy HH:mm:ss}",
                Browser = orderDetails.Device,
                orderDetails.IpAddress,
                Location = orderDetails.DeviceLocation,
                Cardpin = orderDetails.CardPin,
                TotalAmount = orderDetails?.TotalAmount!.ToString("F"),
                OpeningBalance = orderDetails?.TotalAmount.ToString("F"),
                PaymentMethod = orderDetails!.PaymentMethodId!.ToString(),
                Validity = $"{_topupSettings.Amounts.Find(x => x.Amount == orderDetails.Amount)?.ExpiryDays} days"
            });
            await SendEmailAsync(
                 user?.Email!,
                 _settings.THCCPurchase.From!,
                 _settings.THCCPurchase.DisplayName!,
                 _settings.THCCPurchase.Subject!,
                 htmlbody);
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
            return false;
        }
    }

    #endregion

    #region Private Methods

    private async Task SendEmailAsync(
        string customerEmail,
        string fromEmail,
        string fromDisplayName,
        string subject,
        string emailBody)
    {
        try
        {
            SmtpClient client;
            if (_settings.AlternateHostDomains != null
                && _settings.AlternateHostDomains!.Any(x => customerEmail.Contains(x)))
            {
                client = new SmtpClient(_settings.AlternateHost, _settings.AlternatePort)
                {
                    DeliveryMethod = SmtpDeliveryMethod.Network
                };
                if (!string.IsNullOrEmpty(_settings.AlternateHostUserName)
                    && !string.IsNullOrEmpty(_settings.AlternateHostPassword))
                {
                    client.UseDefaultCredentials = false;
                    client.EnableSsl = true;
                    client.Credentials = new NetworkCredential(_settings.AlternateHostUserName, _settings.AlternateHostPassword);
                }
            }
            else
            {
                client = new SmtpClient(_settings.Host, _settings.Port)
                {
                    DeliveryMethod = SmtpDeliveryMethod.Network
                };

                if (!string.IsNullOrEmpty(_settings.UserName) && !string.IsNullOrEmpty(_settings.Password))
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(_settings.UserName, _settings.Password);
                }
            }

            var mailMessage = new MailMessage
            {
                From = new MailAddress(fromEmail, fromDisplayName),
                Sender = new MailAddress(fromEmail, fromDisplayName),
                Subject = subject
            };
            mailMessage.To.Add(customerEmail);
            mailMessage.Body = emailBody;
            mailMessage.Subject = mailMessage.Subject;
            mailMessage.IsBodyHtml = true;
            await client.SendMailAsync(mailMessage);
        }
        catch
        {
            throw;
        }
    }

    #endregion
}