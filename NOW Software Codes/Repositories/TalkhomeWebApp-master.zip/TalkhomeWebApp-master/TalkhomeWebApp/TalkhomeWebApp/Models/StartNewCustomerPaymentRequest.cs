﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.ViewModels;

namespace TalkhomeWebApp.Models
{
    public class StartNewCustomerPaymentRequest
    {
        [Required]
        [MaxLength(200)]
        public string nowtelRef { get; set; }

        [Required]
        public string product { get; set; }

        [Required]
        public string operatorId { get; set; }

        public NewPaymentCardViewModel NewCard { get; set; }
        public BillingAddressViewModel BillingAddress { get; set; }
    }
}
