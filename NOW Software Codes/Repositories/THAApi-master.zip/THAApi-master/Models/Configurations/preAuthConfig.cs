﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class preAuthConfig
    {
        public bool PreAuthEnabled { get; set; }
        public string ApiUrl { get; set; }
        public string ProductCode { get; set; }
        public string ProductItemCode { get; set; }
		public string PrivateAccessKey { get; set; }
	}
}
