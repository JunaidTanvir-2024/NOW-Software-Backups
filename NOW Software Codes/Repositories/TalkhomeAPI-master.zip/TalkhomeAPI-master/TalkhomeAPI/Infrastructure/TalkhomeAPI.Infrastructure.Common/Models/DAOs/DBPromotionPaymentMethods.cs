﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBPromotionPaymentMethods
    {
        public int PromotionId { get; set; }
        public PaymentMethodTypes PaymentMethodId { get; set; }
    }
}
