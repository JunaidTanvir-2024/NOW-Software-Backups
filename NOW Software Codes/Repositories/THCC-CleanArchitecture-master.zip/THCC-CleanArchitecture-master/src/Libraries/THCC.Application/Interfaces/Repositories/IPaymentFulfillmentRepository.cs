﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Repositories
{
    public interface IPaymentFulfillmentRepository : ServiceType.IScoped
    {
        Task<THCCPinDto> Pay360ThccCardFullfilment(
            string transactionId,
            string amount,
            string email,
            string firstname);

        Task<FullfilmentDto> Pay360ThrccCardFullfilment(
            string email,
            string firstName,
            string transactionId,
            string amount,
            string cardNumber);

        Task<THCCPinDto> PaypalThccCardFullfilment(
            string transactionId,
            string amount,
            string email,
            string firstname);

        Task<FullfilmentDto> PaypalThrccCardFullfilment(
            string email,
            string firstName,
            string transactionId,
            string amount,
            string cardNumber);

        Task UpdateFulfillmentItems(
            long orderItemId,
            string errorMsg,
            string cardnumber,
            string cardpin,
            string orderHistoryDescription = null!);

        Task<FullfilmentDto> ThrccCustomerFullfilment(
            string transactionId,
            string amount,
            string productRef);
    }
}
