

using DC.Core.Common.Definitions;
using DC.Core.Common.Interfaces.Database;

namespace DC.Infrastructure.Persistence.Repositories;
internal class UnitOfWork(IConfiguration configuration,
    ILogger logger,
    IAppLoggerRepository appLoggerRepository) : IUnitOfWork
{
    private readonly IConfiguration _configuration;
    private readonly ILogger _logger;
    private IDbTransaction _dbTransaction;
    private readonly IDbConnection _dbConnection = new SqlConnection(configuration.GetConnectionString(AppConstants.Database.Name.DigiConnect));
    private readonly Lazy<IAppLoggerRepository> _appLoggerRepository = new Lazy<IAppLoggerRepository>(() => appLoggerRepository);

    private bool _disposed;

    public IAppLoggerRepository AppLoggerRepository => _appLoggerRepository!.Value;
    public void BeginTransaction()
    {
        if (_dbTransaction == null)
        {
            if (_dbConnection.State != ConnectionState.Closed)
            {
                _dbConnection.Open();
            }
            _dbTransaction = _dbConnection.BeginTransaction();
        }
        else
        {
            throw new InvalidOperationException("Transaction Already started.");
        }
    }
    public void Commit()
    {
        try
        {
            _dbTransaction?.Commit();

        }
        catch (Exception ex)
        {

            _logger.Error("Transaction commit failed:{Exception}", ex);
            Rollback();
            throw;
        }

    }
    public void Rollback()
    {
        try
        {
            _dbTransaction?.Rollback();
        }
        catch (Exception ex)
        {
            _logger.Error("Transaction rollback failed:{Exception}", ex);
            throw;
        }
    }
    public void Dispose(bool disposing)
    {
        if (!_disposed)
        {
            if (disposing)
            {
                _dbTransaction?.Dispose();
                _dbConnection.Dispose();
            }
            _disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}
