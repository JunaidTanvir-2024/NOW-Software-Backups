﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class IsPhoneNumberAlreadyExistRequestModel
    {
        public string PhoneNumber { get; set; }
    }
}
