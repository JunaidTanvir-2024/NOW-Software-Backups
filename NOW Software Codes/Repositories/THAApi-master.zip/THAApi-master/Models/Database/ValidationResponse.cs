﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    public class ValidationResponse
    {
        public int ValidationType { get; set; }
        public string ValidationMessage { get; set; }
    }
}
