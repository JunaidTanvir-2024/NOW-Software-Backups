﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Database;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface IHistory_DL
    {
        Task<IEnumerable<UserAccountPaymentHistory>> GetPaymentHistoryAsync(string msisdn);
        Task<IEnumerable<PaymentHistory>> GetEntirePaymentHistory(string account, string msisdn);
        Task<IEnumerable<PaymentHistory>> GetEntirePaymentHistoryV2(string account, string msisdn);
    }
}
