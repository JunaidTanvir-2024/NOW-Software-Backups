using System.Data;

using Dapper;

using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;

using Microsoft.Data.SqlClient;

using Microsoft.Extensions.Configuration;

using Serilog;

namespace FH.Infrastructure.Persistence.Repositories;
internal class TransactionRepository(IConfiguration configuration, ILogger logger) : ITransactionRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private readonly ILogger _logger = logger;

    public async Task TransactionInsert(ProductTransactionInsertDto.Request request)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var productTransactionParameters = new DynamicParameters();
                productTransactionParameters.Add("transaction_reference", request.TransactionReference);
                productTransactionParameters.Add("vendor_transaction_id", request.VendorTransactionId);
                productTransactionParameters.Add("vendor_transaction_reference", request.VendorTransactionReference);
                productTransactionParameters.Add("cart_reference", request.CartReference);
                productTransactionParameters.Add("vendor_product_code", request.ProductVendorCode);
                productTransactionParameters.Add("product_id", request.ProductId);
                productTransactionParameters.Add("status", request.Status);

                await connection.ExecuteAsync(AppConstants.Database.StoreProcedure.ProductTransactionInsert, productTransactionParameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(CountryRepository), methodName: nameof(TransactionInsert));
        }
    }
    public async Task<ProductTransactionUpdateDto.Response?> TransactionUpdate(ProductTransactionUpdateDto.Request request)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var productTransactionParameters = new DynamicParameters();
                productTransactionParameters.Add("vendor_transaction_id", request.VendorTransactionId);
                productTransactionParameters.Add("status", request.Status);

                return await connection.QueryFirstOrDefaultAsync<ProductTransactionUpdateDto.Response>(AppConstants.Database.StoreProcedure.ProductTransactionUpdate, productTransactionParameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(CountryRepository), methodName: nameof(TransactionInsert));
            return default!;
        }
    }
}
