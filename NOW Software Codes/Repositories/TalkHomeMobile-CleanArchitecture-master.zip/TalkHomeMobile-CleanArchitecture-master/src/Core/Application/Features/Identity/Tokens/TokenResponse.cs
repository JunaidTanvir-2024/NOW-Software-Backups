namespace Application.Features.Identity.Tokens;

public record TokenResponse(string Token, string RefreshToken);