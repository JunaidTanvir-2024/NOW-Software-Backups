﻿using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;

namespace Application.Features.Payment.Card.ExistingCardPaymentV3;
public class ExistingCardPaymentRequestV3 : IRequest<Result<CardResponse>>
{
    public string? Msisdn { get; set; }

    public PaymentExistingCardInfo PaymentCardInfo { get; set; } = default!;

    public SetPaymentTopupInfo? TopupInfo { get; set; }

    public PaymentBundleInfo? BundleInfo { get; set; }

    public PaymentCreditSimInfo? CreditSimInfo { get; set; }
    public PaymentEarlyTerminationChargesInfo? EarlyTerminationChargesInfo { get; set; }

    [JsonIgnore]
    public string? Email { get; set; }

    [JsonIgnore]
    public string? IpAddress { get; set; }
    [JsonIgnore]
    public string? ConversionID { get; set; }
    [JsonIgnore]
    public ConversionPlatForm ConversionPlatFormID { get; set; }
    public bool IsRetry { get; set; } = false;
}