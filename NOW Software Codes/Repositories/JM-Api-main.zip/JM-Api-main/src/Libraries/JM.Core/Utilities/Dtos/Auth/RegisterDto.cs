using JM.Core.Utilities.Definitions;

namespace JM.Core.Utilities.Dtos.Auth;
public abstract class RegisterDto
{
	public sealed record Request
	{
		public required string Email { get; set; }
		public required string Password { get; set; }
		public bool IsSocialLogin { get; set; }
		public string? ProviderKey { get; set; }
		public AppEnum.LoginProvider Provider { get; set; }
	}
	public sealed record Response
	{
		public required bool IsSuccess { get; set; }
	}
}
