﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayG.Models.Porting
{
    public class CancelPortingRequestModel
    {
        public string RequestID { get; set; }
    }
}
