﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Utilities;
public sealed class EnumValidationAttribute : ValidationAttribute
{
    private readonly Type _enumType;
    public EnumValidationAttribute(Type enumType)
    {
        _enumType = enumType;
    }
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        if (Enum.IsDefined(_enumType, value))
        {
            return ValidationResult.Success!;
        }
        return new ValidationResult($"The {validationContext.DisplayName} field is required and must be a valid {_enumType.Name} value.");
    }
}

