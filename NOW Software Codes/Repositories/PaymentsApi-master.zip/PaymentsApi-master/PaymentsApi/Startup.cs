﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using PaymentsApi.Infrastructure.BLL.Implementation.Pay360;
using PaymentsApi.Infrastructure.BLL.Implementation.Paypal;
using PaymentsApi.Infrastructure.BLL.Interfaces.Pay360;
using PaymentsApi.Infrastructure.BLL.Interfaces.Paypal;
using PaymentsApi.Infrastructure.DAL.Database;
using PaymentsApi.Infrastructure.DAL.Implementation;
using PaymentsApi.Infrastructure.DAL.Interfaces;
using PaymentsApi.Infrastructure.Services.Implementation;
using PaymentsApi.Infrastructure.Services.Interfaces;
using PaymentsApi.Middleware;
using PaymentsApi.Models.Configurations;
using PaymentsApi.Models.Utility;
using PaymentsApi.Utility;
using PhoneNumbers;
using Serilog;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.Swagger;
using System.IO;

namespace PaymentsApi
{
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			services.AddSentry();
			services.AddSingleton((ILogger)new LoggerConfiguration()
			 .MinimumLevel.Debug()
			 .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "PaymentsApi-log-{Date}.txt"))
			 .WriteTo.Sentry(options=> Configuration.GetSection("Sentry").Bind(options))
			 .CreateLogger());

			services.AddMvc().AddNewtonsoftJson();
			services.Configure<Pay360Config>(Configuration.GetSection("Pay360"));
			services.Configure<ConnectionString>(Configuration.GetSection("ConnectionStrings"));
			services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));
			services.Configure<SmsConfig>(options => Configuration.GetSection("SmsConfig").Bind(options));
			services.Configure<SmtpConfig>(options => Configuration.GetSection("Smtp").Bind(options));
			services.Configure<SimulationConfig>(options => Configuration.GetSection("Simulation").Bind(options));
			services.Configure<DataPolicyConfig>(Configuration.GetSection("DataPolicyConfig"));
			services.AddSingleton(Configuration.GetSection("Pay360").Get<Pay360Config>());
			services.AddTransient<BL_IPay360CashierApi, BL_Pay360CashierApi>();
			services.AddTransient<BL_IPay360CommonServices, BL_Pay360CommonServices>();
			services.AddTransient<DL_IPay360, DL_Pay360>();
			services.AddTransient<IBL_Paypal, BL_Paypal>();
			services.AddTransient<IDL_Paypal, DL_Paypal>();
			services.AddSingleton<IEmailTemplates, EmailTemplates>();
			services.AddTransient<IPay360Auth, Pay360Auth>();
			services.AddSingleton(PhoneNumberUtil.GetInstance());
			services.AddTransient<IPhoneNumberService, PhoneNumberService>();
			services.AddHttpContextAccessor();
			services.AddHttpClient<IApiCall, ApiCall>();
			services.AddSwaggerGen(c =>
			{
				c.SwaggerDoc("v1", new OpenApiInfo
				{
					Version = "v1",
					Title = "My API",
					Description = "Pay360",
					Contact = new OpenApiContact
					{
						Email = "hello@talkhomemobile.com",
						Name = "Pay360",
						Url = new System.Uri("https://talkhome.co.uk/")
					}

				});
			});

			//services.AddDbContext<DatabaseContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IHostingEnvironment env)
		{
			app.UseMiddleware<RequestLogging>();
			app.UseSwagger();
			app.UseSwaggerUI(c =>
			{
				c.SwaggerEndpoint("/swagger/v1/swagger.json", "Pay360 API V1");
			});
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}
			else
			{
				app.UseHsts();
			}
			app.UseRouting();
			app.UseSentryTracing();
			app.UseEndpoints(configure =>
			{
				configure.MapControllers();
			});
		}
	}
}
