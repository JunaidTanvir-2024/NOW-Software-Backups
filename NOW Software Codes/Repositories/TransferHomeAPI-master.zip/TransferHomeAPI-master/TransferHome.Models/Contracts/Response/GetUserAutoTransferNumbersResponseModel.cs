﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.Response
{
    public class GetUserAutoTransferNumbersResponseModel
    {
        public IEnumerable<AutoTransferNumbersResponseModel> Numbers { get; set; }
    }

    public class AutoTransferNumbersResponseModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int PaymentTypeId { get; set; }
        public int RegularityTypeId { get; set; }
        public string ToMsisdn { get; set; }
        public string ToMsisdnCountryCode { get; set; }
        public decimal Amount { get; set; }
        public bool IsOn { get; set; }
        public string AmountCurrency { get; set; }
        public DateTime CreatedDateTime { get; set; }
    }
}
