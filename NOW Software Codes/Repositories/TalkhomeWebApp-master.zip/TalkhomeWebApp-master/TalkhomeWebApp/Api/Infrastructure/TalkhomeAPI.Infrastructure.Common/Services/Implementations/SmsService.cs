﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using System.Linq;
using Serilog;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class SmsService : ISmsService
    {
        private readonly TwilioConfig _twilioConfig;
        private readonly ILogger _logger;

        public SmsService(IOptions<TwilioConfig> twilioConfig,
            ILogger logger)
        {
            _twilioConfig = twilioConfig.Value;
            _logger = logger;
        }

        public async Task ReSendSms(int phoneCountryCode, string to, string textMessage)
        {
            await Send(phoneCountryCode, to, textMessage);
        }

        public async Task SendSms(int phoneCountryCode, string to, string textMessage)
        {
            await Send(phoneCountryCode, to, textMessage);
        }

        private async Task Send(int phoneCountryCode, string to, string textMessage)
        {
            Twilio.Types.PhoneNumber from = _twilioConfig.TwilioFromNotRestricted;

            if (_twilioConfig.TwilioFromNumberCountries.Contains(phoneCountryCode.ToString()))
            {
                from = new Twilio.Types.PhoneNumber(_twilioConfig.TwilioNumber);
            }
            try
            {
                TwilioClient.Init(_twilioConfig.Sid, _twilioConfig.AuthToken);
                var response = await MessageResource.CreateAsync(
                        body: textMessage,
                        from: from,
                        to: new Twilio.Types.PhoneNumber(to.StartsWith("+") ? to : "+" + to)
                        );
            }
            catch (Exception ex)
            {
                string requestParameters = $"from : {from}, to: {to}, textMessage: {textMessage}";
                _logger.Error($"SmsService - Method: SendSms, " +
                    $"CountryCode: {phoneCountryCode}  , Parameters --> {requestParameters}, Exception: {ex.Message}");
            }
        }
    }
}
