﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models
{
    public class StartExistingCardPaymentRequest
    {
        [Required]
        [MaxLength(200)]
        public string nowtelRef { get; set; }

        [Required]
        public string product { get; set; }

        [Required]
        public string operatorId { get; set; }

        [Required]
        public string cardToken { get; set; }

        [Required(ErrorMessage = "Enter Security Code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string SecurityCode { get; set; }
    }
}
