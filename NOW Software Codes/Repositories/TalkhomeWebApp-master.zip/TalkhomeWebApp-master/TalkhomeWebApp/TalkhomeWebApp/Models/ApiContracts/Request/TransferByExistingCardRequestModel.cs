﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class TransferByExistingCardRequestModel
    {
        public string nowtelRef { get; set; }
        public string product { get; set; }
        public string operatorId { get; set; }
        public string cardToken { get; set; }
        public string SecurityCode { get; set; }
        public string ipAddress { get; set; }
    }
}
