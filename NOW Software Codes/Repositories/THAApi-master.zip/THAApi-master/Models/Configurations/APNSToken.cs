﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{

    public class APNSToken
    {
        public string APNS { get; set; }
        public string Pushkit { get; set; }
        public bool sandBox { get; set; }
    }
}
