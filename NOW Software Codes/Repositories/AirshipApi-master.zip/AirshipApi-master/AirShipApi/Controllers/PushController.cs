﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;

namespace AirShipApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PushController : ControllerBase
    {
        private readonly ILogger Logger;
        private IPush_BL PushBl;

        public PushController(ILogger logger, IPush_BL pushBl)
        {
            Logger = logger;
            PushBl = pushBl;
        }

        [HttpPost]
        [Route("SendPushToTags")]
        public async Task<IActionResult> SendPushToTags(SendPushToTagsRequest request)
        {

            try
            {
                var response = await PushBl.SendPushToTags(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: PushController, Method: SendPushToTags, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<ApiPushResponse>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("SendPushToNamedUser")]
        public async Task<IActionResult> SendPushToNamedUser(SendPushToNamedUserRequest request)
        {

            try
            {
                var response = await PushBl.SendPushToNamedUser(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: PushController, Method: SendPushToNamedUser, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<ApiPushResponse>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

    }
}