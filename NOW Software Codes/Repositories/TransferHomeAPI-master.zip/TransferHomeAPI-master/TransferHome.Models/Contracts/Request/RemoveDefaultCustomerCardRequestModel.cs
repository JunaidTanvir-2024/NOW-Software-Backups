﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class RemoveDefaultCustomerCardRequestModel
    {
        public string Token { get; set; }
    }
}
