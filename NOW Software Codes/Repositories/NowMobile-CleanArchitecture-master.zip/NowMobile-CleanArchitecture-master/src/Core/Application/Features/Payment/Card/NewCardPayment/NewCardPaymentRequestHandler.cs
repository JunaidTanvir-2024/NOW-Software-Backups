﻿using Application.Common.Interfaces.Payment;
using Application.Common.Interfaces.Repositories;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;

namespace Application.Features.Payment.Card.NewCardPayment;

public class NewCardPaymentRequestHandler : IRequestHandler<NewCardPaymentRequest, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly IMapper _mapper;
    private readonly IUnitOfWork _unitOfWork;

    public NewCardPaymentRequestHandler(IPaymentService paymentService,
        IMapper mapper,
        IUnitOfWork unitOfWork
        )
    {
        _paymentService = paymentService;
        _mapper = mapper;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<CardResponse>> Handle(NewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        request.PaymentCardInfo.CardNumber = request.PaymentCardInfo.CardNumber!.Trim().Replace(" ","");
        return await _paymentService.HandleCardPaymentRequest(
                request.PaymentCardInfo,
                null!,
                request.PaymentAddressInfo,
                request.TopupInfo!,
                request.BundleInfo!,
                null!,
                request.Msisdn!,
                request.Email!,
                request.IpAddress!,
                null!,
                null!);
    }
}