﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Mobiquity.Response
{
    public class MobiquityTopUpResponse
    {
        public string serviceRequestId { get; set; }
        public string transactionStatus { get; set; }
        public string mfsTenantId { get; set; }
        public string language { get; set; }
        public string serviceFlow { get; set; }
        public string transactionTimeStamp { get; set; }
        public string message { get; set; }
        public string transactionId { get; set; }
        public string originalServiceRequestId { get; set; }
        public string txnStatus { get; set; }
        public string workFlowId { get; set; }
        public string referenceServiceRequestId { get; set; }
        public string remarks { get; set; }
        public string status { get; set; }
    }
}


public class CommandResponse
{
    public CommandDetails Command { get; set; }
}

public class CommandDetails
{
    public string TXNSTATUS { get; set; }
    public string MESSAGE { get; set; }
    public string ERROR_CODE { get; set; }
}
