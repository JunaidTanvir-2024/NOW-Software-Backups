﻿namespace SC.Core.Common.Definitions.Constants;

public static partial class AppEnums
{
    public enum Vendors
    {
        FusionHub = 1,
        Pay360 = 2,
        MessageMatrix =3,
        EventTracking = 4,
    }
}