﻿using System.Text;

using Microsoft.Extensions.Options;

using Newtonsoft.Json;

using THCC.Application.Interfaces.Services;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;
using THCC.Infrastructure.Services.Payment.Models;
using THCC.Infrastructure.Services.Payment.Pay360;
using THCC.Infrastructure.Services.Payment.PayPal.Models;

using static THCC.Domain.Constants.ThccConstants;
using static THCC.Domain.Constants.ThccEnums;

using ILogger = Serilog.ILogger;


namespace THCC.Infrastructure.Services.Payment.PayPal
{
    public class PayPalService : IPayPalService
    {
        #region Fields

        private readonly PayPalSetting _paypalSettings;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger _logger;
        private readonly ICommonService _commonService;

        #endregion

        #region Ctor
        public PayPalService(
            IOptions<PayPalSetting> paypalSettings,
            IHttpClientFactory httpClientFactory,
            ILogger logger,
            ICommonService commonService)
        {
            _paypalSettings = paypalSettings.Value;
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            _commonService = commonService;
        }

        #endregion

        #region Public Methods

        public async Task<PayPalPaymentResponseDto> CreateSalePayment(PaypalPaymentRequestDto request)
        {
            var paymentRquest = CreateDirectPaypalRequest(request);

            //handle Direct Paypal Payment Response 
            return await DirectPaypalCreateSalePayment(paymentRquest);
        }

        public async Task<PayPalPaymentResponseDto> ExecuteSalePayment(
          string customerUniqueRef,
          string payerId,
          string paymentId)
        {
            var json = JsonConvert.SerializeObject(new PayPalExecuteSalePaymentRequest()
            {
                CustomerUniqueRef = customerUniqueRef,
                IsDirectFullfilment = false,
                PayerId = payerId,
                PaymentId = paymentId,
                ProductCode = nameof(ProductCode.THCC)
            });

            var paypalPaymentResponse = new PayPalPaymentResponseDto();

            try
            {
                var httpClient = _httpClientFactory.CreateClient();
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var output = await httpClient.PostAsync(_paypalSettings.ApiEndpoint + "Paypal/ExecuteSalePayment", content);
                string outputData = await output.Content.ReadAsStringAsync();
                if (output.IsSuccessStatusCode)
                {
                    var response = JsonConvert.DeserializeObject
                        <GenericApiResponse<PayPalExecuteSalePaymentResponse>>(outputData)!;
                    if (response.ErrorCode > 0)
                    {
                        _logger.Debug(
                               "Class: PayPalService, " +
                               "Method: ExecuteSalePayment, " +
                               $"Request: {json}" +
                               $"Response: {JsonConvert.SerializeObject(response)}");

                        //log here the complete response
                        paypalPaymentResponse.IsSuccess = false;
                        if (response.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                        {
                            paypalPaymentResponse.ErrorCode = CustomStatusCode.BadRequest;
                            paypalPaymentResponse.ErrorMessage = CustomStatusKey.DailyPaymentLimitExceeded;
                        }
                        else if (response.ErrorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                        {
                            paypalPaymentResponse.ErrorCode = CustomStatusCode.BadRequest;
                            paypalPaymentResponse.ErrorMessage = response.Message;
                        }
                        else
                        {
                            paypalPaymentResponse.ErrorCode = CustomStatusCode.BadRequest;
                            paypalPaymentResponse.ErrorMessage = CustomStatusKey.OrderNotCompleted;
                        }
                        return paypalPaymentResponse;
                    };
                    paypalPaymentResponse.IsSuccess = true;
                    paypalPaymentResponse.TransactionId = response.Payload!.PaypalTransactionId;
                    return paypalPaymentResponse;
                }
                else
                {
                    _logger.Error(
                       "Class: PayPalService, " +
                       "Method: PayPalExecuteSalePayment" +
                       $"Status Code: {output.StatusCode}" +
                       $"Request: {json}" +
                       $"Response: {outputData}");
                }

                paypalPaymentResponse.IsSuccess = false;
                paypalPaymentResponse.ErrorMessage = outputData;
                paypalPaymentResponse.ErrorCode = -1;
                return paypalPaymentResponse;
            }
            catch (Exception ex)
            {
                _logger.Error(
                   "Class: PayPalService, " +
                   "Method: PayPalExecuteSalePayment" +
                   $"Request: {json}" +
                   $"Response: {ex.Message}");

                paypalPaymentResponse.IsSuccess = false;
                paypalPaymentResponse.ErrorMessage = ex.Message;
                paypalPaymentResponse.ErrorCode = -1;
                return paypalPaymentResponse;
            }
        }

        #endregion

        #region Private Methods

        private PayPalCreateSalePaymentRequest CreateDirectPaypalRequest(PaypalPaymentRequestDto request)
        {
            #region Create Basket

            var baskets = new List<ProductBasket>();
            ProductBasket basket = new();
            basket = request.ProductType == ProductType.CallingCard
                ? new ProductBasket()
                {
                    Amount = request.Amount,
                    BundleRef = "",
                    ProductRef = "",
                    ProductItemCode = nameof(ProductItemCode.THCC)
                }
                : new ProductBasket()
                {
                    Amount = request.Amount,
                    BundleRef = "",
                    ProductRef = request.CardPin ?? "",
                    ProductItemCode = nameof(ProductItemCode.THRCC)
                };
            baskets.Add(basket);

            #endregion

            string productType = Enum.GetName(typeof(ProductType), request.ProductType)!;
            request.Email = request.Email;

            return new PayPalCreateSalePaymentRequest()
            {
                CustomerEmail = request?.Email!,
                CustomerName = request?.Email!,
                CustomerUniqueRef = request?.Email!,
                CustomerMsisdn = null!,
                ProductCode = nameof(ProductCode.THCC),
                RedirectUrl = new RedirectUrls()
                {
                    ReturnUrl = _commonService.GetOriginRequestUrl()+ _paypalSettings.PaymentCallBackUrl +
                    "?orderId=" + request!.OrderId,
                    CancelUrl = _commonService.GetOriginRequestUrl() + _paypalSettings.PaymentCancelCallBackUrl +
                    "?orderId=" + request!.OrderId
                },
                Transactions = new Transactions()
                {
                    Description = $"PayPal Transaction - {productType} for Customer Unique Reference:{request?.Email}",
                    Amount = new Amounts()
                    {
                        Total = request!.Amount,
                        Currency = nameof(Currency.GBP)
                    }
                },
                Basket = baskets
            };
        }

        private async Task<PayPalPaymentResponseDto> DirectPaypalCreateSalePayment(PayPalCreateSalePaymentRequest request)
        {
            var json = JsonConvert.SerializeObject(request);
            var paypalPaymentResponse = new PayPalPaymentResponseDto();

            try
            {
                var httpClient = _httpClientFactory.CreateClient();
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var output = await httpClient.PostAsync(_paypalSettings.ApiEndpoint + "Paypal/CreateSalePayment", content);
                string outputData = await output.Content.ReadAsStringAsync();
                if (output.IsSuccessStatusCode)
                {
                    var response = JsonConvert.DeserializeObject<GenericApiResponse<PayPalCreateSalePaymentResponse>>(outputData)!;
                    if (response.ErrorCode > 0)
                    {
                        _logger.Debug(
                             "Class: PayPalService, " +
                             "Method: DirectPaypalCreateSalePayment, " +
                             $"Request: {json}" +
                             $"Response: {JsonConvert.SerializeObject(response)}");

                        paypalPaymentResponse.IsSuccess = false;
                        if (response.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                        {
                            paypalPaymentResponse.ErrorCode = CustomStatusCode.BadRequest;
                            paypalPaymentResponse.ErrorMessage = CustomStatusKey.DailyPaymentLimitExceeded;
                        }
                        else if (response.ErrorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                        {
                            paypalPaymentResponse.ErrorCode = CustomStatusCode.BadRequest;
                            paypalPaymentResponse.ErrorMessage = response.Message;
                        }
                        else
                        {
                            paypalPaymentResponse.ErrorCode = CustomStatusCode.BadRequest;
                            paypalPaymentResponse.ErrorMessage = CustomStatusKey.OrderNotCompleted;
                        }
                        return paypalPaymentResponse;
                    }
                    paypalPaymentResponse.IsSuccess = true;
                    paypalPaymentResponse.RedirectUrl = response.Payload!.RedirectUrl;
                    paypalPaymentResponse.TransactionId = response.Payload.TransactionId;
                    return paypalPaymentResponse;
                }
                else
                {
                    _logger.Error(
                       "Class: PayPalService, " +
                       "Method: DirectPaypalCreateSalePayment" +
                       $"Status Code: {output.StatusCode}" +
                       $"Request: {json}" +
                       $"Response: {outputData}");
                }

                paypalPaymentResponse.IsSuccess = false;
                paypalPaymentResponse.ErrorMessage = outputData;
                paypalPaymentResponse.ErrorCode = -1;
                return paypalPaymentResponse;
            }
            catch (Exception ex)
            {
                _logger.Error(
                   "Class: PayPalService, " +
                   "Method: DirectPaypalCreateSalePayment" +
                   $"Request: {json}" +
                   $"Response: {ex.Message}");

                paypalPaymentResponse.IsSuccess = false;
                paypalPaymentResponse.ErrorMessage = ex.Message;
                paypalPaymentResponse.ErrorCode = -1;
                return paypalPaymentResponse;
            }
        }

        #endregion
    }
}
