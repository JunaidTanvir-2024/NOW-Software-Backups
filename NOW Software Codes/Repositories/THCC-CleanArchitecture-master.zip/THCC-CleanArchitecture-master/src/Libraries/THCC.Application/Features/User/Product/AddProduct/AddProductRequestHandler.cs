﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.Product.AddProduct
{
    public class AddProductRequestHandler : IRequestHandler<AddProductRequest, object>
    {
        private readonly IUserRepository _userRepository;
        private readonly ICurrentUser _currentUser;
        private readonly ICallingCardRepository _callingCardRepository;
        private readonly ILogger _logger;

        public AddProductRequestHandler(IUserRepository userRepository,
            ICurrentUser currentUser,
            ICallingCardRepository callingCardRepository,
            ILogger logger)
        {
            _userRepository = userRepository;
            _currentUser = currentUser;
            _callingCardRepository = callingCardRepository;
            _logger = logger;
        }

        public async Task<object> Handle(AddProductRequest request, CancellationToken cancellationToken)
        {
            request.CardNumber = request.CardNumber.Trim();
            request.CardPin = request.CardPin.Trim();
            //Check If Product Exist
            var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
            if (userProduct != null)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.ProductAlreadyExist, CustomStatusCode.BadRequest);
            }

            //Validate Card Number
            var cardNoInfo = await _callingCardRepository.GetCardInfo(request.CardNumber);
            if (cardNoInfo?.Pin!.Trim().Equals(
                request.CardPin, StringComparison.InvariantCultureIgnoreCase) != true)
            {
                return ErrorResult.Failure(CustomStatusKey.InvalidCardorPinNumber!, CustomStatusCode.BadRequest);
            }

            //Validate Card Pin
            var pinInfo = await _callingCardRepository.GetPinInfo(request.CardPin);
            if (pinInfo?.Account!.Trim().Equals(
                request.CardNumber, StringComparison.InvariantCultureIgnoreCase) != true)
            {
                return ErrorResult.Failure(CustomStatusKey.InvalidCardorPinNumber!, CustomStatusCode.BadRequest);
            }

            //Add Product
            var (isSuccess, errorCode, errorMessage) = await _userRepository.CreateProduct(request.CardNumber!, _currentUser.GetUserId(), DateTime.UtcNow);
            if (!isSuccess)
            {
                if (errorCode > 0 && errorCode == 100117) //Card number already registered
                {
                    _logger.Debug(
                      "Class: AddProductRequestHandler, " +
                      "Method: Handle-CreateProduct, " +
                      $"Status Code: {errorCode}" +
                      $"Response: {errorMessage}");

                    return ErrorResult.Failure(
                        CustomStatusKey.CardNumberAlreadyRegistered, CustomStatusCode.BadRequest);
                }

                return ErrorResult.Failure(CustomStatusKey.BadRequest!, CustomStatusCode.BadRequest);
            }
            return Unit.Value;

        }
    }
}
