﻿using Application.Features.Bundle.Bundle;
using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.SubscribedBundle;

public class SubscribedBundleRequestHandler : IRequestHandler<SubscribedBundleRequest, Result<List<SubscribedBundleInfo>>>
{
    #region Fields

    private readonly IUnitOfWork _unitOfWork;
    private readonly IStringLocalizer<SubscribedBundleRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;

    #endregion

    #region Ctors

    public SubscribedBundleRequestHandler(
        IUnitOfWork unitOfWork,
        IStringLocalizer<SubscribedBundleRequestHandler> localizer,
        IMapper mapper,
        ICommonService commonService,
        IUserService userService)
    {
        _unitOfWork = unitOfWork;
        _localizer = localizer;
        _mapper = mapper;
        _commonService = commonService;
        _userService = userService;
    }

    #endregion

    #region Methods

    public async Task<Result<List<SubscribedBundleInfo>>> Handle(SubscribedBundleRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<List<SubscribedBundleInfo>>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdnDetails == null)
        {
            return Result<List<SubscribedBundleInfo>>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var subscribeBundlesList = _mapper.Map<List<SubscribedBundleInfo>>(await _unitOfWork.UserRepo.GetSubscribedBundles(msisdnDetails.AccountId!));
        (bool IsAppRequest,_,_)=_commonService.IsAppRequest();
        if (IsAppRequest)
        {
            subscribeBundlesList = subscribeBundlesList.Where(x => !x.IsRetry).ToList();
        }
        var bundles = _mapper.Map<List<BundleInfo>>(await _unitOfWork.BundleRepo.GetBundles(new BundlesRequest()));
       
        if (subscribeBundlesList.Any())
        {
            foreach (var item in subscribeBundlesList)
            {
                if (item.GprsDataBytes >= 0)
                {
                    item.RemainingGprsDataBytesConverted = _commonService.GetDataSize(item.RemainingGprsDataBytes);
                    item.RemainingGprsDataBytesConvertedWithoutUnit = _commonService.GetTotalDataSize(item.RemainingGprsDataBytes);
                    item.GprsDataBytesConverted = _commonService.GetTotalDataSize(item.GprsDataBytes);
                }
                item.IsAllowancewbundle = false;
                var result = bundles.FirstOrDefault(x => x.UuId.Trim().ToLower() == item.Id.ToString().ToLower());
                if (result == null)
                {
                    item.IsAllowancewbundle = true;
                    item.PlanName = item.BrandedName;
                }
                else
                {
                    item.PlanName = result.DisplayName.ToString();
                    item.Price = result.Price;
                    item.Bundleid = result.Id;
                    item.GoodyBagColorCode = result!.GoodyBagColorCode!;
                }
                item.NoOfDays = Convert.ToInt32((item.Expiry - DateTime.UtcNow).TotalDays);
                item.ShowAutoRenew = item.Type == BundleType.BoltOn || item.Type == BundleType.PAYG;

                if (item.Type == 0 && item.Category == 0)
                {
                    item.IsAutoRenew = false;
                    item.ShowAutoRenew = false;
                }

                if (item.Category == BundleCategory.Affiliate)
                {
                    item.IsAutoRenew = false;
                    item.ShowAutoRenew = false;
                }
                if (string.IsNullOrEmpty(item.AutoRenewCardPanMasked) && item.AutoRenewPaymentMethod?.Equals("Card", StringComparison.InvariantCultureIgnoreCase) == true)
                {
                    item.AutoRenewCardPanMasked = "Default";
                }
                if (item.Category == BundleCategory.TwelveMonthsContract)
                {
                    item.ShowChangePlan = true;
                    item.ShowCancel = true;
                    item.SubscriptionDate = item.Expiry;

                    var changePlan = _mapper.Map<SubscribedBundleInfo>(await _unitOfWork.BundleRepo.GetChangePlanBundleByMsisdn(msisdnDetails.Msisdn!));
                    if (changePlan != null)
                    {
                        var bundle = _mapper.Map<BundleInfo>(await _unitOfWork.BundleRepo.GetBundleById(changePlan.Id.ToString()));
                        if (bundle != null)
                        {
                            item.IsChangePlan = true;
                            item.NewPlan= bundle;
                        }

                    }
                }
            }
        }

       
        return Result<List<SubscribedBundleInfo>>.Success(subscribeBundlesList, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
