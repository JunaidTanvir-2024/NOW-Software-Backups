﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Response
{
    public class ApiGetSingleListRespose
    {
        public bool ok { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public DateTime? created { get; set; }
        public DateTime? last_updated { get; set; }
        public string status { get; set; }
        public int channel_count { get; set; }
        public Extra extra { get; set; }
        public class Extra
        {
            public string key { get; set; }
    
        }

    }
}
