namespace Application.Features.Account.History.Models;

public class DataHistoryInfo
{
    public DateTime DateStarted { get; set; }
    public string? SubscriberCharge { get; set; }
    [JsonIgnore]
    public int TotalCount { get; set; }
    public string? DataUsage { get; set; }
}