﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class VerifyEmailRequestModel
    {
        [Required]
        public string Token { get; set; }

        [Required]
        public int TokenTypeId { get; set; }
    }
}
