﻿using CancelBundleApi.Models.RequestModels;

namespace CancelBundleApi.Services.Interfaces;
public interface IUnsubscribeBundleService
{
    Task<bool> UnSubscribeBundle(UnSubscribeBundlesRequest request);
}
