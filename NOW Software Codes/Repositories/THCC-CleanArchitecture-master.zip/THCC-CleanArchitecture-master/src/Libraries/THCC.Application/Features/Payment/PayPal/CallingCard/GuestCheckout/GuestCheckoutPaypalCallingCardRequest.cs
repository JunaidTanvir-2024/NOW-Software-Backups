﻿using THCC.Application.Interfaces.Services;
using THCC.Application.Settings;

namespace THCC.Application.Features.Payment.PayPal.GuestCheckout.CallingCard
{
    public class GuestCheckoutPaypalCallingCardRequest : IRequest<object>
    {
        public decimal Amount { get; set; }
        public string? Email { get; set; }
        public string? EmailOtp { get; set; }
    }

    public class GuestCheckoutCallingCardRequestValidator : AbstractValidator<GuestCheckoutPaypalCallingCardRequest>
    {
        public GuestCheckoutCallingCardRequestValidator(
            IOptions<TopupSettings> topupSettings,ICommonService commonService)
        {
            RuleFor(p => p.Amount).Cascade(CascadeMode.Stop)
                .NotEmpty()
                .NotNull()
                .Must(x => topupSettings.Value.Amounts.Any(a => a.Amount == x))
                .WithMessage("Please only use: " + string.Join(",", values: topupSettings.Value.Amounts.Select(a => a.Amount)));

            RuleFor(p => p.Email)
           .NotNull()
           .NotEmpty()
           .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
           .Must(p => commonService.IsValidEmailAddress(p)).WithMessage("Invalid Email Address");

            RuleFor(p => p.EmailOtp).Cascade(CascadeMode.Stop)
               .NotEmpty()
               .NotNull()
               .MaximumLength(6).WithMessage("Your otp length must not exceed 6."); ;
        }
    }
}
