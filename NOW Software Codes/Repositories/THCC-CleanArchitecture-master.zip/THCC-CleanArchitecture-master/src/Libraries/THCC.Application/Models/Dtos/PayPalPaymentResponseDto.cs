﻿namespace THCC.Application.Models.Dtos
{
    public class PayPalPaymentResponseDto
    {
        public string? RedirectUrl { get; set; }
        public string? PaymentMethod { get; set; }
        public string? TransactionId { get; set; }
        public bool IsSuccess { get; set; }
        public int ErrorCode { get; set; }
        public string? ErrorMessage { get; set; }
    }
}