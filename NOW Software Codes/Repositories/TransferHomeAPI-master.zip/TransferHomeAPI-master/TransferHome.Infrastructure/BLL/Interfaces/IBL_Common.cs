﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Models.Configurations;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.Contracts.Response;
using TrasnferHome.Models.Contracts;

namespace TransferHome.Infrastructure.BLL.Interfaces
{
    public interface IBL_Common
    {
        Task<GenericApiResponse<GetTopupAmountsResponseModel>> GetTopupAmounts();
        Task<GenericApiResponse<InAppPurchaseConfig>> GetInAppPurchaseOptions(GetInAppPurchaseOptionsRequestModel model, string userId);
        Task<GenericApiResponse<ValidateAppleRecieptResponseModel>> ValidateAppleReciept(ValidateAppleRecieptRequestModel model);
    }
}
