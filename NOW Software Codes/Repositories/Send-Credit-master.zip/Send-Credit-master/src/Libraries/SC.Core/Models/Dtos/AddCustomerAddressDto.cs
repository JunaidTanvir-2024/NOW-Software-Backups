﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.Dtos;
public record AddCustomerAddressDto
{
    public string CustomerId { get; set; } = default!;

    public string AddressType { get; set; } = default!;

    public string StreetAddress1 { get; set; } = default!;

    public string StreetAddress2 { get; set; } = default!;

    public string City { get; set; } = default!;

    public string State { get; set; } = default!;

    public string PostalCode { get; set; } = default!;

    public string Country { get; set; } = default!;

    public string Email { get; set; } = default!;

    public string Phone { get; set; } = default!;
    public string Region { get; set; } = default!;
    public string CountryCode { get; set; } = default!;

}

