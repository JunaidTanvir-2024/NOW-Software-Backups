namespace Application.Features.Rate.InternationalWithBundle;

public class InternationalRatesWithBundleRequestValidator : AbstractValidator<InternationalRatesWithBundleRequest>
{

}
