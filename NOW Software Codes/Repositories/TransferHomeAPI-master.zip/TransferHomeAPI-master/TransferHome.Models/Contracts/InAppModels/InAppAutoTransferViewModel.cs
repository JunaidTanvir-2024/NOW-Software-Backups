﻿using System;
using System.Collections.Generic;
using System.Text;
using TransferHome.Models.Contracts.Response;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.InAppModels
{
    public class InAppAutoTransferViewModel
    {
        public decimal Amount { get; set; }
        public int UserId { get; set; }
        public string Currency { get; set; }
        public string CurrencySymbol { get; set; }
        public GetCutomerInfoResponseModel Customer { get; set; }

        public string NowtelTransactionReference { get; set; }
        public string Operatorid { get; set; }
        public string Product { get; set; }
        public string MessageToRecipient { get; set; }
        public string FromMSISDN { get; set; }

        public RegularityType RegularityType { get; set; }
    }
}
