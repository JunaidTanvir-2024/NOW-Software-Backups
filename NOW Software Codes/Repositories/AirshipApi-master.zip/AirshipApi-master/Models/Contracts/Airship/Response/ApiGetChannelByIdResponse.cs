﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Response
{

    public class ApiGetChannelByIdResponse
    {
        public bool ok { get; set; }
        public Channel channel { get; set; }
    }
    public class Channel
    {
        public string channel_id { get; set; }
        public DeviceType device_type { get; set; }
        public bool installed { get; set; }
        public bool background { get; set; }  // If true, the device can recieve background push notifications. If false, it cannot. This field only appears for iOS devices on the 5.0+ SDK.
        public bool opt_in { get; set; }
        public string push_address { get; set; }
        public string address { get; set; }
        public DateTime ?created { get; set; }
        public DateTime ?commercial_opted_in { get; set; }        
        public DateTime ?commercial_opted_out { get; set; }        
        public DateTime ?transactional_opted_in { get; set; }
        public DateTime ?transactional_opted_out { get; set; }        
        public DateTime ?last_registration { get; set; }
        public string named_user_id { get; set; }
        public string alias { get; set; }
        public List<string> tags { get; set; }
        public Dictionary<string, List<string>> tag_groups { get; set; }
        public Ios ios { get; set; }
        public DeviceAttribute device_attributes { get; set; }
    }
    
    public class DeviceAttribute
    {
        public string ua_device_os { get; set; }
        public string ua_country { get; set; }
        public string ua_device_model { get; set; }
        public string ua_local_tz { get; set; }
        public string ua_app_version { get; set; }
        public string ua_language { get; set; }
        public string ua_sdk_version { get; set; }
        public string ua_carrier { get; set; }
       
    }
public class Quiettime
{
    public string start { get; set; }
    public string end { get; set; }
}

public class Ios
{
    public int badge { get; set; }
    public Quiettime quiettime { get; set; }
    public string tz { get; set; }
}
}
