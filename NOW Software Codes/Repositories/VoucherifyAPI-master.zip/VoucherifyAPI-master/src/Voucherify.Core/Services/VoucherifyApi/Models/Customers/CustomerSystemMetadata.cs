using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Customers;

public class CustomerSystemMetadata
{
    [JsonPropertyName("consents")]
    public Dictionary<string, object>? Consents { get; set; }
}
