﻿using Application.Features.Payment.Paypal.Models;

namespace Application.Features.Payment.Paypal.Direct.ExecuteSale;

public class DirectPaypalExecutePaymentRequest : IRequest<Result<PaypalResponse>>
{
    public string? PayerId { get; set; }
    public string? PaymentId { get; set; }
    public int OrderId { get; set; }
    public string? CustomerUniqueRef { get; set; }
    public bool IsFastTopup { get; set; } = false;
}