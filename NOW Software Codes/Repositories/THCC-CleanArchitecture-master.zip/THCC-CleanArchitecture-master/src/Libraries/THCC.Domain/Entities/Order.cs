﻿using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Domain.Entities
{
    public class Order
    {
        public long Id { get; set; }
        public DateTime OrderDateTime { get; set; }
        public string? OrderReference { get; set; }
        public string UserId { get; set; } = default!;
        public decimal Amount { get; set; }
        public decimal Discount { get; set; }
        public decimal TotalAmount { get; set; }
        public OrderStatus OrderStatus { get; set; }
        public string? IpAddress { get; set; }
        public string? Device { get; set; }
        public string? DeviceLocation { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string? Description { get; set; }

        //public string? PaymentUserId { get; set; }
        //public PaymentMethod PaymentType { get; set; } = default!;
        //public string? PaymentTransactionId { get; set; }
        //public string? PaymentErrorMessage { get; set; }
        //public RecordStatus RecordStatus { get; set; }
        //public string? OrderInfoJson { get; set; }
    }
}
