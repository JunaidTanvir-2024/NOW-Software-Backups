﻿namespace SC.Infrastructure.Services.Tokens;

internal static class JwtConfiguration
{
    internal static IServiceCollection AddJwtConfiguration(this IServiceCollection services)
    {
        // Get IJwtTokenService
        var jwtService = services.BuildServiceProvider().GetRequiredService<IJwtService>();

        // Bind jwt settings
        var jwtSettings = services.BuildServiceProvider().GetRequiredService<IOptions<JwtSetting>>().Value;

        string publicKeyPath = string.Empty;

        // Get Secret Key Path;
        if (jwtSettings.AsymmetricFiles.SecretKeyFile is not null)
        {
            publicKeyPath = Path.Combine(Directory.GetCurrentDirectory(), jwtSettings.AsymmetricFiles.SecretKeyFile);
        }

        // Authentication scheme
        services.AddAuthentication(authentication =>
        {
            authentication.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            authentication.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        // Jwt Bearer with events
        .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, bearer =>
        {
            bearer.IncludeErrorDetails = true; // => true for easy debugging else remove it
            bearer.TokenValidationParameters = new TokenValidationParameters
            {
                IssuerSigningKey = new ECDsaSecurityKey(jwtService.GetSecurityKeyViaFile(publicKeyPath)),
                ValidAudience = jwtSettings.Audience,
                ValidIssuer = jwtSettings.Issuer,
                RequireSignedTokens = true,
                RequireExpirationTime = true,
                ValidateLifetime = true,
                ValidateAudience = true,
                ValidateIssuer = true,
                RoleClaimType = ClaimTypes.Role,
                ClockSkew = TimeSpan.Zero // Add zero tolerence on token expiration date/time
            };
            bearer.Events = new JwtBearerEvents
            {
                OnAuthenticationFailed = context => HandleAuthenticationFailed(context),
                OnChallenge = context => HandleChallenge(context),
                OnForbidden = context => HandleForbidden(context)
            };
        });
        services.AddAuthorization(options => options.DefaultPolicy = new AuthorizationPolicyBuilder()
            .RequireAuthenticatedUser()
            .AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme)
            .Build());
        return services;
    }
    private static Task HandleAuthenticationFailed(AuthenticationFailedContext context)
    {
        if (context.Exception is SecurityTokenExpiredException)
        {
            return WriteJsonResponseAsync(context.Response, AppConstants.StatusCodes.Unauthorized, AppConstants.StatusKeys.JwtTokenExpired);
        }
        if (context.Exception is SecurityTokenValidationException)
        {
            return WriteJsonResponseAsync(context.Response, AppConstants.StatusCodes.Unauthorized, AppConstants.StatusKeys.JwtTokenInvalid);
        }
        return Task.CompletedTask;
    }

    private static Task HandleChallenge(JwtBearerChallengeContext context)
    {
        context.HandleResponse();

        if (!context.Request.Headers.ContainsKey("Authorization"))
        {
            return WriteJsonResponseAsync(context.Response, AppConstants.StatusCodes.Unauthorized, AppConstants.StatusKeys.JwtTokenMissing);
        }
        if (!context.Response.HasStarted)
        {
            return WriteJsonResponseAsync(context.Response, AppConstants.StatusCodes.Unauthorized, AppConstants.StatusKeys.JwtTokenInvalid);
        }

        return Task.CompletedTask;
    }

    private static Task HandleForbidden(ForbiddenContext context)
    {
        return WriteJsonResponseAsync(context.Response, AppConstants.StatusCodes.Forbidden, AppConstants.StatusKeys.Forbidden);
    }

    private static Task WriteJsonResponseAsync(HttpResponse response, int statusCode, string errorMessage)
    {
        response.ContentType = AppConstants.ContentTypes.ApplicationJson;
        response.StatusCode = statusCode;

        var jsonResponse = JsonSerializer.Serialize(ResultWrapper.Failure(errorMessage, statusCode));

        return response.WriteAsync(jsonResponse);
    }
}
