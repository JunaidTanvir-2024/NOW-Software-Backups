﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts
{
    public class GenericApiResponse<T>
    {
        public string Message { get; set; }

        public int Status { get; set; }   //0=Success       1=Penidng           2=Failure

        public T Result { get; set; }

        public string ATTTransactionReference { get; set; }

        public string APITransactionReference { get; set; }

        public static GenericApiResponse<T> Success(T result)
        {
            return new GenericApiResponse<T>
            {
                Status = 0,
                Message = "Success",
                Result = result
            };
        }


        public static GenericApiResponse<T> Failure(string message = "", int errorCode = -1)
        {
            string ErrorMessage = "";

            if (message != "")
                ErrorMessage = message;

            int inttmp;
            if (errorCode == -1)
                inttmp = 2;
            else
                inttmp = errorCode;

            return new GenericApiResponse<T>
            {
                Status = inttmp,
                Message = ErrorMessage
            };
        }



        public static GenericApiResponse<T> Pending(string message = "")
        {
            string ErrorMessage = "Pending";

            if (message != "")
                ErrorMessage =  message;

            return new GenericApiResponse<T>
            {
                Status = 1,
                Message = ErrorMessage
            };
        }

    }
}
