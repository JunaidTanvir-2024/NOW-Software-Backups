﻿using NTCB.Api.Features.DTOne.Models;

namespace NTCB.Api.Features.DTOne;

public interface IDTOneService
{
    Task<bool> UpdateDTOneTransactionRecord(CallbackInfo callbackInfo);
    Task<bool> VerifyDTOneTransaction(long transactionReferenceId);
}