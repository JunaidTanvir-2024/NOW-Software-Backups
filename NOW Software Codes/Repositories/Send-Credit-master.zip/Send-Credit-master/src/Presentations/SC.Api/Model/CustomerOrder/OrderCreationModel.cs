﻿using System.ComponentModel;
using System.Text.Json.Serialization;
using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Model.CustomerOrder;
public class OrderCreationModel
{
    public long CustomerOrderID { get; set; } = 0;
    [DefaultValue("")]
    public string PromoCode { get; set; } = default!;
    public DiscountTypeEnum DiscountType { get; set; } = default!;
    public decimal DiscountAmount { get; set; } = decimal.Zero;
    public decimal ServiceFee { get; set; } = decimal.Zero;
    public decimal TaxAmount { get; set; } = decimal.Zero;
    public decimal TaxInclusiveAmount { get; set; } = decimal.Zero;
    public decimal TaxExclusiveAmount { get; set; } = decimal.Zero;
    public decimal TotalOrderAmount { get; set; } = decimal.Zero;
    [DefaultValue("")]
    public string Currency { get; set; } = default!;
}

