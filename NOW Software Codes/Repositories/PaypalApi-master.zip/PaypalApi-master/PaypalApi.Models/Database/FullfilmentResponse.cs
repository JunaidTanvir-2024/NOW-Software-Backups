﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Database
{
    
    public class FullfilmentResponse
    {
        public string ErrorMessage { get; set; }
        public int ErrorCode { get; set; }
        public int? audit_id { get; set; }
        public Decimal new_balance { get; set; }
        public string Pin { get; set; }
    }
}
