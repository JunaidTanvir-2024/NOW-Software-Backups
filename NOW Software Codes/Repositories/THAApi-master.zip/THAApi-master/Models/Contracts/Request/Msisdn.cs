﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class Msisdn
    {
        public List<string> msisdns { get; set; }
    }
}
