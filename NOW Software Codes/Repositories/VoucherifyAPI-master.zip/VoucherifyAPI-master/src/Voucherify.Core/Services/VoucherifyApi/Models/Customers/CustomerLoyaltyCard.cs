﻿using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Customers;

public class CustomerLoyaltyCard
{
    [JsonPropertyName("redeemed_points")]
    public long RedeemedPoints { get; set; }
    [JsonPropertyName("points_to_go")]
    public long PointsToGo { get; set; }
}