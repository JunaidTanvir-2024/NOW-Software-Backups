﻿namespace Now.Models.Database;

public class Bundle
{
    public int Id { get; set; }
    public string? UuId { get; set; }
    public string? DisplayName { get; set; }
    public string? Name { get; set; }
    public string? CountryCode { get; set; }
    public int Category { get; set; }
    public int Type { get; set; }
    public decimal Price { get; set; }
    public decimal Discount { get; set; }
    public decimal TotalPrice { get; set; }
    public string? LocalMinutes { get; set; }
    public string? InternationalMinutes { get; set; }
    public bool? LocalMinutesOrSms { get; set; }
    public bool? InternationalMinutesOrSms { get; set; }
    public string? Data { get; set; }
    public string? DataUnit { get; set; }
    public string? LocalSms { get; set; }
    public string? InternationalSms { get; set; }
    public int ValidityDays { get; set; }
    public bool IsAddOn { get; set; }
    public string? AddOnData { get; set; }
    public string? AddOnDataUnit { get; set; }
    public string? DisplayDescription { get; set; }
    public string? GoodyBagColorCode { get; set; }
    public bool IsAvailable { get; set; }
    public string? AddonPackageDescription { get; set; }
    public bool ShowBadge { get; set; }
    public string? BadgeDescription { get; set; }
    public bool ShowRenewal { get; set; }
}