﻿namespace THCC.Application.Models.Dtos;

public class TopupDenominationsDto
{
    public decimal Amount { get; set; }
    public decimal Points { get; set; }
    public decimal Discount { get; set; }
    public int Discountpercent { get; set; }
    [JsonIgnore]
    public int ExpiryDays { get; set; }
}