﻿using Models.Contracts;
using Models.Database;

namespace Infrastructure.Utilities
{
    public static class CommonHelpers
    {
        public static bool IsUserProfileCompleted(string firstName, string lastName, string email, bool emailVerified, string imageUrl, int dobDay)
        {
            if ((string.IsNullOrEmpty(firstName)
                    && string.IsNullOrEmpty(lastName))
                    || string.IsNullOrEmpty(email)
                    || !emailVerified
                    || string.IsNullOrEmpty(imageUrl)
                    || dobDay <= 0)
            {
                return false;
            }
            return true;
        }
    }
}
