namespace Application.Features.Account.History.Sms;
public class SmsUsageHistoryRequestValidator : AbstractValidator<SmsUsageHistoryRequest>
{
    public SmsUsageHistoryRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
    }
}