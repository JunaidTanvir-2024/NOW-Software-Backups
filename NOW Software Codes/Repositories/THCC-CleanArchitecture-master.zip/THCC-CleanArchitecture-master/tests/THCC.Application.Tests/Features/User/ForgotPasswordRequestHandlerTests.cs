﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FakeItEasy;

using FluentAssertions;

using MapsterMapper;

using Microsoft.Extensions.Options;

using Serilog;

using THCC.Application.Features.User.ForgotPassword.ForgotPasswod;
using THCC.Application.Features.User.Login;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;
using THCC.Domain.Entities;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Application.Tests.Features.User
{
    public class ForgotPasswordRequestHandlerTests
    {
        private readonly IUserRepository _userRepo;
        private readonly ILegacyRepository _legacyRepo;
        private readonly IMailService _mailService;
        private readonly ILogger _logger;
        private readonly IUserService _userService;
        private readonly IOtpService _otpService;

        private readonly ForgotPasswordRequestHandler _forgotPasswordRequestHandler;
        public ForgotPasswordRequestHandlerTests()
        {
          
            _userRepo = A.Fake<IUserRepository>();
            _legacyRepo = A.Fake<ILegacyRepository>();
            _mailService = A.Fake<IMailService>();
            _logger = A.Fake<ILogger>();
            _userService= A.Fake<IUserService>();
            _otpService = A.Fake<IOtpService>();

            _forgotPasswordRequestHandler = new ForgotPasswordRequestHandler(_userRepo,_legacyRepo,_mailService,
                _logger,_userService,_otpService );
        }
        [Fact]
        public async Task ForgotPasswordRequestHandler_UserNotRegistered()
        {
            //Arrange
            var request = new ForgotPasswordRequest()
            {
                Email = "usman@yahoo.com",
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.AccountNotRegistered
                    }
                }
            };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns((Domain.Entities.User?)null!);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns((LegacyUser)null!);

            //Act
            var result = await _forgotPasswordRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task ForgotPasswordRequestHandler_LegacyUserNotConfirmed()
        {
            //Arrange
            var request = new ForgotPasswordRequest()
            {
                Email = "usman@yahoo.com",
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.AccountNotRegistered
                    }
                }
            };
            var legacyUser = new LegacyUser() { IsConfirmedUser = false };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns((Domain.Entities.User?)null!);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns(legacyUser);

            //Act
            var result = await _forgotPasswordRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task ForgotPasswordRequestHandler_LegacytoNewDbUserRegistrationFailed()
        {
            //Arrange
            var request = new ForgotPasswordRequest()
            {
                Email = "usman@yahoo.com"
                
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.InternalServerError,
                        Message =  CustomStatusKey.InternalServerError
                    }
                }
            };
            var signUpResponse = new SignUpInfoDto()
            {
                IsSuccess = false
            };
            var legacyUser = new LegacyUser() { IsConfirmedUser = true, FirstName = "first", LastName = "last" };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns((Domain.Entities.User?)null!);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns(legacyUser);
            A.CallTo(() => _userService.SignUpAsync(null!, null!, "asdads", "asd", "asdasd", true)).Returns(signUpResponse);

            //Act
            var result = await _forgotPasswordRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task ForgotPasswordRequestHandler_UserNotConfirmed()
        {
            //Arrange
            var request = new ForgotPasswordRequest()
            {
                Email = "usman@yahoo.com",
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.AccountNotRegistered
                    }
                }
            };
            var user = new Domain.Entities.User() { EmailConfirmed = false };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns(user);
        
            //Act
            var result = await _forgotPasswordRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task ForgotPasswordRequestHandler_Success()
        {
            //Arrange
            var request = new ForgotPasswordRequest()
            {
                Email = "usman@yahoo.com",
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.AccountNotRegistered
                    }
                }
            };
            var user = new Domain.Entities.User() { EmailConfirmed = true };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns(user);

            //Act
            var result = await _forgotPasswordRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }


    }
}
