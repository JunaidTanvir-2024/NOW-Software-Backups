﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models;
public class PurchaseInventoryRequest
{
    public required List<PurchaseItem> PurchaseItems { get; set; }
    public required string TransactionReference { get; set; }
    public sealed record PurchaseItem
    {
        public required string ProductVendorCode { get; set; }
        public required long ProductId { get; set; }
        public required string CartReference { get; set; }
        public required string RecipientMsisdn { get; set; }
        public required string SenderMsisdn { get; set; }
        public required ushort Quantity { get; set; }
        public required string SenderName { get; set; }
        public ProductPurchaseType ProductType { get; set; }
    }
}

