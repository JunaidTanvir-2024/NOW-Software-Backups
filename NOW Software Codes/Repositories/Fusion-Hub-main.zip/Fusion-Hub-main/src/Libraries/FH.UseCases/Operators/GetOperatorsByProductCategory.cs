using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;
using FluentValidation;
using MapsterMapper;
using Mediator;
using RW.Models;
using RW;

namespace FH.UseCases.Operators;

public sealed class GetOperatorsByProductCategory
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public OperatorsByProductCategoryFilter? OperatorFilters { get; set; }

        public sealed record OperatorsByProductCategoryFilter
        {

            public string? CategoryAliasName { get; set; }
            public string? CountryIsoCode { get; set; }
            public string? CurrencyCode { get; set; }
        }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Page).GreaterThan(0);
            RuleFor(x => x.RecordsPerPage).LessThan(101);
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public OperatorInfo Operator { get; set; } = new OperatorInfo();
        public CategoryInfo Category { get; set; } = new CategoryInfo();
        public CountryInfo Country { get; set; } = new CountryInfo();
        public sealed record OperatorInfo
        {
            public long OperatorId { get; set; }
            public string? OperatorName { get; set; }
            public string? Description { get; set; }
            public string? ShortCode { get; set; }
            public string? Logo { get; set; }
        }
        public sealed record CategoryInfo
        {
            
            public string? CategoryName { get; set; }
            public string? CategoryAliasName { get; set; }
        }

        public sealed record CountryInfo
        {
            public string? CountryName { get; set; }
            public string? CountryIsoCode2 { get; set; }
        }

    }
    #endregion

    #region Handler
    internal sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IMapper _mapper = mapper;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var getOperatorsRequest = _mapper.Map<OperatorByProductCategoryDto.Request>(request);

            // Setting Default Values
            getOperatorsRequest.IsActive = true;
            getOperatorsRequest.IsDeleted = false;

            (IEnumerable<OperatorByProductCategoryDto.Response> operators, DatabasePaginationDto pagination) = await _unitOfWork.OperatorRepository.GetOperatorByProductCategory(getOperatorsRequest);

            if (operators is null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
            }


            var operatorResponse = operators.Select(x => new GetOperatorsByProductCategory.Response()
            {
                Category = { CategoryName = x.CategoryName, CategoryAliasName = x.CategoryAliasName },
                Country = { CountryIsoCode2 = x.CountryIsoCode2, CountryName = x.CountryName },
                Operator = { OperatorId = x.OperatorId, OperatorName = x.OperatorName, Description = x.Description, ShortCode = x.ShortCode, Logo = x.Logo }
            });

            return ResultWrapper.Success(operatorResponse, new Pagination(pagination.TotalRecords, pagination.TotalPages, request.Page, request.RecordsPerPage));
        }
    }
    #endregion
}
