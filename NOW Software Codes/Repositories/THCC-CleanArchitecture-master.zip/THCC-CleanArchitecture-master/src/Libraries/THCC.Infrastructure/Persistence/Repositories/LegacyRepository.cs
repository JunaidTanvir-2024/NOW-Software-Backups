﻿using Dapper;

using Microsoft.Extensions.Configuration;

using System.Data;

using THCC.Application.Interfaces.Repositories;
using THCC.Domain.Entities;
using THCC.Infrastructure.Persistence.DapperConfigurations;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Infrastructure.Persistence.Repositories
{
    public class LegacyRepository : ILegacyRepository
    {
        private readonly IConfiguration _configuration;

        public LegacyRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<LegacyUser> GetUserByEmail(string emailAddress)
        {
            var p = new DynamicParameters();
            p.Add("@email", emailAddress);
            return await DapperWrapper.QueryFirstOrDefaultAsync<LegacyUser>(StoredProcedures.GetUserByEmail_Legacy, p, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.THCCLegacy));
        }

        public async Task<LegacyProduct> GetUserProducts(long userId)
        {
            var p = new DynamicParameters();
            p.Add("@UserId", userId);
            return await DapperWrapper.QueryFirstOrDefaultAsync<LegacyProduct>(StoredProcedures.GetUserByProducts_Legacy, p, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.THCCLegacy));
        }
    }
}
