﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class TransferByPayPalCallBackV2RequestModel
    {
        [Required]
        public string Token { get; set; }

        public string IpAddress { get; set; }

        //Transfer Related Data
        [Required]
        public string NowtelRef { get; set; }

        [Required]
        public string Product { get; set; }
        [Required]
        public string OperatorId { get; set; }
    }
}
