﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Request;
using TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Response;
using TalkHomeContactSyncApi.Models.Database;

namespace TalkHomeContactSyncApi.Infrastructure.ContactSync
{
    public interface IContactSyncDB
    {
        Task<IList<ContactSyncResponse>> GetFilteredTalkHomeContacts(DataTable dataTable);
        Task<User> Login(string userName, string password);
    }
}
