using FH.Infrastructure.Common.Middlewares;
using FH.Infrastructure.Services.MessageBroker;
using FH.Infrastructure.Services.OpenApi;
using FH.Infrastructure.Services.Versioning;
using FH.Infrastructure.Vendors.DTOne.Common;
using FH.Infrastructure.Vendors.Reloadly.Common;

using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace FH.Infrastructure;

public static class ConfigureDependencies
{
    public static IServiceCollection AddInfrastructureDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.RegisterJsonSettings(configuration);
        services.AddDistributedMemoryCache();
        services.AddRegisterMessageBrokerConfigurations(configuration);
        services.RegisterBuiltInServices();
        services.AddApiVersioningConfiguration();
        services.AddOpenApiConfiguration();
        return services;
    }

    private static IServiceCollection RegisterBuiltInServices(this IServiceCollection services)
    {
        services.AddHttpClient();
        services.AddHttpContextAccessor();
        return services;
    }

    private static IServiceCollection RegisterJsonSettings(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<OpenApiSetting>(configuration.GetSection(OpenApiSetting.SectionName));
        services.Configure<SecurityHeaderSetting>(configuration.GetSection(SecurityHeaderSetting.SectionName));
        services.Configure<DTOneSetting>(configuration.GetSection(DTOneSetting.SectionName));
        services.Configure<MessageBrokerSetting>(configuration.GetSection(MessageBrokerSetting.SectionName));
        services.Configure<ReloadlySetting>(configuration.GetSection(ReloadlySetting.SectionName));
        return services;
    }

    public static IApplicationBuilder UseInfrastructureMiddlewares(this IApplicationBuilder app)
    {
       // app.MessageBrokerDbInitializer();
        app.UseAppExceptionMiddleware();
        app.UseOpenApiConfiguration();
        app.UseSecurityHeadersMiddleware();
        app.UseAppLoggingMiddleware();
        return app;
    }

    private static void MessageBrokerDbInitializer(this IApplicationBuilder app)
    {
        using (var scope = app.ApplicationServices.CreateScope())
        {
            scope.ServiceProvider.GetService<MessageBrokerDbContext>()?.Database.Migrate();
        }
    }
}
