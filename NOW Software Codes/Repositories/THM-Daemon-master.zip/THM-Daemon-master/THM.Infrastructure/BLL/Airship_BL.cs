﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PhoneNumbers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using THM.Infrastructure.DAL;
using THM.Infrastructure.Services;
using THM.Models.AirShip;
using THM.Models.Configurations;
using THM.Models.Models;

namespace THM.Infrastructure.BLL
{
    public interface IAirship_BL
    {
        Task AddAirShipEventsAndTags();
        Task AddSimStatusAirShipEventsAndTags();
    }

    public class Airship_BL : IAirship_BL
    {
        private readonly AirShipConfig _airShipConfig;
        private readonly PhoneNumberUtil _phoneNumberUtil;

        private readonly IAirship_DL _airshipDL;
        private readonly IAirshipService _airshipService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<Airship_BL> _logger;
        private readonly Serilog.ILogger _serilogLogger;

        private CountriesData _countriesData { get; set; }

        public Airship_BL(
            IOptions<AirShipConfig> airShipConfig,
            IAirship_DL airship_DL,
            IAirshipService airshipService,
            IConfiguration configuration,
            ILogger<Airship_BL> logger,
            Serilog.ILogger serilogLogger)
        {
            _airshipDL = airship_DL;
            _airShipConfig = airShipConfig.Value;
            _airshipService = airshipService;
            _configuration = configuration;
            _logger = logger;
            _serilogLogger = serilogLogger;
            _phoneNumberUtil = PhoneNumberUtil.GetInstance();
            _countriesData = JsonConvert.DeserializeObject<CountriesData>(File.ReadAllText(
                Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Countries.json"))
                ));
        }

        public async Task AddAirShipEventsAndTags()
        {
            if (!_airShipConfig.IsActive)
                return;

            //Call Records
            var callRecords = await _airshipDL.GetCallRecords();
            if (callRecords.TotalRecords > 0)
            {
                while (callRecords.TotalRecords > 0)
                {
                    _logger.LogDebug(
                        $"Started the Airship Events with Total {callRecords.TotalRecords} Records, " +
                        $"time: {DateTimeOffset.Now}");

                    foreach (var item in callRecords.numbers)
                    {
                        var namedUser = await _airshipDL.IsNumberExistsInTHM(item.CallingNumber);

                        //check if number exists in thm-db
                        if (string.IsNullOrEmpty(namedUser))
                        {
                            //Mark As IsProcessed
                            await _airshipDL.MarkMsisdnAsProcessed(item.Id);
                        }
                        else
                        {
                            try
                            {
                                //Initialize airship tags and events
                                var activityTags = new List<string>();
                                var customEvent = new CustomEventsRequest()
                                {
                                    ProductCode = "THM",
                                    ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                    ChannelIdentifierValue = namedUser.Trim()
                                };

                                customEvent.CustomEventName = item.Roaming ? "call_roaming" : "call_standard_rates";
                                _airshipService.AddCustomEvent(customEvent);
                                activityTags.Add(item.Roaming ? "call_roaming" : "call_standard_rates");

                                customEvent.CustomEventName = "called_any";
                                _airshipService.AddCustomEvent(customEvent);
                                activityTags.Add("called_any");

                                customEvent.CustomEventName = "last_call";
                                _airshipService.AddCustomEvent(customEvent);
                                activityTags.Add("last_call");

                                item.CalledNumber = item.CalledNumber.Trim();

                                string CalledNumberCountryName = "";
                                string CalledNumberCountryCode = "";

                                try
                                {
                                    //Get Called Party Number Country Code
                                    var CalledNumber = _phoneNumberUtil.Parse(
                                        item.CalledNumber.StartsWith("+") ? item.CalledNumber : "+" + item.CalledNumber, "");

                                    CalledNumberCountryCode = _phoneNumberUtil.GetRegionCodeForNumber(CalledNumber);
                                    CalledNumberCountryName = GetCountryNameByCountryCode(CalledNumberCountryCode);
                                }
                                catch (Exception ex)
                                {
                                    _logger.LogError("PhoneLib: " + ex.Message + $"  time: {DateTimeOffset.Now}");

                                    _serilogLogger.Error("PhoneLib: " + ex.Message + $"  time: {DateTimeOffset.Now}");

                                    CalledNumberCountryName = "";
                                }

                                if (!string.IsNullOrEmpty(CalledNumberCountryName))
                                {
                                    customEvent.CustomEventName = "called_" + CalledNumberCountryName;
                                    _airshipService.AddCustomEvent(customEvent);
                                    activityTags.Add("called_" + CalledNumberCountryName);
                                }

                                if (!string.IsNullOrEmpty(CalledNumberCountryCode))
                                {
                                    if (CalledNumberCountryCode == "GB")
                                    {
                                        customEvent.CustomEventName = "called_gb";
                                        _airshipService.AddCustomEvent(customEvent);
                                        activityTags.Add("called_gb");
                                    }
                                    else
                                    {
                                        //Get European Union countries List
                                        var EUCountriesList = _configuration.GetSection("EUCountries").Get<string[]>();
                                        if (EUCountriesList.Contains(CalledNumberCountryCode))
                                        {
                                            customEvent.CustomEventName = "called_eu";
                                            _airshipService.AddCustomEvent(customEvent);
                                            activityTags.Add("called_eu");
                                        }
                                        else
                                        {
                                            customEvent.CustomEventName = "called_row";
                                            _airshipService.AddCustomEvent(customEvent);
                                            activityTags.Add("called_row");
                                        }
                                    }
                                }

                                if (activityTags.Count > 0)
                                {
                                    //Fire airship tags
                                    _airshipService.AddNamedUserTags(
                                        new NamedUserTagsRequest()
                                        {
                                            TagGroup = _airshipService.ActivityTagGroupName,
                                            NamedUser = namedUser,
                                            ProductCode = "THM",
                                            Tags = activityTags
                                        });
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex.Message + $"  time: {DateTimeOffset.Now}");

                                _serilogLogger.Error("AirShip Worker: " + ex.Message + $"  time: {DateTimeOffset.Now}");
                            }

                            _serilogLogger.Debug(
                                    $"Fired Airship Events For {item.CallingNumber}, " +
                                    $"time: {DateTimeOffset.Now}");

                            //Mark As IsProcessed
                            await _airshipDL.MarkMsisdnAsProcessed(item.Id);
                        }
                    }

                    callRecords = await _airshipDL.GetCallRecords();
                }
            }
        }
        public async Task AddSimStatusAirShipEventsAndTags()
        {
            if (!_airShipConfig.IsActive)
                return;

            //Sim Records
            var simRecords = await _airshipDL.GetSimRecords();
            if (simRecords != null && simRecords.Any())
            {
                foreach (var item in simRecords)
                {
                    var namedUser = await _airshipDL.IsNumberExistsInTHM(item.account.Trim());

                    if (!string.IsNullOrEmpty(namedUser))
                    {
                        string eventAndTagName = item.sim_current_state == Models.Enums.SimStauts.Active ? "sim_active" : "sim_inactive";

                        try
                        {
                            //Initialize airship tags and events
                            _airshipService.AddCustomEvent(new CustomEventsRequest()
                            {
                                ProductCode = "THM",
                                ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                ChannelIdentifierValue = namedUser.Trim(),
                                CustomEventName = eventAndTagName
                            });

                            //Fire airship tags
                            _airshipService.AddNamedUserTags(
                                new NamedUserTagsRequest()
                                {
                                    TagGroup = _airshipService.AccountTagGroupName,
                                    NamedUser = namedUser,
                                    ProductCode = "THM",
                                    Tags = new List<string>() { eventAndTagName }
                                });
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError("Sim Status Worker:" + ex.Message + $"  time: {DateTimeOffset.Now}");

                            _serilogLogger.Error("Sim Status Worker: " + ex.Message + $"  time: {DateTimeOffset.Now}");
                        }
                    }
                }
            }
        }
        private string GetCountryNameByCountryCode(string code)
        {
            if (!string.IsNullOrEmpty(code))
            {
                return _countriesData.countries.Where(
                    x => x.IsoTwoCharacterCode.ToLower().Equals(code.ToLower())).First().Name.ToLower().Replace(" ", "").Trim();
            }

            return code;
        }
    }
}