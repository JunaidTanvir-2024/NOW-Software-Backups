namespace RW.Common;
public interface IResultStatus
{
    /// <summary>
    /// Gets or sets a value indicating whether the service result is valid.
    /// </summary>
    public bool IsSuccess { get; set; }
}
