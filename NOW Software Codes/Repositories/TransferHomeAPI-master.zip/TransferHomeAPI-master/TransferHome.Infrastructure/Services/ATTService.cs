﻿using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Models.Configurations;
using TransferHome.Models.Contracts.Service;
using Newtonsoft.Json;
using TransferHome.Infrastructure.Services.Interfaces;

namespace TransferHome.Infrastructure.Services
{
    public class ATTService : IATTService
    {
        private readonly string ApiEndPoint;
        private ILogger Logger;

        public ATTService(IOptions<ATTConfig> config, ILogger logger)
        {
            ApiEndPoint = config.Value.ApiEndPoint;
            Logger = logger;
        }

        public async Task<GetProductResponse> GetProducts(GetProductRequest request)
        {
            string GetProductRequestUri = $"{ApiEndPoint}DTOneProducts?fromMSISDN={request.fromMSISDN}&account={request.account}&destinationMSISDN={request.destinationMSISDN}&product={request.product}";
            string response = await Get(GetProductRequestUri);
            if (!string.IsNullOrEmpty(response))
            {
                return JsonConvert.DeserializeObject<GetProductResponse>(response);
            }
            else
            {
                return null;
            }
        }

        public async Task<ExecuteDataResponse> Execute(ExecuteDataRequest request)
        {
            request.messageToRecipient = string.Empty;
            string BaseUri = $"{ApiEndPoint}DTOneExecute";
            string response = await Post(BaseUri, JsonConvert.SerializeObject(request));
            if (!string.IsNullOrEmpty(response))
            {
                return JsonConvert.DeserializeObject<ExecuteDataResponse>(response);
            }
            else
            {
                return null;
            }
        }

        private async Task<string> Get(string uri)
        {
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(uri), Timeout = TimeSpan.FromSeconds(60) })
                {
                    HttpResponseMessage response = await client.GetAsync("");
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    if (!response.IsSuccessStatusCode || response.Content == null)
                        throw new WebException();

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"ATTService - Method: Get, Parameters -->, uri--> {uri}, ErrorMessage: {ex.Message}");
                return null;
            }
        }

        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address), Timeout = TimeSpan.FromSeconds(60) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                    {
                        throw new WebException();
                    }

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"ATTService - Method: Post, Parameters --> address--> {address} , Json--> {json}, ErrorMessage: {ex.Message}");
                return null;
            }
        }
    }
}
