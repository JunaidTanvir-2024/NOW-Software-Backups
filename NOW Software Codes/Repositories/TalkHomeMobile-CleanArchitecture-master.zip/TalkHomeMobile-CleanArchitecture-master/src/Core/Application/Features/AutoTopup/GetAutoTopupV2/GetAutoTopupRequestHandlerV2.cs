﻿using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.AutoTopup.GetAutoTopupV2;

public class GetAutoTopupRequestHandlerV2 : IRequestHandler<GetAutoTopupRequestV2, Result<AutoTopupResponseV2>>
{
    private readonly IStringLocalizer<GetAutoTopupRequestHandlerV2> _localizer;
    private readonly ITopupRepository _topupRepo;
    private readonly ICurrentUser _currentUser;
    private readonly IUserService _userService;
    private readonly TopupSettings _topupSettings;

    public GetAutoTopupRequestHandlerV2(
        IStringLocalizer<GetAutoTopupRequestHandlerV2> localizer,
        ITopupRepository topupRepo,
        ICurrentUser currentUser,
        IUserService userService,
        IOptions<TopupSettings> topupSettings)
    {
        _localizer = localizer;
        _topupRepo = topupRepo;
        _currentUser = currentUser;
        _userService = userService;
        _topupSettings = topupSettings.Value;
    }

    public async Task<Result<AutoTopupResponseV2>> Handle(GetAutoTopupRequestV2 request, CancellationToken cancellationToken)
    {
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<AutoTopupResponseV2>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var autoTopup = await _topupRepo.GetAutoTopup(request.Msisdn, _currentUser.GetUserEmail()!);
        if (autoTopup == null)
        {
            return Result<AutoTopupResponseV2>.Failure(null!, _localizer[CustomStatusKey.GetAutoTopupFailure], CustomStatusCode.InternalServerError);
        }
        var response = new AutoTopupResponseV2();
        if (autoTopup == null)
        {
            response = new AutoTopupResponseV2()
            {
                AutoTopup = new AutoTopupInfoV2
                {
                    Status = false,
                    ThresHoldAmount = _topupSettings.ThresholdAmount,
                    TopupAmount = 5,
                },
                TopUpAmounts = _topupSettings.TopUpAmounts,
                AutoTopupMonthlyMaxLimit = _topupSettings.AutoTopupMonthlyMaxLimit,
            };
           
        }
        else
        {

            response = new AutoTopupResponseV2()
            {
                AutoTopup = new AutoTopupInfoV2
                {
                    Status = autoTopup.Status,
                    ThresHoldAmount = autoTopup.ThresHold,
                    PaymentMethod = autoTopup.PaymentMethod,
                    TopupAmount = autoTopup.Topup,
                    CardPanMasked = string.IsNullOrEmpty(autoTopup.MaskedPan)?"Default":autoTopup.MaskedPan
                },
                TopUpAmounts = _topupSettings.TopUpAmounts,
                AutoTopupMonthlyMaxLimit=_topupSettings.AutoTopupMonthlyMaxLimit
            };
        }
       
        return Result<AutoTopupResponseV2>.Success(response, _localizer[CustomStatusKey.Success]);
    }
}