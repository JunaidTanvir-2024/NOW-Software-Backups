using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces.Repositories;

public interface IUnitOfWork : IServicesType.IScopedService
{
    IUserRepository UserRepo { get; }
    IDeviceRepository DeviceRepo { get; }
    IBundleRepository BundleRepo { get; }
    ISimRepository SimRepo { get; }
    IPromotionRepository PromotionRepo { get; }
    IRateRepository RateRepo { get; }
    IPaymentRepository PaymentRepo { get; }
    ITopupRepository TopupRepo { get; }
}