﻿using System.Text;

using Microsoft.Extensions.Options;

using Newtonsoft.Json;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

using static THCC.Domain.Constants.ThccConstants;
using static THCC.Domain.Constants.ThccEnums;

using ILogger = Serilog.ILogger;

namespace THCC.Infrastructure.Services.Payment.Pay360;

internal class Pay360Service : ICardService
{
    #region Fields

    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger _logger;
    private readonly ICallingCardRepository _callingCardRepository;
    private readonly CommerceTypeSettings _commerceTypeSettings;
    private readonly Pay360Setting _pay360Setting;

    #endregion

    #region Ctor

    public Pay360Service(
        IHttpClientFactory httpClientFactory,
        ILogger logger,
        IOptions<Pay360Setting> pay360Setting,
        ICallingCardRepository callingCardRepository,
        IOptions<CommerceTypeSettings> commerceTypeSettings)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
        _callingCardRepository = callingCardRepository;
        _commerceTypeSettings = commerceTypeSettings.Value;
        _pay360Setting = pay360Setting.Value;
    }

    #endregion

    #region Public

    #region Cards

    public async Task<List<CustomerCardDto>> GetCustomerCards(string email)
    {
        var request = new
        {
            CustomerUniqueRef = email,
            ProductCode = nameof(ProductCode.THCC)
        };
        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
            string endpoint = _pay360Setting.ApiEndpoint + "Pay360CommonServices/GetCustomerPaymentMethodsByCustomerUniqueRef";
            var output = await httpClient.PostAsync(endpoint, content);

            string outputData = await output.Content.ReadAsStringAsync();
            if (!output.IsSuccessStatusCode)
            {
                _logger.Debug("Pay360Service: GetCustomerCards=> " + outputData);
                return new List<CustomerCardDto>();
            }
            var response = JsonConvert.DeserializeObject<GenericApiResponse<Pay360CustomerCard>>(outputData)!;
            if (response.ErrorCode != 0)
            {
                _logger.Debug("Pay360Service: GetCustomerCards=> Response: " + JsonConvert.SerializeObject(response));
                return new List<CustomerCardDto>();
            }
            if (response.Payload?.PaymentMethodResponses?.Count > 0)
            {
                return response.Payload.PaymentMethodResponses.Select(item => new CustomerCardDto()
                {
                    IsPrimary = item.IsPrimary,
                    CardScheme = item.Card!.CardScheme,
                    CardToken = item.Card!.CardToken,
                    CardType = item.Card!.CardType,
                    CardUsageType = item.Card!.CardUsageType,
                    ExpiryDate = item.Card!.ExpiryDate,
                    MaskedPan = item.Card!.MaskedPan
                }).OrderByDescending(x => x.IsPrimary).ToList();
            }
            else
            {
                _logger.Debug("Pay360Service: GetCustomerCards=> Response: " + JsonConvert.SerializeObject(response));
                return new List<CustomerCardDto>();
            }
        }
        catch (Exception ex)
        {
            _logger.Error(exception: ex, "Pay360Service: GetCustomerCards=> " + ex.Message);
            return new List<CustomerCardDto>();
        }
    }
    public async Task<bool> MakeCustomerDefaultCard(string cv2, string cardToken, string customerUniqueRef)
    {
        var customerResponse = await GetCustomer(customerUniqueRef);
        if (customerResponse.ErrorCode != 0)
        {
            return false;
        }
        var request = new
        {
            defaultCardCV2 = cv2,
            pay360CustomerID = customerResponse.Payload!.Pay360CustId,
            cardToken
        };
        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            var jsonRequest = JsonConvert.SerializeObject(request);
            var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");
            var output = await httpClient.PostAsync(_pay360Setting.ApiEndpoint + "Pay360CommonServices/SetCustomerDefaultCard", content);
            string outputData = await output.Content.ReadAsStringAsync();
            if (!output.IsSuccessStatusCode)
            {
                _logger.Debug(
                       "Pay360Service, " +
                       "Method: SetCustomerDefaultCard, " +
                       $"Status Code: {output.StatusCode}" +
                       $"Request: {jsonRequest}" +
                       $"Response: {outputData}");

                return false;
            }
            var response = JsonConvert.DeserializeObject<GenericApiResponse<Pay360PaymentMethod>>(outputData)!;
            if (response.ErrorCode != 0)
            {
                _logger.Debug(
                      "Pay360Service, " +
                      "Method: SetCustomerDefaultCard, " +
                      $"Status Code: {output.StatusCode}" +
                      $"Request: {JsonConvert.SerializeObject(request)}" +
                      $"Response: {JsonConvert.SerializeObject(response)}");

                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(exception: ex, "Pay360Service: SetCustomerDefaultCard=> " + ex.Message);
            return false;
        }

    }
    public async Task<bool> RemoveCard(string cardToken, string customerUniqueRef)
    {
        var customerResponse = await GetCustomer(customerUniqueRef);
        if (customerResponse.ErrorCode != 0)
        {
            return false;
        }
        var request = new
        {
            cardToken,
            pay360CustomerID = customerResponse.Payload!.Pay360CustId
        };

        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            var json = JsonConvert.SerializeObject(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var output = await httpClient.PostAsync(_pay360Setting.ApiEndpoint + "Pay360CommonServices/RemoveCard", content);
            string outputData = await output.Content.ReadAsStringAsync();
            if (!output.IsSuccessStatusCode)
            {
                _logger.Error(
                   "Pay360Service, " +
                   "Method: RemoveCard, " +
                   $"Status Code: {output.StatusCode}" +
                   $"Request: {json}" +
                   $"Response: {outputData}");

                return false;
            }
            var response = JsonConvert.DeserializeObject<GenericApiResponse<object>>(outputData)!;
            if (response.ErrorCode != 0)
            {
                _logger.Error(
                       "Pay360Service, " +
                       "Method: RemoveCard, " +
                       $"Status Code: {output.StatusCode}" +
                       $"Request: {JsonConvert.SerializeObject(request)}" +
                       $"Response: {JsonConvert.SerializeObject(response)}");

                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error(exception: ex, "Pay360Service: RemoveCard=> " + ex.Message);
            return false;
        }
    }

    #endregion

    #region Payment

    public async Task<CardPaymentResponseDto> CardPayment(CardPaymentRequestDto request)
    {
        Pay360PaymentType pay360PaymentType = Pay360PaymentType.New;
        if (request.PaymentDefaultCardInfo != null)
        {
            pay360PaymentType = Pay360PaymentType.Default;
        }
        else
        {
            pay360PaymentType = request.PaymentExistingCardInfo != null ? Pay360PaymentType.Token : Pay360PaymentType.New;
        }
        var paymentRequest = await CreatePay360PaymentRequest(request, pay360PaymentType);

        //log payment Request and Resonse Here

        return await Pay360Payment(paymentRequest, pay360PaymentType);
    }
    public async Task<CardPaymentResponseDto> Resume3dCardPayment(string transactionId)
    {
        var json = JsonConvert.SerializeObject(new
        {
            pay360TransactionId = transactionId
        });
        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var output = await httpClient.PostAsync(_pay360Setting.ApiEndpoint + "Pay360CashierApi/Resume3DsV2", content);
            string outputData = await output.Content.ReadAsStringAsync();
            if (output.IsSuccessStatusCode)
            {
                return HandleCardPaymentResponse(outputData);
            }
            else
            {
                _logger.Error(
                   "Class: Pay360Service, " +
                   "Method: Resume3dCardPayment, " +
                   $"Status Code: {output.StatusCode}" +
                   $"Request: {json}" +
                   $"Response: {outputData}");

                return new CardPaymentResponseDto()
                {
                    IsSuccess = false,
                    ErrorCode = -1,
                    ErrorMessage = outputData
                };
            }
        }
        catch (Exception ex)
        {
            _logger.Error(
                   "Class: Pay360Service, " +
                   "Method: Resume3dCardPayment, " +
                   $"Request: {json}" +
                   $"Exception: {ex.Message}");

            return new CardPaymentResponseDto()
            {
                IsSuccess = false,
                ErrorCode = -1,
                ErrorMessage = ex.Message
            };
        }
    }
    public async Task<bool> RefundFullPayment(string transactionId)
    {
        var request = new Pay360PaymentRefundRequest
        {
            TransactionId = transactionId
        };
        var json = JsonConvert.SerializeObject(request);
        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            string endpoint = $"{_pay360Setting.ApiEndpoint}Pay360CommonServices/RefundFullPayment";

            var content = new StringContent(json, Encoding.UTF8, "application/json");
            HttpResponseMessage result = await httpClient.PostAsync(endpoint, content);
            var responseString = await result.Content.ReadAsStringAsync();
            if (!result.IsSuccessStatusCode)
            {
                _logger.Error($"Service: Pay360Service, Method: RefundFullPayment, Request: {JsonConvert.SerializeObject(json)},  Response: {responseString}-{result.StatusCode}");
                return false;
            }

            var response = JsonConvert.DeserializeObject<GenericApiResponse<Pay360PaymentResponse>>(responseString)!;
            if (response.ErrorCode > 0)
            {
                _logger.Error($"Service: Pay360Service, Method: RefundFullPayment, Request: {JsonConvert.SerializeObject(json)},  Response: {responseString}-{result.StatusCode}");
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error($"Service: Pay360Service, Method: RefundFullPayment, Request: {JsonConvert.SerializeObject(json)},  Exception:{ex.Message} ");
            return false;
        }
    }
    public async Task<bool> RefundPartialPayment(string transactionId, double amount)
    {
        var request = new Pay360RefundPartialPaymentRequest
        {
            TransactionId = transactionId,
            Currency = nameof(Currency.GBP),
            Amount = amount
        };
        var json = JsonConvert.SerializeObject(request);
        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            string endpoint = $"{_pay360Setting.ApiEndpoint}Pay360CommonServices/RefundPartialPayment";

            var content = new StringContent(json, Encoding.UTF8, "application/json");
            HttpResponseMessage result = await httpClient.PostAsync(endpoint, content);
            var responseString = await result.Content.ReadAsStringAsync();
            if (!result.IsSuccessStatusCode)
            {
                _logger.Error($"Service: Pay360Service, Method: RefundPartialPayment, Request: {JsonConvert.SerializeObject(json)},  Response: {responseString}-{result.StatusCode}");
                return false;
            }

            var response = JsonConvert.DeserializeObject<GenericApiResponse<Pay360PaymentResponse>>(responseString)!;
            if (response.ErrorCode > 0)
            {
                _logger.Error($"Service: Pay360Service, Method: RefundPartialPayment, Request: {JsonConvert.SerializeObject(json)},  Response: {responseString}-{result.StatusCode}");
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error($"Service: Pay360Service, Method: RefundPartialPayment, Request: {JsonConvert.SerializeObject(json)},  Exception:{ex.Message} ");
            return false;
        }
    }
    public async Task<bool> CapturePayment(string transactionId)
    {
        var request = new Pay360PaymentRefundRequest
        {
            TransactionId = transactionId
        };
        var json = JsonConvert.SerializeObject(request);
        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            string endpoint = $"{_pay360Setting.ApiEndpoint}Pay360CommonServices/CaptureTransaction";
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            HttpResponseMessage result = await httpClient.PostAsync(endpoint, content);
            var responseString = await result.Content.ReadAsStringAsync();
            if (!result.IsSuccessStatusCode)
            {
                _logger.Error($"Service: Pay360Service, Method: CapturePayment, Request: {JsonConvert.SerializeObject(json)},  Response: {responseString}-{result.StatusCode}");
                return false;
            }

            var response = JsonConvert.DeserializeObject<GenericApiResponse<Pay360PaymentResponse>>(responseString)!;
            if (response.ErrorCode > 0)
            {
                _logger.Error($"Service: Pay360Service, Method: CapturePayment, Request: {JsonConvert.SerializeObject(json)},  Response: {responseString}-{result.StatusCode}");
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error($"Service: Pay360Service, Method: CapturePayment, Request: {JsonConvert.SerializeObject(json)},  Exception:{ex.Message} ");
            return false;
        }
    }
    public async Task<bool> CancelPayment(string transactionId)
    {
        var request = new Pay360PaymentRefundRequest
        {
            TransactionId = transactionId
        };
        var json = JsonConvert.SerializeObject(request);
        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            string endpoint = $"{_pay360Setting.ApiEndpoint}Pay360CommonServices/CancelPayment";
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            HttpResponseMessage result = await httpClient.PostAsync(endpoint, content);
            var responseString = await result.Content.ReadAsStringAsync();
            if (!result.IsSuccessStatusCode)
            {
                _logger.Error($"Service: Pay360Service, Method: CancelPayment, Request: {JsonConvert.SerializeObject(json)},  Response: {responseString}-{result.StatusCode}");
                return false;
            }
            var response = JsonConvert.DeserializeObject<GenericApiResponse<Pay360PaymentResponse>>(responseString)!;
            if (response.ErrorCode > 0)
            {
                _logger.Error($"Service: Pay360Service, Method: CancelPayment, Request: {JsonConvert.SerializeObject(json)},  Response: {responseString}-{result.StatusCode}");
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            _logger.Error($"Service: Pay360Service, Method: CancelPayment, Request: {JsonConvert.SerializeObject(json)},  Exception:{ex.Message} ");
            return false;
        }
    }
    public async Task<CardPaymentResponseDto> RecurringPayment(RecurringPaymentDto recurringPaymentDto)
    {
        var request = new Pay360PaymentRecurring
        {
            Pay360TransactionId = recurringPaymentDto.TransactionId,
            Amount = (float)recurringPaymentDto.Amount,
            ProductCode = nameof(ProductCode.THCC),
            CommerceType = _commerceTypeSettings.CommerceType
        };
        var json = JsonConvert.SerializeObject(request);
        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            string endpoint = $"{_pay360Setting.ApiEndpoint}Pay360CashierApi/RepeatTransaction";
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var output = await httpClient.PostAsync(endpoint, content);
            string outputData = await output.Content.ReadAsStringAsync();
            if (output.IsSuccessStatusCode)
            {
                return HandleCardPaymentResponse(outputData);
            }
            else
            {
                _logger.Error(
                   "Class: Pay360Service, " +
                   $"Method: RecurringPayment- {endpoint}, " +
                   $"Status Code: {output.StatusCode}" +
                   $"Request: {json}" +
                   $"Response: {outputData}");

                return new CardPaymentResponseDto()
                {
                    IsSuccess = false,
                    ErrorCode = -1,
                    ErrorMessage = outputData
                };
            }
        }
        catch (Exception ex)
        {
            _logger.Error($"Service: Pay360Service, Method: RecurringPayment, Request: {JsonConvert.SerializeObject(json)},  Exception:{ex.Message} ");
            return new CardPaymentResponseDto()
            {
                IsSuccess = false,
                ErrorCode = -1,
                ErrorMessage = ex.Message
            };
        }
    }

    #endregion

    #endregion

    #region Private

    private async Task<GenericApiResponse<Pay360Customer>> GetCustomer(string customerUniqueRef)
    {
        var request = new
        {
            CustomerUniqueRef = customerUniqueRef,
            ProductCode = nameof(ProductCode.THCC)
        };

        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            var json = JsonConvert.SerializeObject(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var output = await httpClient.PostAsync(_pay360Setting.ApiEndpoint + "Pay360CommonServices/GetCustomerByCustomerUniqueRef", content);
            string outputData = await output.Content.ReadAsStringAsync();
            if (!output.IsSuccessStatusCode)
            {
                _logger.Error(
                   $"Pay360Service, Method: GetCustomer, Status Code: {output.StatusCode}Request: {json}Response: {outputData}");
                return new GenericApiResponse<Pay360Customer>
                {
                    ErrorCode = -1
                };
            }
            return JsonConvert.DeserializeObject<GenericApiResponse<Pay360Customer>>(outputData)!;
        }
        catch (Exception ex)
        {
            _logger.Error(
                   $"Pay360Service, Method: GetCustomer, Exception: {ex.Message}");
            return new GenericApiResponse<Pay360Customer>
            {
                ErrorCode = -1
            };
        }

    }
    private async Task<Pay360PaymentRequest> CreatePay360PaymentRequest(CardPaymentRequestDto model, Pay360PaymentType paymentType)
    {
        #region Handle Custom Fields


        var fieldStates = new List<FieldState>
        {
            new FieldState()
            {
                Name = "ProductCode",
                Value = nameof(ProductItemCode.THCC),
                Transient = false
            }
        };

        if (model.TransactionType == ProductType.CallingCard)
        {
            fieldStates.Add(new FieldState
            {
                Name = "ProductItemCode",
                Value = nameof(ProductItemCode.THCC),
                Transient = false
            });
        }
        else if (model.TransactionType == ProductType.AutoTopupTransaction)
        {
            fieldStates.Add(new FieldState
            {
                Name = "ProductItemCode",
                Value = nameof(ProductItemCode.THRCC_AUTO_TOPUP),
                Transient = false
            });
        }
        else
        {
            fieldStates.Add(new FieldState
            {
                Name = "ProductItemCode",
                Value = nameof(ProductItemCode.THRCC),
                Transient = false
            });

            if (model.TransactionType == ProductType.Topup
                || model.TransactionType == ProductType.FastTopup
                || model.TransactionType == ProductType.AutoTopupEnable)
            {
                var firstUseDate = await _callingCardRepository.GetFirstUseDate(model.CardNumber!);
                try
                {
                    fieldStates.Add(new FieldState()
                    {
                        Name = "FirstUseDate",
                        Value = !string.IsNullOrEmpty(firstUseDate) ? Convert.ToDateTime(firstUseDate).ToString("yyyy-MM-dd")! : null!,
                        Transient = false
                    });
                }
                catch (Exception ex)
                {
                    _logger.Error(ex, "Card First User Date Error:" + JsonConvert.SerializeObject(model));
                }

            }
        }

        #endregion

        #region Create Basket

        if (!string.IsNullOrEmpty(model.CardNumber) 
            && model.TransactionType == ProductType.AutoTopupTransaction)
        {
            var cardResponse = await _callingCardRepository.GetCardInfo(model.CardNumber);
            if (cardResponse != null)
            {
                model.CardPin = cardResponse.Pin;
            }
        }

        var baskets = new List<Basket>();

        if (model.TransactionType == ProductType.CallingCard)
        {
            baskets.Add(new Basket
            {
                Amount = (float)model.Amount,
                BundleRef = "",
                ProductRef = "",
                ProductItemCode = nameof(ProductItemCode.THCC)
            });
        }
        else
        {
            baskets.Add(new Basket
            {
                Amount = (float)model.Amount,
                BundleRef = "",
                ProductRef = string.IsNullOrEmpty(model.CardPin) ? "" : model.CardPin,
                ProductItemCode = nameof(ProductItemCode.THRCC)
            });
        }

        #endregion

        #region Create Request

        Pay360PaymentRequest request = new();

        switch (paymentType)
        {
            case Pay360PaymentType.New:
                var paymentNewBaseRequest = CreatePay360PaymentRequestNew(model);
                request.Pay360PaymentRequestNew = paymentNewBaseRequest;
                request.Pay360PaymentRequestNew.Basket = baskets;
                request.Pay360PaymentRequestNew.CustomerUniqueRef = model.Email;
                request.Pay360PaymentRequestNew.CustomerEmail = model.Email;
                request.Pay360PaymentRequestNew.CustomerMsisdn = string.IsNullOrEmpty(model.CardNumber) ? "" : model.CardNumber;
                request.Pay360PaymentRequestNew.TransactionCurrency = nameof(Currency.GBP);
                request.Pay360PaymentRequestNew.IpAddress = model.IpAddress;
                request.Pay360PaymentRequestNew.ProductCode = nameof(ProductCode.THCC);
                request.Pay360PaymentRequestNew.SaveCard = model.PaymentNewCardInfo!.SaveCard;
                request.Pay360PaymentRequestNew.IsDefaultCard = model.PaymentNewCardInfo.MakeDefault;
                request.Pay360PaymentRequestNew.TransactionAmount = baskets.Sum(x => x.Amount);
                request.Pay360PaymentRequestNew.CustomFields = new CustomFields() { fieldState = fieldStates };
                request.Pay360PaymentRequestNew.Recurring = model.IsRecurring;
                request.Pay360PaymentRequestNew.OverrideValidation = model.TransactionType == ProductType.AutoTopupEnable;
                break;
            case Pay360PaymentType.Token:
                var paymentTokenBaseRequest = CreatePay360PaymentRequestToken(model);
                request.Pay360PaymentRequestToken = paymentTokenBaseRequest;
                request.Pay360PaymentRequestToken.Basket = baskets;
                request.Pay360PaymentRequestToken.CustomerUniqueRef = model.Email;
                request.Pay360PaymentRequestToken.CustomerEmail = model.Email;
                request.Pay360PaymentRequestToken.CustomerMsisdn = string.IsNullOrEmpty(model.CardNumber) ? "" : model.CardNumber;
                request.Pay360PaymentRequestToken.TransactionCurrency = nameof(Currency.GBP);
                request.Pay360PaymentRequestToken.IpAddress = model.IpAddress;
                request.Pay360PaymentRequestToken.ProductCode = nameof(ProductCode.THCC);
                request.Pay360PaymentRequestToken.TransactionAmount = baskets.Sum(x => x.Amount);
                request.Pay360PaymentRequestToken.CustomFields = new CustomFields() { fieldState = fieldStates };
                request.Pay360PaymentRequestToken.Recurring = model.IsRecurring;
                request.Pay360PaymentRequestToken.OverrideValidation = model.TransactionType == ProductType.AutoTopupEnable;
                break;
            case Pay360PaymentType.Default:
                request.Pay360PaymentRequestDefault = new Pay360PaymentBase();
                request.Pay360PaymentRequestDefault!.CardCv2 = model.PaymentDefaultCardInfo!.CardCv2;
                request.Pay360PaymentRequestDefault.Basket = baskets;
                request.Pay360PaymentRequestDefault.CustomerUniqueRef = model.Email;
                request.Pay360PaymentRequestDefault.CustomerEmail = model.Email;
                request.Pay360PaymentRequestDefault.CustomerMsisdn = string.IsNullOrEmpty(model.CardNumber) ? "" : model.CardNumber;
                request.Pay360PaymentRequestDefault.Do3DSecure = false;
                request.Pay360PaymentRequestDefault.IsAuthorizationOnly = false;
                request.Pay360PaymentRequestDefault.TransactionCurrency = nameof(Currency.GBP);
                request.Pay360PaymentRequestDefault.IpAddress = model.IpAddress;
                request.Pay360PaymentRequestDefault.ProductCode = nameof(ProductCode.THCC);
                request.Pay360PaymentRequestDefault.TransactionAmount = baskets.Sum(x => x.Amount);
                request.Pay360PaymentRequestDefault.CustomFields = new CustomFields() { fieldState = fieldStates };
                request.Pay360PaymentRequestDefault.Recurring = false;
                request.Pay360PaymentRequestDefault.OverrideValidation = false;
                break;
        }

        #endregion

        return request;
    }
    private Pay360PaymentRequestNew CreatePay360PaymentRequestNew(CardPaymentRequestDto model)
    {
        var result = new Pay360PaymentRequestNew
        {
            CustomerName = model.PaymentNewCardInfo!.NameOnCard!,
            CardCv2 = model.PaymentNewCardInfo.SecurityCode!,
            CardExpiryDate = model.PaymentNewCardInfo.ExpiryMonth + model.PaymentNewCardInfo.ExpiryYear,
            CardPan = model.PaymentNewCardInfo.CardNumber!,
            IsAuthorizationOnly = _pay360Setting.IsAuthorization,
            IsDefaultCard = model.PaymentNewCardInfo.MakeDefault,
            Do3DSecure = _pay360Setting.Do3DSecure,
            TransactionCurrency = nameof(Currency.GBP),
            BillingAddress = new Address
            {
                Line1 = model!.Address!.AddressL1!,
                Line2 = model!.Address.AddressL2!,
                Line3 = model!.Address.AddressL3!,
                Line4 = model!.Address.AddressL4!,
                Region = model!.Address.Region!,
                City = model!.Address.City!,
                Postcode = model!.Address.PostCode!,
                CountryCode = model!.Address.CountryCode!
            }
        };
        if (_pay360Setting.IsCustomerAddressSameAsBilling)
        {
            result.CustomerBillingAddress = result.BillingAddress;
        }
        return result;
    }
    private Pay360PaymentRequestToken CreatePay360PaymentRequestToken(CardPaymentRequestDto model)
    {
        return new Pay360PaymentRequestToken
        {
            CardCv2 = model.PaymentExistingCardInfo!.SecurityCode!,
            IsAuthorizationOnly = _pay360Setting.IsAuthorization,
            TransactionCurrency = nameof(Currency.GBP),
            Do3DSecure = _pay360Setting.Do3DSecure,
            CardToken = model.PaymentExistingCardInfo.CardToken!,
        };
    }
    private async Task<CardPaymentResponseDto> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType)
    {
        string json = string.Empty;
        string endpoint = string.Empty;
        var jsonRequestLog = string.Empty;
        try
        {
            switch (paymentType)
            {
                case Pay360PaymentType.New:
                    endpoint = _pay360Setting.ApiEndpoint + "Pay360CashierApi/NewCustomerPayment";
                    json = JsonConvert.SerializeObject(request.Pay360PaymentRequestNew);
                    request.Pay360PaymentRequestNew!.CardCv2 = null!;
                    jsonRequestLog = JsonConvert.SerializeObject(request.Pay360PaymentRequestNew);
                    break;
                case Pay360PaymentType.Default:
                    endpoint = _pay360Setting.ApiEndpoint + "Pay360CashierApi/ExistingCustomerPaymentDefaultCard";
                    json = JsonConvert.SerializeObject(request.Pay360PaymentRequestDefault);
                    jsonRequestLog = json;
                    break;
                case Pay360PaymentType.ExistingNew:
                    endpoint = _pay360Setting.ApiEndpoint + "Pay360CashierApi/ExistingCustomerPaymentNewCard";
                    json = JsonConvert.SerializeObject(request.Pay360PaymentRequestExistingNew);
                    jsonRequestLog = json;
                    break;
                case Pay360PaymentType.Token:
                    endpoint = _pay360Setting.ApiEndpoint + "Pay360CashierApi/PaymentToken";
                    json = JsonConvert.SerializeObject(request.Pay360PaymentRequestToken);
                    jsonRequestLog = json;
                    break;
            }

            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var httpClient = _httpClientFactory.CreateClient();
            var output = await httpClient.PostAsync(endpoint, content);
            string outputData = await output.Content.ReadAsStringAsync();

            if (output.IsSuccessStatusCode)
            {
                return HandleCardPaymentResponse(outputData);
            }
            else
            {
                _logger.Error(
                   "Class: Pay360Service, " +
                   $"Method: Pay360Payment- {endpoint}, " +
                   $"Status Code: {output.StatusCode}" +
                   $"Request: {jsonRequestLog}" +
                   $"Response: {outputData}");

                return new CardPaymentResponseDto()
                {
                    IsSuccess = false,
                    ErrorCode = -1,
                    ErrorMessage = outputData
                };
            }
        }
        catch (Exception ex)
        {
            _logger.Error(
                   "Class: Pay360Service, " +
                   $"Method: Pay360Payment- {endpoint}, " +
                   $"Request: {jsonRequestLog}" +
                   $"Exception: {ex.Message}");

            return new CardPaymentResponseDto()
            {
                IsSuccess = false,
                ErrorCode = -1,
                ErrorMessage = ex.Message
            };
        }
    }
    private CardPaymentResponseDto HandleCardPaymentResponse(string paymentResponse)
    {
        var cardPaymentResponse = new CardPaymentResponseDto();
        var response = JsonConvert.DeserializeObject<GenericApiResponse<Pay360PaymentResponse>>(paymentResponse)!;
        if (response.ErrorCode > 0)
        {
            _logger.Debug(
               "Class: Pay360Service, " +
               "Method: Pay360Payment- HandleCardPaymentResponse, " +
               $"Response: {JsonConvert.SerializeObject(response)}");

            cardPaymentResponse.IsSuccess = false;

            if (response.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
            {
                cardPaymentResponse.ErrorCode = CustomStatusCode.BadRequest;
                cardPaymentResponse.ErrorMessage = CustomStatusKey.DailyPaymentLimitExceeded;
            }
            else if (response.ErrorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
            {
                cardPaymentResponse.ErrorCode = CustomStatusCode.BadRequest;
                cardPaymentResponse.ErrorMessage = response.Message;
            }
            else
            {
                cardPaymentResponse.ErrorCode = CustomStatusCode.BadRequest;
                cardPaymentResponse.ErrorMessage = CustomStatusKey.OrderNotCompleted;
            }

            return cardPaymentResponse;
        }

        cardPaymentResponse.IsSuccess = true;
        cardPaymentResponse.TransactionId = response.Payload!.TransactionId;
        cardPaymentResponse.IsRecurring = response.Payload.Recurring;
        if (response.Payload.Outcome!.ReasonCode.Equals("U100", StringComparison.InvariantCultureIgnoreCase))
        {
            cardPaymentResponse.Require3dSecure = true;
            cardPaymentResponse.ThreeDSecureData = new ThreeDSecureDataDto()
            {
                Pareq = response.Payload.ClientRedirect!.Pareq,
                RedirectUrl = response.Payload.ClientRedirect.Url,
                TransactionId = response.Payload.TransactionId,
                ThreeDSServerTransId = response.Payload.ClientRedirect.ThreeDSServerTransId,
                Type = response.Payload.ClientRedirect.Type
            };
        }

        return cardPaymentResponse;
    }

    #endregion
}