﻿using Models.Common;
using System;
using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Vouchers.Responses
{
    public class VoucherRedemptionResponse
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }
        [JsonPropertyName("redemptionStatus")]
        public bool RedemptionStatus { get; set; }
        [JsonPropertyName("redemptionDate")]
        public DateTime RedemptionDate { get; set; }
        [JsonPropertyName("customerMetadata")]
        public Metadata CustomerMetadata { get; set; }
        [JsonPropertyName("sourceId")]
        public string SourceId { get; set; }
        [JsonPropertyName("customerId")]
        public string CustomerId { get; set; }
        //public Voucher Voucher { get; set; }
    }
}
