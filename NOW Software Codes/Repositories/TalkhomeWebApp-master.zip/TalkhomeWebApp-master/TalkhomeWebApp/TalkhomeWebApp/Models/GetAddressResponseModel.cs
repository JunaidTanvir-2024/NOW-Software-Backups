﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models
{
    public class GetAddressResponseModel
    {
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public IList<string> Addresses { get; set; }
        public string Message { get; set; }
    }
}
