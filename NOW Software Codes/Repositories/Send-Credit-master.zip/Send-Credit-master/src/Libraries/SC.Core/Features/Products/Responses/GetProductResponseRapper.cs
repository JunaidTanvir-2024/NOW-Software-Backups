﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SC.Core.Features.Products.GetProductsResponse;

namespace SC.Core.Features.Products.Responses;

public sealed class GetProductResponseRapper
{
    public ParticularCategoryProducts Category { get; set; } = new ParticularCategoryProducts();
    public sealed record ParticularCategoryProducts
    {
        public string Name { get; set; } = default!;
        public List<ProductInfo> Products { get; set; } = new List<ProductInfo>();
    }

}

