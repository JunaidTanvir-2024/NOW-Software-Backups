﻿namespace Application.Common.Models.Airship;

public class GenericEventData
{
    public string Email { get; set; } = string.Empty;
    public string InteractionType { get; set; } = string.Empty;
    public string TagGroupName { get; set; } = string.Empty;
    public string EventName { get; set; } = string.Empty;
    public decimal Value { get; set; }
}