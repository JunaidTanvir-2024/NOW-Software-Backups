﻿using Application.Common.Caching;

namespace Application.Features.Account.ChangePassword;
public class ChangePasswordRequestHandler : IRequestHandler<ChangePasswordRequest, Result<object>>
{
    #region Fields

    private readonly IStringLocalizer<ChangePasswordRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;
    private readonly ICurrentUser _currentUser;

    #endregion

    #region Ctor

    public ChangePasswordRequestHandler(

        IStringLocalizer<ChangePasswordRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService,
        ICurrentUser currentUser
       )
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _cacheService = cacheService;
        _cacheKeyService = cacheKeyService;
        _currentUser = currentUser;
    }

    #endregion

    #region Methods
    public async Task<Result<object>> Handle(ChangePasswordRequest request, CancellationToken cancellationToken)
    {
        //Get user info 
        var user = await _unitOfWork.UserRepo.GetUserByIdAsync(_currentUser.GetUserId());

        //Validate password
        bool isAuthenticated = SecurityHelper.CheckPassword(request.OldPassword, user!);
        if (!isAuthenticated)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidCredentials], CustomStatusCode.InvalidCredentials);
        }

        //Change password
        var userCred = GetUserCredentials(request.NewPassword);
        await _unitOfWork.UserRepo.ChangePassword(new User()
        {
            Id = _currentUser.GetUserId(),
            Password = userCred.Password,
            PasswordPrefix = userCred.PasswordPrefix,
            PasswordSuffix = userCred.PasswordSuffix,
            Key = userCred.Key,
            IV = userCred.IV
        });

        //Clear cahe beacuse user password updated
        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, _currentUser.GetUserEmail()!), cancellationToken);
        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, _currentUser.GetUserId().ToString()), cancellationToken);
        var userProducts = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        if (userProducts?.Any() == true)
        {
            foreach (var item in userProducts)
            {
                await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, item.Msisdn!), cancellationToken);
            }
        }

        return Result<object>.Success(null!, _localizer[CustomStatusKey.NewPassword]);
    }

    #endregion

    #region Utilities
    private static UserCredentials GetUserCredentials(string Password)
    {
        var saltDict = SecurityHelper.CreatePasswordAppendages();
        var encryptedSaltDict = SecurityHelper.EncryptPasswordAppendages(saltDict);
        return SecurityHelper.CreateUserCredentials(saltDict, encryptedSaltDict, Password);
    }
    #endregion
}
