namespace DC.Core.Common.Entities;

public sealed record AppLogEntity
{
    public DateTimeOffset Timestamp { get; init; }
    public string? RequestPath { get; init; }
    public string? RequestMethod { get; init; }
    public string? RequestBody { get; init; }
    public string? ResponseBody { get; init; }
    public int StatusCode { get; init; }
    public long Duration { get; init; }
    public string? ClientIP { get; init; }
    public string? UserAgent { get; init; }
    public long ResponseSize { get; init; }
    public string? ErrorReason { get; init; }
    public string? Headers { get; init; }
    public string? QueryString { get; init; }
    public required string CorrelationId { get; init; }
    public required string UniqueReference { get; init; }
    public required string ProductCode { get; init; }
    public required string ProductItemCode { get; init; }
}
