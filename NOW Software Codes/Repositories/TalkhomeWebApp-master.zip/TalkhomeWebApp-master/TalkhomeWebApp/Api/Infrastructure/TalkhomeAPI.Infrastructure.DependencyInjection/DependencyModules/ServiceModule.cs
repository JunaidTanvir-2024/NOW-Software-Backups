﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Infrastructure.Common.Services.Implementations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Services.Interfaces;
using TalkhomeAPI.Services.Services;

namespace TalkhomeAPI.Infrastructure.DependencyInjection.DependencyModules
{
    public static class ServiceModule
    {
        public static void Configure(this IServiceCollection services)
        {
            services.AddTransient<IBundleService, BundleService>();
            services.AddTransient<IRatesService, RatesService>();
            services.AddTransient<IAccountService, AccountService>();
            services.AddTransient<ITransferService, TransferService>();
            services.AddTransient<IEmailService, EmailService>();
            services.AddTransient<ISmsService, SmsService>();
            services.AddTransient<ICommonService, CommonService>();
        }
    }
}
