﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class GetAutoTopUpResponse
    {
        public float ThresHold { get; set; }
        public float Topup { get; set; }
        public bool Status { get; set; }
        public int PaymentMethod { get; set; }
        public string CardInitialTransactionId { get; set; }
        public string CardMaskedPAN { get; set; }
        public string PaypalSubscriptionId { get; set; }
        public float MaxSpendLimit { get; set; }
        public bool LastAutoTopupFailed { get; set; }
    }
}
