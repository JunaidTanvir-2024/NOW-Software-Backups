﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.PaypalApiContracts
{
	public class PayPalByPay360ESPaymentRequest
	{
		public string PaypalCheckoutToken { get; set; }
	}
}
