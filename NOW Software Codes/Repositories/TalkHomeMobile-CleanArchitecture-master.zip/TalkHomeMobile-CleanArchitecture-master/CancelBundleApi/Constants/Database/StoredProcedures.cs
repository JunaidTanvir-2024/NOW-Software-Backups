﻿namespace CancelBundleApi.Constants.Database;
public static class StoredProcedures
{

    public const string GetMsisdnDetails = "th_get_mobile_account_v2";

}