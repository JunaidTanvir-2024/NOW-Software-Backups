﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface ICustomerRating_BL
    {
        public Task<IEnumerable<RatingEvents>> GetRatingEvents();
        public Task<GenericApiResponse<object>> AddCustomerRating(AddCustomerRatingRequest request, string msisdn, string email = null);
        public Task<GenericApiResponse<IEnumerable<CustomerRatings>>> GetCustomerRatings(string msisdn, string productCode, string email = null);

    }
}
