﻿using Models.Contracts.Request;
using Models.Contracts.Request.Voucherify;
using Models.Contracts.Response;
using Models.Database;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
	public interface IPaymentFullfillment_DL
	{
		Task<FullfilmentResponse> ThaPay360cardCustomerFullfilmentAsync(string msisdn, decimal amount, string ccsTransId, string ccAuthCode, string bundleRef);
		Task<FullfilmentResponse> ThaPay360paypalStraightCustomerFullfilmentAsync(string transactionId, string bundleRef, decimal amount, string productRef);
		Task<IEnumerable<TransactionbaketitemsResponseModel>> GetBasketItemAsync(string id);
		Task<int> UpdatePaymentTransactionsItemsAsync(bool isfullfilled, int id, string msg, bool isemailsent, string bundleName);
		Task<int> UpdatePaymentTransactionAsync(int id, bool isPaymentSuccess, string transactionId = null, string paymentErrorMsg = null, bool isTestPayment = false);
		Task<int> InsertTransactionPaymentAsync(List<basket> basket, string transactionCurrency, string customerEmail, string productCode, string transactionId, string productRef, TransactionsPaymentType type, int promotionid, bool isTrialBundle, string discountCode, DiscountCodeType? discountCodeType);
		Task<int> InsertPaypalTransactionPaymentAsync(List<PayPalByPay360Basket> basket, string transactionCurrency, string customerEmail, string productCode, string transactionId, string productRef, TransactionsPaymentType type, int promotionid, string discountCode, DiscountCodeType? discountCodeType);
		Task<PaymentCustomer> GetCustomerByMerchantRef(string merchantRef);
		Task<bool> VoucherifyFulfillment(string accountId, string redemptionId, string creditReason, string paymentMethod, decimal balanceAmount = 300);
	}
}
