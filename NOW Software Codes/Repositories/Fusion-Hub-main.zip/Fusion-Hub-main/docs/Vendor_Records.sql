INSERT INTO [dbo].[vendor]
  ([name]
  ,[description]
  )
VALUES
  ('DTOne',
    'Digital Value Service'),
  ('Reloadly',
    'Reloadly Value Service')
GO