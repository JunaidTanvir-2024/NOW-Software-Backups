﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Pay360ApiContracts;

namespace TalkhomeAPI.Data.Interfaces
{
    public interface IAccountRepository
    {
        Task<bool> IsUserExist(string SipUserName);
        Task<bool> IsNewUser(string account);
        Task<bool> IsAccountDeleted(string account);

		Task<DBAccountInfo> GetAccountDetails(string Username, string pin);
        Task<bool> VerifyPin(string UserName, string Pin);
        Task<int> UpdateUser(DBUser user);
        Task<DBResultValidateMsisdn> ValidateMsisdn(string msisdn);
        Task<DBUser> GetUserByPhoneNumber(string phoneNumber);
        Task<string> GetPinByPhoneNumber(string sipUsername);
        Task InsertEmailVerificationToken(string phoneNumber, string token);
        Task<IEnumerable<DBCallHistory>> GetCallingHistory(string accountNumber);
        Task<IEnumerable<DBTopUpPaymentHistory>> GetTopUpPaymentHistory(string accountNumber);
        Task<IEnumerable<DBITopUpHistory>> GetInternationalTopUpHistory(string clientNumber);
        Task<int> VerifyEmail(string token);
        Task<DBAccountInfo> GetAccountDetailsBySipUsername(string sipUsername);
        Task<bool> IsEmailAlreadyExists(string email);
        Task<int> UpdateAccountDetails(DBUser dBUser);
        Task<string> ValidateUser(string msisdn);
        Task<IEnumerable<DBBundles>> GetBundlesHistory(string accountNumber);
        Task<DBResultValidateMsisdn> VoucherRecharge(string pin, string account);
        Task<DateTime> GetUserRegistrationDate(string accountNumber);
        Task<bool> ValidateSmsRequest(string PhoneNumber, string IpAddress, int smsLimit, SmsTypeId smsTypeId);
        Task<bool> IsValidIpAddress(string ipAddress, string path, int requestsLimit, int requestsLimitMinutes, string requestJson);
        Task<string> GetEmailVerificationToken(string msisdn);
        Task<bool> IsFirstTopUp(string msisdn);
        Task<int> IsBundleExists(string msisdn);
        Task<DBUser> GetUserInfoByEmailToken(string token);
        Task<int> GetSMSCount(string msisdn, string remoteIp);
        Task<List<PaymentHistory>> GetEntirePaymentHistory(string msisdn, string account);
        Task<GenericApiResponse<List<PromotionCountry>>> GetPromotionAlerts(string msisdn);
        Task<GenericApiResponse<bool>> SetPromotions(string msisdn, Promotion promotion);        
        Task<DeleteAccountLogRequest> GetDeleteAccountLogRequest(string msisdn);
        Task<List<DeleteAccountReasonResponseModel>> GetDeleteAccountReasons();
        Task<int> CreateDeleteAccountRequest(DeleteAccountLogRequest deleteAccountRequest);

    }
}
