using JM.Core;
using JM.Infrastructure;

namespace JM.Api;

public static class ConfigureDependencies
{
    public static IServiceCollection AddApiDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddControllers();
        services.AddAuthentication();
        services.AddAuthorization();
        services.AddCoreDependencies(configuration);
        services.AddInfrastructureDependencies(configuration);
        return services;
    }
}
