﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBUserDetails
    {
        public User userData { get; set; }
        public IEnumerable<DBUserAddress> userAddressList { get; set; }
    }
}
