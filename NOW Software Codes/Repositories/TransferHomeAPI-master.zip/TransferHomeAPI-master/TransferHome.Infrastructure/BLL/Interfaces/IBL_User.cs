﻿using TrasnferHome.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Models.Contracts.Response;
using TransferHome.Models.Contracts.Request;
using TrasnferHome.Models.Utility;
using TrasnferHome.Models.DAOs;

namespace TrasnferHome.Infrastructure.BLL.Interfaces
{
    public interface IBL_User
    {
        Task<GenericApiResponse<LoginResponseModel>> LoginSignUpByEmail(LoginSignUpEmailRequestModel model);
        Task<GenericApiResponse<bool>> IsEmailAlreadyExist(IsEmailAlreadyExistRequestModel model);
        Task<GenericApiResponse<object>> LoginSignUpByPhoneNumber(LoginSignUpPhoneNumberRequestModel model);
        Task<GenericApiResponse<bool>> VerifyEmailbyToken(VerifyEmailRequestModel model, UserTokenTypes tokenType);
        Task<GenericApiResponse<LoginResponseModel>> VerifyPinNumber(VerifyPinNumberRequestModel model);
        Task<GenericApiResponse<bool>> ReSendEmailVerificationToken(ReSendTokenRequestModel model);
        Task<GenericApiResponse<bool>> ResendPinNumber(ResendPinNumberRequestModel model);
        Task<GenericApiResponse<bool>> IsPhoneNumberAlreadyExist(IsPhoneNumberAlreadyExistRequestModel model);
        Task<GenericApiResponse<LoginResponseModel>> RegisterSocialMediaUser(ExternalLoginRequestModel model);
        Task<GenericApiResponse<bool>> ForgotPassword(ForgotPasswordRequestModel model);
        Task<GenericApiResponse<bool>> ReSendForgotPasswordToken(ReSendTokenRequestModel model);
        Task<GenericApiResponse<bool>> UpdatePassword(UpdateUserPasswordRequestModel model);
        Task<DBUser> GetUserById(int Id);
        Task<GenericApiResponse<GetCreditHistoryResponseModel>> GetCreditHistory(GetCreditHistoryRequestModel model);
        Task<GenericApiResponse<GetTransferCreditHistoryResponseModel>> GetTransferCreditHistory(GetTransferCreditHistoryRequestModel model);
        Task<GenericApiResponse<GetUserInfoResponseModel>> GetUserinfo(GetUserInfoRequestModel model);
        Task<GenericApiResponse<bool>> EditProfile(EditProfileRequestModel model, string userId);
        Task<GenericApiResponse<GetUserBalanceResponseModel>> GetUserBalance(GetUserBalanceRequestModel model);
        Task<GenericApiResponse<GetFavouriteTransactionNumbersResponseModel>> GetFavouriteTransactionNumbers(GetFavouriteTransactionNumbersRequestModel model);
        Task<GenericApiResponse<object>> SaveFavouriteTransactionNumber(SaveFavouriteTransactionNumberRequestModel model, int userId);
        Task<GenericApiResponse<object>> RemoveFavouriteTransactionNumber(SaveFavouriteTransactionNumberRequestModel model, int userId);
        Task<GenericApiResponse<object>> SaveUpdateFCMToken(SaveUpdateFCMTokenRequestModel model);
        Task<GenericApiResponse<object>> RemoveCreditHistory(RemoveCreditHistoryRequestModel model, int userId);
        Task<GenericApiResponse<object>> RemoveTransferCreditHistory(RemoveTransferCreditHistoryRequestModel model, int userId);
        Task<GenericApiResponse<object>> UpdateUserNotificationsSetting(UpdateUserNotificationsSettingRequestModel model, int userId);
        Task<GenericApiResponse<object>> UpdateMailSubscription(UpdateMailSubscriptionRequestModel model, int userId);
        Task<GenericApiResponse<bool>> Logout(string UDID);
        Task<bool> IsValidTopUpRequest(int id, string balanceCurrency, decimal amount);
    }
}
