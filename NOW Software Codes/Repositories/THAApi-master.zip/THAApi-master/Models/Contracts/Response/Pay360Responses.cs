﻿using Models.Configurations;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Response
{
    public class CardPaymentResponseModel
    {
        public ThreeDSecureData threeDSecureData { get; set; }
        public BundlePurchaseInfo bundlePurchaseInfo { get; set; }
        public TopupInfo topupInfo { get; set; }
        public string CampaignName { get; set; }
        public bool IsRedeemedSuccess { get; set; }
        public string customerMsisdn { get; set; }
        public string transactionId { get; set; }
    }
    public class ThreeDSecureData
    {
        public string redirectUrl { get; set; }
        public string returnUrl { get; set; }
        public string pareq { get; set; }
        public string transactionId { get; set; }
        public string type { get; set; }
        public string threeDSServerTransId { get; set; }
    }
    public class BundlePurchaseInfo
    {
        public string TransactionId { get; set; }
        public string BundleName { get; set; }
        public string BundleAmount { get; set; }
        public string Msisdn { get; set; }
        public string Currency { get; set; }
        public string Destination { get; set; }
        public int RewardPoints { get; set; }
        public BundleType Type { get; set; }
    }
    public class TopupInfo
    {
        public string TransactionId { get; set; }
        public string TopupAmount { get; set; }
        public string Msisdn { get; set; }
        public string Currency { get; set; }
        public string NewBalance { get; set; }
        public bool IsFirstTopup { get; set; }
        public int RewardPoints { get; set; }
    }
    public class InternationalTopupInfo
    {
        public string TransactionId { get; set; }
        public string TopupAmount { get; set; }
        public string Msisdn { get; set; }
        public string Currency { get; set; }
        public string NewBalance { get; set; }
        public string CampaignName { get; set; }
        public bool IsRedeemedSuccess { get; set; }
        public bool IsFirstInternationalTopup { get; set; }
        public decimal FromAmount { get; set; }
    }
    public class Pay360PaymentAmountResponse
    {
        public string currency { get; set; }
        public string[] topupAmount { get; set; }
        public string[] autoTopupThresholdAmount { get; set; }
        public string[] autoTopupAmounts { get; set; }
        public Pay360GetAutoTopUpResponse autoTopupSettings { get; set; }
    }
    public partial class Pay360PaymentAmountResponseV2
    {
        public string currency { get; set; }
        public List<TopupAmount> topupAmounts { get; set; }
        public string[] autoTopupThresholdAmount { get; set; }
        public string[] autoTopupAmounts { get; set; }
        public Pay360GetAutoTopUpResponse autoTopupSettings { get; set; }
        public PopupInfo AccountTopupPopup { get; set; }
    }
    public class Pay360GetAutoTopUpResponse
    {
        public string Msisdn { get; set; }
        public float Threshold { get; set; }
        public float Topup { get; set; }
        public string Currency { get; set; }
        [JsonProperty("Status")]
        public bool AutoTopUpStatus { get; set; }

    }
    public class SetDefaultCardResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public DefaultCardPayload payload { get; set; }
    }

    public class DefaultCardPayload
    {
        public PaymentMethodsPayloadModel PaymentMethodResponse { get; set; }
    }
    public class RemoveCardResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public string payload { get; set; }
    }

    public class GetCustomerResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public UserCustomerResponseModels payload { get; set; }
    }

    public class UserCustomerResponseModels
    {
        [JsonProperty("displayName")]
        public string DisplayName { get; set; }

        [JsonProperty("merchantRef")]
        public string MerchantRef { get; set; }

        [JsonProperty("pay360CustId")]
        public long Pay360CustId { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("defaultCurrency")]
        public string DefaultCurrency { get; set; }

        [JsonProperty("dob")]
        public DateTime? Dob { get; set; }

        [JsonProperty("addressLine1")]
        public string AddressLine1 { get; set; }

        [JsonProperty("addressLine2")]
        public string AddressLine2 { get; set; }

        [JsonProperty("addressLine3")]
        public string AddressLine3 { get; set; }

        [JsonProperty("addressLine4")]
        public string AddressLine4 { get; set; }

        [JsonProperty("city")]
        public string City { get; set; }

        [JsonProperty("region")]
        public string Region { get; set; }

        [JsonProperty("postCode")]
        public string PostCode { get; set; }

        [JsonProperty("country")]
        public string Country { get; set; }

        [JsonProperty("countryCode")]
        public string CountryCode { get; set; }

        [JsonProperty("telephone")]
        public string Telephone { get; set; }
    }
    public class PaymentMethodsResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public PaymentMethodsPayload payload { get; set; }
    }
    public class RemoveAllPaymentMethodsResponse
    {
        public List<string> SuccesfullyRemovedCards { get; set; }
        public List<string> FailedToRemoveCards { get; set; }
    }
    public class PaymentMethodsPayload
    {
        public PaymentMethodsPayload()
        {
            this.paymentMethodResponses = new List<PaymentMethodsPayloadModel>();
        }
        public List<PaymentMethodsPayloadModel> paymentMethodResponses { get; set; }
    }

    public class PaymentMethodsPayloadModel
    {
        [JsonProperty("registered")]
        public bool Registered { get; set; }

        [JsonProperty("isPrimary")]
        public bool isPrimary { get; set; }

        [JsonProperty("card")]
        public CardModel Card { get; set; }

        [JsonProperty("paymentClass")]
        public string PaymentClass { get; set; }
    }

    public class CardModel
    {
        [JsonProperty("cardFingerprint")]
        public string CardFingerPrint { get; set; }

        [JsonProperty("cardToken")]
        public string CardToken { get; set; }

        [JsonProperty("cardType")]
        public string CardType { get; set; }

        [JsonProperty("cardLogo")]
        public string CardLogo { get; set; }

        [JsonProperty("new")]
        public bool New { get; set; }

        [JsonProperty("cardUsageType")]
        public string CardUsageType { get; set; }

        [JsonProperty("cardScheme")]
        public string CardScheme { get; set; }

        [JsonProperty("maskedPan")]
        public string MaskedPan { get; set; }

        [JsonProperty("expiryDate")]
        public string ExpiryDate { get; set; }

        [JsonProperty("issuer")]
        public string Issuer { get; set; }

        [JsonProperty("issuerCountry")]
        public string IssuerCountry { get; set; }

        [JsonProperty("cardHolderName")]
        public string CardHolderName { get; set; }
    }
    public class StartPay360Model
    {
        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        [Display(Name = "City")]
        public string City { get; set; }

        public string CountyOrProvince { get; set; }

        public string CountryCode { get; set; }

        public string PostalCode { get; set; }

        [DataType(DataType.EmailAddress)]
        public string EmailAddress { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string PaymentMethod { get; set; }

        public string CardId { get; set; }

        public string Unreg { get; set; }

        public string Msisdn { get; set; }

        public string Currency { get; set; }

        public int Amount { get; set; }

        public string CustId { get; set; }

        public string NoCards { get; set; }

        public string NameOnCard { get; set; }
        public string CardNumber { get; set; }
        public string CardExpiryMonth { get; set; }
        public string CardExpiryYear { get; set; }
        public string SecurityCode { get; set; }
        public string CardCv2 { get; set; }
        public string Default { get; set; }
    }
    public class RefundFullPaymentResponseModel
    {
        public Processing processing { get; set; }
        public object paymentMethod { get; set; }
        public object customer { get; set; }
        public Outcome outcome { get; set; }
        public Transaction transaction { get; set; }
        public object financialServices { get; set; }
        public object history { get; set; }
        public object clientRedirect { get; set; }
        public object fraudGuard { get; set; }
        public object threeDSecure { get; set; }
        public object basketResponse { get; set; }
    }
    public class Processing
    {
        public AuthResponse authResponse { get; set; }
        public string route { get; set; }
    }

    public class Outcome
    {
        public string status { get; set; }
        public string reasonCode { get; set; }
        public string reasonMessage { get; set; }
    }
    public class Transaction
    {
        public string transactionId { get; set; }
        public string status { get; set; }
        public string type { get; set; }
        public string amount { get; set; }
        public string currency { get; set; }
        public DateTime transactionTime { get; set; }
        public DateTime receivedTime { get; set; }
        public object channel { get; set; }
        public object merchantRef { get; set; }
        public object commerceType { get; set; }
        public RelatedTransaction relatedTransaction { get; set; }
    }
    public class RelatedTransaction
    {
        public string transactionId { get; set; }
        public string merchantRef { get; set; }
    }
    public class AuthResponse
    {
        public object statusCode { get; set; }
        public string acquirerName { get; set; }
        public object message { get; set; }
        public string gatewayReference { get; set; }
        public string gatewayMessage { get; set; }
        public object avsAddressCheck { get; set; }
        public object cv2Check { get; set; }
        public string status { get; set; }
        public object authCode { get; set; }
        public string gatewaySettlement { get; set; }
        public object gatewayCode { get; set; }
        public object avsPostcodeCheck { get; set; }
    }
    public class CaptureTransactionResponseModel
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public Payload payload { get; set; }
        public class AuthResponse
        {
            public object statusCode { get; set; }
            public string acquirerName { get; set; }
            public object message { get; set; }
            public string gatewayReference { get; set; }
            public string gatewayMessage { get; set; }
            public object avsAddressCheck { get; set; }
            public object cv2Check { get; set; }
            public string status { get; set; }
            public object authCode { get; set; }
            public object gatewaySettlement { get; set; }
            public object gatewayCode { get; set; }
            public object avsPostcodeCheck { get; set; }
        }

        public class Processing
        {
            public AuthResponse authResponse { get; set; }
            public string route { get; set; }
        }

        public class Outcome
        {
            public string status { get; set; }
            public string reasonCode { get; set; }
            public string reasonMessage { get; set; }
        }

        public class RelatedTransaction
        {
            public string transactionId { get; set; }
            public string merchantRef { get; set; }
        }

        public class Transaction
        {
            public string transactionId { get; set; }
            public string status { get; set; }
            public string type { get; set; }
            public int amount { get; set; }
            public string currency { get; set; }
            public DateTime transactionTime { get; set; }
            public DateTime receivedTime { get; set; }
            public object channel { get; set; }
            public object merchantRef { get; set; }
            public object commerceType { get; set; }
            public RelatedTransaction relatedTransaction { get; set; }
        }

        public class FinancialServices
        {
            public string dateOfBirth { get; set; }
            public string surname { get; set; }
            public string accountNumber { get; set; }
            public string postCode { get; set; }
        }

        public class Payload
        {
            public Processing processing { get; set; }
            public object paymentMethod { get; set; }
            public object customer { get; set; }
            public Outcome outcome { get; set; }
            public Transaction transaction { get; set; }
            public FinancialServices financialServices { get; set; }
            public object history { get; set; }
        }

        public class Root
        {
            public string message { get; set; }
            public string status { get; set; }
            public int errorCode { get; set; }
            public Payload payload { get; set; }
        }

    }

}
