﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBUser
    {
        public string msisdn { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string email { get; set; }
        public bool email_subscribed { get; set; }
        public bool email_verified { get; set; }
        public int? dayOfBirth { get; set; }
        public int? monthOfBirth { get; set; }
        public DateTime registration_date { get; set; }
    }
}
