﻿using PaymentsApi.Infrastructure.DAL.Database;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Pay360ApiContracts;
using TalkhomeAPI.Models.PaypalApiContracts;

namespace TalkhomeAPI.Data.Interfaces
{
    public interface IPaymentFullfillmentRepository
    {
        Task<FullfilmentResponse> ThaPay360cardCustomerFullfilment(string msisdn, decimal amount, string ccsTransId, string ccAuthCode, string bundleRef);
        Task<FullfilmentResponse> ThaPay360paypalStraightCustomerFullfilment(string transactionId, string bundleRef, decimal amount, string productRef);
        Task<FullfilmentResponse> ThaDirectPaypalStraightCustomerFullfilment(string transactionId, string bundleRef, decimal amount, string productRef);

        Task<IEnumerable<TransactionbaketitemsResponseModel>> Getbasketitem(string id);
        Task<int> UpdatePaymenttransactionsItemsAsync(bool isfullfilled, int id, string msg=null, bool isemailsent=false);

        Task<int> InsertTransactionPayment(List<basket> basket, string transactionCurrency, string customerEmail, string productCode, string transactionId, string productRef, Fullfillmenttype type, int promotionid,bool isTrial);
        Task<int> UpdatePaymentTransactionAsync(int id, bool isPaymentSuccess, string transactionId = null, string paymentErrorMsg = null, bool isPaymentRefund = false);
        Task<int> InsertPaypalByPay360TransactionPayment(List<PayPalByPay360Basket> basket, string transactionCurrency, string customerEmail, string productCode, string transactionId, string productRef, Fullfillmenttype type, int promotionid);
        Task<int> InsertPaypalTransactionPayment(List<ProductBasket> basket, string transactionCurrency, string customerEmail, string productCode, string transactionId, string productRef, Fullfillmenttype type, int promotionid);
        Task<PaymentCustomer> GetCustomerByMerchantRef(string merchantRef);
        Task SaveBundlePurchaseData(bool isSuccess, string bundleName, string bundleRef, float bundleAmount, string accountId, string errorMessage = null);
    }
}
