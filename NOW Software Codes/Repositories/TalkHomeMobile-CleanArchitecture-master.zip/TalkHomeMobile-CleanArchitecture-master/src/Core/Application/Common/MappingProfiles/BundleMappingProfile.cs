using Application.Features.Bundle.Model;
using Mapster;

namespace Application.Common.MappingProfiles;

public class BundleMappingProfile : IRegister
{
    public string? PenyBundleData { get; private set; }
    public string? PenyBundleSMS { get; private set; }
    public string? PenyBundleMinutes { get; private set; }

    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<Bundle, BundleInfo>
       .NewConfig()
       .BeforeMapping((bundle, _) => PennyBundleSetting(bundle))
       .Map(bundleInfo => bundleInfo.LocalSms, _ => PenyBundleSMS)
       .Map(bundleInfo => bundleInfo.Data, _ => PenyBundleData)
       .Map(bundleInfo => bundleInfo.LocalMinutes, _ => PenyBundleMinutes);
    }

    private void PennyBundleSetting(Bundle bundle)
    {
        if (bundle.Type == 9 && bundle.Category == 1)
        {
            var totalPrice = Convert.ToInt32(bundle.TotalPrice * 100);
            PenyBundleData = $"{totalPrice}p/{bundle.DataUnit}";
            PenyBundleSMS = $"{totalPrice}p/SMS";
            PenyBundleMinutes = $"{totalPrice}p/Minute";
        }
        else
        {
            PenyBundleData = bundle.Data;
            PenyBundleSMS = bundle.LocalSms;
            PenyBundleMinutes = bundle.LocalMinutes;
        }
    }
}
