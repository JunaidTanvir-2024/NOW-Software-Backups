using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Validations;

public class BusinessValidationRuleAssignmentList
{
    [JsonPropertyName("object")]
    public string? Object { get; set; }

    [JsonPropertyName("data")]
    public List<BusinessValidationRuleAssignment>? Data { get; set; }
}
