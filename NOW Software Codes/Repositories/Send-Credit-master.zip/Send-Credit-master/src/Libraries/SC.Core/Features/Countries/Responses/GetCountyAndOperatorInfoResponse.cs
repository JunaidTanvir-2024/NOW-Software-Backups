﻿

using System.Text.Json.Serialization;

namespace SC.Core.Features.Countries.Responses;
public sealed class GetCountyAndOperatorInfoResponse
{
    [JsonPropertyName("operator")]
    public OperatorInfo Operator { get; set; } = null!;
    [JsonPropertyName("country")]
    public CountryInfo Country { get; set; } = null!;

    public sealed record OperatorInfo
    {
        [JsonPropertyName("id")]
        public long Id { get; set; }
        [JsonPropertyName("name")]
        public string? Name { get; set; }
    }
    public sealed record CountryInfo
    {
        [JsonPropertyName("id")]
        public long Id { get; set; }
        [JsonPropertyName("name")]
        public string? Name { get; set; }
        [JsonPropertyName("isoCode")]
        public string? IsoCode { get; set; }
    }
}

