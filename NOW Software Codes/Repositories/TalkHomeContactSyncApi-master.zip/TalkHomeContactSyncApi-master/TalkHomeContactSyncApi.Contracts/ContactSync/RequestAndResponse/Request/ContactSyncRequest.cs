﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Request
{
    public class ContactSyncRequest
    {
        public List<string> Contacts { get; set; }
    }
}
