﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{
    public class MobiquityConfig
    {
        public string operator_name { get; set; }
        public string operator_Country { get; set; }
        public string operator_country_code { get; set; }
        public string operator_logoUrl { get; set; }
        public string serviceCode { get; set; }
        public string initiator { get; set; }
        public string bearerCode { get; set; }
        public string language { get; set; }
        public string currency { get; set; }
        public string currencyName { get; set; }
        public string RechargeType { get; set; }
        public string remarks { get; set; }
        public string transactor_bundle { get; set; }
        public string transactor_idType { get; set; }
        public string transactor_idValue { get; set; }
        public string transactor_mpin { get; set; }
        public string transactor_productId { get; set; }
        public string receiver_idType { get; set; }
        public string receiver_idValue { get; set; }
        public string APiURL { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public bool JsonResponseLogging { get; set; }
        public bool SendSmsToSender { get; set; }
        public string smsTemplate { get; set; }
        public string BalanceApiUserName { get; set; }
        public string BalanceApiPassword { get; set; }
        public string BalanceApiRequestType { get; set; }
        public string BalanceApiBLOCKSMS { get; set; }
        public string BalanceApiLANGUAGE1 { get; set; }
        public string BalanceApiCELLID { get; set; }
        public string BalanceApiFTXNID { get; set; }
    }
}
