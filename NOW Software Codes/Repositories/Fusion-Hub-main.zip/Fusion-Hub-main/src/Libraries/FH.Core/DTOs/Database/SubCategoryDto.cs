namespace FH.Core.DTOs.Database;

public sealed record SubCategoryDto
{
    public sealed record Request
    {
        public string? CategoryAliasName { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }

    public sealed record Response
    {
        public string? CategoryAliasName { get; set; }

        public long SubCategoryId { get; set; }
        public string? SubCategoryName { get; set; }
        public string? SubCategoryShortCode { get; set; }
        public string? SubCategoryDescription { get; set; }
    }
}
