﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.DAOs
{
    public class DBTopAmounts
    {
        public int Id { get; set; }
        public decimal Amount { get; set; }
        public bool IsActive { get; set; }
    }
}
