﻿using System.Text.Json.Serialization;
using static Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common.StackableDiscountResponse;

namespace Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Responses
{
	public class StackableDiscountValidationResponse
    {
        [JsonPropertyName("isValid")]
        public bool IsValid { get; set; }
        [JsonPropertyName("campaignName")]
        public string CampaignName { get; set; }
        [JsonPropertyName("order")]
        public ApplicableOrder Order { get; set; }
    }
}
