﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Models.Paypal
{
    public class Pay360PayPalResumePaymentRequest
    {
        public string PaypalCheckoutToken { get; set; }

    }
}
