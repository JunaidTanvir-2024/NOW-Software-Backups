using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.Bundle;

public sealed class BundlesRequest : IRequest<Result<List<BundleInfo>>>
{
    public string? Msisdn { get; set; }
}