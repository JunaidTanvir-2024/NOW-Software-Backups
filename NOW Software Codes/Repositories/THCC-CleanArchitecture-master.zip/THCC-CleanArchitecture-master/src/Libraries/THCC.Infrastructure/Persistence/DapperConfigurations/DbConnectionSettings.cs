﻿using System.Data;

namespace THCC.Infrastructure.Persistence.DapperConfigurations;

public interface IDbConnectionSettings
{
    IDbConnection SqlConnection { get; }
}

internal sealed class DbConnectionSettings : IDbConnectionSettings
{
    public IDbConnection SqlConnection { get; }
    public DbConnectionSettings(IDbConnection connection)
    {
        SqlConnection = connection;
    }
}