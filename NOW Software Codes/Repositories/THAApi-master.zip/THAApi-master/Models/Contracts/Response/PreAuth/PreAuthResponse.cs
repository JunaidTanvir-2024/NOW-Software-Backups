﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response.PreAuth
{
	public class PreAuthResponse
	{
		public string message { get; set; }
		public string status { get; set; }
		public int errorCode { get; set; }
		public bool payload { get; set; }
	}
}
