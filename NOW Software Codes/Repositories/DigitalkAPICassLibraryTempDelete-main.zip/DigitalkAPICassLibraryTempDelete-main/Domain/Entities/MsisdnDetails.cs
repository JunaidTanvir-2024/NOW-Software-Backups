﻿namespace Domain.Entities;

public class MsisdnDetails
{
    public string? Msisdn { get; set; }
    public string? PUKCode { get; set; }
    public string? AccountId { get; set; }
    public decimal Credit { get; set; }
    public DateTime? FirstDate { get; set; }
    public string SubscriberId { set; get; }
}


public class AccountDetail
{
    public string? Msisdn { get; set; }
    public string? Account { get; set; }
}