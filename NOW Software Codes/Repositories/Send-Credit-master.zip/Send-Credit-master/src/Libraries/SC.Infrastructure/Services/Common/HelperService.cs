﻿using Sentry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;
using SC.Core.Models.Dtos;

namespace SC.Infrastructure.Services.Common;
public class HelperService(IHttpContextAccessor httpContextAccessor, ICustomerCartRespository customerCartRepository, IDiscountRepository discountRepository) : IHelperService
{
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;
    private readonly ICustomerCartRespository _customerCartRepository = customerCartRepository;
    private readonly IDiscountRepository _discountRepository = discountRepository;

    public bool BeValidDOBFormat(string? dob)
    {
        if (dob == null) return false;
        if (dob.Length != 8) return false;
        if (!int.TryParse(dob, out _))
            return false;
        int year = int.Parse(dob.Substring(0, 4));
        int month = int.Parse(dob.Substring(4, 2));
        int day = int.Parse(dob.Substring(6, 2));
        if (year < 1900 || year > DateTime.Now.Year || month < 1 || month > 12 || day < 1 || day > DateTime.DaysInMonth(year, month))
            return false;
        return true;
    }
    public bool ConvertToDateFormat(string date, out DateTime result)
    {
        if (!DateTime.TryParseExact(date, AppConstants.CommonAppConfig.DateFormat, null, System.Globalization.DateTimeStyles.None, out result))
        {
            return false;
        }
        return true;
    }
    public bool BeValidCardExpiryDate(string expiryDate)
    {
        if (expiryDate.Length != 4)
            return false;
        if (!int.TryParse(expiryDate.AsSpan(0, 2), out int month) || !int.TryParse(expiryDate.AsSpan(2, 2), out int year))
            return false;
        if (month < 1 || month > 12 || year < DateTime.Now.Year % 100 || year > DateTime.Now.Year % 100 + 99)
            return false;
        return true;
    }
    public bool ConvertCartExpiryStringToDate(string dateString, out DateTime result)
    {
        int.TryParse(dateString.AsSpan(0, 2), out int month);
        int.TryParse(dateString.AsSpan(2, 2), out int year);

        int currentYear = DateTime.Now.Year;
        int firstTwoDigits = currentYear / 100;
        string yearS = firstTwoDigits.ToString() + year.ToString();
        int daysInMonth = DateTime.DaysInMonth(year, month);
        string DateInput = yearS + (month < 10 ? ("0" + month.ToString()) : month.ToString()) + daysInMonth.ToString();



        if (!DateTime.TryParseExact(DateInput, AppConstants.CommonAppConfig.DateFormat, null, System.Globalization.DateTimeStyles.None, out result))
        {
            return false;
        }
        return true;

    }

    public bool IsValidFloatWithTwoDecimalPlaces(float floatValue)
    {
        // Check if the floating-point number has exactly two decimal places
        return Math.Abs(floatValue - Math.Round(floatValue, 2)) < 0.0001;
    }
    public async Task<bool> IsValidUserID(string? UserID)
    {
        //if (string.IsNullOrEmpty(UserID))
        //    return true;
        return await _customerCartRepository.CheckValidUserAsync(UserID);
    }
    public async Task<bool> ValidateGuestUser(string? UserID)
    {
        if (string.IsNullOrEmpty(UserID))
            return true;
        return await _customerCartRepository.CheckValidUserAsync(UserID);
    }

    public async Task<bool> ValidatePromoCode(string? promoCode)
    {
        if (string.IsNullOrEmpty(promoCode))
            return true;
        var discount = await _discountRepository.GetDiscounts(new DiscountDto.Request()
        {
            IsActive = true,
            IsDeleted = false,
            Filters = new DiscountDto.Request.DiscountFilter()
            {
                EndDate = null,
                Name = null,
                Promocode = promoCode,
                StartDate = null,
                Type = null,
                Value = null
            }
        });
        if (discount != null && discount.Count() > 0)
            return true;
        return false;
    }
}

