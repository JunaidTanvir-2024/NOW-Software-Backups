using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;
using JM.Core.Utilities.Interfaces.Services;

using Mediator;

using RW;
namespace JM.Core.Features.Auth.Login;

public abstract class RefreshToken
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public string Token { get; set; } = string.Empty;
		public string RefreshToken { get; set; } = string.Empty;
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(p => p.Token).NotEmpty().NotNull();
			RuleFor(p => p.RefreshToken).NotEmpty().NotNull();
		}
	}

	#endregion

	#region Response
	public sealed record Response
	{
		public required string JwtToken { get; set; }
		public required DateTime JwtTokenExpiry { get; set; }
		public required string RefreshToken { get; set; }
		public required DateTime RefreshTokenExpiry { get; set; }
	}

	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork, IJwtService jwtService) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		private readonly IJwtService _jwtService = jwtService;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{

			var expiredTokenPrinciples = _jwtService.GetPrincipalFromExpiredToken(query.Token);

			if (expiredTokenPrinciples is null)
			{
				return ResultWrapper.Failure(AppConstant.StatusKey.JwtTokenInvalid, AppConstant.StatusCode.BadRequest);
			}

			var userId = expiredTokenPrinciples.GetId();
			var userEmail = expiredTokenPrinciples.GetEmail();

			var userInfo = await _unitOfWork.UserRepository.GetUser(x => x.Id!.Equals(userId));

			if (userInfo is not null)
			{
				if (userInfo.RefreshToken != query.RefreshToken)
				{
					return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
				}

				(string jwtToken, DateTime jwtTokenExpiry, string refreshToken, DateTime refreshTokenExpiry) = _jwtService.GetTokensAsync(userInfo?.UserDetail?.FullName!, userEmail!, userId);

				userInfo!.RefreshToken = refreshToken;
				userInfo.RefreshTokenExpiry = refreshTokenExpiry;
				_unitOfWork.SaveChanges();

				return ResultWrapper.Success(new Response()
				{
					JwtToken = jwtToken,
					RefreshToken = refreshToken,
					JwtTokenExpiry = jwtTokenExpiry,
					RefreshTokenExpiry = refreshTokenExpiry
				});
			}
			return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
		}
	}
	#endregion
}
