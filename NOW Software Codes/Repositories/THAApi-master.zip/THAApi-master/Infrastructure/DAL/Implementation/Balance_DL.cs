﻿using Dapper;
using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class Balance_DL : IBalance_DL
    {
        private readonly ILogger _logger;
        private readonly IHelper_BL _helperService;
        private readonly ConnectionStrings _dbConnections;

        public Balance_DL(ILogger logger, IHelper_BL helperService, IOptions<ConnectionStrings> dbConnections)
        {
            _helperService = helperService;
            _logger = logger;
            _dbConnections = dbConnections.Value;
        }

        /// <summary>
        /// Get User Account Balance By Account
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<UserAccountBalance> GetUserAccountBalanceByAccount(string account)
        {
            GetBalance balance = null;

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
				balance = await dbConnection.QueryFirstOrDefaultAsync<GetBalance>(
                "select credit as Balance, currency as Currency from dbo.subscribers sub (nolock) " +
                "WHERE sub.account = @account",
                new { account });
            }

            if (balance != null)
            {
                return new UserAccountBalance
                {
                    Balance = _helperService.FormatAccountBalance(balance.Balance, balance.Currency),
                    Currency = balance.Currency,
                    CurrencySymbol = _helperService.ToCurrencySymbol(balance.Currency)
                };
            }
            return null;
        }

        /// <summary>
        /// Get User Account Balance
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<UserAccountBalance> GetUserAccountBalance(string msisdn)
        {
            try
            {
                var sipUserName = _helperService.GetSipUserName(msisdn);

                var storedProcedure = "tha_get_balance";

                var parameters = new DynamicParameters();

                parameters.Add("@sipuserName", sipUserName);

                GetBalance balance = null;
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    balance = await dbConnection.QueryFirstOrDefaultAsync<GetBalance>(storedProcedure, parameters,
                            commandType: CommandType.StoredProcedure);
                }

                if (balance != null)
                {
                    return new UserAccountBalance
                    {
                        Balance = _helperService.FormatAccountBalance(balance.Balance, balance.Currency),
                        Currency = balance.Currency,
                        CurrencySymbol = _helperService.ToCurrencySymbol(balance.Currency)
                    };
                }

                return null;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Balance_DL, Method: GetUserAccountBalance, Parameters=> msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return null;
        }
    }
}
