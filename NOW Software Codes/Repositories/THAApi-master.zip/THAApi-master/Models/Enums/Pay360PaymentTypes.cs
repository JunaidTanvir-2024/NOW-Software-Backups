﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum Pay360PaymentType
    {
        New,
        Default,
        Token,
        ExistingNew
    }
    public enum ProductItemCode
    {
        THAATA,
        THADTA

    }
    public enum ProductCode
    {
        THA
    }

    public enum CheckOutTypes
    {
        TopUp = 1,
        Bundle = 2,
        Transfer = 3
    }
    public enum PaymentMethods
    {
        Paypal = 1,
        Card = 2,
        Balance = 3
    }
    public enum DiscountType
    {
        Amount = 1,
        Percent = 2,
        ExtraBalance = 3,
    }

}
