﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class RatesConfig
    {
        public Dictionary<string, string> UpdatedCountryCodes { get; set; }
    }
}
