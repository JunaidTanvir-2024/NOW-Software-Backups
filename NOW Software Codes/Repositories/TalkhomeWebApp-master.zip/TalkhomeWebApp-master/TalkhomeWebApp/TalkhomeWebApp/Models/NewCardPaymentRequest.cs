﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.ViewModels;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models
{
    public class NewCardPaymentRequest
    {
        public CardViewModel UserCard { get; set; }

        //Address Data
        [Required(ErrorMessage = "Enter Address"), StringLength(maximumLength: 1000, ErrorMessage = "Maximum Length Exceeded")]
        public string AddressL1 { get; set; }
        public string AddressL2 { get; set; }
        public string AddressL3 { get; set; }
        public string AddressL4 { get; set; }
        public string City { get; set; }
        public string County { get; set; }
        public string PostCode { get; set; }
        public string Region { get; set; }


        [CollectionValidation(values: new int[] { 0, 5, 10, 15, 20, 25 })]
        public int Amount { get; set; }

        [Required]
        [Range(1, 3)]
        public CheckOutTypes CheckoutPaymentType { get; set; }

        [Required(ErrorMessage = "Enter email address")]
        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [EmailAddress(ErrorMessage = "Invalid email")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        public string EmailAddress { get; set; }

        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        public string Msisdn { get; set; }

        public string BundleId { get; set; }
        public bool ShouldSave { get; set; }

        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }
        public BundleType BundleType { get; set; }

        public bool IsAutoTopUp { get; set; }
        public bool IsAutoBundleRenew { get; set; }
    }
}
