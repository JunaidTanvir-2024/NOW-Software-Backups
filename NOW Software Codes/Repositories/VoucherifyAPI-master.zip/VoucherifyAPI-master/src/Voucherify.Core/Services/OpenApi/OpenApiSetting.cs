namespace Voucherify.Core.Services.OpenApi;

/// <summary>
/// Represents the OpenAPI Configurations used to configure the Swagger generator and UI.
/// </summary>
public class OpenApiSetting
{
    /// <summary>
    /// The name of the configuration section for the OpenAPI settings.
    /// </summary>
    public const string SectionName = nameof(OpenApiSetting);

    /// <summary>
    /// Gets the singleton instance of the OpenApiSettings.
    /// </summary>
    public static OpenApiSetting Instance { get; } = new OpenApiSetting();

    /// <summary>
    /// Gets or sets the version of the API.
    /// </summary>
    public string? Version { get; set; }

    /// <summary>
    /// Gets or sets the title of the API.
    /// </summary>
    public string? Title { get; set; }

    /// <summary>
    /// Gets or sets the description of the API.
    /// </summary>
    public string? Description { get; set; }

    /// <summary>
    /// Gets or sets the terms of service for the API.
    /// </summary>
    public string TermsOfService { get; set; } = default!;

    /// <summary>
    /// Gets or sets the name of the contact for the API.
    /// </summary>
    public string? ContactName { get; set; }

    /// <summary>
    /// Gets or sets the URL for the contact for the API.
    /// </summary>
    public string ContactUrl { get; set; } = default!;

    /// <summary>
    /// Gets or sets the name of the license for the API.
    /// </summary>
    public string? LicenseName { get; set; }

    /// <summary>
    /// Gets or sets the URL for the license for the API.
    /// </summary>
    public string LicenseUrl { get; set; } = default!;

    /// <summary>
    /// Gets or sets the name of the JWT security definition for the API.
    /// </summary>
    public string? JwtSecurityDefinitionName { get; set; }

    /// <summary>
    /// Gets or sets the description of the JWT security definition for the API.
    /// </summary>
    public string? JwtSecurityDefinitionDescription { get; set; }

    /// <summary>
    /// Gets or sets the format of the JWT security definition for the API.
    /// </summary>
    public string? JwtSecurityDefinitionBearerFormat { get; set; }
}
