﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Pay360ApiContracts;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Configurations;
using TalkhomeAPI.Models.Pay360ApiContracts;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class Pay360Service : IPay360Service
    {
        private readonly Pay360Config _Pay360Setting;
        private readonly HttpClient _httpClient;
        private readonly ILogger _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IPhoneNumberService _phoneNumberService;

        public Pay360Service(
            IOptions<Pay360Config> Pay360Setting,
            HttpClient httpClient,
            ILogger logger,
            IHttpContextAccessor httpContextAccessor,
            IPhoneNumberService phoneNumberService)
        {
            _Pay360Setting = Pay360Setting.Value;
            _httpClient = httpClient;
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
            _phoneNumberService = phoneNumberService;
        }

        public async Task<GenericApiResponse<Pay360PaymentResponse>> Resume3DTransaction(Pay360Resume3DRequest request)
        {

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/Resume3DSecureTransaction";

            GenericApiResponse<Pay360PaymentResponse> ret = new GenericApiResponse<Pay360PaymentResponse>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericApiResponse<Pay360PaymentResponse>>(Result);

            return ret;

        }
        public async Task<GenericApiResponse<Pay360PaymentResponse>> Resume3DTransactionV2(Pay360Resume3DRequest request)
        {

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/Resume3DsV2";

            GenericApiResponse<Pay360PaymentResponse> ret = new GenericApiResponse<Pay360PaymentResponse>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericApiResponse<Pay360PaymentResponse>>(Result);

            return ret;

        }

        public async Task<GenericApiResponse<Pay360CardsResponse>> Pay360GetCards(Pay360CustomerRequestModel request)
        {
            GenericApiResponse<Pay360CardsResponse> ret = new GenericApiResponse<Pay360CardsResponse>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/GetCustomerPaymentMethodsByCustomerUniqueRef";

            var json = JsonConvert.SerializeObject(request);

            var Result = await Post(endpoint, json);

            if (Result == null)
            {
                return null;
            }

            //LoggerService.Debug(GetType(), Result);

            ret = JsonConvert.DeserializeObject<GenericApiResponse<Pay360CardsResponse>>(Result);

            return ret;
        }

        public async Task<GenericApiResponse<Pay360CustomerModel>> GetCustomer(Pay360CustomerRequestModel model)
        {

            GenericApiResponse<Pay360CustomerModel> ret = new GenericApiResponse<Pay360CustomerModel>();

            string endpoint = "";

            endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/GetCustomerByCustomerUniqueRef";

            var Json = JsonConvert.SerializeObject(model);

            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericApiResponse<Pay360CustomerModel>>(Result);

            return ret;


        }

        public async Task<GenericApiResponse<Pay360PaymentResponse>> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType)
        {
            GenericApiResponse<Pay360PaymentResponse> ret = new GenericApiResponse<Pay360PaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";

            switch (paymentType)
            {
                case Pay360PaymentType.New:
                    endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/NewCustomerPayment";
                    request.Pay360PaymentRequestNew.isDefaultCard = request.Pay360PaymentRequestNew.isDefaultCard && request.Pay360PaymentRequestNew.saveCard;
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestNew);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.Default:
                    endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/ExistingCustomerPaymentDefaultCard";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestDefault);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.ExistingNew:
                    endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/ExistingCustomerPaymentNewCard";
                    request.Pay360PaymentRequestExistingNew.isDefaultCard = request.Pay360PaymentRequestExistingNew.isDefaultCard && request.Pay360PaymentRequestExistingNew.saveCard;
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestExistingNew);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.Token:
                    endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/PaymentToken";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestToken);
                    Result = await Post(endpoint, Json);
                    break;
            }

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericApiResponse<Pay360PaymentResponse>>(Result);
            return ret;

        }

        public Pay360PaymentRequestToken CreatePay360PaymentRequestToken(Pay360PaymentRequestModel model)
        {
            Pay360PaymentRequestToken result = new Pay360PaymentRequestToken
            {
                cardCv2 = model.UserCard.SecurityCode,
                customerMsisdn = model.Msisdn,
                isAuthorizationOnly = _Pay360Setting.IsAuthorization,
                transactionAmount = model.Amount,
                transactionCurrency = Currency.GBP.ToString(),
                do3DSecure = _Pay360Setting.Do3DSecure,
                cardToken = model.UserCard.Token,
                isDirectFullfilment = _Pay360Setting.IsDirectFullfilment

            };

            return result;
        }

        public Pay360PaymentBase CreatePay360PaymentBaseRequest(StartPay360Model model)
        {
            Pay360PaymentBase result = new Pay360PaymentBase
            {
                cardCv2 = model.CardCv2,
                customerMsisdn = model.Msisdn,
                isAuthorizationOnly = _Pay360Setting.IsAuthorization,
                transactionAmount = model.Amount,
                transactionCurrency = model.Currency,
                do3DSecure = _Pay360Setting.Do3DSecure,
                isDirectFullfilment = _Pay360Setting.IsDirectFullfilment
            };

            return result;
        }

        public Pay360PaymentRequestExistingNew CreatePay360PaymentRequestExistingNew(Pay360PaymentRequestModel model)
        {
            Pay360PaymentRequestExistingNew result = new Pay360PaymentRequestExistingNew
            {

                cardCv2 = model.UserCard.SecurityCode,
                cardExpiryDate = model.UserCard.ExpiryMonth + model.UserCard.ExpiryYear,
                cardPan = model.UserCard.CardNumber,
                customerMsisdn = model.Msisdn,
                isAuthorizationOnly = _Pay360Setting.IsAuthorization,
                isDirectFullfilment = _Pay360Setting.IsDirectFullfilment,
                isDefaultCard = false,
                do3DSecure = _Pay360Setting.Do3DSecure,
                transactionAmount = model.Amount,
                transactionCurrency = Currency.GBP.ToString(),
                customerName = model.UserCard.NameOnCard,
                billingAddress = new billingAddress
                {
                    line1 = model.AddressL1,
                    line2 = model.AddressL2,
                    line3 = model.AddressL3,
                    line4 = model.AddressL4,
                    region = model.Region,
                    city = model.City,
                    postcode = model.PostCode,
                    countryCode = model.UserCard.SelectedCountry
                }
            };

            return result;
        }

        public Pay360PaymentRequestNew CreatePay360PaymentRequestNew(Pay360PaymentRequestModel model)
        {
            Pay360PaymentRequestNew result = new Pay360PaymentRequestNew
            {
                customerName = model.UserCard.NameOnCard,
                cardCv2 = model.UserCard.SecurityCode,
                cardExpiryDate = model.UserCard.ExpiryMonth + model.UserCard.ExpiryYear,
                cardPan = model.UserCard.CardNumber,
                customerMsisdn = model.Msisdn,
                isDirectFullfilment = _Pay360Setting.IsDirectFullfilment,
                isAuthorizationOnly = _Pay360Setting.IsAuthorization,
                isDefaultCard = true,
                do3DSecure = _Pay360Setting.Do3DSecure,
                transactionAmount = model.Amount,
                transactionCurrency = Currency.GBP.ToString(),
                billingAddress = new billingAddress
                {
                    line1 = model.AddressL1,
                    line2 = model.AddressL2,
                    line3 = model.AddressL3,
                    line4 = model.AddressL4,
                    region = model.Region,
                    city = model.City,
                    postcode = model.PostCode,
                    countryCode = model.UserCard.SelectedCountry
                }
            };
            if (_Pay360Setting.IsBillingAndCustomerAddressSame == true)
            {
                result.customerBillingAddress = result.billingAddress;
            }

            return result;
        }

        public async Task<GenericApiResponse<string>> SetAutoTopUp(Pay360SetAutoTopUpRequest model)
        {

            GenericApiResponse<string> ret = new GenericApiResponse<string>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/SetAutoTopup";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericApiResponse<string>>(Result);
                return ret;
            }

            return ret;

        }

        public async Task<GenericApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(Pay360GetAutoTopUpRequest model)
        {

            GenericApiResponse<Pay360GetAutoTopUpResponse> ret = new GenericApiResponse<Pay360GetAutoTopUpResponse>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/GetAutoTopup";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericApiResponse<Pay360GetAutoTopUpResponse>>(Result);
                return ret;
            }

            return ret;

        }

        public async Task<GenericApiResponse<paymentMethodResponse>> SetCustomerDefaultCard(SetCustomerDefaultCardRequest model)
        {

            GenericApiResponse<paymentMethodResponse> ret = new GenericApiResponse<paymentMethodResponse>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/SetCustomerDefaultCard";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericApiResponse<paymentMethodResponse>>(Result);
                return ret;
            }

            return ret;

        }

        public async Task<GenericApiResponse<string>> RemoveCard(RemoveCardRequest model)
        {

            GenericApiResponse<string> ret = new GenericApiResponse<string>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/RemoveCard";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericApiResponse<string>>(Result);
                return ret;
            }

            return ret;

        }

        public async Task<GenericPay360ApiResponse<RefundFullPaymentResponseModel>> RefundFullPayment(RefundFullPaymentRequestModel request)
        {

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/RefundFullPayment";

            GenericPay360ApiResponse<RefundFullPaymentResponseModel> ret = new GenericPay360ApiResponse<RefundFullPaymentResponseModel>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<RefundFullPaymentResponseModel>>(Result);

            return ret;

        }

        public async Task<GenericPay360ApiResponse<CaptureTransactionResponseModel>> CaptureTransaction(CaptureTransactionRequestModel model)
        {
            GenericPay360ApiResponse<CaptureTransactionResponseModel> ret = new GenericPay360ApiResponse<CaptureTransactionResponseModel>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/CaptureTransaction";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<CaptureTransactionResponseModel>>(Result);
                return ret;
            }

            return ret;
        }

        public async Task<GenericPay360ApiResponse<string>> cancelTransaction(CancelTransactionRequestModel model)
        {
            GenericPay360ApiResponse<string> ret = new GenericPay360ApiResponse<string>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/CancelTransaction";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<string>>(Result);
                return ret;
            }

            return ret;
        }

        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await _httpClient.PostAsync(new Uri(address), Content);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            if (!response.IsSuccessStatusCode || response.Content == null)
            {
                var responseData = await response.Content.ReadAsStringAsync();
                _logger.Error($"Pay360 Service => {response.StatusCode} : {responseData}");
                return null;
            }

            return await response.Content.ReadAsStringAsync();
        }
    }
}
