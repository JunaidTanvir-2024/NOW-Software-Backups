﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Configurations
{
    public class InAppPurchaseConfig
    {
        public InAppPurchase[] inAppPurchase { get; set; }
        public topup_options[] topup_options { get; set; }
        public transfer_options[] transfer_options { get; set; }
        public string IOSAppversion { get; set; }
        public string ApiVersion { get; set; }
    }

    public class InAppPurchase
    {
        public string id { get; set; }
        public string currency { get; set; }
        public string credit { get; set; }
    }

    public class topup_options
    {
        public string id { get; set; }
        public string link { get; set; }
        public string title { get; set; }
        public string type { get; set; }
    }

    public class transfer_options
    {
        public string id { get; set; }
        public string link { get; set; }
        public string title { get; set; }
        public string type { get; set; }
    }
}
