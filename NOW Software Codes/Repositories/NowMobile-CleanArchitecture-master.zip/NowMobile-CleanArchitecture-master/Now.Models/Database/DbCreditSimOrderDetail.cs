﻿using Now.Models.Enums;
namespace Now.Models.Database;
public class DbCreditSimOrderDetail
{
    public PaymentType Payment_type { get; set; }
    public string? Paymenttranid { get; set; }
    public long Id { get; set; }
    public string? Amount { get; set; }
    public string? BundleId { get; set; }
    public bool IsProcessed { get; set; }
    public string? FullName { get; set; }
    public string? Email { get; set; }
    public CreditSimType CreditSim_type { get; set; }
}

