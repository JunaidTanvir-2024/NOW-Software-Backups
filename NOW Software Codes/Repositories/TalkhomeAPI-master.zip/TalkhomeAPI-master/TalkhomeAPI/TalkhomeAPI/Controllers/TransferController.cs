﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Services.Interfaces;
using ThmApi.Filters;

namespace TalkhomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransferController : ControllerBase
    {
        private readonly ILogger Logger;
        private readonly ITransferService _transferService;

        public TransferController(ILogger logger, ITransferService transferService)
        {
            Logger = logger;
            _transferService = transferService;
        }

        [Route("GetProducts")]
        [HttpGet]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetProducts([FromQuery]GetProductsRequestModel model)
        {
            try
            {
                return Ok(await _transferService.GetProducts(
                        model.ToMsisdn,
                        User.Claims.First(i => i.Type == "msisdn").Value,
                        User.Claims.First(i => i.Type == "currency").Value));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: GetProducts, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("TransferByAccountBalance")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByAccountBalance([FromBody]TransferByAccountBalanceRequestModel model)
        {
            try
            {
                return Ok(await _transferService.TransferByAccountBalance(model,
                                                User.Claims.First(i => i.Type == "msisdn").Value,
                                                User.Claims.First(i => i.Type == "currency").Value));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByAccountBalance, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("GetSpecialPromotionBalanceToDeduct")]
        [HttpGet]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetSpecialPromotionBalanceToDeduct([FromQuery] GetSpecialPromotionBalanceToDeductRequestModel model)
        {
            try
            {
                return Ok(await _transferService.GetSpecialPromotionBalanceToDeduct(
                                                User.Claims.First(i => i.Type == "msisdn").Value,
                                                model.Amount));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: GetSpecialPromotionBalanceToDeduct, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }





        [Route("TransferByPayPal")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByPayPal([FromBody]TransferByPayPalRequestModel model)
        {
            try
            {
                return Ok(await _transferService.TransferByPayPal(model,
                                                User.Claims.First(i => i.Type == "msisdn").Value,
                                                User.Claims.First(i => i.Type == "currency").Value,
                                                User.Claims.First(i => i.Type == "accountId").Value));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByPayPal, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        //Direct Paypal
        [Route("TransferByPayPalCallBackV1")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByPayPalCallBackV1([FromBody]TransferByPayPalCallBackV1RequestModel model)
        {
            try
            {
                return Ok(await _transferService.TransferByPayPalCallBackV1(model,
                                                User.Claims.First(i => i.Type == "msisdn").Value,
                                                User.Claims.First(i => i.Type == "currency").Value));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByPayPalCallBackV1, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        //PayPal Via Pay360
        [Route("TransferByPayPalCallBackV2")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByPayPalCallBackV2([FromBody]TransferByPayPalCallBackV2RequestModel model)
        {
            try
            {
                return Ok(await _transferService.TransferByPayPalCallBackV2(model,
                                                User.Claims.First(i => i.Type == "msisdn").Value,
                                                User.Claims.First(i => i.Type == "currency").Value));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByPayPalCallBackV2, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("TransferByExistingCard")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByExistingCard([FromBody]TransferByExistingCardRequestModel model)
        {
            try
            {
                return Ok(await _transferService.TransferByExistingCard(model,
                                                    User.Claims.First(i => i.Type == "msisdn").Value,
                                                    User.Claims.First(i => i.Type == "currency").Value,
                                                    User.Claims.First(i => i.Type == "accountId").Value));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByExistingCard, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("TransferByNewCustomer")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByNewCustomer([FromBody]TransferByNewCustomerRequestModel model)
        {
            try
            {
                return Ok(await _transferService.TransferByNewCustomer(model,
                                                    User.Claims.First(i => i.Type == "msisdn").Value,
                                                    User.Claims.First(i => i.Type == "currency").Value,
                                                    User.Claims.First(i => i.Type == "accountId").Value));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByNewCustomer, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("TransferByNewCard")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByNewCard([FromBody]TransferByNewCardRequestModel model)
        {
            try
            {
                return Ok(await _transferService.TransferByNewCard(model,
                                                    User.Claims.First(i => i.Type == "msisdn").Value,
                                                    User.Claims.First(i => i.Type == "currency").Value,
                                                    User.Claims.First(i => i.Type == "accountId").Value));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByNewCardRequestModel, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("TransferByCard3dSecureCallBack")]
        [HttpPost]

        [BasicAuth]
        public async Task<IActionResult> TransferByCard3dSecureCallBack([FromBody]TransferByCardCallBackRequestModel model)
        {
            try
            {
                return Ok(await _transferService.TransferByCard3dSecureCallBack(model));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByCard3dSecureCallBack, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
    }
}