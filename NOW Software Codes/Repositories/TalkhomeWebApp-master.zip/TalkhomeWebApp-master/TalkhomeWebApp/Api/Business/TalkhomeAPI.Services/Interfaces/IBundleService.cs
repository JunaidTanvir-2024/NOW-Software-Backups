﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Services.Interfaces
{
    public interface IBundleService
    {
        Task<IEnumerable<BundlesCountries>> GetCountriesByBundle();
        Task<GenericApiResponse<bool>> ValidateBundlePurchase(string accountId, string msisdn, string bundleId,bool startTrial);
        Task<IEnumerable<Bundles>> GetBundleByCountry(string ServiceId,string account);
        Task<IEnumerable<Bundles>> GetBundleByDestinationCountry(string ServiceId, string toCountryCode, string account);

        Task<Bundles> GetBundleById(string Id);
        Task<bool> AnyActiveAutoBundleRenwal(string account);
        Task<GenericApiResponse<bool>> SetAutoRenew(bool isRenew, string msisdn, string bundleId, bool isTrial = false);
    }
}
