﻿using Models.Contracts.Request;
using Models.Enums;
using Models.Services.Airship;

namespace THAApi.ViewModels
{
    public class SetAutoTopupSuccessViewModel
    {
        public string MaxSpendLimit { get; set; }
        public string ThresholdAmount { get; set; }
        public string TopupAmount { get; set; }
        public ThemeMode ThemeMode { get; set; }
    }
	public class SetAutoBundleRenewalSuccessViewModel
	{
		public ThemeMode ThemeMode { get; set; }
	}
	public class SuccessViewModel
    {
        //public string Message { get; set; }
        public string CustomerMsisdn { get; set; }
        public string TransactionId { get; set; }
        public CheckoutType Type { get; set; }
        public ThemeMode ThemeMode { get; set; }
        public string Origination { get; set; }
        public Topup TopupInfo { get; set; }
        public Bundle BundleInfo { get; set; }
        public InternationalTopup InternationalTopupInfo { get; set; }
        public VoucherifyAirshipInfo VoucherifyInfo { get; set; }
        public UtmParamsInfo UtmParamsInfo { get; set; }

        public class Topup
        {
            public string Amount { get; set; }
            public string Currency { get; set; }
            public string UpdatedBalance { get; set; }
            public PaymentMehtods? PaymentMethod { get; set; }
        }
        public class Bundle
        {
            public string Currency { get; set; }
            public string Amount { get; set; }
            public string Name { get; set; }
            public PaymentMehtods? PaymentMethod { get; set; }
            public BundleType? Type { get; set; }
            public string Destination { get; set; }
        }
        public class InternationalTopup//Also known as SendCredit
        {
            public string Currency { get; set; }
            public string Amount { get; set; }
            public PaymentMehtods? PaymentMethod { get; set; }
            public string Destination { get; set; }
            public bool IsTransferRequest { get; set; } = false;
        }

        

        public enum CheckoutType
        {
            Topup,
            Bundle,
            InternationalTopup,
            SetAutoTopup
        }
        public enum PaymentMehtods
        {
            Card,
            Paypal
        }
    }
}
