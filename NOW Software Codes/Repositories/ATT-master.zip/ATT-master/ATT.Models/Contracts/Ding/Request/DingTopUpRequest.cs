﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Ding.Request
{
    public class DingTopUpRequest
    {
        public string skuCode { get; set; }
        public decimal sendValue { get; set; }
        public string sendCurrencyIso { get; set; }
        public string accountNumber { get; set; }
        public string distributorRef { get; set; }
        public bool ValidateOnly { get; set; }
        public string BillRef { get; set; }

    }
}
