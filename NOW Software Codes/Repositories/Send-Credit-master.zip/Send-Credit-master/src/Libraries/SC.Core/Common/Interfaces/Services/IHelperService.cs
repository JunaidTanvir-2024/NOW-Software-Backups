﻿using SC.Core.DependencyResolver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Interfaces.Services;
public interface IHelperService : ServiceType.IScoped
{

    bool BeValidDOBFormat(string? dob);
    bool ConvertToDateFormat(string date, out DateTime result);
    bool BeValidCardExpiryDate(string expiryDate);
    bool IsValidFloatWithTwoDecimalPlaces(float floatValue);
    bool ConvertCartExpiryStringToDate(string dateString, out DateTime result);
    Task<bool> IsValidUserID(string? UserID);
    Task<bool> ValidateGuestUser(string? UserID);
    Task<bool> ValidatePromoCode(string? promoCode);
}

