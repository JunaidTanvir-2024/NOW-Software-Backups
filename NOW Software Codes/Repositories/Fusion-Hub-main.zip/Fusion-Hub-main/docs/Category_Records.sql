INSERT INTO [dbo].[product_category]
  ([name]
  ,[description]
  )
VALUES
  ('General',
    'General Category')
GO
