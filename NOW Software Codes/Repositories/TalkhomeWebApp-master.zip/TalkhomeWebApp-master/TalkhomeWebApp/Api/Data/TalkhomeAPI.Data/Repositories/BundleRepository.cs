﻿using Dapper;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Org.BouncyCastle.Asn1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.DbConnections;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Repositories
{
	public class BundleRepository : IBundleRepository
	{
		private readonly IDbConnectionSettings TH_Db;
		private readonly IDbConnectionSettings DGT_Db;

		public BundleRepository(IOptions<ConnectionString> connectionString)
		{
			TH_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppDbConnection));
			DGT_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigitalkDbConnection));
		}
		public async Task<bool> IsBundlePurchasedPreviously(string account, string bundleId)
		{
			var storedProcedure = "tha_is_auto_bundle_renewal_record_exists";

			var parameters = new DynamicParameters();
			parameters.Add("@account", account);
			parameters.Add("@bundleId ", bundleId);
			parameters.Add("@exists", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			await DGT_Db.SqlConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
			return parameters.Get<bool>("@exists");
		}
		public async Task<bool> MonthlyBundleValidationAfterTrialExpire(string account, string msisdn, string bundleId, string trialBundleId)
		{
			var storedProcedure = "tha_validate_monthly_bundle_activation";

			var parameters = new DynamicParameters();
			parameters.Add("@account", account);
			parameters.Add("@msisdn", msisdn);
			parameters.Add("@callingPackageId", bundleId);
			parameters.Add("@trialCallingPackageId", trialBundleId);
			parameters.Add("@isValid", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			await DGT_Db.SqlConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
			return parameters.Get<bool>("@isValid");
		}
		public async Task<bool> ValidateBundlePurchase(string account, string msisdn, string bundleId, bool startTrial)
		{
			var storedProcedure = "tha_validate_bundle_purchase";

			var parameters = new DynamicParameters();
			parameters.Add("@account", account);
			parameters.Add("@msisdn", msisdn);
			parameters.Add("@callingPackageId", bundleId);
			parameters.Add("@startTrial", startTrial);
			parameters.Add("@isValid", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			await DGT_Db.SqlConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
			return parameters.Get<bool>("@isValid");
		}
		public async Task SaveBundlePurchaseData(bool isSuccess, string bundleName, string bundleRef, float bundleAmount, string accountId, string errorMessage)
		{
			var storedProcedure = "tha_save_bundle_purchase_data";

			var parameters = new DynamicParameters();
			parameters.Add("@accountId", accountId);
			parameters.Add("@bundleName", bundleName);
			parameters.Add("@bundleRef", bundleRef);
			parameters.Add("@bundleAmount", bundleAmount);
			parameters.Add("@productItemCode", "THAATA");
			parameters.Add("@isSuccess", isSuccess);
			parameters.Add("@ErrorMessage", errorMessage);

			await TH_Db.SqlConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<IEnumerable<BundlesCountries>> GetCountriesByBundle()
		{
			//return await TH_Db.SqlConnection.QueryAsync<BundlesCountries>("tha_web_get_bundles_home_country", commandType: CommandType.StoredProcedure);
			var serviceIds = await GetAllCompatibleBundlesNaServiceIds();
			var originationCountries = await GetAllBundleOriginationCountries();
			return originationCountries.Where(x => serviceIds.Contains(x.Na_Service_Id));
		}
		private async Task<IEnumerable<BundlesCountries>> GetAllBundleOriginationCountries()
		{
			return await TH_Db.SqlConnection.QueryAsync<BundlesCountries>("tha_web_get_bundles_origination_country", commandType: CommandType.StoredProcedure);
		}
		private async Task<IEnumerable<string>> GetAllCompatibleBundlesNaServiceIds()
		{
			return await DGT_Db.SqlConnection.QueryAsync<string>("tha_web_get_compatible_bundles_service_ids", commandType: CommandType.StoredProcedure);
		}
		public async Task<bool> AnyActiveAutoBundleRenwal(string account)
		{
			bool isExist = false;
			var parameters = new DynamicParameters();
			parameters.Add("@account", account);
			parameters.Add("@exists", isExist, direction: ParameterDirection.Output);
			var result = await DGT_Db.SqlConnection.ExecuteAsync("thaAnyActiveAutoBundleRenewal", parameters, commandType: CommandType.StoredProcedure);
			return parameters.Get<bool>("@exists");
		}
		public async Task<IEnumerable<Bundles>> GetBundleByCountry(string ServiceId, string account = null)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@na_service_id", ServiceId);
			parameters.Add("@account", account);
			return await DGT_Db.SqlConnection.QueryAsync<Bundles>("tha_web_get_compatible_bundles_v2", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<IEnumerable<DBBundleDetails>> GetBundleDetailsByIds(List<string> ids)
		{
			try
			{
				var parameter = new DynamicParameters();
				var dataTable = new DataTable();
				dataTable.Columns.Add("@ID", typeof(Guid));
				ids.ForEach(e =>
				{
					dataTable.Rows.Add(Guid.Parse(e));
				});
				parameter.Add("@Ids", dataTable.AsTableValuedParameter());
				return await DGT_Db.SqlConnection.QueryAsync<DBBundleDetails>("tha_get_calling_package_details_by_ids", parameter, commandType: CommandType.StoredProcedure);

			}
			catch (Exception)
			{
				throw;
			}
		}
		public async Task<Bundles> GetBundleById(string Id)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@calling_package_id", Id);

			return await DGT_Db.SqlConnection.QueryFirstOrDefaultAsync<Bundles>("tha_web_get_compatible_bundles_by_id_v2", parameters, commandType: CommandType.StoredProcedure);
		}

		public async Task<int> BundlePurchaseViaAccountBalance(string accountId, string bundleId)
		{
			var parameters = new DynamicParameters();

			parameters.Add("@account", accountId);
			parameters.Add("@bundle_id", bundleId);
			parameters.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
			parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 250);

			await DGT_Db.SqlConnection.ExecuteAsync("tha_add_accounts_bundle", parameters, commandType: CommandType.StoredProcedure);

			return parameters.Get<int>("error_code");
		}
		public async Task<int> SetBundleAutoRenewal(bool isAutoRenew, string Msisdn, string account, string bundleId, bool isTrial,PaymentMethods paymentMethod,string cardMaskedPAN,string cardInitialTransactionId,string paypalSubscriptionId)
		{
			var parameter = new DynamicParameters();
			parameter.Add("@account", account);
			parameter.Add("@msisdn", Msisdn);
			parameter.Add("@is_renew", isAutoRenew);
			parameter.Add("@bundle_id", bundleId);
			parameter.Add("@is_trial", isTrial);
			parameter.Add("@paymentMethod", paymentMethod);
			parameter.Add("@cardMaskedPAN", cardMaskedPAN);
			parameter.Add("@cardInitialTransactionId", cardInitialTransactionId);
			parameter.Add("@paypalSubscriptionId", paypalSubscriptionId);

			await DGT_Db.SqlConnection.ExecuteAsync("tha_update_user_package_renewal_status_v2", parameter, commandType: CommandType.StoredProcedure);
			return 0;
		}
	}
}
