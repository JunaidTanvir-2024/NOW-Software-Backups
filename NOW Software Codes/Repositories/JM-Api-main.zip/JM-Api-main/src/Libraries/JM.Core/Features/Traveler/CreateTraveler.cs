using FluentValidation;

using JM.Core.Features.Country;
using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Traveler;

public class CreateTraveler
{

	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public long UserId { get; set; }
		public long TripId { get; set; }
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.UserId).NotNull().NotEmpty().GreaterThan(0);
			RuleFor(x => x.TripId).NotNull().NotEmpty().GreaterThan(0);
		}
	}
	#endregion

	#region Response
	public sealed record Response
	{
		public required TripInfo Trip { get; set; }
		public IEnumerable<Traveler> Travelers { get; set; } = [];
		public sealed record TripInfo
		{
			public long Id { get; set; }
			public required string Name { get; set; }
			public DateTime StartingDate { get; set; }
			public long CreatorId { get; set; }
		}
		public sealed record Traveler
		{
			public required long Id { get; set; }
			public required string FullName { get; set; }
			public required string Email { get; set; }
		}
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		private readonly IMediator _mediator = mediator;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{
			var newTraveler = await _unitOfWork.TravelerRepository.AddTraveler(new Entities.Traveler()
			{
				UserId = query.UserId,
				TripId = query.TripId,
			});
			_unitOfWork.SaveChanges();

			var tripResult = (await _mediator.Send(new GetTrip.Query()
			{
				Id = query.TripId
			}));

			if (newTraveler is not null && tripResult.IsSuccess)
			{
				var trip = tripResult.TypedPayload<GetTrip.Response>();

				return ResultWrapper.Success(new Response()
				{
					Trip = new Response.TripInfo()
					{
						Id = trip?.Id ?? default,
						Name = trip?.Name!,
						StartingDate = trip?.StartingDate ?? default,
						CreatorId = trip?.CreatorId ?? default,
					},
					Travelers = trip?.Travelers.Select(x => new Response.Traveler()
					{
						Id = x.Id,
						Email = x.Email,
						FullName = x.FullName
					}) ?? default!
				});
			}
			return ResultWrapper.Failure(AppConstant.StatusKey.InternalServerError, AppConstant.StatusCode.InternalServerError);
		}
	}
	#endregion
}
