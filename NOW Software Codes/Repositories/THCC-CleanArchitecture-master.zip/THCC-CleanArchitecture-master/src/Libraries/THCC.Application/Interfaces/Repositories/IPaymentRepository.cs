﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Domain.Aggregates;

namespace THCC.Application.Interfaces.Repositories
{
    public interface IPaymentRepository : ServiceType.IScoped
    {
        Task<long> SaveOrderDetails(
                Order order,
                OrderItem orderItem,
                OrderPayment orderPayment,
                OrderCardPayment orderCardPayment,
                OrderPaypalPayment orderPaypalPayment,
                OrderPoint orderPoint,
                OrderHistory orderHistory);
        Task<OrderDetail> GetOrderDetails(long? orderId, string orderRef = null!);
        Task UpdateOrderHistoryStatus(
                long orderId,
                string transactionId,
                OrderStatus orderStatus,
                PaymentStatus paymentStatus,
                string errorMessage,
                string orderHistoryDesc);
        Task<Customer> GetCustomerByMerchantRef(string merchantRef);
        Task SaveOrderHistory(long orderId, string description);
    }
}