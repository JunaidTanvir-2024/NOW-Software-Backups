﻿using Microsoft.Extensions.Options;
using System.Net.Mail;
using System.Net;
using MimeKit;
using MailKit.Security;
using Microsoft.Extensions.Logging;

namespace SenderService.Core.Services.Mailing;

internal sealed class SmtpMailService : ISmtpMailService
{
    private readonly SmtpSettings _settings;
    private readonly ILogger<SmtpSettings> _logger;

    public SmtpMailService(
        IOptions<SmtpSettings> settings,
        ILogger<SmtpSettings> logger)
    {
        _settings = settings.Value;
        _logger = logger;
    }
    #region Email Senders

    public async Task<bool> SendAsync(MailRequest request, CancellationToken cancellationToken = default)
    {
        bool isEmailSentSuccessfully = false;
        if (_settings.DefaultSender.Mailkit == true)
        {
            return await MailKitSenderAsync(request, isEmailSentSuccessfully, cancellationToken);
        }
        else
        {
            return await SmtpSenderAsync(request, isEmailSentSuccessfully);
        }
    }
    private async Task<bool> MailKitSenderAsync(MailRequest request, bool isEmailSentSuccessfully, CancellationToken cancellationToken = default)
    {
        MimeMessage email = MailKitEmailBuilder(request);

        bool sentFromPrimary = false;
        try
        
        {
            using var smtp = new MailKit.Net.Smtp.SmtpClient();
            await smtp.ConnectAsync(_settings.PrimaryServer.Host, _settings.PrimaryServer.Port, SecureSocketOptions.None, cancellationToken);
            if (!string.IsNullOrEmpty(_settings.PrimaryServer.UserName) && !string.IsNullOrEmpty(_settings.PrimaryServer.Password))
            {
                await smtp.AuthenticateAsync(_settings.PrimaryServer.UserName, _settings.PrimaryServer.Password);
            }
            var sss = await smtp.SendAsync(email, cancellationToken);
            await smtp.DisconnectAsync(true, cancellationToken);
            sentFromPrimary = true;
            isEmailSentSuccessfully = true;
        }
        catch (Exception ex)
        {
            // Log the exception
            _logger.LogError(ex, ex.Message);
        }

        // If email was not sent from the primary server, try sending from the secondary server
        if (!sentFromPrimary)
        {
            try
            {
                using var smtp = new MailKit.Net.Smtp.SmtpClient();
                await smtp.ConnectAsync(_settings.SecondaryServer.Host, _settings.SecondaryServer.Port, SecureSocketOptions.None, cancellationToken);
                if (!string.IsNullOrEmpty(_settings.SecondaryServer.UserName) && !string.IsNullOrEmpty(_settings.SecondaryServer.Password))
                {
                    await smtp.AuthenticateAsync(_settings.SecondaryServer.UserName, _settings.SecondaryServer.Password);
                }
                await smtp.SendAsync(email, cancellationToken);
                await smtp.DisconnectAsync(true, cancellationToken);
                isEmailSentSuccessfully = true;
            }
            catch (Exception ex)
            {
                // Log the exception
                _logger.LogError(ex, ex.Message);
            }
        }

        return isEmailSentSuccessfully;
    }

    private async Task<bool> SmtpSenderAsync(MailRequest request, bool isEmailSentSuccessfully, CancellationToken cancellationToken = default)
    {
        MailMessage message = SmtpEmailBuilder(request);

        // Added flag to check if email was sent from Primary server
        bool sentFromPrimary = false;
        try
        {
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback!);
            using var smtpClient = new SmtpClient(_settings?.PrimaryServer.Host, _settings!.PrimaryServer.Port);
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.EnableSsl = true;
            smtpClient.Credentials = new NetworkCredential(_settings?.PrimaryServer.UserName, _settings?.PrimaryServer.Password);
            await smtpClient.SendMailAsync(message);
            sentFromPrimary = true;
            isEmailSentSuccessfully = true;
        }
        catch (Exception)
        {
            //_logger.Error(ex, ex.Message);
        }
        if (!sentFromPrimary)
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback!);
                using var smtpClient = new SmtpClient(_settings?.SecondaryServer.Host, _settings!.SecondaryServer.Port);
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.EnableSsl = true;
                smtpClient.Credentials = new NetworkCredential(_settings?.SecondaryServer.UserName, _settings?.SecondaryServer.Password);
                await smtpClient.SendMailAsync(message, cancellationToken);
                isEmailSentSuccessfully = true;
            }
            catch (Exception)
            {
                //_logger.Error(ex2, ex2.Message);
            }
        }
        return isEmailSentSuccessfully;
    }
    #endregion

    #region Email Builders
    private MimeMessage MailKitEmailBuilder(MailRequest request)
    {
        var email = new MimeMessage();

        // From
        email.From.Add(new MailboxAddress(request.FromName ?? _settings.PrimaryServer.DisplayName, request.FromEmail ?? _settings.PrimaryServer.FromEmail));

        // To
        foreach (string address in request.ToEmails)
        {
            email.To.Add(MailboxAddress.Parse(address));
        }

        // Reply To
        if (!string.IsNullOrEmpty(request.ReplyToEmail))
        {
            email.ReplyTo.Add(new MailboxAddress(request.ReplyToName, request.ReplyToEmail));
        }

        // Bcc
        if (request.BccEmails != null)
        {
            foreach (string address in request.BccEmails.Where(bccValue => !string.IsNullOrWhiteSpace(bccValue)))
            {
                email.Bcc.Add(MailboxAddress.Parse(address.Trim()));
            }
        }

        // Cc
        if (request.CcEmails != null)
        {
            foreach (string? address in request.CcEmails.Where(ccValue => !string.IsNullOrWhiteSpace(ccValue)))
            {
                email.Cc.Add(MailboxAddress.Parse(address.Trim()));
            }
        }

        // Headers
        if (request.Headers != null)
        {
            foreach (var header in request.Headers)
            {
                email.Headers.Add(header.Key, header.Value);
            }
        }

        // Content
        var builder = new BodyBuilder();
        email.Sender = new MailboxAddress(request.DisplayName ?? _settings.PrimaryServer.DisplayName, request.FromEmail ?? _settings.PrimaryServer.FromEmail);
        email.Subject = request.Subject;
        builder.HtmlBody = request.Body;

        // Create the file attachments for this e-mail message
        if (request.AttachmentData != null)
        {
            foreach (var attachmentInfo in request.AttachmentData)
            {
                builder.Attachments.Add(attachmentInfo.Key, attachmentInfo.Value);
            }
        }

        email.Body = builder.ToMessageBody();
        return email;
    }
    private MailMessage SmtpEmailBuilder(MailRequest request)
    {
        var message = new MailMessage();

        // From
        message.From = new MailAddress(_settings.PrimaryServer.FromEmail!, _settings?.PrimaryServer.DisplayName);

        // To
        foreach (string address in request.ToEmails)
        {
            message.To.Add(new MailAddress(address));
        }

        // Reply To
        if (!string.IsNullOrEmpty(request.ReplyToEmail))
        {
            message.ReplyToList.Add(new MailAddress(request.ReplyToEmail, request.ReplyToName));
        }

        // Bcc
        if (request.BccEmails != null)
        {
            foreach (string address in request.BccEmails.Where(bccValue => !string.IsNullOrWhiteSpace(bccValue)))
            {
                message.Bcc.Add(new MailAddress(address.Trim()));
            }
        }

        // Cc
        if (request.CcEmails != null)
        {
            foreach (string? address in request.CcEmails.Where(ccValue => !string.IsNullOrWhiteSpace(ccValue)))
            {
                message.CC.Add(new MailAddress(address.Trim()));
            }
        }

        // Subject
        message.Subject = request.Subject;

        // Body
        message.IsBodyHtml = true;
        message.Body = request.Body;

        // Attachments
        if (request.AttachmentData != null)
        {
            foreach (var attachment in request.AttachmentData)
            {
                using (var stream = new MemoryStream(attachment.Value))
                {
                    message.Attachments.Add(new Attachment(stream, attachment.Key, "application/octet-stream"));
                }
            }
        }

        return message;
    }
    #endregion
    private bool RemoteServerCertificateValidationCallback(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
    {
        return true;
    }
}
