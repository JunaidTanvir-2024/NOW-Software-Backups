using static Voucherify.Core.Services.Http.HttpService;

namespace Voucherify.Core.Services.Http;

public interface IHttpService
{
    Task<(bool StatusCode, string ResponseBody)> DeleteAsync(string requestUri);
    HttpService EnableLogging();
    Task<(bool StatusCode, string ResponseBody)> GetAsync(string requestUri);
    Task<(bool StatusCode, string ResponseBody)> PostAsync(string requestUri, object? data = default);
    Task<(bool StatusCode, string ResponseBody)> PutAsync(string requestUri, object? data = default);
    HttpService WithBasicAuth(string username, string password);
    HttpService WithBearerAuth(string token);
    HttpService WithHeaders(IEnumerable<HttpServiceKeyValues> headers);
}
