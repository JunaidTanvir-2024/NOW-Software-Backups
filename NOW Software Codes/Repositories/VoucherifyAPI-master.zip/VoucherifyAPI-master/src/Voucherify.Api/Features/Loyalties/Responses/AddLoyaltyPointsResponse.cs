namespace Voucherify.Api.Features.Loyalties.Responses;

public class AddLoyaltyPointsResponse
{
    public string? EventName { get; set; }
    public string? CustomerId { get; set; }
}