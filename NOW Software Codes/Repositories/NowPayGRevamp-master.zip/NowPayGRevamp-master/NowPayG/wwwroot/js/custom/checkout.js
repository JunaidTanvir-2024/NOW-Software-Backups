﻿var postCodeValue = "";
function leaveChange() {
    if (document.getElementById("_statusDDL").value == "GBR") {
        $('#PostCodeSection').show();
        $('.AddressSection').hide();
    }
    else if ($('#_statusDDL').val() == "") {
        $('#PostCodeSection').hide();
        $('.AddressSection').hide();
        $('#dpl_SimOrderAddresses_sec').hide();
    }
    else {
        $('#PostCodeSection').hide();
        $('.AddressSection').show();
        $('#dpl_SimOrderAddresses_sec').hide();
    }
    $('#dpl_SimOrderAddresses').empty();
    $('#postcodeerror').hide();
    $("#AddressL1").val("");
    $("#AddressL2").val("");
    $("#AddressL3").val("");
    $("#AddressL4").val("");
    $("#City").val("");
    $("#County").val("");
    $("#Region").val("");
    $("#PostCode").val("");

}
$(document).ready(function () {
    
    //$("#PhoneNumber").focusout(function (){

    //    $.ajax({
    //        url: "/Account/ValidateMsisdn",
    //        type: "POST",
    //        data: { Msisdn: $('#PhoneNumber').val() },
    //        beforeSend: function (xhr) {

    //            $('#BtnValidatePaymentRequestSpinner').fadeIn();
    //            $('#BtnValidatePaymentRequest').attr('disabled', true);

    //            $('#Msisdn_Error_Checkout').text('').hide();
    //            $('#PhoneNumber').removeClass('input-validation-error');

    //        },
    //        success: function (response) {

    //            if (response != null) {
    //                if (response.status == true) {
    //                    return true;
    //                }
    //                else {
    //                    $('#PhoneNumber').addClass('input-validation-error');
    //                    $('#Msisdn_Error_Checkout').text(response.message).show();
    //                    return false;
    //                }
    //            }
    //            else {
    //                $('#Msisdn_Error_Checkout').text('Something went wrong on server.').show();
    //                return false;
    //            }

    //        },
    //        complete: function (xhr, status) {

    //            $('#BtnValidatePaymentRequestSpinner').fadeOut();
    //            $('#BtnValidatePaymentRequest').attr('disabled', false);

    //        },
    //        error: function (xhr, status, error) {

    //            $('#Msisdn_Error_Checkout').text('Something went wrong on server.').show();
    //            $('#PhoneNumber').addClass('input-validation-error');
    //            return false;

    //        }
    //    });

    //});

    $("#isAutoRenew").change(function () {

        //$("#isAutoRenew").prop("checked") == true
        if (this.checked) {
            $('#UsePaymentMethod').hide();
            $('#paypalCreditSimSec').hide();
        }
        else {
            $('#UsePaymentMethod').show();
            $('#paypalCreditSimSec').show();
        }

    });

    //To disable validation
    var settngs = $.data($('#CheckoutForm')[0], 'validator').settings;
    settngs.ignore = ".ignore,:hidden";
    //Validate Payment Request
    $('#BtnValidatePaymentRequest').click(function () {
        //Disable Validation
        if ($('#pills-paypal-tab').hasClass('active')) {
            if ($('#CheckoutForm').valid()) {
                if ($('#CheckoutPaymentType').val() == 1) {                //TopUp
                    $('#txtTopupAmount').text($('#Amount').val());
                    $('#Msisdn').val($('#PhoneNumber').val());
                }
                else if ($('#CheckoutPaymentType').val() == 2) {            //Fast-TopUp

                }
                else if ($('#CheckoutPaymentType').val() == 3) {            //Bundle
                    $('#Msisdn').val($('#PhoneNumber').val());
                }

                SetPay360PayemntData_checkout();
                if ($('#IsAuthenticated').val() == "False" && ($('#CheckoutPaymentType').val() == 1 || $('#CheckoutPaymentType').val() == 3)) {
                    ValidateNumber_checkout(function (output) {
                        if (output) {
                            ShowPopUp_ConfirmationStartPayment_checkout();
                        }
                    });
                }
                else {
                    SetPay360PayemntData_checkout();
                    ShowPopUp_ConfirmationStartPayment_checkout();
                }


                $("#payPalAutoMessage").hide();
                $("#pay-popup").css("max-width", "350px")
            }
            else
                return false;

        }
        else {

            if (document.getElementById("_statusDDL").value == "GBR" && $('#PostCode').val() != "" && $('#dpl_SimOrderAddresses').val() == null && $('#AddressL1').val() == "") {
                postCodeValue = $('#PostCode').val().trim();
                AddressLookup(function (output) {
                    return;
                });
            }
            else {
                if ($('#PostCode').val().trim() != postCodeValue && postCodeValue != "") {
                    postCodeValue = $('#PostCode').val().trim();
                    AddressLookup(function (output) {
                        return;
                    });
                }
                //else SetPay360PayemntData_checkout();
                else {
                    if (document.getElementById("_statusDDL").value == "GBR" && $('#PostCode').val() == "") {
                        $('.AddressSection').hide();
                    }
                    CheckoutFormValidation_checkout('enable');
                    if ($('#CheckoutForm').valid()) {


                        //if (!validator.form()) { return false; }
                        if ($('#CheckoutPaymentType').val() == 1) {                //TopUp
                            $('#txtTopupAmount').text($('#Amount').val());
                            $('#Msisdn').val($('#PhoneNumber').val());
                        }
                        else if ($('#CheckoutPaymentType').val() == 2) {            //Fast-TopUp

                        }
                        else if ($('#CheckoutPaymentType').val() == 3) {            //Bundle
                            $('#Msisdn').val($('#PhoneNumber').val());
                        }

                        SetPay360PayemntData_checkout();
                        if ($('#IsAuthenticated').val() == "False" && ($('#CheckoutPaymentType').val() == 1 || $('#CheckoutPaymentType').val() == 3)) {
                            ValidateNumber_checkout(function (output) {
                                if (output) {
                                    ShowPopUp_ConfirmationStartPayment_checkout();
                                }
                            });
                        }
                        else {
                            SetPay360PayemntData_checkout();
                            ShowPopUp_ConfirmationStartPayment_checkout();
                        }


                        $("#payPalAutoMessage").hide();
                        $("#pay-popup").css("max-width", "350px");
                    }
                    else {
                        //if ($('#dpl_SimOrderAddresses').val() == null) {
                        //    $('#PostCode').addClass('input-validation-error');
                        //    //$('#PostCode').data("val", "true").data('val-required', 'lookup post code');
                        //    return false;
                        //}
                        return false;
                    }
                }
            }
        }
    });

    //Sim Credit Payment
    $('#BtnPaySimCredit').click(function () {
        if ($('#nav-newcard').hasClass('active')) {
            $('#nav-newcard').hide();
        }
        else {
            $('#pills-tabContent').hide();
        }
        //Disable Validation
        CheckoutFormValidation_checkout('disable');

        //Set the PaypalForm to CheckOut
        $('#CheckoutForm').attr('action', '/Account/AddBundleViaSimCredit');
        $('#Msisdn').val($('#PhoneNumber').val());

        //Open PopUp
        ShowPopUp_ConfirmationStartPayment_checkout();

        $("#payPalAutoMessage").hide();
        $("#pay-popup").css("max-width", "350px");

    });

    //Set Amount From Radio buttons In Case of TopUp
    $('input[type=radio][name=Amount]').change(function () {
        $('#Amount').val($(this).val());
    });

    //Start Payment
    $('#BtnStartPayment').click(function () {
        $('#CheckoutForm').submit();
    })
    $('#BtnPaymentCancelOnPopup').click(function () {
       
        $('#pills-tabContent').show();
    });
    //Agree Terms Error
    AgreeTermsCheckboxValidation_checkout();
    $('#AgreeTerms').change(function () {
        $(this).valid();
    });

    //PayPal Button When User is Authenticated
    $('#Btn_Auth_PayPalMethod').click(function () {
        if ($('#nav-newcard').hasClass('active')) {
            $('#nav-newcard').hide();
        }
        else {
            $('#pills-tabContent').hide();
        }
        //Disable Validation
        CheckoutFormValidation_checkout('disable');
        //Set the PaypalForm to CheckOut

        var IsPay360PayPalPayment = $("#Pay360PayPalPayment").val();
        if (IsPay360PayPalPayment == "true") {
            $('#CheckoutForm').attr('action', '/PayPal/Pay360Payment');
        } else {
            $('#CheckoutForm').attr('action', '/PayPal/Payment');
        }


        if ($('#CheckoutPaymentType').val() == 1) {                 //TopUp
            $('#txtTopupAmount').text($('#Amount').val());
            $('#Msisdn').val($('#PhoneNumber').val());
        }
        else if ($('#CheckoutPaymentType').val() == 2) {            //Fast-TopUp

        }
        else if ($('#CheckoutPaymentType').val() == 3) {            //Bundle
            $('#Msisdn').val($('#PhoneNumber').val());
        }

        if ($("#isAutoRenew").prop("checked") == true || $("#AutopToupToggle_topup_checkout").prop("checked") == true) {
            $('#isAutoRenew').bootstrapToggle('toggle');
            $('#AutopToupToggle_topup_checkout').bootstrapToggle('toggle');
            $("#payPalAutoMessage").show();
            $("#pay-popup").css("max-width", "480px");
        }
        else {
            $("#payPalAutoMessage").hide();
            $("#pay-popup").css("max-width", "350px");
        }
        //Open PopUp
        ShowPopUp_ConfirmationStartPayment_checkout();

    });

    //Set AutoTopup Value In case of TopUp
    $('#AutopToupToggle_topup_checkout').change(function myfunction() {
        $('#AutoTopUp').val($(this).is(":checked"));
    });

    $('#PhoneNumber').keyup(function () {
        // Remove Validations Error
        $('#Msisdn_Error_Checkout').text('').hide();
        $('#PhoneNumber').removeClass('input-validation-error');
    });

});


//Pay360 Payment Settings
function SetPay360PayemntData_checkout() {
    if ($('#pills-paypal-tab').hasClass('active')) {
        var IsPay360PayPalPayment = $("#Pay360PayPalPayment").val();
        if (IsPay360PayPalPayment == "true") {
            $('#CheckoutForm').attr('action', '/PayPal/Pay360Payment');
        } else {
            $('#CheckoutForm').attr('action', '/PayPal/Payment');
        }
    }
    else {
        $('#CheckoutForm').attr('action', '/StartPayment');

        if ($('#IsAuthenticated').val() == "True") {

            if ($('.pay360cards').length > 0) {

                if ($('.pay360cards').hasClass('active')) {

                    if ($('.pay360cards.active').hasClass('default')) {

                        $('#UserCard_Token').val($('.pay360cards.active')[0].dataset.cardtoken);
                        $('#Pay360PaymentType').val(2);  //Default
                    }
                    else {
                        $('#UserCard_Token').val($('.pay360cards.active')[0].dataset.cardtoken);
                        $('#Pay360PaymentType').val(2);  //Token
                    }
                }
                else {
                    if ($('#pay360Newcard').hasClass('active')) {
                        $('#Pay360PaymentType').val(3);  //ExistingNew
                    }
                }
            }
            else {
                $('#Pay360PaymentType').val(0);  //New
            }

        } else {
            $('#Pay360PaymentType').val(0); //New
        }
    }
}

//Handle Overall form Validation
function CheckoutFormValidation_checkout(Type) {

    if (Type == 'enable') {   //If Enabled

        $('#UserCard_NameOnCard').removeClass('ignore');
        $('#UserCard_CardNumber').removeClass('ignore');
        $('#UserCard_ExpiryMonth').removeClass('ignore');
        $('#UserCard_ExpiryYear').removeClass('ignore');
        $('#UserCard_SecurityCode').removeClass('ignore');
        $('#UserCard_Token').removeClass('ignore');

        $('#SecurityCode').removeClass('ignore');
    }
    else {

        $('#UserCard_NameOnCard').addClass('ignore');
        $('#UserCard_CardNumber').addClass('ignore');
        $('#UserCard_ExpiryMonth').addClass('ignore');
        $('#UserCard_ExpiryYear').addClass('ignore');
        $('#UserCard_SecurityCode').addClass('ignore');
        $('#UserCard_Token').addClass('ignore');

        $('#SecurityCode').addClass('ignore');
    }

}

//OpenPopup
function ShowPopUp_ConfirmationStartPayment_checkout() {

    $.magnificPopup.close();
    $.magnificPopup.open({
        items: {
            src: '#pay-popup', // can be a HTML string, jQuery object, or CSS selector
            type: 'inline',
            closeOnContentClick: true,
        }
    });
    $('html').css('margin-right', 0);
}

//Agree Terms Validation Method
function AgreeTermsCheckboxValidation_checkout() {

    // extend jquery range validator to work for required checkboxes
    var defaultRangeValidator = $.validator.methods.range;
    $.validator.methods.range = function (value, element, param) {
        if (element.type === 'checkbox') {
            // if it's a checkbox return true if it is checked
            return element.checked;
        } else {
            // otherwise run the default validation function
            return defaultRangeValidator.call(this, value, element, param);
        }
    }

}




// Validate Msisdn 
function MsisdnValidation_checkout(evt) {

    
    var TotalLength = $("#" + evt.currentTarget.id).val().length;
    var theEvent = evt || window.event;

    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }

    // Regex
    var regex = /[0-9]/;
    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }
    // length
    if (TotalLength >= 12) {
        theEvent.returnValue = false;
        theEvent.preventDefault();
    }

    //$.ajax({
    //    url: "/Account/ValidateMsisdn",
    //    type: "POST",
    //    data: { Msisdn: $('#PhoneNumber').val() },
    //    beforeSend: function (xhr) {         
    //    },
    //    success: function (response) {
    //        if (response != null) {
    //            if (response.status == true && response.errorCode == 0) {

    //                //Not Valid
    //                if (response.data == 1) {
    //                    theEvent.returnValue = false;
    //                    theEvent.preventDefault();
    //                }
    //                else if (response.data == 2 || response.data == 3 || response.data == 4) {
    //                    theEvent.returnValue = true;
    //                }
    //                else if (response.data == 5) {
    //                    $("#home_AutoTopUpSection").show();
    //                    theEvent.returnValue = true;
    //                }
    //                else if (response.data == 6) {
    //                    theEvent.returnValue = true;
    //                }
    //            }
    //            else {
    //                theEvent.returnValue = false;
    //                theEvent.preventDefault();
    //            }
    //        }
    //        else {
    //            theEvent.returnValue = false;
    //            theEvent.preventDefault();
    //        }
    //    },
    //    complete: function (xhr, status) {
           
    //    },
    //    error: function (xhr, status, error) {
    //        theEvent.returnValue = false;
    //        theEvent.preventDefault();
    //    }
    //});


}

// Validate CardNumber
function CardNumberValidation_checkout(evt) {

    var theEvent = evt || window.event;

    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }

    // Regex
    var regex = /[0-9]/;
    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }
}

//Validate Number 
function ValidateNumber_checkout(ValidateCallBack) {

    $.ajax({
        url: "/Account/ValidateMsisdn",
        type: "POST",
        data: { Msisdn: $('#PhoneNumber').val() },
        beforeSend: function (xhr) {

            $('#BtnValidatePaymentRequestSpinner').fadeIn();
            $('#BtnValidatePaymentRequest').attr('disabled', true);

            $('#Msisdn_Error_Checkout').text('').hide();
            $('#PhoneNumber').removeClass('input-validation-error');

        },
        success: function (response) {

            if (response != null) {
                if (response.status == true) {
                    ValidateCallBack(true);
                }
                else {
                    $('#PhoneNumber').addClass('input-validation-error');
                    $('#Msisdn_Error_Checkout').text(response.message).show();
                    ValidateCallBack(false);
                }
            }
            else {
                $('#Msisdn_Error_Checkout').text('Something went wrong on server.').show();
                ValidateCallBack(false);
            }

        },
        complete: function (xhr, status) {

            $('#BtnValidatePaymentRequestSpinner').fadeOut();
            $('#BtnValidatePaymentRequest').attr('disabled', false);

        },
        error: function (xhr, status, error) {

            $('#Msisdn_Error_Checkout').text('Something went wrong on server.').show();
            $('#PhoneNumber').addClass('input-validation-error');
            ValidateCallBack(false);

        }
    });

}

//Validate SecurityCode
function SecurityCode_Validation_checkOut(evt) {

    var theEvent = evt || window.event;
    var TotalLength = $("#" + evt.currentTarget.id).val().length;


    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }

    var regex = /[0-9]/;

    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }

    // length
    if (TotalLength >= 4) {
        theEvent.returnValue = false;
        theEvent.preventDefault();
    }
}

//Check Topup Status
function GetTopupStatus_checkout(control) {

    $.ajax({
        url: "/Pay360/GetAutoTopup",
        type: "POST",
        data: { productRef: $(control).val() },
        beforeSend: function (xhr) {
            $('.loading-bar').show();
        },
        success: function (response) {
            console.log(response);
            if (response != null && response.status == true) {
                $('#AutopToupToggle_topup_checkout').bootstrapToggle((response.data.status == true ? 'on' : 'off'))
            }
            else {
            }
        },
        complete: function (xhr, status) {
            $('.loading-bar').hide();
        },
        error: function (xhr, status, error) {

        }
    });


}