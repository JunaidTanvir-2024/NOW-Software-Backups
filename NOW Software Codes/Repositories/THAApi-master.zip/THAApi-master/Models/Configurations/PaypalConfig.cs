﻿namespace Models.Configurations
{
	public class CallBackSettings
	{
		public const string SectionName = "CallBackSettings";
		public static CallBackSettings Bind = new CallBackSettings();
		public string WebBaseUrl { get; set; }
		public string AppBaseUrl { get; set; }
	}
	public class PayPalConfig
    {
        public string PayPalApiEndpoint { get; set; }
        public string PayPalByP630ApiEndpoint { get; set; }
        public bool IsPaypalByPay360 { get; set; }
        public bool IsDirectFullfilment { get; set; }
        public bool IsTransferAutoRefund { get; set; }
        public bool sendPay360Email { get; set; }
        public string AppPaymentCallBackUrl { get; set; }
        public string AppPaymentTransferCallBackUrl { get; set; }
        public string AppCancelCallBackUrl { get; set; }
        public string AppCancelTransferCallBackUrl { get; set; }
        public string WebPaymentCallBackUrl { get; set; }
        public string WebCancelCallBackUrl { get; set; }
        public string AppSubscriptionCallBackUrl { get; set; }
        public string WebSubscriptionCallBackUrl { get; set; }

    }
}
