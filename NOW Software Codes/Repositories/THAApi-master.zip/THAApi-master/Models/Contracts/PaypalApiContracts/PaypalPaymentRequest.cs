﻿using Models.Contracts.Request.Voucherify;
using Models.Enums;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Models.Contracts.PaypalApiContracts
{
	public class PaypalPaymentRequest
	{
		public string CustomerName { get; set; }
		public string Msisdn { get; set; } = default!;
		public string Email { get; set; } = default!;
		public CheckOutTypes CheckoutType { get; set; } = default!;
		public string BundleUuid { get; set; }
		public decimal BundleAmount { get; set; }
		public decimal BundleDiscount { get; set; }
		public decimal TopupAmount { get; set; }
		public decimal TopupDiscount { get; set; }
		public decimal TransferAmount { get; set; }
        public decimal TransferDiscount { get; set; }
        public string TransferDestinationMsisdn { get; set; }
        public string IpAddress { get; set; } = default!;
		public bool IsAppRequest { get; set; }
		public bool IsFastTopup { get; set; } = false;
		public int OrderId { get; set; }
		public string Currency { get; set; }
		public int? NoOfCycles { get; set; }
		public string FollowedByBundleRef { get; set; }
		public decimal? FollowedByBundleAmount { get; set; }
		public int? FollowedByBundleNoOfCycles { get; set; }
	}
	public class PaypalPaymentCallbackData
	{
		public CheckOutTypes CheckoutType { get; set; }
		public string Token { get; set; }
        public string PayerId { get; set; }
        public string PaymentId { get; set; }
        public int? PTId { get; set; }
        public string BundleId { get; set; }
        public decimal TopupAmount { get; set; }
        public string TransferNowtelRef { get; set; }
        public string TransferProduct { get; set; }
        public int? TransferOperatorId { get; set; }
        public string Msisdn { get; set; }
        public int? ThemeMode { get; set; }
        public string IpAddress { get; set; }
        public string AdvertiserId { get; set; }
        public bool AirshipEventsDisable { get; set; }
        public bool IsTransferRequest { get; set; }
        public string Culture { get; set; }
        public string AppsFlyerId { get; set; }
        public int? DeviceType { get; set; }
        public string DiscountCode { get; set; }
        public DiscountCodeType DiscountCodeType { get; set; }
        public string UtmCampaign { get; set; }
        public string UtmMedium { get; set; }
        public string UtmSource { get; set; }
        public string Email { get; set; }
        public string ToQueryString()
		{
			var queryParameters = HttpUtility.ParseQueryString(string.Empty);
			var properties = TypeDescriptor.GetProperties(typeof(PaypalPaymentCallbackData));
			foreach (PropertyDescriptor item in properties)
			{
				queryParameters.Add(item.Name, item.GetValue(this)?.ToString()??default);
			}
			return queryParameters.ToString();
		}
	}
}
