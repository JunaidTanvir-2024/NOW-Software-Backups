﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
   public class UpdatePlanStatusModel
    {
        public int StatusID { get; set; }
        public int PlanID { get; set; }
    }
}
