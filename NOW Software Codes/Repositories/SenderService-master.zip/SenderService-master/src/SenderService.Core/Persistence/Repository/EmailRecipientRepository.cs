﻿using Microsoft.EntityFrameworkCore;
using SenderService.Core.Persistence.Entities;

namespace SenderService.Core.Persistence.Repository;

public interface IEmailRecipientRepository
{
    Task AddBulkEmailRecipientAsync(List<EmailRecipient> emailRecipient);
    Task AddEmailRecipientAsync(EmailRecipient emailRecipient);
    Task DeleteEmailRecipientAsync(long id);
    Task<List<EmailRecipient>> GetAllAsync();
    Task<List<EmailRecipient>> GetByEmailIdAsync(long emailId);
    Task<EmailRecipient?> GetByIdAsync(long id);
    Task UpdateEmailRecipientAsync(EmailRecipient emailRecipient);
}

internal sealed class EmailRecipientRepository : IEmailRecipientRepository
{
    private readonly SenderServiceContext _dbContext;

    public EmailRecipientRepository(SenderServiceContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<EmailRecipient?> GetByIdAsync(long id)
    {
        return await _dbContext.Set<EmailRecipient>().FirstOrDefaultAsync(x => x.Id == id);
    }

    public async Task<List<EmailRecipient>> GetAllAsync()
    {
        return await _dbContext.Set<EmailRecipient>().ToListAsync();
    }

    public async Task<List<EmailRecipient>> GetByEmailIdAsync(long emailId)
    {
        return await _dbContext.Set<EmailRecipient>().Where(r => r.EmailId == emailId).ToListAsync();
    }

    public async Task AddEmailRecipientAsync(EmailRecipient emailRecipient)
    {
        _dbContext.Set<EmailRecipient>().Add(emailRecipient);
        await _dbContext.SaveChangesAsync();
    }
    public async Task AddBulkEmailRecipientAsync(List<EmailRecipient> emailRecipient)
    {
        await _dbContext.Set<EmailRecipient>().AddRangeAsync(emailRecipient);
        await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateEmailRecipientAsync(EmailRecipient emailRecipient)
    {
        _dbContext.Set<EmailRecipient>().Update(emailRecipient);
        await _dbContext.SaveChangesAsync();
    }

    public async Task DeleteEmailRecipientAsync(long id)
    {
        var emailRecipient = await GetByIdAsync(id);
        if (emailRecipient != null)
        {
            _dbContext.Set<EmailRecipient>().Remove(emailRecipient);
            await _dbContext.SaveChangesAsync();
        }
    }
}
