﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Configurations
{
    public class SmtpConfig
    {
        public string server { get; set; }
        public string from { get; set; }
        public string fromForNowPayGSignUp { get; set; }
        public string userName { get; set; }
        public string password { get; set; }
        public string[] to { get; set; }
        public string[] cc { get; set; }
        public string[] bcc { get; set; }
        public string subjectSignUp { get; set; }
    }
}
