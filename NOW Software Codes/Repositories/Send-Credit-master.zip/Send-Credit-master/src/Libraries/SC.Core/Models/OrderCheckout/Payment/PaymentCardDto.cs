﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SC.Core.Models.OrderCheckout.Payment;
public class PaymentCardDto
{
    public PaymentCardType CardType { get; set; }
    public NewPaymentCardDto NewCard { get; set; } = default!;
    public ExistingPaymentCardDto ExistingCard { get; set; } = default!;
}
public class ExistingPaymentCardDto
{
    public string Token { get; set; } = default!;
    public string CV2 { get; set; } = default!;
    public CardUpdateDto? CardUpdate { get; set; }
}

public class CardUpdateDto
{
    public string ExpiryDate { get; set; } = default!;
    public BillingAddressDto? BillingAddress { get; set; }
}
public class NewPaymentCardDto
{
    public string Pan { get; set; } = default!;
    public string CardHolderName { get; set; } = default!;
    public string ExpiryDate { get; set; } = default!;
    public string CV2 { get; set; } = default!;
    public bool DefaultCard { get; set; }
    public bool SaveCard { get; set; }
    public BillingAddressDto? BillingAddress { get; set; }
}

