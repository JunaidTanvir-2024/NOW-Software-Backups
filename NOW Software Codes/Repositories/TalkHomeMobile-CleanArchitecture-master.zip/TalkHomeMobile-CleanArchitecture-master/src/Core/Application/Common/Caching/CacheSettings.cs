﻿namespace Application.Common.Caching;

public class CacheSettings
{
    public bool UseCache { get; set; }
    public int SlidingExpirationSeconds { get; set; }
}
