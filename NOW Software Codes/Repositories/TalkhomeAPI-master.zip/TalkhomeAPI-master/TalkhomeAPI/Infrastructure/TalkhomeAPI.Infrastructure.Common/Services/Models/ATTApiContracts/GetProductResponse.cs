﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.ATTApiContracts
{
    public class GetProductResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCodeDtOne { get; set; }
        public int errorCode { get; set; }
        public int servcieproviderid { get; set; }
        public AttPayLoad payload { get; set; }
    }

    public class AttPayLoad
    {
        public List<AttOperator> operators { get; set; }
    }

    public class AttOperator
    {
        public string id { get; set; }
        public string name { get; set; }
        public string country { get; set; }
        public string nowtelTransactionReference { get; set; }
        public string iconUri { get; set; }
        public List<AttProduct> products { get; set; }
        public int accessid { get; set; }
    }

    public class AttProduct
    {
        public string clientccy { get; set; }
        public string receiverccy { get; set; }
        public string product { get; set; }
        public string itemPriceClientccy { get; set; }
        public string transactionfeeClientccy { get; set; }
        public string totalPriceClientccy { get; set; }
    }

    public class ExecuteDataRequest
    {
        public string nowtelTransactionReference { get; set; }
        public string operatorid { get; set; }
        public string product { get; set; }
        public string messageToRecipient { get; set; }
        public string fromMSISDN { get; set; }
    }

    public class ExecuteDataResponse
    {
        public string errorCode { get; set; }
        public string errorCodeDtOne { get; set; }
        public string status { get; set; }
        public string message { get; set; }
        public string amount { get; set; }
        public string currency { get; set; }
        public string reference { get; set; }
    }
}
