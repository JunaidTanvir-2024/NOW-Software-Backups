﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Configurations
{
    public class ResendPinConfig
    {
        public bool Sap_IsActive { get; set; }
        public string[] Sap_Countries { get; set; }
        public SmsGateway SmsGateWay { get; set; }
    }
}
