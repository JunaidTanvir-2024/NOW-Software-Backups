﻿using Dapper;
using Microsoft.Extensions.Options;
using NowPayGApi.Infrastructure.DAL.Interfaces;
using NowPayGApi.Models.Configurations;
using NowPayGApi.Models.DAOs;
using NowPayGApi.Models.DAOs.Digitalk;
using NowPayGApi.Models.DbConnections;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace NowPayGApi.Infrastructure.DAL.Impelmentation
{
    public class DL_Digitalk : IDL_Digitalk
    {
        private readonly IDbConnectionSettings Db;
        private readonly IDbConnectionSettings NowMobileRepDB;

        public DL_Digitalk(IOptions<ConnectionString> connectionString)
        {
            Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigitalkMobileDbConnection));
            NowMobileRepDB = new DbConnectionSettings(new SqlConnection(connectionString.Value.NowMobileRepDbConnection));
        }

        public async Task<MobileAccount> GetUserAccount(string msisdn)
        {
            MobileAccount mb = new MobileAccount();
            var storedProcedure = "now_get_mobile_account";
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                mb = await Db.SqlConnection.QueryFirstOrDefaultAsync<MobileAccount>(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);

            }
            catch
            {
                throw;
            }
            return mb;
        }

        public async Task<MobileAccount> GetUserAccountByAccountID(string account)
        {
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@account", account);

                var result = await Db.SqlConnection.QueryFirstOrDefaultAsync<MobileAccount>("now_get_account_summary_details", parameter, commandType: CommandType.StoredProcedure);

                return result;
            }
            catch
            {
                return null;
            }
        }

        public async Task<UserAccountLastTopup> GetLastTopUp(string accountId)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@account", accountId);

                var lastTopup = await Db.SqlConnection.QueryFirstOrDefaultAsync<UserAccountLastTopup>("now_getLastTopup", parameters,
                        commandType: CommandType.StoredProcedure);

                return lastTopup;
            }
            catch
            {
                return null;
            }
        }

        public async Task<IEnumerable<Bundle>> GetUserAccountBundles(string accountId)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@account", accountId);

                var Bundles = await Db.SqlConnection.QueryAsync<Bundle>("now_get_account_bundles", parameters,
                        commandType: CommandType.StoredProcedure);

                return Bundles;
            }
            catch
            {
                return null;
            }
        }

        public async Task<DBResultAddBundle> AddBundleViaSimCredit(string account, string bundleId)
        {
            var garb = new DBResultAddBundle();
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@account", account);
                parameter.Add("@bundle_id", bundleId);
                parameter.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameter.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);
                var bds = await Db.SqlConnection.QueryAsync("now_web_AccountsAddBundle", parameter, commandType: CommandType.StoredProcedure);
                int errorCode = parameter.Get<int>("@error_code");
                string errorMsg = parameter.Get<string>("@error_msg");
                if (errorCode == 0) // Success
                {
                    garb.error_code = errorCode;
                    garb.error_msg = "Success";
                }
                else // Failure
                {
                    garb.error_msg = "Bundle addition failed. " + errorMsg;
                    garb.error_code = errorCode;
                }
            }
            catch
            {
                throw;
            }
            return garb;
        }

        public async Task<DBResultAddBundle> SetBundleAutoRenewal(bool isAutoRenew, string Msisdn, string account, string bundleId,string ProductCode,string Email,int bundleAmount)
        {
            var garb = new DBResultAddBundle();
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@isRenew", isAutoRenew);
                parameter.Add("@msisdn", Msisdn);
                parameter.Add("@account", account);
                parameter.Add("@bundle_id", bundleId);
                parameter.Add("@bundle_Amount", bundleAmount);
                parameter.Add("@product_code", ProductCode);
                parameter.Add("@email", Email);
                parameter.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameter.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);
                var abr = await Db.SqlConnection.QueryAsync("now_bundle_set_auto_renewals_status", parameter, commandType: CommandType.StoredProcedure);

                int errorCode = parameter.Get<int>("@error_code");
                string errorMsg = parameter.Get<string>("@error_msg");

                if (errorCode == 0) // Success
                {
                    garb.error_code = errorCode;
                    garb.error_msg = errorMsg;
                }
                else // Failure
                {
                    garb.error_msg = "Bundle addition failed. " + errorMsg;
                    garb.error_code = errorCode;
                }

            }
            catch(Exception ex)
            {

            }
            return garb;

        }

        public async Task<IEnumerable<DbCallingHistory>> GetCallHistory(string accountId, int pagenumber, int rowsperpage)
        {
            var parameter = new DynamicParameters();

            parameter.Add("@Account", accountId);
            parameter.Add("@PageNumber", pagenumber);
            parameter.Add("@RowsPerPage", rowsperpage);
            parameter.Add("@ErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameter.Add("@ErrorMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

            var result = await NowMobileRepDB.SqlConnection.QueryAsync<DbCallingHistory>("Now_WebApiCallHistory_Paging_v2", parameter, commandType: CommandType.StoredProcedure);

            int errorCode = parameter.Get<int>("@ErrorCode");
            string errorMsg = parameter.Get<string>("@ErrorMessage");

            if (errorCode == 0)
            {
                return result;
            }

            return null;
        }

        public async Task<int> GetCallHistoryTotalCount(string accountId)
        {
            var parameter = new DynamicParameters();

            parameter.Add("@Account", accountId);
            parameter.Add("@ErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameter.Add("@ErrorMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

            var callhistoryList = await NowMobileRepDB.SqlConnection.QueryFirstAsync<int>("Now_WebApiCallHistory_total_count_v2", parameter, commandType: CommandType.StoredProcedure);

            int errorCode = parameter.Get<int>("@ErrorCode");
            string errorMsg = parameter.Get<string>("@ErrorMessage");

            if (errorCode == 0)
            {
                return callhistoryList;
            }

            return 0;
        }

        public async Task<IEnumerable<DBSmsHistory>> GetSmsHistory(string accountId, int pagenumber, int rowsperpage)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@account", accountId);
            parameters.Add("@PageNumber", pagenumber);
            parameters.Add("@RowsPerPage", rowsperpage);
            parameters.Add("@ErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@ErrorMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

            var smsHistoryList = await NowMobileRepDB.SqlConnection.QueryAsync<DBSmsHistory>("Now_WebApismsHistory_Paging_v2", parameters, commandType: CommandType.StoredProcedure);

            int errorCode = parameters.Get<int>("@ErrorCode");

            if (errorCode == 0)
            {
                return smsHistoryList;
            }

            return null;
        }

        public async Task<int> GetSmsHistoryTotalCount(string accountId)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@account", accountId);
            parameters.Add("@ErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@ErrorMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

            var callHistoryPageCount = await NowMobileRepDB.SqlConnection.QueryFirstAsync<int>("Now_WebApiSMSHistory_total_count_v2", parameters, commandType: CommandType.StoredProcedure);
            int errorCode = parameters.Get<int>("@ErrorCode");

            if (errorCode == 0)
            {
                return callHistoryPageCount;
            }

            return 0;
        }

        public async Task<IEnumerable<DBDataHistory>> GetDataHistory(string accountId, int pagenumber, int rowsperpage)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@account", accountId);
            parameters.Add("@PageNumber", pagenumber);
            parameters.Add("@RowsPerPage", rowsperpage);
            parameters.Add("@ErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@ErrorMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

            var smsHistoryList = await NowMobileRepDB.SqlConnection.QueryAsync<DBDataHistory>("Now_WebApigprsHistory_Paging_v2", parameters, commandType: CommandType.StoredProcedure);

            int errorCode = parameters.Get<int>("@ErrorCode");

            if (errorCode == 0)
            {
                return smsHistoryList;
            }

            return null;
        }

        public async Task<int> GetDataHistoryTotalCount(string accountId)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@account", accountId);
            parameters.Add("@ErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@ErrorMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

            var callHistoryPageCount = await NowMobileRepDB.SqlConnection.QueryFirstAsync<int>("Now_WebApiGPRSHistory_total_count_v2", parameters, commandType: CommandType.StoredProcedure);
            int errorCode = parameters.Get<int>("@ErrorCode");

            if (errorCode == 0)
            {
                return callHistoryPageCount;
            }

            return 0;
        }

        public async Task<IEnumerable<DBPaymentHistory>> GetPaymentHistory(string accountId, int pagenumber, int rowsperpage)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@account", accountId);
            parameters.Add("@PageNumber", pagenumber);
            parameters.Add("@RowsPerPage", rowsperpage);
            parameters.Add("@ErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@ErrorMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

            var smsHistoryList = await NowMobileRepDB.SqlConnection.QueryAsync<DBPaymentHistory>("Now_WebApiPaymentHistory_Paging_v2", parameters, commandType: CommandType.StoredProcedure);

            int errorCode = parameters.Get<int>("@ErrorCode");

            if (errorCode == 0)
            {
                return smsHistoryList;
            }

            return null;
        }

        public async Task<int> GetPaymentHistoryTotalCount(string accountId)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@account", accountId);
            parameters.Add("@ErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@ErrorMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

            var callHistoryPageCount = await NowMobileRepDB.SqlConnection.QueryFirstAsync<int>("Now_WebApiPaymentHistory_total_count_v2", parameters, commandType: CommandType.StoredProcedure);
            int errorCode = parameters.Get<int>("@ErrorCode");

            if (errorCode == 0)
            {
                return callHistoryPageCount;
            }

            return 0;
        }
    }
}