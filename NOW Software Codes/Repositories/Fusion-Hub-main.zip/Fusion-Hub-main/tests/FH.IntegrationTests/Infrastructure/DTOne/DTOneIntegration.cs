using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.VisualStudio.TestPlatform.TestHost;

namespace FH.IntegrationTests.Infrastructure.DTOne;
internal class DTOneIntegration : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public DTOneIntegration(WebApplicationFactory<Program> factory)
    {
        _factory = factory;
    }

}
