﻿using Infrastructure.BLL.Implementation;
using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.DAL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace Infrastructure.BLL.Services
{
    public class TwillioService : ITwillioService
    {
        private readonly ILogger Logger;
        private readonly TwillioConfig TwillioConfig;
        private readonly IUserAccount_DL UserAccount_DL;
        private readonly IPhoneNumberService phoneNumberService;

        public TwillioService(ILogger logger, IOptions<TwillioConfig> twillioConfig, IUserAccount_DL userAccount_DL, IPhoneNumberService phoneNumberService)
        {
            Logger = logger;
            TwillioConfig = twillioConfig.Value;
            UserAccount_DL = userAccount_DL;
            this.phoneNumberService = phoneNumberService;
        }
        private string ParseNumber(string number)
        {
            var returnNumber = number.Replace("+", "");

            return returnNumber.StartsWith("00") ? returnNumber.Remove(0, 2) : returnNumber;
        }
        public async Task<bool> Send(string to, string message, bool isSignupPinSms)
        {
            try
            {
                Sms smsStatus = null;
                var toCountryCode = phoneNumberService.GetCountry(to);
                string from = !string.IsNullOrEmpty(toCountryCode) ? TwillioConfig.CountryBaseSenders.TryGetValue(toCountryCode, out var sender) ? sender : TwillioConfig.CountryBaseSenders["Default"] : TwillioConfig.CountryBaseSenders["Default"];
                string formattedTo = to;
                var accountSid = "";
                var authToken = "";
                if (TwillioConfig.Route == "1")
                {
                    if (to.StartsWith("32") ||
                        to.StartsWith("92") ||
                        to.StartsWith("966") ||
                        to.StartsWith("90") ||
                        to.StartsWith("1") ||
                        to.StartsWith("65"))
                    {
                        from = "+1947-333-9544";
                        if (!to.StartsWith("+"))
                            to = "+" + to;
                    }
                    accountSid = TwillioConfig.AccountSid;
                    // Your Auth Token from twilio.com/console
                    authToken = TwillioConfig.AuthToken;
                }
                else
                {
                    if (to.StartsWith("32") ||
                        to.StartsWith("92") ||
                        to.StartsWith("966") ||
                        to.StartsWith("90") ||
                        to.StartsWith("65"))
                    {
                        from = "+1865-424-2403";
                        if (!to.StartsWith("+"))
                            to = "+" + to;
                    }
                    accountSid = TwillioConfig.AccountSid2;
                    // Your Auth Token from twilio.com/console
                    authToken = TwillioConfig.AuthToken2;
                }
                string formattedFrom = from;
                try
                {
                    if (!isSignupPinSms)
                    {
                        formattedFrom = ParseNumber(from);
                        if (formattedFrom.ToLower() != "talk home")
                        {
                            formattedTo = PhoneNumberFixer.Fix(formattedTo);
                        }
                    }

                    //Record our version
                    smsStatus = new Sms
                    {
                        Provider = Provider.Twilio,
                        Sender = formattedFrom,
                        To = formattedTo,
                        Status = Status.Pending,
                        Sent = DateTime.UtcNow,
                        ProviderError = null,
                        ProviderId = null
                    };

                    int result = await UserAccount_DL.SaveSms(smsStatus);
                }
                catch (Exception ex)
                {
                    Logger.Warning(ex.ToString());
                }

                try
                {
                    TwilioClient.Init(accountSid, authToken);

                    var response = await MessageResource.CreateAsync(
                        to: new PhoneNumber(to),
                        from: new PhoneNumber(from),
                        body: message);

                    Logger.Warning($"Twilio Signup SMS {to} , {response.Sid}");

                }
                catch (Exception ex)
                {
                    Logger.Warning("Error on Twilio Signup SMS send: " + ex.ToString());
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Class:{nameof(TwillioService)}, Method:{nameof(Send)}, Message: {ex.Message}, StackTrace: {ex.StackTrace}");
                return false;
            }
        }
    }
}
