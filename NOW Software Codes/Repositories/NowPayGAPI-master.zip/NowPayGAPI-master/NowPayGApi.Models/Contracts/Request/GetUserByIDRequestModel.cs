﻿using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class GetUserByIDRequestModel
    {
        public User userData { get; set; }
    }
}
