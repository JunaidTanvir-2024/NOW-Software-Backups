namespace FH.Core.DTOs.Database;
public sealed class ProductAliasDto
{
    public sealed record Request
    {
        public required long ProductId { get; set; }
        public required string ProductNameAlias { get; set; }
        public required string ProductDescription { get; set; }
    }

    public sealed record Response
    {
    }
}
