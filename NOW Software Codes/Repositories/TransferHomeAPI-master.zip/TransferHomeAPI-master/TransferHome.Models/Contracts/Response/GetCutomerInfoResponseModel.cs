﻿using System;
using System.Collections.Generic;
using System.Text;
using TransferHome.Models.Contracts.Service.Pay360ApiContracts;

namespace TransferHome.Models.Contracts.Response
{
    public class GetCutomerInfoResponseModel
    {
        public decimal Balance { get; set; }
        public string BalanceCurrency { get; set; }
        public Pay360CardsResponse Pay360Cards { get; set; }
    }
}
