﻿using Application.Features.Address;

namespace NowMobile.Api.Controllers;


public class AddressController : VersionedApiController
{

    [HttpGet("{postcode}"), AllowAnonymous, OpenApiOperation("Get Address by using post code.", "")]
    public async Task<IActionResult> GetAddress([FromRoute] string postcode)
    {
        return Ok(await Mediator.Send(new AddressRequest() { PostCode = postcode }));
    }
}
