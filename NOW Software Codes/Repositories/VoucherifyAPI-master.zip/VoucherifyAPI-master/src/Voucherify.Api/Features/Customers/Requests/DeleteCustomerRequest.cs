using FluentValidation;

using Voucherify.Core.Commons.Extensions;

namespace Voucherify.Api.Features.Customers.Requests;

public class DeleteCustomerRequest
{
    public string CustomerSourceId { get; set; } = null!;
}

internal class DeleteCustomerByIdRequestValidator : AbstractValidator<DeleteCustomerRequest>
{
    public DeleteCustomerByIdRequestValidator()
    {
        RuleFor(p => p.CustomerSourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.CustomerSourceId = phoneNumber);
    }
}
