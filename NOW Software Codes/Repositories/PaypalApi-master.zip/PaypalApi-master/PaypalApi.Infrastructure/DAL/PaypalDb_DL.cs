﻿using Dapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PaypalApi.Infrastructure.BLL;
using PaypalApi.Models.Configurations;
using PaypalApi.Models.Contracts.Request.User;
using PaypalApi.Models.Contracts.Response.Api;
using PaypalApi.Models.Database;
using PaypalApi.Models.DbConnections;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaypalApi.Infrastructure.DAL
{
    public class PaypalDb_DL : IPaypalDb_DL
    {

        private readonly ILogger Logger;
        private IDbConnectionSettings DbConnection;
        private IDbConnectionSettings DigiTalkDbConnection;
        private IDbConnectionSettings ThmConnection;
        private IDbConnectionSettings ThrccConnection;
        private IDbConnectionSettings ThccConnection;

        public PaypalDb_DL(ILogger logger, IOptions<ConnectionString> connectionString)
        {
            Logger = logger;
            DbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
            DigiTalkDbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigiTalkConnection));
            ThmConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThmConnection));
            ThrccConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThrccConnection));
            ThccConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThccConnection));
        }

        public async Task<Customer> GetCustomerByMerchantRef(string merchantRef)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@MerchantRef", merchantRef);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<Customer>("Paypal_Api_GetCustomerByMerchantRef", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PaypalDb_DL, Method: GetCustomerByMerchantRef, Parameters=> merchantRef: {merchantRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        public async Task<DbResult<int>> AddCustomer(Customer customer)
        {
            DbResult<int> result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Name", customer.Name);
                parameters.Add("@MerchantRef", customer.MerchantRef);
                parameters.Add("@Email", customer.Email);
                parameters.Add("@Msisdn", customer.Msisdn);
                parameters.Add("@ProductCode", customer.ProductCode);           

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("Paypal_Api_AddCustomer", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<int>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: PaypalDb_DL, Method: AddCustomer, Parameters=> customer: {JsonConvert.SerializeObject(customer)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}, DBErrorMessage: {result.DBErrorMessage}");
                //throw;
                return result;
            }
        }

        public async Task<DbResult<int>> AddTransaction(ApiCreateSalePaymentResponse apiResponse, int customerId, ProductBasket[] basket, string requestJson, string responseJson)
        {
            DbResult<int> result;
            try
            {
                string approvalUrl = (from r in apiResponse.RedirectLinks where r.Rel == "approval_url" select r.Href).FirstOrDefault();

                DataTable items = new DataTable();
                items.Columns.Add("ProductItemCode", typeof(string));
                items.Columns.Add("Amount", typeof(float));
                DataColumn productColumn = items.Columns.Add("ProductRef", typeof(string));
                productColumn.AllowDBNull = true;
                DataColumn bundleColumn = items.Columns.Add("BundleRef", typeof(string));
                bundleColumn.AllowDBNull = true;

                for (int i = 0; i < basket.Length; i++)
                {
                    DataRow row = items.NewRow();
                    row["ProductItemCode"] = basket[i].ProductItemCode;
                    row["Amount"] = basket[i].Amount;
                    row["ProductRef"] = ((string.IsNullOrWhiteSpace(basket[i].ProductRef)) == true ? null : basket[i].ProductRef);
                    row["BundleRef"] = ((string.IsNullOrWhiteSpace(basket[i].BundleRef)) == true ? null : basket[i].BundleRef);
                    items.Rows.Add(row);
                }

                var parameters = new DynamicParameters();
                parameters.Add("@Customer_Id", customerId);
                parameters.Add("@InvoiceNumber", apiResponse.Transaction[0].InvoiceNumber);
                parameters.Add("@PaypalTransactionId", apiResponse.Id);
                parameters.Add("@Description", apiResponse.Transaction[0].Description);
                parameters.Add("@CreateState_Id", (int)apiResponse.State.ToEnum<TransactionStates>());
                parameters.Add("@Intent_Id", (int)apiResponse.Intent.ToEnum<TransactionIntent>());
                parameters.Add("@Amount", apiResponse.Transaction[0].Amount.Total);
                parameters.Add("@Currency", apiResponse.Transaction[0].Amount.Currency);
                parameters.Add("@CreateTime", apiResponse.CreateTime);
                parameters.Add("@RequestTime", DateTime.UtcNow);
                parameters.Add("@ApprovalUrl", (approvalUrl == null ? "": approvalUrl));
                parameters.Add("@CreateRequestJson", requestJson);
                parameters.Add("@CreateResponseJson", responseJson);
                parameters.Add("@TransactionItems", items.AsTableValuedParameter("PaypalTransactionItemType"));
                parameters.Add("@IsCreateError", false);
                parameters.Add("@CreateErrorMessage", "");               

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("PayPal_Api_AddTransaction", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<int>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: PaypalDb_DL, Method: AddTransaction, Parameters=> apiResponse: {JsonConvert.SerializeObject(apiResponse)}, customerId: {customerId}, basket: {basket}, requestJson: {requestJson}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}, DBErrorMessage: {result.DBErrorMessage}");
                
                return result;
            }
        }

        public async Task<DbResult<int>> AddErrorTransaction(int customerId, string invoiceNumber, string description, string intent, float amount, string currency, DateTime requestTime, string errorMessage, ProductBasket[] basket, string requestJson, string responseJson)
        {
            DbResult<int> result;
            try
            {
                
                DataTable items = new DataTable();
                items.Columns.Add("ProductItemCode", typeof(string));
                items.Columns.Add("Amount", typeof(float));
                DataColumn productColumn = items.Columns.Add("ProductRef", typeof(string));
                productColumn.AllowDBNull = true;
                DataColumn bundleColumn = items.Columns.Add("BundleRef", typeof(string));
                bundleColumn.AllowDBNull = true;

                for (int i = 0; i < basket.Length; i++)
                {
                    DataRow row = items.NewRow();
                    row["ProductItemCode"] = basket[i].ProductItemCode;
                    row["Amount"] = basket[i].Amount;
                    row["ProductRef"] = ((string.IsNullOrWhiteSpace(basket[i].ProductRef)) == true ? null : basket[i].ProductRef);
                    row["BundleRef"] = ((string.IsNullOrWhiteSpace(basket[i].BundleRef)) == true ? null : basket[i].BundleRef);
                    items.Rows.Add(row);
                }

                var parameters = new DynamicParameters();
                parameters.Add("@Customer_Id", customerId);
                parameters.Add("@InvoiceNumber", invoiceNumber);
                parameters.Add("@PaypalTransactionId","");
                parameters.Add("@Description", description);
                parameters.Add("@CreateState_Id", 0);
                parameters.Add("@Intent_Id", (int)intent.ToEnum<TransactionIntent>());
                parameters.Add("@Amount", amount);
                parameters.Add("@Currency", currency);
                parameters.Add("@CreateTime", DateTime.UtcNow);
                parameters.Add("@RequestTime", DateTime.UtcNow);
                parameters.Add("@ApprovalUrl", "");
                parameters.Add("@CreateRequestJson", requestJson);
                parameters.Add("@CreateResponseJson", responseJson);
                parameters.Add("@TransactionItems", items.AsTableValuedParameter("PaypalTransactionItemType"));
                parameters.Add("@IsCreateError", true);
                parameters.Add("@CreateErrorMessage", errorMessage);

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("PayPal_Api_AddTransaction", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<int>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: PaypalDb_DL, Method: AddErrorTransaction, Parameters=> customerId: {customerId}, isError: {true}, apiErrorMessage: {errorMessage}, basket: {basket}, requestJson: {requestJson}, responseJson: {responseJson}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}, DBErrorMessage: {result.DBErrorMessage}");

                return result;
            }
        }

        public async Task<DbTransactions> CheckCustomerTransaction(string customerMerchantRef, string paypalTransactionId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@CustomerMerchantRef", customerMerchantRef);
                parameters.Add("@PaypalTransactionId", paypalTransactionId);
               
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbTransactions>("PayPal_Api_CheckCustomerTransaction", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PaypalDb_DL, Method: CheckCustomerTransaction, Parameters=> customerMerchantRef: {customerMerchantRef}, paypalTransactionId: {paypalTransactionId}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null;
            }
        }

        public async Task<DbResult<int>> UpdateTransaction(ApiExecuteSalePaymentResponse apiResponse, int transactionId, string requestJson, string responseJson, string httpStatusCode)
        {
            DbResult<int> result;
            try
            {
                
                var parameters = new DynamicParameters();
                parameters.Add("@TransactionId", transactionId);
                parameters.Add("@ExecuteState_Id", (apiResponse.State == null ? 0 :(int)apiResponse.State.ToEnum<TransactionStates>()));
                parameters.Add("@PayerPaymentMethod", (apiResponse.Payer == null ? "paypal" :apiResponse.Payer.PaymentMethod));
                string PayerEmail = "", PayerFirstName = "", PayerLastName = "", PayerId = "", PayerStatus = "";                
               
                if (apiResponse.Payer != null)
                {
                    PayerStatus = (apiResponse.Payer.Status == null ? "" : apiResponse.Payer.Status);
                    if(apiResponse.Payer.PayerInfo != null)
                    {
                        PayerEmail = (apiResponse.Payer.PayerInfo.Email == null ? "" : apiResponse.Payer.PayerInfo.Email);
                        PayerFirstName = (apiResponse.Payer.PayerInfo.FirstName == null ? "" : apiResponse.Payer.PayerInfo.FirstName);
                        PayerLastName = (apiResponse.Payer.PayerInfo.LastName == null ? "" : apiResponse.Payer.PayerInfo.LastName);
                        PayerId = (apiResponse.Payer.PayerInfo.PayerId == null ? "" : apiResponse.Payer.PayerInfo.PayerId);
                    }
                }
                parameters.Add("@PayerEmail", PayerEmail);
                parameters.Add("@PayerFirstName", PayerFirstName);
                parameters.Add("@PayerLastName", PayerLastName);
                parameters.Add("@PayerId", PayerId);
                parameters.Add("@PayerStatus", PayerStatus);

                string PayeeMerchantId = "", PayeeEmail = "", SaleId = "", SaleState = "", SaleTransactionFee = "0", SaleTransactionFeeCurrency = "";
                DateTime SaleCreateTime = DateTime.UtcNow;

                if(apiResponse.Transaction != null)
                {
                    if(apiResponse.Transaction.Length > 0)
                    {

                        if(apiResponse.Transaction[0].Payee != null)
                        {
                            PayeeMerchantId = (apiResponse.Transaction[0].Payee.MerchantId == null ? "" : apiResponse.Transaction[0].Payee.MerchantId);
                            PayeeEmail = (apiResponse.Transaction[0].Payee.Email == null ? "" : apiResponse.Transaction[0].Payee.Email);
                        }

                        if (apiResponse.Transaction[0].RelatedResources.Length > 0)
                        {
                            if(apiResponse.Transaction[0].RelatedResources[0].Sale != null)
                            {
                                SaleId = (apiResponse.Transaction[0].RelatedResources[0].Sale.Id == null ? "" : apiResponse.Transaction[0].RelatedResources[0].Sale.Id);
                                SaleCreateTime = (apiResponse.Transaction[0].RelatedResources[0].Sale.CreateTime == null ? SaleCreateTime : apiResponse.Transaction[0].RelatedResources[0].Sale.CreateTime);
                                SaleState = (apiResponse.Transaction[0].RelatedResources[0].Sale.State == null ? "" : apiResponse.Transaction[0].RelatedResources[0].Sale.State);
                                if (apiResponse.Transaction[0].RelatedResources[0].Sale.TransactionFee != null)
                                {
                                    SaleTransactionFee = (apiResponse.Transaction[0].RelatedResources[0].Sale.TransactionFee.Value == null ? "0" : apiResponse.Transaction[0].RelatedResources[0].Sale.TransactionFee.Value);
                                    SaleTransactionFeeCurrency = (apiResponse.Transaction[0].RelatedResources[0].Sale.TransactionFee.Currency == null ? "" : apiResponse.Transaction[0].RelatedResources[0].Sale.TransactionFee.Currency);
                                }
                            }
                        }

                    }
                }
                parameters.Add("@PayeeMerchantId", PayeeMerchantId);
                parameters.Add("@PayeeEmail", PayeeEmail);
                parameters.Add("@SaleId", SaleId);
                parameters.Add("@SaleCreateTime", SaleCreateTime);
                parameters.Add("@SaleState", SaleState);
                parameters.Add("@SaleTransactionFee", SaleTransactionFee);
                parameters.Add("@SaleTransactionFeeCurrency", SaleTransactionFeeCurrency);
               
                parameters.Add("@ExecuteRequestJson", requestJson);
                parameters.Add("@ExecuteResponseJson", responseJson);               
                parameters.Add("@IsExecuteError", false);
                parameters.Add("@ExecuteErrorMessage", "");
                parameters.Add("@ExecuteResponseHttpStatus", httpStatusCode);

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("PayPal_Api_UpdateTransaction", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<int>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: PaypalDb_DL, Method: UpdateTransaction, Parameters=> transactionId: {transactionId}, requestJson: {requestJson}, responseJson: {responseJson}, httpStatusCode: {httpStatusCode}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}, DBErrorMessage: {result.DBErrorMessage}");

                return result;
            }
        }

        public async Task<DbResult<int>> UpdateErrorTransaction(string payerId, int transactionId, string executeErrorMessage, string requestJson, string responseJson, string httpStatusCode)
        {
            DbResult<int> result;
            try
            {

                var parameters = new DynamicParameters();
                parameters.Add("@TransactionId", transactionId);
                parameters.Add("@ExecuteState_Id", 0);
                parameters.Add("@PayerPaymentMethod", "");
                parameters.Add("@PayerEmail", "");
                parameters.Add("@PayerFirstName", "");
                parameters.Add("@PayerLastName", "");
                parameters.Add("@PayerId", payerId);
                parameters.Add("@PayerStatus", "");
                parameters.Add("@PayeeMerchantId", "");
                parameters.Add("@PayeeEmail", "");
                parameters.Add("@SaleId", "");
                parameters.Add("@SaleCreateTime", "");
                parameters.Add("@SaleState", "");
                parameters.Add("@SaleTransactionFee", 0);
                parameters.Add("@SaleTransactionFeeCurrency", "");
                parameters.Add("@ExecuteRequestJson", requestJson);
                parameters.Add("@ExecuteResponseJson", responseJson);
                parameters.Add("@IsExecuteError", true);
                parameters.Add("@ExecuteErrorMessage", executeErrorMessage);
                parameters.Add("@ExecuteResponseHttpStatus", httpStatusCode);

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult<int>>("PayPal_Api_UpdateTransaction", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult<int>();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                Logger.Error($"Class: PaypalDb_DL, Method: UpdateErrorTransaction, Parameters=> payerId: {payerId}, transactionId: {transactionId}, requestJson: {requestJson}, responseJson: {responseJson}, httpStatusCode: {httpStatusCode}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}, DBErrorMessage: {result.DBErrorMessage}");
                return result;
            }
        }

        public async Task<List<TransactionItems>> GetTransactionItems(string transactionId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@TransactionId", transactionId);
                var result = await DbConnection.SqlConnection.QueryAsync<TransactionItems>("Paypal_Api_GetTransactionItems", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PaypalDb_DL, Method: GetTransactionItems, Parameters=> transactionId: {transactionId}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null;
            }

        }

        public async Task<int> UpdateTransactionItem(int Id, bool IsFullfilled, DateTime FulfilmentDateTime, string FullfillmentError)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", Id);
                parameters.Add("@FullfillmentError", FullfillmentError);               
                parameters.Add("@IsFullfilled", IsFullfilled);               
                parameters.Add("@FulfilmentDateTime", FulfilmentDateTime);
                var result = await DbConnection.SqlConnection.ExecuteAsync("Paypal_Api_UpdateTransactionItem", parameters, commandType: CommandType.StoredProcedure);
                if(result < 1)  // Not updated
                {
                    Logger.Error($"Class: PaypalDb_DL, Method: UpdateTransactionItem, Parameters=> transactionItemId: {Id}, FullfillmentError: {FullfillmentError}, IsFullfilled: {IsFullfilled}, FulfilmentDateTime: {FulfilmentDateTime}, ErrorMessage: Error in database record updation.");
                }
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PaypalDb_DL, Method: UpdateTransactionItem, Parameters=> transactionItemId: {Id}, FullfillmentError: {FullfillmentError}, IsFullfilled: {IsFullfilled}, FulfilmentDateTime: {FulfilmentDateTime}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return 0;
            }
        }

        public async Task<FullfilmentResponse> ThmCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef)
        {

            
            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@amount", Decimal.Parse(amount));
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@new_balance", ParameterDirection.Output, DbType.Decimal);
                parameters.Add("@audit_id", ParameterDirection.Output, DbType.Int32);

                var result = await ThmConnection.SqlConnection.ExecuteAsync("thm_ndl_paypal_create_queue", parameters, commandType: CommandType.StoredProcedure);
                //response.new_balance = parameters.Get<Decimal>("@new_balance");
                //response.audit_id = parameters.Get<int>("@audit_id");
                response.ErrorCode = 0;
                response.ErrorMessage = "Success";

            }
            catch (Exception ex)
            {
                response.ErrorCode = 1;
                response.ErrorMessage = "Code Exception: " + ex.Message;
                Logger.Error($"Class: PaypalDb_DL, Method: ThmCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> ThaCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef)
        {


            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@amount", Decimal.Parse(amount));
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@new_balance", ParameterDirection.Output, DbType.Decimal);
                parameters.Add("@audit_id", ParameterDirection.Output, DbType.Int32);

                var result = await DigiTalkDbConnection.SqlConnection.ExecuteAsync("tha_ndl_paypal_create_queue", parameters, commandType: CommandType.StoredProcedure);
                //response.new_balance = parameters.Get<Decimal>("@new_balance");
                //response.audit_id = parameters.Get<int>("@audit_id");
                response.ErrorCode = 0;
                response.ErrorMessage = "Success";

            }
            catch (Exception ex)
            {
                response.ErrorCode = 1;
                response.ErrorMessage = "Code Exception: " + ex.Message;
                Logger.Error($"Class: PaypalDb_DL, Method: ThmCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> ThccCustomerFullfilment(string transactionId, string amount)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@amount", amount);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@thccpin", ParameterDirection.Output, DbType.String);
                parameters.Add("@errorcode", ParameterDirection.Output, DbType.Int32);
                parameters.Add("@errormsg", ParameterDirection.Output, DbType.String);

                var result = await ThccConnection.SqlConnection.QueryAsync("thm_pay360_accountupdatebalance", parameters, commandType: CommandType.StoredProcedure);
                response.ErrorCode = parameters.Get<int>("@errorcode");
                response.ErrorMessage = parameters.Get<string>("@errormsg");
                response.Pin = parameters.Get<string>("@thccpin");
            }
            catch (Exception ex)
            {
                response.ErrorCode = 1;
                response.ErrorMessage = "Code Exception: " + ex.Message;
                Logger.Error($"Class: PaypalDb_DL, Method: ThccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<FullfilmentResponse> ThrccCustomerFullfilment(string transactionId, string amount, string productRef)
        {

            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@amount", amount);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@productref", productRef);
                parameters.Add("@thccpin", ParameterDirection.Output, DbType.String);
                parameters.Add("@errorcode", ParameterDirection.Output, DbType.Int32);
                parameters.Add("@errormsg", ParameterDirection.Output, DbType.String);

                var result = await ThrccConnection.SqlConnection.QueryAsync("thm_pay360_accountupdatebalance", parameters, commandType: CommandType.StoredProcedure);
                response.ErrorCode = parameters.Get<int>("@errorcode");
                response.ErrorMessage = parameters.Get<string>("@errormsg");
                response.Pin = parameters.Get<string>("@thccpin");

            }
            catch (Exception ex)
            {
                response.ErrorCode = 1;
                response.ErrorMessage = "Code Exception: " + ex.Message;
                Logger.Error($"Class: PaypalDb_DL, Method: ThrccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<DbResult<List<ProductItems>>> GetProductItems(string msisdn)
        {

            DbResult<List<ProductItems>> result = new DbResult<List<ProductItems>>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                var dbResult = await DbConnection.SqlConnection.QueryAsync<ProductItems>("Pay360_Api_GetProductItems_v1", parameters, commandType: CommandType.StoredProcedure);
                if (dbResult == null || dbResult.Count() < 1) 
                {
                    result.DBStatus = 2;
                    result.DBErrorMessage = "Data not available in ProductItems table";
                }
                else // Success
                {
                    result.DBStatus = 1;
                    result.DBErrorMessage = "";
                    result.Data = dbResult.ToList();
                }
               
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Pay360, Method: GetProductItems, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
            }
            return result;
        }

        public async Task<List<ProductItems>> GetProductItems()
        {
            try
            {
                var result = await DbConnection.SqlConnection.QueryAsync<ProductItems>("Paypal_Api_GetProductItems", commandType: CommandType.StoredProcedure);
                return result.ToList();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PaypalDb_DL, Method: GetProductItems, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null;
            }
        }

        public async Task<ValidateRes> ThaProductRefValidation(string productItemCode, string productRef)
        {

            //return 0; // For Testing Purpose Only. Comment this for Live and Un-Comment below code for live
            ValidateRes valRes = new ValidateRes();
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@productref", productRef);
                parameters.Add("@tamount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await DigiTalkDbConnection.SqlConnection.ExecuteAsync("tha_pay360_validate_msisdn_v1", parameters, commandType: CommandType.StoredProcedure);

                valRes.Errorcode = parameters.Get<Int32>("@errorcode");
                valRes.Errormsg = parameters.Get<string>("@errormsg");
                valRes.Tamount = parameters.Get<Int32>("@tamount");

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PaypalDb_DL, Method: ThmProductRefValidation, Parameters => productItemCode: {productItemCode}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");

            }

            return valRes;

        }

        public async Task<ValidateRes> ThmProductRefValidation(string productItemCode, string productRef, string bundleRef)
        {

            //return 0; // For Testing Purpose Only. Comment this for Live and Un-Comment below code for live
            ValidateRes valRes = new ValidateRes();
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@productref", productRef);

                bundleRef = string.IsNullOrWhiteSpace(bundleRef) ? "" : bundleRef;
                parameters.Add("@bundleRef", bundleRef);
                parameters.Add("@tamount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ThmConnection.SqlConnection.ExecuteAsync("thm_pay360_validate_msisdn_v2", parameters, commandType: CommandType.StoredProcedure);

                valRes.Errorcode = parameters.Get<Int32>("@errorcode");
                valRes.Errormsg = parameters.Get<string>("@errormsg");
                valRes.Tamount = parameters.Get<Int32>("@tamount");

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PaypalDb_DL, Method: ThmProductRefValidation, Parameters => productItemCode: {productItemCode}, productRef: {productRef}, bundleRef: {bundleRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");

            }

            return valRes;

        }

        public async Task<int> ThrccProductRefValidation(string productItemCode, string productRef)
        {


            //return 0; // For Testing Purpose Only. Comment this for Live and Un-Comment below code for live
            try
            {


                var parameters = new DynamicParameters();

                parameters.Add("@productref", productRef);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await ThrccConnection.SqlConnection.ExecuteAsync("thrcc_pay360_validate_msisdn", parameters, commandType: CommandType.StoredProcedure);

                return parameters.Get<Int32>("@errorcode");

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PaypalDb_DL, Method: ThmProductRefValidation, Parameters => productItemCode: {productItemCode}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return 1;
            }

        }

    }
}
