﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class UpdateAutoTransferStatusResponseModel
    {
        public bool status { get; set; }
    }
}
