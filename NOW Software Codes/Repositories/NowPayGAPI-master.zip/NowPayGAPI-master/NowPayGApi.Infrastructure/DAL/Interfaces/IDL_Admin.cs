﻿using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace NowPayGApi.Infrastructure.DAL.Interfaces
{
    public interface IDL_Admin
    {
        Task<DBUser> Login(DBUser model);
        Task<int> AddPlans(DBUser model);
        Task<bool> IsUserExistByEmail(string email);
        Task<IEnumerable<User>> GetAllUsers(string CSVNumbers);
        Task<DBUserDetails> GetUserByID(User user);
        Task<int> UpdateUserStatus(UpdateUserStatusModel model);
        Task<int> SaveUpdateAdmin(DBAdmin model);
        Task<int> UpdatePlanStatus(UpdatePlanStatusModel model);
        Task<int> UpdatePlan(AddPlanRequestModel model);
        Task<int> AddPlan(AddPlanRequestModel model);
        Task<IEnumerable<DBAdmin>> GetAllAdmins(DBAdmin model);
        Task<int> UpdateAdminStatus(DBAdmin model);
        Task<int> DispatchOrder(int orderId, int userId);
        Task<DbUserSimOrderDetails> GetSpecificSimOrderDetails(int orderId);
        Task<IEnumerable<DBUserSIMOrder>> GetAllSimOrders();
        Task<int> Insertotp(InsertotpRequestModel model);
        Task<int> Verifyotp(VerifyotpRequestModel model);
        Task<int> VerifyUserSimOrder(VerifyUserSimOrderRequestModel model);
        Task<int> IsverifiedUser(string email);
    }
}
