using System.Text.Json.Serialization;

using Voucherify.Core.Commons.Converters;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Promotions;
using Voucherify.Core.Services.VoucherifyApi.Models.Validations;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Campaigns;

public class Campaign
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("active")]
    public bool Active { get; set; }

    [JsonPropertyName("description")]
    public string? Description { get; set; }

    [JsonPropertyName("type")]
    [JsonConverter(typeof(EnumConverter<CampaignExtensionType>))]
    public CampaignExtensionType Type { get; set; }

    [JsonPropertyName("campaign_type")]
    [JsonConverter(typeof(EnumConverter<CampaignType>))]
    public CampaignType CampaignType { get; set; }

    [JsonPropertyName("start_date")]
    public DateTime? StartDate { get; set; }

    [JsonPropertyName("expiration_date")]
    public DateTime? ExpirationDate { get; set; }

    [JsonPropertyName("voucher")]
    public CampaignVoucher? Voucher { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    [JsonPropertyName("voucher_generation_status")]
    [JsonConverter(typeof(EnumConverter<CampaignVoucherGenerationStatus>))]
    public CampaignVoucherGenerationStatus VoucherGenerationStatus { get; set; }

    [JsonPropertyName("promotion")]
    public PromotionTierList? Promotion { get; set; }

    [JsonPropertyName("validation_rules_assignments")]
    public BusinessValidationRuleAssignmentList? Assignments { get; set; }
}
