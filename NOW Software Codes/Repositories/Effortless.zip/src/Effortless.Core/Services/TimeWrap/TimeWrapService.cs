namespace Effortless.Core.Services.TimeWrap;

internal sealed class TimeWrapService : ITimeWrapService
{
    public DateTime UtcNow => DateTime.UtcNow;
}
