﻿//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using SenderService.Core.Persistence.Entities;

//namespace SenderService.Core.Persistence.Configurations;

//internal class EmailRecipientConfiguration : IEntityTypeConfiguration<EmailRecipient>
//{
//    public void Configure(EntityTypeBuilder<EmailRecipient> entity)
//    {
//        entity.HasIndex(e => e.EmailId, "IX_EmailRecipients_EmailId");

//        entity.Property(e => e.EmailAddress).HasMaxLength(510);
//        entity.Property(e => e.RecipientName).HasMaxLength(510);

//        entity.HasOne(d => d.Email).WithMany(p => p.EmailRecipients).HasForeignKey(d => d.EmailId);
//    }
//}
