﻿

using System.Text.Json.Serialization;

namespace SC.Core.Features.Products;
public sealed class GetProductsResponse
{
    [JsonPropertyName("product")]
    public ProductInfo Product { get; set; } = new ProductInfo();
    public sealed record ProductInfo
    {
        [JsonPropertyName("productId")]
        public long ProductId { get; set; }
        [JsonPropertyName("productName")]
        public string? ProductName { get; set; }
        [JsonPropertyName("productAliasName")]
        public string? ProductAliasName { get; set; }
        [JsonPropertyName("description")]
        public string? Description { get; set; }
        [JsonPropertyName("logo")]
        public string? Logo { get; set; }
        [JsonPropertyName("validityUnit")]
        public string? ValidityUnit { get; set; }
        [JsonPropertyName("validityValue")]
        public string? ValidityValue { get; set; }
        [JsonPropertyName("vendorProductCode")]
        public string? VendorProductCode { get; set; }
        [JsonPropertyName("vendorOperatorCode")]
        public string? VendorOperatorCode { get; set; }
        [JsonPropertyName("productType")]
        public string? ProductType { get; set; }
        [JsonPropertyName("productOperator")]
        public ProductOperatorInfo ProductOperator { get; set; } = new ProductOperatorInfo();
        [JsonPropertyName("productCountry")]
        public ProductCountryInfo ProductCountry { get; set; } = new ProductCountryInfo();
        [JsonPropertyName("productCurrency")]
        public ProductCurrencyInfo ProductCurrency { get; set; } = new ProductCurrencyInfo();
        [JsonPropertyName("productSubCategory")]
        public ProductSubCategoryInfo ProductSubCategory { get; set; } = new ProductSubCategoryInfo();
        [JsonPropertyName("productVendor")]
        public ProductVendorInfo ProductVendor { get; set; } = new ProductVendorInfo();
        [JsonPropertyName("productPrice")]
        public ProductPriceInfo ProductPrice { get; set; } = new ProductPriceInfo();
        [JsonPropertyName("productBenefitsJson")]
        public string? ProductBenefitsJson { get; set; }
        [JsonPropertyName("productCategory")]
        public ProductCategoryInfo ProductCategory { get; set; } = new ProductCategoryInfo();


    }
    public sealed record ProductOperatorInfo
    {
        [JsonPropertyName("operatorName")]
        public string? OperatorName { get; set; }
        [JsonPropertyName("operatorDescription")]
        public string? OperatorDescription { get; set; }

    }

    public sealed record ProductCountryInfo
    {
        [JsonPropertyName("countryName")]
        public string? CountryName { get; set; }
        [JsonPropertyName("countryIsoCode2")]
        public string? CountryIsoCode2 { get; set; }
        [JsonPropertyName("countryIsoCode3")]
        public string? CountryIsoCode3 { get; set; }
        [JsonPropertyName("continent")]
        public string? Continent { get; set; }
        [JsonPropertyName("callingCode")]
        public string? CallingCode { get; set; }

    }

    public sealed record ProductCurrencyInfo
    {
        [JsonPropertyName("currencyName")]
        public string? CurrencyName { get; set; }
        [JsonPropertyName("currencyCode")]
        public string? CurrencyCode { get; set; }
        [JsonPropertyName("currencyIsDefault")]
        public bool? CurrencyIsDefault { get; set; }
    }

    public sealed record ProductSubCategoryInfo
    {
        [JsonPropertyName("subCategoryName")]
        public string? SubCategoryName { get; set; }
        [JsonPropertyName("subCategoryDescription")]
        public string? SubCategoryDescription { get; set; }
    }

    public sealed record ProductVendorInfo
    {
        [JsonPropertyName("vendorName")]
        public string? VendorName { get; set; }
        [JsonPropertyName("vendorDescription")]
        public string? VendorDescription { get; set; }

    }

    public sealed record ProductPriceInfo
    {
        [JsonPropertyName("sellingPrice")]
        public decimal? SellingPrice { get; set; }
        [JsonPropertyName("tax")]
        public decimal? Tax { get; set; }
        [JsonPropertyName("productId")]
        public decimal? Fee { get; set; }
        [JsonPropertyName("maxPrice")]
        public decimal? MaxPrice { get; set; }
        [JsonPropertyName("minPrice")]
        public decimal? MinPrice { get; set; }

    }


    public sealed record ProductBenefit
    {
        [JsonPropertyName("unit")]
        public string? Unit { get; set; }
        [JsonPropertyName("unitType")]
        public string? UnitType { get; set; }
        [JsonPropertyName("benefitType")]
        public string? BenefitType { get; set; }
        [JsonPropertyName("benefitWithTax")]
        public decimal? BenefitWithTax { get; set; }
        [JsonPropertyName("benefitWithoutTax")]
        public decimal? BenefitWithoutTax { get; set; }
    }

    public sealed record ProductCategoryInfo
    {
        [JsonPropertyName("categoryName")]
        public string? CategoryName { get; set; }
        [JsonPropertyName("categoryDescription")]
        public string? CategoryDescription { get; set; }
    }


}

