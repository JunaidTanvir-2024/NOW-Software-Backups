﻿namespace SenderService.Core.Features.Email.Request;
public class GetEmailsRequest
{
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public string? Email { get; set; }
}
