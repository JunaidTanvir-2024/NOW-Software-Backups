﻿using Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;

namespace Models.Contracts.Request
{
    public class DeleteAccountLogRequestModel
    {       
        public string AccountId { get; set; }        
        public string Msisdn { get; set; }
        public DateTime? AccountActivationDate { set; get; }   
        public string DeleteAccountReason { set; get; }
        public string Comments { set; get; }
        public AccountDeleteStatus AccountDeleteStatus { set; get; }
        public DateTime? AllowedSignUpDate { set; get; }

    }
}
