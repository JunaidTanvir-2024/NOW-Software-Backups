﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Models.Pay360ApiContracts;

namespace TalkhomeAPI.Services.Interfaces
{
    public interface IAccountService
    {
        Task<bool> IsUserExist(string UserName);
        Task<DBAccountInfo> GetAccountDetails(string Username, string pin);
        Task<GenericApiResponse<VerifyPinResponseModel>> VerifyPin(VerifyPinRequestModel model);
        Task<GenericApiResponse<VerifyPinResponseModel>> VerifyPinV2(VerifyPinRequestModel model);
        Task<GenericApiResponse<string>> ValidateMsisdn(string msisdn);
        Task<GenericApiResponse<SignUpResponseModel>> SignUp(SignUpRequestModel model);
        Task<GenericApiResponse<SignUpResponseModel>> SignUpV2(SignUpRequestModel model);
        Task<string> ValidateUser(string msisdn);
        Task<GenericApiResponse<LoginResponseModel>> Login(LoginRequestModel model);
        Task<GenericApiResponse<LoginResponseModel>> LoginV2(LoginRequestModel model);
        Task<GenericApiResponse<ReSendPinResponseModel>> ReSendPin(ReSendPinRequestModel model);
        Task<GenericApiResponse<VerifyEmailResponseModel>> VerifyEmail(VerifyEmailRequestModel model);
        Task<GenericApiResponse<GetAccountDetailsResponseModel>> GetAccountDetails(string msisdn);
        Task<GenericApiResponse<CallHistoryResponseModel>> GetCallingHistory(string accountNumber);
        Task<GenericApiResponse<List<EntirePaymentHistory>>> GetEntirePaymentHistory(string account, string msisdn);
        Task<GenericApiResponse<GetTopUpPaymentHistoryResponseModel>> GetTopUpPaymentHistory(string accountNumber);
        Task<GenericApiResponse<GetInternationalTopUpHistoryResponseModel>> GetInternationalTopUpHistory(string accountNumber);

        Task<GenericApiResponse<UpdateMissingDetailsResponseModel>> UpdateMissingDetails(
            UpdateMissingDetailsRequestModel model, string msisdn);
        Task<GenericApiResponse<bool>> IsEmailAlreadyExists(IsEmailAlreadyExistsRequestModel model);
        Task<GenericApiResponse<UpdateAccountDetailsResponseModel>> UpdateAccountDetails(
            UpdateAccountDetailsRequestModel model, string msisdn);
        Task<GenericApiResponse<ReSendEmailVerificationResponse>> ReSendEmailVerificationLink(string msisdn);

        Task<GenericApiResponse<GetBundlesHistoryResponseModel>> GetBundlesHistory(string accountNumber);
        Task<GenericApiResponse<bool>> IsMsisdnRegistered(IsMsisdnRegisteredRequestModel request);
        Task<GenericApiResponse<GetAccountDetailsByMsisdnResponseModel>> GetAccountDetailsByMsisdn(GetAccountDetailsByMsisdnRequestModel request);
        Task<GenericApiResponse<RSS>> GetPromotions(string msisdn);
        Task<GenericApiResponse<bool>> SetPromotions(string msisdn, Promotion promotion);       
        Task<GenericApiResponse<bool>> CreateDeleteAccountRequest(DeleteAccountLogRequest deleteAccountRequestModel);       
        Task<GenericApiResponse<List<DeleteAccountReasonResponseModel>>> GetDeleteAccountReasons();
        Task<GenericApiResponse<bool>> VerifyPinCode(PinVerificationCodeRequestModel model);
        Task<GenericApiResponse<bool>> IsAccountDeleteRequestInProgress(string msisdn);
    }
}
