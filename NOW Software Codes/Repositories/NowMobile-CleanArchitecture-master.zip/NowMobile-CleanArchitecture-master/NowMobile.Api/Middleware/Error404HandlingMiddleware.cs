﻿using Application.Common.Enums;
using Application.Common.Models.ResponseWrappers;
using Microsoft.Extensions.Localization;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using NowMobile.Api.Filters;

namespace NowMobile.Api.Middleware;

public class Error404HandlingMiddleware
{
    private readonly RequestDelegate _next;

    public Error404HandlingMiddleware(RequestDelegate next)
    {
        _next = next;
    }
    public async Task InvokeAsync(HttpContext context)
    {
        await ExceptionHandlerAsync(context);
    }

    private async Task ExceptionHandlerAsync(HttpContext context)
    {
        await _next(context);
        if (context.Response.StatusCode == 404)
        {
            var _localizer = context.RequestServices.GetService<IStringLocalizer<ValidateModelStateAttribute>>();
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsync(JsonConvert.SerializeObject(
                Result<object>.Failure(_localizer![CustomStatusKey.NotFound], CustomStatusCode.NotFound)
              , new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() }));
        }
    }

}
public static class ErrorHandlingMiddlewareExtension
{
    public static IApplicationBuilder Use404ErrorHandlingMiddleware(this IApplicationBuilder app)
    {
        return app.UseMiddleware<Error404HandlingMiddleware>();
    }
}
