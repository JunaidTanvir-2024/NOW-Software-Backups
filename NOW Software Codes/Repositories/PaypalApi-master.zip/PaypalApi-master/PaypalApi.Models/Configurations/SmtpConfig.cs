﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Configurations
{
    public class SmtpConfig
    {
        public string server { get; set; }
        public string from { get; set; }
        public string fromForCustomer { get; set; }
        public string userName { get; set; }
        public string password { get; set; }
        public string[] to { get; set; }
        public string[] cc { get; set; }
        public string[] bcc { get; set; }
        public string subject { get; set; }
        public string subjectForCustomer { get; set; }
        public bool sendEmailToCustomer { get; set; }
    }
}
