﻿using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace NowPayGApi.Infrastructure.DAL.Interfaces
{
    public interface IDL_CommonServices
    {
        Task<IEnumerable<DBPlan>> GetAllActivePlans();
        Task<IEnumerable<DBPlan>> GetAllPlans();
        Task<IEnumerable<DBCountry>> GetCountry();
        Task<IEnumerable<DBPlanCategory>> GetPlanCategories();
        Task<IEnumerable<DBProduct>> GetProduct();
        Task<IEnumerable<Currencies>> GetCurrency();
        Task<GetPlanResponseModel> GetPlanById(IdRequestModel model);
        Task<IEnumerable<DBInternationalRates>> GetAllInternationalRates();
        Task<DBRoamingRates> GetRoamingRates(int fromCountryId, int toCountryId);
        Task<IEnumerable<DBUKRates>> GetAllUKRates();
        Task<IEnumerable<DBCountry>> GetAllCountriesWithPlans();
        Task<GetSimOrdersNoByEmailResponseModel> GetSimOrderNoByEmail(string email);
       
    }
}
