﻿namespace Application.Common.Settings;
public class PaymentSettings
{
    public const string SectionName = "PaymentSettings";
    public static PaymentSettings Bind = new PaymentSettings();
    public Pay360Setting? Pay360Setting { get; set; }
    public PayPalSetting? PayPalSetting { get; set; }
}
public class Pay360Setting
{
    public const string SectionName = "PaymentSettings:Pay360";
    public static Pay360Setting Bind = new Pay360Setting();
    public string ApiEndpoint { get; set; } = default!;
    public bool IsAuthorization { get; set; } = default!;
    public bool Do3DSecure { get; set; } = default!;
    public bool IsDirectFullfilment { get; set; } = default!;
    public bool IsCustomerAddressSameAsBilling { get; set; } = default!;
    public string AppPaymentCallBackUrl { get; set; } = default!;
    public string WebPaymentCallBackUrl { get; set; } = default!;
    public float AuthorizeCardTestAmount { get; set; }
}
public class PayPalSetting
{
    public const string SectionName = "PaymentSettings:PayPal";
    public static PayPalSetting Bind = new PayPalSetting();
    public string ApiEndpoint { get; set; } = default!;
    public bool IsDirectFullfilment { get; set; } = default!;
    public string AppPaymentCallBackUrl { get; set; } = default!;
    public string AppSubscriptionCallBackUrl { get; set; } = default!;
    public string WebSubscriptionCallBackUrl { get; set; } = default!;
    public string AppCancelCallBackUrl { get; set; } = default!;
    public string WebPaymentCallBackUrl { get; set; } = default!;
    public string WebCancelCallBackUrl { get; set; } = default!;
}

