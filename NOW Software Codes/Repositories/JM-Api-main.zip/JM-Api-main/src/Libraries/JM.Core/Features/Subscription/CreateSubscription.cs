using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

using static JM.Core.Utilities.Definitions.AppEnum;

namespace JM.Core.Features.Subscription;

public abstract class CreateSubscription
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public decimal Price { get; set; }
        public IEnumerable<SubscriptionBenefit> Benefits { get; set; } = [];
        public DateTime ExpiryDate { get; set; }
        public sealed record SubscriptionBenefit
        {
            public SubscriptionType Type { get; set; }
            public SubscriptionUnitType UnitType { get; set; }
            public int Unit { get; set; }
            public AdsFreeExperience AdsFreeExperience { get; set; }
        }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query> { }
    #endregion

    #region Response
    public sealed record Response
    {
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var subscription = await _unitOfWork.SubscriptionRepository.AddSubscription(new Entities.Subscription()
            {
                Price = query.Price,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                ExpiryDate = query.ExpiryDate.ToUniversalTime()
            });
            _unitOfWork.SaveChanges();

            if (subscription is not null)
            {
                var subscriptionBenefits = query.Benefits.Select(x => new Entities.SubscriptionBenefit()
                {
                    AdsFreeExperience = (int)x.AdsFreeExperience,
                    SubscriptionId = subscription.Id,
                    Type = (int)x.Type,
                    UnitType = (int)x.UnitType,
                    Unit = x.Unit,
                });

                await _unitOfWork.SubscriptionRepository.AddSubscriptionBenefits(subscriptionBenefits);
                _unitOfWork.SaveChanges();

                return ResultWrapper.Success(AppConstant.StatusKey.Success, AppConstant.StatusCode.Success);
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
    }
    #endregion
}
