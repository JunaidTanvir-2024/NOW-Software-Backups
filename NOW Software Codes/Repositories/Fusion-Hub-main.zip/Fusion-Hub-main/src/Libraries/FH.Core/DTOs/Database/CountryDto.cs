namespace FH.Core.DTOs.Database;
public class CountryDto
{
    public sealed record Request
    {
        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; } 
        public CountryFilter? CountryFilters { get; set; }

        public sealed record CountryFilter
        {
            public string? CountryName { get; set; }
            public string? CountryCallingCode { get; set; }
            public string? IsoCode2 { get; set; }
            public string? IsoCode3 { get; set; }
        }
    }

    public sealed record Response
    {
        public long CountryId { get; set; }
        public string? IsoCode2 { get; set; }
        public string? IsoCode3 { get; set; }
        public int CallingCode { get; set; }
        public string? CountryName { get; set; }
        public int IsoNumericCode { get; set; }
        public string? Continent { get; set; }
        public string? CountryLogo { get; set; }
    }

}
