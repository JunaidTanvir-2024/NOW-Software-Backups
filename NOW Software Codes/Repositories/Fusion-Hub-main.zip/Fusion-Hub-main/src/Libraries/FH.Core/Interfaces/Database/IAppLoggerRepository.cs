using FH.Core.DependencyResolver;
using FH.Core.Entities;

namespace FH.Core.Interfaces.Database;

public interface IAppLoggerRepository : ServiceType.IScoped
{
    Task AppLogUpsert(AppLogEntity logDto);
    Task VendorLogInsert(VendorLogEntity vendorLogDto);
}
