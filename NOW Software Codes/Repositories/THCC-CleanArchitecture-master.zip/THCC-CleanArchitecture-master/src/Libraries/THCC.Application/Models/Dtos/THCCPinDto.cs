﻿namespace THCC.Application.Models.Dtos
{
    public class THCCPinDto
    {
        public string? pin { get; set; }
        public float credit { get; set; }
        public string? serial { get; set; }
    }
}
