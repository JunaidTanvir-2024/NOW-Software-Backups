﻿using Newtonsoft.Json;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts.Paypal.Response.Api
{
    public class ApiPaypalPaymentResponse
    {
        [JsonProperty("processing")]
        public ProcessingModel Processing { get; set; }

        [JsonProperty("paymentMethod")]
        public PaypalPaymentMethodResponse PaymentMethod { get; set; }

        [JsonProperty("customer")]
        public CustomerResponseModel Customer { get; set; }

        [JsonProperty("outcome")]
        public OutcomeModel Outcome { get; set; }

        [JsonProperty("transaction")]
        public TransactionResponseModel Transaction { get; set; }

        [JsonProperty("financialServices")]
        public FinancialServicesResponseModel FinancialServices { get; set; }

        [JsonProperty("history")]
        public List<HistoryModel> History { get; set; }

        [JsonProperty("clientRedirect")]
        public ClientRedirectModel ClientRedirect { get; set; }

        [JsonProperty("fraudGuard")]
        public FraudGuardModel FraudGuard { get; set; }
       
        [JsonProperty("basketResponse")]
        public List<BasketItemsResponse> BasketResponse { get; set; }


    }

    public class PaypalPaymentMethodResponse
    {
        [JsonProperty("paypal")]
        public PaypalPayment Paypal { get; set; }
        [JsonProperty("paymentClass")]
        public string PaymentClass { get; set; }

    }
    public class PaypalPayment
    {
        [JsonProperty("payerID")]
        public string PayerID { get; set; }
        [JsonProperty("email")]
        public string PayerEmail { get; set; }
        [JsonProperty("accountVerified")]
        public bool AccountVerified { get; set; }
        [JsonProperty("checkoutToken")]
        public string CheckoutToken { get; set; }
        [JsonProperty("source")]
        public string Source { get; set; }

    }
   


}
