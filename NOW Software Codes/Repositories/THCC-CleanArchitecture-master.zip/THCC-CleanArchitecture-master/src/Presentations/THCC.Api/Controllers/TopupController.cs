﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using THCC.Api.Controllers.Common;

using THCC.Application.Features.Topup.AutoTopup;
using THCC.Application.Features.Topup.Denominations;
using THCC.Application.Features.Topup.DisableAutoTopup;
using THCC.Application.Features.Topup.VerifyCardNumber;
using THCC.Application.Models.Dtos;
using THCC.Application.Settings;

namespace THCC.Api.Controllers
{
    public class TopupController : BaseApiController
    {
        [AllowAnonymous]
        [HttpGet("denominations")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TopupSettings))]
        public async Task<IActionResult> GetTopupDenominations(CancellationToken cancellationToken)
        {
            return HandleResponse(await Mediator.Send(new TopupDenominationRequest(), cancellationToken));
        }

        [HttpGet("{CardNumber}/verify")]
        [AllowAnonymous]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(VerifyCardNumberResponse))]
        public async Task<IActionResult> VerifyCardNumberNumber([FromRoute] VerifyCardNumberRequest request, CancellationToken cancellationToken)
        {
            return HandleResponse(await Mediator.Send(request, cancellationToken));
        }

        [Authorize]
        [HttpGet("autotopup")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AutoTopupResponseDto))]
        public async Task<IActionResult> GetAutoTopup(CancellationToken cancellationToken)
        {
            return HandleResponse(await Mediator.Send(new AutoTopupRequest(), cancellationToken));
        }
        [Authorize]
        [HttpPut("autotopup/disable")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> DisableAutoTopup(CancellationToken cancellationToken)
        {
            return HandleResponse(await Mediator.Send(new DisableAutoTopupRequest(), cancellationToken));
        }
    }
}
