﻿using Microsoft.Extensions.Options;
using System.Data;

namespace CancelBundleApi.Settings.Database;

public interface IDbConnectionSettings
{
    IDbConnection SqlConnection { get; }
}

internal sealed class DbConnectionSettings : IDbConnectionSettings
{
    public IDbConnection SqlConnection { get; }
    public DbConnectionSettings(IDbConnection connection)
    {
        SqlConnection = connection;
    }
}