using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Friendship;

public abstract class GetFriendship
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long UserId { get; set; }
        public AppEnum.FriendshipStatus Status { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.UserId).GreaterThan(0);
            RuleFor(x => x.Status).NotNull().NotEmpty();
        }
        #endregion
    }
    #region Response
    public sealed record Response
    {
        public required UserInfo Initiator { get; set; }
        public required UserInfo Responder { get; set; }
        public required string Status { get; set; }

        public sealed record UserInfo
        {
            public required long Id { get; set; }
            public required string Email { get; set; }
            public required string Username { get; set; }
            public string? FullName { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var friendshipInfo = await _unitOfWork.FriendshipRepository.GetFriendship(x => (x.InitiatorId.Equals(query.UserId) || x.ResponderId.Equals(query.UserId)) && x.Status.Equals(Enum.GetName(typeof(AppEnum
            .FriendshipStatus), query.Status)));

            if (friendshipInfo is not null)
            {
                return ResultWrapper.Success(new Response()
                {
                    Status = friendshipInfo?.Status!,
                    Initiator = new Response.UserInfo()
                    {
                        Id = friendshipInfo?.Initiator?.Id ?? default,
                        Email = friendshipInfo?.Initiator?.Email!,
                        Username = friendshipInfo?.Initiator?.UserName!,
                        FullName = friendshipInfo?.Initiator?.UserDetail?.FullName,
                    },
                    Responder = new Response.UserInfo()
                    {
                        Id = friendshipInfo?.Responder?.Id ?? default,
                        Email = friendshipInfo?.Responder?.Email!,
                        Username = friendshipInfo?.Responder?.UserName!,
                        FullName = friendshipInfo?.Responder?.UserDetail?.FullName,
                    },
                });
            }

            return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
        }
    }
    #endregion
}
