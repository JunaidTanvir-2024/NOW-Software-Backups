﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.User.Signup.SignupResend;

public class SignupResendRequest : IRequest<object>
{
    public string Email { get; set; } = default!;
}

public sealed class SignupResendRequestValidator : AbstractValidator<SignupResendRequest>
{
    public SignupResendRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Email)
            .NotNull()
            .NotEmpty()
            .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
            .Must(p => commonService.IsValidEmailAddress(p))
            .WithMessage("Invalid email address");
    }
}