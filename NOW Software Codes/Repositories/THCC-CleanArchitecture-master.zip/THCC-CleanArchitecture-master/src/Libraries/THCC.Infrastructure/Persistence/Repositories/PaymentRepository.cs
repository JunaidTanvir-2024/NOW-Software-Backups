﻿using System.Data;

using Dapper;

using Microsoft.Extensions.Configuration;

using Newtonsoft.Json;

using Serilog;

using THCC.Application.Interfaces.Repositories;
using THCC.Domain.Aggregates;
using THCC.Domain.Entities;
using THCC.Infrastructure.Persistence.DapperConfigurations;

using static THCC.Domain.Constants.ThccConstants;
using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Persistence.Repositories;

public class PaymentRepository : IPaymentRepository
{
    #region Fields

    private readonly IConfiguration _configuration;
    private readonly ILogger _logger;

    #endregion

    #region Ctors

    public PaymentRepository(
        IConfiguration configuration,
        ILogger logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    #endregion

    #region Methods

    public async Task<long> SaveOrderDetails(
        Order order,
        OrderItem orderItem,
        OrderPayment orderPayment,
        OrderCardPayment orderCardPayment,
        OrderPaypalPayment orderPaypalPayment,
        OrderPoint orderPoint,
        OrderHistory orderHistory)
    {
        try
        {
            var param = new DynamicParameters();

            //Order
            param.Add("@UserId", order.UserId);
            param.Add("@PaymentUserId", orderPayment.PaymentUserId);
            param.Add("@Amount", order.Amount);
            param.Add("@Discount", order.Discount);
            param.Add("@TotalAmount", order.TotalAmount);
            param.Add("@IpAddress", order.IpAddress);
            param.Add("@Device", order.Device);
            param.Add("@DeviceLocation", order.DeviceLocation);
            param.Add("@Description", order.Description);

            //OrderItem
            param.Add("@ProductType", orderItem?.ProductType);
            param.Add("@CardNumber", orderItem?.CardNumber);
            param.Add("@CardPin", orderItem?.CardPin);

            //Order Payment
            param.Add("@PaymentStatus", orderPayment.Stauts);
            param.Add("@PaymentType", orderPayment.PaymentMethodId);

            //Card Payment
            param.Add("@CardMask", orderCardPayment?.CardNumber);
            param.Add("@CardType", orderCardPayment?.CardType);
            param.Add("@CardExpiry", orderCardPayment?.CardExpiry);
            param.Add("@MakeDefault", orderCardPayment?.MakeDefault);
            param.Add("@SaveCard", orderCardPayment?.SaveCard);
            param.Add("@IsAutoPayment", orderCardPayment?.IsAutoPayment);
            param.Add("@AutoPaymentAmount", orderCardPayment?.AutoPaymentAmount);
            param.Add("@AutoPaymentThreshold", orderCardPayment?.AutoPaymentThreshold);

            //Paypal Payment
            param.Add("@PaypalEmail", null);

            //Points
            param.Add("@OpeningBalance", orderPoint.OpeningBalance);
            param.Add("@ClosingBalance", orderPoint.ClosingBalance);
            param.Add("@OpeningPoints", orderPoint.OpeningPoints);
            param.Add("@ClosingPoints", orderPoint.ClosingPoints);
            param.Add("@PointsReceived", orderPoint.PointsReceived);
            param.Add("@PointsRedeemed", orderPoint.PointsRedeemed);

            //History
            param.Add("@OrderHistoryDescription", orderHistory?.Description);

            //Output Parameters
            param.Add("@OrderID", dbType: DbType.Int64, direction: ParameterDirection.Output);
            param.Add("@ErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            param.Add("@ErrorMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 500);

            await DapperWrapper.ExecuteAsync(StoredProcedures.SaveOrderDetails, param, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));

            var orderId = param.Get<long>("@OrderID");
            var errorCode = param.Get<int>("@ErrorCode");
            var errorMessage = param.Get<string>("@ErrorMessage");
            if (errorCode > 0)
            {
                _logger.Error($"Error while saving order: " +
                    $"{JsonConvert.SerializeObject(order)} " +
                    $"{JsonConvert.SerializeObject(orderItem)}  " +
                    $"{JsonConvert.SerializeObject(orderPayment)}  " +
                    $"{JsonConvert.SerializeObject(orderCardPayment)}  " +
                    $"{JsonConvert.SerializeObject(orderPaypalPayment)}  " +
                    $"{JsonConvert.SerializeObject(orderPoint)}  " +
                    $"{JsonConvert.SerializeObject(orderHistory)}  " +
                    $"ErrorMessage:{errorMessage} ");
            }
            return orderId;
        }
        catch (Exception ex)
        {
            _logger.Error($"ex- Error while saving order: {JsonConvert.SerializeObject(order)} {JsonConvert.SerializeObject(orderItem)}  ErrorMessage:{ex.Message} ");
            return 0;
        }
    }

    public async Task<OrderDetail> GetOrderDetails(long? orderId, string orderRef = null!)
    {
        var param = new DynamicParameters();
        param.Add("@OrderID", orderId);
        param.Add("@OrderRef", orderRef);
        return await DapperWrapper.QueryFirstOrDefaultAsync<OrderDetail>(
                        StoredProcedures.OrderDetails, param, commandType: CommandType.StoredProcedure,
                        _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
    }

    public async Task UpdateOrderHistoryStatus(
        long orderId,
        string transactionId,
        OrderStatus orderStatus,
        PaymentStatus paymentStatus,
        string errorMessage,
        string orderHistoryDesc)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@OrderID", orderId);
            parameters.Add("@TransactionID", transactionId);
            parameters.Add("@OrderStatus", orderStatus);
            parameters.Add("@PaymentStatus", paymentStatus);
            parameters.Add("@OrderHistoryDescription", orderHistoryDesc);
            parameters.Add("@ErrorMessage", errorMessage);
            await DapperWrapper.ExecuteAsync(StoredProcedures.UpdateOrderHistoryStatus, parameters, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
        }
        catch (Exception ex)
        {
            _logger.Error($"Class: PaymentRepository, Method: UpdateOrderHistoryStatus, Parameters=> orderId: {orderId}, transactionId:{transactionId} orderStatus:{orderStatus} " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
        }
    }

    public async Task<Customer> GetCustomerByMerchantRef(string merchantRef)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@MerchantRef", merchantRef);
            return await DapperWrapper.QueryFirstOrDefaultAsync<Customer>(
                StoredProcedures.GetCustomerByMerchantReference, parameters, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.CentralizedPayment));
        }
        catch (Exception ex)
        {
            _logger.Error($"Class: PaymentRepository, Method: GetCustomerByMerchantRef, Parameters=> merchantRef: {merchantRef}, " +
                $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
            return null!;
        }
    }

    public async Task SaveOrderHistory(long orderId, string description)
    {
        try
        {
            var param = new DynamicParameters();
            param.Add("@OrderId", orderId);
            param.Add("@OrderHistoryDescription", description);
            await DapperWrapper.ExecuteAsync(StoredProcedures.SaveOrderHistory, param, commandType: CommandType.StoredProcedure,
                _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
        }
        catch (Exception ex)
        {
            _logger.Error($"Class: PaymentRepository, Method: SaveOrderHistory, Parameters=> orderId: {orderId}, " +
                                $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
        }
    }

    #endregion
}
