﻿using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces;

public interface ICommonService : IServicesType.ITransientService
{
    bool IsValidMsisdn(string msisdn);
    bool IsValidEmailAddress(string email, bool useRegEx = false, bool requireDotInDomainName = false);
    bool IsWebRequest();
    (bool IsMobileRequest, DeviceType? DeviceType, MediumType MediumType) IsAppRequest();
    string FormatMsisdn(string msisdn);

}
