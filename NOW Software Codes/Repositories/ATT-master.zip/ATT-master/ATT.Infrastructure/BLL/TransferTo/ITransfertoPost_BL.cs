﻿using ATT.Models.Contracts;
using ATT.Models.Contracts.TransferTo.Request;
using ATT.Models.Contracts.TransferTo.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.TransferTo
{
    public interface ITransfertoPost_BL
    {

        Task<GenericApiResponse<DtOnePromotionsResponse>> DtOneGetPromotions();
        Task<GenericApiResponse<TransferToOperatorsByCountryId>> DTOneOperatorListbyCountry(string currency, int CountryID, string productCode);
        Task<GenericApiResponse<TransferToMSISDNInfoResponse>> transfertoParseMSISDN(string msisdn, string currency, long? sourceMSISDN = null);

        Task<GenericApiResponse<string>> transfertoGoodsServiceParseMsisdn(string msisdn, string countryId, string serviceId, string currency);

        Task<GenericApiResponse<string>> transfertoReserveID(string currency);

        Task<GenericApiResponse<Dictionary<string, string>>> transfertoCountryList(string currency, string productCode);

        Task<GenericApiResponse<Dictionary<string, string>>> transferToOperatorsList(string currency, int CountryID);

        Task<GenericApiResponse<string>> transferToOperatorPriceList(string currency, int OperatorID, long? sourceMSISDN = null);

        Task<GenericApiResponse<decimal>> transferToGetAccountBalance(string currency);

        Task<GenericApiResponse<string>> transferToCheckService(string currency);

        Task<GenericApiResponse<transfertoExecuteTransaction>> transfertoTransaction(string fromMsisdn, string toMsisdn, string amount, string currency, string operatorid, string success_sms_quote, long requestKey);
        Task<GenericApiResponse<transfertoExecuteTransaction>> transfertoTransaction_TRH(string fromMsisdn, string toMsisdn, string amount, string currency, string operatorid, string success_sms_quote, long requestKey, string productCode);

        Task<GenericApiResponse<string>> getOperatorProductsMSISDN(string destinationMSISDN, string currency, string Product);

        //Task<GenericApiResponse<string>> getOperatorProductsMSISDN(string destinationMSISDN, string currency,string productCode);

        Task<GenericApiResponse<string>> getOperatorProductsMSISDN(string destinationMSISDN, string currency, long? sourceMSISDN = null);

        Task<GenericApiResponse<TransferToGetTransactionResponse>> transfertoGetTransactionDetailFromTransactionId(string transactionId, string account);

        Task<GenericApiResponse<TransferToGetTransactionResponse>> transfertoGetTransactionDetailFromKey(string transactionKey, string account);

        Task<GenericApiResponse<string>> getFreeSwitchOperatorProductsMSISDN(string destinationMSISDN, string currency);

        Task<GenericApiResponse<transfertoExecuteTransaction>> transfertoExecuteTransactionFreeSwitch(string fromMsisdn, string toMsisdn, string amount, string currency, string operatorid, string success_sms_quote, long requestKey);


        /// GOODS and SERVICES 

        Task<GenericApiResponse<TransfertoServciesList>> transfertoServiceList(string currency);

        Task<GenericApiResponse<TransferToCountriesListByServices>> transfertoCountryListByService(string currency, int serviceId);

        Task<GenericApiResponse<TransfertoOperatorListByServices>> transfertoOperatorListByService(string currency, int serviceId);

        Task<GenericApiResponse<TransfertoDataBundleProductList>> transfertoDataBundleProductList(string currency, int serviceId, int operatorId, int countryid);

        Task<GenericApiResponse<TransfertoTranscationDataBundleGSReponse>> transfertoDataBundleTransaction(TransfertoTranscationDataBundleGSRequest data);

        Task<GenericApiResponse<TransfertoTranscationDataBundleGSReponse>> transfertoGetDataBundleTransactionByTransactionid(string currency, int transactionid);


    }
}
