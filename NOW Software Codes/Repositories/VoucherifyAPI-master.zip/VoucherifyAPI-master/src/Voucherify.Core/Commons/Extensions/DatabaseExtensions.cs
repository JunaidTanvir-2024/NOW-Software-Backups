﻿using Microsoft.Extensions.Configuration;

namespace Voucherify.Core.Commons.Extensions;

public static class DatabaseExtensions
{
    private static IConfiguration? _configuration;

    // Get DbConnection by passing connection string name
    public static void SetConfiguration(IConfiguration configuration)
    {
        _configuration = configuration;
    }
    public static string? GetDbConnection(string dbConnectionString)
    {
        return _configuration?.GetConnectionString(dbConnectionString);
    }
}
