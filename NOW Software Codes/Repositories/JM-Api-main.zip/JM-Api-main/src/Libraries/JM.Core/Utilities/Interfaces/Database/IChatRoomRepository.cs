using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;

public interface IChatRoomRepository : ResolveAs.IScoped
{
    Task<ChatRoom> AddChatRoom(ChatRoom chatRoom);
    void UpdateChatRoom(ChatRoom chatRoom);
    Task<ChatRoom?> GetChatRoom(Expression<Func<ChatRoom, bool>> expression);
    Task<IEnumerable<ChatRoom>> GetChatRoomList(Expression<Func<ChatRoom, bool>> expression = default!);
}
