﻿using Microsoft.Extensions.Options;
using System;
using System.Linq;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class InternationalTopupServiceFeeCalculator : IInternationalTopupServiceFeeCalculator
    {
        private readonly ATTConfig _attConfig;

        public InternationalTopupServiceFeeCalculator(IOptions<ATTConfig> attConfig)
        {
            this._attConfig = attConfig.Value;
        }
        public (decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) Calculate(string origination, string destination, string currency, decimal productPrice)
        {
            var serviceFeePercentage = decimal.Zero;
            var serviceFeeDiscountPercentage = decimal.Zero;
            var excludedOriginations = _attConfig.ServiceFee.ExcludedOriginations;
            var excludedDestinations = _attConfig.ServiceFee.ExcludedDestinations;

            var currencyFeeRules = _attConfig.ServiceFee.FeeRules;
            //adding fee rule
            var appliedRule = currencyFeeRules.FirstOrDefault(x => x.Currency.Equals(currency, System.StringComparison.InvariantCultureIgnoreCase)
			&& ((string.IsNullOrEmpty(x.Origination) || x.Origination.Equals(origination, StringComparison.InvariantCultureIgnoreCase))
			&& (string.IsNullOrEmpty(x.Destination) || x.Destination.Equals(destination, StringComparison.InvariantCultureIgnoreCase)))
			&& productPrice >= x.Min && (productPrice < x.Max || x.Max == -1));
            if (appliedRule != null)
            {
                serviceFeePercentage = appliedRule.FeePercentage;
            }
            else
            {
                serviceFeePercentage = decimal.Zero;
            }
            var feeDiscountRules = _attConfig.ServiceFee.FeeDiscountRules;
            var appliedFeeDiscountRule = feeDiscountRules.FirstOrDefault(x => (string.IsNullOrEmpty(x.Currency) || x.Currency.Equals(currency, System.StringComparison.InvariantCultureIgnoreCase))
            && (string.IsNullOrEmpty(x.Origination) || x.Origination.Equals(origination, StringComparison.InvariantCultureIgnoreCase))
            && (string.IsNullOrEmpty(x.Destination) || x.Destination.Equals(destination, StringComparison.InvariantCultureIgnoreCase)));
            if (appliedFeeDiscountRule != null)
            {
                serviceFeeDiscountPercentage = appliedFeeDiscountRule.DiscountPercentage;
            }
            else
            {
                serviceFeeDiscountPercentage = decimal.Zero;
            }
            if (excludedOriginations.Any(x => x.Equals(origination, System.StringComparison.InvariantCultureIgnoreCase))
            || excludedDestinations.Any(x => x.Equals(destination, System.StringComparison.InvariantCultureIgnoreCase)))
            {
                serviceFeeDiscountPercentage = 100;
            }
            var serviceFee = serviceFeePercentage / 100 * productPrice;
            var serviceFeeDiscount = serviceFeeDiscountPercentage / 100 * serviceFee;
            var totalServiceFee = serviceFee - serviceFeeDiscount;
            return (Math.Round(totalServiceFee, 2), Math.Round(serviceFee, 2), Math.Round(serviceFeeDiscount, 2));
        }
    }
}
