﻿using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;

namespace Application.Features.Payment.Card.NewCardPayment;

public class NewCardPaymentRequest : IRequest<Result<CardResponse>>
{
    public string? Msisdn { get; set; }

    public PaymentNewCardInfo PaymentCardInfo { get; set; } = default!;

    public PaymentAddressInfo PaymentAddressInfo { get; set; } = default!;

    public PaymentTopupInfo? TopupInfo { get; set; }

    public PaymentBundleInfo? BundleInfo { get; set; }

    [JsonIgnore]
    public string? Email { get; set; }

    [JsonIgnore]
    public string? IpAddress { get; set; }
}



