﻿namespace Application.Features.Device.ConfirmDeviceResend;
public class ConfirmDeviceResendRequest : IRequest<Result<object>>
{
    public string EmailOrPhone { get; set; } = default!;
    public string DeviceId { get; set; } = default!;
}