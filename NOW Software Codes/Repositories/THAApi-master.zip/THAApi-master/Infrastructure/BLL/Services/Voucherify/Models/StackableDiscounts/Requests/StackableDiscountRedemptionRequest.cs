﻿using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Requests
{
    public class StackableDiscountRedemptionRequest
    {
        public StackableDiscountCustomerInfo Customer { get; set; } = null!;
        public StackableDiscountOrderInfo Order { get; set; } = null!;
        public StackableDiscountInfo Redemption { get; set; } = null!;
    }
}
