﻿using ATT.Infrastructure.BLL.Common;
using ATT.Infrastructure.DAL;
using ATT.Models.Configurations;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Common;
using ATT.Models.Contracts.Mobiquity.Request;
using ATT.Models.Contracts.Mobiquity.Response;
using ATT.Models.Database;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PhoneNumbers;
using RestSharp;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using ServiceProvider = ATT.Models.Contracts.Common.ServiceProvider;

namespace ATT.Infrastructure.BLL.Mobiquity
{
    public class MobiquityPost_BL : IMobiquityPost_BL
    {
        private ILogger _logger;
        private MobiquityConfig _mobiquityConf;
        private ICommon_BL _common_BL;
        private IAttDb_DL _appDB;
        private readonly TwilioConfig TwilioConfig;
        private readonly SmtpConfig SmtpConfig;
        private readonly HttpConfig httpConfig;

        public MobiquityPost_BL(IAttDb_DL _db, ILogger appLoggers, IOptions<MobiquityConfig> mobiquityConf, ICommon_BL common_BL, IOptions<TwilioConfig> twilioConfig, IOptions<SmtpConfig> smpt, IOptions<HttpConfig> http)
        {
            _appDB = _db;
            _logger = appLoggers;
            _mobiquityConf = mobiquityConf.Value;
            TwilioConfig = twilioConfig.Value;
            SmtpConfig = smpt.Value;
            _common_BL = common_BL;
            httpConfig = http.Value;
        }
        public async Task<JsonOperatorProductResponse> MobiquityTHAGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, bool useDbRates, int? cdsp_config_id, string productCode, string productItemCode)
        {

            string iso = string.Empty;
            PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
            try
            {
                string phone = ToMsisdn;
                if (!phone.StartsWith("+"))
                    phone = "+" + phone;
                // phone must begin with '+'
                PhoneNumber numberProto = phoneUtil.Parse(phone, "");
                int countryCode = numberProto.CountryCode;
                iso = phoneUtil.GetRegionCodeForCountryCode(countryCode);
            }
            catch (NumberParseException e)
            {
                _logger.Debug($"  MobiquityTHAGetPhoneOperator-PhoneNumberUtil unable to fetch iso code against " + ToMsisdn + " error " + e.ToString());
            }

            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 5;
            int suggesstionCount = 7;
            try
            {

                // Validating fraud customers , at_check_fraud

                try
                {

                    bool isPermitted = await _appDB.CheckFraudUser("", ToMsisdn, fromMSISDN);
                    if (isPermitted == false)
                    {
                        result.errorCode = 3;
                        result.status = "Failure";
                        result.message = "Fraud detected. Access Blocked.";
                        return result;
                    }

                }
                catch (Exception ex)
                {
                    _logger.Error($"  \"GET /MobiquityTHAGetPhoneOperator\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {ToMsisdn}, destinationMSISDN: {fromMSISDN}, currency:{account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = "General API Access Error: " + ex.Message;
                    return result;

                }

                //var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN);// Get the discount if any exists in db agains destination

                PayLoad payload = new PayLoad();
                result.message = "Operators found";
                result.status = "Success";
                result.errorCode = 0;
                List<AttOperator> operators = new List<AttOperator>();
                List<AttProduct> products = new List<AttProduct>();
                AttOperator operatorDetails = new AttOperator();

                operatorDetails.id = _mobiquityConf.receiver_idValue;
                operatorDetails.name = _mobiquityConf.operator_name;
                operatorDetails.country = _mobiquityConf.operator_Country;
                operatorDetails.nowtelTransactionReference = Guid.NewGuid().ToString();
                operatorDetails.ProductItemCode = productItemCode;
                operatorDetails.iconUri = _mobiquityConf.operator_logoUrl;

                DBResponse dbResult = new DBResponse();
                dbResult = await _appDB.insertTransactionGUID_Tha(operatorDetails.nowtelTransactionReference, account.ToUpper(), ToMsisdn, "{}", "N/A", "N/A", result.servcieproviderid, fromMSISDN, productItemCode, _mobiquityConf.operator_country_code, operatorDetails.id, productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country);
                if (dbResult.DBStatus == 0)
                {
                    _logger.Debug($"  MobiquityTHAGetPhoneOperator  Failed  Source:Mobiquity API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = " Source:Mobiquity API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                    return result;
                }
                else
                {
                    int from_country_code = 0;
                    phoneUtil = PhoneNumberUtil.GetInstance();
                    try
                    {
                        if (!fromMSISDN.StartsWith("+"))
                            fromMSISDN = "+" + fromMSISDN;
                        PhoneNumber numberProto = phoneUtil.Parse(fromMSISDN, "");
                        from_country_code = numberProto.CountryCode;
                    }
                    catch (NumberParseException e)
                    {

                    }

                    THACustomerChargeValuesForReplacement custChargeValues = new THACustomerChargeValuesForReplacement();
                    custChargeValues = await _appDB.GetTHAMobiquityCustomerChargeValuesForReplacement(cdsp_config_id.Value, result.servcieproviderid, from_country_code, operatorDetails.name);

                    bool productFound = false;
                    foreach (var custChargeValue in custChargeValues.chargeValues)
                    {

                        var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN, custChargeValue.selling_price);// Get the discount if any exists in db agains destination
                        AttProduct product = new AttProduct();
                        product.product = custChargeValue.received_amount.ToString();
                        productFound = true;
                        product.receiverccy = _mobiquityConf.currencyName;
                        product.clientccy = account;
                        product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                        product.transactionfeeClientccy = 0.ToString();
                        product.totalPriceClientccy = custChargeValue.selling_price.ToString();

                        product.discountPercentage = discountPercentage;
                        product.orignalAmount = product.totalPriceClientccy;
                        product.itemPriceClientccy = Math.Round((Convert.ToDecimal(product.orignalAmount) - (Convert.ToDecimal(product.orignalAmount) * product.discountPercentage / 100)), 2).ToString();
                        product.totalPriceClientccy = product.itemPriceClientccy;

                        products.Add(product);

                        await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                account,
                product.receiverccy,
                product.product,
               custChargeValue.buying_price.ToString(),
                custChargeValue.buying_price.ToString(),
                product.totalPriceClientccy,
                //endrate.CustomerChargeValue.ToString(),
                //endrate.CustomerChargeValue.ToString(),
                0,
                null,
                null,
                   discountPercentage: product.discountPercentage,
                   orignalAmount: product.orignalAmount
                );
                    }

                    if (!productFound)
                    {
                        if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                ErrorMessage = $"ProductNotMatched: \n\r ConfiguredRates: {JsonConvert.SerializeObject(custChargeValues)}",
                                Status = "Failure",
                                FromMsisdn = fromMSISDN,
                                ToMsisdn = ToMsisdn,
                                ProductCode = productCode,
                                ProductItemCode = productItemCode,
                                ServiceProviderName = ServiceProvider.Mobiquity.ToString(),
                                TransationType = TransationType.Get
                            });
                        }
                        await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "ProductNotMatched", DbConfiguredValues: JsonConvert.SerializeObject(custChargeValues));
                    }


                    operatorDetails.accessid = dbResult.InsertId;
                    operatorDetails.products = products;
                    operators.Add(operatorDetails);
                    payload.operators = operators;
                    result.payload = payload;
                    _logger.Information($"  MobiquityTHAGetPhoneOperator  Success      Parameters-msisdn:{ToMsisdn} currency:{account}");



                    return result;
                }
            }
            catch (Exception ex)
            {
                var date = DateTime.Now;
                _logger.Debug($"  MobiquityTHAGetPhoneOperator  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";

                if (SmtpConfig.sendErrorGetProductsEmail)
                {
                    await _common_BL.SendEmail(new EmailTransactionModel()
                    {
                        ErrorMessage = ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                        Status = "Failure",
                        FromMsisdn = fromMSISDN,
                        ToMsisdn = ToMsisdn,
                        ProductCode = productCode,
                        ProductItemCode = productItemCode,
                        ServiceProviderName = ServiceProvider.Mobiquity.ToString(),
                        TransationType = TransationType.Get
                    });
                }
                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""));
                return result;
            }

        }


        public async Task<object> MobiquityTHATopUp(ExecuteData request)
        {
            try
            {
                string json = "";
                string returnData = "";
                DateTime TopUpApiStartTime = DateTime.Now;
                DateTime TopUpApiEndTime = TopUpApiStartTime;

                string nowtelTransactionReference = request.nowtelTransactionReference;
                string product = request.product;
                string messageToRecipient = request.messageToRecipient;
                string fromMSISDN = request.fromMSISDN;

                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(nowtelTransactionReference, product);


                guidReferneceRecord.tomsisdn = guidReferneceRecord.tomsisdn.Replace("+", "");
                guidReferneceRecord.tomsisdn = guidReferneceRecord.tomsisdn.StartsWith("00") == true ? guidReferneceRecord.tomsisdn.Remove(0, 2) : guidReferneceRecord.tomsisdn;


                if (guidReferneceRecord == null)
                {
                    _logger.Debug($"   /CRM_ATT_MobiquityTopUp  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return result;
                }
                try
                {


                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn, request.nowtelTransactionReference.Remove(0, 14), request.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"  \"GET /CRM_ATT_MobiquityTopUp\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return result;
                }
                string clientId = _mobiquityConf.username;

                try
                {
                    string recipientIso = string.Empty;
                    string senderIso = string.Empty;
                    PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
                    try
                    {
                        ///Receipent ISO Code
                        string phone = guidReferneceRecord.tomsisdn;
                        if (!phone.StartsWith("+"))
                            phone = "+" + phone;
                        // phone must begin with '+'
                        PhoneNumber numberProto = phoneUtil.Parse(phone, "");
                        int countryCode = numberProto.CountryCode;
                        recipientIso = phoneUtil.GetRegionCodeForCountryCode(countryCode);

                        //Sender ISO Code
                        phone = request.fromMSISDN;
                        if (!phone.StartsWith("+"))
                            phone = "+" + phone;
                        // phone must begin with '+'
                        numberProto = phoneUtil.Parse(phone, "");
                        countryCode = numberProto.CountryCode;
                        senderIso = phoneUtil.GetRegionCodeForCountryCode(countryCode);

                    }
                    catch (NumberParseException e)
                    {
                        _logger.Debug($"  CRM_ATT_MobiquityTopUp-PhoneNumberUtil unable to fetch iso code against ToNumber" + guidReferneceRecord.tomsisdn + ". From Number" + request.fromMSISDN + " error " + e.ToString());
                    }


                    var subUrl = $"/incoming/CTMMOREQ/v2";

                    var _tomsisdn = guidReferneceRecord.tomsisdn.StartsWith("93") ? "0" + guidReferneceRecord.tomsisdn.Substring(2) : guidReferneceRecord.tomsisdn;


                    MobiquityTopUpRequest topUpRequest = new MobiquityTopUpRequest()
                    {

                        serviceCode = _mobiquityConf.serviceCode,
                        transactionAmount = guidReferneceRecord.toAmount.ToString(),
                        initiator = _mobiquityConf.initiator,
                        bearerCode = _mobiquityConf.bearerCode,
                        language = _mobiquityConf.language,
                        currency = _mobiquityConf.currency,
                        custRefNo = _tomsisdn,
                        RechargeType = _mobiquityConf.RechargeType,
                        remarks = _mobiquityConf.remarks,
                        transactor = new transactor
                        {
                            bundle = _mobiquityConf.transactor_bundle,
                            idType = _mobiquityConf.transactor_idType,
                            idValue = _mobiquityConf.transactor_idValue,
                            mpin = _mobiquityConf.transactor_mpin,
                            productId = _mobiquityConf.transactor_productId
                        },
                        receiver = new receiver
                        {
                            idType = _mobiquityConf.receiver_idType,
                            idValue = _mobiquityConf.receiver_idValue
                        },
                        rechargeReceiver = new rechargeReceiver
                        {
                            idType = "mobileNumber",
                            idValue = _tomsisdn
                        }

                    };




                    json = JsonConvert.SerializeObject(topUpRequest);
                    var baseAddress = new Uri(_mobiquityConf.APiURL);
                    HttpClientHandler clientHandler = new HttpClientHandler();
                    clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

                    HttpClient client = new HttpClient(clientHandler) { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                    client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
                    client.DefaultRequestHeaders.Add("username", _mobiquityConf.username);
                    client.DefaultRequestHeaders.Add("password", _mobiquityConf.password);

                    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");



                    TopUpApiStartTime = DateTime.Now;
                    var httpResponse = await client.PostAsync(subUrl, httpContent);
                    TopUpApiEndTime = DateTime.Now;

                    if (httpResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        if (_mobiquityConf.JsonResponseLogging)
                        {
                            _logger.Information($"Mobiquity CRM_ATT_MobiquityTopUp Request {json} Response {returnData}");
                        }
                        var response = JsonConvert.DeserializeObject<MobiquityTopUpResponse>(returnData);


                        //Failure Occurred
                        if (response.status == null || response.status.ToUpper().Trim() != "SUCCEEDED")
                        {
                            returnData = await httpResponse.Content.ReadAsStringAsync();
                            var errorResponse = JsonConvert.DeserializeObject<CommandResponse>(returnData);

                            try
                            {

                                await _appDB.insertAirTimeTransferTransaction_Trh_v4(
                               DateTime.Now.ToString(),
                                clientId, // Username
                               guidReferneceRecord.selling_price,         // Customer Charge Value
                               -1,
                               decimal.Parse(product),
                               guidReferneceRecord.account,
                               guidReferneceRecord.toCurrency,
                               guidReferneceRecord.destination_country,
                               "Failure",
                               "HttpStatusCode:" + httpResponse.StatusCode.ToString(),
                               guidReferneceRecord.operatorCode,
                               product,
                               guidReferneceRecord.operatorName,
                               null,
                               "",
                               fromMSISDN,
                               guidReferneceRecord.tomsisdn,
                               5,
                               messageToRecipient,
                               guidReferneceRecord.productCode,
                               guidReferneceRecord.ProductItemCode,
                               nowtelTransactionReference,
                               json,
                                    returnData,
                                     guidReferneceRecord.discountPercentage.ToString(),
                                guidReferneceRecord.orignalAmount,
                                    TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                    );


                                if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                                {
                                    await _common_BL.SendEmail(new EmailTransactionModel()
                                    {
                                        accessGUID = nowtelTransactionReference,
                                        DestinationCountry = guidReferneceRecord.destination_country,
                                        ErrorMessage = "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + returnData,
                                        Status = "Failure",
                                        FromMsisdn = guidReferneceRecord.frommsisdn,
                                        ToMsisdn = guidReferneceRecord.tomsisdn,
                                        OperatorId = guidReferneceRecord.operatorCode,
                                        OperatorName = guidReferneceRecord.operatorName,
                                        ProductCode = guidReferneceRecord.productCode,
                                        ProductItemCode = guidReferneceRecord.ProductItemCode,
                                        ServiceProviderName = ServiceProvider.Mobiquity.ToString(),
                                        TransationType = TransationType.Execute

                                    });
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.Debug($"  CRM_ATT_MobiquityTopUp  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                            }


                            _logger.Debug($"  CRM_ATT_MobiquityTopUp  Failed  Source:Mobiquity API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-N/A          Reason={ errorResponse.Command.TXNSTATUS + ":" + errorResponse.Command.MESSAGE}");
                            var resultt = new
                            {
                                errorCode = 2,
                                status = "Failure",
                                message = errorResponse.Command.TXNSTATUS + ":" + errorResponse.Command.MESSAGE
                            };

                            return resultt;
                        }

                        //Successful transaction
                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh_v4(
                                                            DateTime.Now.ToString(),
                                                             clientId, // Username
                                                            guidReferneceRecord.selling_price,       // Customer Charge Value
                                                            guidReferneceRecord.CustomerChargeValue,  // Actual Charge Value
                                                            Convert.ToDecimal(guidReferneceRecord.product),
                                                            guidReferneceRecord.account,
                                                            _mobiquityConf.currencyName,
                                                            guidReferneceRecord.destination_country,
                                                            "Success",
                                                            "",
                                                            _mobiquityConf.receiver_idValue,
                                                            product,
                                                            _mobiquityConf.operator_name,
                                                            null,
                                                            response.transactionId,
                                                            fromMSISDN,
                                                            guidReferneceRecord.tomsisdn,
                                                            5,
                                                            messageToRecipient,
                                                            guidReferneceRecord.productCode,
                                                            guidReferneceRecord.ProductItemCode,
                                                            nowtelTransactionReference,
                                                            json,
                                                            returnData,
                                                             guidReferneceRecord.discountPercentage.ToString(),
                                                            guidReferneceRecord.orignalAmount,
                                                            TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                                            );


                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  CRM_ATT_MobiquityTopUp  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }

                        _logger.Information($"  CRM_ATT_MobiquityTopUp   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{response.transactionId}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.selling_price, // Customer Charge Value
                            currency = guidReferneceRecord.fromCurrency,
                            reference = response.transactionId
                        };

                        if (_mobiquityConf.SendSmsToSender)
                        {
                            var smsToSend = _mobiquityConf.smsTemplate
                                .Replace("#currency#", guidReferneceRecord.toCurrency)
                                .Replace("#amount#", guidReferneceRecord.toAmount)
                                .Replace("#to#", guidReferneceRecord.tomsisdn)
                                .Replace("#TransRef#", response.transactionId);
                            _common_BL.SendTwilioSms(request.fromMSISDN, smsToSend, guidReferneceRecord.productCode);

                            // Option Message Sms to Destination Msisdn
                            //var smsBody = request.messageToRecipient;
                            //await SendTwilioSms(guidReferneceRecord.tomsisdn, smsBody, guidReferneceRecord.productCode, true);
                        }
                        return result;
                    }
                    else
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<CommandResponse>(returnData);

                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh_v4(
                           DateTime.Now.ToString(),
                            clientId, // Username
                           guidReferneceRecord.selling_price,         // Customer Charge Value
                           -1,
                           decimal.Parse(product),
                           guidReferneceRecord.account,
                           guidReferneceRecord.toCurrency,
                           guidReferneceRecord.destination_country,
                           "Failure",
                           "HttpStatusCode:" + httpResponse.StatusCode.ToString(),
                           guidReferneceRecord.operatorCode,
                           product,
                           guidReferneceRecord.operatorName,
                           null,
                           "",
                           fromMSISDN,
                           guidReferneceRecord.tomsisdn,
                           5,
                           messageToRecipient,
                           guidReferneceRecord.productCode,
                           guidReferneceRecord.ProductItemCode,
                           nowtelTransactionReference,
                           json,
                                returnData,
                                 guidReferneceRecord.discountPercentage.ToString(),
                                guidReferneceRecord.orignalAmount,
                                TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                );


                            if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                            {
                                await _common_BL.SendEmail(new EmailTransactionModel()
                                {
                                    accessGUID = nowtelTransactionReference,
                                    DestinationCountry = guidReferneceRecord.destination_country,
                                    ErrorMessage = "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + returnData,
                                    Status = "Failure",
                                    FromMsisdn = guidReferneceRecord.frommsisdn,
                                    ToMsisdn = guidReferneceRecord.tomsisdn,
                                    OperatorId = guidReferneceRecord.operatorCode,
                                    OperatorName = guidReferneceRecord.operatorName,
                                    ProductCode = guidReferneceRecord.productCode,
                                    ProductItemCode = guidReferneceRecord.ProductItemCode,
                                    ServiceProviderName = ServiceProvider.Mobiquity.ToString(),
                                    TransationType = TransationType.Execute

                                });
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  CRM_ATT_MobiquityTopUp  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        _logger.Debug($"  CRM_ATT_MobiquityTopUp  Failed  Source:Mobiquity API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-N/A          Reason={ errorResponse.Command.TXNSTATUS + ":" + errorResponse.Command.MESSAGE}");
                        var result = new
                        {
                            errorCode = 2,
                            status = "Failure",
                            message = errorResponse.Command.TXNSTATUS + ":" + errorResponse.Command.MESSAGE
                        };

                        return result;
                    }
                }
                catch (Exception ex)
                {
                    var date = DateTime.Now;


                    if (TopUpApiEndTime < TopUpApiStartTime)
                    {
                        TopUpApiEndTime = date;
                    }

                    try
                    {
                        await _appDB.insertAirTimeTransferTransaction_Trh_v4(
                        DateTime.Now.ToString(),
                        clientId, // Username
                        guidReferneceRecord.selling_price,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        guidReferneceRecord.toCurrency,
                        guidReferneceRecord.destination_country,
                        "FailureException",
                        ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                        guidReferneceRecord.operatorCode,
                        product,
                        guidReferneceRecord.operatorName,
                        null,
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        5,
                        messageToRecipient,
                        guidReferneceRecord.productCode,
                        guidReferneceRecord.ProductItemCode,
                        nowtelTransactionReference,
                         json,
                                returnData,
                                 guidReferneceRecord.discountPercentage.ToString(),
                                guidReferneceRecord.orignalAmount,
                                TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                        );

                        if (SmtpConfig.sendErrorExecuteTransactionEmail)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                accessGUID = nowtelTransactionReference,
                                DestinationCountry = guidReferneceRecord.destination_country,
                                ErrorMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                                Status = "FailureException",
                                FromMsisdn = guidReferneceRecord.frommsisdn,
                                ToMsisdn = guidReferneceRecord.tomsisdn,
                                OperatorId = guidReferneceRecord.operatorCode,
                                OperatorName = guidReferneceRecord.operatorName,
                                ProductCode = guidReferneceRecord.productCode,
                                ProductItemCode = guidReferneceRecord.ProductItemCode,
                                ServiceProviderName = ServiceProvider.Mobiquity.ToString(),
                                TransationType = TransationType.Execute

                            });
                        }
                    }
                    catch (Exception dbException)
                    {
                        _logger.Debug($"  CRM_ATT_MobiquityTopUp  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _logger.Debug($"  CRM_ATT_MobiquityTopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return errorResult;
                }
            }
            catch (Exception ex)
            {
                _logger.Debug($"  CRM_ATT_MobiquityTopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return errorResult;
            }

        }

        public async Task<JsonMobiquityBalanceResponse> MobiquityGetBalance()
        {
            JsonMobiquityBalanceResponse result = new JsonMobiquityBalanceResponse();
            try
            {
                MobiquityBalanceEnquiryRequest req = new MobiquityBalanceEnquiryRequest
                {
                    COMMAND = new BalanceEnquiryCommand
                    {
                        TYPE = _mobiquityConf.BalanceApiRequestType,
                        MSISDN = _mobiquityConf.transactor_idValue,
                        PROVIDER = _mobiquityConf.currency,
                        PAYID = _mobiquityConf.transactor_productId,
                        MPIN = _mobiquityConf.transactor_mpin,
                        PIN = _mobiquityConf.transactor_mpin,
                        BLOCKSMS = _mobiquityConf.BalanceApiBLOCKSMS,
                        LANGUAGE1 = _mobiquityConf.BalanceApiLANGUAGE1,
                        CELLID = _mobiquityConf.BalanceApiCELLID,
                        FTXNID = _mobiquityConf.BalanceApiFTXNID
                    }

                };

                var json = JsonConvert.SerializeObject(req);
                var baseAddress = new Uri(_mobiquityConf.APiURL);
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

                HttpClient client = new HttpClient(clientHandler) { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
                client.DefaultRequestHeaders.Add("username", _mobiquityConf.username);
                client.DefaultRequestHeaders.Add("password", _mobiquityConf.password);

                var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
                var httpResponse = await client.PostAsync("/incoming/RBEREQ", httpContent);

                if(httpResponse.StatusCode==HttpStatusCode.OK && httpResponse.IsSuccessStatusCode)
                {
                    result.errorCode = 0;
                    result.message= "Success";
                    result.status = "Success";
                    var payload = await httpResponse.Content.ReadAsStringAsync();
                    result.payload = JsonConvert.DeserializeObject<payload>(payload);
                    return result;
                }
                else
                {
                    result.errorCode = (int)httpResponse.StatusCode;
                    result.message = httpResponse.StatusCode.ToString();
                    result.status = "Failure";
                    return result;
                }
                return result;
            }
            catch (Exception ex)
            {
                _logger.Debug($"  MobiquityGetBalance  Failed  Source: Message:{ex.ToString()}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                return result;
            }

        }
    }
}
