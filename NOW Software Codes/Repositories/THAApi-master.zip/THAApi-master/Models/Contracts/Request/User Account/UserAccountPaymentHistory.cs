﻿using System;

namespace Models.Contracts.Request
{
    public class UserAccountPaymentHistory
    {
        public DateTime TransDate { get; set; }
        public string Amount { get; set; }
        public string Method { get; set; }
        public string Type { get; set; }
        public string Reference { get; set; }
        public bool Successfull { get; set; }
    }
}
