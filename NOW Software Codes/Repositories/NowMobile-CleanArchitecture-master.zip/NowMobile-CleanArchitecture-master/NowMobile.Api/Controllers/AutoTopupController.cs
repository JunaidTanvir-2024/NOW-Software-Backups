﻿using Application.Features.AutoTopup.Card;
using Application.Features.AutoTopup.Card.Existing;
using Application.Features.AutoTopup.Card.New;
using Application.Features.AutoTopup.GetAutoTopup;
using Application.Features.AutoTopup.Paypal;

using Application.Features.AutoTopup.SetAutoTopup;
using Application.Features.AutoTopup.ThresholdAmount;

namespace NowMobile.Api.Controllers;

public class AutoTopupController : VersionedApiController
{
    [HttpGet("card"), OpenApiOperation("Get auto topup settings", "")]
    public async Task<IActionResult> GetAutoTopup([FromQuery] GetAutoTopupRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("card"), OpenApiOperation("Set auto topup settings", "")]
    public async Task<IActionResult> SetAutoTopup([FromBody] SetAutoTopupRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("card/new"), OpenApiOperation("Set auto topup with new card", "")]
    public async Task<IActionResult> SetAutoTopupNewCard([FromBody] SetAutoTopupNewCardRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("card/existing"), OpenApiOperation("Set auto topup with existing card", "")]
    public async Task<IActionResult> SetAutoTopupExistingCard([FromBody] SetAutoTopupExistingCardRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("paypal"), OpenApiOperation("Set auto topup settings by paypal", "")]
    public async Task<IActionResult> SetAutoTopup([FromBody] SetAutoTopupPaypalRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpGet("card/threshold"), OpenApiOperation("Get topup threshold amounts", "")]
    public async Task<IActionResult> GetThresholdAmounts()
    {
        return Ok(await Mediator.Send(new ThresholdAmountRequest()));
    }
    private string GetIpAddress() =>
    Request.Headers.ContainsKey("X-Forwarded-For")
        ? Request.Headers["X-Forwarded-For"]
        : HttpContext.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "N/A";
}
