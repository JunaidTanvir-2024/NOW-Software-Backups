﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace THCC.Infrastructure.Persistence.EntityFrameworkConfigurations.DbMigrations
{
    /// <inheritdoc />
    public partial class THCCMigrationV3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "CreatedDateTime",
                table: "Users",
                type: "datetime2",
                nullable: true,
                defaultValue: new DateTime(2023, 7, 17, 7, 47, 11, 915, DateTimeKind.Utc).AddTicks(5852),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "CreatedDateTime",
                table: "Users",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true,
                oldDefaultValue: new DateTime(2023, 7, 17, 7, 47, 11, 915, DateTimeKind.Utc).AddTicks(5852));
        }
    }
}
