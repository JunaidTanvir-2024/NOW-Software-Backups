﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Request
{
    public class GetOperatorsRequest : BaseRequest
    {
        public string command = "getOperators";

        public string country { get; set; }

        public int local { get; set; }

        public int productType { get; set; } 


        public GetOperatorsRequest()
        {
            local = 0;
            productType = 0;
        }
    }
}
