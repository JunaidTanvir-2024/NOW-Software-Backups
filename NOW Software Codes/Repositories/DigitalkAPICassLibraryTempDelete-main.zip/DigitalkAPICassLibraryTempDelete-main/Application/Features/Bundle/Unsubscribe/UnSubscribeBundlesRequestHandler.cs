namespace Application.Features.Bundle.Bundle;

public sealed class UnSubscribeBundlesRequestHandler : IRequestHandler<UnSubscribeBundlesRequest, Result<bool>>
{    
    private readonly IStringLocalizer<UnSubscribeBundlesRequestHandler> _localizer;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;
    private readonly IBundleService _bundleService;
    public UnSubscribeBundlesRequestHandler(
        ICommonService commonService,
        IUserService userService,
        IBundleService bundleService,
         IStringLocalizer<UnSubscribeBundlesRequestHandler> localizer)
    {
        _commonService = commonService;
        _userService = userService;
        _bundleService = bundleService;
        _localizer = localizer;
    }

    public async Task<Result<bool>> Handle(UnSubscribeBundlesRequest request, CancellationToken cancellationToken)
    {
        //(bool IsMobileRequest, DeviceType? DeviceType, MediumType MediumType) = _commonService.IsAppRequest();

        if (!string.IsNullOrEmpty(request.Msisdn))
        {
            request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        }
       
        var msisdnDetails = await _userService.GetMsisdnDetail(request.Msisdn);

        var result = await _bundleService.UnSubscribeBundle(msisdnDetails.SubscriberId, request.PackageId);
        if (result == false)
        {
            return Result<bool>.Success(result,_localizer[CustomStatusKey.BundleUnSubscribeFail]);
        }
        return Result<bool>.Success(result, _localizer[CustomStatusKey.BundleUnSubscribeSuccess]);
    }
}