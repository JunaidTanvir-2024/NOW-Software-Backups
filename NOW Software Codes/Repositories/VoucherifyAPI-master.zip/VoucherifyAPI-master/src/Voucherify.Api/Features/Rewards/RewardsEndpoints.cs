using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

using Voucherify.Core.Commons.Filters;

namespace Voucherify.Api.Features.Rewards;

public static class RewardsEndpoints
{
    private const string EndpointPrefix = "/api/rewards";
    private const string EndpointTag = "Rewards Endpoints";

    public static void AddRewardsEndpoints(this WebApplication app)
    {
        var rewardEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);

        // rewardEndpoints.MapPost("/redeem", RedeemReward)
        //    .AddEndpointFilter<ValidationFilter<RedeemPromotionTierRequest>>()
        //    .Produces(StatusCodes.Status400BadRequest)
        //    .Produces(StatusCodes.Status200OK)
        //    .Produces(StatusCodes.Status404NotFound);
    }
    // private static async Task<IResult> RedeemReward()
    // {
    //     var result = await loyaltiesHandler.GiveLoyaltyPointsToCustomer(request);
    //     return result.IsValid ? Results.Ok(result) : Results.BadRequest(result);
    // }
}