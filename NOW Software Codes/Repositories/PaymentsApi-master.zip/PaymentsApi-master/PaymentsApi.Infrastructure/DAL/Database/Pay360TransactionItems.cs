﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public class Pay360TransactionItems
    {
       
        public string ProductItemCode { get; set; }
        public float Amount { get; set; }        
        public string ProductRef { get; set; }        
        public string BundleRef { get; set; }
    }
}
