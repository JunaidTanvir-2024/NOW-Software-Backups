﻿namespace THCC.Application.Features.Country;

public class CountryRequest : IRequest<object> { }