namespace JM.Infrastructure.Services.Identity;

public sealed class IdentitySetting
{
    public const string SectionName = nameof(IdentitySetting);
    public Password PasswordOptions { get; set; } = null!;
    public Lockout LockoutOptions { get; set; } = null!;
    public Signup SignupOptions { get; set; } = null!;
    public SignIn SignInOptions { get; set; } = null!;

    public sealed class Lockout
    {
        public ushort DefaultLockoutMinutes { get; set; }
        public ushort MaxFailedAccessAttempts { get; set; }
        public bool EnableLookoutForNewUser { get; set; }
    }

    public sealed class Password
    {
        public bool RequireDigit { get; set; }
        public ushort RequiredLength { get; set; }
        public bool RequireNonAlphanumeric { get; set; }
        public bool RequireUppercase { get; set; }
        public bool RequireLowercase { get; set; }
        public ushort RequiredUniqueChars { get; set; }
    }

    public sealed class SignIn
    {
        public bool RequireConfirmedEmail { get; set; }
        public bool RequireConfirmedPhoneNumber { get; set; }
        public bool RequireConfirmedAccount { get; set; }
    }
    public sealed class Signup
    {
        public bool RequireUniqueEmail { get; set; }
        public string AllowedUserNameCharacters { get; set; } = null!;
    }
}

