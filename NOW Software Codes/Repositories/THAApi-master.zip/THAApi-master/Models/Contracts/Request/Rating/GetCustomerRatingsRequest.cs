﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.Rating
{
    public class GetCustomerRatingsRequest
    {
        public string productCode { get; set; }
        public string MSISDN { get; set; }
        public string Email { get; set; }
        public RatingSources RatingSources { get; set; }
    }
}
