﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Ding.Response
{
   
    public class DingJsonOperatorProductResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public DingPayLoad payload { get; set; }
    }

    public class DingPayLoad
    {
        public List<DingOperator> operators { get; set; }
    }

    public class DingOperator
    {
        public string id { get; set; }
        public string name { get; set; }
        public string country { get; set; }
        public string nowtelTransactionReference { get; set; }
        public string iconUri { get; set; }
        public List<DingProduct> products { get; set; }
    }

    public class DingProduct
    {
        public string clientccy { get; set; }
        public string receiverccy { get; set; }
        public string productExcludingTax { get; set; }
        public string product { get; set; }
        public string itemPriceClientccy { get; set; }
        public string transactionfeeClientccy { get; set; }
        public string totalPriceClientccy { get; set; }
        public string dingSkuCode { get; set; }
    }

    public class DingOperatorAndDBInsertStatus
    {
        public DingOperator dingOperator;
        public int DBStatus { get; set; } // 1 for Success and 0 for Failure
        public string DBErrorSP { get; set; } // Error Stored Procedure Name
        public string DBErrorMessage { get; set; } // Error Message
    }
}
