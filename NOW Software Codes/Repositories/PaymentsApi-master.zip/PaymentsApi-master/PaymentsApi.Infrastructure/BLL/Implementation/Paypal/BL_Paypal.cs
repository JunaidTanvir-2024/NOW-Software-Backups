﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PaymentsApi.Infrastructure.BLL.Implementation.Pay360;
using PaymentsApi.Infrastructure.BLL.Interfaces.Pay360;
using PaymentsApi.Infrastructure.BLL.Interfaces.Paypal;
using PaymentsApi.Infrastructure.DAL.Database;
using PaymentsApi.Infrastructure.DAL.Interfaces;
using PaymentsApi.Models.Configurations;
using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Pay360.Request.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using PaymentsApi.Models.Contracts.Paypal.Request.Api;
using PaymentsApi.Models.Contracts.Paypal.Request.User;
using PaymentsApi.Models.Contracts.Paypal.Response.Api;
using PaymentsApi.Models.Contracts.Paypal.Response.User;
using PaymentsApi.Models.Utility;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PaymentsApi.Infrastructure.BLL.Implementation.Paypal
{
    public class BL_Paypal : IBL_Paypal
    {

        private Pay360Config Pay360Configurations;
        private IDL_Paypal Db;
        private DL_IPay360 Pay360Db;
        private readonly IPay360Auth pay360Auth;
        private IApiCall ApiCall;
        private readonly ILogger Logger;
        private readonly SmsConfig SmsConfig;
        private readonly SmtpConfig SmtpConfig;
        private readonly SimulationConfig SimulationConf;
        private IEmailTemplates EmailTemplate;
        private BL_IPay360CashierApi Pay360CashierApi;

        public BL_Paypal(
            ILogger logger,
            IDL_Paypal db,
            IOptions<Pay360Config> pay360Config,
            IOptions<SmsConfig> smsConfig,
            IOptions<SmtpConfig> smpt,
            IOptions<SimulationConfig> stimulationConfig,
            IApiCall apiCall,
            IEmailTemplates emailTemplate,
            BL_IPay360CashierApi pay360CashierApi,
            DL_IPay360 pay360Db,
            IPay360Auth pay360Auth)
        {
            Pay360Configurations = pay360Config.Value;
            Db = db;
            this.ApiCall = apiCall;
            Logger = logger;
            SmsConfig = smsConfig.Value;
            SmtpConfig = smpt.Value;
            SimulationConf = stimulationConfig.Value;
            EmailTemplate = emailTemplate;
            Pay360CashierApi = pay360CashierApi;
            Pay360Db = pay360Db;
            this.pay360Auth = pay360Auth;
        }

        public async Task<GenericApiResponse<UserPaypalPaymentResponse>> PaypalPayment(UserPaypalPaymentRequest userRequest)
        {
            GenericApiResponse<UserPaypalPaymentResponse> response;
            string userRequestJson = JsonConvert.SerializeObject(userRequest);

            string customerMerchantReference = "P_" + userRequest.ProductCode + "_" + userRequest.CustomerUniqueRef;

            int valResponse = await Db.PaypalFraudValidation(customerMerchantReference, userRequest.CustomerEmail, userRequest.IpAddress, userRequest.ProductCode, userRequest.Basket[0].ProductItemCode);

            if (valResponse != 1) // Fraud Customer
            {
                response = new GenericApiResponse<UserPaypalPaymentResponse>()
                {
                    errorCode = 12,
                    message = "Sorry we are unable to complete your transaction, please contact customer services - (Val-1001)",
                    pay360ApiCode = "",
                    status = "Failure",
                    payload = null
                };
                return response;
            }

            bool sendpay360Email = false;

            if (userRequest.SendPay360Email == true && !string.IsNullOrWhiteSpace(userRequest.CustomerEmail))
            {
                sendpay360Email = true;
            }

            try
            {
                string description = "";

                GenericApiResponse<UserResponseModels> validationResponse = await Pay360CashierApi.Validations(userRequest.CustomerMsisdn, userRequest.ProductCode, userRequest.TransactionAmount, userRequest.Basket);
                if (validationResponse.errorCode == 0) // Validation Successfull
                {
                    description = validationResponse.message;
                }
                else // Validation Error
                {
                    response = new GenericApiResponse<UserPaypalPaymentResponse>()
                    {
                        errorCode = validationResponse.errorCode,
                        message = validationResponse.message,
                        pay360ApiCode = validationResponse.pay360ApiCode,
                        status = validationResponse.status,
                        payload = null
                    };
                    return response;
                }

                var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(userRequest.CustomerMsisdn, userRequest.ProductCode, nameof(Pay360PaymentType.PAYPAL));

                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/payment";

                Customer customer = new Customer()
                {
                    DisplayName = userRequest.CustomerName,
                    MerchantRef = customerMerchantReference,
                    Email = userRequest.CustomerEmail,
                    AddressLine1 = userRequest.CustomerBillingAddress == null ? null : userRequest.CustomerBillingAddress.Line1,
                    AddressLine2 = userRequest.CustomerBillingAddress == null ? null : userRequest.CustomerBillingAddress.Line2,
                    AddressLine3 = userRequest.CustomerBillingAddress == null ? null : userRequest.CustomerBillingAddress.Line3,
                    AddressLine4 = userRequest.CustomerBillingAddress == null ? null : userRequest.CustomerBillingAddress.Line4,
                    City = userRequest.CustomerBillingAddress == null ? null : userRequest.CustomerBillingAddress.City,
                    CountryCode = userRequest.CustomerBillingAddress == null ? null : userRequest.CustomerBillingAddress.CountryCode,
                    Region = userRequest.CustomerBillingAddress == null ? null : userRequest.CustomerBillingAddress.Region,
                    PostCode = userRequest.CustomerBillingAddress == null ? null : userRequest.CustomerBillingAddress.PostCode,
                    ProductCode = userRequest.ProductCode,
                    Msisdn = userRequest.CustomerMsisdn
                };
                DbResult<int> custResult = await Db.AddUpdatePaypalCustomer(customer);
                if (custResult.DBStatus != 1)
                {
                    return response = GenericApiResponse<UserPaypalPaymentResponse>.Failure(custResult.DBErrorMessage, 14);
                }
                else
                {
                    customer.Id = custResult.Data;
                }

                string transactionMerchantRef = userRequest.ProductCode + "_" + Guid.NewGuid().ToString("N");

                HttpResponseMessage apiHttpResponse;

                ApiPaypalPaymentRequest requestModel = new ApiPaypalPaymentRequest
                {
                    Customer = new PaypalCustomerRequestModel()
                    {
                        Telephone = userRequest.CustomerMsisdn,
                        DisplayName = userRequest.CustomerName,
                        MerchantRef = customerMerchantReference,
                        Email = userRequest.CustomerEmail,
                        Registered = "true",
                        IpAddress = userRequest.IpAddress,
                        // CustomerBillingAddress = new CustomerBillingAddress() { Line1 = userRequest.CustomerBillingAddress.Line1, Line2 = userRequest.CustomerBillingAddress.Line2, Line3 = userRequest.CustomerBillingAddress.Line3, Line4 = userRequest.CustomerBillingAddress.Line4, City = userRequest.CustomerBillingAddress.City, PostCode = userRequest.CustomerBillingAddress.PostCode, Region = userRequest.CustomerBillingAddress.Region, CountryCode = userRequest.CustomerBillingAddress.CountryCode }
                        CustomerBillingAddress = userRequest.CustomerBillingAddress

                    },
                    PaymentMethod = userRequest.PaymentMethod,
                    Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = "ECOM", Deferred = false, Recurring = false, MerchantRef = transactionMerchantRef, Description = description },
                    TransactionOptions = new PaypalTransactionOptionsModel() { SendEmailReceipt = sendpay360Email },
                    Order = new PaypalOrder() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                    CustomFields = userRequest.CustomFields
                };


                try
                {
                    apiHttpResponse = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                }
                catch (Exception ex)
                {
                    PaypalTransaction dbTransaction = new PaypalTransaction();
                    dbTransaction.Customer_Id = customer.Id;
                    dbTransaction.CustomerMerchantRef = customerMerchantReference;
                    dbTransaction.TransactionMerchantRef = transactionMerchantRef;
                    dbTransaction.UserRequestJson = userRequestJson;
                    dbTransaction.RequestJsonToPay360 = JsonConvert.SerializeObject(requestModel);
                    dbTransaction.ResponseJsonFromPay360 = "";
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    dbTransaction.TransactionType_Id = (int)Pay360TransactionTypes.PAYMENT;
                    dbTransaction.TransactionAmount = userRequest.TransactionAmount;
                    dbTransaction.TransactionCurrency = userRequest.TransactionCurrency;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    dbTransaction.OutcomeReasonMessage = ex.Message;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;

                    DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, false);
                    throw;
                }

                string Pay360RequestJson = JsonConvert.SerializeObject(requestModel);

                ApiPaypalPaymentResponse apiResponse;
                string Pay360ResponseJson = "";
                if (apiHttpResponse.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    Pay360ResponseJson = apiHttpResponse.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaypalPaymentResponse>(Pay360ResponseJson);

                    //Initialising dbTransaction Object.
                    PaypalTransaction dbTransaction = CreateDbTransactionObject(apiResponse, customerMerchantReference, customer.Id, transactionMerchantRef, userRequestJson, Pay360RequestJson, Pay360ResponseJson, userRequest.IsDirectFullfilment, creds.ApiInstallationIdCashierApi, userRequest.IpAddress);
                    DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, true);

                    if (apiResponse.Outcome.Status.ToLower() != "success") // Failure
                    {

                        if (result.DBStatus != 1) // Db Insertion Failed.
                        {
                            return response = GenericApiResponse<UserPaypalPaymentResponse>.Failure("Transaction Un-Successfull and Database Insertion Error: " + result.DBErrorMessage, 13);
                        }
                        else
                        {
                            return response = GenericApiResponse<UserPaypalPaymentResponse>.Failure("Transaction Un-Successfull", 12);
                        }
                    }
                    else // Success
                    {
                        UserPaypalPaymentResponse userResponse = new UserPaypalPaymentResponse()
                        {
                            CustomerId = apiResponse.Customer.Id.ToString(),
                            TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                            TransactionId = apiResponse.Transaction.TransactionId,
                            //Processing = apiResponse.Processing,
                            OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status },
                            ClientRedirectUrl = apiResponse.ClientRedirect.Url,
                            CheckoutToken = apiResponse.PaymentMethod.Paypal.CheckoutToken

                        };

                        if (result.DBStatus != 1)
                        {
                            return response = GenericApiResponse<UserPaypalPaymentResponse>.Failure("Transaction Successfull but Error in Database Insertion: " + result.DBErrorMessage, 11);
                        }

                        response = GenericApiResponse<UserPaypalPaymentResponse>.Success(userResponse, "Success");

                    }
                }
                else if (apiHttpResponse.StatusCode == System.Net.HttpStatusCode.MultiStatus)
                {
                    Pay360ResponseJson = apiHttpResponse.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaypalPaymentResponse>(Pay360ResponseJson);
                    PaypalTransaction dbTransaction = CreateDbTransactionObject(apiResponse, customerMerchantReference, customer.Id, transactionMerchantRef, userRequestJson, Pay360RequestJson, Pay360ResponseJson, userRequest.IsDirectFullfilment, creds.ApiInstallationIdCashierApi, userRequest.IpAddress);
                    DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, false);
                    string errorMessage = apiResponse.Outcome.ReasonMessage;
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", Pay360ResponseJson).Trim();
                    if (reasonCode == "A136")
                    {
                        errorMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }
                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserPaypalPaymentResponse>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserPaypalPaymentResponse>.Failure(errorMessage, 12);
                    response.pay360ApiCode = reasonCode;

                }
                else
                {

                    Pay360ResponseJson = await apiHttpResponse.Content.ReadAsStringAsync();
                    PaypalTransaction dbTransaction = new PaypalTransaction();
                    dbTransaction.Customer_Id = customer.Id;
                    dbTransaction.CustomerMerchantRef = customerMerchantReference;
                    dbTransaction.TransactionMerchantRef = transactionMerchantRef;
                    dbTransaction.UserRequestJson = userRequestJson;
                    dbTransaction.RequestJsonToPay360 = Pay360RequestJson;
                    dbTransaction.ResponseJsonFromPay360 = Pay360ResponseJson;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    dbTransaction.TransactionType_Id = (int)Pay360TransactionTypes.PAYMENT;
                    dbTransaction.TransactionAmount = userRequest.TransactionAmount;
                    dbTransaction.TransactionCurrency = userRequest.TransactionCurrency;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", Pay360ResponseJson);
                    dbTransaction.OutcomeReasonMessage = reasonMessage;
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", Pay360ResponseJson).Trim();
                    dbTransaction.OutcomeReasonCode = reasonCode;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;

                    DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, false);
                    if (reasonCode == "A136")
                    {
                        reasonMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }

                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserPaypalPaymentResponse>.Failure("Transaction Un-Successfull: " + reasonMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserPaypalPaymentResponse>.Failure(reasonMessage, 12);
                    response.pay360ApiCode = reasonCode;

                }

            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserPaypalPaymentResponse>.Failure(ex.Message, 14);
                throw;
            }

            return response;
        }

        public async Task<GenericApiResponse<UserPaypalResumeResponse>> PaypalResume(UserPaypalResumeRequest userRequest)
        {
            GenericApiResponse<UserPaypalResumeResponse> response = (GenericApiResponse<UserPaypalResumeResponse>)null;
            string userRequestJson = JsonConvert.SerializeObject(userRequest);
            string pay360RequestJson = "";
            try
            {
                var PrimaryTransaction = await Db.GetResumeSummaryTran(userRequest.PaypalCheckoutToken);

                if (PrimaryTransaction == null)
                {
                    return response = GenericApiResponse<UserPaypalResumeResponse>.Failure("Transaction not found", 20);
                }
                else if (PrimaryTransaction.Resume_Transaction_Id != null && PrimaryTransaction.Resume_Transaction_Id > 0)  // Already Resumed
                {
                    return response = GenericApiResponse<UserPaypalResumeResponse>.Failure("Transaction already Resumed", 28);
                }

                var creds = pay360Auth.GetApiCredsByInstallationId(PrimaryTransaction.ApiInstallationIdCashierApi);

                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/" + PrimaryTransaction.Pay360TransactionId + "/resume";

                HttpResponseMessage apiHttpResponse;
                object requestModel = new object();

                pay360RequestJson = JsonConvert.SerializeObject(requestModel);
                try
                {
                    apiHttpResponse = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                }
                catch (Exception ex)
                {

                    PaypalTransaction dbTransaction = new PaypalTransaction();
                    dbTransaction.Customer_Id = PrimaryTransaction.Customer_Id;
                    dbTransaction.CustomerMerchantRef = PrimaryTransaction.CustomerMerchantRef;
                    dbTransaction.TransactionMerchantRef = null;
                    dbTransaction.Pay360TransactionId = PrimaryTransaction.Pay360TransactionId;
                    dbTransaction.PaypalCheckoutToken = userRequest.PaypalCheckoutToken;
                    dbTransaction.UserRequestJson = userRequestJson;
                    dbTransaction.RequestJsonToPay360 = JsonConvert.SerializeObject(requestModel);
                    dbTransaction.ResponseJsonFromPay360 = "";
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    dbTransaction.TransactionType_Id = (int)Pay360TransactionTypes.PAYMENT;
                    dbTransaction.TransactionAmount = PrimaryTransaction.TransactionAmount;
                    dbTransaction.TransactionCurrency = PrimaryTransaction.TransactionCurrency;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    dbTransaction.OutcomeReasonMessage = ex.Message;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;

                    DbResult<long> result = await Db.AddResumeTransaction(dbTransaction);

                    throw;
                }
                ApiPaypalPaymentResponse apiResponse;
                string pay360ResponseJson = "";
                if (apiHttpResponse.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    pay360ResponseJson = apiHttpResponse.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaypalPaymentResponse>(pay360ResponseJson);

                    if (apiResponse.Outcome.ReasonCode == "S100") // Success
                    {
                        PaypalTransaction dbTransaction = CreateDbTransactionObject(apiResponse, PrimaryTransaction.CustomerMerchantRef, PrimaryTransaction.Customer_Id, null, userRequestJson, pay360RequestJson, pay360ResponseJson, PrimaryTransaction.IsDirectFullfilment, creds.ApiInstallationIdCashierApi, null);
                        DbResult<long> result = await Db.AddResumeTransaction(dbTransaction);
                        if (result.DBStatus != 1)
                        {
                            return response = GenericApiResponse<UserPaypalResumeResponse>.Failure("Transaction Successful, Database update failed", 11);
                        }
                        //Check fraud rules here
                        var isUserWhiteListed = await Db.PaypalIsUserWhitelisted(apiResponse.Customer.MerchantRef);
                        if (!isUserWhiteListed)
                        {
                            var customer = await Db.GetCustomerByMerchantRef(apiResponse.Customer.MerchantRef);

                            string customerEmail = string.IsNullOrEmpty(customer.Email) ? apiResponse.Customer.Email : customer.Email;

                            if (!string.IsNullOrEmpty(customerEmail)
                                && !apiResponse.PaymentMethod.Paypal.PayerEmail.Equals(customerEmail, StringComparison.InvariantCultureIgnoreCase))
                            {
                                response = new GenericApiResponse<UserPaypalResumeResponse>()
                                {
                                    errorCode = 12,
                                    message = "Sorry we are unable to complete your transaction, please contact customer services - (Val - 1002)",
                                    pay360ApiCode = "",
                                    status = "Failure",
                                    payload = null
                                };
                                return response;
                            }
                            if (!apiResponse.PaymentMethod.Paypal.AccountVerified)
                            {
                                response = new GenericApiResponse<UserPaypalResumeResponse>()
                                {
                                    errorCode = 12,
                                    message = "Sorry we are unable to complete your transaction, please contact customer services - (Val - 1003)",
                                    pay360ApiCode = "",
                                    status = "Failure",
                                    payload = null
                                };
                                return response;
                            }
                        }
                        //
                        UserPaypalResumeResponse userResponse = new UserPaypalResumeResponse()
                        {
                            CustomerId = apiResponse.Customer.Id.ToString(),
                            TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                            TransactionId = apiResponse.Transaction.TransactionId,
                            //Processing = apiResponse.Processing,
                            OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status },
                            PaymentMethod = apiResponse.PaymentMethod

                        };

                        if (PrimaryTransaction.TransactionStatus_Id == (Pay360SummaryTransactionStatuses.SINGLEPAYMENT) && PrimaryTransaction.IsDirectFullfilment == true)
                        {
                            // Fullfilment
                            return response = await PaypalFullfilment(userResponse, PrimaryTransaction.Pay360TransactionId, PrimaryTransaction.SinglePayment_Transaction_Id.ToString(), apiResponse.Transaction.Currency, PrimaryTransaction.CustomerMerchantRef, PrimaryTransaction.CustomerName, PrimaryTransaction.CustomerEmail);
                        }


                        response = GenericApiResponse<UserPaypalResumeResponse>.Success(userResponse, "Success");

                    }
                    else  // Failure
                    {
                        pay360ResponseJson = apiHttpResponse.Content.ReadAsStringAsync().Result;
                        apiResponse = JsonConvert.DeserializeObject<ApiPaypalPaymentResponse>(pay360ResponseJson);
                        PaypalTransaction dbTransaction = CreateDbTransactionObject(apiResponse, PrimaryTransaction.CustomerMerchantRef, PrimaryTransaction.Customer_Id, null, userRequestJson, pay360RequestJson, pay360ResponseJson, PrimaryTransaction.IsDirectFullfilment, creds.ApiInstallationIdCashierApi, null);
                        DbResult<long> result = await Db.AddResumeTransaction(dbTransaction);
                        string errorMessage = apiResponse.Outcome.ReasonMessage;
                        string reasonCode = apiResponse.Outcome.ReasonCode;

                        if (result.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserPaypalResumeResponse>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }

                        response = GenericApiResponse<UserPaypalResumeResponse>.Failure(errorMessage, 12);
                        response.pay360ApiCode = reasonCode;
                    }

                }
                else if (apiHttpResponse.StatusCode == System.Net.HttpStatusCode.MultiStatus)
                {
                    pay360ResponseJson = apiHttpResponse.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaypalPaymentResponse>(pay360ResponseJson);
                    PaypalTransaction dbTransaction = CreateDbTransactionObject(apiResponse, PrimaryTransaction.CustomerMerchantRef, PrimaryTransaction.Customer_Id, null, userRequestJson, pay360RequestJson, pay360ResponseJson, PrimaryTransaction.IsDirectFullfilment, creds.ApiInstallationIdCashierApi, null);
                    DbResult<long> result = await Db.AddResumeTransaction(dbTransaction);
                    string errorMessage = apiResponse.Outcome.ReasonMessage;
                    string reasonCode = apiResponse.Outcome.ReasonCode;
                    if (reasonCode == "A136")
                    {
                        errorMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }
                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserPaypalResumeResponse>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserPaypalResumeResponse>.Failure(errorMessage, 12);
                    response.pay360ApiCode = reasonCode;

                }
                else
                {
                    pay360ResponseJson = await apiHttpResponse.Content.ReadAsStringAsync();
                    PaypalTransaction dbTransaction = new PaypalTransaction();
                    dbTransaction.Customer_Id = PrimaryTransaction.Customer_Id;
                    dbTransaction.CustomerMerchantRef = PrimaryTransaction.CustomerMerchantRef;
                    dbTransaction.TransactionMerchantRef = null;
                    dbTransaction.Pay360TransactionId = PrimaryTransaction.Pay360TransactionId;
                    dbTransaction.PaypalCheckoutToken = userRequest.PaypalCheckoutToken;
                    dbTransaction.UserRequestJson = userRequestJson;
                    dbTransaction.RequestJsonToPay360 = pay360RequestJson;
                    dbTransaction.ResponseJsonFromPay360 = pay360ResponseJson;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    dbTransaction.TransactionType_Id = (int)Pay360TransactionTypes.PAYMENT;
                    dbTransaction.TransactionAmount = PrimaryTransaction.TransactionAmount;
                    dbTransaction.TransactionCurrency = PrimaryTransaction.TransactionCurrency;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", pay360ResponseJson);
                    dbTransaction.OutcomeReasonMessage = reasonMessage;
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", pay360ResponseJson).Trim();
                    dbTransaction.OutcomeReasonCode = reasonCode;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                    DbResult<long> result = await Db.AddResumeTransaction(dbTransaction);
                    if (reasonCode == "A136")
                    {
                        reasonMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }

                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserPaypalResumeResponse>.Failure("Transaction Un-Successfull: " + reasonMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserPaypalResumeResponse>.Failure(reasonMessage, 12);
                    response.pay360ApiCode = reasonCode;

                }

            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserPaypalResumeResponse>.Failure(ex.Message, 14);
                throw;
            }

            return response;
        }

        public async Task<GenericApiResponse<UserPaypalRefundResponse>> PaypalRefund(UserPaypalRefundRequest userRequest)
        {
            GenericApiResponse<UserPaypalRefundResponse> response = (GenericApiResponse<UserPaypalRefundResponse>)null;
            string userRequestJson = JsonConvert.SerializeObject(userRequest);
            string pay360RequestJson = "";
            try
            {
                PaypalTransactionSummary SummaryTransaction = await Db.GetSummaryByPay360TransactionId(userRequest.TransactionId);

                if (SummaryTransaction == null)
                {
                    return response = GenericApiResponse<UserPaypalRefundResponse>.Failure("Transaction not found", 20);
                }
                else if (SummaryTransaction.TransactionStatus_Id == Pay360SummaryTransactionStatuses.RESUME3DFAILED || SummaryTransaction.Resume_Transaction_Id == null || SummaryTransaction.Resume_Transaction_Id == 0)  // Not Resumed Yet
                {
                    return response = GenericApiResponse<UserPaypalRefundResponse>.Failure("Transaction not resumed yet.", 29);
                }
                else if (SummaryTransaction.TransactionStatus_Id == Pay360SummaryTransactionStatuses.FULLREFUND)  // Already Refunded
                {
                    return response = GenericApiResponse<UserPaypalRefundResponse>.Failure("Transaction already refunded.", 30);
                }

                var creds = pay360Auth.GetApiCredsByInstallationId(SummaryTransaction.ApiInstallationIdCashierApi);

                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/" + userRequest.TransactionId + "/refund";

                HttpResponseMessage apiHttpResponse;
                FullRefundTransactionModel requestModel = new FullRefundTransactionModel();

                pay360RequestJson = JsonConvert.SerializeObject(requestModel);
                try
                {
                    apiHttpResponse = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                }
                catch (Exception ex)
                {

                    PaypalTransaction dbTransaction = new PaypalTransaction();
                    dbTransaction.Customer_Id = SummaryTransaction.Customer_Id;
                    dbTransaction.CustomerMerchantRef = SummaryTransaction.CustomerMerchantRef;
                    dbTransaction.TransactionMerchantRef = null;
                    dbTransaction.RelatedTransactionId = userRequest.TransactionId;
                    dbTransaction.UserRequestJson = userRequestJson;
                    dbTransaction.RequestJsonToPay360 = JsonConvert.SerializeObject(requestModel);
                    dbTransaction.ResponseJsonFromPay360 = "";
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    dbTransaction.TransactionType_Id = (int)Pay360TransactionTypes.REFUND;
                    dbTransaction.TransactionAmount = SummaryTransaction.TransactionAmount;
                    dbTransaction.TransactionCurrency = SummaryTransaction.TransactionCurrency;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    dbTransaction.OutcomeReasonMessage = ex.Message;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;

                    DbResult<long> result = await Db.AddRefundTransaction(dbTransaction);

                    throw;
                }
                ApiPaypalPaymentResponse apiResponse;
                string pay360ResponseJson = "";
                if (apiHttpResponse.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    pay360ResponseJson = apiHttpResponse.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaypalPaymentResponse>(pay360ResponseJson);

                    if (apiResponse.Outcome.ReasonCode == "S100") // Success
                    {
                        PaypalTransaction dbTransaction = CreateDbTransactionObject(apiResponse, SummaryTransaction.CustomerMerchantRef, SummaryTransaction.Customer_Id, null, userRequestJson, pay360RequestJson, pay360ResponseJson, SummaryTransaction.IsDirectFullfilment, creds.ApiInstallationIdCashierApi, null);
                        DbResult<long> result = await Db.AddRefundTransaction(dbTransaction);
                        if (result.DBStatus != 1)
                        {
                            return response = GenericApiResponse<UserPaypalRefundResponse>.Failure("Transaction Successful, Database update failed", 11);
                        }

                        UserPaypalRefundResponse userResponse = new UserPaypalRefundResponse()
                        {
                            CustomerId = apiResponse.Customer == null ? null : apiResponse.Customer.Id.ToString(),
                            TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                            TransactionId = apiResponse.Transaction.TransactionId,
                            RelatedTransactionId = apiResponse.Transaction.RelatedTransaction.TransactionId,
                            OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status },

                        };

                        response = GenericApiResponse<UserPaypalRefundResponse>.Success(userResponse, "Success");

                    }
                    else  // Failure
                    {
                        pay360ResponseJson = apiHttpResponse.Content.ReadAsStringAsync().Result;
                        apiResponse = JsonConvert.DeserializeObject<ApiPaypalPaymentResponse>(pay360ResponseJson);
                        PaypalTransaction dbTransaction = CreateDbTransactionObject(apiResponse, SummaryTransaction.CustomerMerchantRef, SummaryTransaction.Customer_Id, null, userRequestJson, pay360RequestJson, pay360ResponseJson, SummaryTransaction.IsDirectFullfilment, creds.ApiInstallationIdCashierApi, null);
                        DbResult<long> result = await Db.AddRefundTransaction(dbTransaction);
                        string errorMessage = apiResponse.Outcome.ReasonMessage;
                        string reasonCode = apiResponse.Outcome.ReasonCode;

                        if (result.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserPaypalRefundResponse>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }

                        response = GenericApiResponse<UserPaypalRefundResponse>.Failure(errorMessage, 12);
                        response.pay360ApiCode = reasonCode;
                    }

                }
                else if (apiHttpResponse.StatusCode == System.Net.HttpStatusCode.MultiStatus)
                {
                    pay360ResponseJson = apiHttpResponse.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaypalPaymentResponse>(pay360ResponseJson);
                    PaypalTransaction dbTransaction = CreateDbTransactionObject(apiResponse, SummaryTransaction.CustomerMerchantRef, SummaryTransaction.Customer_Id, null, userRequestJson, pay360RequestJson, pay360ResponseJson, SummaryTransaction.IsDirectFullfilment, creds.ApiInstallationIdCashierApi, null);
                    DbResult<long> result = await Db.AddRefundTransaction(dbTransaction);
                    string errorMessage = apiResponse.Outcome.ReasonMessage;
                    string reasonCode = apiResponse.Outcome.ReasonCode;

                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserPaypalRefundResponse>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserPaypalRefundResponse>.Failure(errorMessage, 12);
                    response.pay360ApiCode = reasonCode;

                }
                else
                {
                    pay360ResponseJson = await apiHttpResponse.Content.ReadAsStringAsync();
                    PaypalTransaction dbTransaction = new PaypalTransaction();
                    dbTransaction.Customer_Id = SummaryTransaction.Customer_Id;
                    dbTransaction.CustomerMerchantRef = SummaryTransaction.CustomerMerchantRef;
                    dbTransaction.TransactionMerchantRef = null;
                    dbTransaction.RelatedTransactionId = userRequest.TransactionId;
                    dbTransaction.UserRequestJson = userRequestJson;
                    dbTransaction.RequestJsonToPay360 = pay360RequestJson;
                    dbTransaction.ResponseJsonFromPay360 = pay360ResponseJson;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    dbTransaction.TransactionType_Id = (int)Pay360TransactionTypes.REFUND;
                    dbTransaction.TransactionAmount = SummaryTransaction.TransactionAmount;
                    dbTransaction.TransactionCurrency = SummaryTransaction.TransactionCurrency;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", pay360ResponseJson);
                    dbTransaction.OutcomeReasonMessage = reasonMessage;
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", pay360ResponseJson).Trim();
                    dbTransaction.OutcomeReasonCode = reasonCode;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;

                    DbResult<long> result = await Db.AddRefundTransaction(dbTransaction);

                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserPaypalRefundResponse>.Failure("Transaction Un-Successfull: " + reasonMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserPaypalRefundResponse>.Failure(reasonMessage, 12);
                    response.pay360ApiCode = reasonCode;

                }

            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserPaypalRefundResponse>.Failure(ex.Message, 14);
                throw;
            }

            return response;
        }

        #region Fullfilment

        private async Task<GenericApiResponse<UserPaypalResumeResponse>> PaypalFullfilment(UserPaypalResumeResponse userResponse, string pay360TransactionId, string transactionId, string currency, string customerMerchantRef, string customerName, string customerEmail)
        {
            GenericApiResponse<UserPaypalResumeResponse> response = null;
            try
            {

                bool isfullfilmentError = false;
                bool isfullfilment = false;
                bool isSmsSent = false;
                bool isEmailSent = false;
                bool isEmailSentToCustomer = false;
                DateTime? fullfilmentDatetime = null;
                DateTime? smsSentDatetime = null;
                DateTime? emailSentDatetime = null;
                DateTime? customerEmailSentDatetime = null;
                var topup_option = 2;
                var thm_sms = 0;

                // Get TransactionItems for Fullfilment
                List<TransactionItems> transactionItems = await Db.GetTransactionItemsForFullfilment(transactionId);

                List<BasketItemsResponse> BasketResponse = new List<BasketItemsResponse>();

                foreach (TransactionItems tranItem in transactionItems)
                {
                    FullfilmentResponse result = null;

                    if (tranItem.ProductItemCode == "THM")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var bundleRef = tranItem.BundleRef;
                            var amount = tranItem.Amount;
                            var productRef = tranItem.ProductRef;

                            result = await Db.ThmStraightCustomerFullfilment(tranId, bundleRef, amount.ToString(), productRef, customerEmail, "THM");

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.Audit.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            string customerEmailMsg = $"Talkhome \r\nYou have successfully Topped Up. \r\nYour new balance is {newBalanceCurrency}{newBalance.ToString("0.00")}\r\nTop Up Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            if (!string.IsNullOrWhiteSpace(tranItem.BundleRef))
                            {
                                newBalance = newBalance - Convert.ToDecimal(tranItem.Amount);
                                customerEmailMsg = $"Talkhome \r\nYou have successfully purchased a plan. \r\nYour new balance is {newBalanceCurrency}{newBalance.ToString("0.00")}\r\nTransaction Id: {pay360TransactionId}";
                            }


                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference:" + customerMerchantRef;
                            emailTransaction.description = "Pay360 THM Top Up Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await Pay360CashierApi.SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendEmailToCustomer)
                            {
                                isEmailSentToCustomer = await Pay360CashierApi.SendEmailToCustomer(customerEmail, customerEmailMsg);
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }
                            #endregion

                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode == "THCC")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;

                            result = await Db.ThccCustomerFullfilment(tranId, tranItem.Amount.ToString(), customerEmail, customerName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            var EmailMsg = $"Talkhome \r\nYou have successfully purchased TalkHome Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion


                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantRef;
                            emailTransaction.description = "Pay360 THCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await Pay360CashierApi.SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendEmailToCustomer == true && SmtpConfig.sendEmailToTHCCCustomer == true)
                            {
                                isEmailSentToCustomer = await Pay360CashierApi.SendEmailToCustomer(customerEmail, EmailMsg);
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetTHCCTemplate(customerName, "£", tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await Pay360CashierApi.SendHtmlEmailToCustomer(customerEmail, emailTemplateContent, "THCC", SmtpConfig.subjectForTHCCNCustomer);
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode == "THRCC")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var bundleRef = tranItem.BundleRef;
                            var amount = tranItem.Amount * 100;
                            var productRef = tranItem.ProductRef;
                            result = await Db.ThrccCustomerFullfilment(tranId, amount.ToString(), productRef, customerEmail, customerName);
                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region GetRewaradPoints
                            int points = 0;
                            try
                            {
                                //await Pay360Db.THRCCAddRewardPoints((int)result.Audit.audit_id, result.Card, tranItem.Amount * 100);

                                points = await Pay360Db.GetPoints(result.Card);
                            }
                            catch (Exception ex)
                            {
                                Logger.Error($"Class: BL_Paypal, Method: GetPoints, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                                points = 0;
                            }
                            #endregion

                            #region SendSms
                            var EmailMsg = "";
                            if (tranItem.ProductRef == null)// Change the email for the customer accordingly.
                            {
                                EmailMsg = $"TalkHome Rechargeable Calling Card <br/> You have successfully purchased a TalkHome Rechargeable Calling Card.<br/>Pin: {result.Pin}<br/>Rechargeable Card Number: {result.Card}<br/>Amount: {newBalanceCurrency}{tranItem.Amount}<br/>Transaction Id: {pay360TransactionId} You've earned {points} points! Registered users can <a href=\"https://talk-home.co.uk/logincallingcards\">log in</a> to redeem points but if you're not registered don't worry, you can still claim your points when you <a href=\"https://talk-home.co.uk/signupcallingcards\">sign up</a>.";
                            }
                            else
                            {
                                EmailMsg = $"TalkHome Rechargeable Calling Card <br/> You have successfully topped up. <br/>Pin: {result.Pin}<br/>Rechargeable Card Number: {result.Card}<br/> Amount: {newBalanceCurrency}{tranItem.Amount}<br/>Transaction Id: {pay360TransactionId} Your new points {points}. Registered users can <a href=\"https://talk-home.co.uk/logincallingcards\">log in</a> to redeem points but if you're not registered don't worry, you can still claim your points when you <a href=\"https://talk-home.co.uk/signupcallingcards\">sign up</a>.";
                            }
                            #endregion SendSms

                            #region sendEmail
                            //Email Testing
                            //EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            //emailTransaction.msisdn = "CustomerReference: " + customerMerchantRef;
                            //emailTransaction.description = "Pay360 THRCC Details"; // set the text according to the type of transaction
                            //emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            //emailTransaction.transactionId = pay360TransactionId;
                            //emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            //isEmailSent = await Pay360CashierApi.SendEmail(emailTransaction);
                            //if (isEmailSent)
                            //{
                            //    emailSentDatetime = DateTime.UtcNow;
                            //}

                            #endregion

                            #region SendEmailToCustomer

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendEmailToCustomer == true && SmtpConfig.sendEmailToTHRCCCustomer)
                            {
                                isEmailSentToCustomer = await Pay360CashierApi.SendEmailToCustomer(customerEmail, EmailMsg, true);
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = "";
                                if (tranItem.ProductRef == null)// Change the email for the customer accordingly.
                                {
                                    emailTemplateContent = EmailTemplate.GetTHRCCTemplate(customerName, "£", tranItem.Amount.ToString(), result.Card, result.Pin, points.ToString(), newBalanceCurrency + (result.Audit.new_balance / 100).ToString("0.00"));
                                    await Pay360CashierApi.SendHtmlEmailToCustomer(customerEmail, emailTemplateContent, "THCC", SmtpConfig.subjectForTHRCCNewCustomer);
                                }
                                else
                                {
                                    emailTemplateContent = EmailTemplate.GetTHRCCTemplate(customerName, "£", tranItem.Amount.ToString(), result.Card, points.ToString(), newBalanceCurrency + (result.Audit.new_balance / 100).ToString("0.00"));
                                    await Pay360CashierApi.SendHtmlEmailToCustomer(customerEmail, emailTemplateContent, "THCC", SmtpConfig.subjectForTHRCCCustomer);
                                }

                            }
                            #endregion

                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "NOWPG")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "", BundleName = "" };
                        }
                        else // Live Mode
                        {

                            var tranId = pay360TransactionId;
                            var bundleRef = tranItem.BundleRef;
                            var amount = tranItem.Amount;
                            var productRef = tranItem.ProductRef;

                            result = await Db.NowStraightCustomerFullfilment(tranId, bundleRef, amount.ToString(), productRef);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {

                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.Audit.new_balance;
                            var newBalanceCurrency = currency;

                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            var SmsMsg = "";

                            if (!string.IsNullOrWhiteSpace(tranItem.BundleRef))
                            {
                                SmsMsg = $"NOWMOBILE \r\nYou have successfully purchased a plan {newBalanceCurrency}{tranItem.Amount},Plan Name:{result.BundleName} .\r\nTransaction Id: {pay360TransactionId}";
                            }
                            else
                            {
                                SmsMsg = $"NOWMOBILE \r\nYou have successfully topped Up {newBalanceCurrency}{tranItem.Amount}.\r\nTransaction Id: {pay360TransactionId}";
                            }

                            //var PushMsg = $"You have successfully Topped Up {newBalanceCurrency}{tranItem.Amount}.\r\nTransaction Id: {pay360TransactionId}";

                            //if (thm_sms != 0)
                            //{
                            //    if (SmsConfig.UsePoppayout == true)
                            //    {

                            //        PoppayoutsSendSmsResponse smsResponse = await this.SendPoppayoutSms("TalkHome", new string[] { msisdn }, SmsMsg, 1);

                            //        if (smsResponse != null && smsResponse.errorCode == 0)
                            //        {
                            //            isSmsSent = true;
                            //            smsSentDatetime = DateTime.UtcNow;
                            //        }
                            //        else
                            //        {
                            //            isSmsSent = false;
                            //        }
                            //    }
                            //    else
                            //    {
                            //        XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("TalkHome", msisdn, SmsMsg);
                            //        if (smsResponse != null && smsResponse.errorCode == 0)
                            //        {
                            //            isSmsSent = true;
                            //            smsSentDatetime = DateTime.UtcNow;
                            //        }
                            //        else
                            //        {
                            //            isSmsSent = false;
                            //        }
                            //    }
                            //}
                            #endregion SendSms

                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference:" + customerMerchantRef;
                            emailTransaction.description = "Pay360 NOWMOBILE Top Up Details. " + Environment.NewLine; // set the text according to the type of transaction

                            if (!String.IsNullOrEmpty(tranItem.BundleRef))
                            {
                                emailTransaction.description += " Bundle Name: " + result.BundleName;
                            }

                            emailTransaction.status = "The Customer has Purchased Successfully."; // set the status text accordingly    
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await Pay360CashierApi.SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendEmailToCustomer)
                            {
                                isEmailSentToCustomer = await Pay360CashierApi.SendEmailToCustomer(customerEmail, SmsMsg, "NOWPAYG");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }

                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "WTCC")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;

                            result = await Db.WtccCustomerFullfilment(tranId, amount.ToString(), customerEmail, customerName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms

                            var EmailMsg = $"WorldTalk \r\nYou have successfully purchased WorldTalk Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion


                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantRef;
                            emailTransaction.description = "Pay360 WTCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await Pay360CashierApi.SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendEmailToCustomer == true)
                            {
                                isEmailSentToCustomer = await Pay360CashierApi.SendEmailToCustomer(customerEmail, EmailMsg, "WTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetWTCCTemplate(customerName, newBalanceCurrency, tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await Pay360CashierApi.SendHtmlEmailToCustomer(customerEmail, emailTemplateContent, "WTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "THAATA" || tranItem.ProductItemCode.ToUpper() == "THAATW")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {

                            var tranId = pay360TransactionId;
                            var bundleRef = tranItem.BundleRef;
                            var amount = tranItem.Amount * 100;
                            var prodRef = tranItem.ProductRef;

                            result = await Db.ThaStraightCustomerFullfilment(tranId, bundleRef, amount.ToString(), prodRef);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.Audit.new_balance / 100;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }


                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantRef;
                            emailTransaction.description = "Pay360 Talkhome App Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await Pay360CashierApi.SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                            #region SendEmailToCustomer

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendEmailToCustomer)
                            {
                                string customerEmailMsg = $"Talkhome App \r\nYou have successfully Topped Up. \r\nTop Up Amount: {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                                if (!string.IsNullOrWhiteSpace(tranItem.BundleRef))
                                {
                                    //newBalance = newBalance - Convert.ToDecimal(tranItem.Amount);
                                    customerEmailMsg = $"Talkhome App\r\nYou have successfully purchased a bundle. \r\nBundle Name: {result.BundleName} \r\nBundle Amount: {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                                }
                                isEmailSentToCustomer = await Pay360CashierApi.SendEmailToCustomer(customerEmail, customerEmailMsg);
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }
                            #endregion

                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "STCC")  // SafariTalk Calling Card
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;

                            result = await Db.StccCustomerFullfilment(tranId, amount.ToString(), customerEmail, customerName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms

                            var EmailMsg = $"SafariTalk \r\nYou have successfully purchased SafariTalk Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion

                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantRef;
                            emailTransaction.description = "Pay360 STCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await Pay360CashierApi.SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendEmailToCustomer == true)
                            {
                                isEmailSentToCustomer = await Pay360CashierApi.SendEmailToCustomer(customerEmail, EmailMsg, "STCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetSTCCTemplate(customerName, newBalanceCurrency, tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await Pay360CashierApi.SendHtmlEmailToCustomer(customerEmail, emailTemplateContent, "STCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "BTCC")  // BabyTalk Calling Card
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;

                            result = await Db.BtccCustomerFullfilment(tranId, amount.ToString(), customerEmail, customerName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            var EmailMsg = $"BabyTalk \r\nYou have successfully purchased BabyTalk Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion


                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantRef;
                            emailTransaction.description = "Pay360 BTCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await Pay360CashierApi.SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendEmailToCustomer == true)
                            {
                                isEmailSentToCustomer = await Pay360CashierApi.SendEmailToCustomer(customerEmail, EmailMsg, "BTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetBTCCTemplate(customerName, newBalanceCurrency, tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await Pay360CashierApi.SendHtmlEmailToCustomer(customerEmail, emailTemplateContent, "BTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "MTCC")  // MaxiTalk Calling Card
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;

                            result = await Db.MtccCustomerFullfilment(tranId, amount.ToString(), customerEmail, customerName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            var EmailMsg = $"MaxiTalk \r\nYou have successfully purchased MaxiTalk Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion


                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantRef;
                            emailTransaction.description = "Pay360 MTCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await Pay360CashierApi.SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendEmailToCustomer == true)
                            {
                                isEmailSentToCustomer = await Pay360CashierApi.SendEmailToCustomer(customerEmail, EmailMsg, "MTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetMTCCTemplate(customerName, newBalanceCurrency, tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await Pay360CashierApi.SendHtmlEmailToCustomer(customerEmail, emailTemplateContent, "MTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "TDCC")  // TalkDirect Calling Card
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;

                            result = await Db.TdccCustomerFullfilment(tranId, amount.ToString(), customerEmail, customerName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            var EmailMsg = $"TalkDirect \r\nYou have successfully purchased TalkDirect Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion


                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantRef;
                            emailTransaction.description = "Pay360 TDCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await Pay360CashierApi.SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendEmailToCustomer == true)
                            {
                                isEmailSentToCustomer = await Pay360CashierApi.SendEmailToCustomer(customerEmail, EmailMsg, "TDCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (!string.IsNullOrWhiteSpace(customerEmail) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetTDCCTemplate(customerName, newBalanceCurrency, tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await Pay360CashierApi.SendHtmlEmailToCustomer(customerEmail, emailTemplateContent, "TDCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else // ProductItemCode Not Found
                    {

                        isfullfilmentError = true;
                        isfullfilment = false;
                        isSmsSent = false;
                        isEmailSent = false;
                        isEmailSentToCustomer = false;
                        fullfilmentDatetime = DateTime.UtcNow;
                        smsSentDatetime = null;
                        emailSentDatetime = null;
                        customerEmailSentDatetime = null;
                        result = new FullfilmentResponse { ErrorCode = 2, ErrorMessage = $"ProductItemCode: {tranItem.ProductItemCode} Not Found", Pin = null };
                    }

                    BasketResponse.Add(new BasketItemsResponse() { IsFullFilled = isfullfilment, ProductItemCode = tranItem.ProductItemCode, Pin = result.Pin, Card = result.Card });

                    int dBResult = await Db.UpdateTransactionItem(tranItem.Id, result != null ? result.ErrorMessage : "Code Exception Null Object", isSmsSent, isEmailSentToCustomer, isfullfilment, smsSentDatetime, customerEmailSentDatetime, fullfilmentDatetime);
                }
                int dbresult = await Db.UpdateTransactionSummaryFullfilmentStatus(pay360TransactionId, isfullfilmentError ? 9 : 4, DateTime.UtcNow);

                userResponse.BasketResponse = BasketResponse;

                return response = GenericApiResponse<UserPaypalResumeResponse>.Success(userResponse, "Success");
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: BL_Paypal, Method: PaypalFullfilment, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return response = GenericApiResponse<UserPaypalResumeResponse>.Failure(ex.Message, 26);
            }
        }


        #endregion Fullfilment       

        private PaypalTransaction CreateDbTransactionObject(ApiPaypalPaymentResponse apiPaymentResponse, string customerMerchantRef, int customerId, string transactionMerchantRef, string userRequestJson, string pay360RequestJson, string pay360ResponseJson, bool isDirectFullfilment, string ApiInstallationIdCashierApi, string ipAddress = null)
        {
            return new PaypalTransaction
            {
                CustomerMerchantRef = customerMerchantRef,
                Customer_Id = customerId,
                Pay360CustomerId = apiPaymentResponse.Customer == null ? 0 : apiPaymentResponse.Customer.Id,
                TransactionMerchantRef = transactionMerchantRef,
                TransactionDescription = apiPaymentResponse.Transaction.TransactionDescription,
                Pay360TransactionId = apiPaymentResponse.Transaction.TransactionId,
                TransactionAmount = apiPaymentResponse.Transaction.Amount,
                TransactionStatus_Id = (int)apiPaymentResponse.Transaction.Status.ToEnum<Pay360TransactionStatuses>(),
                TransactionType_Id = (int)apiPaymentResponse.Transaction.Type.ToEnum<Pay360TransactionTypes>(),
                TransactionCurrency = apiPaymentResponse.Transaction.Currency,
                RequestTime = DateTime.UtcNow,
                TransactionTime = DateTimeOffset.Parse(apiPaymentResponse.Transaction.TransactionTime).UtcDateTime,
                TransactionReceivedTime = DateTimeOffset.Parse(apiPaymentResponse.Transaction.ReceivedTime).UtcDateTime,
                OutcomeReasonCode = apiPaymentResponse.Outcome.ReasonCode,
                OutcomeReasonMessage = apiPaymentResponse.Outcome.ReasonMessage,
                OutcomeStatus = apiPaymentResponse.Outcome.Status,
                AuthGatewayReference = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.GatewayReference),
                AuthGatewayMessage = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.GatewayMessage),
                AuthAcquirerName = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.AcquirerName),
                ClientRedirectUrl = apiPaymentResponse.ClientRedirect == null ? null : apiPaymentResponse.ClientRedirect.Url,
                PaypalAccountVerified = apiPaymentResponse.PaymentMethod == null ? false : (apiPaymentResponse.PaymentMethod.Paypal == null ? false : apiPaymentResponse.PaymentMethod.Paypal.AccountVerified),
                PaypalCheckoutToken = apiPaymentResponse.PaymentMethod == null ? null : (apiPaymentResponse.PaymentMethod.Paypal == null ? null : apiPaymentResponse.PaymentMethod.Paypal.CheckoutToken),
                PaypalPayerEmail = apiPaymentResponse.PaymentMethod == null ? null : (apiPaymentResponse.PaymentMethod.Paypal == null ? null : apiPaymentResponse.PaymentMethod.Paypal.PayerEmail),
                PaypalPayerID = apiPaymentResponse.PaymentMethod == null ? null : (apiPaymentResponse.PaymentMethod.Paypal == null ? null : apiPaymentResponse.PaymentMethod.Paypal.PayerID),
                RelatedTransactionId = apiPaymentResponse.Transaction.RelatedTransaction == null ? null : apiPaymentResponse.Transaction.RelatedTransaction.TransactionId,
                UserRequestJson = userRequestJson,
                RequestJsonToPay360 = pay360RequestJson,
                ResponseJsonFromPay360 = pay360ResponseJson,
                IpAddress = ipAddress == null ? null : ipAddress,
                IsDirectFullfilment = isDirectFullfilment,
                ApiInstallationIdCashierApi = ApiInstallationIdCashierApi
            };
        }

    }
}
