﻿using Microsoft.AspNetCore.Mvc.Rendering;
using NowPayG.Models.ApiContracts.Response;
using NowPayG.Models.Pay360ApiContracts;
using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class CheckOutViewModel : BaseViewModel
    {
        public FastTopUpViewModel FastTopUp { get; set; }
        public Pay360CardsResponse UserPay360Cards { get; set; }
        public IEnumerable<SelectListItem> UserProducts { get; set; }
        public PlanResponseModel SelectedPlan { get; set; }
        public CheckOutTypes CheckoutType { get; set; }
        public CardViewModel UserCard { get; set; }

        [Required(ErrorMessage = "Enter Number"), MaxLength(length: 12, ErrorMessage = "Maximum 12 characters allowed"), MinLength(length: 10, ErrorMessage = "Minimum 10 characters allowed")]
        public string Msisdn { get; set; }

        [Required(ErrorMessage = "Enter Number"), MaxLength(length: 12, ErrorMessage = "Maximum 12 characters allowed"), MinLength(length: 10, ErrorMessage = "Minimum 10 characters allowed")]
        public string PhoneNumber { get; set; }

        public int Amount { get; set; }

        [Required(ErrorMessage = "Enter Security Code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [Range(0, int.MaxValue, ErrorMessage = "Only numbers allowed.")]
        public string SecurityCode { get; set; }

        [Range(typeof(bool), "true", "true", ErrorMessage = "You have to agree to terms & conditions.")]
        public bool AgreeTerms { get; set; }

        public bool IsAutoToupEnabled { get; set; }

        public CountriesResponseModel ListOfCountries { get; set; }
        [Required(ErrorMessage = "Enter email address")]
        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        //[EmailAddress(ErrorMessage = "Invalid email")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        public string EmailAddress { get; set; }

        [Required(ErrorMessage = "Enter Address"), StringLength(maximumLength: 1000, ErrorMessage = "Maximum Length Exceeded")]
        public string AddressL1 { get; set; }

        public string AddressL2 { get; set; }
        public string AddressL3 { get; set; }

        public string AddressL4 { get; set; }

        public string City { get; set; }
        public string County { get; set; }

        [Required(ErrorMessage = "Enter Post Code"), StringLength(maximumLength: 9, ErrorMessage = "Maximum Length Exceeded")]
        public string PostCode { get; set; }
        public string Region { get; set; }

    }
}
