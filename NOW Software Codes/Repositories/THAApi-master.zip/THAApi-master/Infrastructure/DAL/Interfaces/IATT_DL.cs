﻿using Models.Contracts.Request;
using Models.Database;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface IATT_DL
    {
        Task<bool> IsFirstATTTransaction(string accountId);
		Task<ATTTransactions> GetATTHistory(TransferToTransactionsListRequest request, string account);
        Task<SochitelValidateExec> ValidateNowtelReferenceNew(string nowtelreference, string product);
        Task<DBProduct> GetProductByNowtelTransactionReference(string guid, string product);
        Task<SochitelValidateCustomer> ValidateNowtelCustomerNew(string frommsisdn, string nowtelreference, string product, decimal amount);
        Task SaveTransactionAsync(DBTransferTransaction transaction);
        Task CreateTransactionLogAsync(InternationalTopupTransactionLog transaction);

        Task UpdateTransactionLog(InternationalTopupTransactionLog transaction);
        Task<InternationalTopupTransactionLog> GetTransactionLog(string nowtelRef, string product);

		Task<IEnumerable<TransferToCountries>> GetTranferToCountries();
    }
}
