﻿using Application.Common.Extensions.DependencyResolver;
using Application.Features.Rating;

namespace Application.Common.Interfaces;

public interface IRatingServices : IServicesType.ITransientService
{
    Task<IEnumerable<RatingEventInfo>> GetRatingEvents();
    Task AddCustomerRating(RatingInfo request);
    Task<IEnumerable<RatingStatus>> GetRatingStatus(string emailAddress);
}
