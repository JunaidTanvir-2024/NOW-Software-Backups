﻿namespace THCC.Application.Interfaces.Repositories;

public interface ITopupRepository : ServiceType.IScoped
{
    Task<AutoTopup> GetAutoTopup(string accountNumber, string userEmail);
    Task SetAutoTopup(bool isAutoTopup, string accountNumber, string userEmail, decimal topupAmount, string topupCurrency, decimal topupTheresholdAmount, string paymentMethod = default!, string cardMaskedPan = default!, string cardInitialTransactionId = default!);
    Task DisableAutoTopup(string account);
    Task<IEnumerable<AutoTopUpTransactions>> GetAutoTopupTransactions();
    Task<decimal> GetCurrentMonthAutoTopupAmount(string productItemCode, string cardNumber, string cardPin);
    Task AddAutoTopupTransaction(int customerId,
        string customerMerchantRef,
        string pay360TransactionId,
        float transactionAmount,
        string transactionCurrency,
        DateTime? transactionDate,
        bool isTransactionSuccess,
        string transactionErrorMessage,
        bool isFullfilmentSuccess,
        string fullfilmentErrorMessage,
        DateTime? fullfilmentDate,
        string fullfilmentRef,
        bool isSmsSent,
        DateTime? smsSentDate,
        bool isEmailSent,
        DateTime? emailSentDate);
    Task<int> UpdateTHRCCAutoTopupTransaction(bool isSuccess,
            string errorMessage,
            DateTime lastExecutionTime,
            string msisdn, // Not used
            int errorCode,
            int reExecuteCount,
            string email,
            string productCode,
            string account);
}
