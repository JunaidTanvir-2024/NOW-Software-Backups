using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Products;

public class ProductUpdate
{
    [JsonPropertyName("source_id")]
    public string? SourceId { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("price")]
    public long? Price { get; set; }

    [JsonPropertyName("attributes")]
    public List<string>? Attributes { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    public static ProductUpdate FromEmpty()
    {
        return new ProductUpdate();
    }

    public static ProductUpdate FromProduct(Product product)
    {
        Metadata? metadata = null;

        if (product.Metadata != null)
        {
            metadata = new Metadata();

            foreach (var key in product.Metadata.Keys)
            {
                metadata.Add(key, product.Metadata[key]);
            }
        }

        List<string>? attributes = null;

        if (product.Attributes != null)
        {
            attributes = new List<string>();

            attributes.AddRange(product.Attributes);
        }

        return new ProductUpdate()
        {
            SourceId = product.SourceId,
            Name = product.Name,
            Attributes = attributes,
            Metadata = metadata
        };
    }
}
