﻿using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Now.Models.Configurations;
using Now.Models.Contracts;
using Now.Models.Database;
using Now.Models.DbConnections;
using Now.Models.Enums;
using Serilog;
using System.Data;

using System.Data.SqlClient;



namespace Now.Infrastructure.DAL;

public class CreditSimFulfillment_DL : ICreditSimFulfillment_DL
{
    private readonly IDbConnectionSettings _dGT_NowMobile_Db;
    private readonly IDbConnectionSettings _now_Web_Db;
    private readonly ILogger _logger;

    public CreditSimFulfillment_DL(IOptions<ConnectionStrings> connectionString, ILogger logger, IConfiguration configuration)
    {
        _dGT_NowMobile_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigiTalkNowMobileConnection));
        _now_Web_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
        _logger = logger;
    }

    public async Task<IEnumerable<DbSimOrderPool>> GetActiveNumbersFromPool()
    {
        return await _dGT_NowMobile_Db.SqlConnection.QueryAsync<DbSimOrderPool>(
                                                "now_creditSim_fulfillment_getActiveNumbers", commandType: CommandType.StoredProcedure);
    }

    public async Task<DbResult<List<DbCreditSimOrderDetail>>> GetCreditSimOrderDetail(string msisdn)
    {
        DbResult<List<DbCreditSimOrderDetail>> response = new DbResult<List<DbCreditSimOrderDetail>>();

        var parameter = new DynamicParameters();
        parameter.Add("@msisdn", msisdn);

        var result = await _now_Web_Db.SqlConnection.QueryAsync<DbCreditSimOrderDetail>(
                                                "now_central_GetCreditSimOrderDetail", parameter, commandType: CommandType.StoredProcedure);
        if (result == null)
        {
            response.DBStatus = DbStatus.Failure;
            response.ErrorCode = 2;
            response.DBErrorMessage = "No Record Found.";
        }
        else
        {
            response.DBStatus = DbStatus.Success;
            response.ErrorCode = 1;
            response.DBErrorMessage = "";
            response.Data = result.AsList();
        }

        return response;
    }

    public async Task<DbResult<DbAddBundleOrTopupResult>> AddBundleOrTopup(
        string transactionId, string bundleRef, string amount, string msisdn, PaymentType paymentType, string customerEmail)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(bundleRef))
            {
                bundleRef = "";
            }

            string creditReason = "Now Mobile Credit SIM Topup";
            string paymentMethod = "Paypal Topup";

            if (paymentType == PaymentType.Card)
            {
                paymentMethod = "Pay360 Topup";
            }

            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@bundleref", bundleRef);
            parameters.Add("@productref", msisdn);
            parameters.Add("@amount", Decimal.Parse(amount));
            parameters.Add("@transactionid", transactionId);
            parameters.Add("@bundlename", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
            parameters.Add("@ProductCode", "NOW");
            parameters.Add("@Email", customerEmail);
            parameters.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);


            var result = await _dGT_NowMobile_Db.SqlConnection.QueryFirstOrDefaultAsync<DbFullfilmentResult>(
                                        "now_central_pay360_accountupdatebalance", parameters, commandType: CommandType.StoredProcedure);
            if (result == null)
            {
                _logger.Error($"Class: CreditSimFulfillment_DL, Method: AddBundleOrTopup, Parameters => transactionId: " +
                                        $"{transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {msisdn}, " +
                                        $"paymentType: {paymentType}, ErrorMessage: Null response received from database.");


                return new DbResult<DbAddBundleOrTopupResult>
                {
                    DBStatus = DbStatus.Failure,
                    DBErrorMessage = "Null response received from database.",
                    ErrorCode = 1
                };
            }

            int ErrorCode = parameters.Get<int>("@error_code");
            string ErrorMessage = parameters.Get<string>("@error_msg");

            if (ErrorCode > 0)
            {
                return new DbResult<DbAddBundleOrTopupResult>
                {
                    DBStatus = DbStatus.Failure,
                    DBErrorMessage = ErrorMessage,
                    ErrorCode = 1
                };
            }

            DbAddBundleOrTopupResult responseData = new DbAddBundleOrTopupResult();
            responseData.Audit_id = result.Audit_id.ToString();
            responseData.BundleName = parameters.Get<string>("@bundlename");
            return new DbResult<DbAddBundleOrTopupResult> { DBStatus = DbStatus.Success, DBErrorMessage = "", ErrorCode = 0, Data = responseData };
        }
        catch (Exception ex)
        {
            return new DbResult<DbAddBundleOrTopupResult>
            {
                DBStatus = DbStatus.Failure,
                DBErrorMessage = ex.Message,
                ErrorCode = 1
            };
        }
    }

    public async Task<DbResult<string>> UpdateCreditSimFullfilment(long id, bool isFullfilled, string fulfillment_error_message, string fulfillment_ref)
    {
        DynamicParameters parameters = new DynamicParameters();
        parameters.Add("@id", id);
        parameters.Add("@isFullfilled", isFullfilled);
        parameters.Add("@fulfillment_error_message", fulfillment_error_message);
        parameters.Add("@fulfillment_ref", fulfillment_ref);

        var result = await _now_Web_Db.SqlConnection.ExecuteAsync("now_update_creditSim_Fullfilment", parameters, commandType: CommandType.StoredProcedure);
        if (result > 0)
        {
            return new DbResult<string> { DBStatus = DbStatus.Success, DBErrorMessage = "", ErrorCode = 0 };
        }
        else
        {
            _logger.Error($"Class: CreditSimFulfillment_DL, Method: UpdateCreditSimFullfilment, Parameters => id: {id}, " +
                $"isFullfilled: {isFullfilled}, fulfillment_error_message: {fulfillment_error_message}, " +
                $"fulfillment_ref: {fulfillment_ref}, ErrorMessage: Error in Data updation.");

            return new DbResult<string> { DBStatus = DbStatus.Failure, DBErrorMessage = "Error in Data updation.", ErrorCode = 1 };
        }
    }

    public async Task UpdateCreditSimFullfilmentInSimPool(int id, bool isFullfiled, string errorMessage)
    {
        DynamicParameters parameters = new DynamicParameters();
        parameters.Add("@id", id);
        parameters.Add("@isFullfilled", isFullfiled);
        parameters.Add("@fulfillment_error_message", errorMessage);

        await _dGT_NowMobile_Db.SqlConnection.ExecuteAsync("now_creditSim_fulfillment_updateFullfillmentStatus", parameters, commandType: CommandType.StoredProcedure);
    }
    public async Task UpdateSimStatus(string msisdn)
    {
        DynamicParameters parameters = new DynamicParameters();
        parameters.Add("@msisdn", msisdn);

        await _now_Web_Db.SqlConnection.ExecuteAsync("now_central_update_sim_status", parameters, commandType: CommandType.StoredProcedure);
    }

    public async Task<(bool, OrderDetails, IEnumerable<OrderItemDetails>)> GetOrderDetails(string transactionId)
    {
        var parameter = new DynamicParameters();
        parameter.Add("@TransactionId", transactionId);
        var reader = await _now_Web_Db.SqlConnection.QueryMultipleAsync("now_central_GetOrderDetailsbyTransactionId", parameter, commandType: CommandType.StoredProcedure);

        var orderDetails = reader.Read<OrderDetails>().FirstOrDefault();
        if (orderDetails != null)
        {
            var orderItemDetails = reader.Read<OrderItemDetails>().ToList();
            return (true, orderDetails, orderItemDetails);
        }
        return (true, null!, null!);
    }

    public async Task<Bundle> GetBundleById(int bundleId)
    {
        var parameters = new DynamicParameters();
        parameters.Add("@BundleId", bundleId);
        return await _dGT_NowMobile_Db.SqlConnection.QueryFirstOrDefaultAsync<Bundle>(
                                    "now_central_GetBundleById", parameters, commandType: CommandType.StoredProcedure);
    }
    public async Task<MsisdnDetails> GetMsisdnDetail(string msisdn)
    {
        var parameters = new DynamicParameters();
        parameters.Add("@msisdn", msisdn);

        return await _dGT_NowMobile_Db.SqlConnection.QueryFirstOrDefaultAsync<MsisdnDetails>(
                "th_get_mobile_account_v2", parameters, commandType: CommandType.StoredProcedure);
    }

    public async Task SetBundleAutoRenewal(bool isRenew, string msisdn, string accountId, string bundleUuid, string userEmail, PaymentType paymentMethod, string cardPanMasked = null, string cardInitialTransactionId = null)
    {
        var parameter = new DynamicParameters();
        parameter.Add("@isRenew", isRenew);
        parameter.Add("@msisdn", msisdn);
        parameter.Add("@account", accountId);
        parameter.Add("@callingPackageId", bundleUuid);
        parameter.Add("@paymentMethod", paymentMethod.ToString());
        parameter.Add("@cardPanMasked", cardPanMasked);
        parameter.Add("@cardInitialTransactionId", cardInitialTransactionId);
        parameter.Add("@email", userEmail);
        await _dGT_NowMobile_Db.SqlConnection.ExecuteAsync("now_UpdateBundleAutoRenewalStatus", parameter, commandType: CommandType.StoredProcedure);
    }

    public async Task SetAutoTopup(bool isAutoTopup, string msisdn, string userEmail, float topupAmount, string topupCurrency, float topupTheresholdAmount, PaymentType paymentMethod, string cardMaskedPan = default!, string cardInitialTransactionId = default!)
    {
        if (string.IsNullOrEmpty(topupCurrency))
        {
            topupCurrency = "GBP";
        }
        var parameters = new DynamicParameters();
        parameters.Add("@AutoTopupTheresholdAmount", topupTheresholdAmount);
        parameters.Add("@IsAutoTopup", isAutoTopup);
        parameters.Add("@Msisdn", msisdn);
        parameters.Add("@TopupAmount", topupAmount);
        parameters.Add("@TopupCurrency", topupCurrency);
        parameters.Add("@Email", userEmail);
        parameters.Add("@ProductCode", "NOW");
        parameters.Add("@PaymentMethod", paymentMethod.ToString());
        parameters.Add("@MaskedPan", cardMaskedPan);
        parameters.Add("@InitialTransactionId", cardInitialTransactionId);
        await _dGT_NowMobile_Db.SqlConnection.ExecuteAsync("now_UpdateCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);
    }
}
