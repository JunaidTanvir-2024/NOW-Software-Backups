namespace Application.Common.Extensions.DependencyResolver;

public interface IServicesType
{
    public interface IScopedService { }
    public interface ISingletonService { }
    public interface ITransientService { }
}
