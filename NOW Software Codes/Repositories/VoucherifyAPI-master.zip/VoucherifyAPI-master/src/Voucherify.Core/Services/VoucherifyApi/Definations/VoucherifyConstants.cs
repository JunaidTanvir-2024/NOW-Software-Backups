namespace Voucherify.Core.Services.VoucherifyApi.Definations;

public sealed class VoucherifyConstants
{
    private VoucherifyConstants() { }
    public static class Endpoints
    {
        public const string Vouchers = "/vouchers/";
        public const string EnableVoucher = "/vouchers/{0}/enable/";
        public const string DisableVoucher = "/vouchers/{0}/disable/";
        public const string ValidateVoucher = "/vouchers/{0}/validate/";
        public const string RedeemVoucher = "/vouchers/{0}/redemption/";
        public const string Promotions = "/promotions/tiers/";
        public const string ValidatePromotion = "/promotions/tiers/{0}/validation/";
        public const string ValidatePromotionList = "/promotions/validation/";
        public const string RedeemPromotion = "/promotions/tiers/{0}/redemption/";
        public const string Campaigns = "/campaigns/";
        public const string ExamineCampaigns = "/campaigns/qualification/";
        public const string EnableCampaign = "/campaigns/{0}/enable/";
        public const string DisableCampaign = "/campaigns/{0}/disable/";
        public const string Rewards = "/rewards/";
        public const string Customers = "/customers/";
        public const string Orders = "/orders/";
        public const string Loyalties = "/loyalties/";
        public const string LoyaltiesRewards = "/loyalties/{0}/rewards/";
        public const string EarningRule = "/loyalties/{0}/earning-rules/";
        public const string EnableEarningRule = "/loyalties/{0}/earning-rules/{1}/enable/";
        public const string DisableEarningRule = "/loyalties/{0}/earning-rules/{1}/disable/";
        public const string RedeemReward = "/loyalties/{0}/members/{1}/";
        public const string Events = "/events/";
        public const string Products = "/products/";
        public const string Skus = "/skus/";
        public const string Publications = "/publications/";
        public const string StackableDiscountValidations = "/validations/";
        public const string StackableDiscountRedemptions = "/redemptions/";
        public const string StackableDiscountRollback = "/redemptions/{0}/rollbacks/";
    }
}
