namespace MM.Core.Common.Interfaces.Services.Models;
public record HttpServiceResponse
{
    public required bool IsFailure { get; init; }
    public required string Json { get; init; }
}
