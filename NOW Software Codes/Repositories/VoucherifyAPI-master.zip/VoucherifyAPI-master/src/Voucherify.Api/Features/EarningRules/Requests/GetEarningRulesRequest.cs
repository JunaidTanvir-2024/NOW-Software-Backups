using System.ComponentModel;

using FluentValidation;

namespace Voucherify.Api.Features.EarningRules.Requests;

public class GetEarningRulesRequest
{
    public string CampaignNameOrId { get; set; } = null!;

    [DefaultValue(1)]
    public int PageNumber { get; set; }

    [DefaultValue(10)]
    public int PageSize { get; set; }
}

internal class GetEarningRulesRequestValidator : AbstractValidator<GetEarningRulesRequest>
{
    public GetEarningRulesRequestValidator()
    {
        RuleFor(p => p.CampaignNameOrId).NotNull().NotEmpty();
        RuleFor(p => p.PageNumber).GreaterThan(0);
        RuleFor(p => p.PageSize).GreaterThan(0);
    }
}