﻿namespace Application.Features.Account.ChangePassword;
public class ChangePasswordRequestValidator : AbstractValidator<ChangePasswordRequest>
{
    public ChangePasswordRequestValidator()
    {
        RuleFor(p => p.ConfirmNewPassword).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.NewPassword).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.OldPassword).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(x => x).Custom((x, context) =>
        {
            if (x.NewPassword != x.ConfirmNewPassword)
            {
                context.AddFailure(nameof(x.NewPassword), "Passwords should match");
            }
        });
    }
}
