using Application.Common.Extensions.DependencyResolver;
using Application.Features.Payment.Models;
using Domain.Aggregate;

namespace Application.Common.Mailing;

public interface IMailService : IServicesType.ITransientService
{
    Task SendForgotPasswordEmailAsync(string toEmail, int Otp);
    Task SendSignupEmailOtpAsync(string toEmail, int Otp, bool? IsUserAlreadyRegisterd = false);
    Task SendTopUpEmail(OrderDetails orderDetails, IEnumerable<OrderItemDetails> orderItemDetails);
    Task SendBundleEmail(OrderDetails orderDetails, IEnumerable<OrderItemDetails> orderItemDetails);
    Task SendFreeSimOrderEmail(string firstName, string lastName, string email);
    Task SendEmailToCustomer(string customerEmail, string Message, string Subject);
    Task SendCreditSimOrderEmail(OrderDetails orderDetails, IEnumerable<OrderItemDetails> orderItemDetails);
}