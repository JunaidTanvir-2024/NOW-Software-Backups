﻿using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerCard.Request;
using SC.Core.Features.CustomerOrder.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerCard;
internal sealed class MarkCardDefaultRequestHandler : IRequestHandler<MarkCardDefaultRequest, IResultWrapper>
{
    private readonly ICustomerCardRepository _customerCardRespository;
    private readonly ICommonService _commonService;
    public MarkCardDefaultRequestHandler(ICustomerCardRepository customerCardRespository, ICommonService commonService)
    {
        _customerCardRespository = customerCardRespository;
        _commonService = commonService;
    }
    public async Task<IResultWrapper> Handle(MarkCardDefaultRequest request, CancellationToken cancellationToken)
    {


        var RemovedCard = await _customerCardRespository.MarkCardAsDefaultAsync(request.CardID, _commonService.GetUserID());

        return ResultWrapper.Success(new { IsMarkedDefault = RemovedCard });
    }

}

