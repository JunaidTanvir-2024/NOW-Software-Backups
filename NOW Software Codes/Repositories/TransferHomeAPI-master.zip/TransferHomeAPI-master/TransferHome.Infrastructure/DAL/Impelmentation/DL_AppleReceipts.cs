﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Infrastructure.DAL.Interfaces;
using TrasnferHome.Models.Configurations;
using TrasnferHome.Models.DbConnections;

namespace TransferHome.Infrastructure.DAL.Impelmentation
{
    public class DL_AppleReceipts : IDL_AppleReceipts
    {
        private readonly IDbConnectionSettings Db;
        public DL_AppleReceipts(IOptions<ConnectionString> connectionString)
        {
            Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TransferHomeDbConnection));
        }

        //public async Task<bool> IsReceiptExists(string Token)
        //{
        //}
    }
}
