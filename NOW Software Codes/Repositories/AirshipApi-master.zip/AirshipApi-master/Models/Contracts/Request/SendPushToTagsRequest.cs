﻿using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class SendPushToTagsRequest
    {
        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("DeviceType")]
        [Required]
        //[EnumDataType(typeof(DeviceType))]
        public List<DeviceType> DeviceTypes { get; set; }
       
        [JsonProperty("TagGroup")]        
        public string TagGroup { get; set; }

        [JsonProperty("Tags")]
        [Required]
        public List<string> Tags { get; set; }

        [JsonProperty("Notification")]
        [Required]
        public Notification Notification { get; set; }

        [JsonProperty("Actions")]        
        public Action Actions { get; set; }
    }

    public class Notification
    {
        [JsonProperty("Alert")]
        [Required]
        public string Alert { get; set; }
    }

    public class Action
    {
        [JsonProperty("Open")]
        [Required]
        public Open Open { get; set; }
    }

    public class Open
    {
        [JsonProperty("Type")]
        [Required]
        [EnumDataType(typeof(ActionOpenType))]
        public ActionOpenType Type { get; set; }

        [JsonProperty("Content")]
        [Required]
        public string Content { get; set; }

        [JsonProperty("FallbackUrl")]        
        public string FallbackUrl { get; set; }
    }
}
