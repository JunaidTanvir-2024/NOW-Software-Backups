﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts
{
    public class PayPalExecuteSaleTopupRequest
    {
        [JsonProperty("payer_id")]
        [Required]
        public string PayerId { get; set; }


        [JsonProperty("payment_id")]
        [Required]
        public string PaymentId { get; set; }
    }
}
