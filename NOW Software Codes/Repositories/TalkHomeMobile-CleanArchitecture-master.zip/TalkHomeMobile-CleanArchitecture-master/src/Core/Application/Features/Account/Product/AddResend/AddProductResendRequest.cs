﻿namespace Application.Features.Account.Product.AddResend;
public class AddProductResendRequest : IRequest<Result<object>>
{
    public string Alias { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
}
