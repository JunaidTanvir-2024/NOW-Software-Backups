﻿using Dapper;

using NTCB.Api.Commons.Definations;
using NTCB.Api.Commons.Wrappers.Db;

using System.Data;

namespace NTCB.Api.Features.DTOne;

public class DTOneRepository : IDTOneRepository
{
    public async Task<bool> VerifyTransactionStatus(string transactionReferenceId)
    {
        DynamicParameters dynamicParameters = new DynamicParameters();
        dynamicParameters.Add("@TransactionReferenceId", transactionReferenceId);

        return await DapperWrapper.QueryFirstOrDefaultAsync<bool>(NTCBConstants.StoreProcedures.VerifyDTOneTransaction, dynamicParameters, CommandType.StoredProcedure);
    }
    public async Task<bool> UpdateTransactionRecord(string transactionReferenceId, string transactionStatus, string dtOneJsonResponse, string? transactionErrorMessage)
    {
        DynamicParameters dynamicParameters = new DynamicParameters();
        dynamicParameters.Add("@TransactionReferenceId", transactionReferenceId);
        dynamicParameters.Add("@TransactionStatus", transactionStatus);
        dynamicParameters.Add("@@TransactionStatusMessage", transactionErrorMessage);
        dynamicParameters.Add("@DTOneTransactionResponse", dtOneJsonResponse);

        return await DapperWrapper.QueryFirstOrDefaultAsync<bool>(NTCBConstants.StoreProcedures.UpdateDTOneTransaction, dynamicParameters, CommandType.StoredProcedure);
    }
    public async Task<bool> UpdateCallbackRecord(string transactionReferenceId, string transactionStatus, string dtOneJsonResponse)
    {
        DynamicParameters dynamicParameters = new DynamicParameters();
        dynamicParameters.Add("@TransactionReferenceId", transactionReferenceId);
        dynamicParameters.Add("@TransactionStatus", transactionStatus);
        dynamicParameters.Add("@DTOneTransactionResponse", dtOneJsonResponse);

        return await DapperWrapper.QueryFirstOrDefaultAsync<bool>(NTCBConstants.StoreProcedures.UpdateCallbackStatus, dynamicParameters, CommandType.StoredProcedure);
    }
}
