﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class ResumeTransferTransactionRequestModel
    {
        [Required]
        public string NowtelTransactionReference { get; set; }
        [Required]
        public string OperatorId { get; set; }
        [Required]
        public string Product { get; set; }
        public string MessageToRecipient { get; set; }
        [Required]
        public string FromMsisdn { get; set; }
        [Required]
        public string Token { get; set; }
        [Required]
        public int TokenTypeId { get; set; }
    }
}
