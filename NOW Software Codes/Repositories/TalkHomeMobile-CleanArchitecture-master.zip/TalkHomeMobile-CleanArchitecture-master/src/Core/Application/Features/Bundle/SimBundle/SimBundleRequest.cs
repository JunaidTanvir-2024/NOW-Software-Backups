using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.SimBundle;

public sealed class SimBundleRequest : IRequest<Result<List<BundleInfo>>> { }