﻿using Application.Common.Interfaces.Payment;
using Application.Common.Settings;
using Microsoft.Extensions.Options;
using System.Globalization;

namespace Application.Features.Payment.Card.CustomerCards;

public class CustomerCardsRequestHandler : IRequestHandler<CustomerCardsRequest, Result<List<CustomerCard>>>
{
    #region Fields

    private readonly IStringLocalizer<CustomerCardsRequestHandler> _localizer;
    private readonly ICardService _cardService;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly CallBackSettings _callbackSettings;

    #endregion

    #region Ctors
    public CustomerCardsRequestHandler(
        IStringLocalizer<CustomerCardsRequestHandler> localizer,
        ICardService cardService,
        IOptions<CallBackSettings> callbackSettings,
        ICurrentUser currentUser,
        ICommonService commonService)
    {
        _localizer = localizer;
        _cardService = cardService;
        _currentUser = currentUser;
        _commonService = commonService;
        _callbackSettings = callbackSettings.Value;
    }

    #endregion


    public async Task<Result<List<CustomerCard>>> Handle(CustomerCardsRequest request, CancellationToken cancellationToken)
    {
          (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();

        var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);

        foreach (var card in cards)
        {
            card.ImageUrl = (IsAppRequest ? _callbackSettings.AppBaseUrl!
                : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(card.CardScheme);
            if (!IsAppRequest)
            {
                DateTime dt = DateTime.ParseExact(card.ExpiryDate, "MMyy", CultureInfo.InvariantCulture);
                card.ExpiryDate = dt.ToString("MM/yy", CultureInfo.InvariantCulture);
            }
        }

        if (cards.Count > 0 && !cards.Any(x => x.IsPrimary))
        {
            cards.First().IsPrimary = true;
        }

        return Result<List<CustomerCard>>.Success(cards, _localizer[CustomStatusKey.Success]);
    }
}
