﻿using MapsterMapper;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.Products;
using SC.Core.Vendors.FusionHub;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder;
internal sealed class CarItemCreationHandler : IRequestHandler<CartItemCreationRequest, IResultWrapper>
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly ICommonService _commonService;
    private readonly IFusionHubService _fusionHubService;
    private readonly IMapper _mapper;
    public CarItemCreationHandler(ICustomerCartRespository customerCartRespository, ICommonService commonService, IFusionHubService fusionHubService, IMapper mapper)
    {
        _customerCartRespository = customerCartRespository;
        _commonService = commonService;
        _fusionHubService = fusionHubService;
        _mapper = mapper;
    }
    public async Task<IResultWrapper> Handle(CartItemCreationRequest request, CancellationToken cancellationToken)
    {

        var getProductRequest = new GetProductsRequest()
        {
            Page = 1,
            RecordsPerPage = 1,
            Filters = new Common.Model.Filter() { ProductId = (int)request.productId }
        };

        var productresponse = await _fusionHubService.GetProductAsync(getProductRequest);
        if (productresponse?.Payload == null)
        {
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
        }
        var productResult = _mapper.Map<List<GetProductsResponse>>(productresponse.Payload);

        string VendorProductCode = string.Empty;
        string? productType = string.Empty;
        if (productResult != null && productResult.Count > 0)
        {
            VendorProductCode = productResult.First().Product.VendorProductCode!;
            productType = productResult.First().Product.ProductSubCategory?.SubCategoryName;
        }

        var cart = new CartItemCreationDto()
        {
            receiverEmail = request.receiverEmail,
            receiverMobile = request.receiverMobile,
            receiverPin = request.receiverPin,
            customMessage = request.customMessage,
            isRenewal = request.isRenewal,
            senderId = request.senderId,
            senderName = request.senderName,
            senderEmail = request.senderEmail,
            senderMobile = request.senderMobile,
            productId = request.productId,
            customerCartId = request.customerCartId,
            isActive = request.isDeleted,
            isDeleted = request.isActive,
            customerID = _commonService.GetUserID(),
            ProductVendorCode = VendorProductCode,
            ProductType =productType
        };
        var response = await _customerCartRespository.CartItemCreationAsync(cart);
        return ResultWrapper.Success(response);
    }
}

