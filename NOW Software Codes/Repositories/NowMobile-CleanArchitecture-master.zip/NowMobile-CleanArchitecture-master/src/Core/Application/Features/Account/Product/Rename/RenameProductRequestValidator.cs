﻿namespace Application.Features.Account.Product.Rename;
public class RenameProductRequestValidator : AbstractValidator<RenameProductRequest>
{
    public RenameProductRequestValidator(ICommonService commonService)
    {
        RuleFor(x => x.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(x => commonService.IsValidMsisdn(x))
            .WithMessage("Invalid msisdn");

        RuleFor(p => p.Alias).Cascade(CascadeMode.Stop)
           .NotEmpty()
           .NotNull();
    }
}
