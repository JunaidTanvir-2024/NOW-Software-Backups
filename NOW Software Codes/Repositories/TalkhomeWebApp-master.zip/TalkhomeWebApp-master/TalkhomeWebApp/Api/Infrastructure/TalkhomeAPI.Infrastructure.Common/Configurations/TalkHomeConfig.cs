﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class TalkHomeConfig
    {
        public SignUpType SignUpType { get; set; }
        
        
        public string ApiEndPoint { get; set; }
        public string NowtelAuthToken { get; set; }


        public string SignUpPreAuthAEndPoint { get; set; }
        public string SignUpPreAuthAEndPointV2 { get; set; }
        public string PreAuthEndPoint { get; set; }
        public string LoginEndPoint { get; set; }
		public string SignupPreAuthAPrivateAccessKey { get; set; }	
	}
}
