﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
//using TalkhomeAPI.Infrastructure.Common.Services.Models.FaceBook;
using TalkhomeWebApp.Models.Configurations;
using TalkhomeWebApp.Models.Facebook.CustomEvents;

namespace TalkhomeWebApp.Services
{
    public interface IFacebookService
    {

        public bool IsActive { get; }
        //Task AddCustomEvent(CustomFbEventsRequest data);
        Task CreateCustomEvent(string advertiserID, EventDetailsModel eventDetails);
    }
    public class FacebookService : IFacebookService
    {
        private readonly FacebookConfig _facebookConfig;
        private readonly HttpClient _faceBookClient;
        private readonly ILogger _logger;
        public bool IsActive { get; }

        public FacebookService(IOptions<FacebookConfig> facebookConfig, HttpClient httpClient,
                        ILogger logger)
        {
            _facebookConfig = facebookConfig.Value;
            IsActive = facebookConfig.Value.IsActive;
            _faceBookClient = httpClient;
            _logger = logger;
        }

        public async Task CreateCustomEvent(string advertiserID, EventDetailsModel eventDetails)
        {
            try
            {
                var requestModel = new FaceBookCreateEventRequestModel()
                {
                    _event = "CUSTOM_APP_EVENTS",
                    advertiser_tracking_enabled = 1,
                    application_tracking_enabled = 1,
                    custom_events = new List<EventDetailsModel>
                    {
                        new EventDetailsModel
                        {
                            _eventName=eventDetails._eventName,
                            _valueToSum=eventDetails._valueToSum,
                            fb_currency=eventDetails.fb_currency
                        }
                    },
                    advertiser_id = advertiserID,
                };
                string URL = _facebookConfig.ApiEndpoint + _facebookConfig.APPID + "/activities";
                var request = new HttpRequestMessage(HttpMethod.Post, URL)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(requestModel), Encoding.UTF8, "application/json")
                };
                await _faceBookClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message);
            }
        }
    }
}

