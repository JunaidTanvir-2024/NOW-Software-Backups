﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Pay360ApiContracts;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Pay360ApiContracts;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface IPay360Service
    {
        Task<GenericApiResponse<Pay360PaymentResponse>> Resume3DTransaction(Pay360Resume3DRequest request);
        Task<GenericApiResponse<Pay360PaymentResponse>> Resume3DTransactionV2(Pay360Resume3DRequest request);
        Task<GenericApiResponse<Pay360CustomerModel>> GetCustomer(Pay360CustomerRequestModel model);
        Task<GenericApiResponse<Pay360CardsResponse>> Pay360GetCards(Pay360CustomerRequestModel request);
        Task<GenericApiResponse<Pay360PaymentResponse>> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType);
        Pay360PaymentRequestToken CreatePay360PaymentRequestToken(Pay360PaymentRequestModel model);
        Pay360PaymentBase CreatePay360PaymentBaseRequest(StartPay360Model model);
        Pay360PaymentRequestExistingNew CreatePay360PaymentRequestExistingNew(Pay360PaymentRequestModel model);
        Pay360PaymentRequestNew CreatePay360PaymentRequestNew(Pay360PaymentRequestModel model);
        Task<GenericApiResponse<string>> SetAutoTopUp(Pay360SetAutoTopUpRequest model);
        Task<GenericApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(Pay360GetAutoTopUpRequest model);
        Task<GenericApiResponse<paymentMethodResponse>> SetCustomerDefaultCard(SetCustomerDefaultCardRequest model);
        Task<GenericApiResponse<string>> RemoveCard(RemoveCardRequest model);
        Task<GenericPay360ApiResponse<RefundFullPaymentResponseModel>> RefundFullPayment(RefundFullPaymentRequestModel request);
        Task<GenericPay360ApiResponse<CaptureTransactionResponseModel>> CaptureTransaction(CaptureTransactionRequestModel model);
        Task<GenericPay360ApiResponse<string>> cancelTransaction(CancelTransactionRequestModel model);       
    }
}
