﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Dapper;
using Microsoft.AspNetCore.Identity;

namespace AspNetCore.Identity.Dapper
{
    /// <summary>
    /// The default implementation of <see cref="IUsersTable{TUser, TKey, TUserClaim, TUserRole, TUserLogin, TUserToken}"/>.
    /// </summary>
    /// <typeparam name="TUser">The type representing a user.</typeparam>
    /// <typeparam name="TKey">The type of the primary key for a role and user.</typeparam>
    /// <typeparam name="TUserClaim">The type representing a claim.</typeparam>
    /// <typeparam name="TUserRole">The type representing a user role.</typeparam>
    /// <typeparam name="TUserLogin">The type representing a user external login.</typeparam>
    /// <typeparam name="TUserToken">The type representing a user token.</typeparam>
    public class UsersTable<TUser, TKey, TUserClaim, TUserRole, TUserLogin, TUserToken> : IdentityTable, IUsersTable<TUser, TKey, TUserClaim, TUserRole, TUserLogin, TUserToken>
        where TUser : IdentityUser<TKey>
        where TKey : IEquatable<TKey>
        where TUserClaim : IdentityUserClaim<TKey>, new()
        where TUserRole : IdentityUserRole<TKey>, new()
        where TUserLogin : IdentityUserLogin<TKey>, new()
        where TUserToken : IdentityUserToken<TKey>, new()
    {
        /// <summary>
        /// Creates a new instance of <see cref="UsersTable{TUser, TKey, TUserClaim, TUserRole, TUserLogin, TUserToken}"/>.
        /// </summary>
        /// <param name="dbConnectionFactory">A factory for creating instances of <see cref="IDbConnection"/>.</param>
        public UsersTable(IDbConnectionFactory dbConnectionFactory) : base(dbConnectionFactory) { }

        /// <inheritdoc/>
        public virtual async Task<bool> CreateAsync(TUser user)
        {
            const string sql = @"
                INSERT INTO [dbo].[users]
                VALUES (@Id, @UserName, @NormalizedUserName, @Email, @NormalizedEmail, @EmailConfirmed, @PasswordHash, @SecurityStamp, @ConcurrencyStamp, @PhoneNumber, @PhoneNumberConfirmed, @TwoFactorEnabled, @LockoutEnd, @LockoutEnabled, @AccessFailedCount);
            ";
            var rowsInserted = await DbConnection.ExecuteAsync(sql, new
            {
                user.Id,
                user.UserName,
                user.NormalizedUserName,
                user.Email,
                user.NormalizedEmail,
                user.EmailConfirmed,
                user.PasswordHash,
                user.SecurityStamp,
                user.ConcurrencyStamp,
                user.PhoneNumber,
                user.PhoneNumberConfirmed,
                user.TwoFactorEnabled,
                user.LockoutEnd,
                user.LockoutEnabled,
                user.AccessFailedCount
            });
            return rowsInserted == 1;
        }

        /// <inheritdoc/>
        public virtual async Task<bool> DeleteAsync(TKey userId)
        {
            const string sql = @"
                DELETE
                FROM [dbo].[users]
                WHERE [user_id] = @Id;
            ";
            var rowsDeleted = await DbConnection.ExecuteAsync(sql, new { Id = userId });
            return rowsDeleted == 1;
        }

        /// <inheritdoc/>
        public virtual async Task<TUser> FindByIdAsync(TKey userId)
        {
            const string sql = @"
               SELECT user_id	as	Id
                        ,user_name	as	UserName
                        ,normalized_user_name	as	NormalizedUserName
                        ,email	as	Email
                        ,normalized_email	as	NormalizedEmail
                        ,email_confirmed	as	EmailConfirmed
                        ,password_hash	as	PasswordHash
                        ,security_stamp	as	SecurityStamp
                        ,concurrency_stamp	as	ConcurrencyStamp
                        ,phone_number	as	PhoneNumber
                        ,phone_number_confirmed	as	PhoneNumberConfirmed
                        ,two_factor_enabled	as	TwoFactorEnabled
                        ,lockoutend	as	LockoutEnd
                        ,lockout_enabled	as	LockoutEnabled
                        ,access_failed_count	as	AccessFailedCount
                FROM [dbo].[users]
                WHERE [user_id] = @Id;
            ";
            var user = await DbConnection.QuerySingleOrDefaultAsync<TUser>(sql, new { Id = userId });
            return user;
        }

        /// <inheritdoc/>
        public virtual async Task<TUser> FindByNameAsync(string normalizedUserName)
        {

            const string sql = @"
                SELECT user_id	as	Id
                        ,user_name	as	UserName
                        ,normalized_user_name	as	NormalizedUserName
                        ,email	as	Email
                        ,normalized_email	as	NormalizedEmail
                        ,email_confirmed	as	EmailConfirmed
                        ,password_hash	as	PasswordHash
                        ,security_stamp	as	SecurityStamp
                        ,concurrency_stamp	as	ConcurrencyStamp
                        ,phone_number	as	PhoneNumber
                        ,phone_number_confirmed	as	PhoneNumberConfirmed
                        ,two_factor_enabled	as	TwoFactorEnabled
                        ,lockoutend	as	LockoutEnd
                        ,lockout_enabled	as	LockoutEnabled
                        ,access_failed_count	as	AccessFailedCount
                FROM [dbo].[users]
                WHERE [normalized_user_name] = @NormalizedUserName;
            ";
            var user = await DbConnection.QuerySingleOrDefaultAsync<TUser>(sql, new { NormalizedUserName = normalizedUserName });
            return user;
        }

        /// <inheritdoc/>
        public virtual async Task<TUser> FindByEmailAsync(string normalizedEmail)
        {

            const string sql = @"
                SELECT user_id	as	Id
                        ,user_name	as	UserName
                        ,normalized_user_name	as	NormalizedUserName
                        ,email	as	Email
                        ,normalized_email	as	NormalizedEmail
                        ,email_confirmed	as	EmailConfirmed
                        ,password_hash	as	PasswordHash
                        ,security_stamp	as	SecurityStamp
                        ,concurrency_stamp	as	ConcurrencyStamp
                        ,phone_number	as	PhoneNumber
                        ,phone_number_confirmed	as	PhoneNumberConfirmed
                        ,two_factor_enabled	as	TwoFactorEnabled
                        ,lockoutend	as	LockoutEnd
                        ,lockout_enabled	as	LockoutEnabled
                        ,access_failed_count	as	AccessFailedCount
                FROM [dbo].[users]
                WHERE [normalized_email] = @NormalizedEmail;
            ";
            var user = await DbConnection.QuerySingleOrDefaultAsync<TUser>(sql, new { NormalizedEmail = normalizedEmail });
            return user;

        }

        /// <inheritdoc/>
        public virtual Task<bool> UpdateAsync(TUser user, IList<TUserClaim> claims, IList<TUserLogin> logins, IList<TUserToken> tokens) => UpdateAsync(user, claims, null, logins, tokens);

        /// <inheritdoc/>
        public virtual async Task<bool> UpdateAsync(TUser user, IList<TUserClaim> claims, IList<TUserRole> roles, IList<TUserLogin> logins, IList<TUserToken> tokens)
        {
            const string updateUserSql = @"
                UPDATE [dbo].[users]
                SET 
                    [access_failed_count] = @AccessFailedCount,
                    [lockout_enabled] =@LockoutEnabled,
                    [lockoutend]=@LockoutEnd,
                    [email_confirmed]=@EmailConfirmed,
                    [two_factor_enabled] =@TwoFactorEnabled,
                    [password_hash]=@PasswordHash
                WHERE [user_id] = @Id;
            ";
            var rowsupdated = await DbConnection.ExecuteAsync(updateUserSql, new
            {
                user.Id,
                user.AccessFailedCount,
                user.LockoutEnabled,
                user.LockoutEnd,
                user.EmailConfirmed
                ,
                user.TwoFactorEnabled,
                user.PasswordHash
            });
            return rowsupdated == 1;
            //using (var transaction = DbConnection.BeginTransaction())
            //{
            //    await DbConnection.ExecuteAsync(updateUserSql, new
            //    {
            //        user.UserName,
            //        user.NormalizedUserName,
            //        user.Email,
            //        user.NormalizedEmail,
            //        user.EmailConfirmed,
            //        user.PasswordHash,
            //        user.SecurityStamp,
            //        user.ConcurrencyStamp,
            //        user.PhoneNumber,
            //        user.PhoneNumberConfirmed,
            //        user.TwoFactorEnabled,
            //        user.LockoutEnd,
            //        user.LockoutEnabled,
            //        user.AccessFailedCount,
            //        user.Id
            //    }, transaction);
            //    if (claims?.Count() > 0)
            //    {
            //        const string deleteClaimsSql = @"
            //            DELETE 
            //            FROM [dbo].[user_claims]
            //            WHERE [user_id] = @UserId;
            //        ";
            //        await DbConnection.ExecuteAsync(deleteClaimsSql, new { UserId = user.Id }, transaction);
            //        const string insertClaimsSql = @"
            //            INSERT INTO [dbo].[user_claims] (user_id, claim_type, claim_value)
            //            VALUES (@UserId, @ClaimType, @ClaimValue);
            //        ";
            //        await DbConnection.ExecuteAsync(insertClaimsSql, claims.Select(x => new
            //        {
            //            UserId = user.Id,
            //            x.ClaimType,
            //            x.ClaimValue
            //        }), transaction);
            //    }
            //    if (roles?.Count() > 0)
            //    {
            //        const string deleteRolesSql = @"
            //            DELETE
            //            FROM [dbo].[user_roles]
            //            WHERE [user_id] = @UserId;
            //        ";
            //        await DbConnection.ExecuteAsync(deleteRolesSql, new { UserId = user.Id }, transaction);
            //        const string insertRolesSql = @"
            //            INSERT INTO [dbo].[user_roles] (user_id, role_id)
            //            VALUES (@UserId, @RoleId);
            //        ";
            //        await DbConnection.ExecuteAsync(insertRolesSql, roles.Select(x => new
            //        {
            //            UserId = user.Id,
            //            x.RoleId
            //        }), transaction);
            //    }
            //    if (logins?.Count() > 0)
            //    {
            //        const string deleteLoginsSql = @"
            //            DELETE
            //            FROM [dbo].[user_logins]
            //            WHERE [user_id] = @UserId;
            //        ";
            //        await DbConnection.ExecuteAsync(deleteLoginsSql, new { UserId = user.Id }, transaction);
            //        const string insertLoginsSql = @"
            //            INSERT INTO [dbo].[user_logins] (login_provider, provider_key, provider_display_name, user_id)
            //            VALUES (@LoginProvider, @ProviderKey, @ProviderDisplayName, @UserId);
            //        ";
            //        await DbConnection.ExecuteAsync(insertLoginsSql, logins.Select(x => new
            //        {
            //            x.LoginProvider,
            //            x.ProviderKey,
            //            x.ProviderDisplayName,
            //            UserId = user.Id
            //        }), transaction);
            //    }
            //    if (tokens?.Count() > 0)
            //    {
            //        const string deleteTokensSql = @"
            //            DELETE
            //            FROM [dbo].[user_tokens]
            //            WHERE [user_id] = @UserId;
            //        ";
            //        await DbConnection.ExecuteAsync(deleteTokensSql, new { UserId = user.Id }, transaction);
            //        const string insertTokensSql = @"
            //            INSERT INTO [dbo].[user_tokens] (user_id, login_provider, name, value)
            //            VALUES (@UserId, @LoginProvider, @Name, @Value);
            //        ";
            //        await DbConnection.ExecuteAsync(insertTokensSql, tokens.Select(x => new
            //        {
            //            x.UserId,
            //            x.LoginProvider,
            //            x.Name,
            //            x.Value
            //        }), transaction);
            //    }
            //    try
            //    {
            //        transaction.Commit();
            //    }
            //    catch
            //    {
            //        transaction.Rollback();
            //        return false;
            //    }
            //}
            return true;
        }

        /// <inheritdoc/>
        public virtual async Task<IEnumerable<TUser>> GetUsersInRoleAsync(string roleName)
        {
            const string sql = @"
                 SELECT u.user_id	as	Id
                        ,u.user_name	as	UserName
                        ,u.normalized_user_name	as	NormalizedUserName
                        ,u.email	as	Email
                        ,u.normalized_email	as	NormalizedEmail
                        ,u.email_confirmed	as	EmailConfirmed
                        ,u.password_hash	as	PasswordHash
                        ,u.security_stamp	as	SecurityStamp
                        ,u.concurrency_stamp	as	ConcurrencyStamp
                        ,u.phone_number	as	PhoneNumber
                        ,u.phone_number_confirmed	as	PhoneNumberConfirmed
                        ,u.two_factor_enabled	as	TwoFactorEnabled
                        ,u.lockoutend	as	LockoutEnd
                        ,u.lockout_enabled	as	LockoutEnabled
                        ,u.access_failed_count	as	AccessFailedCount
                FROM [dbo].[users] AS [u]
                INNER JOIN [dbo].[user_roles] AS [ur] ON [u].[user_id] = [ur].[user_id]
                INNER JOIN [dbo].[roles] AS [r] ON [ur].[role_id] = [r].[role_id]
                WHERE [r].[name] = @RoleName;
            ";
            var users = await DbConnection.QueryAsync<TUser>(sql, new { RoleName = roleName });
            return users;
        }

        /// <inheritdoc/>
        public virtual async Task<IEnumerable<TUser>> GetUsersForClaimAsync(Claim claim)
        {
            const string sql = @"
                  SELECT u.user_id	as	Id
                        ,u.user_name	as	UserName
                        ,u.normalized_user_name	as	NormalizedUserName
                        ,u.email	as	Email
                        ,u.normalized_email	as	NormalizedEmail
                        ,u.email_confirmed	as	EmailConfirmed
                        ,u.password_hash	as	PasswordHash
                        ,u.security_stamp	as	SecurityStamp
                        ,u.concurrency_stamp	as	ConcurrencyStamp
                        ,u.phone_number	as	PhoneNumber
                        ,u.phone_number_confirmed	as	PhoneNumberConfirmed
                        ,u.two_factor_enabled	as	TwoFactorEnabled
                        ,u.lockoutend	as	LockoutEnd
                        ,u.lockout_enabled	as	LockoutEnabled
                        ,u.access_failed_count	as	AccessFailedCount
                FROM [dbo].[users] AS [u]
                INNER JOIN [dbo].[user_claims] AS [uc] ON [u].[user_id] = [uc].[user_id]
                WHERE [uc].[claim_type] = @ClaimType AND [uc].[claim_value] = @ClaimValue;
            ";
            var users = await DbConnection.QueryAsync<TUser>(sql, new
            {
                ClaimType = claim.Type,
                ClaimValue = claim.Value
            });
            return users;
        }
    }
}
