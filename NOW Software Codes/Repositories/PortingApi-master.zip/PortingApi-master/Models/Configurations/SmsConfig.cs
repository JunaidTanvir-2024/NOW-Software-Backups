﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class SmsConfig
    {
        public string ApiEndPoint { get; set; }
        public string SmsFrom { get; set; }
        public string SmsJobId { get; set; }
    }
}
