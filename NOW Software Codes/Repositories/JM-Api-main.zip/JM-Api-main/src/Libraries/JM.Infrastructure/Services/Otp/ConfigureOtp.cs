using JM.Core.Utilities.Settings;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace JM.Infrastructure.Services.Otp;

internal static partial class ConfigureOtp
{
    #region Otp Dependency Extension
    internal static IServiceCollection AddOtpConfiguration(this IServiceCollection services, IConfiguration configuration)
    {
        return services
                    .Configure<OtpSetting>(configuration.GetSection(OtpSetting.SectionName));
    }

    #endregion
}
