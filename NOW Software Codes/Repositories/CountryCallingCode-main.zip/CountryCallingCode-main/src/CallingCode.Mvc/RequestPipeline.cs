﻿using CallingCode.Mvc.Middlewares;

namespace CallingCode.Mvc;

public static class RequestPipeline
{
    public static WebApplication AddMiddlewaresToRequestPipelines(this WebApplication app)
    {
        //app.Use(async (context, next) =>
        //{
        //    context.Items.Add("VisitorTime", DateTime.Now);
        //    await next();
        //});

        // Configure the HTTP request pipeline.
        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/Home/Error");
            // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            app.UseHsts();
        }
        app.UseTrailingSlashAndLowerCaseUrlMiddleware();
        app.UseHttpsRedirection();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseAuthorization();
        app.MapControllerRoute(
            name: "CallingCodes",
            pattern: "CallingCodes/{action}/{id?}",
            defaults: new { controller = "CallingCodes", action = "Index" });

        return app;
    }
}
