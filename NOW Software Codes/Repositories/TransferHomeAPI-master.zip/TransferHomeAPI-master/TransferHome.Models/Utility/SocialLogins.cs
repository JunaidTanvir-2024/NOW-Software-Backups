﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace TrasnferHome.Models.Utility
{
    public class SocialLogins
    {
        public async Task<GoogleUserViewModel> GetUserFromGoogle(string access_token)
        {
            try
            {
                HttpClient client = new HttpClient();
                string urlProfile = "";

                urlProfile = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=" + access_token;

                client.CancelPendingRequests();
                HttpResponseMessage output = await client.GetAsync(urlProfile);

                if (output.IsSuccessStatusCode)
                {
                    string outputData = await output.Content.ReadAsStringAsync();
                    GoogleUserViewModel socialUser = JsonConvert.DeserializeObject<GoogleUserViewModel>(outputData);

                    return socialUser;
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<FacebookUserViewModel> GetUserFromFacebook(string access_token)
        {
            try
            {
                HttpClient client = new HttpClient();
                string urlProfile = "";

                urlProfile = "https://graph.facebook.com/me?fields=id,name,email,picture&access_token=" + access_token;

                client.CancelPendingRequests();
                HttpResponseMessage output = await client.GetAsync(urlProfile);

                if (output.IsSuccessStatusCode)
                {
                    string outputData = await output.Content.ReadAsStringAsync();
                    FacebookUserViewModel socialUser = JsonConvert.DeserializeObject<FacebookUserViewModel>(outputData);

                    return socialUser;
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

    public class GoogleUserViewModel
    {
        public string id { get; set; }
        public string name { get; set; }
        public string given_name { get; set; }
        public string email { get; set; }
        public string picture { get; set; }
    }

    public class FacebookUserViewModel
    {
        public string id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public FacebookPictureViewModel picture { get; set; }
    }

    [JsonObject("picture")]
    public class FacebookPictureViewModel
    {
        [JsonProperty("data")]
        public FacebookPictureDataViewModel Data { get; set; }
    }

    [JsonObject("data")]
    public class FacebookPictureDataViewModel
    {
        public string url { get; set; }
    }

    public class SocialUserViewModel
    {
        public string Id { get; set; }
        public string name { get; set; }
        public string Email { get; set; }
        public string Picture { get; set; }
        public LoginType Type { get; set; }
    }
}
