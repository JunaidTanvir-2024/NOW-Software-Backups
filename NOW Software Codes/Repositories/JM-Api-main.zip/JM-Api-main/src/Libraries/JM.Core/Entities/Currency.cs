using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class Currency : IBaseEntity<long>
{
    public long Id { get; set; }
    public string Name { get; set; } = null!;
    public string Code { get; set; } = null!;
    public string Symbol { get; set; } = null!;
    public ICollection<Trip> Trips { get; set; } = [];
}
