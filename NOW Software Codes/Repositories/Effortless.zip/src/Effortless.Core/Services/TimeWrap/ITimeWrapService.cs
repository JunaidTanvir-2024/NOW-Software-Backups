﻿namespace Effortless.Core.Services.TimeWrap;

public interface ITimeWrapService
{
    DateTime UtcNow { get; }
}