﻿namespace THCC.Application.Models.Dtos
{
    public class RecurringPaymentDto
    {
        public decimal Amount { get; set; }
        public string TransactionId { get; set; } = default!;
    }
}
