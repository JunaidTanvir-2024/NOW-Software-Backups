﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts.Pay360.Response.User
{
    public class UserCustomerResponseModels
    {
        [JsonProperty("displayName")]
        public string DisplayName { get; set; }

        [JsonProperty("merchantRef")]
        public string MerchantRef { get; set; }

        [JsonProperty("pay360CustId")]
        public long Pay360CustId { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("defaultCurrency")]
        public string DefaultCurrency { get; set; }

        [JsonProperty("dob")]
        public DateTime? Dob { get; set; }

        [JsonProperty("addressLine1")]
        public string AddressLine1 { get; set; }

        [JsonProperty("addressLine2")]
        public string AddressLine2 { get; set; }

        [JsonProperty("addressLine3")]
        public string AddressLine3 { get; set; }

        [JsonProperty("addressLine4")]
        public string AddressLine4 { get; set; }

        [JsonProperty("city")]
        public string City { get; set; }

        [JsonProperty("region")]
        public string Region { get; set; }

        [JsonProperty("postCode")]
        public string PostCode { get; set; }

        [JsonProperty("country")]
        public string Country { get; set; }

        [JsonProperty("countryCode")]
        public string CountryCode { get; set; }

        [JsonProperty("telephone")]
        public string Telephone { get; set; }
    }
}
