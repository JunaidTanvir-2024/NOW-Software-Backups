using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using BundlerMinifier.TagHelpers;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using THCCWEB.Configurations;
using THCCWEB.Middlewares;
using THCCWEB.Services;
using THCCWEB.Services.Interface;
using WebMarkupMin.AspNetCore3;

namespace THCCWEB
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.Configure<CookiePolicyOptions>();
            //services.AddControllersWithViews();
            services.Configure<BasicAuthConfig>(Configuration.GetSection("BasicAuthSettings"));


            services.Configure<EndPointsConfig>(Configuration.GetSection("EndPoints"));
            services.AddTransient<IAccountService, AccountService>();
            services.AddSingleton((Serilog.ILogger)new LoggerConfiguration()
             .MinimumLevel.Debug()
             .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "THCCWEB-log-{Date}.txt"))
             .CreateLogger());
            services.AddControllersWithViews(options =>
            {
                options.Filters.Add(new ResponseCacheAttribute() { NoStore = true, Location = ResponseCacheLocation.None });
            });

            services.Configure<RouteOptions>(options =>
            {
                options.AppendTrailingSlash = false;
                options.LowercaseUrls = true;
                options.LowercaseQueryStrings = true;
            });

            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options =>
                {
                    options.Cookie.HttpOnly = true;
                    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
                    options.Cookie.SameSite = SameSiteMode.Lax;
                    options.LoginPath = "/login";
                    options.ExpireTimeSpan = TimeSpan.FromDays(1);
                });

            services.Configure<CookieTempDataProviderOptions>(options =>
            {
                options.Cookie.IsEssential = true;
            });

            services.AddBundles(options =>
            {
                options.AppendVersion = true;
            });

            services.AddWebMarkupMin(
                options =>
                {
                    options.AllowMinificationInDevelopmentEnvironment = true;
                    options.AllowCompressionInDevelopmentEnvironment = true;
                })
                .AddHtmlMinification(
                    options =>
                    {
                        options.MinificationSettings.RemoveRedundantAttributes = true;
                        options.MinificationSettings.RemoveHttpProtocolFromAttributes = true;
                        options.MinificationSettings.RemoveHttpsProtocolFromAttributes = true;
                    })
                .AddHttpCompression();

            services.AddResponseCompression(options =>
            {
                options.EnableForHttps = true;
                options.Providers.Add<BrotliCompressionProvider>();
                options.Providers.Add<GzipCompressionProvider>();
                options.MimeTypes =
                    ResponseCompressionDefaults.MimeTypes.Concat(
                        new[] {
                                "text/plain",
                                "text/html",
                                "text/css",
                                "text/json",
                                "font/woff2",
                                "application/javascript",
                                "application/json",
                                "image/x-icon",
                                "image/png",
                                "image/jpeg",
                                "image/jpg",
                        });
            });

            services.Configure<BrotliCompressionProviderOptions>(options =>
            {
                options.Level = CompressionLevel.Optimal;
            });

            services.Configure<GzipCompressionProviderOptions>(options =>
            {
                options.Level = CompressionLevel.Optimal;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/error/system/500");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseResponseCompression();
            
            app.UseStaticFiles();

            app.UseWebMarkupMin();

            app.UseCookiePolicy(new CookiePolicyOptions
            {
                // This lambda determines whether user consent for non-essential 
                // cookies is needed for a given request.
                CheckConsentNeeded = context => true,
                // requires using Microsoft.AspNetCore.Http;
                MinimumSameSitePolicy = SameSiteMode.None,

                Secure = env.IsDevelopment() ? CookieSecurePolicy.None : CookieSecurePolicy.Always
            });

            app.UseNotFoundMiddleware();

            app.UseTrailingSlashAndLowerCaseUrlMiddleware();

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {

                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
