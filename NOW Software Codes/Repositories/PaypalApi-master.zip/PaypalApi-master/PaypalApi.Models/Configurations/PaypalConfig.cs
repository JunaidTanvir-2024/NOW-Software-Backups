﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Configurations
{
    public class PaypalConfig
    {
        public string ApiEndPoint { get; set; }
        public string CliendId { get; set; }
        public string Secret { get; set; }       

    }
}
