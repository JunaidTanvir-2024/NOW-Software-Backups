using System.ComponentModel;

using FluentValidation;

namespace Voucherify.Api.Features.Vouchers.Requests;

public class GetVouchersRequest
{
    [DefaultValue(1)]
    public int PageNumber { get; set; }
    [DefaultValue(10)]
    public int PageSize { get; set; }
    public string? CustomerSourceId { get; set; }
}
internal class GetVouchersRequestValidator : AbstractValidator<GetVouchersRequest>
{
    public GetVouchersRequestValidator()
    {
        RuleFor(p => p.PageNumber).GreaterThan(0);
        RuleFor(p => p.PageSize).GreaterThan(0);
    }
}