﻿using Application.Common.Interfaces.Payment;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Card.NewCardPayment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Payment.Card.AddCard;
public class AddCardRequestHandler : IRequestHandler<AddCardRequest, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;

    public AddCardRequestHandler(IPaymentService paymentService)
    {
        _paymentService = paymentService;
    }

    public async Task<Result<CardResponse>> Handle(AddCardRequest request, CancellationToken cancellationToken)
    {
        request.PaymentCardInfo.CardNumber = request.PaymentCardInfo.CardNumber!.Trim().Replace(" ", "");

        return await _paymentService.HandleCardPaymentRequest(
                request.PaymentCardInfo,
                null!,
                request.PaymentAddressInfo,
                null!,
                null!,
                null!,
                request.Msisdn!,
                request.Email!,
                request.IpAddress!,
                null!,
                null!,
                false,
                null!,
                0);
    }
}
