using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Products;

public class SkuCreate
{
    [JsonPropertyName("source_id")]
    public string? SourceId { get; set; }

    [JsonPropertyName("sku")]
    public string? SkuValue { get; set; }

    [JsonPropertyName("price")]
    public long? Price { get; set; }

    [JsonPropertyName("attributes")]
    public Metadata? Attributes { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}
