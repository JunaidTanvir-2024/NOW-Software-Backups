using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;
public interface ILoggerRepository : ResolveAs.IScoped
{
    Task AppLogUpsert(AppLog appLog);
    Task VendorLogInsert(VendorLog vendorLog);
}
