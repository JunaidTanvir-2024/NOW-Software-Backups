using System.Security.Claims;

namespace JM.Core.Utilities.Extensions;
public static class ClaimsPrincipalExtensions
{
    public static string? GetEmail(this ClaimsPrincipal principal)
    {
        return principal.FindFirstValue(ClaimTypes.Email);
    }
    public static string? GetFullName(this ClaimsPrincipal principal)
    {
        return principal.FindFirstValue(ClaimTypes.Name);
    }
    public static long GetId(this ClaimsPrincipal principal)
    {
        return Convert.ToInt64(principal.FindFirstValue(ClaimTypes.Sid));
    }
}
