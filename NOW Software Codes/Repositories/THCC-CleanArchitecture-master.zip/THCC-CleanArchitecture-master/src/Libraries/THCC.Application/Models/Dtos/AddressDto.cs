﻿namespace THCC.Application.Models.Dtos;

public class AddressDto
{
    public string? Latitude { get; set; }
    public string? Longitude { get; set; }
    public IList<string> Addresses { get; set; } = new List<string>();
    public string? Message { get; set; }
}