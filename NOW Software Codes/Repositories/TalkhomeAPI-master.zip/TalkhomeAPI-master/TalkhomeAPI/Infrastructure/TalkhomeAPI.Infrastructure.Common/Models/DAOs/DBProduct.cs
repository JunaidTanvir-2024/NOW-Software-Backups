﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBProduct
    {
        public string GUID { get; set; }
        public string fromCurrency { get; set; }
        public string toCurrency { get; set; }
        public string fromMsisdn { get; set; }
        public string tomsisdn { get; set; }
        public string toAmount { get; set; }
        public string fromAmount { get; set; }
        public string account { get; set; }
        public string CustomerChargeValue { get; set; }
        public string product { get; set; }
        public string operatorCountryName { get; set; }
        public string operatorLogoUrl { get; set; }
        public string operatorName { get; set; }
    }
}
