﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATTDaemon
{
    public class ATTService
    {

        public void OnStart()
        {
        }

        public void OnStop()
        {
        }

    }
}
