﻿using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.Contacts.Requests;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Contacts
{
    internal class InsertContactPersonHandler : IRequestHandler<InsertContactPersonRequest, IResultWrapper>
    {
        private readonly IContactPersonRepository _contactPersonRepository;
        private readonly ICommonService _commonService;

        public InsertContactPersonHandler(IContactPersonRepository contactPersonRepository, ICommonService commonService)
        {
            this._contactPersonRepository = contactPersonRepository;
            this._commonService = commonService;
        }

        public async Task<IResultWrapper> Handle(InsertContactPersonRequest request, CancellationToken cancellationToken)
        {


            var loggedUserId = _commonService.GetUserID();
            var contactPersonDto = new ContactPersonDto()
            {

                UserId = loggedUserId,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                MobileNo = request.MobileNo,
                CreatedAt = DateTime.UtcNow,
                CreatedBy = loggedUserId,
                UpdatedAt = DateTime.UtcNow,
                UpdatedBy = loggedUserId,
            };

            var res = await _contactPersonRepository.AddContactPerson(contactPersonDto);
            return ResultWrapper.Success(res);
        }
    }
}