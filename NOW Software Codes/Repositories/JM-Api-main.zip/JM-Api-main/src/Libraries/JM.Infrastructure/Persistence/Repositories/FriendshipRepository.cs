using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.EntityFrameworkCore;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;

public class FriendshipRepository(AppDbContext context, ILogger logger) : IFriendshipRepository
{
	private readonly AppDbContext _context = context;
	private readonly ILogger _logger = logger;

	public async Task<Friendship> AddFriendship(Friendship friFriendship)
	{
		try
		{
			var addedFriendship = await _context.Set<Friendship>().AddAsync(friFriendship);

			await _context.Entry(addedFriendship.Entity)
				.Reference(f => f.Initiator)
				.LoadAsync();

			await _context.Entry(addedFriendship.Entity)
				.Reference(f => f.Responder)
				.LoadAsync();

			return addedFriendship.Entity;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(FriendshipRepository), nameof(AddFriendship));
			return default!;
		}
	}
	public void UpdateFriendship(Friendship friFriendship)
	{
		try
		{
			_context.Entry(friFriendship).CurrentValues.SetValues(friFriendship);
			_context.Entry(friFriendship).State = EntityState.Modified;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(FriendshipRepository), nameof(UpdateFriendship));
		}
	}
	public async Task<Friendship?> GetFriendship(Expression<Func<Friendship, bool>> expression)
	{
		try
		{
			return await _context.Set<Friendship>()
				.Where(expression)
				.Include(x => x.Initiator).ThenInclude(x => x.UserDetail)
				.Include(x => x.Responder).ThenInclude(x => x.UserDetail)
				.FirstOrDefaultAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(FriendshipRepository), nameof(GetFriendship));
			return default!;
		}
	}
	public async Task<IEnumerable<Friendship>> GetFriendshipList(Expression<Func<Friendship, bool>> expression = default!)
	{
		try
		{
			var query = _context.Set<Friendship>()
			   .Include(x => x.Initiator).ThenInclude(x => x.UserDetail)
				.Include(x => x.Responder).ThenInclude(x => x.UserDetail);
			return expression is null ? await query.ToListAsync() : await query.Where(expression).ToListAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(FriendshipRepository), nameof(GetFriendshipList));
			return default!;
		}
	}
}
