﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class AddCustomerRatingRequest
    {
        [Required]
        public int CustomerRating { get; set; }
        [Required]
        public int TotalRating { get; set; }
        [Required]
        public string RatingEvent { get; set; }
    }
}
