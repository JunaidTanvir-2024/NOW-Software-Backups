﻿using Models.Contracts.Request;
using Models.Contracts.Request.CountryDestination;
using Models.Contracts.Response;
using Models.Database;
using Models.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
	public interface IBundle_BL
    {
        Task<bool> IsOfferBUndle(string callingPackageId);
        Task<GenericApiResponse<string>> SetBundleAutoRenewal(bool isAutoRenew, string Msisdn, string bundleId, string Email);
        Task<GenericApiResponse<string>> SetBundleAutoRenewalV2(bool isAutoRenew, string Msisdn, string bundleId, string Email);
        Task<GenericApiResponse<IEnumerable<DataBundleDetail>>> GetDataBundlesProducts(string sourceMSISDN, string destinationMSISDN);
        Task<IEnumerable<AccountBundleDetails>> GetAccountBundlesViaSQL(string msisdn, string currency, string accountId);
        Task<IEnumerable<AccountBundleDetailsV2>> GetAccountBundlesViaSQLV2(string msisdn, string currency, string accountId);
        Task<AccountSubscriptionDetails> GetAccountSubscriptionsViaSQL(string msisdn, string email);
        Task<AccountSubscriptionDetailsV2> GetAccountSubscriptionsViaSQLV2(string msisdn, string email);
        Task<GenericApiResponse<bool>> ValidateBundle(string accountId, string bundleId);
        Task<GenericApiResponse<CountryDestinationBundle>> Get(string msisdn, string id);
        Task<GenericApiResponse<CountryBundleDetails>> GetBundleDetails(string ISOCode, string msisdn, string currency);
        Task<GenericApiResponse<CountryBundleDetailsV2>> GetBundleDetailsV2(string ISOCode, string msisdn, string currency,string welcomeBundleDescription, string paygBundleDescription, string globalCreditDescription);
        Task<GenericApiResponse<Rates>> GetRateDetails(string id, string msisdn);
        Task<GenericApiResponse<IEnumerable<CountryDestination>>> GetAllRates(string msisdn);
        Task<GenericApiResponse<RatesView>> GetRatesAndTopRates(string msisdn);
        Task<GenericApiResponse<RatesView>> GetCountryWithBundles(string msisdn);
        Task<GenericApiResponse<BundlesWithTopDestinations>> GetCountryWithBundlesAndTopBundlesV2(string msisdn,List<string> countryCodes, string welcomeBundleDescription, string paygBundleDescription);
        Task<GenericApiResponse<RatesView>> GetCountryWithBundlesAndTopBundles(string msisdn,List<string> countryCodes);
        Task<GenericApiResponse<TopBundlesView>> GetuserTopBundles(string msisdn);
        Task<GenericApiResponse<TopBundlesView>> GetUserSuggestedBundles(string msisdn, SuggestedBundleRequest request);
        Task<GenericApiResponse<UserAccountBalance>> PurchaseBundle(string AppsFlyerId, DeviceType DeviceType, string advertiserID, string msisdn, string bundleId, bool isBundleAutoRenew, string email);
        Task<GenericApiResponse<UserAccountBalance>> PurchaseBundleV2(string AppsFlyerId, DeviceType DeviceType, string advertiserID, string msisdn, string bundleId, bool isBundleAutoRenew, string email);
        Task<GenericApiResponse<DestinationRate>> GetDestinationRate(string sourceMsisdn, string destinationMsisdn);
    }
}

