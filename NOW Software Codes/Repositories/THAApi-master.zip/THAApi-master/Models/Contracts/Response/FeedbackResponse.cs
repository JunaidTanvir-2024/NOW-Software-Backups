﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    
    public class FeedbackResponse
    {
        public string Message { get; set; }

        public bool Active { get; set; }

        public int MinimumDuration { get; set; }

        public int AutoDismiss { get; set; }

        public FeedbackButton[] Buttons { get; set; }
    }

    public class FeedbackButton
    {
        public string Title { get; set; }

        public string Quality { get; set; }
    }
}
