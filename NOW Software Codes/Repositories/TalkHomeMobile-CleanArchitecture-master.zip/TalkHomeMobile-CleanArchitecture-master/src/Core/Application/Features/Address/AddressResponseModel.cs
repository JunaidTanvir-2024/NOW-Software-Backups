﻿namespace Application.Features.Address;

public class AddressResponseModel
{
    public string? Latitude { get; set; }
    public string? Longitude { get; set; }
    public IList<string> Addresses { get; set; } = new List<string>();
    public string? Message { get; set; }
}