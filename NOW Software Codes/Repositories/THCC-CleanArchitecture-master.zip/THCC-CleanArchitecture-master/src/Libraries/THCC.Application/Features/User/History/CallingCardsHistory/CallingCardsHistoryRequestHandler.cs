﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.History.CallingCardsHistory
{
    public class CallingCardsHistoryRequestHandler : IRequestHandler<CallingCardsHistoryRequest, object>
    {
        #region Fields

        private readonly IUserRepository _userRepository;
        private readonly ICurrentUser _currentUser;

        #endregion

        #region Ctors
        public CallingCardsHistoryRequestHandler(
            IUserRepository userRepository,
            ICurrentUser currentUser)
        {
            _userRepository = userRepository;
            _currentUser = currentUser;
        }

        #endregion

        #region Methods

        public async Task<object> Handle(CallingCardsHistoryRequest request, CancellationToken cancellationToken)
        {
            var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
            if (userProduct == null)
            {
                return ErrorResult.Failure(CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
            }

            var callingCards = new List<CallingCardsHistoryResponse>();

            var accountDetail = await _userRepository.GetAccountDetails(userProduct!.Product!);
            callingCards.Add(new CallingCardsHistoryResponse() { Card = accountDetail.CardNumber!.Trim(), Pin = accountDetail.PinNumber!.Trim() });

            var response = await _userRepository.CallingCardsHistory(_currentUser.GetUserId());
            response?.ForEach(item => callingCards.Add(new CallingCardsHistoryResponse() { Card = "", Pin = item.Pin!.Trim() }));
            return callingCards!;
        }

        #endregion
    }
}
