﻿using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface IChannel_DL
    {
        Task<GenericResult<bool>> AddChannel(Channel channel, string productCode);
        Task<GenericResult<bool>> AddChannelTags(AddChannelTagsRequest request);
    }
}
