﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Utility
{
    public enum ATTStatusCodes
    {
        DenominationsNotAvailable = 301,
        DenominationBlocked = 310,
        OperatorBlocked = 311,
        TopupNumberLimitExceed = 230,
        TopupAmountLimitExceed = 231
    }
}
