﻿using System;

namespace Models.Contracts.Request
{
    public class UserAccountSmsHistory
    {
        public string Destination { get; set; }

        public string Charge { get; set; }

        public DateTime DateTime { get; set; }
    }
}
