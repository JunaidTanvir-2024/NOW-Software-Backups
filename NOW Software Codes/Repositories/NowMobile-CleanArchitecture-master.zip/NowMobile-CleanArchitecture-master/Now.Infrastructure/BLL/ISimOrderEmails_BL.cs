﻿using Now.Models.Enums;

namespace Now.Infrastructure.BLL;

public interface ISimOrderEmails_BL
{
    Task SendWhyAndBenefitsEmail(SimOrderType simOrderType);
    Task SendNotActivatedSimEmail(SimOrderType simOrderType);
    Task SendOtherServicesEmail(SimOrderType simOrderType);
    Task SendSocialMediaEmails(SimOrderType simOrderType);
    Task SendNotToppedUpEmail(SimOrderType freeSim);
}
