﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Response.Pay360
{
    public class Pay360SetAutoTopUpRequest
    {
        public string productRef { get; set; }
        public string productCode { get; set; }
        public string productItemCode { get; set; }
        public float thresholdBalanceAmount { get; set; }
        public bool isAutoTopup { get; set; }
        public decimal topupAmount { get; set; }
        public string TopupCurrency { get; set; }
        public string Email { get; set; }
    }
}
