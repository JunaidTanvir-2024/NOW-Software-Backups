﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ViewModels.Pay360.Request
{
    public class Pay360GetAutoTopUpRequest
    {
        public string Msisdn { get; set; }
        public string Email { get; set; }
        public string productCode = "THCC";
    }
}
