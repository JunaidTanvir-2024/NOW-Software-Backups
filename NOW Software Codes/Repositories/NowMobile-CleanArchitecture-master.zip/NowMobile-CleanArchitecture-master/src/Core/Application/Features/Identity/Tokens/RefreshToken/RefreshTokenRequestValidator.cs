﻿namespace Application.Features.Identity.Tokens.RefreshToken;

public class RefreshTokenRequestValidator : AbstractValidator<RefreshTokenRequest>
{
    public RefreshTokenRequestValidator()
    {
        RuleFor(p => p.RefreshToken).NotEmpty().NotNull();
        RuleFor(p => p.Token).NotEmpty().NotEmpty().NotNull();
    }
}
