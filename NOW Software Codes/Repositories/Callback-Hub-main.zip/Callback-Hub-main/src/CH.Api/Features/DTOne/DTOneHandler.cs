using CH.Api.Common.Definitions;
using CH.Api.Common.DTOs;
using CH.Api.Common.Helpers;
using CH.Api.Common.Http;
using CH.Api.Common.Settings;

using Microsoft.Extensions.Options;

namespace CH.Api.Features.DTOne;

public interface IDTOneHandler
{
    Task DTOneTransactionCallback(object data);
}

internal sealed class DTOneHandler(IOptions<FusionHubSetting> fusionHubSetting,
    IHttpContextAccessor httpContextAccessor,
    ISecurityHelpers securityHelpers,
    IHttpService httpService,
    Serilog.ILogger logger) : IDTOneHandler
{
    private readonly FusionHubSetting _fusionHubSetting = fusionHubSetting.Value;
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;
    private readonly ISecurityHelpers _securityHelpers = securityHelpers;
    private readonly Serilog.ILogger _logger = logger;
    private const string CORRELATION_ID = "Correlation_Id";
    private readonly IHttpService _httpService = httpService
            .BaseUrl(fusionHubSetting.Value.BaseUrl)
        .SetVendor(AppEnums.Vendor.FusionHub)
        .WithHeaders(new Dictionary<string, string>()
        {
            [nameof(AppEnums.ClientInformation.ProductCode)] = "CB",
            [nameof(AppEnums.ClientInformation.ProductItemCode)] = "CB_HUB",
            [nameof(AppEnums.ClientInformation.UniqueReference)] = $"CB_{httpContextAccessor.HttpContext?.Items[CORRELATION_ID]?.ToString()}"}
        );

    public async Task DTOneTransactionCallback(object data)
    {
        var requestObject = new CallbackDto(_securityHelpers.HashData(data), data);
        try
        {
            await _httpService.PostAsync(_fusionHubSetting.CallbackEndpoints.DtOneTransaction!, requestObject);
        }
        catch (Exception ex)
        {
            LogError(ex, nameof(DTOneHandler), nameof(DTOneTransactionCallback));
        }
    }

    /// <summary>
    /// To avoid changes in logging behavior, added this method
    /// </summary>
    /// <param name="ex"></param>
    /// <param name="methodName"></param>
    private void LogError(Exception ex, string className, string methodName)
    {
        _logger.Error($"[Class: {className}] - [Method: {methodName}] - [TimeStamp: {DateTime.UtcNow}] - [Error: {ex.StackTrace}]");
    }
}
