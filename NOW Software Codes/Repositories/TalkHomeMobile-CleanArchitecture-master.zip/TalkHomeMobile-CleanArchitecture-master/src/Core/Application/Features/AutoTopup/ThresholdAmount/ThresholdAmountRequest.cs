﻿namespace Application.Features.AutoTopup.ThresholdAmount;

public class ThresholdAmountRequest : IRequest<Result<List<float>>> { }
