﻿namespace Application.Features.Account.DeleteAccount;
public class DeleteAccountRequest : IRequest<Result<object>>
{
    public string Email { get; set; } = default!;
    public string Password { get; set; } = default!;
}
