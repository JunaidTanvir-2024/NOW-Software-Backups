﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models
{
    public class PayPalPaymentReturnV1RequestModel
    {
        [Required]
        public string PaymentId { get; set; }
        [Required]
        public string PayerID { get; set; }

        //Transfer Related Data
        [Required]
        [MaxLength(200)]
        public string nowtelRef { get; set; }
        [Required]
        [Range(1, int.MaxValue)]
        public int product { get; set; }
        [Required]
        [Range(1, int.MaxValue)]
        public int operatorId { get; set; }
    }
}
