﻿
namespace Now.Models.Database;

public class DbFullfilmentResult
{
    public decimal New_balance { get; set; }
    public int Audit_id { get; set; }
}
