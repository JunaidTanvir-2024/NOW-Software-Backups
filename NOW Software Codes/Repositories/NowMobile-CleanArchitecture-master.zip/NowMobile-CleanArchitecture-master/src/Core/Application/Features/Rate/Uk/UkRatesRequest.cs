using Application.Features.Rate.Model;

namespace Application.Features.Rate.Uk;

public class UkRatesRequest : IRequest<Result<List<UkRate>>> { }
