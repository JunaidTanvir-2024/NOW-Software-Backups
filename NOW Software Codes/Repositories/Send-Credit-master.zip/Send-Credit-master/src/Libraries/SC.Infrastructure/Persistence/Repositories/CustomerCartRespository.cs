﻿using Dapper;

using Microsoft.VisualBasic;

using SC.Core.Common.DTOs.Configurations;
using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Common.Model;
using SC.Core.Models.Dtos;
using SC.Infrastructure.Services;

using Sentry;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Infrastructure.Persistence.Repositories;

internal sealed class CustomerCartRespository : ICustomerCartRespository
{
    private readonly IConfiguration _configuration;
    private readonly ILogger _logger;

    public CustomerCartRespository(IConfiguration configuration, ILogger logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<long> OrderCreationAsync(OrderCreationDto order)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_customer_order_id", order.CustomerOrderID);
                parameters.Add("@p_customer_id", order.UserID);
                parameters.Add("@p_promo_code", order.PromoCode);
                parameters.Add("@p_discount_type", order.DiscountTypeId);
                parameters.Add("@p_discount_inclusive_amount", order.DiscountInclusiveAmount);
                parameters.Add("@p_discount_amount", order.DiscountAmount);
                parameters.Add("@p_service_fee", order.ServiceFee);
                parameters.Add("@p_tax_amount", order.TaxAmount);
                parameters.Add("@p_tax_inclusive_amount", order.TaxInclusiveAmount);
                parameters.Add("@p_tax_exclusive_amount", order.TaxExclusiveAmount);
                parameters.Add("@p_total_order_amount", order.TotalOrderAmount);
                parameters.Add("@p_currency", order.Currency);
                parameters.Add("@p_order_status", order.OrderStatus);
                parameters.Add("@p_customer_address_id", order.CustomerAddressId); // this will be set later
                parameters.Add("@p_is_active", order.isActive);
                parameters.Add("@p_is_deleted", order.isDeleted);
                parameters.Add("@p_created_at", DateTime.UtcNow);
                parameters.Add("@p_updated_at", DateTime.UtcNow);
                parameters.Add("@p_created_by", order.UserID);
                parameters.Add("@p_updated_by", order.UserID);
                parameters.Add("@p_request_id", order.RequestId);
                parameters.Add("@p_payment_method", order.PaymentMethod);
      
                var result = await connection.ExecuteScalarAsync<long>(AppConstants.StoreProcedures.OrderCreation, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error("OrderCreationAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<long> CartCreationAsync(CartCreationDto cart)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_customer_cart_id", cart.CustomerCartID);
                parameters.Add("@p_customer_id", cart.CustomerID);
                parameters.Add("@p_product_id", cart.ProductID);
                parameters.Add("@p_product_name", cart.ProductName);
                parameters.Add("@p_quantity", cart.Quantity);
                parameters.Add("@p_price", cart.Price);
                parameters.Add("@p_currency", cart.Currency);
                parameters.Add("@p_discount_type", cart.DiscountType);
                parameters.Add("@p_discount_amount", cart.DiscountAmount);
                parameters.Add("@p_status", cart.Status);
                parameters.Add("@p_state", cart.Status);
                parameters.Add("@p_customer_order_id", cart.CustomerOrderID);
                parameters.Add("@p_is_active", cart.isActive);
                parameters.Add("@p_is_deleted", cart.isDeleted);
                parameters.Add("@p_created_at", DateTime.UtcNow);
                parameters.Add("@p_updated_at", DateTime.UtcNow);
                parameters.Add("@p_created_by", cart.CustomerID);
                parameters.Add("@p_updated_by", cart.CustomerID);
                parameters.Add("@p_service_fee_amount", cart.ServiceFeeAmount);
                parameters.Add("@p_product_price_type", cart.ProductPriceType);
                parameters.Add("@p_product_price", cart.ProductPrice);

                var result = await connection.ExecuteScalarAsync<long>(AppConstants.StoreProcedures.CartCreation, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error("CartCreationAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<bool?> RemoveCartAsync(long productID, long CustomerCartID, long orderID)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_product_id", productID);
                parameters.Add("@p_order_id", orderID);
                parameters.Add("@p_customer_cart_id", CustomerCartID);
                var result = await connection.ExecuteScalarAsync<int>(AppConstants.StoreProcedures.RemoveProdcutfromCart, parameters, commandType: CommandType.StoredProcedure);
                return result > 0 ? true : false;
            }
            catch (Exception ex)
            {
                _logger.Error("RemoveCartAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<long> CartItemCreationAsync(CartItemCreationDto cart)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_customer_cart_item_id", cart.customerCartItemId);
                parameters.Add("@p_receiver_email", cart.receiverEmail);
                parameters.Add("@p_receiver_mobile", cart.receiverMobile);
                parameters.Add("@p_receiver_pin", cart.receiverPin);
                parameters.Add("@p_custom_message", cart.customMessage);
                parameters.Add("@p_is_renewal", cart.isRenewal);
                parameters.Add("@p_sender_id", cart.senderId);
                parameters.Add("@p_sender_name", cart.senderName);
                parameters.Add("@p_sender_email", cart.senderEmail);
                parameters.Add("@p_sender_mobile", cart.senderMobile);
                parameters.Add("@p_product_id", cart.productId);
                parameters.Add("@p_customer_cart_id", cart.customerCartId);
                parameters.Add("@p_is_active", cart.isActive);
                parameters.Add("@p_is_deleted", cart.isDeleted);
                parameters.Add("@p_created_at", DateTime.UtcNow);
                parameters.Add("@p_updated_at", DateTime.UtcNow);
                parameters.Add("@p_created_by", cart.customerID);
                parameters.Add("@p_updated_by", cart.customerID);

                parameters.Add("@p_product_vendor_code", cart.ProductVendorCode);
                parameters.Add("@p_product_type", cart.ProductType);

                var result = await connection.ExecuteScalarAsync<long>(AppConstants.StoreProcedures.CustomerCartInfoInsert, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error("CartItemCreationAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<List<GetCustomerCartDto>> GetCustomerCart(string customerID)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@customer_id", customerID);
                parameters.Add("@order_status", OrderStatusEnum.Init.Getkey());

                return (await connection.QueryAsync<GetCustomerCartDto>(AppConstants.StoreProcedures.GetCustomerCart, parameters, commandType: CommandType.StoredProcedure)).ToList();
            }
            catch (Exception ex)
            {
                _logger.Error("GetCustomerCart, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<GetCustomerOrderDto> GetCustomerOrder(string customerID, string orderStatus)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@customer_id", customerID);
                parameters.Add("@order_status", orderStatus);

                return await connection.QueryFirstOrDefaultAsync<GetCustomerOrderDto>(AppConstants.StoreProcedures.GetCustomerOrder, parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.Error("GetCustomerOrder, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }
    public async Task<List<GetCustomerOrderDto>> GetCustomerOrders(string customerID, string orderStatus , long orderID = 0)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@customer_id", customerID);
                parameters.Add("@order_status", orderStatus);

                return (await connection.QueryAsync<GetCustomerOrderDto>(AppConstants.StoreProcedures.GetCustomerOrders, parameters, commandType: CommandType.StoredProcedure)).ToList();
            }
            catch (Exception ex)
            {
                _logger.Error("GetCustomerOrders, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default!;
            }
        }
    }

    public async Task<long> AddCustomerAddressAsync(AddCustomerAddressDto Address)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_customer_id", Address.CustomerId);
                parameters.Add("@p_address_type", Address.AddressType);
                parameters.Add("@p_street_address1", Address.StreetAddress1);
                parameters.Add("@p_street_address2", Address.StreetAddress2);
                parameters.Add("@p_city", Address.City);
                parameters.Add("@p_state", Address.State);
                parameters.Add("@p_postalcode", Address.PostalCode);
                parameters.Add("@p_country", Address.Country);
                parameters.Add("@p_email", Address.Email);
                parameters.Add("@p_phone", Address.Phone);
                parameters.Add("@p_is_active", true);
                parameters.Add("@p_is_deleted", false);
                parameters.Add("@p_created_at", DateTime.UtcNow);
                parameters.Add("@p_updated_at", DateTime.UtcNow);
                parameters.Add("@p_created_by", Address.CustomerId);
                parameters.Add("@p_updated_by", Address.CustomerId);
                parameters.Add("@p_region", Address.Region);
                parameters.Add("@p_country_code", Address.CountryCode);

                parameters.Add("@p_customer_order_status", AppEnums.OrderStatusEnum.Init.Getkey());
                var result = await connection.ExecuteScalarAsync<long>(AppConstants.StoreProcedures.CustomerAddressInsert, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error("AddCustomerAddressAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<List<GetPaymentMethodDto>> GetPaymentMethods()
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                return (await connection.QueryAsync<GetPaymentMethodDto>(AppConstants.StoreProcedures.GetPaymentMethods, null, commandType: CommandType.StoredProcedure)).ToList();
            }
            catch (Exception ex)
            {
                _logger.Error("GetPaymentMethods, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<CustomerOrderDetailDto> GetCustomerOrderDetail(string customerID, string orderStatus, long orderID = 0)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@customer_id", customerID);
                parameters.Add("@order_status", orderStatus);
                parameters.Add("@order_id", orderID);

                var gridreader = await connection.QueryMultipleAsync(AppConstants.StoreProcedures.GetCustomerOrderDetail, parameters, commandType: CommandType.StoredProcedure);

                var Order = await gridreader.ReadFirstOrDefaultAsync<CustomerOrderDetailDto>();
                if (Order != null)
                    Order.CartDetail = (List<GetCustomerCartDto>)await gridreader.ReadAsync<GetCustomerCartDto>();

                return Order;
            }
            catch (Exception ex)
            {
                _logger.Error("GetCustomerOrderDetail, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<long> OrderPaymentCreationAsync(OrderPaymentDto order)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_order_payment_id", order.OrderPaymentId);
                parameters.Add("@p_customer_id", order.CustomerId);
                parameters.Add("@p_customer_order_id", order.CustomerOrderId);
                parameters.Add("@p_transaction_id", order.TransactionId);
                parameters.Add("@p_order_amount", order.OrderAmount);
                parameters.Add("@p_is_payment_success", order.IsPaymentSuccess);
                parameters.Add("@p_created_at", DateTime.UtcNow);
                parameters.Add("@p_updated_at", DateTime.UtcNow);
                parameters.Add("@p_created_by", order.CreatedBy);
                parameters.Add("@p_updated_by", order.UpdatedBy);
                parameters.Add("@p_request_id", order.RequestId);
                parameters.Add("@p_action", order.Action);
                parameters.Add("@@p_require3d_secure", order.Require3dSecure);
                var result = await connection.ExecuteScalarAsync<long>(AppConstants.StoreProcedures.OrderPaymentInsert, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error("OrderPaymentCreationAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<bool> MigrateGuestData(string? userID, string singInUserID)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                if (string.IsNullOrEmpty(userID))
                    return false;
                var parameters = new DynamicParameters();
                parameters.Add("@user_id", userID);
                parameters.Add("@signIn_user_id", singInUserID);
                var result = await connection.ExecuteScalarAsync<int>(AppConstants.StoreProcedures.MigrateGuestData, parameters, commandType: CommandType.StoredProcedure);
                return result > 0 ? true : false;
            }
            catch (Exception ex)
            {
                _logger.Error("MigrateGuestData, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<string?> CreateGuestUserAsync()
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_created_at", DateTime.UtcNow);
                var result = await connection.ExecuteScalarAsync<string>(AppConstants.StoreProcedures.CreateUserAsGuest, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error("CreateGuestUserAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<bool> CheckValidUserAsync(string userID)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@user_id", userID);
                var result = await connection.ExecuteScalarAsync<int>(AppConstants.StoreProcedures.CheckValidUserID, parameters, commandType: CommandType.StoredProcedure);
                return result > 0 ? true : false;
            }
            catch (Exception ex)
            {
                _logger.Error("CheckValidUserAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<long> GetOrderIDbyTransactionIDAsync(string customerID, string orderStatus, string transactionID)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@customer_id", customerID);
                parameters.Add("@order_status", orderStatus);
                parameters.Add("@transactionID", transactionID);
                var result = await connection.ExecuteScalarAsync<long>(AppConstants.StoreProcedures.GetOrderIDByTransactionID, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error("GetOrderIDbyTransactionID, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<List<CartStatusUpdateDto>> CartUpdateAsync(IEnumerable<CartStatusUpdateDto> cart)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
            {
                var table = new DataTable();
                table.Columns.Add("id", typeof(long));
                table.Columns.Add("status", typeof(string));

                foreach (var pd in cart)
                {
                    table.Rows.Add(pd.ID, pd.STATUS);
                }

                var parameters = new DynamicParameters();
                parameters.Add("cart_data", table.AsTableValuedParameter(AppConstants.TableTypes.StatusUpdateType));

                var records = await connection.QueryAsync<CartStatusUpdateDto>(AppConstants.StoreProcedures.UpdateCustomerCart, parameters, commandType: CommandType.StoredProcedure);

                return records.ToList();
            }
        }
        catch (Exception ex)
        {
            _logger.Error("CartUpdateAsync, " +
                               "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                               "StackTrace: " + ex.StackTrace);
            return default(List<CartStatusUpdateDto>)!;
        }
    }
    public async Task<List<CartStatusUpdateDto>> UpdateCartFinalStatusAsync(IEnumerable<CartStatusUpdateDto> cart)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
            {
                var table = new DataTable();
                table.Columns.Add("id", typeof(long));
                table.Columns.Add("status", typeof(string));


                foreach (var pd in cart)
                {
                    table.Rows.Add(pd.ID, pd.STATUS);
                }

                var parameters = new DynamicParameters();
                parameters.Add("cart_data", table.AsTableValuedParameter(AppConstants.TableTypes.StatusUpdateType));

                var records = await connection.QueryAsync<CartStatusUpdateDto>(AppConstants.StoreProcedures.CartFinalStatusUpdate, parameters, commandType: CommandType.StoredProcedure);

                return records.ToList();
            }
        }
        catch (Exception ex)
        {
            _logger.Error("UpdateCartFinalStatusAsync, " +
                               "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                               "StackTrace: " + ex.StackTrace);
            return default(List<CartStatusUpdateDto>)!;
        }
    }

    public async Task<List<ServiceFeeConfigurationDto>> GetServiceFeeConfiguration()
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                return (await connection.QueryAsync<ServiceFeeConfigurationDto>(AppConstants.StoreProcedures.GetServiceFeeConfiguration, null, commandType: CommandType.StoredProcedure)).ToList();
            }
            catch (Exception ex)
            {
                _logger.Error("GetServiceFeeConfigurationDto, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<decimal> GetTotalOrderAmountPerDay(string customerID, string orderStatus, DateTime creationDate)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@customer_id", customerID);
                parameters.Add("@order_status", orderStatus);
                parameters.Add("@P_creationDate", creationDate.Date);
                var result = await connection.ExecuteScalarAsync<decimal>(AppConstants.StoreProcedures.GetTotalOrderAmountPerDay, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error("GetTotalOrderAmountPerDay, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }
}