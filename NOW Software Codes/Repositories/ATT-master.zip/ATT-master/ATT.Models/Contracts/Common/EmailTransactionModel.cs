﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Common
{
    public class EmailTransactionModel
    {
        public string accessGUID { get; set; }
        public string ProductCode { get; set; }
        public string ProductItemCode { get; set; }
        public string FromMsisdn { get; set; }
        public string ToMsisdn { get; set; }
        public string DestinationCountry { get; set; }
        public string Status { get; set; }
        public string ErrorMessage { get; set; }
        public string OperatorId { get; set; }
        public string OperatorName { get; set; }
        public string ServiceProviderName { get; set; }
        public TransationType TransationType { get; set; }

    }

    public enum TransationType
    {
        Get=1,
        Execute=2
    }

    public enum ServiceProvider
    {
        TransferTo=2,
        Ding=3,
        Reloadly=4,
        Mobiquity=5
    }
}
