﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request
{
    public class VerifyPinRequestModel
    {
        public string ProductCode { get; set; }

        public string MsisdnOrCardNumber { get; set; }
    }
}
