﻿namespace THCC.Application.Settings
{
    public class GeoLocationSettings
    {
        public const string SectionName = "GeoLocationSettings";
        public static GeoLocationSettings Bind = new();
        public string? ApiKey { get; set; }
        public string? ApiBaseUrl { get; set; }
        public bool IsActive { get; set; }
    }
}
