﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class ExistingCardPaymentRequestModel
    {
        [Required]
        [MaxLength(300)]
        public string cardToken { get; set; }

        [Required(ErrorMessage = "Enter Security Code"), 
            StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string securityCode { get; set; }

        [Required]
        public string ipAddress { get; set; }

        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [EmailAddress(ErrorMessage = "Invalid email")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        public string EmailAddress { get; set; }


        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        public string Msisdn { get; set; }

        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        public string CustomerUniqueRef { get; set; }

        [CollectionValidation(values: new int[] { 0, 5, 10, 15, 20, 25 })]
        public int TopUpAmount { get; set; }
        public string BundleId { get; set; }

        [Required]
        [Range(1, 2)]
        public CheckOutTypes CheckoutType { get; set; }


        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }

        public bool IsAutoTopUp { get; set; }
    }
}
