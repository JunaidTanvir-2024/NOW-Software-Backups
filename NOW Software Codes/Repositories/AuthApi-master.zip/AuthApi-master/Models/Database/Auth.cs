﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    public class Auth
    {             
        public long id { get; set; }
        public string msisdn { get; set; }
        public string device_uuid { get; set; }
        public string email { get; set; }
        public string enc_g { get; set; }
        public string enc_k { get; set; }
        public string enc_tx { get; set; }
        public Algo enc_a { get; set; }
        public string enc_d { get; set; }
        public EType enc_ty { get; set; }
        public bool is_verified { get; set; }
        public DateTime create_date { get; set; }
        public DateTime verify_date { get; set; }
        public string product_code { get; set; }
        public string product_item_code { get; set; }
        public string ip_address { get; set; }
        
    }
}
