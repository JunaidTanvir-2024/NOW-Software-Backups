﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Service.Pay360ApiContracts
{
    public class RefundFullPaymentResponseModel
    {
        public Processing processing { get; set; }
        public object paymentMethod { get; set; }
        public object customer { get; set; }
        public Outcome outcome { get; set; }
        public Transaction transaction { get; set; }
        public object financialServices { get; set; }
        public object history { get; set; }
        public object clientRedirect { get; set; }
        public object fraudGuard { get; set; }
        public object threeDSecure { get; set; }
        public object basketResponse { get; set; }
    }
    public class AuthResponse
    {
        public object statusCode { get; set; }
        public string acquirerName { get; set; }
        public object message { get; set; }
        public string gatewayReference { get; set; }
        public string gatewayMessage { get; set; }
        public object avsAddressCheck { get; set; }
        public object cv2Check { get; set; }
        public string status { get; set; }
        public object authCode { get; set; }
        public string gatewaySettlement { get; set; }
        public object gatewayCode { get; set; }
        public object avsPostcodeCheck { get; set; }
    }

    public class Processing
    {
        public AuthResponse authResponse { get; set; }
        public string route { get; set; }
    }

    public class Outcome
    {
        public string status { get; set; }
        public string reasonCode { get; set; }
        public string reasonMessage { get; set; }
    }

    public class RelatedTransaction
    {
        public string transactionId { get; set; }
        public string merchantRef { get; set; }
    }

    public class Transaction
    {
        public string transactionId { get; set; }
        public string status { get; set; }
        public string type { get; set; }
        public string amount { get; set; }
        public string currency { get; set; }
        public DateTime transactionTime { get; set; }
        public DateTime receivedTime { get; set; }
        public object channel { get; set; }
        public object merchantRef { get; set; }
        public object commerceType { get; set; }
        public RelatedTransaction relatedTransaction { get; set; }
    }
}
