﻿using Application.Common.Interfaces.Payment;
using Application.Common.Settings;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;
using Microsoft.Extensions.Options;

namespace Application.Features.Payment.Paypal.CreateSaleV2;

public class PaypalCreateSalePaymentRequestHandlerV2 : IRequestHandler<PaypalCreateSalePaymentRequestV2, Result<PaypalResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly IMapper _mapper;
    private readonly TopupSettings _topupSettings;

    public PaypalCreateSalePaymentRequestHandlerV2(IPaymentService paymentService,
        IMapper mapper,
        IOptions<TopupSettings> topupSettings)
    {
        _paymentService = paymentService;
        _mapper = mapper;
        _topupSettings = topupSettings.Value;
    }

    public async Task<Result<PaypalResponse>> Handle(
        PaypalCreateSalePaymentRequestV2 request, CancellationToken cancellationToken)
    {
        var isSubscriptionRequest = (request?.TopupInfo?.AutoTopupInfo?.Status==true || request?.BundleInfo?.IsRenewable==true);
        var topupInfo = _mapper.Map<PaymentTopupInfo>(request!.TopupInfo!);
        if(topupInfo?.AutoTopupInfo != null)
        {
            topupInfo.AutoTopupInfo.ThresHoldAmount = _topupSettings.ThresholdAmount;
        }
        return await _paymentService.HandlePaypalPaymentRequest(
            topupInfo!,
            request.BundleInfo!,
            request.CreditSimInfo!,
            request.Msisdn!,
            request.Email!,
            request.IpAddress!,
            isSubscriptionRequest,
            subscriptionWithInitialSale:true,
            request.ConversionID,
            (int) request.ConversionPlatFormID);
    }
}