﻿using System;
using System.Threading.Tasks;
using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;

namespace AirShipApi.Controllers
{

    [Route("[controller]")]
    [ApiController]
    public class StaticListController : ControllerBase
    {

        private readonly ILogger Logger;
        private IStaticList_BL StaticListBl;

        public StaticListController(ILogger logger, IStaticList_BL staticlistBL)
        {
            Logger = logger;
            StaticListBl = staticlistBL;
        }

        [HttpPost]
        [Route("GetSingleList")]
        public async Task<IActionResult> GetSingleList(GetSingleListRequest request)
        {

            try
            {
                var response = await StaticListBl.GetSingleList(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: ChannelController, Method: GetSingleList, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<ApiGetSingleListRespose>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("GetAllLists")]
        public async Task<IActionResult> GetAllLists(GetAllListsRequest request)
        {

            try
            {
                var response = await StaticListBl.GetAllLists(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: ChannelController, Method: GetAllLists, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<ApiGetAllListsResponse>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }
        [HttpPost]
        [Route("AddList")]
        public async Task<IActionResult> AddList(AddListRequest request)
        {

            try
            {
                var response = await StaticListBl.AddList(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: ChannelController, Method: AddList, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }
        [HttpPost]
        [Route("DownloadListContent")]
        public async Task<IActionResult> DownloadListContent(DownloadListContentRequest request)
        {

            try
            {
                var response = await StaticListBl.DownloadListContent(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: DownloadListContent, Method: DownloadListContent, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }
    }
}