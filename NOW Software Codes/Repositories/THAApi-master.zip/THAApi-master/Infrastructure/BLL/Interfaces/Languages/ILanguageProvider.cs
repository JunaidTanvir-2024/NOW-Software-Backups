﻿namespace Infrastructure.BLL.Interfaces.Languages
{
	public interface ILanguageProvider
	{
		IMessageService Message { get; }

		void SetLanguage(string[] accepted);
	}
}
