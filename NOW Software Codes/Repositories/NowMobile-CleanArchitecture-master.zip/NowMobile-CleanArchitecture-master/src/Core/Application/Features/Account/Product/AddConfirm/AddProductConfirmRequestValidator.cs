﻿namespace Application.Features.Account.Product.AddConfirm;
public class AddProductConfirmValidator : AbstractValidator<AddProductConfirmRequest>
{
    public AddProductConfirmValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");

        RuleFor(p => p.Alias).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull();

        RuleFor(p => p.Otp).Cascade(CascadeMode.Stop)
            //.NotEmpty()
            .NotNull();
    }
}
