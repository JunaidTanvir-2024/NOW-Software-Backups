﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PaypalApi.Infrastructure.BLL;
using PaypalApi.Models.Contracts.Request.User;
using PaypalApi.Models.Contracts.Response.Api;
using PaypalApi.Models.Contracts.Response.User;
using Serilog;

namespace PaypalApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PaypalController : ControllerBase
    {

        private readonly ILogger Logger;
        private IPaypal_BL PaypalBl;

        public PaypalController(ILogger logger, IPaypal_BL paypalBl)
        {
            Logger = logger;
            PaypalBl = paypalBl;
        }

        [HttpPost("CreateSalePayment")]
        public async Task<ActionResult> CreateSalePayment(UserCreateSalePaymentRequest userRequest)
        {

            GenericApiResponse<UserCreateSalePaymentResponse> response;
            try
            {               

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await PaypalBl.CreateSalePayment(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserCreateSalePaymentResponse>()
                {
                    errorCode = 111,
                    status = "Failure",
                    message = "Service not available ",
                    payload = null
                };
                Logger.Error($"Controller: PaypalController, Method: CreateSalePayment, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("ExecuteSalePayment")]
        public async Task<ActionResult> ExecuteSalePayment(UserExecuteSalePaymentRequest userRequest)
        {

            GenericApiResponse<UserExecuteSalePaymentResponse> response;
            try
            {               

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await PaypalBl.ExecuteSalePayment(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserExecuteSalePaymentResponse>()
                {
                    errorCode = 111,
                    status = "Failure",
                    message = "Service not available ",
                    payload = null
                };
                Logger.Error($"Controller: PaypalController, Method: ExecuteSalePayment, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

    }
}