﻿namespace SC.Core.Features.Users.Requests;
public class UserLoginLogRequest : IRequest<IResultWrapper>
{
    public string UserID { get; init; } = default!;
    public DateTimeOffset LoginTime { get; init; } = default!;
    public DateTimeOffset LoginOutTime { get; init; } = default!;
    public string? DeviceInfo { get; init; } = default!;
    public string? Refresh_Token { get; init; } = default!;
    public DateTime? Refresh_Token_Expiry { get; init; } = default!;
    public bool IsSuccessLogin { get; set; } = default!;

}
public class UserLoginLogRequestValidator : AbstractValidator<UserLoginLogRequest>
{
    public UserLoginLogRequestValidator()
    {
        RuleFor(x => x.UserID).NotNull();
        RuleFor(x => x.LoginTime).NotNull();
    }
}
