﻿namespace Application.Features.Account.Product.MakeDefault;
public class DefaultProductRequestValidator : AbstractValidator<DefaultProductRequest>
{
    public DefaultProductRequestValidator(ICommonService commonService)
    {
        RuleFor(x => x.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(x => commonService.IsValidMsisdn(x))
            .WithMessage("Invalid msisdn");
    }
}
