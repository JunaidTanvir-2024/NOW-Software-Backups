﻿namespace Application.Common.Interfaces;

public interface IIdentityService : ISerivcesType.ITransientService
{
}
