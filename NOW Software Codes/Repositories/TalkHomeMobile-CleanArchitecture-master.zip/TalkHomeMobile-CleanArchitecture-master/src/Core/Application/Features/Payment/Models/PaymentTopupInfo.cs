﻿
using Application.Features.AutoTopup;

namespace Application.Features.Payment.Models;

public class PaymentTopupInfo
{
    public float TopupAmount { get; set; }
    public bool IsFastTopup { get; set; } = false;
    public AutoTopupInfo? AutoTopupInfo { get; set; }
}
public class SetPaymentTopupInfo
{
    public float TopupAmount { get; set; }
    public bool IsFastTopup { get; set; } = false;
    public SetAutoTopupInfo? AutoTopupInfo { get; set; }
}
