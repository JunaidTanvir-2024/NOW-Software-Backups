using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Validations;

public class Validation
{
    [JsonPropertyName("code")]
    public string? Code { get; set; }
    [JsonPropertyName("applicable_to")]
    public VoucherSubjectList? ApplicableTo { get; set; }

    [JsonPropertyName("inapplicable_to")]
    public VoucherSubjectList? InapplicableTo { get; set; }

    [JsonPropertyName("error")]
    public ValidationError? Error { get; set; }

    [JsonPropertyName("valid")]
    public bool Valid { get; set; }

    [JsonPropertyName("reason")]
    public string? Reason { get; set; }

    [JsonPropertyName("tracking_id")]
    public string? TrackingId { get; set; }

    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("session")]
    public ValidationSession? Session { get; set; }
}
