﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class transfertoExecuteTransaction
    {
        public int error_code { get; set; }
        public string error_txt { get; set; }
        public string transactionid { get; set; }
        public string msisdn { get; set; }
        public string destination_msisdn { get; set; }
        public string country { get; set; }
        public string originating_currency { get; set; }
        public string destination_currency { get; set; }
        public string product_requested { get; set; }
        public decimal wholesale_price { get; set; }
        public decimal retail_price { get; set; }
        public string @operator { get; set; }
        public string operatorid { get; set; }
        public string sms { get; set; }
        public string pin { get; set; }
        public string receiptText { set; get; }
    }
}
