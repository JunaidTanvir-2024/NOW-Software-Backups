﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using Serilog;
using THCCWEB.Configurations;
using THCCWEB.ExtendedContoller;
using THCCWEB.Models.ApiContracts;
using THCCWEB.Models.ApiContracts.Request;
using THCCWEB.Models.ApiContracts.Request.Account;
using THCCWEB.Models.ApiContracts.Response;
using THCCWEB.Models.ViewModels;
using THCCWEB.Models.ViewModels.Account;
using THCCWEB.Models.ViewModels.Pay360.Request;
using THCCWEB.Models.ViewModels.Pay360.Response;
using THCCWEB.Resources;
using THCCWEB.Services.Interface;
using THCCWEB.Utilities;
using static THCCWEB.Utilities.Enum;

namespace THCCWEB.Controllers
{

    public class AccountController : ExtendedController
    {
        private readonly ILogger _logger;
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly string _thccWebApiEndPoint;
        private readonly IAccountService _accountService;
        private readonly IDataProtector _dataProtector;
        private string baseAouthString = "";
        public AccountController(ILogger logger,
            IOptions<EndPointsConfig> endPoints,
            IAccountService accservice,
            IOptions<BasicAuthConfig> basicAuthConfig, IDataProtectionProvider provider) : base(logger)
        {
            _logger = logger;
            _thccWebApiEndPoint = endPoints.Value.THCCWebApiEndPoint;
            _accountService = accservice;
            _basicAuthConfig = basicAuthConfig.Value;
            baseAouthString = Bas64Convertor.Base64Encode(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password);
            _dataProtector = provider.CreateProtector("THCC-WEB");
        }


        [HttpGet]
        [Route("Login")]
        public IActionResult Login(string ReturnUrl = "", bool isexist = false)
        {
            if (!User.Identity.IsAuthenticated)
            {
                if (isexist) ViewBag.Message = MessageResource.ResourceManager.GetString(ApiStatusCodes.UserAlreadyExist.ToString()); ;
                return View();
            }
            return RedirectToAction("AccountDashboard");
        }

        [HttpGet]
        [Route("account/myaccount")]
        [Authorize]
        public async Task<IActionResult> AccountDashboard(string type)
        {
            try
            {
                var result = GetProfile();
                if (result.AccountNumber == "0")
                { return RedirectToAction("addproduct"); }
                result.NavType = "accountsummary";
                if (!string.IsNullOrEmpty(type))
                    result.NavType = type;
                var response = await Api.CallApi(_thccWebApiEndPoint + "Account/CallingCardAccountSummary", User, ApiCallType.Bearer, null, true);
                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (errorCode == 0)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<AccountSummery>();
                        if (payload != null)
                        {
                            result.Cradit = payload.credit;
                            result.PinCode = payload.pinnumber;
                            result.Points = payload.points;
                            if (payload.lastTopDate.HasValue)
                            {
                                result.LastTopUpDate = payload.lastTopDate.Value.ToString("dd MMM yyyy");

                            }
                            result.LastTopUp = payload.lastTopUp;

                        }
                    }
                }
                return View(result);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: AccountDashboard, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }

        }

        public string ToNiceDateFormat(string input)
        {
            var Date = new DateTime();

            if (!DateTime.TryParse(input, out Date))
                return input;

            return Date.ToString("dd MMM yyyy");
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> VerifyLoginUser(LoginRequestModel model,string returnUrl = "")
        {
            try
            {
                var response = await Api.CallApi(_thccWebApiEndPoint + "Authenticate/Login", User, ApiCallType.BasicAuth, model: new LoginRequestModel()
                {
                    Email = model.Email.Trim(),
                    Password = model.Password.Trim()

                }, false, false, null, baseAouthString);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<LoginResponseModel>();
                        if (payload.ProductList == null)
                        {
                            var claims = new List<Claim>
                        {

                            new Claim (ClaimTypes.Email, payload.Email),
                            new Claim ("FirstName" ,payload.FirstName),
                            new Claim ("LastName" ,payload.LastName),
                            new Claim ("CountryId" ,payload.CountryId.ToString()),
                            new Claim ("ProductRef",string.Empty),
                            new Claim ("AccountNumber","0"),
                            new Claim ("UserId",payload.Id.ToString()),
                            new Claim("bearer_token", payload.Token),
                            new Claim("IsSubscribedToNewsletter", payload.IsSubscribedToNewsletter.HasValue ? payload.IsSubscribedToNewsletter.ToString():"false")
                        };
                            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                            var principal = new ClaimsPrincipal(identity);
                            var prop = new AuthenticationProperties();
                            HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, prop).Wait();
                            return Json(new { errorCode = (int)ApiStatusCodes.ProductsNotFound, key = MessageResource.ResourceManager.GetString(ApiStatusCodes.ProductsNotFound.ToString()) });
                        }
                        else
                        {
                            var claims = new List<Claim>
                        {
                            new Claim (ClaimTypes.Email, payload.Email),
                            new Claim ("FirstName" ,payload.FirstName),
                            new Claim ("LastName" ,payload.LastName),
                            new Claim ("CountryId" ,payload.CountryId.ToString()),
                            new Claim ("ProductRef",payload.ProductList!=null? payload.ProductList[0].ProductRef:""),
                            new Claim ("AccountNumber",payload.ProductList!=null? payload.ProductList[0].AccountId:"0"),
                            new Claim ("UserId",payload.Id.ToString()),
                            new Claim("bearer_token", payload.Token),
                            new Claim("IsSubscribedToNewsletter", payload.IsSubscribedToNewsletter.HasValue ? payload.IsSubscribedToNewsletter.ToString():"false")
                        };
                            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                            var principal = new ClaimsPrincipal(identity);
                            //var handler = new JwtSecurityTokenHandler();
                            //var jsonToken = handler.ReadToken(payload.Token) as JwtSecurityToken;
                            //var expiry = jsonToken.ValidTo;
                            //var prop = new AuthenticationProperties { ExpiresUtc = expiry.AddMinutes(5), IsPersistent = true, AllowRefresh = false };
                            var prop = new AuthenticationProperties();
                            HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, prop).Wait();
                            return Json(new { errorCode = 0, token = payload.Token,redirectUrl = returnUrl });
                        }
                    }
                    else
                    {
                        if (errorCode == (int)ApiStatusCodes.EmailNotVerified)
                        {
                            ViewBag.Message = "";
                            return Json(new { errorCode = (int)ApiStatusCodes.EmailNotVerified, key = MessageResource.ResourceManager.GetString(ApiStatusCodes.EmailNotVerified.ToString()) });
                        }
                        else if (errorCode == (int)ApiStatusCodes.InvalidEmailorPassword)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.InvalidEmailorPassword, key = MessageResource.ResourceManager.GetString(ApiStatusCodes.InvalidEmailorPassword.ToString()) });
                        }
                        else if (errorCode == (int)ApiStatusCodes.UserNotFound)
                        {

                            return Json(new { errorCode = (int)ApiStatusCodes.UserNotFound, key = MessageResource.ResourceManager.GetString(ApiStatusCodes.UserNotFound.ToString()) });
                        }
                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyLoginUser, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("resendverificationemail")]
        public IActionResult resendverificationemail()
        {
            return View();
        }

        [HttpGet]
        [Route("ForgotPassword")]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        [Route("ResetForgotPassword")]
        public async Task<IActionResult> ResetForgotPassword(ForgotPasswordRequestModel model)
        {
            try
            {
                var response = await Api.CallApi(_thccWebApiEndPoint + "Authenticate/ForgotPassword", User, ApiCallType.BasicAuth, model: new ForgotPasswordRequestModel()
                {
                    Email = model.Email,
                }, basicauthtoken: baseAouthString);
                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                    {
                        return Json(new { errorCode = 0, key = ApiStatusCodes.ResetPasswordLinkSentSuccessfully.ToString().ToLower() });
                    }
                    else
                    {
                        if (errorCode == (int)ApiStatusCodes.EmailNotVerified)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.EmailNotVerified, key = ApiStatusCodes.EmailNotVerified.ToString().ToLower() });
                        }

                        else if (errorCode == (int)ApiStatusCodes.UserNotFound)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.UserNotFound, key = MessageResource.ResourceManager.GetString(ApiStatusCodes.UserNotFound.ToString()) });
                        }
                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: ResetForgotPassword, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("register-for-my-account")]
        public IActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegistraionViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = await Api.CallApi(_thccWebApiEndPoint + "Authenticate/Register", User, ApiCallType.BasicAuth, model, basicauthtoken: baseAouthString);
                if (result != null)
                {

                    if (result.IsSuccessStatusCode)
                    {
                        var responseJson = JObject.Parse(result.Content.ReadAsStringAsync().Result);
                        int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                        if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                        {
                            //Success Case
                            return Json(new { errorCode = 0, key = "Sucessfullregistered" });
                        }
                        else
                        {
                            if (errorCode == (int)ApiStatusCodes.UserAlreadyExist)
                            {
                                return Json(new { errorCode = (int)ApiStatusCodes.UserAlreadyExist, key = ApiStatusCodes.UserAlreadyExist.ToString().ToLower() });
                            }

                        }
                    }
                    else
                    {
                        return Json(new { errorCode = (int)ApiStatusCodes.InternalServerError, key = ApiStatusCodes.InternalServerError.ToString().ToLower() });
                    }
                }
                return View();
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: Register, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("password-recovery")]
        public async Task<IActionResult> Passwordrecovery(string token)
        {
            try
            {
                var response = await Api.CallApi(_thccWebApiEndPoint + "Authenticate/VerifyEmail", User, ApiCallType.BasicAuth, model: new VerifyEmailRequestModel()
                {
                    Token = token.Trim(),
                    TokenTypeId = 2

                }, basicauthtoken: baseAouthString);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                    {
                        TempData["reset"] = "true";
                        TempData["token"] = token;
                        return RedirectToAction("resetuserPassword");
                    }
                    else
                    {
                        if (errorCode == (int)ApiStatusCodes.ExpiredToken)
                        {
                            return RedirectToAction("ErrorMessage", "Home", new { key = "ExpiredToken" });
                        }
                        return RedirectToAction("ErrorMessage", "Home", new { key = "InvalidToken" });
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: Passwordrecovery, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("verify-Email")]
        public async Task<IActionResult> VerifyEmail(string token)
        {
            try
            {
                var response = await Api.CallApi(_thccWebApiEndPoint + "Authenticate/VerifyEmail", User, ApiCallType.BasicAuth, model: new VerifyEmailRequestModel()
                {
                    Token = token.Trim(),
                    TokenTypeId = 1

                }, basicauthtoken: baseAouthString);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                    {
                        return RedirectToAction("SuccessMessage", "Home", new { key = "SuccessEmailVerification" });

                    }
                    else if (errorCode == (int)ApiStatusCodes.InternalServerError)
                    {
                        return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                    }
                    else
                    {
                        if (errorCode == (int)ApiStatusCodes.ExpiredToken)
                        {
                            return RedirectToAction("ErrorMessage", "Home", new { key = "ExpiredToken" });
                        }
                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyEmail, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }
        [HttpGet]
        [Route("resetuserPassword")]
        public IActionResult ResetUserPassword()
        {

            if (TempData.ContainsKey("reset"))
            {
                TempData.Remove("reset");
                TempData.Keep("token");
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        [HttpPost]
        [Route("UpdateUserPassword")]
        public async Task<IActionResult> UpdateUserPassword(UpdatePasswordModel model)
        {
            try
            {
                var token = TempData["token"].ToString();
                var emailResponse = await Api.CallApi(_thccWebApiEndPoint + "Authenticate/GetEmailByToken", User, ApiCallType.BasicAuth, GetRequest: false, model: new ResetUserPasswordModel
                {
                    Token = token

                }, basicauthtoken: baseAouthString);
                if (emailResponse.IsSuccessStatusCode)
                {
                    var emailJobject = JObject.Parse(emailResponse.Content.ReadAsStringAsync().Result);
                    int emailErrorCode = emailJobject.GetValue("errorCode").ToObject<int>();
                    if (emailErrorCode == 0)
                    {
                        string emailaddress = emailJobject.GetValue("payload").ToObject<string>();
                        var response = await Api.CallApi(_thccWebApiEndPoint + "Authenticate/ChangePassword", User, ApiCallType.BasicAuth, GetRequest: false, model: new UpdatePasswordModel()
                        {
                            Email = emailaddress.Trim(),
                            NewPassword = model.NewPassword.Trim()

                        }, basicauthtoken: baseAouthString);

                        if (response.IsSuccessStatusCode)
                        {
                            var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                            int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                            if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                            {
                                return Json(new { errorCode = 0, key = ApiStatusCodes.PasswordUpdatedSucessfully.ToString().ToLower() });

                            }
                            else
                            {
                                if (errorCode == (int)ApiStatusCodes.DBError)
                                {
                                    return Json(new { errorCode = (int)ApiStatusCodes.DBError, key = MessageResource.ResourceManager.GetString(ApiStatusCodes.DBError.ToString()) });
                                }
                                else if (errorCode == (int)ApiStatusCodes.UserNotFound)
                                {

                                    return Json(new { errorCode = (int)ApiStatusCodes.UserNotFound, key = MessageResource.ResourceManager.GetString(ApiStatusCodes.UserNotFound.ToString()) });
                                }
                                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                            }
                        }
                        else
                        {
                            return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                        }
                    }
                    else 
                    {
                        return RedirectToAction("ErrorMessage", "Home", new { key = "EmailDoesNotMatched" });
                    }

                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }


            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: UpdateUserPassword, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }



        [HttpGet]
        [Route("getpoints")]
        public async Task<IActionResult> getpoints()
        {
            try
            {
                string accountno = GetProfile().AccountNumber.ToString();
                GetPointrequestModel model = new GetPointrequestModel();
                model.accno = accountno;
                var response = await Api.CallApi(_thccWebApiEndPoint + "Account/getpoints", User, ApiCallType.BasicAuth, model, GetRequest: false, basicauthtoken: baseAouthString);
                if (response.IsSuccessStatusCode)
                {

                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<CallingCardPoints>();
                        return Json(new { errorCode = 0, payload });
                    }
                    else
                    {

                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Accountcontroller, Method: getpoints, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }
        [HttpGet]
        [Route("Getlasttopup")]
        public async Task<IActionResult> Getlasttopup()
        {
            try
            {
                var response = await Api.CallApi(_thccWebApiEndPoint + "Account/Getlasttopup", User, ApiCallType.Bearer, GetRequest: true);
                if (response.IsSuccessStatusCode)
                {

                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<UserAccountLastTopup>();
                        DateTime dt = DateTime.Parse(payload.date, new CultureInfo("en-CA"));
                        return Json(new { errorCode = 0, payload });
                    }
                    else
                    {

                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {

                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Accountcontroller, Method: Getlasttopup, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("redeempoints")]
        [Authorize]
        public async Task<IActionResult> redeempoints(RedeemPointsrequestModel model)
        {
            try
            {
                string subscriberid = "";
                var response = await Api.CallApi(_thccWebApiEndPoint + "Account/CallingCardAccountSummary", User, ApiCallType.Bearer, null, true);
                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (errorCode == 0)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<AccountSummery>();
                        if (payload != null)
                        {
                            subscriberid = payload.subscriberId;
                        }
                    }
                }

                string accountno = GetProfile().AccountNumber.ToString();
                string Email = GetProfile().Email.ToString();
                RedeemPointsrequestModel requestModel = new RedeemPointsrequestModel();
                requestModel.cardno = accountno;
                requestModel.EmailAddress = Email;
                requestModel.subscriberid = subscriberid;
                requestModel.points = model.points;

                var RedeemPointsresponse = await Api.CallApi(_thccWebApiEndPoint + "Account/redeempoints", User, ApiCallType.Bearer, requestModel, GetRequest: false
                    );
                if (response.IsSuccessStatusCode)
                {

                    var responseJson = JObject.Parse(RedeemPointsresponse.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<bool>();
                        return Json(new { errorCode = 0, payload });
                    }
                    else
                    {

                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Accountcontroller, Method: redeempoints, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }



        [HttpPost]
        [Route("setdefaultcard")]
        public async Task<ActionResult> SetDefaultCard(SetCustomerDefaultCardRequest model)
        {
            try
            {
                string id;
                var pay360customer_id = await Api.CallApi(_thccWebApiEndPoint + "Pay360Account/Getpay360Customer", User, ApiCallType.BasicAuth, model: new Pay360CustomerRequestModel { customerUniqueRef = GetProfile().Email, productCode = "THCC" }, GetRequest: false, basicauthtoken: baseAouthString);
                if (pay360customer_id.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(pay360customer_id.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (errorCode == 0)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<Pay360CustomerModel>();
                        id = payload.pay360CustId;
                    }
                    else
                    {
                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }

                model.pay360CustomerID = id;
                var customerResponse = await Api.CallApi(_thccWebApiEndPoint + "Pay360Account/SetCustomerDefaultCard", User, ApiCallType.BasicAuth, model, GetRequest: false, basicauthtoken: baseAouthString);
                if (customerResponse.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(customerResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (errorCode == 0)
                    {
                        return Json(new { status = true, message = "Customer's default card set successfully" });
                    }
                    else
                    {
                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Accountcontroller, Method: SetDefaultCard, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("removedefaultcard")]
        public async Task<ActionResult> RemovedefaultCard(Pay360RemoveCardRequest model)
        {
            try
            {   /////////check is autotopup on or off///////////////////
                bool alow_to_remove_default_card = true;

                Pay360GetAutoTopUpRequest autotopreq = new Pay360GetAutoTopUpRequest();
                autotopreq.Msisdn = GetProfile().AccountNumber.ToString();
                autotopreq.Email = GetProfile().Email.ToString();
                var response = await Api.CallApi(_thccWebApiEndPoint + "Pay360Account/getautotopup", User, ApiCallType.BasicAuth, autotopreq, GetRequest: false, basicauthtoken: baseAouthString);
                if (response.IsSuccessStatusCode)
                {

                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<Pay360GetAutoTopUpResponse>();
                        /////offf autotopup/////
                        if (payload.Status == true)
                        {
                            SetCreditAutoRenewal off_topup_model = new SetCreditAutoRenewal();
                            off_topup_model.msisdn = GetProfile().AccountNumber.ToString();
                            off_topup_model.productCode = "THCC";
                            off_topup_model.autoTopUp = false;
                            off_topup_model.threshold = (int)payload.ThresHold;
                            off_topup_model.topUpAmount = (int)payload.Topup;
                            var offautotopupresponse = await Api.CallApi(_thccWebApiEndPoint + "Pay360Account/setautotopup", User, ApiCallType.BasicAuth, off_topup_model, GetRequest: false, basicauthtoken: baseAouthString);
                            if (offautotopupresponse.IsSuccessStatusCode)
                            {
                                int off_topup_errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                                if (off_topup_errorCode == 0)
                                {
                                    alow_to_remove_default_card = true;

                                }
                                else
                                {
                                    alow_to_remove_default_card = false;
                                }
                            }
                            else
                            {
                                alow_to_remove_default_card = false;
                            }
                        }
                    }
                    ///////Removecard/////
                    if (alow_to_remove_default_card == true)
                    {

                        string id = "";
                        var pay360customer_id = await Api.CallApi(_thccWebApiEndPoint + "Pay360Account/Getpay360Customer", User, ApiCallType.BasicAuth, model: new Pay360CustomerRequestModel { customerUniqueRef = GetProfile().Email, productCode = "THCC" }, GetRequest: false, basicauthtoken: baseAouthString);
                        if (pay360customer_id.IsSuccessStatusCode)
                        {
                            var responseJsongetcustomer = JObject.Parse(pay360customer_id.Content.ReadAsStringAsync().Result);
                            int errorCodegetcustomer = responseJsongetcustomer.GetValue("errorCode").ToObject<int>();
                            if (errorCodegetcustomer == 0)
                            {
                                var payload = responseJsongetcustomer.GetValue("payload").ToObject<Pay360CustomerModel>();
                                id = payload.pay360CustId;
                            }
                        }
                        model.pay360CustomerID = id;
                        var customerResponse = await Api.CallApi(_thccWebApiEndPoint + "Pay360Account/removecard", User, ApiCallType.Bearer, model, GetRequest: false);
                        if (customerResponse.IsSuccessStatusCode)
                        {
                            var removecardresponseJson = JObject.Parse(customerResponse.Content.ReadAsStringAsync().Result);
                            int removecard_errorCode = removecardresponseJson.GetValue("errorCode").ToObject<int>();
                            if (removecard_errorCode == 0)
                            {
                                return Json(new { status = true, message = string.Empty });
                            }
                            else
                            {
                                return Json(null);
                            }
                        }
                        else
                        {
                            return Json(null);
                        }
                    }
                    else { return Json(null); }

                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Accountcontroller, Method: RemoveDefaultCard, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Json(new { errorCode = StatusCode((int)ApiStatusCodes.InternalServerError) });
            }
        }

        [HttpPost]
        [Route("removecard")]
        public async Task<ActionResult> RemoveCard(Pay360RemoveCardRequest model)
        {
            try
            {
                string id = "";
                var pay360customer_id = await Api.CallApi(_thccWebApiEndPoint + "Pay360Account/Getpay360Customer", User, ApiCallType.BasicAuth, model: new Pay360CustomerRequestModel { customerUniqueRef = GetProfile().Email, productCode = "THCC" }, GetRequest: false, basicauthtoken: baseAouthString);
                if (pay360customer_id.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(pay360customer_id.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (errorCode == 0)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<Pay360CustomerModel>();
                        id = payload.pay360CustId;
                    }
                    else
                    {
                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }

                model.pay360CustomerID = id;
                var customerResponse = await Api.CallApi(_thccWebApiEndPoint + "Pay360Account/removecard", User, ApiCallType.Bearer, model, GetRequest: false);
                if (customerResponse.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(customerResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (errorCode == 0)
                    {
                        return Json(new { status = true, message = string.Empty });
                    }
                    else
                    {
                        return Json(null);
                    }
                }
                else
                {
                    return Json(null);
                }

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: RemoveCard, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Json(new { errorCode = StatusCode((int)ApiStatusCodes.InternalServerError) });
            }
        }
        [HttpGet]
        [Route("addproduct")]
        [Authorize]
        public IActionResult AddProduct()
        {
            if (GetProfile().AccountNumber != "0")
            {
                return RedirectToAction("AccountDashboard");
            }
            return View();
        }

        [HttpPost]
        [Route("addproduct")]
        [Authorize]
        public async Task<IActionResult> AddProduct(ProductAdditionRequest model)
        {
            try
            {

                model.userid = GetProfile().Id;
                var response = await Api.CallApi(_thccWebApiEndPoint + "Account/addproduct", User, ApiCallType.Bearer, model, GetRequest: false);
                var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                if (response.IsSuccessStatusCode)
                {
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {

                        var payload = responseJson.GetValue("payload").ToObject<UserAccountSummary>();
                        UpdateAccnuminclaims(payload.productRef, payload.RefreashedToken);
                        return Json(new { errorCode = 0, payload });
                    }
                    else if (errorCode == 976)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<UserAccountSummary>();
                        return Json(new { errorCode = 976, payload });
                    }
                    else if (errorCode == 977)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<LoginResponseModel>();
                        return Json(new { errorCode = 977, payload });
                    }
                    else
                    { return Json(new { errorCode = StatusCode((int)ApiStatusCodes.InternalServerError) }); }
                }
                else
                {
                    var payload = responseJson.GetValue("payload").ToObject<UserAccountSummary>();
                    return Json(new { errorCode = 976, payload });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: AddProduct, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Json(new { errorCode = StatusCode((int)ApiStatusCodes.InternalServerError) });
            }
        }

        #region Users account
        [HttpPost]
        [Route("updatebasicinfo")]
        [Authorize]
        public async Task<IActionResult> UpdateUserInfo(UserProfileViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json(new { errorCode = (int)ApiStatusCodes.InternalServerError, message = "Model state not valid" });
                }
                var response = await Api.CallApi(_thccWebApiEndPoint + "Account/UpdateUserInfo", User, ApiCallType.Bearer, model, false);
                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    // int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    // if (errorCode == 0)
                    {
                        UpdateClaimsInfo(new UpdateUserInfoViewModel { FirstName = model.FirstName, LastName = model.LastName, IsSubscribedToNewsletter = model.MailSubscription });
                        return Json(new { errorCode = 0, message = "Ok" });
                    }
                }
                return Json(new { errorCode = (int)ApiStatusCodes.InternalServerError });
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: UpdateUserInfo, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Json(new { errorCode = (int)ApiStatusCodes.InternalServerError });
            }
        }

        [HttpPost]
        [Route("updatenewpassword")]
        [Authorize]
        public async Task<JsonResult> UpdateNewPassword(UpdateUserPasswordViewModel model)
        {
            try
            {
                var response = await Api.CallApi(_thccWebApiEndPoint + "Account/UserNewPasswordUpdate", User, ApiCallType.Bearer, model, false);
                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int _errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (_errorCode == 0)
                    {
                        return Json(new { errorCode = 0, message = "Ok" });
                    }
                    else
                    {
                        return Json(new { errorCode = _errorCode, message = MessageResource.ResourceManager.GetString(ApiStatusCodes.InvalidOldPassword.ToString()) });
                    }
                }
                return Json(new { errorCode = (int)ApiStatusCodes.InternalServerError });
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: UpdateNewPassword, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Json(new { errorCode = (int)ApiStatusCodes.InternalServerError });
            }

        }
        [HttpPost]
        public async Task<JsonResult> VerifyPinNumber(string pin)
        {
            try
            {
                var response = await Api.CallApi(_thccWebApiEndPoint + "Common/VerifyPinNumber", User, ApiCallType.BasicAuth, new VerifyPinRequestModel
                {
                    MsisdnOrCardNumber = pin,
                }, basicauthtoken: baseAouthString);
                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int _errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (_errorCode == 0)
                    {
                        return Json(new { errorCode = 0, message = "Pin Verified" });
                    }
                    else
                    {
                        return Json(new { errorCode = _errorCode, message = MessageResource.ResourceManager.GetString(ApiStatusCodes.InvalidMsisdn.ToString()) });
                    }
                }
                return Json(new { errorCode = (int)ApiStatusCodes.InternalServerError });
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyPinNumber, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Json(new { errorCode = (int)ApiStatusCodes.InternalServerError });
            }
        }

        #endregion
        private void UpdateAccnuminclaims(string acc, string refreashToken)
        {
            try
            {
                var identity = User.Identity as ClaimsIdentity;
                var ACCnumClaims = identity.FindFirst("AccountNumber");
                identity.RemoveClaim(ACCnumClaims);
                var token = identity.FindFirst("bearer_token");
                identity.RemoveClaim(token);
                var claims = new List<Claim>
                        {
                            new Claim ("AccountNumber" ,acc),
                            new Claim ("bearer_token" ,refreashToken),
                        };
                identity.AddClaims(claims);
                var principal = new ClaimsPrincipal(identity);
                var prop = new AuthenticationProperties();
                HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, prop).Wait();
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Accountcontroller, Method: UpdateClaimsInfo, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }

        }
        private void UpdateClaimsInfo(UpdateUserInfoViewModel model)
        {
            try
            {
                var identity = User.Identity as ClaimsIdentity;
                var firstNameClaims = identity.FindFirst("FirstName");
                identity.RemoveClaim(firstNameClaims);
                var LastNameClaims = identity.FindFirst("LastName");
                identity.RemoveClaim(LastNameClaims);
                var IsSubscribedToNewsletter = identity.FindFirst("IsSubscribedToNewsletter");
                identity.RemoveClaim(IsSubscribedToNewsletter);
                var claims = new List<Claim>
                        {
                            new Claim ("FirstName" ,model.FirstName),
                            new Claim ("LastName" ,model.LastName),
                            new Claim("IsSubscribedToNewsletter", model.IsSubscribedToNewsletter.HasValue ? model.IsSubscribedToNewsletter.ToString() : "false")
            };
                identity.AddClaims(claims);
                var principal = new ClaimsPrincipal(identity);
                var prop = new AuthenticationProperties();
                HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, prop).Wait();
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Accountcontroller, Method: UpdateClaimsInfo, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }

        }
        [HttpPost]
        [Route("resendverificationemail")]
        public async Task<IActionResult> ResendVerificationemail(ReSendTokenRequestModel model)
        {
            try
            {
                var result = await Api.CallApi(_thccWebApiEndPoint + "Authenticate/ReSendToken", User, ApiCallType.BasicAuth, model, basicauthtoken: baseAouthString);

                if (result.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(result.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                    {
                        //Success Case
                        return RedirectToAction("SuccessMessage", "Home", new { key = "VerificationLinkSentSuccessfully" });
                    }
                    if (errorCode == (int)ApiStatusCodes.UserNotFound)
                    {
                        return RedirectToAction("ErrorMessage", "Home", new { key = "UserNotFound" });
                    }
                    else
                    {
                        return RedirectToAction("ErrorMessage", "Home", new { key = "DBError" });

                    }
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Accountcontroller, Method: ResendVerificationemail, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }

        }

        [HttpGet]
        [Route("EmailProductVerification/{email}")]
        public async Task<JsonResult> EmailProductVerification(string email)
        {
            try
            {
                var response = await Api.CallApi(_thccWebApiEndPoint + "Account/ISEmailProductExist/" + email, User, ApiCallType.BasicAuth, null, GetRequest: true, false, null, baseAouthString);
                var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                int error = responseJson.GetValue("errorCode").ToObject<int>();
                if (response.IsSuccessStatusCode)
                {
                    if (error == 0)
                    {

                        var payload = responseJson.GetValue("payload").ToObject<UserProductValidationResponseModel>();
                        return Json(new { errorCode = 0, payload = payload });
                    }
                }
                return Json(new { errorCode = error, message = "Something went wrong" });
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Accountcontroller, Method: EmailProductVerification, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Json(new { errorCode = (int)ApiStatusCodes.InternalServerError });
            }
        }
    }
}
