﻿using NowPayG.Models.ApiContracts.Response;
using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;

namespace NowPayG.Models
{
    public class BaseViewModel
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName
        {
            get
            {
                return FirstName + " " + LastName;

            }
        }
        public string Email { get; set; }
        public string Token { get; set; }
        public bool IsSignedIn { get; set; }
        public LoginTypes LoginType { get; set; }
        public IEnumerable<UserProductsResponseModel> ProductList { get; set; }

        public async Task SetSharedDataAsync(IPrincipal User)
        {
            var claimIdentity = (ClaimsIdentity)User.Identity;

            if (claimIdentity.Claims.Count() > 0)
            {
                Id = Convert.ToInt32(claimIdentity.Claims.FirstOrDefault(x => x.Type == "Id").Value);
                FirstName = claimIdentity.Claims.FirstOrDefault(x => x.Type == "FirstName").Value;
                LastName = claimIdentity.Claims.FirstOrDefault(x => x.Type == "LastName").Value;
                Email = claimIdentity.Claims.FirstOrDefault(x => x.Type == "Email").Value;
                Token = claimIdentity.Claims.FirstOrDefault(x => x.Type == "Token").Value;
                if (claimIdentity.Claims.FirstOrDefault(x => x.Type == "IsSignedIn") != null)
                    IsSignedIn = Convert.ToBoolean(claimIdentity.Claims.FirstOrDefault(x => x.Type == "IsSignedIn").Value);
                if (claimIdentity.Claims.FirstOrDefault(x => x.Type == "LoginType") != null)
                    LoginType = (LoginTypes)(Convert.ToInt16(claimIdentity.Claims.FirstOrDefault(x => x.Type == "LoginType").Value));
            }
            else
            {
                Id = 0;
                FirstName = string.Empty;
                LastName = string.Empty;
                Email = string.Empty;
                Token = string.Empty;
                IsSignedIn = false;
            }
        }
    }
}
