namespace CancelBundleApi.Repositories.Interfaces;

public interface IUnitOfWork
{
    IUserRepository UserRepo { get; }

}