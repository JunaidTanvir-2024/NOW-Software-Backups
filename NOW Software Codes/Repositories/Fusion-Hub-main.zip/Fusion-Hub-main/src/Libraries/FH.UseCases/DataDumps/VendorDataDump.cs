using FH.Core.Extensions;
using FH.Core.Interfaces.Vendors;

using Hangfire;

using Mediator;

using RW;

using Serilog;

namespace FH.UseCases.DataDumps;
public sealed class VendorDataDump
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper> { }

	#endregion

	#region Handler
	internal sealed class Handler(
		IDTOneDataDumpService dTOneDataDumpService,
		IRecurringJobManager recurringJobManager,
		IReloadlyDataDumpService reloadlyGiftCardDataDumpService,
		ILogger logger) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IDTOneDataDumpService _dTOneDataDumpService = dTOneDataDumpService;
		private readonly IRecurringJobManager _recurringJobManager = recurringJobManager;
		private readonly IReloadlyDataDumpService _reloadlyGiftCardDataDumpService = reloadlyGiftCardDataDumpService;
		private readonly ILogger _logger = logger;

		public ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
		{
			try
			{
				_recurringJobManager.AddOrUpdate("ReloadlyGiftCardProductsDump", () => _reloadlyGiftCardDataDumpService.Products(), Cron.Daily);
				_recurringJobManager.AddOrUpdate("DTOneProductsDump", () => _dTOneDataDumpService.Products(), Cron.Daily);

				return ValueTask.FromResult<IResultWrapper>(ResultWrapper.Success(new { IsEnabled = true }));
			}
			catch (Exception ex)
			{
				_logger.ErrorLog(ex, nameof(VendorDataDump), nameof(Handler));
				return ValueTask.FromResult<IResultWrapper>(ResultWrapper.Failure(new { IsEnabled = false }));
			}
		}
	}
	#endregion
}
