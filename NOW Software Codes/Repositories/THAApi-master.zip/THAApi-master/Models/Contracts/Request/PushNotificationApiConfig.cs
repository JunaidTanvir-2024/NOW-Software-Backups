﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class PushNotificationApiConfig
    {
        public string ApiEndPoint { get; set; }
    }
}
