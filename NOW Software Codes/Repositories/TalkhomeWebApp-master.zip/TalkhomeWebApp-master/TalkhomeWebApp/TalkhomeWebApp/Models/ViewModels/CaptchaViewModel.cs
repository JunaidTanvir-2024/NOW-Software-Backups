﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class CaptchaViewModel
    {
        public Boolean success { get; set; }
        public string challenge_ts { get; set; }
        public string hostname { get; set; }
    }
    public class GoogleCaptchaTokenResponseModel
    {
        // Response Model from Google Recaptcha V3 Verify API
        [JsonProperty("success")]
        public bool Success { get; set; }

        [JsonProperty("score")]
        public decimal Score { get; set; }

        [JsonProperty("action")]
        public string Action { get; set; }

        [JsonProperty("error-codes")]
        public List<string> ErrorCodes { get; set; }
    }

}
