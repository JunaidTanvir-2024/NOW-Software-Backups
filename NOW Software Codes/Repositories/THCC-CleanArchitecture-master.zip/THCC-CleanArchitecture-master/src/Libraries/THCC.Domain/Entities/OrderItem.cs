﻿using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Domain.Entities
{
    public class OrderItem
    {
        public long Id { get; set; }
        public long OrderId { get; set; }
        public ProductType ProductType { get; set; }
        public decimal Amount { get; set; }
        public decimal Discount { get; set; }
        public decimal TotalAmount { get; set; }
        public bool IsFulfill { get; set; }
        public string? FulfillmentErrorMsg { get; set; }
        public DateTime FulfillmentDateTime { get; set; }
        public string? CardNumber { get; set; }
        public string? CardPin { get; set; }
    }
}
