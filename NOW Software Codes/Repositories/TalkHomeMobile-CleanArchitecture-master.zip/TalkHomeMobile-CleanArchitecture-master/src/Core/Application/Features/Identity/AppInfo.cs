﻿namespace Application.Features.Identity;
public sealed class AppInfo
{
    public string CpuArchitecture { get; set; } = default!;

    public string ActionExecuted { get; set; } = default!;

    public string DeviceOS { get; set; } = default!;

    public string DeviceOSVersion { get; set; } = default!;

    public string DeviceMake { get; set; } = default!;

    public string DeviceModel { get; set; } = default!;

    public string DeviceLanguage { get; set; } = default!;

    public string DevicePersistentID { get; set; } = default!;

    public string AppVersion { get; set; } = default!;

    public string AppLanguage { get; set; } = default!;
}
