﻿namespace Models.Enums
{
    public enum ApiStatusCodes
    {
        CredentialsNotFound = 1,
        CodeException = 2,
        InvalidChannel = 3,
        NullContent = 4,
        DataNotAvailable = 5,
        DataNotUpdated = 6,
        UnSuccessful = 7       
    }
}
