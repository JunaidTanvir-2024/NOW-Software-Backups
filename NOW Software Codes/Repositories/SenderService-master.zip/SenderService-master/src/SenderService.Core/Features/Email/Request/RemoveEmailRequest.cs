﻿using System.ComponentModel.DataAnnotations;

namespace SenderService.Core.Features.Email.Request;

public class RemoveEmailRequest
{
    [EmailAddress]
    public string Email { get; set; } = default!;
    public int RecipientType { get; set; }
}
