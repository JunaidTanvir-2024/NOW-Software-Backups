using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Redemptions;

public class RedemptionGift
{
    [JsonPropertyName("amount")]
    public long Amount { get; set; }
}
