﻿using Application.Common.Extensions.DependencyResolver;
using Application.Common.Interfaces.Shared;
using Domain.Aggregate;

namespace Application.Common.Interfaces.Repositories;

public interface ITopupRepository : IServicesType.IScopedService
{
    Task<AutoTopupResponse> GetAutoTopup(string msisdn, string userEmail);
    Task SetAutoTopup(bool isAutoTopup, string msisdn, string userEmail, float topupAmount, string topupCurrency, float topupTheresholdAmount, PaymentMethod paymentMethod, string cardMaskedPan = null, string cardInitialTransactionId = null);
    Task<bool> DisableAutoTopup(string msisdn,string transactionId);
}