﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.Airship
{
    public class GenericAirShipApiResponse<T>
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public T payload { get; set; }
    }
}
