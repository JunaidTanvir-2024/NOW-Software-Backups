﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class PaypalByPay360PaymentCallBackRequestModel
    {
        [Required]
        public string Token { get; set; }

        [Required]
        [Range(1, 2)]
        public CheckOutTypes type { get; set; }

        public string bundleId { get; set; }

        public string IpAddress { get; set; }

        [Required]
        public string Msisdn { get; set; }

        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }
        public BundleType BundleType { get; set; }
        public int PTId { get; set; }
    }
}
