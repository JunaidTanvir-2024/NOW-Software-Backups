﻿namespace CancelBundleApi.Constants.Enums
{
    internal enum BundleServiceEnum
    {
        BundleApiService = 1
    }
}
