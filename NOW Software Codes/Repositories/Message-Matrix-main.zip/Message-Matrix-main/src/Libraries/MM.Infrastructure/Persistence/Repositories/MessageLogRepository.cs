using MM.Core.Common.Interfaces.Database;

namespace MM.Infrastructure.Persistence.Repositories;



public class MessageLogRepository : ISmsLogRepository
{
    private readonly IConfiguration? _configuration;

    public MessageLogRepository(IConfiguration configuration)
    {
        _configuration = configuration;
    }


    public async Task InsertSmsLog(MessageLog smsLogDto)
    {
        using ( var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.MessageMatrix)))
        {
            var parameters = new DynamicParameters();
            parameters.Add("@transaction_id", smsLogDto.TransactionId);
            parameters.Add("@sender", smsLogDto.Sender);
            parameters.Add("@receiver", smsLogDto.Receiver);
            parameters.Add("@message", smsLogDto.Message);
            parameters.Add("@message_status", smsLogDto.MessageStatus);
            parameters.Add("@message_error", smsLogDto.MessageError);
            parameters.Add("@created_by", smsLogDto.CreatedBy);
            parameters.Add("@current_time", smsLogDto.CurrentTime);
            parameters.Add("@message_sid", smsLogDto.MessageSid);
            parameters.Add("@guid", smsLogDto.Guid);

            try
            {
                await connection.ExecuteAsync(AppConstants.StoreProcedures.InsertSmsLogging, parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }

    public async Task<int> GetMessageCount(string receiver, string message, DateTime requestedDate)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.MessageMatrix)))
        {
            var parameters = new DynamicParameters();
            parameters.Add("@param_receiver", receiver);
            parameters.Add("@param_message", message);
            parameters.Add("@param_request_date", requestedDate);

            try
            {
              var getAccount = await connection.QuerySingleOrDefaultAsync<int>(AppConstants.StoreProcedures.GetMessageCount, parameters, commandType: CommandType.StoredProcedure);
              return getAccount;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }


    public async Task<bool> GetMessageSent(int smsCount, long smsTime, string senderMsisdn)
    {
        bool isLimitExceed = false;
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.MessageMatrix)))
        {
            var parameters = new DynamicParameters();
            parameters.Add("@sms_count", smsCount);
            parameters.Add("@sms_time", smsTime);
            parameters.Add("@sender", senderMsisdn);
            try
            {
                var result = await connection.QueryFirstOrDefaultAsync<bool>(AppConstants.StoreProcedures.GetMessageSent, parameters, commandType: CommandType.StoredProcedure);

                return result;
            }
            catch (Exception ex)
            {
                throw;
            }
           // return isLimitExceed;
        }
    }
}
