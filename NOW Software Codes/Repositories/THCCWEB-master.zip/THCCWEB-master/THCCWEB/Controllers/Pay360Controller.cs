﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using THCCWEB.Configurations;
using THCCWEB.ExtendedContoller;
using THCCWEB.Models.ApiContracts;
using THCCWEB.Models.ApiContracts.Request.Account;
using THCCWEB.Models.ApiContracts.Request.Pay360;
using THCCWEB.Models.ApiContracts.Response.Pay360;
using THCCWEB.Models.ViewModels;
using THCCWEB.Models.ViewModels.Account;
using THCCWEB.Models.ViewModels.CheckOutView;
using THCCWEB.Models.ViewModels.Pay360.Response;
using THCCWEB.Resources;
using THCCWEB.Utilities;
using THCCWEB.Utilities.Extension;
using static THCCWEB.Utilities.Enum;

namespace THCCWEB.Controllers
{
    public class Pay360Controller : ExtendedController
    {
        private readonly EndPointsConfig _endPoints;
        private readonly ILogger _logger;
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly string baseAouthString = string.Empty;
        private readonly IDataProtector _dataProtector;
        public Pay360Controller(IOptions<EndPointsConfig> endPoints, ILogger logger, IOptions<BasicAuthConfig> basicAuthConfig, IDataProtectionProvider provider) : base(logger)
        {
            _endPoints = endPoints.Value;
            _logger = logger;
            _basicAuthConfig = basicAuthConfig.Value;
            baseAouthString = Bas64Convertor.Base64Encode(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password);
            _dataProtector = provider.CreateProtector("THCC-WEB");
        }

        [Route("TopupSecureReturnPayment")]
        public async Task<IActionResult> securereturntopup(Secure3DModel secure3DModel)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); };
                //Get encrypted query string
                var EncryptedQueryString = secure3DModel.Id;

                //UnProtect the encrypted string
                var UnEncryptedQueryString = _dataProtector.Unprotect(EncryptedQueryString);

                //Convert UnEncrypted Query string to Json string
                JObject QueryStringJson = JObject.Parse(UnEncryptedQueryString);

                //Convert Json string to Json Object 
                var QuerystringObject = QueryStringJson.ToObject<Secure3DViewModel>();

                var model = new Secure3DViewModel
                {
                    MD = secure3DModel.MD,
                    PaRes = secure3DModel.PaRes,
                    AccountNumber = QuerystringObject.AccountNumber,
                    Email = QuerystringObject.Email,
                    IsAuthenticated = QuerystringObject.IsAuthenticated,
                    IsAutoTopup = QuerystringObject.IsAutoTopup,
                    Type = QuerystringObject.Type
                };

                string encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));


                var paymentResponse = await Api.CallApi(_endPoints.THCCWebApiEndPoint +
                                                        "Pay360Account/Resume3DTransaction", User, ApiCallType.BasicAuth,
                                                        model, basicauthtoken: encoded);


                _logger.Information($"Class: Pay360, Method: securereturntopup-Response, " +
                                    $"Status Code: {paymentResponse.StatusCode}, " +
                                    $"Message: {paymentResponse.ReasonPhrase} " +
                                    $"Request: {JsonConvert.SerializeObject(model)}");


                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var Secure3Dpayload = paymentResponseJson.GetValue("payload").ToObject<Pay360PaymentResponseModel>().directPaymentData;

                        if (model.Type == "TopUp" && model.IsAuthenticated) //Set Auto-TopUp
                        {
                            var AccountResult = await Api.CallApi(_endPoints.THCCWebApiEndPoint + "Account/AccountSummaryByAccountNumber/" + Secure3Dpayload.CardNumber, User, ApiCallType.BasicAuth, null, true, basicauthtoken: baseAouthString);
                            var autoTopupResponse = await Api.CallApi(_endPoints.THCCWebApiEndPoint +
                                               "Pay360Account/GetAutoTopup", User, ApiCallType.BasicAuth, new Pay360GetAutoTopUpRequest()
                                               {
                                                   Msisdn = model.AccountNumber,
                                                   Email = model.Email,
                                                   ProductCode = ProductType.THCC.ToString()
                                               }, basicauthtoken: baseAouthString);
                            if (autoTopupResponse.IsSuccessStatusCode)
                            {
                                var autoTopupResponseJson = JObject.Parse(autoTopupResponse.Content.ReadAsStringAsync().Result);
                                int autoTopupErrorCode = autoTopupResponseJson.GetValue("errorCode").ToObject<int>();
                                if (errorCode == 0)
                                {
                                    var payload = autoTopupResponseJson.GetValue("payload").ToObject<Pay360GetAutoTopUpResponse>();
                                    if (model.IsAutoTopup == true && payload.Status == false)
                                    {
                                        await Api.CallApi(_endPoints.THCCWebApiEndPoint + "Pay360Account/SetAutoTopUp", User, ApiCallType.Bearer, model: new Pay360SetAutoTopUpRequest()
                                        {
                                            productRef = model.AccountNumber,
                                            productCode = "THCC",
                                            productItemCode = "THRCC",
                                            isAutoTopup = true,
                                            thresholdBalanceAmount = 1,
                                            topupAmount = 5,
                                            TopupCurrency = "GBP",
                                            Email = model.Email
                                        });
                                    }
                                    else if (model.IsAutoTopup == false && payload.Status == true)
                                    {
                                        await Api.CallApi(_endPoints.THCCWebApiEndPoint + "Pay360Account/SetAutoTopUp", User, ApiCallType.Bearer, model: new Pay360SetAutoTopUpRequest()
                                        {
                                            productRef = model.AccountNumber,
                                            productCode = "THCC",
                                            productItemCode = "THRCC",
                                            isAutoTopup = false,
                                            thresholdBalanceAmount = 1,
                                            topupAmount = 5,
                                            TopupCurrency = "GBP",
                                            Email = model.Email
                                        });
                                    }
                                }
                            }
                        }

                        if (model.Type == "TopUp" || model.Type == "THRCCNC") //Get Account Summary
                        {
                            var AccountResult = await Api.CallApi(_endPoints.THCCWebApiEndPoint + "Account/AccountSummaryByAccountNumber/" +
                                                        Secure3Dpayload.CardNumber, User, ApiCallType.BasicAuth, null, true, basicauthtoken: baseAouthString);
                            if (AccountResult.IsSuccessStatusCode)
                            {
                                var resultJson = JObject.Parse(AccountResult.Content.ReadAsStringAsync().Result);
                                int accountErrorCode = resultJson.GetValue("errorCode").ToObject<int>();
                                if (accountErrorCode == 0)
                                {
                                    var payload = resultJson.GetValue("payload").ToObject<AccountSummery>();
                                    if (payload != null)
                                    {
                                        Secure3Dpayload.NewBalnce = payload.credit;
                                        Secure3Dpayload.TotalPoints = payload.points;
                                    }
                                }
                            }
                        }

                        TempData.Put("SuccessModel", Secure3Dpayload);

                        return RedirectToAction("SuccessMessage", "Home", new { key = Secure3Dpayload.Key });
                    }
                    else
                    {

                        _logger.Information($"Class: Pay360, Method: securereturntopup-ErrorResponse, " +
                                            $"Request: {JsonConvert.SerializeObject(secure3DModel)} , " +
                                            $"Response: {JsonConvert.SerializeObject(paymentResponseJson)}");

                        //Need to handle error code values
                        return HandleErrorResponse<Secure3DViewModel>(model, errorCode,
                                                    paymentResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: Pay360Controller, Method: securereturntopup, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("StartPay360Payment")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> StartPay360Payment(CheckoutViewModel model)
        {
            try
            {
                if (!string.IsNullOrEmpty(model.UserCard.Token))
                {
                    ModelState.Remove("UserCard.CardNumber");
                    ModelState.Remove("UserCard.NameOnCard");
                    ModelState.Remove("UserCard.ExpiryYear");
                    ModelState.Remove("UserCard.ExpiryMonth");
                    ModelState.Remove("UserCard.SecurityCode");
                    ModelState.Remove("BillingAddress.AddressL1");
                    ModelState.Remove("BillingAddress.CountryCode");
                    ModelState.Remove("PostCode");
                    ModelState.Remove("RechargePIN");
                }
                else
                {
                    ModelState.Remove("BillingAddress.AddressL1");
                    ModelState.Remove("UserCard.Token");
                    ModelState.Remove("PostCode");
                    ModelState.Remove("SecurityCode");
                    ModelState.Remove("RechargePIN");
                }

                if (User.Identity.IsAuthenticated)
                {
                    model.IsAuthenticated = true;
                    model.UniqueRef = User.Claims.Where(x => x.Type == ClaimTypes.Email).FirstOrDefault().Value;

                    if (string.IsNullOrEmpty(model.EmailAddress))
                    {
                        ModelState.Remove("EmailAddress");
                        model.EmailAddress = User.Claims.Where(x => x.Type == ClaimTypes.Email).FirstOrDefault().Value;
                    }
                }
                else
                {
                    model.UniqueRef = model.EmailAddress;
                }

                model.ipAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext);

                if (!ModelState.IsValid)
                {
                    return BadRequest();
                }

                var Enpoint = model.Pay360PaymentType == Pay360PaymentType.New ? "NewCustomerPayment" : model.Pay360PaymentType == Pay360PaymentType.Token ? "ExistingCardPayment" : model.Pay360PaymentType == Pay360PaymentType.ExistingNew ? "NewCardPayment" : "";
                var paymentResponse = await Api.CallApi(_endPoints.THCCWebApiEndPoint +
                                        "Pay360Account/" + Enpoint, User, ApiCallType.BasicAuth, model, basicauthtoken: baseAouthString);


                _logger.Information($"Class: Pay360, Method: StartPay360Payment-Response, " +
                                    $"Status Code: {paymentResponse.StatusCode}, " +
                                    $"Message: {paymentResponse.ReasonPhrase} " +
                                    $"Request: {JsonConvert.SerializeObject(model)}");


                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var Directpayload = paymentResponseJson.GetValue("payload").ToObject<Pay360PaymentResponseModel>().directPaymentData;

                        //Set AutoTopup
                        if (Directpayload.Key == ProductType.TopUp.ToString() && User.Identity.IsAuthenticated)
                        {
                            var autoTopupResponse = await Api.CallApi(_endPoints.THCCWebApiEndPoint +
                                                    "Pay360Account/GetAutoTopup", User, ApiCallType.BasicAuth, new Pay360GetAutoTopUpRequest()
                                                    {
                                                        Msisdn = User.Claims.Where(x => x.Type == "AccountNumber").FirstOrDefault().Value,
                                                        Email = User.Claims.Where(x => x.Type == ClaimTypes.Email).FirstOrDefault().Value,
                                                        ProductCode = ProductType.THCC.ToString()
                                                    }, basicauthtoken: baseAouthString);
                            if (autoTopupResponse.IsSuccessStatusCode)
                            {
                                var autoTopupResponseJson = JObject.Parse(autoTopupResponse.Content.ReadAsStringAsync().Result);
                                int autoTopupErrorCode = autoTopupResponseJson.GetValue("errorCode").ToObject<int>();
                                if (errorCode == 0)
                                {
                                    var payload = autoTopupResponseJson.GetValue("payload").ToObject<Pay360GetAutoTopUpResponse>();
                                    if (model.IsAutoToupEnabled == true && payload.Status == false)
                                    {
                                        await Api.CallApi(_endPoints.THCCWebApiEndPoint + "Pay360Account/SetAutoTopUp", User, ApiCallType.BasicAuth, model: new Pay360SetAutoTopUpRequest()
                                        {
                                            productRef = User.Claims.Where(x => x.Type == "AccountNumber").FirstOrDefault().Value,
                                            productCode = "THCC",
                                            productItemCode = "THRCC",
                                            isAutoTopup = true,
                                            thresholdBalanceAmount = 1,
                                            topupAmount = 5,
                                            TopupCurrency = "GBP",
                                            Email = User.Claims.Where(x => x.Type == ClaimTypes.Email).FirstOrDefault().Value
                                        }, basicauthtoken: baseAouthString);
                                    }
                                    else if (model.IsAutoToupEnabled == false && payload.Status == true)
                                    {
                                        await Api.CallApi(_endPoints.THCCWebApiEndPoint + "Pay360Account/SetAutoTopUp", User, ApiCallType.BasicAuth, model: new Pay360SetAutoTopUpRequest()
                                        {
                                            productRef = User.Claims.Where(x => x.Type == "AccountNumber").FirstOrDefault().Value,
                                            productCode = "THCC",
                                            productItemCode = "THRCC",
                                            isAutoTopup = false,
                                            thresholdBalanceAmount = 1,
                                            topupAmount = 5,
                                            TopupCurrency = "GBP",
                                            Email = User.Claims.Where(x => x.Type == ClaimTypes.Email).FirstOrDefault().Value
                                        }, basicauthtoken: baseAouthString);
                                    }
                                }
                            }
                        }

                        //Get New balance and Total points for success page
                        if (Directpayload.Key == ProductType.TopUp.ToString() || Directpayload.Key == ProductType.THRCCNC.ToString())
                        {
                            var AccountResult = await Api.CallApi(_endPoints.THCCWebApiEndPoint + "Account/AccountSummaryByAccountNumber/" + Directpayload.CardNumber, User, ApiCallType.BasicAuth, null, true, basicauthtoken: baseAouthString);
                            if (AccountResult.IsSuccessStatusCode)
                            {
                                var resultJson = JObject.Parse(AccountResult.Content.ReadAsStringAsync().Result);
                                int accountErrorCode = resultJson.GetValue("errorCode").ToObject<int>();
                                if (accountErrorCode == 0)
                                {
                                    var payload = resultJson.GetValue("payload").ToObject<AccountSummery>();
                                    if (payload != null)
                                    {
                                        Directpayload.NewBalnce = payload.credit;
                                        Directpayload.TotalPoints = payload.points;
                                    }
                                }
                            }
                        }

                        //Add response to success page model
                        TempData.Put("SuccessModel", Directpayload);



                        return RedirectToAction("SuccessMessage", "Home", new { key = Directpayload.Key });

                    }
                    else if (errorCode == (int)ApiStatusCodes.Pending3dSecure)// 3DSecure Scenario
                    {

                        var payload = paymentResponseJson.GetValue("payload").ToObject<Pay360PaymentResponseModel>().threeDSecureData;

                        #region Protect Retrun Url using data protection API 

                        var BaseUrl = payload.returnUrl.Split('?')[0];
                        var QueryString = payload.returnUrl.Split('?')[1];

                        //Convert string queted query string to json 
                        var collection = HttpUtility.ParseQueryString(QueryString);
                        var JsonQueryString = JsonConvert.SerializeObject(collection.AllKeys.ToDictionary(y => y, y => collection[y]));

                        // Protect the Json Query String
                        string encriptedQueryString = _dataProtector.Protect(JsonQueryString);

                        //Created Protected return Url
                        payload.returnUrl = BaseUrl + "?Id=" + encriptedQueryString;

                        #endregion

                        var transactionViewModel = new Pay360TransactionViewModel
                        {
                            url = payload.redirectUrl,
                            pareq = payload.pareq,
                            TransactionId = payload.transactionId,
                            returnUrl = payload.returnUrl
                        };

                        return View("~/Views/Account/Redirect3dSecure.cshtml", transactionViewModel);
                    }


                    _logger.Information($"Class: Pay360, Method: StartPay360Payment-ErrorResponse, " +
                                     $"Request: {JsonConvert.SerializeObject(model)} , " +
                                     $"Response: {JsonConvert.SerializeObject(paymentResponseJson)}");

                    //Need to handle error code values
                    return HandleErrorResponse<CheckoutViewModel>(model, errorCode,
                                                                paymentResponseJson.GetValue("message").ToObject<string>());
                }
                else if (paymentResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Classs:Pay360Controller, Method: StartPay360Payment," +
                    $"ErrorMessage:{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}," +
                    $"StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("GetAutoTopup")]

        public async Task<IActionResult> GetAutoTopup(Pay360GetAutoTopUpRequest model)
        {
            try
            {
                if (!User.Identity.IsAuthenticated)
                {
                    return Unauthorized();
                }
                model.Msisdn = User.Claims.Where(x => x.Type == "AccountNumber").FirstOrDefault().Value;
                model.Email = User.Claims.Where(x => x.Type == ClaimTypes.Email).FirstOrDefault().Value;
                model.ProductCode = "THCC";
                var response = await Api.CallApi(_endPoints.THCCWebApiEndPoint + "Pay360Account/getautotopup", User, ApiCallType.BasicAuth, model, GetRequest: false, basicauthtoken: baseAouthString);
                if (response.IsSuccessStatusCode)
                {

                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                    {
                        var payload = responseJson.GetValue("payload").ToObject<Pay360GetAutoTopUpResponse>();
                        return Json(new { errorCode = 0, payload });
                    }
                    else
                    {

                        return StatusCode((int)ApiStatusCodes.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)ApiStatusCodes.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Pay360Controller, Method: getautotopup, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }
        [HttpPost]
        [Route("setautotopup")]
        public async Task<IActionResult> SetAutoTopup(Pay360SetAutoTopUpRequest model)
        {
            try
            {
                if (model.thresholdBalanceAmount > 30)
                {
                    return Json(new { errorCode = 1, Message = " Balance Threshold amount should be less then 30" });
                }

                var response = await Api.CallApi(_endPoints.THCCWebApiEndPoint + "Pay360Account/SetAutoTopUp", User, ApiCallType.BasicAuth, model: new Pay360SetAutoTopUpRequest()
                {
                    productRef = User.Claims.Where(x => x.Type == "AccountNumber").FirstOrDefault().Value,
                    productCode = "THCC",
                    productItemCode = "THRCC",
                    isAutoTopup = model.isAutoTopup,
                    thresholdBalanceAmount = (int)model.thresholdBalanceAmount,
                    topupAmount = model.topupAmount,
                    TopupCurrency = "GBP",
                    Email = User.Claims.Where(x => x.Type == ClaimTypes.Email).FirstOrDefault().Value
                }, basicauthtoken: baseAouthString);
                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    string message = responseJson.GetValue("payload").ToObject<string>();

                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                    {
                        return Json(new { errorCode = 0, Message = message });
                    }
                    else
                    {
                        return Json(new { errorCode = 1, Message = "Internal Server Error" });
                    }
                }
                else
                {
                    return Json(new { errorCode = 1, Message = "Internal Server Error" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Pay360Controller, Method: SetAutoTopup, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }
    }
}
