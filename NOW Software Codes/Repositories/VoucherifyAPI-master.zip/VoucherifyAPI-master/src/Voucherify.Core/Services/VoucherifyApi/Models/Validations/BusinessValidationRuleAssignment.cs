using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Validations;

public class BusinessValidationRuleAssignment
{
    [JsonPropertyName("rule_id")]
    public string? RuleId { get; set; }

    [JsonPropertyName("related_object_id")]
    public string? RelatedObjectId { get; set; }

    [JsonPropertyName("related_object_type")]
    public string? RelatedObjectType { get; set; }
}
