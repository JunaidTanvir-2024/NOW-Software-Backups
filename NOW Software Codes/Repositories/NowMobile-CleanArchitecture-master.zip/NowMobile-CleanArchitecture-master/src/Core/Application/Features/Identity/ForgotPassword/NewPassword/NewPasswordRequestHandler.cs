﻿using Application.Common.Caching;
using Application.Common.Interfaces.Infrastructure.Identity;

namespace Application.Features.Identity.ForgotPassword.NewPassword;
public class NewPasswordHandler : IRequestHandler<NewPasswordRequest, Result<object>>
{
    #region Fields

    private readonly IOtpService _otpService;
    private readonly IStringLocalizer<NewPasswordHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;

    #endregion

    #region Ctor

    public NewPasswordHandler(
        IOtpService otpService,
        IStringLocalizer<NewPasswordHandler> localizer,
        IUnitOfWork unitOfWork,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService
       )
    {
        _otpService = otpService;
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _cacheService = cacheService;
        _cacheKeyService = cacheKeyService;
    }

    #endregion

    #region Methods

    public async Task<Result<object>> Handle(NewPasswordRequest request, CancellationToken cancellationToken)
    {
        //Check user for any type of deactivation


        var userReponse = await _unitOfWork.UserRepo.GetUserByEmail(request.Email);
        if (userReponse == null)
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.AccountNotRegistered], CustomStatusCode.AccountNotRegistered);
        }

        var emailOtpResponse = await _otpService.VerifyOtp(request.Otp, request.Email, OtpType.ForgotPassword, true);
        if (emailOtpResponse.Code == CustomStatusCode.InvalidOtp)
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.InvalidOtp], CustomStatusCode.InvalidOtp);
        }

        await _unitOfWork.UserRepo.ChangePassword(new User()
        {
            Id = userReponse.Id,
            Password = CryptoHelper.Hash(request.Password),
        });


        //Clear cahe beacuse user password updated
        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, userReponse.Email), cancellationToken);
        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, userReponse.Id.ToString()), cancellationToken);
        var userProducts = await _unitOfWork.UserRepo.GetUserProducts(userReponse.Id);
        if (userReponse != null && userProducts.Any())
        {
            foreach (var item in userProducts)
            {
                await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, item.Msisdn!), cancellationToken);
            }
        }
        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }

    #endregion

}