﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Database
{
    public class THACustomerChargeValuesForReplacement
    {
        public List<THACustomerChargeValueForReplacement> chargeValues = new List<THACustomerChargeValueForReplacement>();
    }
    public class THACustomerChargeValueForReplacement
    {
        public decimal buying_price { get; set; }
        public decimal selling_price { get; set; }
        public decimal received_amount { get; set; }
    }

    public class COMM_ATT_CustomerChargeValuesForReplacement
    {
        public List<COMM_ATT_CustomerChargeValueForReplacement> chargeValues = new List<COMM_ATT_CustomerChargeValueForReplacement>();
    }

    public class COMM_ATT_CustomerChargeValueForReplacement
    {
        public decimal buying_price { get; set; }
        public decimal selling_price { get; set; }
        public decimal received_amount { get; set; }
    }
}
