namespace DC.Core.Common.Entities;

public sealed record ActiveMsisdnEntity
{
    public DateTime ActiveDate { get; set; }
    public string AccountId { get; set; }
    public string Msisdn { get; set; }
    public bool IsFulfilled { get; set; }
    public bool IsActive { get; set; }
    public DateTime SimStateUpdated { get; set; }
    public string SimState { get; set; }
    public DateTime CreatedOn { get; set; }
    public string CreatedBy { get; set; }
    public DateTime ModifiedOn { get; set; }
    public string ModifiedBy { get; set; }

    public string Product { get; set; }

}

