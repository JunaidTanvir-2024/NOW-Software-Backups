﻿
namespace Application.Common.Settings;
public class OtpSettings
{
    public const string SectionName = "OtpSettings";
    public static OtpSettings Bind { get; set; } = new OtpSettings();
    public bool Otpverification { get; set; }
    public int OtpExpirationInMinutes { get; set; }
    public int OtpRetryLimit { get; set; }
    public int OtpDisableTimeInMinutes { get; set; }
    public int OtpCreationLimit { get; set; }
}