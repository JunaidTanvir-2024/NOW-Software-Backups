﻿namespace THCC.Infrastructure.Services.Mailing.External.Models;

public class AddEmailRequest
{
    public string Subject { get; set; } = default!;
    public string Body { get; set; } = default!;
    public string FromEmail { get; set; } = default!;
    public string FromName { get; set; } = default!;
    public byte Priority { get; set; }
    public List<RecipientsInfo> Recipients { get; set; } = new List<RecipientsInfo>();
    public string ProductCode { get; set; } = default!;
}

public class RecipientsInfo
{
    public byte RecipientType { get; set; }
    public string EmailAddress { get; set; } = null!;
    public string? RecipientName { get; set; }
}