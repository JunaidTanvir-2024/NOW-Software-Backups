using Microsoft.AspNetCore.Mvc;

using Voucherify.Api.Features.Vouchers.Requests;
using Voucherify.Core.Commons.Filters;

namespace Voucherify.Api.Features.Vouchers;

public static class VouchersEndpoints
{
    private const string EndpointPrefix = "/api/vouchers";
    private const string EndpointTag = "Vouchers Endpoints";

    public static void AddVouchersEndpoints(this WebApplication app)
    {
        var vouchersEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);

        vouchersEndpoints.MapGet("", GetVouchers)
            .AddEndpointFilter<FluentValidationFilter<GetVouchersRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        vouchersEndpoints.MapGet("/{voucherCodeOrId}", GetVoucher)
            .AddEndpointFilter<FluentValidationFilter<GetVoucherRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        vouchersEndpoints.MapDelete("/{voucherCodeOrId}", DeleteVoucher)
            .AddEndpointFilter<FluentValidationFilter<DeleteVoucherRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status204NoContent);

        vouchersEndpoints.MapPost("/validate", ValidateVoucher)
            .AddEndpointFilter<FluentValidationFilter<ValidateVoucherRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        vouchersEndpoints.MapPost("/redeem", RedeemVoucher)
            .AddEndpointFilter<FluentValidationFilter<RedeemVoucherRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);
    }
    private static async Task<IResult> GetVouchers(IVouchersHandler vouchersHandler, [AsParameters] GetVouchersRequest request)
    {
        var result = await vouchersHandler.GetVouchersList(request);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetVoucher(IVouchersHandler vouchersHandler, [AsParameters] GetVoucherRequest request)
    {
        var result = await vouchersHandler.GetSpecificVoucher(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> DeleteVoucher(IVouchersHandler vouchersHandler, [AsParameters] DeleteVoucherRequest request)
    {
        var result = await vouchersHandler.DeleteVoucher(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.BadRequest(result);
    }
    private static async Task<IResult> ValidateVoucher(IVouchersHandler vouchersHandler, [FromBody] ValidateVoucherRequest request)
    {
        var result = await vouchersHandler.VoucherValidation(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> RedeemVoucher(IVouchersHandler vouchersHandler, [FromBody] RedeemVoucherRequest request)
    {
        var result = await vouchersHandler.VoucherRedemption(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
}
