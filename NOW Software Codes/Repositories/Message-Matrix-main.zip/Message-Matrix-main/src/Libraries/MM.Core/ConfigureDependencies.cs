using MM.Core.Features.SMS;

using MM.Core.Common.Behaviors;
using MM.Core.Common.DependencyResolver;
using MM.Core.Features.SMS.Request; 

namespace MM.Core;

public static class ConfigureDependencies
{
    public static IServiceCollection AddCoreDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.AutoResolve();
        services.RegisterCoreServices();
        services.RegisterRequestValidators();
        return services;
    }

    private static IServiceCollection RegisterCoreServices(this IServiceCollection services)
    {
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
        services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));

        return services;
    }
    private static IServiceCollection RegisterRequestValidators(this IServiceCollection services)
    {
        services.AddScoped<IValidator<SendSMSRequest>, SendSMSRequestValidator>();
        return services;
    }
}
