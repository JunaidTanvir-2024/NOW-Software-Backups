namespace CancelBundleApi.Models.RequestModels;

public class UnSubscribeBundlesRequest
{
    public int SubscriberBundleId { get; set; }
    public string SubscriberId { set; get; }
}