﻿using THCC.Application.Settings;

namespace THCC.Application.Features.Payment.PayPal.CallingCard
{
    public class PaypalCallingCardRequest : IRequest<object>
    {
        public decimal Amount { get; set; }
    }

    public class CallingCardRequestValidator : AbstractValidator<PaypalCallingCardRequest>
    {
        public CallingCardRequestValidator(
            IOptions<TopupSettings> topupSettings)
        {
            RuleFor(p => p.Amount).Cascade(CascadeMode.Stop)
                .NotEmpty()
                .NotNull()
                .Must(x => topupSettings.Value.Amounts.Any(a => a.Amount == x))
                .WithMessage("Please only use: " + string.Join(",", values: topupSettings.Value.Amounts.Select(a => a.Amount)));
        }
    }
}
