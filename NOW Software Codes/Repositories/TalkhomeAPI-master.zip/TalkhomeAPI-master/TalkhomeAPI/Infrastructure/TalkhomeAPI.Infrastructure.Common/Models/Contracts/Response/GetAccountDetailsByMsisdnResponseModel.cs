﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class GetAccountDetailsByMsisdnResponseModel
    {
        public string Currency { get; set; }
        public string EmailAddress { get; set; }
    }
}
