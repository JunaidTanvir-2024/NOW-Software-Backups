﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NowPayG.Models.Porting
{
    public enum PortTypes
    {
        PortIn = 1,
        PortInNew = 2,
        PortOut = 3
    }
}
