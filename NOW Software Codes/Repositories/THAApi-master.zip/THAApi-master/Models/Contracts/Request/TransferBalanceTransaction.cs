﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{

    public class TransferBalanceRequest
    {
        public string SourceMsisdn { get; set; }

        public string TransferAmount { get; set; }

        public string DestinationMsisdn { get; set; }

        public string DestinationName { get; set; }
    }
    public class TransferBalanceTransaction
    {
        public TransferBalanceTransaction()
        {
            this.Source = new TransferBalanceParty();

            this.Destination = new TransferBalanceParty();
        }

        public string Id { get; set; }

        public TransferBalanceParty Source { get; set; }

        public TransferBalanceParty Destination { get; set; }

        public string FxRate { get; set; }
        public string advertiserID { get; set; }
        //public AppsFlyerInfo AppsFlyerInfo { get; set; }
        public string AppsFlyerId { get; set; }
        public int DeviceType { get; set; }
    }

    public class TransferBalanceParty
    {
        public string AccountId { get; set; }

        public string Msisdn { get; set; }

        public string Name { get; set; }

        public string Amount { get; set; }

        public string Currency { get; set; }
    }
}
