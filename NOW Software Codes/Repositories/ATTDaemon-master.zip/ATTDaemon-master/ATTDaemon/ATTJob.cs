﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ATTDaemon.Infrastructure.Repositories;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ATTDaemon.Models;
using System.Net.Http;
using System.Net;
using Newtonsoft.Json.Linq;
using ATTDaemon.Models.DB;

namespace ATTDaemon
{
    public class ATTJob : IJob
    {
        public async void Execute(IJobExecutionContext context)
        {
            IDaemonDB db = new DaemonDB();

            List<countries> listOfCountries = db.getCountries();

            foreach (countries contry in listOfCountries)
            {
                Task<String> HttpSochitelPostService = getHttpRequest("http://localhost:10021/getOperatorsAndProducts?country=" + contry.ISOCode2 + "&currency=GBP");
                string strResponseJSON = await HttpSochitelPostService;                 // Send request to Sochitel and receive JSON 

                JToken json = JObject.Parse(strResponseJSON);
                OperatorsAndProducts operatorsandproducts = json.ToObject<OperatorsAndProducts>();

                if(operatorsandproducts.errorCode == 0)
                {
                    foreach(operators op in operatorsandproducts.payload.operators)
                    {
                        //insert or update operator record for this 
                        at_Operators operatorDBRec = db.getOperatorRecord(op.id, 1, "EUR");
                        if (operatorDBRec == null)
                        {
                            db.insertOperator(op.id, 1, "EUR", op.name, contry.CountryID, op.iconUri, op.isFixed);
                            operatorDBRec = db.getOperatorRecord(op.id, 1, "EUR");
                        }

                        if (op.products.Count > 0)
                        {
                            //delete rates of this operator
                            db.deleteOperatorRatesRecords(operatorDBRec.operatorRecordID);

                            foreach (productdata prod in op.products)
                            {
                                //now insert products data in DB
                                db.insertOperatorProductRate(operatorDBRec.operatorRecordID, float.Parse(prod.transactionfeeClientccy), float.Parse(prod.itemPriceClientccy), float.Parse(prod.totalPriceClientccy), prod.clientccy, prod.receiverccy, prod.product);
                            }
                        }
                    }
                }
                else
                {
                    //for some reason the request could not be processed  
                }

            }

        }







        private async Task<string> getHttpRequest(string url)
        {
            HttpClient SochitelHttpClient = new HttpClient();

            //SochitelHttpClient.BaseAddress = new Uri(url);

            string returnData = "";
            try
            {
                var httpResponse = await SochitelHttpClient.GetAsync(url);

                if (httpResponse.Content != null)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    Exception ex = new Exception($"Sochitel API Call Exception - Empty Contents Received");
                    throw ex;
                }
            }
            catch (WebException wex)
            {
                //_loggerExternalAPIExceptions.Debug($"\"Post  Sochitel API Web Access\"     Failed      Message:{wex.ToString()}");
                throw wex;
            }
            catch (Exception ex)
            {
                //_loggerExternalAPIExceptions.Debug($"\"Post  Sochitel API\"  Failed       Generasl Exception      Message:{ex.ToString()}");
                throw ex;
            }

            return returnData;
        }




    }
}
