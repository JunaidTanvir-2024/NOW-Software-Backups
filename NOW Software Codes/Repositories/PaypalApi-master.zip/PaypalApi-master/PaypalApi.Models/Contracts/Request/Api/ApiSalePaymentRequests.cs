﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Contracts.Request.Api
{
  

        public class ApiCreateSalePaymentRequest
        {

            [JsonProperty("intent")]
            public string Intent { get; set; } = "sale";

            [JsonProperty("redirect_urls")]            
            public RedirectUrls RedirectUrl { get; set; }

            [JsonProperty("payer")]            
            public Payers Payer { get; set; }

            [JsonProperty("transactions")]            
            public Transactions[] Transaction { get; set; }

        }

    public class ApiExecuteSalePaymentRequest
    {
        [JsonProperty("payer_id")]        
        public string PayerId { get; set; }

    }

    public class RedirectUrls
        {
            [JsonProperty("return_url")]            
            public string ReturnUrl { get; set; }

            [JsonProperty("cancel_url")]            
            public string CancelUrl { get; set; }
        }

        public class Transactions
        {
            [JsonProperty("amount")]
            public Amounts Amount { get; set; }

            [JsonProperty("invoice_number")]
            public string InvoiceNumber { get; set; }

            [JsonProperty("description")]
            public string Description { get; set; }

        }

        public class Amounts
        {
            [JsonProperty("total")]            
            public float Total { get; set; }

            [JsonProperty("currency")]           
            public string Currency { get; set; }
        }

        public class Payers
        {
        [JsonProperty("payment_method")]        
        public string PaymentMethod { get; set; } = "paypal";

        }         
    
}
