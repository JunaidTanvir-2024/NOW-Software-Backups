﻿using SmsOutReachCallBackUrlApi.Contracts.Sap.Request;
using SmsOutReachCallBackUrlApi.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SmsOutReachCallBackUrlApi.Infrastructure.Sap
{
    public interface ISapDb
    {
        Task<DbResult> AddSmsCallBackData(SapSmsCallBackRequest deliveryReport);
    }
}
