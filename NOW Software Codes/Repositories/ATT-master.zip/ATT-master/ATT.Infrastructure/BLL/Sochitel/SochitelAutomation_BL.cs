﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using System.Text;
using Serilog;
using ATT.Infrastructure.DAL;
using ATT.Infrastructure.BLL.TransferTo;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Sochitel.Response;
using ATT.Models.Database;
using ATT.Models.Configurations;
using Microsoft.Extensions.Options;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Newtonsoft.Json;

namespace ATT.Infrastructure.BLL.Sochitel
{
    public  class SochitelAutomation_BL : ISochitelAutomation_BL
    {
        private ISochiPost_BL _SochiTelPost;
        private ILogger _loggerAPIAccess;
        private IAttDb_DL _dbATT;
        private ITransfertoPost_BL _TransferToPost;
        private SochitelConfig SochitelConf;
        ISochiTelAuth_BL SochitelAuth;
        private readonly TwilioConfig TwilioConfig;


        public SochitelAutomation_BL(ISochiPost_BL post, ITransfertoPost_BL transferToPost, ILogger appLoggers, IAttDb_DL _db, IOptions<SochitelConfig> sochitelConf, ISochiTelAuth_BL sochitelAuth, IOptions<TwilioConfig> twilioConfig)
        {
            _SochiTelPost = post;
            _TransferToPost = transferToPost;
            _loggerAPIAccess = appLoggers;
            _dbATT = _db;
            SochitelConf = sochitelConf.Value;
            SochitelAuth = sochitelAuth;
            TwilioConfig = twilioConfig.Value;
        }

        #region GetFreeSwitchOperatorProducts

        public async Task<JsonOperatorProductResponse> GetFreeSwitchOperatorProducts(string sourceMSISDN, string destinationMSISDN, string account, string productCode, string productItemCode)
        {

            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 1;
            try
            {
                var GetPRoductStartTime = DateTime.Now;
                GenericApiResponse<OperatorProducts> sochitelOperatorProductsResponse = await _SochiTelPost.getOperatorProductsMSISDN(destinationMSISDN, account);
                var GetPRoductEndTime = DateTime.Now;

                if (sochitelOperatorProductsResponse.Status == 0)
                {
                    StringBuilder productsJSON = new StringBuilder();
                    productsJSON.Append("{");

                    PayLoad payload = new PayLoad();

                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;

                    // Range type product checking
                    if (sochitelOperatorProductsResponse.Result.products.Count > 0 && sochitelOperatorProductsResponse.Result.products.First().Value.priceType == "range")
                    {
                        decimal SochitelMinimumUserValue = decimal.Parse(sochitelOperatorProductsResponse.Result.products.First().Value.price.min.user.ToString());
                        decimal SochitelMaximumUserValue = decimal.Parse(sochitelOperatorProductsResponse.Result.products.First().Value.price.max.user.ToString());
                        decimal SOchitelMinMaxUserValueDifference = SochitelMaximumUserValue - SochitelMinimumUserValue;

                        decimal SochitelMinimumOperatorValue = decimal.Parse(sochitelOperatorProductsResponse.Result.products.First().Value.price.min.@operator.ToString());
                        decimal SochitelMaximumOperatorValue = decimal.Parse(sochitelOperatorProductsResponse.Result.products.First().Value.price.max.@operator.ToString());
                        decimal SochitelMinMaxOperatorValueDifference = SochitelMaximumOperatorValue - SochitelMinimumOperatorValue;

                        //Get TransferTo operator products
                        GenericApiResponse<string> transferToOperatorProducts = await _TransferToPost.getOperatorProductsMSISDN(destinationMSISDN, account);

                        int serviceProviderOperaorId = int.Parse(sochitelOperatorProductsResponse.Result.OperatorID);

                        // get product rates from database
                        //var enRates = await _dbATT.GetEndRates(serviceProviderOperaorId, account, 1, originDestinationId);

                        List<AttOperator> operators = new List<AttOperator>();
                        List<AttProduct> products = new List<AttProduct>();
                        AttOperator operatorDetails = new AttOperator();
                        string GUID = Guid.NewGuid().ToString();

                        // TransferTo products found.
                        if (transferToOperatorProducts.Status == 0)
                        {
                            XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                            xmlDoc.LoadXml(transferToOperatorProducts.Result); // Load the XML document from the specified file


                            XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                            if (xmlproductslist.Count == 0)
                            {
                                // return empty reply
                            }
                            string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                            XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                            string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                            XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                            string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');


                            operatorDetails.id = sochitelOperatorProductsResponse.Result.OperatorID;
                            operatorDetails.name = sochitelOperatorProductsResponse.Result.OperatorName;
                            operatorDetails.country = sochitelOperatorProductsResponse.Result.CountryName;
                            operatorDetails.nowtelTransactionReference = GUID;
                            operatorDetails.iconUri = sochitelOperatorProductsResponse.Result.OperatorLogo;

                            //int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                            //var enRates = await _dbATT.GetEndRates(2, operatorid, account);

                            for (int a = 0; a < productslist.Length; a++)
                            {
                                //include only those TransferTo products that has product values between min and max range of sochitel
                                if (decimal.Parse(retailpricelist[a]) >= SochitelMinimumUserValue && decimal.Parse(retailpricelist[a]) <= SochitelMaximumUserValue)
                                {
                                    decimal sochiCalculatedValue = Math.Round((((decimal.Parse(productslist[a]) - SochitelMinimumOperatorValue) / SochitelMinMaxOperatorValueDifference) * SOchitelMinMaxUserValueDifference) + SochitelMinimumUserValue, 2);


                                    decimal productValue = Convert.ToDecimal(productslist[a]);

                                   // var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                                    //if (endrate != null)
                                    //{

                                        products.Add(_dbATT.GetProduct(
                                        account,         //clientccy
                                        xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                        productslist[a],     //product
                                        sochiCalculatedValue.ToString(),  //itemPriceClientccy
                                        sochiCalculatedValue.ToString()   //totalPriceClientccy
                                                                    //endrate.CustomerChargeValue.ToString(),
                                                                    //endrate.CustomerChargeValue.ToString()
                                        ));

                                        productsJSON.Append($"\"{productslist[a]}\":\"{sochiCalculatedValue.ToString()}\", ");
                                    //}
                                }
                            }

                            productsJSON.Append("}");
                            operatorDetails.products = products;


                            DBResponse dbResult = new DBResponse();
                            //dbResult = await _dbATT.insertTransactionGUID(GUID, account, destinationMSISDN, productsJSON.ToString());
                            dbResult = await _dbATT.insertTransactionGUID_Trh(GUID, account, destinationMSISDN, productsJSON.ToString(),"","",1, sourceMSISDN, productItemCode, "", "", productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country, GetProductApiTime: (GetPRoductEndTime - GetPRoductStartTime).TotalMilliseconds);
                            if (dbResult.DBStatus == 1)
                            {

                                // Loop for inserting product access details
                                for (int i = 0; i < products.Count; i++)
                                {

                                    await _dbATT.insertaccessDetails(dbResult.InsertId,
                                        products[i].clientccy,
                                        products[i].receiverccy,
                                        products[i].product,
                                        products[i].totalPriceClientccy,
                                        products[i].totalPriceClientccy,
                                        0
                                    );
                                }

                                operatorDetails.accessid = dbResult.InsertId;
                                operators.Add(operatorDetails);
                                payload.operators = operators;
                                result.payload = payload;
                                //_loggerAPIAccess.Information($" \"GET /sochitelGetOperatorProductsMSISDN_Direct\"  Success    Parameters-msisdn:{destinationMSISDN} currency:{account}");
                                return result;
                            }
                            else
                            {
                                _loggerAPIAccess.Debug($" SochitelAutomation_BL  \"GET /GetFreeSwitchOperatorProducts\"  Failed  Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                                //var result1 = new { errorCode = 2, status = "Failure", message = " Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage };

                                result.message = "Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record . Exception: " + dbResult.DBErrorMessage;
                                result.status = "Failure";
                                result.errorCode = 2;
                                return result;
                            }
                        }

                        // if transfer 2 response not availble
                        else
                        {
                            string[] breakdownPercentages = SochitelConf.RangeToProductConversionPercentages.Split(',');

                            operatorDetails.id = sochitelOperatorProductsResponse.Result.OperatorID;
                            operatorDetails.name = sochitelOperatorProductsResponse.Result.OperatorName;
                            operatorDetails.country = sochitelOperatorProductsResponse.Result.CountryName;
                            operatorDetails.nowtelTransactionReference = GUID;
                            operatorDetails.iconUri = sochitelOperatorProductsResponse.Result.OperatorLogo;

                            //int operatorid = int.Parse(sochitelOperatorProductsResponse.Result.OperatorID);

                            // var enRates = await _dbATT.GetEndRates(1, operatorid, account);

                            foreach (string percent in breakdownPercentages)
                            {
                                decimal percentValue = decimal.Parse(percent) / 100;

                                decimal productValue = Math.Round(((SochitelMinMaxOperatorValueDifference * percentValue) + SochitelMinimumOperatorValue), 2);

                                //var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                                //if (endrate != null)
                                //{

                                    products.Add(_dbATT.GetProduct(
                                    account,         //clientccy
                                    sochitelOperatorProductsResponse.Result.currency.@operator,    //receiverccy
                                    Math.Round(((SochitelMinMaxOperatorValueDifference * percentValue) + SochitelMinimumOperatorValue), 2).ToString(),     //product
                                    Math.Round(((SOchitelMinMaxUserValueDifference * percentValue) + SochitelMinimumUserValue), 2).ToString(),  //itemPriceClientccy
                                    Math.Round(((SOchitelMinMaxUserValueDifference * percentValue) + SochitelMinimumUserValue), 2).ToString()   //totalPriceClientccy
                                                                                                                                                            //endrate.CustomerChargeValue.ToString(),
                                                                                                                                                            //endrate.CustomerChargeValue.ToString()
                                    ));

                                    productsJSON.Append($"\"{Math.Round(((SochitelMinMaxOperatorValueDifference * percentValue) + SochitelMinimumOperatorValue), 2).ToString()}\":\"{Math.Round(((SOchitelMinMaxUserValueDifference * percentValue) + SochitelMinimumUserValue), 2).ToString()}\", ");
                                //}
                            }

                            productsJSON.Append("}");

                            operatorDetails.products = products;

                            DBResponse dbResult = new DBResponse();
                            //dbResult = await _dbATT.insertTransactionGUID(GUID, account, destinationMSISDN, productsJSON.ToString());
                            dbResult = await _dbATT.insertTransactionGUID_Trh(GUID, account, destinationMSISDN, productsJSON.ToString(),"","",1, sourceMSISDN, productItemCode, "", "", productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country,GetProductApiTime: (GetPRoductEndTime - GetPRoductStartTime).TotalMilliseconds);
                            if (dbResult.DBStatus == 1)
                            {

                                for (int i = 0; i < products.Count; i++)
                                {

                                    await _dbATT.insertaccessDetails(dbResult.InsertId,
                                        products[i].clientccy,
                                        products[i].receiverccy,
                                        products[i].product,
                                        products[i].totalPriceClientccy,
                                        products[i].totalPriceClientccy,
                                        0
                                    );
                                }
                                operatorDetails.accessid = dbResult.InsertId;
                                operators.Add(operatorDetails);
                                payload.operators = operators;
                                result.payload = payload;
                                //_loggerAPIAccess.Information($" \"GET /sochitelGetOperatorProductsMSISDN_Direct\"  Success    Parameters-msisdn:{destinationMSISDN} currency:{account}");
                                return result;
                            }
                            else
                            {
                                _loggerAPIAccess.Debug($"SochitelAutomation_BL  \"GET /GetFreeSwitchOperatorProducts\"  Failed  Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");
                                //var result1 = new { errorCode = 2, status = "Failure", message = " Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage };

                                result.message = "Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                                result.status = "Failure";
                                result.errorCode = 2;
                                return result;


                            }

                        }
                    }
                    else
                    {

                        AttOperator attOperator = await convertProducts_Direct(sochitelOperatorProductsResponse.Result, account, destinationMSISDN, true, sourceMSISDN, productCode, productItemCode);
                        List<AttOperator> operators = new List<AttOperator>();
                        operators.Add(attOperator);
                        payload.operators = operators;
                        result.payload = payload;
                        //_loggerAPIAccess.Information($" \"GET /sochitelGetOperatorProductsMSISDN_Direct\"  Success    Parameters-msisdn:{destinationMSISDN} currency:{account}");
                        return result;

                    }


                }
                else
                {
                    //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                    _loggerAPIAccess.Debug($" SochitelAutomation_BL  \"GET /GetFreeSwitchOperatorProducts\"  Failed  Source:Sochitel API        Parameters-msisdn:{destinationMSISDN}  currency:{account}       Reason-{sochitelOperatorProductsResponse.Message}");

                    // var result = new { errorCode = 1, status = "Failure", message = sochitelOperatorProductsResponse.Message };

                    result.message = sochitelOperatorProductsResponse.Message;
                    result.status = "Failure";
                    result.errorCode = 1;
                    return result;


                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"SochitelAutomation_BL  \"GET /GetFreeSwitchOperatorProducts\"  Failed  Source:General  Parameters-msisdn:{destinationMSISDN} currency:{account}    Message:{ex.ToString()}");

                //var result = new { errorCode = 1, status = "Failure", message = ex.ToString() };
                //return Json(result);

                result.message = ex.ToString();
                result.status = "Failure";
                result.errorCode = 1;
                return result;


            }
        }

        async public Task<AttOperator> convertProducts_Direct(OperatorProducts operatorProductsResponse, string account, string destinationMSISDN, bool insertAPIReferenceInDB, string sourceMSISDN, string productCode, string productItemCode)
        {


            List<AttProduct> products = new List<AttProduct>();
            string GUID = Guid.NewGuid().ToString();
            AttOperator operatorDetails = new AttOperator();
            operatorDetails.id = operatorProductsResponse.OperatorID;
            operatorDetails.name = operatorProductsResponse.OperatorName;
            operatorDetails.country = operatorProductsResponse.CountryName;
            operatorDetails.nowtelTransactionReference = GUID;
            operatorDetails.iconUri = operatorProductsResponse.OperatorLogo;

            DBResponse dbResult = new DBResponse();
            if (insertAPIReferenceInDB == true)
            {
                //dbResult = await _dbATT.insertTransactionGUID(GUID, account, msisdn, "{}");
                dbResult = await _dbATT.insertTransactionGUID_Trh(GUID, account, destinationMSISDN, "{}","","",1, sourceMSISDN, productItemCode, "", "", productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country);
                operatorDetails.accessid = dbResult.InsertId;
            }


            int serviceProviderOperaorId = int.Parse(operatorProductsResponse.OperatorID);

           // var enRates = await _dbATT.GetEndRates(serviceProviderOperaorId, account, 1, originDestinationId);

            StringBuilder productsJSON = new StringBuilder();
            productsJSON.Append("{");
            foreach (KeyValuePair<string, Product> product in operatorProductsResponse.products)
            {

                int productid = int.Parse(product.Value.id);
                decimal productValue = Convert.ToDecimal(product.Value.price.@operator);

                //var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                //if (endrate != null)
                //{
                    if (product.Value.priceType == "fixed")
                    {

                        products.Add(_dbATT.GetProduct(
                            operatorProductsResponse.currency.user,         //clientccy
                            operatorProductsResponse.currency.@operator,    //receiverccy
                            product.Value.price.@operator,     //product
                            product.Value.price.user,  //itemPriceClientccy
                            product.Value.price.user   //totalPriceClientccy
                                                   //endrate.CustomerChargeValue.ToString(),  //itemPriceClientccy
                                                   //endrate.CustomerChargeValue.ToString()   //totalPriceClientccy

                        ));                  

                    int accessId = operatorDetails.accessid;


                        await _dbATT.insertaccessDetails(accessId,
                            operatorProductsResponse.currency.user.ToString(),
                            operatorProductsResponse.currency.@operator.ToString(),
                            product.Value.price.@operator.ToString(),
                            product.Value.price.user,  //itemPriceClientccy
                            product.Value.price.user,  //totalPriceClientccy
                            //endrate.CustomerChargeValue.ToString(),
                            //endrate.CustomerChargeValue.ToString(),
                            productid
                            );

                        productsJSON.Append($"\"{product.Value.price.@operator}\":\"{product.Value.price.user}\", ");
                    }
                    
                //}

            }

            productsJSON.Append("}");
            operatorDetails.products = products;
            if (insertAPIReferenceInDB == true)
            {

                await _dbATT.updateProductsJSONOfGUID(GUID, productsJSON.ToString());
            }


            return operatorDetails;
        }

        #endregion GetFreeSwitchOperatorProducts


        #region FreeSwitch_Execute

        public async Task<object> FreeSwitch_Execute(ExecuteData data)
        {

            try
            {

                string nowtelTransactionReference = data.nowtelTransactionReference;
                string operatorid = data.operatorid.ToString();
                string operatorProduct = data.product;
                string messageToRecipient = data.messageToRecipient;
                string fromMSISDN = data.fromMSISDN;
                string product = "";

                //APIAccessGUID guidReferneceRecord = await _dbATT.getTransactionGUIDRecord(nowtelTransactionReference, operatorProduct);
                APIAccessGUID_Trh guidReferneceRecord = await _dbATT.getTransactionGUIDRecord_Trh(nowtelTransactionReference, operatorProduct);

                product = guidReferneceRecord.CustomerChargeValue.ToString();                

                if (guidReferneceRecord == null)
                {
                    _loggerAPIAccess.Debug($"SochitelAutomation_BL  \"GET /FreeSwitch_Execute\"  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return result;
                }
                string[] Credentials = SochitelAuth.GetSochitelAttCredentials(guidReferneceRecord.account);

                string transactionReference = Guid.NewGuid().ToString("N").ToUpper();
                transactionReference = transactionReference.Substring(0, 30);
                try
                {
                    var TopUpApiStartTime = DateTime.Now;
                    GenericApiResponse<ExecTransaction> execTransactionResponse = await _SochiTelPost.execTransaction(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, transactionReference);
                    var TopUpApiEndTime = DateTime.Now;

                    if (execTransactionResponse.Status == 0)
                    {
                        try
                        {
                            //Successful transaction                           

                            await _dbATT.insertAirTimeTransferTransaction_Trh(
                                DateTime.Now.ToString(),
                                Credentials[0],  // Sochitel Username
                                guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                                execTransactionResponse.Result.amount.user,   // Actual Charge Value
                                execTransactionResponse.Result.amount.@operator,
                                execTransactionResponse.Result.currency.user,
                                execTransactionResponse.Result.currency.@operator,
                                execTransactionResponse.Result.country.name,
                                "Success",
                                "",
                                execTransactionResponse.Result.@operator.id.ToString(),
                                execTransactionResponse.Result.productId.ToString(),
                                execTransactionResponse.Result.@operator.name,
                                execTransactionResponse.APITransactionReference,
                                execTransactionResponse.ATTTransactionReference,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                1,
                                messageToRecipient,
                                guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                nowtelTransactionReference,
                                 $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}",
                                JsonConvert.SerializeObject(execTransactionResponse.Result),
                                TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                );


                            //await
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"SochitelAutomation_BL  \"GET /FreeSwitch_Execute\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }

                        _loggerAPIAccess.Information($"SochitelAutomation_BL  \"GET /FreeSwitch_Execute\"   Success    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   SochiReference-{execTransactionResponse.ATTTransactionReference}       APIReference-{execTransactionResponse.APITransactionReference}");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.CustomerChargeValue,      // Customer Charge Value
                            currency = execTransactionResponse.Result.currency.user,
                            reference = execTransactionResponse.ATTTransactionReference

                        };

                        if (SochitelConf.SendSmsToSender)
                        {
                            var smsToSend = SochitelConf.SmsTemplate
                                .Replace("#currency#", execTransactionResponse.Result.currency.@operator)
                                .Replace("#amount#", data.product)
                                .Replace("#to#", guidReferneceRecord.tomsisdn)
                                .Replace("#TransRef#", execTransactionResponse.ATTTransactionReference);
                             SendTwilioSms(data.fromMSISDN, smsToSend);
                        }

                        return result;
                    }
                    else if (execTransactionResponse.Status == 1)
                    {
                        try
                        {
                            //Pending transaction                          

                            await _dbATT.insertAirTimeTransferTransaction_Trh(
                               DateTime.Now.ToString(),
                               Credentials[0],  // Sochitel Username
                               guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                               execTransactionResponse.Result.amount.user,   // Actual Charge Value
                               execTransactionResponse.Result.amount.@operator,
                               execTransactionResponse.Result.currency.user,
                               execTransactionResponse.Result.currency.@operator,
                               execTransactionResponse.Result.country.name,
                               "Pending",
                               "",
                               execTransactionResponse.Result.@operator.id.ToString(),
                               execTransactionResponse.Result.productId.ToString(),
                               execTransactionResponse.Result.@operator.name,
                               execTransactionResponse.APITransactionReference,
                               execTransactionResponse.ATTTransactionReference,
                               fromMSISDN,
                               guidReferneceRecord.tomsisdn,
                               1,
                               messageToRecipient,
                               guidReferneceRecord.productCode,
                               guidReferneceRecord.ProductItemCode,
                               nowtelTransactionReference,
                                $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}",
                                JsonConvert.SerializeObject(execTransactionResponse.Result)
                               );
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"SochitelAutomation_BL  \"POST /FreeSwitch_Execute\"  Database error occured while registering the Pending transaction    Exception {ex.ToString()} ");
                        }

                        _loggerAPIAccess.Information($"SochitelAutomation_BL  \"POST /FreeSwitch_Execute\"    Pending   Pasameters:   tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   SochiReference-{execTransactionResponse.ATTTransactionReference}       APIReference-{execTransactionResponse.APITransactionReference}");
                        var result = new { errorCode = 1, status = "Pending", message = "Your transaction is pending" };
                        return result;
                    }
                    else //Error
                    {
                        try
                        {
                            // Error

                            await _dbATT.insertAirTimeTransferTransaction_Trh(
                              DateTime.Now.ToString(),
                              Credentials[0],  // Sochitel Username
                              guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                              decimal.Parse(product),   // Actual Charge Value
                              decimal.Parse(operatorProduct),
                              guidReferneceRecord.account,
                               "",
                               "",
                              "Failure",
                              execTransactionResponse.Message,
                              operatorid,
                              "",
                              "",
                              execTransactionResponse.APITransactionReference,
                              execTransactionResponse.ATTTransactionReference,
                              fromMSISDN,
                              guidReferneceRecord.tomsisdn,
                              1,
                              messageToRecipient,
                              guidReferneceRecord.productCode,
                              guidReferneceRecord.ProductItemCode,
                              nowtelTransactionReference,
                               "","");
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"SochitelAutomation_BL  \"POST /FreeSwitch_Execute\"   Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }

                        //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                        _loggerAPIAccess.Debug($"SochitelAutomation_BL  \"POST /FreeSwitch_Execute\"   Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   SochiReference-{execTransactionResponse.ATTTransactionReference}     APIReference-{execTransactionResponse.APITransactionReference}        Reason={execTransactionResponse.Message}");
                        var result = new { errorCode = 2, status = "Failure", message = execTransactionResponse.Message };
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                       
                        // Error

                        await _dbATT.insertAirTimeTransferTransaction_Trh(
                          DateTime.Now.ToString(),
                          Credentials[0],  // Sochitel Username
                          guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                          decimal.Parse(product),   // Actual Charge Value
                          decimal.Parse(operatorProduct),
                          guidReferneceRecord.account,
                           "",
                           "",
                          "FailureException",
                          ex.Message,
                          operatorid,
                          "",
                          "",
                          transactionReference,
                          "",
                          fromMSISDN,
                          guidReferneceRecord.tomsisdn,
                          1,
                          messageToRecipient,
                          guidReferneceRecord.productCode,
                          guidReferneceRecord.ProductItemCode,
                          nowtelTransactionReference,"",""
                          );
                    }
                    catch (Exception dbException)
                    {
                        _loggerAPIAccess.Debug($"SochitelAutomation_BL  \"POST /FreeSwitch_Execute\"   Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }

                    //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                    _loggerAPIAccess.Debug($"SochitelAutomation_BL  \"POST /FreeSwitch_Execute\"   Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   SochiReference-{transactionReference}     APIReference-{""}        Reason={ex.Message}");
                    var result = new { errorCode = 2, status = "Failure", message = ex.Message };
                    return result;
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"SochitelAutomation_BL  \"POST /FreeSwitch_Execute\"   Failed   Source:General    Pasameters:         Message:{ex.ToString()}");
                var result = new { errorCode = 2, status = "Failure", message = ex.ToString() };
                return result;
            }


        }

        #endregion FreeSwitch_Execute


        //-------------------------------------------------------------------------------------------------------------------------

        private async Task<bool> SendTwilioSms(string to, string textMessage)
        {
            bool isRestrictedCountry = false;
            Twilio.Types.PhoneNumber from = "888 8";

            foreach (var item in TwilioConfig.TwilioFromNumberCountries)
            {
                if (to.StartsWith(item))
                {
                    isRestrictedCountry = true;
                    from = new Twilio.Types.PhoneNumber(TwilioConfig.TwilioNumber);
                }
            }

            if (!to.StartsWith("+"))
            {
                to = "+" + to;
            }

            string requestParameters = $"from : {from}, to: {to}, textMessage: {textMessage}";

            try
            {
                TwilioClient.Init(TwilioConfig.Sid, TwilioConfig.AuthToken);
                var message = await MessageResource.CreateAsync(body: textMessage, from: isRestrictedCountry ? from : "TransfHome", to: new Twilio.Types.PhoneNumber(to));
                return true;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Error($"SochitelAutomation_BL - Method: SendTwilioSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
                return false;
            }
        }

        //-------------------------------------------------------------------------------------------------------------------------

        #region sochitelGetOperatorProductsMSISDN

        public async Task<JsonOperatorProductResponse> sochitelGetOperatorProductsMSISDN(string destinationMSISDN, string account, int originDestinationId)
        {
         
            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 1;
            try
            {
                GenericApiResponse<OperatorProducts> sochitelOperatorProductsResponse = await _SochiTelPost.getOperatorProductsMSISDN(destinationMSISDN, account);

                if (sochitelOperatorProductsResponse.Status == 0)
                {
                    StringBuilder productsJSON = new StringBuilder();
                    productsJSON.Append("{");

                    PayLoad payload = new PayLoad();
                  
                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;

                    // Range type product checking
                    if (sochitelOperatorProductsResponse.Result.products.Count == 1 && sochitelOperatorProductsResponse.Result.products.First().Value.priceType == "range")
                    {
                        decimal SochitelMinimumUserValue = decimal.Parse(sochitelOperatorProductsResponse.Result.products.First().Value.price.min.user.ToString());
                        decimal SochitelMaximumUserValue = decimal.Parse(sochitelOperatorProductsResponse.Result.products.First().Value.price.max.user.ToString());
                        decimal SOchitelMinMaxUserValueDifference = SochitelMaximumUserValue - SochitelMinimumUserValue;

                        decimal SochitelMinimumOperatorValue = decimal.Parse(sochitelOperatorProductsResponse.Result.products.First().Value.price.min.@operator.ToString());
                        decimal SochitelMaximumOperatorValue = decimal.Parse(sochitelOperatorProductsResponse.Result.products.First().Value.price.max.@operator.ToString());
                        decimal SochitelMinMaxOperatorValueDifference = SochitelMaximumOperatorValue - SochitelMinimumOperatorValue;

                        //Get TransferTo operator products
                        GenericApiResponse<string> transferToOperatorProducts = await _TransferToPost.getOperatorProductsMSISDN(destinationMSISDN, account);

                        int serviceProviderOperaorId = int.Parse(sochitelOperatorProductsResponse.Result.OperatorID);

                        // get product rates from database
                        var enRates = await _dbATT.GetEndRates(serviceProviderOperaorId, account, 1, originDestinationId);

                        List<AttOperator> operators = new List<AttOperator>();
                        List<AttProduct> products = new List<AttProduct>();
                        AttOperator operatorDetails = new AttOperator();
                        string GUID = Guid.NewGuid().ToString();

                        // TransferTo products found.
                        if (transferToOperatorProducts.Status == 0)
                        {
                            XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                            xmlDoc.LoadXml(transferToOperatorProducts.Result); // Load the XML document from the specified file


                            XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                            if (xmlproductslist.Count == 0)
                            {
                                // return empty reply
                            }
                            string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                            XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                            string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                            XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                            string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');


                            operatorDetails.id = sochitelOperatorProductsResponse.Result.OperatorID;
                            operatorDetails.name = sochitelOperatorProductsResponse.Result.OperatorName;
                            operatorDetails.country = sochitelOperatorProductsResponse.Result.CountryName;
                            operatorDetails.nowtelTransactionReference = GUID;
                            operatorDetails.iconUri = sochitelOperatorProductsResponse.Result.OperatorLogo;

                            //int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                            //var enRates = await _dbATT.GetEndRates(2, operatorid, account);

                            for (int a = 0; a < productslist.Length; a++)
                            {
                                //include only those TransferTo products that has product values between min and max range of sochitel
                                if (decimal.Parse(retailpricelist[a]) >= SochitelMinimumUserValue && decimal.Parse(retailpricelist[a]) <= SochitelMaximumUserValue)
                                {
                                    decimal sochiCalculatedValue = Math.Round((((decimal.Parse(productslist[a]) - SochitelMinimumOperatorValue) / SochitelMinMaxOperatorValueDifference) * SOchitelMinMaxUserValueDifference) + SochitelMinimumUserValue, 2);


                                    decimal productValue = Convert.ToDecimal(productslist[a]);

                                    var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                                    if (endrate != null)
                                    {

                                        products.Add(_dbATT.GetProduct(
                                        account,         //clientccy
                                        xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                        productslist[a],     //product
                                        //sochiCalculatedValue.ToString(),  //itemPriceClientccy
                                        //sochiCalculatedValue.ToString()   //totalPriceClientccy
                                        endrate.CustomerChargeValue.ToString(),
                                        endrate.CustomerChargeValue.ToString()
                                        ));

                                        productsJSON.Append($"\"{productslist[a]}\":\"{sochiCalculatedValue.ToString()}\", ");
                                    }
                                }
                            }

                            productsJSON.Append("}");
                            operatorDetails.products = products;


                            DBResponse dbResult = new DBResponse();
                            dbResult = await _dbATT.insertTransactionGUID(GUID, account, destinationMSISDN, productsJSON.ToString(),"","",1);
                            if (dbResult.DBStatus == 1)
                            {

                                // Loop for inserting product access details
                                for (int i = 0; i < products.Count; i++)
                                {

                                    await _dbATT.insertaccessDetails(dbResult.InsertId,
                                        products[i].clientccy,
                                        products[i].receiverccy,
                                        products[i].product,
                                        products[i].totalPriceClientccy,
                                        products[i].totalPriceClientccy,
                                        0
                                    );
                                }

                                operatorDetails.accessid = dbResult.InsertId;
                                operators.Add(operatorDetails);
                                payload.operators = operators;
                                result.payload = payload;
                                _loggerAPIAccess.Information($" \"GET /sochitelGetOperatorProductsMSISDN\"  Success    Parameters-msisdn:{destinationMSISDN} currency:{account}");
                                return result;
                            }
                            else
                            {
                                _loggerAPIAccess.Debug($"  \"GET /sochitelGetOperatorProductsMSISDN\"  Failed  Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                                //var result1 = new { errorCode = 2, status = "Failure", message = " Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage };

                                result.message = "Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record . Exception: " + dbResult.DBErrorMessage ;
                                result.status = "Failure";
                                result.errorCode = 2;
                                return result;
                            }
                        }

                        // if transfer 2 response not availble
                        else
                        {
                            string[] breakdownPercentages = SochitelConf.RangeToProductConversionPercentages.Split(',');

                            operatorDetails.id = sochitelOperatorProductsResponse.Result.OperatorID;
                            operatorDetails.name = sochitelOperatorProductsResponse.Result.OperatorName;
                            operatorDetails.country = sochitelOperatorProductsResponse.Result.CountryName;
                            operatorDetails.nowtelTransactionReference = GUID;
                            operatorDetails.iconUri = sochitelOperatorProductsResponse.Result.OperatorLogo;

                            //int operatorid = int.Parse(sochitelOperatorProductsResponse.Result.OperatorID);

                            // var enRates = await _dbATT.GetEndRates(1, operatorid, account);

                            foreach (string percent in breakdownPercentages)
                            {
                                decimal percentValue = decimal.Parse(percent) / 100;

                                decimal productValue = Math.Round(((SochitelMinMaxOperatorValueDifference * percentValue) + SochitelMinimumOperatorValue), 2);

                                var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                                if (endrate != null)
                                {

                                    products.Add(_dbATT.GetProduct(
                                    account,         //clientccy
                                    sochitelOperatorProductsResponse.Result.currency.@operator,    //receiverccy
                                    Math.Round(((SochitelMinMaxOperatorValueDifference * percentValue) + SochitelMinimumOperatorValue), 2).ToString(),     //product
                                    endrate.CustomerChargeValue.ToString(),
                                    endrate.CustomerChargeValue.ToString()
                                    ));

                                    productsJSON.Append($"\"{Math.Round(((SochitelMinMaxOperatorValueDifference * percentValue) + SochitelMinimumOperatorValue), 2).ToString()}\":\"{Math.Round(((SOchitelMinMaxUserValueDifference * percentValue) + SochitelMinimumUserValue), 2).ToString()}\", ");
                                }
                            }

                            productsJSON.Append("}");

                            operatorDetails.products = products;

                            DBResponse dbResult = new DBResponse();
                            dbResult = await _dbATT.insertTransactionGUID(GUID, account, destinationMSISDN, productsJSON.ToString(),"","",1);
                            if (dbResult.DBStatus == 1)
                            {

                                for (int i = 0; i < products.Count; i++)
                                {

                                    await _dbATT.insertaccessDetails(dbResult.InsertId,
                                        products[i].clientccy,
                                        products[i].receiverccy,
                                        products[i].product,
                                        products[i].totalPriceClientccy,
                                        products[i].totalPriceClientccy,
                                        0
                                    );
                                }
                                operatorDetails.accessid = dbResult.InsertId;
                                operators.Add(operatorDetails);
                                payload.operators = operators;
                                result.payload = payload;
                                _loggerAPIAccess.Information($" \"GET /sochitelGetOperatorProductsMSISDN\"  Success    Parameters-msisdn:{destinationMSISDN} currency:{account}");
                                return result;
                            }
                            else
                            {
                                _loggerAPIAccess.Debug($"  \"GET /sochitelGetOperatorProductsMSISDN\"  Failed  Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");
                                //var result1 = new { errorCode = 2, status = "Failure", message = " Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage };

                                result.message = "Source:Sochitel API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                                result.status = "Failure";
                                result.errorCode = 2;
                                return result;

                              
                            }

                        }
                    }
                    else
                    {

                        AttOperator attOperator = await convertProducts(sochitelOperatorProductsResponse.Result, account, destinationMSISDN, true, originDestinationId);
                        List<AttOperator> operators = new List<AttOperator>();
                        operators.Add(attOperator);
                        payload.operators = operators;
                        result.payload = payload;
                        _loggerAPIAccess.Information($" \"GET /sochitelGetOperatorProductsMSISDN\"  Success    Parameters-msisdn:{destinationMSISDN} currency:{account}");
                        return result;

                    }


                }
                else
                {
                    //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                    _loggerAPIAccess.Debug($"  \"GET /sochitelGetOperatorProductsMSISDN\"  Failed  Source:Sochitel API        Parameters-msisdn:{destinationMSISDN}  currency:{account}       Reason-{sochitelOperatorProductsResponse.Message}");

                    // var result = new { errorCode = 1, status = "Failure", message = sochitelOperatorProductsResponse.Message };

                    result.message = sochitelOperatorProductsResponse.Message;
                    result.status = "Failure";
                    result.errorCode = 1;
                    return result;

                  
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($" \"GET /sochitelGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-msisdn:{destinationMSISDN} currency:{account}    Message:{ex.ToString()}");

                //var result = new { errorCode = 1, status = "Failure", message = ex.ToString() };
                //return Json(result);

                result.message = ex.ToString();
                result.status = "Failure";
                result.errorCode = 1;
                return result;

                
            }
        }

        async public Task<AttOperator> convertProducts(OperatorProducts operatorProductsResponse, string account, string msisdn, bool insertAPIReferenceInDB, int originDestinationId)
        {


            List<AttProduct> products = new List<AttProduct>();
            string GUID = Guid.NewGuid().ToString();
            AttOperator operatorDetails = new AttOperator();
            operatorDetails.id = operatorProductsResponse.OperatorID;
            operatorDetails.name = operatorProductsResponse.OperatorName;
            operatorDetails.country = operatorProductsResponse.CountryName;
            operatorDetails.nowtelTransactionReference = GUID;
            operatorDetails.iconUri = operatorProductsResponse.OperatorLogo;

            DBResponse dbResult = new DBResponse();
            if (insertAPIReferenceInDB == true)
            {
                dbResult = await _dbATT.insertTransactionGUID(GUID, account, msisdn, "{}","","",1);
                operatorDetails.accessid = dbResult.InsertId;
            }


            int serviceProviderOperaorId = int.Parse(operatorProductsResponse.OperatorID);

            var enRates = await _dbATT.GetEndRates(serviceProviderOperaorId, account, 1, originDestinationId);

            StringBuilder productsJSON = new StringBuilder();
            productsJSON.Append("{");
            foreach (KeyValuePair<string, Product> product in operatorProductsResponse.products)
            {

                int productid = int.Parse(product.Value.id);
                decimal productValue = Convert.ToDecimal(product.Value.price.@operator);

                var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                if (endrate != null)
                {
                    if (product.Value.priceType == "fixed")
                    {

                        products.Add(_dbATT.GetProduct(
                            operatorProductsResponse.currency.user,         //clientccy
                            operatorProductsResponse.currency.@operator,    //receiverccy
                            product.Value.price.@operator,     //product
                            endrate.CustomerChargeValue.ToString(),  //itemPriceClientccy
                            endrate.CustomerChargeValue.ToString()   //totalPriceClientccy
                        ));

                        int accessId = operatorDetails.accessid;


                        await _dbATT.insertaccessDetails(accessId,
                            operatorProductsResponse.currency.user.ToString(),
                            operatorProductsResponse.currency.@operator.ToString(),
                            product.Value.price.@operator.ToString(),
                            endrate.CustomerChargeValue.ToString(),
                            endrate.CustomerChargeValue.ToString(),
                            productid
                            );

                        productsJSON.Append($"\"{product.Value.price.@operator}\":\"{product.Value.price.user}\", ");
                    }
                    else
                    {

                        products.Add(_dbATT.GetProduct(
                            operatorProductsResponse.currency.user,         //clientccy
                            operatorProductsResponse.currency.@operator,    //receiverccy
                            product.Value.price.min.@operator,     //product
                            product.Value.price.min.user,  //itemPriceClientccy
                            product.Value.price.min.user   //totalPriceClientccy
                        ));


                        products.Add(_dbATT.GetProduct(
                            operatorProductsResponse.currency.user,         //clientccy
                            operatorProductsResponse.currency.@operator,    //receiverccy
                            product.Value.price.max.@operator,     //product
                            product.Value.price.max.user,  //itemPriceClientccy
                            product.Value.price.max.user   //totalPriceClientccy
                        ));
                    }
                }

            }

            productsJSON.Append("}");
            operatorDetails.products = products;
            if (insertAPIReferenceInDB == true)
            {

                await _dbATT.updateProductsJSONOfGUID(GUID, productsJSON.ToString());
            }


            return operatorDetails;
        }
      
        #endregion sochitelGetOperatorProductsMSISDN

    }
}
