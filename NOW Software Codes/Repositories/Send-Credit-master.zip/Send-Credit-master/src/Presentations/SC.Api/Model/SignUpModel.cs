﻿using SC.Core.Common.Definitions.Utilities;
using System.ComponentModel.DataAnnotations;
using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Model;
public class SignUpModel
{
    [Required(ErrorMessage = "The {0} field is required.")]
    [StringLength(30, ErrorMessage = "The {0} must be at most {1} characters long."), EmailAddress]
    public string Email { get; set; } = default!;
    [Required(ErrorMessage = "The {0} field is required.")]
    [StringLength(30, ErrorMessage = "The {0} must be at most {1} characters long.")]
    public string? Password { get; set; }

    [Required(ErrorMessage = "The {0} field is required.")]
    [EnumValidation(typeof(AppEnums.UserTypeEnum), ErrorMessage = "The {0} field is required and must be a valid UserTypeEnum value.")]
    public UserTypeEnum UserType { get; set; } = AppEnums.UserTypeEnum.Customer;

    public string? PhoneNumber { get; set; } = default!;

}

public class ResendOPTModel
{
    public string Email { get; set; } = default!;

}
public class ForgotPasswordModel
{
    public string Email { get; set; } = default!;

}

public class ResetPasswordModel
{
    public string Email { get; set; } = default!;
    [StringLength(128, ErrorMessage = "The {0} must be at most {1} characters long.")]
    public string Password { get; set; } = default!;
    public string Token { get; set; } = default!;

}

