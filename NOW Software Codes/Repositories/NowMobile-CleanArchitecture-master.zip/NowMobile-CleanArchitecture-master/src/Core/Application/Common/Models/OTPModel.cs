namespace Application.Common.Models;

public class OTPModel
{
    public DateTime RemainingDateTime { get; set; }
    public int StatusCode { get; set; }
    public int Otp { get; set; }
}