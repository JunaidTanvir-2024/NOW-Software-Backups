﻿using System.Globalization;

using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Services.Payment;

namespace THCC.Application.Features.Payment.Card.CustomerCards;

public class CustomerCardsRequestHandler : IRequestHandler<CustomerCardsRequest, object>
{
    #region Fields

    private readonly ICardService _cardService;
    private readonly ICurrentUser _currentuser;

    #endregion

    #region Ctors

    public CustomerCardsRequestHandler(
        ICardService cardService,
      ICurrentUser currentuser)
    {
        _cardService = cardService;
        _currentuser = currentuser;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(CustomerCardsRequest request, CancellationToken cancellationToken)
    {
        var cards = await _cardService.GetCustomerCards(_currentuser.GetUserEmail()!);
        if (cards?.Count > 0)
        {
            foreach (var card in cards)
            {
                DateTime dt = DateTime.ParseExact(card.ExpiryDate, "MMyy", CultureInfo.InvariantCulture);
                card.ExpiryDate = dt.ToString("MM/yy", CultureInfo.InvariantCulture);
            }

            if (!cards.Any(x => x.IsPrimary))
            {
                cards[0].IsPrimary = true;
            }
        }
        return cards!;
    }

    #endregion
}
