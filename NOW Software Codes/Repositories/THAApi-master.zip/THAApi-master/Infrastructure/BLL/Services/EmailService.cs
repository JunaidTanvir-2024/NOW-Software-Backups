﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Microsoft.Extensions.Options;
using MimeKit;
using Models.Configurations;
using Serilog;

namespace Infrastructure.BLL.Services
{
   
    public class EmailService : IEmailService
    {
        private readonly SmtpConfig _smtpConfig;
        private readonly ILogger _logger;
        private readonly RedirectUrlsConfig _redirectUrls;

        public EmailService(ILogger logger,
                        IOptions<SmtpConfig> smpt,
                        IOptions<RedirectUrlsConfig> redirectUrls)
        {
            _logger = logger;
            _redirectUrls = redirectUrls.Value;
            _smtpConfig = smpt.Value;
        }

        public async Task SendUserRegistrationEmail(string email, string name, string token)
        {
            try
            {
                var builder = new BodyBuilder();

                using (StreamReader SourceReader = File.OpenText(string.Format(
                    Path.GetFullPath(@"~\wwwroot\Templates\Instant-on-sign-up-to-app.html").Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();
                }

                string verificationLink = _redirectUrls.VerifyEmailRedirectUrl.Replace("{token}", token);

                string htmlBody = builder.HtmlBody.Replace("%VERIFY_LINK%", verificationLink);

                await SendEmail(email, htmlBody, true, "Email Verification");
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: EmailService, Method: SendUserRegistrationEmail, Parameters=> customerEmail: {email}, ErrorMessage: {ex.Message}");
            }
        }

        public async Task<bool> SendEmail(string customerEmail, string Message, bool IsHtmlBody, string subject = null)
        {
            try
            {
                if (!_smtpConfig.sendEmailToCustomer)
                    return false;
                SmtpClient client = new SmtpClient(_smtpConfig.server);

                if (_smtpConfig.userName != "" && _smtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(_smtpConfig.userName, _smtpConfig.password);
                }

                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(_smtpConfig.from);
                mailMessage.To.Add(customerEmail);
                if (IsHtmlBody)
                {
                    mailMessage.IsBodyHtml = IsHtmlBody;
                }
                mailMessage.Body = Message;
                mailMessage.Subject = subject;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: EmailService, Method: SendEmail, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }
        }
        public async Task<bool> SendEmail(string[] customerEmail, string Message, bool IsHtmlBody, string subject = null)
        {
            try
            {
                if (!_smtpConfig.sendEmailToCustomer)
                    return false;
                SmtpClient client = new SmtpClient(_smtpConfig.server);

                if (_smtpConfig.userName != "" && _smtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(_smtpConfig.userName, _smtpConfig.password);
                }

                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(_smtpConfig.from);
                foreach (var item in customerEmail)
                {
                    mailMessage.To.Add(item);
                }
                if (IsHtmlBody)
                {
                    mailMessage.IsBodyHtml = IsHtmlBody;
                }
                mailMessage.Body = Message;
                mailMessage.Subject = subject;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: EmailService, Method: SendEmail, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }
        }

    }
}
