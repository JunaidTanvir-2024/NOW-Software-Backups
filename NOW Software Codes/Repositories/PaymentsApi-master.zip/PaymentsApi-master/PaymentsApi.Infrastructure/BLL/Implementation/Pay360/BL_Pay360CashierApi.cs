﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PaymentsApi.Infrastructure.BLL.Interfaces.Pay360;
using PaymentsApi.Infrastructure.DAL.Database;
using PaymentsApi.Infrastructure.DAL.Interfaces;
using PaymentsApi.Models.Configurations;
using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Pay360.Request.Api;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using PaymentsApi.Models.Utility;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace PaymentsApi.Infrastructure.BLL.Implementation.Pay360
{
    public class BL_Pay360CashierApi : BL_IPay360CashierApi
    {
        private Pay360Config Pay360Configurations;
        private DataPolicyConfig DataPolicyConfig;
        private DL_IPay360 Db;
        private IApiCall ApiCall;
        private readonly ILogger Logger;
        private readonly SmsConfig SmsConfig;
        private readonly SmtpConfig SmtpConfig;
        private readonly SimulationConfig SimulationConf;
        private IEmailTemplates EmailTemplate;
        private readonly IPay360Auth pay360Auth;

        public BL_Pay360CashierApi(
            ILogger logger,
            DL_IPay360 db,
            IOptions<Pay360Config> pay360Config,
            IOptions<DataPolicyConfig> dataPolicyConfig,
            IOptions<SmsConfig> smsConfig,
            IOptions<SmtpConfig> smpt,
            IOptions<SimulationConfig> stimulationConfig,
            IApiCall apiCall,
            IEmailTemplates emailTemplate,
            IPay360Auth pay360Auth)
        {
            Pay360Configurations = pay360Config.Value;
            DataPolicyConfig = dataPolicyConfig.Value;
            Db = db;
            this.ApiCall = apiCall;
            Logger = logger;
            SmsConfig = smsConfig.Value;
            SmtpConfig = smpt.Value;
            SimulationConf = stimulationConfig.Value;
            EmailTemplate = emailTemplate;
            this.pay360Auth = pay360Auth;
        }


        #region PaymentRequests

        public async Task<GenericApiResponse<UserResponseModels>> NewCustomerPayment(UserPaymentRequestNewCustomer userRequest)
        {
            var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(userRequest.CustomerMsisdn, userRequest.ProductCode, nameof(Pay360PaymentType.CARD));

            if (userRequest.BillingAddress == null)
            {
                userRequest.BillingAddress = new BillingAddress();
                userRequest.BillingAddress.Line1 = "";
                userRequest.BillingAddress.Line2 = "";
                userRequest.BillingAddress.Line3 = "";
                userRequest.BillingAddress.Line4 = "";
                userRequest.BillingAddress.PostCode = "";
                userRequest.BillingAddress.Region = "";
                userRequest.BillingAddress.CountryCode = "";
                userRequest.BillingAddress.City = "";
            }

            if (userRequest.CustomerBillingAddress == null)
            {
                userRequest.CustomerBillingAddress = new Models.Contracts.Pay360.Request.User.CustomerBillingAddress();
                userRequest.CustomerBillingAddress.Line1 = "";
                userRequest.CustomerBillingAddress.Line2 = "";
                userRequest.CustomerBillingAddress.Line3 = "";
                userRequest.CustomerBillingAddress.Line4 = "";
                userRequest.CustomerBillingAddress.PostCode = "";
                userRequest.CustomerBillingAddress.Region = "";
                userRequest.CustomerBillingAddress.CountryCode = "";
                userRequest.CustomerBillingAddress.City = "";

            }


            GenericApiResponse<UserResponseModels> response;
            string requestJson = "";

            bool sendpay360Email = false;

            if (userRequest.SendPay360Email == true && !string.IsNullOrWhiteSpace(userRequest.CustomerEmail))
            {
                sendpay360Email = true;
            }

            //bool sendEmail = string.IsNullOrWhiteSpace(userRequest.CustomerEmail) ? false : true;

            string customerMerchantReference;

            if (userRequest.ProductCode.ToLower() == "tha")
            {
                customerMerchantReference = userRequest.CustomerUniqueRef;
            }
            else
            {
                customerMerchantReference = userRequest.ProductCode + "_" + userRequest.CustomerUniqueRef;
            }

            try
            {
                string description = "";

                if (!userRequest.OverrideValidation)
                {
                    GenericApiResponse<UserResponseModels> validationResponse = await Validations(userRequest.CustomerMsisdn, userRequest.ProductCode, userRequest.TransactionAmount, userRequest.Basket);
                    if (validationResponse.errorCode == 0) // Validation Successfull
                    {
                        description = validationResponse.message;
                    }
                    else // Validation Error
                    {
                        return validationResponse;
                    }
                }

                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/payment";


                Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);

                if (customer == null)
                {
                    //New Customer
                    customer = new Customer()
                    {
                        DisplayName = userRequest.CustomerName,
                        MerchantRef = customerMerchantReference,
                        Email = userRequest.CustomerEmail,
                        AddressLine1 = userRequest.CustomerBillingAddress == null ? "" : userRequest.CustomerBillingAddress.Line1,
                        AddressLine2 = userRequest.CustomerBillingAddress == null ? "" : userRequest.CustomerBillingAddress.Line2,
                        AddressLine3 = userRequest.CustomerBillingAddress == null ? "" : userRequest.CustomerBillingAddress.Line3,
                        AddressLine4 = userRequest.CustomerBillingAddress == null ? "" : userRequest.CustomerBillingAddress.Line4,
                        City = userRequest.CustomerBillingAddress == null ? "" : userRequest.CustomerBillingAddress.City,
                        CountryCode = userRequest.CustomerBillingAddress == null ? "" : userRequest.CustomerBillingAddress.CountryCode,
                        Region = userRequest.CustomerBillingAddress == null ? "" : userRequest.CustomerBillingAddress.Region,
                        PostCode = userRequest.CustomerBillingAddress == null ? "" : userRequest.CustomerBillingAddress.PostCode,
                        ProductCode = userRequest.ProductCode,
                        Msisdn = userRequest.CustomerMsisdn
                    };
                    DbResult<int> result = await Db.AddCustomer(customer);
                    if (result.DBStatus != 1)
                    {
                        return response = GenericApiResponse<UserResponseModels>.Failure(result.DBErrorMessage, 14);
                    }
                    else
                    {
                        customer.Id = result.Data;
                    }

                }
                else // Customer Already Exists
                {
                    if (!string.IsNullOrWhiteSpace(userRequest.CustomerEmail) && userRequest.CustomerEmail != customer.Email)
                    {
                        await Db.UpdateCustomerEmail(customer.MerchantRef, userRequest.CustomerEmail);
                    }
                }

                string transactionMerchantRef = userRequest.ProductCode + "_" + Guid.NewGuid().ToString("N");

                HttpResponseMessage apiResponseJson;

                if (userRequest.FinancialServices == null)
                {
                    ApiPaymentRequestNewCustomer requestModel = null;

                    if (userRequest.BillingAddress != null && userRequest.BillingAddress.Line1 != "")
                    {

                        requestModel = new ApiPaymentRequestNewCustomer
                        {
                            Customer = new CustomerRequestModel()
                            {
                                Telephone = userRequest.CustomerMsisdn,
                                DisplayName = userRequest.CustomerName,
                                MerchantRef = customerMerchantReference,
                                Email = userRequest.CustomerEmail,
                                Registered = "true",
                                IpAddress = userRequest.IpAddress,
                                CustomerBillingAddress = new Models.Contracts.Pay360.Request.Api.CustomerBillingAddress() { Line1 = userRequest.CustomerBillingAddress.Line1, Line2 = userRequest.CustomerBillingAddress.Line2, Line3 = userRequest.CustomerBillingAddress.Line3, Line4 = userRequest.CustomerBillingAddress.Line4, City = userRequest.CustomerBillingAddress.City, PostCode = userRequest.CustomerBillingAddress.PostCode, Region = userRequest.CustomerBillingAddress.Region, CountryCode = userRequest.CustomerBillingAddress.CountryCode }
                            },
                            PaymentMethod = new PaymentMethodRequestModel()
                            {
                                Registered = userRequest.SaveCard,
                                Card = new CardRequestModel() { CV2 = userRequest.CardCv2, DefaultCard = userRequest.IsDefaultCard, ExpiryDate = userRequest.CardExpiryDate, Pan = userRequest.CardPan },
                                CardBillingAddress = new CardBillingAddress() { City = userRequest.BillingAddress.City, CountryCode = userRequest.BillingAddress.CountryCode, Line1 = userRequest.BillingAddress.Line1, Line2 = userRequest.BillingAddress.Line2, Line3 = userRequest.BillingAddress.Line3, Line4 = userRequest.BillingAddress.Line4, PostCode = userRequest.BillingAddress.PostCode, Region = userRequest.BillingAddress.Region }
                            },
                            Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                            TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                            Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                            CustomFields = userRequest.CustomFields
                        };
                    }
                    else
                    {
                        requestModel = new ApiPaymentRequestNewCustomer
                        {
                            Customer = new CustomerRequestModel()
                            {
                                Telephone = userRequest.CustomerMsisdn,
                                DisplayName = userRequest.CustomerName,
                                MerchantRef = customerMerchantReference,
                                Email = userRequest.CustomerEmail,
                                Registered = "true",
                                IpAddress = userRequest.IpAddress,
                                CustomerBillingAddress = new Models.Contracts.Pay360.Request.Api.CustomerBillingAddress() { Line1 = userRequest.CustomerBillingAddress.Line1, Line2 = userRequest.CustomerBillingAddress.Line2, Line3 = userRequest.CustomerBillingAddress.Line3, Line4 = userRequest.CustomerBillingAddress.Line4, City = userRequest.CustomerBillingAddress.City, PostCode = userRequest.CustomerBillingAddress.PostCode, Region = userRequest.CustomerBillingAddress.Region, CountryCode = userRequest.CustomerBillingAddress.CountryCode }
                            },
                            PaymentMethod = new PaymentMethodRequestModel()
                            {
                                Registered = userRequest.SaveCard,
                                Card = new CardRequestModel()
                                {
                                    CV2 = userRequest.CardCv2,
                                    DefaultCard = userRequest.IsDefaultCard,
                                    ExpiryDate = userRequest.CardExpiryDate,
                                    Pan = userRequest.CardPan
                                }
                            },
                            Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                            TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                            Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                            CustomFields = userRequest.CustomFields
                        };
                    }
                    try
                    {
                        if (userRequest.Recurring)
                        {
                            requestModel.Transaction.ContinuousAuthorityAgreement = new ContinuousAuthorityAgreement
                            {
                                Expiry = DateTime.UtcNow.AddYears(1).ToString("yyyy-MM-dd"),
                                MinFrequency = 1
                            };
                        }
                        apiResponseJson = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                    }
                    catch (Exception)
                    {
                        await SaveFailedTransactionApiError(transactionMerchantRef, customer.Id, PaymentMethods.Card, requestModel.Transaction.Deferred, requestModel.Transaction.Amount, requestModel.Transaction.Currency, userRequest.Basket, creds.ApiInstallationIdCashierApi);
                        throw;
                    }
                    if (DataPolicyConfig.DisablePaymentMethodInRequest)
                    {
                        requestModel.PaymentMethod.Card = null;
                    }
                    requestJson = JsonConvert.SerializeObject(requestModel);
                }
                else
                {
                    ApiPaymentRequestNewCustomerWithFinancialServices requestModel = null;

                    if (userRequest.BillingAddress != null && userRequest.BillingAddress.Line1 != "")
                    {
                        requestModel = new ApiPaymentRequestNewCustomerWithFinancialServices
                        {
                            Customer = new CustomerRequestModel()
                            {
                                Telephone = userRequest.CustomerMsisdn,
                                DisplayName = userRequest.CustomerName,
                                MerchantRef = customerMerchantReference,
                                Email = userRequest.CustomerEmail,
                                Registered = "true",
                                IpAddress = userRequest.IpAddress,
                                CustomerBillingAddress = new Models.Contracts.Pay360.Request.Api.CustomerBillingAddress() { Line1 = userRequest.CustomerBillingAddress.Line1, Line2 = userRequest.CustomerBillingAddress.Line2, Line3 = userRequest.CustomerBillingAddress.Line3, Line4 = userRequest.CustomerBillingAddress.Line4, City = userRequest.CustomerBillingAddress.City, PostCode = userRequest.CustomerBillingAddress.PostCode, Region = userRequest.CustomerBillingAddress.Region, CountryCode = userRequest.CustomerBillingAddress.CountryCode }
                            },
                            PaymentMethod = new PaymentMethodRequestModel() { Registered = userRequest.SaveCard, Card = new CardRequestModel() { CV2 = userRequest.CardCv2, DefaultCard = userRequest.IsDefaultCard, ExpiryDate = userRequest.CardExpiryDate, Pan = userRequest.CardPan }, CardBillingAddress = new CardBillingAddress() { City = userRequest.BillingAddress.City, CountryCode = userRequest.BillingAddress.CountryCode, Line1 = userRequest.BillingAddress.Line1, Line2 = userRequest.BillingAddress.Line2, Line3 = userRequest.BillingAddress.Line3, Line4 = userRequest.BillingAddress.Line4, PostCode = userRequest.BillingAddress.PostCode, Region = userRequest.BillingAddress.Region } },
                            Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                            FinancialServices = new UserFinancialServicesModel() { AccountNumber = userRequest.FinancialServices.AccountNumber, DateOfBirth = userRequest.FinancialServices.DateOfBirth, PostCode = userRequest.FinancialServices.PostCode, Surname = userRequest.FinancialServices.Surname },
                            TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                            Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                            CustomFields = userRequest.CustomFields
                        };
                    }
                    else
                    {
                        requestModel = new ApiPaymentRequestNewCustomerWithFinancialServices
                        {
                            Customer = new CustomerRequestModel()
                            {
                                Telephone = userRequest.CustomerMsisdn,
                                DisplayName = userRequest.CustomerName,
                                MerchantRef = customerMerchantReference,
                                Email = userRequest.CustomerEmail,
                                Registered = "true",
                                IpAddress = userRequest.IpAddress,
                                CustomerBillingAddress = new Models.Contracts.Pay360.Request.Api.CustomerBillingAddress() { Line1 = userRequest.CustomerBillingAddress.Line1, Line2 = userRequest.CustomerBillingAddress.Line2, Line3 = userRequest.CustomerBillingAddress.Line3, Line4 = userRequest.CustomerBillingAddress.Line4, City = userRequest.CustomerBillingAddress.City, PostCode = userRequest.CustomerBillingAddress.PostCode, Region = userRequest.CustomerBillingAddress.Region, CountryCode = userRequest.CustomerBillingAddress.CountryCode }
                            },
                            PaymentMethod = new PaymentMethodRequestModel() { Registered = userRequest.SaveCard, Card = new CardRequestModel() { CV2 = userRequest.CardCv2, DefaultCard = userRequest.IsDefaultCard, ExpiryDate = userRequest.CardExpiryDate, Pan = userRequest.CardPan } },
                            Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                            FinancialServices = new UserFinancialServicesModel() { AccountNumber = userRequest.FinancialServices.AccountNumber, DateOfBirth = userRequest.FinancialServices.DateOfBirth, PostCode = userRequest.FinancialServices.PostCode, Surname = userRequest.FinancialServices.Surname },
                            TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                            Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                            CustomFields = userRequest.CustomFields
                        };
                    }

                    try
                    {
                        if (userRequest.Recurring)
                        {
                            requestModel.Transaction.ContinuousAuthorityAgreement = new ContinuousAuthorityAgreement
                            {
                                Expiry = DateTime.UtcNow.AddYears(1).ToString("yyyy-MM-dd"),
                                MinFrequency = 1
                            };
                        }
                        apiResponseJson = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                    }
                    catch (Exception)
                    {
                        await SaveFailedTransactionApiError(transactionMerchantRef, customer.Id, PaymentMethods.Card, requestModel.Transaction.Deferred, requestModel.Transaction.Amount, requestModel.Transaction.Currency, userRequest.Basket, creds.ApiInstallationIdCashierApi);
                        throw;
                    }
                    if (DataPolicyConfig.DisablePaymentMethodInRequest)
                    {
                        requestModel.PaymentMethod.Card = null;
                    }
                    requestJson = JsonConvert.SerializeObject(requestModel);
                }



                ApiPaymentResponse apiResponse;
                string responseJson = "";
                if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                    //Initialising dbTransaction Object.
                    Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, customer.Id, transactionMerchantRef, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = responseJson;
                    DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.NEWCUSTOMER, true, userRequest.IpAddress);

                    if (apiResponse.Outcome.Status.ToLower() != "success") // Failure
                    {

                        if (result.DBStatus != 1) // Db Insertion Failed.
                        {
                            return response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull and Database Insertion Error: " + result.DBErrorMessage, 13);
                        }
                        else
                        {
                            return response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull", 12);
                        }
                    }
                    else // Success
                    {

                        if (userRequest.IsDefaultCard)
                        {
                            string key = Guid.NewGuid().ToString("N");
                            string cV2 = RijndaelEncryption.Encrypt(userRequest.CardCv2, key);
                            await Db.UpdateCustomerIdAndCV2(customer.MerchantRef, apiResponse.Customer.Id, true, cV2, key);
                        }
                        else
                        {
                            await Db.UpdateCustomerIdAndCV2(customer.MerchantRef, apiResponse.Customer.Id);
                        }

                        UserResponseModels userResponse = new UserResponseModels()
                        {
                            CustomerId = apiResponse.Customer.Id.ToString(),
                            TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                            TransactionId = apiResponse.Transaction.TransactionId,
                            Processing = apiResponse.Processing,
                            OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status },
                            ClientRedirect = apiResponse.ClientRedirect,
                            ThreeDSecure = apiResponse.ThreeDSecure,
                            Recurring = apiResponse.Transaction.Recurring,
                            MaskedPan = apiResponse.PaymentMethod.Card.MaskedPan,
                        };
                        if (result.DBStatus != 1)
                        {
                            return response = GenericApiResponse<UserResponseModels>.Failure("Transaction Successfull but Error in Database Insertion: " + result.DBErrorMessage, 11);
                        }

                        if (userRequest.IsAuthorizationOnly == false && userRequest.Do3DSecure == false && userRequest.IsDirectFullfilment == true)
                        {
                            // Fullfilment
                            return response = await Fullfilment(userResponse, apiResponse.Transaction.TransactionId, result.Data.ToString(), userRequest.TransactionCurrency, customerMerchantReference, userRequest.CustomerEmail, userRequest.CustomerMsisdn);
                        }
                        else if (userRequest.IsAuthorizationOnly == false && userRequest.Do3DSecure == true && userRequest.IsDirectFullfilment == true && userResponse.OutcomeModel.ReasonCode == "S100" && userResponse.ClientRedirect == null) // Transaction Successfull and Completed but Card Not Enrolled in 3Ds
                        {
                            // Fullfilment
                            return response = await Fullfilment(userResponse, apiResponse.Transaction.TransactionId, result.Data.ToString(), userRequest.TransactionCurrency, customerMerchantReference, userRequest.CustomerEmail, userRequest.CustomerMsisdn);
                        }

                        response = GenericApiResponse<UserResponseModels>.Success(userResponse, "Success");



                    }
                }
                else if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.MultiStatus)
                {
                    responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);
                    //We should capture the status= success 
                    Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, customer.Id, transactionMerchantRef, PaymentMethods.Card, creds.ApiInstallationIdCashierApi, creds.ApiInstallationIdCashierApi);
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = responseJson;
                    DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.NEWCUSTOMER, false, userRequest.IpAddress);
                    string errorMessage = apiResponse.Outcome.ReasonMessage;
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", responseJson).Trim();
                    if (reasonCode == "A136")
                    {
                        errorMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }

                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserResponseModels>.Failure(errorMessage, 12);
                    response.pay360ApiCode = reasonCode;

                }
                else
                {

                    string jsonResult = await apiResponseJson.Content.ReadAsStringAsync();
                    Pay360Transaction dbTransaction = new Pay360Transaction();
                    dbTransaction.Customer_Id = customer.Id;
                    dbTransaction.TransactionMerchantRef = transactionMerchantRef;
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = jsonResult;
                    dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    int transactionTypeId = (userRequest.IsAuthorizationOnly == true ? (int)Pay360TransactionTypes.PREAUTH : (int)Pay360TransactionTypes.PAYMENT);
                    dbTransaction.TransactionType_Id = transactionTypeId;
                    dbTransaction.TransactionAmount = userRequest.TransactionAmount;
                    dbTransaction.TransactionCurrency = userRequest.TransactionCurrency;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    dbTransaction.OutcomeReasonMessage = reasonMessage;
                    dbTransaction.Is3DSecure = userRequest.Do3DSecure;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                    DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.NEWCUSTOMER, false, userRequest.IpAddress);
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();
                    if (reasonCode == "A136")
                    {
                        reasonMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }
                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + reasonMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserResponseModels>.Failure(reasonMessage, 12);
                    response.pay360ApiCode = reasonCode;

                }

            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserResponseModels>.Failure(ex.Message, 14);
                throw;
            }

            return response;
        }

        public async Task<GenericApiResponse<UserResponseModels>> ExistingCustomerPaymentDefaultCard(UserPaymentRequestExistingCustomerDefaultCard userRequest)
        {
            var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(userRequest.CustomerMsisdn, userRequest.ProductCode, nameof(Pay360PaymentType.CARD));

            GenericApiResponse<UserResponseModels> response;
            string requestJson = "";
            //Uncomment When Pay360 fix it
            //bool sendEmail = string.IsNullOrWhiteSpace(userRequest.CustomerEmail) ? false : true;

            string customerMerchantReference;

            if (userRequest.ProductCode.ToLower() == "tha")
            {
                customerMerchantReference = userRequest.CustomerUniqueRef;
            }
            else
            {
                customerMerchantReference = userRequest.ProductCode + "_" + userRequest.CustomerUniqueRef;
            }

            bool sendpay360Email = false;

            if (userRequest.SendPay360Email == true && !string.IsNullOrWhiteSpace(userRequest.CustomerEmail))
            {
                sendpay360Email = true;
            }

            try
            {

                string description = "";
                if (!userRequest.OverrideValidation)
                {
                    GenericApiResponse<UserResponseModels> validationResponse = await Validations(userRequest.CustomerMsisdn, userRequest.ProductCode, userRequest.TransactionAmount, userRequest.Basket);
                    if (validationResponse.errorCode == 0) // Validation Successfull
                    {
                        description = validationResponse.message;
                    }
                    else // Validation Error
                    {
                        return validationResponse;
                    }
                }

                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/payment";

                Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                //Uncomment When Pay360 fix it
                //sendEmail = string.IsNullOrWhiteSpace(customer.Email) ? false : true;
                bool isCustomerEmailUpdated = false;

                //DbResult<bool> validateTopupResult = await Db.ValidateTopUp(userRequest.CustomerMsisdn, userRequest.TransactionAmount);
                //if (validateTopupResult.DBStatus != 1)
                //{
                //    return response = GenericApiResponse<UserResponseModels>.Failure(validateTopupResult.DBErrorMessage, validateTopupResult.DBStatus);
                //}

                if (customer != null)
                {
                    if (!string.IsNullOrWhiteSpace(userRequest.CustomerEmail) && userRequest.CustomerEmail != customer.Email)
                    {
                        isCustomerEmailUpdated = true;
                    }

                    string transactionMerchantRef = userRequest.ProductCode + "_" + Guid.NewGuid().ToString("N");

                    HttpResponseMessage apiResponseJson;

                    if (userRequest.FinancialServices == null)
                    {

                        ApiPaymentRequestExistingCustomerDefaultCard requestModel = new ApiPaymentRequestExistingCustomerDefaultCard
                        {

                            Customer = new CustomerRequestModelExistingCustomer() { Email = userRequest.CustomerEmail, Telephone = userRequest.CustomerMsisdn, MerchantRef = customerMerchantReference, IpAddress = userRequest.IpAddress },
                            PaymentMethod = new PaymentMethodRequestModelExistingCustomer() { FromCustomer = new CardRequestModelExistingCustomer() { CV2 = userRequest.CardCv2 } },
                            Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                            TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                            Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                            CustomFields = userRequest.CustomFields
                        };

                        //Uncomment When Pay360 fix it
                        //if(isCustomerEmailUpdated)
                        //{
                        //    requestModel.Customer.Email = userRequest.CustomerEmail;
                        //    requestModel.Customer.Update = true;
                        //}

                        try
                        {
                            if (userRequest.Recurring)
                            {
                                requestModel.Transaction.ContinuousAuthorityAgreement = new ContinuousAuthorityAgreement { Expiry = DateTime.UtcNow.AddYears(1).ToString("yyyy-MM-dd"), MinFrequency = 1 };
                            }
                            apiResponseJson = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                        }
                        catch (Exception)
                        {
                            await SaveFailedTransactionApiError(transactionMerchantRef, customer.Id, PaymentMethods.Card, requestModel.Transaction.Deferred, requestModel.Transaction.Amount, requestModel.Transaction.Currency, userRequest.Basket, creds.ApiInstallationIdCashierApi);
                            throw;
                        }
                        if (DataPolicyConfig.DisablePaymentMethodInRequest)
                        {
                            requestModel.PaymentMethod = null;
                        }
                        requestJson = JsonConvert.SerializeObject(requestModel);
                    }
                    else
                    {
                        ApiPaymentRequestExistingCustomerDefaultCardWithFinancialServices requestModel = new ApiPaymentRequestExistingCustomerDefaultCardWithFinancialServices
                        {

                            Customer = new CustomerRequestModelExistingCustomer() { Email = userRequest.CustomerEmail, Telephone = userRequest.CustomerMsisdn, MerchantRef = customerMerchantReference, IpAddress = userRequest.IpAddress },
                            PaymentMethod = new PaymentMethodRequestModelExistingCustomer() { FromCustomer = new CardRequestModelExistingCustomer() { CV2 = userRequest.CardCv2 } },
                            Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                            FinancialServices = new UserFinancialServicesModel() { AccountNumber = userRequest.FinancialServices.AccountNumber, DateOfBirth = userRequest.FinancialServices.DateOfBirth, PostCode = userRequest.FinancialServices.PostCode, Surname = userRequest.FinancialServices.Surname },
                            TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                            Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                            CustomFields = userRequest.CustomFields
                        };

                        //Uncomment When Pay360 fix it
                        //if (isCustomerEmailUpdated)
                        //{
                        //    requestModel.Customer.Email = userRequest.CustomerEmail;
                        //    requestModel.Customer.Update = true;
                        //}

                        try
                        {
                            if (userRequest.Recurring)
                            {
                                requestModel.Transaction.ContinuousAuthorityAgreement = new ContinuousAuthorityAgreement { Expiry = DateTime.UtcNow.AddYears(1).ToString("yyyy-MM-dd"), MinFrequency = 1 };
                            }
                            apiResponseJson = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                        }
                        catch (Exception)
                        {
                            await SaveFailedTransactionApiError(transactionMerchantRef, customer.Id, PaymentMethods.Card, requestModel.Transaction.Deferred, requestModel.Transaction.Amount, requestModel.Transaction.Currency, userRequest.Basket, creds.ApiInstallationIdCashierApi);
                            throw;
                        }
                        if (DataPolicyConfig.DisablePaymentMethodInRequest)
                        {
                            requestModel.PaymentMethod = null;
                        }
                        requestJson = JsonConvert.SerializeObject(requestModel);
                    }

                    ApiPaymentResponse apiResponse;
                    string responseJson = "";
                    if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.Created)
                    {
                        responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                        apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                        Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, customer.Id, transactionMerchantRef, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                        dbTransaction.RequestJsonToPay360 = requestJson;
                        dbTransaction.ResponseJsonFromPay360 = responseJson;
                        DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_DEFAULTCARD, true, userRequest.IpAddress);
                        if (isCustomerEmailUpdated)
                        {
                            await Db.UpdateCustomerEmail(customer.MerchantRef, userRequest.CustomerEmail);
                        }

                        if (result.DBStatus != 1)
                        {
                            return response = GenericApiResponse<UserResponseModels>.Failure("Transaction Successfull but Error in Database Insertion: " + result.DBErrorMessage, 11);
                        }

                        UserResponseModels userResponse = new UserResponseModels()
                        {
                            CustomerId = apiResponse.Customer.Id.ToString(),
                            TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                            TransactionId = apiResponse.Transaction.TransactionId,
                            ClientRedirect = apiResponse.ClientRedirect,
                            ThreeDSecure = apiResponse.ThreeDSecure,
                            MaskedPan = apiResponse.PaymentMethod.Card.MaskedPan,
                            Recurring = apiResponse.Transaction.Recurring,
                            OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status }
                        };

                        if (userRequest.IsAuthorizationOnly == false && userRequest.Do3DSecure == false && userRequest.IsDirectFullfilment == true)
                        {
                            // Fullfilment
                            return response = await Fullfilment(userResponse, apiResponse.Transaction.TransactionId, result.Data.ToString(), userRequest.TransactionCurrency, customerMerchantReference, userRequest.CustomerEmail, userRequest.CustomerMsisdn);
                        }
                        else if (userRequest.IsAuthorizationOnly == false && userRequest.Do3DSecure == true && userRequest.IsDirectFullfilment == true && userResponse.OutcomeModel.ReasonCode == "S100" && userResponse.ClientRedirect == null) // Transaction Successfull and Completed but Card Not Enrolled in 3Ds
                        {
                            // Fullfilment
                            return response = await Fullfilment(userResponse, apiResponse.Transaction.TransactionId, result.Data.ToString(), userRequest.TransactionCurrency, customerMerchantReference, userRequest.CustomerEmail, userRequest.CustomerMsisdn);
                        }

                        response = GenericApiResponse<UserResponseModels>.Success(userResponse, "Success");
                    }
                    else if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.MultiStatus)
                    {
                        responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                        apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);
                        Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, customer.Id, transactionMerchantRef, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                        dbTransaction.RequestJsonToPay360 = requestJson;
                        dbTransaction.ResponseJsonFromPay360 = responseJson;
                        DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_DEFAULTCARD, false, userRequest.IpAddress);

                        string errorMessage = apiResponse.Outcome.ReasonMessage;
                        string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", responseJson).Trim();
                        if (reasonCode == "A136")
                        {
                            errorMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                        }
                        if (result.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }

                        response = GenericApiResponse<UserResponseModels>.Failure(errorMessage, 12);
                        response.pay360ApiCode = reasonCode;

                    }
                    else
                    {

                        string jsonResult = await apiResponseJson.Content.ReadAsStringAsync();
                        Pay360Transaction dbTransaction = new Pay360Transaction();
                        dbTransaction.Customer_Id = customer.Id;
                        dbTransaction.TransactionMerchantRef = transactionMerchantRef;
                        dbTransaction.RequestJsonToPay360 = requestJson;
                        dbTransaction.ResponseJsonFromPay360 = jsonResult;
                        dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                        dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                        int transactionTypeId = (userRequest.IsAuthorizationOnly == true ? (int)Pay360TransactionTypes.PREAUTH : (int)Pay360TransactionTypes.PAYMENT);
                        dbTransaction.TransactionType_Id = transactionTypeId;
                        dbTransaction.TransactionAmount = userRequest.TransactionAmount;
                        dbTransaction.TransactionCurrency = userRequest.TransactionCurrency;
                        dbTransaction.RequestTime = DateTime.UtcNow;
                        string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                        dbTransaction.OutcomeReasonMessage = reasonMessage;
                        dbTransaction.Is3DSecure = userRequest.Do3DSecure;
                        dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                        DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_DEFAULTCARD, false, userRequest.IpAddress);
                        string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();
                        if (reasonCode == "A136")
                        {
                            reasonMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                        }
                        if (result.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + reasonMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }

                        response = GenericApiResponse<UserResponseModels>.Failure(reasonMessage, 12);
                        response.pay360ApiCode = reasonCode;

                    }

                }
                else // Customer does not exists -> return error 
                {
                    response = GenericApiResponse<UserResponseModels>.Failure("Customer does not exists.", 23);
                }
            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserResponseModels>.Failure(ex.Message);
                throw;
            }

            return response;
        }

        public async Task<GenericApiResponse<UserResponseModels>> ExistingCustomerPaymentNewCard(UserPaymentRequestExistingCustomerNewCard userRequest)
        {
            var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(userRequest.CustomerMsisdn, userRequest.ProductCode, nameof(Pay360PaymentType.CARD));

            if (userRequest.BillingAddress == null)
            {
                userRequest.BillingAddress = new BillingAddress();
                userRequest.BillingAddress.Line1 = "";
                userRequest.BillingAddress.Line2 = "";
                userRequest.BillingAddress.Line3 = "";
                userRequest.BillingAddress.Line4 = "";
                userRequest.BillingAddress.PostCode = "";
                userRequest.BillingAddress.Region = "";
                userRequest.BillingAddress.City = "";
                userRequest.BillingAddress.CountryCode = "";
            }


            GenericApiResponse<UserResponseModels> response;

            bool sendpay360Email = false;

            if (userRequest.SendPay360Email == true && !string.IsNullOrWhiteSpace(userRequest.CustomerEmail))
            {
                sendpay360Email = true;
            }

            string requestJson = "";

            string customerMerchantReference;

            if (userRequest.ProductCode.ToLower() == "tha")
            {
                customerMerchantReference = userRequest.CustomerUniqueRef;
            }
            else
            {
                customerMerchantReference = userRequest.ProductCode + "_" + userRequest.CustomerUniqueRef;
            }

            try
            {

                string description = "";
                if (!userRequest.OverrideValidation)
                {
                    GenericApiResponse<UserResponseModels> validationResponse = await Validations(userRequest.CustomerMsisdn, userRequest.ProductCode, userRequest.TransactionAmount, userRequest.Basket);
                    if (validationResponse.errorCode == 0) // Validation Successfull
                    {
                        description = validationResponse.message;
                    }
                    else // Validation Error
                    {
                        return validationResponse;
                    }
                }

                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/payment";

                Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                //Uncomment When Pay360 fix it
                //sendEmail = string.IsNullOrWhiteSpace(customer.Email) ? false : true;
                bool isCustomerEmailUpdated = false;

                //DbResult<bool> validateTopupResult = await Db.ValidateTopUp(userRequest.CustomerMsisdn, userRequest.TransactionAmount);
                //if (validateTopupResult.DBStatus != 1)
                //{
                //    return response = GenericApiResponse<UserResponseModels>.Failure(validateTopupResult.DBErrorMessage, validateTopupResult.DBStatus);
                //}

                if (customer != null)
                {
                    if (!string.IsNullOrWhiteSpace(userRequest.CustomerEmail) && userRequest.CustomerEmail != customer.Email)
                    {
                        isCustomerEmailUpdated = true;
                    }

                    string transactionMerchantRef = userRequest.ProductCode + "_" + Guid.NewGuid().ToString("N");

                    HttpResponseMessage apiResponseJson;

                    if (userRequest.FinancialServices == null)
                    {

                        ApiPaymentRequestExistingCustomerNewCard requestModel = null;

                        if (userRequest.BillingAddress.Line1 != "")
                        {

                            requestModel = new ApiPaymentRequestExistingCustomerNewCard
                            {
                                TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                                Customer = new CustomerRequestModelExistingCustomer() { Email = userRequest.CustomerEmail, Telephone = userRequest.CustomerMsisdn, MerchantRef = customerMerchantReference, IpAddress = userRequest.IpAddress },
                                PaymentMethod = new PaymentMethodRequestModel()
                                {
                                    Registered = userRequest.SaveCard,
                                    Card = new CardRequestModel() { CardHolderName = userRequest.CustomerName, CV2 = userRequest.CardCv2, DefaultCard = userRequest.IsDefaultCard, ExpiryDate = userRequest.CardExpiryDate, Pan = userRequest.CardPan },
                                    CardBillingAddress = new CardBillingAddress() { City = userRequest.BillingAddress.City, CountryCode = userRequest.BillingAddress.CountryCode, Line1 = userRequest.BillingAddress.Line1, Line2 = userRequest.BillingAddress.Line2, Line3 = userRequest.BillingAddress.Line3, Line4 = userRequest.BillingAddress.Line4, PostCode = userRequest.BillingAddress.PostCode, Region = userRequest.BillingAddress.Region }
                                },
                                Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                                Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                                CustomFields = userRequest.CustomFields
                            };
                        }
                        else
                        {
                            requestModel = new ApiPaymentRequestExistingCustomerNewCard
                            {
                                TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                                Customer = new CustomerRequestModelExistingCustomer() { Email = userRequest.CustomerEmail, Telephone = userRequest.CustomerMsisdn, MerchantRef = customerMerchantReference, IpAddress = userRequest.IpAddress },
                                PaymentMethod = new PaymentMethodRequestModel()
                                {
                                    Registered = userRequest.SaveCard,
                                    Card = new CardRequestModel() { CardHolderName = userRequest.CustomerName, CV2 = userRequest.CardCv2, DefaultCard = userRequest.IsDefaultCard, ExpiryDate = userRequest.CardExpiryDate, Pan = userRequest.CardPan }
                                },
                                Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                                Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                                CustomFields = userRequest.CustomFields
                            };


                        }

                        //if (isCustomerEmailUpdated)
                        //{
                        //    requestModel.Customer.Email = userRequest.CustomerEmail;
                        //    requestModel.Customer.Update = true;
                        //}
                        //else
                        //{
                        //    requestModel.Customer.Email = customer.Email;
                        //    requestModel.Customer.Update = true;
                        //}

                        try
                        {
                            if (userRequest.Recurring)
                            {
                                requestModel.Transaction.ContinuousAuthorityAgreement = new ContinuousAuthorityAgreement { Expiry = DateTime.UtcNow.AddYears(1).ToString("yyyy-MM-dd"), MinFrequency = 1 };
                            }
                            apiResponseJson = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                        }
                        catch (Exception)
                        {
                            await SaveFailedTransactionApiError(transactionMerchantRef, customer.Id, PaymentMethods.Card, requestModel.Transaction.Deferred, requestModel.Transaction.Amount, requestModel.Transaction.Currency, userRequest.Basket, creds.ApiInstallationIdCashierApi);
                            throw;
                        }
                        if (DataPolicyConfig.DisablePaymentMethodInRequest)
                        {
                            requestModel.PaymentMethod = null;
                        }
                        requestJson = JsonConvert.SerializeObject(requestModel);
                    }
                    else
                    {
                        ApiPaymentRequestExistingCustomerNewCardWithFinancialServices requestModel = new ApiPaymentRequestExistingCustomerNewCardWithFinancialServices
                        {
                            TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                            Customer = new CustomerRequestModelExistingCustomer() { Email = userRequest.CustomerEmail, Telephone = userRequest.CustomerMsisdn, MerchantRef = customerMerchantReference, IpAddress = userRequest.IpAddress },
                            PaymentMethod = new PaymentMethodRequestModel()
                            {
                                Registered = userRequest.SaveCard,
                                Card = new CardRequestModel() { CardHolderName = userRequest.CustomerName, CV2 = userRequest.CardCv2, DefaultCard = userRequest.IsDefaultCard, ExpiryDate = userRequest.CardExpiryDate, Pan = userRequest.CardPan },
                                CardBillingAddress = new CardBillingAddress() { City = userRequest.BillingAddress.City, CountryCode = userRequest.BillingAddress.CountryCode, Line1 = userRequest.BillingAddress.Line1, Line2 = userRequest.BillingAddress.Line2, Line3 = userRequest.BillingAddress.Line3, Line4 = userRequest.BillingAddress.Line4, PostCode = userRequest.BillingAddress.PostCode, Region = userRequest.BillingAddress.Region }
                            },
                            Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                            FinancialServices = new UserFinancialServicesModel() { AccountNumber = userRequest.FinancialServices.AccountNumber, DateOfBirth = userRequest.FinancialServices.DateOfBirth, PostCode = userRequest.FinancialServices.PostCode, Surname = userRequest.FinancialServices.Surname },
                            Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                            CustomFields = userRequest.CustomFields
                        };

                        //if (isCustomerEmailUpdated)
                        //{
                        //    requestModel.Customer.Email = userRequest.CustomerEmail;
                        //    requestModel.Customer.Update = true;
                        //}
                        //else
                        //{
                        //    requestModel.Customer.Email = customer.Email;
                        //    requestModel.Customer.Update = true;
                        //}

                        try
                        {
                            if (userRequest.Recurring)
                            {
                                requestModel.Transaction.ContinuousAuthorityAgreement = new ContinuousAuthorityAgreement
                                {
                                    Expiry = DateTime.UtcNow.AddYears(1).ToString("yyyy-MM-dd"),
                                    MinFrequency = 1
                                };
                            }
                            apiResponseJson = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                        }
                        catch (Exception)
                        {
                            await SaveFailedTransactionApiError(transactionMerchantRef, customer.Id, PaymentMethods.Card, requestModel.Transaction.Deferred, requestModel.Transaction.Amount, requestModel.Transaction.Currency, userRequest.Basket, creds.ApiInstallationIdCashierApi);
                            throw;
                        }
                        if (DataPolicyConfig.DisablePaymentMethodInRequest)
                        {
                            requestModel.PaymentMethod.Card = null;
                        }
                        requestJson = JsonConvert.SerializeObject(requestModel);
                    }
                    ApiPaymentResponse apiResponse;
                    string responseJson = "";
                    if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.Created)
                    {
                        responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                        apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                        Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, customer.Id, transactionMerchantRef, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                        dbTransaction.RequestJsonToPay360 = requestJson;
                        dbTransaction.ResponseJsonFromPay360 = responseJson;
                        DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_NEWCARD, true, userRequest.IpAddress);

                        //Update user's default card if true
                        if (userRequest.IsDefaultCard)
                        {
                            string key = Guid.NewGuid().ToString("N");
                            string cV2 = RijndaelEncryption.Encrypt(userRequest.CardCv2, key);
                            await Db.UpdateCustomerDefaultCv2(customer.MerchantRef, cV2, key);
                        }

                        if (isCustomerEmailUpdated)
                        {
                            await Db.UpdateCustomerEmail(customer.MerchantRef, userRequest.CustomerEmail);
                        }

                        if (result.DBStatus != 1)
                        {
                            return response = GenericApiResponse<UserResponseModels>.Failure("Transaction Successfull but Error in Database Insertion: " + result.DBErrorMessage, 11);
                        }

                        UserResponseModels userResponse = new UserResponseModels()
                        {
                            CustomerId = apiResponse.Customer.Id.ToString(),
                            TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                            TransactionId = apiResponse.Transaction.TransactionId,
                            ClientRedirect = apiResponse.ClientRedirect,
                            ThreeDSecure = apiResponse.ThreeDSecure,
                            Recurring = apiResponse.Transaction.Recurring,
                            MaskedPan = apiResponse.PaymentMethod.Card.MaskedPan,
                            OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status }
                        };

                        if (userRequest.IsAuthorizationOnly == false && userRequest.Do3DSecure == false && userRequest.IsDirectFullfilment == true)
                        {
                            // Fullfilment
                            return response = await Fullfilment(userResponse, apiResponse.Transaction.TransactionId, result.Data.ToString(), userRequest.TransactionCurrency, customerMerchantReference, userRequest.CustomerEmail, userRequest.CustomerMsisdn);
                        }
                        else if (userRequest.IsAuthorizationOnly == false && userRequest.Do3DSecure == true && userRequest.IsDirectFullfilment == true && userResponse.OutcomeModel.ReasonCode == "S100" && userResponse.ClientRedirect == null) // Transaction Successfull and Completed but Card Not Enrolled in 3Ds
                        {
                            // Fullfilment
                            return response = await Fullfilment(userResponse, apiResponse.Transaction.TransactionId, result.Data.ToString(), userRequest.TransactionCurrency, customerMerchantReference, userRequest.CustomerEmail, userRequest.CustomerMsisdn);
                        }

                        response = GenericApiResponse<UserResponseModels>.Success(userResponse, "Success");
                    }
                    else if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.MultiStatus)
                    {
                        responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                        apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                        Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, customer.Id, transactionMerchantRef, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                        dbTransaction.RequestJsonToPay360 = requestJson;
                        dbTransaction.ResponseJsonFromPay360 = responseJson;
                        DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_NEWCARD, false, userRequest.IpAddress);

                        string errorMessage = apiResponse.Outcome.ReasonMessage;
                        string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", responseJson).Trim();
                        if (reasonCode == "A136")
                        {
                            errorMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                        }
                        if (result.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }

                        response = GenericApiResponse<UserResponseModels>.Failure(errorMessage, 12);
                        response.pay360ApiCode = reasonCode;

                    }
                    else
                    {

                        string jsonResult = await apiResponseJson.Content.ReadAsStringAsync();
                        Pay360Transaction dbTransaction = new Pay360Transaction();
                        dbTransaction.Customer_Id = customer.Id;
                        dbTransaction.TransactionMerchantRef = transactionMerchantRef;
                        dbTransaction.RequestJsonToPay360 = requestJson;
                        dbTransaction.ResponseJsonFromPay360 = jsonResult;
                        dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                        dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                        int transactionTypeId = (userRequest.IsAuthorizationOnly == true ? (int)Pay360TransactionTypes.PREAUTH : (int)Pay360TransactionTypes.PAYMENT);
                        dbTransaction.TransactionType_Id = transactionTypeId;
                        dbTransaction.TransactionAmount = userRequest.TransactionAmount;
                        dbTransaction.TransactionCurrency = userRequest.TransactionCurrency;
                        dbTransaction.RequestTime = DateTime.UtcNow;
                        string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                        dbTransaction.OutcomeReasonMessage = reasonMessage;
                        dbTransaction.Is3DSecure = userRequest.Do3DSecure;
                        dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                        DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_NEWCARD, false, userRequest.IpAddress);
                        string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();
                        if (reasonCode == "A136")
                        {
                            reasonMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                        }
                        if (result.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + reasonMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }

                        response = GenericApiResponse<UserResponseModels>.Failure(reasonMessage, 12);
                        response.pay360ApiCode = reasonCode;
                    }

                }

                else // Customer does not exists -> return error 
                {
                    response = GenericApiResponse<UserResponseModels>.Failure("Customer does not exists.", 23);
                }
            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserResponseModels>.Failure(ex.Message, 14);
                throw;
            }

            return response;
        }

        public async Task<GenericApiResponse<UserResponseModels>> Resume3DSecureTransaction(UserRequestResume3DSecureTransaction userRequest)
        {
            GenericApiResponse<UserResponseModels> response = (GenericApiResponse<UserResponseModels>)null;
            string requestJson = "";
            try
            {
                var PrimaryTransaction = await Db.GetTransactionByPay360TransactionId(userRequest.Pay360TransactionId);

                if (PrimaryTransaction == null)
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure("Transaction not found", 20);
                }

                var creds = pay360Auth.GetApiCredsByInstallationId(PrimaryTransaction.ApiInstallationIdCashierApi);

                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/" + userRequest.Pay360TransactionId + "/resume";


                HttpResponseMessage apiResponseJson;
                Resume3DSecureTransactionModel requestModel = new Resume3DSecureTransactionModel
                {
                    ThreeDSecureResponse = new ThreeDSecureResponseModel() { Pares = userRequest.Pareq }
                };
                requestJson = JsonConvert.SerializeObject(requestModel);
                try
                {
                    apiResponseJson = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                }
                catch (Exception)
                {
                    await SaveFailedTransactionApiErrorWithoutBasket(PrimaryTransaction.TransactionMerchantRef, PrimaryTransaction.Customer_Id, PaymentMethods.Card, false, PrimaryTransaction.TransactionAmount, PrimaryTransaction.TransactionCurrency, creds.ApiInstallationIdCashierApi);
                    //await SaveFailed3DTransactionApiError(userRequest.Pay360TransactionId, userRequest.Pareq);
                    DbResult<int> resultUpdate = await Db.UpdateTransactionSummary(userRequest.Pay360TransactionId, 0, Pay360SummaryTransactionStatuses.RESUMETIMEOUT, DateTime.UtcNow, true);
                    throw;
                }
                ApiPaymentResponse apiResponse;
                string responseJson = "";
                if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                    Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, PrimaryTransaction.Customer_Id, null, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = responseJson;
                    await Db.AddTransactionWithoutBasket(dbTransaction);

                    Pay360TransactionSummary pay360TransactionSummary = await Db.GetTransactionSummaryByPay360TransactionId(userRequest.Pay360TransactionId);

                    if (pay360TransactionSummary != null)
                    {
                        UserResponseModels userResponse = new UserResponseModels();

                        //if (apiResponse != null && apiResponse.ThreeDSecure != null && apiResponse.ThreeDSecure.Status.ToUpper().Trim() == "AUTHENTICATED")
                        if (apiResponse != null && apiResponse.Outcome.ReasonCode.ToUpper() == "S100")
                        {
                            DbResult<int> result = await Db.UpdateSummaryThreeDSecureCompleted(pay360TransactionSummary.Id);
                            if (result.DBStatus != 1)
                            {
                                return response = GenericApiResponse<UserResponseModels>.Failure("Transaction Successful , Database update failed", 11);
                            }

                            userResponse = new UserResponseModels()
                            {
                                CustomerId = apiResponse.Customer.Id.ToString(),
                                TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                                TransactionId = apiResponse.Transaction.TransactionId,
                                ThreeDSecure = apiResponse.ThreeDSecure,
                                MaskedPan = apiResponse.PaymentMethod.Card.MaskedPan,
                                Recurring = apiResponse.Transaction.Recurring,
                                OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status }
                            };

                            if (pay360TransactionSummary.TransactionStatus_Id == (Pay360SummaryTransactionStatuses.SINGLEPAYMENT) && pay360TransactionSummary.IsDirectFullfilment == true)
                            {
                                // Fullfilment
                                return response = await Fullfilment(userResponse, PrimaryTransaction.Pay360TransactionId, PrimaryTransaction.Id.ToString(), apiResponse.Transaction.Currency, pay360TransactionSummary.CustomerMerchantRef, userRequest.CustomerEmail, PrimaryTransaction.Msisdn);
                            }

                            response = GenericApiResponse<UserResponseModels>.Success(userResponse, "Success");
                        }
                        else
                        {
                            DbResult<int> result = await Db.UpdateSummaryThreeDSecureFailed(pay360TransactionSummary.Id);
                            userResponse = new UserResponseModels()
                            {
                                CustomerId = apiResponse.Customer.Id.ToString(),
                                TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                                TransactionId = apiResponse.Transaction.TransactionId,
                                ThreeDSecure = apiResponse.ThreeDSecure,
                                MaskedPan = apiResponse.PaymentMethod.Card.MaskedPan,
                                Recurring = apiResponse.Transaction.Recurring,
                                OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status }
                            };
                            response = GenericApiResponse<UserResponseModels>.Failure(userResponse, "3DS Authentication Failed", 16);
                        }
                    }
                    else
                    {
                        return response = GenericApiResponse<UserResponseModels>.Failure("Transaction failure , Database update failed", 15);
                    }
                }
                else if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.MultiStatus)
                {
                    responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                    Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, PrimaryTransaction.Customer_Id, null, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = responseJson;
                    DbResult<long> result = await Db.AddTransactionWithoutBasket(dbTransaction);

                    string errorMessage = apiResponse.Outcome.ReasonMessage;
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", responseJson).Trim();
                    if (reasonCode == "A136")
                    {
                        errorMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }
                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }


                    Pay360TransactionSummary pay360TransactionSummary = await Db.GetTransactionSummaryByPay360TransactionId(userRequest.Pay360TransactionId);
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", responseJson);
                    if (pay360TransactionSummary != null && reasonCode != "V107" && reasonCode != "A125" && (pay360TransactionSummary.TransactionStatus_Id == Pay360SummaryTransactionStatuses.SINGLEPAYMENT || pay360TransactionSummary.TransactionStatus_Id == Pay360SummaryTransactionStatuses.PREAUTH))
                    {
                        DbResult<int> resultUpdate = await Db.UpdateTransactionSummary(userRequest.Pay360TransactionId, 0, Pay360SummaryTransactionStatuses.RESUME3DFAILED, DateTime.UtcNow, true);
                        if (resultUpdate.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserResponseModels>.Failure("Resume 3D Failed: " + reasonMessage + " and error in Summary table updation: " + resultUpdate.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }
                    }

                    response = GenericApiResponse<UserResponseModels>.Failure(errorMessage, 12);
                    response.pay360ApiCode = reasonCode;

                }
                else
                {
                    string jsonResult = await apiResponseJson.Content.ReadAsStringAsync();
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    Pay360TransactionSummary pay360TransactionSummary = await Db.GetTransactionSummaryByPay360TransactionId(userRequest.Pay360TransactionId);
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();
                    Pay360Transaction dbTransaction = new Pay360Transaction();
                    dbTransaction.Customer_Id = PrimaryTransaction.Customer_Id;
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = jsonResult;
                    dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    int transactionTypeId = (int)Pay360TransactionTypes.PAYMENT;
                    dbTransaction.TransactionType_Id = transactionTypeId;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    dbTransaction.RelatedTransactionId = userRequest.Pay360TransactionId;
                    dbTransaction.OutcomeReasonMessage = reasonMessage;
                    dbTransaction.Is3DSecure = true;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                    DbResult<long> result = await Db.AddTransactionWithoutBasket(dbTransaction, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_NEWCARD, false);
                    if (reasonCode == "A136")
                    {
                        reasonMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }
                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserResponseModels>.Failure("Resume 3D Failed: " + reasonMessage + " and error in transaction insertion: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }
                    if (pay360TransactionSummary != null && reasonCode != "V107" && reasonCode != "A125" && (pay360TransactionSummary.TransactionStatus_Id == Pay360SummaryTransactionStatuses.SINGLEPAYMENT || pay360TransactionSummary.TransactionStatus_Id == Pay360SummaryTransactionStatuses.PREAUTH))
                    {
                        DbResult<int> resultUpdate = await Db.UpdateTransactionSummary(userRequest.Pay360TransactionId, 0, Pay360SummaryTransactionStatuses.RESUME3DFAILED, DateTime.UtcNow, true);
                        if (resultUpdate.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserResponseModels>.Failure("Resume 3D Failed: " + reasonMessage + " and error in Summary table updation: " + resultUpdate.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }
                    }
                    response = GenericApiResponse<UserResponseModels>.Failure(reasonMessage, 12);
                    response.pay360ApiCode = reasonCode;
                }

            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserResponseModels>.Failure(ex.Message, 14);
                throw;
            }

            return response;
        }

        public async Task<GenericApiResponse<UserResponseModels>> Resume3DsV2(UserRequestResume3DsV2 userRequest)
        {

            GenericApiResponse<UserResponseModels> response = (GenericApiResponse<UserResponseModels>)null;
            string requestJson = "";
            try
            {
                var PrimaryTransaction = await Db.GetTransactionByPay360TransactionId(userRequest.Pay360TransactionId);

                if (PrimaryTransaction == null)
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure("Transaction not found", 20);
                }

                var creds = pay360Auth.GetApiCredsByInstallationId(PrimaryTransaction.ApiInstallationIdCashierApi);

                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/" + userRequest.Pay360TransactionId + "/resume";

                HttpResponseMessage apiResponseJson;
                object requestModel = new object();

                requestJson = JsonConvert.SerializeObject(requestModel);
                try
                {
                    apiResponseJson = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                }
                catch (Exception)
                {
                    await SaveFailedTransactionApiErrorWithoutBasket(PrimaryTransaction.TransactionMerchantRef, PrimaryTransaction.Customer_Id, PaymentMethods.Card, false, PrimaryTransaction.TransactionAmount, PrimaryTransaction.TransactionCurrency, creds.ApiInstallationIdCashierApi);
                    //await SaveFailed3DTransactionApiError(userRequest.Pay360TransactionId, userRequest.Pareq);
                    throw;
                }
                ApiPaymentResponse apiResponse;
                string responseJson = "";
                if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                    Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, PrimaryTransaction.Customer_Id, null, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = responseJson;
                    await Db.AddTransactionWithoutBasket(dbTransaction);

                    Pay360TransactionSummary pay360TransactionSummary = await Db.GetTransactionSummaryByPay360TransactionId(userRequest.Pay360TransactionId);

                    if (pay360TransactionSummary != null)
                    {
                        UserResponseModels userResponse = new UserResponseModels();

                        //if (apiResponse != null && apiResponse.ThreeDSecure != null && apiResponse.ThreeDSecure.Status.ToUpper().Trim() == "AUTHENTICATED")
                        if (apiResponse != null && apiResponse.Outcome.ReasonCode.ToUpper() == "S100")
                        {
                            DbResult<int> result = await Db.UpdateSummaryThreeDSecureCompleted(pay360TransactionSummary.Id);
                            if (result.DBStatus != 1)
                            {
                                return response = GenericApiResponse<UserResponseModels>.Failure("Transaction Successful , Database update failed", 11);
                            }

                            userResponse = new UserResponseModels()
                            {
                                CustomerId = apiResponse.Customer.Id.ToString(),
                                TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                                TransactionId = apiResponse.Transaction.TransactionId,
                                ThreeDSecure = apiResponse.ThreeDSecure,
                                Recurring = apiResponse.Transaction.Recurring,
                                MaskedPan = apiResponse.PaymentMethod.Card.MaskedPan,
                                OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status }
                            };

                            if (pay360TransactionSummary.TransactionStatus_Id == (Pay360SummaryTransactionStatuses.SINGLEPAYMENT) && pay360TransactionSummary.IsDirectFullfilment == true)
                            {
                                // Fullfilment
                                return response = await Fullfilment(userResponse, PrimaryTransaction.Pay360TransactionId, PrimaryTransaction.Id.ToString(), apiResponse.Transaction.Currency, pay360TransactionSummary.CustomerMerchantRef, userRequest.CustomerEmail, PrimaryTransaction.Msisdn);
                            }

                            response = GenericApiResponse<UserResponseModels>.Success(userResponse, "Success");
                        }
                        else
                        {
                            DbResult<int> result = await Db.UpdateSummaryThreeDSecureFailed(pay360TransactionSummary.Id);
                            userResponse = new UserResponseModels()
                            {
                                CustomerId = apiResponse.Customer.Id.ToString(),
                                TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                                TransactionId = apiResponse.Transaction.TransactionId,
                                ThreeDSecure = apiResponse.ThreeDSecure,
                                MaskedPan = apiResponse.PaymentMethod.Card.MaskedPan,
                                Recurring = apiResponse.Transaction.Recurring,
                                OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status }
                            };
                            response = GenericApiResponse<UserResponseModels>.Failure(userResponse, "3DS Authentication Failed", 16);
                        }
                    }
                    else
                    {
                        return response = GenericApiResponse<UserResponseModels>.Failure("Transaction failure , Database update failed", 15);
                    }
                }
                else if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.MultiStatus)
                {
                    responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                    Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, PrimaryTransaction.Customer_Id, null, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = responseJson;
                    DbResult<long> result = await Db.AddTransactionWithoutBasket(dbTransaction);

                    string errorMessage = apiResponse.Outcome.ReasonMessage;
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", responseJson).Trim();
                    if (reasonCode == "A136")
                    {
                        errorMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }
                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserResponseModels>.Failure(errorMessage, 12);
                    response.pay360ApiCode = reasonCode;

                }
                else
                {
                    string jsonResult = await apiResponseJson.Content.ReadAsStringAsync();
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    Pay360TransactionSummary pay360TransactionSummary = await Db.GetTransactionSummaryByPay360TransactionId(userRequest.Pay360TransactionId);
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();
                    Pay360Transaction dbTransaction = new Pay360Transaction();
                    dbTransaction.Customer_Id = PrimaryTransaction.Customer_Id;
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = jsonResult;
                    dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    int transactionTypeId = (int)Pay360TransactionTypes.PAYMENT;
                    dbTransaction.TransactionType_Id = transactionTypeId;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    dbTransaction.RelatedTransactionId = userRequest.Pay360TransactionId;
                    dbTransaction.OutcomeReasonMessage = reasonMessage;
                    dbTransaction.Is3DSecure = true;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                    DbResult<long> result = await Db.AddTransactionWithoutBasket(dbTransaction, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_NEWCARD, false);
                    if (reasonCode == "A136")
                    {
                        reasonMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }
                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserResponseModels>.Failure("Resume 3D Failed: " + reasonMessage + " and error in transaction insertion: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }
                    if (pay360TransactionSummary != null && reasonCode != "V107" && reasonCode != "A125" && (pay360TransactionSummary.TransactionStatus_Id == Pay360SummaryTransactionStatuses.SINGLEPAYMENT || pay360TransactionSummary.TransactionStatus_Id == Pay360SummaryTransactionStatuses.PREAUTH))
                    {
                        DbResult<int> resultUpdate = await Db.UpdateTransactionSummary(userRequest.Pay360TransactionId, 0, Pay360SummaryTransactionStatuses.RESUME3DFAILED, DateTime.UtcNow, true);
                        if (resultUpdate.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserResponseModels>.Failure("Resume 3D Failed: " + reasonMessage + " and error in Summary table updation: " + resultUpdate.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }
                    }
                    response = GenericApiResponse<UserResponseModels>.Failure(reasonMessage, 12);
                    response.pay360ApiCode = reasonCode;
                }

            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserResponseModels>.Failure(ex.Message, 14);
                throw;
            }

            return response;
        }


        public async Task<GenericApiResponse<UserResponseModels>> ExistingCustomerPaymentCardToken(UserPaymentRequestCardToken userRequest)
        {
            var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(userRequest.CustomerMsisdn, userRequest.ProductCode, nameof(Pay360PaymentType.CARD));

            GenericApiResponse<UserResponseModels> response;


            string requestJson = "";

            string customerMerchantReference;

            if (userRequest.ProductCode.ToLower() == "tha")
            {
                customerMerchantReference = userRequest.CustomerUniqueRef;
            }
            else
            {
                customerMerchantReference = userRequest.ProductCode + "_" + userRequest.CustomerUniqueRef;
            }

            bool sendpay360Email = false;

            if (userRequest.SendPay360Email == true && !string.IsNullOrWhiteSpace(userRequest.CustomerEmail))
            {
                sendpay360Email = true;
            }

            try
            {
                string description = "";
                if (!userRequest.OverrideValidation)
                {
                    GenericApiResponse<UserResponseModels> validationResponse = await Validations(userRequest.CustomerMsisdn, userRequest.ProductCode, userRequest.TransactionAmount, userRequest.Basket);
                    if (validationResponse.errorCode == 0) // Validation Successfull
                    {
                        description = validationResponse.message;
                    }
                    else // Validation Error
                    {
                        return validationResponse;
                    }
                }

                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/payment";

                Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);

                bool isCustomerEmailUpdated = false;

                //DbResult<bool> validateTopupResult = await Db.ValidateTopUp(userRequest.CustomerMsisdn, userRequest.TransactionAmount);
                //if (validateTopupResult.DBStatus != 1)
                //{
                //    return response = GenericApiResponse<UserResponseModels>.Failure(validateTopupResult.DBErrorMessage, validateTopupResult.DBStatus);
                //}

                if (customer != null)
                {

                    //sendEmail = string.IsNullOrWhiteSpace(customer.Email) ? false : true;

                    if (!string.IsNullOrWhiteSpace(userRequest.CustomerEmail) && userRequest.CustomerEmail != customer.Email)
                    {
                        isCustomerEmailUpdated = true;
                    }

                    string transactionMerchantRef = userRequest.ProductCode + "_" + Guid.NewGuid().ToString("N");

                    HttpResponseMessage apiResponseJson;

                    if (userRequest.FinancialServices == null)
                    {

                        ApiPaymentRequestCardToken requestModel = new ApiPaymentRequestCardToken
                        {
                            TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                            Customer = new CustomerRequestModelExistingCustomer() { Email = userRequest.CustomerEmail, Telephone = userRequest.CustomerMsisdn, MerchantRef = customerMerchantReference, IpAddress = userRequest.IpAddress },
                            PaymentMethod = new CardTokenPaymentMethodRequestModel() { CardToken = new CardTokenRequestModel() { Token = userRequest.CardToken, Cv2 = userRequest.CardCv2 } },
                            Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                            Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                            CustomFields = userRequest.CustomFields
                        };

                        try
                        {
                            if (userRequest.Recurring)
                            {
                                requestModel.Transaction.ContinuousAuthorityAgreement = new ContinuousAuthorityAgreement { Expiry = DateTime.UtcNow.AddYears(1).ToString("yyyy-MM-dd"), MinFrequency = 1 };
                            }
                            apiResponseJson = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                        }
                        catch (Exception)
                        {
                            await SaveFailedTransactionApiError(transactionMerchantRef, customer.Id, PaymentMethods.Card, requestModel.Transaction.Deferred, requestModel.Transaction.Amount, requestModel.Transaction.Currency, userRequest.Basket, creds.ApiInstallationIdCashierApi);
                            throw;
                        }
                        if (DataPolicyConfig.DisablePaymentMethodInRequest)
                        {
                            requestModel.PaymentMethod = null;
                        }

                        requestJson = JsonConvert.SerializeObject(requestModel);
                    }
                    else
                    {
                        ApiPaymentRequestCardTokenWithFinancialServices requestModel = new ApiPaymentRequestCardTokenWithFinancialServices
                        {
                            TransactionOptions = new TransactionOptionsModel() { Do3DSecure = userRequest.Do3DSecure, SendEmailReceipt = sendpay360Email },
                            Customer = new CustomerRequestModelExistingCustomer() { Email = userRequest.CustomerEmail, Telephone = userRequest.CustomerMsisdn, MerchantRef = customerMerchantReference, IpAddress = userRequest.IpAddress },
                            PaymentMethod = new CardTokenPaymentMethodRequestModel() { CardToken = new CardTokenRequestModel() { Token = userRequest.CardToken, Cv2 = userRequest.CardCv2 } },
                            Transaction = new TransactionRequestModel() { Amount = userRequest.TransactionAmount, Currency = userRequest.TransactionCurrency, CommerceType = userRequest.CommerceType, Deferred = userRequest.IsAuthorizationOnly, Recurring = userRequest.Recurring, MerchantRef = transactionMerchantRef, Description = description },
                            FinancialServices = new UserFinancialServicesModel() { AccountNumber = userRequest.FinancialServices.AccountNumber, DateOfBirth = userRequest.FinancialServices.DateOfBirth, PostCode = userRequest.FinancialServices.PostCode, Surname = userRequest.FinancialServices.Surname },
                            Order = new Order() { OrderRef = transactionMerchantRef, ShippingAddress = userRequest.ShippingAddress },
                            CustomFields = userRequest.CustomFields
                        };

                        try
                        {
                            if (userRequest.Recurring)
                            {
                                requestModel.Transaction.ContinuousAuthorityAgreement = new ContinuousAuthorityAgreement
                                {
                                    Expiry = DateTime.UtcNow.AddYears(1).ToString("yyyy-MM-dd"),
                                    MinFrequency = 1
                                };
                            }
                            apiResponseJson = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                        }
                        catch (Exception)
                        {
                            await SaveFailedTransactionApiError(transactionMerchantRef, customer.Id, PaymentMethods.Card, requestModel.Transaction.Deferred, requestModel.Transaction.Amount, requestModel.Transaction.Currency, userRequest.Basket, creds.ApiInstallationIdCashierApi);
                            throw;
                        }
                        if (DataPolicyConfig.DisablePaymentMethodInRequest)
                        {
                            requestModel.PaymentMethod = null;
                        }
                        requestJson = JsonConvert.SerializeObject(requestModel);
                    }

                    ApiPaymentResponse apiResponse;
                    string responseJson = "";
                    if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.Created)
                    {
                        responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                        apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                        Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, customer.Id, transactionMerchantRef, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                        dbTransaction.RequestJsonToPay360 = requestJson;
                        dbTransaction.ResponseJsonFromPay360 = responseJson;
                        DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.PAYMENTTOKEN, AddSummaryTransaction: true, ipAddress: userRequest.IpAddress);
                        if (isCustomerEmailUpdated)
                        {
                            await Db.UpdateCustomerEmail(customer.MerchantRef, userRequest.CustomerEmail);
                        }

                        if (result.DBStatus != 1)
                        {
                            return response = GenericApiResponse<UserResponseModels>.Failure("Transaction Successfull but Error in Database Insertion: " + result.DBErrorMessage, 11);
                        }

                        UserResponseModels userResponse = new UserResponseModels()
                        {
                            CustomerId = apiResponse.Customer.Id.ToString(),
                            ClientRedirect = apiResponse.ClientRedirect,
                            ThreeDSecure = apiResponse.ThreeDSecure,
                            TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                            Recurring = apiResponse.Transaction.Recurring,
                            MaskedPan = apiResponse.PaymentMethod.Card.MaskedPan,
                            TransactionId = apiResponse.Transaction.TransactionId,
                            OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status }
                        };

                        if (userRequest.IsAuthorizationOnly == false && userRequest.Do3DSecure == false && userRequest.IsDirectFullfilment == true)
                        {
                            // Fullfilment
                            return response = await Fullfilment(userResponse, apiResponse.Transaction.TransactionId, result.Data.ToString(), userRequest.TransactionCurrency, customerMerchantReference, userRequest.CustomerEmail, userRequest.CustomerMsisdn);
                        }
                        else if (userRequest.IsAuthorizationOnly == false && userRequest.Do3DSecure == true && userRequest.IsDirectFullfilment == true && userResponse.OutcomeModel.ReasonCode == "S100" && userResponse.ClientRedirect == null) // Transaction Successfull and Completed but Card Not Enrolled in 3Ds
                        {
                            // Fullfilment
                            return response = await Fullfilment(userResponse, apiResponse.Transaction.TransactionId, result.Data.ToString(), userRequest.TransactionCurrency, customerMerchantReference, userRequest.CustomerEmail, userRequest.CustomerMsisdn);
                        }

                        response = GenericApiResponse<UserResponseModels>.Success(userResponse, "Success");
                    }
                    else if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.MultiStatus)
                    {
                        responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                        apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);
                        Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, customer.Id, transactionMerchantRef, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                        dbTransaction.RequestJsonToPay360 = requestJson;
                        dbTransaction.ResponseJsonFromPay360 = responseJson;
                        DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, AddSummaryTransaction: false, ipAddress: userRequest.IpAddress);

                        string errorMessage = apiResponse.Outcome.ReasonMessage;
                        string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", responseJson).Trim();
                        if (reasonCode == "A136")
                        {
                            errorMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                        }
                        if (result.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }

                        response = GenericApiResponse<UserResponseModels>.Failure(errorMessage, 12);
                        response.pay360ApiCode = reasonCode;

                    }
                    else
                    {
                        string jsonResult = await apiResponseJson.Content.ReadAsStringAsync();
                        Pay360Transaction dbTransaction = new Pay360Transaction();
                        dbTransaction.Customer_Id = customer.Id;
                        dbTransaction.TransactionMerchantRef = transactionMerchantRef;
                        dbTransaction.RequestJsonToPay360 = requestJson;
                        dbTransaction.ResponseJsonFromPay360 = jsonResult;
                        dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                        dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                        int transactionTypeId = (userRequest.IsAuthorizationOnly == true ? (int)Pay360TransactionTypes.PREAUTH : (int)Pay360TransactionTypes.PAYMENT);
                        dbTransaction.TransactionType_Id = transactionTypeId;
                        dbTransaction.TransactionAmount = userRequest.TransactionAmount;
                        dbTransaction.TransactionCurrency = userRequest.TransactionCurrency;
                        dbTransaction.RequestTime = DateTime.UtcNow;
                        string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                        dbTransaction.OutcomeReasonMessage = reasonMessage;
                        dbTransaction.Is3DSecure = userRequest.Do3DSecure;
                        dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                        DbResult<long> result = await Db.AddTransaction(dbTransaction, userRequest.Basket, userRequest.IsDirectFullfilment, Pay360SummaryTransactionTypes.PAYMENTTOKEN, false, userRequest.IpAddress);
                        string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();
                        if (reasonCode == "A136")
                        {
                            reasonMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                        }
                        if (result.DBStatus != 1)
                        {
                            response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + reasonMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                            response.pay360ApiCode = reasonCode;
                            return response;
                        }

                        response = GenericApiResponse<UserResponseModels>.Failure(reasonMessage, 12);
                        response.pay360ApiCode = reasonCode;
                    }

                }
                else // Customer does not exists -> return error 
                {
                    response = GenericApiResponse<UserResponseModels>.Failure("Customer does not exists.", 23);
                }
            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserResponseModels>.Failure(ex.Message, 14);
                throw;
            }

            return response;
        }

        public async Task<GenericApiResponse<UserResponseModels>> RepeatTransaction(UserRequestRepeatTransaction userRequest)
        {

            GenericApiResponse<UserResponseModels> response;
            string requestJson = "";
            try
            {
                var PrimaryTransaction = await Db.GetTransactionByPay360TransactionId(userRequest.Pay360TransactionId);

                string transactionMerchantRef = userRequest.ProductCode + "_" + Guid.NewGuid().ToString("N");
                if (PrimaryTransaction == null)
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure("Transaction not found", 20);
                }

                var creds = pay360Auth.GetApiCredsByInstallationId(PrimaryTransaction.ApiInstallationIdCashierApi);

                ProductBasket[] productBasket = await Db.GetTransactionItems(PrimaryTransaction.Id.ToString());

                //var transactionToBeRepeated = await Db.GetTransactionSummaryByPay360TransactionId(userRequest.Pay360TransactionId);
                //DbResult<bool> validateTopupResult = await Db.ValidateTopUp(userRequest.CustomerMsisdn, (float)transactionToBeRepeated.TransactionAmount.Value);
                //if (validateTopupResult.DBStatus != 1)
                //{
                //    return response = GenericApiResponse<UserResponseModels>.Failure(validateTopupResult.DBErrorMessage, validateTopupResult.DBStatus);
                //}
                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/" + userRequest.Pay360TransactionId + "/repeat";

                HttpResponseMessage apiResponseJson;
                var apiRequest = new ApiRequestRepeatTransactionOverride
                {
                    Transaction = new ApiRequestRepeatTransactionOverride.RepeatTransactionRequestModel
                    {
                        Amount = userRequest.Amount,
                        MerchantRef = transactionMerchantRef,
                        CommerceType = userRequest.CommerceType,
                        Currency = PrimaryTransaction.TransactionCurrency,
                        Deferred = false,
                        Recurring = true
                    }
                };
                requestJson = JsonConvert.SerializeObject(apiRequest);
                try
                {
                    apiResponseJson = await ApiCall.Post(apiEndPoint, apiRequest, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                }
                catch (Exception)
                {
                    await SaveFailedTransactionApiError(transactionMerchantRef, PrimaryTransaction.Customer_Id, PaymentMethods.Card, false, PrimaryTransaction.TransactionAmount, PrimaryTransaction.TransactionCurrency, productBasket, creds.ApiInstallationIdCashierApi);
                    //await SaveFailed3DTransactionApiError(userRequest.Pay360TransactionId, userRequest.Pareq);
                    throw;
                }
                ApiPaymentResponse apiResponse;
                string responseJson = "";
                if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                    Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, PrimaryTransaction.Customer_Id, transactionMerchantRef, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = responseJson;

                    Pay360TransactionSummary pay360TransactionSummary = await Db.GetTransactionSummaryByPay360TransactionId(userRequest.Pay360TransactionId);

                    DbResult<long> result = await Db.AddTransaction(dbTransaction, productBasket, pay360TransactionSummary.IsDirectFullfilment, Pay360SummaryTransactionTypes.REPEAT, true);

                    if (result.DBStatus != 1)
                    {
                        return response = GenericApiResponse<UserResponseModels>.Failure("Transaction Successfull but Error in Database Insertion: " + result.DBErrorMessage, 11);
                    }

                    UserResponseModels userResponse = new UserResponseModels()
                    {
                        //CustomerId = apiResponse.Customer.Id.ToString(),
                        TransactionAmount = apiResponse.Transaction.Amount.ToString().Replace(",", "."),
                        TransactionId = apiResponse.Transaction.TransactionId,
                        MaskedPan = apiResponse.PaymentMethod.Card.MaskedPan,
                        Recurring = apiResponse.Transaction.Recurring,
                        ThreeDSecure = apiResponse.ThreeDSecure,
                        OutcomeModel = new OutcomeModel() { ReasonCode = apiResponse.Outcome.ReasonCode, ReasonMessage = apiResponse.Outcome.ReasonMessage, Status = apiResponse.Outcome.Status }
                    };

                    if (pay360TransactionSummary.TransactionStatus_Id == (Pay360SummaryTransactionStatuses.SINGLEPAYMENT) && pay360TransactionSummary.IsDirectFullfilment == true && pay360TransactionSummary.Is3DSecure == false)
                    {
                        // Fullfilment
                        return response = await Fullfilment(userResponse, PrimaryTransaction.Pay360TransactionId, PrimaryTransaction.Id.ToString(), apiResponse.Transaction.Currency, pay360TransactionSummary.CustomerMerchantRef, PrimaryTransaction.Msisdn);
                    }
                    else if (pay360TransactionSummary.TransactionStatus_Id == (Pay360SummaryTransactionStatuses.SINGLEPAYMENT) && pay360TransactionSummary.IsDirectFullfilment == true && pay360TransactionSummary.Is3DSecure == true && userResponse.OutcomeModel.ReasonCode == "S100" && userResponse.ClientRedirect == null) // Transaction Successfull and Completed but Card Not Enrolled in 3Ds
                    {
                        // Fullfilment
                        return response = await Fullfilment(userResponse, PrimaryTransaction.Pay360TransactionId, PrimaryTransaction.Id.ToString(), apiResponse.Transaction.Currency, pay360TransactionSummary.CustomerMerchantRef, "", PrimaryTransaction.Msisdn);
                    }


                    response = GenericApiResponse<UserResponseModels>.Success(userResponse, "Success");
                }
                else if (apiResponseJson.StatusCode == System.Net.HttpStatusCode.MultiStatus)
                {
                    responseJson = apiResponseJson.Content.ReadAsStringAsync().Result;
                    apiResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);

                    Pay360Transaction dbTransaction = CreateDbTransactionObject(apiResponse, PrimaryTransaction.Customer_Id, null, PaymentMethods.Card, creds.ApiInstallationIdCashierApi);
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = responseJson;
                    DbResult<long> result = await Db.AddTransaction(dbTransaction, productBasket, false);

                    string errorMessage = apiResponse.Outcome.ReasonMessage;
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", responseJson).Trim();
                    if (reasonCode == "A136")
                    {
                        errorMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }
                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + errorMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserResponseModels>.Failure(errorMessage, 12);
                    response.pay360ApiCode = reasonCode;
                }
                else
                {
                    string jsonResult = await apiResponseJson.Content.ReadAsStringAsync();
                    Pay360Transaction dbTransaction = new Pay360Transaction();
                    dbTransaction.Customer_Id = PrimaryTransaction.Customer_Id;
                    dbTransaction.TransactionMerchantRef = transactionMerchantRef;
                    dbTransaction.RelatedTransactionId = userRequest.Pay360TransactionId;
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = jsonResult;
                    dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    int transactionTypeId = (int)Pay360TransactionTypes.REPEAT;
                    dbTransaction.TransactionType_Id = transactionTypeId;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    dbTransaction.OutcomeReasonMessage = reasonMessage;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                    DbResult<long> result = await Db.AddTransaction(dbTransaction, productBasket, false, Pay360SummaryTransactionTypes.REPEAT, false);
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();
                    if (reasonCode == "A136")
                    {
                        reasonMessage = "Sorry we are unable to complete your transaction, please contact customer services - (A136)";
                    }

                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<UserResponseModels>.Failure("Transaction Un-Successfull: " + reasonMessage + ", and Database Insertion Error: " + result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<UserResponseModels>.Failure(reasonMessage, 12);
                    response.pay360ApiCode = reasonCode;
                }

            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserResponseModels>.Failure(ex.Message, 14);
                throw;
            }

            return response;
        }
        #endregion PaymentRequests

        #region UpdateCustomerCard

        public async Task<GenericApiResponse<UpdatePaymentMethodResponseModel>> UpdateCustomerCard(UpdateCustomerCardRequest request)
        {
            var customer = await Db.GetCustomerByPay360CustomerId(long.Parse(request.Pay360CustomerID));
            if (customer == null)
            {
                return GenericApiResponse<UpdatePaymentMethodResponseModel>.Failure("Customer does not exists.", 23);
            }

            var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(customer.Msisdn, customer.ProductCode, nameof(Pay360PaymentType.CARD));

            string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/customers/" + creds.ApiInstallationIdCashierApi + "/" + request.Pay360CustomerID + "/paymentMethods/" + request.CardToken + "/update";
            GenericApiResponse<UpdatePaymentMethodResponseModel> apiResponse;
            var updateCardRequest = new UpdateCustomerCardModel()
            {
                isPrimary = request.IsPrimary,
                card = request.card
            };
            try
            {
                HttpResponseMessage httpResponse = await ApiCall.Post(apiEndPoint, updateCardRequest, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                var updateResponseMethod = JsonConvert.DeserializeObject<UpdatePaymentMethodResponseModel>(httpResponse.Content.ReadAsStringAsync().Result);
                apiResponse = GenericApiResponse<UpdatePaymentMethodResponseModel>.Success(updateResponseMethod, "Card has been updated successfully.");
            }
            catch (Exception ex)
            {
                apiResponse = GenericApiResponse<UpdatePaymentMethodResponseModel>.Failure(ex.Message, 14);
                throw;
            }

            return apiResponse;
        }



        #endregion  UpdateCustomerCard

        #region Fullfilment

        public async Task<GenericApiResponse<UserResponseModels>> Fullfilment(UserResponseModels userResponse, string pay360TransactionId, string transactionId, string currency, string customerMerchantReference, string customerEmail, string msisdn = "")
        {

            GenericApiResponse<UserResponseModels> response = null;
            try
            {

                bool isfullfilmentError = false;
                bool isfullfilment = false;
                bool isSmsSent = false;
                bool isEmailSent = false;
                bool isEmailSentToCustomer = false;
                DateTime? fullfilmentDatetime = null;
                DateTime? smsSentDatetime = null;
                DateTime? emailSentDatetime = null;
                DateTime? customerEmailSentDatetime = null;
                var topup_option = 2;
                var thm_sms = 0;

                // Get TransactionItems for Fullfilment
                List<TransactionItems> transactionItems = await Db.GetTransactionItemsForFullfilment(transactionId);

                List<BasketItemsResponse> BasketResponse = new List<BasketItemsResponse>();

                Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);

                if (!string.IsNullOrWhiteSpace(customerEmail))
                {
                    customer.Email = customerEmail;
                }

                foreach (TransactionItems tranItem in transactionItems)
                {
                    FullfilmentResponse result = null;

                    if (tranItem.ProductItemCode.ToUpper() == "THM" || tranItem.ProductItemCode.ToUpper() == "THMIVR")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var bundleRef = tranItem.BundleRef;
                            var amount = tranItem.Amount;
                            var productRef = tranItem.ProductRef;
                            if (tranItem.ProductItemCode.ToUpper() == "THMIVR")
                            {
                                tranId = "ivr_" + tranId;
                            }
                            result = await Db.ThmStraightCustomerFullfilment(tranId, bundleRef, amount.ToString(), productRef, customer.Email, "THM");

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.Audit.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }
                            //Console.WriteLine($"Pay360_BL/StartPay360Job, Customer Fullfilment Successfull,  TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, CustomerMerchantRef: {apiResponseModel.payload.Transaction.MerchantRef}, Date_Utc: {DateTime.UtcNow}");

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            string SmsMsg = $"Talkhome \r\nYou have successfully Topped Up. \r\nYour new balance is {newBalanceCurrency}{newBalance.ToString("0.00")}\r\nTop Up Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            if (!string.IsNullOrWhiteSpace(result.BundleName))
                            {
                                newBalance = newBalance - Convert.ToDecimal(tranItem.Amount);
                                SmsMsg = $"Talkhome \r\nYou have successfully purchased a plan. \r\nYour new balance is {newBalanceCurrency}{newBalance.ToString("0.00")}\r\n Plan Name: {result.BundleName}\r\nTransaction Id: {pay360TransactionId}";
                            }
                            //var PushMsg = $"You have successfully Auto Topped Up. \r\nYour new balance is {newBalanceCurrency}{newBalance}\r\nTop Up Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {apiResponseModel.payload.Transaction.TransactionId}";
                            //var pushResult = SendPushNotification(PushMsg, autoTopupTransaction.Msisdn);
                            //if (SmsConfig.UsePoppayout == true)
                            //{

                            //    PoppayoutsSendSmsResponse smsResponse = await this.SendPoppayoutSms("TalkHome", new string[] { msisdn }, SmsMsg, 1);

                            //    if (smsResponse != null && smsResponse.errorCode == 0)
                            //    {
                            //        isSmsSent = true;
                            //        smsSentDatetime = DateTime.UtcNow;
                            //    }
                            //    else
                            //    {
                            //        isSmsSent = false;
                            //    }
                            //}
                            //else
                            //{
                            //    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("TalkHome", msisdn, SmsMsg);
                            //    if (smsResponse != null && smsResponse.errorCode == 0)
                            //    {
                            //        isSmsSent = true;
                            //        smsSentDatetime = DateTime.UtcNow;
                            //    }
                            //    else
                            //    {
                            //        isSmsSent = false;
                            //    }
                            //}
                            #endregion SendSms


                            if (tranItem.ProductItemCode.ToUpper() == "THMIVR") /// Sms to IVR customer
                            {

                                string ThmSmsMsg = SmsConfig.ThmIVRSmsText.Replace("###Amount###", newBalanceCurrency + tranItem.Amount.ToString()).Replace("###TransactionId###", pay360TransactionId);
                                if (SmsConfig.ThmIVRSmsProvider == "1") // Xeebi
                                {
                                    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("TalkhomeMobile", msisdn, ThmSmsMsg);
                                    if (smsResponse != null && smsResponse.errorCode == 0)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }

                                }
                                else if (SmsConfig.ThmIVRSmsProvider == "3") // Localsms
                                {

                                    var smsResponse = await this.SendLocalsms(SmsConfig.LocalsmsTHMFrom, msisdn, ThmSmsMsg);
                                    if (smsResponse != null)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }
                                }
                                else // Twilio
                                {
                                    isSmsSent = await SendTwilioSms(msisdn, ThmSmsMsg, "TalkhomeMobile");
                                    smsSentDatetime = DateTime.UtcNow;
                                }
                            }


                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference:" + customerMerchantReference;
                            emailTransaction.description = "Pay360 THM Top Up Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer)
                            {
                                isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, SmsMsg);
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }
                            #endregion

                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode == "THCC" || tranItem.ProductItemCode.ToUpper() == "THCCIVR")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;
                            if (tranItem.ProductItemCode.ToUpper() == "THCCIVR")
                            {
                                tranId = "ivr_" + tranId;
                            }
                            result = await Db.ThccCustomerFullfilment(tranId, tranItem.Amount.ToString(), customer.Email, customer.DisplayName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            var EmailMsg = $"Talkhome \r\nYou have successfully purchased TalkHome Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion

                            if (tranItem.ProductItemCode.ToUpper() == "THCCIVR") /// Sms to IVR customer
                            {

                                string ivrSmsMsg = SmsConfig.ThccIVRSmsText.Replace("###pin###", result.Pin);
                                if (SmsConfig.ThccIVRSmsProvider == "1") // Xeebi
                                {
                                    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("Talkhome", msisdn, ivrSmsMsg);
                                    if (smsResponse != null && smsResponse.errorCode == 0)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }
                                }
                                else // Twilio
                                {
                                    isSmsSent = await SendTwilioSms(msisdn, ivrSmsMsg, "Talkhome");
                                    smsSentDatetime = DateTime.UtcNow;
                                }
                            }

                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                            emailTransaction.description = "Pay360 THCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer == true && SmtpConfig.sendEmailToTHCCCustomer == true)
                            {
                                isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, EmailMsg);
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetTHCCTemplate(customer.DisplayName, "£", tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await SendHtmlEmailToCustomer(customer.Email, emailTemplateContent, "THCC", SmtpConfig.subjectForTHCCNCustomer);
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode == "THRCC")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var bundleRef = tranItem.BundleRef;
                            var amount = tranItem.Amount * 100;
                            var productRef = tranItem.ProductRef;
                            result = await Db.ThrccCustomerFullfilment(tranId, amount.ToString(), productRef, customer.Email, customer.DisplayName);
                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region GetRewaradPoints
                            int points = 0;
                            try
                            {

                                //await Db.THRCCAddRewardPoints((int)result.audit_id, result.Card, tranItem.Amount * 100);

                                points = await Db.GetPoints(result.Card);
                            }
                            catch (Exception ex)
                            {
                                Logger.Error($"Class: BL_Pay360CashierApi, Method: GetPoints, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                                points = 0;
                            }
                            #endregion

                            #region SendSms
                            var EmailMsg = "";
                            if (tranItem.ProductRef == null)// Change the email for the customer accordingly.
                            {
                                EmailMsg = $"TalkHome Rechargeable Calling Card <br/> You have successfully purchased a TalkHome Rechargeable Calling Card.<br/>Pin: {result.Pin}<br/>Rechargeable Card Number: {result.Card}<br/>Amount: {newBalanceCurrency}{tranItem.Amount}<br/>Transaction Id: {pay360TransactionId} You've earned {points} points! Registered users can <a href=\"https://talk-home.co.uk/logincallingcards\">log in</a> to redeem points but if you're not registered don't worry, you can still claim your points when you <a href=\"https://talk-home.co.uk/signupcallingcards\">sign up</a>.";
                            }
                            else
                            {
                                EmailMsg = $"TalkHome Rechargeable Calling Card <br/> You have successfully topped up. <br/>Pin: {result.Pin}<br/>Rechargeable Card Number: {result.Card}<br/> Amount: {newBalanceCurrency}{tranItem.Amount}<br/>Transaction Id: {pay360TransactionId} Your new points {points}. Registered users can <a href=\"https://talk-home.co.uk/logincallingcards\">log in</a> to redeem points but if you're not registered don't worry, you can still claim your points when you <a href=\"https://talk-home.co.uk/signupcallingcards\">sign up</a>.";
                            }
                            #endregion SendSms

                            #region sendEmail
                            //Email Testing
                            //EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            //emailTransaction.msisdn = "CustomerReference: " + customerMerchantReference;
                            //emailTransaction.description = "Pay360 THRCC Details"; // set the text according to the type of transaction
                            //emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            //emailTransaction.transactionId = pay360TransactionId;
                            //emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            //isEmailSent = await SendEmail(emailTransaction);
                            //if (isEmailSent)
                            //{
                            //    emailSentDatetime = DateTime.UtcNow;
                            //}

                            #endregion

                            #region SendEmailToCustomer

                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer == true && SmtpConfig.sendEmailToTHRCCCustomer == true)
                            {
                                isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, EmailMsg, true);
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = "";
                                if (tranItem.ProductRef == null)// Change the email for the customer accordingly.
                                {
                                    emailTemplateContent = EmailTemplate.GetTHRCCTemplate(customer.DisplayName, "£", tranItem.Amount.ToString(), result.Card, result.Pin, points.ToString(), newBalanceCurrency + (result.new_balance / 100).ToString("0.00"));
                                    await SendHtmlEmailToCustomer(customer.Email, emailTemplateContent, "THCC", SmtpConfig.subjectForTHRCCNewCustomer);
                                }
                                else
                                {
                                    emailTemplateContent = EmailTemplate.GetTHRCCTemplate(customer.DisplayName, "£", tranItem.Amount.ToString(), result.Card, points.ToString(), newBalanceCurrency + (result.new_balance / 100).ToString("0.00"));
                                    await SendHtmlEmailToCustomer(customer.Email, emailTemplateContent, "THCC", SmtpConfig.subjectForTHRCCCustomer);
                                }

                            }
                            #endregion

                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "NOWPG" || tranItem.ProductItemCode.ToUpper() == "NOWPGIVR")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "", BundleName = "" };
                        }
                        else // Live Mode
                        {

                            var tranId = pay360TransactionId;
                            var bundleRef = tranItem.BundleRef;
                            var amount = tranItem.Amount;
                            var productRef = tranItem.ProductRef;
                            if (tranItem.ProductItemCode.ToUpper() == "NOWPGIVR")
                            {
                                tranId = "ivr_" + tranId;
                            }
                            if (topup_option == 1)
                            {
                                result = await Db.NowCustomerFullfilment(tranId, bundleRef, amount.ToString(), productRef);
                            }
                            else
                            {
                                result = await Db.NowStraightCustomerFullfilment(tranId, bundleRef, amount.ToString(), productRef);
                            }

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {

                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.Audit.new_balance;
                            var newBalanceCurrency = currency;

                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            var SmsMsg = "";
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            if (!String.IsNullOrEmpty(tranItem.BundleRef))
                            {
                                SmsMsg = $"NOWMOBILE \r\nYou have successfully purchased a plan {newBalanceCurrency}{tranItem.Amount},Plan Name:{result.BundleName} .\r\nTransaction Id: {pay360TransactionId}";
                            }
                            else
                            {
                                SmsMsg = $"NOWMOBILE \r\nYou have successfully topped Up {newBalanceCurrency}{tranItem.Amount}.\r\nTransaction Id: {pay360TransactionId}";
                            }

                            //var PushMsg = $"You have successfully Topped Up {newBalanceCurrency}{tranItem.Amount}.\r\nTransaction Id: {pay360TransactionId}";
                            //var pushResult = SendPushNotification(PushMsg, autoTopupTransaction.Msisdn);
                            //if (thm_sms != 0)
                            //{
                            //    if (SmsConfig.UsePoppayout == true)
                            //    {

                            //        PoppayoutsSendSmsResponse smsResponse = await this.SendPoppayoutSms("TalkHome", new string[] { msisdn }, SmsMsg, 1);

                            //        if (smsResponse != null && smsResponse.errorCode == 0)
                            //        {
                            //            isSmsSent = true;
                            //            smsSentDatetime = DateTime.UtcNow;
                            //        }
                            //        else
                            //        {
                            //            isSmsSent = false;
                            //        }
                            //    }
                            //    else
                            //    {
                            //        XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("TalkHome", msisdn, SmsMsg);
                            //        if (smsResponse != null && smsResponse.errorCode == 0)
                            //        {
                            //            isSmsSent = true;
                            //            smsSentDatetime = DateTime.UtcNow;
                            //        }
                            //        else
                            //        {
                            //            isSmsSent = false;
                            //        }
                            //    }
                            //}
                            #endregion SendSms

                            if (tranItem.ProductItemCode.ToUpper() == "NOWPGIVR") /// Sms to IVR customer
                            {

                                string NowSmsMsg = SmsConfig.NowPayGIVRSmsText.Replace("###Amount###", newBalanceCurrency + tranItem.Amount.ToString()).Replace("###TransactionId###", pay360TransactionId);
                                if (SmsConfig.NowPayGIVRSmsProvider == "1") // Xeebi
                                {
                                    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("NowMobile", msisdn, NowSmsMsg);
                                    if (smsResponse != null && smsResponse.errorCode == 0)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }
                                }
                                else if (SmsConfig.NowPayGIVRSmsProvider == "3") // Localsms
                                {

                                    var smsResponse = await this.SendLocalsms(SmsConfig.LocalsmsNowPGFrom, msisdn, NowSmsMsg);
                                    if (smsResponse != null)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }
                                }
                                else // Twilio
                                {
                                    isSmsSent = await SendTwilioSms(msisdn, NowSmsMsg, "NowMobile");
                                    smsSentDatetime = DateTime.UtcNow;
                                }
                            }


                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference:" + customerMerchantReference;
                            emailTransaction.description = "Pay360 NOWMOBILE Top Up Details. " + Environment.NewLine; // set the text according to the type of transaction

                            if (!String.IsNullOrEmpty(tranItem.BundleRef))
                            {
                                emailTransaction.description += " Bundle Name: " + result.BundleName;
                            }

                            emailTransaction.status = "The Customer has Purchased Successfully."; // set the status text accordingly    
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer)
                            {
                                isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, SmsMsg, "NOWPAYG");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }

                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "WTCC" || tranItem.ProductItemCode.ToUpper() == "WTCCIVR")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;
                            if (tranItem.ProductItemCode.ToUpper() == "WTCCIVR")
                            {
                                tranId = "ivr_" + tranId;
                            }
                            result = await Db.WtccCustomerFullfilment(tranId, amount.ToString(), customer.Email, customer.DisplayName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            var EmailMsg = $"WorldTalk \r\nYou have successfully purchased WorldTalk Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion

                            if (tranItem.ProductItemCode.ToUpper() == "WTCCIVR") /// Sms to IVR customer
                            {

                                string WtccSmsMsg = SmsConfig.WtccIVRSmsText.Replace("###pin###", result.Pin);
                                if (SmsConfig.WtccIVRSmsProvider == "1") // Xeebi
                                {
                                    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("WorldTalk", msisdn, WtccSmsMsg);
                                    if (smsResponse != null && smsResponse.errorCode == 0)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }
                                }
                                else // Twilio
                                {
                                    isSmsSent = await SendTwilioSms(msisdn, WtccSmsMsg, "WorldTalk");
                                    smsSentDatetime = DateTime.UtcNow;
                                }
                            }

                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                            emailTransaction.description = "Pay360 WTCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = currency + " " + tranItem.Amount.ToString();
                            isEmailSent = await SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer == true)
                            {
                                isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, EmailMsg, "WTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetWTCCTemplate(customer.DisplayName, newBalanceCurrency, tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await SendHtmlEmailToCustomer(customer.Email, emailTemplateContent, "WTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "THAIVR")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            //var tranId = pay360TransactionId;
                            //var amount = tranItem.Amount * 100;
                            //if (tranItem.ProductItemCode.ToUpper() == "THAIVR")
                            //{
                            //    tranId = "ivr_" + tranId;
                            //}
                            //result = await Db.ThaIvrCustomerFullfilment(tranId, amount.ToString(), customer.Email, customer.DisplayName);

                            var ccAuthCode = pay360TransactionId;
                            var CssTransId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;
                            var prodRef = tranItem.ProductRef;
                            if (tranItem.ProductItemCode.ToUpper() == "THAIVR")
                            {
                                ccAuthCode = "ivr_" + ccAuthCode;
                                CssTransId = "ivr_" + CssTransId;
                            }

                            result = await Db.ThaIvrCustomerFullfilment(prodRef, amount.ToString(), CssTransId, ccAuthCode);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }


                            if (tranItem.ProductItemCode.ToUpper() == "THAIVR") /// Sms to IVR customer
                            {

                                string ThaSmsMsg = SmsConfig.ThaIVRSmsText.Replace("###TransactionId###", pay360TransactionId);
                                if (SmsConfig.ThaIVRSmsProvider == "1") // Xeebi
                                {
                                    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("TalkhomeApp", msisdn, ThaSmsMsg);
                                    if (smsResponse != null && smsResponse.errorCode == 0)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }
                                }
                                else // Twilio
                                {
                                    isSmsSent = await SendTwilioSms(msisdn, ThaSmsMsg, "TalkhomeApp");
                                    smsSentDatetime = DateTime.UtcNow;
                                }
                            }

                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                            emailTransaction.description = "Pay360 TalkhomeApp IVR Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = currency + " " + tranItem.Amount.ToString();
                            isEmailSent = await SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion                          


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "THAATA" || tranItem.ProductItemCode.ToUpper() == "THAATW")
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {

                            var ccAuthCode = pay360TransactionId;
                            var CssTransId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;
                            var prodRef = tranItem.ProductRef;
                            var bundleRef = tranItem.BundleRef;

                            result = await Db.ThaCustomerFullfilment(prodRef, amount.ToString(), CssTransId, ccAuthCode, bundleRef);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.Audit.new_balance / 100;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }


                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                            emailTransaction.description = "Pay360 Talkhome App Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = newBalanceCurrency + tranItem.Amount.ToString();
                            isEmailSent = await SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                            #region SendEmailToCustomer

                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer)
                            {
                                string customerEmailMsg = $"Talkhome App \r\nYou have successfully Topped Up. \r\nTop Up Amount: {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                                if (!string.IsNullOrWhiteSpace(tranItem.BundleRef))
                                {
                                    //newBalance = newBalance - Convert.ToDecimal(tranItem.Amount);
                                    customerEmailMsg = $"Talkhome App\r\nYou have successfully purchased a bundle. \r\nBundle Name: {result.BundleName} \r\nBundle Amount: {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                                }
                                isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, customerEmailMsg);
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }
                            #endregion

                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "STCC" || tranItem.ProductItemCode.ToUpper() == "STCCIVR")  // SafariTalk Calling Card
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;
                            if (tranItem.ProductItemCode.ToUpper() == "STCCIVR")
                            {
                                tranId = "ivr_" + tranId;
                            }
                            result = await Db.StccCustomerFullfilment(tranId, amount.ToString(), customer.Email, customer.DisplayName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            var EmailMsg = $"SafariTalk \r\nYou have successfully purchased SafariTalk Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion

                            if (tranItem.ProductItemCode.ToUpper() == "STCCIVR") /// Sms to IVR customer
                            {

                                string ivrSmsMsg = SmsConfig.SafariTalkIVRSmsText.Replace("###pin###", result.Pin);
                                if (SmsConfig.StccIVRSmsProvider == "1") // Xeebi
                                {
                                    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("SafariTalk", msisdn, ivrSmsMsg);
                                    if (smsResponse != null && smsResponse.errorCode == 0)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }
                                }
                                else // Twilio
                                {
                                    isSmsSent = await SendTwilioSms(msisdn, ivrSmsMsg, "SafariTalk");
                                    smsSentDatetime = DateTime.UtcNow;
                                }
                            }

                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                            emailTransaction.description = "Pay360 STCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = currency + " " + tranItem.Amount.ToString();
                            isEmailSent = await SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer == true)
                            {
                                isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, EmailMsg, "STCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetSTCCTemplate(customer.DisplayName, newBalanceCurrency, tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await SendHtmlEmailToCustomer(customer.Email, emailTemplateContent, "STCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "BTCC" || tranItem.ProductItemCode.ToUpper() == "BTCCIVR")  // BabyTalk Calling Card
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;
                            if (tranItem.ProductItemCode.ToUpper() == "BTCCIVR")
                            {
                                tranId = "ivr_" + tranId;
                            }
                            result = await Db.BtccCustomerFullfilment(tranId, amount.ToString(), customer.Email, customer.DisplayName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            var EmailMsg = $"BabyTalk \r\nYou have successfully purchased BabyTalk Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion

                            if (tranItem.ProductItemCode.ToUpper() == "BTCCIVR") /// Sms to IVR customer
                            {

                                string ivrSmsMsg = SmsConfig.BabyTalkIVRSmsText.Replace("###pin###", result.Pin);
                                if (SmsConfig.BtccIVRSmsProvider == "1") // Xeebi
                                {
                                    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("BabyTalk", msisdn, ivrSmsMsg);
                                    if (smsResponse != null && smsResponse.errorCode == 0)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }
                                }
                                else // Twilio
                                {
                                    isSmsSent = await SendTwilioSms(msisdn, ivrSmsMsg, "BabyTalk");
                                    smsSentDatetime = DateTime.UtcNow;
                                }
                            }

                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                            emailTransaction.description = "Pay360 BTCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = currency + " " + tranItem.Amount.ToString();
                            isEmailSent = await SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer == true)
                            {
                                isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, EmailMsg, "BTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetBTCCTemplate(customer.DisplayName, newBalanceCurrency, tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await SendHtmlEmailToCustomer(customer.Email, emailTemplateContent, "BTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "MTCC" || tranItem.ProductItemCode.ToUpper() == "MTCCIVR")  // MaxiTalk Calling Card
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;
                            if (tranItem.ProductItemCode.ToUpper() == "MTCCIVR")
                            {
                                tranId = "ivr_" + tranId;
                            }
                            result = await Db.MtccCustomerFullfilment(tranId, amount.ToString(), customer.Email, customer.DisplayName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            var EmailMsg = $"MaxiTalk \r\nYou have successfully purchased MaxiTalk Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion

                            if (tranItem.ProductItemCode.ToUpper() == "MTCCIVR") /// Sms to IVR customer
                            {

                                string ivrSmsMsg = SmsConfig.MaxiTalkIVRSmsText.Replace("###pin###", result.Pin);
                                if (SmsConfig.MtccIVRSmsProvider == "1") // Xeebi
                                {
                                    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("MaxiTalk", msisdn, ivrSmsMsg);
                                    if (smsResponse != null && smsResponse.errorCode == 0)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }
                                }
                                else // Twilio
                                {
                                    isSmsSent = await SendTwilioSms(msisdn, ivrSmsMsg, "MaxiTalk");
                                    smsSentDatetime = DateTime.UtcNow;
                                }
                            }

                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                            emailTransaction.description = "Pay360 MTCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = currency + " " + tranItem.Amount.ToString();
                            isEmailSent = await SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer == true)
                            {
                                isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, EmailMsg, "MTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetMTCCTemplate(customer.DisplayName, newBalanceCurrency, tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await SendHtmlEmailToCustomer(customer.Email, emailTemplateContent, "MTCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else if (tranItem.ProductItemCode.ToUpper() == "TDCC" || tranItem.ProductItemCode.ToUpper() == "TDCCIVR")  // TalkDirect Calling Card
                    {
                        #region Call the fullfilment SP
                        if (SimulationConf.SimulationMode)  // Simulation Mode
                        {
                            result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                        }
                        else // Live Mode
                        {
                            var tranId = pay360TransactionId;
                            var amount = tranItem.Amount * 100;
                            if (tranItem.ProductItemCode.ToUpper() == "TDCCIVR")
                            {
                                tranId = "ivr_" + tranId;
                            }
                            result = await Db.TdccCustomerFullfilment(tranId, amount.ToString(), customer.Email, customer.DisplayName);

                        }
                        #endregion Customer_Fullfilment
                        if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
                        {
                            isfullfilment = true;
                            fullfilmentDatetime = DateTime.UtcNow;
                            //fullfilmentRef = result.audit_id;
                            var newBalance = result.new_balance;
                            var newBalanceCurrency = currency;
                            if (newBalanceCurrency == "USD")
                            {
                                newBalanceCurrency = "$";
                            }
                            else if (newBalanceCurrency == "GBP")
                            {
                                newBalanceCurrency = "£";
                            }
                            else if (newBalanceCurrency == "EUR")
                            {
                                newBalanceCurrency = "€";
                            }

                            #region SendSms
                            //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
                            var EmailMsg = $"TalkDirect \r\nYou have successfully purchased TalkDirect Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {pay360TransactionId}";
                            #endregion

                            if (tranItem.ProductItemCode.ToUpper() == "TDCCIVR") /// Sms to IVR customer
                            {

                                string ivrSmsMsg = SmsConfig.TalkDirectIVRSmsText.Replace("###pin###", result.Pin);
                                if (SmsConfig.TdccIVRSmsProvider == "1") // Xeebi
                                {
                                    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("TalkDirect", msisdn, ivrSmsMsg);
                                    if (smsResponse != null && smsResponse.errorCode == 0)
                                    {
                                        isSmsSent = true;
                                        smsSentDatetime = DateTime.UtcNow;
                                    }
                                    else
                                    {
                                        isSmsSent = false;
                                    }
                                }
                                else // Twilio
                                {
                                    isSmsSent = await SendTwilioSms(msisdn, ivrSmsMsg, "TalkDirect");
                                    smsSentDatetime = DateTime.UtcNow;
                                }
                            }

                            #region sendEmail
                            //Email Testing
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                            emailTransaction.description = "Pay360 TDCC Details"; // set the text according to the type of transaction
                            emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
                            emailTransaction.transactionId = pay360TransactionId;
                            emailTransaction.amount = currency + " " + tranItem.Amount.ToString();
                            isEmailSent = await SendEmail(emailTransaction);
                            if (isEmailSent)
                            {
                                emailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion

                            #region SendEmailToCustomer
                            //Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer == true)
                            {
                                isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, EmailMsg, "TDCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendTemplateEmailToCustomer == true)
                            {
                                string emailTemplateContent = EmailTemplate.GetTDCCTemplate(customer.DisplayName, newBalanceCurrency, tranItem.Amount.ToString(), result.Pin);
                                isEmailSentToCustomer = await SendHtmlEmailToCustomer(customer.Email, emailTemplateContent, "TDCC");
                                customerEmailSentDatetime = DateTime.UtcNow;
                            }

                            #endregion


                        }
                        else // Fullfilment Error
                        {
                            isfullfilmentError = true;
                            isfullfilment = false;
                            isSmsSent = false;
                            isEmailSent = false;
                            isEmailSentToCustomer = false;
                            fullfilmentDatetime = DateTime.UtcNow;
                            smsSentDatetime = null;
                            emailSentDatetime = null;
                            customerEmailSentDatetime = null;
                        }
                    }
                    else // ProductItemCode Not Found
                    {

                        isfullfilmentError = true;
                        isfullfilment = false;
                        isSmsSent = false;
                        isEmailSent = false;
                        isEmailSentToCustomer = false;
                        fullfilmentDatetime = DateTime.UtcNow;
                        smsSentDatetime = null;
                        emailSentDatetime = null;
                        customerEmailSentDatetime = null;
                        result = new FullfilmentResponse { ErrorCode = 2, ErrorMessage = $"ProductItemCode: {tranItem.ProductItemCode} Not Found", Pin = null };
                    }

                    BasketResponse.Add(new BasketItemsResponse() { IsFullFilled = isfullfilment, ProductItemCode = tranItem.ProductItemCode, Pin = result.Pin, Card = result.Card });

                    int dBResult = await Db.UpdateTransactionItem(tranItem.Id, result != null ? result.ErrorMessage : "Code Exception Null Object", isSmsSent, isEmailSentToCustomer, isfullfilment, smsSentDatetime, customerEmailSentDatetime, fullfilmentDatetime);
                }
                int dbresult = await Db.UpdateTransactionSummaryFullfilmentStatus(pay360TransactionId, isfullfilmentError ? 9 : 4, DateTime.UtcNow);

                userResponse.BasketResponse = BasketResponse;

                return response = GenericApiResponse<UserResponseModels>.Success(userResponse, "Success");
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: BL_Pay360CashierApi, Method: Fullfilment, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return response = GenericApiResponse<UserResponseModels>.Failure(ex.Message, 26);
            }
        }


        #endregion Fullfilment       

        #region Validations

        public async Task<GenericApiResponse<UserResponseModels>> Validations(string customerMsisdn, string productCode, float transactionAmount, ProductBasket[] productBasket)
        {

            GenericApiResponse<UserResponseModels> response;
            string description = "";

            try
            {
                List<ProductItems> productItems = null;

                if (!string.IsNullOrWhiteSpace(customerMsisdn))
                {
                    productItems = await Db.GetProductItems(customerMsisdn);
                }
                else
                {
                    productItems = await Db.GetProductItems();
                }

                if (productItems == null || productItems.Count < 1)
                {

                    return response = GenericApiResponse<UserResponseModels>.Failure("Product Items not configured.", 6);
                }

                if (productBasket != null)
                {
                    float basketTotal = 0;
                    for (int i = 0; i < productBasket.Length; i++)
                    {
                        #region ProductRef Validation

                        if (string.IsNullOrEmpty(description))
                        {
                            description = productBasket[i].ProductItemCode + ":" + productBasket[i].Amount.ToString();
                        }
                        else
                        {
                            description = description + "," + productBasket[i].ProductItemCode + ":" + productBasket[i].Amount.ToString();
                        }

                        var validateFailure = await ValidateProduct(i, productItems, productCode, productBasket);

                        if (validateFailure != null)
                        {
                            return validateFailure;
                        }

                        #endregion  ProductRef Validation

                        #region Basket Amount Total Validation
                        basketTotal = basketTotal + productBasket[i].Amount;
                        #endregion Basket Amount Total Validation

                        #region ProductItem MaxLimit Validation
                        if (productItems != null && productItems.Count > 0)
                        {
                            ProductItems pItem = productItems.Find(item => item.ProductCode == productCode && item.ProductItemCode == productBasket[i].ProductItemCode);

                            if (pItem == null)
                            {
                                return response = GenericApiResponse<UserResponseModels>.Failure("Basket item " + productBasket[i].ProductItemCode + " not available in database.", 7);
                            }
                            else
                            {
                                if (productBasket[i].Amount > pItem.AmountLimit)
                                {
                                    return response = GenericApiResponse<UserResponseModels>.Failure("Basket item " + productBasket[i].ProductItemCode + " amount exceeds MaxAmount(" + pItem.AmountLimit + ") limit. ", 8);
                                }
                            }
                        }
                        #endregion ProductItem MaxLimit Validation
                    }
                    if (basketTotal != transactionAmount)
                    {
                        return response = GenericApiResponse<UserResponseModels>.Failure("Basket total and TransactionAmount are not same.", 2);
                    }
                }
                else
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure("Basket is empty.", 1);
                }
            }

            catch (Exception)
            {
                throw;
            }

            return response = GenericApiResponse<UserResponseModels>.Success(new UserResponseModels(), description);
        }

        private async Task<GenericApiResponse<UserResponseModels>> ValidateProduct(int i, List<ProductItems> productItems, string productCode, ProductBasket[] productBasket)
        {
            GenericApiResponse<UserResponseModels> response;

            ProductItems pItem = productItems.Find(item => item.ProductCode == productCode && item.ProductItemCode == productBasket[i].ProductItemCode);

            if (pItem == null)
            {
                return response = GenericApiResponse<UserResponseModels>.Failure("Basket item " + productBasket[i].ProductItemCode + " for ProductCode " + productCode + " not available in database.", 7);
            }

            if (productBasket[i].ProductItemCode.ToLower() == "thm")
            {

                ValidateRes result = await Db.ThmProductRefValidation(productBasket[i].ProductItemCode, productBasket[i].ProductRef, productBasket[i].BundleRef);

                if (result.Errorcode == 1) // Not Valid ProductRef
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"Invalid ProductRef: {productBasket[i].ProductRef} for ProductItem: {productBasket[i].ProductItemCode}.", 3);
                }
                else if (result.Errorcode == 2)
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"You have reached the maximum number of bundles: {productBasket[i].BundleRef} for ProductItem: {productBasket[i].ProductItemCode}.", 21);
                }
                else if (result.Errorcode != 0) // Not Valid ProductRef
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"Card topup denied for MSISDN : {productBasket[i].ProductRef} for ProductItem: {productBasket[i].ProductItemCode}.", 22);

                }
                else if (productBasket[i].Amount != 0 && result.Tamount != 0 && pItem.AmountLimit < (float.Parse(result.Tamount.ToString()) + float.Parse(productBasket[i].Amount.ToString())))
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"You exceeded daily the limit", 5);
                }


            }
            else if (productBasket[i].ProductItemCode.ToLower() == "thaata" || productBasket[i].ProductItemCode.ToLower() == "thaatw")
            {
                ValidateRes result = await Db.ThaProductRefValidation(productBasket[i].ProductItemCode, productBasket[i].ProductRef);

                if (result.Errorcode != 0) // Not Valid ProductRef
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"Invalid ProductRef: {productBasket[i].ProductRef} for ProductItem: {productBasket[i].ProductItemCode}.", 24);
                }
                else if (productBasket[i].Amount != 0 && result.Tamount != 0 && pItem.AmountLimit < (float.Parse(result.Tamount.ToString()) + productBasket[i].Amount * 100))
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"You exceeded daily the limit", 5);
                }
            }
            else if (productBasket[i].ProductItemCode.ToLower() == "thrcc")
            {

                var result = await Db.ThrccProductRefValidation(productBasket[i].ProductItemCode, productBasket[i].ProductRef);
                if (result.Errorcode != 0) // Not Valid ProductRef
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"Invalid ProductRef: {productBasket[i].ProductRef} for ProductItem: {productBasket[i].ProductItemCode}.", 4);
                }
                else if (productBasket[i].Amount != 0 && result.Tamount != 0 && pItem.AmountLimit < (float.Parse(result.Tamount.ToString()) + float.Parse(productBasket[i].Amount.ToString())))
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"You exceeded daily the limit", 5);
                }
            }
            else if (productBasket[i].ProductItemCode.ToLower() == "nowpg")
            {
                ValidateRes result = await Db.NowPayGProductRefValidation(productBasket[i].ProductItemCode, productBasket[i].ProductRef, productBasket[i].BundleRef);

                if (result.Errorcode == 1) // Not Valid ProductRef
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"Invalid ProductRef: {productBasket[i].ProductRef} for ProductItem: {productBasket[i].ProductItemCode}.", 27);
                }
                else if (result.Errorcode == 2)
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"You have reached the maximum number of bundles: {productBasket[i].BundleRef} for ProductItem: {productBasket[i].ProductItemCode}.", 21);
                }
                else if (result.Errorcode != 0) // Not Valid ProductRef
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"Paypal topup denied ProductRef: {productBasket[i].ProductRef} for ProductItem: {productBasket[i].ProductItemCode}.", 22);

                }
                else if (productBasket[i].Amount != 0 && result.Tamount != 0 && pItem.AmountLimit < (float.Parse(result.Tamount.ToString()) + float.Parse(productBasket[i].Amount.ToString())))
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure($"You exceeded daily the limit", 5);
                }

            }
            // For ITSA
            else if (productCode.ToLower() == "itsa")
            {

                DbResult<bool> validateTopupResult = await Db.ItsaValidations(productBasket[i].ProductRef, productBasket[i].Amount);
                if (validateTopupResult.DBStatus != 0)
                {
                    return response = GenericApiResponse<UserResponseModels>.Failure(validateTopupResult.DBErrorMessage, validateTopupResult.DBStatus);
                }

            }
            return null;
        }

        public async Task<GenericApiResponse<TAmount>> Validate(Validate userRequest)
        {
            GenericApiResponse<TAmount> response = new GenericApiResponse<TAmount>();

            var tamount = new TAmount();

            List<ProductItems> productItems = await Db.GetProductItems(userRequest.Msisdn);

            ValidateRes result = await Db.ThmProductRefValidation(userRequest.Product, userRequest.Msisdn);

            ProductItems pItem = productItems.Find(item => item.ProductCode.ToLower() == userRequest.Product.ToLower() && item.ProductItemCode.ToLower() == userRequest.Product.ToLower());

            if (pItem == null)
            {
                response = GenericApiResponse<TAmount>.Failure($"Invalid Product", 9);
            }

            if (result != null && result.Errorcode == 0 && (pItem.AmountLimit < (float.Parse(result.Tamount.ToString()) + userRequest.Amount)))
            {
                response = GenericApiResponse<TAmount>.Failure($"You exceeded daily the limit", 5);
                tamount.Tamount = result.Tamount;
                response.payload = tamount;
            }
            else
            {
                tamount.Tamount = result.Tamount;
                response.payload = tamount;

            }

            return response;
        }

        #endregion Validations

        #region EmailAndSms

        private async Task<bool> SendTwilioSms(string to, string textMessage, string fromString)
        {
            bool isRestrictedCountry = false;
            Twilio.Types.PhoneNumber from = fromString;

            foreach (var item in SmsConfig.TwilioFromNumberCountries)
            {
                if (to.StartsWith(item))
                {
                    isRestrictedCountry = true;
                    from = new Twilio.Types.PhoneNumber(SmsConfig.TwilioNumber);
                }
            }

            if (!to.StartsWith("+"))
            {
                to = "+" + to;
            }

            string requestParameters = $"from : {from}, to: {to}, textMessage: {textMessage}";

            try
            {
                TwilioClient.Init(SmsConfig.Sid, SmsConfig.AuthToken);
                var message = await MessageResource.CreateAsync(body: textMessage, from: isRestrictedCountry ? from : fromString, to: new Twilio.Types.PhoneNumber(to));
                if (message.Status == MessageResource.StatusEnum.Failed || message.Status == MessageResource.StatusEnum.Undelivered)
                {
                    return false;
                    //if (SAPConfig.IsActive)
                    //{
                    //    await SendSAPSMS(new SendSAPSMSRequestModel() { destination = new string[] { to }, message = textMessage, origination = "TransfHome" });
                    //}
                }
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"BL_Pay360CashierApi - Method: SendTwilioSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
                //if (SAPConfig.IsActive)
                //{
                //    await SendSAPSMS(new SendSAPSMSRequestModel() { destination = new string[] { to }, message = textMessage, origination = "TransfHome" });
                //}
                return false;
            }
        }

        private async Task<PoppayoutsSendSmsResponse> SendPoppayoutSms(string from, string[] to, string textMessage, int SmsJobPriority)
        {
            PoppayoutsSendSmsResponse returnResult = null;


            string requestParameters = $" from: {from}, to: {JsonConvert.SerializeObject(to)}, textMessage: {textMessage}, SmsJobPriority: {SmsJobPriority} ";

            try
            {

                string PoppayoutsSMSEndPoint = SmsConfig.PoppayoutsApiEndPoint + "/SendSms";


                string response = "";

                PoppayoutsSendSmsRequest req = new PoppayoutsSendSmsRequest();
                req.from = from;
                req.to = to;
                req.textMessage = textMessage;
                req.SmsJobPriority = SmsJobPriority;

                string jsonRequest = JsonConvert.SerializeObject(req);
                Task<String> HttpPoppayoutsPostService = PostRequestToPoppayoutEndPoint(PoppayoutsSMSEndPoint, "Post", jsonRequest);
                response = await HttpPoppayoutsPostService;
                returnResult = JsonConvert.DeserializeObject<PoppayoutsSendSmsResponse>(response);
                if (returnResult == null)
                {
                    Logger.Error($"Pay360_BL - Method: SendSMS, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");
                    Console.WriteLine($"Pay360_BL - Method: SendSMS, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");

                }
                else if (returnResult.payload.data == null && returnResult.payload.error_string != null)
                {
                    Logger.Error($"Pay360_BL - Method: SendSMS, Parameters --> {requestParameters}, ErrorMessage: {returnResult.payload.error_string}");
                    Console.WriteLine($"Pay360_BLl - Method: SendSMS, Parameters --> {requestParameters}, ErrorMessage: {returnResult.payload.error_string}");
                }
                else
                {
                    if (returnResult.payload.data != null && returnResult.payload.error_string == null)
                    {
                        Logger.Debug($"Pay360_BL success - Method: SendSMS, Parameters --> {requestParameters}");
                        Console.WriteLine($"Pay360_BL success - Method: SendSMS, Parameters --> {requestParameters}");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"BL_Pay360CashierApi - Method: SendSMS, Parameters --> {requestParameters}, Exception: {ex.Message}");
            }

            return returnResult;
        }
        private async Task<XeebiSendSmsResponse> SendXeebiSms(string from, string to, string textMessage)
        {
            XeebiSendSmsResponse returnResult = null;


            string requestParameters = $" from: {from}, to: {to}, textMessage: {textMessage}";

            try
            {
                string XeebiSMSEndPoint = SmsConfig.XeebiApiEndPoint + "/SendSms";

                string response = "";

                XeebiSendSmsRequest req = new XeebiSendSmsRequest();
                req.from = from;
                req.to = to;
                req.text = textMessage;

                Task<String> HttpPoppayoutsPostService = PostRequestToXeebiEndPoint(XeebiSMSEndPoint, "Post", req);
                response = await HttpPoppayoutsPostService;
                returnResult = JsonConvert.DeserializeObject<XeebiSendSmsResponse>(response);
                if (returnResult == null)
                {
                    Logger.Error($"Pay360_BL - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");
                    //Console.WriteLine($"Pay360_BL - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");

                }
                else if (returnResult.errorCode == 2)
                {
                    Logger.Error($"Pay360_BL - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: {returnResult.message}");
                    //Console.WriteLine($"Pay360_BL - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: {returnResult.message}");
                }
                else
                {
                    if (returnResult.errorCode == 0 && returnResult.payload.submit_status == "OK")
                    {
                        Logger.Debug($"Pay360_BL success - Method: SendXeebiSms, Parameters --> {requestParameters}");
                        //Console.WriteLine($"Pay360_BL success - Method: SendXeebiSms, Parameters --> {requestParameters}");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"BL_Pay360CashierApi - Method: SendXeebiSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
            }

            return returnResult;
        }

        private async Task<string> SendLocalsms(string from, string to, string textMessage)
        {
            string returnResult = null;


            string requestParameters = $" from: {from}, to: {to}, textMessage: {textMessage}";

            try
            {
                string SMSEndPoint = SmsConfig.LocalsmsApiEndPoint + $"/sendsms?username={SmsConfig.LocalsmsApiUsername}&password={SmsConfig.LocalsmsApiPassword}&to={to}&from={from}&text={textMessage}";

                string response = "";


                Task<String> HttpGetService = GetRequestToLocalEndPoint(SMSEndPoint);
                response = await HttpGetService;
                returnResult = response;
                if (returnResult == "")
                {
                    Logger.Error($"Pay360_BL - Method: SendLocalsms, Parameters --> {requestParameters}, ErrorMessage: Empty response received. Please check SendLocalsms APi.");
                    //Console.WriteLine($"Pay360_BL - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");
                }
                Logger.Information($"Sent sms to {to} via localSMS returnResult={returnResult}");
            }
            catch (Exception ex)
            {
                Logger.Error($"BL_Pay360CashierApi - Method: SendLocalsms, Parameters --> {requestParameters}, Exception: {ex.Message}");
            }

            return returnResult;
        }
        private async Task<string> PostRequestToPoppayoutEndPoint(string apiEndPoint, string postType, string json)
        {

            string returnData = "";
            try
            {
                HttpClient httpClient = new HttpClient();

                httpClient.BaseAddress = new Uri(apiEndPoint);

                var httpContent = new StringContent(json, Encoding.UTF8, "application/json");


                HttpResponseMessage httpResponse;

                if (postType == "Post")
                {
                    httpResponse = await httpClient.PostAsync(apiEndPoint, httpContent);
                }
                else
                {
                    httpResponse = await httpClient.GetAsync(apiEndPoint);
                }

                if (httpResponse.Content != null)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    Exception ex = new Exception($"BL_Pay360CashierApi Exception - Empty Contents Received for request - {json}");
                    throw ex;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            return returnData;
        }
        private async Task<string> PostRequestToXeebiEndPoint(string apiEndPoint, string postType, XeebiSendSmsRequest req)
        {

            string returnData = "";
            try
            {
                HttpClient httpClient = new HttpClient();

                httpClient.BaseAddress = new Uri(apiEndPoint);

                //var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

                MultipartFormDataContent content = new MultipartFormDataContent();
                content.Add(new StringContent(req.from), "from");
                content.Add(new StringContent(req.to), "to");
                content.Add(new StringContent(req.text), "textMessage");
                //content.Add(httpContent);

                HttpResponseMessage httpResponse;

                if (postType == "Post")
                {
                    httpResponse = await httpClient.PostAsync(apiEndPoint, content);
                }
                else
                {
                    httpResponse = await httpClient.GetAsync(apiEndPoint);
                }

                if (httpResponse.Content != null)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    Exception ex = new Exception($"BL_Pay360CashierApi Exception - Empty Contents Received for request - ");
                    throw ex;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            return returnData;
        }
        private async Task<string> GetRequestToLocalEndPoint(string apiEndPoint)
        {

            string returnData = "";
            try
            {
                HttpClient httpClient = new HttpClient();

                httpClient.BaseAddress = new Uri(apiEndPoint);


                HttpResponseMessage httpResponse;

                httpResponse = await httpClient.GetAsync(apiEndPoint);

                if ((httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Accepted) && httpResponse.Content != null)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    Exception ex = new Exception($"BL_Pay360CashierApi=>GetRequestToLocalEndPoint Exception - Empty Contents Received for request - ");
                    throw ex;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            return returnData;
        }

        public async Task<bool> SendEmail(EmailTransactionModel transactionModel)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }



                //client.DeliveryMethod = SmtpDeliveryMethod.Network;
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SmtpConfig.from);
                foreach (var to in SmtpConfig.to)
                {
                    mailMessage.To.Add(to);
                }
                foreach (var cc in SmtpConfig.cc)
                {
                    if (cc != "" && cc != null)
                    {
                        mailMessage.CC.Add(cc);
                    }
                }
                foreach (var bcc in SmtpConfig.bcc)
                {
                    if (bcc != "" && bcc != null)
                    {
                        mailMessage.Bcc.Add(bcc);
                    }
                }
                mailMessage.Body = transactionModel.msisdn + Environment.NewLine;
                mailMessage.Body += "Discription: " + transactionModel.description + Environment.NewLine;
                mailMessage.Body += "Status: " + transactionModel.status + Environment.NewLine;
                mailMessage.Body += "Transaction ID: " + transactionModel.transactionId + Environment.NewLine;
                mailMessage.Body += "Amount: " + transactionModel.amount;
                mailMessage.Subject = SmtpConfig.subject;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: BL_Pay360CashierApi, Method: SendEmail, Parameters=> transactionModel: {JsonConvert.SerializeObject(transactionModel)}, ErrorMessage: {ex.Message}");
                return false;
            }

        }
        public async Task<bool> SendEmailToCustomer(string customerEmail, string Message, bool IsHtmlBody = false)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }



                //client.DeliveryMethod = SmtpDeliveryMethod.Network;
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SmtpConfig.fromForCustomer);
                mailMessage.To.Add(customerEmail);
                if (IsHtmlBody)
                {
                    mailMessage.IsBodyHtml = IsHtmlBody;
                }
                mailMessage.Body = Message;
                mailMessage.Subject = SmtpConfig.subjectForCustomer;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: BL_Pay360CashierApi, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }

        }
        public async Task<bool> SendEmailToCustomer(string customerEmail, string Message, string productCode)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }

                if (Message == null || string.IsNullOrEmpty(Message.Trim()))
                {
                    return false;
                }


                //client.DeliveryMethod = SmtpDeliveryMethod.Network;
                MailMessage mailMessage = new MailMessage();
                if (productCode.ToUpper() == "WTCC")
                {
                    mailMessage.From = new MailAddress(SmtpConfig.fromForWtccCustomer);
                    mailMessage.Subject = SmtpConfig.subjectForWtccCustomer;
                }
                else if (productCode.ToUpper() == "STCC")
                {
                    mailMessage.From = new MailAddress(SmtpConfig.fromForStccCustomer);
                    mailMessage.Subject = SmtpConfig.subjectForStccCustomer;
                }
                else if (productCode.ToUpper() == "BTCC")
                {
                    mailMessage.From = new MailAddress(SmtpConfig.fromForBtccCustomer);
                    mailMessage.Subject = SmtpConfig.subjectForBtccCustomer;
                }
                else if (productCode.ToUpper() == "MTCC")
                {
                    mailMessage.From = new MailAddress(SmtpConfig.fromForMtccCustomer);
                    mailMessage.Subject = SmtpConfig.subjectForMtccCustomer;
                }
                else if (productCode.ToUpper() == "TDCC")
                {
                    mailMessage.From = new MailAddress(SmtpConfig.fromForTdccCustomer);
                    mailMessage.Subject = SmtpConfig.subjectForTdccCustomer;
                }
                else
                {
                    mailMessage.From = new MailAddress(productCode.ToUpper() == "NOWPAYG" ? SmtpConfig.fromForNowPayGCustomer : SmtpConfig.fromForCustomer);
                    mailMessage.Subject = (productCode.ToUpper() == "NOWPAYG" ? SmtpConfig.subjectForNowPayGCustomer : SmtpConfig.subjectForCustomer);
                }
                mailMessage.To.Add(customerEmail);
                mailMessage.Body = Message;

                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360_BL, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }

        }

        public async Task<bool> SendHtmlEmailToCustomer(string customerEmail, string htmlMessage, string productCode, string EmailSubject = null)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);
                MailMessage mailMessage = new MailMessage();
                string DisplayName = null;
                if (string.IsNullOrEmpty(htmlMessage))
                {
                    Logger.Error($"Class: BL_Pay360CashierApi, Method: SendHtmlEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {""}, ProductCode: {productCode}, ErrorMessage: Empty Message");
                    return false;
                }

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }
                var strFromEmail = "hello@talkhome.co.uk";

                if (string.IsNullOrEmpty(EmailSubject))
                {
                    EmailSubject = SmtpConfig.subjectForCustomer;
                }

                if (productCode.ToUpper() == "THM")
                {
                    strFromEmail = SmtpConfig.fromForTHMCustomer;
                }
                else if (productCode.ToUpper() == "THA")
                {
                    strFromEmail = SmtpConfig.fromForTHACustomer;
                }
                else if (productCode.ToUpper() == "THCC")
                {
                    strFromEmail = SmtpConfig.fromForTHCCCustomer;
                    DisplayName = SmtpConfig.DisplayNameForTHCC;
                }
                else if (productCode.ToUpper() == "NOWPAYG")
                {
                    strFromEmail = SmtpConfig.fromForNowPayGCustomer;
                }
                else if (productCode.ToUpper() == "WTCC")
                {
                    strFromEmail = SmtpConfig.fromForWtccCustomer;
                    EmailSubject = SmtpConfig.subjectForWtccCustomer;
                }
                else if (productCode.ToUpper() == "STCC")
                {
                    strFromEmail = SmtpConfig.fromForStccCustomer;
                    EmailSubject = SmtpConfig.subjectForStccCustomer;
                }
                else if (productCode.ToUpper() == "BTCC")
                {
                    strFromEmail = SmtpConfig.fromForBtccCustomer;
                    EmailSubject = SmtpConfig.subjectForBtccCustomer;
                }
                else if (productCode.ToUpper() == "MTCC")
                {
                    strFromEmail = SmtpConfig.fromForMtccCustomer;
                    EmailSubject = SmtpConfig.subjectForMtccCustomer;
                }
                else if (productCode.ToUpper() == "TDCC")
                {
                    strFromEmail = SmtpConfig.fromForTdccCustomer;
                    EmailSubject = SmtpConfig.subjectForTdccCustomer;
                }

                //client.DeliveryMethod = SmtpDeliveryMethod.Network;
                if (DisplayName != null)
                {
                    mailMessage.From = new MailAddress(strFromEmail, DisplayName);
                }
                else
                {
                    mailMessage.From = new MailAddress(strFromEmail);
                }

                mailMessage.To.Add(customerEmail);
                mailMessage.Body = htmlMessage;
                mailMessage.IsBodyHtml = true;
                mailMessage.Subject = EmailSubject;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: BL_Pay360CashierApi, Method: SendHtmlEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {htmlMessage}, ProductCode: {productCode}, ErrorMessage: {ex.Message}");
                return false;
            }

        }


        #endregion EmailAndSms

        #region PrivateMethods
        private async Task SaveFailedTransactionApiError(string transactionMerchantRef, int customerId, PaymentMethods paymentMethod, bool isDeferred, double? amount, string currency, ProductBasket[] basket, string ApiInstallationIdCashierApi)
        {
            await Db.AddTransaction(new Pay360Transaction
            {
                TransactionMerchantRef = transactionMerchantRef,
                Customer_Id = customerId,
                PaymentMethod_Id = (int)PaymentMethods.Card,
                TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR,
                RequestTime = DateTime.UtcNow,
                TransactionAmount = amount,
                TransactionCurrency = currency,
                TransactionType_Id = isDeferred == true ? (int)Pay360TransactionTypes.PREAUTH : (int)Pay360TransactionTypes.PAYMENT,
                ApiInstallationIdCashierApi = ApiInstallationIdCashierApi
            },
            basket,
            false
            );
        }

        private async Task SaveFailedTransactionApiErrorWithoutBasket(string transactionMerchantRef, int customerId, PaymentMethods paymentMethod, bool isDeferred, double? amount, string currency, string ApiInstallationIdCashierApi)
        {
            await Db.AddTransactionWithoutBasket(new Pay360Transaction
            {
                TransactionMerchantRef = transactionMerchantRef,
                Customer_Id = customerId,
                PaymentMethod_Id = (int)PaymentMethods.Card,
                TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR,
                RequestTime = DateTime.UtcNow,
                TransactionAmount = amount,
                TransactionCurrency = currency,
                TransactionType_Id = isDeferred == true ? (int)Pay360TransactionTypes.PREAUTH : (int)Pay360TransactionTypes.PAYMENT,
                ApiInstallationIdCashierApi = ApiInstallationIdCashierApi
            }
            );
        }
        //private async Task SaveFailed3DTransactionApiError(string transactionid, string pareq)
        //{
        //    await Db.AddTransaction(new Pay360Transaction
        //    {
        //        Pay360TransactionId = transactionid,
        //        ClientRedirectPaReq = pareq,
        //        RequestTime = DateTime.UtcNow
        //    });
        //}

        private Pay360Transaction CreateDbTransactionObject(ApiPaymentResponse apiPaymentResponse, int customerId, string transactionMerchantRef, PaymentMethods paymentMethod, string ApiInstallationIdCashierApi, string ipAddress = null)
        {
            return new Pay360Transaction
            {
                RequestTime = DateTime.UtcNow,
                TransactionMerchantRef = transactionMerchantRef,
                Customer_Id = customerId,
                Pay360TransactionId = apiPaymentResponse.Transaction.TransactionId,
                TransactionAmount = apiPaymentResponse.Transaction.Amount,
                TransactionStatus_Id = (int)apiPaymentResponse.Transaction.Status.ToEnum<Pay360TransactionStatuses>(),
                TransactionType_Id = (int)apiPaymentResponse.Transaction.Type.ToEnum<Pay360TransactionTypes>(),
                TransactionCurrency = apiPaymentResponse.Transaction.Currency,
                TransactionTime = DateTimeOffset.Parse(apiPaymentResponse.Transaction.TransactionTime).UtcDateTime,
                TransactionReceivedTime = DateTimeOffset.Parse(apiPaymentResponse.Transaction.ReceivedTime).UtcDateTime,
                Route = apiPaymentResponse.Processing == null ? null : apiPaymentResponse.Processing.Route,
                TransactionCommerceType = apiPaymentResponse.Transaction.CommerceType,
                OutcomeReasonCode = apiPaymentResponse.Outcome.ReasonCode,
                OutcomeReasonMessage = apiPaymentResponse.Outcome.ReasonMessage,
                OutcomeStatus = apiPaymentResponse.Outcome.Status,
                AuthStatusCode = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.StatusCode),
                AuthMessage = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.Message),
                AuthCode = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.AuthCode),
                AuthGatewayReference = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.GatewayReference),
                AuthGatewaySettlement = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.GatewaySettlement),
                AuthGatewayCode = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.GatewayCode),
                AuthGatewayMessage = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.GatewayMessage),
                AuthAvsAddressCheck = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.AvsAddressCheck),
                AuthAvsPostCodeCheck = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.AvsPostCodeCheck),
                AuthCv2Check = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.Cv2Check),
                AuthStatus = apiPaymentResponse.Processing == null ? null : (apiPaymentResponse.Processing.AuthResponse == null ? null : apiPaymentResponse.Processing.AuthResponse.Status),
                CardMaskedPan = apiPaymentResponse.PaymentMethod.Card.MaskedPan,
                FinancialServicesDob = apiPaymentResponse.FinancialServices == null ? null : apiPaymentResponse.FinancialServices.DateOfBirth,
                FinancialServicesAccountNumber = apiPaymentResponse.FinancialServices == null ? null : apiPaymentResponse.FinancialServices.AccountNumber,
                FinancialServicesPostCode = apiPaymentResponse.FinancialServices == null ? null : apiPaymentResponse.FinancialServices.PostCode,
                FinancialServicesSurName = apiPaymentResponse.FinancialServices == null ? null : apiPaymentResponse.FinancialServices.Surname,
                PaymentMethod_Id = (int)paymentMethod,
                Is3DSecure = apiPaymentResponse.ClientRedirect == null ? false : true,
                ThreeDSecureEci = apiPaymentResponse.ThreeDSecure == null ? null : apiPaymentResponse.ThreeDSecure.Eci,
                ThreeDSecureEnrolmentDateTime = apiPaymentResponse.ThreeDSecure == null ? null : apiPaymentResponse.ThreeDSecure.EnrolmentDateTime,
                ThreeDSecureEnrolmentIndicator = apiPaymentResponse.ThreeDSecure == null ? null : apiPaymentResponse.ThreeDSecure.EnrolmentIndicator,
                ThreeDSecureEnrolmentStatus = apiPaymentResponse.ThreeDSecure == null ? null : apiPaymentResponse.ThreeDSecure.EnrolmentStatus,
                ThreeDSecureScheme = apiPaymentResponse.ThreeDSecure == null ? null : apiPaymentResponse.ThreeDSecure.Scheme,
                ThreeDSecureStatus = apiPaymentResponse.ThreeDSecure == null ? null : apiPaymentResponse.ThreeDSecure.Status,
                ThreeDSecureXid = apiPaymentResponse.ThreeDSecure == null ? null : apiPaymentResponse.ThreeDSecure.Xid,
                ThreeDSecureAuthenticationIndicator = apiPaymentResponse.ThreeDSecure == null ? null : apiPaymentResponse.ThreeDSecure.AuthenticationIndicator,
                ThreeDSecureAuthenticationStatus = apiPaymentResponse.ThreeDSecure == null ? null : apiPaymentResponse.ThreeDSecure.AuthenticationStatus,
                ThreeDSecureAvv = apiPaymentResponse.ThreeDSecure == null ? null : apiPaymentResponse.ThreeDSecure.Avv,
                ClientRedirectPaReq = apiPaymentResponse.ClientRedirect == null ? null : apiPaymentResponse.ClientRedirect.Pareq,
                ClientRedirectUrl = apiPaymentResponse.ClientRedirect == null ? null : apiPaymentResponse.ClientRedirect.Url,
                ClientRirectType = apiPaymentResponse.ClientRedirect == null ? null : apiPaymentResponse.ClientRedirect.Type,
                IpAddress = ipAddress == null ? null : ipAddress,
                ApiInstallationIdCashierApi = ApiInstallationIdCashierApi
            };
        }

        private Pay360TransactionSummary CreateDbTransactionSummaryObject(Pay360Transaction dbTransaction, string customerMerchantRef, bool IsAuthorisation, Pay360SummaryTransactionTypes pay360SummaryTransactionType)
        {
            var obj = new Pay360TransactionSummary
            {
                Customer_Id = dbTransaction.Customer_Id,
                CustomerMerchantRef = customerMerchantRef,
                Pay360TransactionId = dbTransaction.Pay360TransactionId,
                TransactionAmount = dbTransaction.TransactionAmount,
                TransactionCurrency = dbTransaction.TransactionCurrency,
                TransactionMerchantRef = dbTransaction.TransactionMerchantRef,
                Is3DSecure = dbTransaction.Is3DSecure
            };

            if (IsAuthorisation)
            {
                obj.Preauth_Transaction_Id = dbTransaction.Id;
                obj.Transaction_PreAuth_DateTime = dbTransaction.TransactionTime;
                obj.TransactionStatus_Id = Pay360SummaryTransactionStatuses.PREAUTH;
            }
            else
            {
                obj.Single_Payment_Transaction_Id = dbTransaction.Id;
                obj.Transaction_SinglePayment_DateTime = dbTransaction.TransactionTime;
                obj.TransactionStatus_Id = Pay360SummaryTransactionStatuses.SINGLEPAYMENT;
            }

            obj.TransactionType_Id = pay360SummaryTransactionType;

            return obj;
        }


        #endregion



    }
}
