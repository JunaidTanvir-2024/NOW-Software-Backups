﻿using System.ComponentModel.DataAnnotations;

namespace NowPayGApi.Models.Contracts.Request
{
    public class LoginRequestModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }
        //[Required]
        //[EmailAddress]
        //public string Email { get; set; }

        //[Required]
        //[StringLength(50, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        //[DataType(DataType.Password)]
        //public string Password { get; set; }
    }
    public class LoginRequestModelAdmin
    {
        [Required]
        [EmailAddress]
        public string UserName { get; set; }

        [Required]
        public string Password { get; set; }
    }
   
}
