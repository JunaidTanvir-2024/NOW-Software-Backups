﻿using NowPayG.Models;

namespace NowPayG.Utility
{
    public class Global
    {
        public static BaseViewModel BaseModel = new BaseViewModel();
    }
}
