﻿namespace Application.Common.Enums;

public enum OtpType : byte
{
    ForgotPassword = 1,
    SignUp = 2,
    Device = 3,
    AddProduct = 4,
    UpdateProduct = 5,
    FreeSimOrder = 6,
    CreditSimOrder = 7,
    FreeSimWithPortIn =8
}
