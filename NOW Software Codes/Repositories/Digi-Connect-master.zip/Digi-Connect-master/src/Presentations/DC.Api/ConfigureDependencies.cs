using DC.Core.Common.Definitions;

using Hangfire;

namespace DC.Api;

public static class ConfigureDependencies
{
    public static IServiceCollection AddApiDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHangfire(x => x.UseSqlServerStorage(configuration.GetConnectionString(AppConstants.Database.Name.DigiConnect)));
        services.AddHangfireServer();
        services.AddControllers();
        services.AddControllers();
        services.AddCoreDependencies(configuration);
        services.AddInfrastructureDependencies(configuration);
        return services;
    }
}
