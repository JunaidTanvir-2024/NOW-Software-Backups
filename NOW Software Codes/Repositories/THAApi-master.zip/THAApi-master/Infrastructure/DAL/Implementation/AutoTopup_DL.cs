﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Database;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class AutoTopup_DL : IAutoTopup_DL
	{
		private readonly string _connectionString;
		private readonly ILogger<AutoTopup_DL> _logger;

		public AutoTopup_DL(IOptions<ConnectionStrings> connectionStrings,
			ILogger<AutoTopup_DL> logger)
		{
			this._connectionString = connectionStrings.Value.TalkHomeAppDigiTalkDb;
			this._logger = logger;
		}
		public async Task<AutoTopupDetail> Get(string msisdn)
		{
			try
			{
				DynamicParameters parameters = new DynamicParameters();
				parameters.Add("@Msisdn", msisdn);

				using var dbConnection = new SqlConnection(_connectionString);
				var result = await dbConnection.QueryFirstOrDefaultAsync<AutoTopupDetail>(StoredProcedures.AutoTopup.Get, parameters, commandType: CommandType.StoredProcedure);
				return result;
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Class: AutoTopup_DL, Method: GetCustomerAutoTopup_THA, Parameters=>  msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
				throw;
			}
		}

		public async Task<int> Set(AutoTopupDetail entity)
		{
			try
			{
				DynamicParameters parameters = new DynamicParameters();
				parameters.Add("@AutoTopupTheresholdAmount", entity.ThresHold);
				parameters.Add("@IsAutoTopup", entity.Status);
				parameters.Add("@Msisdn", entity.Msisdn);
				parameters.Add("@TopupAmount", entity.Topup);
				parameters.Add("@TopupCurrency", entity.Currency);
				parameters.Add("@PaymentMethod", entity.PaymentMethod);
				parameters.Add("@CardMaskedPAN", entity.CardMaskedPAN);
				parameters.Add("@CardInitialTransactionId", entity.CardInitialTransactionId);
				parameters.Add("@PaypalSubscriptionId", entity.PaypalSubscriptionId);

				using var dbConnection = new SqlConnection(_connectionString);
				var result = await dbConnection.ExecuteAsync(StoredProcedures.AutoTopup.Set, parameters, commandType: CommandType.StoredProcedure);
				return result;
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Class: AutoTopup_DL, Method: UpdateCustomerAutoTopup_THA, Parameters=> autoTopupTheresholdAmount: {entity.ThresHold}, isAutoTopup: {entity.Status}, msisdn: {entity.Msisdn}, topupAmount: {entity.Topup}, topupCurrency: {entity.Currency}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
				throw;
			}
		}

	}
}
