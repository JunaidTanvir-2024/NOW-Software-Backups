using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class Source
{
    [JsonPropertyName("banner")]
    public string? Banner { get; set; }
    [JsonPropertyName("object_id")]
    public string? ObjectId { get; set; }
    [JsonPropertyName("object_type")]
    public string? ObjectType { get; set; }
}