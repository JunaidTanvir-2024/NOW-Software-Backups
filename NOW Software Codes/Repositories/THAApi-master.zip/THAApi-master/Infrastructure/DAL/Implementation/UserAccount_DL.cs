﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Request;
using Models.Database;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Infrastructure.BLL.Interfaces;
using Models.Contracts.Request.User_Account;
using Models.Contracts.Response;
using System.Diagnostics;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Newtonsoft.Json.Serialization;
using Status = Models.Enums.Status;
using Microsoft.Extensions.Localization;
using System.Globalization;
using Microsoft.AspNetCore.Hosting;
using Models.Contracts.Request.Bundle;
using Models.Contracts.Request.Digitalk;
using Models.Constants;
using System.Security.Principal;

namespace Infrastructure.DAL.Implementation
{
    public class UserAccount_DL : IUserAccount_DL
    {
        private ILogger _logger;
        private readonly IHelper_BL _helperService;
        private readonly IStringLocalizer _localizer;
        private readonly ApiConfig _apiConfig;
        private IConfiguration _configuration;
        private readonly ConnectionStrings _dbConnections;
        private HttpClient _digitalkAppsApiClient;
        private readonly IHostingEnvironment _hostingEnv;

        public UserAccount_DL(
            IConfiguration configuration,
            IOptions<ApiConfig> apiConfig,
            IOptions<ConnectionStrings> dbConnections,
            ILogger logger,
            IHelper_BL helperService,
            IStringLocalizer localizer,
            HttpClient httpClient,
            IHostingEnvironment HostingEnv
)
        {
            _logger = logger;
            _helperService = helperService;
            _localizer = localizer;
            _apiConfig = apiConfig.Value;
            _configuration = configuration;
            _dbConnections = dbConnections.Value;
            _digitalkAppsApiClient = httpClient;
            _hostingEnv = HostingEnv;
        }

        /// <summary>
        /// Get calling history from Apps database [ConnectionString: TalkHomeAppDigiTalkDb]
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        public async Task<IEnumerable<DBCallHistory>> GetCallingHistory(string accountNumber)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@account", accountNumber, dbType: DbType.String);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                return await dbConnection.QueryAsync<DBCallHistory>("tha_web_call_history", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        /// <summary>
        /// Check whether user is doing first topup or not from Apps database [ConnectionString: TalkHomeAppDigiTalkDb] 
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<bool> IsFirstTopUp(string msisdn)
        {
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@msisdn", msisdn);

                DateTime? result = null;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    result = await dbConnection.ExecuteScalarAsync<DateTime?>("tha_first_topup", parameter, commandType: CommandType.StoredProcedure);
                }

                return result is null;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: IsFirstTopUp, Class: UserAccount_DL, Parameters: Msisdn {msisdn}");
            }
            return false;
        }
        /// <summary>
        /// Check user whether it is user first bundle or not from Apps database [ConnectionString: TalkHomeAppDigiTalkDb]
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<bool> IsFirstBundle(string msisdn)
        {
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@msisdn", msisdn);

                DateTime? result = null;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    result = await dbConnection.ExecuteScalarAsync<DateTime?>("tha_first_bundle", parameter, commandType: CommandType.StoredProcedure);
                }

                return result is null;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: IsFirstBundle, Class: UserAccount_DL, Parameters: Msisdn {msisdn}");
            }
            return false;
        }

        /// <summary>
        /// Check whether bundle exist or not 
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<int> IsBundleExists(string msisdn)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@productref", msisdn);
            parameters.Add("@isExits", dbType: DbType.Int32, direction: ParameterDirection.Output);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                await dbConnection.ExecuteAsync("tha_bundle_exists", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<int>("@isExits");
            }
        }

        /// <summary>
        /// Check user status whether user is new or already have transaction record 
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<bool> IsNewUser(string msisdn)
        {
            bool isNewUser = false;
            var parameters = new DynamicParameters();

            parameters.Add("@productref", msisdn);
            parameters.Add("@isNewUser", dbType: DbType.Boolean, direction: ParameterDirection.Output);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                await dbConnection.ExecuteAsync("tha_is_new_user", parameters, commandType: CommandType.StoredProcedure);

                isNewUser = parameters.Get<bool>("@isNewUser");
            }
            bool isAccountDeleted = await IsAccountDeleted(msisdn);
            isNewUser = !isAccountDeleted ? isNewUser : false;
            return isNewUser;
        }

        /// <summary>
        /// Insert email verification token
        /// </summary>
        /// <param name="phoneNumber"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task<int> InsertEmailVerificationToken(string phoneNumber, string token)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", phoneNumber);
            parameters.Add("@token", token);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                return await dbConnection.ExecuteAsync("tha_web_user_set_email_token", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        /// <summary>
        /// Get user registration date
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        public async Task<DateTime> GetUserRegistrationDate(string accountNumber)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@account", accountNumber);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
            {
                return await dbConnection.QueryFirstOrDefaultAsync<DateTime>("tha_web_get_registration_date", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        /// <summary>
        /// Get bundles history
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        public async Task<IEnumerable<DBBundles>> GetBundlesHistory(string accountNumber)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@account", accountNumber);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                return await dbConnection.QueryAsync<DBBundles>("tha_web_get_account_bundles", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        /// <summary>
        /// Get account details
        /// </summary>
        /// <param name="sipUsername"></param>
        /// <returns></returns>
        public async Task<DBAccountInfo> GetAccountDetailsBySipUsername(string sipUsername)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@sipuserName", sipUsername);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                return await dbConnection.QueryFirstOrDefaultAsync<DBAccountInfo>("tha_web_get_account_details_by_sipUsername", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        /// <summary>
        /// Get user notifications
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericResult<UserNotifications>> GetUserNotifications(string msisdn)
        {
            string logParameters = $" msisdn: {msisdn} ";
            try
            {
                var parameter = new DynamicParameters();

                parameter.Add("@msisdn", msisdn);

                UserNotifications userNotifications = new UserNotifications();

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    userNotifications = await dbConnection.QueryFirstOrDefaultAsync<UserNotifications>("tha_app_get_user_notifications", parameter, commandType: CommandType.StoredProcedure);
                }

                if (userNotifications is null)
                {
                    var defaultData = new UserNotifications()
                    {
                        canEmail = false,
                        canPush = false,
                        canSms = false
                    };
                    return new GenericResult<UserNotifications>() { Data = defaultData, Status = Status.Success, ErrorCode = 0, ErrorMessage = "" };
                }
                else
                {
                    return new GenericResult<UserNotifications>() { Data = userNotifications, Status = Status.Success, ErrorCode = 0, ErrorMessage = "" };
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetUserNotifications, Parameters=> {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<UserNotifications> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }
        }

        /// <summary>
        /// Update user notifications
        /// </summary>
        /// <param name="request"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericResult<string>> UpdateUserNotifications(UserNotifications request, string msisdn)
        {

            string logParameters = $" msisdn: {msisdn}, {JsonConvert.SerializeObject(request)} ";
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@msisdn", msisdn);
                parameter.Add("@canEmail", request.canEmail);
                parameter.Add("@canPush", request.canPush);
                parameter.Add("@canSms", request.canSms);

                int isUpdated = 0;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    isUpdated = await dbConnection.ExecuteAsync("tha_app_update_user_notifications", parameter, commandType: CommandType.StoredProcedure);
                }

                if (isUpdated < 1)
                {
                    _logger.Error($"Class: UserAccount_DL, Method: UpdateUserNotifications, Parameters=> {logParameters}, ErrorMessage: Error in updation.");
                    return new GenericResult<string> { Status = Status.Failure, ErrorMessage = "Error in updation", ErrorCode = 1 };
                }

                return new GenericResult<string> { Status = Status.Success, ErrorMessage = "Success", ErrorCode = 0 };

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: UpdateUserNotifications, Parameters=> {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<string> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }
        }

        /// <summary>
        /// Update user profile
        /// </summary>
        /// <param name="request"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericResult<string>> UpdateUserProfile(UpdateUserProfileResponse request, string msisdn)
        {
            string logParameters = $" msisdn: {msisdn}, {JsonConvert.SerializeObject(request)} ";
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@msisdn", msisdn);
                parameter.Add("@firstName", request.FirstName);
                parameter.Add("@lastName", request.LastName);
                parameter.Add("@email", request.Email);
                parameter.Add("@dobDay", request.DobDay);
                parameter.Add("@dobMonth", request.DobMonth);
                parameter.Add("@dobYear", request.DobYear);
                //parameter.Add("@canEmail", request.CanEmail);
                //parameter.Add("@canPush", request.CanPush);
                //parameter.Add("@canSms", request.CanSms);
                parameter.Add("@image", request.Image);

                int isUpdated = 0;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    isUpdated = await dbConnection.ExecuteAsync("tha_app_update_user_registration", parameter, commandType: CommandType.StoredProcedure);
                }

                if (isUpdated < 1)
                {
                    _logger.Error($"Class: UserAccount_DL, Method: UpdateUserProfile, Parameters=> {logParameters}, ErrorMessage: Error in updation.");
                    return new GenericResult<string> { Status = Status.Failure, ErrorMessage = "Error in updation", ErrorCode = 1 };
                }

                return new GenericResult<string> { Status = Status.Success, ErrorMessage = "Success", ErrorCode = 0 };
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: UpdateUserProfile, Parameters=> {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<string> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }
        }

        /// <summary>
        /// Update user profile. This method work similar to UpdateUserProfile with the ability to handle one extra field isProfileCompleted in [tha_user_registration] table
        /// </summary>
        /// <param name="request"></param>
        /// <param name="msisdn"></param>
        /// <param name="isProfileCompleted"></param>
        /// <returns></returns>
        public async Task<GenericResult<string>> UpdateUserProfileV2(UpdateUserProfileResponse request, string msisdn, bool isProfileCompleted)
        {
            string logParameters = $" msisdn: {msisdn}, {JsonConvert.SerializeObject(request)} ";
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@msisdn", msisdn);
                parameter.Add("@firstName", request.FirstName);
                parameter.Add("@lastName", request.LastName);
                parameter.Add("@email", request.Email);
                parameter.Add("@isProfileCompleted", isProfileCompleted);
                parameter.Add("@dobDay", request.DobDay);
                parameter.Add("@dobMonth", request.DobMonth);
                parameter.Add("@dobYear", request.DobYear);
                //parameter.Add("@canEmail", request.CanEmail);
                //parameter.Add("@canPush", request.CanPush);
                //parameter.Add("@canSms", request.CanSms);
                parameter.Add("@image", request.Image);

                int isUpdated = 0;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    isUpdated = await dbConnection.ExecuteAsync("tha_app_update_user_registrationV2", parameter, commandType: CommandType.StoredProcedure);
                }

                if (isUpdated < 1)
                {
                    _logger.Error($"Class: UserAccount_DL, Method: UpdateUserProfile, Parameters=> {logParameters}, ErrorMessage: Error in updation.");
                    return new GenericResult<string> { Status = Status.Failure, ErrorMessage = "Error in updation", ErrorCode = 1 };
                }

                return new GenericResult<string> { Status = Status.Success, ErrorMessage = "Success", ErrorCode = 0 };

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: UpdateUserProfile, Parameters=> {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<string> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }
        }

        /// <summary>
        /// Get user profile
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericResult<Profile>> GetUserProfile(string msisdn)
        {
            var parameter = new DynamicParameters();
            parameter.Add("@msisdn", msisdn);

            Profile userProfile = new Profile();

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                userProfile = await dbConnection.QueryFirstOrDefaultAsync<Profile>("tha_app_get_user_registration", parameter, commandType: CommandType.StoredProcedure);
            }

            if (userProfile == null)
            {
                return new GenericResult<Profile>() { Data = new Profile() { msisdn = msisdn }, Status = Status.Success, ErrorCode = 0, ErrorMessage = "" };
            }
            else
            {
                return new GenericResult<Profile>() { Data = userProfile, Status = Status.Success, ErrorCode = 0, ErrorMessage = "" };
            }
        }

        /// <summary>
        /// Get user profile. This method work similar to GetUserProfile with the ability to map one extra field isProfileCompleted from [tha_user_registration] table
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericResult<Profile>> GetUserProfileV2(string msisdn)
        {
            var parameter = new DynamicParameters();
            parameter.Add("@msisdn", msisdn);

            Profile userProfile = new Profile();

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                userProfile = await dbConnection.QueryFirstOrDefaultAsync<Profile>("tha_app_get_user_registrationV2", parameter, commandType: CommandType.StoredProcedure);
            }

            if (userProfile == null)
            {
                return new GenericResult<Profile>() { Data = new Profile() { msisdn = msisdn }, Status = Status.Success, ErrorCode = 0, ErrorMessage = "" };
            }
            else
            {
                return new GenericResult<Profile>() { Data = userProfile, Status = Status.Success, ErrorCode = 0, ErrorMessage = "" };
            }
        }

        /// <summary>
        /// Get user account with balance
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<UserAccount> GetUserAccountWithBalance(string msisdn)
        {
            var sipUserName = _helperService.GetSipUserName(msisdn);

            var userAccount = await GetRawUserAccount(sipUserName);

            if (userAccount != null)
            {
                var accountId = userAccount.AccountID;
                userAccount.Msisdn = msisdn;

                var UserSubscriberDetails = await GetSubscriberDetailsByAccount(accountId);

                userAccount.SubscriberId = UserSubscriberDetails.SubscriberID;
                userAccount.UserAccountBalance = UserSubscriberDetails.UserAccountBalance;
                userAccount.UserAccountDetails = UserSubscriberDetails.UseSubscriberDetails;

                return userAccount;
            }

            return null;
        }

        /// <summary>
        /// Get subscriber details by account
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<UserSubscriberDetails> GetSubscriberDetailsByAccount(string account)
        {

            UserSubscriberDetails usbdet = new UserSubscriberDetails();
            try
            {
                Subscriber_Details usersubdet = null;

                var parameters = new DynamicParameters();

                parameters.Add("@account", account);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    usersubdet = await dbConnection.QueryFirstOrDefaultAsync<Subscriber_Details>("tha_get_subscriber_details", parameters, commandType: CommandType.StoredProcedure);
                }

                if (usersubdet != null)
                {
                    UserAccountDetails uaDet = new UserAccountDetails();
                    uaDet.AddressOne = usersubdet.AddressOne;
                    uaDet.AddressTwo = usersubdet.AddressTwo;
                    uaDet.AddressThree = usersubdet.AddressThree;
                    uaDet.AddressFour = usersubdet.AddressFour;
                    uaDet.Country = usersubdet.Country;
                    uaDet.DeliveryAddressOne = usersubdet.DeliveryAddressOne;
                    uaDet.DeliveryAddressTwo = usersubdet.DeliveryAddressTwo;
                    uaDet.DeliveryAddressThree = usersubdet.DeliveryAddressThree;
                    uaDet.DeliveryCountry = usersubdet.DeliveryCountry;
                    uaDet.DeliveryPostCode = usersubdet.DeliveryPostCode;
                    uaDet.EmailAddress = usersubdet.EmailAddress;
                    uaDet.FirstName = usersubdet.FirstName;
                    uaDet.LastName = usersubdet.LastName;
                    uaDet.Na_Service_Id = usersubdet.Na_Service_Id;
                    uaDet.PostCode = usersubdet.PostCode;
                    uaDet.referralCode = usersubdet.referralCode;
                    uaDet.TelephoneOne = usersubdet.TelephoneOne;
                    uaDet.TelephoneTwo = usersubdet.TelephoneTwo;
                    uaDet.Title = usersubdet.Title;

                    UserAccountBalance uacb = new UserAccountBalance();

                    if (usersubdet.Balance != null && !usersubdet.Balance.Equals(""))
                    {
                        uacb = new UserAccountBalance
                        {
                            Balance = _helperService.FormatAccountBalance(decimal.Parse(usersubdet.Balance, CultureInfo.InvariantCulture), usersubdet.Currency),
                            Currency = usersubdet.Currency,
                            CurrencySymbol = _helperService.ToCurrencySymbol(usersubdet.Currency)

                        };
                    }

                    usbdet.SubscriberID = usersubdet.SubscriberID;
                    usbdet.UserAccountBalance = uacb;
                    usbdet.UseSubscriberDetails = uaDet;

                }

                return usbdet;
            }
            catch (Exception ex)
            {
                _logger.Error(ex.ToString());

                return usbdet;
            }
        }

        /// <summary>
        /// Get destination rate
        /// </summary>
        /// <param name="sourceMsisdn"></param>
        /// <param name="destinationMsisdn"></param>
        /// <returns></returns>
        public async Task<DestinationRate> GetDestinationRate(string sourceMsisdn, string destinationMsisdn)
        {
            sourceMsisdn = _helperService.StripLeadingZeros(sourceMsisdn);
            destinationMsisdn = _helperService.StripLeadingZeros(destinationMsisdn);
            var formattedSourceMsisdn = _helperService.FormatMsisdn(sourceMsisdn);
            var sourceCountry = _helperService.GetCountryName(formattedSourceMsisdn);
            var destinationRatesTable = GetRatesTable(sourceCountry);
            var storedProcedure = "THA_GET_RATES_GENERIC_V1";

            var parameters = new DynamicParameters();

            parameters.Add("@number", destinationMsisdn);
            parameters.Add("@code", destinationRatesTable);

            dynamic resultSet = null;

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                resultSet = await dbConnection.QueryFirstOrDefaultAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
            }

            DestinationRate destinationRate = null;
            if (resultSet != null)
            {
                destinationRate = new DestinationRate
                {
                    Number = (string)resultSet.prefix,
                    Zone = (string)resultSet.zone_name,
                    CallRate = (decimal)resultSet.call_rate,
                    SMSRate = (decimal)resultSet.sms_rate
                };
            }

            return destinationRate;
        }

        /// <summary>
        /// Store message count
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <param name="messageCount"></param>
        /// <returns></returns>
        public async Task<bool> StoreMessageCount(string receivedMsisdn, int messageCount)
        {
            try
            {

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "UPDATE UserJourney SET MessageCount = @messageCount WHERE ReceivedMsisdn = @receivedMsisdn", new
                    {
                        receivedMsisdn = receivedMsisdn,
                        messageCount = messageCount,
                    });
                }


                return true;
            }
            catch (Exception ex)
            {
                _logger.Error("User journey exception {Ex}", ex.ToString());
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Sms Http Send Failed
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <param name="clxHttpRequest"></param>
        /// <returns></returns>
        public async Task<bool> SmsHttpSendFailed(string receivedMsisdn, string clxHttpRequest)
        {
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "UPDATE UserJourney SET SmsHttpSendFailed = @smsHttpSendFailed, ClxHttpRequest = @clxHttpRequest WHERE ReceivedMsisdn = @receivedMsisdn", new
                    {
                        receivedMsisdn = receivedMsisdn,
                        smsHttpSendFailed = true,
                        clxHttpRequest = clxHttpRequest
                    });
                }


                return true;
            }
            catch (Exception ex)
            {
                _logger.Error("User journey exception {Ex}", ex.ToString());
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Pin Sent
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <param name="smsSentToMsisdn"></param>
        /// <param name="clxHttpRequest"></param>
        /// <returns></returns>
        public async Task<bool> PinSent(string receivedMsisdn, string smsSentToMsisdn, string clxHttpRequest)
        {
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "UPDATE UserJourney SET PinSent = @pinSent, SmsSentToMsisdn = @smsSentToMsisdn, ClxHttpRequest = @clxHttpRequest WHERE ReceivedMsisdn = @receivedMsisdn", new
                    {
                        pinSent = DateTime.UtcNow,
                        receivedMsisdn = receivedMsisdn,
                        smsSentToMsisdn = smsSentToMsisdn,
                        clxHttpRequest = clxHttpRequest
                    });
                }



                return true;
            }
            catch (Exception ex)
            {
                _logger.Error("User journey exception {Ex}", ex.ToString());
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Store Pin Message Length And Encoding Type
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <param name="pinMessageLength"></param>
        /// <param name="encodingType"></param>
        /// <returns></returns>
        public async Task<bool> StorePinMessageLengthAndEncodingType(string receivedMsisdn, int pinMessageLength, string encodingType)
        {
            try
            {

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "UPDATE UserJourney SET PinMessageLength = @pinMessageLength, EncodingType = @encodingType WHERE ReceivedMsisdn = @receivedMsisdn", new
                    {
                        receivedMsisdn = receivedMsisdn,
                        pinMessageLength = pinMessageLength,
                        encodingType = encodingType
                    });
                }


                return true;
            }
            catch (Exception ex)
            {
                _logger.Error("User journey exception {Ex}", ex.ToString());
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Send To Number Parse Failed
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <returns></returns>
        public async Task<bool> SendToNumberParseFailed(string receivedMsisdn)
        {
            try
            {

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "UPDATE UserJourney SET SendToNumberParseFailed = @sendToNumberParseFailed WHERE ReceivedMsisdn = @receivedMsisdn", new
                    {
                        receivedMsisdn = receivedMsisdn,
                        SendToNumberParseFailed = true,
                    });
                }


                return true;
            }
            catch (Exception ex)
            {
                _logger.Error("User journey exception {Ex}", ex.ToString());
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Passes Sms Validation
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <returns></returns>
        public async Task<bool> PassesSmsValidation(string receivedMsisdn)
        {
            try
            {

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "UPDATE UserJourney SET PassesSmsValidation = @passesSmsValidation WHERE ReceivedMsisdn = @receivedMsisdn", new
                    {
                        receivedMsisdn = receivedMsisdn,
                        passesSmsValidation = true,
                    });
                }



                return true;
            }
            catch (Exception ex)
            {
                _logger.Error("User journey exception {Ex}", ex.ToString());
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Begin Pin Send
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <returns></returns>
        public async Task<bool> BeginPinSend(string receivedMsisdn)
        {
            try
            {

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "UPDATE UserJourney SET BeginPinSend = @beginPinSend WHERE ReceivedMsisdn = @receivedMsisdn", new
                    {
                        receivedMsisdn = receivedMsisdn,
                        beginPinSend = DateTime.UtcNow,
                    });
                }


                return true;
            }
            catch (Exception ex)
            {
                _logger.Error("User journey exception {Ex}", ex.ToString());
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Execute Web Call through
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="destination"></param>
        /// <param name="IsIOS"></param>
        /// <param name="IsAndroid"></param>
        /// <param name="IOSAllowedVersion"></param>
        /// <param name="AndroidAllowedVersion"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<string>> ExecuteWebCallthrough(string msisdn, string destination, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null)
        {
            GenericApiResponse<string> gRes = new GenericApiResponse<string>();

            gRes.Status = "Failure";
            gRes.Message = "Not Ready";

            var storedProcedure = string.Empty;
            var sipSettings = await GetSipConfigurations(msisdn, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);

            if (!sipSettings.is_somme_user)
            {
                storedProcedure = "tha_web_callthrough_update";
            }
            else
            {
                storedProcedure = "tha_Somme_web_callthrough_update";
            }

            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@cli", msisdn);
                parameters.Add("@bda", destination);
                parameters.Add("@error", dbType: DbType.Int32, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    await dbConnection.ExecuteAsync(storedProcedure, parameters,
                       commandType: CommandType.StoredProcedure);
                }

                int success = parameters.Get<int>("@error");

                if (success == 0)
                {
                    gRes.Status = "Success";
                    gRes.Message = "Ready";
                    gRes.Payload = null;
                }

                return gRes;

            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Failed to update web callthrough ", msisdn);
            }
            return gRes;
        }

        /// <summary>
        /// Get user email
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<useremailRegistration>> getEmail(string msisdn)
        {
            var storedProcedure = "tha_select_user_registration";
            GenericApiResponse<useremailRegistration> gr = new GenericApiResponse<useremailRegistration>();

            var parameters = new DynamicParameters();

            try
            {
                parameters.Add("@msisdn", msisdn);

                useremailRegistration usrRegis = null;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    usrRegis = await dbConnection.QueryFirstOrDefaultAsync<useremailRegistration>(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);
                }

                gr.Status = "Success";
                gr.Message = "Success";
                gr.Payload = usrRegis;

                return gr;
            }
            catch (Exception ex)
            {
                gr.Status = "Failure";
                gr.Message = "Failure";

                _logger.Error(ex, "Failed to GetPromotions from api", msisdn);
            }

            return gr;
        }

        /// <summary>
        /// Set email
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<bool>> SetEmail(string msisdn, Email email)
        {
            var storedProcedure = "tha_update_user_registration";

            GenericApiResponse<bool> gr = new GenericApiResponse<bool>();

            var parameters = new DynamicParameters();

            try
            {
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@email", email.email);
                parameters.Add("@canBeContacted", email.canSend);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);
                }

                gr.Status = "Success";
                gr.Message = "Success";
                gr.Payload = true;

                return gr;
            }
            catch (Exception ex)
            {
                gr.Status = "Failure";
                gr.Message = "Failure";

                _logger.Error(ex, "Failed to SetEmail from api", msisdn);
            }

            return gr;
        }

        /// <summary>
        /// Is Enabled For User
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<bool> IsEnabledForUser(string msisdn)
        {
            if (msisdn.StartsWith("00"))
            {
                msisdn = msisdn.Remove(0, 2);
            }

            int callFeedbackCount = 0;
            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                callFeedbackCount = (
                    await dbConnection.QueryAsync<int>(
                    "select count(*) from CallFeedback (nolock) where msisdn = @msisdn",
                    new { msisdn })
                ).Single();
            }

            return callFeedbackCount < 3;
        }

        /// <summary>
        /// Set FCM Token
        /// </summary>
        /// <param name="fcmToken"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<bool>> SetFCMToken(FCMToKenReq fcmToken, string msisdn)
        {
            var storedProcedure = "tha_fcm_api_setToken";
            GenericApiResponse<bool> gr = new GenericApiResponse<bool>();

            var parameters = new DynamicParameters();

            try
            {
                parameters.Add("@token", fcmToken.token);
                parameters.Add("@msisdn", msisdn);

                int isFCMTokenSet = 0;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    isFCMTokenSet = await dbConnection.ExecuteAsync(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);
                }

                gr.Status = "Success";
                gr.Message = "Success";
                gr.Payload = true;

                return gr;
            }
            catch (Exception ex)
            {
                gr.Status = "Failure";
                gr.Message = "Failure";
                gr.Payload = false;
                _logger.Error(ex, "Class: UserAccount_DL, Method: SetFCMToken", msisdn);
            }

            return gr;

        }

        /// <summary>
        /// Get User Account Pin
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<string> GetUserAccountPin(string msisdn)
        {

            try
            {
                var parameters = new DynamicParameters();

                var sipusername = $"THA{msisdn}";

                parameters.Add("@sip_user_name", sipusername);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryFirstOrDefaultAsync<string>("tha_get_pin_v4", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Get local access number
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="IsIOS"></param>
        /// <param name="IsAndroid"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<IEnumerable<LocalAccessNumber2>>> Get2(string msisdn, bool IsIOS = false, bool IsAndroid = false)
        {
            var response = new GenericApiResponse<IEnumerable<LocalAccessNumber2>>();

            IEnumerable<LocalAccessNumber2> countryNumbers = Enumerable.Empty<LocalAccessNumber2>();

            countryNumbers = await GetLocalAccessNumbers2(msisdn, IsIOS, IsAndroid);

            if (countryNumbers != null && countryNumbers.Any())
            {
                response.Status = "Success";
                response.Message = "Success";
                response.Payload = countryNumbers;
            }
            else
            {
                response.Status = "Success";
                response.Message = _localizer["NoLocalAccessNumbersAvailable"];
            }

            return response;
        }

        /// <summary>
        /// Get Local Access Numbers 2
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="IsIOS"></param>
        /// <param name="IsAndroid"></param>
        /// <returns></returns>
        private async Task<IEnumerable<LocalAccessNumber2>> GetLocalAccessNumbers2(string msisdn, bool IsIOS = false, bool IsAndroid = false)
        {
            try
            {
                var sipSettings = await GetSipConfigurations(msisdn, IsIOS, IsAndroid);
                var sp = string.Empty;

                if (!sipSettings.is_somme_user)
                {
                    sp = "tha_get_tha_local_access_numbers2";
                }
                else
                {
                    sp = "tha_somme_get_tha_local_access_numbers2";
                }

                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                IEnumerable<LocalAccessNumber2> localAccessNumbers = Enumerable.Empty<LocalAccessNumber2>();

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    localAccessNumbers = await dbConnection.QueryAsync<LocalAccessNumber2>(sp, parameters, commandType: CommandType.StoredProcedure);
                }

                return localAccessNumbers;
            }
            catch (Exception ex)
            {
                _logger.Error(ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Set Promotions
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="promotion"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<bool>> SetPromotions(string msisdn, Promotion promotion)
        {
            var storedProcedure = "tha_update_transfer_alert";
            GenericApiResponse<bool> gr = new GenericApiResponse<bool>();

            var parameters = new DynamicParameters();

            try
            {
                var country_code = string.IsNullOrEmpty(promotion.countryId.Trim()) ? 0 : int.Parse(promotion.countryId);
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@country_name", promotion.countryName);
                parameters.Add("@country_code", country_code);
                parameters.Add("@altert_status", promotion.status);

                int status = 0;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    status = await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }

                gr.Status = "Success";
                gr.Message = "Success";
                gr.Payload = true;

                return gr;
            }
            catch (Exception ex)
            {
                gr.Status = "Failure";
                gr.Message = "Failure";

                _logger.Error(ex, "Failed to GetPromotions from api", msisdn);
            }

            return gr;
        }

        /// <summary>
        /// Get Promotion Alerts
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<IEnumerable<Country>>> GetPromotionAlerts(string msisdn)
        {
            var storedProcedure = "tha_get_transfer_alert";
            GenericApiResponse<IEnumerable<Country>> gr = new GenericApiResponse<IEnumerable<Country>>();

            var parameters = new DynamicParameters();

            try
            {
                parameters.Add("@msisdn", msisdn);

                IEnumerable<Country> callCountry = Enumerable.Empty<Country>();

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    callCountry = await dbConnection.QueryAsync<Country>(storedProcedure, parameters,
                           commandType: CommandType.StoredProcedure);
                }

                gr.Status = "Success";
                gr.Message = "Success";
                gr.Payload = callCountry;

                return gr;
            }
            catch (Exception ex)
            {
                gr.Status = "Failure";
                gr.Message = "Failure";

                _logger.Error(ex, "Failed to GetPromotions from api", msisdn);
            }

            return gr;

        }

        /// <summary>
        /// Get Referrals
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<Referrals>> GetReferrals(string msisdn)
        {
            GenericApiResponse<Referrals> gr = new GenericApiResponse<Referrals>();

            var storedProcedure = "tha_raf_referrals";

            var parameters = new DynamicParameters();

            try
            {
                Referrals rf = new Referrals();
                parameters.Add("@msisdn", msisdn);

                IEnumerable<Referral> referrals = Enumerable.Empty<Referral>();

                using (var dbConnection = new SqlConnection(_dbConnections.DigitalkAppsRepDb))
                {
                    referrals = await dbConnection.QueryAsync<Referral>(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);
                }

                var lstOut = ConvertList(referrals, msisdn);

                gr.Status = "Success";
                gr.Message = "Success";

                rf.referrals = lstOut;

                gr.Payload = rf;
            }
            catch (Exception ex)
            {
                gr.Status = "Success";
                gr.Message = "Success";

                _logger.Error(ex, "Failed to GetReferrals from database", msisdn);
            }

            return gr;

        }

        /// <summary>
        /// Convert List
        /// </summary>
        /// <param name="lstDB"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        private List<ReferralOut> ConvertList(IEnumerable<Referral> lstDB, string msisdn)
        {
            var currency = msisdn == "44" ? _localizer["Currency44"] : _localizer["CurrencyOther"];

            List<ReferralOut> lstOut = new List<ReferralOut>();
            foreach (var item in lstDB)
            {
                lstOut.Add(new ReferralOut() { amount = currency + (item.amount / 100).ToString(CultureInfo.InvariantCulture), date = item.Date, msisdn = item.msisdn });
            }

            return lstOut;
        }

        /// <summary>
        /// Add or Remove Credit To Balance Transfer
        /// </summary>
        /// <param name="transaction"></param>
        /// <param name="sourceUserAccount"></param>
        /// <param name="destinationAccount"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<bool>> AddRemoveCreditToBalanceTransfer(TransferBalanceTransaction transaction,
           UserAccount sourceUserAccount,
           UserAccount destinationAccount
           )
        {
            string paymentmethod = "Balance Transfer";

            var response = new GenericApiResponse<bool>();
            string adjustmentreason_cr = "TALK HOME App - Balance Transfer C";
            string adjustmentreason_deb = "TALK HOME App - Balance Transfer D";

            int rechargetype_cr = 45;
            int rechargetype_deb = 44;
            decimal amount_cr = decimal.Parse(transaction.Destination.Amount, CultureInfo.InvariantCulture) * 100;
            decimal amount_deb = decimal.Parse(transaction.Source.Amount, CultureInfo.InvariantCulture) * 100;

            var removeCredit = await RemoveCreditViaSql(sourceUserAccount.AccountID,
               amount_deb,
               adjustmentreason_deb,
               destinationAccount.AccountID,
               rechargetype_deb,
               transaction.Id
              );

            if (removeCredit != null && !string.IsNullOrEmpty(removeCredit.AuditID))
            {

                var addCredit = await AddCreditViaSql(destinationAccount.AccountID,
                amount_cr,
                adjustmentreason_cr,
                sourceUserAccount.AccountID,
                rechargetype_cr,
                transaction.Id
               );

                if (addCredit.Amount == 0)
                {
                    response.Payload = false;
                    response.Status = "2";
                    response.Message = _localizer["TransferServiceNotvailable"];

                }
                else
                {
                    response.Payload = true;
                    response.Status = "Success";
                    response.Message = "Success";
                }

            }
            else
            {
                response.Payload = false;
                response.Status = "3";
                response.Message = _localizer["TransferServiceNotvailable"];

            }

            return response;
        }

        /// <summary>
        /// Remove Credit Via Sql
        /// </summary>
        /// <param name="accountID"></param>
        /// <param name="amount"></param>
        /// <param name="adjustmentreason"></param>
        /// <param name="paymentmethod"></param>
        /// <param name="rechargetype"></param>
        /// <param name="reference"></param>
        /// <returns></returns>
        private async Task<DTCrditResponse> RemoveCreditViaSql(string accountID, decimal amount, string adjustmentreason, string paymentmethod, int rechargetype, string reference)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@account", accountID);
                parameters.Add("@channel", 1);
                parameters.Add("@bonus", 0);
                parameters.Add("@amount", -1 * amount);
                parameters.Add("@creditReason", adjustmentreason);
                parameters.Add("@paymentMethod", paymentmethod);
                parameters.Add("@rechargeType", rechargetype);
                parameters.Add("@reference", reference);
                parameters.Add("@ccsTransId", 0);
                parameters.Add("@ccAuthCode", "ap2app");

                AccBal acctBal = new AccBal();

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    acctBal = await dbConnection.QueryFirstOrDefaultAsync<AccBal>("AccountUpdateBalance", parameters, commandType: CommandType.StoredProcedure);
                }

                DTCrditResponse dt = new DTCrditResponse();
                dt.AuditID = acctBal.audit_id.ToString(CultureInfo.InvariantCulture);
                dt.Amount = acctBal.new_balance;

                return dt;
            }
            catch (Exception ex)
            {
                DTCrditResponse dt = new DTCrditResponse();
                dt.AuditID = "";
                dt.Amount = 0;

                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: RemoveCreditViaSql, Class: UserAccount_DL, Parameters: AccountId {accountID}, Amount {amount},  AdjustmentReason {adjustmentreason},  PaymentMethod {paymentmethod}, RechargeType {rechargetype},  Reference {reference}");

                return dt;
            }
        }

        /// <summary>
        /// Add Credit Via Sql
        /// </summary>
        /// <param name="accountID"></param>
        /// <param name="amount"></param>
        /// <param name="adjustmentreason"></param>
        /// <param name="paymentmethod"></param>
        /// <param name="rechargetype"></param>
        /// <param name="reference"></param>
        /// <returns></returns>
        private async Task<DTCrditResponse> AddCreditViaSql(string accountID, decimal amount, string adjustmentreason, string paymentmethod, int rechargetype, string reference)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@account", accountID);
                parameters.Add("@channel", 1);
                parameters.Add("@bonus", 0);
                parameters.Add("@amount", amount);
                parameters.Add("@creditReason", adjustmentreason);
                parameters.Add("@paymentMethod", paymentmethod);
                parameters.Add("@rechargeType", rechargetype);
                parameters.Add("@reference", reference);
                parameters.Add("@ccsTransId", 0);
                parameters.Add("@ccAuthCode", "ap2app");

                AccBal acctBal = new AccBal();

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    acctBal = await dbConnection.QueryFirstOrDefaultAsync<AccBal>("AccountUpdateBalance", parameters, commandType: CommandType.StoredProcedure);
                }

                DTCrditResponse dt = new DTCrditResponse();
                dt.AuditID = acctBal.audit_id.ToString(CultureInfo.InvariantCulture);
                dt.Amount = acctBal.new_balance;

                return dt;
            }
            catch (Exception ex)
            {
                DTCrditResponse dt = new DTCrditResponse();
                dt.AuditID = "";
                dt.Amount = 0;
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: AddCreditViaSql, Class: UserAccount_DL, Parameters: AccountId {accountID}, Amount {amount},  AdjustmentReason {adjustmentreason},  PaymentMethod {paymentmethod}, RechargeType {rechargetype},  Reference {reference}");
                return dt;
            }
        }

        /// <summary>
        /// Debit Account Balance
        /// </summary>
        /// <param name="account"></param>
        /// <param name="Amount"></param>
        /// <param name="reference"></param>
        /// <param name="authcode"></param>
        /// <returns></returns>
        public async Task<DBAccountBalance> DebitAccountBalance(string account, decimal Amount, string reference, string authcode)
        {
            var destinationAmount = Amount;

            //Multiply everything by 100 since we store money in pence...
            var debitAmount = -(destinationAmount * 100);
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryFirstOrDefaultAsync<DBAccountBalance>
                       ("AccountUpdateBalance", new
                       {
                           account = account,
                           channel = 0,
                           amount = debitAmount,
                           bonus = 0m,
                           creditReason = "AirTime Transfer Debit",
                           paymentMethod = "",
                           rechargeType = 0,
                           reference = reference,
                           ccsTransId = 0,
                           ccAuthCode = authcode,
                       }, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                _logger.Error("Exception in CreditAccountBalance : " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Update Referral Code
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="referralCode"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<string>> UpdateReferralCode(string msisdn, ReferralCode referralCode)
        {
            var response = new GenericApiResponse<string>();

            var storedProcedure = "tha_update_referrals";

            var parameters = new DynamicParameters();
            try
            {

                parameters.Add("@msisdn", msisdn);
                parameters.Add("@referralCode", referralCode.referralCode);
                parameters.Add("@errorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorRemarks", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);
                }

                //Parse output values
                var errorCode = parameters.Get<int>("@errorCode");
                var errorRemarks = parameters.Get<string>("@errorRemarks");

                response.Payload = "";
                response.Message = errorRemarks;

                if (errorCode == 0)
                    response.Status = "Success";
                else
                    response.Status = "Failure";

            }
            catch (Exception ex)
            {
                response.Status = "Failure";
                response.Message = _localizer["ExceptionOccured"] + "!!";
                _logger.Error(ex, "Failed to UpdateReferralCode to database", msisdn);
            }
            return response;
        }

        /// <summary>
        /// Create Referral Code
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<ReferralCode>> CreateReferralCode(string msisdn, string name)
        {
            var response = new GenericApiResponse<ReferralCode>();
            if (name.Length > 9)
                name = name.Substring(0, 9);

            var storedProcedure = "tha_create_referral_codes";

            var parameters = new DynamicParameters();
            try
            {
                ReferralCode rCode = new ReferralCode();

                parameters.Add("@msisdn", msisdn);
                parameters.Add("@name", name);
                parameters.Add("@referralCode", dbType: DbType.String, direction: ParameterDirection.Output, size: 20);
                parameters.Add("@isNew", dbType: DbType.Boolean, direction: ParameterDirection.Output);
                parameters.Add("@result", dbType: DbType.String, direction: ParameterDirection.Output, size: 50);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);
                }

                var referralCode = parameters.Get<string>("@referralCode");
                var isNew = parameters.Get<bool>("@isNew");
                var result = parameters.Get<string>("@result");

                rCode.referralCode = referralCode;
                response.Payload = rCode;
                response.Message = result;

                if (isNew)
                    response.Status = "Success";
                else if (referralCode != null && referralCode.ToString(CultureInfo.InvariantCulture) != "")
                    response.Status = "Success";

            }
            catch (Exception ex)
            {
                response.Status = "Failure";
                response.Message = _localizer["ExceptionOccured"] + "!!";
                _logger.Error(ex, "Failed to CreateReferralCode ", msisdn);
            }
            return response;
        }

        /// <summary>
        /// Save Referral SMSs
        /// </summary>
        /// <param name="referredByMSISDN"></param>
        /// <param name="referredMSISDN"></param>
        /// <param name="referral_sms"></param>
        /// <returns></returns>
        public async Task<int> SaveReferralSMSs(string referredByMSISDN, string referredMSISDN, string referral_sms)
        {
            var response = new GenericApiResponse<string>();

            var storedProcedure = "tha_referral_sms_details_insert";

            var parameters = new DynamicParameters();
            try
            {
                parameters.Add("@referredByMSISDN", referredByMSISDN);
                parameters.Add("@referredMSISDN", referredMSISDN);
                parameters.Add("@referral_sms", referral_sms);
                parameters.Add("@sms_count", dbType: DbType.Int32, direction: ParameterDirection.Output, size: 32);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);
                }

                return parameters.Get<Int32>("@sms_count");

            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Failed to save SaveReferralSMSs to database", referredByMSISDN);
                return -1;
            }
        }

        /// <summary>
        /// Get user account balance from Apps database [ConnectionString: TalkHomeAppDigiTalkDb]
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<UserAccountBalance> GetUserAccountBalanceAsync(string msisdn)
        {
            try
            {
                var sipUserName = _helperService.GetSipUserName(msisdn);

                var storedProcedure = "tha_get_balance";

                var parameters = new DynamicParameters();

                parameters.Add("@sipuserName", sipUserName);

                GetBalance balance = null;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    balance = await dbConnection.QueryFirstOrDefaultAsync<GetBalance>(sql: storedProcedure, param: parameters, commandType: CommandType.StoredProcedure);
                }

                if (balance != null)
                {
                    return new UserAccountBalance
                    {
                        Balance = _helperService.FormatAccountBalance(balance.Balance, balance.Currency),
                        Currency = balance.Currency,
                        CurrencySymbol = _helperService.ToCurrencySymbol(balance.Currency)
                    };
                }
                return null;
            }

            catch (Exception ex)
            {
                _logger.Error($"Class: UserAccount_DL, Method: GetUserAccountBalance, Msisdn: {msisdn}, ErrorMessage: {ex.Message}");
            }

            return null;
        }

        /// <summary>
        /// Charge user from Apps database [ConnectionString: TalkHomeAppDigiTalkDb]
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="messageCount"></param>
        /// <returns></returns>
        public async Task<bool> ChargeUser1(string from, string to, int messageCount)
        {
            BalanceResult chargeResult = null;

            var storedProcedure = "tha_sms_charge_customer";

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                chargeResult =
                await dbConnection.QueryFirstOrDefaultAsync<BalanceResult>(
                    storedProcedure,
                    new
                    {
                        msisdn = from,
                        destination = to,
                        message_count = messageCount
                    },
                    commandType: CommandType.StoredProcedure);
            }

            if (chargeResult == null || chargeResult.audit_id == 0 || chargeResult.new_balance < 0)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Charge user from Apps database [ConnectionString: TalkHomeAppDigiTalkDb]
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="messageCount"></param>
        /// <returns></returns>
        public async Task<bool> ChargeUser(string from, string to, int messageCount)
        {
            var storedProcedure = "tha_sms_ChargeSubscriber";

            ChargeSubscriberResult chargeResult = null;

            for (var i = 0; i < messageCount; i++)
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    chargeResult =
                    await dbConnection.QueryFirstOrDefaultAsync<ChargeSubscriberResult>(
                        storedProcedure,
                        new
                        {
                            transacId = 1,
                            msisdn = from,
                            destination = to,
                            dialplanid = (int?)null,
                            interfaceType = "THASMS"
                        },
                        commandType: CommandType.StoredProcedure);
                }

                if (chargeResult == null || chargeResult.Result != 0)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Sms DbContext Save Failed
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <returns></returns>
        public async Task<bool> SmsDbContextSaveFailed(string receivedMsisdn)
        {
            try
            {

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                   "UPDATE UserJourney SET SmsDbContextSaveFailed = @smsDbContextSaveFailed WHERE ReceivedMsisdn = @receivedMsisdn", new
                   {
                       receivedMsisdn = receivedMsisdn,
                       smsDbContextSaveFailed = true,
                   });
                }


                return true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: UserAccount_DL, Method: SmsDbContextSaveFailed,  ErrorMessage:  Exception, {ex.Message}");
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Get Pin Async
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<string> GetPinAsync(string msisdn)
        {
            if (string.IsNullOrEmpty(msisdn))
            {
                return null;
            }

            try
            {
                var sipUsername = _helperService.GetSipUserName(msisdn);
                var parameters = new DynamicParameters();

                parameters.Add("@sip_user_name", sipUsername);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryFirstOrDefaultAsync<string>("tha_get_pin_v1", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Validate Device And Ip Address
        /// </summary>
        /// <param name="devicePersistentId"></param>
        /// <param name="ipAddress"></param>
        /// <returns></returns>
        public async Task<ValidationResponse> ValidateDeviceAndIpAddressAsync(string devicePersistentId, string ipAddress)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@device_persistent_id", devicePersistentId);
                parameters.Add("@ip", ipAddress);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    return await dbConnection.QueryFirstOrDefaultAsync<ValidationResponse>("tha_validate_device_ip", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: UserAccount_DL, Method: ValidateDeviceAndIpAddress, ErrorMessage: {ex.Message} ");
                return new ValidationResponse() { ValidationType = 99, ValidationMessage = "Code Exception: " + ex.Message };
            }
        }

        /// <summary>
        /// Get 2
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="IsIOS"></param>
        /// <param name="IsAndroid"></param>
        /// <param name="IOSAllowedVersion"></param>
        /// <param name="AndroidAllowedVersion"></param>
        /// <returns></returns>
        public async Task<GenericApiResponse<IEnumerable<LocalAccessNumber2>>> Get2(string msisdn, bool IsIOS, bool IsAndroid, string IOSAllowedVersion = null, string AndroidAllowedVersion = null)
        {
            var response = new GenericApiResponse<IEnumerable<LocalAccessNumber2>>();

            IEnumerable<LocalAccessNumber2> countryNumbers = Enumerable.Empty<LocalAccessNumber2>();

            countryNumbers = await GetLocalAccessNumbers2(msisdn, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);

            if (countryNumbers != null && countryNumbers.Any())
            {
                response.Status = "Success";
                response.Message = "Success";
                response.Payload = countryNumbers;
            }
            else
            {
                response.Status = "Success";
                response.Message = _localizer["NoLocalAccessNumbersAvailable"];
            }
            return response;
        }

        /// <summary>
        /// Get Local Access Numbers 2
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="IsIOS"></param>
        /// <param name="IsAndroid"></param>
        /// <param name="IOSAllowedVersion"></param>
        /// <param name="AndroidAllowedVersion"></param>
        /// <returns></returns>
        private async Task<IEnumerable<LocalAccessNumber2>> GetLocalAccessNumbers2(string msisdn, bool IsIOS, bool IsAndroid, string IOSAllowedVersion = null, string AndroidAllowedVersion = null)
        {
            try
            {
                var sipSettings = await GetSipConfigurations(msisdn, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);
                var sp = string.Empty;
                if (!sipSettings.is_somme_user)
                    sp = "tha_get_tha_local_access_numbers2";
                else
                    sp = "tha_somme_get_tha_local_access_numbers2";

                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    return await dbConnection.QueryAsync<LocalAccessNumber2>(sp, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetLocalAccessNumbers2, Parameters=>  MSISDN {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Get Sip Configurations
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="IsIOS"></param>
        /// <param name="IsAndroid"></param>
        /// <param name="IOSAllowedVersion"></param>
        /// <param name="AndroidAllowedVersion"></param>
        /// <returns></returns>
        public async Task<SipConfigurationsResponse> GetSipConfigurations(string msisdn, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null)
        {
            if (string.IsNullOrEmpty(msisdn))
            {
                return new SipConfigurationsResponse();
            }

            try
            {
                var sp = string.Empty;
                sp = "tha_get_sip_configurations_v3";

                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@IsIOS", IsIOS);
                parameters.Add("@IsAndroid", IsAndroid);
                parameters.Add("@IOSAllowedVersion", IOSAllowedVersion);
                parameters.Add("@AndroidAllowedVersion", AndroidAllowedVersion);

                SipConfigurationsResponse result = null;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    result = await dbConnection.QueryFirstOrDefaultAsync<SipConfigurationsResponse>(sp, parameters, commandType: CommandType.StoredProcedure);
                }

                result = result == null ? new SipConfigurationsResponse() : result;
                return result;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetSipConfigurations, Parameters=>  MSISDN {msisdn} , ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

                return new SipConfigurationsResponse();
            }
        }

        /// <summary>
        /// Get User Account
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="appInfo"></param>
        /// <param name="IsIOS"></param>
        /// <param name="IsAndroid"></param>
        /// <param name="IOSAllowedVersion"></param>
        /// <param name="AndroidAllowedVersion"></param>
        /// <returns></returns>
        public async Task<UserAccount> GetUserAccount(string msisdn, AppInfo appInfo, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null)
        {
            string devicePersistanceID = appInfo.DevicePersistentID;

            var sipUserName = _helperService.GetSipUserName(msisdn);

            var userAccount =
                await GetRawUserAccount(sipUserName);

            if (userAccount != null)
            {
                var accountId = userAccount.AccountID;
                userAccount.Msisdn = msisdn;

                var UserSubscriberDetails = await GetUserSubscriberDetails(accountId);

                userAccount.SubscriberId = UserSubscriberDetails.SubscriberID;
                userAccount.UserAccountBalance = UserSubscriberDetails.UserAccountBalance;
                userAccount.UserAccountDetails = UserSubscriberDetails.UseSubscriberDetails;
                userAccount.canEnterReferralCode = await CanUseReferralCodeRevised(userAccount.UserAccountDetails.Na_Service_Id, msisdn);
                userAccount.UserAccountDetails.referralCode = await GetReferralCode(msisdn);
                userAccount.A2ACallSettings = new a2aCallSettings { isTLS = true, port = "5061", url = _apiConfig.app_app_call_url };
                var sipSettings = await GetSipConfigurations(msisdn, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);
                userAccount.PaidCallSettings = new PaidCallSettings { transport = sipSettings.transport, is_somme_user = sipSettings.is_somme_user, isTLS = sipSettings.is_tls, port = sipSettings?.Port, realmIPV4 = sipSettings?.realm_ipv4, realmIPV6 = sipSettings?.realm_ipv6 };
                userAccount.scdisable = _apiConfig.payment_itunes_only_version;
                userAccount.isSIPCallLockedIPV6 = false;
                userAccount.isIPV6MsgDisplay = false;

                userAccount.multiStepFO = false;

                userAccount.stunServers = await GetStunServers();

                if (Convert.ToInt32(_apiConfig.multiStepFO_complete_enable) == 1)
                {
                    userAccount.multiStepFO = true;
                }
                else
                {
                    IList<string> enableList = _apiConfig.multiStepFO_enabled_country_codes.Split(',').ToList<string>();

                    var result = from s in enableList
                                 where msisdn.StartsWith(s)
                                 select s;

                    if (result.Count() > 0)
                    {
                        userAccount.multiStepFO = true;
                    }
                }

                userAccount.canShowApp2APP = false;

                if (Convert.ToInt32(_apiConfig.app_app_call_complete_enable) == 1)
                {
                    userAccount.canShowApp2APP = true;
                }
                else
                {
                    IList<string> enableList = _apiConfig.app_app_call_enabled_country_codes.Split(',').ToList<string>();

                    var resultEn = from s in enableList
                                   where msisdn.StartsWith(s)
                                   select s;

                    if (resultEn.Count() > 0)
                    {
                        userAccount.canShowApp2APP = true;
                    }

                }

                ForceUpdateMessage forceUpdate = new ForceUpdateMessage();
                IList<string> forceUpdateList = _apiConfig.force_update_country_codes.Split(',').ToList<string>();

                var forceUpdateEn = from s in forceUpdateList
                                    where msisdn.StartsWith(s)
                                    select s;

                if (forceUpdateEn.Count() > 0)
                {
                    forceUpdate.disabledMessage = new Message
                    {
                        el = "Κατεβάστε νεα έκδοση του Talk Home app.\n\nΠαρακαλώ πατήστε τον παρακάτω σύνδεσμο να αναβαθμιστεί και συνεχίσετε να χρησιμοποιείτε το app.",
                        en = "Download the new version of the Talk Home app.\n\nPlease tap the button below to upgrade and continue using the app.",
                        fr = "Download the new version of the Talk Home app.\n\nPlease tap the button below to upgrade and continue using the app.",
                        it = "Télécharger la nouvelle version de l'app Talk Home.\n\nS'il vous plait, cliqueer sur le lien pour mettre à jour et continuer à utiliser l'app."
                    };
                    forceUpdate.disabledVersionsAndroid = new string[] { "1.5.7", "1.5.8", "1.5.9", "1.5.10", "1.6.0", "1.6.1", "1.7.0", "1.7.1", "1.7.2" };
                    forceUpdate.disabledVersionsIos = new string[] { "1.5.7", "1.5.8", "1.5.9", "1.5.10", "1.6.0", "1.6.1", "1.7.0", "1.7.1", "1.7.2" };
                    userAccount.forceUpdateMessage = forceUpdate;
                }

                //if (appInfo!=null && (appInfo.AppVersion== "3.0.6" || appInfo.AppVersion == "3.0.7"))
                //{
                //    userAccount.isSIPCallLockedIPV6 = false;
                //    userAccount.isIPV6MsgDisplay = false;
                //}
                //else if (msisdn.StartsWith("44") ||
                //    msisdn.StartsWith("33") ||
                //    msisdn.StartsWith("31") ||
                //     msisdn.StartsWith("39"))
                //{
                //    userAccount.isSIPCallLockedIPV6 = true;
                //    userAccount.isIPV6MsgDisplay = true;
                //}


                userAccount.emailRegistration = await getEmailDefault(msisdn);
                var profileResp = await GetUserProfile(msisdn);
                userAccount.userProfile = (profileResp.Status == Status.Success ? profileResp.Data : null);

                if (!string.IsNullOrEmpty(devicePersistanceID))
                    userAccount.isReturningUser = await isReturningUser(msisdn, devicePersistanceID);
                return userAccount;
            }
            return null;
        }

        /// <summary>
        /// Get Stun Servers
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<string>> GetStunServers()
        {

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                try
                {
                    return await dbConnection.QueryAsync<string>("tha_get_stun_servers_details", commandType: CommandType.StoredProcedure);
                }
                catch (Exception ex)
                {
                    var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                    _logger.Error($"Class: UserAccount_DL, Method: GetStunServers, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                    return null;
                }
            }
        }

        /// <summary>
        /// Get Bundle Promo Guid
        /// </summary>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public async Task<string> GetBundlePromoGuid(int prefix)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@prefix", prefix);
                parameters.Add("@calling_package_id", dbType: DbType.Guid, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    var result = await dbConnection.ExecuteAsync("dbo.tha_getpromotion_bundle", parameters, commandType: CommandType.StoredProcedure);

                    if (parameters.Get<dynamic>("@calling_package_id") == null)
                    {
                        return string.Empty;
                    }

                    var calling_package_id = parameters.Get<Guid>("@calling_package_id");

                    if (calling_package_id == null)
                    {
                        return string.Empty;
                    }
                    return calling_package_id.ToString();
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetBundlePromoGuid, Parameters=>  prefix {prefix}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return string.Empty;
        }

        /// <summary>
        /// Check Bundle Promo
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public int CheckBundlePromo(string msisdn)
        {
            int prefix = 0;
            string[] bundle_promo_cuntry = _configuration["Bundle_Promotion_Pre_Fixes"].Split(',');
            foreach (string str in bundle_promo_cuntry)
            {
                if (str != "" && msisdn.StartsWith(str))
                {
                    prefix = int.Parse(str);
                    return prefix;
                }
            }
            return prefix;
        }

        /// <summary>
        /// Get Bundle Rate Promo Guid
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<string> GetBundleRatePromoGuid(string msisdn)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@msisdn", msisdn);
                parameters.Add("@calling_package_id", dbType: DbType.Guid, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.ExecuteAsync("dbo.tha_get_bundles_promotional_rates_guid", parameters, commandType: CommandType.StoredProcedure);

                    if (parameters.Get<dynamic>("@calling_package_id") == null)
                    {
                        return string.Empty;
                    }

                    var calling_package_id = parameters.Get<Guid>("@calling_package_id");

                    var compatibleBundles = await GetCompatibleBundles(msisdn);
                    int RatebundleCount = compatibleBundles?.Where(i => i.Id.ToString() == calling_package_id.ToString()).Count() ?? 0;
                    if (RatebundleCount == 0)
                    {
                        return string.Empty;
                    }
                    return calling_package_id.ToString();
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetBundleRatePromoGuid, Parameters=>  MSISDN {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

                return string.Empty;
            }
        }

        /// <summary>
        /// Add Bundle Promo via digitalk api
        /// </summary>
        /// <param name="bundleId"></param>
        /// <param name="SubscriberId"></param>
        /// <returns></returns>
        public async Task<bool> AddBundlePromo(string bundleId, int SubscriberId)
        {

            var body = JsonConvert.SerializeObject(new { PackageId = bundleId }, new JsonSerializerSettings
            {
                ContractResolver = new DefaultContractResolver()
            });

            var requestMessage = new HttpRequestMessage(HttpMethod.Post,
                $"subscribers/{SubscriberId}/subscriptions/0/bundles")
            {
                Content = new StringContent(body, System.Text.Encoding.UTF8, "application/json")
            };

            var result = await _digitalkAppsApiClient.SendAsync(requestMessage);

            if (result.IsSuccessStatusCode)

                return true;

            return false;
        }

        /// <summary>
        /// Get Bundle Pound Promo Guid
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<string> GetBundlePoundPromoGuid(string msisdn)
        {

            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@msisdn", msisdn);
                parameters.Add("@calling_package_id", dbType: DbType.Guid, direction: ParameterDirection.Output);


                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync("dbo.tha_get_bundle_pound_promo_guid", parameters, commandType: CommandType.StoredProcedure);

                    if (parameters.Get<dynamic>("@calling_package_id") == null)
                    {
                        return string.Empty;
                    }

                    var calling_package_id = parameters.Get<Guid>("@calling_package_id");

                    var compatibleBundles = await GetCompatibleBundles(msisdn);

                    int bundleCount = compatibleBundles.Where(i => i.Id.ToString() == calling_package_id.ToString()).Count();
                    if (bundleCount == 0)
                    {
                        return string.Empty;
                    }

                    return calling_package_id.ToString();
                }
            }
            catch (Exception ex)
            {

                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetBundlePoundPromoGuid, Parameters=>  MSISDN {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

                return string.Empty;
            }
        }

        /// <summary>
        /// Get Compatible Bundles via digitalk api
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Bundle>> GetCompatibleBundles(string msisdn)
        {
            var userAccount = await GetUserAccount(msisdn);

            var result = await _digitalkAppsApiClient.GetAsync($"subscribers/{userAccount.SubscriberId}/subscriptions/0/compatible-bundles");

            if (!result.IsSuccessStatusCode)
                return null;

            var bundles = JsonConvert.DeserializeObject<BundleAllowanceItems>(await result.Content.ReadAsStringAsync());

            return bundles.Items.Select(bundle => new Bundle
            {
                Id = new Guid(bundle.PackageId),
                BrandedName = bundle.BrandedName,
                Description = bundle.Description,
                //PackageType = bundle.PackageType,
                //PackageCategory = bundle.PackageCategory,
                TotalCostPence = (int)Convert.ToDecimal(bundle.InitialCharge, CultureInfo.InvariantCulture),
                ChargePeriodDays = bundle.ChargePeriodLength,
                Texts = bundle.SMSAllowance.Messages,
                Seconds = bundle.VoiceAllowance.Seconds,
                Minutes = bundle.VoiceAllowance.Seconds / 60
            });
        }

        /// <summary>
        /// Add SignUp Promo
        /// </summary>
        /// <param name="accountID"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<bool> AddSignUpPromo(string accountID, string msisdn)
        {
            try
            {
                decimal signupAmount = 100m;
                if (msisdn.StartsWith("971"))
                {
                    signupAmount = 50m;
                }
                else if (msisdn.StartsWith("90"))
                {
                    signupAmount = 500m;
                }

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync("tha_update_signup_promotions", new
                    {
                        account = accountID,
                        channel = 1,
                        amount = signupAmount,
                        bonus = 0m,
                        creditReason = "TALK HOME App - Sign Up Promo",
                        paymentMethod = "",
                        rechargeType = 45,
                        reference = "TALK HOME App - Sign Up Promo",
                        ccsTransId = 0,
                        ccAuthCode = "THASU-PRM1"
                    }, commandType: CommandType.StoredProcedure);
                }

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    await dbConnection.ExecuteAsync("AccountUpdateBalance", new
                    {
                        account = accountID,
                        channel = 1,
                        amount = signupAmount,
                        bonus = 0m,
                        creditReason = "TALK HOME App - Sign Up Promo",
                        paymentMethod = "",
                        rechargeType = 45,
                        reference = "TALK HOME App - Sign Up Promo",
                        ccsTransId = 0,
                        ccAuthCode = "THASU-PRM1"
                    }, commandType: CommandType.StoredProcedure);
                }

                return true;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: AddSignUpPromo, Parameters=>  MSISDN {msisdn} AccountID{accountID}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

                return false;
            }
        }

        /// <summary>
        /// Get Signup Promo
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<SignupPromo> GetSignupPromo(string msisdn)
        {
            SignupPromo sg = new SignupPromo();

            var storedProcedure = "tha_get_signup_promotion";

            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", msisdn);
            parameters.Add("@is_unit_Promo", dbType: DbType.Boolean, direction: ParameterDirection.Output);
            parameters.Add("@is_bundle_Promo", dbType: DbType.Boolean, direction: ParameterDirection.Output);
            parameters.Add("@amount", dbType: DbType.Decimal, direction: ParameterDirection.Output);

            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);


                    if (parameters.Get<dynamic>("@is_unit_Promo") == null)
                    {
                        sg.is_unit_Promo = false;
                    }
                    else
                    {
                        if (_configuration["Signup_Pound_Promotion"].ToString(CultureInfo.InvariantCulture) != "1")
                        {
                            sg.is_unit_Promo = false;
                        }
                        else
                        {
                            sg.is_unit_Promo = parameters.Get<Boolean>("@is_unit_Promo");
                        }
                    }

                    if (parameters.Get<dynamic>("@is_bundle_Promo") == null)
                    {
                        sg.is_bundle_Promo = false;
                    }
                    else
                    {
                        if (_configuration["Signup_Pound_Bundle_Promotion"].ToString(CultureInfo.InvariantCulture) != "1")
                        {
                            sg.is_bundle_Promo = false;
                        }
                        else
                        {
                            sg.is_bundle_Promo = parameters.Get<Boolean>("@is_bundle_Promo");
                        }
                    }

                    if (parameters.Get<dynamic>("@amount") == null)
                    {
                        sg.amount = 0;
                    }
                    else
                    {
                        sg.amount = parameters.Get<decimal>("@amount");
                    }
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetSignupPromo, Parameters=>  MSISDN {msisdn} , ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }

            return sg;
        }

        /// <summary>
        /// Account Has Promo
        /// </summary>
        /// <param name="account"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<bool> AccountHasPromo(string account, string msisdn)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", msisdn);
            parameters.Add("@account_no", account);
            parameters.Add("@count", dbType: DbType.Int32, direction: ParameterDirection.Output);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
            {
                await dbConnection.ExecuteAsync("tha_get_accountbydeviceaccount_v01", parameters, commandType: CommandType.StoredProcedure);
                var count = parameters.Get<Int32>("@count");

                if (count > 0)
                {
                    return false;
                }
                return true;
            }
        }

        /// <summary>
        /// Rates Sheet Configured
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <returns></returns>
        public async Task<bool> RatesSheetConfigured(string receivedMsisdn)
        {
            try
            {

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "UPDATE UserJourney SET RatesSheetConfigured = @ratesSheetConfigured WHERE ReceivedMsisdn = @receivedMsisdn", new
                    {
                        receivedMsisdn = receivedMsisdn,
                        ratesSheetConfigured = true,
                    });
                }


                return true;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: RatesSheetConfigured, Parameters=>  receivedMsisdn {receivedMsisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                Debug.Write(ex.ToString());

                return false;
            }
        }

        /// <summary>
        /// Configure Rate Sheet
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<bool> ConfigureRateSheet(string msisdn, string account)
        {
            try
            {
                var rateSheetId = await DetermineRateSheet(msisdn);

                if (rateSheetId != null)
                {
                    var parameters = new DynamicParameters();

                    parameters.Add("@account", account);
                    parameters.Add("@ratesheetId", rateSheetId);

                    int isConfigured = 0;

                    using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                    {
                        isConfigured = await dbConnection.ExecuteAsync("tha_update_ratesheet", parameters, commandType: CommandType.StoredProcedure);
                    }

                    var startTime = DateTime.UtcNow;

                    await GenericTimestamp(msisdn, "ConfigureRateSheet", GetTimeDifference(startTime, DateTime.UtcNow));

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: ConfigureRateSheet, Parameters=>  MSISDN {msisdn} Account{account}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

                return false;
            }
        }

        /// <summary>
        /// Determine Rate Sheet
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<int?> DetermineRateSheet(string msisdn)
        {
            //--THA44, 1
            //--THA39, 6
            //--THA33, 7
            //--THA30, 8
            //--THA31, 9
            //--THA49, 10
            //--THA43, 11
            //--THA351

            string formatedmsisdn = _helperService.FormatMsisdn(msisdn);

            var countryCode = _helperService.GetCountryCode(formatedmsisdn);

            int? rateSheetId = null;

            if (_configuration["Enable_Test_RateSheet"] == "1")
            {
                rateSheetId = int.Parse(_configuration["Test_RateSheet_Id"].ToString(CultureInfo.InvariantCulture));
                return rateSheetId;
            }

            var accountCurrency = _helperService.GetAccountCurrency(formatedmsisdn);

            rateSheetId = await GetNaServiceId(accountCurrency);

            int? newRateSheetId = await GetNaServiceIdByMSISDN(msisdn);

            if (newRateSheetId != null && newRateSheetId > 0)
            {
                rateSheetId = newRateSheetId;
            }

            int countryRateSheetId = 0;
            if (!string.IsNullOrEmpty(countryCode))
                countryRateSheetId = await GetNaServiceIdByCountryCode(countryCode);
            if (countryRateSheetId > 0)
            {
                rateSheetId = countryRateSheetId;
            }

            return rateSheetId;
        }

        /// <summary>
        /// Get NaService Id by Country Code (Two Letter ISO Code)
        /// </summary>
        /// <param name="countryCode"></param>
        /// <returns></returns>
        public async Task<int> GetNaServiceIdByCountryCode(string countryCode)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@countryCode", countryCode);
                parameters.Add("@na_service_id", dbType: DbType.Int32, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync("tha_get_na_service_id_by_countryCode", parameters, commandType: CommandType.StoredProcedure);

                    if (parameters.Get<dynamic>("@na_service_id") == null)
                    {
                        return 0;
                    }

                    var na_service_id = parameters.Get<Int32>("@na_service_id");

                    return na_service_id;
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetNaServiceIdByCountryCode, Parameters=>  MSISDN {countryCode}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

                return 0;
            }
        }

        /// <summary>
        /// Get NaService Id By MSISDN
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<int> GetNaServiceIdByMSISDN(string msisdn)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@msisdn", msisdn);
                parameters.Add("@na_service_id", dbType: DbType.Int32, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync("tha_get_na_service_id_by_msisdn", parameters, commandType: CommandType.StoredProcedure);

                    if (parameters.Get<dynamic>("@na_service_id") == null)
                    {
                        return 0;
                    }

                    var na_service_id = parameters.Get<Int32>("@na_service_id");
                    return na_service_id;
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetNaServiceIdByMSISDN, Parameters=>  MSISDN {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

                return 0;
            }
        }

        /// <summary>
        /// Get NaService Id
        /// </summary>
        /// <param name="currency"></param>
        /// <returns></returns>
        public async Task<int> GetNaServiceId(string currency)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@currency", currency);
                parameters.Add("@na_service_id", dbType: DbType.Int32, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync("tha_get_na_service_id_by_currency_v1", parameters, commandType: CommandType.StoredProcedure);
                    if (parameters.Get<dynamic>("@na_service_id") == null)
                    {
                        return 0;
                    }

                    return parameters.Get<Int32>("@na_service_id");
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetNaServiceId, Parameters=>  currency {currency}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

                return 0;
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <returns></returns>
        public async Task<bool> AppInfoHandled(string receivedMsisdn)
        {
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "UPDATE UserJourney SET AppInfoHandled = @appInfoHandled WHERE ReceivedMsisdn = @receivedMsisdn", new
                    {
                        receivedMsisdn = receivedMsisdn,
                        appInfoHandled = true,
                    });
                }


                return true;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: AppInfoHandled, Parameters=>  receivedMsisdn {receivedMsisdn} , ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Get Unallocated IM User Account
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<IMUserAccount> GetUnallocatedIMUserAccount(string msisdn, string account)
        {
            var startTime = DateTime.UtcNow;
            IMUserAccount unallocatedIMUserAccount = null;
            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
            {
                unallocatedIMUserAccount = await dbConnection.QueryFirstOrDefaultAsync<IMUserAccount>(
                        "SELECT xmppuser as IMUser, xmpppassword as IMPassword " +
                        "FROM trc_accountIM WITH (readuncommitted) " +
                        "WHERE account = @account",
                        new { account });
            }

            await GenericTimestamp(msisdn, "GetUnallocatedIMUserAccount", GetTimeDifference(startTime, DateTime.UtcNow));

            return unallocatedIMUserAccount;
        }

        /// <summary>
        /// Subscriber Updates Applied
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <returns></returns>
        public async Task<bool> SubscriberUpdatesApplied(string receivedMsisdn)
        {
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                     "UPDATE UserJourney SET SubscriberUpdatesApplied = @subscriberUpdatesApplied WHERE ReceivedMsisdn = @receivedMsisdn", new
                     {
                         receivedMsisdn = receivedMsisdn,
                         subscriberUpdatesApplied = true,
                     });
                }



                return true;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: SubscriberUpdatesApplied, Parameters=>  receivedMsisdn {receivedMsisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Count Deleted Accounts
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<int> CountDeletedAccountAsync(string msisdn)
        {
            try
            {
                var sp = "tha_deleted_account_count";
                var parameters = new DynamicParameters();
                parameters.Add("@sipuserName", $"THA{msisdn}");

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryFirstAsync<int>(sp, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: CountDeletedAccountAsync, Parameters=>  msisdn {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                Debug.Write(ex.ToString());
                return 0;
            }
        }

        /// <summary>
        /// Soft Delete Account
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="account"></param>
        /// <param name="merchantRef"></param>
        /// <param name="paypalMerchantRef"></param>
        /// <returns></returns>
        public async Task<bool> SoftDeleteAccountAsync(string msisdn, string account, string merchantRef, string paypalMerchantRef)
        {
            try
            {
                var sp = "tha_delete_account";
                var parameters = new DynamicParameters();
                parameters.Add("@sipuserName", "THA" + msisdn);
                parameters.Add("@msisdn", msisdn);

                var result1 = await new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb).QueryFirstAsync(sp, parameters, commandType: CommandType.StoredProcedure);
                sp = "tha_delete_account";
                parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                var result2 = await new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb).QueryFirstAsync(sp, parameters, commandType: CommandType.StoredProcedure);

                sp = "tha_delete_account";
                parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                var result3 = await new SqlConnection(_dbConnections.TalkHomeAppDb).QueryFirstAsync(sp, parameters, commandType: CommandType.StoredProcedure);

                sp = "Pay360_Api_DeleteAccount";
                parameters = new DynamicParameters();
                parameters.Add("@merchantRef", merchantRef);
                parameters.Add("@paypalMerchantRef", paypalMerchantRef);
                parameters.Add("@productCode", "THA");

                var result4 = await new SqlConnection(_dbConnections.CentralisedPaymentConnection).QueryFirstAsync(sp, parameters, commandType: CommandType.StoredProcedure);

                //Await all results to make things happen paralell
                //await Task.WhenAll(result1, result2, result3, result4);

                //Check results for all operations
                var result = result1 != null && result1.errorCode == 0
                          && result2 != null && result2.errorCode == 0
                          && result3 != null && result3.errorCode == 0
                          && result4 != null && result4.errorCode == 0;
                if (result)
                {
                    //Update delete logs into database
                    var existingUserDeletedAccountRequest = await GetDeleteAccountLogRequest(msisdn);
                    if (existingUserDeletedAccountRequest == null || existingUserDeletedAccountRequest?.AccountDeleteRequestDate == null)//this condition is added to handle insert the delete account record after account delete request
                    {
                        await InsertDeleteAccountLogs(account, msisdn, "Account deleted successfully!");
                    }
                    else
                    {
                        await SetAccountDeletedStatus(msisdn, account, "Account deleted successfully!");
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: SoftDeleteAccountAsync, Parameters=>  msisdn {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Insert Delete Account Logs
        /// </summary>
        /// <param name="account"></param>
        /// <param name="msisdn"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task InsertDeleteAccountLogs(string account, string msisdn, string message)
        {
            try
            {
                var sp = "tha_insert_delete_account_logs";
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@account", account);
                parameters.Add("@message", message);

                parameters.Add("@accountDeleteStatus", AccountDeleteStatus.Deleted);
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync(sp, parameters, commandType: CommandType.StoredProcedure);
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: InsertDeleteAccountLogs, Parameters=>  msisdn {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
        }

        /// <summary>
        /// Unallocated Account Obtained
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <returns></returns>
        public async Task<bool> UnallocatedAccountObtained(string receivedMsisdn)
        {
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "UPDATE UserJourney SET UnallocatedAccountObtained = @unallocatedAccountObtained WHERE ReceivedMsisdn = @receivedMsisdn", new
                    {
                        receivedMsisdn = receivedMsisdn,
                        unallocatedAccountObtained = true,
                    });
                }



                return true;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: UnallocatedAccountObtained, Parameters=>  receivedMsisdn {receivedMsisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                Debug.Write(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Get Unallocated Account
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="accountCurrency"></param>
        /// <returns></returns>
        public async Task<string> GetUnallocatedAccount(string msisdn, string accountCurrency)
        {
            var startTime = DateTime.UtcNow;

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
            {
                var result =
                await dbConnection.QueryFirstAsync<string>(
                    "set xact_abort on " +
                    "set transaction isolation level read committed " +

                    "begin transaction " +

                    "declare @account [char](20) " +

                    "IF EXISTS (SELECT * FROM trc_pans WHERE comments = @msisdn) " +

                    "BEGIN " +
                    "SELECT @account = account FROM trc_pans WHERE comments = @msisdn " +
                    "END " +
                    "ELSE " +
                    "BEGIN " +
                    "SELECT TOP 1 @account = account " +
                    "FROM trc_pans WITH (UPDLOCK, READPAST) " +
                    "WHERE isaccount = 1 AND sold = 0 AND allocated = 'WEB' AND currency = @accountCurrency " +
                    "ORDER BY serial " +

                    "UPDATE trc_pans " +
                    "SET sold = 1, sold_date = getdate(), comments = @msisdn " +
                    "WHERE account = @account " +
                    "END " +

                    "SELECT @account " +

                    "commit",
                    new { accountCurrency, msisdn });

                return result.Trim();
            }
            //await userJourneyService.GenericTimestamp(msisdn, "GetUnallocatedAccount", GetTimeDifference(startTime, DateTime.UtcNow));
        }

        /// <summary>
        /// Get Temporary Account
        /// </summary>
        /// <param name="userInf"></param>
        /// <param name="accountCurrency"></param>
        /// <param name="remoteIp"></param>
        /// <returns></returns>
        public async Task<string> GetTemporaryAccount(UserInf userInf, string accountCurrency, string remoteIp)
        {
            string msisdn = userInf.Msisdn;
            string cpuArchitecture = userInf.deviceInf.cpuArchitecture;
            string ActionExecuted = userInf.deviceInf.ActionExecuted;
            string DeviceOS = userInf.deviceInf.DeviceOS;
            string DeviceOSVersion = userInf.deviceInf.DeviceOSVersion;
            string DeviceMake = userInf.deviceInf.DeviceMake;
            string DeviceModel = userInf.deviceInf.DeviceModel;
            string DeviceLanguage = userInf.deviceInf.DeviceLanguage;
            string DevicePersistentID = userInf.deviceInf.DevicePersistentID;
            string AppVersion = userInf.appInf.AppVersion;
            string AppLanguage = userInf.appInf.AppLanguage;
            string AuthTx = userInf.AuthTx;
            int signupVer = userInf.signupVer;
            string ProductCode = userInf.appInf.ProductCode;
            string ProductItemCode = userInf.appInf.ProductItemCode;
            bool isLegacySignup = false;
            bool isTrusted = userInf.deviceInf.isTrusted;
            bool IsAndroid = userInf.deviceInf.IsAndroid;

            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@msisdn", msisdn);
                parameters.Add("@ActionExecuted", ActionExecuted);
                parameters.Add("@DeviceOS", DeviceOS);
                parameters.Add("@DeviceOSVersion", DeviceOSVersion);
                parameters.Add("@DeviceMake", DeviceMake);
                parameters.Add("@DeviceModel", DeviceModel);
                parameters.Add("@DeviceLanguage", DeviceLanguage);
                parameters.Add("@DevicePersistentID", DevicePersistentID);
                parameters.Add("@AppVersion", AppVersion);
                parameters.Add("@AppLanguage", AppLanguage);
                parameters.Add("@deviceIsTrusted", isTrusted);
                parameters.Add("@deviceUserAgent", "");
                parameters.Add("@deviceIPAddress", remoteIp);
                parameters.Add("@cpuArchitecture", cpuArchitecture);
                parameters.Add("@IsTrusted", isTrusted);
                parameters.Add("@productCode", ProductCode);
                parameters.Add("@productItemCode", ProductItemCode);
                parameters.Add("@AuthTx", AuthTx);
                parameters.Add("@isLegacySignup", isLegacySignup);
                parameters.Add("@signupVer", signupVer);
                parameters.Add("@accountCurrency", accountCurrency);
                parameters.Add("@pin", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 20);
                parameters.Add("@error_code", null, DbType.Int32, ParameterDirection.Output);
                parameters.Add("@error_msg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
                /*
                 * 
                 * @pin varchar(20) output,
                 * @error_code int output,
                 * @error_msg varchar(100) output
                 * 
                 */
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    await dbConnection.ExecuteAsync("tha_create_register_request", parameters, commandType: CommandType.StoredProcedure);
                }

                string pin = parameters.Get<string>("@pin");
                int error_code = parameters.Get<int>("@error_code");
                string error_msg = parameters.Get<string>("@error_msg");

                return pin;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetTemporaryAccount, Parameters=>  MSISDN {msisdn} , ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }

        }

        /// <summary>
        /// Save Sms
        /// </summary>
        /// <param name="sms"></param>
        /// <returns></returns>
        public async Task<int> SaveSms(Sms sms)
        {

            var storedProcedure = "tha_save_sms";
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Provider", (int)sms.Provider);
                parameters.Add("@Sender", sms.Sender);
                parameters.Add("@To", sms.To);
                parameters.Add("@Status", sms.Status);
                parameters.Add("@Sent", sms.Sent);
                parameters.Add("@ProviderId", sms.ProviderId);
                parameters.Add("@ProviderError", sms.ProviderError);

                int result = 0;
                using (var dbConnection = new SqlConnection(_dbConnections.SmsServiceDb))
                {
                    result = await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }

                if (result < 1)
                {
                    _logger.Error($"Class: UserAccount_DL, Method: SaveSms, Request: {JsonConvert.SerializeObject(sms)}, ErrorMessage: Error in saving sms status in database.");
                }
                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: SaveSms, Parameters=> requestJson: Sms{JsonConvert.SerializeObject(sms)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return 0;
            }

        }

        /// <summary>
        /// Get SMS Operator
        /// </summary>
        /// <param name="na_service_id"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<int> GetSMSOperator(int na_service_id, string msisdn)
        {

            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@na_service_id", na_service_id);
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@operatorId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.ExecuteAsync("tha_get_signup_sms_configurations", parameters, commandType: CommandType.StoredProcedure);
                    if (parameters.Get<dynamic>("@operatorId") == null)
                    {
                        return 0;
                    }

                    return parameters.Get<Int32>("@operatorId");
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetSMSOperator, Parameters=>  MSISDN {msisdn} na_service_id{na_service_id}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return 0;
            }
        }

        /// <summary>
        /// Get SMS Count
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="remoteIp"></param>
        /// <returns></returns>
        public async Task<int> GetSMSCount(string msisdn, string remoteIp)
        {

            var storedProcedure = "tha_sms_get_sms_count_v1";
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@ip", remoteIp);
                parameters.Add("@count", dbType: DbType.Int32, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.SmsServiceDb))
                {
                    await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    return parameters.Get<int>("@count");
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetSMSCount, Parameters=>  MSISDN {msisdn} , ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return 10;
            }

        }

        /// <summary>
        /// Update SignUp Account
        /// </summary>
        /// <param name="userAccount"></param>
        /// <returns></returns>
        public async Task UpdateSignUpAccount(UserAccount userAccount)
        {

            var startTime = DateTime.UtcNow;

            try
            {
                if (userAccount != null)
                {
                    var parameters = new DynamicParameters();
                    var sipUsername = _helperService.GetSipUserName(userAccount.Msisdn);
                    var storedProcedure = "tha_update_signup_v2";
                    parameters.Add("@account", userAccount.AccountID);
                    parameters.Add("@serial", userAccount.Serial);
                    parameters.Add("@cli", userAccount.Msisdn);
                    parameters.Add("@sipUser", sipUsername);

                    using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                    {
                        await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                    }
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: UpdateSignUpAccount, Parameters=> requestJson: UserAccount{JsonConvert.SerializeObject(userAccount)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

            }

            await GenericTimestamp(userAccount.Msisdn, "UpdateSignUpAccount", GetTimeDifference(startTime, DateTime.UtcNow));
        }

        /// <summary>
        /// Update SignUp Account 2
        /// </summary>
        /// <param name="userAccount"></param>
        /// <returns></returns>
        public async Task UpdateSignUpAccount2(UserAccount userAccount)
        {

            var startTime = DateTime.UtcNow;

            try
            {
                if (userAccount != null)
                {
                    var parameters = new DynamicParameters();
                    var sipUsername = _helperService.GetSipUserName(userAccount.Msisdn);
                    var storedProcedure = "tha_update_signup_v2";
                    parameters.Add("@account", userAccount.AccountID);
                    parameters.Add("@serial", userAccount.Serial);
                    parameters.Add("@cli", userAccount.Msisdn);
                    parameters.Add("@sipUser", sipUsername);

                    using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                    {
                        await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                    }
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: UpdateSignUpAccount, Parameters=> requestJson: UserAccount{JsonConvert.SerializeObject(userAccount)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

            }

            await GenericTimestamp(userAccount.Msisdn, "UpdateSignUpAccount", GetTimeDifference(startTime, DateTime.UtcNow));
        }

        /// <summary>
        /// Get Time Difference
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <returns></returns>
        private string GetTimeDifference(DateTime startTime, DateTime endTime)
        {
            var duration = endTime.Subtract(startTime);
            return duration.Milliseconds.ToString(CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Generic Time stamp
        /// </summary>
        /// <param name="receivedMsisdn"></param>
        /// <param name="fieldName"></param>
        /// <param name="milliseconds"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<bool> GenericTimestamp(string receivedMsisdn, string fieldName, string milliseconds)
        {
            try
            {
                var sql = $"UPDATE UserJourney SET {fieldName} = '{milliseconds}' WHERE ReceivedMsisdn = '{receivedMsisdn}'";

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    var updateUserJourney = await dbConnection.ExecuteAsync(sql);
                    return true;
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GenericTimestamp, Parameters=>  receivedMsisdn {receivedMsisdn} fieldName {fieldName} milliseconds {milliseconds}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return false;
            }
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get User Account Result
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<UserAccount> GetUserAccountResult(string msisdn, string account)
        {
            var startTime = DateTime.UtcNow;



            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@account", account);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryFirstOrDefaultAsync<UserAccount>("tha_get_user_account_results", parameters, commandType: CommandType.StoredProcedure);
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetUserAccountResult, Parameters=>  MSISDN {msisdn} account{account}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }

        /// <summary>
        ///  Validate User
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="ipAddress"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public async Task<string> ValidateAsyncUser(string msisdn, string ipAddress, int type)
        {
            if (string.IsNullOrEmpty(msisdn))
            {
                return null;
            }

            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                if (_hostingEnv.EnvironmentName.Equals("Production"))
                {
                    parameters.Add("@ip", ipAddress);
                    parameters.Add("@type", type);
                }

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    return await dbConnection.QueryFirstOrDefaultAsync<string>(_hostingEnv.EnvironmentName == "Production" ? "tha_validate_blocked_user_v2" : "tha_validate_blocked_user", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: ValidateAsyncUser, Parameters=>  MSISDN {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Get Account Info Via SQL
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<AccountInfo> GetAccountCurrencyAndPin(string msisdn)
        {
            if (string.IsNullOrEmpty(msisdn))
            {
                return null;
            }

            if (msisdn.StartsWith("00"))
            {
                msisdn = msisdn.Substring(2);
            }

            var sipusername = $"THA{msisdn}";

            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@sip_user_name", sipusername);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryFirstOrDefaultAsync<AccountInfo>("tha_get_pin_v4", parameters, commandType: CommandType.StoredProcedure);
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetAccountInfoViaSQL, Parameters=> msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }

        }

        /// <summary>
        /// IsUserBlockedAsync
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<bool> IsUserBlockedAsync(string msisdn)
        {
            if (string.IsNullOrWhiteSpace(msisdn))
            {
                return false;
            }

            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.QueryFirstOrDefaultAsync<string>("tha_validate_blocked_user", parameters, commandType: CommandType.StoredProcedure);
                    return string.IsNullOrEmpty(result) ? false : true;
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: ValidateUser, Parameters=> msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return false;
            }
        }

        /// <summary>
        /// Validate Nowtel Token
        /// </summary>
        /// <param name="nowtelToken"></param>
        /// <returns></returns>
        public async Task<bool> ValidateNowtelTokenAsync(string nowtelToken)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@NowtelAuth", nowtelToken);
                parameters.Add("@isValid", null, DbType.Boolean, ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync("tha_validate_token", parameters, commandType: CommandType.StoredProcedure);
                    return parameters.Get<bool>("@isValid");
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: ValidateNowtelToken, Parameters=> nowtelToken: {nowtelToken}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return false;
            }
        }

        /// <summary>
        /// Get User Account Info
        /// </summary>
        /// <param name="sipUserName"></param>
        /// <returns></returns>
        public async Task<UserAccountInformation> GetUserAccountInfo(string sipUserName)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@sipuserName", sipUserName);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    var result = await dbConnection.QueryAsync<UserAccountInformation>("tha_get_account_info_v1", parameters, commandType: CommandType.StoredProcedure);
                    return result?.FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetUserAccountInfo, Parameters=> sipUserName: {sipUserName}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Get User Account
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<UserAccount> GetUserAccount(string msisdn)
        {
            //var cacheQuery = cache.WithSource(this);

            //using (DogStatsd.StartTimer("WebServices.GetUserAccount"))
            //{
            var sipUserName = _helperService.GetSipUserName(msisdn);

            var userAccount = await GetRawUserAccount(sipUserName);

            //var userAccount =
            //    await cacheQuery.Method(i => i.GetRawUserAccount(sipUserName))
            //                    .ExpireAfter(TimeSpan.FromMinutes(2))
            //                    .InvalidateIf(i => i.Value?.AccountID != null)
            //                    .GetValueAsync();

            if (userAccount != null)
            {
                var accountId = userAccount.AccountID;
                userAccount.Msisdn = msisdn;

                //var UserSubscriberDetails = await cacheQuery.Method(i => i.GetUserSubscriberDetails(accountId))
                //                    .ExpireAfter(TimeSpan.FromMinutes(2))
                //                    .GetValueAsync();

                var UserSubscriberDetails = await GetUserSubscriberDetails(accountId);

                userAccount.SubscriberId = UserSubscriberDetails.SubscriberID;
                userAccount.UserAccountBalance = UserSubscriberDetails.UserAccountBalance;
                userAccount.UserAccountDetails = UserSubscriberDetails.UseSubscriberDetails;
                userAccount.canEnterReferralCode = await CanUseReferralCodeRevised(userAccount.UserAccountDetails.Na_Service_Id, msisdn);
                userAccount.UserAccountDetails.referralCode = await GetReferralCode(msisdn);

                return userAccount;
            }

            return null;
            //}
        }

        /// <summary>
        /// Get User Account
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="appInfo"></param>
        /// <returns></returns>
        public async Task<UserAccount> GetUserAccount(string msisdn, AppInfo appInfo)
        {

            string devicePersistanceID = appInfo.DevicePersistentID;

            //using (DogStatsd.StartTimer("WebServices.GetUserAccount"))
            //{
            var sipUserName = _helperService.GetSipUserName(msisdn);

            var userAccount =
                await GetRawUserAccount(sipUserName);

            if (userAccount != null)
            {
                var accountId = userAccount.AccountID;
                userAccount.Msisdn = msisdn;

                var UserSubscriberDetails = await GetUserSubscriberDetails(accountId);

                userAccount.SubscriberId = UserSubscriberDetails.SubscriberID;
                userAccount.UserAccountBalance = UserSubscriberDetails.UserAccountBalance;
                userAccount.UserAccountDetails = UserSubscriberDetails.UseSubscriberDetails;
                userAccount.canEnterReferralCode = await CanUseReferralCodeRevised(userAccount.UserAccountDetails.Na_Service_Id, msisdn);
                userAccount.UserAccountDetails.referralCode = await GetReferralCode(msisdn);
                userAccount.A2ACallSettings = new a2aCallSettings { isTLS = true, port = "5061", url = _apiConfig.app_app_call_url };
                userAccount.scdisable = _apiConfig.payment_itunes_only_version;
                userAccount.isSIPCallLockedIPV6 = false;
                userAccount.isIPV6MsgDisplay = false;

                userAccount.multiStepFO = false;

                if (_apiConfig.multiStepFO_complete_enable == 1)
                {
                    userAccount.multiStepFO = true;
                }
                else
                {

                    IList<string> enableList = _apiConfig.multiStepFO_enabled_country_codes.Split(',').ToList<string>();

                    var result = from s in enableList
                                 where msisdn.StartsWith(s)
                                 select s;

                    if (result.Count() > 0)
                    {
                        userAccount.multiStepFO = true;
                    }

                }

                userAccount.canShowApp2APP = false;

                if (_apiConfig.app_app_call_complete_enable == 1)
                {
                    userAccount.canShowApp2APP = true;
                }
                else
                {
                    IList<string> enableList = _apiConfig.app_app_call_enabled_country_codes.Split(',').ToList<string>();

                    var resultEn = from s in enableList
                                   where msisdn.StartsWith(s)
                                   select s;

                    if (resultEn.Count() > 0)
                    {
                        userAccount.canShowApp2APP = true;
                    }

                }

                ForceUpdateMessage forceUpdate = new ForceUpdateMessage();
                IList<string> forceUpdateList = _apiConfig.force_update_country_codes.Split(',').ToList<string>();

                var forceUpdateEn = from s in forceUpdateList
                                    where msisdn.StartsWith(s)
                                    select s;

                if (forceUpdateEn.Count() > 0)
                {
                    forceUpdate.disabledMessage = new Message
                    {
                        el = "Κατεβάστε νεα έκδοση του Talk Home app.\n\nΠαρακαλώ πατήστε τον παρακάτω σύνδεσμο να αναβαθμιστεί και συνεχίσετε να χρησιμοποιείτε το app.",
                        en = "Download the new version of the Talk Home app.\n\nPlease tap the button below to upgrade and continue using the app.",
                        fr = "Download the new version of the Talk Home app.\n\nPlease tap the button below to upgrade and continue using the app.",
                        it = "Télécharger la nouvelle version de l'app Talk Home.\n\nS'il vous plait, cliqueer sur le lien pour mettre à jour et continuer à utiliser l'app."
                    };
                    forceUpdate.disabledVersionsAndroid = new string[] { "1.5.7", "1.5.8", "1.5.9", "1.5.10", "1.6.0", "1.6.1", "1.7.0", "1.7.1", "1.7.2" };
                    forceUpdate.disabledVersionsIos = new string[] { "1.5.7", "1.5.8", "1.5.9", "1.5.10", "1.6.0", "1.6.1", "1.7.0", "1.7.1", "1.7.2" };
                    userAccount.forceUpdateMessage = forceUpdate;
                }

                //if (appInfo!=null && (appInfo.AppVersion== "3.0.6" || appInfo.AppVersion == "3.0.7"))
                //{
                //    userAccount.isSIPCallLockedIPV6 = false;
                //    userAccount.isIPV6MsgDisplay = false;
                //}
                //else if (msisdn.StartsWith("44") ||
                //    msisdn.StartsWith("33") ||
                //    msisdn.StartsWith("31") ||
                //     msisdn.StartsWith("39"))
                //{
                //    userAccount.isSIPCallLockedIPV6 = true;
                //    userAccount.isIPV6MsgDisplay = true;
                //}


                userAccount.emailRegistration = await getEmailDefault(msisdn);
                if (!string.IsNullOrEmpty(devicePersistanceID))
                    userAccount.isReturningUser = await isReturningUser(msisdn, devicePersistanceID);
                return userAccount;
            }

            return null;
            //}
        }

        /// <summary>
        /// Handle App Info
        /// </summary>
        /// <param name="userAccount"></param>
        /// <param name="info"></param>
        /// <param name="remoteIp"></param>
        /// <param name="accountCurrency"></param>
        /// <returns></returns>
        public async Task HandleAppInfo(UserAccount userAccount, AppInfo info, string remoteIp, string accountCurrency)
        {
            string msisdn = userAccount.Msisdn;
            string cpuArchitecture = info.cpuArchitecture;
            string ActionExecuted = info.ActionExecuted;
            string DeviceOS = info.DeviceOS;
            string DeviceOSVersion = info.DeviceOSVersion;
            string DeviceMake = info.DeviceMake;
            string DeviceModel = info.DeviceModel;
            string DeviceLanguage = info.DeviceLanguage;
            string DevicePersistentID = info.DevicePersistentID;
            string AppVersion = info.AppVersion;
            string AppLanguage = info.AppLanguage;
            string AuthTx = "";
            int signupVer = 0;
            string ProductCode = "THA";
            string ProductItemCode = "THAAPP";
            bool isLegacySignup = false;
            bool isTrusted = false;
            bool IsAndroid = false;

            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@msisdn", msisdn);
                parameters.Add("@ActionExecuted", ActionExecuted);
                parameters.Add("@DeviceOS", DeviceOS);
                parameters.Add("@DeviceOSVersion", DeviceOSVersion);
                parameters.Add("@DeviceMake", DeviceMake);
                parameters.Add("@DeviceModel", DeviceModel);
                parameters.Add("@DeviceLanguage", DeviceLanguage);
                parameters.Add("@DevicePersistentID", DevicePersistentID);
                parameters.Add("@AppVersion", AppVersion);
                parameters.Add("@AppLanguage", AppLanguage);
                parameters.Add("@deviceIsTrusted", isTrusted);
                parameters.Add("@deviceUserAgent", "");
                parameters.Add("@deviceIPAddress", remoteIp);
                parameters.Add("@cpuArchitecture", cpuArchitecture);
                parameters.Add("@IsTrusted", isTrusted);
                parameters.Add("@productCode", ProductCode);
                parameters.Add("@productItemCode", ProductItemCode);
                parameters.Add("@AuthTx", AuthTx);
                parameters.Add("@isLegacySignup", isLegacySignup);
                parameters.Add("@signupVer", signupVer);
                parameters.Add("@accountCurrency", accountCurrency);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    await dbConnection.ExecuteAsync("tha_create_signin_request", parameters, commandType: CommandType.StoredProcedure);
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: HandleAppInfo, Parameters=>  MSISDN {msisdn} , ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

            }

            //await userJourneyService.GenericTimestamp(userAccount.Msisdn, "HandleAppInfo", GetTimeDifference(startTime, DateTime.UtcNow));
        }

        /// <summary>
        /// Handle App Info
        /// </summary>
        /// <param name="userAccount"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task HandleAppInfo(UserAccount userAccount, AppInfo info)
        {
            var startTime = DateTime.UtcNow;

            try
            {
                if (info == null)
                {
                    return;
                }

                if (userAccount == null)
                {
                    return;
                }


                if (userAccount?.UserAccountBalance == null)
                {
                    return;
                }

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(
                    "INSERT INTO tha_LogonInfo " +
                    "(Account, AccountType, CLI, ActionExecuted, DeviceOS, DeviceOSVersion, DeviceMake, DeviceModel, " +
                    "DeviceLanguage, DevicePersistentID, AppVersion, AppLanguage, DeviceIPAddress, DeviceUserAgent, DeviceIsTrusted, cpuArchitecture) " +
                    "values (@account, @accountType, @cli, @actionExecuted, @deviceOS, @deviceOSVersion, @deviceMake, @deviceModel, " +
                    "@deviceLanguage, @devicePersistentID, @appVersion, @appLanguage, @deviceIPAddress, @deviceUserAgent," +
                    "@deviceIsTrusted,@cpuArchitecture)",
                    new
                    {
                        account = userAccount.AccountID,
                        accountType = userAccount.UserAccountBalance.Currency,
                        cli = userAccount.Msisdn,
                        actionExecuted = info.ActionExecuted,
                        deviceOS = info.DeviceOS,
                        deviceOSVersion = info.DeviceOSVersion,
                        deviceMake = info.DeviceMake,
                        deviceModel = info.DeviceModel,
                        deviceLanguage = info.DeviceLanguage,
                        devicePersistentID = info.DevicePersistentID,
                        appVersion = info.AppVersion,
                        appLanguage = info.AppLanguage,
                        deviceIPAddress = (string)null,
                        deviceUserAgent = (string)null,
                        deviceIsTrusted = (string)null,
                        cpuArchitecture = info.cpuArchitecture
                    });
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: HandleAppInfo, Parameters=> AppInfo: {JsonConvert.SerializeObject(info)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }

            //await userJourneyService.GenericTimestamp(userAccount.Msisdn, "HandleAppInfo", GetTimeDifference(startTime, DateTime.UtcNow));
        }

        /// <summary>
        /// Save Call Quality
        /// </summary>
        /// <param name="request"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<bool> SaveCallQuality(CallQualityRequest request, string msisdn)
        {
            try
            {
                var storedProcedure = "Tha_save_call_quality";

                var parameters = new DynamicParameters();
                parameters.Add("@call_id", request.call_id);
                parameters.Add("@is_somme_user", request.is_somme_user);
                parameters.Add("@mos", request.mos);
                parameters.Add("@user_call_rating", request.user_call_rating);
                parameters.Add("@from_msisdn", msisdn);
                parameters.Add("@avg_jitter", request.avg_jitter);
                parameters.Add("@avg_lat", request.avg_lat);
                parameters.Add("@pkt_loss", request.pkt_loss);
                parameters.Add("@rFactor", request.rFactor);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryFirstOrDefaultAsync<bool>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: CreditControl_DL, Method: SaveCallQuality, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return false;
            }

        }

        //public async Task<SaveClientCallDbResponse> SaveClientCallLogs(SaveClientCallRequest request, string msisdn)
        //{
        //    try
        //    {

        //        var dt = new DataTable();
        //        dt.Columns.Add("log_date", typeof(DateTime));
        //        dt.Columns.Add("key");
        //        dt.Columns.Add("value");
        //        if (request.Logs.Count() > 0)
        //            foreach (var item in request.Logs)
        //            {

        //                var itemLog = item.Split(":::");
        //                DateTime? date = null;
        //                string key = "";
        //                string value = "";

        //                if (itemLog.Length == 1)
        //                {
        //                    key = itemLog[0];
        //                }
        //                else if (itemLog.Length == 2)
        //                {
        //                    key = itemLog[0];
        //                    value = itemLog[1];
        //                }
        //                else if (itemLog.Length == 3)
        //                {
        //                    try
        //                    {
        //                        date = Convert.ToDateTime(itemLog[0]);
        //                    }
        //                    catch (Exception ex)
        //                    {
        //                        Logger.Error($"Class: CreditControl_DL, Method: SaveClientCallLogs_Datetime Conversion, item {itemLog[0]}, ErrorMessage: " + ex.Message + ", StackTrace: " + ex.StackTrace);
        //                    }
        //                    key = itemLog[1];
        //                    value = itemLog[2];
        //                }
        //                DataRow dr = dt.NewRow();
        //                if (date == null)
        //                {
        //                    dr["log_date"] = DBNull.Value;
        //                }
        //                else
        //                {
        //                    dr["log_date"] = date;
        //                }

        //                dr["key"] = key;
        //                dr["value"] = value;
        //                dt.Rows.Add(dr);
        //            }


        //        var storedProcedure = "THA_Save_Client_Call_Logs_v1";

        //        var parameters = new DynamicParameters();
        //        parameters.Add("@fromNumber", msisdn);
        //        parameters.Add("@callDurationSeconds", request.callDurationSeconds);
        //        parameters.Add("@callId", request.callId);
        //        parameters.Add("@callSuccess", request.callSuccess);
        //        parameters.Add("@registration", request.registration);
        //        parameters.Add("@networkType", request.networkType);
        //        parameters.Add("@publicIP", request.publicIP);
        //        parameters.Add("@mos", request.mos);
        //        parameters.Add("@stackTrace", request.stackTrace);
        //        parameters.Add("@deviceType", request.deviceType);
        //        parameters.Add("@appVersion", request.appVersion);
        //        parameters.Add("@hangUpReason", request.hangUpReason);
        //        parameters.Add("@ClientCallLogType", dt.AsTableValuedParameter("dbo.ClientCallLogType"));
        //        var result = await THAClientLogsDb.SqlConnection.QueryFirstOrDefaultAsync<SaveClientCallDbResponse>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
        //        Logger.Error($"Class: CreditControl_DL, Method: SaveClientCallLogs, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
        //        return new SaveClientCallDbResponse() { ErrorCode = (int)ApiStatusCodes.CodeException, ErrorMessage = ex.Message, isAdded = false };
        //    }
        //}

        /// <summary>
        /// Save Client Call Logs
        /// </summary>
        /// <param name="request"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<SaveClientCallDbResponse> SaveClientCallLogs(SaveClientCallRequest request, string msisdn)
        {
            try
            {
                var dt = new DataTable();
                dt.Columns.Add("log_date", typeof(DateTime));
                dt.Columns.Add("key");
                dt.Columns.Add("value");
                if (request.Logs.Count() > 0 && !request.callSuccess)
                {
                    foreach (var item in request.Logs)
                    {

                        var itemLog = item.Split(":::");
                        DateTime? date = null;
                        string key = "";
                        string value = "";

                        if (itemLog.Length == 1)
                        {
                            key = itemLog[0];
                        }
                        else if (itemLog.Length == 2)
                        {
                            key = itemLog[0];
                            value = itemLog[1];
                        }
                        else if (itemLog.Length == 3)
                        {
                            try
                            {
                                date = Convert.ToDateTime(itemLog[0]);
                            }
                            catch (Exception ex)
                            {
                                //_logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: SaveClientCallLogs, Class: UserAccount_DL, Parameters: Msisdn {msisdn}, Request {JsonConvert.SerializeObject(request)}");
                            }
                            key = itemLog[1];
                            value = itemLog[2];
                        }
                        DataRow dr = dt.NewRow();
                        if (date == null)
                        {
                            dr["log_date"] = DBNull.Value;
                        }
                        else
                        {
                            dr["log_date"] = date;
                        }

                        dr["key"] = key;
                        dr["value"] = value;
                        dt.Rows.Add(dr);
                    }
                }

                //var storedProcedure = "THA_Save_Client_Call_Logs_v1";
                var storedProcedure = "THA_Save_Client_Call_Logs_dynamic";

                var parameters = new DynamicParameters();
                parameters.Add("@fromNumber", msisdn);
                parameters.Add("@callDurationSeconds", request.callDurationSeconds);
                parameters.Add("@callId", request.callId);
                parameters.Add("@callSuccess", request.callSuccess);
                parameters.Add("@registration", request.registration);
                parameters.Add("@networkType", request.networkType);
                parameters.Add("@publicIP", request.publicIP);
                parameters.Add("@mos", request.mos);
                parameters.Add("@stackTrace", request.stackTrace);
                parameters.Add("@deviceType", request.deviceType);
                parameters.Add("@deviceModel", request.deviceModel);
                parameters.Add("@DeviceOS", request.DeviceOS);
                parameters.Add("@appVersion", request.appVersion);
                parameters.Add("@cpuArchitecture", request.cpuArchitecture);
                parameters.Add("@hangUpReason", request.hangUpReason);
                parameters.Add("@ClientCallLogType", dt.AsTableValuedParameter("dbo.ClientCallLogType"));

                using (var dbConnection = new SqlConnection(_dbConnections.THAClientLogsDb))
                {
                    var result = await dbConnection.QueryFirstOrDefaultAsync<SaveClientCallDbResponse>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    return result;
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                //_logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: SaveClientCallLogs, Class: UserAccount_DL, Parameters: Msisdn {msisdn}, Request {JsonConvert.SerializeObject(request)}");
                return new SaveClientCallDbResponse() { ErrorCode = (int)ApiStatusCodes.CodeException, ErrorMessage = ex.Message, isAdded = false };
            }
        }

        /// <summary>
        /// Get Andriod Payment Options
        /// </summary>
        /// <param name="currency"></param>
        /// <returns></returns>
        public async Task<IEnumerable<InAPPAndroidPaymentSettings>> getAndriodPaymentOptions(string currency)
        {
            try
            {
                var storedProcedure = "[tha_get_inapp_android_payment_settings]";

                var parameters = new DynamicParameters();
                parameters.Add("@currency", currency);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryAsync<InAPPAndroidPaymentSettings>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: CreditControl_DL, Method: getAndriodPaymentOptions, Parameters: currency={currency}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Get Andriod PaymentOption
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public async Task<decimal?> getAndriodPaymentOption(string productId)
        {
            try
            {
                var storedProcedure = "[tha_get_inapp_android_payment_setting_by_productid]";

                var parameters = new DynamicParameters();
                parameters.Add("@productId", productId);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    return await dbConnection.QueryFirstAsync<decimal>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: CreditControl_DL, Method: getAndriodPaymentOptions, Parameters: productId={productId}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }

        public async Task<FullfilmentResponse> ThaGooglePayCustomerFullfilment(string msisdn, string amount, string ccsTransId, string ccAuthCode, string bundleRef)
        {

            FullfilmentResponse response = new FullfilmentResponse();

            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@amount", amount);
                parameters.Add("@reference", ccsTransId);
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@ccAuthCode", ccAuthCode);
                parameters.Add("@bundlename", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
                parameters.Add("@error_code", null, DbType.Int32, ParameterDirection.Output);
                parameters.Add("@error_msg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

                int errorCode = 0;
                AccountBalance result = new AccountBalance();
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    result = await dbConnection.QueryFirstOrDefaultAsync<AccountBalance>("tha_account_update_topup_add_bundle_google_pay", parameters, commandType: CommandType.StoredProcedure);
                    //if (result != null && result.audit_id > 0) // Fullfilment Successfull

                    errorCode = parameters.Get<int>("@error_code");
                }

                if (errorCode == 0) // Fullfilment Successfull
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.audit_id = result.audit_id;
                    response.Audit = new FullfilmentAudit() { audit_id = result.audit_id, new_balance = Convert.ToDecimal(result.new_balance, CultureInfo.InvariantCulture) };
                    response.BundleName = parameters.Get<string>("@bundlename");
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = parameters.Get<string>("@error_msg");
                    response.audit_id = 0;
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: DL_Pay360, Method: ThaGooglePayCustomerFullfilment, Parameters=> msisdn: {msisdn}, bundleRef: {bundleRef}, amount: {amount}, ccsTransId: {ccsTransId}, ccAuthCode: {ccAuthCode}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
            }

            return response;

        }

        /// <summary>
        /// Get Raw User Account
        /// </summary>
        /// <param name="sipUserName"></param>
        /// <returns></returns>
        public async Task<UserAccount> GetRawUserAccount(string sipUserName)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@sipuserName", sipUserName);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    var result = await dbConnection.QueryAsync<UserAccount>("tha_get_sip_account_details", parameters, commandType: CommandType.StoredProcedure);

                    return result?.FirstOrDefault();
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetRawUserAccount, Parameters=> sipUserName: {sipUserName}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }

        }

        /// <summary>
        /// Get User Subscriber Details
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<UserSubscriberDetails> GetUserSubscriberDetails(string account)
        {

            UserSubscriberDetails usbdet = new UserSubscriberDetails();



            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@account", account);

                Subscriber_Details usersubdet = null;
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    usersubdet = await dbConnection.QueryFirstOrDefaultAsync<Subscriber_Details>("tha_get_subscriber_details", parameters, commandType: CommandType.StoredProcedure);
                }

                if (usersubdet != null)
                {
                    UserAccountDetails uaDet = new UserAccountDetails();
                    uaDet.AddressOne = usersubdet.AddressOne;
                    uaDet.AddressTwo = usersubdet.AddressTwo;
                    uaDet.AddressThree = usersubdet.AddressThree;
                    uaDet.AddressFour = usersubdet.AddressFour;
                    uaDet.Country = usersubdet.Country;
                    uaDet.DeliveryAddressOne = usersubdet.DeliveryAddressOne;
                    uaDet.DeliveryAddressTwo = usersubdet.DeliveryAddressTwo;
                    uaDet.DeliveryAddressThree = usersubdet.DeliveryAddressThree;
                    uaDet.DeliveryCountry = usersubdet.DeliveryCountry;
                    uaDet.DeliveryPostCode = usersubdet.DeliveryPostCode;
                    uaDet.EmailAddress = usersubdet.EmailAddress;
                    uaDet.FirstName = usersubdet.FirstName;
                    uaDet.LastName = usersubdet.LastName;
                    uaDet.Na_Service_Id = usersubdet.Na_Service_Id;
                    uaDet.PostCode = usersubdet.PostCode;
                    uaDet.referralCode = usersubdet.referralCode;
                    uaDet.TelephoneOne = usersubdet.TelephoneOne;
                    uaDet.TelephoneTwo = usersubdet.TelephoneTwo;
                    uaDet.Title = usersubdet.Title;

                    UserAccountBalance uacb = new UserAccountBalance();

                    if (usersubdet.Balance != null && usersubdet.Balance != "")
                    {
                        uacb = new UserAccountBalance
                        {
                            Balance = _helperService.FormatAccountBalance(decimal.Parse(usersubdet.Balance, CultureInfo.InvariantCulture), usersubdet.Currency),
                            Currency = usersubdet.Currency,
                            CurrencySymbol = _helperService.ToCurrencySymbol(usersubdet.Currency)

                        };
                    }


                    usbdet.SubscriberID = usersubdet.SubscriberID;
                    usbdet.UserAccountBalance = uacb;
                    usbdet.UseSubscriberDetails = uaDet;

                }

                return usbdet;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetUserSubscriberDetails, Parameters=> account: {account}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return usbdet;
            }

        }

        /// <summary>
        /// Can Use Referral Code Revised
        /// </summary>
        /// <param name="na_service_id"></param>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<bool> CanUseReferralCodeRevised(int na_service_id, string msisdn)
        {

            var storedProcedure = "tha_can_apply_referral_code_revised";
            var parameters = new DynamicParameters();
            var canApply = false;

            try
            {
                parameters.Add("@na_service_id", na_service_id);
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@canApply", dbType: DbType.Boolean, direction: ParameterDirection.Output);


                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);

                    canApply = parameters.Get<bool>("@canApply");
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: CanUseReferralCodeRevised, Parameters=> na_service_id: {na_service_id},msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);

            }
            return canApply;
        }

        /// <summary>
        /// Get Referral Code
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<string> GetReferralCode(string msisdn)
        {
            var storedProcedure = "tha_get_referral_code";

            var parameters = new DynamicParameters();

            var referralCode = "";

            try
            {
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@referralCode", dbType: DbType.String, direction: ParameterDirection.Output, size: 20);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);

                    referralCode = parameters.Get<string>("@referralCode");
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetReferralCode, Parameters=> msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }

            return referralCode;
        }

        /// <summary>
        /// Get Email Default
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<useremailRegistration> getEmailDefault(string msisdn)
        {
            var storedProcedure = "tha_select_user_registration";

            useremailRegistration usrRegis = null;

            var parameters = new DynamicParameters();

            try
            {

                parameters.Add("@msisdn", msisdn);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.QueryAsync<useremailRegistration>(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);

                    return result?.FirstOrDefault<useremailRegistration>();
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: getEmailDefault, Parameters=> msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }

            return usrRegis;
        }


        /// <summary>
        /// Validate Transfer
        /// </summary>
        /// <param name="sourceAmount"></param>
        /// <param name="sourceMsisdn"></param>
        /// <param name="sourceAccount"></param>
        /// <param name="destinationAmount"></param>
        /// <param name="destinationMsisdn"></param>
        /// <param name="destinationAccount"></param>
        /// <returns></returns>
        public async Task<bool> ValidateTransfer(string sourceAmount, string sourceMsisdn, string sourceAccount, string destinationAmount, string destinationMsisdn, string destinationAccount)
        {
            bool sourceAllowed, destinationAllowed;

            try
            {
                var storedProcedure = "tha_transfer_validate_users_v1";

                var parameters = new DynamicParameters();

                decimal sourceDecAmount = decimal.Parse(sourceAmount, CultureInfo.InvariantCulture) * 100;


                parameters.Add("@amount", sourceDecAmount);
                parameters.Add("@msisdn", sourceMsisdn);
                parameters.Add("@accountId", sourceAccount);

                parameters.Add("@transferCount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@transferAmount", dbType: DbType.Decimal, direction: ParameterDirection.Output);
                parameters.Add("@isTransferAllowed", dbType: DbType.Boolean, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    var result = await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    if (parameters.Get<dynamic>("@isTransferAllowed") == null)
                    {
                        sourceAllowed = false;
                    }
                    else
                    {
                        sourceAllowed = parameters.Get<Boolean>("@isTransferAllowed");
                    }
                }
            }
            catch (Exception ex)
            {
                sourceAllowed = false;
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: ValidateTransfer, Class: ATT_DL, Parameters: SourceAmount {sourceAmount},  SourceMsisdn {sourceMsisdn},  SourceAccount {sourceAccount},  DestinationAmount {destinationAmount},  DestinationMsisdn {destinationMsisdn},  DestinationAccount {destinationAccount}");
            }

            try
            {
                decimal destinationDecAmount = decimal.Parse(destinationAmount, CultureInfo.InvariantCulture) * 100;

                var storedProcedure = "tha_transfer_validate_users_v2";

                var parameters = new DynamicParameters();

                parameters.Add("@amount", destinationDecAmount);
                parameters.Add("@msisdn", destinationMsisdn);
                parameters.Add("@accountId", destinationAccount);

                parameters.Add("@transferCount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@transferAmount", dbType: DbType.Decimal, direction: ParameterDirection.Output);
                parameters.Add("@isTransferAllowed", dbType: DbType.Boolean, direction: ParameterDirection.Output);
                parameters.Add("@errorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    var result = await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                    var errorCode = 0;

                    if (parameters.Get<dynamic>("@isTransferAllowed") == null)
                    {
                        destinationAllowed = false;
                    }
                    else
                    {
                        destinationAllowed = parameters.Get<Boolean>("@isTransferAllowed");
                        errorCode = parameters.Get<int>("@errorCode");
                        //0-Success
                        //1 - transfer count exceeded maximum count limit of msisdn
                        //2 - Transfer amount limit excceded generic amount limit
                    }
                }
            }
            catch (Exception ex)
            {
                destinationAllowed = false;
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: ValidateTransfer, Class: ATT_DL, Parameters: SourceAmount {sourceAmount},  SourceMsisdn {sourceMsisdn},  SourceAccount {sourceAccount},  DestinationAmount {destinationAmount},  DestinationMsisdn {destinationMsisdn},  DestinationAccount {destinationAccount}");
            }
            return destinationAllowed && sourceAllowed;
        }

        /// <summary>
        /// Get Fx Rate From DB
        /// </summary>
        /// <param name="fromCurrency"></param>
        /// <param name="toCurrency"></param>
        /// <returns></returns>
        public async Task<string> GetFxRateFromDB(string fromCurrency, string toCurrency)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@fromCurrency", fromCurrency);
                parameters.Add("@toCurrency", toCurrency);
                parameters.Add("@value", dbType: DbType.String, direction: ParameterDirection.Output, size: 20);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.ExecuteAsync("tha_get_fx_rates", parameters, commandType: CommandType.StoredProcedure);
                    return parameters.Get<string>("@value");
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetFxRateFromDB, Class: ATT_DL, Parameters: FromCurrency {fromCurrency},  ToCurrency {toCurrency}");
            }
            return string.Empty;
        }
        /// <summary>
        /// is Returning User
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="devicePersistanceId"></param>
        /// <returns></returns>
        private async Task<bool> isReturningUser(string msisdn, string devicePersistanceId)
        {
            var storedProcedure = "tha_validate_returning_user";

            var parameters = new DynamicParameters();

            var isReturningUser = false;

            try
            {

                parameters.Add("@CLI", msisdn);
                parameters.Add("@DevicePersistentID", devicePersistanceId);
                parameters.Add("@isReturningUser", dbType: DbType.Boolean, direction: ParameterDirection.Output);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    await dbConnection.ExecuteAsync(storedProcedure, parameters,
                        commandType: CommandType.StoredProcedure);

                    isReturningUser = parameters.Get<bool>("@isReturningUser");
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: getEmailDefault, Parameters=> msisdn: {msisdn} devicePersistanceId {devicePersistanceId}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return isReturningUser;
        }

        /// <summary>
        /// Get Rates Table
        /// </summary>
        /// <param name="sourceCountry"></param>
        /// <returns></returns>
        private string GetRatesTable(string sourceCountry)
        {
            string destinationRatesTable = string.Empty;
            switch (sourceCountry)
            {
                case "United Kingdom":
                    destinationRatesTable = "tha_international_rates";
                    break;
                case "United States":
                case "United States of America":
                    destinationRatesTable = "tha_international_rates_usd";
                    break;
                case "Italy":
                    destinationRatesTable = "tha_international_rates_eur_it";
                    break;
                case "France":
                    destinationRatesTable = "tha_international_rates_eur_fr";
                    break;
                case "Greece":
                    destinationRatesTable = "tha_international_rates_eur_gr";
                    break;
                case "Germany":
                    destinationRatesTable = "tha_international_rates_eur_de";
                    break;
                case "Netherlands":
                    destinationRatesTable = "tha_international_rates_eur_nl";
                    break;
                case "Austria":
                    destinationRatesTable = "tha_international_rates_eur_at";
                    break;
                case "Portugal":
                    destinationRatesTable = "tha_international_rates_eur_pt";
                    break;
                case "Cyprus":
                    destinationRatesTable = "tha_international_rates_eur_cy";
                    break;
                case "Spain":
                    destinationRatesTable = "tha_international_rates_eur_es";
                    break;
            }

            return destinationRatesTable;
        }
        /// <summary>
        /// This method will insert the delete account request log
        /// </summary>
        /// <param name="deleteAccountRequest"></param>
        /// <returns></returns>
        public async Task<int> CreateDeleteAccountRequest(DeleteAccountLogRequestModel deleteAccountRequest)
        {

            var sp = "tha_insert_delete_account_logs_v2";
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", deleteAccountRequest.Msisdn);
            parameters.Add("@account", deleteAccountRequest.AccountId);
            parameters.Add("@message", AccountDeleteMessages.DeleteRequestMessage);

            parameters.Add("@accountActivationDate", deleteAccountRequest.AccountActivationDate);
            parameters.Add("@accountDeleteStatus", AccountDeleteStatus.Requested);
            parameters.Add("@comments", deleteAccountRequest.Comments);
            parameters.Add("@reason", deleteAccountRequest.DeleteAccountReason);
            parameters.Add("@allowedSignUpDate", deleteAccountRequest.AllowedSignUpDate);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                return await dbConnection.ExecuteAsync(sp, parameters, commandType: CommandType.StoredProcedure);
            }

        }
        /// <summary>
        /// This method will return the list of delete account reasons
        /// </summary>
        /// <param name="languageIsoCode"></param>
        /// <returns></returns>
        public async Task<List<DeleteAccountReason>> GetDeleteAccountReasons(string languageIsoCode)
        {
            try
            {
                string languageColName = GetDeleteAccountTableLanguageColName(languageIsoCode);

                var parameters = new DynamicParameters();
                parameters.Add("@languageName", languageColName);

                List<DeleteAccountReason> deleteAccountReasons;
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.QueryAsync<DeleteAccountReason>("tha_get_delete_account_reasons", parameters, commandType: CommandType.StoredProcedure);
                    deleteAccountReasons = result.ToList();
                }

                return deleteAccountReasons;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetDeleteAccountReasons, Class: UserAccount_DL, Parameters: languageIsoCode {languageIsoCode}");
            }
            return new List<DeleteAccountReason>();
        }
        private string GetDeleteAccountTableLanguageColName(string languageIsoCode)
        {
            switch (languageIsoCode)
            {
                case "en":
                    return $"english_{languageIsoCode}";
                case "nl":
                    return $"dutch_{languageIsoCode}";
                case "fr":
                    return $"french_{languageIsoCode}";
                case "el":
                    return $"greek_{languageIsoCode}";
                case "es":
                    return $"spanish_{languageIsoCode}";
                case "fil":
                    return $"filipino_{languageIsoCode}";
                case "it":
                    return $"italian_{languageIsoCode}";
                case "nb":
                    return $"norwegian_{languageIsoCode}";
                case "pt":
                    return $"portuguese_{languageIsoCode}";
                case "sv":
                    return $"swedish_{languageIsoCode}";
                case "tr":
                    return $"turkish_{languageIsoCode}";
                case "vi":
                    return $"vietnamese_{languageIsoCode}";
                case "de":
                    return $"german_{languageIsoCode}";
                default:
                    return "english_en";
            }
        }
        /// <summary>
        /// This method will return the delete account request based on the msisdn
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<DeleteAccountLogRequest> GetDeleteAccountLogRequest(string msisdn)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    return await dbConnection.QueryFirstOrDefaultAsync<DeleteAccountLogRequest>("tha_get_delete_account_request", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetDeleteAccountLogRequest," +
                    $"Parameters=> model: " + $"{JsonConvert.SerializeObject(new { msisdn })}, " +
                   "ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return null;
            }
        }
        /// <summary>
        /// This method will set the account status PENDING,APPROVED,CANCELLED
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<bool> UpdateDeletedAccountStatus(DeleteAccountLogRequestModel model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", model.Msisdn);
                parameters.Add("@account", model.AccountId);
                parameters.Add("@accountDeleteStatus", model.AccountDeleteStatus);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync("tha_update_delete_account_log_status", parameters, commandType: CommandType.StoredProcedure);
                }
                return true;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: UpdateDeletedAccountStatus," +
                     $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                    "ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return false;
        }
        /// <summary>
        /// This method will return the list of account delete requests which are not Deleted or cancelled
        /// </summary>
        /// <returns></returns>
        public async Task<List<DeleteAccountLogRequest>> GetDeleteAccountLogRequestsList()
        {
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var result = await dbConnection.QueryAsync<DeleteAccountLogRequest>("tha_get_delete_account_requests_list", commandType: CommandType.StoredProcedure);
                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: GetDeleteAccountLogRequestsList," +
                   "ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return new List<DeleteAccountLogRequest>();
        }
        /// <summary>
        /// This method will set the account delete date and mark the account status as deleted and update the message
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="account"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public async Task<bool> SetAccountDeletedStatus(string msisdn, string account, string message)
        {
            try
            {

                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@account", account);
                parameters.Add("@message", message);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync("tha_set_account_delete_status", parameters, commandType: CommandType.StoredProcedure);
                }
                return true;
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: SetAccountDeletedStatus," +
                     $"Parameters=> model: " + $"{JsonConvert.SerializeObject(new { Msisdn = msisdn, Account = account })}, " +
                    "ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return false;
        }
        /// <summary>
        /// This method will check if the account is deleted
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<bool> IsAccountDeleted(string msisdn)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@isDeleted", dbType: DbType.Boolean, direction: ParameterDirection.Output);
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync("tha_is_account_deleted", parameters, commandType: CommandType.StoredProcedure);
                }
                return parameters.Get<bool>("@isDeleted");
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: UserAccount_DL, Method: IsAccountDeleted," +
                     $"Parameters=> model: " + $"{JsonConvert.SerializeObject(new { Msisdn = msisdn })}, " +
                    "ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
            }
            return false;
        }
    }

}

