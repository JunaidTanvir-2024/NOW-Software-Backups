using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;
using FluentValidation;
using MapsterMapper;
using Mediator;
using RW.Models;
using RW;

namespace FH.UseCases.Products;

public static class GetProductOperator
{
    #region Query

    public sealed record Query : IRequest<IResultWrapper>
    {
        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public decimal? Price { get; set; }
        public string? CountryIsoCode { get; set; }
        public string? CurrencyCode { get; set; }
        public string? Category { get; set; }
        public string? SubCategory { get; set; }
        public string? Operator { get; set; }
    }

    #endregion Query

    #region Validator

    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Page).GreaterThan(0);
            RuleFor(x => x.RecordsPerPage).LessThan(100);
        }
    }

    #endregion Validator

    #region Response

    public sealed record Response
    {
        public ProductInfo Product { get; set; } = new ProductInfo();

        public sealed record ProductInfo
        {
            public long ProductId { get; set; }
            public string? ProductName { get; set; }
            public string? ProductAliasName { get; set; }
            public string? Description { get; set; }
            public bool? ProductType { get; set; }

            public ProductOperatorInfo ProductOperator { get; set; } = new ProductOperatorInfo();
            public ProductCountryInfo ProductCountry { get; set; } = new ProductCountryInfo();
            public ProductVendorInfo ProductVendor { get; set; } = new ProductVendorInfo();
            public ProductPriceInfo ProductPrice { get; set; } = new ProductPriceInfo();
          
        }
        public sealed record ProductOperatorInfo
        {
            public string? OperatorName { get; set; }
            public string? OperatorAliasName { get; set; }
            public string? OperatorShortCode { get; set; }
            public string? OperatorDescription { get; set; }
        }

        public sealed record ProductCountryInfo
        {
            public string? CountryName { get; set; }
            public string? CountryIsoCode2 { get; set; }
            public string? CountryIsoCode3 { get; set; }
            public string? Continent { get; set; }
            public string? CallingCode { get; set; }
        }

        public sealed record ProductVendorInfo
        {
            public string? VendorProductCode { get; set; }
            public string? VendorOperatorCode { get; set; }
            public string? Logo { get; set; }
        }



        public sealed record ProductPriceInfo
        {
            public decimal? Price { get; set; }
            public decimal? RangeMinPrice { get; set; }
        }
    }

    #endregion Response

    #region Handler

    internal sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IMapper _mapper = mapper;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        async ValueTask<IResultWrapper> IRequestHandler<Query, IResultWrapper>.Handle(Query request, CancellationToken cancellationToken)
        {
            var productsRequestDto = _mapper.Map<ProductByOperatorDto.Request>(request);

            // Setting Default Values
            //productsRequestDto.Filters = Filters;
            productsRequestDto.IsActive = true;
            productsRequestDto.IsDeleted = false;

            (IEnumerable<ProductByOperatorDto.Response> products, DatabasePaginationDto pagination) = await _unitOfWork.ProductRepository.GetSingleProductByEachOperator(productsRequestDto);

            if (products is null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
            }
            var responseProducts = products.Select(x => new GetProductOperator.Response()
            {
                Product = new Response.ProductInfo()
                {
                    ProductId = x.ProductId,
                    ProductName = x.ProductName,
                    ProductAliasName = x.ProductAliasName,
                    Description = x.Description,
                    ProductType = x.ProductType,


                    ProductOperator = new Response.ProductOperatorInfo()
                    {
                        OperatorName = x.OperatorName,
                        OperatorAliasName = x.OperatorAliasName,
                        OperatorShortCode = x.OperatorShortCode,
                        OperatorDescription = x.OperatorDescription
                    },

                    ProductCountry = new Response.ProductCountryInfo()
                    {
                        CountryName = x.CountryName,
                        CountryIsoCode2 = x.CountryIsoCode2,
                        CountryIsoCode3 = x.CountryIsoCode3,
                        Continent = x.Continent,
                        CallingCode = x.CallingCode
                    },

                    ProductVendor = new Response.ProductVendorInfo()
                    {
                        VendorProductCode = x.VendorProductCode,
                        VendorOperatorCode = x.VendorOperatorCode,
                        Logo = x.Logo
                    },

                    ProductPrice = new Response.ProductPriceInfo()
                    {
                        Price = x.Price,
                        RangeMinPrice = x.range_min_price
                    }
                    
                }
            });
            return ResultWrapper.Success(responseProducts, new Pagination(pagination.TotalRecords, pagination.TotalPages, request.Page, request.RecordsPerPage));
        }
    }

    #endregion Handler
}
