using MM.Infrastructure.Persistence.Repositories;

namespace MM.Infrastructure.Services.Http;

internal sealed class HttpService : IHttpService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILoggerRepository _loggerRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ITimeWarpService _timeWarpService;
    private string? _bearerToken;
    private string? _basicAuthUsername;
    private string? _basicAuthPassword;
    private bool _isLoggingEnabled;
    private int _vendorId;
    private readonly List<Dictionary<string, string>> _headers;

    public HttpService(
        IHttpClientFactory httpClientFactory,
        ILoggerRepository loggerRepository,
        IHttpContextAccessor httpContextAccessor,
        ITimeWarpService timeWarpService)
    {
        _httpClientFactory = httpClientFactory;
        _loggerRepository = loggerRepository;
        _httpContextAccessor = httpContextAccessor;
        _timeWarpService = timeWarpService;
        _headers = new List<Dictionary<string, string>>();
    }

    IHttpService IHttpService.WithBearerAuth(string? token)
    {
        _bearerToken = token;
        return this;
    }

    IHttpService IHttpService.WithBasicAuth(string? username, string? password)
    {
        _basicAuthUsername = username;
        _basicAuthPassword = password;
        return this;
    }

    IHttpService IHttpService.WithHeaders(IEnumerable<Dictionary<string, string>> headers)
    {
        _headers.AddRange(headers);
        return this;
    }

    IHttpService IHttpService.EnableLogging()
    {
        _isLoggingEnabled = true;
        return this;
    }
    IHttpService IHttpService.SetVendor(AppEnums.Vendors vendor)
    {
        _vendorId = (int)vendor;
        return this;
    }

    public async Task<HttpServiceResponse> GetAsync(string requestUri)
    {
        return await SendRequestAsync(HttpMethod.Get, requestUri);
    }

    public async Task<HttpServiceResponse> PostAsync(string requestUri, object? data = default)
    {
        return await SendRequestAsync(HttpMethod.Post, requestUri, CreateJsonContent(data));
    }

    public async Task<HttpServiceResponse> PutAsync(string requestUri, object? data = default)
    {
        return await SendRequestAsync(HttpMethod.Put, requestUri, CreateJsonContent(data));
    }

    public async Task<HttpServiceResponse> DeleteAsync(string requestUri)
    {
        return await SendRequestAsync(HttpMethod.Delete, requestUri);
    }

    private async Task<HttpServiceResponse> SendRequestAsync(HttpMethod method, string requestUri, HttpContent? content = null)
    {
        var stopwatch = Stopwatch.StartNew();
        var client = _httpClientFactory.CreateClient();

        var request = new HttpRequestMessage(method, requestUri);

        if (_bearerToken is not null)
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _bearerToken);
        }

        else if (_basicAuthUsername is not null && _basicAuthPassword is not null)
        {
            var authValue = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_basicAuthUsername}:{_basicAuthPassword}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authValue);
        }

        foreach (var header in _headers)
        {
            client.DefaultRequestHeaders.Add(header["Key"], header["Value"]);
        }

        if (content is not null)
        {
            request.Content = content;
        }

        var requestBody = request?.Content is not null ? await request.Content.ReadAsStringAsync() : string.Empty;

        return await SendRequestAndSaveLog(stopwatch, client, request, requestBody);
    }

    private async Task<HttpServiceResponse> SendRequestAndSaveLog(Stopwatch stopwatch, HttpClient client, HttpRequestMessage? request, string requestBody)
    {
        try
        {
            var result = await client.SendAsync(request!);

            var responseBody = await result.Content.ReadAsStringAsync();

            // Calculating response size
            var responseSize = Encoding.UTF8.GetByteCount(responseBody);

            if (_isLoggingEnabled)
            {
                InsertVendorLogs(stopwatch, request, (int)result.StatusCode, responseBody, requestBody, responseSize, string.Empty);
            }
            return new HttpServiceResponse() { IsFailure = result.IsSuccessStatusCode, Json = responseBody };
        }
        catch (Exception ex)
        {
            if (_isLoggingEnabled)
            {
                // Response body and size will be zero as there is no response in case of error 
                InsertVendorLogs(stopwatch, request, AppConstants.StatusCodes.InternalServerError, string.Empty, requestBody, 0, ex.StackTrace?.ToString());
            }
            return new HttpServiceResponse() { IsFailure = false, Json = string.Empty };
        }
    }

    private static HttpContent CreateJsonContent(object? data)
    {
        var json = JsonSerializer.Serialize(data);
        return new StringContent(json, Encoding.UTF8, AppConstants.ContentTypes.ApplicationJson);
    }

    private void InsertVendorLogs(Stopwatch stopwatch, HttpRequestMessage? request, int statusCode, string? responseBody, string? reqeustBody, int responseSize, string? stackTraceError)
    {
        var logEntry = new VendorLogDto
        {
            CorrelationId = _httpContextAccessor.HttpContext?.Items["CorrelationIdKey"]?.ToString()!,
            Timestamp = _timeWarpService.UtcNow,
            RequestPath = request?.RequestUri?.ToString(),
            RequestBody = reqeustBody,
            ResponseBody = responseBody,
            StatusCode = statusCode,
            Duration = stopwatch.ElapsedMilliseconds,
            Headers = JsonSerializer.Serialize(request?.Headers),
            QueryString = request?.RequestUri?.Query,
            ErrorReason = stackTraceError,
            ResponseSize = responseSize,
            RequestMethod = request?.Method.ToString(),
            VendorId = _vendorId,
        };

        _loggerRepository.VendorLogInsertAsync(logEntry);
    }
}
