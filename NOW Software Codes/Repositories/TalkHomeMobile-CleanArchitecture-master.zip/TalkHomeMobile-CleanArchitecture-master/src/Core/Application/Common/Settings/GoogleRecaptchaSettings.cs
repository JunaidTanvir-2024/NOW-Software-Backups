﻿namespace Application.Common.Settings;

public class GoogleRecaptchaSettings
{
    public const string SectionName = "GoogleRecaptchaSettings";
    public static GoogleRecaptchaSettings Bind = new GoogleRecaptchaSettings();
    public string? VefiyAPIAddress { get; set; }
    public string? Sitekey { get; set; }
    public string? Secretkey { get; set; }
    public decimal? RecaptchaThreshold { get; set; }
    public bool IsActive { get; set; } = false;
}