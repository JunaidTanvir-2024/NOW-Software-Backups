﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{

    public class SerilogConfig
    {
        public string FilePath { get; set; }
    }

}
