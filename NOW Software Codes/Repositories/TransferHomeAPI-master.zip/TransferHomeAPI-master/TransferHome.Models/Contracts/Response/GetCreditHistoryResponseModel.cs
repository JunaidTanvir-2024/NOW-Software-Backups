﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class GetCreditHistoryResponseModel
    {
        public IEnumerable<CreditHistory> CreditHistory { get; set; }
    }

    public class CreditHistory
    {
        public int TransactionNumber { get; set; }
        public string PaymentType { get; set; }
        public string Amount { get; set; }
        public string Currency { get; set; }
        public DateTime TransactionDate { get; set; }
    }
}
