﻿using Dapper;
using Microsoft.Extensions.Options;
using Org.BouncyCastle.Ocsp;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.DbConnections;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Implementations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;

namespace TalkhomeAPI.Data.Repositories
{
	public class TransferRepository : ITransferRepository
	{
		private readonly IDbConnectionSettings _Att_Db;
		private readonly IDbConnectionSettings _Digitalk;
		private readonly IDbConnectionSettings _TalkHomeAppDb;
		private readonly ILogger _logger;
		private readonly IInternationalTopupServiceFeeCalculator _internationalTopupServiceFeeCalculator;
		private readonly IPhoneNumberService _phoneNumberService;

		public TransferRepository(IOptions<ConnectionString> connectionString, ILogger logger,
			IInternationalTopupServiceFeeCalculator internationalTopupServiceFeeCalculator,
			IPhoneNumberService phoneNumberService)
		{
			_Att_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.ATTDbConnection));
			_Digitalk = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigitalkDbConnection));
			_TalkHomeAppDb = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppDbConnection));
			_logger = logger;
			this._internationalTopupServiceFeeCalculator = internationalTopupServiceFeeCalculator;
			this._phoneNumberService = phoneNumberService;
		}
		public async Task CreateTransactionLogAsync(InternationalTopupTransactionLog transaction)
		{
			try
			{
				var parameters = new DynamicParameters();
				parameters.Add("@TransactionIdentifier", transaction.TransactionIdentifier);
				parameters.Add("@ProductIdentifier", transaction.ProductIdentifier);
				parameters.Add("@CustomerIdentifier", transaction.CustomerIdentifier);
				parameters.Add("@ToMsisdn", transaction.ToMsisdn);
				parameters.Add("@Currency", transaction.Currency);
				parameters.Add("@ProductPrice", transaction.ProductPrice);
				parameters.Add("@SalePrice", transaction.SalePrice);
				parameters.Add("@DiscountApplied", transaction.DiscountApplied);
				parameters.Add("@ServiceFee", transaction.ServiceFee);
				parameters.Add("@DiscountOnServiceFee", transaction.DiscountOnServiceFee);
				parameters.Add("@TotalPrice", transaction.TotalPrice);
				parameters.Add("@CheckoutStatus", transaction.CheckoutStatus);
				parameters.Add("@Message", transaction.Message);
				await _TalkHomeAppDb.SqlConnection.ExecuteAsync(
							"tha_international_topup_logs_create", parameters, commandType: CommandType.StoredProcedure);

			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: TransferRepository, Method: CreateTransactionLog");
			}
		}
		public async Task<InternationalTopupTransactionLog> GetTransactionLog(string nowtelRef, string product)
		{
			try
			{
				var parameters = new DynamicParameters();
				parameters.Add("@TransactionIdentifier", nowtelRef);
				parameters.Add("@ProductIdentifier", product);
				return await _TalkHomeAppDb.SqlConnection.QueryFirstOrDefaultAsync<InternationalTopupTransactionLog>(
							"tha_international_topup_logs_get", parameters, commandType: CommandType.StoredProcedure);

			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: TransferRepository, Method: GetTransactionLog");
				return null;
			}
		}
		public async Task UpdateTransactionLog(InternationalTopupTransactionLog transaction)
		{
			try
			{
				var parameters = new DynamicParameters();
				parameters.Add("@TransactionIdentifier", transaction.TransactionIdentifier);
				parameters.Add("@ProductIdentifier", transaction.ProductIdentifier);
				parameters.Add("@ProductPrice", transaction.ProductPrice);
				parameters.Add("@SalePrice", transaction.SalePrice);
				parameters.Add("@DiscountApplied", transaction.DiscountApplied);
				parameters.Add("@ServiceFee", transaction.ServiceFee);
				parameters.Add("@DiscountOnServiceFee", transaction.DiscountOnServiceFee);
				parameters.Add("@TotalPrice", transaction.TotalPrice);
				parameters.Add("@CheckoutStatus", transaction.CheckoutStatus);
				parameters.Add("@Message", transaction.Message);
				await _TalkHomeAppDb.SqlConnection.ExecuteAsync(
							"tha_international_topup_logs_update", parameters, commandType: CommandType.StoredProcedure);

			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: TransferRepository, Method: UpdateTransactionLog");
			}
		}
		public async Task<InternationalTopupProduct> GetProductByNowtelTransactionReference(string guid, string product)
		{
			try
			{
				var parameters = new DynamicParameters();
				parameters.Add("@guid", guid);
				parameters.Add("@product", product);

				return await _Att_Db.SqlConnection.QueryFirstOrDefaultAsync<InternationalTopupProduct>("at_getAPIAccessGUIDRecord_Trh_V1", parameters, commandType: CommandType.StoredProcedure);
			}
			catch (Exception ex)
			{
				_logger.Error(ex, $"Class=>TransferRepository, Method=>GetProductByNowtelTransactionReference, Guid=>{guid}, product=>{product}");
				return null;
			}
		}

		public async Task SaveTransaction(DBTransferTransaction transaction)
		{
			try
			{
				var parameters = new DynamicParameters();

				parameters.Add("@AccountId", transaction.AccountId);
				parameters.Add("@PaymentTypeId", (int)transaction.PaymentTypeId); //app
				parameters.Add("@PaymentRef", transaction.PaymentRef);
				parameters.Add("@StatusId", transaction.StatusId);
				parameters.Add("@NowtelRef", transaction.NowtelRef);
				parameters.Add("@ClientCurrency", transaction.ClientCurrecny);
				parameters.Add("@ReceiverCurrency", transaction.ReceiverCurrecny);
				parameters.Add("@Product", transaction.Product);
				parameters.Add("@ItemPrice", transaction.ItemPrice);
				parameters.Add("@TotalPrice", transaction.TotalPrice);
				parameters.Add("@ServiceFee", transaction.ServiceFee);
				parameters.Add("@ServiceFeeDiscount", transaction.ServiceFeeDiscount);
				parameters.Add("@TotalServiceFee", transaction.TotalServiceFee);
				parameters.Add("@Discount", 0);
				parameters.Add("@DiscountCode", null);
				parameters.Add("@DiscountCodeType", null);
				parameters.Add("@FromMsisdn", transaction.FromMsisdn);
				parameters.Add("@ToMsisdn", transaction.ToMsisdn);
				parameters.Add("@OperatorCountryName", transaction.OperatorCountryName);
				parameters.Add("@CountryCode", transaction.CountryCode);
				parameters.Add("@OperatorName", transaction.OperatorName);
				parameters.Add("@OperatorLogoUrl", transaction.OperatorLogoUrl);
				parameters.Add("@TransferRef", transaction.TransferRef);
				parameters.Add("@PaymentErrorMsg", null);
				parameters.Add("@TransferErrorMsg", null);

				await _TalkHomeAppDb.SqlConnection.ExecuteAsync("tha_app_save_itopup_transactions_v2",
					parameters, commandType: CommandType.StoredProcedure);
			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class=>TransferRepository, Method=>SaveTransaction,Message=>Error in save transaction");
				throw ex;
			}
		}

		public async Task<int> IsFirstInternationTopup(string account)
		{
			var parameters = new DynamicParameters();

			parameters.Add("@AccountId", account);
			parameters.Add("@IsFirstTopup", dbType: DbType.Int32, direction: ParameterDirection.Output);

			await _TalkHomeAppDb.SqlConnection.ExecuteAsync("tha_web_isfirstitopup", parameters, commandType: CommandType.StoredProcedure);

			return parameters.Get<int>("@IsFirstTopup");
		}

		public async Task<DBAccountBalance> UpdateAccountBalance(decimal amount, string accountID, string reference)
		{
			amount = Math.Round(100 * amount, 0);

			var parameters = new DynamicParameters();

			parameters.Add("@account", accountID);
			parameters.Add("@channel", 2); //web
			parameters.Add("@amount", amount);
			parameters.Add("@bonus", 0);
			parameters.Add("@creditReason", "AirTime Transfer Debit Web");
			parameters.Add("@paymentMethod", "AccountBalance");
			parameters.Add("@rechargeType", 0);
			parameters.Add("@reference", reference);
			parameters.Add("@ccsTransId", 0);
			parameters.Add("@ccAuthCode", "THATRWeb");

			return await _Digitalk.SqlConnection.QueryFirstOrDefaultAsync<DBAccountBalance>("tha_web_AccountUpdateBalance", parameters, commandType: CommandType.StoredProcedure);
		}

		public async Task<PromotionBalanceDedutionDetails> InsertSpecialPromotionLogs(decimal amount, string accountID, string reference, string paymentMethod)
		{
			amount = Math.Round(100 * amount, 0);

			var parameters = new DynamicParameters();

			parameters.Add("@account", accountID);
			parameters.Add("@channel", 2); //web
			parameters.Add("@amount", amount);
			parameters.Add("@bonus", 0);
			parameters.Add("@creditReason", "AirTime Transfer Debit Web");
			parameters.Add("@paymentMethod", paymentMethod);
			parameters.Add("@rechargeType", 0);
			parameters.Add("@reference", reference);
			parameters.Add("@ccsTransId", 0);
			parameters.Add("@ccAuthCode", "THATRWeb");
			parameters.Add("@ccExpdate", null);
			parameters.Add("@ccIssue", null);
			parameters.Add("@ccName", null);
			parameters.Add("@ccNum", null);
			parameters.Add("@ccType", null);
			parameters.Add("@ccValid", null);
			parameters.Add("@paymentBillId", null);
			parameters.Add("@settleBillId", null);
			parameters.Add("@userName", null);
			parameters.Add("@refundedAuditId", null);
			parameters.Add("@suppressBillPaymentAlways", false);
			parameters.Add("@suppressNotify", false);
			parameters.Add("@checkCreditLimits", true);
			parameters.Add("@auditId", null);
			parameters.Add("@show_output", true);

			parameters.Add("@retAmount", dbType: DbType.Decimal, direction: ParameterDirection.Output);
			parameters.Add("@retcreditReason", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

			await _Digitalk.SqlConnection.ExecuteAsync("tha_special_promotions_insert_v3", parameters, commandType: CommandType.StoredProcedure);

			return new PromotionBalanceDedutionDetails()
			{
				retAmount = parameters.Get<decimal>("retAmount") / 100,
				retcreditReason = parameters.Get<string>("retcreditReason")
			};


		}



		public async Task<PromotionBalanceDedutionDetails> GetSpecialPromotionBalanceToDeduct(decimal amount, string accountID)
		{
			amount = Math.Round(100 * amount, 0);

			var parameters = new DynamicParameters();

			parameters.Add("@account", accountID);
			parameters.Add("@amount", amount);
			parameters.Add("@creditReason", "AirTime Transfer Debit Web");
			parameters.Add("@retAmount", dbType: DbType.Decimal, direction: ParameterDirection.Output);
			parameters.Add("@retcreditReason", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

			await _Digitalk.SqlConnection.ExecuteAsync("tha_special_promotions_balance_to_Deduct", parameters, commandType: CommandType.StoredProcedure);

			return new PromotionBalanceDedutionDetails()
			{
				retAmount = parameters.Get<decimal>("retAmount") / 100,
				retcreditReason = parameters.Get<string>("retcreditReason")
			};

		}

		public async Task<TransferValidationResponse> ValidateTransferRequest(DBValidateTransferRequest request)
		{
			var parameters = new DynamicParameters();

			parameters.Add("@FromCountryCode", request.FromCountryCode);
			parameters.Add("@ToCountryCode", request.ToCountryCode);
			parameters.Add("@AccountId", request.AccountId);
			parameters.Add("@TotalAmount", request.TotalAmount);
			parameters.Add("@UserCurrency", request.UserCurrency);
			parameters.Add("@FromMsisdn", request.FromMsisdn);

			parameters.Add("@Response", dbType: DbType.Int32, direction: ParameterDirection.Output);

			await _TalkHomeAppDb.SqlConnection.ExecuteAsync("tha_web_validate_transfer_request", parameters, commandType: CommandType.StoredProcedure);

			return parameters.Get<TransferValidationResponse>("@Response");
		}

		/* public async Task<TransferValidationResponse?> ValidateNowtelCustomerNew(string frommsisdn, string nowtelreference, string product, decimal amount)
         {
             var storedProcedure = "at_validate_customer_v5_pending";

             var parameters = new DynamicParameters();
             parameters.Add("@frommsisdn", frommsisdn);
             parameters.Add("@nowtelreference", nowtelreference);
             parameters.Add("@amount", amount);
             parameters.Add("@product", product);
             parameters.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
             parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
             parameters.Add("@isAllowed", dbType: DbType.Int32, direction: ParameterDirection.Output);


             var response = await
              _TalkHomeAppDb.SqlConnection.ExecuteAsync(storedProcedure, parameters,
                 commandType: CommandType.StoredProcedure);

             return parameters.Get<TransferValidationResponse>("@isAllowed");


         }*/

		public async Task<ValidateCustomer> ValidateNowtelCustomerNew(string frommsisdn, string nowtelreference, string product, decimal amount)
		{
			ValidateCustomer validateCustomer = new ValidateCustomer();
			var storedProcedure = "at_validate_customer_v5_pending";

			var parameters = new DynamicParameters();
			parameters.Add("@frommsisdn", frommsisdn);
			parameters.Add("@nowtelreference", nowtelreference);
			parameters.Add("@amount", amount);
			parameters.Add("@product", product);
			parameters.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output, size: 100);
			parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
			parameters.Add("@isAllowed", dbType: DbType.Int32, direction: ParameterDirection.Output);

			try
			{

				var response = await
				 _Att_Db.SqlConnection.ExecuteAsync(storedProcedure, parameters,
					commandType: CommandType.StoredProcedure);

				if (parameters.Get<string>("@error_msg") != null)
				{
					validateCustomer.errorCode = parameters.Get<Int32>("@error_code");
					validateCustomer.isAllowed = parameters.Get<Int32>("@isAllowed");
					validateCustomer.Message = parameters.Get<string>("@error_msg");
				}

				return validateCustomer;


			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class=>TransferRepository, Method=>ValidateNowtelCustomerNew");
				throw ex;
			}

		}
	}
}
