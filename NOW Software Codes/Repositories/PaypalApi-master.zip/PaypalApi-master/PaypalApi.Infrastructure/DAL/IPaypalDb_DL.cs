﻿using PaypalApi.Models.Contracts.Request.User;
using PaypalApi.Models.Contracts.Response.Api;
using PaypalApi.Models.Database;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PaypalApi.Infrastructure.DAL
{
    public interface IPaypalDb_DL
    {
        Task<Customer> GetCustomerByMerchantRef(string merchantRef);
        Task<DbResult<int>> AddCustomer(Customer customer);
        Task<DbResult<int>> AddTransaction(ApiCreateSalePaymentResponse apiResponse, int customerId, ProductBasket[] basket, string requestJson, string responseJson);
        Task<DbResult<int>> AddErrorTransaction(int customerId, string invoiceNumber, string description, string intent, float amount, string currency, DateTime requestTime, string errorMessage, ProductBasket[] basket, string requestJson, string responseJson);
        Task<DbTransactions> CheckCustomerTransaction(string customerMerchantRef, string paypalTransactionId);        
        Task<DbResult<int>> UpdateTransaction(ApiExecuteSalePaymentResponse apiResponse, int transactionId, string requestJson, string responseJson, string httpStatusCode);
        Task<DbResult<int>> UpdateErrorTransaction(string payerId, int transactionId, string executeErrorMessage, string requestJson, string responseJson, string httpStatusCode);
        Task<List<TransactionItems>> GetTransactionItems(string transactionId);
        Task<int> UpdateTransactionItem(int Id, bool IsFullfilled, DateTime FulfilmentDateTime, string FullfillmentError);
        Task<FullfilmentResponse> ThrccCustomerFullfilment(string transactionId, string amount, string productRef);
        Task<FullfilmentResponse> ThccCustomerFullfilment(string transactionId, string amount);
        Task<FullfilmentResponse> ThmCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef);
        Task<List<ProductItems>> GetProductItems();        
        Task<ValidateRes> ThmProductRefValidation(string productItemCode, string productRef, string bundleRef);
        Task<int> ThrccProductRefValidation(string productItemCode, string productRef);
        Task<ValidateRes> ThaProductRefValidation(string productItemCode, string productRef);
        Task<DbResult<List<ProductItems>>> GetProductItems(string msisdn);
        Task<FullfilmentResponse> ThaCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef);


    }
}
