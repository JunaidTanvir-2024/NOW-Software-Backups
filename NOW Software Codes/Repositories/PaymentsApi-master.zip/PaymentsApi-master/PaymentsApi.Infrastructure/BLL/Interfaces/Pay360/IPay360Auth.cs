﻿using static PaymentsApi.Infrastructure.BLL.Implementation.Pay360.Pay360Auth;

namespace PaymentsApi.Infrastructure.BLL.Interfaces.Pay360
{
    public interface IPay360Auth
    {
        Pay360Creds GetApiCredsByProductCodeAndProductRef(string productRef, string productCode, string paymentType);
        Pay360Creds GetApiCredsByInstallationId(string installationId);
    }
}