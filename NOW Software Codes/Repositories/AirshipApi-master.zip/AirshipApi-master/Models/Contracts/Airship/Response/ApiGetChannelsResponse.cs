﻿using System.Collections.Generic;

namespace Models.Contracts.Airship.Response
{
    public class ApiGetChannelsResponse
    {
        public string next_page { get; set; }
        public List<Channel> channels { get; set; }


    }
}
