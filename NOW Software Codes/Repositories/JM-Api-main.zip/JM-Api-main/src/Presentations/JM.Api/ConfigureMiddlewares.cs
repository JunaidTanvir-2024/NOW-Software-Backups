using JM.Infrastructure;

using Microsoft.AspNetCore.HttpOverrides;

namespace JM.Api;

public static class ConfigureMiddlewares
{
	public static WebApplication AddApiMiddlewares(this WebApplication app, IConfiguration configuration)
	{
		app.UseForwardedHeaders(new ForwardedHeadersOptions
		{
			ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
		});
		app.UseStaticFiles();
		app.UseAuthentication();
		app.UseAuthorization();
		app.UseHttpsRedirection();
		app.UseInfrastructureMiddlewares(configuration);
		app.MapControllers();
		return app;
	}
}
