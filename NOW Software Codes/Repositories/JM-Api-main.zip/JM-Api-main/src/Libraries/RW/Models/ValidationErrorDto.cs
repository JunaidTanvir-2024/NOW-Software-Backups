namespace RW.Models;
public readonly record struct ValidationErrorDto
{
    public required string PropertyName { get; init; }
    public required string ErrorMessage { get; init; }
}
