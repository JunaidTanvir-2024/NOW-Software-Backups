namespace Application.Features.Bundle.BundleDetail;

public sealed class BundleByIdRequestValidator : AbstractValidator<BundleByIdRequest>
{
    public BundleByIdRequestValidator()
    {
        RuleFor(p => p.Id).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
    }
}