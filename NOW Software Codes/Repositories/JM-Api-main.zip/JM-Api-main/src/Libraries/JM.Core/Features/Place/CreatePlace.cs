using FluentValidation;

using JM.Core.Features.Country;
using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;
namespace JM.Core.Features.Place;

public abstract class CreatePlace
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long TripId { get; set; }
        public long PlaceId { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.TripId).NotNull().NotEmpty().GreaterThan(0);
            RuleFor(x => x.PlaceId).NotNull().NotEmpty().GreaterThan(0);
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public required TripInfo Trip { get; set; }
        public IEnumerable<Traveler> Travelers { get; set; } = [];
        public sealed record TripInfo
        {
            public long Id { get; set; }
            public required string Name { get; set; }
            public DateTime StartingDate { get; set; }
            public long CreatorId { get; set; }
        }
        public sealed record Traveler
        {
            public required long Id { get; set; }
            public required string FullName { get; set; }
            public required string Email { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IMediator _mediator = mediator;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var newPlace = await _unitOfWork.TripRepository.AddPlaceToTrip(new Entities.TripPlace()
            {
                TripId = query.TripId,
                PlaceId = query.PlaceId
            });
            _unitOfWork.SaveChanges();

            var tripResult = (await _mediator.Send(new GetTrip.Query()
            {
                Id = query.TripId
            }, cancellationToken));

            if (newPlace is not null && tripResult.IsSuccess)
            {
                var trip = tripResult.TypedPayload<GetTrip.Response>();
                return ResultWrapper.Success(new Response()
                {
                    Trip = new Response.TripInfo()
                    {
                        Id = trip?.Id ?? default,
                        Name = trip?.Name!,
                        StartingDate = trip?.StartingDate ?? default,
                        CreatorId = trip?.CreatorId ?? default,
                    },
                    Travelers = trip?.Travelers.Select(x => new Response.Traveler()
                    {
                        Id = x.Id,
                        Email = x.Email,
                        FullName = x.FullName,
                    }) ?? default!
                });
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
    }
    #endregion
}
