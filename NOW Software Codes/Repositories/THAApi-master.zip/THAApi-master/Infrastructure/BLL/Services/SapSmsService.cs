﻿using Infrastructure.BLL.Implementation;
using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.DAL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.Extensions.Configuration;
using Models.Contracts.Request;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services
{
    public class SapSmsService : ISapSmsService
    {
        private readonly IUserAccount_DL UserAccount_DL;
        private readonly HttpClient SapSmsClient;

        public SapSmsService(
            IUserAccount_DL userAccount_DL,
            HttpClient httpClient)
        {
            UserAccount_DL = userAccount_DL;
            this.SapSmsClient = httpClient;
        }
        public async Task<SmsResult> Send(string from, string to, string message, bool paid, bool isSignupPinSms = false, string language = "en")
        {
            string[] destinations = new string[] { to };
            Sms smsStatus = null;

            string formattedFrom = from;
            string formattedTo = to;

            try
            {
                if (!isSignupPinSms)
                {
                    formattedFrom = ParseNumber(from);
                    if (formattedFrom.ToLower() != "talk home")
                    {
                        formattedTo = PhoneNumberFixer.Fix(formattedTo);
                    }
                }

                //Record our version
                smsStatus = new Sms
                {
                    Provider = Provider.SAP,
                    Sender = formattedFrom,
                    To = formattedTo,
                    Status = Status.Pending,
                    Sent = DateTime.UtcNow,
                    ProviderError = null,
                    ProviderId = null
                };

                int result = await UserAccount_DL.SaveSms(smsStatus);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }


            //Actually send the SMS
            var body = JsonConvert.SerializeObject(new
            {
                destination = destinations,
                origination = from,
                message = message,
                language = language
            }, new JsonSerializerSettings
            {
                ContractResolver = new DefaultContractResolver()
            });


            var requestMessage = new HttpRequestMessage(HttpMethod.Post,
                        $"api/HslSms/SendSms")
            {
                Content = new StringContent(body, Encoding.UTF8, "application/json")
            };

            try
            {
                var result = await SapSmsClient.SendAsync(requestMessage);

                if (result.IsSuccessStatusCode)
                {
                    return SmsResult.Ok(smsStatus.To);
                }
                else
                {
                    return SmsResult.Error(smsStatus.To, SmsErrorCode.ProviderFailure);
                }

            }
            catch (Exception ex)
            {
                return SmsResult.Error(to, SmsErrorCode.Exception, ex.ToString());
            }
        }
        private string ParseNumber(string number)
        {
            var returnNumber = number.Replace("+", "");

            return returnNumber.StartsWith("00") ? returnNumber.Remove(0, 2) : returnNumber;
        }
    }
}
