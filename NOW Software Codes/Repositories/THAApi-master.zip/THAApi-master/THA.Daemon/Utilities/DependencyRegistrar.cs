﻿using Models.Configurations;
using Models.Contracts.Request;

namespace THA.Daemon.Utilities
{
    public static class DependencyRegistrar
    {
        public static void RegisterAppSettingsConfig(this IServiceCollection services, IConfiguration Configuration)
        {
            services.Configure<ConnectionStrings>(Configuration.GetSection("ConnectionStrings"));
            services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));
            services.Configure<ApiConfig>(Configuration.GetSection("ApiConfig"));
            services.Configure<preAuthConfig>(Configuration.GetSection("preAuthConfig"));
            services.Configure<DigitalkConfig>(Configuration.GetSection("Digitalk"));
            services.Configure<PushNotificationApiConfig>(Configuration.GetSection("PushNotificationApiConfig"));
            services.Configure<ForceUpdateConfig>(Configuration.GetSection("ForceUpdateConfig"));
            services.Configure<TwillioConfig>(Configuration.GetSection("Twillio"));
            services.Configure<JwtConfig>(Configuration.GetSection("JWT"));
            services.Configure<VoucherifyConfig>(Configuration.GetSection(VoucherifyConfig.SectionName));
            services.Configure<Pay360Config>(Configuration.GetSection("Pay360"));
            services.Configure<AirShipConfig>(Configuration.GetSection("AirShipConfig"));
            services.Configure<AddressApiConfig>(Configuration.GetSection("AddressApiConfig"));
            services.Configure<PayPalConfig>(Configuration.GetSection("PayPal"));
            services.Configure<CallBackSettings>(Configuration.GetSection(CallBackSettings.SectionName));
            services.Configure<SmtpConfig>(Configuration.GetSection("SmtpConfig"));
            services.Configure<RedirectUrlsConfig>(Configuration.GetSection("RedirectUrlsConfig"));
            services.Configure<AppsFlyerConfig>(Configuration.GetSection("AppsFlyerConfig"));
            services.Configure<FaceBookConfig>(Configuration.GetSection("FaceBookConfig"));
            services.Configure<InAppPageConfig>(Configuration.GetSection("InAppPageConfig"));
            services.Configure<CustomerRatingConfig>(Configuration.GetSection("CustomerRatingConfig"));
            services.Configure<ATTConfig>(Configuration.GetSection(ATTConfig.Section));
            services.Configure<AccountDeleteSettings>(Configuration.GetSection("AccountDeleteSettings"));
        }
    }
}
