﻿using Models.Database;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface ITransaction_DL
    {
        Task SaveTransactionAsync(DBTransferTransaction transaction);
    }
}
