﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models
{
    public class SecureReturnTransferRequest
    {
        [Required]
        [MaxLength(200)]
        public string nowtelRef { get; set; }

        [Required]
        public string product { get; set; }

        [Required]
        public string operatorId { get; set; }

        [Required]
        public string MD { get; set; }
        public bool shouldSave { get; set; }

        //[Required]
        public string PaRes { get; set; }        

        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [EmailAddress(ErrorMessage = "Invalid email")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        public string customerEmail { get; set; }
        public string clientRedirectType { get; set; }
    }
}
