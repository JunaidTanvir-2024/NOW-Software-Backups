﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models.ApiResponse.Users
{
    public class GetUserByIDResponseModel
    {
        public ViewModels.UserViewModel userData { get; set; }
        public IEnumerable<ViewModels.UserAddressViewModel> userAddressList { get; set; }
    }
}