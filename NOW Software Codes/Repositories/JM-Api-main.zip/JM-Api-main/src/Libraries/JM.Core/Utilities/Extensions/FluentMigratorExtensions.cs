using System.Data;

using FluentMigrator.Builders.Create.Table;

using JM.Core.Entities.Common;

namespace JM.Core.Utilities.Extensions;
public static class FluentMigratorExtensions
{
    public static ICreateTableColumnOptionOrForeignKeyCascadeOrWithColumnSyntax ForeignKey<ForeignTable>(this ICreateTableColumnOptionOrWithColumnSyntax column, Rule onDelete = Rule.Cascade) where ForeignTable : IBaseEntity<long>
    {
        var primaryTableName = typeof(ForeignTable).Name;
        var primaryColumnName = nameof(IBaseEntity<long>.Id);
        return column.Indexed().ForeignKey(primaryTableName: primaryTableName, primaryColumnName: primaryColumnName).OnDelete(onDelete);
    }
    public static ICreateTableColumnOptionOrForeignKeyCascadeOrWithColumnSyntax ForeignKey<MainTable, ForeignTable>(this ICreateTableColumnOptionOrWithColumnSyntax column, string schemaName = default!, string customPrimaryColumnName = default!, Rule onDelete = Rule.Cascade) where MainTable : IBaseEntity<long>
    {
        var mainTableName = typeof(MainTable).Name;
        var primaryTableName = GetPrimaryTableName<ForeignTable>();
        var primaryColumnName = nameof(IBaseEntity<long>.Id);
        var foreignKeyName = $"FK_{primaryTableName}_{mainTableName}_{mainTableName}{customPrimaryColumnName ?? nameof(IBaseEntity<long>.Id)}";

        return column.Indexed().ForeignKey(foreignKeyName: foreignKeyName, primaryTableSchema: schemaName, primaryTableName: primaryTableName, primaryColumnName: primaryColumnName).OnDelete(onDelete);
    }

    private static string GetPrimaryTableName<ForeignTable>()
    {
        return typeof(ForeignTable).Name.Replace("Identity", "", StringComparison.OrdinalIgnoreCase);
    }

}
