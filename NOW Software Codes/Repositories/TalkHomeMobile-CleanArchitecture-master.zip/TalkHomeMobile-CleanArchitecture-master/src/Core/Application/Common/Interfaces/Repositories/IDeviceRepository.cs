﻿using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces.Repositories;

public interface IDeviceRepository : IServicesType.IScopedService
{
    /// <summary>
    /// save user device logs
    /// </summary>
    /// <param name="log"></param>
    /// <returns></returns>
    Task SaveDeviceLog(UserDeviceLog log);

    /// <summary>
    /// mark user device as active
    /// </summary>
    /// <param name="deviceId"></param>
    /// <param name="deviceType"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    Task MarkDeviceAsActive(string deviceId, DeviceType deviceType, long userId);

    /// <summary>
    /// save user device and mark as in-active and confirmd
    /// </summary>
    /// <param name="deviceId"></param>
    /// <param name="deviceType"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    Task SaveDeviceAsActiveAndConfirmed(string deviceId, DeviceType deviceType, long userId);

    /// <summary>
    /// save user device and mark as in-active
    /// </summary>
    /// <param name="deviceId"></param>
    /// <param name="deviceType"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    Task SaveUserDeviceAsInActive(string deviceId, DeviceType deviceType, long userId);

    /// <summary>
    /// save user device and mark as current active
    /// </summary>
    /// <param name="token"></param>
    /// <param name="deviceType"></param>
    /// <param name="deviceType"></param>
    /// <returns></returns>
    Task SaveUserDeviceNotificationToken(string token, string deviceId, DeviceType deviceType);

    /// <summary>
    /// Is user using this device for first time
    /// </summary>
    /// <param name="deviceId"></param>
    /// <param name="userId"></param>
    /// <returns>yes or no</returns>
    Task<bool> IsNewDevice(string deviceId, long userId);

    /// <summary>
    /// mark user device as confirmed
    /// </summary>
    /// <param name="deviceId"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    Task MarkDeviceAsConfirmed(string deviceId, long userId);
}
