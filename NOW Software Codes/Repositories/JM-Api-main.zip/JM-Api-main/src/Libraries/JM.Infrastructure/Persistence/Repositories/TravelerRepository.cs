using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.EntityFrameworkCore;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;

public class TravelerRepository(AppDbContext context, ILogger logger) : ITravelerRepository
{
    private readonly AppDbContext _context = context;
    private readonly ILogger _logger = logger;

    public async Task<Traveler> AddTraveler(Traveler trip)
    {
        try
        {
            var addedTraveler = await _context.Set<Traveler>().AddAsync(trip);
            return addedTraveler.Entity;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(TravelerRepository), nameof(AddTraveler));
            return default!;
        }
    }
    public void UpdateTraveler(Traveler trip)
    {
        try
        {
            _context.Entry(trip).CurrentValues.SetValues(trip);
            _context.Entry(trip).State = EntityState.Modified;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(TravelerRepository), nameof(UpdateTraveler));
        }
    }
    public async Task<Traveler?> GetTraveler(Expression<Func<Traveler, bool>> expression)
    {
        try
        {
            return await _context.Set<Traveler>()
                .Where(expression)
                .Include(x => x.Trip)
                .ThenInclude(x => x.Travelers)
                .Include(x => x.User)
                .ThenInclude(x => x.UserDetail)
                .FirstOrDefaultAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(TravelerRepository), nameof(GetTraveler));
            return default!;
        }
    }
    public async Task<IEnumerable<Trip>> GetTravelerList(Expression<Func<Trip, bool>> expression = default!)
    {
        try
        {
            var query = expression is not null ? _context.Set<Trip>().Where(expression) : _context.Set<Trip>();

            return await query
                .Include(x => x.Travelers)
                .ThenInclude(x => x.User)
                .ThenInclude(x => x.UserDetail)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(TravelerRepository), nameof(GetTravelerList));
            return default!;
        }
    }
}
