﻿using Application.Common.Interfaces.Payment;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Bundle.BundleRenewalPaypal;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Bundle.AutoRenewal.Disable;
public class DisableBundleAutoRenewalRequestHandler : IRequestHandler<DisableBundleAutoRenewalRequest, Result<object>>
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;
    private readonly IStringLocalizer<DisableBundleAutoRenewalRequestHandler> _localizer;
    private readonly ICurrentUser _currentUser;
    private readonly IPaymentService _paymentService;
    private readonly IPayPalService _payPalService;

    public DisableBundleAutoRenewalRequestHandler(IUnitOfWork unitOfWork,
        ICommonService commonService,
        IUserService userService,
        IStringLocalizer<DisableBundleAutoRenewalRequestHandler> localizer,
        ICurrentUser currentUser,
        IPaymentService paymentService,
        IPayPalService payPalService)
    {
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _userService = userService;
        _localizer = localizer;
        _currentUser = currentUser;
        _paymentService = paymentService;
        _payPalService = payPalService;
    }
    public async Task<Result<object>> Handle(DisableBundleAutoRenewalRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        //Check if user msisdn
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Get bundle Info
        var bundlesResponse = await _unitOfWork.BundleRepo.GetBundleById(new BundleByIdRequest() { Id = request.BundleId.ToString() });
        if (bundlesResponse == null)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }
        //if (bundlesResponse.Type == (int) BundleType.Rolling)
        //{
        //    return Result<object>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        //}

        var msisdnInfo = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);

        //Get subscribed bundles
        var subscribedBunldes = await _unitOfWork.UserRepo.GetSubscribedBundles(msisdnInfo.AccountId!);
        if (subscribedBunldes.Any())
        {
            if (!subscribedBunldes.Any(x => x.Id.ToString().Equals(bundlesResponse.UuId, StringComparison.InvariantCultureIgnoreCase)))
            {
                return Result<object>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
            }
        }

        //
        var autoRenewalStatus = await _unitOfWork.BundleRepo.GetBundleAutoRenewal(request.Msisdn, msisdnInfo.AccountId!, bundlesResponse.UuId!);
        /*if (autoRenewalStatus.IsRenew == false)
        {
            //Already disabled
            return Result<object>.Success(null, _localizer[CustomStatusKey.Success]);
        }*/
        if ((autoRenewalStatus?.PaymentMethod?.Equals("Paypal", StringComparison.InvariantCultureIgnoreCase) ?? true))
        {
            var paymentRequest = new PaypalSuspendSubscriptionRequest
            {
                SubscriptionId = autoRenewalStatus.InitialTransactionId
            };
            //Stop autotopup
            var paypalSuspendSubscriptionResponse = await _payPalService.PayPalCancelSubscription(paymentRequest);
            if (paypalSuspendSubscriptionResponse != null)
            {
                //disable bundle auto renewal
                await _unitOfWork.BundleRepo.SetBundleAutoRenewal(
                        false,
                        request.Msisdn,
                        msisdnInfo.AccountId!,
                        bundlesResponse.UuId!,
                        _currentUser.GetUserEmail()!,
                        PaymentMethod.Paypal);
                return Result<object>.Success(null, _localizer[CustomStatusKey.Success]);
            }
            else
            {
                return Result<object>.Failure(
                _localizer[CustomStatusKey.SetAutoTopupFailure], CustomStatusCode.InternalServerError);
            }
        }
        else
        {
            //disable bundle auto renewal
            await _unitOfWork.BundleRepo.SetBundleAutoRenewal(
                    false,
                    request.Msisdn,
                    msisdnInfo.AccountId!,
                    bundlesResponse.UuId!,
                    _currentUser.GetUserEmail()!,
                    PaymentMethod.Card);
            var responseModel = new BundleAutoRenewalPaypalResponse();
            return Result<object>.Success(null, _localizer[CustomStatusKey.Success]);
        }
    }
}
