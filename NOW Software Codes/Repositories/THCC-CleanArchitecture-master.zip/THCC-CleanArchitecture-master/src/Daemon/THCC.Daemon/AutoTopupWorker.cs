using THCC.Application.Interfaces.Services;

namespace THCC.Daemon
{
    public class AutoTopupWorker : BackgroundService
    {
        private readonly ILogger<AutoTopupWorker> _logger;
        private readonly IServiceScopeFactory _serviceProvider;

        public AutoTopupWorker(
            ILogger<AutoTopupWorker> logger,
            IServiceScopeFactory serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using var scope = _serviceProvider.CreateScope();
                    var autoTopupService = scope.ServiceProvider.GetRequiredService<IAutoTopupService>();
                    await autoTopupService.StartPay360THRCCAutoTopupJob();
                }
                catch (Exception ex)
                {
                    _logger.LogError("AutoTopupWorker, " +
                                     "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                     "StackTrace: " + ex.StackTrace);
                }
                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
        }
    }
}