﻿using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Identity;

public interface ICurrentUser : ServiceType.IScoped
{
    string GetUserId();
    string GetUserEmail();
    bool IsAuthenticated();
}