﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Response
{
    public class TransactionBalance
    {
        public float initial { get; set; }
        public float transaction { get; set; }
        public float commission { get; set; }
        public float commissionPercentage { get; set; }
        public float final { get; set; }
        public string currency { get; set; }
    }
}
