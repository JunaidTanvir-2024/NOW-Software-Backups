﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.Pay360ApiContracts
{
    public class RemoveCardRequest
    {
        [Required(ErrorMessage = "Select Card")]
        public string cardToken { get; set; }
        public string pay360CustomerID { get; set; }
    }
}
