using Asp.Versioning;

using FH.Api.Controllers.Common;
using FH.UseCases.Categories;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.V1;

[ApiVersion(1.0)]
public sealed class CategoryController : BaseApiController
{
    [HttpPost]
    public async Task<ActionResult> GetSubCategories([FromBody] GetSubCatgories.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}
