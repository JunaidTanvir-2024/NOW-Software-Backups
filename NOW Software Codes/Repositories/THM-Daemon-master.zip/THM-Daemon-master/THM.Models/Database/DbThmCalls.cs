﻿using System;
using System.Collections.Generic;
using System.Text;

namespace THM.Models.Database
{
    public class DbThmCalls
    {
        public long Id { get; set; }
        public string CallingNumber { get; set; }
        public string CalledNumber { get; set; }
        public bool Roaming { get; set; }
    }
}
