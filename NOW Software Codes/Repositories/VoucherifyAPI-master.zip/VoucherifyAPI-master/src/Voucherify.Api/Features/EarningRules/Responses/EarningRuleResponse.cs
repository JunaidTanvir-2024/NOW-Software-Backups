using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.EarningRules.Responses;

public partial class EarningRuleResponse
{
    public string? Id { get; set; }
    public string? ValidationRuleId { get; set; }
    public int LoyaltyPoints { get; set; }
    public string? LoyaltyType { get; set; }
    public string? EventType { get; set; }
    public bool IsActive { get; set; }
    public string? Banner { get; set; }
    public string? CampaignId { get; set; }
    public LoyaltyMetadataInfo? LoyaltyMetadata { get; set; }
    public Metadata? Metadata { get; set; }
    public class LoyaltyMetadataInfo
    {
        public int BasePoints { get; set; }
        public int Base { get; set; }
    }
}
