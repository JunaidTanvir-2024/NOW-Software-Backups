namespace Application.Features.Identity.Signup;

public sealed class UserInfo
{
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public string Email { get; set; } = default!;
    public string Password { get; set; } = default!;
    public string ConfirmPassword { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
    public bool NewsLetter { get; set; }
}