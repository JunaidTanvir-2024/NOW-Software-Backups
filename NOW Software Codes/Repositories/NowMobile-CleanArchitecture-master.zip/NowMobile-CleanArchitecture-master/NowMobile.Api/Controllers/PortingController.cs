using Application.Features.Sim.Porting.CancelPorting;
using Application.Features.Sim.Porting.Models;
using Application.Features.Sim.Porting.PortIn;
using Application.Features.Sim.Porting.Porting;
using Application.Features.Sim.Porting.PortInNew;
using Application.Features.Sim.Porting.PortOut;

namespace NowMobile.Api.Controllers;
[Authorize]
public class PortingController : VersionedApiController
{
    [HttpGet, OpenApiOperation("Get Portings", "")]
    public async Task<IActionResult> GetPortings([FromQuery] PortingRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("PortOut"), OpenApiOperation("Port Out", "")]
    public async Task<IActionResult> PortOut([FromQuery] PortOutRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("PortIn"), OpenApiOperation("Port In", ""),AllowAnonymous]
    public async Task<IActionResult> PortIn([FromQuery] PortInRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("PortInNew"), OpenApiOperation("Port In New", "")]
    public async Task<IActionResult> PortIn([FromQuery] PortInNewRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("CancelPorting"), OpenApiOperation("Cancel Porting", "")]
    public async Task<IActionResult> CancelPorting([FromQuery] CancelPortingRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("SwitchingInfo"), OpenApiOperation("Switching Info", "")]
    public async Task<IActionResult> SwitchingInfo([FromQuery] SwitchingInfoResponse request)
    {
        return Ok(await Mediator.Send(request));
    }
}