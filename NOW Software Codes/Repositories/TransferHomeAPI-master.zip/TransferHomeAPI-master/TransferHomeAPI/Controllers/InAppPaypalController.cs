﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using TransferHome.Infrastructure.BLL.Interfaces;
using TransferHome.Infrastructure.Services.Interfaces;
using TransferHome.Models.Contracts.InAppModels;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.Contracts.Service.PaypalApiContracts;
using TransferHome.Models.DAOs;
using TransferHome.Models.Resources;
using TransferHome.Models.Utility;
using TrasnferHome.Infrastructure.BLL.Interfaces;
using TrasnferHome.Models.Utility;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TransferHomeAPI.Controllers
{
    public class InAppPaypalController : Controller
    {
        private readonly ILogger Logger;
        private readonly IPayPalService PayPalService;
        private readonly IBL_User UserBL;
        private readonly IBL_Transfer TransferBL;
        string ErrorView = string.Format("~/Views/InAppPay360/Error.cshtml");

        public InAppPaypalController(ILogger logger, IPayPalService payPalService, IBL_User userBL, IBL_Transfer transferBL)
        {
            Logger = logger;
            PayPalService = payPalService;
            UserBL = userBL;
            TransferBL = transferBL;
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [Route("paypal/topup")]
        [HttpGet]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<ActionResult> TopUp(InAppPayPalTopUpViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                var userId = Convert.ToInt32(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value);
                var user = await UserBL.GetUserById(userId);
                if (user == null)
                {
                    var message = new InAppMessageViewModel() { Message = "User not found" };
                    return View(ErrorView, message);
                }

                //Validate TopUp Request
                bool isIvalid = await UserBL.IsValidTopUpRequest(user.Id, user.BalanceCurrency, model.Amount);
                if (!isIvalid)
                {
                    var message = new InAppMessageViewModel() { Message = "Your daily topup limit is exceeded" };
                    return View(ErrorView, message);
                }

                var baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                var baskets = new List<ProductBasket>();
                var basket = new ProductBasket()
                {
                    Amount = model.Amount,
                    BundleRef = "",
                    ProductItemCode = ProductItemCode.TRHAT.ToString(),
                    ProductRef = ""
                };

                baskets.Add(basket);

                string uRef = string.IsNullOrEmpty(user.PhoneNumber) ? user.Email : user.PhoneNumber;

                PayPalCreateSalePaymentRequest request = new PayPalCreateSalePaymentRequest
                {
                    CustomerName = string.IsNullOrEmpty(user.FullName) ? string.IsNullOrEmpty(user.PhoneNumber) ? user.Email : user.PhoneNumber : user.FullName,
                    CustomerMsisdn = user.PhoneNumber,
                    CustomerUniqueRef = uRef,
                    CustomerEmail = user.Email,
                    ProductCode = ProductCode.TRH.ToString(),
                    Transaction = new TransferHome.Models.Contracts.Service.PaypalApiContracts.Transactions()
                    {
                        Amount = new TransferHome.Models.Contracts.Service.PaypalApiContracts.Amounts()
                        {
                            Total = model.Amount,
                            Currency = model.Currency
                        },
                        Description = "Create sale payment request from Transfer Home."
                    },
                    RedirectUrl = new RedirectUrls
                    {
                        ReturnUrl = PayPalService.GetResumeUrl("topUpSuccessReturn?currency=" + model.Currency + "&reference=" + uRef + "&amount=" + model.Amount + "&userId=" + userId, baseUrl),
                        CancelUrl = PayPalService.GetResumeUrl("cancelReturn", baseUrl)
                    },
                    Basket = baskets
                };

                var response = await PayPalService.PayPalCreateSalePayment(request);

                if (response == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                if (response.errorCode > 0)
                {
                    var message = new InAppMessageViewModel();
                    message.Message = ErrorMessage(response.errorCode);

                    return View(ErrorView, message);
                }

                return Redirect(response.payload.RedirectUrl);
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPaypalController, Method: TopUp, Parameters=> Model: {model.Amount}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }

        [HttpGet]
        [Route("topUpSuccessReturn")]
        public async Task<ActionResult> TopUpSuccessReturn(SuccessReturnPayPalViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                PayPalExecuteSalePaymentRequest PaymentRequest = new PayPalExecuteSalePaymentRequest
                {
                    CustomerUniqueRef = model.reference,
                    PayerId = model.PayerID,
                    PaymentId = model.paymentId,
                    ProductCode = "TRH"
                };

                var response = await PayPalService.PayPalExecuteSalePayment(PaymentRequest);

                if (response == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                if (response.errorCode > 0)
                {
                    var message = new InAppMessageViewModel();
                    message.Message = ErrorMessage(response.errorCode);

                    Logger.Error($"Controller: InAppPaypalController, Method: TopUpSuccessReturn, Parameters=> Model:{JsonConvert.SerializeObject(model)}, Message: {response.message}");

                    return View(ErrorView, message);
                }
                var creditRequest = new DBCredit()
                {
                    Amount = Convert.ToDecimal(model.amount),
                    Currency = model.currency,
                    type = TopUpType.Paypal,
                    UseId = model.userId,
                    TransactionNumber = response.payload.PaypalTransactionId
                };
                try
                {
                    var creditResponse = await TransferBL.CreditBalance(creditRequest);

                    ViewBag.IsTopUp = true;

                    if (creditResponse > 0)
                    {
                        var user = await UserBL.GetUserById(model.userId);
                        var isFirstTimeTopUp = (await UserBL.GetCreditHistory(new GetCreditHistoryRequestModel { UserId = model.userId })).payload.CreditHistory.Count() == 1 ? true : false;

                        var message = new InAppMessageViewModel() { Message = "Top Up Balance <br/> Successfully" };
                        message.FirebaseTopUpEvent = new FirebaseUserTopUpEventModel { Currency = model.currency, Msisdn = user.PhoneNumber, TopUpAmount = model.amount, TopUpDateTime = DateTime.UtcNow.ToString(), IsFirstTimeTopUp = isFirstTimeTopUp, TopUpBy = TopUpMethod.Paypal.ToString() };

                        return View(string.Format("~/Views/InAppPay360/Success.cshtml"), message);
                    }
                    else
                    {
                        Logger.Error($"Controller: InAppPaypalController, Method: TopUpSuccessReturn, Parameters=> Model:{JsonConvert.SerializeObject(model)}, TransactionId: { response.payload.PaypalTransactionId}, Message: This transaction should be rollback.");

                        var message = new InAppMessageViewModel() { Message = "Sorry, due to some reasons we couldn't top-up your account. Please contact customer service." };
                        return View(ErrorView, message);

                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Controller: InAppPaypalController, Method: TopUpSuccessReturn, Parameters=> Model: {JsonConvert.SerializeObject(creditRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                    var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                    return View(ErrorView, message);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPaypalController, Method: TopUpSuccessReturn, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }


        /// <summary>
        /// Required Bearer
        /// </summary>
        [Route("paypal/transfer")]
        [HttpGet]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<ActionResult> Transfer(PaypalTransferPostModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }
                var userId = Convert.ToInt32(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value);

                var user = await UserBL.GetUserById(userId);
                //validate request 
                int validateResponse = await TransferBL.ValidateTrasnferRequest(user.Id, model.Amount);
                if (validateResponse > 0)
                {
                    var message = new InAppMessageViewModel() { Message = "You have exceeded your daily limit" };
                    return View(ErrorView, message);
                }

                var TransferTransactionDb = await TransferBL.GetTransferTransactionByNowtelTransactionReference(model.nowtelTransactionReference, model.product);
                if (TransferTransactionDb != null)
                {
                    if (model.Currency != TransferTransactionDb.fromCurrency || Convert.ToDecimal(model.Amount) < Convert.ToDecimal(TransferTransactionDb.CustomerChargeValue))
                    {
                        var message = new InAppMessageViewModel() { Message = "Payment amount or currency do not match transfer amount or currency" };
                        return View(ErrorView, message);
                    }
                }
                else
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                

                if (user == null)
                {
                    var message = new InAppMessageViewModel() { Message = "User not found" };
                    return View(ErrorView, message);
                }

                //From Msisdn is replaced with User Phonenumber
                model.fromMSISDN = user.PhoneNumber;

                var baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                var baskets = new List<ProductBasket>();
                var basket = new ProductBasket()
                {
                    Amount = model.Amount,
                    BundleRef = "",
                    ProductItemCode = ProductItemCode.TRHDT.ToString(),
                    ProductRef = ""
                };

                baskets.Add(basket);

                string uRef = string.IsNullOrEmpty(user.PhoneNumber) ? user.Email : user.PhoneNumber;
                PayPalCreateSalePaymentRequest request = new PayPalCreateSalePaymentRequest
                {
                    CustomerName = string.IsNullOrEmpty(user.FullName) ? string.IsNullOrEmpty(user.PhoneNumber) ? user.Email : user.PhoneNumber : user.FullName,
                    CustomerMsisdn = user.PhoneNumber,
                    CustomerUniqueRef = uRef,
                    CustomerEmail = user.Email,
                    ProductCode = ProductCode.TRH.ToString(),
                    Transaction = new TransferHome.Models.Contracts.Service.PaypalApiContracts.Transactions()
                    {
                        Amount = new TransferHome.Models.Contracts.Service.PaypalApiContracts.Amounts()
                        {
                            Total = model.Amount,
                            Currency = model.Currency
                        },
                        Description = "Transfer payment request from Transfer Home."
                    },
                    RedirectUrl = new RedirectUrls
                    {
                        ReturnUrl = PayPalService.GetResumeUrl("transferSuccessReturn?userId=" + userId + "&reference=" + uRef + "&NowtelTransactionRef=" + model.nowtelTransactionReference + "&Product=" + model.product + "&OperatorId=" + model.operatorid + "&MessageToRecipient=" + model.messageToRecipient + "&FromMSISDN=" + model.fromMSISDN, baseUrl),
                        CancelUrl = PayPalService.GetResumeUrl("cancelReturn", baseUrl)
                    },
                    Basket = baskets
                };

                var response = await PayPalService.PayPalCreateSalePayment(request);

                if (response == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                if (response.errorCode > 0)
                {
                    var message = new InAppMessageViewModel();
                    message.Message = ErrorMessage(response.errorCode);

                    return View(ErrorView, message);
                }

                return Redirect(response.payload.RedirectUrl);
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPaypalController, Method: Transfer, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }

        [HttpGet]
        [Route("transferSuccessReturn")]
        public async Task<ActionResult> TransferSuccessReturn(InAppSuccessReturnPayPalTransferViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                PayPalExecuteSalePaymentRequest PaymentRequest = new PayPalExecuteSalePaymentRequest
                {
                    CustomerUniqueRef = model.reference,
                    PayerId = model.PayerID,
                    PaymentId = model.paymentId,
                    ProductCode = "TRH"
                };

                var response = await PayPalService.PayPalExecuteSalePayment(PaymentRequest);

                if (response == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                if (response.errorCode > 0)
                {
                    var message = new InAppMessageViewModel();
                    message.Message = ErrorMessage(response.errorCode);

                    return View(ErrorView, message);
                }

                var request = new ExecuteDirectTransferRequestModel
                {
                    nowtelTransactionReference = model.NowtelTransactionRef,
                    product = model.Product,
                    fromMSISDN = model.FromMSISDN,
                    messageToRecipient = model.MessageToRecipient,
                    operatorid = model.OperatorId,
                    UserId = model.userId,
                    TransactionType = TransferTransactionType.TRHDT,
                    PaymentType = PaymentType.Paypal
                };
                try
                {
                    var transferResponse = await TransferBL.ExecuteDirectTransfer(request);
                    if (transferResponse == null)
                    {
                        var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                        return View(ErrorView, message);
                    }

                    if (transferResponse.errorCode == 0)
                    {
                        ViewBag.IsTopUp = false;

                        var message = new InAppMessageViewModel() { Message = transferResponse.message };
                        message.FirebaseTransferEvent = new FirebaseUserTransferEventModel { TransferAmountCurrency = transferResponse.payload.transferAmountCurrency, Msisdn = model.FromMSISDN, TransferAmount = transferResponse.payload.transferAmount, TransferDateTime = DateTime.UtcNow.ToString(), DestinationNumber = transferResponse.payload.DestinationMsisdn, TransferFrom = TopUpMethod.Paypal.ToString(), DestinationCountry = transferResponse.payload.DestinationCountry, OperatorName = transferResponse.payload.OperatorName };

                        return View(string.Format("~/Views/InAppPay360/Success.cshtml"), message);
                    }
                    else
                    {
                        Logger.Error($"Controller: InAppPaypalController, Method: TransferSuccessReturn, Parameters=> Model :{JsonConvert.SerializeObject(model)}, Message: This transaction should be rollback. { transferResponse.message}");

                        var message = new InAppMessageViewModel();

                        if (transferResponse.errorCode == (int)ApiStatusCodes.TopupNumberLimitExceed
                            || transferResponse.errorCode == (int)ApiStatusCodes.TopupAmountLimitExceed
                            || transferResponse.errorCode == (int)ApiStatusCodes.DenominationBlocked
                            || transferResponse.errorCode == (int)ApiStatusCodes.DenominationsNotAvailable
                            || transferResponse.errorCode == (int)ApiStatusCodes.OperatorBlocked
                            )
                        {
                            message.Message = transferResponse.message + "<br/> Sorry, due to some reasons we couldn't transfer your balance. Please contact customer service.";
                        }
                        else
                        {
                            message.Message = "Sorry, due to some reasons we couldn't transfer your balance. Please contact customer service.";

                        }

                        return View(ErrorView, message);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Controller: InAppPaypalController, Method: TransferSuccessReturn, Parameters=> Model: {JsonConvert.SerializeObject(request)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                    var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                    return View(ErrorView, message);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPaypalController, Method: TransferSuccessReturn, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }

        [HttpGet]
        [Route("cancelReturn")]
        public async Task<ActionResult> CancelReturn(CancelReturnPayPalViewModel model)
        {
            try
            {
                var message = new InAppMessageViewModel() { Message = "PayPal Payment Cancelled" };
                return View(ErrorView, message);
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: TopUpController, Method: CancelReturn, Parameters=> CancelReturnPayPalViewModel: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }

        private string ErrorMessage(int errorCode)
        {
            var ErrorCodes = new int[] { 5, 11, 22, 27 };

            if (ErrorCodes.Contains(errorCode))
            {
                return ApiMessage.ResourceManager.GetString(Enum.GetName(typeof(PaymentAPIStatusCodes), errorCode));
            }
            else
            {
                return "This service is currently unavailable. Please try again later.";
            }
        }
    }
}
