﻿using System.Text.Json.Serialization;
namespace NTCB.Api.Features.DTOne.Models;

public class CreditPartyIdentifierInfo
{
    [JsonPropertyName("mobile_number")]
    public string? MobileNumber { get; set; }
}
