using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.EntityFrameworkCore;

using Serilog;
namespace JM.Infrastructure.Persistence.Repositories;

internal sealed class PlaceRepository(AppDbContext context, ILogger logger) : IPlaceRepository
{
    private readonly AppDbContext _context = context;
    private readonly ILogger _logger = logger;

    public async Task<Place> AddPlace(Place place)
    {
        try
        {
            var addedPlace = await _context.Set<Place>().AddAsync(place);
            return addedPlace.Entity;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(PlaceRepository), nameof(AddPlace));
            return default!;
        }
    }
    public void UpdatePlace(Place place)
    {
        try
        {
            _context.Entry(place).CurrentValues.SetValues(place);
            _context.Entry(place).State = EntityState.Modified;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(PlaceRepository), nameof(UpdatePlace));
        }
    }
    public async Task<Place?> GetPlace(Expression<Func<Place, bool>> expression)
    {
        try
        {
            var place = _context.Set<Place>()
                .Where(expression);

            return await place.FirstOrDefaultAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(PlaceRepository), nameof(GetPlace));
            return default!;
        }
    }
    public async Task<IEnumerable<TripPlace>> GetPlaceList(Expression<Func<TripPlace, bool>> expression = default!)
    {
        try
        {
            var query = _context.Set<TripPlace>().Include(x => x.Place);
            return expression is null ? await query.ToListAsync() : await query.Include(x => x.Trip).Where(expression).ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(PlaceRepository), nameof(GetPlaceList));
            return default!;
        }
    }
    public async Task<IEnumerable<Place>> GetPlaceList(Expression<Func<Place, bool>> expression = default!)
    {
        try
        {
            var query = _context.Set<Place>();
            return expression is null ? await query.ToListAsync() : await query.Where(expression).ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(PlaceRepository), nameof(GetPlaceList));
            return default!;
        }
    }
}
