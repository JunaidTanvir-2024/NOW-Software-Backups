﻿using CallingCode.Mvc.Common.Models;
using CallingCode.Mvc.Common.Services.GeoLocation;
using CallingCode.Mvc.Common.Services.OpenMeteo;
using CallingCode.Mvc.Persistence;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;

namespace CallingCode.Mvc.Controllers;

[Route("~")]
[Route("Country-Codes")]
public class CallingCodesController : Controller
{

    private readonly IOpenMeteoImplementation _openMeteo;
    private readonly IGeoLocation _geoLocation;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public CallingCodesController(IOpenMeteoImplementation openMeteo, IGeoLocation geoLocation, IHttpContextAccessor httpContextAccessor)
    {
        _openMeteo = openMeteo;
        _geoLocation = geoLocation;
        _httpContextAccessor = httpContextAccessor;
    }
    
    [HttpGet]
    [Route("")]
    public IActionResult Index()
    {
        var countries = JsonDataStore.Countries?
            .Where(x => CountriesData.PopularCountries.Contains(x.Name?.Common))
            .OrderBy(x => x.Cca2)
            .ToList();

        return View(countries);
    }

    //[HttpPost]
    //[Route("{countryName}")]
    //public IActionResult CallingCodesByCountry(string countryName)
    //{
    //    // Get the request headers from the HttpContext
    //    var requestHeaders = HttpContext.Request.Headers;
    //    // Set the session variable
    //    //TempData["VisitorDateTime"] = Convert.ToDateTime(requestHeaders["X-Date"]);

    //    return new JsonResult(countryName);
    //}

    [HttpGet]
    [Route("{countryName}-dialing-code")]
    public async Task<IActionResult> CallingCodesByCountrys(string countryName)
    {
        
        if (countryName.Equals("Swaziland", StringComparison.OrdinalIgnoreCase))
        {
            countryName = "Eswatini";
        }

        countryName = countryName.Replace("-", " ");
        var countryCode = JsonDataStore.Countries?.Where(x => x.Name?.Common?.ToLower() == countryName.ToLower()).Select(x => x.Cca3).FirstOrDefault();

        if (countryCode != null)
        {
            var country = JsonDataStore.Countries?.FirstOrDefault(x => x.Cca3 != null && x.Cca3.Equals(countryCode, StringComparison.OrdinalIgnoreCase));
            var countryCallingCode = country.Idd.Root + country.Idd.Suffixes.FirstOrDefault();
            var contentVariation = GetContentVaridation(country.Name.Common, countryCallingCode);

            double latitude = 0;
            double longitude = 0;

            if (country.CapitalInfo.Latlng != null)
            {
                //Replace with capital's latitude
                latitude = country.CapitalInfo.Latlng[0];

                //Replace with capital's longitude
                longitude = country.CapitalInfo.Latlng[1];
            }

            var weatherDetail = await _openMeteo.GetWeatherDetail(latitude, longitude);

            var countryTimeDetail = await _openMeteo.GetCountryTimeDetail(latitude, longitude);

            var location = await _geoLocation.GetGeoInfo(HttpContext);
            var fromCountry = location?.CountryCode != null ? location.CountryCode : "GB";
            var bundleDetails = await _openMeteo.GetBundleDetails(fromCountry, country.Cca2);

            //var visitorDateTime = await _openMeteo.GetVisitorTime(GetIpAddress());
            var visitorDateTime = await _openMeteo.GetVisitorTime("115.186.136.73");

            countryTimeDetail.TimeDifferenceMessage = DateTimeHelper.CalculateTimeDifference(visitorDateTime, countryTimeDetail.DateTime, country.Name.Common, country.Capital!.FirstOrDefault());

            return View("CallingCodesByCountry", new CountryDetail()
            {
                Country = country,
                Weather = weatherDetail,
                CountryTimeZone = countryTimeDetail,
                BundleInfo = bundleDetails,
                ContentVariation = contentVariation,
            });
        }

        return Redirect("/country-codes");
    }

    private static Variation GetContentVaridation(string countryName, string countryCode)
    {
        var result = countryName[0].ToString().ToLower();
        var contentVariationsJson = JsonDataStore.ContentVariations;

        var contentVariations = JsonSerializer.Deserialize<ContentVariations>(contentVariationsJson.Replace("[Country Name]", countryName).Replace("[Country Code]", countryCode));

        var countriesStartWith1 = contentVariations.Variations[0].CountryCodeStartsWith.Split(",");
        var countriesStartWith2 = contentVariations.Variations[1].CountryCodeStartsWith.Split(",");

        Variation? contentVariation = null;
        if (countriesStartWith1.Contains(result) == true)
        {
            contentVariation = contentVariations.Variations[0];
        }
        else if (countriesStartWith2.Contains(result) == true)
        {
            contentVariation = contentVariations.Variations[1];
        }
        else
        {
            contentVariation = contentVariations.Variations[2];
        }
        return contentVariation;
    }

    [HttpGet, Route("Privacy")]
    public IActionResult Privacy()
    {
        return View();
    }

    [HttpGet, Route("Error"), ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    private string GetIpAddress() =>
        Request.Headers.ContainsKey("X-Forwarded-For")
            ? Request.Headers["X-Forwarded-For"]
            : HttpContext.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "N/A";

}

public static class DateTimeHelper
{
    public static string CalculateTimeDifference(DateTimeOffset visitorTime, DateTimeOffset countryTime, string? countryName, string? captialName)
    {


        // Get the server time
        var serverTime = countryTime;

        // Get the visitor time

        // Calculate the time difference in minutes
        var timeDiff = (int) (visitorTime - serverTime).TotalMinutes;
        var absTimeDiff = Math.Abs(timeDiff);

        // Calculate the date difference
        var dateDiff = (visitorTime.Date - serverTime.Date).Days;

        // Calculate the hour and minute differences
        var hourDiff = absTimeDiff / 60;
        var remainingMinutes = absTimeDiff % 60;

        if (remainingMinutes >= 29 && remainingMinutes < 30)
        {
            // If the remaining minutes are 29 or more, increment the hour difference by 1
            remainingMinutes = remainingMinutes + 1;
        }
        if (remainingMinutes >= 59)
        {
            // If the remaining minutes are 29 or more, increment the hour difference by 1
            hourDiff++;
            remainingMinutes = 0;
        }

        // Construct the message based on the time and date difference
        var message = "";
        if (hourDiff >= 1)
        {
            // There is a time difference of at least 1 hour
            message = $"{captialName}, {countryName} is {hourDiff} hour{(hourDiff > 1 ? "s" : "")}";
            if (remainingMinutes > 0)
            {
                message += $", {remainingMinutes} minute{(remainingMinutes > 1 ? "s" : "")}";
            }
            message += $" {(timeDiff >= 0 ? "behind" : "ahead of")} you ({visitorTime:h:mm:ss tt})";
        }
        else if (remainingMinutes == 1)
        {
            // There is a time difference of 1 minute
            message = $"{captialName}, {countryName} is {remainingMinutes} minute {(timeDiff >= 0 ? "behind" : "ahead of")} you ({visitorTime:h:mm:ss tt})";
        }
        else
        {
            // There is a time difference of less than 1 minute
            message = $"{captialName}, {countryName} is {remainingMinutes} minutes {(timeDiff >= 0 ? "behind" : "ahead of")} you ({visitorTime:h:mm:ss tt})";
        }

        return message;
    }
    
}