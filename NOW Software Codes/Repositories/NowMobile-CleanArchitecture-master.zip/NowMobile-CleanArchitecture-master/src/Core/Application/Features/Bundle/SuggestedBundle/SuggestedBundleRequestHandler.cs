﻿using Application.Features.Bundle.Model;
using Application.Features.Bundle.SimBundle;

namespace Application.Features.Bundle.SuggestedBundle;
public class SuggestedBundleRequestHandler : IRequestHandler<SuggestedBundleRequest, Result<List<BundleInfo>>>
{
    #region Fields

    private readonly IUnitOfWork _unitOfWork;
    private readonly IStringLocalizer<SimBundleRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly IUserService _userService;

    #endregion

    #region Ctors

    public SuggestedBundleRequestHandler(
        IUnitOfWork unitOfWork,
        IStringLocalizer<SimBundleRequestHandler> localizer,
        IMapper mapper,
        IUserService userService)
    {
        _unitOfWork = unitOfWork;
        _localizer = localizer;
        _mapper = mapper;
        _userService = userService;
    }

    #endregion

    #region Methods

    public async Task<Result<List<BundleInfo>>> Handle(SuggestedBundleRequest request, CancellationToken cancellationToken)
    {
        if (request.Msisdn != null && !await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<List<BundleInfo>>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var bundles = _mapper.Map<List<BundleInfo>>(await _unitOfWork.BundleRepo.GetSuggestedBundles(request));
        return Result<List<BundleInfo>>.Success(bundles, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
