using FluentValidation;

namespace Voucherify.Api.Features.EarningRules.Requests;

public class GetEarningRuleRequest
{
    public string CampaignNameOrId { get; set; } = null!;
    public string EarningRuleId { get; set; } = null!;
}
internal class GetEarningRuleRequestValidator : AbstractValidator<GetEarningRuleRequest>
{
    public GetEarningRuleRequestValidator()
    {
        RuleFor(p => p.CampaignNameOrId).NotNull().NotEmpty();
        RuleFor(p => p.EarningRuleId).NotNull().NotEmpty();
    }
}