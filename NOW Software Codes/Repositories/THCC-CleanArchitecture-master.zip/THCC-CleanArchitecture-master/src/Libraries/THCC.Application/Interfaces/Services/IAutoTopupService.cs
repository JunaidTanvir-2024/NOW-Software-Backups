﻿using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Services
{
    public interface IAutoTopupService : ServiceType.IScoped
    {
        Task StartPay360THRCCAutoTopupJob();
    }
}
