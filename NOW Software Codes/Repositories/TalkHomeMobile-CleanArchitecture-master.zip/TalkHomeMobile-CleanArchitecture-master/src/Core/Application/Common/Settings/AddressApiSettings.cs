﻿namespace Application.Common.Settings;
public class AddressSettings
{
    public const string SectionName = "AddressSettings";
    public static AddressSettings Bind = new AddressSettings();
    public string? ApiKey { get; set; }
    public string? ApiEndpoint { get; set; }
}
public class DeleteAccountSettings
{
    public const string SectionName = "DeleteAccountSettings";
    public static DeleteAccountSettings Bind = new DeleteAccountSettings();
    public int Limit { get; set; }
    public bool IsValidate { get; set; }
}