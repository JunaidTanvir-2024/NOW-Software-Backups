﻿using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common
{
    public class StackableDiscountCustomerInfo
    {
        public string SourceId { get; set; }
        public Metadata Metadata { get; set; }
    }
}
