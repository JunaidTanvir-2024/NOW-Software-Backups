﻿using Infrastructure.BLL.Interfaces;
using Models.Contracts.Request;
using Newtonsoft.Json;
using Serilog;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Infrastructure.BLL.Implementation
{
    public class Culture_BL : ICulture_BL
    {
        private readonly IDictionary<string, Culture> cultureByCode;
        private readonly IDictionary<string, Culture> cultureByName;

        public Culture_BL(IEnumerable<Culture> cultures)
        {
            cultures = JsonConvert.DeserializeObject<Culture[]>(File.ReadAllText("region.json"));
            var enumerable = cultures as Culture[] ?? cultures.ToArray();
            this.cultureByCode = 
                enumerable.GroupBy(i => i.TwoLetterISORegionName)
                        .Select(i => i.First())
                        .ToDictionary(i => i.TwoLetterISORegionName, i => i);
            this.cultureByName =
                enumerable.GroupBy(i => i.EnglishName)
                        .Select(i => i.First())
                        .ToDictionary(i => i.EnglishName, i => i);
        }

        public string GetCountryName(string countryCode)
        {
            Culture culture;
            if (countryCode.ToLower() == "ph")
            {
                    return "Philippines";
            }
            else if (countryCode.ToLower() == "sl")
            {
                return "Sierra Leone";
            }
            else if (countryCode.ToLower() == "gh")
            {
                return "Ghana";
            }
            else if (countryCode.ToLower() == "ci")
            {
                return "Ivory Coast";
            }
            else if (countryCode.ToLower() == "gn")
            {
                return "Guinea";
            }
            else if (countryCode.ToLower() == "ug")
            {
                return "Uganda";
            }
            else if (countryCode.ToLower() == "cd")
            {
                return "DRC";
            }
            else if (countryCode.ToLower() == "ht")
            {
                return "haiti";
            }
            else if (countryCode.ToLower() == "ml")
            {
                return "Mali";
            }
            else if (countryCode.ToLower() == "cm")
            {
                return "Cameroon";
            }
            else if (countryCode.ToLower() == "eg")
            {
                return "Egypt";
            }
            else if (countryCode.ToLower() == "mu")
            {
                return "Mauritius";
            }
            else if (countryCode.ToLower() == "sn")
            {
                return "Senegal";
            }
            else if (countryCode.ToLower() == "lk")
            {
                return "Sri Lanka";
            }

            else if (countryCode.ToLower() == "cy")
            {
                return "Cyprus";
            } else if (cultureByCode.TryGetValue(countryCode, out culture))
            {
                return culture.EnglishName;
            }

            //logger.Warning("Unknown country code: {CountryCode}", countryCode);
            return null;
        }
        public string GetAlphaTwoCountryCode(string countryName)
        {
            Culture culture;
            if (cultureByName.TryGetValue(countryName, out culture))
            {
                return culture.TwoLetterISORegionName;
            }
            else if(countryName.ToLower() == "sierra leone")
            {
                return "SL";
            }
            else if (countryName.ToLower() == "ghana")
            {
                return "GH";
            }
            else if (countryName.ToLower() == "ivory coast")
            {
                return "CI";
            }
            else if (countryName.ToLower() == "guinea")
            {
                return "GN";
            }
            else if (countryName.ToLower() == "uganda")
            {
                return "UG";
            }
            else if (countryName.ToLower() == "drc")
            {

                return "CD";
            }
            else if (countryName.ToLower() == "haiti")
            {
                return "HT";
            }
            else if (countryName.ToLower() == "mali")
            {
                return "ML";
            }
            else if (countryName.ToLower() == "cameroon")
            {
                return "CM";
            }
            else if (countryName.ToLower() == "egypt")
            {
                return "EG";
            }
            else if (countryName.ToLower() == "mauritius")
            {
                return "MU";
            }
            else if (countryName.ToLower() == "senegal")
            {
                return "SN";
            }
            else if (countryName.ToLower() == "sri lanka")
            {
                return "LK";
            }
            else if (countryName.ToLower() == "cyprus")
            {
                return "CY";
            }else if (countryName.ToLower() == "gambia")
            {
                return "GM";
            }




            return null;
        }
        public string ISOCurrencyCode(string countryCode)
        {
            Culture culture;
            if(!string.IsNullOrEmpty(countryCode) && cultureByCode.TryGetValue(countryCode, out culture))
            {
                return culture.ISOCurrencySymbol;
            }
            else
            {
                return "USD";//Default
            }
            //logger.Warning("Unknown country code: {CountryCode}", countryCode);
        }
    }
}
