﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBTopUpPaymentHistory
    {
        public DateTime TransDate { get; set; }
        public string Amount { get; set; }
        public string Method { get; set; }
        public string Reference { get; set; }
    }
}
