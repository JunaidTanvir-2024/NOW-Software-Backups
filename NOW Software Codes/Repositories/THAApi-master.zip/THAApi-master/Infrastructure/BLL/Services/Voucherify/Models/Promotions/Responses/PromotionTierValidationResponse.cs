using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Responses
{
    public class PromotionTierValidationResponse
    {
        [JsonPropertyName("")]
        public bool IsValid { get; set; }

        [JsonPropertyName("")]
        public string PromotionTierId { get; set; }
    }
}