﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class LoginSignUpByPhoneNumberRequestModel
    {
        public string PhoneNumber { get; set; }
        public string PhoneNumberCountryCode { get; set; }
        public bool? MailSubscription { get; set; }
    }
}
