﻿using Microsoft.AspNetCore.Authorization;
using SC.Core.Features.Products;
using SC.Core.Features.Products.Requests;

using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Controllers.V1;
public class ProductController : BaseApiController
{
    [AllowAnonymous]
    [HttpPost]
    public async Task<ActionResult> GetProducts(GetProductModel Model)
    {
        var result = await Mediator.Send(new GetProductsRequest()
        {
            Page = Model.Page,
            RecordsPerPage = Model.RecordsPerPage,
            Filters = Model.Filters

        });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }



    [AllowAnonymous]
    [HttpPost("ByCategory")]
    public async Task<ActionResult> GetproductsBycategory(GetProductModel Model)
    {
        var result = await Mediator.Send(new GetProductByCategoryRequest()
        {
            Page = Model.Page,
            RecordsPerPage = Model.RecordsPerPage,
            Filters = Model.Filters

        });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }

    [AllowAnonymous]
    [HttpPost("ByOperator")]
    public async Task<ActionResult> GetproductsBycategory(GetProductByOperatorModel Model)
    {
        var result = await Mediator.Send(Model.map());

        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}

