namespace Application.Features.Rate.Model;

public class UkRate
{
    public float Landline { get; set; }
    public float Data { get; set; }
    public float Mobile { get; set; }
    public float Text { get; set; }
}
