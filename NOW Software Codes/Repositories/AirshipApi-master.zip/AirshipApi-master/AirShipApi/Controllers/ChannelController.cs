﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;

namespace AirShipApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ChannelController : ControllerBase
    {

        private readonly ILogger Logger;
        private IChannel_BL ChannelBl;

        public ChannelController(ILogger logger, IChannel_BL channelBl)
        {
            Logger = logger;
            ChannelBl = channelBl;
        }

        [HttpPost]
        [Route("AddChannel")]
        public async Task<IActionResult> AddChannel(AddChannelRequest request)
        {

            try
            {
                var response = await ChannelBl.AddChannel(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: ChannelController, Method: AddChannel, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("AddChannelTags")]
        public async Task<IActionResult> AddChannelTags(AddChannelTagsRequest request)
        {

            try
            {
                var response = await ChannelBl.AddChannelTags(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: ChannelController, Method: AddChannelTags, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("GetChannelById")]
        public async Task<IActionResult> GetChannelById(GetChannelRequest request)
        {

            try
            {
                var response = await ChannelBl.GetChannelById(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: ChannelController, Method: GetChannelById, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<ApiGetChannelByIdResponse>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }
        [HttpPost]
        [Route("GetChannels")]
        public async Task<IActionResult> GetChannels(GetAllChannelsRequest request)
        {

            try
            {
                var response = await ChannelBl.GetChannels(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: ChannelController, Method: GetChannels, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<ApiGetChannelsResponse>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

    }
}