﻿using NowPayGApi.Models.DAOs;
using NowPayGApi.Models.DAOs.Digitalk;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace NowPayGApi.Infrastructure.DAL.Interfaces
{
    public interface IDL_Digitalk
    {
        Task<MobileAccount> GetUserAccount(string msisdn);
        Task<MobileAccount> GetUserAccountByAccountID(string account);
        Task<UserAccountLastTopup> GetLastTopUp(string accountId);
        Task<IEnumerable<Bundle>> GetUserAccountBundles(string accountId);
        Task<DBResultAddBundle> AddBundleViaSimCredit(string account, string bundleId);
        Task<DBResultAddBundle> SetBundleAutoRenewal(bool isAutoRenew, string Msisdn, string account, string bundleId,string ProductCode,string Email,int bundleAmount);


        Task<IEnumerable<DbCallingHistory>> GetCallHistory(string accountId, int pagenumber, int rowsperpage);
        Task<int> GetCallHistoryTotalCount(string accountId);

        Task<IEnumerable<DBSmsHistory>> GetSmsHistory(string accountId, int pagenumber, int rowsperpage);
        Task<int> GetSmsHistoryTotalCount(string accountId);

        Task<int> GetDataHistoryTotalCount(string accountId);
        Task<IEnumerable<DBDataHistory>> GetDataHistory(string accountId, int pagenumber, int rowsperpage);

        Task<int> GetPaymentHistoryTotalCount(string accountId);
        Task<IEnumerable<DBPaymentHistory>> GetPaymentHistory(string accountId, int pagenumber, int rowsperpage);

    }
}
