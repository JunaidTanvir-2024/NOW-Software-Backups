﻿namespace NTCB.Api.Commons.Definations;

public class NTCBEnums
{

}
