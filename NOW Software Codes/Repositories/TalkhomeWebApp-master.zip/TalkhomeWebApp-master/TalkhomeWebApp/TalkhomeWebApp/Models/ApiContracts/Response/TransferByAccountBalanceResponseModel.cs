﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class TransferByAccountBalanceResponseModel
    {
        public decimal RemainingBalance { get; set; }
        public TransferData TransferData { get; set; }
        public string UserCurrencySymbol { get; set; }
    }
}
