﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayG.Models.ApiContracts.Response
{
    public class GetUserSummaryResponseModel
    {
        public MobileAccountResponseModel MobileAccount { get; set; }
        public IEnumerable<BundleResponseModel> BundleList { get; set; }
        public UserAccountLastTopupResponseModel LastTopUp { get; set; }

        public IEnumerable<CallingHistoryResponseModel> CallingHistory { get; set; }
        public int CallingHisotryTotalRecords { get; set; }
    }
}
