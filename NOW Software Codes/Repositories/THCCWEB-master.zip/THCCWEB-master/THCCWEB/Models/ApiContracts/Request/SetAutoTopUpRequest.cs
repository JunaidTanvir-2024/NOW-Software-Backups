﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request
{
    public class SetAutoTopUpRequest
    {
        public string productRef { get; set; }
        public string productCode { get; set; }
        public string productItemCode { get; set; }
        public decimal thresholdBalanceAmount { get; set; }
        public bool isAutoTopup { get; set; }
        public decimal topupAmount { get; set; }
        public string topupCurrency { get; set; }
        public string Email { get; set; }
    }
}
