﻿
using SC.Core.Common.Interfaces.Services;

namespace SC.Core.Features.Users;
internal class UserLoginLogHandler : IRequestHandler<UserLoginLogRequest, IResultWrapper>
{
    private readonly IUserRepository _userRepository;

    public UserLoginLogHandler(
      IUserRepository IUserRepository)
    {
        _userRepository = IUserRepository;
    }
    public async Task<IResultWrapper> Handle(UserLoginLogRequest request, CancellationToken cancellationToken)
    {
        await _userRepository.UserSignInLogInsertAsync(new LoginLogDto()
        {
            UserID = request.UserID,
            LoginTime = request.LoginTime,
            DeviceInfo = request.DeviceInfo,
            Refresh_Token = request.Refresh_Token,
            Refresh_Token_Expiry = request.Refresh_Token_Expiry,
            IsSuccessLogin = request.IsSuccessLogin
        });
        return ResultWrapper.Success(Unit.Value);
    }
}

