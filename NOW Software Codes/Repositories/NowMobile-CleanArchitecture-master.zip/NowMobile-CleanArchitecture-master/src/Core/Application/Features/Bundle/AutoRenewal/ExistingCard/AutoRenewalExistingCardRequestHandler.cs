using Application.Common.Interfaces.Payment;
using Application.Features.Payment.Card.ExistingCardPayment;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;

namespace Application.Features.Bundle.AutoRenewal.ExistingCard;

public class AutoRenewalExistingCardRequestHandler : IRequestHandler<AutoRenewalExistingCardRequest, Result<CardResponse>>
{
    private readonly IStringLocalizer<AutoRenewalExistingCardRequestHandler> _localizer;
    private readonly IPaymentService _paymentService;
    private readonly ICurrentUser _currentUser;
    private readonly ICardService _cardService;
    private readonly IMapper _mapper;

    public AutoRenewalExistingCardRequestHandler(
        IStringLocalizer<AutoRenewalExistingCardRequestHandler> localizer,
        IPaymentService paymentService,
        ICurrentUser currentUser,
        ICardService cardService,
        IMapper mapper)
    {
        _localizer = localizer;
        _paymentService = paymentService;
        _currentUser = currentUser;
        _cardService = cardService;
        _mapper = mapper;
    }
    public async Task<Result<CardResponse>> Handle(AutoRenewalExistingCardRequest request, CancellationToken cancellationToken)
    {
        string existigCardNumber, cardScheme;

        //Check if card is user own card
        var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
        if (cards == null || cards != null &&
            !cards.Any(x => x.CardToken.Equals(
                request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)))
        {
            return Result<CardResponse>.Failure(
                _localizer[CustomStatusKey.InvalidPaymentCard], CustomStatusCode.InvalidPaymentCard);
        }

        existigCardNumber = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).MaskedPan;

        cardScheme = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).CardScheme;


        var bundleInfo = _mapper.Map<PaymentBundleInfo>(request);
        return await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: null!,
            paymentExistingCardInfo: request.PaymentCardInfo,
            paymentAddressInfo: null,
            topupInfo: null!,
            bundleInfo: bundleInfo,
            creditSimInfo: null!,
            msisdn: request.Msisdn,
            email: _currentUser.GetUserEmail()!,
            ipAddress: request.IpAddress,
            cardMaskedPan: existigCardNumber!,
            cardScheme: cardScheme!,
            isAuthorizeOnly: true
            );
    }
}