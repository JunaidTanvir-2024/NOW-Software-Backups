﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.Dtos
{
  

    public class GetFaqsbyOperatorDto
    {
        public sealed record Request
        {
            public string? OperatorShortCode { get; set; }
            public bool IsActive { get; set; }
            public bool IsDeleted { get; set; }
            public int Page { get; set; }
            public int RecordsPerPage { get; set; }

       
        }

        public sealed record Response
        {
            public int OperatorFaqId { get; set; }
            public int OperatorId { get; set; }
            public int FaqId { get; set; }
            public string? Question { get; set; }
            public string? Answer { get; set; }
        }
    }
}
