﻿namespace Now.Models.Database;

public class DbAddBundleOrTopupResult
{
    public string? Audit_id { get; set; }
    public string? BundleName { get; set; }
}
