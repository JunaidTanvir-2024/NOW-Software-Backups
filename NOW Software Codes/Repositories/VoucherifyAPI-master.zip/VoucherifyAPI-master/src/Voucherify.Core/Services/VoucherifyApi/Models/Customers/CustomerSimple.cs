using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Customers;

public class CustomerSimple
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("source_id")]
    public string? SourceId { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("email")]
    public string? Email { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}
