﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Services.Interfaces;
using ThmApi.Filters;

namespace TalkhomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommonController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly ICommonService _commonService;

        public CommonController(
            ILogger logger,
            ICommonService commonService)
        {
            _logger = logger;
            _commonService = commonService;
        }

        [HttpGet]
        [Route("GetAddressByPostCode")]
        [BasicAuth]
        public async Task<IActionResult> GetAddressByPostCode([FromQuery]GetAddressByPostCodeRequestModel model)
        {
            try
            {
                return Ok(await _commonService.GetAddressByPostCode(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: CommonController, Method: GetAddressByPostCode, " +
                              $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                              $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }



    }
}