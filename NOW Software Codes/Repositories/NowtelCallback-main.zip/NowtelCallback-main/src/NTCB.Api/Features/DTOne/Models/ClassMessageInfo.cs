﻿using System.Text.Json.Serialization;
namespace NTCB.Api.Features.DTOne.Models;


public class ClassMessageInfo
{
    [JsonPropertyName("id")]
    public int? Id { get; set; }
    
    [JsonPropertyName("message")]
    public string? Message { get; set; }
}
