﻿using Application.Features.Payment.Card.Models;

namespace Application.Features.Payment.Card.Resume3d;

public class Resume3dRequest : IRequest<Result<CardResponse>>
{
    public string MD { get; set; } = default!;
    public int OrderId { get; set; } = default!;
    public bool IsAuthorizeOnly { get; set; } = false;
    public bool IsFastTopup { get; set; } = false;
}