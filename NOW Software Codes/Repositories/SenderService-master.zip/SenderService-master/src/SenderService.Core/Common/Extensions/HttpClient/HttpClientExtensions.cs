namespace SenderService.Core.Common.Extensions.HttpClient;

public static class HttpClientExtensions
{
    public static HttpRequestBuilder CreateRequest(this IHttpClientFactory httpClientFactory, HttpMethod method, string url)
    {
        return new HttpRequestBuilder(method, url, httpClientFactory);
    }
}
