using JM.Api;

using Serilog;

InitializeLogger();

Log.Information("Journey Mingle Booting Up..");
try
{
    var builder = WebApplication.CreateBuilder(args);
    {
        builder.Host.UseSerilog((hostingContext, config) => config.ReadFrom.Configuration(hostingContext.Configuration));
        builder.Services.AddApiDependencies(builder.Configuration);
    }
    var app = builder.Build();
    {
        app.AddApiMiddlewares(builder.Configuration);
        app.Run();
    }
}
catch (Exception ex) when (!ex.GetType().Name.Equals("StopTheHostException", StringComparison.Ordinal))
{
    InitializeLogger();
    Log.Error("Journey Mingle Shutting down...");
    Log.Fatal(ex, "Unhandled exception");
    throw;
}
finally
{
    InitializeLogger();
    Log.Error("Journey Mingle Shutting down...");
    Log.CloseAndFlush();
}

static void InitializeLogger()
{
    if (Log.Logger is not Serilog.Core.Logger)
    {
        Log.Logger = new LoggerConfiguration().WriteTo.Console().CreateLogger();
    }
}
