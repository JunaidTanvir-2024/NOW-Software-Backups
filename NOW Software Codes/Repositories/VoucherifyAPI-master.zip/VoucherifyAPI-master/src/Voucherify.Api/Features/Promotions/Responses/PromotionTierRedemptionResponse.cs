using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

namespace Voucherify.Api.Features.Promotions.Responses;

public class PromotionTierRedemptionResponse
{
    public string? Id { get; set; }
    public bool RedemptionStatus { get; set; }
    public DateTime? RedemptionDate { get; set; }
    public Metadata? CustomerMetadata { get; set; }
    public string? SourceId { get; set; }
    public string? CustomerId { get; set; }
    public Voucher? Voucher { get; set; }
}
