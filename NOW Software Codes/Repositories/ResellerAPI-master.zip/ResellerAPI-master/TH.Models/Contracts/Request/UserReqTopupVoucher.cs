﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TH.Models.Contracts.Request
{
    public class UserReqTopupVoucher
    {
        [Required]
        [JsonProperty("msisdn")]
        public string msisdn { get; set; }

        [Required]
        [JsonProperty("pin")]
        public string pin { get; set; }

    }
}
