﻿using Dapper;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using THM.Models.Configurations;
using THM.Models.Database;
using THM.Models.DbConnections;

namespace THM.Infrastructure.DAL
{
    public interface IAirship_DL
    {
        Task<(IEnumerable<DbThmCalls> numbers, int TotalRecords)> GetCallRecords();
        Task<IEnumerable<DbThmSims>> GetSimRecords();
        Task<string> IsNumberExistsInTHM(string msisdn);
        Task MarkMsisdnAsProcessed(long Id);
    }

    public class Airship_DL : IAirship_DL
    {
        private readonly IDbConnectionSettings _THMGeneral_Db;
        private readonly IDbConnectionSettings _THM_Db;
        private readonly IDbConnectionSettings _THMDigitalk_Db;

        public Airship_DL(IOptions<ConnectionStrings> connectionString)
        {
            _THMGeneral_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.THMGeneral));
            _THM_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.THWEbConnection));
            _THMDigitalk_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigiTalkNowMobileConnection));
        }

        public async Task<(IEnumerable<DbThmCalls> numbers, int TotalRecords)> GetCallRecords()
        {
            var parameters = new DynamicParameters();
            parameters.Add("@TotalRecords", dbType: DbType.Int32, direction: ParameterDirection.Output);

            var response = await _THMGeneral_Db.SqlConnection.QueryAsync<DbThmCalls>("thm_airship_getCallRecords", parameters, commandType: CommandType.StoredProcedure);

            var totalRecords = parameters.Get<int>("@TotalRecords");

            return (response, totalRecords);
        }
        public async Task<string> IsNumberExistsInTHM(string msisdn)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Msisdn", msisdn);

            return await _THM_Db.SqlConnection.ExecuteScalarAsync<string>("thm_revamp_isNumberExists", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task MarkMsisdnAsProcessed(long Id)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Id", Id);

            await _THMGeneral_Db.SqlConnection.ExecuteAsync("thm_airship_markNumberAsProcessed", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<IEnumerable<DbThmSims>> GetSimRecords()
        {
            return await _THMDigitalk_Db.SqlConnection.QueryAsync<DbThmSims>("thm_getUpdatedSims", commandType: CommandType.StoredProcedure);
        }
    }
}
