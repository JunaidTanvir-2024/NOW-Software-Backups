﻿namespace Application.Features.Account.Product.Update;
public class UpdateProductRequest : IRequest<Result<object>>
{
    public int ProductId { get; set; }
    //public string Alias { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
}