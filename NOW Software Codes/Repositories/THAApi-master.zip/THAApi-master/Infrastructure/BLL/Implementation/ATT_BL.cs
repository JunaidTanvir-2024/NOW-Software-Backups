﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.BLL.Services.Voucherify.Models.MetadataModels;
using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common;
using Infrastructure.DAL.Implementation;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using MimeKit;
using Models.Configurations;
using Models.Constants;
using Models.Contracts.Request;
using Models.Contracts.Request.Voucherify;
using Models.Contracts.Response;
using Models.Database;
using Models.Enums;
using Models.Services.Airship;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class ATT_BL : IATT_BL
    {
        private readonly IUserAccount_DL _userAccountRepo;
        private readonly IUserAccount_BL _userAccountBL;
        private readonly IATT_DL _attRepo;
        private readonly IStringLocalizer _localizer;
        private readonly IATTService _aTTService;
        private readonly IAirShipService _airShipService;
        private readonly IFaceBookService _faceBookService;
        private readonly IAppsFlyerService _appsFlyerService;
        private readonly IHelper_BL _helperService;
        private readonly ILogger _logger;
        private readonly IEmailService _emailService;
        private readonly IVoucherify_BL _voucherifyService;
		private readonly IInternationalTopupServiceFeeCalculator _internationalTopupServiceFeeCalculator;
		private readonly Pay360Config _pay360Config;
        private readonly VoucherifyConfig _voucherifyConfig;

        public ATT_BL(
            IATT_DL aTT_DL,
            IUserAccount_BL userAccount_BL,
            IUserAccount_DL userAccount_DL,
            IStringLocalizer localizer,
            IATTService attService,
            IAirShipService airShipService,
            IFaceBookService faceBookService,
            IAppsFlyerService appsFlyerService,
            IHelper_BL helpService,
            ILogger logger,
            IEmailService emailService,
            IVoucherify_BL voucherify_BL,
            IOptions<VoucherifyConfig> options,
            IOptions<Pay360Config> pay360Config,
            IInternationalTopupServiceFeeCalculator internationalTopupServiceFeeCalculator)
        {
            _userAccountRepo = userAccount_DL;
            _userAccountBL = userAccount_BL;
            _attRepo = aTT_DL;
            _localizer = localizer;
            _aTTService = attService;
            _airShipService = airShipService;
            _faceBookService = faceBookService;
            _appsFlyerService = appsFlyerService;
            _helperService = helpService;
            _logger = logger;
            _emailService = emailService;
            _voucherifyService = voucherify_BL;
			this._internationalTopupServiceFeeCalculator = internationalTopupServiceFeeCalculator;
			_pay360Config = pay360Config.Value;
            _voucherifyConfig = options.Value;
        }
        public async Task<GenericApiResponse<ProductsForTransactionOutputArray>> GetProductsNew(UserAccountBalance userAccount, string destination, string clientMSISDN, string sendTopupDescription)
        {
            string account = "GBP";
            if (userAccount != null && userAccount != null && !string.IsNullOrEmpty(userAccount.Currency))
            {
                account = userAccount.Currency.ToUpper();
            }
            var pArray = new ProductsForTransactionOutputArray
            {
                Operators = new List<ProductsForTransactionOutput>()
            };

            pArray.SendTopupPopup = new PopupInfo()
            {
                Description = sendTopupDescription,
                Heading = _localizer["AirTimeHeading"]
            };

            var result = await _aTTService.GetProductsAsync(account, destination, clientMSISDN);
            if (result == null || result.payload == null)
            {
                _logger.Warning($"Class: GetProductsNew, Method:GetProductsNew, Message:No products availalbe for this destination, Destination:{destination}, clientMSISDN:{clientMSISDN}");
                return GenericApiResponse<ProductsForTransactionOutputArray>.Failure(_localizer["NoProductAvailableForDestination"], ApiStatusCodes.UnSuccessful);
            }
            var airpayload = result.payload;
            foreach (operators airop in airpayload.operators)
            {
                var t2product = new ProductsForTransactionOutput
                {
                    Id = int.Parse(airop.id),
                    IconUri = airop.iconUri,
                    Country = airop.country,
                    Name = airop.name,
                    NowtelTransactionReference = airop.nowtelTransactionReference,
                    Products = new List<ProductsForTransactionRow>()
                };

                foreach (Product airpro in airop.products)
                {
                    var productrow = new ProductsForTransactionRow
                    {
                        Clientccy = airpro.clientccy,
                        ItemPriceClientccy = airpro.itemPriceClientccy,
                        Product = airpro.product,
                        Receiverccy = airpro.receiverccy,
                        TotalPriceClientccy = airpro.totalPriceClientccy,
                        TransactionfeeClientccy = airpro.transactionfeeClientccy
                    };
                    t2product.Products.Add(productrow);
                }
                pArray.Operators.Add(t2product);
            }

            return GenericApiResponse<ProductsForTransactionOutputArray>.Success(pArray, "Operators found");
        }
        public async Task<GenericApiResponse<AirtimeTransferExecute>> ExecuteTransactionByBalance(TransFerTotransferConfirm request, string fromMsisdn)
        {
            var executeres = new GenericApiResponse<AirtimeTransferExecute>();

            var userAccount = await _userAccountBL.GetATTUserAccountWithoutCaching(fromMsisdn);


            //Get Product Info
            var product = await _attRepo.GetProductByNowtelTransactionReference(
                                        request.nowtelTransactionReference, request.product);
            var custCharge = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture);

            string msisdndestination = _helperService.GetCountryCode(product.tomsisdn);
            string msisdnorigination = _helperService.GetCountryCode(product.fromMsisdn);

            DeviceType deviceType = (DeviceType)request.DeviceType;

            var validate = await _attRepo.ValidateNowtelReferenceNew(request.nowtelTransactionReference, request.product);
            if (validate == null)
            {
                executeres.Status = "Failure";
                executeres.Message = _localizer["NoProductAvailableForDestination"];
                _logger.Warning($"Class: ATT_BL, Method: ExecuteTransactionByBalance, Message: No product available for this destination, NowtelTransactionReference: {request.nowtelTransactionReference}, FromMsisdn: {fromMsisdn}, Operator: {request.operatorid}, Product: {request.product}");
                return executeres;
            }

            var custValidate = await _attRepo.ValidateNowtelCustomerNew(fromMsisdn, request.nowtelTransactionReference, request.product, validate.transferAmount);

            if (custValidate.isAllowed != 1)
            {
                executeres.Status = "Failure";
                executeres.Message = _localizer["BalanceTransferFailed"];
                _logger.Warning($"Class: ATT_BL, Method: ExecuteTransactionByBalance,Message: Balance transfer failed. customer not allowed , NowtelTransactionReference: {request.nowtelTransactionReference}, FromMsisdn: {fromMsisdn}, Operator: {request.operatorid}, Product: {request.product}, ErrorCode: {custValidate.errorCode}, ErrorMessage: {custValidate.Message}");
                return executeres;
            }

            if (decimal.Parse(userAccount.UserAccountBalance.Balance, CultureInfo.InvariantCulture) < validate.transferAmount)
            {
                //Handle Airship tags and events
                await _airShipService.HandleIntTopupTagsAndEvents(
                      new IntTopupInfoAirShip()
                      {
                          Destination = msisdndestination,
                          IsCard = null,
                          IsSuccess = false,
                          Msisdn = fromMsisdn,
                          Origination = msisdnorigination,
                          Amount = custCharge,
                          IsTransferRequest = request.IsTransferRequest
                      });

                // Handle FaceBook Events
                await _faceBookService.HandleIntTopupEvents(request.advertiserID, msisdnorigination, msisdndestination, false, null, custCharge, request.IsTransferRequest);

                // Handle AppsFlyer Events
                await _appsFlyerService.HandleIntTopupEvents(request.AppsFlyerId, deviceType, msisdnorigination, msisdndestination, false, null, custCharge, ipAddress: null, request.IsTransferRequest);

                executeres.Status = "Failure";
                executeres.Message = _localizer["InsufficientBalance"];

                return executeres;
            }

            var result = await _aTTService.TransferBalance(request, fromMsisdn);
            if (result == null)
            {
                executeres.Status = "Failure";
                executeres.Message = _localizer["BalanceTransferFailed"];
                return executeres;
            }


            if (result.errorCode == 0
                && result.status.Equals("success", StringComparison.InvariantCultureIgnoreCase))
            {
                var debitResp = await _userAccountRepo.DebitAccountBalance(
                       userAccount.AccountID,
                       validate.transferAmount,
                       request.nowtelTransactionReference,
                       result.reference);



                //Handle Airship tags and events
                await _airShipService.HandleIntTopupTagsAndEvents(
                      new IntTopupInfoAirShip()
                      {
                          Destination = msisdndestination,
                          IsCard = null,
                          IsSuccess = true,
                          Msisdn = fromMsisdn,
                          Origination = msisdnorigination,
                          Amount = custCharge,
                          IsTransferRequest = request.IsTransferRequest
                      });

                // Handle FaceBook Events
                await _faceBookService.HandleIntTopupEvents(request.advertiserID, msisdnorigination, msisdndestination, true, null, custCharge, request.IsTransferRequest);

                // Handle AppsFlyer Events
                await _appsFlyerService.HandleIntTopupEvents(request.AppsFlyerId, deviceType, msisdnorigination, msisdndestination, true, null, custCharge, ipAddress: null, request.IsTransferRequest);

                //Save ATT transaction
                await _attRepo.SaveTransactionAsync(
                    new DBTransferTransaction()
                    {
                        AccountId = userAccount.AccountID,
                        ClientCurrecny = product.fromCurrency,
                        CountryCode = _helperService.GetCountryCode(product.tomsisdn),
                        FromMsisdn = product.fromMsisdn,
                        ToMsisdn = product.tomsisdn,
                        ItemPrice = custCharge,
                        TotalPrice = custCharge,
                        Discount = 0,
                        DiscountCode = null,
                        DiscountCodeType = null,
                        NowtelRef = request.nowtelTransactionReference,
                        OperatorCountryName = product.operatorCountryName,
                        OperatorLogoUrl = product.operatorLogoUrl,
                        OperatorName = product.operatorName,
                        PaymentErrorMsg = null,
                        TransferErrorMsg = null,
                        PaymentRef = debitResp?.audit_id,
                        TransferRef = result.reference,
                        PaymentTypeId = InternationalTopupPaymentType.AccountBalance,
                        StatusId = TransferTransactionStatus.Success,
                        Product = Convert.ToDecimal(request.product, CultureInfo.InvariantCulture),
                        ReceiverCurrecny = product.toCurrency
                    });

                var userProfile = await _userAccountRepo.GetUserProfile(fromMsisdn);
                if (!string.IsNullOrEmpty(userProfile?.Data?.email))
                    await SendInternationalTopupPaymentReceiptAsync(userProfile.Data.email, product, userProfile.Data, "Account Balance",decimal.Zero,0,string.Empty,0,result.reference,result.pinCode);//result.reference contains the transaction id

                executeres.Status = "Success";
                executeres.Message = _localizer["BalanceTransferSuccessful"];
                executeres.Payload = result;
            }
            else
            {
                await _airShipService.HandleIntTopupTagsAndEvents(
                      new IntTopupInfoAirShip()
                      {
                          Destination = msisdndestination,
                          IsCard = null,
                          IsSuccess = false,
                          Msisdn = fromMsisdn,
                          Origination = msisdnorigination,
                          Amount = custCharge,
                          IsTransferRequest = request.IsTransferRequest
                      });


                // Handle FaceBook Events
                await _faceBookService.HandleIntTopupEvents(request.advertiserID, msisdnorigination, msisdndestination, false, null, custCharge, request.IsTransferRequest);

                // Handle AppsFlyer Events
                await _appsFlyerService.HandleIntTopupEvents(request.AppsFlyerId, deviceType, msisdnorigination, msisdndestination, false, null, custCharge, ipAddress: null, request.IsTransferRequest);

                //Save ATT transaction
                await _attRepo.SaveTransactionAsync(
                    new DBTransferTransaction()
                    {
                        AccountId = userAccount.AccountID,
                        ClientCurrecny = product.fromCurrency,
                        CountryCode = _helperService.GetCountryCode(product.tomsisdn),
                        FromMsisdn = product.fromMsisdn,
                        ToMsisdn = product.tomsisdn,
                        ItemPrice = custCharge,
                        TotalPrice = custCharge,
                        Discount = 0,
                        DiscountCode = null,
                        DiscountCodeType = null,
                        NowtelRef = request.nowtelTransactionReference,
                        OperatorCountryName = product.operatorCountryName,
                        OperatorLogoUrl = product.operatorLogoUrl,
                        OperatorName = product.operatorName,
                        PaymentErrorMsg = null,
                        TransferErrorMsg = result == null ? "Transfer service not responding" : result?.message,
                        PaymentRef = null,
                        TransferRef = null,
                        PaymentTypeId = InternationalTopupPaymentType.AccountBalance,
                        StatusId = TransferTransactionStatus.Failure,
                        Product = Convert.ToDecimal(request.product, CultureInfo.InvariantCulture),
                        ReceiverCurrecny = product.toCurrency
                    });

                executeres.Status = "Failure";
                executeres.Message = _localizer["BalanceTransferFailed"];
                executeres.Payload = result;
                _logger.Warning($"Class: ATT_BL, Method:ExecuteTransactionByBalance, Message: Balance transfer failed, FromMsisdn:{fromMsisdn}, NowTelTransactionRef:{request.nowtelTransactionReference}, Operator:{request.operatorid}, Product:{request.product}, ErrorCode:{result.errorCode}, ErrorMessage:{result.message}");
            }

            return executeres;
        }

        public async Task<GenericApiResponse<AirtimeTransferExecute>> ExecuteTransactionByBalanceV2(TransFerTotransferConfirmV2 request, string fromMsisdn)
        {
            _logger.Information("started");
            var executeres = new GenericApiResponse<AirtimeTransferExecute>();
            string voucherifyCampaignName = string.Empty;
            var userAccount = await _userAccountBL.GetATTUserAccountWithoutCaching(fromMsisdn);
            var transaction = await _attRepo.GetTransactionLog(request.nowtelTransactionReference, request.product);
            if(transaction is null)
            {
                transaction =await PrepareTransactionLogAsync(request.nowtelTransactionReference, request.product);
                await _attRepo.CreateTransactionLogAsync(transaction);
            }
            var isFirstInternationalTopup = await IsFirstInternationalTopup(userAccount.AccountID);
            var hasUserDoneTransaction = await _userAccountRepo.IsNewUser(fromMsisdn);
            var isFirstTopup = await _userAccountRepo.IsFirstTopUp(fromMsisdn);

            GenericApiResponse<StackableDiscountResponse> redemptionResult = null;

            //Get Product Info
            var product = await _attRepo.GetProductByNowtelTransactionReference(
                                        request.nowtelTransactionReference, request.product);

			var custCharge = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture);
            var productAmount = decimal.Parse(product.fromAmount, CultureInfo.InvariantCulture);
            string msisdndestination = _helperService.GetCountryCode(product.tomsisdn);
            string msisdnorigination = _helperService.GetCountryCode(product.fromMsisdn);
            //calculate service fee
			(decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(msisdnorigination, msisdndestination, product.fromCurrency, productAmount);
            custCharge += totalServiceFee;
            var discountAmount = decimal.Zero;

            DeviceType deviceType = (DeviceType)request.DeviceType;

            var validate = await _attRepo.ValidateNowtelReferenceNew(request.nowtelTransactionReference, request.product);
            if (validate == null)
            {
                executeres.Status = "Failure";
                executeres.Message = _localizer["NoProductAvailableForDestination"];
                _logger.Warning($"Class: ATT_BL, Method: ExecuteTransactionByBalance, Message: No product available for this destination, NowtelTransactionReference: {request.nowtelTransactionReference}, FromMsisdn: {fromMsisdn}, Operator: {request.operatorid}, Product: {request.product}");
                PrepareUpdateTransactionLog(transaction, discountAmount, 2, "No product available for this destination");
                await _attRepo.UpdateTransactionLog(transaction);
                return executeres;
            }
            var custValidate = await _attRepo.ValidateNowtelCustomerNew(fromMsisdn, request.nowtelTransactionReference, request.product, validate.transferAmount);
            if (custValidate.isAllowed != 1)
            {
                executeres.Status = "Failure";
                executeres.Message = _localizer["BalanceTransferFailed"];
                _logger.Debug($"Class: ATT_BL, Method: ExecuteTransactionByBalance,Message: Balance transfer failed. customer not allowed , NowtelTransactionReference: {request.nowtelTransactionReference}, FromMsisdn: {fromMsisdn}, Operator: {request.operatorid}, Product: {request.product}, ErrorCode: {custValidate.errorCode}, ErrorMessage: {custValidate.Message}");
				PrepareUpdateTransactionLog(transaction, discountAmount, 2, "Balance transfer failed. customer not allowed");
				await _attRepo.UpdateTransactionLog(transaction);
				return executeres;
            }

            if (!string.IsNullOrEmpty(request.DiscountCode))
            {
                var discountRequest = new StackableDiscountRequest
                {
                    Amount = custCharge,
                    CheckoutType = CheckOutTypes.Transfer,
                    DiscountCode = request.DiscountCode,
                    DiscountCodeType = request.DiscountCodeType,
                    PaymentMethod = PaymentMethods.Balance,
                    Operator = product.operatorName,
                    DestinationCountryISOCode = msisdndestination,
                };
                var customerMetaData = new CustomerMetadata()
                {
                    FirstInternationalTopup = isFirstInternationalTopup,
                    FirstTopup = isFirstTopup,
                    TransactionDone = !hasUserDoneTransaction,
                };
                var validationResult = await _voucherifyService.ValidateDiscount(discountRequest, product.fromMsisdn, userAccount.AccountID, customerMetaData);
                if (validationResult?.Payload != null)
                {
                    discountAmount = validationResult.Payload.DiscountAmount;
                    custCharge -= discountAmount;
                }
            }

            if (decimal.Parse(userAccount.UserAccountBalance.Balance, CultureInfo.InvariantCulture) < custCharge)
            {
                //Handle Airship tags and events
                await _airShipService.HandleIntTopupTagsAndEvents(
                      new IntTopupInfoAirShip()
                      {
                          Destination = msisdndestination,
                          IsCard = null,
                          IsSuccess = false,
                          Msisdn = fromMsisdn,
                          Origination = msisdnorigination,
                          Amount = custCharge,
                          IsTransferRequest = request.IsTransferRequest
                      });

                // Handle FaceBook Events
                await _faceBookService.HandleIntTopupEvents(request.advertiserID, msisdnorigination, msisdndestination, false, null, custCharge, request.IsTransferRequest);

                // Handle AppsFlyer Events
                await _appsFlyerService.HandleIntTopupEvents(request.AppsFlyerId, deviceType, msisdnorigination, msisdndestination, false, null, custCharge, ipAddress: null, request.IsTransferRequest);

                executeres.Status = "Failure";
                executeres.Message = _localizer["InsufficientBalance"];
				PrepareUpdateTransactionLog(transaction, discountAmount, 2, "InsufficientBalance");
				await _attRepo.UpdateTransactionLog(transaction);
				return executeres;
            }

            var result = await _aTTService.TransferBalance(request, fromMsisdn);
            if (result == null)
            {
                executeres.Status = "Failure";
                executeres.Message = _localizer["BalanceTransferFailed"];
				PrepareUpdateTransactionLog(transaction, discountAmount, 2, "BalanceTransferFailed");
				await _attRepo.UpdateTransactionLog(transaction);
				return executeres;
            }

            if (result.errorCode == 0 && result.status.Equals("success", StringComparison.InvariantCultureIgnoreCase))
            {
                if (!string.IsNullOrEmpty(request.DiscountCode))
                {
                    redemptionResult = await _voucherifyService.RedeemDiscount(new StackableDiscountRequest
                    {
                        Amount = Convert.ToDecimal(product.CustomerChargeValue),
                        CheckoutType = CheckOutTypes.Transfer,
                        DiscountCode = request.DiscountCode,
                        DiscountCodeType = request.DiscountCodeType,
                        PaymentMethod = PaymentMethods.Paypal,
                        Operator = product.operatorName,
                        DestinationCountryISOCode = msisdndestination,
                    }, product.fromMsisdn, userAccount.AccountID, new CustomerMetadata()
                    {
                        FirstInternationalTopup = isFirstInternationalTopup,
                        FirstTopup = isFirstTopup,
                        TransactionDone = !hasUserDoneTransaction,
                    });
                    voucherifyCampaignName = redemptionResult?.Payload?.RedemptionId != null ? redemptionResult?.Payload?.CampaignName : string.Empty;
                }

                var isRedeemed = redemptionResult?.Payload?.RedemptionId != null;

                var internationalTopupPoints = Utility.CalculateInternationalTopupRewardPointsRange(Convert.ToDecimal(product.CustomerChargeValue), _voucherifyConfig.LoyaltyEarningRules.International);

                result.VoucherifyInfo = Utility.GetVoucherifyInfo(voucherifyCampaignName, CheckOutTypes.Transfer, request.DiscountCodeType, isFirstInternationalTopup, internationalTopupPoints: internationalTopupPoints, isRedeemedSuccess: isRedeemed);

                await _voucherifyService.PurchaseEvent(product.fromMsisdn, string.Format(VoucherifyEventsNames.InternationalTopup, internationalTopupPoints), new VoucherifyEventsMetadata { ChargeAmount = Convert.ToDecimal(product.CustomerChargeValue), Timestamp = DateTime.UtcNow, LoyaltyPoints = internationalTopupPoints });

                var debitResp = await _userAccountRepo.DebitAccountBalance(
                       userAccount.AccountID,
                       custCharge,
                       request.nowtelTransactionReference,
                       result.reference);

                //Handle Airship tags and events
                await _airShipService.HandleIntTopupTagsAndEvents(
                      new IntTopupInfoAirShip()
                      {
                          Destination = msisdndestination,
                          IsCard = null,
                          IsSuccess = true,
                          Msisdn = fromMsisdn,
                          Origination = msisdnorigination,
                          Amount = custCharge,
                          IsTransferRequest = request.IsTransferRequest
                      });

                // Handle FaceBook Events
                await _faceBookService.HandleIntTopupEvents(request.advertiserID, msisdnorigination, msisdndestination, true, null, custCharge, request.IsTransferRequest);

                // Handle AppsFlyer Events
                await _appsFlyerService.HandleIntTopupEvents(request.AppsFlyerId, deviceType, msisdnorigination, msisdndestination, true, null, custCharge, ipAddress: null, request.IsTransferRequest);

                //Save ATT transaction
                await _attRepo.SaveTransactionAsync(
                    new DBTransferTransaction()
                    {
                        AccountId = userAccount.AccountID,
                        ClientCurrecny = product.fromCurrency,
                        CountryCode = _helperService.GetCountryCode(product.tomsisdn),
                        FromMsisdn = product.fromMsisdn,
                        ToMsisdn = product.tomsisdn,
                        ItemPrice = productAmount,
                        TotalPrice = custCharge,
                        Discount = discountAmount,
                        DiscountCode = request.DiscountCode,
                        DiscountCodeType = request.DiscountCodeType,
                        ServiceFee=serviceFee,
                        ServiceFeeDiscount=serviceFeeDiscount,
                        TotalServiceFee=totalServiceFee,
                        NowtelRef = request.nowtelTransactionReference,
                        OperatorCountryName = product.operatorCountryName,
                        OperatorLogoUrl = product.operatorLogoUrl,
                        OperatorName = product.operatorName,
                        PaymentErrorMsg = null,
                        TransferErrorMsg = null,
                        PaymentRef = debitResp?.audit_id,
                        TransferRef = result.reference,
                        PaymentTypeId = InternationalTopupPaymentType.AccountBalance,
                        StatusId = TransferTransactionStatus.Success,
                        Product = Convert.ToDecimal(request.product, CultureInfo.InvariantCulture),
                        ReceiverCurrecny = product.toCurrency
                    });

                var userProfile = await _userAccountRepo.GetUserProfile(fromMsisdn);
                if (!string.IsNullOrEmpty(userProfile?.Data?.email))
                {
					var rewardPoints = Utility.CalculateInternationalTopupRewardPointsRange(productAmount, _voucherifyConfig.LoyaltyEarningRules.International);

				    await SendInternationalTopupPaymentReceiptAsync(userProfile.Data.email, product, userProfile.Data, "Account Balance",totalServiceFee,discountAmount,request.DiscountCode,rewardPoints,result.reference,result.pinCode);//result.reference here is the transation id
				}
                executeres.Status = "Success";
                executeres.Message = _localizer["BalanceTransferSuccessful"];
                executeres.Payload = result;
				PrepareUpdateTransactionLog(transaction, discountAmount, 1, "Balance transfer successful");
				await _attRepo.UpdateTransactionLog(transaction);
			}
            else
            {
                await _airShipService.HandleIntTopupTagsAndEvents(
                      new IntTopupInfoAirShip()
                      {
                          Destination = msisdndestination,
                          IsCard = null,
                          IsSuccess = false,
                          Msisdn = fromMsisdn,
                          Origination = msisdnorigination,
                          Amount = custCharge,
                          IsTransferRequest = request.IsTransferRequest
                      });

                // Handle FaceBook Events
                await _faceBookService.HandleIntTopupEvents(request.advertiserID, msisdnorigination, msisdndestination, false, null, custCharge, request.IsTransferRequest);

                // Handle AppsFlyer Events
                await _appsFlyerService.HandleIntTopupEvents(request.AppsFlyerId, deviceType, msisdnorigination, msisdndestination, false, null, custCharge, ipAddress: null, request.IsTransferRequest);

                //Save ATT transaction
                await _attRepo.SaveTransactionAsync(
                    new DBTransferTransaction()
                    {
                        AccountId = userAccount.AccountID,
                        ClientCurrecny = product.fromCurrency,
                        CountryCode = _helperService.GetCountryCode(product.tomsisdn),
                        FromMsisdn = product.fromMsisdn,
                        ToMsisdn = product.tomsisdn,
                        ItemPrice = productAmount,
                        TotalPrice = custCharge,
                        Discount = discountAmount,
                        ServiceFee=serviceFee,
                        TotalServiceFee=totalServiceFee,
                        ServiceFeeDiscount=serviceFeeDiscount,
                        DiscountCode = request.DiscountCode,
                        DiscountCodeType = request.DiscountCodeType,
                        NowtelRef = request.nowtelTransactionReference,
                        OperatorCountryName = product.operatorCountryName,
                        OperatorLogoUrl = product.operatorLogoUrl,
                        OperatorName = product.operatorName,
                        PaymentErrorMsg = null,
                        TransferErrorMsg = result == null ? "Transfer service not responding" : result?.message,
                        PaymentRef = null,
                        TransferRef = null,
                        PaymentTypeId = InternationalTopupPaymentType.AccountBalance,
                        StatusId = TransferTransactionStatus.Failure,
                        Product = Convert.ToDecimal(request.product, CultureInfo.InvariantCulture),
                        ReceiverCurrecny = product.toCurrency
                    });

                executeres.Status = "Failure";
                executeres.Message = _localizer["BalanceTransferFailed"];
                executeres.Payload = result;
                _logger.Warning($"Class: ATT_BL, Method:ExecuteTransactionByBalance, Message: Balance transfer failed, FromMsisdn:{fromMsisdn}, NowTelTransactionRef:{request.nowtelTransactionReference}, Operator:{request.operatorid}, Product:{request.product}, ErrorCode:{result.errorCode}, ErrorMessage:{result.message}");
			    PrepareUpdateTransactionLog(transaction, discountAmount, 2, "Balance transfer failed");
			    await _attRepo.UpdateTransactionLog(transaction);
            }
			return executeres;
        }



        public async Task<DBProduct> GetProductByNowtelTransactionReference(string nowtelref, string product)
        {
            return await _attRepo.GetProductByNowtelTransactionReference(nowtelref, product);
        }
        public async Task<GenericApiResponse<ATTTransactions>> GetAttHistoryAsync(TransferToTransactionsListRequest request, string account)
        {
            var response = new GenericApiResponse<ATTTransactions>();
            response.Payload = await _attRepo.GetATTHistory(request, account);
            response.Message = _localizer["Successfullyretrieved"] + "!!";
            response.Status = "Success";
            return response;
        }
        private async Task SendInternationalTopupPaymentReceiptAsync(string PaymentEmailAddress, DBProduct product, Profile userProfile, string paymentMethod,decimal serviceFee,decimal discountAmount,string discountCode,int rewardPointsEarned, string transactionId,string pinCode)
        {
            try
            {
                if (!userProfile.emailVerified)
                    return;
                var builder = new BodyBuilder();
                using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\International-topup-payment-reciept.html").Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();
                }
            
                string messageBody = builder.HtmlBody
                    .Replace("%TIMESTAMP%", DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"))
                    .Replace("%FIRST_NAME%", userProfile?.firstName)
                    .Replace("%EMAIL%", userProfile?.email)
                    .Replace("%TOPUPNUMBER%", product.tomsisdn)
                    .Replace("%TOPUPCOUNTRY%", product.operatorCountryName)
                    .Replace("%RCVAMOUNT%", _helperService.ToMonetaryUnit(product.toAmount, product.toCurrency))
                    .Replace("%AMOUNT%", _helperService.ToMonetaryUnit(product.fromAmount, product.fromCurrency))
                    .Replace("%SERVICEFEE%", _helperService.ToMonetaryUnit(serviceFee, product.fromCurrency))
                    .Replace("%DISCOUNT%", _helperService.ToMonetaryUnit(discountAmount, product.fromCurrency))
                    .Replace("%DISCOUNTCODE%", discountCode)
                    .Replace("%REWARDPOINTSEARNED%", rewardPointsEarned.ToString())
                    .Replace("%TOPUPOPERATOR%", product.operatorName)
                    .Replace("%PAYMENTMETHOD%", paymentMethod)
                    .Replace("%TRANSACTIONID%", transactionId);

                if (string.IsNullOrEmpty(pinCode))
                {
                    if (messageBody.Contains("<tr id=\"row_pinCode\">"))
                    {
                        messageBody = messageBody.Replace("<tr id=\"row_pinCode\">", "<tr id=\"row_pinCode\" style=\"display:none\">");
                    }
                }
                else
                {
                    messageBody = messageBody.Replace("%PINCODE%", pinCode);
                }

                await _emailService.SendEmail(PaymentEmailAddress, messageBody, true, "Mobile Top-up Sent Successfully");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Class: ATT_BL, Method: SendInternationalTopupPaymentReceiptAsync");
            }
        }

        public async Task<bool> IsFirstInternationalTopup(string accountId)
        {
            return await _attRepo.IsFirstATTTransaction(accountId);
        }
		private InternationalTopupTransactionLog PrepareUpdateTransactionLog(InternationalTopupTransactionLog transaction, decimal? discount, int checkoutStatus, string message)
		{
			if (discount.HasValue)
			{
				transaction.DiscountApplied = discount.Value;
				transaction.TotalPrice -= discount.Value;
			}
			transaction.CheckoutStatus = checkoutStatus;
			transaction.Message = message;
			return transaction;
		}
		private async Task<InternationalTopupTransactionLog> PrepareTransactionLogAsync(string nowtelRef, string productId, decimal discount = 0)
		{
			var product = await _attRepo.GetProductByNowtelTransactionReference(nowtelRef, productId);
			var productAmount = decimal.Parse(product.fromAmount, CultureInfo.InvariantCulture);
			var origination = _helperService.GetCountryCode(product.fromMsisdn);
			var destination = _helperService.GetCountryCode(product.tomsisdn);
			var amountToCharge = decimal.Parse(product.CustomerChargeValue, CultureInfo.InvariantCulture);
			(decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, product.fromCurrency, productAmount);
			amountToCharge += totalServiceFee;
			amountToCharge -= discount;
			return new InternationalTopupTransactionLog
			{
				CheckoutStatus = 0,
				Currency = product.fromCurrency,
				CustomerIdentifier = product.fromMsisdn,
				ToMsisdn = product.tomsisdn,
				TransactionIdentifier = nowtelRef,
				ProductPrice = productAmount,
				DiscountOnServiceFee = serviceFeeDiscount,
				DiscountApplied = discount,
				Message = "",
				ProductIdentifier = product.product,
				TotalPrice = amountToCharge,
				ServiceFee = totalServiceFee,
				SalePrice = productAmount,
			};
		}
	}
}