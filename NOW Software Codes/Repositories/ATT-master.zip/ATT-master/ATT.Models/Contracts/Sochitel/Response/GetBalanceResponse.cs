﻿
namespace ATT.Models.Contracts.Sochitel.Response
{
    public class Balance
    {
        public float value { get; set; }
        public string currency { get; set; }
    }
}
