using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Dtos.Auth;
using JM.Core.Utilities.Interfaces.Database;
using JM.Core.Utilities.Interfaces.Services;

using Mediator;

using RW;

namespace JM.Core.Features.Auth.Login;
public abstract class SocialLogin
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public string Email { get; set; } = string.Empty;
		public string ProviderKey { get; set; } = string.Empty;
		public AppEnum.LoginProvider Provider { get; set; }
	}

	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.Email).NotNull().NotEmpty();
		}
	}

	#endregion

	#region Response
	public sealed record Response
	{
	}

	#endregion

	#region Handler
	internal sealed class Handler(IIdentityService authService, IUnitOfWork unitOfWork, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IIdentityService _authService = authService;
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		private readonly IMediator _mediator = mediator;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{

			var user = await _unitOfWork.UserRepository.GetUser(x => x.NormalizedEmail!.Equals(query.Email.ToUpperInvariant()));

			if (user is not null)
			{
				var loginResult = await _mediator.Send(new Login.Query()
				{
					Email = query.Email,
					Password = $"JM_{query.ProviderKey}_1"
				}, cancellationToken);

				if (loginResult.IsSuccess)
				{
					return ResultWrapper.Success(loginResult.TypedPayload<Login.Response>());
				}
				return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
			}

			var signupResult = await _authService.RegisterAsync(new RegisterDto.Request()
			{
				Email = query.Email,
				Password = $"JM_{query.ProviderKey}_1",
				IsSocialLogin = true,
				Provider = query.Provider,
				ProviderKey = query.ProviderKey
			});

			if (signupResult.IsSuccess)
			{
				return ResultWrapper.Success(AppConstant.StatusKey.UserCreated, AppConstant.StatusCode.Created);
			}

			return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
		}
	}
	#endregion
}
