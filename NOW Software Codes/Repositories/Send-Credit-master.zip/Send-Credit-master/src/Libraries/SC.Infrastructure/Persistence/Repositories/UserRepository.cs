﻿using SC.Core.Models.Dtos;
using SC.Infrastructure.Persistence.Repositories.DTOs;
using Sentry;
using static SC.Core.Common.Definitions.Constants.AppConstants;
using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Infrastructure.Persistence.Repositories;

internal sealed class UserRepository : IUserRepository
{
    private UserRepository() { }
    private readonly ILogger _logger;
    private readonly IConfiguration? _configuration;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public UserRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor, ILogger logger)
    {
        _httpContextAccessor = httpContextAccessor;
        _configuration = configuration;
        _logger = logger;
    }
    public async Task UserSignInLogInsertAsync(LoginLogDto appLogDto)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var userAgent = _httpContextAccessor?.HttpContext.Request.Headers.UserAgent;

                var parameters = new DynamicParameters();
                parameters.Add("@user_id", appLogDto.UserID);
                parameters.Add("@user_login_time", appLogDto.LoginTime);
                parameters.Add("@deviceinfo", userAgent?.ToString());
                parameters.Add("@refresh_token", appLogDto.Refresh_Token?.ToString());
                parameters.Add("@token_expiry", appLogDto?.Refresh_Token_Expiry);
                parameters.Add("@issuccess_login", appLogDto?.IsSuccessLogin);

                await connection.ExecuteAsync(AppConstants.StoreProcedures.UserLoginLogInsert, parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.Error("UserSignInLogInsertAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
            }
        }
    }
    public async Task<int> GetLoginFailedAttemps(string UserId, DateTime TimeSpan)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@user_id", UserId);
                parameters.Add("@consecutive_period", TimeSpan);
                var result = await connection.ExecuteScalarAsync<int>(AppConstants.StoreProcedures.UserLoginAttempsCount, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error("GetLoginFailedAttemps, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return 0;
            }
        }

    }
    public async Task UpdateUserAsync(string UserID, string User_Status, string UserToken, string TokenPurpose, UserTypeEnum userType)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@user_id", UserID);
                parameters.Add("@user_status", User_Status);
                parameters.Add("@user_token", UserToken);
                parameters.Add("@token_purpose", TokenPurpose);
                parameters.Add("@user_type", userType);


                await connection.ExecuteAsync(AppConstants.StoreProcedures.UserUpdate, parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.Error("UpdateUserAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
            }
        }
    }

    public async Task<GetUserDetailDto> GetUserDetailByUserID(string UserID)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@user_id", UserID);

                var result = await connection.QueryFirstOrDefaultAsync<GetUserDetailDto>(AppConstants.StoreProcedures.GetUserDetail, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error("GetUserDetailByUserID, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default(GetUserDetailDto);
            }
        }
    }
    public async Task<bool> ÚpdateAccountDetail(UserAccountDto detail)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@user_id", detail.UserID);
                parameters.Add("@p_avatar", detail.Avatar);
                parameters.Add("@p_date_of_birth", detail.DateOfBirth);
                parameters.Add("@p_first_name", detail.FirstName);
                parameters.Add("@p_last_name", detail.LastName);
                parameters.Add("@p_from_name", detail.FrontName);
                parameters.Add("@p_gender", detail.Gender);

                var result = await connection.ExecuteScalarAsync<int>(AppConstants.StoreProcedures.UserAccountDetailUpdate, parameters, commandType: CommandType.StoredProcedure);
                return result > 0 ? true : false;
            }
            catch (Exception ex)
            {
                _logger.Error("ÚpdateAccountDetail, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return false;
            }
        }
    }
}

