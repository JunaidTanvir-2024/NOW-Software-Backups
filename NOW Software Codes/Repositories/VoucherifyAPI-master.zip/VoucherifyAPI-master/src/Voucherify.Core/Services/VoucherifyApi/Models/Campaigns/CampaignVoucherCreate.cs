using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Campaigns;

public class CampaignVoucherCreate
{
    [JsonPropertyName("code_config")]
    public CodeConfig? CodeConfig { get; set; }

    [JsonPropertyName("type")]
    public VoucherType? Type { get; private set; }

    [JsonPropertyName("discount")]
    public Discount? Discount { get; private set; }

    [JsonPropertyName("gift")]
    public Gift? Gift { get; private set; }

    [JsonPropertyName("redemption")]
    public VoucherRedemption? Redemption { get; set; }

    public CampaignVoucherCreate WithDiscount(Discount discount)
    {
        Discount = discount;
        Gift = null;
        Type = VoucherType.DiscountVoucher;
        return this;
    }

    public CampaignVoucherCreate WithGift(Gift gift)
    {
        Discount = null;
        Gift = gift;
        Type = VoucherType.GiftVoucher;
        return this;
    }
}
