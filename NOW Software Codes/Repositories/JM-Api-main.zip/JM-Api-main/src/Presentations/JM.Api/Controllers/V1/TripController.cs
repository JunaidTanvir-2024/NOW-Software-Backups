using JM.Api.Controllers.Common;
using JM.Core.Features.Country;
using JM.Core.Features.Place;
using JM.Core.Features.Traveler;
using JM.Core.Features.Trip;
using JM.Core.Utilities.Definitions;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using RW.Common;
using RW.Failures;
using RW.Models;
using RW.Successes;

namespace JM.Api.Controllers.V1;
[Authorize]
public sealed class TripController : V1ApiController
{
	[HttpPost]
	[ProducesResponseType<SuccessPayload<CreateTrip.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.InternalServerError)]
	public async Task<ActionResult> AddTrip([FromBody] CreateTrip.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}

	[HttpPost("filter")]
	[ProducesResponseType<SuccessPayload<GetTripList.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
	[AllowAnonymous]
	public async Task<ActionResult> GetTrips([FromBody] GetTripList.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
	[HttpGet("id")]
	[ProducesResponseType<SuccessPayload<GetTrip.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
	[AllowAnonymous]
	public async Task<ActionResult> GetTrip([FromQuery] GetTrip.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
	[HttpPatch]
	[ProducesResponseType<SuccessPayload<UpdateTrip.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.InternalServerError)]
	public async Task<ActionResult> UpdateTrip([FromBody] UpdateTrip.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
	[HttpDelete]
	[ProducesResponseType<SuccessPayload<RemoveTrip.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.BadRequest)]
	public async Task<ActionResult> RemoveTrip([FromQuery] RemoveTrip.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
	[HttpPost("traveler")]
	[ProducesResponseType<SuccessPayload<CreateTraveler.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.BadRequest)]
	public async Task<ActionResult> AddTraveler([FromBody] CreateTraveler.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
	[HttpGet("traveler")]
	[ProducesResponseType<SuccessPayload<GetTravelerList.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
	public async Task<ActionResult> GetTraveler([FromQuery] GetTravelerList.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
	[HttpGet("traveler/id")]
	[ProducesResponseType<SuccessPayload<GetTraveler.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
	[AllowAnonymous]
	public async Task<ActionResult> GetTraveler([FromQuery] GetTraveler.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
	[HttpPost("place")]
	[ProducesResponseType<SuccessPayload<CreatePlace.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.BadRequest)]
	public async Task<ActionResult> AddTraveler([FromBody] CreatePlace.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
}
