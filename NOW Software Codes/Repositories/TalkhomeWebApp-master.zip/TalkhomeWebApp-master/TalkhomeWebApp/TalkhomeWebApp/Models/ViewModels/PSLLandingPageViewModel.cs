﻿using System.Collections.Generic;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class PSLLandingPageViewModel
    {
        public List<Bundles> Bundles { get; set; }
        public string CurrencySymbol { get; set; }
        public string CurrencyCode { get; set; }
        public Rates Rate { get; set; }
    }
}
