﻿using Models.Contracts.Response;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IApnSender
    {
        Task<ApnsApiResponse> SendAsync(
          string jsonBody,
          string deviceToken,
          APNSNotificationTypes notificationType,
          ApnServerType apnsserver,
          string apnsId = null,
          int apnsExpiration = 0,
          int apnsPriority = 10,
          bool isBackground = false
          );
        Task<List<ApnsApiResponse>> SendAsyncBulk(
          string jsonBody,
          List<string> DeviceTokens,
          APNSNotificationTypes notificationType,
          ApnServerType apnsserver,
          string apnsId = null,
          int apnsExpiration = 0,
          int apnsPriority = 10,
          bool isBackground = false
          );
    }
}
