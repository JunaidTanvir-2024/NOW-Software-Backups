﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.ApiContracts
{
    public class PortOutRequest
    {
        [JsonProperty("CodeType")]
        public int CodeType { get; set; }
    }
}
