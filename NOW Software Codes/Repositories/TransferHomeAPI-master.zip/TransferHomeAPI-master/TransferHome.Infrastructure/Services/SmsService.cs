﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Infrastructure.Services.Interfaces;
using TransferHome.Models.Configurations;
using TransferHome.Models.Contracts.Service;
using TransferHome.Models.Contracts.Service.SmsServiceModels;
using TrasnferHome.Models.Contracts;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using System.Linq;

namespace TransferHome.Infrastructure.Services
{
    public class SmsService : ISmsService
    {
        private readonly string ApiEndPoint;
        private readonly string SmsFrom;
        private readonly string SmsJobId;
        private ILogger Logger;
        private readonly TwilioConfig TwilioConfig;
        private readonly SAPConfig SAPConfig;
        private readonly CommonSettings CommontSettings;
        private readonly ResendPinConfig ResendPinConfig;

        public SmsService(IOptions<SAPConfig> sapConfig, IOptions<XeebiSmsConfig> config, IOptions<ResendPinConfig> resendPinConfig, ILogger logger, IOptions<TwilioConfig> twilioConfig, IOptions<CommonSettings> commonSettings)
        {
            CommontSettings = commonSettings.Value;
            TwilioConfig = twilioConfig.Value;
            ApiEndPoint = config.Value.ApiEndPoint;
            SmsFrom = config.Value.SmsFrom;
            SmsJobId = config.Value.SmsJobId;
            Logger = logger;
            SAPConfig = sapConfig.Value;
            ResendPinConfig = resendPinConfig.Value;
        }

        public async Task SendSms(string to, string textMessage)
        {
            if (SAPConfig.IsActive)
            {
                bool isMatch = false;
                foreach (var item in SAPConfig.CountryCodes)
                {
                    if (to.StartsWith(item))
                    {
                        isMatch = true;
                    }
                }
                if (isMatch)
                {
                    if (!to.StartsWith("+"))
                    {
                        to = "+" + to;
                    }

                    await SendSAPSMS(new SendSAPSMSRequestModel() { destination = new string[] { to }, message = textMessage, origination = "TransfHome" });
                }
                else
                {
                    if (CommontSettings.SmsGateway == TrasnferHome.Models.Utility.SmsGateway.Twilio)
                    {
                        await SendTwilioSms(to, textMessage);
                    }
                    else
                    {
                        await SendXeebiSms(to, textMessage);
                    }
                }
            }
            else
            {
                if (CommontSettings.SmsGateway == TrasnferHome.Models.Utility.SmsGateway.Twilio)
                {
                    await SendTwilioSms(to, textMessage);
                }
                else
                {
                    await SendXeebiSms(to, textMessage);
                }
            }
        }

        public async Task ReSendSms(int phoneCountryCode, string to, string textMessage)
        {
            if (ResendPinConfig.Sap_IsActive && ResendPinConfig.Sap_Countries.Contains(phoneCountryCode.ToString()))
            {
                if (!to.StartsWith("+"))
                {
                    to = "+" + to;
                }

                await SendSAPSMS(new SendSAPSMSRequestModel() { destination = new string[] { to }, message = textMessage, origination = "TransfHome" });
            }
            else if (ResendPinConfig.SmsGateWay == TrasnferHome.Models.Utility.SmsGateway.Twilio)
            {
                await SendTwilioSms(to, textMessage);
            }
            else
            {
                await SendXeebiSms(to, textMessage);
            }
        }

        private async Task SendTwilioSms(string to, string textMessage)
        {
            bool isRestrictedCountry = false;
            Twilio.Types.PhoneNumber from = "TransfHome";

            foreach (var item in TwilioConfig.TwilioFromNumberCountries)
            {
                if (to.StartsWith(item))
                {
                    isRestrictedCountry = true;
                    from = new Twilio.Types.PhoneNumber(TwilioConfig.TwilioNumber);
                }
            }

            if (!to.StartsWith("+"))
            {
                to = "+" + to;
            }

            string requestParameters = $"from : {from}, to: {to}, textMessage: {textMessage}";

            try
            {
                TwilioClient.Init(TwilioConfig.Sid, TwilioConfig.AuthToken);
                var message = await MessageResource.CreateAsync(body: textMessage, from: isRestrictedCountry ? from : "TransfHome", to: new Twilio.Types.PhoneNumber(to));
                return;
            }
            catch (Exception ex)
            {
                Logger.Error($"SmsService - Method: SendTwilioSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
                await SendXeebiSms(to, textMessage);
                return;
            }
        }

        private async Task<XeebiSendSmsResponse> SendXeebiSms(string to, string textMessage)
        {
            XeebiSendSmsResponse returnResult = null;

            if (!to.StartsWith("+"))
            {
                to = "+" + to;
            }

            string requestParameters = $"to: {to}, textMessage: {textMessage}";

            try
            {
                string XeebiSMSEndPoint = ApiEndPoint + "Xeebi/SendSms";

                string response = "";

                XeebiSendSmsRequest req = new XeebiSendSmsRequest();
                req.from = SmsFrom;
                req.to = to;
                req.text = textMessage;

                Task<String> HttpPoppayoutsPostService = PostRequestToXeebiEndPoint(XeebiSMSEndPoint, "Post", req);
                response = await HttpPoppayoutsPostService;
                returnResult = JsonConvert.DeserializeObject<XeebiSendSmsResponse>(response);
                if (returnResult == null)
                {
                    Logger.Error($"SmsService - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");

                }
                else if (returnResult.errorCode == 2)
                {
                    Logger.Error($"SmsService - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: {returnResult.message}");
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                Logger.Error($"SmsService - Method: SendXeebiSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
            }

            return returnResult;
        }

        private async Task<string> PostRequestToXeebiEndPoint(string apiEndPoint, string postType, XeebiSendSmsRequest req)
        {

            string returnData = "";
            try
            {
                HttpClient httpClient = new HttpClient();

                httpClient.BaseAddress = new Uri(apiEndPoint);

                //var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

                MultipartFormDataContent content = new MultipartFormDataContent();
                content.Add(new StringContent(req.from), "from");
                content.Add(new StringContent(req.to), "to");
                content.Add(new StringContent(req.text), "textMessage");
                //content.Add(httpContent);

                HttpResponseMessage httpResponse;

                if (postType == "Post")
                {
                    httpResponse = await httpClient.PostAsync(apiEndPoint, content);
                }
                else
                {
                    httpResponse = await httpClient.GetAsync(apiEndPoint);
                }

                if (httpResponse.Content != null)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    Exception ex = new Exception($"SmsService Exception - Empty Contents Received for request - ");
                    throw ex;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            return returnData;
        }

        private async Task<GenericApiResponse<string>> SendSAPSMS(SendSAPSMSRequestModel model)
        {
            var Content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(SAPConfig.ApiEndPoint), Timeout = TimeSpan.FromSeconds(60) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (response.IsSuccessStatusCode && response.Content != null)
                    {
                        return JsonConvert.DeserializeObject<GenericApiResponse<string>>(await response.Content.ReadAsStringAsync());
                    }
                    else
                    {
                        Logger.Error($"SmsService - Method: SendSAPSMS, Parameters --> {model}, Exception: {response.ReasonPhrase}");
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"SmsService - Method: SendSAPSMS, Parameters --> {model}, Exception: {ex.Message}");
                return null;
            }
        }
    }
}
