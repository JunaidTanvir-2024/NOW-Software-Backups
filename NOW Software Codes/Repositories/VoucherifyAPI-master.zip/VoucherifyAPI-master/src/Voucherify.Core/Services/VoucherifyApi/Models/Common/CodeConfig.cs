using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class CodeConfig
{
    [JsonPropertyName("length")]
    public int? Length { get; set; }

    [JsonPropertyName("charset")]
    public string? Charset { get; set; }

    [JsonPropertyName("prefix")]
    public string? Prefix { get; set; }

    [JsonPropertyName("postfix")]
    public string? Postfix { get; set; }

    [JsonPropertyName("pattern")]
    public string? Pattern { get; set; }
}
