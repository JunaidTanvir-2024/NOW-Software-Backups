﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common
{
	public partial class StackableDiscountResponse
	{
		[JsonPropertyName("order")]
		public ApplicableOrder Order { get; set; }
        [JsonPropertyName("redemptionId")]
        public string RedemptionId { get; set; }
        [JsonPropertyName("campaignName")]
        public string CampaignName { get; set; }

        public class ApplicableOrder
		{
			[JsonPropertyName("amountOff")]
			public decimal? AmountOff { get; set; }
			[JsonPropertyName("percentOff")]
			public decimal? PercentOff { get; set; }
			[JsonPropertyName("discountType")]
			public string DiscountType { get; set; }
			[JsonPropertyName("unitType")]
            public string UnitType { get; set; }
			[JsonPropertyName("amount")]
            public decimal? Amount { get; set; }
			[JsonPropertyName("discountAmount")]
            public decimal? DiscountAmount { get; set; }
            [JsonPropertyName("amountLimit")]
            public long? AmountLimit { get; set; }

            [JsonPropertyName("items")]
			public IEnumerable<ApplicableOrderItems> Items { get; set; }
			public class ApplicableOrderItems
			{
                [JsonPropertyName("productId")]
                public string ProductId { get; set; }
                
				[JsonPropertyName("skuId")]
                public string SkuId { get; set; }
                
				[JsonPropertyName("skuPrice")]
                public long? SkuPrice { get; set; }
			}
		}
	}

}
