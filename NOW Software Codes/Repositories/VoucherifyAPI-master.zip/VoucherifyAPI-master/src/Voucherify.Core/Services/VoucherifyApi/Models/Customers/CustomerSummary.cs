using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Customers;

public class CustomerSummary
{
    [JsonPropertyName("orders")]
    public CustomerSummaryOrders? Orders { get; set; }

    [JsonPropertyName("redemptions")]
    public CustomerSummaryRedemptions? Redemptions { get; set; }
}