using CH.Api;
using CH.Api.Common.Middlewares;
using CH.Api.Features.DTOne;

using Serilog;

InitializeLogger();
var assemblyName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;

Log.Information($"{assemblyName} Booting Up..");
try
{
    var builder = WebApplication.CreateBuilder(args);
    {
        builder.Host.UseSerilog((hostingContext, config) => config.ReadFrom.Configuration(hostingContext.Configuration).WriteTo.Sentry());
        builder.WebHost.UseSentry();
        builder.Services.AddApiDependencies(builder.Configuration);
    }

    var app = builder.Build();
    {
        app.UseAppExceptionMiddleware();
        app.UseSecurityHeadersMiddleware();
        app.UseHttpsRedirection();
        app.UseSentryTracing();
        app.AddDTOneEndpoints();
        app.UseAppLoggingMiddleware();
        app.Run();
    }
}
catch (Exception ex) when (!ex.GetType().Name.Equals("StopTheHostException", StringComparison.Ordinal))
{
    InitializeLogger();
    Log.Error($"{assemblyName} Shutting down...");
    Log.Fatal(ex, "Unhandled exception");
    throw;
}
finally
{
    InitializeLogger();
    Log.Error($"{assemblyName} Shutting down...");
    Log.CloseAndFlush();
}

/// <summary>
/// Static console logger
/// </summary>
static void InitializeLogger()
{
    if (Log.Logger is not Serilog.Core.Logger)
    {
        Log.Logger = new LoggerConfiguration().WriteTo.Console().WriteTo.Sentry().CreateLogger();
    }
}
