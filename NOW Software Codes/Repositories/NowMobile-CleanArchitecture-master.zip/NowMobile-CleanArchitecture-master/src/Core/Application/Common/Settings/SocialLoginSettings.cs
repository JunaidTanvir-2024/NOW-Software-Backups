﻿namespace Application.Common.Settings;
internal class SocialLoginSettings
{
}
public class AppleLoginSettings
{
    public const string SectionName = "AppleLoginSettings";
    public static AppleLoginSettings Bind = new AppleLoginSettings();
    public string? PrivateKey { get; set; }
    public string? ClientId { get; set; }
    public string? TeamId { get; set; }
}
