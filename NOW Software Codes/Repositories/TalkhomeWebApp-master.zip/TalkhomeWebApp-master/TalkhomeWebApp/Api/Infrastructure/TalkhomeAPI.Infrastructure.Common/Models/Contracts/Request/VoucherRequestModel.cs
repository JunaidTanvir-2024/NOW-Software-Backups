﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class VoucherRequestModel
    {
        [Required(ErrorMessage = "Enter Voucher Code"), MaxLength(length: 11, ErrorMessage = "Maximum 11 characters allowed"),
            MinLength(length: 11, ErrorMessage = "Minimum 11 characters allowed")]
        public string Pin { get; set; }

        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        public string Msisdn { get; set; }

        public string IpAddress { get; set; }
    }
}
