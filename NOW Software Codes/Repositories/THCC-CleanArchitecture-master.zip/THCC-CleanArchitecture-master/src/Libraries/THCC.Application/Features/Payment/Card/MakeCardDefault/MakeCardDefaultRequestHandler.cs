﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Services.Payment;

namespace THCC.Application.Features.Payment.Card.MakeCardDefault;

public class MakeCardDefaultRequestHandler : IRequestHandler<MakeCardDefaultRequest, object>
{
    #region Fields

    private readonly ICardService _cardService;
    private readonly ICurrentUser _currentUser;

    #endregion

    #region Ctors

    public MakeCardDefaultRequestHandler(
        ICardService cardService,
        ICurrentUser currentUser
        )
    {
        _cardService = cardService;
        _currentUser = currentUser;
    }

    #endregion

    #region Method

    public async Task<object> Handle(MakeCardDefaultRequest request, CancellationToken cancellationToken)
    {
        await _cardService.MakeCustomerDefaultCard(request.SecurityCode, request.CardToken, _currentUser.GetUserEmail()!);
        return await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
    }

    #endregion

}