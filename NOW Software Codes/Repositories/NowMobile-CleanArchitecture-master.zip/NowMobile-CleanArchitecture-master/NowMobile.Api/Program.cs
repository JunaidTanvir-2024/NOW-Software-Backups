using Application;
using Application.Common.Configurations;
using Application.Common.Extensions;
using Application.Common.Settings;
using FluentValidation.AspNetCore;
using Infrastructure;
using MediatR;
using Serilog;
using Shared.DependencyInjection;
using System.Reflection;
using System.Text.Json;
using NowMobile.Api;
using NowMobile.Api.Filters;
using NowMobile.Api.Middleware;
using NowMobile.Api.OpenApi;
using NowMobile.Api.SecurityHeaders;

try
{
    IConfiguration configuration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
    var builder = WebApplication.CreateBuilder(new WebApplicationOptions()
    {
        EnvironmentName = configuration["Environment"]
    });
    {
        builder.Host.AddJsonFilesConfigurations();
    }
    builder.Host.UseSerilog((_, config) => config.WriteTo.Console().ReadFrom.Configuration(builder.Configuration));

    var middlewareSettings = builder.Services.GetJsonFileConfigurations(MiddlewareSettings.Bind, MiddlewareSettings.SectionName, builder.Configuration);

    builder.Services.AddMvc();
    builder.Services.AddControllers(options =>
    {
        options.Filters.Add(typeof(ValidateModelStateAttribute));
       options.Filters.AddBasicAuthFilter();
    }).AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.DictionaryKeyPolicy = JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    });

    builder.Services.AddApiVersioning(config =>
    {
        config.DefaultApiVersion = new ApiVersion(1, 0);
        config.AssumeDefaultVersionWhenUnspecified = true;
        config.ReportApiVersions = true;
    });

    builder.Services.AddMiddlewaresServices(middlewareSettings);
    builder.Services.AddHealthChecks();

    builder.Services.AddMediatR(Assembly.GetExecutingAssembly());
    builder.Services.AddOpenApiDocumentation(builder.Configuration);

    builder.Services.AddRouting(options => options.LowercaseUrls = true);
    builder.Services.AddFluentValidationAutoValidation().AddFluentValidationClientsideAdapters();

    #region Layers registration

    builder.Services.AddSharedServices().AddApplicationServices(builder.Configuration).AddInfrastructureServices(builder.Configuration);

    #endregion

    builder.Services.Configure<ApiBehaviorOptions>(options => options.SuppressModelStateInvalidFilter = true);

    var app = builder.Build();

    app.UseLocalizationMiddleware(middlewareSettings.EnableLocalization);
    app.UseStaticFiles();
    app.UseSecurityHeaders(builder.Configuration);
    app.UseExceptionMiddleware();
    app.UseRouting();
    app.UseAuthentication();
    app.UseCurrentUser();
    app.UseAuthorization();
    //app.UseRequestLogging(middlewareSettings.EnableHttpsLogging);
    //app.UseResponseLogging(middlewareSettings.EnableHttpsLogging);
    app.UseOpenApiDocumentation(builder.Configuration);
    app.MapControllers().RequireAuthorization();
    app.MapHealthChecks("/api/health");

    //For handling 404 in api
    //app.Use((Func<HttpContext, Func<Task>, Task>) HandleAPI404Response(app));
    app.Use404ErrorHandlingMiddleware();
    app.Run();
}
catch (Exception ex) when (!ex.GetType().Name.Equals("StopTheHostException", StringComparison.Ordinal))
{
    StaticLogger.EnsureInitialized();
    Log.Fatal(ex, "Unhandled exception");
}
finally
{
    StaticLogger.EnsureInitialized();
    Log.Information("Server Shutting down...");
    Log.CloseAndFlush();
}

//#region Private Helper Functions
//static Func<HttpContext, Func<Task>, Task> HandleAPI404Response(WebApplication app)
//{
//    return async (context, next) =>
//    {
//        await next();
//        if (context.Response.StatusCode == 404)
//        {
//            var _localizer = app.Services.GetService<IStringLocalizer<ValidateModelStateAttribute>>();
//            context.Response.ContentType = "application/json";
//            await context.Response.WriteAsync(JsonConvert.SerializeObject(
//                Result<object>.Failure(_localizer![CustomStatusKey.NotFound], CustomStatusCode.NotFound)
//              , new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() }));
//        }
//    };
//}
//#endregion
