﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.AirShip
{
    public class IntTopupInfoAirShip
    {
        public string Msisdn { get; set; }
        public string Origination { get; set; }
        public string Destination { get; set; }
        public bool IsSuccess { get; set; }
        public bool? IsCard { get; set; }
        public bool SaveCard { get; set; }
    }
}
