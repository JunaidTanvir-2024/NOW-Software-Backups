using System.Security.Cryptography;
using System.Text.Json;
using System.Text;
using Microsoft.Extensions.Options;
using CH.Api.Common.Settings;

namespace CH.Api.Common.Helpers;

public interface ISecurityHelpers
{
    string HashData(object obj);
    bool VerifyHashedData(object obj, string hashedValue);
}

internal class SecurityHelpers : ISecurityHelpers
{
    private readonly SecuritySetting _securitySettings;

    public SecurityHelpers(IOptions<SecuritySetting> securitySettings)
    {
        _securitySettings = securitySettings.Value;
    }
    public string HashData(object obj)
    {
        return ComputeHash(obj);
    }
    public bool VerifyHashedData(object obj, string hashedValue)
    {
        var computedHash = ComputeHash(obj);

        return computedHash.Equals(hashedValue, StringComparison.OrdinalIgnoreCase);
    }

    private string ComputeHash(object obj)
    {
        var sha512 = SHA512.Create();
        var data = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(obj) + GenerateSalt());
        var hashBytes = sha512.ComputeHash(data);
        return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
    }

    private string GenerateSalt()
    {
        using var sha512 = SHA512.Create();
        var textBytes = Encoding.UTF8.GetBytes(_securitySettings.Password);
        return Encoding.UTF8.GetString(sha512.ComputeHash(textBytes));
    }
}
