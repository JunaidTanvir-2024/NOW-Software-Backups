﻿using Application.Features.Device;

namespace Application.Features.Device.NotificationToken;

public class NotificationTokenRequestValidator : AbstractValidator<NotificationTokenRequest>
{
    public NotificationTokenRequestValidator()
    {
        RuleFor(p => p.DeviceToken).NotEmpty().NotNull().MaximumLength(500);
        RuleFor(p => p.DeviceId).NotEmpty().NotNull().MaximumLength(50);
    }
}