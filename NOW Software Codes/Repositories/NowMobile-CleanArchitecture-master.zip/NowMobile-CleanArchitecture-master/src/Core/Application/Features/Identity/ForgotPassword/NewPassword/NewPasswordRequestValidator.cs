﻿using Application.Common.Interfaces;

namespace Application.Features.Identity.ForgotPassword.NewPassword;
public class NewPasswordRequestValidator : AbstractValidator<NewPasswordRequest>
{
    public NewPasswordRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.ConfirmPassword).NotEmpty().NotNull();
        RuleFor(p => p.Password).NotEmpty().NotNull();
        //.WithMessage("Your password cannot be empty")
        //.MinimumLength(8).WithMessage("Your password length must be at least 8.")
        //.MaximumLength(20).WithMessage("Your password length must not exceed 16.")
        //.Matches(@"[A-Z]+").WithMessage("Your password must contain at least one uppercase letter.")
        //.Matches(@"[a-z]+").WithMessage("Your password must contain at least one lowercase letter.")
        //.Matches(@"[0-9]+").WithMessage("Your password must contain at least one number.")
        //.Matches(@"[\!\?\*\.]+").WithMessage("Your password must contain at least one (!? *.).");
        RuleFor(data => data.Email)
            .Cascade(CascadeMode.Stop)
            .NotNull().NotEmpty()
            .Must(p => commonService.IsValidEmailAddress(p))
            .WithMessage("Invalid Email Address");

        RuleFor(p => p.Otp).NotEmpty().NotNull();

        RuleFor(x => x).Custom((x, context) =>
        {
            if (x.Password != x.ConfirmPassword)
            {
                context.AddFailure(nameof(x.Password), "Passwords should match");
            }
        });
    }
}
