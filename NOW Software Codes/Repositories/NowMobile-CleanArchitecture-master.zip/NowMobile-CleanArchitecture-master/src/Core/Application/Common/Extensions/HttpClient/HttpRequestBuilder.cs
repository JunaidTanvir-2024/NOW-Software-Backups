using Application.Common.Constants;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Web;

namespace SenderService.Core.Common.Extensions.HttpClient;
public class RequestHeader
{
    public string? Key { get; set; }
    public string? Value { get; set; }
}
public partial class HttpRequestBuilder
{
    private readonly HttpMethod _method;
    private string _url;
    private HttpContent? _content;
    private List<RequestHeader> _headers = new List<RequestHeader>();
    private string? _bearerToken;
    private string? _basicAuthUsername;
    private string? _basicAuthPassword;
    private readonly MultipartFormDataContent _multipartContent = new MultipartFormDataContent();
    private readonly IHttpClientFactory _httpClient;

    public HttpRequestBuilder(HttpMethod method, string url, IHttpClientFactory httpClient)
    {
        _method = method;
        _url = url;
        _httpClient = httpClient;
    }

    public HttpRequestBuilder WithBearerAuth(string token)
    {
        _bearerToken = token;
        return this;
    }

    public HttpRequestBuilder WithBasicAuth(string username, string password)
    {
        _basicAuthUsername = username;
        _basicAuthPassword = password;
        return this;
    }
    public HttpRequestBuilder WithApiKey(string apiKey)
    {
        return this;
    }
    public HttpRequestBuilder WithJsonContent(string json)
    {
        _content = new StringContent(json, Encoding.UTF8, GlobalConstants.ContentType.ApplicationJson);
        return this;
    }
    public HttpRequestBuilder WithQueryParams(object queryParams)
    {
        var properties = from p in queryParams.GetType().GetProperties()
                         where p.GetValue(queryParams, null) != null
                         select p.Name + "=" + HttpUtility.UrlEncode(p.GetValue(queryParams, null)?.ToString());

        var queryString = string.Join("&", properties.ToArray());
        _url = $"{_url}?{queryString}";
        return this;
    }

    public HttpRequestBuilder WithFiles(params (string name, string filePath)[] files)
    {
        foreach (var (name, filePath) in files)
        {
            var fileContent = new ByteArrayContent(File.ReadAllBytes(filePath));
            fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse(GlobalConstants.ContentType.ApplicationOctetStream);
            _multipartContent.Add(fileContent, name, Path.GetFileName(filePath));
        }
        return this;
    }

    public HttpRequestBuilder WithFormUrlEncodedContent(Dictionary<string, string> formData)
    {
        _content = new FormUrlEncodedContent(formData);
        return this;
    }

    public HttpRequestBuilder WithXmlContent(string xml)
    {
        _content = new StringContent(xml, Encoding.UTF8, GlobalConstants.ContentType.ApplicationXml);
        return this;
    }

    public HttpRequestBuilder WithQueryParams(params (string parameter, string? value)[] queryParams)
    {
        var queryString = string.Join("&", queryParams
            .Where(kvp => kvp.value != null)
            .Select(kvp => $"{kvp.parameter}={kvp.value}"));
        _url = $"{_url}?{queryString}";
        return this;
    }
    public HttpRequestBuilder WithPathParams(params (string key, string value)[] pathParams)
    {
        foreach (var (key, value) in pathParams)
        {
            _url = _url.Replace($"{{{key}}}", value);
        }
        return this;
    }

    public HttpRequestBuilder WithPathParams(params string[]? values)
    {
        var keys = Regex.Matches(_url, @"{(.*?)}")
            .Cast<Match>()
            .Select(m => m.Groups[1].Value)
            .ToList();

        if (keys.Count != values?.Length)
        {
            throw new ArgumentException("The number of path variables does not match the number of values.");
        }

        for (int i = 0; i < keys.Count; i++)
        {
            _url = _url.Replace($"{{{keys[i]}}}", values[i]);
        }
        return this;
    }

    public HttpRequestBuilder WithHeaders(params (string name, string value)[] headers)
    {
        foreach (var (name, value) in headers)
        {

            _headers.Add(new RequestHeader { Key = name, Value = value });
        }
        return this;
    }


    public async Task<HttpResponseMessage> SendAsync()
    {
        var request = ApiRequest();
        return await _httpClient.CreateClient().SendAsync(request);
    }

    private HttpRequestMessage ApiRequest()
    {
        var request = new HttpRequestMessage(_method, _url);

        if (_bearerToken != null)
        {
            request.Headers.Authorization = new AuthenticationHeaderValue(GlobalConstants.AuthType.Jwt, _bearerToken);
        }
        else if (_basicAuthUsername != null && _basicAuthPassword != null)
        {
            var authValue = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_basicAuthUsername}:{_basicAuthPassword}"));
            request.Headers.Authorization = new AuthenticationHeaderValue(GlobalConstants.AuthType.Basic, authValue);
        }
        if (_content != null)
        {
            request.Content = _content;
        }
        else if (_multipartContent.Any())
        {
            request.Content = _multipartContent;

        }
        if (_headers.Count > 0)
        {
            foreach (var header in _headers)
            {
                request.Headers.Add(header.Key!, header.Value);
            }
        }
        return request;
    }

    public async Task<T?> SendAndDeserializeAsync<T>()
    {
        var response = await SendAsync();
        if (response.IsSuccessStatusCode)
        {
            string? content = await response.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<T>(content, new JsonSerializerOptions()
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
                NumberHandling = JsonNumberHandling.Strict,
                Converters =
                {
                new JsonStringEnumConverter(JsonNamingPolicy.CamelCase)
                }

            });
        }
        else
        {
            return default;
        }
    }

    public async Task<(T? result, string apiRequest, string apiResponse)> SendAndDeserializeAndCaptureAsync<T>()
    {
        var request = ApiRequest();
        var response = await SendAsync();
        string? apiRequest;
        // Capture request and response to database
        if (request.Content == null)
        {
            apiRequest = JsonSerializer.Serialize(request.RequestUri, new JsonSerializerOptions()
            {
                WriteIndented = true,
                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            });
        }
        else
        {
            apiRequest = await request.Content.ReadAsStringAsync();
        }
        var ssss = await response.Content.ReadAsStringAsync();
        var apiResponse = await response.Content.ReadAsStringAsync();

        // Log the API request/response informatio

        //Log.Logger.ForContext("APILevel", APILevel.API)
        //    .Information("API request captured. RequestUrl: {RequestUrl}, StatusCode: {StatusCode}, RequestBody: {RequestBody}, ResponseBody: {ResponseBody}", _url, (int) response.StatusCode, apiRequest, apiResponse);

        if (response.IsSuccessStatusCode)
        {
            string? content = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<T>(content, new JsonSerializerOptions()
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
                NumberHandling = JsonNumberHandling.Strict,
                Converters =
                {
                new JsonStringEnumConverter(JsonNamingPolicy.CamelCase)
                }
            });
            return (result, apiRequest, apiResponse);
        }
        else
        {
            return (default, apiRequest, apiResponse);
        }
    }
}
