using Application.Features.Bundle.Model;
using Application.Features.Rate.Model;


namespace Application.Features.Rate.Model;

public sealed class InternationalRatesWithBundleInfo
{
    public InternationalRate RateInfo { get; set; } = new InternationalRate();
    public List<BundleInfo> BundleInfo { get; set; } = new List<BundleInfo>();
}

public sealed class RoamingRatesInfo { 
    public List<RoamingRate> RatesInfo { get; set; } = new List<RoamingRate>();
  
    public bool IsEU { get; set; }
}