namespace Application.Common.Settings;

public sealed class MiddlewareSettings
{
    public const string SectionName = "MiddlewareSettings";
    public static MiddlewareSettings Bind = new MiddlewareSettings();
    public bool EnableHttpsLogging { get; set; } = false;
    public bool EnableLocalization { get; set; } = true;
}