﻿using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBUser
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int CountryId { get; set; }
        public string CountryName { get; set; }
        public string Email { get; set; }
        public bool IsEmailVerified { get; set; }
        public string Password { get; set; }
        public bool MailSubscription { get; set; }
        [Column("SocialSignUpTypeId")]
        public LoginTypes SocialSignUpTypeId { get; set; }
        [Column("RoleId")]
        public Roles Role { get; set; }
        public bool IsActive { get; set; }
    }
}
