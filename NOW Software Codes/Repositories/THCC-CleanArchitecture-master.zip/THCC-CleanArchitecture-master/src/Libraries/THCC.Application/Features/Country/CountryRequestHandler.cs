﻿using Newtonsoft.Json;

using THCC.Application.Models.Dtos;

namespace THCC.Application.Features.Country;

public class CountryRequestHandler : IRequestHandler<CountryRequest, object>
{
    async Task<object> IRequestHandler<CountryRequest, object>.Handle(CountryRequest request, CancellationToken cancellationToken)
    {
        string configurationsDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Configurations");
        var countriesList = JsonConvert.DeserializeObject<List<CountryDetailsDto>>(await File.ReadAllTextAsync(configurationsDirectory + "/countries.json", cancellationToken));
        countriesList = countriesList!.Where(x => x.IsActive).OrderBy(x => x.Name).ToList();
        var response = countriesList.ConvertAll(x => new { x.Name, x.IsoTwoCharacterCode, x.IsoThreeCharacterCode });
        return response;
    }
}
