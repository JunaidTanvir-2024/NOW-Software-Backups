﻿using Application.Features.Payment.Paypal;
using Application.Features.Payment.Paypal.Models;

namespace Application.Common.Interfaces.Payment;
public interface IPayPalService : ISerivcesType.ITransientService
{
    Task<PaypalPaymentResponse> PayPalCreateSalePayment(PaypalPaymentRequest request);
    Task<PaypalPaymentResponse> PayPalCreateSalePaymentWithSubscription(PaypalPaymentRequest request, bool subscriptionWithInitialSale = false);
    Task<PaypalPaymentResponse> DirectPayPalExecuteSalePayment(string customerUniqueRef, string payerId, string paymentId);
    Task<PaypalPaymentResponse> PayPalSuspendSubscription(PaypalPaymentRequest request);
}
