using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Promotions;

public class PromotionTierList
{
    [JsonPropertyName("object")]
    public string? Object { get; set; }

    [JsonPropertyName("tiers")]
    public List<PromotionTier>? Tiers { get; set; }
}
