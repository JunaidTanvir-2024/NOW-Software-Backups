using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;
using FH.UseCases.Exports;

using FluentValidation;

using Mediator;

using Microsoft.AspNetCore.Http;

using RW;

namespace FH.UseCases.Operators;
public sealed class OperatorAliasMapper
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public required IFormFile CsvFile { get; set; }
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.CsvFile).NotNull().NotEmpty();
		}
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;

		public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
		{
			var csvData = request.CsvFile.CsvFileToJson<IEnumerable<OperatorAliasFile.Response>>();

			var operatorsAliasUpdate = csvData?.Select(x => new OperatorAliasDto.Request()
			{
				OperatorId = x.OperatorId,
				OperatorNameAlias = x.OperatorAliasName ?? string.Empty,
				OperatorDescription = x.OperatorDescription ?? string.Empty
			});

			if (operatorsAliasUpdate is null)
			{
				return ResultWrapper.Failure("fail to update Operator aliases", AppConstants.StatusCode.BadRequest);
			};
			await _unitOfWork.OperatorRepository.UpdateOperatorsAliases(operatorsAliasUpdate);

			return ResultWrapper.Success("Operator aliases updated successfully", AppConstants.StatusCode.Success);
		}
	}
	#endregion
}
