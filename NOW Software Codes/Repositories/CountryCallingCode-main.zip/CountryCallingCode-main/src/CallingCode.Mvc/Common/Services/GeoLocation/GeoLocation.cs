﻿using CallingCode.Mvc.Common.Extensions;
using CallingCode.Mvc.Common.Models;
using System.Net.Http.Headers;
using System.Text.Json;

namespace CallingCode.Mvc.Common.Services.GeoLocation;

public interface IGeoLocation
{
    public Task<GeoInfo?> GetGeoInfo(HttpContext context);
}

public class GeoLocation : IGeoLocation
{
    private readonly ILogger<GeoLocation> _logger;
    public GeoLocation(ILogger<GeoLocation> logger)
    {
        _logger = logger;
    }
    public async Task<GeoInfo?> GetGeoInfo(HttpContext context)
    {
        var Ip = UtilityExtensions.GetRemoteIPAddress(context);

        try
        {
            using var client = new HttpClient { BaseAddress = new Uri("https://ipinfo.io/" + Ip + "?token=8846473981a4d0") };
            HttpResponseMessage response = await client.GetAsync("");
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<GeoInfo>(json);
            }

            return null!;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Class: HomeController, Method: GetGeoInfo, " +
                                  $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                  $"StackTrace: {ex.StackTrace}");

            return null!;
        }
    }
}