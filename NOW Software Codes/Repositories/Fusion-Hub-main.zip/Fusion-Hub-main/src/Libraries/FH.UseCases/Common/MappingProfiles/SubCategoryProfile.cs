using FH.Core.DTOs.Database;
using FH.UseCases.Categories;
using FH.UseCases.Products;

using Mapster;

namespace FH.UseCases.Common.MappingProfiles;

public class SubCategoryProfile : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        // Handler Query & Response should be as destination and DTOs Request & Responses should be on the right

        config.NewConfig<GetSubCatgories.Response, SubCategoryDto.Response>()
        .TwoWays()
        .Map(des => des.CategoryAliasName, src => src.CategoryAliasName)
        .Map(des => des.SubCategoryId, src => src.SubCategoryObj.SubCategoryId)
        .Map(des => des.SubCategoryName, src => src.SubCategoryObj.SubCategoryName)
        .Map(des => des.SubCategoryShortCode, src => src.SubCategoryObj.SubCategoryShortCode)
        .Map(des => des.SubCategoryDescription, src => src.SubCategoryObj.SubCategoryDescription);


        config.NewConfig<GetProductByCategory.Response, ProductByCategoryDto.Response>()
             .TwoWays()
            .Map(des => des.CountryName, src => src.SubCategoryResponse.CountryName)
            .Map(des => des.OperatorShortCode, src => src.SubCategoryResponse.OperatorShortCode)
            .Map(des => des.CurrencyCode, src => src.SubCategoryResponse.CurrencyCode)
            .Map(des => des.ProductId, src => src.SubCategoryResponse.ProductId)
            .Map(des => des.ProductAliasName, src => src.SubCategoryResponse.ProductAliasName)
            .Map(des => des.ProductType, src => src.SubCategoryResponse.ProductType)
            .Map(des => des.CategoryName, src => src.SubCategoryResponse.CategoryName)
            .Map(des => des.SubCategoryName, src => src.SubCategoryResponse.SubCategoryName)
            .Map(des => des.Price, src => src.SubCategoryResponse.Price)
            .Map(des => des.MinPrice, src => src.SubCategoryResponse.MinPrice)
            .Map(des => des.MaxPrice, src => src.SubCategoryResponse.MaxPrice)
            .Map(des => des.Tax, src => src.SubCategoryResponse.Tax);
          


    }
}
