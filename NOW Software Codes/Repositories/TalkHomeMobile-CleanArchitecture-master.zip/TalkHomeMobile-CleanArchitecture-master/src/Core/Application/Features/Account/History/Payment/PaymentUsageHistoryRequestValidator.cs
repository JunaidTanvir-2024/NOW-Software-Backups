namespace Application.Features.Account.History.Payment;
public class PaymentUsageHistoryRequestValidator : AbstractValidator<PaymentUsageHistoryRequest>
{
    public PaymentUsageHistoryRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
    }
}