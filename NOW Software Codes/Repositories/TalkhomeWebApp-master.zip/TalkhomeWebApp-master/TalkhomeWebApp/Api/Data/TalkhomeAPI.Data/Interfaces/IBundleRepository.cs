﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Interfaces
{
    public interface IBundleRepository
    {
        Task SaveBundlePurchaseData(bool isSuccess, string bundleName, string bundleRef, float bundleAmount, string accountId, string errorMessage);
        Task<bool> MonthlyBundleValidationAfterTrialExpire(string account, string msisdn, string bundleId, string trialBundleId);
        Task<bool> ValidateBundlePurchase(string account, string msisdn, string bundleId,bool startTrial);
        Task<IEnumerable<BundlesCountries>> GetCountriesByBundle();
        Task<bool> AnyActiveAutoBundleRenwal(string account);
        Task<bool> IsBundlePurchasedPreviously(string account, string bundleId);
        Task<IEnumerable<Bundles>> GetBundleByCountry(string ServiceId,string account=null);
        Task<Bundles> GetBundleById(string Id);
        Task<int> BundlePurchaseViaAccountBalance(string accountId, string bundleId);
        Task<int> SetBundleAutoRenewal(bool isAutoRenew, string Msisdn, string account, string bundleId, bool isTrial, PaymentMethods paymentMethod, string cardMaskedPAN, string cardInitialTransactionId, string paypalSubscriptionId);
        Task<IEnumerable<DBBundleDetails>> GetBundleDetailsByIds(List<string> ids);
    }
}
