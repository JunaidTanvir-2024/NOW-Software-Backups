﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class GetSpecialPromotionBalanceToDeductRequestModel
    {
        public decimal Amount { get; set; }
		public string nowtelRef { get; set; }
		public string product { get; set; }
	}
}
