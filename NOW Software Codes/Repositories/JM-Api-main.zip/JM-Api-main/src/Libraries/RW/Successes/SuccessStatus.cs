using RW.Common;

namespace RW.Successes;

public class SuccessStatus<T>(string successMessage, int successCode) : IResultWrapper<T>
{
    bool IResultStatus.IsSuccess { get; set; } = true;
    public string Message { get; set; } = successMessage;
    public int Code { get; set; } = successCode;
    T? IResultWrapper<T>.Payload { get; set; }
    T? IResultWrapper<T>.Errors { get; set; }
    object? IResultWrapper.Payload { get; set; }
    object? IResultWrapper.Errors { get; set; }
}
