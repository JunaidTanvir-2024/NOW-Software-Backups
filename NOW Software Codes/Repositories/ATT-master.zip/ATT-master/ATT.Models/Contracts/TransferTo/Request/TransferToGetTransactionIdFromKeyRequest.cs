﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ATT.Models.Contracts.TransferTo.Request
{
    public class TransferToGetTransactionIdFromKeyRequest : TransfertoBaseRequest
    {
        public string action = "get_id_from_key";
        public string from_key { get; set; }
        //public string operatorid { get; set; }
        public string toXML()
        {
            //return "<TransferTo>" + base.toXML() + $"<action>{action}</action><destination_msisdn>{destination_msisdn}</destination_msisdn><operatorid>{operatorid}</operatorid></TransferTo>";

            return "<TransferTo>" + base.toXML() + $"<action>{action}</action><from_key>{from_key}</from_key></TransferTo>";
        }
    }
}
