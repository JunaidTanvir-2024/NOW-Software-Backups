using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Web;

using FH.Core.Definitions;
using FH.Core.Entities;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;
using FH.Core.Interfaces.Services;
using FH.Infrastructure.Services.Caching;

using Microsoft.AspNetCore.Http;

namespace FH.Infrastructure.Services.Http;


internal sealed class HttpService(
                IHttpClientFactory httpClientFactory,
                IUnitOfWork unitOfWork,
                IHttpContextAccessor httpContextAccessor,
                ITimeWarpService timeWarpService,
                ICacheManager cacheManager) : IHttpService
{
    private const string CORRELATION_ID = "Correlation_Id";
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly IUnitOfWork _unitOfWork = unitOfWork;
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;
    private readonly ITimeWarpService _timeWarpService = timeWarpService;
    private readonly ICacheManager _cacheManager = cacheManager;
    private string? _basicAuthUsername;
    private string? _basicAuthPassword;
    private bool _isLoggingEnabled;
    private int _vendorId;
    private bool _isBearerTokenNeeded;
    private string? _tokenProperty;
    private string? _tokenExpiryProperty;
    private string? _cachedTokenKey;
    private bool _isHeaderPaginationEnabled;
    private string? _totalPagesHeaderKey;
    private string? _totalRecordsHeaderKey;
    private Dictionary<string, string> _headers = [];
    private bool _isTokenInfoExpired;

    IHttpService IHttpService.WithBearerAuth(string cachedTokenKey, string tokenProperty, string tokenExpiryProperty)
    {
        _isBearerTokenNeeded = true;
        _tokenProperty = tokenProperty;
        _tokenExpiryProperty = tokenExpiryProperty;
        _cachedTokenKey = cachedTokenKey;
        return this;
    }

    IHttpService IHttpService.WithBasicAuth(string? username, string? password)
    {
        _basicAuthUsername = username;
        _basicAuthPassword = password;
        return this;
    }

    IHttpService IHttpService.WithHeaders(Dictionary<string, string> headers)
    {
        _headers = headers;
        return this;
    }
    IHttpService IHttpService.EnableLogging()
    {
        _isLoggingEnabled = true;
        return this;
    }
    IHttpService IHttpService.SetVendor(AppEnums.Vendor vendor)
    {
        _vendorId = (int)vendor;
        return this;
    }
    IHttpService IHttpService.GetPaginationFromHeader(string totalPagesHeaderKey, string totalRecordHeaderKey)
    {
        _isHeaderPaginationEnabled = true;
        _totalPagesHeaderKey = totalPagesHeaderKey;
        _totalRecordsHeaderKey = totalRecordHeaderKey;
        return this;
    }

    public async Task<(bool IsFailure, string Json)> GetAsync(string requestUri, object? queryParams = default)
    {
        var httpRequest = await RequestBuilderAsync(HttpMethod.Get, requestUri, queryParams);
        return await SendAndLogHttpRequest(httpRequest.Stopwatch, httpRequest.HttpClient, httpRequest.HttpRequestMessage);
    }

    public async Task<(bool IsFailure, string Json)> PostAsync(string requestUri, object? data = default, bool isAccessTokenRequest = false)
    {
        if (isAccessTokenRequest)
        {
            var bearerTokenInfo = await _cacheManager.RetrieveFromCache(_cachedTokenKey) ?? string.Empty;
            if (string.IsNullOrEmpty(bearerTokenInfo))
            {
                _isTokenInfoExpired = true;
            }
            else
            {
                return (false, bearerTokenInfo);
            }
        }

        var httpRequest = await RequestBuilderAsync(HttpMethod.Post, requestUri, content: data, isAccessTokenRequest: isAccessTokenRequest);

        return await SendAndLogHttpRequest(httpRequest.Stopwatch, httpRequest.HttpClient, httpRequest.HttpRequestMessage);
    }

    public async Task<(bool IsFailure, string Json)> PutAsync(string requestUri, object? data = default)
    {
        var httpRequest = await RequestBuilderAsync(HttpMethod.Put, requestUri, content: data);
        return await SendAndLogHttpRequest(httpRequest.Stopwatch, httpRequest.HttpClient, httpRequest.HttpRequestMessage);
    }

    public async Task<(bool IsFailure, string Json)> DeleteAsync(string requestUri)
    {
        var httpRequest = await RequestBuilderAsync(HttpMethod.Delete, requestUri);
        return await SendAndLogHttpRequest(httpRequest.Stopwatch, httpRequest.HttpClient, httpRequest.HttpRequestMessage);
    }

    private async Task<(HttpRequestMessage HttpRequestMessage, HttpClient HttpClient, Stopwatch Stopwatch)> RequestBuilderAsync(HttpMethod method, string requestUri, object? queryParameters = null, object? content = null, bool isAccessTokenRequest = false)
    {

        var client = _httpClientFactory.CreateClient();

        var stopwatch = Stopwatch.StartNew();

        var apiUrl = queryParameters is null ? requestUri : BuildQueryParams(requestUri, queryParameters);

        var request = new HttpRequestMessage(method, apiUrl);

        if (_headers.Count > 0)
        {
            foreach (var header in _headers)
            {
                client.DefaultRequestHeaders.Add(header.Key, header.Value);
            }
        }

        request.Content = content is not null ? CreateJsonContent(content) : default;

        if (_isBearerTokenNeeded && !isAccessTokenRequest)
        {
            var bearerToken = await GetBearerToken(_tokenProperty);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
        }

        else if (!_isBearerTokenNeeded && _basicAuthUsername is not null && _basicAuthPassword is not null)
        {
            var authValue = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_basicAuthUsername}:{_basicAuthPassword}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authValue);
        }

        return (request, client, stopwatch);
    }

    private async Task<(bool IsFailure, string Json)> SendAndLogHttpRequest(Stopwatch stopwatch, HttpClient client, HttpRequestMessage? request)
    {
        var (responseBody, statusCode, isFailure, exception) = await SendHttpRequest(client, request);

        await LogHttpRequest(stopwatch, request, responseBody, statusCode, exception);

        return new() { IsFailure = isFailure, Json = responseBody! };
    }

    private async Task LogHttpRequest(Stopwatch stopwatch, HttpRequestMessage? request, string responseBody, int statusCode, Exception? ex = null)
    {
        var requestBody = request?.Content is not null ? await request.Content.ReadAsStringAsync() : string.Empty;

        if (ex is null)
        {
            InsertVendorLogs(stopwatch, request, statusCode, responseBody, requestBody, Encoding.UTF8.GetByteCount(responseBody), string.Empty);
        }
        else
        { 
            InsertVendorLogs(stopwatch, request, AppConstants.StatusCode.InternalServerError, string.Empty, requestBody, 0, ex?.StackTrace?.ToString());
        }
    }

    private async Task<(string responseBody, int statusCode, bool isFailure, Exception? exception)> SendHttpRequest(HttpClient client, HttpRequestMessage? request)
    {
        string responseBody = default!;
        int statusCode = default;

        try
        {
            var httpResponseMessage = await client.SendAsync(request!);

            responseBody = await IncludePaginationFromHeader(httpResponseMessage);

            if (_isBearerTokenNeeded && _isTokenInfoExpired)
            {
                await StoreBearerTokenInfo(_cachedTokenKey, responseBody, _tokenExpiryProperty);
            }

            statusCode = (int)httpResponseMessage.StatusCode;

            return (responseBody, statusCode, !httpResponseMessage.IsSuccessStatusCode, null);
        }
        catch (Exception ex)
        {
            return (responseBody, statusCode, false, ex);
        }
    }

    private async Task<string> IncludePaginationFromHeader(HttpResponseMessage httpResponseMessage)
    {
        var responseBody = await httpResponseMessage.Content.ReadAsStringAsync() ?? string.Empty;
        if (_isHeaderPaginationEnabled && IsJsonList(responseBody))
        {
            (int totalPages, int totalRecords) = httpResponseMessage.GetPaginationInfoFromHeader(_totalPagesHeaderKey, _totalRecordsHeaderKey);
            responseBody = JsonSerializer.Serialize(new { response = JsonSerializer.Deserialize<object>(responseBody), pagination = new { totalRecords, totalPages } });
        }
        return responseBody;
    }

    private static StringContent CreateJsonContent(object? data)
    {
        var json = JsonSerializer.Serialize(data, new JsonSerializerOptions
        {
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        });
        return new StringContent(json, Encoding.UTF8, AppConstants.ContentType.ApplicationJson);
    }

    private void InsertVendorLogs(Stopwatch stopwatch, HttpRequestMessage? request, int statusCode, string? responseBody, string? requestBody, int responseSize, string? stackTraceError)
    {
        if (_isLoggingEnabled)
        {
            var logEntry = new VendorLogEntity
            {
                CorrelationId = _httpContextAccessor.HttpContext?.Items[CORRELATION_ID]?.ToString()!,
                Timestamp = _timeWarpService.UtcNow,
                RequestPath = request?.RequestUri?.ToString(),
                RequestBody = requestBody,
                ResponseBody = responseBody,
                StatusCode = statusCode,
                Duration = stopwatch.ElapsedMilliseconds,
                Headers = JsonSerializer.Serialize(request?.Headers),
                QueryString = request?.RequestUri?.Query,
                ErrorReason = stackTraceError,
                ResponseSize = responseSize,
                RequestMethod = request?.Method.ToString(),
                VendorId = _vendorId,
            };

            _unitOfWork.AppLoggerRepository.VendorLogInsert(logEntry);
        }
    }

    private static string BuildQueryParams(string requestUrl, object? queryParams)
    {
        var properties = from p in queryParams?.GetType().GetProperties()
                         let jsonPropertyName = p.GetCustomAttributes(typeof(JsonPropertyNameAttribute), true)
                             .OfType<JsonPropertyNameAttribute>()
                             .FirstOrDefault()?.Name ?? p.Name
                         where p.GetValue(queryParams, null) != null
                         select jsonPropertyName + "=" + HttpUtility.UrlEncode(p.GetValue(queryParams, null)?.ToString());

        var queryString = string.Join("&", properties.ToArray());
        return $"{requestUrl}?{queryString}";
    }

    private static bool IsJsonList(string jsonString)
    {
        try
        {
            JsonDocument doc = JsonDocument.Parse(jsonString);

            return doc.RootElement.ValueKind == JsonValueKind.Array;
        }
        catch (JsonException)
        {
            return false;
        }
    }

    private async Task<string?> GetBearerToken(string? accessTokenKey)
    {
        var tokenInfo = await _cacheManager.RetrieveFromCache(_cachedTokenKey) ?? string.Empty;

        var authResponse = JsonSerializer.Deserialize<Dictionary<string, object>>(tokenInfo);

        var bearerToken = !string.IsNullOrEmpty(accessTokenKey) ? Convert.ToString(authResponse![accessTokenKey]) : default;

        return bearerToken;
    }
    private async Task StoreBearerTokenInfo(string? cacheTokenKey, string jsonResponse, string? bearerTokenExpiryProperty)
    {
        var authResponse = JsonSerializer.Deserialize<Dictionary<string, object>>(jsonResponse);

        var bearerTokenExpiryTime = !string.IsNullOrEmpty(bearerTokenExpiryProperty) ? Convert.ToString(authResponse![bearerTokenExpiryProperty]) : default;

        await _cacheManager.StoreInCache(cacheTokenKey, jsonResponse, bearerTokenExpiryTime);
    }
}
