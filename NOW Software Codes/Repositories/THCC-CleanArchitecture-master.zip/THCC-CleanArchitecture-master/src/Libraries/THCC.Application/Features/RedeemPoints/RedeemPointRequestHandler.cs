﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.RedeemPoints
{
    public class RedeemPointRequestHandler : IRequestHandler<RedeemPointRequest, object>
    {
        #region Fields

        private readonly ICurrentUser _currentUser;
        private readonly IMailService _mailService;
        private readonly IPointsRepository _pointsRepository;
        private readonly IPaymentRepository _paymentRepository;
        private readonly IUserRepository _userRepo;
        private readonly ILocationService _locationService;

        #endregion

        #region Ctors
        public RedeemPointRequestHandler(
            ICurrentUser currentUser,
            IMailService mailService,
            IPointsRepository pointsRepository,
            IPaymentRepository paymentRepository,
            IUserRepository userRepo,
            ILocationService locationService)
        {
            _currentUser = currentUser;
            _mailService = mailService;
            _pointsRepository = pointsRepository;
            _paymentRepository = paymentRepository;
            _userRepo = userRepo;
            _locationService = locationService;
        }

        #endregion

        #region Method

        public async Task<object> Handle(RedeemPointRequest request, CancellationToken cancellationToken)
        {
            var userProduct = await _userRepo.GetUserProducts(_currentUser.GetUserId());
            if (userProduct == null)
            {
                return ErrorResult.Failure(CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
            }
            var accountDetail = await _userRepo.GetAccountDetails(userProduct!.Product!);
            int points = await _pointsRepository.GetPoints(userProduct!.Product!);
            int amount = request.Points / 100;
            var location = await _locationService.GetLocationInfo();
            var order = new Order
            {
                UserId = _currentUser.GetUserId(),
                Discount = 0,
                TotalAmount = amount,
                Amount = amount,
                Description = null,
                IpAddress = location.IpAddress,
                OrderStatus = OrderStatus.Created,
                Device = location?.Device,
                DeviceLocation = location?.CountryName == null ? null : $"{location.CityName},{location.CountryName}",
            };
            var orderItem = new OrderItem
            {
                TotalAmount = amount,
                Amount = amount,
                CardNumber = userProduct!.Product!,
                CardPin = accountDetail!.PinNumber!.Trim(),
                ProductType = ProductType.Topup
            };
            var orderPayment = new OrderPayment()
            {
                PaymentMethodId = PaymentMethod.Points,
                Stauts = PaymentStatus.Pending,
                PaymentUserId = _currentUser.GetUserId()
            };
            var orderPoint = new OrderPoint()
            {
                OpeningBalance = decimal.Parse(accountDetail.Credit!),
                ClosingBalance = decimal.Parse(accountDetail.Credit!) + amount,
                OpeningPoints = points,
                PointsReceived = 0,
                PointsRedeemed = request.Points,
                ClosingPoints = points - request.Points,
            };
            var orderHistory = new OrderHistory() { Description = "Order Created" };
            //Save order data
            long orderId = await _paymentRepository.SaveOrderDetails(
                                order: order,
                                orderItem: orderItem,
                                orderPayment: orderPayment,
                                orderCardPayment: null!,
                                orderPaypalPayment: null!,
                                orderPoint: orderPoint,
                                orderHistory: orderHistory);
            if (orderId == 0)
            {
                return ErrorResult.Failure(CustomStatusKey.InternalServerError!, CustomStatusCode.InternalServerError);
            }

            var redeemResponse = await _pointsRepository.Redeempoints(userProduct!.Product!, request.Points, accountDetail.SubscriberId!);
            if (!redeemResponse)
            {
                //Update payment history status
                await _paymentRepository.UpdateOrderHistoryStatus(
                    orderId,
                    null!,
                    OrderStatus.Failure,
                    PaymentStatus.Failure,
                    OrderHistoryConstants.RedeemPointsFailed,
                    OrderHistoryConstants.RedeemPointsFailed);

                return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
            }

            //Update payment history status
            await _paymentRepository.UpdateOrderHistoryStatus(
                    orderId,
                    null!,
                    OrderStatus.Success,
                    PaymentStatus.Success,
                    null!,
                    OrderHistoryConstants.RedeemPointsSuccess);

            var orderDetail = await _paymentRepository.GetOrderDetails(orderId, null!);
            var isEmailSent = await _mailService.SendRedeemEmail(orderDetail);
            await _paymentRepository.SaveOrderHistory(orderId, isEmailSent
                    ? OrderHistoryConstants.EmailSentSuccess : OrderHistoryConstants.EmailSentFailed);

            return Unit.Value!;
        }

        #endregion
    }
}
