﻿using Application.Features.Payment.Card.CustomerCards;
using Application.Features.Payment.Card.Models;

namespace Application.Common.Interfaces.Payment;

public interface ICardService : ISerivcesType.ITransientService
{
    Task<List<CustomerCard>> GetCustomerCards(string customerUniqueRef);
    Task<bool> MakeCustomerDefaultCard(string cv2, string cardToken, string customerUniqueRef);
    Task<bool> RemoveCard(string cardToken, string customerUniqueRef);
    Task<CardPaymentResponse> CardPayment(CardPaymentRequest request);
    Task<CardPaymentResponse> Resume3dCardPayment(string transactionId);
    Task<bool> RefundFullPayment(string transactionId);
}