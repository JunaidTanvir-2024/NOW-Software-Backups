﻿using Application.Common.Constants;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;

namespace Application.Common.Configurations;

public static class DependenciesContainer
{
    public static ConfigureHostBuilder AddJsonFilesConfigurations(this ConfigureHostBuilder host)
    {
        host!.ConfigureAppConfiguration((context, config) =>
        {
            var env = context.HostingEnvironment;
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string configurationsDirectory = Path.Combine(baseDirectory, JsonFiles.FolderName);

            config.AddJsonFile($"{JsonFiles.AppSettings}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{JsonFiles.AppSettings}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Rating}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Rating}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Logger}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Logger}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Cache}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Cache}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Database}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Database}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Mail}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Mail}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Middleware}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Middleware}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Security}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Security}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.OpenApi}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.OpenApi}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.SecurityHeaders}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.SecurityHeaders}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Sms}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Sms}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Common}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Common}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Payment}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Payment}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.ConversionTracking}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.ConversionTracking}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Integration}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Integration}.json", optional: true, reloadOnChange: true)
               .AddJsonFile($"{configurationsDirectory}/{JsonFiles.InAppReceipt}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.InAppReceipt}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();
        });
        return host;
    }
}