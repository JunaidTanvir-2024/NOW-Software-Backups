namespace Application.Features.Bundle.BundleRenewal;

public sealed class BundleAutoRenewalRequest : IRequest<Result<object>>
{
    public string Msisdn { get; set; } = default!;
    public int BundleId { get; set; } = default!;
    public bool IsAutoRenew { get; set; } = default!;
}
