﻿using System;

namespace Models.Contracts.Request.Digitalk
{
	public class DigitalkBundle
	{
		public int AllowancePeriodsElapsed { get; set; }
		public object AllowanceRenewalDate { get; set; }
		public CallingPackage CallingPackage { get; set; }
		public int ChargePeriodsElapsed { get; set; }
		public CommonAllowance CommonAllowance { get; set; }
		public DateTime Expired { get; set; }
		public GPRSAllowance GPRSAllowance { get; set; }
		public int Id { get; set; }
		public DateTime LastAllowancePaymentDate { get; set; }
		public DateTime LastChargePaymentDate { get; set; }
		public MMSAllowance MMSAllowance { get; set; }
		public object NoticePeriodEnd { get; set; }
		public SMSAllowance SMSAllowance { get; set; }
		public DateTime Started { get; set; }
		public int State { get; set; }
		public int Type { get; set; }
		public VoiceAllowance VoiceAllowance { get; set; }
	}
}