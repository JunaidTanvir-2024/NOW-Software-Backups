﻿using Application.Common.Interfaces;
using Application.Features.Bundle.Model;
using Application.Features.Bundle.NationalBundle;
using Application.Features.Rate.Model;


namespace Application.Features.Rate.Roaming;
public class RoamingRatesRequestHandler : IRequestHandler<RoamingRatesRequest, Result<RoamingRate>>
{
    private readonly IUnitOfWork _uow;
    private readonly ICommonService _commonService;
    private readonly IStringLocalizer<RoamingRatesRequestHandler> _localizer;
    private readonly IMapper _mapper;

    public RoamingRatesRequestHandler(
        IUnitOfWork uow,
        ICommonService commonService,
        IStringLocalizer<RoamingRatesRequestHandler> localizer,
        IMapper mapper)
    {
        _uow = uow;
        _commonService = commonService;
        _localizer = localizer;
        _mapper = mapper;
    }

    public async Task<Result<RoamingRate>> Handle(RoamingRatesRequest request, CancellationToken cancellationToken)
    {
        var rates = await _uow.RateRepo.GetRoamingRates(request.FromCountryCode, request.ToCountryCode);
        if (rates != null && !string.IsNullOrEmpty(rates.Code))
        {
            bool iseu = _commonService.IsEUCountry(rates.Code);
            if (iseu)
            {
                rates.IsEU = true;
            }
        }
        return Result<RoamingRate>.Success(rates, _localizer[CustomStatusKey.Success]);
    }
}
