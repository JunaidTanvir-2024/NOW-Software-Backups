﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBCountry
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string PhoneCode { get; set; }
        public string IsoTwoCharacterCode { get; set; }
        public string IsoThreeCharacterCode { get; set; }
        public string IsoNumericCode { get; set; }
        public bool IsNational { get; set; }
    }
}
