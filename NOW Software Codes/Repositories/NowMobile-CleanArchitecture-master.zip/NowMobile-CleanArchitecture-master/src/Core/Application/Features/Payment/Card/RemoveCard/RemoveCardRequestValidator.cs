﻿namespace Application.Features.Payment.Card.RemoveCard;

public class RemoveCardRequestValidator : AbstractValidator<RemoveCardRequest>
{
    public RemoveCardRequestValidator()
    {
        RuleFor(p => p.CardToken).NotEmpty().NotNull();
    }
}
