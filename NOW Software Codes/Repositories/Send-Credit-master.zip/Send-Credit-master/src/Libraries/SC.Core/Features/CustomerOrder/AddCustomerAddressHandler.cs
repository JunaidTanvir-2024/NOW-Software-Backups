﻿using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder;
internal sealed class AddCustomerAddressHandler : IRequestHandler<AddCustomerAddressRequest, IResultWrapper>
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly ICommonService _commonService;
    public AddCustomerAddressHandler(ICustomerCartRespository customerCartRespository, ICommonService commonservice)
    {
        _customerCartRespository = customerCartRespository;
        _commonService = commonservice;
    }
    public async Task<IResultWrapper> Handle(AddCustomerAddressRequest request, CancellationToken cancellationToken)
    {
        var orderAddress = new AddCustomerAddressDto()
        {
            CustomerId = _commonService.GetUserID(),
            AddressType = request.AddressType,
            StreetAddress1 = request.StreetAddress1,
            StreetAddress2 = request.StreetAddress2,
            City = request.City,
            State = request.State,
            PostalCode = request.PostalCode,
            Email = request.Email,
            Phone = request.Phone,
            Country = string.IsNullOrEmpty(request.Country) ? _commonService.GetDefaultCountryISO() : request.Country,
            Region = request.Region,
            CountryCode = request.CountryCode
        };
        var response = await _customerCartRespository.AddCustomerAddressAsync(orderAddress);
        return ResultWrapper.Success(response);
    }


}

