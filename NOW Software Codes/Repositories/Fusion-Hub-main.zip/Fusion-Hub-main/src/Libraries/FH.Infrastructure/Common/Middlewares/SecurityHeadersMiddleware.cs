using FH.Core.Definitions;

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

namespace FH.Infrastructure.Common.Middlewares;
internal sealed class SecurityHeadersMiddleware(RequestDelegate next, IOptions<SecurityHeaderSetting> options)
{
    private readonly SecurityHeaderSetting _securityHeaderSetting = options.Value;

    public async Task Invoke(HttpContext context)
    {
        if (_securityHeaderSetting?.Enable is true)
        {
            if (!context.Response.HasStarted)
            {
                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.XFrameOptions))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.XFrameOptions, _securityHeaderSetting.XFrameOptions);
                }

                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.XContentTypeOptions))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.XContentTypeOptions, _securityHeaderSetting.XContentTypeOptions);
                }

                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.ReferrerPolicy))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.ReferrerPolicy, _securityHeaderSetting.ReferrerPolicy);
                }

                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.PermissionsPolicy))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.PermissionsPolicy, _securityHeaderSetting.PermissionsPolicy);
                }

                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.SameSite))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.SameSite, _securityHeaderSetting.SameSite);
                }

                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.XXSSProtection))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.XXSSProtection, _securityHeaderSetting.XXSSProtection);
                }
            }
        }

        await next(context);
    }
}

public sealed class SecurityHeaderSetting
{
    public const string SectionName = nameof(SecurityHeaderSetting);
    public static SecurityHeaderSetting Bind { get; } = new SecurityHeaderSetting();
    public bool Enable { get; set; }

    public string? XFrameOptions { get; set; }

    public string? XContentTypeOptions { get; set; }

    public string? ReferrerPolicy { get; set; }

    public string? PermissionsPolicy { get; set; }

    public string? SameSite { get; set; }

    public string? XXSSProtection { get; set; }

    public List<string>? ContentPolicy { get; set; }
}
