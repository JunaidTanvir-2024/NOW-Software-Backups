﻿using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Domain.Aggregates
{
    public class OrderDetail
    {
        public long Id { get; set; }
        public DateTime OrderDateTime { get; set; }
        public string? OrderReference { get; set; }
        public string? UserId { get; set; }
        public string? PaymentUserId { get; set; }
        public decimal Amount { get; set; }
        public decimal Discount { get; set; }
        public decimal TotalAmount { get; set; }
        public OrderStatus OrderStatus { get; set; }
        public string? IpAddress { get; set; }
        public string? Device { get; set; }
        public string? DeviceLocation { get; set; }
        public long OrderItemId { get; set; }
        public ProductType ProductType { get; set; }
        public string? CardNumber { get; set; }
        public string? CardPin { get; set; }
        public PaymentMethod PaymentMethodId { get; set; }
        public PaymentStatus PaymentStatus { get; set; }
        public string? TransactionId { get; set; }
        public string? CardMask { get; set; }
        public string? CardType { get; set; }
        public bool IsAutoPayment { get; set; }
        public decimal AutoPaymentAmount { get; set; }
        public decimal AutoPaymentThreshold { get; set; }
        public decimal PointsReceived { get; set; }
        public decimal PointsRedeemed { get; set; }
        public decimal OpeningPoints { get; set; }
        public decimal ClosingPoints { get; set; }
        public decimal OpeningBalance { get; set; }
        public decimal ClosingBalance { get; set; }
    }
}
