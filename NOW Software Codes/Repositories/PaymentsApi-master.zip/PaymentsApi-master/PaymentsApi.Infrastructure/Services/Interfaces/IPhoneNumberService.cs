﻿namespace PaymentsApi.Infrastructure.Services.Interfaces
{
    public interface IPhoneNumberService
    {
        string GetCountryISOCode(string originator);
    }
}
