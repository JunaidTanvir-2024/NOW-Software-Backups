﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class AppsFlyerConfig
    {
        public string ApiEndpoint { get; set; }
        public bool IsActive { get; set; }
    }
}
