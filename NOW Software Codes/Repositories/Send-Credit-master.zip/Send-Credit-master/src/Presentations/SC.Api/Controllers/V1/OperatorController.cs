﻿using Microsoft.AspNetCore.Authorization;

using SC.Api.Model.Common;
using SC.Api.Model.Operator;
using SC.Core.Features.Operators;
using SC.Core.Features.Operators.OperatorBySubCategory;

using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Controllers.V1;

public class OperatorController : BaseApiController
{
    [AllowAnonymous]
    [HttpPost]
    public async Task<ActionResult> GetOperators(GetOperatorsRequest request)
    {
        var result = await Mediator.Send(request);

        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
    [AllowAnonymous]
    [HttpPost("ByProductCategory")]
    public async Task<ActionResult> GetOperatorsByProdcutCategory(GetOperatorByProductCategoryModel model)
    {
        var result = await Mediator.Send(model.map());
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
    [AllowAnonymous]
    [HttpPost("MsisdnLookup")]
    public async Task<ActionResult> GetMsisdnLookup(MsisdnLookupModel model)
    {
        var result = await Mediator.Send(model.map());
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }


    [AllowAnonymous]
    [HttpPost("BySubCategory")]
    public async Task<ActionResult> GetOperatorBySubCategory(GetOperatorBySubCategory.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}