﻿namespace SenderService.Core.Features.ProductCode.Response;
public class ProductCodeResponse
{
    public long Id { get; set; }
    public string? Code { get; set; }
    public string? ItemCode { get; set; }
}
