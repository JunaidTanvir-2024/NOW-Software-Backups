using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Services;

public interface ITimeWarpService : ResolveAs.ISingleton
{
    DateTime UtcNow { get; }
}
