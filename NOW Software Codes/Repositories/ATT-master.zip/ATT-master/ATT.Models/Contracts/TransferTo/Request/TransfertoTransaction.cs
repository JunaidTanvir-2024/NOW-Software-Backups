﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Request
{
    public class TransfertoTransaction : TransfertoBaseRequest
    {
        public string action;

        public string destination_msisdn { get; set; }
        public string operatorid { get; set; }
        public string msisdn { get; set; }
        public string product { get; set; }
        public string sms { get; set; }
        public string sender_sms_text { get; set; }

        public TransfertoTransaction()
        { }

        public string toXML()
        {
            string s = "<TransferTo>" + base.toXML();

            s = s + $"<action>{action}</action> ";

            s = s + "<sender_sms>yes</sender_sms>";

            s = s + $"<sender_text>Thanks from Talk Home</sender_text>";

            s = s + $"<destination_msisdn>{destination_msisdn}</destination_msisdn> ";

            s = s + $"<msisdn>{msisdn}</msisdn> ";

            s = s + $"<product>{product}</product> ";

            s = s + $"<operatorid>{operatorid}</operatorid> ";

            s = s + "<send_sms>yes</send_sms>";

            s = s + $"<sms>{sms}</sms>";            

            s = s + "</TransferTo>";

            return s;
        }

        public string toXML(string productCode)
        {
            string s = "<TransferTo>" + base.toXML();

            s = s + $"<action>{action}</action> ";

            s = s + "<sender_sms>yes</sender_sms>";
            if (productCode.ToLower()=="trh") {
                    s = s + $"<sender_text>Thanks from TransferHome</sender_text>";
            } else 
            s = s + $"<sender_text>Thanks from Talk Home</sender_text>";

            s = s + $"<destination_msisdn>{destination_msisdn}</destination_msisdn> ";

            s = s + $"<msisdn>{msisdn}</msisdn> ";

            s = s + $"<product>{product}</product> ";

            s = s + $"<operatorid>{operatorid}</operatorid> ";

            s = s + "<send_sms>yes</send_sms>";

            s = s + $"<sms>{sms}</sms>";            

            s = s + "</TransferTo>";

            return s;
        }

    }
}
