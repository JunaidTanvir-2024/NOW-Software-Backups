﻿using System;
using System.Collections.Generic;
using System.Text;
using THM.Models.Enums;

namespace THM.Models.Database
{
    public class DbThmSims
    {
        public string account { get; set; }
        public SimStauts sim_current_state { get; set; }
        public SimStauts sim_previous_state { get; set; }
    }
}
