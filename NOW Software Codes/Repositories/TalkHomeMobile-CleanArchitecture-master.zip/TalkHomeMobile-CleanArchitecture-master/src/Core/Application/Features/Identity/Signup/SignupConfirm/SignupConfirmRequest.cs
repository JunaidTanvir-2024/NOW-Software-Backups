﻿namespace Application.Features.Identity.Signup.SignupConfirm;
public sealed class SignupConfirmRequest : IRequest<Result<TokenResponse>>
{
    public AppInfo AppInfo { get; set; } = new AppInfo();
    public UserInfo UserInfo { get; set; } = new UserInfo();
    public OTPInfo OtpInfo { get; set; } = new OTPInfo();
    [JsonIgnore]
    public string? IpAddress { get; set; } = null;
}
public sealed class OTPInfo
{
    public int EmailOtp { get; set; } = default!;
    public int MsisdnOtp { get; set; } = default!;
}