﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Resources;
using System.Threading.Tasks;

namespace THCCWEB.Utilities.Extension
{
    public static class CommonExtentionMethods
    {
        public static void Put<T>(this ITempDataDictionary tempData, string key, T value) where T : class
        {
            foreach (var item in tempData) { tempData.Remove(item.Key); }

            tempData[key] = JsonConvert.SerializeObject(value);
        }
        public static string GetRemoteIPAddress(this HttpContext context, bool allowForwarded = true)
        {
            if (allowForwarded)
            {
                string header = (context.Request.Headers["CF-Connecting-IP"].FirstOrDefault() ?? context.Request.Headers["X-Forwarded-For"].FirstOrDefault());
                if (IPAddress.TryParse(header, out IPAddress ip))
                {
                    return ip.MapToIPv4().ToString();
                }
            }
            return context.Connection.RemoteIpAddress.MapToIPv4().ToString();
        }
        public static string GetMessageFromResourceFile(string key)
        {
            var resourceManager = new ResourceManager("THCCWEB.Resources.MessageResource", Assembly.GetExecutingAssembly());

            resourceManager.IgnoreCase = true;

            return resourceManager.GetString(key);
        }

        public static T Get<T>(this ITempDataDictionary tempData, string key) where T : class
        {
            object o;
            tempData.TryGetValue(key, out o);
            return o == null ? null : JsonConvert.DeserializeObject<T>((string)o);
        }
    }
}
