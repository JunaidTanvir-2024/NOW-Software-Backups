﻿namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class PinVerificationCodeRequestModel
    {
        public string PinCode { get; set; }

        public string PhoneNumber { get; set; }

        public string PhoneNumberCountryCode { get; set; }
    }
}
