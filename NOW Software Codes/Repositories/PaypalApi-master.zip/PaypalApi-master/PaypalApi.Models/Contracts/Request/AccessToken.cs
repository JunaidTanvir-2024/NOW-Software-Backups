﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Contracts.Request
{
    public class AccessToken : IAccessToken
    {
        public string Token { get; set; }

        public DateTime ExpiryDate { get; set; }
    }

    public interface IAccessToken
    {
        string Token { get; set; }

        DateTime ExpiryDate { get; set; }
    }
}
