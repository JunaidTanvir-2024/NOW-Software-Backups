﻿namespace Application.Common.Caching;

public interface ICacheKeyService : ISerivcesType.IScopedService
{
    public string GetCacheKey(string name, string id);
}