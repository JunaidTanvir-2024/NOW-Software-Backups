﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.CallingCardSummary
{
    public class CallingCardSummaryRequestHandler : IRequestHandler<CallingCardSummaryRequest, object>
    {
        #region Fields

        private readonly ICurrentUser _currentUser;
        private readonly ICallingCardRepository _callingCardRepository;
        private readonly IUserRepository _userRepository;

        #endregion

        #region Ctor

        public CallingCardSummaryRequestHandler(
            ICurrentUser currentUser,
            ICallingCardRepository callingCardRepository,
            IUserRepository userRepository)
        {
            _currentUser = currentUser;
            _callingCardRepository = callingCardRepository;
            _userRepository = userRepository;
        }

        #endregion

        #region Methods

        public async Task<object> Handle(
            CallingCardSummaryRequest request, CancellationToken cancellationToken)
        {
            request.CardPin = request.CardPin.Trim();
            var type = request.CardPin.Split("-");
           
            request.CardPin =type.Length>1? type[1]: request.CardPin;

            //Get Rechargeable card data
            if (type[0].Equals(nameof(ProductItemCode.THRCC)))
            {
                //Check rechargeable card 
                var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
                if (userProduct != null)
                {
                    var cardNumberInfo = await _userRepository.GetAccountDetails(userProduct!.Product!);
                    if (cardNumberInfo?.PinNumber!.Trim().Equals(request.CardPin) == true)
                    {
                        return new CallingCardSummaryResponse()
                        {
                            ExpiryDate = "N/A",
                            RemainingBalance = cardNumberInfo.Credit!,
                            Status = cardNumberInfo.AccountState == 1 && cardNumberInfo.SubscriberState == 1 ? "Active" : "Not-Active",
                        };
                    }
                }
            }

            //Get classic card data
            //1.First Call active
            //2.Active
            //3.Suspended
            //4.Dormant
            //5.Inactive
            if (type[0].Equals(nameof(ProductItemCode.THCC)))
            {
                var isUserPin = await _callingCardRepository.IsUserPinNumber(
                    request.CardPin, _currentUser.GetUserId());
                if (isUserPin)
                {
                    var classicPinDetails = await _callingCardRepository.GetClassicPinDetails(request.CardPin);
                    if (classicPinDetails != null)
                    {
                        return new CallingCardSummaryResponse()
                        {
                            Status = classicPinDetails.State == 1 || classicPinDetails.State == 2
                              ? "Active" : "Not-Active",
                            ExpiryDate = classicPinDetails.State == 1 || classicPinDetails.State == 2
                                    ? classicPinDetails.ExpiryDate!.ToString()! : "N/A",
                            RemainingBalance = classicPinDetails.State == 1 || classicPinDetails.State == 2
                            ? classicPinDetails.RemainingCredit!.ToString()! : "N/A"
                        };
                    }
                }
            }

            return ErrorResult.Failure(CustomStatusKey.InvalidPin, CustomStatusCode.BadRequest);
        }

        #endregion
    }
}