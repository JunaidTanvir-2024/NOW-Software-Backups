﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Airship.Request;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using RestSharp;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class CustomEvents_BL : ICustomEvents_BL
    {

        private IApiCall ApiCall;
        private readonly ILogger Logger;
        private ICustomEvents_DL  CustomEventsDb;


        public CustomEvents_BL(ILogger logger, IApiCall apiCall, ICustomEvents_DL customEventsDb)
        {
            Logger = logger;
            ApiCall = apiCall;
            CustomEventsDb = customEventsDb;
        }

        public async Task<GenericApiResponse<ApiCustomEventResponse>> AddCustomEvents(AddCustomEventsRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<ApiCustomEventResponse>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = credentials.BearerToken;
                Dictionary<string, string> otherHeaders = new Dictionary<string, string>();
                otherHeaders.Add("X-UA-Appkey", credentials.AppKey);
                string url = credentials.ApiEndPoint + "/api/custom-events";
                ApiAddCustomEventsRequest apiRequest = new ApiAddCustomEventsRequest() { OccurredTime = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"), User = new User() { ChannelIdentifier = request.ChannelIdentifier, ChannelIdentifierValue = request.ChannelIdentifierValue }, Body = new Body() { Name = request.CustomEventName, Value = request.Value, InteractionId = request.InteractionId, InteractionType = request.InteractionType, Transaction = request.Transaction, Properties = request.Properties } };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest);
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, AuthType.Bearer, authHeader, otherHeaders: otherHeaders);               
                if (httpResponse == null)
                {
                    Logger.Error($"Class: CustomEvents_BL, Method: AddCustomEvents, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<ApiCustomEventResponse>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiCustomEventResponse apiResponseModel = JsonConvert.DeserializeObject<ApiCustomEventResponse>(responseJson);
                        if (apiResponseModel.Ok == true)
                        {

                            var dbResult = await CustomEventsDb.AddCustomEvents(request, apiResponseModel, jsonRequest, httpResponse.StatusCode, true);
                            if (dbResult.Status == Status.Success)
                            {
                                return GenericApiResponse<ApiCustomEventResponse>.Success(apiResponseModel, "Success");
                            }
                            else
                            {
                                return GenericApiResponse<ApiCustomEventResponse>.Failure(dbResult.ErrorMessage, ApiStatusCodes.UnSuccessful);
                            }

                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<ApiCustomEventResponse>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        ApiCustomEventResponse apiResponseModel = JsonConvert.DeserializeObject<ApiCustomEventResponse>(responseJson);
                        var dbResult = await CustomEventsDb.AddCustomEventsError(request, responseJson, jsonRequest, httpResponse.StatusCode, false);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiCustomEventResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        ApiCustomEventResponse apiResponseModel = JsonConvert.DeserializeObject<ApiCustomEventResponse>(responseJson);
                        var dbResult = await CustomEventsDb.AddCustomEventsError(request, responseJson, jsonRequest, httpResponse.StatusCode, false);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiCustomEventResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: CustomEvents_BL, Method: AddCustomEvents, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApiCustomEventResponse>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }

    }
}
