﻿using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.ForgotPassword.ForgotPasswordResend;

public class ForgotPasswordResendRequestHandler : IRequestHandler<ForgotPasswordResendRequest, object>
{
    #region Fields

    private readonly IOtpService _otpService;
    private readonly IMailService _mailService;
    private readonly IUserRepository _userRepository;

    #endregion

    #region Ctors

    public ForgotPasswordResendRequestHandler(
         IOtpService otpService,
         IMailService mailService,
         IUserRepository userRepository)
    {
        _otpService = otpService;
        _mailService = mailService;
        _userRepository = userRepository;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(ForgotPasswordResendRequest request, CancellationToken cancellationToken)
    {
        //Get user details
        var user = await _userRepository.GetUserByEmailAsync(request.Email);
        if (user == null)
        {
            return ErrorResult.Failure(
                CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
        }

        var token = await _userRepository.GeneratePasswordResetTokenAsync(user!)!;
        var emailOtp = await _otpService.SaveToken(request.Email, token!, OtpType.ForgotPassword);
        await _mailService.SendForgotPasswordEmail(request.Email, emailOtp);

        return Unit.Value;
    }

    #endregion
}