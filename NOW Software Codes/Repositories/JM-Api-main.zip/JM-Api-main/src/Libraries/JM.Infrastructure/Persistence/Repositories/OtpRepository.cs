using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.EntityFrameworkCore;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;

internal sealed class OtpRepository(AppDbContext context, ILogger logger) : IOtpRepository
{
    private readonly AppDbContext _context = context;
    private readonly ILogger _logger = logger;

    public async Task<Otp> AddOtp(Otp otp)
    {
        try
        {
            var addedOtp = await _context.Set<Otp>().AddAsync(otp);
            return addedOtp.Entity;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OtpRepository), nameof(AddOtp));
            return default!;
        }
    }
    public void UpdateOtp(Otp otp)
    {
        try
        {
            _context.Entry(otp).CurrentValues.SetValues(otp);
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OtpRepository), nameof(UpdateOtp));
        }
    }
    public Otp DeleteOtp(Otp otp)
    {
        try
        {
            var removedOtp = _context.Set<Otp>().Remove(otp);
            return removedOtp.Entity;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OtpRepository), nameof(DeleteOtp));
            return default!;
        }
    }
    public async Task<Otp?> GetOtp(Expression<Func<Otp, bool>> expression)
    {
        try
        {
            return await _context.Set<Otp>()
                .Where(expression)
                .OrderByDescending(x => x.Id)
                .FirstOrDefaultAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OtpRepository), nameof(GetOtp));
            return default!;
        }
    }
    public async Task<long> GetOtpCount(Expression<Func<Otp, bool>> expression)
    {
        try
        {
            return await _context.Set<Otp>()
                                 .LongCountAsync(expression);
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OtpRepository), nameof(GetOtpCount));
            return default!;
        }
    }
}
