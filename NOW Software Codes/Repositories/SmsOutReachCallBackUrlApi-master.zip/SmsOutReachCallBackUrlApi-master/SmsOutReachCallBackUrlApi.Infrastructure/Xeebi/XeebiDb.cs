﻿using SmsOutReachCallBackUrlApi.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using SmsOutReachCallBackUrlApi.Models.Connections;

namespace SmsOutReachCallBackUrlApi.Infrastructure.Xeebi
{
    public class XeebiDb : IXeebiDb
    {

        private IDbConnectionSettings DbConnection;
        

        public XeebiDb(string connectionString)
        {
            
            DbConnection = new DbConnectionSettings(new SqlConnection(connectionString));
            
        }


        async public Task<DbResult> InsertUpdateSmsCallBackUrlData(DataTable deliveryReport)
        {

            DbResult result = null;
            try
            {

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DbResult>("Sp_Api_InsertUpdateSmsCallBackUrlData", new { tblSmsTransaction = deliveryReport.AsTableValuedParameter("dbo.SmsTransactionType") }, commandType: CommandType.StoredProcedure);

                return result;
            }
            catch (Exception ex)
            {
                result = new DbResult();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                return result;
            }
        }

    }
}
