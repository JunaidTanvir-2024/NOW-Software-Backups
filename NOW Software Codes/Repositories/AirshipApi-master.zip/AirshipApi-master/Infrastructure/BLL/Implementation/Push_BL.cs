﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Airship.Request;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using RestSharp;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class Push_BL : IPush_BL
    {

        private IApiCall ApiCall;
        private readonly ILogger Logger;
        private IPush_DL PushDb;


        public Push_BL(ILogger logger, IApiCall apiCall, IPush_DL pushDb)
        {
            Logger = logger;
            ApiCall = apiCall;
            PushDb = pushDb;
        }

        public async Task<GenericApiResponse<ApiPushResponse>> SendPushToTags(SendPushToTagsRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<ApiPushResponse>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/push";               
                ApiSendPushToTagsRequest apiRequest = new ApiSendPushToTagsRequest() { DeviceTypes = request.DeviceTypes, TagAudience = new ApiTagAudience() { TagGroup = request.TagGroup, Tags = request.Tags }, Notification = new ApiNotification() { Alert = request.Notification.Alert, RequestActions = request.Actions } };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest, new StringEnumConverter());
                jsonRequest = jsonRequest.Replace("LandingPageContent", "content");
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Push_BL, Method: SendPushToTags, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<ApiPushResponse>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiPushResponse apiResponseModel = JsonConvert.DeserializeObject<ApiPushResponse>(responseJson);
                        if (apiResponseModel.Ok == true)
                        {

                            var dbResult = await PushDb.AddPushToTagsRequest(request, apiResponseModel, jsonRequest, httpResponse.StatusCode);
                            if (dbResult.Status == Status.Success)
                            {
                                return GenericApiResponse<ApiPushResponse>.Success(apiResponseModel, "Success");
                            }
                            else
                            {
                                return GenericApiResponse<ApiPushResponse>.Failure(dbResult.ErrorMessage, ApiStatusCodes.UnSuccessful);
                            }

                        }
                        else
                        {
                            string response = httpResponse.Content;
                            var dbResult = await PushDb.AddPushToTagsRequestError(request, response, jsonRequest, httpResponse.StatusCode);
                            return GenericApiResponse<ApiPushResponse>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        var dbResult = await PushDb.AddPushToTagsRequestError(request, responseJson, jsonRequest, httpResponse.StatusCode);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiPushResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        var dbResult = await PushDb.AddPushToTagsRequestError(request, responseJson, jsonRequest, httpResponse.StatusCode);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiPushResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Push_BL, Method: SendPushToTags, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApiPushResponse>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }

        public async Task<GenericApiResponse<ApiPushResponse>> SendPushToNamedUser(SendPushToNamedUserRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<ApiPushResponse>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/push";
                ApiSendPushToNamedUserRequest apiRequest = new ApiSendPushToNamedUserRequest() { DeviceTypes = request.DeviceTypes,  NamedUserAudience = new ApiNamedUserAudience() {  NamedUser = request.NamedUsers }, Notification = new ApiNamedUserNotification() { Alert = request.Notification.Alert, RequestActions = request.Actions } };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest, new StringEnumConverter());
                jsonRequest = jsonRequest.Replace("LandingPageContent", "content");
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Push_BL, Method: SendPushToNamedUser, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<ApiPushResponse>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiPushResponse apiResponseModel = JsonConvert.DeserializeObject<ApiPushResponse>(responseJson);
                        if (apiResponseModel.Ok == true)
                        {

                            var dbResult = await PushDb.AddPushToNamedUser(request, apiResponseModel, jsonRequest, httpResponse.StatusCode);
                            if (dbResult.Status == Status.Success)
                            {
                                return GenericApiResponse<ApiPushResponse>.Success(apiResponseModel, "Success");
                            }
                            else
                            {
                                return GenericApiResponse<ApiPushResponse>.Failure(dbResult.ErrorMessage, ApiStatusCodes.UnSuccessful);
                            }

                        }
                        else
                        {
                            string response = httpResponse.Content;
                            var dbResult = await PushDb.AddPushToNamedUserError(request, response, jsonRequest, httpResponse.StatusCode);
                            return GenericApiResponse<ApiPushResponse>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        var dbResult = await PushDb.AddPushToNamedUserError(request, responseJson, jsonRequest, httpResponse.StatusCode);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiPushResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        var dbResult = await PushDb.AddPushToNamedUserError(request, responseJson, jsonRequest, httpResponse.StatusCode);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiPushResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Push_BL, Method: SendPushToNamedUser, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApiPushResponse>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }

    }
}
