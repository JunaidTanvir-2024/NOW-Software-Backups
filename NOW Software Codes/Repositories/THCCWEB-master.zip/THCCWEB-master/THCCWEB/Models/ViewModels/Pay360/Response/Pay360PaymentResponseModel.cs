﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ViewModels.Pay360.Response
{
    public class Pay360PaymentResponseModel
    {
        public ThreeDSecureData threeDSecureData { get; set; }
        public DirectPaymentData directPaymentData { get; set; }
    }
    public class ThreeDSecureData
    {
        public string redirectUrl { get; set; }
        public string returnUrl { get; set; }
        public string pareq { get; set; }
        public string transactionId { get; set; }
    }
    public class DirectPaymentData
    {
        public string Key { get; set; }
        public string Pin { get; set; }
        public string CardNumber { get; set; }
        public string PurchaseType { get; set; }
        public string ProductItemCode { get; set; }
        public int NewPoints { get; set; }
        public string NewBalnce { get; set; }
        public int TotalPoints { get; set; }
        public string TransectionAmmount { get; set; }
        public string TransactionID { get; set; }
    }
}
