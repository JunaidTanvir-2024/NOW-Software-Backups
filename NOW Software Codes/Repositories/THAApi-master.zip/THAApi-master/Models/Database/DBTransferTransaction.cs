﻿using Models.Contracts.Request.Voucherify;
using System;

namespace Models.Database
{
	public class InternationalTopupTransactionLog
	{
		public string TransactionIdentifier { get; set; }
		public string ProductIdentifier { get; set; }
		public string CustomerIdentifier { get; set; }
		public string ToMsisdn { get; set; }
		public string Currency { get; set; }
		public decimal ProductPrice { get; set; }
		public decimal SalePrice { get; set; }
		public decimal DiscountApplied { get; set; }
		public decimal ServiceFee { get; set; }
		public decimal DiscountOnServiceFee { get; set; }
		public decimal TotalPrice { get; set; }
		public int CheckoutStatus { get; set; }
		public string Message { get; set; }
	}
	public class DBTransferTransaction
	{
		public string AccountId { get; set; }
		public TransferTransactionStatus StatusId { get; set; }
		public InternationalTopupPaymentType PaymentTypeId { get; set; }
		public string FromMsisdn { get; set; }
		public string ToMsisdn { get; set; }
		public string ClientCurrecny { get; set; }
		public string ReceiverCurrecny { get; set; }
		public decimal Product { get; set; }
		public decimal ItemPrice { get; set; }
		public decimal TotalPrice { get; set; }
        public decimal ServiceFee { get; set; }
        public decimal ServiceFeeDiscount { get; set; }
        public decimal TotalServiceFee { get; set; }
        public decimal Discount { get; set; }
		public string DiscountCode { get; set; }
		public DiscountCodeType? DiscountCodeType { get; set; }
		public string OperatorName { get; set; }
		public string OperatorLogoUrl { get; set; }
		public string OperatorCountryName { get; set; }
		public string CountryCode { get; set; }
		public string TransferRef { get; set; }
		public string PaymentRef { get; set; }
		public string NowtelRef { get; set; }
		public string PaymentErrorMsg { get; set; }
		public string TransferErrorMsg { get; set; }
	}
	public enum InternationalTopupPaymentType
	{
		Paypal = 1,
		Card = 2,
		Voucher = 3,
		AccountBalance = 4
	}
	public enum TransferTransactionStatus
	{
		Success = 1,
		Failure = 2,
		Pending = 3
	}
}
