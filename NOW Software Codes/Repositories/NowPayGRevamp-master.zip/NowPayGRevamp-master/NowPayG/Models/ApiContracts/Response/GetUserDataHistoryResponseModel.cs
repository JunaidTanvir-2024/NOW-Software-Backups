﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Response
{
    public class GetUserDataHistoryResponseModel
    {
        public IEnumerable<DBDataHistory> DataHistory { get; set; }
        public int DataHisotryTotalRecords { get; set; }
    }

    public class DBDataHistory
    {
        public string Date { get; set; }
        public string subscriber_charge { get; set; }
        public string MB { get; set; }
    }
}
