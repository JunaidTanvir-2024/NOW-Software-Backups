using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;

using Serilog;

using THCC.Application;
using THCC.Daemon;
using THCC.Infrastructure;

var builder = WebApplication.CreateBuilder(args);
{
    builder.Host.UseSerilog((builder, config) =>
    {
        config.WriteTo.Sentry().WriteTo.Console().ReadFrom.Configuration(builder.Configuration);
    });
    builder.WebHost.UseSentry();
}
builder.Host.AddJsonFilesConfigurations();
builder.Services.AddApplicationServices(builder.Configuration);
builder.Services.AddInfrastructureServices(builder.Configuration);
builder.Services.AddHostedService<AutoTopupWorker>();
builder.Services.AddHostedService<ClassicCardConsumptionWorker>();
builder.Services.AddHostedService<RechargableCardConsumptionWorker>();
builder.Services.AddHostedService<ClassicCardCallingWorker>();

var app = builder.Build();
app.Run();