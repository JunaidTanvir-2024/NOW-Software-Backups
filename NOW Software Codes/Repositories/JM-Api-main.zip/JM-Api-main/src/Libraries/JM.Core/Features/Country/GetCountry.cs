using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Country;

public abstract class GetCountry
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long Id { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query> { }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public required string Name { get; set; }
        public required string IsoCode3 { get; set; }
        public ushort CallingCode { get; set; }
        public required string NumericCode { get; set; }
        public required string FlagEmoji { get; set; }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var country = await _unitOfWork.CountryRepository.GetCountry(x => x.Id.Equals(query.Id));
            if (country is not null)
            {
                return ResultWrapper.Success(new Response()
                {
                    Id = country.Id,
                    Name = country.Name,
                    IsoCode3 = country.IsoCode3,
                    CallingCode = country.CallingCode,
                    NumericCode = country.NumericCode,
                    FlagEmoji = country.IsoCode2.IsoCodeToFlagEmoji()
                });
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
        }
    }
    #endregion
}
