﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Database
{
    public class ServicePRoviderThreshhold
    {
        public decimal lower_percentage_bound { get; set; }
        public decimal upper_percentage_bound { get; set; }
    }
}
