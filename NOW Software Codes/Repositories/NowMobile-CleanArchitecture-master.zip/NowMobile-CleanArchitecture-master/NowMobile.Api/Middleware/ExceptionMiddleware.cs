using Application.Common.Enums;
using Application.Common.Interfaces.Shared;
using Application.Common.Models.ResponseWrappers;
using Microsoft.Extensions.Localization;
using Serilog;
using Serilog.Context;

namespace NowMobile.Api.Middleware;
internal sealed class ExceptionMiddleware : IMiddleware
{
    private readonly ICurrentUser _currentUser;
    private readonly ISerializerService _jsonSerializer;
    private readonly IStringLocalizer<ExceptionMiddleware> _localizer;

    public ExceptionMiddleware(
        ICurrentUser currentUser,
        ISerializerService jsonSerializer,
        IStringLocalizer<ExceptionMiddleware> stringLocalizer)
    {
        _currentUser = currentUser;
        _jsonSerializer = jsonSerializer;
        _localizer = stringLocalizer;
    }

    public async Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        try
        {
            await next(context);
        }
        catch (Exception exception)
        {
            string email = _currentUser.GetUserEmail() is string userEmail ? userEmail : "Anonymous";
            var userId = _currentUser.GetUserId();
            if (userId != 0)
            {
                LogContext.PushProperty("UserId", userId);
            }

            LogContext.PushProperty("UserEmail", email);
            string errorId = Guid.NewGuid().ToString();
            LogContext.PushProperty("ErrorId", errorId);
            LogContext.PushProperty("StackTrace", exception.StackTrace);
            var errorResult = new ErrorResult
            {
                Source = exception.TargetSite?.DeclaringType?.FullName,
                Exception = exception.Message.Trim(),
                ErrorId = errorId,
                SupportMessage = "Provide the ErrorId to the support team for further analysis."
            };
            errorResult.Messages!.Add(exception.Message);
            var responseData = Result<object>.Failure(
                           _localizer.GetString(CustomStatusKey.InternalServerError),
                           CustomStatusCode.InternalServerError);

            Log.Error($"{errorResult.Exception} Request failed with Status Code {context.Response.StatusCode} and Error Id {errorId}.");

            context.Response.ContentType = "application/json";
            await context.Response.WriteAsync(_jsonSerializer.Serialize(responseData));
        }
    }
}
internal static class ExceptionMiddlewareExtensions
{
    internal static IApplicationBuilder UseExceptionMiddleware(this IApplicationBuilder app) =>
       app.UseMiddleware<ExceptionMiddleware>();
}