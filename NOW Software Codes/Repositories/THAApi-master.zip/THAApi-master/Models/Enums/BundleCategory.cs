﻿namespace Models.Enums
{
    public enum BundleCategory
    {
        Platinium = 1,
        Gold,
        Silver
    }

}

