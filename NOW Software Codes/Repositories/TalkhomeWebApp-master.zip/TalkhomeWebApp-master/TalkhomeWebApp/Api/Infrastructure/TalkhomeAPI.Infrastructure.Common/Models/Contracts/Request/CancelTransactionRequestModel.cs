﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class CancelTransactionRequestModel
    {
        public string transactionId { get; set; }
    }
}
