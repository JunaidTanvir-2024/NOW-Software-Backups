﻿using Application.Features.Bundle.Model;
using Application.Features.Carousel;

namespace Application.Features.Account.ProductSummary;

public class ProductSummaryResponse
{
    public MsisdnInfo MsisdnInfo { get; set; } = default!;

    public IEnumerable<BundleInfo>? SuggestedBundlesInfo { get; set; }

    public IEnumerable<SubscribedBundleInfo>? SubscribedBundlesInfo { get; set; }

    public IEnumerable<CarouselResponse> Carousel { get; set; } = new List<CarouselResponse>();
}
