using FH.Core.Definitions;
using FH.Core.DependencyResolver;

namespace FH.Infrastructure.Services.Http;

public interface IHttpService : ServiceType.IScoped
{
    Task<(bool IsFailure, string Json)> DeleteAsync(string requestUri);
    Task<(bool IsFailure, string Json)> GetAsync(string requestUri, object? queryParams = default);
    Task<(bool IsFailure, string Json)> PostAsync(string requestUri, object? data = default, bool isAccessTokenRequest = false);
    Task<(bool IsFailure, string Json)> PutAsync(string requestUri, object? data = default);
    IHttpService EnableLogging();
    IHttpService WithBasicAuth(string? username, string? password);
    IHttpService WithBearerAuth(string cachedTokenKey, string tokenProperty, string tokenExpiry);
    IHttpService WithHeaders(Dictionary<string, string> headers);
    IHttpService SetVendor(AppEnums.Vendor vendor);
    IHttpService GetPaginationFromHeader(string totalPagesHeaderKey, string totalRecordHeaderKey);
}
