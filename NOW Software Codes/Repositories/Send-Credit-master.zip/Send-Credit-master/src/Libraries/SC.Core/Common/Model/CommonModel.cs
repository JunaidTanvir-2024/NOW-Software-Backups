﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Model;
public sealed record Filter
{
    public string? CountryIsoCode { get; set; }
    public string? CurrencyCode { get; set; }
    public int? CallingCode { get; set; }
    public string? ValidityUnit { get; set; }
    public int? OperatorId { get; set; }
    public int? ProductId { get; set; }
    public int? ProductCategoryId { get; set; }
    public int? ProductSubCategoryId { get; set; }
    public string? ProductAliasName { get; set; }
    public string? OperatorShortCode { get; set; }
    public string? ProductSubCategoryShortCode { get; set; }


}