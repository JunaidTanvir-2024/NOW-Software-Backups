﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.Service.Pay360ApiContracts
{
    public class Secure3DViewModel
    {
        public string MD { get; set; }
        public string PaRes { get; set; }

        public int Ref { get; set; }
    }
}
