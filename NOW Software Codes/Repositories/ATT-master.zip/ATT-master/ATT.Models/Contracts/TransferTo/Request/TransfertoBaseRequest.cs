﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Request
{
    public class TransfertoBaseRequest
    {
        public string login { get; set; }
        public long key { get; set; }
        public string md5 { get; set; }

        public string toXML()
        {
            return $"<login>{login}</login><key>{key}</key><md5>{md5}</md5>";
        }
    }
}
