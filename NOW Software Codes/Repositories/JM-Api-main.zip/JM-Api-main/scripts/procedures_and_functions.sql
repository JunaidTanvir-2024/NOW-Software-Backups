
-- applog_upsert

CREATE OR REPLACE PROCEDURE "jm"."applog_upsert"(
    v_request_reference varchar,
    v_request_path varchar,
    v_request_method varchar,
    v_request_body varchar,
    v_status_code int,
    v_process_duration bigint,
    v_client_ip varchar,
    v_user_agent varchar,
    v_error_reason text,
    v_request_headers varchar,
    v_response_body text,
    v_product_reference varchar
)
LANGUAGE plpgsql AS $$
BEGIN
    -- Check if the record already exists based on RequestReference
    IF EXISTS (SELECT 1 FROM "jm"."AppLog" WHERE "RequestReference" = v_request_reference) THEN
        -- Perform an UPDATE operation
        UPDATE "jm"."AppLog"
        SET
            "RequestPath" = v_request_path,
            "RequestMethod" = v_request_method,
            "RequestBody" = v_request_body,
            "StatusCode" = v_status_code,
            "ProcessDuration" = v_process_duration,
            "ClientIp" = v_client_ip,
            "UserAgent" = v_user_agent,
            "ErrorReason" = v_error_reason,
            "RequestHeaders" = v_request_headers,
            "ResponseBody" = v_response_body,
            "ProductReference" = v_product_reference,
            "UpdatedAt" = (now() AT TIME ZONE 'UTC'::text)
        WHERE
            "RequestReference" = v_request_reference;
    ELSE
        -- Perform an INSERT operation
        INSERT INTO "jm"."AppLog" (
            "RequestReference",
            "RequestPath",
            "RequestMethod",
            "RequestBody",
            "StatusCode",
            "ProcessDuration",
            "ClientIp",
            "UserAgent",
            "ErrorReason",
            "RequestHeaders",
            "ResponseBody",
            "ProductReference"
        )
        VALUES (
            v_request_reference,
            v_request_path,
            v_request_method,
            v_request_body,
            v_status_code,
            v_process_duration,
            v_client_ip,
            v_user_agent,
            v_error_reason,
            v_request_headers,
            v_response_body,
            v_product_reference
        );
    END IF;
END;
$$;

-- vendorlog_insert

CREATE OR REPLACE PROCEDURE "jm"."vendorlog_insert"(
    v_request_reference varchar,
    v_request_path varchar,
    v_request_method varchar,
    v_request_body varchar,
    v_status_code int,
    v_process_duration bigint,
    v_client_ip varchar,
    v_user_agent varchar,
    v_error_reason text,
    v_request_headers varchar,
    v_response_body text,
    v_product_reference varchar,
    v_vendor_id int8
)
LANGUAGE plpgsql AS $$
BEGIN
    -- Perform an INSERT operation
    INSERT INTO "jm"."VendorLog" (
        "RequestReference",
        "RequestPath",
        "RequestMethod",
        "RequestBody",
        "StatusCode",
        "ProcessDuration",
        "ClientIp",
        "UserAgent",
        "ErrorReason",
        "RequestHeaders",
        "ResponseBody",
        "ProductReference",
        "VendorId"
    )
    VALUES (
        v_request_reference,
        v_request_path,
        v_request_method,
        v_request_body,
        v_status_code,
        v_process_duration,
        v_client_ip,
        v_user_agent,
        v_error_reason,
        v_request_headers,
        v_response_body,
        v_product_reference,
        v_vendor_id
    );
END;
$$;


-- User by get email
CREATE OR REPLACE PROCEDURE jm."user_by_email_get"(v_email varchar)
LANGUAGE plpgsql
AS $$
BEGIN
    SELECT
        u.UserName,
        u.NormalizedUserName,
        u.Email,
        u.NormalizedEmail,
        u.EmailConfirmed,
        u.PasswordHash,
        u.PhoneNumber,
        u.PhoneNumberConfirmed,
        u.TwoFactorEnabled,
        u.LockoutEnd,
        u.LockoutEnabled,
        u.AccessFailedCount,
        ud.FirstName,
        ud.LastName,
        ud.ProfilePhoto,
        ud.RefreshToken,
        ud.RefreshTokenExpiry,
        ud.UserId,
        ud.CountryId,
        ud.IsActive,
        ud.IsDeleted,
        ud.DeletedAt,
        ud.CreatedAt,
        ud.UpdatedAt
    FROM
        "User" u
    INNER JOIN
        "UserDetail" ud ON u.Id = ud.UserId
    WHERE
        u.Email = v_email;
END;
$$;
