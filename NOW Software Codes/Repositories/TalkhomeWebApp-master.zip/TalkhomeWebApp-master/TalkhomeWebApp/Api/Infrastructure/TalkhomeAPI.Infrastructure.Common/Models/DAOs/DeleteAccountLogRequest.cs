﻿using System;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DeleteAccountLogRequest
    {
        public int Id { get; set; }
        public string AccountId { get; set; }
        public string Msisdn { get; set; }
        public DateTime? AccountActivationDate { set; get; }
        public DateTime? AccountDeleteRequestDate { set; get; }
        public string DeleteAccountReason { set; get; }
        public string Comments { set; get; }
        public AccountDeleteStatus AccountDeleteStatus { set; get; }
        public DateTime? AllowedSignUpDate { set; get; }
    }
}
