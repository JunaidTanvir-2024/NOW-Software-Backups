

using Application.Features.Topup.Amount;

namespace NowMobile.Api.Controllers;

public class TopupController : VersionedApiController
{
    [HttpGet("Amount"), AllowAnonymous]
    [OpenApiOperation("Get topup denominations.", "")]
    public async Task<IActionResult> GetTopupAmounts()
    {
        return Ok(await Mediator.Send(new TopupAmountRequest()));
    }
}