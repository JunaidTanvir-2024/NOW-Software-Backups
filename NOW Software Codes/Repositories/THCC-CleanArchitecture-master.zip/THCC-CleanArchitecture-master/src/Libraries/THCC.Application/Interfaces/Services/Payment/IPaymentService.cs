﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Services.Payment;

public interface IPaymentService : ServiceType.ITransient
{
    Task<object> HandleCardPaymentRequest(
        PaymentNewCardDto paymentNewCardInfo,
        PaymentAddressDto paymentAddressInfo,
        PaymentExistingCardDto paymentExistingCardInfo,
        AutoTopupDto autoTopupInfo,
        UserDto userInfo,
        ProductType productType,
        decimal amount,
        string cardNumber);

    Task<object> HandleCardPaymentResume3dRequest(
        string transactionId,
        long orderId);

    Task<object> HandlePaypalPaymentRequest(
        ProductType productType,
        UserDto userInfo,
        decimal amount,
        string cardNumber);

    Task<object> HandleDirectPaypalExecuteRequest(
       string payerId,
       string paymentId,
       string uniqueRef,
       long orderId);
}
