﻿using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.Payment.Paypal.CreateSaleV2;

public class PaypalCreateSalePaymentRequestValidatorV2 : AbstractValidator<PaypalCreateSalePaymentRequestV2>
{
    public PaypalCreateSalePaymentRequestValidatorV2(ICommonService commonService, IOptions<TopupSettings> options)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p!))
            .When(p => p.CreditSimInfo == null || (p.CreditSimInfo != null && p.CreditSimInfo.OrderId <= 0))
            .WithMessage("Invalid msisdn");

        RuleFor(p => p.TopupInfo).Cascade(CascadeMode.Stop)
           .NotEmpty()
           .NotNull()
           .When(p => p.BundleInfo == null && p.CreditSimInfo == null);

        RuleFor(p => p.BundleInfo).Cascade(CascadeMode.Stop)
           .NotEmpty()
           .NotNull()
           .When(p => p.TopupInfo == null && p.CreditSimInfo == null);

        RuleFor(p => p.CreditSimInfo).Cascade(CascadeMode.Stop)
           .NotEmpty()
           .NotNull()
           .When(p => p.BundleInfo == null && p.TopupInfo == null);

        RuleFor(p => p.TopupInfo!.TopupAmount).Cascade(CascadeMode.Stop)
            .NotEmpty()
        .NotNull()
            .Must(p => options.Value.TopUpAmounts.Contains(p))
            .When(p => p.TopupInfo != null)
            .WithMessage("Invalid topup amount");

        RuleFor(p => p.TopupInfo!.AutoTopupInfo).Cascade(CascadeMode.Stop)
            .NotEmpty()
        .NotNull()
            .Must(p => options.Value.TopUpAmounts.Contains(p!.TopupAmount)).WithMessage("Invalid auto top-up amount")
            .When(p => p.TopupInfo != null && p.TopupInfo.AutoTopupInfo != null);

        RuleFor(p => p.BundleInfo).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => p!.BundleId > 0).WithMessage("Invalid bundle reference")
            .When(p => p.BundleInfo != null);

        RuleFor(p => p.CreditSimInfo).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => p!.OrderId > 0).WithMessage("Invalid credit sim reference")
            .When(p => p.CreditSimInfo != null);
    }
}