﻿
using ATT.Infrastructure.BLL.Common;
using ATT.Infrastructure.DAL;
using ATT.Models.Configurations;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Common;
using ATT.Models.Contracts.TransferTo.Response;
using ATT.Models.Database;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using ServiceProvider = ATT.Models.Contracts.Common.ServiceProvider;

namespace ATT.Infrastructure.BLL.TransferTo
{
    public class TransfertoAutomation_BL : ITransfertoAutomation_BL
    {

        private ITransfertoPost_BL _TransferToPost;
        private Serilog.ILogger _loggerAPIAccess;
        private IDataBundlesDb_DL _appDBDataBundle;
        private IAttDb_DL _appDB;
        private TransferToConfig TransferToConf;
        private ICommon_BL _common_BL;
        private readonly SmtpConfig SmtpConfig;

        public TransfertoAutomation_BL(ITransfertoPost_BL post, ILogger appLoggers, IAttDb_DL _db, IDataBundlesDb_DL _dBDataBundle, IOptions<TransferToConfig> transferToConf, ICommon_BL common_BL, IOptions<SmtpConfig> smpt)
        {
            _TransferToPost = post;
            _loggerAPIAccess = appLoggers;
            _appDB = _db;
            _appDBDataBundle = _dBDataBundle;
            TransferToConf = transferToConf.Value;
            SmtpConfig = smpt.Value;
            _common_BL = common_BL;
        }

        #region transferToGetOperatorProductsMSISDN

        public async Task<JsonOperatorProductResponse> transferToGetOperatorProductsMSISDN(string destinationMSISDN, string account, int originDestinationId, string sourceMSISDN)
        {
            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 2;

            try
            {
                GenericApiResponse<string> operatorProducts = await _TransferToPost.getOperatorProductsMSISDN(destinationMSISDN, account);

                if (operatorProducts.Status == 0)
                {

                    PayLoad payload = new PayLoad();

                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();


                    XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                    xmlDoc.LoadXml(operatorProducts.Result); // Load the XML document from the specified file

                    int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    var enRates = await _appDB.GetEndRates(operatorid, account, 2, originDestinationId);

                    XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                    if (xmlproductslist.Count == 0)
                    {
                        // return empty reply
                    }
                    string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                    string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                    string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');

                    string GUID = Guid.NewGuid().ToString();
                    operatorDetails.id = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;         //OperatorID
                    operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                    operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name
                    operatorDetails.nowtelTransactionReference = GUID;
                    operatorDetails.iconUri = "https://operator-logo.transferto.com/logo-" + xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText + "-1.png";       //operator logo

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.insertTransactionGUID1(GUID, account, destinationMSISDN, "{}", "", "", 2, sourceMSISDN);
                    if (dbResult.DBStatus == 0)
                    {
                        _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:transferTo API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:transferTo API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        for (int a = 0; a < productslist.Length; a++)
                        {
                            decimal productValue = Convert.ToDecimal(productslist[a]);

                            var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                            if (endrate != null)
                            {
                                products.Add(_appDB.GetProduct(
                                account,         //clientccy
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                productslist[a],     //product
                                //wholesalespricelist[a],  //itemPriceClientccy
                                //retailpricelist[a]   //totalPriceClientccy
                                 endrate.CustomerChargeValue.ToString(),
                                 endrate.CustomerChargeValue.ToString()
                                 ));

                                await _appDB.insertaccessDetails(dbResult.InsertId,
                                account,
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,
                                productslist[a],
                                endrate.CustomerChargeValue.ToString(),
                                endrate.CustomerChargeValue.ToString(),
                                0
                                );
                            }
                        }
                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _loggerAPIAccess.Information($"  \"GET /transferToGetOperatorProductsMSISDN\"  Success      Parameters-msisdn:{destinationMSISDN} currency:{account}");

                        return result;
                    }
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:TransferTo API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}       Reason={operatorProducts.Message}");
                    // var result2 = new { errorCode = 2, status = "Failure", message = operatorProducts.Message };
                    //return Json(result2);

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = operatorProducts.Message;

                    return result;


                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                return result;
            }
        }

        public async Task<JsonOperatorProductResponse> transferToGetOperatorProductsMSISDN(string destinationMSISDN, string account, int originDestinationId)
        {
            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 2;

            try
            {
                GenericApiResponse<string> operatorProducts = await _TransferToPost.getOperatorProductsMSISDN(destinationMSISDN, account);

                if (operatorProducts.Status == 0)
                {

                    PayLoad payload = new PayLoad();

                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();


                    XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                    xmlDoc.LoadXml(operatorProducts.Result); // Load the XML document from the specified file

                    int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    var enRates = await _appDB.GetEndRates(operatorid, account, 2, originDestinationId);

                    XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                    if (xmlproductslist.Count == 0)
                    {
                        // return empty reply
                    }
                    string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                    string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                    string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');

                    string GUID = Guid.NewGuid().ToString();
                    operatorDetails.id = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;         //OperatorID
                    operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                    operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name
                    operatorDetails.nowtelTransactionReference = GUID;
                    operatorDetails.iconUri = "https://operator-logo.transferto.com/logo-" + xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText + "-1.png";       //operator logo

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.insertTransactionGUID(GUID, account, destinationMSISDN, "{}", "", "", 1);
                    if (dbResult.DBStatus == 0)
                    {
                        _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:transferTo API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:transferTo API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        for (int a = 0; a < productslist.Length; a++)
                        {
                            decimal productValue = Convert.ToDecimal(productslist[a]);

                            var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                            if (endrate != null)
                            {
                                products.Add(_appDB.GetProduct(
                                account,         //clientccy
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                productslist[a],     //product
                                //wholesalespricelist[a],  //itemPriceClientccy
                                //retailpricelist[a]   //totalPriceClientccy
                                 endrate.CustomerChargeValue.ToString(),
                                 endrate.CustomerChargeValue.ToString()
                                 ));

                                await _appDB.insertaccessDetails(dbResult.InsertId,
                                account,
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,
                                productslist[a],
                                endrate.CustomerChargeValue.ToString(),
                                endrate.CustomerChargeValue.ToString(),
                                0
                                );
                            }
                        }
                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _loggerAPIAccess.Information($"  \"GET /transferToGetOperatorProductsMSISDN\"  Success      Parameters-msisdn:{destinationMSISDN} currency:{account}");

                        return result;
                    }
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:TransferTo API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}       Reason={operatorProducts.Message}");
                    // var result2 = new { errorCode = 2, status = "Failure", message = operatorProducts.Message };
                    //return Json(result2);

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = operatorProducts.Message;
                    return result;


                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                return result;
            }
        }

        public async Task<JsonOperatorProductResponse> transferToDirectGetOperatorProductsMSISDN(string sourceMSISDN,
            string destinationMSISDN,
            string account,
            string product)
        {
            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 2;

            // Validating fraud customers , at_check_fraud

            try
            {

                bool isPermitted = await _appDB.CheckFraudUser(product, destinationMSISDN, sourceMSISDN);
                if (isPermitted == false)
                {
                    result.errorCode = 3;
                    result.status = "Failure";
                    result.message = "Fraud detected. Access Blocked.";
                    return result;
                }

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Error($"  \"GET /transferToDirectGetOperatorProductsMSISDN\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {sourceMSISDN}, destinationMSISDN: {destinationMSISDN}, currency:{account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error: " + ex.Message;
                return result;

            }



            try
            {
                GenericApiResponse<string> operatorProducts = await _TransferToPost.getOperatorProductsMSISDN(destinationMSISDN, account, product);

                if (operatorProducts.Status == 0)
                {

                    PayLoad payload = new PayLoad();

                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();


                    XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                    xmlDoc.LoadXml(operatorProducts.Result); // Load the XML document from the specified file

                    int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    //   var enRates = await _appDB.GetEndRates(operatorid, account, 2, originDestinationId);

                    XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                    if (xmlproductslist.Count == 0)
                    {
                        // return empty reply
                    }
                    string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                    string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                    string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');

                    string GUID = Guid.NewGuid().ToString();
                    operatorDetails.id = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;         //OperatorID
                    operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                    operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name
                    operatorDetails.nowtelTransactionReference = GUID;
                    operatorDetails.iconUri = "https://operator-logo.transferto.com/logo-" + xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText + "-1.png";       //operator logo

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.insertTransactionGUID2(GUID, account, destinationMSISDN, "{}", "", "", 2, sourceMSISDN, "", "", product);
                    if (dbResult.DBStatus == 0)
                    {
                        _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:transferTo API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:transferTo API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        for (int a = 0; a < productslist.Length; a++)
                        {
                            decimal productValue = Convert.ToDecimal(productslist[a]);

                            //   var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                            //   if (endrate != null)
                            {
                                products.Add(_appDB.GetProduct(
                                account,         //clientccy
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                productslist[a],     //product
                                //wholesalespricelist[a],  //itemPriceClientccy
                                //retailpricelist[a]   //totalPriceClientccy
                                retailpricelist[a],
                                retailpricelist[a]
                                //endrate.CustomerChargeValue.ToString(),
                                // endrate.CustomerChargeValue.ToString()
                                 ));

                                await _appDB.insertaccessDetails(dbResult.InsertId,
                                account,
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,
                                productslist[a],
                                retailpricelist[a],
                                retailpricelist[a],
                                //endrate.CustomerChargeValue.ToString(),
                                //endrate.CustomerChargeValue.ToString(),
                                0
                                );
                            }
                        }
                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _loggerAPIAccess.Information($"  \"GET /transferToGetOperatorProductsMSISDN\"  Success      Parameters-msisdn:{destinationMSISDN} currency:{account}");

                        return result;
                    }
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:TransferTo API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}       Reason={operatorProducts.Message}");
                    // var result2 = new { errorCode = 2, status = "Failure", message = operatorProducts.Message };
                    //return Json(result2);

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = operatorProducts.Message;
                    return result;


                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                return result;
            }
        }

        public async Task<JsonOperatorProductResponse> DTOneDirectGetOperatorProductsMSISDN(string sourceMSISDN, string destinationMSISDN, string account, string product, string productItemCode)
        {
            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 2;


            // Validating fraud customers , at_check_fraud

            try
            {

                bool isPermitted = await _appDB.CheckFraudUser(product, destinationMSISDN, sourceMSISDN);
                if (isPermitted == false)
                {
                    result.errorCode = 3;
                    result.status = "Failure";
                    result.message = "Fraud detected. Access Blocked.";
                    return result;
                }

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Error($"  \"GET /DTOneDirectGetOperatorProductsMSISDN\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {sourceMSISDN}, destinationMSISDN: {destinationMSISDN}, currency:{account},   ErrorMessage:{ex.Message}, StackTrace: {ex.StackTrace}");

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error: " + ex.Message;
                return result;

            }

           // var discountPercentage = await _common_BL.GetDiscountSettings(product, productItemCode, destinationMSISDN, sourceMSISDN);// Get the discount if any exists in db agains destination

            try
            {
                GenericApiResponse<string> operatorProducts = await _TransferToPost.getOperatorProductsMSISDN(destinationMSISDN, account, product);

                if (operatorProducts.Status == 0)
                {

                    PayLoad payload = new PayLoad();

                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();


                    XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                    xmlDoc.LoadXml(operatorProducts.Result); // Load the XML document from the specified file

                    int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    //   var enRates = await _appDB.GetEndRates(operatorid, account, 2, originDestinationId);

                    XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                    if (xmlproductslist.Count == 0)
                    {
                        // return empty reply
                    }
                    string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                    string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                    string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');

                    string GUID = Guid.NewGuid().ToString();
                    operatorDetails.id = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;         //OperatorID
                    operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                    operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name
                    operatorDetails.nowtelTransactionReference = GUID;
                    operatorDetails.ProductItemCode = productItemCode;
                    operatorDetails.iconUri = "https://operator-logo.transferto.com/logo-" + xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText + "-1.png";       //operator logo

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.insertTransactionGUID_Trh(GUID, account, destinationMSISDN, "{}", "", "", 2, sourceMSISDN, productItemCode, "", "", product, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country);
                    if (dbResult.DBStatus == 0)
                    {
                        _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:transferTo API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:transferTo API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        for (int a = 0; a < productslist.Length; a++)
                        {
                            decimal productValue = Convert.ToDecimal(productslist[a]);

                            //   var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                            //   if (endrate != null)
                            {

                                var discountPercentage = await _common_BL.GetDiscountSettings(product, productItemCode, destinationMSISDN, sourceMSISDN, Convert.ToDecimal(retailpricelist[a]));// Get the discount if any exists in db agains destination

                                var attProduct = _appDB.GetProduct(
                                account,         //clientccy
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                productslist[a],     //product
                                //wholesalespricelist[a],  //itemPriceClientccy
                                //retailpricelist[a]   //totalPriceClientccy
                                retailpricelist[a],
                                retailpricelist[a]
                                //endrate.CustomerChargeValue.ToString(),
                                // endrate.CustomerChargeValue.ToString()
                                 );

                                attProduct.discountPercentage = discountPercentage;
                                attProduct.orignalAmount = attProduct.totalPriceClientccy;
                                attProduct.itemPriceClientccy = Math.Round((Convert.ToDecimal(attProduct.orignalAmount) - (Convert.ToDecimal(attProduct.orignalAmount) * attProduct.discountPercentage / 100)), 2).ToString();
                                attProduct.totalPriceClientccy = attProduct.itemPriceClientccy;

                                products.Add(attProduct);

                                await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                                account,
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,
                                productslist[a],
                                wholesalespricelist[a],
                                wholesalespricelist[a],
                                attProduct.totalPriceClientccy,
                                //endrate.CustomerChargeValue.ToString(),
                                //endrate.CustomerChargeValue.ToString(),
                                0, discountPercentage: attProduct.discountPercentage,
                                orignalAmount: attProduct.orignalAmount
                                );
                            }
                        }
                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _loggerAPIAccess.Information($"  \"GET /transferToGetOperatorProductsMSISDN\"  Success      Parameters-msisdn:{destinationMSISDN} currency:{account}");

                        return result;
                    }
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:TransferTo API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}       Reason={operatorProducts.Message}");
                    // var result2 = new { errorCode = 2, status = "Failure", message = operatorProducts.Message };
                    //return Json(result2);
                    result.errorCodeDtOne = operatorProducts.Status;
                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = operatorProducts.Message;
                    return result;


                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                return result;
            }
        }


        public async Task<JsonOperatorProductResponse> transferToDirectGetOperatorProductsMSISDN(string sourceMSISDN, string destinationMSISDN, string account, string productCode = null, string productItemCode = null)
        {
            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 2;

            // Validating fraud customers , at_check_fraud

            try
            {

                bool isPermitted = await _appDB.CheckFraudUser("", destinationMSISDN, sourceMSISDN);
                if (isPermitted == false)
                {
                    result.errorCode = 3;
                    result.status = "Failure";
                    result.message = "Fraud detected. Access Blocked.";
                    return result;
                }

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Error($"  \"GET /DTOneDirectGetOperatorProductsMSISDN\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {sourceMSISDN}, destinationMSISDN: {destinationMSISDN}, currency:{account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error: " + ex.Message;
                return result;

            }

            //var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, destinationMSISDN, sourceMSISDN);// Get the discount if any exists in db agains destination

            try
            {
                var GetPRoductStartTime = DateTime.Now;
                var productJson = "{}";
                var requestJson = "";
                var responseJson = "";
                var serviceProviderId = 2;

                GenericApiResponse<string> operatorProducts;

                if (productCode.ToUpper() != "TRH")
                {
                    operatorProducts = await _TransferToPost.getOperatorProductsMSISDN(destinationMSISDN, account, long.Parse(sourceMSISDN));
                }
                else
                {
                    operatorProducts = await _TransferToPost.getOperatorProductsMSISDN(destinationMSISDN, account, productCode);
                }
                try
                {
                    requestJson = "destinationMSISDN: " + destinationMSISDN + " account:" + account + "sourceMSISDN" + sourceMSISDN + "Message " + operatorProducts.Message; responseJson = JsonConvert.SerializeObject(operatorProducts.Result?.ToString());
                }
                catch
                {

                }
                var GetPRoductEndTime = DateTime.Now;

                if (operatorProducts.Status == 0)
                {

                    PayLoad payload = new PayLoad();

                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();


                    XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                    xmlDoc.LoadXml(operatorProducts.Result); // Load the XML document from the specified file

                    int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    //   var enRates = await _appDB.GetEndRates(operatorid, account, 2, originDestinationId);

                    XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                    if (xmlproductslist.Count == 0)
                    {
                        // return empty reply
                    }
                    string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                    string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                    string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');

                    string GUID = Guid.NewGuid().ToString();
                    operatorDetails.id = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;         //OperatorID
                    operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                    operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name
                    operatorDetails.nowtelTransactionReference = GUID;
                    operatorDetails.iconUri = "https://operator-logo.transferto.com/logo-" + xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText + "-1.png";       //operator logo

                    DBResponse dbResult = new DBResponse();
                    //dbResult = await _appDB.insertTransactionGUID1(GUID, account, destinationMSISDN, productJson,requestJson,responseJson,serviceProviderId, sourceMSISDN, GetProductApiTime: (GetPRoductEndTime - GetPRoductStartTime).TotalMilliseconds,productItemCode:productItemCode);
                    dbResult = await _appDB.insertTransactionGUID_Tha(operatorDetails.nowtelTransactionReference, account.ToUpper(), destinationMSISDN, productJson, requestJson, responseJson, serviceProviderId, sourceMSISDN, productItemCode, "", operatorDetails.id, productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country, GetProductApiTime: (GetPRoductEndTime - GetPRoductStartTime).TotalMilliseconds);
                    if (dbResult.DBStatus == 0)
                    {
                        _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:transferTo API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:transferTo API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        for (int a = 0; a < productslist.Length; a++)
                        {
                            decimal productValue = Convert.ToDecimal(productslist[a]);

                            //   var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                            //   if (endrate != null)
                            {

                                var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, destinationMSISDN, sourceMSISDN, Convert.ToDecimal(retailpricelist[a]));// Get the discount if any exists in db agains destination

                                var attProduct = _appDB.GetProduct(
                                account,         //clientccy
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                productslist[a],     //product
                                //wholesalespricelist[a],  //itemPriceClientccy
                                //retailpricelist[a]   //totalPriceClientccy
                                retailpricelist[a],
                                retailpricelist[a]
                                //endrate.CustomerChargeValue.ToString(),
                                // endrate.CustomerChargeValue.ToString()
                                 );


                                attProduct.discountPercentage = discountPercentage;
                                attProduct.orignalAmount = attProduct.totalPriceClientccy;
                                attProduct.itemPriceClientccy = Math.Round((Convert.ToDecimal(attProduct.orignalAmount) - (Convert.ToDecimal(attProduct.orignalAmount) * attProduct.discountPercentage / 100)), 2).ToString();
                                attProduct.totalPriceClientccy = attProduct.itemPriceClientccy;

                                products.Add(attProduct);

                                await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                                account,
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,
                                productslist[a],
                                wholesalespricelist[a],
                                wholesalespricelist[a],
                                attProduct.totalPriceClientccy,
                                //endrate.CustomerChargeValue.ToString(),
                                //endrate.CustomerChargeValue.ToString(),
                                0,
                                discountPercentage: attProduct.discountPercentage,
                                orignalAmount: attProduct.orignalAmount
                                );
                            }
                        }
                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _loggerAPIAccess.Information($"  \"GET /transferToGetOperatorProductsMSISDN\"  Success      Parameters-msisdn:{destinationMSISDN} currency:{account}");

                        return result;
                    }
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:TransferTo API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}       Reason={operatorProducts.Message}");
                    // var result2 = new { errorCode = 2, status = "Failure", message = operatorProducts.Message };
                    //return Json(result2);

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = operatorProducts.Message;


                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                    {
                        await _common_BL.SendEmail(new EmailTransactionModel()
                        {
                            ErrorMessage = result.message,
                            Status = "Failure",
                            FromMsisdn = sourceMSISDN,
                            ToMsisdn = destinationMSISDN,
                            ProductCode = productCode,
                            ProductItemCode = productItemCode,
                            ServiceProviderName = ServiceProvider.TransferTo.ToString(),
                            TransationType = TransationType.Get
                        });
                    }
                    await _appDB.insertGetProductsAccessErrors(account, destinationMSISDN, result.servcieproviderid, sourceMSISDN, productCode, productItemCode, result.message);
                    return result;


                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                if (SmtpConfig.sendErrorGetProductsEmail)
                {
                    await _common_BL.SendEmail(new EmailTransactionModel()
                    {
                        ErrorMessage = ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                        Status = "Failure",
                        FromMsisdn = sourceMSISDN,
                        ToMsisdn = destinationMSISDN,
                        ProductCode = productCode,
                        ProductItemCode = productItemCode,
                        ServiceProviderName = ServiceProvider.TransferTo.ToString(),
                        TransationType = TransationType.Get
                    });
                }
                await _appDB.insertGetProductsAccessErrors(account, destinationMSISDN, result.servcieproviderid, sourceMSISDN, productCode, productItemCode, ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""));
                return result;
            }
        }

        public async Task<JsonOperatorProductResponse> CRM_ATT_transferToDirectGetOperatorProductsMSISDN(string fromMSISDN, string account, string ToMsisdn, int? cdsp_config_id, string productCode, string productItemCode, string ProductId, int selectedCarrierNumber)
        {
            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 2;

            // Validating fraud customers , at_check_fraud

            try
            {

                bool isPermitted = await _appDB.CheckFraudUser("", ToMsisdn, fromMSISDN);
                if (isPermitted == false)
                {
                    result.errorCode = 3;
                    result.status = "Failure";
                    result.message = "Fraud detected. Access Blocked.";
                    return result;
                }

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Error($"  \"GET /CRM_ATT_transferToDirectGetOperatorProductsMSISDN\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {fromMSISDN}, destinationMSISDN: {ToMsisdn}, currency:{account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error: " + ex.Message;
                return result;

            }



            try
            {
                var GetPRoductStartTime = DateTime.Now;
                var productJson = "{}";
                var requestJson = "";
                var responseJson = "";
                var serviceProviderId = 2;
                //  GenericApiResponse<string> operatorProducts = await _TransferToPost.getOperatorProductsMSISDN(ToMsisdn, account);
                GenericApiResponse<string> operatorProducts = new GenericApiResponse<string>();
                if (ProductId.ToLower().Equals("trhivr"))
                {
                    operatorProducts = await _TransferToPost.getFreeSwitchOperatorProductsMSISDN(ToMsisdn, account);
                }
                else
                {
                    operatorProducts = await _TransferToPost.getOperatorProductsMSISDN(ToMsisdn, account, long.Parse(fromMSISDN));
                }
                try
                {
                    requestJson = "destinationMSISDN: " + ToMsisdn + " account:" + account + "sourceMSISDN" + fromMSISDN + "Message " + operatorProducts.Message; responseJson = JsonConvert.SerializeObject(operatorProducts.Result?.ToString());
                }
                catch
                {

                }
                var GetPRoductEndTime = DateTime.Now;

                if (operatorProducts.Status == 0)
                {

                    PayLoad payload = new PayLoad();

                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();


                    XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                    xmlDoc.LoadXml(operatorProducts.Result); // Load the XML document from the specified file

                    int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    //   var enRates = await _appDB.GetEndRates(operatorid, account, 2, originDestinationId);

                    XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                    if (xmlproductslist.Count == 0)
                    {
                        // return empty reply
                    }
                    string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                    string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                    string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');

                    string GUID = Guid.NewGuid().ToString();
                    operatorDetails.id = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;         //OperatorID
                    operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                    operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name
                    operatorDetails.nowtelTransactionReference = GUID;
                    operatorDetails.ProductItemCode = productItemCode;
                    operatorDetails.iconUri = "https://operator-logo.transferto.com/logo-" + xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText + "-1.png";       //operator logo

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.Com_ATT_insertTransactionGUID(ProductId, operatorDetails.nowtelTransactionReference, account.ToUpper(), ToMsisdn, productJson, requestJson, responseJson, serviceProviderId, fromMSISDN, productItemCode, xmlDoc.GetElementsByTagName("countryid").Item(0).InnerText, operatorDetails.id, productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country, GetProductApiTime: (GetPRoductEndTime - GetPRoductStartTime).TotalMilliseconds);

                    if (dbResult.DBStatus == 0)
                    {
                        _loggerAPIAccess.Debug($"  \"GET /CRM_ATT_transferToDirectGetOperatorProductsMSISDN\"  Failed  Source:transferTo API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:transferTo API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        if (cdsp_config_id.HasValue)
                        {
                            COMM_ATT_CustomerChargeValuesForReplacement custChargeValues = new COMM_ATT_CustomerChargeValuesForReplacement();
                            custChargeValues = await _appDB.Com_ATT_GetCustomerChargeValuesForReplacement(cdsp_config_id.Value, selectedCarrierNumber);



                            foreach (var custChargeValue in custChargeValues.chargeValues.Where(r => r.buying_price >= Convert.ToDecimal(wholesalespricelist[0]) && r.buying_price <= Convert.ToDecimal(wholesalespricelist[wholesalespricelist.Length - 1])))
                            {

                                decimal productValue = Convert.ToDecimal(productslist.FirstOrDefault(s => Convert.ToDecimal(s) == custChargeValue.received_amount));
                                //var indexOFProduct=Array.IndexOf( productslist,productValue);
                                if (productValue == custChargeValue.received_amount)
                                {
                                    //products.Add(_appDB.GetProduct(
                                    //account,         //clientccy
                                    //xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                    //productslist[a],     //product
                                    //                     //wholesalespricelist[a],  //itemPriceClientccy
                                    //                     //retailpricelist[a]   //totalPriceClientccy
                                    //retailpricelist[a],
                                    //retailpricelist[a]
                                    // //endrate.CustomerChargeValue.ToString(),
                                    // // endrate.CustomerChargeValue.ToString()
                                    // ));

                                    AttProduct product = new AttProduct();
                                    product.product = custChargeValue.received_amount.ToString(); //((int)Math.Floor((dingProductDetailedResponse.Items[0].Minimum.ReceiveValue / dingProductDetailedResponse.Items[0].Minimum.SendValue) * custChargeValue.buying_price)).ToString();
                                    product.receiverccy = xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText; //receiverccy
                                    product.clientccy = account;                                                                                      //// have to add product.clientccy = dingProductDetailedResponse.Items[0].Minimum.SendCurrencyIso;
                                    product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                    product.totalPriceClientccy = custChargeValue.selling_price.ToString();
                                    product.transactionfeeClientccy = 0.ToString();
                                    products.Add(product);



                                    //await _appDB.insertaccessDetails(dbResult.InsertId,
                                    //account,
                                    //xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,
                                    //productslist[a],
                                    //retailpricelist[a],
                                    //retailpricelist[a],
                                    ////endrate.CustomerChargeValue.ToString(),
                                    ////endrate.CustomerChargeValue.ToString(),
                                    //0
                                    //);
                                    await _appDB.insertaccessDetails(dbResult.InsertId,
     account,
     product.receiverccy,
     product.product,
     custChargeValue.buying_price.ToString(),
     custChargeValue.buying_price.ToString(),
     custChargeValue.selling_price.ToString(),
     //endrate.CustomerChargeValue.ToString(),
     //endrate.CustomerChargeValue.ToString(),
     0
     );

                                }
                            }
                        }
                        else
                        {
                            for (int a = 0; a < productslist.Length; a++)
                            {
                                decimal productValue = Convert.ToDecimal(productslist[a]);

                                //   var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                                //   if (endrate != null)
                                {
                                    products.Add(_appDB.GetProduct(
                                    account,         //clientccy
                                    xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                    productslist[a],     //product
                                                         //wholesalespricelist[a],  //itemPriceClientccy
                                                         //retailpricelist[a]   //totalPriceClientccy
                                    retailpricelist[a],
                                    retailpricelist[a]
                                     //endrate.CustomerChargeValue.ToString(),
                                     // endrate.CustomerChargeValue.ToString()
                                     ));

                                    await _appDB.insertaccessDetails(dbResult.InsertId,
                                    account,
                                    xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,
                                    productslist[a],
                                    wholesalespricelist[a],
                                    wholesalespricelist[a],
                                    retailpricelist[a],
                                    //endrate.CustomerChargeValue.ToString(),
                                    //endrate.CustomerChargeValue.ToString(),
                                    0
                                    );
                                }
                            }
                        }
                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _loggerAPIAccess.Information($"  \"GET /CRM_ATT_transferToDirectGetOperatorProductsMSISDN\"  Success      Parameters-msisdn:{ToMsisdn} currency:{account}");

                        return result;
                    }
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /CRM_ATT_transferToDirectGetOperatorProductsMSISDN\"  Failed  Source:TransferTo API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={operatorProducts.Message}");
                    // var result2 = new { errorCode = 2, status = "Failure", message = operatorProducts.Message };
                    //return Json(result2);

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = operatorProducts.Message;
                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                    {
                        await _common_BL.SendEmail(new EmailTransactionModel()
                        {
                            ErrorMessage = result.message,
                            Status = "Failure",
                            FromMsisdn = fromMSISDN,
                            ToMsisdn = ToMsisdn,
                            ProductCode = productCode,
                            ProductItemCode = productItemCode,
                            ServiceProviderName = ServiceProvider.TransferTo.ToString(),
                            TransationType = TransationType.Get
                        });
                    }
                    await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message);
                    return result;


                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /CRM_ATT_transferToDirectGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                if (SmtpConfig.sendErrorGetProductsEmail)
                {
                    await _common_BL.SendEmail(new EmailTransactionModel()
                    {
                        ErrorMessage = ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                        Status = "Failure",
                        FromMsisdn = fromMSISDN,
                        ToMsisdn = ToMsisdn,
                        ProductCode = productCode,
                        ProductItemCode = productItemCode,
                        ServiceProviderName = ServiceProvider.TransferTo.ToString(),
                        TransationType = TransationType.Get
                    });
                }
                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""));
                return result;
            }
        }


        public async Task<JsonATTCRMOperatorProductResponse> transferToATTCRMDirectGetOperatorProductsMSISDN(string sourceMSISDN, string destinationMSISDN, string account, string productId)
        {
            JsonATTCRMOperatorProductResponse result = new JsonATTCRMOperatorProductResponse();

            try
            {
                var GetPRoductStartTime = DateTime.Now;
                var productJson = "{}";
                var requestJson = "";
                var responseJson = "";
                var serviceProviderId = 2;
                long? sMsisdn = null;
                if (sourceMSISDN != null)
                    sMsisdn = long.Parse(sourceMSISDN);
                GenericApiResponse<string> operatorProducts = new GenericApiResponse<string>();
                if (productId.ToLower().Equals("trhivr"))
                {
                    operatorProducts = await _TransferToPost.getFreeSwitchOperatorProductsMSISDN(destinationMSISDN, account);
                }
                else
                {
                    operatorProducts = await _TransferToPost.getOperatorProductsMSISDN(destinationMSISDN, account, sMsisdn);
                }


                try
                {
                    requestJson = "destinationMSISDN: " + destinationMSISDN + " account:" + account + "sourceMSISDN" + sourceMSISDN + "Message " + operatorProducts.Message; responseJson = JsonConvert.SerializeObject(operatorProducts.Result?.ToString());
                    _loggerAPIAccess.Debug($"{productJson}");
                }
                catch
                {

                }

                if (operatorProducts.Status == 0)
                {

                    ATTCRMPayLoad payload = new ATTCRMPayLoad();

                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttCRMOperator> operators = new List<AttCRMOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttCRMOperator operatorDetails = new AttCRMOperator();


                    XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                    xmlDoc.LoadXml(operatorProducts.Result); // Load the XML document from the specified file

                    int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    //   var enRates = await _appDB.GetEndRates(operatorid, account, 2, originDestinationId);

                    XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                    if (xmlproductslist.Count == 0)
                    {
                        // return empty reply
                    }
                    string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                    string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                    string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');

                    operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                    operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name

                    for (int a = 0; a < productslist.Length; a++)
                    {
                        decimal productValue = Convert.ToDecimal(productslist[a]);

                        //   var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                        //   if (endrate != null)
                        {
                            products.Add(_appDB.GetProduct(
                            account,         //clientccy
                            xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                            productslist[a],     //product
                                                 //wholesalespricelist[a],  //itemPriceClientccy
                                                 //retailpricelist[a]   //totalPriceClientccy
                            retailpricelist[a],
                            retailpricelist[a]
                             //endrate.CustomerChargeValue.ToString(),
                             // endrate.CustomerChargeValue.ToString()
                             ));

                        }
                    }
                    operatorDetails.products = products;
                    operators.Add(operatorDetails);
                    payload.operators = operators;
                    result.ATTCRMpayload = payload;
                    _loggerAPIAccess.Information($"  \"GET /transferToATTCRMDirectGetOperatorProductsMSISDN\"  Success      Parameters-msisdn:{destinationMSISDN} currency:{account}");

                    return result;
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToATTCRMDirectGetOperatorProductsMSISDN\"  Failed  Source:TransferTo API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}       Reason={operatorProducts.Message}");
                    // var result2 = new { errorCode = 2, status = "Failure", message = operatorProducts.Message };
                    //return Json(result2);

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = operatorProducts.Message;
                    return result;


                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToATTCRMDirectGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                return result;
            }
        }

        #region FreeSwitch

        // For FreeSwitch Daemon
        public async Task<JsonOperatorProductResponse> transferToFreeSwitchGetOperatorProductsMSISDN(string sourceMSISDN, string destinationMSISDN, string account, string productCode, string productItemCode)
        {
            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 2;

            try
            {
                var GetPRoductStartTime = DateTime.Now;
                GenericApiResponse<string> operatorProducts = await _TransferToPost.getFreeSwitchOperatorProductsMSISDN(destinationMSISDN, account);
                var productJson = "{}";
                var requestJson = "";
                var responseJson = "";
                var serviceProviderId = 2;
                try
                {
                    requestJson = "destinationMSISDN: " + destinationMSISDN + " account:" + account + "sourceMSISDN" + sourceMSISDN + "Message " + operatorProducts.Message; responseJson = JsonConvert.SerializeObject(operatorProducts.Result?.ToString());
                }
                catch
                {

                }

                var GetPRoductEndTime = DateTime.Now;
                if (operatorProducts.Status == 0)
                {

                    PayLoad payload = new PayLoad();

                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();


                    XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                    xmlDoc.LoadXml(operatorProducts.Result); // Load the XML document from the specified file

                    int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    //   var enRates = await _appDB.GetEndRates(operatorid, account, 2, originDestinationId);

                    XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                    if (xmlproductslist.Count == 0)
                    {
                        // return empty reply
                    }
                    string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                    string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                    string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');

                    string GUID = Guid.NewGuid().ToString();
                    operatorDetails.id = xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText;         //OperatorID
                    operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                    operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name
                    operatorDetails.nowtelTransactionReference = GUID;
                    operatorDetails.iconUri = "https://operator-logo.transferto.com/logo-" + xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText + "-1.png";       //operator logo

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.insertTransactionGUID_Trh(GUID, account, destinationMSISDN, productJson, requestJson, responseJson, serviceProviderId, sourceMSISDN, productItemCode, "", "", productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country, GetProductApiTime: (GetPRoductEndTime - GetPRoductStartTime).TotalMilliseconds);
                    //dbResult = await _appDB.insertTransactionGUID1(GUID, account, destinationMSISDN, "{}", sourceMSISDN);
                    if (dbResult.DBStatus == 0)
                    {
                        _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:transferTo API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:transferTo API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        for (int a = 0; a < productslist.Length; a++)
                        {
                            decimal productValue = Convert.ToDecimal(productslist[a]);

                            //   var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                            //   if (endrate != null)
                            {
                                products.Add(_appDB.GetProduct(
                                account,         //clientccy
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                                productslist[a],     //product
                                //wholesalespricelist[a],  //itemPriceClientccy
                                //retailpricelist[a]   //totalPriceClientccy
                                retailpricelist[a],
                                retailpricelist[a]
                                //endrate.CustomerChargeValue.ToString(),
                                // endrate.CustomerChargeValue.ToString()
                                 ));

                                await _appDB.insertaccessDetails(dbResult.InsertId,
                                account,
                                xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,
                                productslist[a],
                                retailpricelist[a],
                                retailpricelist[a],
                                //endrate.CustomerChargeValue.ToString(),
                                //endrate.CustomerChargeValue.ToString(),
                                0
                                );
                            }
                        }
                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _loggerAPIAccess.Information($"  \"GET /transferToGetOperatorProductsMSISDN\"  Success      Parameters-msisdn:{destinationMSISDN} currency:{account}");

                        return result;
                    }
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:TransferTo API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}       Reason={operatorProducts.Message}");
                    // var result2 = new { errorCode = 2, status = "Failure", message = operatorProducts.Message };
                    //return Json(result2);

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = operatorProducts.Message;
                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                    {
                        await _common_BL.SendEmail(new EmailTransactionModel()
                        {
                            ErrorMessage = result.message,
                            Status = "Failure",
                            FromMsisdn = sourceMSISDN,
                            ToMsisdn = destinationMSISDN,
                            ProductCode = productCode,
                            ProductItemCode = productItemCode,
                            ServiceProviderName = ServiceProvider.TransferTo.ToString(),
                            TransationType = TransationType.Get
                        });
                    }
                    await _appDB.insertGetProductsAccessErrors(account, destinationMSISDN, result.servcieproviderid, sourceMSISDN, productCode, productItemCode, result.message);
                    return result;


                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                if (SmtpConfig.sendErrorGetProductsEmail)
                {
                    await _common_BL.SendEmail(new EmailTransactionModel()
                    {
                        ErrorMessage = ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                        Status = "Failure",
                        FromMsisdn = sourceMSISDN,
                        ToMsisdn = destinationMSISDN,
                        ProductCode = productCode,
                        ProductItemCode = productItemCode,
                        ServiceProviderName = ServiceProvider.TransferTo.ToString(),
                        TransationType = TransationType.Get
                    });
                }
                await _appDB.insertGetProductsAccessErrors(account, destinationMSISDN, result.servcieproviderid, sourceMSISDN, productCode, productItemCode, ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""));
                return result;
            }
        }

        public async Task<JsonATTCRMOperatorProductResponse> transferToATTCRMFreeSwitchGetOperatorProductsMSISDN(string destinationMSISDN, string account)
        {
            JsonATTCRMOperatorProductResponse result = new JsonATTCRMOperatorProductResponse();

            try
            {
                GenericApiResponse<string> operatorProducts = await _TransferToPost.getFreeSwitchOperatorProductsMSISDN(destinationMSISDN, account);
                var productJson = "{}";
                var requestJson = "";
                var responseJson = "";
                var serviceProviderId = 2;
                try
                {
                    requestJson = "destinationMSISDN: " + destinationMSISDN + " account:" + account + "Message " + operatorProducts.Message; responseJson = JsonConvert.SerializeObject(operatorProducts.Result?.ToString());
                }
                catch
                {

                }
                if (operatorProducts.Status == 0)
                {

                    ATTCRMPayLoad payload = new ATTCRMPayLoad();

                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttCRMOperator> operators = new List<AttCRMOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttCRMOperator operatorDetails = new AttCRMOperator();


                    XmlDocument xmlDoc = new XmlDocument(); // Create an XML document object
                    xmlDoc.LoadXml(operatorProducts.Result); // Load the XML document from the specified file

                    int operatorid = int.Parse(xmlDoc.GetElementsByTagName("operatorid").Item(0).InnerText);

                    //   var enRates = await _appDB.GetEndRates(operatorid, account, 2, originDestinationId);

                    XmlNodeList xmlproductslist = xmlDoc.GetElementsByTagName("product_list");
                    if (xmlproductslist.Count == 0)
                    {
                        // return empty reply
                    }
                    string[] productslist = xmlproductslist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlwholesalespricelist = xmlDoc.GetElementsByTagName("wholesale_price_list");
                    string[] wholesalespricelist = xmlwholesalespricelist.Item(0).InnerText.Split(',');

                    XmlNodeList xmlretailpricelist = xmlDoc.GetElementsByTagName("retail_price_list");
                    string[] retailpricelist = xmlretailpricelist.Item(0).InnerText.Split(',');

                    string GUID = Guid.NewGuid().ToString();
                    operatorDetails.name = xmlDoc.GetElementsByTagName("operator").Item(0).InnerText;       //OperatorName
                    operatorDetails.country = xmlDoc.GetElementsByTagName("country").Item(0).InnerText;        //country Name

                    for (int a = 0; a < productslist.Length; a++)
                    {
                        decimal productValue = Convert.ToDecimal(productslist[a]);

                        //   var endrate = enRates.Where(s => s.DestinationReceiveValue == productValue).FirstOrDefault();

                        //   if (endrate != null)
                        {
                            products.Add(_appDB.GetProduct(
                            account,         //clientccy
                            xmlDoc.GetElementsByTagName("destination_currency").Item(0).InnerText,    //receiverccy
                            productslist[a],     //product
                                                 //wholesalespricelist[a],  //itemPriceClientccy
                                                 //retailpricelist[a]   //totalPriceClientccy
                            wholesalespricelist[a],
                            wholesalespricelist[a]
                             //endrate.CustomerChargeValue.ToString(),
                             // endrate.CustomerChargeValue.ToString()
                             ));
                        }
                    }


                    operatorDetails.products = products;
                    operators.Add(operatorDetails);
                    payload.operators = operators;
                    result.ATTCRMpayload = payload;
                    _loggerAPIAccess.Information($"  \"GET /transferToGetOperatorProductsMSISDN\"  Success      Parameters-msisdn:{destinationMSISDN} currency:{account}");

                    return result;
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToATTCRMFreeSwitchGetOperatorProductsMSISDN\"  Failed  Source:TransferTo API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}       Reason={operatorProducts.Message}");
                    // var result2 = new { errorCode = 2, status = "Failure", message = operatorProducts.Message };
                    //return Json(result2);

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = operatorProducts.Message;
                    return result;


                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToATTCRMFreeSwitchGetOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                return result;
            }
        }

        // For Free Switch
        public async Task<object> ExecuteTransactionFreeSwitch(ExecuteData data)
        {
            try
            {
                string nowtelTransactionReference = data.nowtelTransactionReference;
                string operatorid = data.operatorid;
                string product = data.product;
                string messageToRecipient = data.messageToRecipient;
                string fromMSISDN = data.fromMSISDN;

                // APIAccessGUID guidReferneceRecord = await _appDB.getTransactionGUIDRecord(nowtelTransactionReference, product);
                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(nowtelTransactionReference, product);

                if (guidReferneceRecord == null)
                {
                    _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return result;
                }
                try
                {


                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn,data.nowtelTransactionReference.Remove(0, 14), data.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    _loggerAPIAccess.Error($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return result;
                }
                long RequestKey = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;

                try
                {
                    var TopUpApiStartTime = DateTime.Now;
                    GenericApiResponse<transfertoExecuteTransaction> execTransactionResponse = await _TransferToPost.transfertoExecuteTransactionFreeSwitch(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, RequestKey);
                    var TopUpApiEndTime = DateTime.Now;

                    if (execTransactionResponse.Status == 0)
                    {
                        //Successful transaction
                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh(
                                DateTime.Now.ToString(),
                                TransferToConf.AttFreeSwitchUsernameEUR, // Username
                                guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                                execTransactionResponse.Result.wholesale_price,  // Actual Charge Value
                                decimal.Parse(execTransactionResponse.Result.product_requested),
                                execTransactionResponse.Result.originating_currency,
                                execTransactionResponse.Result.destination_currency,
                                execTransactionResponse.Result.country,
                                "Success",
                                "",
                                execTransactionResponse.Result.operatorid,
                                execTransactionResponse.Result.product_requested,
                                execTransactionResponse.Result.@operator,
                                RequestKey.ToString(),
                                execTransactionResponse.Result.transactionid,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                2,
                                messageToRecipient,
                                guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                nowtelTransactionReference,
                                $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}, RequestKey:{RequestKey}",
                        execTransactionResponse.Result.ToString(),
                                TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                );

                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }


                        _loggerAPIAccess.Information($"  \"POST /transfertoExecuteTransaction\"   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                            currency = execTransactionResponse.Result.originating_currency,
                            reference = execTransactionResponse.Result.transactionid
                        };
                        return result;
                    }
                    else
                    {
                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh(
                           DateTime.Now.ToString(),
                            TransferToConf.AttFreeSwitchUsernameEUR, // Username
                           guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                           -1,
                           decimal.Parse(product),
                           guidReferneceRecord.account,
                           "",
                           "",
                           "Failure",
                           execTransactionResponse.Message,
                           operatorid,
                           product,
                           "",
                           RequestKey.ToString(),
                           "",
                           fromMSISDN,
                           guidReferneceRecord.tomsisdn,
                           2,
                           messageToRecipient,
                           guidReferneceRecord.productCode,
                           guidReferneceRecord.ProductItemCode,
                           nowtelTransactionReference,
                            "", "",
                        TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                        );

                            if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                            {
                                await _common_BL.SendEmail(new EmailTransactionModel()
                                {
                                    accessGUID = nowtelTransactionReference,
                                    DestinationCountry = guidReferneceRecord.destination_country,
                                    ErrorMessage = execTransactionResponse.Message,
                                    Status = "Failure",
                                    FromMsisdn = guidReferneceRecord.frommsisdn,
                                    ToMsisdn = guidReferneceRecord.tomsisdn,
                                    OperatorId = guidReferneceRecord.operatorCode,
                                    OperatorName = guidReferneceRecord.operatorName,
                                    ProductCode = guidReferneceRecord.productCode,
                                    ProductItemCode = guidReferneceRecord.ProductItemCode,
                                    ServiceProviderName = ServiceProvider.TransferTo.ToString(),
                                    TransationType = TransationType.Execute
                                });
                            }

                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                        _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}          Reason={execTransactionResponse.Message}");
                        var result = new { errorCode = 2, status = "Failure", message = execTransactionResponse.Message };
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    try
                    {

                        await _appDB.insertAirTimeTransferTransaction_Trh(
                        DateTime.Now.ToString(),
                        TransferToConf.AttFreeSwitchUsernameEUR, // Username
                        guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        "",
                        "",
                        "FailureException",
                        ex.Message,
                        operatorid,
                        product,
                        "",
                        RequestKey.ToString(),
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        2,
                        messageToRecipient,
                        guidReferneceRecord.productCode,
                        guidReferneceRecord.ProductItemCode,
                        nowtelTransactionReference,
                        "",
                        ""
                        );

                        if (SmtpConfig.sendErrorExecuteTransactionEmail)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                accessGUID = nowtelTransactionReference,
                                DestinationCountry = guidReferneceRecord.destination_country,
                                ErrorMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                                Status = "FailureException",
                                FromMsisdn = guidReferneceRecord.frommsisdn,
                                ToMsisdn = guidReferneceRecord.tomsisdn,
                                OperatorId = guidReferneceRecord.operatorCode,
                                OperatorName = guidReferneceRecord.operatorName,
                                ProductCode = guidReferneceRecord.productCode,
                                ProductItemCode = guidReferneceRecord.ProductItemCode,
                                ServiceProviderName = ServiceProvider.TransferTo.ToString(),
                                TransationType = TransationType.Execute

                            });
                        }
                    }
                    catch (Exception dbException)
                    {
                        _loggerAPIAccess.Debug($"  \"POST /transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return errorResult;
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return errorResult;
            }
        }

        #endregion FreeSwitch


        #endregion transferToGetOperatorProductsMSISDN


        // Data Bundles GetOperatorsProductsMsisdn

        #region transferToGetDataBundlesOperatorProductsMSISDN

        public async Task<TransfertoDataBundlesProductsJsonResponse> transferToGetDataBundlesOperatorProductsMSISDN(string destinationMSISDN, string account, int originDestinationId)
        {

            TransfertoDataBundlesProductsJsonResponse result = new TransfertoDataBundlesProductsJsonResponse();
            result.servcieproviderid = 2;

            try
            {


                GenericApiResponse<TransferToMSISDNInfoResponse> parsedMSISDNobject = await _TransferToPost.transfertoParseMSISDN(destinationMSISDN, account);

                //GenericApiResponse<string> mSISDNobject = await _TransferToPost.transfertoGoodsServiceParseMsisdn(destinationMSISDN, "678", "7", account);

                if (parsedMSISDNobject.Status == 0)
                {


                    int serviceId = 7;
                    int serviceProviderOperatorId = parsedMSISDNobject.Result.operatorid;//1449;
                    int countryId = parsedMSISDNobject.Result.countryid;//678;
                    try
                    {
                        //  GenericApiResponse<TransfertoDataBundleProductList> servicelist = await _TransferToPost.transfertoDataBundleProductList(account, serviceId, operatorId, countryId);

                        var endrates = _appDBDataBundle.GetDataBundleEndRates(serviceProviderOperatorId, account, 2, originDestinationId);

                        // configuration with database save response in database in accessdatanudledetaisl table 

                        // and return final response according to database rates after comaprsion with api rates  
                        if (endrates != null)
                        {

                            string nowTelTransactionReference = DateTime.Now.Ticks.ToString();
                            DataBundlesOperator operatorDetails = new DataBundlesOperator();

                            // operatorDetails.id = parsedMSISDNobject.Result.operatorid.ToString();         //OperatorID
                            operatorDetails.name = parsedMSISDNobject.Result.@operator;       //OperatorName
                            operatorDetails.country_id = parsedMSISDNobject.Result.countryid;   // country Id
                            operatorDetails.country = parsedMSISDNobject.Result.country;        //country Name
                            operatorDetails.nowtelTransactionReference = nowTelTransactionReference;
                            operatorDetails.iconUri = "https://operator-logo.transferto.com/logo-" + parsedMSISDNobject.Result.operatorid.ToString() + "-1.png";       //operator logo

                            var productsDataBundles = endrates;
                            List<DataBundleProductList> productlist = new List<DataBundleProductList>();
                            foreach (var item in productsDataBundles)
                            {
                                operatorDetails.id = item.OperatorId.ToString();         //OperatorID;
                                operatorDetails.ProductApiType = item.ProductType;

                                if (item.ProductType == "ATT")
                                {
                                    productlist.Add(new DataBundleProductList
                                    {
                                        AccountCurrency = item.ClientCurrency,
                                        ProductCurrency = item.ReceiverCurrency,
                                        ProductId = -1,
                                        Product = item.ProductValue,
                                        ProductDesc = item.BundleVolume + ", " + item.ExpiryDays + " Days",
                                        WholeSalePrice = Math.Round(item.WholeSalePrice, 2),
                                        CalculatedRetailPrice = Math.Round(item.CalculatedRetailPrice, 2),
                                        TransactionFee = Math.Round(item.TransactionFee, 2),
                                        CustomerChargePrice = Math.Round(item.CustomerChargePrice, 2),
                                        BundleVolume = item.BundleVolume,
                                        ExpiryDays = item.ExpiryDays,
                                        Extra = item.Extra,
                                        LocalMinutes = item.LocalMinutes,
                                        InternationalMinutes = item.InternationalMinutes,
                                        InternationalSms = item.InternationalSms,
                                        LocalSms = item.LocalSms,
                                        FacebookData = item.FacebookData,
                                        InstragramData = item.InstragramData,
                                        TwitterData = item.TwitterData,
                                        ProductDisplay = item.ProductDisplay
                                    });
                                }
                                else  // GS ProducyType
                                {
                                    productlist.Add(new DataBundleProductList
                                    {

                                        AccountCurrency = item.ClientCurrency,
                                        ProductCurrency = item.ReceiverCurrency,

                                        ProductId = item.ProductId,
                                        Product = item.ProductName,
                                        ProductDesc = item.ProductDesc,
                                        WholeSalePrice = Math.Round(item.WholeSalePrice, 2),
                                        CalculatedRetailPrice = Math.Round(item.CalculatedRetailPrice, 2),
                                        TransactionFee = Math.Round(item.TransactionFee, 2),
                                        CustomerChargePrice = Math.Round(item.CustomerChargePrice, 2),
                                        BundleVolume = item.BundleVolume,
                                        ExpiryDays = item.ExpiryDays,
                                        Extra = item.Extra,
                                        LocalMinutes = item.LocalMinutes,
                                        InternationalMinutes = item.InternationalMinutes,
                                        InternationalSms = item.InternationalSms,
                                        LocalSms = item.LocalSms,
                                        FacebookData = item.FacebookData,
                                        InstragramData = item.InstragramData,
                                        TwitterData = item.TwitterData,
                                        ProductDisplay = item.ProductDisplay

                                    });
                                }

                            }
                            operatorDetails.products = productlist;

                            List<DataBundlesOperator> operators = new List<DataBundlesOperator>();
                            operators.Add(operatorDetails);
                            DataBundlesOperatorProductsPayLoad payload = new DataBundlesOperatorProductsPayLoad();
                            payload.operators = operators;

                            result.message = "Operator found";
                            result.status = "Success";
                            result.errorCode = 0;
                            result.payload = payload;


                            string productCurrency = string.Empty;

                            string productIdList = string.Empty;
                            string productList = string.Empty;
                            string productDescList = string.Empty;
                            string wholeSalePriceList = string.Empty;
                            string customerChargePriceList = string.Empty;

                            foreach (var item in productlist)
                            {
                                productCurrency = item.ProductCurrency;
                                productIdList += item.ProductId.ToString() + "||";
                                productList += item.Product.ToString() + "||";
                                productDescList += item.ProductDesc.ToString() + "||";
                                wholeSalePriceList += item.WholeSalePrice.ToString() + "||";
                                customerChargePriceList += item.CustomerChargePrice.ToString() + "||";
                            }

                            productIdList = productIdList.TrimEnd(new char[] { '|' });
                            productList = productList.TrimEnd(new char[] { '|' });
                            productDescList = productDescList.TrimEnd(new char[] { '|' });
                            wholeSalePriceList = wholeSalePriceList.TrimEnd(new char[] { '|' });
                            customerChargePriceList = customerChargePriceList.TrimEnd(new char[] { '|' });

                            await _appDBDataBundle.insertDataBundleAccessDetails(

                                   nowTelTransactionReference,
                                   account,
                                   destinationMSISDN,
                                   operatorDetails.ProductApiType,
                                   account, // Clitency
                                   productCurrency,
                                   productIdList,
                                   productList,
                                   productDescList,
                                   wholeSalePriceList.ToString(),
                                   customerChargePriceList
                                   );
                        }
                        else if (endrates == null)
                        {
                            result.message = "No Data Bundle Products available.";
                            result.status = "Failure";
                            result.errorCode = 2;
                        }
                        else
                        {
                            _loggerAPIAccess.Debug($"  \"GET /transferToGetDataBundleProductsMSISDN \"  Failed  Source:GetDataBundleProducts API End Point -  currency:{account} serviceId:{serviceId} , serviceProviderOperatorId:{serviceProviderOperatorId}  , countryId:{countryId}    originDestinationId:{originDestinationId}");
                            result.message = "";
                            result.status = "Failure";
                            result.errorCode = 2;
                        }

                    }
                    catch (Exception ex)
                    {
                        _loggerAPIAccess.Debug($"  \"GET /transferToGetDataBundleProductsMSISDN \"  Failed  Source:General  Parameters-  currency:{account} serviceId:{serviceId} , serviceProviderOperatorId:{serviceProviderOperatorId}  , countryId:{countryId}    Message:{ex.ToString()}");
                        result.message = ex.Message;
                        result.status = "Failure";
                        result.errorCode = 2;
                    }
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /transferToGetDataBundleProductsMSISDN \"  Failed  Source:General  Parameters-  currency:{account}, destinationMSISDN:{destinationMSISDN}, originDestinationId:{originDestinationId}  Message:{parsedMSISDNobject.Message}");
                    result.message = parsedMSISDNobject.Message;
                    result.status = "Failure";
                    result.errorCode = 2;
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /transferToGetDataBundleProductsMSISDN \"  Failed  Source:General  Parameters-  currency:{account}, destinationMSISDN:{destinationMSISDN},   Message:{ex.ToString()}");
                result.message = ex.Message;
                result.status = "Failure";
                result.errorCode = 2;
            }

            return result;
        }

        #endregion transferToGetDataBundlesOperatorProductsMSISDN


    }
}
