﻿using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Request
{
    public class UserSIMOrderRequestModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public ProductType Product { get; set; }
        public bool IsReplacement { get; set; }
    }
}
