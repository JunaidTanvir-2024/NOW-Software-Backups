﻿namespace NowMobile.Api.Models;

public class PaymentResponseModel
{
    public bool IsSuccess { get; set; }
    public int OrderId { get; set; }
    public int ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }
}
