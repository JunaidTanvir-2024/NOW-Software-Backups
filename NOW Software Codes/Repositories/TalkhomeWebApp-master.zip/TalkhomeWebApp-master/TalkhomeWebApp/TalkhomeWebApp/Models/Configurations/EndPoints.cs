﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.Configurations
{
    public class EndPoints
    {
        public string TalkHomeAPIEndPoint { get; set; }
        public string PortingApiEndpoint { get; set; }
    }
}
