﻿namespace THCC.Application.Settings;

public class RateLimitingSettings
{
    public const string SectionName = "RateLimitingSettings";
    public static RateLimitingSettings Bind = new RateLimitingSettings();
    public int? PermitLimit { get; set; }
    public int? QueueLimit { get; set; }
    public int? Window { get; set; }
    public int? AuthPermitLimit { get; set; }
    public int? AuthQueueLimit { get; set; }
    public int? AuthWindow { get; set; }
}
