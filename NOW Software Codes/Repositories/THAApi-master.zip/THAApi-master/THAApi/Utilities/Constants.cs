﻿namespace THAApi.Utilities
{
    public static class Pages
    {
        public const string Resume3DV1Page = "~/Views/Resume3DV1.cshtml";
        public const string Resume3DV2Page = "~/Views/Resume3DV2.cshtml";
        public const string ErrorPage = "~/Views/Error.cshtml";
        public const string SetAutoTopupErrorPage = "~/Views/SetAutoTopupError.cshtml";
        public const string ErrorPageV2 = "~/Views/ErrorV2.cshtml";
        public const string SuccessPage = "~/Views/Success.cshtml";
        public const string LoyaltyInfo = "~/Views/Loyalty.cshtml";
        public const string SendTopup = "~/Views/SendTopup.cshtml";
        public const string WelcomeBundle = "~/Views/WelcomeBundle.cshtml";
        public const string PaygBundle = "~/Views/PaygBundle.cshtml";
        public const string GlobalCredit = "~/Views/GlobalCredits.cshtml";
        public const string AccountTopup = "~/Views/AccountTopup.cshtml";
        public const string SetAutoTopupSuccessPage = "~/Views/SetAutoTopupSuccess.cshtml";
        public const string SetBundleAutoRenewalSuccessPage = "~/Views/SetBundleAutoRenewalSuccessPage.cshtml";
        public const string SetBundleAutoRenewalErrorPage = "~/Views/SetBundleAutoRenewalErrorPage.cshtml";
    }
}