using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.DTOs.Vendors.DTOne;
using FH.Core.Helpers;
using FH.Core.Interfaces.Database;
using FH.Core.Interfaces.Vendors;

using FluentValidation;

using Mediator;

using RW;

namespace FH.UseCases.Cart;
public sealed class BuyBundle
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public required string TransactionReference { get; set; }
        public required long ProductId { get; set; }
        public required string CartReference { get; set; }
        public required string ProductVendorCode { get; set; }
        public required string RecipientMsisdn { get; set; }
        public required string SenderName { get; set; }
        public required string SenderMsisdn { get; set; }
        public required ushort Quantity { get; set; }
    }

    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.TransactionReference).NotNull().NotEmpty();
            RuleFor(x => x.ProductId).GreaterThan(0);
            RuleFor(x => x.SenderMsisdn).NotNull().NotEmpty();
            RuleFor(x => x.RecipientMsisdn).NotNull().NotEmpty();
        }
    }

    #endregion

    #region Response
    public sealed record Response
    {
        public required string TransactionReference { get; set; }
        public IEnumerable<PurchasedItem> PurchasedItems { get; set; } = [];
        public sealed record PurchasedItem
        {
            public required string ProductVendorCode { get; set; }
            public required long ProductId { get; set; }
            public required string Status { get; set; }
        }
    }

    #endregion

    #region Handler
    internal sealed class Handler(IDTOneService dTOneService, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IDTOneService _dTOneService = dTOneService;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            (string firstName, string lastName) = AppHelpers.SplitNames(request.SenderName);
            var buyBundleResult = await _dTOneService.BuyBundle(new DTOneBuyBundle.Request
            {
                AutoConfirm = true,
                ProductId = request.ProductId,
                ProductVendorCode = request.ProductVendorCode,
                ReceiverMsisdn = request.SenderMsisdn,
                SenderMsisdn = request.SenderMsisdn,
                SenderFirstName = firstName,
                SenderLastName = lastName,
                Quantity = request.Quantity,
            });

            if (buyBundleResult?.PurchasedItems.Count > 0)
            {
                foreach (var item in buyBundleResult.PurchasedItems)
                {
                    await _unitOfWork.TransactionRepository.TransactionInsert(new ProductTransactionInsertDto.Request()
                    {
                        VendorTransactionId = item.VendorTransactionId,
                        CartReference = request.CartReference,
                        ProductId = item.ProductId,
                        ProductVendorCode = item.ProductVendorCode,
                        Status = item.Status,
                        VendorTransactionReference = item.VendorTransactionReference,
                        TransactionReference = request.TransactionReference
                    });
                }
                return ResultWrapper.Success(new Response()
                {
                    TransactionReference = request.TransactionReference,
                    PurchasedItems = buyBundleResult.PurchasedItems.Select(x => new Response.PurchasedItem()
                    {
                        ProductId = x.ProductId,
                        ProductVendorCode = x.ProductVendorCode,
                        Status = x.Status
                    })
                });
            }

            return ResultWrapper.Failure(AppConstants.StatusKey.BadRequest, AppConstants.StatusCode.BadRequest);
        }
    }
    #endregion
}
