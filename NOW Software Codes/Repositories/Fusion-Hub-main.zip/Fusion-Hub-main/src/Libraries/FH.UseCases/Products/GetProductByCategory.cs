using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;

namespace FH.UseCases.Products;


public static class GetProductByCategory
{
    #region Query

    public sealed record Query : IRequest<IResultWrapper>
    {

        public CategoryBySubCategoryFilter? CategoryFilters { get; set; }

        public sealed record CategoryBySubCategoryFilter
        {
            public string? CountryIsoCode2 { get; set; }
            public string? CurrencyCode { get; set; }
            public string? CategoryAliasName { get; set; }
        }
    }

    #endregion Query

    #region Validator

    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
          
            
        }
    }

    #endregion Validator

    #region Response

    public sealed record Response
    {
        public ProductCategoryBySubCategoryResponse SubCategoryResponse { get; set; } = new ProductCategoryBySubCategoryResponse();

        public sealed record ProductCategoryBySubCategoryResponse
        {
            public string? CountryName { get; set; }
            public string? OperatorShortCode { get; set; }
            public string? CurrencyCode { get; set; }
            public long ProductId { get; set; }
            public string? ProductAliasName { get; set; }
            public string? ProductType { get; set; }
            public string? CategoryName { get; set; }
            public string? SubCategoryName { get; set; }
            public decimal? Price { get; set; }
            public decimal? Tax { get; set; }
            public decimal? Fee { get; set; }
            public decimal? MaxPrice { get; set; }
            public decimal? MinPrice { get; set; }
        }
      
    }

    #endregion Response

    #region Handler

    internal sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IMapper _mapper = mapper;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        async ValueTask<IResultWrapper> IRequestHandler<Query, IResultWrapper>.Handle(Query request, CancellationToken cancellationToken)
        {
            var productsRequestDto = _mapper.Map<ProductByCategoryDto.Request>(request);

            // Setting Default Values
            productsRequestDto.IsActive = true;
            productsRequestDto.IsDeleted = false;

            var result  = await _unitOfWork.ProductRepository.GetProductSubCategoryByCategory(productsRequestDto);

            if (result is null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
            }
            var getProductsResponse = _mapper.Map<IEnumerable<Response>>(result);
            return ResultWrapper.Success(getProductsResponse);
        }
    }

    #endregion Handler
}
