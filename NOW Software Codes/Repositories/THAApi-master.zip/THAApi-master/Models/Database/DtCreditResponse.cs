﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
   
    public class DTCrditResponse
    {
        public string AdjustmentReason { get; set; }

        public decimal Amount { get; set; }

        public string AuditID { get; set; }

        public int Channel { get; set; }

        public string PaymentMethod { get; set; }

        public string RechargeType { get; set; }

        public string Reference { get; set; }

    }

    public class AccBal
    {
        public decimal new_balance { get; set; }
        public int audit_id { get; set; }
    }
}
