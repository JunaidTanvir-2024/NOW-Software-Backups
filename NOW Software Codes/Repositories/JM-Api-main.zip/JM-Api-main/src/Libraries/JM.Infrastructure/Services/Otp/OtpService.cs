using JM.Core.Utilities.Interfaces.Services;

namespace JM.Infrastructure.Services.Otp;

internal sealed class OtpService : IOtpService
{
    public string GenerateOtp(int minValue = 111111, int maxValue = 999999)
    {
        // Random rdm = new Random();
        // return rdm.Next(minValue, maxValue);
        return "123456";
    }
}
