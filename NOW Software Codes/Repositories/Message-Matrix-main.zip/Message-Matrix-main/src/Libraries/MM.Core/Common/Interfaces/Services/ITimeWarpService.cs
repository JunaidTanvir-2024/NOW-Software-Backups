namespace MM.Core.Common.Interfaces.Services;

public interface ITimeWarpService
{
    DateTime UtcNow { get; }
}
