﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TransferHome.Models.Contracts.Service.Pay360ApiContracts
{
    public class AutoTopUpRequest
    {
        public string msisdn { get; set; }
        public int thresholdBalanceAmount { get; set; }
        public bool isAutoTopup { get; set; }
        public int topupAmount { get; set; }
        public string topupCurrency { get; set; }
    }
}
