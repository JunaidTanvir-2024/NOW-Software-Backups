using FH.UseCases.DataDumps;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.Common;

public sealed class DataDumpController : BaseApiController
{
    [HttpGet]
    public async Task<ActionResult> Dump()
    {
        var result = await Mediator.Send(new VendorDataDump.Query());
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);
    }
}
