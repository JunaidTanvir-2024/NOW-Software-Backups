﻿namespace Application.Common.Models;
public class PaymentRenewalSetting
{
    public bool IsDefaultCard { get; set; }
    public bool IsNewCard { get; set; }
    public bool IsPaypal { get; set; }
}
