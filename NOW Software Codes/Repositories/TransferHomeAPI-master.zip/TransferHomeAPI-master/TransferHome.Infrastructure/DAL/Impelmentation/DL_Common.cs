﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Infrastructure.DAL.Interfaces;
using TransferHome.Models.DAOs;
using TrasnferHome.Models.Configurations;
using TrasnferHome.Models.DbConnections;
using Dapper;
using System.Data;

namespace TransferHome.Infrastructure.DAL.Impelmentation
{
    public class DL_Common : IDL_Common
    {
        private readonly IDbConnectionSettings TransferHomeDb;

        public DL_Common(IOptions<ConnectionString> connectionString)
        {
            TransferHomeDb = new DbConnectionSettings(new SqlConnection(connectionString.Value.TransferHomeDbConnection));
        }

        public async Task<IEnumerable<DBTopAmounts>> TopUpAmounts()
        {
            try
            {
                return await TransferHomeDb.SqlConnection.QueryAsync<DBTopAmounts>("[dbo].[Transferhome_Api_Common_GetTopupAmounts]", commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }
    }
}
