﻿namespace Application.Common.Settings;

public class GoogleAnalytics4Settings
{
    public const string SectionName = "GoogleAnalytics4Settings";
    public static GoogleAnalytics4Settings Bind = new GoogleAnalytics4Settings();
    public string? MeasurementId { get; set; }
    public bool? IsActive { get; set; }
}

