using RW;

using Voucherify.Api.Features.Products.Requests;
using Voucherify.Api.Features.Products.Responses;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Domain.Definitions;
using Voucherify.Core.Services.VoucherifyApi;
using Voucherify.Core.Services.VoucherifyApi.Models.Products;

namespace Voucherify.Api.Features.Products;

public interface IProductsHandler
{
    Task<IResultWrapper<List<Product>>> GetProducts(GetProductsRequest request);
    Task<IResultWrapper<List<ProductSkusResponse>>> GetProductSkus(GetSkusRequest request);
    Task<IResultWrapper<Product>> GetSpecificProduct(GetProductRequest request);
    Task<IResultWrapper<ProductSkusResponse>> GetSpecificSkus(GetProductSkuRequest request);
}

internal class ProductsHandler : IProductsHandler
{
    private const string Products = "Products";
    private const string Skus = "Skus";
    private readonly IVoucherifyImplementation _voucherifyImplementation;

    public ProductsHandler(IVoucherifyImplementation voucherifyImplementation)
    {
        _voucherifyImplementation = voucherifyImplementation;
    }
    public async Task<IResultWrapper<List<Product>>> GetProducts(GetProductsRequest request)
    {
        var products = await _voucherifyImplementation.GetProducts(request.PageNumber, request.PageSize);

        return products != null
            ? ResultWrapper.Success(products).IncludePagination(request.PageNumber, request.PageSize, products?.Count)
            : ResultWrapper.Failure<List<Product>>(AppConstants.StatusMessages.ProductNotFound, AppConstants.StatusCodes.ProductNotFound);
    }
    public async Task<IResultWrapper<Product>> GetSpecificProduct(GetProductRequest request)
    {
        var product = await _voucherifyImplementation.GetProduct(request.ProductNameOrId);

        return product != null
                    ? ResultWrapper.Success(product)
                    : ResultWrapper.Failure<Product>(AppConstants.StatusMessages.ProductNotFound, AppConstants.StatusCodes.ProductNotFound);
    }
    public async Task<IResultWrapper<List<ProductSkusResponse>>> GetProductSkus(GetSkusRequest request)
    {
        var productSkus = await _voucherifyImplementation.GetSKUs(request.ProductNameOrId);

        var productSkuResponse = productSkus?.Select(productSku => new ProductSkusResponse()
        {
            Currency = productSku.Currency,
            Price = productSku.Price,
            ProductId = productSku.ProductId,
            SkuId = productSku.Id,
            SourceId = productSku.SourceId,
            Points = productSku?.Metadata != null && productSku.Metadata?.ContainsKey("points") == true && productSku.Metadata?.ContainsKey("points") != null ? Convert.ToInt64(productSku.Metadata["points"].ToString()) : 0
        }).ToList();

        return productSkuResponse != null
            ? ResultWrapper.Success(productSkuResponse)
            : ResultWrapper.Failure<List<ProductSkusResponse>>(AppConstants.StatusMessages.SkuNotFound, AppConstants.StatusCodes.SkuNotFound);
    }
    public async Task<IResultWrapper<ProductSkusResponse>> GetSpecificSkus(GetProductSkuRequest request)
    {
        var productSku = await _voucherifyImplementation.GetSKU(request.SkuNameOrId);
        var productSkuResposne = new ProductSkusResponse()
        {
            Currency = productSku?.Currency,
            Price = productSku?.Price,
            ProductId = productSku?.ProductId,
            SkuId = productSku?.Id,
            SourceId = productSku?.SourceId,
            Points = productSku?.Metadata != null && productSku.Metadata?.ContainsKey("points") == true && productSku.Metadata?.ContainsKey("points") != null ? Convert.ToInt64(productSku.Metadata["points"].ToString()) : 0
        };
        return productSku != null
            ? ResultWrapper.Success(productSkuResposne)
            : ResultWrapper.Failure<ProductSkusResponse>(AppConstants.StatusMessages.SkuNotFound, AppConstants.StatusCodes.SkuNotFound);
    }
}
