﻿using MapsterMapper;
using RW.Models;
using SC.Core.Features.Products.Requests;
using SC.Core.Vendors.FusionHub;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SC.Core.Features.ProductByOperator;
public static class ProductByOperator
{
    public sealed record Query : IRequest<IResultWrapper>
    {

        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public decimal? Price { get; set; }
        public string? CountryIsoCode { get; set; }
        public string? CurrencyCode { get; set; }
        public string? Category { get; set; }
        public string? SubCategory { get; set; }
        public string? Operator { get; set; }
    }


    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Page).GreaterThan(0);
        }
    }

    #region response
    public sealed record Response
    {
        [JsonPropertyName("product")]
        public ProductInfo Product { get; set; } = new ProductInfo();

        public sealed record ProductInfo
        {
            [JsonPropertyName("productId")]
            public long ProductId { get; set; }
            [JsonPropertyName("productName")]
            public string? ProductName { get; set; }
            [JsonPropertyName("productAliasName")]
            public string? ProductAliasName { get; set; }
            [JsonPropertyName("description")]
            public string? Description { get; set; }
            [JsonPropertyName("productType")]
            public bool? ProductType { get; set; }
            [JsonPropertyName("productOperator")]
            public ProductOperatorInfo ProductOperator { get; set; } = new ProductOperatorInfo();
            [JsonPropertyName("productCountry")]
            public ProductCountryInfo ProductCountry { get; set; } = new ProductCountryInfo();
            [JsonPropertyName("productVendor")]
            public ProductVendorInfo ProductVendor { get; set; } = new ProductVendorInfo();
            [JsonPropertyName("productPrice")]
            public ProductPriceInfo ProductPrice { get; set; } = new ProductPriceInfo();

        }
        public sealed record ProductOperatorInfo
        {
            [JsonPropertyName("operatorName")]
            public string? OperatorName { get; set; }
            [JsonPropertyName("operatorAliasName")]
            public string? OperatorAliasName { get; set; }
            [JsonPropertyName("operatorShortCode")]
            public string? OperatorShortCode { get; set; }
            [JsonPropertyName("operatorDescription")]
            public string? OperatorDescription { get; set; }
        }

        public sealed record ProductCountryInfo
        {
            [JsonPropertyName("countryName")]
            public string? CountryName { get; set; }
            [JsonPropertyName("countryIsoCode2")]
            public string? CountryIsoCode2 { get; set; }
            [JsonPropertyName("countryIsoCode3")]
            public string? CountryIsoCode3 { get; set; }
            [JsonPropertyName("continent")]
            public string? Continent { get; set; }
            [JsonPropertyName("callingCode")]
            public string? CallingCode { get; set; }
        }

        public sealed record ProductVendorInfo
        {
            [JsonPropertyName("vendorProductCode")]
            public string? VendorProductCode { get; set; }
            [JsonPropertyName("vendorOperatorCode")]
            public string? VendorOperatorCode { get; set; }
            [JsonPropertyName("logo")]
            public string? Logo { get; set; }
        }



        public sealed record ProductPriceInfo
        {
            [JsonPropertyName("price")]
            public decimal? Price { get; set; }
            [JsonPropertyName("rangeMinPrice")]
            public decimal? RangeMinPrice { get; set; }
        }

    }

    #endregion
    #region Handler
    internal sealed class Handler : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IFusionHubService _fusionHubService;
        private readonly IMapper _mapper;
        public Handler(IFusionHubService fusionHubService, IMapper mapper)
        {
            _fusionHubService = fusionHubService;
            _mapper = mapper;
        }
        public async Task<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var response = await _fusionHubService.GetProductofEachOperatorAsync(request);
            if (response?.Payload == null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
            }
            return ResultWrapper.Success(response.Payload, new Pagination(response?.PaginationInfo.TotalCount, response?.PaginationInfo.PageCount, response?.PaginationInfo.CurrentPage, response?.PaginationInfo.PageSize));
        }
    }
    #endregion


}

