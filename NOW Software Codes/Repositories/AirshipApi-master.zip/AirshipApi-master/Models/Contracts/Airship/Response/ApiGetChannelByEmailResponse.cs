﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Response
{
    public class ApiGetChannelByEmailResponse
    {
        public bool ok { get; set; }
        public Channel channel { get; set; }

    }
}
