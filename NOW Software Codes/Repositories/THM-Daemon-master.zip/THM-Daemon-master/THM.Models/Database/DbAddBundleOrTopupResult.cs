﻿using System;
using System.Collections.Generic;
using System.Text;

namespace THM.Models.Database
{
    public class DbAddBundleOrTopupResult
    {
        public string audit_id { get; set; }
        public string bundleName { get; set; }
    }
}
