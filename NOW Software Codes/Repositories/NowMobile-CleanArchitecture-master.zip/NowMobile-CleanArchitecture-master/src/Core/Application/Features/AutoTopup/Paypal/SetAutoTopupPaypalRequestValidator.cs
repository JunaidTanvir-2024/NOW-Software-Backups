﻿using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.AutoTopup.Paypal;

public class SetAutoTopupPaypalRequestValidator : AbstractValidator<SetAutoTopupPaypalRequest>
{
    public SetAutoTopupPaypalRequestValidator(ICommonService commonService, IOptions<TopupSettings> options)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");

        RuleFor(p => p.TopupAmount).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => options.Value.TopUpAmounts.Contains(p))
            .WithMessage("Invalid top-up amount");
    }
}