using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Auth.Expense;

public abstract class GetExpense
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long Id { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public string? Description { get; set; }
        public decimal Amount { get; set; }
        public TravelerInfo? Traveler { get; set; }
        public ExpenseCategoryInfo? Category { get; set; }
        public sealed record TravelerInfo
        {
            public required long Id { get; set; }
            public string? FullName { get; set; }
            public string? Email { get; set; }
        }
        public sealed record ExpenseCategoryInfo
        {
            public required long Id { get; set; }
            public required string Name { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IMediator _mediator = mediator;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var expense = await _unitOfWork.ExpenseRepository.GetExpense(x => x.IsActive && x.Id.Equals(query.Id));

            if (expense is not null)
            {
                return ResultWrapper.Success(new Response()
                {
                    Id = expense.Id,
                    Amount = expense.Amount,
                    Description = expense.Description,
                    Traveler = expense.Traveler is not null ? new Response.TravelerInfo()
                    {
                        Id = expense?.Traveler?.User?.Id ?? default,
                        Email = expense?.Traveler?.User?.Email,
                        FullName = expense?.Traveler?.User?.UserDetail?.FullName,
                    } : default,
                    Category = expense?.Category is not null ? new Response.ExpenseCategoryInfo()
                    {
                        Id = expense.Category.Id,
                        Name = expense.Category.Name
                    } : default
                });
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
    }
    #endregion
}
