﻿using Application.Common.Mailing;
using Application.Common.Models.Airship;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.PurchaseBundle.PurchaseBundleBySimCredit;
public class PurchaseBundleBySimCreditRequestHandler : IRequestHandler<PurchaseBundleBySimCreditRequest, Result<PurchaseBundleResponse>>
{
    #region Fields

    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<PurchaseBundleBySimCreditRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly IBundleService _bundleService;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;
    private readonly IMailService _mailService;
    private readonly IAirshipService _airshipService;

    #endregion

    #region Ctor

    public PurchaseBundleBySimCreditRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<PurchaseBundleBySimCreditRequestHandler> localizer,
        IMapper mapper,
        IBundleService bundleService,
        ICurrentUser currentUser,
        ICommonService commonService,
        IAirshipService airshipService,
        IUserService userService,
        IMailService mailService)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
        _bundleService = bundleService;
        _currentUser = currentUser;
        _commonService = commonService;
        _userService = userService;
        _mailService = mailService;
        _airshipService = airshipService;
    }

    #endregion

    #region Methods

    public async Task<Result<PurchaseBundleResponse>> Handle(PurchaseBundleBySimCreditRequest request, CancellationToken cancellationToken)
    {
        string planId = "", planName = "", planCountryCode = "";
        decimal planAmount = 0;
        int planCategory = 0, planType = 0;
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();

        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<PurchaseBundleResponse>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var msisdn = await _uow.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdn == null)
        {
            return Result<PurchaseBundleResponse>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var bundle = await _uow.BundleRepo.GetBundleById(new BundleByIdRequest() { Id = request.BundleId.ToString() });
        if (bundle == null)
        {
            return Result<PurchaseBundleResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }
        planAmount = bundle.TotalPrice;
        planCountryCode = bundle.CountryCode;
        planName = bundle.DisplayName;
        planType = bundle.Type;
        planCategory = bundle.Category;

        if (bundle.Type == (int) BundleType.Rolling)
        {
            return Result<PurchaseBundleResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }

        //Bundle purcahse validation
        (int errorCode, string errorMessge) = await _bundleService.BundlePurchaseValidation(msisdn.AccountId!, bundle.UuId!);
        if (errorCode > 0)
        {
            //log error 
            return Result<PurchaseBundleResponse>.Failure(errorMessge, CustomStatusCode.BundlePurchaseFailed);
        }

        //Bundle buy via sim credit
        var purchaseBundle = await _bundleService.AddBundleBySimCredit(
            new PurchaseBundleRequest()
            {
                BundleId = bundle.Id.ToString(),
                Msisdn = request.Msisdn,
                IsAutoRenew = request.IsAutoRenew,
                UserId = _currentUser.GetUserId(),
                UserEmail = _currentUser!.GetUserEmail()!,
                AccountId = msisdn.AccountId!,
            },
            request.ConversionID,
            (int)request.ConversionPlatFormID);

        //Handle error cases
        if (purchaseBundle.errorCode > 0)
        {
            #region Airship
            if (!IsAppRequest)
            {
                _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                {
                    Email = _currentUser!.GetUserEmail()!,
                    Amount = planAmount,
                    AutoRenew = false,
                    IsCard = null,
                    IsSuccess = false,
                    BundleType = planType,
                    BundleCategory = planCategory,
                    BundleName = planName,
                    Destination = planCountryCode,
                    SaveCard = false,
                });
            }
            #endregion
            //log error

            if (purchaseBundle.errorCode == 102005) //Insufficient Balance
            {
                return Result<PurchaseBundleResponse>.Failure(
                    _localizer[CustomStatusKey.InsufficientBalance], CustomStatusCode.InsufficientBalance);
            }
            else if (purchaseBundle.errorCode == 300) //Bundle limit exceeded
            {
                return Result<PurchaseBundleResponse>.Failure(
                    _localizer[CustomStatusKey.BundlePurchaseLimitExceeded], CustomStatusCode.BundlePurchaseLimitExceeded);
            }
            else
            {
                return Result<PurchaseBundleResponse>.Failure(
                    _localizer[CustomStatusKey.BundlePurchaseFailed], CustomStatusCode.BundlePurchaseFailed);
            }
        }

        //Set auto renewal
        if (request.IsAutoRenew)
        {
            await _uow.BundleRepo.SetBundleAutoRenewal
                  (request.IsAutoRenew,
                  request.Msisdn,
                  msisdn.AccountId!,
                  bundle.UuId!.ToString(),
                  _currentUser.GetUserEmail()!,
                  PaymentMethod.Card);
        }

        #region Email

        var (_, orderDetails, orderItemDetails) = await _uow.PaymentRepo.GetOrderDetails(purchaseBundle.orderId);

        await _mailService.SendBundleEmail(orderDetails, orderItemDetails);

        #endregion
        var response = new PurchaseBundleResponse() { OrderId = purchaseBundle.orderId };

        #region Airship
        if (!IsAppRequest)
        {
            _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
            {
                Email = _currentUser!.GetUserEmail()!,
                Amount = planAmount,
                AutoRenew = false,
                IsCard = null,
                IsSuccess = true,
                BundleType = planType,
                BundleCategory = planCategory,
                BundleName = planName,
                Destination = planCountryCode,
                SaveCard = false,
            });
        }
        #endregion

        return Result<PurchaseBundleResponse>.Success(response, CustomStatusKey.Success);
    }

    #endregion
}
