﻿using Application.Features.Payment.Card.Models;
using Application.Features.Payment.InAppReceipt;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;

namespace Application.Common.Interfaces.Payment;

public interface IPaymentService : ISerivcesType.ITransientService
{
    Task<Result<CardResponse>> HandleCardPaymentRequest(
            PaymentNewCardInfo paymentNewCardInfo,
            PaymentExistingCardInfo paymentExistingCardInfo,
            PaymentAddressInfo paymentAddressInfo,
            PaymentTopupInfo topupInfo,
            PaymentBundleInfo bundleInfo,
            PaymentCreditSimInfo creditSimInfo,
            string msisdn,
            string email,
            string ipAddress,
            string cardMaskedPan,
            string cardScheme,
            bool isAuthorizeOnly = default);

    Task<Result<CardResponse>> HandleCardPaymentResume3dRequest(
        string transactionId,
        int orderId,
        bool IsAuthorizeOnly,
        bool IsFastTopup = false,
        bool IsAppRequest = false);

    Task<Result<PaypalResponse>> HandlePaypalPaymentRequest(
        PaymentTopupInfo topupInfo,
        PaymentBundleInfo bundleInfo,
        PaymentCreditSimInfo creditSimInfo,
        string msisdn,
        string email,
        string ipAddress,
        bool isSubscriptionRequest = default,
        bool subscriptionWithInitialSale = default);

    Task<Result<PaypalResponse>> HandleDirectPaypalExecuteRequest(
        string payerId,
        string paymentId,
        string uniqueRef,
        int orderId,
        bool IsFastTopup = false,
        bool IsAppRequest = false);

    Task<Result<InAppReceiptResponse>> VerifyInAppPurchaseReceipt(InAppReceiptRequest request);
}
