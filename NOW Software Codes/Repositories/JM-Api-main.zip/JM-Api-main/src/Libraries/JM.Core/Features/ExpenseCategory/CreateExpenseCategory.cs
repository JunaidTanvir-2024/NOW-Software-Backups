using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;
namespace JM.Core.Features.ExpenseCategory;

public abstract class CreateExpenseCategory
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public string Name { get; set; } = string.Empty;
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Name).NotEmpty().NotNull();
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public required string Name { get; set; }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var expenseCategory = await _unitOfWork.ExpenseRepository.AddExpenseCategory
            (
                new Entities.ExpenseCategory()
                {
                    Name = query.Name
                }
            );
            _unitOfWork.SaveChanges();

            if (expenseCategory is not null)
            {
                return ResultWrapper.Success(new Response()
                {
                    Id = expenseCategory.Id,
                    Name = expenseCategory.Name
                });
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
    }
    #endregion
}
