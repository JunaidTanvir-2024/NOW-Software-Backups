using JM.Core.Entities.Common;

namespace JM.Core.Entities;
public sealed class Country : IBaseEntity<long>
{
    public long Id { get; set; }
    public string Name { get; set; } = null!;
    public string IsoCode2 { get; set; } = null!;
    public string IsoCode3 { get; set; } = null!;
    public ushort CallingCode { get; set; }
    public string NumericCode { get; set; } = null!;
    public ICollection<UserDetail> UserDetails { get; set; } = [];
}
