namespace MM.Infrastructure.Persistence.Repositories.DTOs;
public record VendorLogDto
{
    public DateTimeOffset Timestamp { get; init; }
    public string? RequestPath { get; init; }
    public string? RequestMethod { get; init; }
    public string? RequestBody { get; init; }
    public string? ResponseBody { get; init; }
    public int StatusCode { get; init; }
    public long Duration { get; init; }
    public long ResponseSize { get; init; }
    public string? ErrorReason { get; init; }
    public string? Headers { get; init; }
    public string? QueryString { get; init; }
    public required string CorrelationId { get; init; } = null!;
    public required int VendorId { get; init; }
}
