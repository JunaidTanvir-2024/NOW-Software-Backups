﻿

using System.Data.SqlTypes;
using System.Text.Json.Serialization;

namespace SC.Core.Features.CustomerOrder.Requests;
public sealed class RemoveCardRequest : IRequest<IResultWrapper>
{

    public long CardID { get; set; } = default!;

}
public sealed class RRemoveCardRequestValidator : AbstractValidator<RemoveCardRequest>
{
    public RRemoveCardRequestValidator()
    {
        RuleFor(x => x.CardID).NotEmpty();
    }
}

