﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSOutReach.Modal.Xeebi
{
    public class SmsJobReport
    {
        public int JobId { get; set; }
        public int Dispatached { get; set; }
        public int Delivered { get; set; }
        public int Expired { get; set; }
        public int Rejected { get; set; }
        public int UnDelivered { get; set; }
    }

    
}
