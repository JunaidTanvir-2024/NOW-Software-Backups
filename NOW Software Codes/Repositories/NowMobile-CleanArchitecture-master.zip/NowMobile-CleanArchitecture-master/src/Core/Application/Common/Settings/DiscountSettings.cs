﻿

namespace Application.Common.Settings;
public class DiscountSettings
{
    public const string SectionName = "DiscountSettings";
    public static DiscountSettings Bind = new DiscountSettings();
    public string? StartDate { get; set; }
    public string? EndDate { get; set; }
    public bool? IsActive { get; set; }
}
