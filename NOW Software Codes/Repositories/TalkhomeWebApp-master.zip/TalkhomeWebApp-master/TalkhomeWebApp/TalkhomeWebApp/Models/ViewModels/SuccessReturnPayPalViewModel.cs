﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class SuccessReturnPayPalViewModel
    {
        public string paymentId { get; set; }
        public string token { get; set; }
        public string PayerID { get; set; }

    }
}
