﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class SendSms
    {
        public string StrMsisdn { get; set; }

        public string StrContacts { get; set; }

        public string StrPin { get; set; }

        public string StrMessage { get; set; }
    }
}
