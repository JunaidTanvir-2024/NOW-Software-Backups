using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Services;

public interface IGooglePlacesIntegration : ResolveAs.IScoped
{
    Task<GoogleGetPlace.Response> GetPlaces(GoogleGetPlace.Query query);
}
