﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{
    public class SmtpConfig
    {
        public string server { get; set; }
        public string from { get; set; }
        public string userName { get; set; }
        public string password { get; set; }
        public string[] to { get; set; }
        public string[] cc { get; set; }
        public string[] bcc { get; set; }
        public string GetProductssubject { get; set; }
        public bool sendErrorGetProductsEmail { get; set; }
        public bool sendGetProductsExceptionErrorsOnly { get; set; }
        public string ExecuteTransactionsubject { get; set; }
        public bool sendErrorExecuteTransactionEmail { get; set; }
        public bool sendExecuteTransactionExceptionErrorsOnly { get; set; }
    }
}
