global using Serilog;
global using MediatR;
global using Microsoft.AspNetCore.Mvc;
global using DC.Core;
global using DC.Infrastructure;
global using Asp.Versioning;
//global using DC.Core.Features.WeatherForecast.Requests;
