﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Microsoft.Extensions.Localization;

namespace Infrastructure.BLL.Implementation
{
    public class Helper_BL : IHelper_BL
    {
        private readonly IPhoneNumberService PhoneNumberService;
        private readonly ICulture_BL CultureService;
        private readonly IStringLocalizer Localizer;

        public Helper_BL(
            IPhoneNumberService phoneNumberService,
            ICulture_BL cultureService,
            IStringLocalizer localizer)
        {
            PhoneNumberService = phoneNumberService;
            CultureService = cultureService;
            Localizer = localizer;
        }

        public string GetCountryNamebyCoutryISCode(string iso)
        {
            return CultureService.GetCountryName(iso);
        }
        public string GetCountryNamebyCoutryISCode(string iso, string remarks)
        {
            return CultureService.GetCountryName(iso) + remarks;
        }
        public string GetCountryName(string msisdn)
        {
            var formattedMsisdn = FormatMsisdn(msisdn);
            var countryCode = PhoneNumberService.GetCountry(formattedMsisdn);
            return CultureService.GetCountryName(countryCode);
        }
        public string GetCountryIso(string msisdn)
        {
            var formattedMsisdn = FormatMsisdn(msisdn);
            var countryCode = PhoneNumberService.GetCountryIsoCode(formattedMsisdn);
            return countryCode;
        }
        public string GetISOCurrencyCode(string msisdn)
        {
            var formattedMsisdn = FormatMsisdn(msisdn);
            var countryCode = PhoneNumberService.GetCountry(formattedMsisdn);
            return CultureService.ISOCurrencyCode(countryCode);
        }
        public string GetCountryCode(string msisdn)
        {
            var formattedMsisdn = FormatMsisdn(msisdn);
            var countryCode = PhoneNumberService.GetCountry(formattedMsisdn);
            return countryCode;
        }
        public string GetAccountCurrency(string msisdn)
        {
            var formattedMsisdn = FormatMsisdn(msisdn);

            var accountCurrency = GetISOCurrencyCode(formattedMsisdn);

            var allowedCurrencies = new List<string>()
            {
                "EUR",
                "GBP",
                "USD",
                "CHF",
                "TRY",
                "NOK"
            };

            if (!allowedCurrencies.Contains(accountCurrency))
            {
                accountCurrency = "USD";
            }

            return accountCurrency;
        }
        public string StripLeadingZeros(string msisdn)
        {
            if (msisdn.StartsWith("00"))
            {
                msisdn = msisdn.Substring(2);
            }
            return msisdn;
        }
        public string GetSipUserName(string msisdn)
        {
            return $"THA{StripLeadingZeros(msisdn)}";
        }
        public string FormatMsisdn(string msisdn)
        {
            if (msisdn.StartsWith("00"))
            {
                msisdn= msisdn.Replace("00","");
            }
            if (!msisdn.StartsWith("+"))
            {
                return $"+{msisdn}";
            }
            return msisdn;
        }
        public string ToMonetaryUnit(decimal amount, string currency)
        {
            return DetermineMonetaryUnit(amount, currency);
        }
        public string ToMonetaryUnit(string amount, string currency)
        {
            var decimalAmount = Convert.ToDecimal(amount, CultureInfo.InvariantCulture);

            return DetermineMonetaryUnit(decimalAmount, currency);
        }
        private string DetermineMonetaryUnit(decimal amount, string currency)
        {
            if (amount >= 1)
            {
                var monetaryAmount = amount.ToString(CultureInfo.InvariantCulture);
                var currencyUnit = GetMajorCurrencyUnit(currency);
                if (currencyUnit == string.Empty)
                    return FormattableString.Invariant($"{monetaryAmount}{currency}");
                else
                    return FormattableString.Invariant($"{currencyUnit}{monetaryAmount}");
            }
            else
            {

                var monetaryAmount = Math.Round((amount * 100), 1);
                //var monetaryAmount = (amount * 100);
                var currencyUnit = GetMinorCurrencyUnit(currency);
                return FormattableString.Invariant($"{monetaryAmount}{currencyUnit}");
            }
        }
        private string GetMajorCurrencyUnit(string currency)
        {
            switch (currency)
            {
                case "GBP":
                    return "£";
                case "EUR":
                    return "€";
                case "USD":
                    return "$";
            }
            return string.Empty;
        }
        private string GetMinorCurrencyUnit(string currency)
        {
            switch (currency)
            {
                case "GBP":
                    return "p";
                case "EUR":
                    return "c";
                case "USD":
                    return "c";
            }
            return string.Empty;
        }
        public string ToCurrencySymbol(string currency)
        {
            switch (currency)
            {
                case "GBP":
                    return "£";
                case "EUR":
                    return "€";
                case "USD":
                    return "$";
                case "NOK":
                    return "kr";
                case "CHF":
                    return "CHF";
                case "TRY":
                    return "₺";
                default:
                    return currency;
            }
        }
        public string ToCurrencyName(string currencySymbol)
        {
            
            
                if("£".Equals(currencySymbol,StringComparison.InvariantCultureIgnoreCase))
                    return "GBP";
                else if("€".Equals(currencySymbol, StringComparison.InvariantCultureIgnoreCase))
                    return "EUR";
                else if("$".Equals(currencySymbol, StringComparison.InvariantCultureIgnoreCase))
                    return "USD";
                else if("kr".Equals(currencySymbol, StringComparison.InvariantCultureIgnoreCase))
                    return "NOK";
                else if("CHF".Equals(currencySymbol, StringComparison.InvariantCultureIgnoreCase))
                    return "CHF";
                else if("₺".Equals(currencySymbol, StringComparison.InvariantCultureIgnoreCase))
                    return "TRY";
                else
                    return currencySymbol;
        }
        public string FormatAccountBalance(decimal amount, string currency)
        {
            switch (currency)
            {
                case "GBP":
                case "EUR":
                case "USD":
                case "CHF":
                case "NOK":
                    return ((int)amount / 100m).ToString("F",CultureInfo.InvariantCulture);
            }
            return amount.ToString("F", CultureInfo.InvariantCulture);
            //return amount.ToString(CultureInfo.InvariantCulture);
        }
        public string ToSmsCharge(decimal amount, string currency)
        {
            var currencyUnit = GetMinorCurrencyUnit(currency);
            return FormattableString.Invariant($"{amount}{currencyUnit}");
        }
        public string ToCallCharge(decimal amount, string currency)
        {
            var currencyUnit = GetMinorCurrencyUnit(currency);
            return FormattableString.Invariant($"{amount}{currencyUnit}");
        }
        public string ToCallType(string zone)
        {
            if (zone == "ON-NET")
            {
                return Localizer["Free"];
            }
            else
            {
                return Localizer["Paid"];
            }
        }
        public string ToCallDuration(int totalSeconds)
        {
            int seconds = totalSeconds % 60;
            int minutes = totalSeconds / 60;
            var duration = minutes + ":" + seconds;
            return duration;
        }
        public string ToPaymentHistoryAmount(decimal amount, string currency)
        {
            var monetaryAmount = Convert.ToInt32(amount);

            if (monetaryAmount < 0)
            {
                //Make positive
                monetaryAmount = Math.Abs(monetaryAmount);
            }

            //Convert to actual amount
            monetaryAmount = monetaryAmount / 100;

            if (monetaryAmount >= 1)
            {
                var formattedAmount = Math.Round(Convert.ToDecimal(monetaryAmount, CultureInfo.InvariantCulture), 2);
                var currencyUnit = GetMajorCurrencyUnit(currency);
                return FormattableString.Invariant($"{currencyUnit}{formattedAmount}");
            }
            else
            {
                var currencyUnit = GetMinorCurrencyUnit(currency);
                return FormattableString.Invariant($"{monetaryAmount}{currencyUnit}");
            }
        }
        public string GetPaymentHistoryReference(string method, string reason)
        {
            if (String.IsNullOrEmpty(method))
            {
                return reason;
            }
            else if (method == "Sign Up Promo")
            {
                return Localizer["SignUpPromo"];
            }
            else if (method == "iTunes Top Up")
            {
                return Localizer["ITunesTopUp"];
            }
            else if (method == "Bundle Recharge")
            {
                return Localizer["BundlePurchase"];
            }
            else
            {
                return reason;
            }
        }
    }
}
