﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DbUserSimOrderDetails
    {
        public DBUser UserInfo { get; set; }
        public DBUserAddress AddressInfo { get; set; }
        public DBUserSIMOrder OrderDetails { get; set; }
        public IEnumerable<DBUserProduct> UserProducts { get; set; }
    }
}
