﻿using Dapper;
using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Database;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using static Dapper.SqlMapper;

namespace Infrastructure.DAL.Implementation
{
	public class History_DL : IHistory_DL
	{
		private readonly IUserAccount_DL _userAccountDL;
		private readonly IHelper_BL _helperService;
		private readonly ConnectionStrings _dbConnections;

		public History_DL(
			IOptions<ConnectionStrings> dbConnections,
			IUserAccount_DL userAccountDL,
			IHelper_BL helperService)
		{
			_userAccountDL = userAccountDL;
			_helperService = helperService;
			_dbConnections = dbConnections.Value;
		}

		/// <summary>
		/// Get Entire Payment History
		/// </summary>
		/// <param name="account"></param>
		/// <param name="msisdn"></param>
		/// <returns></returns>
		public async Task<IEnumerable<PaymentHistory>> GetEntirePaymentHistory(string account, string msisdn)
		{
			//Get InApp Tranfer + Voucher Recharge 
			var accountParm = new DynamicParameters();
			accountParm.Add("@account", account, dbType: System.Data.DbType.String);

			List<PaymentHistory> accountHistory = new List<PaymentHistory>();

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
			{
				accountHistory = (await dbConnection.QueryAsync<PaymentHistory>(
				"tha_get_entire_payment_history_v2", accountParm, commandType: System.Data.CommandType.StoredProcedure)).ToList();
			}

			accountHistory.ForEach(x => { x.Db = "account"; });

			//Get (Bundle + Topup via Card & Paypal) + International Topup Via (via Card & Paypal & Accout Balance) 
			var paymentParm = new DynamicParameters();
			paymentParm.Add("@msisdn", msisdn, dbType: System.Data.DbType.String);
			paymentParm.Add("@account", account, dbType: System.Data.DbType.String);

			GridReader reader = null;

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
			{
				reader = await dbConnection.QueryMultipleAsync(
				 "tha_topup_bundle_itopup_history", paymentParm, commandType: System.Data.CommandType.StoredProcedure);


				var airTimeHistory = reader.Read<PaymentHistory>();
				var bundleTopupHisotry = reader.Read<PaymentHistory>();
				var bundleAccountHisotry = reader.Read<PaymentHistory>();

				foreach (var x in airTimeHistory)
				{
					x.Db = "payment";
				}
				foreach (var x in bundleTopupHisotry)
				{
					x.Db = "payment";
				}
				foreach (var x in bundleAccountHisotry)
				{
					x.Db = "payment";
				}

				accountHistory.AddRange(bundleAccountHisotry);
				accountHistory.AddRange(airTimeHistory);
				accountHistory.AddRange(bundleTopupHisotry);
			}
			if (accountHistory.Count > 0)
			{
				accountHistory = accountHistory.OrderByDescending(x => x.PaymentDate).ToList();
			}

			return accountHistory;
		}

		/// <summary>
		/// Get Entire Payment History V2
		/// </summary>
		/// <param name="account"></param>
		/// <param name="msisdn"></param>
		/// <returns></returns>
		public async Task<IEnumerable<PaymentHistory>> GetEntirePaymentHistoryV2(string account, string msisdn)
		{
			//Get InApp Tranfer + Voucher Recharge 
			var accountParm = new DynamicParameters();
			accountParm.Add("@account", account, dbType: System.Data.DbType.String);

			List<PaymentHistory> accountHistory = new List<PaymentHistory>();

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
			{
				accountHistory = (await dbConnection.QueryAsync<PaymentHistory>(
				"tha_get_entire_payment_history_v2", accountParm, commandType: System.Data.CommandType.StoredProcedure)).ToList();
			}

			accountHistory.ForEach(x => { x.Db = "account"; });


			//Get (Bundle + Topup via Card & Paypal) + International Topup Via (via Card & Paypal & Accout Balance) 
			var paymentParm = new DynamicParameters();
			paymentParm.Add("@msisdn", msisdn, dbType: System.Data.DbType.String);
			paymentParm.Add("@account", account, dbType: System.Data.DbType.String);

			GridReader reader = null;

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
			{
				reader = await dbConnection.QueryMultipleAsync(
				"tha_topup_bundle_itopup_history_v1", paymentParm, commandType: System.Data.CommandType.StoredProcedure);

				var airTimeHistory = reader.Read<PaymentHistory>().ToList();
				var bundleTopupHisotry = reader.Read<PaymentHistory>().ToList();
				var bundleAccountHisotry = reader.Read<PaymentHistory>().ToList();


				airTimeHistory.ForEach(x => { x.Db = "payment"; });
				bundleTopupHisotry.ForEach(x => { x.Db = "payment"; });
				bundleAccountHisotry.ForEach(x => { x.Db = "payment"; });

				accountHistory.AddRange(bundleAccountHisotry);
				accountHistory.AddRange(airTimeHistory);
				accountHistory.AddRange(bundleTopupHisotry);
			}
			if (accountHistory.Count > 0)
			{
				accountHistory = accountHistory.OrderByDescending(x => x.PaymentDate).ToList();
			}
			return accountHistory;
		}

		/// <summary>
		/// Get Payment History
		/// </summary>
		/// <param name="msisdn"></param>
		/// <returns></returns>
		public async Task<IEnumerable<UserAccountPaymentHistory>> GetPaymentHistoryAsync(string msisdn)
		{
			var userAccount = await _userAccountDL.GetUserAccount(msisdn);

			var parameters = new DynamicParameters();
			parameters.Add("@account", userAccount.AccountID, dbType: System.Data.DbType.String);

			IEnumerable<PaymentHistory> result = Enumerable.Empty<PaymentHistory>();

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
			{
				result = await dbConnection.QueryAsync<PaymentHistory>("tha_get_entire_payment_history_v1", parameters, commandType: System.Data.CommandType.StoredProcedure);
			}

			return ToUserAccountPaymentHistory(result, userAccount.UserAccountBalance.Currency);
		}


		/// <summary>
		/// To User Account Payment History
		/// </summary>
		/// <param name="paymentHistories"></param>
		/// <param name="currency"></param>
		/// <returns></returns>
		private IEnumerable<UserAccountPaymentHistory> ToUserAccountPaymentHistory(
							IEnumerable<PaymentHistory> paymentHistories, string currency)
		{

			return paymentHistories.Select(e => new UserAccountPaymentHistory()
			{
				Amount = _helperService.ToPaymentHistoryAmount(e.Amount, currency),
				Method = GetPaymentMethod(e.Method),
				Reference = e.Reference,//HelperService.GetPaymentHistoryReference(e.Method, e.Reason),
				TransDate = e.PaymentDate,
				Type = GetPaymentType(e.Method),
				Successfull = true,
			});
		}

		/// <summary>
		/// Get Payment Method
		/// </summary>
		/// <param name="paymentMethod"></param>
		/// <returns></returns>
		private string GetPaymentMethod(string paymentMethod)
		{
			if (paymentMethod.Contains("card", StringComparison.InvariantCultureIgnoreCase))
			{
				return "Card";
			}
			else if (paymentMethod.Contains("paypal", StringComparison.InvariantCultureIgnoreCase))
			{
				return "PayPal";
			}
			else
			{
				return "Balance";
			}
		}

		/// <summary>
		/// Get Payment Type
		/// </summary>
		/// <param name="paymentMethod"></param>
		/// <returns></returns>
		private string GetPaymentType(string paymentMethod)
		{
			if (paymentMethod.Contains("topup", StringComparison.InvariantCultureIgnoreCase))
			{
				return "Topup";
			}
			else if (paymentMethod.Contains("bundle", StringComparison.InvariantCultureIgnoreCase))
			{
				return "Bundle";
			}
			else if (paymentMethod.Contains("AccountBalance", StringComparison.InvariantCultureIgnoreCase))
			{
				return "InAppTransfer";
			}
			else
			{
				return "Send Top-Up";
			}
		}
	}
}
