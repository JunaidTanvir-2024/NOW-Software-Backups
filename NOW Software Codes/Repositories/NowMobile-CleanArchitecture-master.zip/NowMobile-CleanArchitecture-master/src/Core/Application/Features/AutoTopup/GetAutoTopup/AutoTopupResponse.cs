namespace Application.Features.AutoTopup.GetAutoTopup;

public class AutoTopupResponse
{
    public AutoTopupInfo AutoTopup { get; set; } = new AutoTopupInfo();
    public List<float> AutoTopupThresholdAmounts { get; set; } = new List<float>();
    public List<float> TopUpAmounts { get; set; } = new List<float>();
}
