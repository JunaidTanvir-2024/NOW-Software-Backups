﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum DeviceType
    {
        ios = 1, 
        android = 2,
        amazon = 3,
        web = 4,
        open = 5,
        email = 6,
        sms = 7,
        wns = 8
    }
}
