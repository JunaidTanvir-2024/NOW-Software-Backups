﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL
{
    public interface IBL_Porting
    {
        Task<GenericApiResponse<bool>> PortIn(PortInRequestModel model, PortTypes portType, int? OrderReferenceId = null);
        Task<GenericApiResponse<bool>> PortOut(PortOutRequestModel model, CodeTypes codeType, PortTypes portType);
        Task<GenericApiResponse<GetPortingRequestsResponseModel>> GetPortingRequests(GetPortingRequestsRequestModel model);
        Task<GenericApiResponse<bool>> UpdateUserPortingDate(UpdateUserPortingDateRequestModel model);
        Task<GenericApiResponse<bool>> ValidatePortingRequest(ValidatePortingRequestModel model);
        Task<GenericApiResponse<bool>> CancelPortingRequest(CancelPortingRequestModel model);
        Task<GenericApiResponse<SwitchingInformationApiResponseModel>> GetSwitchingInformation(string msisdn);
        Task<PortOutBySmsResponseModel> PortOutBySms(PortOutBySmsRequestModel model);
        Task<PortOutBySmsResponseModel> GetSwitchingInformationBySms(string msisdn);
    }
}
