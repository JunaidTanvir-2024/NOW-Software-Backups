﻿namespace Application.Features.Device.ConfirmDeviceResend;

public class ConfirmDeviceResendRequestValidator : AbstractValidator<ConfirmDeviceResendRequest>
{
    public ConfirmDeviceResendRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.EmailOrPhone)
            .Cascade(CascadeMode.Stop).NotNull().NotEmpty().MaximumLength(50)
            .Must(p => commonService.IsValidEmailAddress(p))
                .When(p => !p.EmailOrPhone.All(char.IsDigit), ApplyConditionTo.CurrentValidator)
                .WithMessage("Invalid Email Address")
            .Must(p => commonService.IsValidMsisdn(p))
                .When(p => p.EmailOrPhone.All(char.IsDigit), ApplyConditionTo.CurrentValidator)
                .WithMessage("Invalid Phone Number");

        RuleFor(p => p.DeviceId).NotEmpty().NotNull();
    }
}