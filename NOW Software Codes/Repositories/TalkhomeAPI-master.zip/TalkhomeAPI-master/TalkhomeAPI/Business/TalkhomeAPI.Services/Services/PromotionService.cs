﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Services.Interfaces;

namespace TalkhomeAPI.Services.Services
{
    public class PromotionService : IPromotionService
    {
        private readonly IPromotionRepository _promotionRepository;

        public PromotionService(IPromotionRepository promotionRepository)
        {
            _promotionRepository = promotionRepository;
        }

        public async Task<GenericApiResponse<GetPromotionsResponseModel>> GetAccountPromotions(string msisdn)
        {
            var result = await _promotionRepository.GetAccountPromotions(msisdn);

            return GenericApiResponse<GetPromotionsResponseModel>.Success(
                          new GetPromotionsResponseModel()
                          {
                              PromotionsDetails = result
                          }, result.Promotions.Count() > 0 ? "Found Promotions" : "Promotions not found");
        }

        public async Task<PromotionPaymentDetails> CheckAnyActivePromotions(
                                                                    float Amount,
                                                                    string msisdn,
                                                                    PaymentMethodTypes paymentMethod,
                                                                    PromotionDependentTypes[] dependentTypes,
                                                                    bool IsAutoTopup)
        {
            var response = new PromotionPaymentDetails()
            {
                ChargeAmount = Amount,
                FullfilmentAmount = Amount
            };

            var result = await _promotionRepository.GetAccountPromotions(msisdn);

            if (result != null && result.Promotions != null && result.Promotions.Any())
            {
                var filteredProms = result.Promotions.Where(x => dependentTypes.Contains(x.PromotionDependentType));

                if (filteredProms.Where(x => x.PromotionDependentType == PromotionDependentTypes.AutoTopup).Any())
                {
                    if (IsAutoTopup == false)
                    {
                        filteredProms = filteredProms.Where(x => x.PromotionDependentType != PromotionDependentTypes.AutoTopup);
                    }
                }

                foreach (var prom in filteredProms)
                {
                    var promotionPaymentMethods = result.PromotionPaymentMethods.
                        Where(x => x.PromotionId == prom.ID && x.PaymentMethodId == paymentMethod);

                    if (promotionPaymentMethods.Any())
                    {
                        if (prom.Type == PromotionType.Discount)
                        {
                            if (prom.OfferUnit == OfferUnitTypes.Percentage)
                            {
                                response.ChargeAmount -= ((Amount * (float)prom.OfferValue) / 100);
                            }
                            else
                            {
                                response.ChargeAmount -= (float)prom.OfferValue;
                            }
                        }

                        if (prom.Type == PromotionType.ExtraBalance)
                        {
                            if (prom.OfferUnit == OfferUnitTypes.Percentage)
                            {
                                response.FullfilmentAmount += ((Amount * (float)prom.OfferValue) / 100);
                            }
                            else
                            {
                                response.FullfilmentAmount += (float)prom.OfferValue;
                            }
                        }
                    }
                }
            }

            response.ChargeAmount = (float)Math.Truncate(response.ChargeAmount * 100) / 100;
            response.FullfilmentAmount = (float)Math.Truncate(response.FullfilmentAmount * 100) / 100;

            return response;
        }
    }
}
