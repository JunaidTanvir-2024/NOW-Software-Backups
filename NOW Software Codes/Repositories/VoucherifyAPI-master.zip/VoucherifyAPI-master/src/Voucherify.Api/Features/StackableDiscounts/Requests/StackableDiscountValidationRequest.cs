using FluentValidation;

using Voucherify.Api.Features.StackableDiscounts.Common;
using Voucherify.Core.Commons.Extensions;

namespace Voucherify.Api.Features.StackableDiscounts.Requests;

public class StackableDiscountValidationRequest
{
    public StackableDiscountCustomerInfo Customer { get; set; } = null!;
    public StackableDiscountOrderInfo Order { get; set; } = null!;
    public StackableDiscountRedemptionInfo Validation { get; set; } = null!;
}

internal class StackableDiscountValidationRequestValidator : AbstractValidator<StackableDiscountValidationRequest>
{
    public StackableDiscountValidationRequestValidator()
    {
        RuleFor(p => p.Customer.SourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.Customer.SourceId = phoneNumber);

        RuleFor(p => p.Validation.DiscountCode).NotNull().NotEmpty();
        RuleFor(p => p.Validation.DiscountType).NotNull().NotEmpty();
    }
}
