using Microsoft.AspNetCore.Mvc;

using Voucherify.Api.Features.Customers.Requests;

using Voucherify.Core.Commons.Filters;

namespace Voucherify.Api.Features.Customers;

public static class CustomersEndpoint
{
    private const string EndpointPrefix = "/api/customers";
    private const string EndpointTag = "Customers Endpoints";

    public static void AddCustomersEndpoints(this WebApplication app)
    {
        var customersEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);

        customersEndpoints.MapPost("/", AddCustomer)
            .AddEndpointFilter<FluentValidationFilter<AddCustomerRequest>>()
            .Produces(StatusCodes.Status201Created)
            .Produces(StatusCodes.Status400BadRequest);

        customersEndpoints.MapGet("", GetCustomers)
            .AddEndpointFilter<FluentValidationFilter<GetCustomersRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);


        customersEndpoints.MapPost("/campaigns", GetCampaignsAgainstCustomer)
        .AddEndpointFilter<FluentValidationFilter<GetCustomerCampaignsRequest>>()
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound);

        customersEndpoints.MapPost("/invitationCode", GetInvitationCode)
        .AddEndpointFilter<FluentValidationFilter<GetReferralCodeRequest>>()
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound);

        customersEndpoints.MapGet("/{customerSourceId}", GetCustomer)
            .AddEndpointFilter<FluentValidationFilter<GetCustomerRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        customersEndpoints.MapPost("/loyaltyCard", GetCustomerLoyaltyCard)
       .AddEndpointFilter<FluentValidationFilter<GetCustomerLoyaltyCardRequest>>()
       .Produces(StatusCodes.Status400BadRequest)
       .Produces(StatusCodes.Status200OK)
       .Produces(StatusCodes.Status404NotFound);

        customersEndpoints.MapPut("/", UpdateCustomer)
            .AddEndpointFilter<FluentValidationFilter<UpdateCustomerRequest>>()
            .Produces(StatusCodes.Status204NoContent)
            .Produces(StatusCodes.Status400BadRequest);

        customersEndpoints.MapDelete("/{customerSourceId}", DeleteCustomer)
            .AddEndpointFilter<FluentValidationFilter<DeleteCustomerRequest>>()
            .Produces(StatusCodes.Status204NoContent)
            .Produces(StatusCodes.Status400BadRequest);
    }
    private static async Task<IResult> AddCustomer(ICustomersHandler customersHandler, [FromBody] AddCustomerRequest request)
    {
        var result = await customersHandler.CreateCustomer(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.BadRequest(result);
    }
    private static async Task<IResult> UpdateCustomer(ICustomersHandler customersHandler, [FromBody] UpdateCustomerRequest request)
    {
        var result = await customersHandler.UpdateCustomer(request);

        return result.IsSuccess
            ? Results.NoContent()
            : Results.BadRequest(result);
    }
    private static async Task<IResult> GetCustomer(ICustomersHandler customersHandler, [AsParameters] GetCustomerRequest request)
    {
        var result = await customersHandler.GetCustomer(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetCustomerLoyaltyCard(ICustomersHandler customersHandler, [FromBody] GetCustomerLoyaltyCardRequest request)
    {
        var result = await customersHandler.GetCustomerLoyaltyCard(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetInvitationCode(ICustomersHandler customersHandler, [FromBody] GetReferralCodeRequest request)
    {
        var result = await customersHandler.GetInvitationCode(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetCustomers(ICustomersHandler customersHandler, [AsParameters] GetCustomersRequest request)
    {
        var result = await customersHandler.GetCustomers(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> DeleteCustomer(ICustomersHandler customersHandler, [AsParameters] DeleteCustomerRequest request)
    {
        var result = await customersHandler.DeleteCustomer(request);
        return result.IsSuccess
            ? Results.NoContent()
            : Results.BadRequest(result);
    }
    private static async Task<IResult> GetCampaignsAgainstCustomer(ICustomersHandler customersHandler, [FromBody] GetCustomerCampaignsRequest request)
    {
        var result = await customersHandler.GetCampaignsAgainstCustomer(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
}
