﻿

namespace Now.Models.Database;

public class DbSimOrderPool
{
    public int Id { get; set; }
    public string? Msisdn { get; set; }
    public bool? IsAvailable { get; set; }
    public bool? IsActive { get; set; }
    public string? Account { get; set; }
    public DateTime Activation_Date { get; set; }
    public bool IsFulfilled { get; set; }
    public string? FulfillmentErrorMessage { get; set; }
    public DateTime FulfillmentDateTime { get; set; }
}
