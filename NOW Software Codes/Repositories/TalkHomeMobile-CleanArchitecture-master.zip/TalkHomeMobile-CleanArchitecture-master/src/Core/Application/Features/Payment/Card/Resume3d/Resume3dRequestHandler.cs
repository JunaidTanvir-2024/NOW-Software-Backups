﻿using Application.Common.Interfaces;
using Application.Common.Interfaces.Payment;
using Application.Features.Payment.Card.Models;

namespace Application.Features.Payment.Card.Resume3d;

public class Resume3dRequestHandler : IRequestHandler<Resume3dRequest, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly ICommonService _commonService;

    public Resume3dRequestHandler(IPaymentService paymentService, ICommonService commonService)
    {
        _paymentService = paymentService;
        _commonService = commonService;
    }

    public async Task<Result<CardResponse>> Handle(Resume3dRequest request, CancellationToken cancellationToken)
    {

        (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();
        return await _paymentService.HandleCardPaymentResume3dRequest(request.MD, request.OrderId, request.IsAuthorizeOnly, request.IsFastTopup, IsAppRequest);
    }
}