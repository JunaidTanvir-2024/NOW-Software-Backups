﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Serilog;
using Models.Contracts.Response;
using Models.Enums;
using Models.Contracts.Request;
using THAApi.ViewModels;
using THAApi.Utilities;
using Infrastructure.Utilities;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;
using Microsoft.Extensions.Localization;
using Infrastructure.BLL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;

namespace THAApi.Controllers
{
	[ApiController]
	public class Pay360Controller : Controller
	{
		private readonly ILogger _logger;
		private readonly IPayment_BL _paymentBL;
		private readonly IStringLocalizer _localizer;
		private readonly IHelper_BL _helper_BL;
		private readonly Pay360Config pay360Config;

		public Pay360Controller(
			ILogger logger,
			IPayment_BL paymentBL,
			IStringLocalizer localizer,
			IHelper_BL helper_BL,
			IOptions<Pay360Config> pay360Options)
		{
			_logger = logger;
			_paymentBL = paymentBL;
			_localizer = localizer;
			this._helper_BL = helper_BL;
			this.pay360Config = pay360Options.Value;
		}

		[HttpPost]
		[Route("Pay360/NewCustomerPayment")]
		public async Task<IActionResult> NewCustomerPayment([FromBody] NewCustomerPaymentRequestModel model)
		{
			try
			{
				if (model.CheckoutType == CheckOutTypes.TopUp)
				{
					_logger.Information($"Pay360/NewCustomerPayment Topup: {JsonConvert.SerializeObject(model)}");
				}
				string advertiserID = HttpContext.GetAdvertiserID();
				var response = await _paymentBL.NewCustomerPaymentAsync(
					model,
					User.Msisdn(),
					User.Currency(),
					HttpContext.GetRemoteIPAddress(),
					User.Email(),
					advertiserID);

				if (response.ErrorCode == 0)
				{
					string paymentMethodViewData = await PrepareSuccessHtml(response.Payload, model.UtmParamsInfo, HttpContext.ThemeMode());
					return Ok(GenericApiResponse<object>.Success(new { html = paymentMethodViewData }, ""));
				}

				if (response.ErrorCode == (int)ApiStatusCodes.Pending3dSecure)
				{
					string Secure3dResponseView = "";

					if (response.Payload.threeDSecureData.type.Equals("v1", StringComparison.InvariantCultureIgnoreCase))
					{
						var resume3dViewModel = new Resume3DV1ViewModel()
						{
							Pareq = response.Payload.threeDSecureData.pareq,
							ReturnUrl = response.Payload.threeDSecureData.returnUrl,
							Url = response.Payload.threeDSecureData.redirectUrl,
							TransactionId = response.Payload.threeDSecureData.transactionId,
						};
						resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
						resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
						Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV1Page, resume3dViewModel, false);
					}
					else
					{
						var resume3dViewModel = new Resume3DV2ViewModel()
						{
							ReturnUrl = response.Payload.threeDSecureData.returnUrl,
							Url = response.Payload.threeDSecureData.redirectUrl,
							TransactionId = response.Payload.threeDSecureData.transactionId,
							ThreeDSServerTransId = response.Payload.threeDSecureData.threeDSServerTransId
						};
						resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
						resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
						Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV2Page, resume3dViewModel, false);
					}
					return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, ""));
				}

				var resp = GenericApiResponse<object>.Failure(null, response.Message, ApiStatusCodes.UnSuccessful);

				return Ok(resp);
			}
			catch (Exception ex)
			{
				if (model.CardInfo != null)
				{
					model.CardInfo.NameOnCard = "";
					model.CardInfo.CardNumber = "";
					model.CardInfo.SecurityCode = "";
					model.CardInfo.ExpiryDate = "";
				}

				_logger.Error($"Class: Pay360Controller, " +
							  $"Method: NewCustomerPayment, " +
							  $"Request:{JsonConvert.SerializeObject(model)}, " +
							  $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
							  $"StackTrace: {ex.StackTrace}");

				var resp = GenericApiResponse<object>.Failure(
					null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

				return Ok(resp);
			}
		}

		[HttpPost]
		[Route("Pay360/ActivateBundle")]
		public async Task<IActionResult> ActivateBundle([FromBody] ActivateBundleRequestModel model)
		{
			try
			{
				string advertiserID = HttpContext.GetAdvertiserID();
				var response = await _paymentBL.ActivateBundleDefaultCardPaymentAsync(
								model,
								User.Msisdn(),
								User.Currency(),
								HttpContext.GetRemoteIPAddress(),
								User.Email(),
								advertiserID);
				if (response.ErrorCode == 0)
				{
					string paymentMethodViewData = await PrepareSuccessHtml(response.Payload, model.UtmParamsInfo, HttpContext.ThemeMode());
					return Ok(GenericApiResponse<object>.Success(new { html = paymentMethodViewData }, ""));
				}
				var resp = GenericApiResponse<object>.Failure(null, response.Message, ApiStatusCodes.UnSuccessful);
				return Ok(resp);
			}
			catch (Exception ex)
			{
				_logger.Error($"Class: Pay360Controller, " +
							  $"Method: ActivateBundle, " +
							  $"Request:{JsonConvert.SerializeObject(model)}, " +
							  $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}," +
							  $"StackTrace: {ex.StackTrace}");

				var resp = GenericApiResponse<object>.Failure(
					null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

				return Ok(resp);
			}
		}

		[HttpPost]
		[Route("Pay360/ExistingCardPayment")]
		public async Task<IActionResult> ExistingCardPayment([FromBody] ExistingCardPaymentRequestModel model)
		{
			try
			{
				string advertiserID = HttpContext.GetAdvertiserID();
				var response = await _paymentBL.ExistingCardPaymentAsync(
					model,
					User.Msisdn(),
					User.Currency(),
					HttpContext.GetRemoteIPAddress(),
					User.Email(),
					advertiserID);

				if (response.ErrorCode == 0)
				{
					string paymentMethodViewData = await PrepareSuccessHtml(response.Payload, model.UtmParamsInfo, HttpContext.ThemeMode());
					return Ok(GenericApiResponse<object>.Success(new { html = paymentMethodViewData }, ""));
				}

				if (response.ErrorCode == (int)ApiStatusCodes.Pending3dSecure)
				{
					string Secure3dResponseView = "";

					if (response.Payload.threeDSecureData.type.Equals("v1", StringComparison.InvariantCultureIgnoreCase))
					{
						var resume3dViewModel = new Resume3DV1ViewModel()
						{
							Pareq = response.Payload.threeDSecureData.pareq,
							ReturnUrl = response.Payload.threeDSecureData.returnUrl,
							Url = response.Payload.threeDSecureData.redirectUrl,
							TransactionId = response.Payload.threeDSecureData.transactionId,
						};
						resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
						resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
						Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV1Page, resume3dViewModel, false);
					}
					else
					{
						var resume3dViewModel = new Resume3DV2ViewModel()
						{
							ReturnUrl = response.Payload.threeDSecureData.returnUrl,
							Url = response.Payload.threeDSecureData.redirectUrl,
							TransactionId = response.Payload.threeDSecureData.transactionId,
							ThreeDSServerTransId = response.Payload.threeDSecureData.threeDSServerTransId
						};
						resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
						resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
						Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV2Page, resume3dViewModel, false);
					}
					return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, ""));
				}

				var resp = GenericApiResponse<object>.Failure(null, response.Message, ApiStatusCodes.UnSuccessful);

				return Ok(resp);
			}
			catch (Exception ex)
			{
				model.SecurityCode = "";

				_logger.Error($"Class: Pay360Controller, " +
							  $"Method: ExistingCardPayment, " +
							  $"Request:{JsonConvert.SerializeObject(model)}, " +
							  $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
							  $"StackTrace: {ex.StackTrace}");

				var resp = GenericApiResponse<object>.Failure(
					null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

				return Ok(resp);
			}
		}

		[ApiExplorerSettings(IgnoreApi = true)]
		[AllowAnonymous]
		[Route("Pay360/Resume3DTransaction"), HttpPost]
		public async Task<IActionResult> Resume3DTransaction([FromQuery] Resume3DPaymentDataRequest data,
															 [FromForm] Resume3DPaymentRequest request)
		{
			try
			{
				HttpContext.Request.Headers["AirshipEventsDisable"] = data.airshipEventsDisable ? "1" : "0";
				HttpContext.Request.Headers["Msisdn"] = data.CustomerMsisdn;
				var response = await _paymentBL.Resume3DTransactionAsync(request, data);

				if (response.ErrorCode > 0)
					return View(Pages.ErrorPage, new ErrorViewModel()
					{
						Message = response.Message,
						ThemeMode = data.ThemeMode,
						PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
						Type = data.CheckoutType,
						BundlePurchaseInfo = response.Payload?.bundlePurchaseInfo,
						Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn)
					});

				if (response.Payload.topupInfo != null)
				{
					var successviewModel = new SuccessViewModel()
					{
						Type = SuccessViewModel.CheckoutType.Topup,
						ThemeMode = data.ThemeMode,
						Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn),
						UtmParamsInfo = new UtmParamsInfo()
						{
							utm_campaign = data.UtmCampaign,
							utm_medium = data.UtmMedium,
							utm_source = data.UtmSource
						},
						CustomerMsisdn = data.CustomerMsisdn,
						TransactionId = request.MD,
						TopupInfo = new SuccessViewModel.Topup()
						{
							Amount = response.Payload.topupInfo.TopupAmount,
							Currency = response.Payload.topupInfo.Currency,
							PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
							UpdatedBalance = response.Payload.topupInfo.NewBalance
						},
					};

					return View(Pages.SuccessPage, successviewModel);
				}
				else
				{
					var successviewModel = new SuccessViewModel()
					{
						Type = SuccessViewModel.CheckoutType.Bundle,
						ThemeMode = data.ThemeMode,
						Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn),
						UtmParamsInfo = new UtmParamsInfo()
						{
							utm_campaign = data.UtmCampaign,
							utm_medium = data.UtmMedium,
							utm_source = data.UtmSource
						},
						CustomerMsisdn = data.CustomerMsisdn,
						TransactionId = request.TransactionId,
						BundleInfo = new SuccessViewModel.Bundle()
						{
							Amount = response.Payload.bundlePurchaseInfo.BundleAmount,
							Currency = response.Payload.bundlePurchaseInfo.Currency,
							PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
							Name = response.Payload.bundlePurchaseInfo.BundleName,
							Type = response.Payload.bundlePurchaseInfo.Type,
							Destination = response.Payload.bundlePurchaseInfo.Destination,
						},

					};

					return View(Pages.SuccessPage, successviewModel);
				}
			}
			catch (Exception ex)
			{
				_logger.Error($"Class: Pay360Controller, " +
							  $"Method: Resume3DTransaction, " +
							  $"Request-request: {JsonConvert.SerializeObject(data)}, " +
							  $"Request-Data: {JsonConvert.SerializeObject(data)}, " +
							  $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
							  $"StackTrace: {ex.StackTrace}");

				return View(Pages.ErrorPage,
					new ErrorViewModel()
					{
						Message = _localizer["SomethingWentWrong"],
						ThemeMode = data.ThemeMode,
						PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
						Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn),
						Type = data.CheckoutType,
					});
			}
		}
		[HttpGet]
		[Route("pay360/getPaymentAmounts")]
		public async Task<IActionResult> GetPaymentAmounts()
		{
			return Ok(await _paymentBL.GetPaymentAmounts(User.Currency(), User.Msisdn(), User.Email()));
		}

		[HttpGet]
		[Route("GetAddressByPostCode")]
		public async Task<IActionResult> GetAddressByPostCode([FromQuery] GetAddressByPostCodeRequestModel model)
		{
			return Ok(await _paymentBL.GetAddressByPostCode(model));
		}

		[HttpPost]
		[Route("SetAutoTopup")]
		public async Task<IActionResult> SetAutoTopup([FromBody] SetAutoTopUpRequestModel model)
		{
			return Ok(await _paymentBL.SetAutoTopUp(model, User.Msisdn(), User.Currency(), User.Email()));
		}
		[HttpPost]
		[Route("SetAutoTopupWithCard")]
		public async Task<IActionResult> SetAutoTopupWithCard([FromBody] SetAutoTopupWithCardRequestModel model)
		{
			try
			{
				_logger.Information($"Pay360/SetAutoTopupWithCard: {JsonConvert.SerializeObject(model)}");
				string advertiserID = HttpContext.GetAdvertiserID();
				var response = await _paymentBL.SetAutoTopupWithCard(
					model,
					User.Msisdn(),
					User.Account(),
					User.Currency(),
					HttpContext.GetRemoteIPAddress(),
					User.Email(),
					advertiserID);

				if (response.ErrorCode == 0)
				{
					string paymentMethodViewData = await PrepareSetAutoTopupSuccessHtml(model, response.Payload, null, HttpContext.ThemeMode());
					return Ok(GenericApiResponse<object>.Success(new { html = paymentMethodViewData }, ""));
				}

				if (response.ErrorCode == (int)ApiStatusCodes.Pending3dSecure)
				{
					string Secure3dResponseView = "";

					if (response.Payload.threeDSecureData.type.Equals("v1", StringComparison.InvariantCultureIgnoreCase))
					{
						var resume3dViewModel = new Resume3DV1ViewModel()
						{
							Pareq = response.Payload.threeDSecureData.pareq,
							ReturnUrl = response.Payload.threeDSecureData.returnUrl,
							Url = response.Payload.threeDSecureData.redirectUrl,
							TransactionId = response.Payload.threeDSecureData.transactionId,
						};
						resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
						resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
						Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV1Page, resume3dViewModel, false);
					}
					else
					{
						var resume3dViewModel = new Resume3DV2ViewModel()
						{
							ReturnUrl = response.Payload.threeDSecureData.returnUrl,
							Url = response.Payload.threeDSecureData.redirectUrl,
							TransactionId = response.Payload.threeDSecureData.transactionId,
							ThreeDSServerTransId = response.Payload.threeDSecureData.threeDSServerTransId
						};
						resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
						resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
						Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV2Page, resume3dViewModel, false);
					}
					return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, ""));
				}

				var resp = GenericApiResponse<object>.Failure(null, response.Message, ApiStatusCodes.UnSuccessful);

				return Ok(resp);
			}
			catch (Exception ex)
			{
				if (model.NewCardInfo != null)
				{
					model.NewCardInfo.NameOnCard = "";
					model.NewCardInfo.CardNumber = "";
					model.NewCardInfo.SecurityCode = "";
					model.NewCardInfo.ExpiryDate = "";
				}

				_logger.Error($"Class: Pay360Controller, " +
							  $"Method: SetAutoTopupWithCard, " +
							  $"Request:{JsonConvert.SerializeObject(model)}, " +
							  $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
							  $"StackTrace: {ex.StackTrace}");

				var resp = GenericApiResponse<object>.Failure(
					null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

				return Ok(resp);
			}
		}
		[HttpPost]
		[ApiExplorerSettings(IgnoreApi = true)]
		[AllowAnonymous]
		[Route("SetAutoTopupWithCardResume3DTransaction")]
		public async Task<IActionResult> SetAutoTopupWithCardResume3DTransaction([FromQuery] Resume3DPaymentDataRequest data,
															 [FromForm] Resume3DPaymentRequest request)
		{
			try
			{
				HttpContext.Request.Headers["AirshipEventsDisable"] = data.airshipEventsDisable ? "1" : "0";
				HttpContext.Request.Headers["Msisdn"] = data.CustomerMsisdn;
				var response = await _paymentBL.SetAutoTopupWithCardResume3DTransactionAsync(request, data);

				if (response.ErrorCode > 0)
					return View(Pages.SetAutoTopupErrorPage, new ErrorViewModel()
					{
						Message = response.Message,
						ThemeMode = data.ThemeMode,
						PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
						Type = data.CheckoutType,
						BundlePurchaseInfo = response.Payload?.bundlePurchaseInfo,
						Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn)
					});

				var successviewModel = new SetAutoTopupSuccessViewModel()
				{
					MaxSpendLimit = _helper_BL.ToMonetaryUnit((decimal)pay360Config.AutoTopupMaxSpendLimit, data.Currency),
					ThresholdAmount = _helper_BL.ToMonetaryUnit((decimal)data.AutoTopupThreshold, data.Currency),
					TopupAmount = _helper_BL.ToMonetaryUnit((decimal)data.AutoToupAmount, data.Currency),
					ThemeMode = data.ThemeMode
				};

				return View(Pages.SetAutoTopupSuccessPage, successviewModel);
			}
			catch (Exception ex)
			{
				_logger.Error($"Class: Pay360Controller, " +
							  $"Method: Resume3DTransaction, " +
							  $"Request-request: {JsonConvert.SerializeObject(data)}, " +
							  $"Request-Data: {JsonConvert.SerializeObject(data)}, " +
							  $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
							  $"StackTrace: {ex.StackTrace}");

				return View(Pages.SetAutoTopupErrorPage,
					new ErrorViewModel()
					{
						Message = _localizer["SomethingWentWrong"],
						ThemeMode = data.ThemeMode,
						PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
						Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn),
						Type = data.CheckoutType,
					});
			}
		}
		[HttpGet]
		[Route("GetAutoTopup")]
		public async Task<IActionResult> GetAutoTopup()
		{
			return Ok(await _paymentBL.GetAutoTopUp(User.Msisdn(), User.Email()));
		}

		[HttpGet]
		[Route("Pay360/getPaymentMethods")]
		public async Task<IActionResult> GetPaymentMethods()
		{
			return Ok(
				await _paymentBL.GetCustomerCards(new Pay360CustomerRequestModel()
				{
					customerUniqueRef = User.Msisdn(),
					productCode = ProductCode.THA.ToString()
				}));
		}

		[HttpPost]
		[Route("Pay360/removeCard")]
		public async Task<IActionResult> RemoveCard([FromBody] RemoveCardUserRequest request)
		{
			return Ok(await _paymentBL.RemoveCard(User.Msisdn(), User.Account(), request));
		}

		[HttpPost]
		[Route("Pay360/setDefaultCard")]
		public async Task<IActionResult> SetDefaultCard([FromBody] SetDefaultCardUserRequest defaultCardReq)
		{
			return Ok(await _paymentBL.SetDefaultCard(User.Msisdn(), defaultCardReq));
		}

		private async Task<string> PrepareSuccessHtml(CardPaymentResponseModel response, UtmParamsInfo utmParams, ThemeMode themeMode)
		{
			var successResponse = new SuccessViewModel();

			if (response.topupInfo != null)
			{
				//Topup
				successResponse.Origination = _helper_BL.GetCountryCode(response.customerMsisdn);
				successResponse.UtmParamsInfo = new UtmParamsInfo()
				{
					utm_campaign = utmParams?.utm_campaign,
					utm_medium = utmParams?.utm_medium,
					utm_source = utmParams?.utm_source
				};
				successResponse.CustomerMsisdn = response.customerMsisdn;
				successResponse.TransactionId = response.transactionId;
				successResponse.ThemeMode = themeMode;
				successResponse.Type = SuccessViewModel.CheckoutType.Topup;
				successResponse.TopupInfo = new SuccessViewModel.Topup()
				{
					Amount = response.topupInfo.TopupAmount,
					Currency = response.topupInfo.Currency,
					PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
					UpdatedBalance = response.topupInfo.NewBalance
				};
			}
			else
			{
				//Bundle
				successResponse.Origination = _helper_BL.GetCountryCode(response.customerMsisdn);
				successResponse.UtmParamsInfo = new UtmParamsInfo()
				{
					utm_campaign = utmParams?.utm_campaign,
					utm_medium = utmParams?.utm_medium,
					utm_source = utmParams?.utm_source
				};
				successResponse.CustomerMsisdn = response.customerMsisdn;
				successResponse.TransactionId = response.transactionId;
				successResponse.ThemeMode = themeMode;
				successResponse.Type = SuccessViewModel.CheckoutType.Bundle;
				successResponse.BundleInfo = new SuccessViewModel.Bundle()
				{
					Amount = response.bundlePurchaseInfo.BundleAmount,
					Currency = response.bundlePurchaseInfo.Currency,
					PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
					Name = response.bundlePurchaseInfo.BundleName,
					Type = response.bundlePurchaseInfo.Type,
					Destination = response.bundlePurchaseInfo.Destination,
				};
			}


			var paymentMethodViewData = await this.RenderViewAsync(Pages.SuccessPage, successResponse, false);
			return paymentMethodViewData;
		}
		private async Task<string> PrepareSetAutoTopupSuccessHtml(SetAutoTopupWithCardRequestModel request, CardPaymentResponseModel response, UtmParamsInfo utmParams, ThemeMode themeMode)
		{
			var successResponse = new SetAutoTopupSuccessViewModel();

			//Topup
			successResponse.TopupAmount = _helper_BL.ToMonetaryUnit((decimal)request.AutoTopupInfo.TopupAmount, User.Currency());
			successResponse.ThresholdAmount = _helper_BL.ToMonetaryUnit((decimal)request.AutoTopupInfo.ThresholdAmount, User.Currency());
			successResponse.MaxSpendLimit = _helper_BL.ToMonetaryUnit((decimal)pay360Config.AutoTopupMaxSpendLimit, User.Currency());
			successResponse.ThemeMode = themeMode;

			var paymentMethodViewData = await this.RenderViewAsync(Pages.SetAutoTopupSuccessPage, successResponse, false);
			return paymentMethodViewData;
		}
		private async Task<string> PrepareSetBundleAutoRenewalSuccessHtml(SetAutoRenewalCardRequestModel request, CardPaymentResponseModel response, UtmParamsInfo utmParams, ThemeMode themeMode)
		{

			var successResponse = new SetAutoBundleRenewalSuccessViewModel();
			successResponse.ThemeMode = themeMode;
			var paymentMethodViewData = await this.RenderViewAsync(Pages.SetBundleAutoRenewalSuccessPage, successResponse, false);
			return paymentMethodViewData;
		}
		[HttpPost]
		[Route("Pay360/SetBundleAutoRenewalWithCard")]
		public async Task<IActionResult> SetBundleAutoRenewalWithCard([FromBody] SetAutoRenewalCardRequestModel model)
		{
			try
			{
				_logger.Information($"Pay360/SetBundleAutoRenewalWithCard: {JsonConvert.SerializeObject(model)}");
				string advertiserID = HttpContext.GetAdvertiserID();
				var response = await _paymentBL.SetAutoBundleRenewalWithCard(
					model,
					User.Msisdn(),
					User.Account(),
					User.Currency(),
					HttpContext.GetRemoteIPAddress(),
					User.Email(),
					advertiserID);

				if (response.ErrorCode == 0)
				{
					string paymentMethodViewData = await PrepareSetBundleAutoRenewalSuccessHtml(model, response.Payload, null, HttpContext.ThemeMode());
					return Ok(GenericApiResponse<object>.Success(new { html = paymentMethodViewData }, ""));
				}

				if (response.ErrorCode == (int)ApiStatusCodes.Pending3dSecure)
				{
					string Secure3dResponseView = "";

					if (response.Payload.threeDSecureData.type.Equals("v1", StringComparison.InvariantCultureIgnoreCase))
					{
						var resume3dViewModel = new Resume3DV1ViewModel()
						{
							Pareq = response.Payload.threeDSecureData.pareq,
							ReturnUrl = response.Payload.threeDSecureData.returnUrl,
							Url = response.Payload.threeDSecureData.redirectUrl,
							TransactionId = response.Payload.threeDSecureData.transactionId,
						};
						resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
						resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
						Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV1Page, resume3dViewModel, false);
					}
					else
					{
						var resume3dViewModel = new Resume3DV2ViewModel()
						{
							ReturnUrl = response.Payload.threeDSecureData.returnUrl,
							Url = response.Payload.threeDSecureData.redirectUrl,
							TransactionId = response.Payload.threeDSecureData.transactionId,
							ThreeDSServerTransId = response.Payload.threeDSecureData.threeDSServerTransId
						};
						resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
						resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
						Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV2Page, resume3dViewModel, false);
					}
					return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, ""));
				}

				var resp = GenericApiResponse<object>.Failure(null, response.Message, ApiStatusCodes.UnSuccessful);

				return Ok(resp);
			}
			catch (Exception ex)
			{
				if (model.NewCardInfo != null)
				{
					model.NewCardInfo.NameOnCard = "";
					model.NewCardInfo.CardNumber = "";
					model.NewCardInfo.SecurityCode = "";
					model.NewCardInfo.ExpiryDate = "";
				}

				_logger.Error($"Class: Pay360Controller, " +
							  $"Method: SetBundleAutoRenewalWithCard, " +
							  $"Request:{JsonConvert.SerializeObject(model)}, " +
							  $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
							  $"StackTrace: {ex.StackTrace}");

				var resp = GenericApiResponse<object>.Failure(
					null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

				return Ok(resp);
			}
		}
		[HttpPost]
		[ApiExplorerSettings(IgnoreApi = true)]
		[AllowAnonymous]
		[Route("SetAutoRenewalWithCardResume3DTransaction")]
		public async Task<IActionResult> SetAutoRenewalWithCardResume3DTransaction([FromQuery] Resume3DPaymentDataRequest data,
														   [FromForm] Resume3DPaymentRequest request)
		{
			try
			{
				HttpContext.Request.Headers["AirshipEventsDisable"] = data.airshipEventsDisable ? "1" : "0";
				HttpContext.Request.Headers["Msisdn"] = data.CustomerMsisdn;
				var response = await _paymentBL.SetAutoBundleRenewalCardResume3DTransactionAsync(request, data);

				if (response.ErrorCode > 0)
					return View(Pages.SetBundleAutoRenewalErrorPage, new ErrorViewModel()
					{
						Message = response.Message,
						ThemeMode = data.ThemeMode,
						PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
						Type = data.CheckoutType,
						BundlePurchaseInfo = response.Payload?.bundlePurchaseInfo,
						Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn)
					});

				var successviewModel = new SetAutoBundleRenewalSuccessViewModel()
				{
					ThemeMode = data.ThemeMode
				};

				return View(Pages.SetBundleAutoRenewalSuccessPage, successviewModel);
			}
			catch (Exception ex)
			{
				_logger.Error($"Class: Pay360Controller, " +
							  $"Method: Resume3DTransaction, " +
							  $"Request-request: {JsonConvert.SerializeObject(data)}, " +
							  $"Request-Data: {JsonConvert.SerializeObject(data)}, " +
							  $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
							  $"StackTrace: {ex.StackTrace}");

				return View(Pages.SetBundleAutoRenewalErrorPage,
					new ErrorViewModel()
					{
						Message = _localizer["SomethingWentWrong"],
						ThemeMode = data.ThemeMode,
						PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
						Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn),
						Type = data.CheckoutType,
					});
			}
		}
	}
}
