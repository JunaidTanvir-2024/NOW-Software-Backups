using DC.Api.Controllers.Common;
using DC.Core.Features.HangFire;
using DC.Core.Features.Notifications.Requests;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DC.Api.Controllers.V1;
[Route("api/[controller]")]
[ApiController]
public class HangFireJobController  : BaseApiController
{
    
    [Route("api/hangFire")]
    [HttpGet, AllowAnonymous]

    public async Task<ActionResult> GetBundles()
    {
        var request = new InitiateHangFireJobRequest();
        var result = await Mediator.Send(request);
        //if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);


    }
}
