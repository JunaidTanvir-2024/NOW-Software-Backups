namespace FH.Core.Entities;
public sealed record VendorEntity : BaseEntity<long>
{
    public string? BatchHash { get; set; }
    public long ApiPage { get; set; }
    public string? ApiType { get; set; }
    public long VendorId { get; set; }
}
