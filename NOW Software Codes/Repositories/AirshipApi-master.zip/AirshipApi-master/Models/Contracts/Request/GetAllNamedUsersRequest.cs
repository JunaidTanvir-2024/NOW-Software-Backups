﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
   public class GetAllNamedUsersRequest
    {
        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; }
    }
}
