﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Models.AppsFlyer;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public interface IAppsFlyerService
    {
        bool IsActive { get; }
        Task CreateEvent(string customerUserId, string eventName, string ipAddress, string eventRevenenuCurrency = null, decimal eventRevenue = 0, object eventValue = null);
        Task SetCustomerId(string customerUserId, string afUserId);
    }

    public class AppsFlyerService : IAppsFlyerService
    {
        private readonly AppsFlyerConfig _appsFlyerConfig;

        public bool IsActive { get; }
        public AppsFlyerService(
                        IOptions<AppsFlyerConfig> appsFlyerConfig)
        {
            _appsFlyerConfig = appsFlyerConfig.Value;
            IsActive = appsFlyerConfig.Value.IsActive;
        }

        public async Task CreateEvent(string customerUserId, string eventName, string ipAddress, string eventRevenenuCurrency = null, decimal eventRevenue = 0, object eventValue = null)
        {
            try
            {
                var requestModel = new CreateEventRequestModel()
                {
                    customerUserId = customerUserId,
                    eventName = eventName,
                    eventRevenenuCurrency = eventRevenenuCurrency,
                    eventValue = eventValue,
                    ip = ipAddress,
                    eventRevenue = eventRevenue
                };

                var request = new HttpRequestMessage(HttpMethod.Post, _appsFlyerConfig.ApiEndpoint + "api/Home/CreateEvent")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(requestModel), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch
            {
            }
        }

        public async Task SetCustomerId(string customerUserId, string afUserId)
        {
            try
            {
                var requestModel = new SetCustomerIdRequestModel()
                {
                    afUserId = afUserId,
                    customerUserId = customerUserId
                };

                var request = new HttpRequestMessage(HttpMethod.Post, _appsFlyerConfig.ApiEndpoint + "api/Home/SetCuId")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(requestModel), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch
            {
            }
        }
    }
}
