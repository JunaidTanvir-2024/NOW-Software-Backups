﻿using FluentValidation;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Vouchers.Requests;

public class AddVoucherRequest
{
    public string? Type { get; set; }
    public VoucherRedemptionInfo? Redemption { get; set; }
    public VoucherDiscountInfo? Discount { get; set; }
    public Metadata? Metadata { get; set; }

    public sealed class VoucherDiscountInfo
    {
        public string? Type { get; set; }
        public string? Effect { get; set; }
        public long? AmountOff { get; set; }
        public double? PercentOff { get; set; }
        public double? UnitOff { get; set; }
        public string? UnitType { get; set; }
        public long? AmountLimit { get; set; }
    }

    public sealed class VoucherRedemptionInfo
    {
        public long? Quantity { get; set; }
    }
}
internal class AddVoucherRequestValidator : AbstractValidator<AddVoucherRequest>
{
    public AddVoucherRequestValidator()
    {
        RuleFor(p => p.Discount).NotNull().NotEmpty();
    }
}
