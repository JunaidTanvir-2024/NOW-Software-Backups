﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.Contracts.Response;
using TransferHome.Models.Contracts.Service;
using TransferHome.Models.DAOs;
using TrasnferHome.Models.Contracts;
using TrasnferHome.Models.Utility;

namespace TransferHome.Infrastructure.BLL.Interfaces
{
    public interface IBL_Transfer
    {
        Task<GenericApiResponse<GetProductsResponseModel>> GetProducts(GetProductsRequestModel model, string userId);
        Task<GenericApiResponse<TransferFromAccountBalanceResponseModel>> TransferFromAccountBalance(TransferFromAccountBalanceRequestModel model, int userId);
        Task<decimal> CreditBalance(DBCredit model);
        Task<GenericApiResponse<TransferFromAccountBalanceResponseModel>> ExecuteDirectTransfer(ExecuteDirectTransferRequestModel model);
        Task<DBProduct> GetTransferTransactionByNowtelTransactionReference(string nowtelTransactionReference, string product);
        Task<GenericApiResponse<object>> GenerateTwoFactorAuthenticationToken(int userId, string NowtelTransactionReference);
        Task<GenericApiResponse<TransferFromAccountBalanceResponseModel>> ResumeTransferTransaction(ResumeTransferTransactionRequestModel model, int userId);
        Task<GenericApiResponse<object>> SaveAutoTransferSettings(SaveAutoTransferSettingsRequestModel model, int userId);
        Task<GenericApiResponse<object>> GetUserAutoTransferNumbers(int userId);
        Task<GenericApiResponse<object>> UpdateAutoTransferStatus(UpdateAutoTransferStatusRequestModel model, int userId);
        Task<GenericApiResponse<object>> RemoveAutoTransferNumber(RemoveAutoTransferNumberRequestModel model, int userId);
        Task<GenericApiResponse<object>> UpdateAutoTransferSettings(UpdateAutoTransferSettingsRequestModel model, int userId);
        Task<int> ValidateTrasnferRequest(int userId, decimal amount);
    }
}
