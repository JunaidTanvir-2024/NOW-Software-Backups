﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Database
{
    public class CustomerChargeValueForReplacement
    {
        public string Country { get; set; }
        public string InitialCallingCode { get; set; }
        public string OrignalChargeValue { get; set; }
        public string NewChargeValue { get; set; }
        public string ProductItemCode { get; set; }
    }
}
