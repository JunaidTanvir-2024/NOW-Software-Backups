﻿using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Web;
using TalkhomeWebApp.Models;
using TalkhomeWebApp.Models.Configurations;
using TalkhomeWebApp.Utilities;
using TalkhomeWebApp.Utilities.Extension;

namespace TalkhomeWebApp.Services
{
    public class RatesService : IRatesService
    {
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly EndPoints _endpoints;
		private readonly ApiClient _apiClient;

		public RatesService(
            IOptions<BasicAuthConfig> basicAuthConfig,
            IOptions<EndPoints> Endpoints,
            ApiClient apiClient)
        {
            _basicAuthConfig = basicAuthConfig.Value;
            _endpoints = Endpoints.Value;
			this._apiClient = apiClient;
		}
        
        public async Task<List<Rates>> GetRates(string countryCode, IPrincipal User)
        {
            List<Rates> payload = new List<Rates>();
           string token = Convert.ToBase64String(System.Text.Encoding.
                    GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));


                var response = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint + "Rates/GetRates", User,
					ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "IsoCode=" + countryCode }, basicauthtoken: token);

            if (response.IsSuccessStatusCode)
            {
                var RatesResponse = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                var errorCode = RatesResponse.GetValue("errorCode").ToObject<int>();
                if (errorCode == 0)
                {
                    payload = RatesResponse.GetValue("payload").ToObject<List<Rates>>();

                    if (payload.Count > 0)
                    {
                        payload = payload.OrderBy(x => x.Destination).ToList();
                    }
                }
            }

            return payload;
        }
    }
}
