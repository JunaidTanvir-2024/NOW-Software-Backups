using Application.Features.Bundle.Bundle;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Bundle.DataBundle;
using Application.Features.Bundle.InternationalBundle;
using Application.Features.Bundle.Model;
using Application.Features.Bundle.NationalBundle;
using Application.Features.Bundle.SimBundle;
using Application.Features.Bundle.SuggestedBundle;

namespace Application.Common.Interfaces.Repositories;
public interface IBundleRepository : ISerivcesType.IScopedService
{
    Task<Bundle> GetBundleById(BundleByIdRequest bundleByIdRequest);
    Task<List<Bundle>> GetBundles(BundlesRequest bundlesRequest);
    Task<List<Bundle>> GetNationalBundles(NationalBundleRequest nationalBundleRequest);
    Task<List<Bundle>> GetInternationalBundlesByCountryCode(InternationalBundleRequest internationalBundleByCountryCodeRequest);
    Task<List<Bundle>> GetDataBundles(DataBundleRequest dataBundleRequest);
    Task<Bundle> GetBundleById(string bundleId);

    Task<List<Bundle>> GetSimBundles(SimBundleRequest simBundleRequest);
    Task<List<Bundle>> GetSuggestedBundles(SuggestedBundleRequest suggestedBundleRequest);
    Task<(int, string)> BundlePurchaseValidation(string accountId, string bundleUuId);
    Task<(int errorCode, string errorMessage, int? AuditId)> AddBundleViaSp(string accountId, string msisdn, string email, string bundleUuid);
    Task SetBundleAutoRenewal(bool isRenew, string msisdn, string accountId, string bundleUuid, string userEmail, PaymentMethod paymentMethod, string cardPanMasked = null, string cardInitialTransactionId = null);
    Task<GetBundleAutoRenewalStatus> GetBundleAutoRenewal(string msisdn, string accountId, string bundleId);
}