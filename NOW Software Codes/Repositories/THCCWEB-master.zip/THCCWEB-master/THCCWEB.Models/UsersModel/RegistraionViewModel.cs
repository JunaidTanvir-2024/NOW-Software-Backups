﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace THCCWEB.Models.UsersModel
{
    public class RegistraionViewModel
    {
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required(ErrorMessage = "Enter Password")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Enter Confirm Password"), Compare("Password", ErrorMessage = "Passwod do not match")]
        public string ConfirmPassword { get; set; }
        [Required]
        public bool MailSubscription { get; set; }
        [Required]
        public bool ChkTermsConditionsSignUp { get; set; }

    }
}
