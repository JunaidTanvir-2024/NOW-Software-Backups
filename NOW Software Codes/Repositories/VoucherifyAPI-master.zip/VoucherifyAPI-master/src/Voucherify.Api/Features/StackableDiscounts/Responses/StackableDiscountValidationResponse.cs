using Voucherify.Api.Features.StackableDiscounts.Common;

namespace Voucherify.Api.Features.StackableDiscounts.Responses;

public partial class StackableDiscountValidationResponse
{
    public bool IsValid { get; set; }
    public string? CampaignName { get; set; }
    public ApplicableOrder? Order { get; set; }
}
