﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBTopUpPaymentHistory
    {
        public DateTime TransDate { get; set; }
        public string Amount { get; set; }
        public string Method { get; set; }
        public string Reference { get; set; }
    }
    public class DBBundleDetails
    {
        public Guid Id { get; set; }
        public bool IsTrial { get; set; }
        public Guid? TrialId { get; set; }
        public int OffPercentage { get; set; }
        public BundleType Type { get; set; }
        public BundleCategory Category { get; set; }
        public string DisplayName { get; set; }
    }
}
