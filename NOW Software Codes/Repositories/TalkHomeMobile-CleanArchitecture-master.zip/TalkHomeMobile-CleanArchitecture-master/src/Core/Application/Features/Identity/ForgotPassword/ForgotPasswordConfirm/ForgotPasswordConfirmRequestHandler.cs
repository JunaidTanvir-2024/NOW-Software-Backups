﻿using Application.Common.Interfaces.Infrastructure.Identity;

namespace Application.Features.Identity.ForgotPassword.ForgotPasswordConfirm;

public class ForgotPasswordConfirmRequestHandler : IRequestHandler<ForgotPasswordConfirmRequest, Result<object>>
{
    private readonly IOtpService _otpService;
    private readonly IStringLocalizer<ForgotPasswordConfirmRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;

    public ForgotPasswordConfirmRequestHandler(
         IOtpService otpService,
         IStringLocalizer<ForgotPasswordConfirmRequestHandler> localizer,
         IUnitOfWork unitOfWork
       )
    {
        _otpService = otpService;
        _localizer = localizer;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<object>> Handle(ForgotPasswordConfirmRequest request, CancellationToken cancellationToken)
    {
        //validate user for any type of deactivation

        //get user by email
        var userReponse = await _unitOfWork.UserRepo.GetUserByEmail(request.EmailAddress);
        if (userReponse == null)
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.AccountNotRegistered], CustomStatusCode.AccountNotRegistered);
        }

        var response = await _otpService.IsValidOtp(
            request.EmailAddress,
            request.Otp,
            OtpType.ForgotPassword);

        if (response.Code == (int) CustomStatusCode.InvalidOtp)
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.InvalidOtp], CustomStatusCode.InvalidOtp);
        }

        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }
}