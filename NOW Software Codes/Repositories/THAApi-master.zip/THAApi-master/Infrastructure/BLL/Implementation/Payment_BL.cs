﻿using Models.Contracts.Response;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Serilog;
using Models.Configurations;
using Infrastructure.BLL.Interfaces;
using Microsoft.Extensions.Options;
using Infrastructure.DAL.Interfaces;
using Models.Contracts.Request;
using System.Linq;
using Infrastructure.BLL.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Infrastructure.Utilities;
using Microsoft.Extensions.Localization;
using Models.Database;
using Models.Services.Airship;
using System.Net;
using System.Net.Sockets;
using System.Globalization;
using MimeKit;
using System.IO;
using Models.Contracts.Request.Voucherify;
using Models.Constants;
using Infrastructure.BLL.Services.Voucherify.Models.MetadataModels;
using Models.Contracts.PaypalApiContracts;
using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common;
using Newtonsoft.Json;
using System.Text;

namespace Infrastructure.BLL.Implementation
{
	public class Payment_BL : IPayment_BL
	{
		#region Fields
		private readonly IPay360Service _pay360Service;
		private readonly IPayPalPay360Service _payPalByPay360Service;
		private readonly IUserAccount_DL _accountRepo;
		private readonly IBundle_DL _bundleRepo;
		private readonly IHttpContextAccessor _httpContext;
		private readonly IStringLocalizer _localizer;
		private readonly ITransaction_DL _transactionDL;
		private readonly IHelper_BL _helperService;
		private readonly IPaymentFullfillment_DL _paymentFullfillmentDL;
		private readonly IEmailService _emailService;
		private readonly IAirShipService _airShipService;
		private readonly IAppsFlyerService _appsFlyerService;
		private readonly IATTService _attService;
		private readonly IATT_DL _attRepo;
		private readonly ILogger _logger;
		private readonly PayPalConfig _payPalConfig;
		private readonly Pay360Config _pay360Config;
		private readonly AirShipConfig _airShipConfig;
		private readonly InAppPageConfig _inAppPageConfig;
		private readonly IFaceBookService _faceBookService;
		private readonly IVoucherify_BL _voucherifyService;
		private readonly IPayPalService payPalService;
		private readonly IInternationalTopupServiceFeeCalculator _internationalTopupServiceFeeCalculator;
		private readonly IAutoTopup_DL _autoTopupDL;
		private readonly VoucherifyConfig _voucherifyConfig;
		#endregion

		#region Constructor
		public Payment_BL(
			IPay360Service pay360Service,
			IPayPalPay360Service paypalByPay360Service,
			IUserAccount_DL accountRepository,
			IBundle_DL bundleRepository,
			IHttpContextAccessor httpContext,
			IStringLocalizer stringLocalizer,
			ITransaction_DL transaction_DL,
			IHelper_BL helperService,
			IPaymentFullfillment_DL paymentFullfillment_DL,
			IEmailService emailService,
			IAirShipService airShipService,
			IAppsFlyerService appsFlyerService,
			IATTService attService,
			IATT_DL attDL,
			IOptions<AirShipConfig> AirShipConfig,
			IOptions<Pay360Config> pay360Config,
			IOptions<PayPalConfig> paypalConfig,
			IOptions<InAppPageConfig> inAppPageConfig,
			ILogger logger,
			IFaceBookService faceBookService,
			IVoucherify_BL voucherifyService,
			IPayPalService payPalService,
			IOptions<VoucherifyConfig> options,
			IInternationalTopupServiceFeeCalculator internationalTopupServiceFeeCalculator,
			IAutoTopup_DL _autoTopupDL
			)
		{
			_payPalByPay360Service = paypalByPay360Service;
			_pay360Service = pay360Service;
			_accountRepo = accountRepository;
			_bundleRepo = bundleRepository;
			_httpContext = httpContext;
			_localizer = stringLocalizer;
			_transactionDL = transaction_DL;
			_helperService = helperService;
			_paymentFullfillmentDL = paymentFullfillment_DL;
			_emailService = emailService;
			_airShipService = airShipService;
			_appsFlyerService = appsFlyerService;
			_attService = attService;
			_attRepo = attDL;
			this._logger = logger;
			_pay360Config = pay360Config.Value;
			_payPalConfig = paypalConfig.Value;
			_airShipConfig = AirShipConfig.Value;
			_inAppPageConfig = inAppPageConfig.Value;
			_faceBookService = faceBookService;
			this._voucherifyService = voucherifyService;
			this.payPalService = payPalService;
			this._internationalTopupServiceFeeCalculator = internationalTopupServiceFeeCalculator;
			this._autoTopupDL = _autoTopupDL;
			_voucherifyConfig = options.Value;
		}
		#endregion

		#region Version v1
		#region Card Payments Topup and Bundle
		public async Task<GenericApiResponse<CardPaymentResponseModel>> ExistingCardPaymentAsync(
							  ExistingCardPaymentRequestModel model, string msisdn, string currency, string ipAddress, string email, string advertiserID)
		{
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));

			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						email = userInfo.Data.email.Trim();
				}
			}


			DeviceType deviceType = (DeviceType)model.DeviceType;
			string bundleName = "";
			string bundleDest = "";
			long bundleRewardPoints = 0;
			string Currency = "";
			decimal bundlePrice = 0;
			string msisdnOrigin = _helperService.GetCountryCode(msisdn);
			BundleType bundleType = BundleType.PAYG;
			bool isTrialBundle = false;
			decimal ChargeAmount;
			decimal discountAmount = 0;

			if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				if (model.BundleInfo == null
							|| string.IsNullOrEmpty(model.BundleInfo.BundleId))
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
												_localizer["BundleInfoMissing"], ApiStatusCodes.BadRequest);
				}

				//Check Bundle Limit
				var bundlesResponse = await _accountRepo.GetBundlesHistory(accountDetails.AccountID);
				if (bundlesResponse.Count() >= 10)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
												_localizer["MaxNumberOfBundlesPurchased"], ApiStatusCodes.BundleLimitExceeded);
				}

				//Get Bundle details
				var bundleResponse = await _bundleRepo.GetBundleById(model.BundleInfo.BundleId, accountDetails.AccountID);
				if (bundleResponse == null)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
												_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
				}
				bundleDest = bundleResponse.Description.Replace(" ", "").Replace(",", "");
				bundleType = bundleResponse.BundleType;
				Currency = accountDetails.Currency;
				bundlePrice = Convert.ToDecimal(bundleResponse.TotalCostPence / 100, CultureInfo.InvariantCulture);

				if (bundleResponse.IsTrial
					&& bundleResponse.TrialId != null
					&& !(await _bundleRepo.IsBundlePurchasedPreviously(accountDetails.AccountID, bundleResponse.TrialId.ToString())))
				{
					isTrialBundle = true;
					var trialBundle = await _bundleRepo.GetBundleById(
						bundleResponse.TrialId.ToString(), accountDetails.AccountID);
					if (trialBundle == null)
					{
						return GenericApiResponse<CardPaymentResponseModel>.Failure(
												_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
					}
					bundleName = trialBundle.BrandedName;
					bundleDest = trialBundle.Description.Replace(" ", "").Replace(",", "");
					bundleType = trialBundle.BundleType;
					ChargeAmount = _pay360Config.TestPaymentAmount;//This is just test amount which will be refunded after successfull payment
					model.BundleInfo = new BundleInfo()
					{
						BundleId = bundleResponse.TrialId.ToString(),
						IsBundleAutoRenew = true//Autorenewal will be true for trial bundles so that background service can start primary bundle after expire
					};
				}
				else
				{
					bundleName = bundleResponse.BrandedName;
					ChargeAmount = bundleResponse.TotalCostPence / 100;
					if (bundleResponse.BundleType == BundleType.Monthly || bundleResponse.BundleType == BundleType.Welcome)
					{
						//Autorenewal will be true for montly and welcome bundles always
						model.BundleInfo.IsBundleAutoRenew = true;
					}
				}
			}
			else
			{
				if (model.TopupInfo == null || model.TopupInfo.TopUpAmount <= 0)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
											_localizer["TopupInfoMissing"], ApiStatusCodes.BadRequest);
				}
				ChargeAmount = model.TopupInfo.TopUpAmount;
			}

			var paymentrequest = await GeneratePay360PaymentRequest(
				new Pay360PaymentRequestData()
				{
					CustomerMsisdn = msisdn,
					ChargeAmount = ChargeAmount,
					DiscountAmount = discountAmount,
					CheckoutPaymentType = model.CheckoutType,
					BundleId = (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle ? model.BundleInfo.BundleId : ""),
					IpAddress = ipAddress,
					CustomerEmail = email,
					Currency = currency,
					Pay360PaymentType = Pay360PaymentType.Token,
					accountNumber = accountDetails.AccountID,
					CustomerUniqueRef = msisdn,
					CardToken = model.CardToken,
					SecurityCode = model.SecurityCode
				});

			//Don't do 3d secure process in case of trial bundle
			if (isTrialBundle)
			{
				paymentrequest.Pay360PaymentRequestToken.do3DSecure = false;
			}

			var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.Token);

			//Save transaction
			var paymentTransactionId = await _paymentFullfillmentDL.InsertTransactionPaymentAsync(
				paymentrequest.Pay360PaymentRequestToken.basket,
				paymentrequest.Pay360PaymentRequestToken.transactionCurrency,
				paymentrequest.Pay360PaymentRequestToken.customerEmail,
				paymentrequest.Pay360PaymentRequestToken.productCode,
				paymentResponse != null && paymentResponse.Payload != null
										&& !string.IsNullOrEmpty(paymentResponse.Payload.transactionId) ?
				paymentResponse.Payload.transactionId : null,
				paymentrequest.Pay360PaymentRequestToken.customerMsisdn,
				TransactionsPaymentType.Card,
				0,
				isTrialBundle,
				null, null);

			//Handle Error Scenarios
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = true,
							Msisdn = msisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});


					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
				}
				else
				{
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							IsCard = true,
							Msisdn = msisdn,
							Amount = ChargeAmount.ToString(CultureInfo.InvariantCulture)
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(advertiserID, false, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					//Handle AppFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, false, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);
				}


				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId,
						false,
						null,
						paymentResponse == null
						? "Payment Service Not Responding - Null Response - Exist Customer"
						 : $"{paymentResponse.ErrorCode} - {paymentResponse.Message} - Exist Customer");

				return HandlePay360PaymentFailureResponse
					<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, model.CheckoutType);
			}
			if (paymentResponse.Payload.outcome.reasonCode == "U100") //3d Secure Scenario
			{
				//Set default card
				if (model.IsDefaultCard)
				{
					await _pay360Service.SetDefaultCard(msisdn, new SetDefaultCardUserRequest
					{
						CardToken = model.CardToken,
						CV2 = model.SecurityCode
					});
				}
				/*Make sure to encrypt url here
                 * Convert the hardcoded string to classs
                 * and Implement the class to query string convertsion method
                 */

				var secure3dType = paymentResponse.Payload.clientRedirect.type.ToLower().Contains("v2") ? "v2" : "v1";

				string returnUrl = _inAppPageConfig.BaseUrl + "/Pay360/Resume3DTransaction";
				var AirshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();
				string querParms =
					"?CheckoutType=" + (int)model.CheckoutType +
					"&CustomerEmail=" + email +
					"&CustomerMsisdn=" + msisdn +
					"&Currency=" + currency +
					"&BundleId=" + (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle ? model.BundleInfo.BundleId : "") +
					"&Secure3dType=" + secure3dType +
					"&PTId=" + paymentTransactionId +
					"&Ip=" + ipAddress +
					"&advertiserID=" + advertiserID +
					"&AirshipEventsDisable=" + AirshipEventsDisable +
					"&IsDefaultCard=" + model.IsDefaultCard +
					"&culture=" + _localizer["Locale"];

				if (model.AppsFlyerId != null)
				{
					querParms += $"&AppsFlyerId={model.AppsFlyerId}" +
								 $"&DeviceType={model.DeviceType}";
				}
				if (model.TopupInfo != null && model.TopupInfo.AutoTopupInfo != null)
				{
					querParms += "&IsAutoTopUp=" + model.TopupInfo.AutoTopupInfo.isActive +
								 "&AutoToupAmount=" + model.TopupInfo.AutoTopupInfo.amount +
								 "&AutoTopupThreshold=" + model.TopupInfo.AutoTopupInfo.thresholdBalanceAmount;
				}
				if (model.BundleInfo != null)
				{
					querParms += "&IsAutoRenewal=" + model.BundleInfo.IsBundleAutoRenew;
				}
				if (model.UtmParamsInfo != null)
				{
					querParms += "&UtmCampaign=" + model.UtmParamsInfo.utm_campaign +
								 "&UtmMedium=" + model.UtmParamsInfo.utm_medium +
								 "&UtmSource=" + model.UtmParamsInfo.utm_source;
				}

				returnUrl += querParms;

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
							paymentTransactionId, false, paymentResponse.Payload.transactionId);

				//Send Response
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
												new CardPaymentResponseModel()
												{
													threeDSecureData = new ThreeDSecureData()
													{
														pareq = paymentResponse.Payload.clientRedirect.pareq,
														redirectUrl = paymentResponse.Payload.clientRedirect.url,
														transactionId = paymentResponse.Payload.transactionId,
														returnUrl = returnUrl,
														type = secure3dType,
														threeDSServerTransId = paymentResponse.Payload.clientRedirect.threeDSServerTransId
													}
												}, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);
			}
			else if (paymentResponse.Payload.outcome.reasonCode == "S100")
			{
				//Set default card
				if (model.IsDefaultCard)
				{
					await _pay360Service.SetDefaultCard(msisdn, new SetDefaultCardUserRequest
					{
						CardToken = model.CardToken,
						CV2 = model.SecurityCode
					});
				}
				//Payment successfull
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, true);

				//fullfill
				await Pay360CardPaymentFullfillment(paymentResponse, msisdn, email, isTrialBundle, accountDetails.AccountID);

				//Get Updated User Balance
				var userBalance = await _accountRepo.GetUserAccountBalanceAsync(msisdn);

				var currencySymbol = _helperService.ToCurrencySymbol(currency);

				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					if (model.BundleInfo != null)
					{
						var autoRenewRes = await _bundleRepo.SetBundleAutoRenewal(
							model.BundleInfo.IsBundleAutoRenew,
							msisdn,
							accountDetails.AccountID,
							model.BundleInfo.BundleId,
							isTrialBundle);
						if (autoRenewRes.isValid && bundleType != BundleType.Welcome)
						{
							await _airShipService.HandleAutoRenew(
								msisdn, model.BundleInfo.IsBundleAutoRenew, bundleDest, bundleType);
						}
					}

					//bool isFirstBundle = await _accountRepo.IsFirstBundle(msisdn);

					//App flyer events
					//await _appsFlyerService.HandleBundlePurchaseEvents(
					//    model.AppsFlyerInfo,
					//    (decimal)ChargeAmount,
					//    currency,
					//    ipAddress,
					//    msisdnOrigin,
					//    bundleDest,
					//    isFirstBundle);

					//Airship events
					await _airShipService.HandleBundleTagsAndEvents(new BundleInfoAirShip()
					{
						IsSuccess = true,
						Origination = msisdnOrigin,
						Destination = bundleDest,
						IsCard = true,
						Msisdn = msisdn,
						BundleType = bundleType,
						Amount = bundlePrice
					});


					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);
					//Handle Appflyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);

					//Refund payment if trial bundle
					if (isTrialBundle)
					{
						await _pay360Service.RefundFullPayment(
							new Models.Contracts.Request.RefundFullPaymentRequestModel()
							{
								transactionId = paymentResponse.Payload.transactionId
							});
					}

					return GenericApiResponse<CardPaymentResponseModel>.Success(
						new CardPaymentResponseModel()
						{
							bundlePurchaseInfo = new BundlePurchaseInfo()
							{
								TransactionId = paymentResponse.Payload.transactionId,
								BundleAmount = isTrialBundle ? "0" : paymentResponse.Payload.transactionAmount,
								BundleName = bundleName,
								Msisdn = msisdn,
								Currency = currencySymbol,
								Destination = bundleDest,
								Type = bundleType,
							},
							customerMsisdn = msisdn,
							transactionId = paymentResponse.Payload.transactionId
						}, _localizer["BundlePurchasedSuccessfully"]);
				}
				else
				{


					if (model.TopupInfo.AutoTopupInfo != null)
					{
						var autoTopupRes = await _pay360Service.SetAutoTopUp(model.TopupInfo.AutoTopupInfo, msisdn, currency, email);
						if (autoTopupRes.ErrorCode == 0)
						{
							await _airShipService.HandleAutoTopup(msisdn, model.TopupInfo.AutoTopupInfo.isActive);
						}
					}

					//AppFlyer events
					//await _appsFlyerService.HandleTopupEvents(
					//    model.AppsFlyerInfo,
					//    (decimal)ChargeAmount,
					//    currency,
					//    msisdnOrigin,
					//    ipAddress,
					//    isFirstTopup);

					//Airship events
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = true,
							Origination = msisdnOrigin,
							IsCard = true,
							Msisdn = msisdn,
							Amount = ChargeAmount.ToString(CultureInfo.InvariantCulture)
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(advertiserID, true, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, true, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					return GenericApiResponse<CardPaymentResponseModel>.Success(
						new CardPaymentResponseModel()
						{
							topupInfo = new TopupInfo()
							{
								TopupAmount = paymentResponse.Payload.transactionAmount,
								Msisdn = msisdn,
								TransactionId = paymentResponse.Payload.transactionId,
								Currency = currencySymbol,
								NewBalance = userBalance.Balance
							},
							customerMsisdn = msisdn,
							transactionId = paymentResponse.Payload.transactionId
						}, _localizer["TopUpSuccessful", paymentResponse.Payload.transactionAmount]);
				}
			}

			return GenericApiResponse<CardPaymentResponseModel>.Failure(
				null, _localizer["PaymentServiceNotResponding"], ApiStatusCodes.PaymentServiceError);
		}


		public async Task<GenericApiResponse<CardPaymentResponseModel>> ActivateBundleDefaultCardPaymentAsync(
							  ActivateBundleRequestModel model, string msisdn, string currency, string ipAddress, string email, string advertiserID)
		{
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));
			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						email = userInfo.Data.email.Trim();
				}
			}

			DeviceType deviceType = (DeviceType)model.DeviceType;
			string bundleName = "";
			string bundleDest = "";
			string Currency = "";
			decimal bundlePrice = 0;
			string msisdnOrigin = _helperService.GetCountryCode(msisdn);
			BundleType bundleType = BundleType.Monthly;
			var isTrialBundle = false;
			decimal ChargeAmount = 0;
			decimal discountAmount = 0;

			model.BundleInfo.IsBundleAutoRenew = true;//auto renewal will be true for monthly bundles always
			if (model.BundleInfo == null || string.IsNullOrEmpty(model.BundleInfo.BundleId))
			{
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
											_localizer["BundleInfoMissing"], ApiStatusCodes.BadRequest);
			}

			//Check Bundle Limit
			var bundlesResponse = await _accountRepo.GetBundlesHistory(accountDetails.AccountID);
			if (bundlesResponse.Count() >= 10)
			{
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
											_localizer["MaxNumberOfBundlesPurchased"], ApiStatusCodes.BundleLimitExceeded);
			}

			//Get Bundle details
			var bundleResponse = await _bundleRepo.GetBundleById(model.BundleInfo.BundleId, accountDetails.AccountID);
			if (bundleResponse == null)
			{
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
											_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
			}
			bundlePrice = Convert.ToDecimal(bundleResponse.TotalCostPence / 100, CultureInfo.InvariantCulture);

			if (bundleResponse.BundleType != BundleType.Monthly)
			{
				//Only monthly bundles can be activated through this api
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
											_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
			}

			//Monthly bundle validation
			if (!await _bundleRepo.MonthlyBundleValidationAfterTrialExpire(
				accountDetails.AccountID, msisdn, bundleResponse.ID.ToString(), bundleResponse.TrialId.ToString()))
			{
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
													_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
			}

			bundleDest = bundleResponse.Description.Replace(" ", "").Replace(",", "");
			bundleType = bundleResponse.BundleType;
			Currency = accountDetails.Currency;
			ChargeAmount = bundleResponse.TotalCostPence / 100;
			var cust = await _paymentFullfillmentDL.GetCustomerByMerchantRef(msisdn);
			string cardCv2 = RijndaelEncryption.Decrypt(cust.DefaultCardCV2, cust.EncryptionKey);
			IPAddress ip = Dns.GetHostAddresses(Dns.GetHostName()).Where(address => address.AddressFamily == AddressFamily.InterNetwork).First();

			var paymentrequest = await GeneratePay360PaymentRequest(
				new Pay360PaymentRequestData()
				{
					CustomerMsisdn = msisdn,
					ChargeAmount = ChargeAmount,
					DiscountAmount = discountAmount,
					CheckoutPaymentType = Models.Enums.CheckOutTypes.Bundle,
					BundleId = model.BundleInfo.BundleId,
					IpAddress = ipAddress,
					CustomerEmail = email,
					Currency = currency,
					Pay360PaymentType = Pay360PaymentType.Default,
					accountNumber = accountDetails.AccountID,
					CustomerUniqueRef = msisdn,
					SecurityCode = cardCv2
				});

			//Don't do 3d secure process in case of bundle bundle activate
			paymentrequest.Pay360PaymentRequestDefault.do3DSecure = false;

			var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.Default);

			//Save transaction
			var paymentTransactionId = await _paymentFullfillmentDL.InsertTransactionPaymentAsync(
				paymentrequest.Pay360PaymentRequestDefault.basket,
				paymentrequest.Pay360PaymentRequestDefault.transactionCurrency,
				paymentrequest.Pay360PaymentRequestDefault.customerEmail,
				paymentrequest.Pay360PaymentRequestDefault.productCode,
				paymentResponse != null && paymentResponse.Payload != null
										&& !string.IsNullOrEmpty(paymentResponse.Payload.transactionId) ?
				paymentResponse.Payload.transactionId : null,
				paymentrequest.Pay360PaymentRequestDefault.customerMsisdn,
				TransactionsPaymentType.Card,
				0,
				isTrialBundle,
				null, null);

			//Handle Error Scenarios
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleBundleTagsAndEvents(
					new BundleInfoAirShip()
					{
						IsSuccess = false,
						Origination = msisdnOrigin,
						Destination = bundleDest,
						IsCard = true,
						Msisdn = msisdn,
						BundleType = bundleType,
						Amount = bundlePrice
					});

				//Handle FaceBook Events
				await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
				//Handle AppsFlyer Events
				await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId,
						false,
						null,
						paymentResponse == null ?
						 "Payment Service Not Responding - Null Response - Exist Customer" :
						  $"{paymentResponse.ErrorCode} - {paymentResponse.Message} - Exist Customer");

				return HandlePay360PaymentFailureResponse
					<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, Models.Enums.CheckOutTypes.Bundle);
			}
			if (paymentResponse.Payload.outcome.reasonCode == "S100")
			{
				//Payment successfull
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, true);

				//fullfill
				await Pay360CardPaymentFullfillment(paymentResponse, msisdn, email, isTrialBundle, accountDetails.AccountID);

				//Get Updated User Balance
				var userBalance = await _accountRepo.GetUserAccountBalanceAsync(msisdn);

				var currencySymbol = _helperService.ToCurrencySymbol(currency);

				if (model.BundleInfo != null)
				{
					//Set autorenewal false for trial bundle so that background service don't activate that bundle twice
					if (bundleResponse.TrialId != null)
						await _bundleRepo.SetBundleAutoRenewal(false, msisdn, accountDetails.AccountID, bundleResponse.TrialId.ToString());

					//Set autorenewal true for monthly bundle
					if (bundleType != BundleType.Welcome)
					{
						var autoRenewRes = await _bundleRepo.SetBundleAutoRenewal(
						model.BundleInfo.IsBundleAutoRenew,
						msisdn,
						accountDetails.AccountID,
						model.BundleInfo.BundleId);

						if (autoRenewRes.isValid)
						{
							await _airShipService.HandleAutoRenew(msisdn, model.BundleInfo.IsBundleAutoRenew, bundleDest, bundleType);
						}
					}
				}

				//bool isFirstBundle = await _accountRepo.IsFirstBundle(msisdn);

				//App flyer events
				//await _appsFlyerService.HandleBundlePurchaseEvents(
				//    model.AppsFlyerInfo,
				//    (decimal)ChargeAmount,
				//    currency,
				//    ipAddress,
				//    msisdnOrigin,
				//    bundleDest,
				//    isFirstBundle);

				//Airship events
				await _airShipService.HandleBundleTagsAndEvents(new BundleInfoAirShip()
				{
					IsSuccess = true,
					Origination = msisdnOrigin,
					Destination = bundleDest,
					IsCard = true,
					Msisdn = msisdn,
					BundleType = bundleType,
					Amount = bundlePrice
				});


				//Handle FaceBook Events
				await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);
				//Handle AppsFlyer Events
				await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);

				return GenericApiResponse<CardPaymentResponseModel>.Success(
					new CardPaymentResponseModel()
					{
						bundlePurchaseInfo = new BundlePurchaseInfo()
						{
							TransactionId = paymentResponse.Payload.transactionId,
							BundleAmount = paymentResponse.Payload.transactionAmount,
							BundleName = bundleName,
							Msisdn = msisdn,
							Currency = currencySymbol,
							Destination = bundleDest,
							Type = bundleType
						}
					}, _localizer["BundlePurchasedSuccessfully"]);
			}

			return GenericApiResponse<CardPaymentResponseModel>.Failure(null,
												_localizer["PaymentServiceNotResponding"], ApiStatusCodes.PaymentServiceError);
		}

		public async Task<GenericApiResponse<CardPaymentResponseModel>> NewCustomerPaymentAsync(NewCustomerPaymentRequestModel model, string msisdn, string currency, string ipAddress, string email, string advertiserID)
		{
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));

			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						email = userInfo.Data.email.Trim();
				}
			}

			//DeviceType deviceType = (DeviceType)Enum.Parse(typeof(DeviceType), model.DeviceType, true);
			DeviceType deviceType = (DeviceType)model.DeviceType;
			string bundleName = "";
			string bundleDest = "";
			string Currency = "";
			decimal bundlePrice = 0;
			string msisdnOrigin = _helperService.GetCountryCode(msisdn);
			BundleType bundleType = BundleType.PAYG;
			bool isTrialBundle = false;
			decimal ChargeAmount;
			decimal discountAmount = 0;
			if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				if (model.BundleInfo == null
					|| string.IsNullOrWhiteSpace(model.BundleInfo.BundleId))
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
					   _localizer["BundleInfoMissing"],
					   ApiStatusCodes.BadRequest);
				}

				//Check Bundle Limit
				var bundlesResponse = await _accountRepo.GetBundlesHistory(accountDetails.AccountID);
				if (bundlesResponse.Count() >= 10)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
						_localizer["MaxNumberOfBundlesPurchased"],
						ApiStatusCodes.BundleLimitExceeded);
				}

				//Get Bundle details
				var bundleResponse = await _bundleRepo.GetBundleById(model.BundleInfo.BundleId, accountDetails.AccountID);
				if (bundleResponse == null)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
						_localizer["InvalidBundle"],
						ApiStatusCodes.InvalidBundle);
				}

				bundleDest = bundleResponse.Description.Replace(" ", "").Replace(",", "");
				bundleType = bundleResponse.BundleType;
				Currency = accountDetails.Currency;
				bundlePrice = Convert.ToDecimal(bundleResponse.TotalCostPence / 100, CultureInfo.InvariantCulture);

				if (bundleResponse.IsTrial
					&& bundleResponse.TrialId != null
					&& !(await _bundleRepo.IsBundlePurchasedPreviously(accountDetails.AccountID, bundleResponse.TrialId.ToString())))
				{
					//Trial bundle
					var trialBundle = await _bundleRepo.GetBundleById(bundleResponse.TrialId.ToString(), accountDetails.AccountID);
					if (trialBundle == null)
					{
						return GenericApiResponse<CardPaymentResponseModel>.Failure(_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
					}
					bundleName = trialBundle.BrandedName;
					bundleDest = trialBundle.Description.Replace(" ", "").Replace(",", "");
					bundleType = trialBundle.BundleType;
					isTrialBundle = true;
					ChargeAmount = _pay360Config.TestPaymentAmount;//This amount is just for testing payment method, after successfull transaction this amount will be refunded
					model.BundleInfo = new BundleInfo()
					{
						BundleId = bundleResponse.TrialId.ToString(),
						IsBundleAutoRenew = true//Autorenewal will be true for trial bundle so that our backgroudn service can start primary bundle
					};
					model.CardInfo.ShouldSaveCard = true;//Save card bit will be true always for trial bundles
				}
				else
				{
					//Normal bundle
					bundleName = bundleResponse.BrandedName;
					ChargeAmount = bundleResponse.TotalCostPence / 100;
					if (bundleResponse.BundleType == BundleType.Monthly || bundleResponse.BundleType == BundleType.Welcome)
					{
						model.BundleInfo.IsBundleAutoRenew = true;//Monthly and Welcome bundles autorenewal will be true always
						model.CardInfo.ShouldSaveCard = true;//Save card bit will be true always for montly bundles
					}
				}
			}
			else
			{
				if (model.TopupInfo == null || model.TopupInfo.TopUpAmount <= 0)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
					   _localizer["TopupInfoMissing"],
					   ApiStatusCodes.BadRequest);
				}
				ChargeAmount = model.TopupInfo.TopUpAmount;

			}

			var paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
			{
				CustomerMsisdn = msisdn,
				ChargeAmount = ChargeAmount,
				DiscountAmount = discountAmount,
				CheckoutPaymentType = model.CheckoutType,
				BundleId = (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle ? model.BundleInfo.BundleId : ""),
				IpAddress = ipAddress,
				CustomerEmail = email,
				Currency = currency,
				Pay360PaymentType = Pay360PaymentType.New,
				CustomerAddressData = new AddressData()
				{
					AddressL1 = model.AddressInfo.AddressL1,
					AddressL2 = model.AddressInfo.AddressL2,
					AddressL3 = model.AddressInfo.AddressL3,
					AddressL4 = model.AddressInfo.AddressL4,
					PostCode = model.AddressInfo.PostCode,
					City = model.AddressInfo.City,
					Region = model.AddressInfo.Region,
					CountryCode = model.AddressInfo.CountryCode
				},
				CustomerCardData = new CardData()
				{
					CardNumber = model.CardInfo.CardNumber,
					NameOnCard = model.CardInfo.NameOnCard,
					SecurityCode = model.CardInfo.SecurityCode,
					ExpiryDate = model.CardInfo.ExpiryDate
				},
				ShouldSaveCard = model.CardInfo.ShouldSaveCard,
				IsDefaultCard = model.CardInfo.IsDefaultCard,
				accountNumber = accountDetails.AccountID,
				CustomerUniqueRef = msisdn
			});

			//Don't do 3d secure process in case of trial bundle
			if (isTrialBundle)
			{
				paymentrequest.Pay360PaymentRequestNew.do3DSecure = false;
			}

			var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.New);

			//save transaction
			var paymentTransactionId = await _paymentFullfillmentDL.InsertTransactionPaymentAsync(
				paymentrequest.Pay360PaymentRequestNew.basket,
				paymentrequest.Pay360PaymentRequestNew.transactionCurrency,
				paymentrequest.Pay360PaymentRequestNew.customerEmail,
				paymentrequest.Pay360PaymentRequestNew.productCode,
				paymentResponse != null && paymentResponse.Payload != null && !string.IsNullOrEmpty(paymentResponse.Payload.transactionId) ?
				paymentResponse.Payload.transactionId : null,
				paymentrequest.Pay360PaymentRequestNew.customerMsisdn,
				TransactionsPaymentType.Card,
				0,
				isTrialBundle,
				null, null);

			//Handle Error Scenarios
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = true,
							Msisdn = msisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});


					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
				}
				else
				{
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							IsCard = true,
							Msisdn = msisdn,
							Amount = ChargeAmount.ToString(CultureInfo.InvariantCulture)
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(advertiserID, false, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, false, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);
				}

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId,
						false,
						null,
						paymentResponse == null ? "Payment Service Not Responding - Null Response - New Customer"
						: $"{paymentResponse.ErrorCode} - {paymentResponse.Message} - New Customer");

				return HandlePay360PaymentFailureResponse
					<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, model.CheckoutType);
			}

			if (paymentResponse.Payload.outcome.reasonCode == "U100") //3d Secure Scenario
			{
				/*Make sure to encrypt url here
                   * Convert the hardcoded string to classs
                   * and Implement the class to query string convertsion method
                   */

				var secure3dType = paymentResponse.Payload.clientRedirect.type.ToLower().Contains("v2") ? "v2" : "v1";

				string returnUrl = _inAppPageConfig.BaseUrl + "/Pay360/Resume3DTransaction";
				var airshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();
				string querParms =
					"?CheckoutType=" + (int)model.CheckoutType +
					"&CustomerEmail=" + email +
					"&CustomerMsisdn=" + msisdn +
					"&Currency=" + currency +
					"&BundleId=" + (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle ? model.BundleInfo.BundleId : "") +
					"&Secure3dType=" + secure3dType +
					"&PTId=" + paymentTransactionId +
					"&Ip=" + ipAddress +
					"&advertiserID=" + advertiserID +
					"&airshipEventsDisable=" + airshipEventsDisable +
					"&SaveCard=" + paymentrequest.Pay360PaymentRequestNew.saveCard +
					"&culture=" + _localizer["Locale"];

				if (model.AppsFlyerId != null)
				{
					querParms += $"&AppsFlyerId={model.AppsFlyerId}" +
								 $"&DeviceType={model.DeviceType}";
				}

				if (model.TopupInfo != null && model.TopupInfo.AutoTopupInfo != null)
				{
					querParms += "&IsAutoTopUp=" + model.TopupInfo.AutoTopupInfo.isActive +
								 "&AutoToupAmount=" + model.TopupInfo.AutoTopupInfo.amount +
								 "&AutoTopupThreshold=" + model.TopupInfo.AutoTopupInfo.thresholdBalanceAmount;
				}

				if (model.BundleInfo != null)
				{
					querParms += "&IsAutoRenewal=" + model.BundleInfo.IsBundleAutoRenew;
				}

				if (model.UtmParamsInfo != null)
				{
					querParms += "&UtmCampaign=" + model.UtmParamsInfo.utm_campaign +
								 "&UtmMedium=" + model.UtmParamsInfo.utm_medium +
								 "&UtmSource=" + model.UtmParamsInfo.utm_source;
				}

				returnUrl += querParms;

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId, false, paymentResponse.Payload.transactionId);

				//Send Response
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
												new CardPaymentResponseModel()
												{
													threeDSecureData = new ThreeDSecureData()
													{
														pareq = paymentResponse.Payload.clientRedirect.pareq,
														redirectUrl = paymentResponse.Payload.clientRedirect.url,
														transactionId = paymentResponse.Payload.transactionId,
														returnUrl = returnUrl,
														type = secure3dType,
														threeDSServerTransId = paymentResponse.Payload.clientRedirect.threeDSServerTransId
													}
												}, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);
			}
			else if (paymentResponse.Payload.outcome.reasonCode == "S100")
			{
				//Payment successfull
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, true);

				//Fulfillment
				await Pay360CardPaymentFullfillment(paymentResponse, msisdn, email, isTrialBundle, accountDetails.AccountID);

				//Get Updated User Balance
				var userBalance = await _accountRepo.GetUserAccountBalanceAsync(msisdn);

				var currencySymbol = _helperService.ToCurrencySymbol(currency);

				if (paymentrequest.Pay360PaymentRequestNew.saveCard)
				{
					await _airShipService.AddNamedUserTags(
						new NamedUserTagsRequest()
						{
							NamedUser = msisdn,
							Tags = new List<string>() { "addcard_app" },
							TagGroup = _airShipConfig.ActivityTagGroupName
						});
				}

				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					//var isFirstBundle = await _accountRepo.IsFirstBundle(msisdn);

					var autoRenewResp = await _bundleRepo.SetBundleAutoRenewal(
					model.BundleInfo.IsBundleAutoRenew, msisdn, accountDetails.AccountID,
					model.BundleInfo.BundleId, isTrialBundle);

					if (autoRenewResp.isValid && bundleType != BundleType.Welcome)
					{
						await _airShipService.HandleAutoRenew(
							msisdn, model.BundleInfo.IsBundleAutoRenew, bundleDest, bundleType);
					}

					//Refund payment if trial bundle
					if (isTrialBundle)
					{
						await _pay360Service.RefundFullPayment(
							new Models.Contracts.Request.RefundFullPaymentRequestModel()
							{
								transactionId = paymentResponse.Payload.transactionId,
							});
					}
					//ApsFlyer events
					//await _appsFlyerService.HandleBundlePurchaseEvents(
					//    model.AppsFlyerInfo,
					//    decimal.Parse(paymentResponse.Payload.transactionAmount,CultureInfo.InvariantCulture),
					//    currency,
					//    ipAddress,
					//    msisdnOrigin,
					//    bundleDest,
					//    isFirstBundle);

					//Airship events
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = true,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = true,
							Msisdn = msisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});


					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);
					//Handle Appsflyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);

					return GenericApiResponse<CardPaymentResponseModel>.Success(
						new CardPaymentResponseModel()
						{
							bundlePurchaseInfo = new BundlePurchaseInfo()
							{
								TransactionId = paymentResponse.Payload.transactionId,
								BundleAmount = isTrialBundle ? "0" : paymentResponse.Payload.transactionAmount,
								BundleName = bundleName,
								Msisdn = msisdn,
								Currency = currencySymbol,
								Destination = bundleDest,
								Type = bundleType,
							},
							customerMsisdn = msisdn,
							transactionId = paymentResponse.Payload.transactionId
						}, _localizer["BundlePurchasedSuccessfully"]);
				}
				else
				{
					if (model.TopupInfo.AutoTopupInfo != null)
					{
						var autoTopupResp = await _pay360Service.SetAutoTopUp(
									model.TopupInfo.AutoTopupInfo, msisdn, currency, email);
						if (autoTopupResp.ErrorCode == 0)
						{
							await _airShipService.HandleAutoTopup(msisdn, model.TopupInfo.AutoTopupInfo.isActive);
						}
					}

					//AppsFlyer events
					//await _appsFlyerService.HandleTopupEvents(
					//    model.AppsFlyerInfo,
					//    decimal.Parse(paymentResponse.Payload.transactionAmount,CultureInfo.InvariantCulture),
					//    currency,
					//    msisdnOrigin,
					//    ipAddress,
					//    isFirstTopup);

					//Airship events
					await _airShipService.HandleTopupTagsAndEvents(
							 new TopupInfoAirship()
							 {
								 IsSuccess = true,
								 Origination = msisdnOrigin,
								 IsCard = true,
								 Msisdn = msisdn,
								 Amount = ChargeAmount.ToString(CultureInfo.InvariantCulture)
							 });


					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(advertiserID, true, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, true, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					return GenericApiResponse<CardPaymentResponseModel>.Success(
						new CardPaymentResponseModel()
						{
							topupInfo = new TopupInfo()
							{
								TopupAmount = paymentResponse.Payload.transactionAmount,
								Msisdn = msisdn,
								TransactionId = paymentResponse.Payload.transactionId,
								Currency = currencySymbol,
								NewBalance = userBalance.Balance,
							},
							customerMsisdn = msisdn,
							transactionId = paymentResponse.Payload.transactionId
						}, _localizer["TopUpSuccessful", paymentResponse.Payload.transactionAmount]);
				}
			}

			return GenericApiResponse<CardPaymentResponseModel>.Failure(
				null, _localizer["PaymentServiceNotResponding"], ApiStatusCodes.PaymentServiceError);
		}

		public async Task<GenericApiResponse<CardPaymentResponseModel>> Resume3DTransactionAsync(Resume3DPaymentRequest request, Resume3DPaymentDataRequest data)
		{
			GenericPay360ApiResponse<Pay360PaymentResponse> paymentResponse;

			if (data.Secure3dType.Equals("v1", StringComparison.InvariantCultureIgnoreCase))
			{
				paymentResponse = await _pay360Service.Resume3DV1Transaction(
					new Pay360Resume3DRequest()
					{
						pareq = request.PaRes,
						pay360TransactionId = request.MD,
						customerEmail = data.CustomerEmail
					});
			}
			else
			{
				paymentResponse = await _pay360Service.Resume3DV2Transaction(
					new Pay360Resume3DRequest()
					{
						pay360TransactionId = request.MD,
						customerEmail = data.CustomerEmail,
						overallStatus = request.OverallStatus
					});
			}

			// Cannot resume again scenario 
			if (paymentResponse != null
				&& paymentResponse.ErrorCode > 0
				&& (paymentResponse.Pay360ApiCode.Equals("V107")))
			{
				return HandlePay360PaymentFailureResponse<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, data.CheckoutType);
			}

			DeviceType deviceType = (DeviceType)data.DeviceType;
			string bundleName = "";
			string bundleDest = "";
			string Currency = "";
			decimal bundlePrice = 0;
			decimal discountAmount = 0;
			var msisdnOrigin = _helperService.GetCountryCode(data.CustomerMsisdn);
			BundleType bundleType = BundleType.PAYG;
			bool isTrialBundle = false;

			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(
											_helperService.GetSipUserName(data.CustomerMsisdn));

			if (data.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				var bundleInfo = await _bundleRepo.GetBundleById(data.BundleId, accountDetails.AccountID);
				bundleDest = bundleInfo.Description.Replace(" ", "").Replace(",", "");
				bundleType = bundleInfo.BundleType;
				Currency = accountDetails.Currency;
				bundleName = bundleInfo.BrandedName;
				bundlePrice = Convert.ToDecimal(bundleInfo.TotalCostPence / 100, CultureInfo.InvariantCulture);
				if (bundleInfo.IsTrial && bundleInfo.TrialId != null)
					isTrialBundle = bundleInfo.IsTrial;
			}

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				if (data.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = true,
							Msisdn = data.CustomerMsisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});


					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(data.advertiserID, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(data.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
				}
				else
				{
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							IsCard = true,
							Msisdn = data.CustomerMsisdn,
							Amount = ""
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(data.advertiserID, false, true, 0, Currency, msisdnOrigin);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(data.AppsFlyerId, deviceType, false, true, 0, Currency, msisdnOrigin);
				}

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
					data.PTId,
					false,
					null,
					paymentResponse == null ? "Payment Service Not Responding - Resume" : paymentResponse.ErrorCode + " - " + paymentResponse.Message + " - Resume");

				return HandlePay360PaymentFailureResponse
						 <Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, data.CheckoutType);
			}

			//Successful payment
			await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(data.PTId, true);

			//Fulfillment
			await Pay360CardPaymentFullfillment(paymentResponse, data.CustomerMsisdn, data.CustomerEmail, isTrialBundle, accountDetails.AccountID);

			//GetUserBalance
			var userBalance = await _accountRepo.GetUserAccountBalanceAsync(data.CustomerMsisdn);

			var currencySymbol = _helperService.ToCurrencySymbol(data.Currency);
			if (data.SaveCard)
			{
				await _airShipService.AddNamedUserTags(
					new NamedUserTagsRequest()
					{
						NamedUser = data.CustomerMsisdn,
						Tags = new List<string>() { "addcard_app" },
						TagGroup = _airShipConfig.ActivityTagGroupName
					});
			}
			if (data.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				//bool isFirstBundle = await _accountRepo.IsFirstBundle(data.CustomerMsisdn);

				//Refund payment if trial bundle
				if (isTrialBundle)
				{
					await _pay360Service.RefundFullPayment(
						new Models.Contracts.Request.RefundFullPaymentRequestModel()
						{
							transactionId = paymentResponse.Payload.transactionId,
						});
				}

				//Set Bundle Auto Renewal
				var autoRenewResp = await _bundleRepo.SetBundleAutoRenewal(
					data.IsAutoRenewal,
					data.CustomerMsisdn,
					accountDetails.AccountID,
					data.BundleId);

				if (bundleType != BundleType.Welcome)
				{
					if (autoRenewResp.isValid)
						await _airShipService.HandleAutoRenew(
							data.CustomerMsisdn,
							data.IsAutoRenewal,
							bundleDest,
							bundleType);
				}


				//AppsFlyer events
				//await _appsFlyerService.HandleBundlePurchaseEvents(
				//    new AppsFlyerInfo(data.AppsFlyerId, data.DeviceType),
				//    decimal.Parse(paymentResponse.Payload.transactionAmount,CultureInfo.InvariantCulture),
				//    data.Currency,
				//    data.Ip,
				//    msisdnOrigin,
				//    bundleDest,
				//    isFirstBundle);

				//Airship event
				await _airShipService.HandleBundleTagsAndEvents(
					new BundleInfoAirShip()
					{
						IsSuccess = true,
						Origination = msisdnOrigin,
						Destination = bundleDest,
						IsCard = true,
						Msisdn = data.CustomerMsisdn,
						BundleType = bundleType,
						Amount = bundlePrice
					});


				//Handle FaceBook Events
				await _faceBookService.HandleBundlePurchaseEvents(data.advertiserID, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);
				//Handle AppsFlyer Events
				await _appsFlyerService.HandleBundlePurchaseEvents(data.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);

				return GenericApiResponse<CardPaymentResponseModel>.Success(
					new CardPaymentResponseModel()
					{
						bundlePurchaseInfo = new BundlePurchaseInfo()
						{
							TransactionId = paymentResponse.Payload.transactionId,
							BundleAmount = isTrialBundle ? "0" : paymentResponse.Payload.transactionAmount,
							BundleName = bundleName,
							Msisdn = data.CustomerMsisdn,
							Currency = currencySymbol,
							Destination = bundleDest,
							Type = bundleType
						},
						customerMsisdn = data.CustomerMsisdn,
						transactionId = paymentResponse.Payload.transactionId
					}, _localizer["BundlePurchasedSuccessfully"]);
			}
			else
			{
				//Set auto top-up
				if (data.AutoTopupThreshold > 0 && data.AutoToupAmount > 0)
				{
					var autoTopupRes = await _pay360Service.SetAutoTopUp(
						new SetAutoTopUpRequestModel()
						{
							amount = data.AutoToupAmount,
							isActive = data.IsAutoTopUp,
							thresholdBalanceAmount = data.AutoTopupThreshold
						},
					 data.CustomerMsisdn,
					 data.Currency,
					 data.CustomerEmail);

					if (autoTopupRes.ErrorCode == 0)
					{
						await _airShipService.HandleAutoTopup(data.CustomerMsisdn, data.IsAutoTopUp);
					}
				}

				////AppsFlyer events
				//await _appsFlyerService.HandleTopupEvents(
				//    new AppsFlyerInfo(data.AppsFlyerId, data.DeviceType),
				//    decimal.Parse(paymentResponse.Payload.transactionAmount,CultureInfo.InvariantCulture),
				//    data.Currency,
				//    msisdnOrigin,
				//    data.Ip,
				//    isFirstTopup);

				//Airship Event
				await _airShipService.HandleTopupTagsAndEvents(
					 new TopupInfoAirship()
					 {
						 IsSuccess = true,
						 Origination = msisdnOrigin,
						 IsCard = true,
						 Msisdn = data.CustomerMsisdn,
						 Amount = paymentResponse.Payload.transactionAmount
					 });


				//Handle FaceBook Events
				await _faceBookService.HandleTopupEvents(data.advertiserID, true, true, Convert.ToDecimal(paymentResponse.Payload.transactionAmount), Currency, msisdnOrigin);
				//Handle AppsFlyer Events
				await _appsFlyerService.HandleTopupEvents(data.AppsFlyerId, deviceType, true, true, Convert.ToDecimal(paymentResponse.Payload.transactionAmount), Currency, msisdnOrigin);

				return GenericApiResponse<CardPaymentResponseModel>.Success(
					new CardPaymentResponseModel()
					{
						topupInfo = new TopupInfo()
						{
							TopupAmount = paymentResponse.Payload.transactionAmount,
							Msisdn = data.CustomerMsisdn,
							TransactionId = paymentResponse.Payload.transactionId,
							Currency = currencySymbol,
							NewBalance = userBalance.Balance
						},
						customerMsisdn = data.CustomerMsisdn,
						transactionId = paymentResponse.Payload.transactionId
					}, _localizer["TopUpSuccessful", paymentResponse.Payload.transactionAmount]);
			}
		}
		#endregion

		#region Paypal Payments Topup and Bundle
		public async Task<GenericApiResponse<PaypalPaymentResponseModel>> PaypalPaymentAsync(
							  PaypalPaymentRequestModel model, string msisdn, string currency, string ipAddress, string advertiserID)
		{
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));

			var bundleDest = "";
			string Currency = "";
			decimal bundlePrice = 0;
			decimal ChargeAmount = model.TopUpAmount;
			var msisdnOrigin = _helperService.GetCountryCode(msisdn);
			BundleType bundleType = BundleType.PAYG;

			DeviceType deviceType = (DeviceType)model.DeviceType;

			if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				//Check Bundle Limit
				var bundlesResponse = await _accountRepo.GetBundlesHistory(accountDetails.AccountID);
				if (bundlesResponse.Count() >= 10)
				{
					return GenericApiResponse<PaypalPaymentResponseModel>.Failure(
						_localizer["MaxNumberOfBundlesPurchased"], ApiStatusCodes.BundleLimitExceeded);
				}

				//Get Bundle details
				var bundleResponse = await _bundleRepo.GetBundleById(model.BundleId, accountDetails.AccountID);
				if (bundleResponse == null)
				{
					return GenericApiResponse<PaypalPaymentResponseModel>.Failure(
						_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
				}
				bundlePrice = Convert.ToDecimal(bundleResponse.TotalCostPence / 100, CultureInfo.InvariantCulture);
				if (bundleResponse.BundleType == BundleType.Monthly)
				{
					//Montly bundles cannot be purchased with paypal payment
					return GenericApiResponse<PaypalPaymentResponseModel>.Failure(
						_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
				}
				ChargeAmount = bundleResponse.TotalCostPence / 100;
				bundleDest = bundleResponse.Description.Replace(" ", "").Replace(",", "");
				bundleType = bundleResponse.BundleType;
				Currency = accountDetails.Currency;
			}

			var userInfo = await _accountRepo.GetUserProfile(msisdn);

			string name = msisdn;
			string emailAddress = "";

			if (userInfo.Status == Models.Enums.Status.Success)
			{
				if (userInfo.Data != null)
				{
					if (!string.IsNullOrEmpty(userInfo.Data.email))
						emailAddress = userInfo.Data.email.Trim();

					if (!string.IsNullOrEmpty(userInfo.Data.firstName))
					{
						name = $"{userInfo.Data.firstName} {userInfo.Data.lastName}";
					}
				}
			}

			//var httpRequest = _httpContext.HttpContext.Request;
			//string returnUrl = new Uri($"{httpRequest.Scheme}://{httpRequest.Host}/PaypalByPay360CallBack").AbsoluteUri;
			string returnUrl = _inAppPageConfig.BaseUrl + "/PaypalByPay360CallBack";
			string cancelUrl = _inAppPageConfig.BaseUrl + "/PaypalPaymentCancel?&culture=" + _localizer["Locale"] + "&ThemeMode=" + _httpContext.HttpContext.ThemeMode();
			var airshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();
			var userRegistrationDate = await _accountRepo.GetUserRegistrationDate(accountDetails.AccountID);
			var request = new PayPalByPay360CSPaymentRequest
			{
				CustomerName = name,
				CustomerEmail = emailAddress,
				CustomerMsisdn = msisdn,
				CustomerUniqueRef = msisdn,
				ProductCode = ProductCode.THA.ToString(),
				isDirectFullfilment = _pay360Config.IsDirectFullfilment,
				transactionCurrency = currency,
				PaymentMethod = new PayPalByPay360PaymentMethod()
				{
					Paypal = new PayPalByPay360Urls()
					{
						returnUrl = returnUrl
						+ "?CheckoutType=" + (int)model.CheckoutType
						+ "&BundleId=" + model.BundleId
						+ "&Msisdn=" + msisdn
						+ "&ThemeMode=" + _httpContext.HttpContext.ThemeMode()
						+ "&Email=" + emailAddress
						+ "&IpAddress=" + ipAddress
						+ "&advertiserID=" + advertiserID
						+ "&airshipEventsDisable=" + airshipEventsDisable
						+ "&culture=" + _localizer["Locale"],
						cancelUrl = cancelUrl
					}
				},
				ipAddress = ipAddress,
				Basket = new List<PayPalByPay360Basket>() {
					new PayPalByPay360Basket()
					{
						chargeAmount = ChargeAmount,
						discountAmount=0,
						bundleRef = model.CheckoutType == Models.Enums.CheckOutTypes.Bundle ? model.BundleId : "",
						productItemCode = ProductItemCode.THAATA.ToString(),
						productRef = msisdn
					}
				},
				transactionAmount = ChargeAmount,
				CustomFields = new PayPalByPay360CustomField()
				{
					fieldState = new List<PayPalByPay360FieldState>()
					{
						new PayPalByPay360FieldState() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
						new PayPalByPay360FieldState() { name = "ProductItemCode", value = ProductItemCode.THAATA.ToString(), transient = false },
						new PayPalByPay360FieldState() { name = "FirstUseDate", value = userRegistrationDate.ToString("yyyy-MM-dd"), transient = false }
					}
				},
				sendPay360Email = _pay360Config.sendPay360Email
			};
			if (model.AppsFlyerId != null)
			{
				request.PaymentMethod.Paypal.returnUrl +=
						  $"&AppsFlyerId={model.AppsFlyerId}" +
						  $"&DeviceType={model.DeviceType}";
			}
			if (model.UtmParamsInfo != null)
			{
				request.PaymentMethod.Paypal.returnUrl +=
						  $"&UtmCampaign={model.UtmParamsInfo.utm_campaign}"
						+ $"&UtmMedium={model.UtmParamsInfo.utm_medium}"
						+ $"&UtmSource={model.UtmParamsInfo.utm_source}";
			}

			//Save transaction
			var paymentTransactionId = await _paymentFullfillmentDL.InsertPaypalTransactionPaymentAsync(
				request.Basket,
				request.transactionCurrency,
				request.CustomerEmail,
				request.ProductCode,
				null,
				request.CustomerMsisdn,
				TransactionsPaymentType.Paypal,
				0,
				null, null);

			request.PaymentMethod.Paypal.returnUrl += $"&PTId={paymentTransactionId}";

			var paymentResponse = await _payPalByPay360Service.PayPalByPay360CS(request);

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = false,
							Msisdn = msisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});

					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, false, false, bundlePrice, Currency);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, false, bundlePrice, Currency);
				}
				else
				{
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							IsCard = false,
							Msisdn = msisdn,
							Amount = ""
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(advertiserID, false, false, 0, Currency, msisdnOrigin);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, false, false, 0, Currency, msisdnOrigin);
				}

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
					paymentTransactionId,
					false,
					null,
				 paymentResponse == null ? "Payment service not responding" : paymentResponse.Message);

				return HandlePay360PaymentFailureResponse
					<PayPalByPay360CSPaymentResponse, PaypalPaymentResponseModel>(paymentResponse, model.CheckoutType);
				;
			}

			await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, false, paymentResponse.Payload.transactionId);

			return GenericApiResponse<PaypalPaymentResponseModel>.Success(
				new PaypalPaymentResponseModel()
				{
					clientRedirectUrl = paymentResponse.Payload.clientRedirectUrl
				}, _localizer["PaymentCreatedSuccessfully"]);
		}


		public async Task<GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>> PaypalByPay360PaymentCallBackAsync(PaypalByPay360PaymentCallBackRequestModel model)
		{
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(
												_helperService.GetSipUserName(model.Msisdn));
			string bundleName = "";
			string bundleDest = "";
			string Currency = "";
			decimal bundlePrice = 0;
			var msisdnOrigin = _helperService.GetCountryCode(model.Msisdn);
			BundleType bundleType = BundleType.PAYG;
			bool isTrialBundle = false;

			DeviceType deviceType = (DeviceType)model.DeviceType;

			if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				var bundleInfo = await _bundleRepo.GetBundleById(model.BundleId, accountDetails.AccountID);
				bundleDest = bundleInfo.Description.Replace(" ", "").Replace(",", "");
				bundleType = bundleInfo.BundleType;
				Currency = accountDetails.Currency;
				bundleName = bundleInfo.BrandedName;
				bundlePrice = Convert.ToDecimal(bundleInfo.TotalCostPence / 100, CultureInfo.InvariantCulture);
				if (bundleInfo.IsTrial && bundleInfo.TrialId != null)
					isTrialBundle = bundleInfo.IsTrial;
			}

			var paymentResponse = await _payPalByPay360Service.PayPalByPay360ES(
				new PayPalByPay360ESPaymentRequest()
				{
					PaypalCheckoutToken = model.Token
				});

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = false,
							Msisdn = model.Msisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});

					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(model.advertiserID, msisdnOrigin, bundleDest, bundleType, false, false, bundlePrice, Currency);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, false, bundlePrice, Currency);
				}
				else
				{
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							IsCard = false,
							Msisdn = model.Msisdn,
							Amount = ""
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(model.advertiserID, false, false, 0, Currency, msisdnOrigin);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, false, false, 0, Currency, msisdnOrigin);
				}

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
										model.PTId,
										false,
										null,
										paymentResponse == null ? "Payment Service Not Responding" : (paymentResponse.ErrorCode + " - " + paymentResponse.Message));

				return HandlePay360PaymentFailureResponse<PayPalByPay360ESPaymentResponse,
								PaypalByPay360PaymentCallBackResponseModel>(paymentResponse, model.CheckoutType);
			}

			//Successfull payment
			await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(model.PTId, true);

			//Fulfillment
			await Pay360PaypalPaymentFullfillment(paymentResponse, model.Msisdn, model.Email, accountDetails.AccountID, decimal.Zero);

			var userBalance = await _accountRepo.GetUserAccountBalanceAsync(model.Msisdn);
			var currencySymbol = _helperService.ToCurrencySymbol(accountDetails.Currency);

			if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				//Airship events
				await _airShipService.HandleBundleTagsAndEvents(
					 new BundleInfoAirShip()
					 {
						 IsSuccess = true,
						 Origination = msisdnOrigin,
						 Destination = bundleDest,
						 IsCard = false,
						 Msisdn = model.Msisdn,
						 BundleType = bundleType,
						 Amount = bundlePrice
					 });

				await _faceBookService.HandleBundlePurchaseEvents(model.advertiserID, msisdnOrigin, bundleDest, bundleType, true, false, bundlePrice, Currency);

				await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, true, false, bundlePrice, Currency);

				return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Success(
					new PaypalByPay360PaymentCallBackResponseModel()
					{
						bundlePurchaseInfo = new BundlePurchaseInfo()
						{
							TransactionId = paymentResponse.Payload.transactionId,
							BundleAmount = isTrialBundle ? "0" : paymentResponse.Payload.transactionAmount,
							BundleName = bundleName,
							Currency = currencySymbol,
							Msisdn = model.Msisdn,
							Destination = bundleDest,
							Type = bundleType
						}

					}, _localizer["BundlePurchasedSuccessfully"]);
			}
			else
			{
				//var isFirstTopup = await _accountRepo.IsFirstTopUp(model.Msisdn);

				//AppsFlyer events
				//await _appsFlyerService.HandleTopupEvents(
				//    new AppsFlyerInfo(model.AppsFlyerId, model.DeviceType),
				//     decimal.Parse(paymentResponse.Payload.transactionAmount,CultureInfo.InvariantCulture),
				//     accountDetails.Currency,
				//     msisdnOrigin,
				//     model.IpAddress,
				//     isFirstTopup);

				//Airship events
				await _airShipService.HandleTopupTagsAndEvents(
				   new TopupInfoAirship()
				   {
					   IsSuccess = true,
					   Origination = msisdnOrigin,
					   IsCard = false,
					   Msisdn = model.Msisdn,
					   Amount = paymentResponse.Payload.transactionAmount
				   });


				//Handle FaceBook Events
				await _faceBookService.HandleTopupEvents(model.advertiserID, true, false, Convert.ToDecimal(paymentResponse.Payload.transactionAmount), Currency, msisdnOrigin);
				//Handle AppsFlyer Events
				await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, true, false, Convert.ToDecimal(paymentResponse.Payload.transactionAmount), Currency, msisdnOrigin);

				return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Success(
					new PaypalByPay360PaymentCallBackResponseModel()
					{
						topupInfo = new TopupInfo()
						{
							TopupAmount = paymentResponse.Payload.transactionAmount,
							Msisdn = model.Msisdn,
							TransactionId = paymentResponse.Payload.transactionId,
							Currency = currencySymbol,
							NewBalance = userBalance.Balance
						}
					}, _localizer["TopUpSuccessful", paymentResponse.Payload.transactionAmount]);
			}
		}
		#endregion

		#region Card Payments Transfer Balance
		public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByNewCardAsync(
							  TransferByNewCustomerRequestModel model, string currency, string ipAddress, string msisdn, string emailAddress, string advertiserID)
		{
			var product = await _attRepo.GetProductByNowtelTransactionReference(model.nowtelRef, model.product);
			if (product == null || !float.TryParse(product.CustomerChargeValue, out var productPrice) || productPrice <= 0)
			{
				_logger.Warning($"Class=>Payment_BL, Method=> TransferByNewCardAsync, Message=>No product available for destination, NowTelRef=>{model.nowtelRef},Product=>{model.product}");
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
				   _localizer["NoProductAvailableForDestination"],
				   ApiStatusCodes.BadRequest);
			}

			var msisdnOrigin = _helperService.GetCountryCode(product.fromMsisdn);
			var msisdnDest = _helperService.GetCountryCode(product.tomsisdn);

			DeviceType deviceType = (DeviceType)model.DeviceType;

			var custValidate = await _attRepo.ValidateNowtelCustomerNew(
				  msisdn,
				  model.nowtelRef,
				  model.product,
				  Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture));

			if (custValidate.isAllowed != 1)
			{
				_logger.Error($"Class=>Payment_BL, Method=> TransferByNewCardAsync, Message=>Balance transfer failed, FromMsisdn=>{msisdn}, NowTelRef=>{model.nowtelRef},Product=>{model.product},Amount=>{product.CustomerChargeValue}");
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
							_localizer["BalanceTransferFailed"], ApiStatusCodes.BadRequest);
			}

			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));

			if (string.IsNullOrEmpty(emailAddress))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						emailAddress = userInfo.Data.email.Trim();
				}
			}
			var custChargeValue = decimal.Parse(product.CustomerChargeValue, CultureInfo.InvariantCulture);
			var paymentResponse = await _pay360Service.Pay360Payment(
				await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
				{
					CustomerUniqueRef = msisdn,
					CustomerMsisdn = msisdn,
					ChargeAmount = custChargeValue,
					DiscountAmount = 0,
					IpAddress = ipAddress,
					Currency = currency,
					toMsisdn = product.tomsisdn,
					CustomerEmail = emailAddress,
					Pay360PaymentType = Pay360PaymentType.New,
					CustomerAddressData = new AddressData()
					{
						AddressL1 = model.billingAddressData.AddressL1,
						AddressL2 = model.billingAddressData.AddressL2,
						AddressL3 = model.billingAddressData.AddressL3,
						AddressL4 = model.billingAddressData.AddressL4,
						PostCode = model.billingAddressData.PostCode,
						City = model.billingAddressData.City,
						Region = model.billingAddressData.Region,
						CountryCode = model.billingAddressData.CountryCode
					},
					CustomerCardData = new CardData()
					{
						CardNumber = model.cardData.CardNumber,
						NameOnCard = model.cardData.NameOnCard,
						SecurityCode = model.cardData.SecurityCode,
						ExpiryDate = model.cardData.ExpiryDate
					},
					ShouldSaveCard = model.cardData.ShouldSaveCard,
					IsDefaultCard = model.cardData.IsDefaultCard,
					accountNumber = accountDetails.AccountID,
					CheckoutPaymentType = Models.Enums.CheckOutTypes.Transfer
				}),
				Pay360PaymentType.New);

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
					new IntTopupInfoAirShip()
					{
						IsTransferRequest = model.IsTransferRequest,
						IsSuccess = false,
						Origination = msisdnOrigin,
						Destination = msisdnDest,
						IsCard = true,
						Msisdn = msisdn,
						Amount = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture),
					});


				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(advertiserID, msisdnOrigin, msisdnDest, false, true, Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture), model.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnOrigin, msisdnDest, false, true, Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture), ipAddress = null, model.IsTransferRequest);

				//Save transaction
				var custCharge = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture);
				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = accountDetails.AccountID,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = custCharge,
						TotalPrice = custCharge,
						Discount = 0,
						DiscountCode = null,
						DiscountCodeType = null,
						NowtelRef = model.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = paymentResponse == null
									? "Payment service not responding" : paymentResponse.Message,
						TransferErrorMsg = null,
						PaymentRef = null,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Card,
						StatusId = TransferTransactionStatus.Failure,
						Product = Convert.ToDecimal(model.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency
					});

				return HandlePay360PaymentFailureResponse<Pay360PaymentResponse, TransferByCardResponseModel>(paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}

			return await HandleTransferByCardResponse(
							paymentResponse.Payload,
							model,
							float.Parse(product.CustomerChargeValue, CultureInfo.InvariantCulture),
							product.fromMsisdn,
							product.tomsisdn,
							currency,
							accountDetails.AccountID,
							ipAddress,
							emailAddress,
							advertiserID,
							model.AppsFlyerId,
							deviceType,
							model.IsTransferRequest);
		}

		public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByExistingCardAsync(
							  TransferByExistingCustomerRequestModel model, string currency, string ipAddress, string msisdn, string emailAddress, string advertiserID)
		{
			var product = await _attRepo.GetProductByNowtelTransactionReference(model.nowtelRef, model.product);
			if (product == null || !float.TryParse(product.CustomerChargeValue, out var productPrice) || productPrice <= 0)
			{
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
				   _localizer["NoProductAvailableForDestination"],
				   ApiStatusCodes.BadRequest);
			}


			var msisdnOrigin = _helperService.GetCountryCode(product.fromMsisdn);
			var msisdnDest = _helperService.GetCountryCode(product.tomsisdn);

			DeviceType deviceType = (DeviceType)model.DeviceType;

			var custValidate = await _attRepo.ValidateNowtelCustomerNew(
				  msisdn,
				  model.nowtelRef,
				  model.product,
				  Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture));
			if (custValidate.isAllowed != 1)
			{
				_logger.Information($"Class=>Payment_BL, Method=>TransferByExistingCardAsync, Message=>Unable to validate nowtel customer, FromMsisdn=>{msisdn},NowtelRef=>{model.nowtelRef}, Product=>{model.product}, Amount=>{product.CustomerChargeValue}");
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
							_localizer["BalanceTransferFailed"], ApiStatusCodes.BadRequest);
			}

			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));

			if (string.IsNullOrEmpty(emailAddress))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						emailAddress = userInfo.Data.email.Trim();
				}
			}
			var custChargeValue = decimal.Parse(product.CustomerChargeValue, CultureInfo.InvariantCulture);
			var paymentResponse = await _pay360Service.Pay360Payment(
				await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
				{
					CustomerMsisdn = msisdn,
					ChargeAmount = custChargeValue,
					DiscountAmount = 0,
					IpAddress = ipAddress,
					Currency = currency,
					toMsisdn = product.tomsisdn,
					Pay360PaymentType = Pay360PaymentType.Token,
					CardToken = model.CardToken,
					SecurityCode = model.SecurityCode,
					accountNumber = accountDetails.AccountID,
					CustomerEmail = emailAddress,
					CustomerUniqueRef = msisdn,
					CheckoutPaymentType = Models.Enums.CheckOutTypes.Transfer
				}), Pay360PaymentType.Token);

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
					new IntTopupInfoAirShip()
					{
						IsSuccess = false,
						Origination = msisdnOrigin,
						Destination = msisdnDest,
						IsCard = true,
						Msisdn = msisdn,
						Amount = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture),
						IsTransferRequest = model.IsTransferRequest
					});


				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(advertiserID, msisdnOrigin, msisdnDest, false, true, Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture), model.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnOrigin, msisdnDest, false, true, Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture), null, model.IsTransferRequest);

				//Save transaction
				var custCharge = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture);
				await _attRepo.SaveTransactionAsync(new DBTransferTransaction()
				{
					AccountId = accountDetails.AccountID,
					ClientCurrecny = product.fromCurrency,
					CountryCode = _helperService.GetCountryCode(product.tomsisdn),
					FromMsisdn = product.fromMsisdn,
					ToMsisdn = product.tomsisdn,
					ItemPrice = custCharge,
					TotalPrice = custCharge,
					Discount = 0,
					DiscountCode = null,
					DiscountCodeType = null,
					NowtelRef = model.nowtelRef,
					OperatorCountryName = product.operatorCountryName,
					OperatorLogoUrl = product.operatorLogoUrl,
					OperatorName = product.operatorName,
					PaymentErrorMsg = paymentResponse == null
										? "Payment service not responding" : paymentResponse.Message,
					TransferErrorMsg = null,
					PaymentRef = null,
					TransferRef = null,
					PaymentTypeId = InternationalTopupPaymentType.Card,
					StatusId = TransferTransactionStatus.Failure,
					Product = Convert.ToDecimal(model.product, CultureInfo.InvariantCulture),
					ReceiverCurrecny = product.toCurrency
				});

				return HandlePay360PaymentFailureResponse<Pay360PaymentResponse, TransferByCardResponseModel>
																			(paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}
			if (model.IsDefaultCard)
			{
				await _pay360Service.SetDefaultCard(msisdn, new SetDefaultCardUserRequest
				{
					CardToken = model.CardToken,
					CV2 = model.SecurityCode
				});
			}
			return await HandleTransferByCardResponse(
				paymentResponse.Payload,
				model,
				float.Parse(product.CustomerChargeValue, CultureInfo.InvariantCulture),
				product.fromMsisdn,
				product.tomsisdn,
				currency,
				accountDetails.AccountID,
				ipAddress,
				emailAddress,
				advertiserID,
				model.AppsFlyerId,
				deviceType,
				model.IsTransferRequest);
		}


		public async Task<GenericApiResponse<InternationalTopupInfo>> TransferByCardResume3DTransactionCallbackAsync(TransferByPay360Resume3DData data, Resume3DPaymentRequest request)
		{
			GenericPay360ApiResponse<Pay360PaymentResponse> paymentResponse;
			if (data.threeDsV.Equals("V2", StringComparison.InvariantCultureIgnoreCase))
			{
				//3ds v2
				paymentResponse = await _pay360Service.Resume3DV2Transaction(
					new Pay360Resume3DRequest()
					{
						pay360TransactionId = request.MD,
						customerEmail = data.customerEmail,
					});
			}
			else
			{
				//3ds v1
				paymentResponse = await _pay360Service.Resume3DV1Transaction(
					new Pay360Resume3DRequest()
					{
						pay360TransactionId = request.MD,
						customerEmail = data.customerEmail,
						pareq = request.PaRes,
					});
			}


			// Cannot resume again scenario 
			if (paymentResponse != null
				&& paymentResponse.ErrorCode > 0
				&& (paymentResponse.Pay360ApiCode.Equals("V107")))
			{
				return HandlePay360PaymentFailureResponse
					<Pay360PaymentResponse, InternationalTopupInfo>(paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}

			//Get Product Details for international topup
			var product = await _attRepo.GetProductByNowtelTransactionReference(data.nowtelRef, data.product);
			var custCharge = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture);


			var msisdnOrigin = _helperService.GetCountryCode(product.fromMsisdn);
			var msisdnDest = _helperService.GetCountryCode(product.tomsisdn);

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
				   new IntTopupInfoAirShip()
				   {
					   IsSuccess = false,
					   Origination = msisdnOrigin,
					   Destination = msisdnDest,
					   IsCard = true,
					   Msisdn = data.msisdn,
					   Amount = custCharge,
					   IsTransferRequest = data.IsTransferRequest
				   });


				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(data.advertiserID, msisdnOrigin, msisdnDest, false, true, custCharge, data.IsTransferRequest);
				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(data.AppsFlyerId, data.DeviceType, msisdnOrigin, msisdnDest, false, true, custCharge, null, data.IsTransferRequest);

				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = data.account,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = custCharge,
						TotalPrice = custCharge,
						Discount = 0,
						DiscountCode = null,
						DiscountCodeType = null,
						NowtelRef = data.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = paymentResponse == null
										? "Payment service not responding" : paymentResponse.Message,
						TransferErrorMsg = null,
						PaymentRef = null,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Card,
						StatusId = TransferTransactionStatus.Failure,
						Product = Convert.ToDecimal(data.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency
					});

				return HandlePay360PaymentFailureResponse
						<Pay360PaymentResponse, InternationalTopupInfo>(paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}

			//Payment is success, Now Transfer balance
			var executeTransResponse = await _attService.TransferBalance(
				new TransFerTotransferConfirm()
				{
					nowtelTransactionReference = data.nowtelRef,
					product = data.product,
					operatorid = int.Parse(data.operatorId),
					messageToRecipient = "",
				}, data.msisdn);

			if (executeTransResponse == null || executeTransResponse.errorCode > 0)
			{
				//cancel catpured payment
				if (_pay360Config.TransferIsAuthorization)
				{
					await _pay360Service.CancelTransaction(
						new CancelTransactionRequestModel()
						{
							transactionId = paymentResponse.Payload.transactionId
						});
				}

				await _airShipService.HandleIntTopupTagsAndEvents(
				   new IntTopupInfoAirShip()
				   {
					   IsSuccess = false,
					   Origination = msisdnOrigin,
					   Destination = msisdnDest,
					   IsCard = true,
					   Msisdn = data.msisdn,
					   Amount = custCharge,
					   IsTransferRequest = data.IsTransferRequest
				   });


				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(data.advertiserID, msisdnOrigin, msisdnDest, false, true, custCharge, data.IsTransferRequest);
				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(data.AppsFlyerId, data.DeviceType, msisdnOrigin, msisdnDest, false, true, custCharge, null, data.IsTransferRequest);

				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = data.account,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = custCharge,
						TotalPrice = custCharge,
						Discount = 0,
						DiscountCode = null,
						DiscountCodeType = null,
						NowtelRef = data.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = null,
						TransferErrorMsg = executeTransResponse == null
											? "Transfer service not responding" : executeTransResponse?.message,
						PaymentRef = paymentResponse.Payload.transactionId,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Card,
						StatusId = TransferTransactionStatus.Failure,
						Product = Convert.ToDecimal(data.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency
					});

				_logger.Information($"Class=>Payment_BL, Method=>TransferByCardResume3DTransactionCallbackAsync, Message=>Unable to transfer balance, FromMsisdn=>{data.msisdn},NowtelRef=>{data.nowtelRef},Operator=>{data.operatorId}, Product=>{data.product}, Amount=>{custCharge}");
				return GenericApiResponse<InternationalTopupInfo>.Failure(null,
							  _localizer["PaymentServiceNotResponding"], ApiStatusCodes.InternalServerError);
			}
			//capture payment
			if (_pay360Config.TransferIsAuthorization)
			{
				string captureFailedMessage = $"Payment capture failed==> Payment TransactionId:{paymentResponse.Payload.transactionId} " +
											  $"Transfer TransactionId:{executeTransResponse.reference}";
				try
				{
					var captureResponse = await _pay360Service.CaptureTransaction(
						new CaptureTransactionRequestModel()
						{
							transactionId = paymentResponse.Payload.transactionId
						});
					if (captureResponse == null || captureResponse.ErrorCode > 0)
					{
						await _emailService.SendEmail(
							_pay360Config.PaymentCaptureFailureEmail,
							captureFailedMessage,
							false,
							"Capture Failed-THA-App-" + paymentResponse.Payload.transactionId);
						_logger.Information($"Class=>Payment_BL, Method=>TransferByCardResume3DTransactionCallbackAsync, Message=>Capture transaction failed, FromMsisdn=>{data.msisdn},NowtelRef=>{data.nowtelRef},Operator=>{data.operatorId}, Product=>{data.product}, Amount=>{custCharge},ErrorMessage=>{captureFailedMessage}");
					}
				}
				catch (Exception ex)
				{
					await _emailService.SendEmail(
						_pay360Config.PaymentCaptureFailureEmail,
						captureFailedMessage + "-" + ex.Message,
						false,
						"Capture Failed-THA-App-" + paymentResponse.Payload.transactionId);
					_logger.Error(ex, $"Class=>Payment_BL, Method=>TransferByCardResume3DTransactionCallbackAsync, Message=>Capture transaction failed, FromMsisdn=>{data.msisdn},NowtelRef=>{data.nowtelRef},Operator=>{data.operatorId}, Product=>{data.product}, Amount=>{custCharge},ErrorMessage=>{captureFailedMessage}");
				}
			}

			var userBalance = await _accountRepo.GetUserAccountBalanceAsync(data.msisdn);

			//AppsFlyer events
			//await _appsFlyerService.HandleTopupEvents(
			//    new AppsFlyerInfo(data.AppsFlyerId, data.DeviceType), 
			//    decimal.Parse(paymentResponse.Payload.transactionAmount,CultureInfo.InvariantCulture), 
			//    data.currency,
			//    msisdnOrigin, 
			//    data.IpAddress, 
			//    isFirstTopup);

			//Airship events
			await _airShipService.HandleIntTopupTagsAndEvents(
					new IntTopupInfoAirShip()
					{
						IsSuccess = true,
						IsCard = true,
						Msisdn = data.msisdn,
						Destination = msisdnDest,
						Origination = msisdnOrigin,
						Amount = custCharge,
						IsTransferRequest = data.IsTransferRequest,
					});


			// Handle FaceBook Events
			await _faceBookService.HandleIntTopupEvents(data.advertiserID, msisdnOrigin, msisdnDest, true, true, custCharge, data.IsTransferRequest);
			// Handle AppsFlyer Events
			await _appsFlyerService.HandleIntTopupEvents(data.AppsFlyerId, data.DeviceType, msisdnOrigin, msisdnDest, true, true, custCharge, null, data.IsTransferRequest);

			//Save transaction with success
			await _attRepo.SaveTransactionAsync(
				new DBTransferTransaction()
				{
					AccountId = data.account,
					ClientCurrecny = product.fromCurrency,
					CountryCode = _helperService.GetCountryCode(product.tomsisdn),
					FromMsisdn = product.fromMsisdn,
					ToMsisdn = product.tomsisdn,
					ItemPrice = custCharge,
					TotalPrice = custCharge,
					Discount = 0,
					DiscountCode = null,
					DiscountCodeType = null,
					NowtelRef = data.nowtelRef,
					OperatorCountryName = product.operatorCountryName,
					OperatorLogoUrl = product.operatorLogoUrl,
					OperatorName = product.operatorName,
					PaymentErrorMsg = null,
					TransferErrorMsg = null,
					PaymentRef = paymentResponse.Payload.transactionId,
					TransferRef = executeTransResponse.reference,
					PaymentTypeId = InternationalTopupPaymentType.Card,
					StatusId = TransferTransactionStatus.Success,
					Product = Convert.ToDecimal(data.product, CultureInfo.InvariantCulture),
					ReceiverCurrecny = product.toCurrency
				});

			var userProfile = await _accountRepo.GetUserProfile(product.fromMsisdn);
			if (!string.IsNullOrEmpty(userProfile?.Data?.email))
			{
				await SendInternationalTopupPaymentReceiptAsync(userProfile.Data.email, product, userProfile.Data, "Card", decimal.Zero, decimal.Zero, string.Empty, 0, executeTransResponse.reference, executeTransResponse.pinCode);
			}
			return GenericApiResponse<InternationalTopupInfo>.Success(
			new InternationalTopupInfo()
			{
				TopupAmount = paymentResponse.Payload.transactionAmount,
				Msisdn = data.msisdn,
				TransactionId = paymentResponse.Payload.transactionId,
				Currency = _helperService.ToCurrencySymbol(userBalance.Currency),
				NewBalance = userBalance.Balance,
				FromAmount = Convert.ToDecimal(product.fromAmount, CultureInfo.InvariantCulture)
			}, _localizer["InternationalTopupSuccessfull"]);
		}

		private async Task<GenericApiResponse<TransferByCardResponseModel>> HandleTransferByCardResponse(
			Pay360PaymentResponse model,
			dynamic request,
			float amountToCharge,
			string fromMsisdn,
			string toMsisdn,
			string currency,
			string accountId,
			string ipAddress,
			string email,
			string advertiserID,
			string AppsFlyerId,
			DeviceType DeviceType,
			bool IsTransferRequest)
		{
			if (request is TransferByNewCustomerRequestModel)
			{
				request = request as TransferByNewCustomerRequestModel;
			}
			if (request is TransferByExistingCustomerRequestModel)
			{
				request = request as TransferByExistingCustomerRequestModel;
			}

			if (model.outcome.reasonCode == "U100") //3d Secure Scenario
			{
				var threeDsV = model.clientRedirect.type.Contains(
						"V2", StringComparison.InvariantCultureIgnoreCase) ? "V2" : "V1";
				var airshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();
				//Send Response
				string returnUrl = _inAppPageConfig.BaseUrl + "/transfer/Resume3DTransaction" +
							 "?NowtelRef=" + request.nowtelRef +
							 "&Product=" + request.product +
							 "&OperatorId=" + request.operatorId +
							 "&CustomerEmail=" + email +
							 "&ThreeDsV=" + threeDsV +
							 "&Msisdn=" + fromMsisdn +
							 "&Account=" + accountId +
							 "&IpAddress=" + ipAddress +
							 "&advertiserID=" + advertiserID +
							 "&AirshipEventsDisable=" + airshipEventsDisable +
							 "&IsTransferRequest=" + IsTransferRequest +
							 "&culture=" + _localizer["Locale"];

				if (AppsFlyerId != null)
				{
					returnUrl += $"&AppsFlyerId={AppsFlyerId}" +
								 $"&DeviceType={DeviceType}";
				}
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
												new TransferByCardResponseModel()
												{
													threeDSecureData = new ThreeDSecureData()
													{
														pareq = model.clientRedirect.pareq,
														type = model.clientRedirect.type,
														redirectUrl = model.clientRedirect.url,
														threeDSServerTransId = model.clientRedirect.threeDSServerTransId,
														transactionId = model.transactionId,
														returnUrl = returnUrl
													}
												}, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

			}
			else if (model.outcome.reasonCode == "S100")//Non 3d secure
			{
				//Get Product Details for international topup
				var product = await _attRepo.GetProductByNowtelTransactionReference(request.nowtelRef, request.product);
				var custCharge = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture);

				//Transfer balance
				var executeTransResponse = await _attService.TransferBalance(
					new TransFerTotransferConfirm()
					{
						nowtelTransactionReference = request.nowtelRef,
						product = request.product,
						operatorid = request.operatorId,
						messageToRecipient = ""
					}, fromMsisdn);

				if (executeTransResponse == null || executeTransResponse.errorCode > 0)
				{
					//Save ATT transaction
					await _attRepo.SaveTransactionAsync(
						new DBTransferTransaction()
						{
							AccountId = accountId,
							ClientCurrecny = product.fromCurrency,
							CountryCode = _helperService.GetCountryCode(product.tomsisdn),
							FromMsisdn = product.fromMsisdn,
							ToMsisdn = product.tomsisdn,
							ItemPrice = custCharge,
							TotalPrice = custCharge,
							Discount = 0,
							DiscountCode = null,
							DiscountCodeType = null,
							NowtelRef = request.nowtelRef,
							OperatorCountryName = product.operatorCountryName,
							OperatorLogoUrl = product.operatorLogoUrl,
							OperatorName = product.operatorName,
							PaymentErrorMsg = null,
							TransferErrorMsg = executeTransResponse == null
												? "Transfer service not responding" : executeTransResponse?.message,
							PaymentRef = model.transactionId,
							TransferRef = null,
							PaymentTypeId = InternationalTopupPaymentType.Card,
							StatusId = TransferTransactionStatus.Failure,
							Product = Convert.ToDecimal(request.product, CultureInfo.InvariantCulture),
							ReceiverCurrecny = product.toCurrency
						});

					//cancel catpured payment
					if (_pay360Config.TransferIsAuthorization)
					{
						await _pay360Service.CancelTransaction(
							new CancelTransactionRequestModel()
							{
								transactionId = model.transactionId
							});
					}
					_logger.Warning($"Class=>Payment_BL, Method=> HandleTransferByCardResponse, Message=>Balance transfer failed, FromMsisdn=>{fromMsisdn}, NowTelRef=>{request.nowtelRef},Product=>{request.product},Amount=>{product.CustomerChargeValue}");
					return GenericApiResponse<TransferByCardResponseModel>.Failure(
								null, _localizer["BalanceTransferFailed"], ApiStatusCodes.UnSuccessful);
				}

				//capture payment
				if (_pay360Config.TransferIsAuthorization)
				{
					string captureFailedMessage = $"Payment capture failed==> Payment TransactionId:{model.transactionId} " +
												  $"Transfer TransactionId:{executeTransResponse.reference}";
					try
					{
						var captureResponse = await _pay360Service.CaptureTransaction(
							new CaptureTransactionRequestModel()
							{
								transactionId = model.transactionId
							});
						if (captureResponse == null || captureResponse.ErrorCode > 0)
						{
							await _emailService.SendEmail(
								_pay360Config.PaymentCaptureFailureEmail,
								captureFailedMessage,
								false,
								"Capture Failed-THA-App-" + model.transactionId);
							_logger.Error($"Class=>Payment_BL, Method=> HandleTransferByCardResponse,Message=>Capture transaction failed, {captureFailedMessage}");
						}
					}
					catch (Exception ex)
					{
						await _emailService.SendEmail(
							_pay360Config.PaymentCaptureFailureEmail,
							captureFailedMessage + "-" + ex.Message,
							false,
							"Capture Failed-THA-App-" + model.transactionId);
						_logger.Error(ex, $"Class=>Payment_BL, Method=> HandleTransferByCardResponse,Message=>Capture transaction failed, {captureFailedMessage}");
					}
				}

				var fromMsisdnCode = _helperService.GetCountryCode(fromMsisdn);
				var toMsisdnCode = _helperService.GetCountryCode(toMsisdn);

				//AppsFlyer events
				//await _appsFlyerService.HandleTopupEvents(request.AppsFlyerInfo, (decimal)amountToCharge, currency, fromMsisdnCode, ipAddress, isFirstTopup);

				//Airship events
				await _airShipService.HandleIntTopupTagsAndEvents(
					 new IntTopupInfoAirShip()
					 {
						 IsSuccess = true,
						 IsCard = true,
						 Msisdn = fromMsisdn,
						 Destination = toMsisdnCode,
						 Origination = fromMsisdnCode,
						 Amount = custCharge,
						 IsTransferRequest = IsTransferRequest
					 });

				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(advertiserID, fromMsisdnCode, toMsisdnCode, true, true, custCharge, IsTransferRequest);
				// Handle FaceBook Events
				await _appsFlyerService.HandleIntTopupEvents(AppsFlyerId, DeviceType, fromMsisdnCode, toMsisdnCode, true, true, custCharge, null, IsTransferRequest);

				//Save ATT transaction
				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = accountId,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = custCharge,
						TotalPrice = custCharge,
						Discount = 0,
						DiscountCode = null,
						DiscountCodeType = null,
						NowtelRef = request.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = null,
						TransferErrorMsg = null,
						PaymentRef = model.transactionId,
						TransferRef = executeTransResponse.reference,
						PaymentTypeId = InternationalTopupPaymentType.Card,
						StatusId = TransferTransactionStatus.Success,
						Product = Convert.ToDecimal(request.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency
					});

				return GenericApiResponse<TransferByCardResponseModel>.Success(
					new TransferByCardResponseModel()
					{
						intTopupInfo = new InternationalTopupInfo()
						{
							TopupAmount = amountToCharge.ToString(CultureInfo.InvariantCulture),
							Msisdn = fromMsisdn,
							TransactionId = model.transactionId,
							Currency = _helperService.ToCurrencySymbol(currency),
							FromAmount = Convert.ToDecimal(product.fromAmount, CultureInfo.InvariantCulture)
						},
						transferData = new TransferData
						{
							toMsisdn = product.tomsisdn,
						}
					}, _localizer["InternationalTopupSuccessfull"]);
			}
			else
			{
				////Save transaction
				//await _attRepo.SaveATTTransactionAsync(
				//    accountId,
				//    request.nowtelRef,
				//    request.product,
				//    model.transactionId,
				//    null,
				//    TransferTransactionStatus.Failure,
				//    InternationalTopupPaymentType.Card,
				//    "Payment service error - " + model.outcome.reasonCode);

				return GenericApiResponse<TransferByCardResponseModel>.Failure(
					null, _localizer["BalanceTransferFailed"], ApiStatusCodes.PaymentServiceError);
			}
		}
		#endregion

		#region Paypal Payments Transfer Credit
		public async Task<GenericApiResponse<TransferByPayPalResponseModel>> TransferByPayPalAsync(
							  TransferByPayPalRequestModel model, string currency, string ipAddress, string msisdn, string advertiserID)
		{
			var product = await _attRepo.GetProductByNowtelTransactionReference(model.nowtelRef, model.product);
			if (product == null || !decimal.TryParse(product.CustomerChargeValue, out var chargedAmount) || chargedAmount <= 0)
			{
				_logger.Information($"Class=>Payment_BL, Method=>TransferByPayPalAsync, Message=> No product available for this destination, FromMsisdn=>{msisdn},Product=>{model.product}, NowTelRef=>{model.nowtelRef}");
				return GenericApiResponse<TransferByPayPalResponseModel>.Failure(
											_localizer["NoProductAvailableForDestination"], ApiStatusCodes.BadRequest);
			}

			string msisdndestination = _helperService.GetCountryCode(product.tomsisdn);
			string msisdnorigination = _helperService.GetCountryCode(product.fromMsisdn);

			DeviceType deviceType = (DeviceType)model.DeviceType;

			var custValidate = await _attRepo.ValidateNowtelCustomerNew(
				msisdn,
				model.nowtelRef,
				model.product,
				Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture));
			if (custValidate.isAllowed != 1)
			{
				_logger.Information($"Class=>Payment_BL, Method=>TransferByPayPalAsync, Message=> Unable to validate nowtel customer, FromMsisdn=>{msisdn},Product=>{model.product}, NowTelRef=>{model.nowtelRef}");
				return GenericApiResponse<TransferByPayPalResponseModel>.Failure(
							_localizer["BalanceTransferFailed"], ApiStatusCodes.BadRequest);
			}

			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));
			var origination = _helperService.GetCountryCode(msisdn);
			string emailAddress = "";
			decimal ChargeAmount = decimal.Parse(product.CustomerChargeValue, CultureInfo.InvariantCulture);

			var userInfo = await _accountRepo.GetUserProfile(msisdn);

			if (userInfo.Status == Models.Enums.Status.Success)
			{
				if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
					emailAddress = userInfo.Data.email.Trim();
			}

			//Get User Registration Date
			var userRegistrationDate = await _accountRepo.GetUserRegistrationDate(accountDetails.AccountID);

			string returnUrl = _inAppPageConfig.BaseUrl + "/transfer/TransferByPaypalReturnV2";
			string cancelUrl = _inAppPageConfig.BaseUrl + "/transfer/TransferByPaypalCancelV2?&culture=" + _localizer["Locale"] + "&ThemeMode=" + _httpContext.HttpContext.ThemeMode();
			var airshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();
			var request = new PayPalByPay360CSPaymentRequest()
			{
				Basket = new List<PayPalByPay360Basket>() {
							new PayPalByPay360Basket()
							{
								chargeAmount = ChargeAmount,
								bundleRef = "",
								productItemCode = ProductItemCode.THADTA.ToString(),
								productRef = ""
							}
						},
				ipAddress = ipAddress,
				CustomerName = userInfo != null ? !string.IsNullOrEmpty(userInfo.Data.firstName) ? userInfo.Data.firstName : msisdn : msisdn,
				CustomerMsisdn = msisdn,
				CustomerEmail = emailAddress,
				transactionCurrency = currency,
				transactionAmount = ChargeAmount,
				PaymentMethod = new PayPalByPay360PaymentMethod()
				{
					Paypal = new PayPalByPay360Urls()
					{
						returnUrl = returnUrl +
									"?nowtelRef=" + model.nowtelRef +
									"&product=" + model.product +
									"&operatorId=" + model.operatorId +
									"&msisdn=" + msisdn +
									"&ThemeMode=" + _httpContext.HttpContext.ThemeMode() +
									"&IpAddress=" + ipAddress +
									"&advertiserID=" + advertiserID +
									"&AirshipEventsDisable=" + airshipEventsDisable +
									"&IsTransferRequest=" + model.IsTransferRequest +
									"&culture=" + _localizer["Locale"],
						cancelUrl = cancelUrl
					}
				},
				CustomFields = new PayPalByPay360CustomField()
				{
					fieldState = new List<PayPalByPay360FieldState>()
							{
								new PayPalByPay360FieldState() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
								new PayPalByPay360FieldState() { name = "ProductItemCode", value = ProductItemCode.THADTA.ToString(), transient = false },
								new PayPalByPay360FieldState() { name = "FirstUseDate",value = userRegistrationDate.ToString("yyyy-MM-dd"), transient = false },
								new PayPalByPay360FieldState() { name = "ANumber",value = product.fromMsisdn, transient = false },
								new PayPalByPay360FieldState() { name = "BNumber",value = product.tomsisdn, transient = false }
							}
				},
				CustomerUniqueRef = msisdn,
				ProductCode = ProductCode.THA.ToString(),
				isDirectFullfilment = false,
				sendPay360Email = _pay360Config.sendPay360Email
			};
			if (model.AppsFlyerId != null)
			{
				request.PaymentMethod.Paypal.returnUrl +=
									$"&AppsFlyerId={model.AppsFlyerId}" +
									$"&DeviceType={model.DeviceType}";
			}
			var paymentResponse = await _payPalByPay360Service.PayPalByPay360CS(request);
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
					new IntTopupInfoAirShip()
					{
						IsSuccess = false,
						Origination = msisdnorigination,
						Destination = msisdndestination,
						IsCard = false,
						Msisdn = msisdn,
						Amount = Convert.ToDecimal(ChargeAmount),
						IsTransferRequest = model.IsTransferRequest
					});

				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(advertiserID, msisdnorigination, msisdndestination, false, false, Convert.ToDecimal(ChargeAmount), model.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnorigination, msisdndestination, false, false, Convert.ToDecimal(ChargeAmount), null, model.IsTransferRequest);

				//Save transaction
				var custCharge = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture);
				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = accountDetails.AccountID,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = custCharge,
						TotalPrice = custCharge,
						Discount = 0,
						DiscountCode = null,
						DiscountCodeType = null,
						NowtelRef = model.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = paymentResponse == null ? "Payment service not responding" : paymentResponse.Message,
						TransferErrorMsg = null,
						PaymentRef = null,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Paypal,
						Product = Convert.ToDecimal(model.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency,
						StatusId = TransferTransactionStatus.Failure
					});

				return HandlePay360PaymentFailureResponse<PayPalByPay360CSPaymentResponse, TransferByPayPalResponseModel>(
							 paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}

			//We will save transaction after successfull calback
			return GenericApiResponse<TransferByPayPalResponseModel>.Success(
				new TransferByPayPalResponseModel()
				{
					clientRedirectUrl = paymentResponse.Payload.clientRedirectUrl
				}, _localizer["PaymentCreatedSuccessfully"]);
		}

		public async Task<GenericApiResponse<InternationalTopupInfo>> TransferByPayPalCallbackAsync(TransferByPaypalCallBackRequestModel model)
		{
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(model.msisdn));

			var paymentResponse = await _payPalByPay360Service.PayPalByPay360ES(
				new PayPalByPay360ESPaymentRequest()
				{
					PaypalCheckoutToken = model.token
				});

			var product = await _attRepo.GetProductByNowtelTransactionReference(model.nowtelRef, model.product);
			var custCharge = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture);


			var msisdnOrigin = _helperService.GetCountryCode(product.fromMsisdn);
			var msisdnDest = _helperService.GetCountryCode(product.tomsisdn);

			DeviceType deviceType = (DeviceType)model.DeviceType;

			//handle payment failiure scenarios
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
				   new IntTopupInfoAirShip()
				   {
					   IsSuccess = false,
					   Origination = msisdnOrigin,
					   Destination = msisdnDest,
					   IsCard = false,
					   Msisdn = model.msisdn,
					   Amount = custCharge,
					   IsTransferRequest = model.IsTransferRequest
				   });

				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(model.advertiserID, msisdnOrigin, msisdnDest, false, false, custCharge, model.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnOrigin, msisdnDest, false, false, custCharge, null, model.IsTransferRequest);

				//Save transaction
				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = accountDetails.AccountID,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = custCharge,
						TotalPrice = custCharge,
						Discount = decimal.Zero,
						DiscountCode = null,
						DiscountCodeType = null,
						NowtelRef = model.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = paymentResponse == null ? "Payment service not responding" : paymentResponse.Message,
						TransferErrorMsg = null,
						PaymentRef = null,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Paypal,
						Product = Convert.ToDecimal(model.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency,
						StatusId = TransferTransactionStatus.Failure
					});


				return HandlePay360PaymentFailureResponse<PayPalByPay360ESPaymentResponse, InternationalTopupInfo>
																			(paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}

			//Now payment is success, then start tranfer balance
			var executeTransResponse = await _attService.TransferBalance(new TransFerTotransferConfirm()
			{
				nowtelTransactionReference = model.nowtelRef,
				product = model.product,
				operatorid = model.operatorId,
				messageToRecipient = ""
			}, model.msisdn);

			if (executeTransResponse == null || executeTransResponse.errorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
				   new IntTopupInfoAirShip()
				   {
					   IsSuccess = false,
					   Origination = msisdnOrigin,
					   Destination = msisdnDest,
					   IsCard = false,
					   Msisdn = model.msisdn,
					   Amount = custCharge,
					   IsTransferRequest = model.IsTransferRequest,
				   });


				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(model.advertiserID, msisdnOrigin, msisdnDest, false, false, custCharge, model.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnOrigin, msisdnDest, false, false, custCharge, null, model.IsTransferRequest);

				//Save transaction
				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = accountDetails.AccountID,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = custCharge,
						TotalPrice = custCharge,
						Discount = decimal.Zero,
						DiscountCode = null,
						DiscountCodeType = null,
						NowtelRef = model.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = null,
						TransferErrorMsg = executeTransResponse == null
												? "Transfer service not responding" : executeTransResponse?.message,
						PaymentRef = paymentResponse.Payload.transactionId,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Paypal,
						StatusId = TransferTransactionStatus.Failure,
						Product = Convert.ToDecimal(model.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency
					});

				//Refund Paypal Payment
				if (_payPalConfig.IsTransferAutoRefund)
				{
					string refundFailedMessage = $"Payment refund failed==> Payment TransactionId:{paymentResponse.Payload.transactionId}";

					try
					{
						var refundResponse = await _payPalByPay360Service.PaypalRefund(
							  new Models.Contracts.PaypalApiContracts.RefundFullPaymentRequestModel()
							  {
								  transactionId = paymentResponse.Payload.transactionId
							  });

						if (refundResponse == null || refundResponse.errorCode > 0)
						{
							await _emailService.SendEmail(
								_pay360Config.PaymentCaptureFailureEmail,
								refundFailedMessage,
								false,
								"Refund Paypal Failed-THA-App-" + paymentResponse.Payload.transactionId);
						}
					}
					catch (Exception ex)
					{
						await _emailService.SendEmail(
							_pay360Config.PaymentCaptureFailureEmail,
							refundFailedMessage + "-" + ex.Message,
							false,
							"Refund Paypal Failed-THA-App-" + paymentResponse.Payload.transactionId);
					}
				}
				else
				{
					string refundFailedMessage = $"Need to refund the transaction:{paymentResponse.Payload.transactionId}";

					await _emailService.SendEmail(
						_pay360Config.PaymentCaptureFailureEmail,
						refundFailedMessage,
						false,
						"Transfer Via Paypal Failed-THA-App-" + paymentResponse.Payload.transactionId);
				}
				_logger.Error($"Class=>Payment_BL, Method=>TransferByPayPalCallbackAsync, Message=> Balance transfer failed after successful payment, FromMsisdn=>{model.msisdn},Product=>{model.product}, NowTelRef=>{model.nowtelRef}");

				return GenericApiResponse<InternationalTopupInfo>.Failure(null,
												_localizer["BalanceTransferFailed"], ApiStatusCodes.UnSuccessful);
			}

			//var isFirstTopup = await AccountRepo.IsFirstTopUp(model.msisdn);
			var userBalance = await _accountRepo.GetUserAccountBalanceAsync(model.msisdn);

			//Appsflyer events
			//await _appsFlyerService.HandleTopupEvents(
			//    new AppsFlyerInfo(model.AppsFlyerId, model.DeviceType),
			//    decimal.Parse(paymentResponse.Payload.transactionAmount,CultureInfo.InvariantCulture),
			//    userBalance.Currency,
			//    msisdnOrigin,
			//    model.IpAddress,
			//    isFirstTopup);

			//Airship events
			await _airShipService.HandleIntTopupTagsAndEvents(
				   new IntTopupInfoAirShip()
				   {
					   IsSuccess = true,
					   IsCard = false,
					   Msisdn = model.msisdn,
					   Destination = msisdnDest,
					   Origination = msisdnOrigin,
					   Amount = custCharge,
					   IsTransferRequest = model.IsTransferRequest,
				   });


			// Handle FaceBook Events
			await _faceBookService.HandleIntTopupEvents(model.advertiserID, msisdnOrigin, msisdnDest, true, false, custCharge, model.IsTransferRequest);
			// Handle AppsFlyer Events
			await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnOrigin, msisdnDest, true, false, custCharge, null, model.IsTransferRequest);

			//Save transaction
			await _attRepo.SaveTransactionAsync(
				new DBTransferTransaction()
				{
					AccountId = accountDetails.AccountID,
					ClientCurrecny = product.fromCurrency,
					CountryCode = _helperService.GetCountryCode(product.tomsisdn),
					FromMsisdn = product.fromMsisdn,
					ToMsisdn = product.tomsisdn,
					ItemPrice = custCharge,
					TotalPrice = custCharge,
					Discount = decimal.Zero,
					DiscountCode = null,
					DiscountCodeType = null,
					NowtelRef = model.nowtelRef,
					OperatorCountryName = product.operatorCountryName,
					OperatorLogoUrl = product.operatorLogoUrl,
					OperatorName = product.operatorName,
					PaymentErrorMsg = null,
					TransferErrorMsg = null,
					PaymentRef = paymentResponse.Payload.transactionId,
					TransferRef = executeTransResponse.reference,
					PaymentTypeId = InternationalTopupPaymentType.Paypal,
					StatusId = TransferTransactionStatus.Success,
					Product = Convert.ToDecimal(model.product, CultureInfo.InvariantCulture),
					ReceiverCurrecny = product.toCurrency
				});

			var userProfile = await _accountRepo.GetUserProfile(model.msisdn);
			if (!string.IsNullOrEmpty(userProfile?.Data?.email))
			{
				await SendInternationalTopupPaymentReceiptAsync(userProfile.Data.email, product, userProfile.Data, "Paypal", decimal.Zero, decimal.Zero, string.Empty, 0, executeTransResponse.reference, executeTransResponse.pinCode);
			}

			return GenericApiResponse<InternationalTopupInfo>.Success(
				new InternationalTopupInfo()
				{
					TopupAmount = paymentResponse.Payload.transactionAmount,
					Msisdn = model.msisdn,
					TransactionId = paymentResponse.Payload.transactionId,
					Currency = _helperService.ToCurrencySymbol(userBalance.Currency),
					NewBalance = userBalance.Balance,
					FromAmount = Convert.ToDecimal(product.fromAmount, CultureInfo.InvariantCulture)
				}, _localizer["InternationalTopupSuccessfull"]);
		}
		#endregion

		#region Autotopup management and topup methods
		public async Task<GenericApiResponse<bool>> SetAutoTopUp(SetAutoTopUpRequestModel model, string msisdn, string currency, string email)
		{
			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						email = userInfo.Data.email.Trim();
				}
			}


			bool defaultcard = false;
			if (model.isActive)
			{
				var cardResponse = await _pay360Service.GetPaymentMethods(msisdn);
				if (cardResponse.ErrorCode == 0)
				{
					defaultcard = cardResponse.Payload?.paymentMethodResponses?.Any(x => x.isPrimary == true) ?? false;
					if (defaultcard == false || cardResponse.Payload.paymentMethodResponses.Count == 0)
					{
						return GenericApiResponse<bool>.Failure(_localizer["NoDefaultCard"], ApiStatusCodes.Pay360Error);
					}
				}
			}

			if (model.amount == default && model.thresholdBalanceAmount == default)
			{
				var getResponse = await _autoTopupDL.Get(msisdn);
				if (getResponse != null)
				{
					model.amount = getResponse.Topup;
					model.thresholdBalanceAmount = getResponse.ThresHold;
				}
			}

			var setResponse = await _pay360Service.SetAutoTopUp(model, msisdn, currency, email);
			if (setResponse.ErrorCode == 0)
			{
				await _airShipService.HandleAutoTopup(msisdn, model.isActive);
				await _appsFlyerService.HandleAutoTopup(model.AppsFlyerId, model.DeviceType, model.isActive, Convert.ToDecimal(model.amount));
				return GenericApiResponse<bool>.Success(setResponse.Payload, setResponse.Message);
			}
			else
				return GenericApiResponse<bool>.Failure(setResponse.Message, (ApiStatusCodes)setResponse.ErrorCode);
		}
		public async Task<GenericApiResponse<bool>> SetAutoTopUpV2(SetAutoTopUpRequestModel model, string msisdn, string currency, string email)
		{
			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						email = userInfo.Data.email.Trim();
				}
			}


			bool defaultcard = false;
			if (model.isActive)
			{
				var cardResponse = await _pay360Service.GetPaymentMethods(msisdn);
				if (cardResponse.ErrorCode == 0)
				{
					defaultcard = cardResponse.Payload?.paymentMethodResponses?.Any(x => x.isPrimary == true) ?? false;
					if (defaultcard == false || cardResponse.Payload.paymentMethodResponses.Count == 0)
					{
						return GenericApiResponse<bool>.Failure(_localizer["NoDefaultCard"], ApiStatusCodes.Pay360Error);
					}
				}
			}

			if (model.amount == default && model.thresholdBalanceAmount == default)
			{
				var getResponse = await _pay360Service.GetAutoTopUp(msisdn, email);
				if (getResponse.ErrorCode == 0)
				{
					model.amount = getResponse.Payload.Topup;
					model.thresholdBalanceAmount = getResponse.Payload.Threshold;
				}
			}

			var setResponse = await _pay360Service.SetAutoTopUp(model, msisdn, currency, email);
			if (setResponse.ErrorCode == 0)
			{
				await _airShipService.HandleAutoTopup(msisdn, model.isActive);
				await _appsFlyerService.HandleAutoTopup(model.AppsFlyerId, model.DeviceType, model.isActive, Convert.ToDecimal(model.amount));
				return GenericApiResponse<bool>.Success(setResponse.Payload, setResponse.Message);
			}
			else
				return GenericApiResponse<bool>.Failure(setResponse.Message, (ApiStatusCodes)setResponse.ErrorCode);
		}

		public async Task<GenericApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(string msisdn, string email)
		{
			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						email = userInfo.Data.email.Trim();
				}
			}

			var autoTopup = await _autoTopupDL.Get(msisdn);
			if (autoTopup != null)
				return GenericApiResponse<Pay360GetAutoTopUpResponse>.Success(new Pay360GetAutoTopUpResponse
				{
					AutoTopUpStatus = autoTopup.Status,
					Currency = autoTopup.Currency,
					Msisdn = autoTopup.Msisdn,
					Topup = autoTopup.Topup,
					Threshold = autoTopup.ThresHold
				}, "Success");
			else
				return GenericApiResponse<Pay360GetAutoTopUpResponse>.Failure("Unable to get auto topup record", ApiStatusCodes.BadRequest);
		}
		public async Task<GenericApiResponse<Pay360PaymentAmountResponse>> GetPaymentAmounts(string currency, string msisdn, string email)
		{
			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						email = userInfo.Data.email.Trim();
				}
			}

			var paymentAmount = new Pay360PaymentAmountResponse()
			{
				topupAmount = _pay360Config.TopupAmount.Split(","),
				autoTopupAmounts = _pay360Config.AutoTopupAmount.Split(","),
				autoTopupThresholdAmount = _pay360Config.AutoTopupThresholdAmount.Split(","),
				currency = currency
			};

			var autoTopupSettings = await _pay360Service.GetAutoTopUp(msisdn, email);

			if (autoTopupSettings.ErrorCode == 0)
			{
				paymentAmount.autoTopupSettings = autoTopupSettings.Payload;
				return GenericApiResponse<Pay360PaymentAmountResponse>.Success(paymentAmount, "Success");
			}
			else
			{
				return GenericApiResponse<Pay360PaymentAmountResponse>.Failure(
					autoTopupSettings.Message, ApiStatusCodes.InternalServerError);
			}
		}

		#endregion

		#region Cards management
		public async Task<GenericApiResponse<PaymentMethodsPayload>> GetCustomerCards(Pay360CustomerRequestModel request)
		{
			var response = await _pay360Service.GetPaymentMethods(request.customerUniqueRef);
			if (response.ErrorCode == 0)
				return GenericApiResponse<PaymentMethodsPayload>.Success(response.Payload, response.Message);
			else
				return GenericApiResponse<PaymentMethodsPayload>.Failure(response.Message, (ApiStatusCodes)response.ErrorCode);
		}

		public async Task<GenericApiResponse<bool>> SetDefaultCard(string msisdn, SetDefaultCardUserRequest request)
		{
			var response = await _pay360Service.SetDefaultCard(msisdn, request);
			if (response.ErrorCode == 0)
				return GenericApiResponse<bool>.Success(response.Payload, response.Message);
			else
				return GenericApiResponse<bool>.Failure(response.Message, (ApiStatusCodes)response.ErrorCode);
		}

		public async Task<GenericApiResponse<bool>> RemoveCard(string msisdn, string account, RemoveCardUserRequest request)
		{
			var existingCards = await _pay360Service.GetPaymentMethods(msisdn);
			var anyActiveAutoBundleRenewal = await _bundleRepo.AnyActiveAutoBundleRenwal(account);
			if (existingCards.Payload.paymentMethodResponses.Count == 1 && anyActiveAutoBundleRenewal)
			{
				//Don't allow user to remove payment method if there is any bundle with active auto renewal
				return GenericApiResponse<bool>.Failure("Card cannot be removed while auto bundle renewal is active.", ApiStatusCodes.BadRequest);
			}
			var response = await _pay360Service.RemoveCard(msisdn, request);
			if (response.ErrorCode == 0)
			{
				//Handle airship
				var paymentMethodRes = await _pay360Service.GetPaymentMethods(msisdn);
				if (paymentMethodRes.ErrorCode == 0
					&& paymentMethodRes.Payload != null
					&& paymentMethodRes.Payload.paymentMethodResponses.Count == 0)
				{
					await _airShipService.RemoveNamedUserTags(new NamedUserTagsRequest()
					{
						NamedUser = msisdn,
						Tags = new List<string>() { "addcard_app" },
						TagGroup = _airShipConfig.ActivityTagGroupName
					});
				}

				return GenericApiResponse<bool>.Success(response.Payload, response.Message);
			}
			else
				return GenericApiResponse<bool>.Failure(response.Message, (ApiStatusCodes)response.ErrorCode);
		}
		#endregion

		#region Helper methods
		private async Task<Pay360PaymentRequest> GeneratePay360PaymentRequest(Pay360PaymentRequestData model)
		{
			//Get User Registration Date
			var userRegistrationDate = await _accountRepo.GetUserRegistrationDate(model.accountNumber);

			List<fieldstate> _fieldState = new List<fieldstate>()
				{
					new fieldstate() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
					new fieldstate() { name = "ProductItemCode", value = ProductItemCode.THAATA.ToString(), transient = false },
					new fieldstate() { name = "FirstUseDate", value = userRegistrationDate.ToString("yyyy-MM-dd"), transient = false },
				};

			if (model.CheckoutPaymentType == Models.Enums.CheckOutTypes.Transfer)
			{
				_fieldState.Add(new fieldstate() { name = "ANumber", value = model.CustomerMsisdn, transient = false });
				_fieldState.Add(new fieldstate() { name = "BNumber", value = model.toMsisdn, transient = false });
			}

			List<basket> baskets = new List<basket>();

			if (model.CheckoutPaymentType == Models.Enums.CheckOutTypes.Bundle)
			{
				baskets.Add(new basket()
				{
					chargeAmount = model.ChargeAmount,
					discountAmount = model.DiscountAmount,
					bundleRef = model.BundleId,
					productItemCode = ProductItemCode.THAATA.ToString(),
					productRef = model.CustomerMsisdn
				});
			}
			else if (model.CheckoutPaymentType == Models.Enums.CheckOutTypes.TopUp)
			{
				baskets.Add(new basket()
				{
					chargeAmount = model.ChargeAmount,
					discountAmount = model.DiscountAmount,
					bundleRef = "",
					productItemCode = ProductItemCode.THAATA.ToString(),
					productRef = model.CustomerMsisdn
				});
			}
			else
			{
				baskets.Add(new basket()
				{
					chargeAmount = model.ChargeAmount,
					discountAmount = model.DiscountAmount,
					bundleRef = "",
					productItemCode = ProductItemCode.THADTA.ToString(),
					productRef = model.CustomerMsisdn
				});
			}

			Pay360PaymentRequest request = new Pay360PaymentRequest();

			switch (model.Pay360PaymentType)
			{
				case Pay360PaymentType.New:
					request.Pay360PaymentRequestNew = new Pay360PaymentRequestNew
					{
						basket = baskets,
						customerName = model.CustomerCardData.NameOnCard,
						customerMsisdn = model.CustomerMsisdn,
						customerUniqueRef = model.CustomerUniqueRef,
						customerEmail = model.CustomerEmail,
						transactionCurrency = model.Currency,
						ipAddress = model.IpAddress,
						productCode = ProductCode.THA.ToString(),
						transactionAmount = model.ChargeAmount,
						customFields = new customField() { fieldState = _fieldState },
						cardCv2 = model.CustomerCardData.SecurityCode,
						cardExpiryDate = model.CustomerCardData.ExpiryDate,
						cardPan = model.CustomerCardData.CardNumber,
						isDirectFullfilment = model.CheckoutPaymentType == Models.Enums.CheckOutTypes.Transfer ? false : _pay360Config.IsDirectFullfilment,
						isAuthorizationOnly = model.CheckoutPaymentType == Models.Enums.CheckOutTypes.Transfer ? _pay360Config.TransferIsAuthorization : _pay360Config.IsAuthorization,
						isDefaultCard = model.IsDefaultCard,
						do3DSecure = _pay360Config.Do3DSecure,
						saveCard = (model.IsDefaultCard ? true : model.ShouldSaveCard),
						OverrideValidation = model.OverrideValidation,
						recurring = model.IsRecurring,
						billingAddress = new billingAddress()
						{
							line1 = model.CustomerAddressData.AddressL1,
							line2 = model.CustomerAddressData.AddressL2,
							line3 = model.CustomerAddressData.AddressL3,
							line4 = model.CustomerAddressData.AddressL4,
							region = model.CustomerAddressData.Region,
							city = model.CustomerAddressData.City,
							postcode = model.CustomerAddressData.PostCode,
							countryCode = model.CustomerAddressData.CountryCode
						}
					};
					if (_pay360Config.IsBillingAndCustomerAddressSame == true)
						request.Pay360PaymentRequestNew.customerBillingAddress = request.Pay360PaymentRequestNew.billingAddress;
					break;
				case Pay360PaymentType.Token:
					request.Pay360PaymentRequestToken = new Pay360PaymentRequestToken
					{
						basket = baskets,
						customerMsisdn = model.CustomerMsisdn,
						customerUniqueRef = model.CustomerUniqueRef,
						customerEmail = model.CustomerEmail,
						transactionCurrency = model.Currency,
						ipAddress = model.IpAddress,
						productCode = ProductCode.THA.ToString(),
						cardCv2 = model.SecurityCode,
						transactionAmount = model.ChargeAmount,
						customFields = new customField() { fieldState = _fieldState },
						isDirectFullfilment = model.CheckoutPaymentType == Models.Enums.CheckOutTypes.Transfer ? false : _pay360Config.IsDirectFullfilment,
						isAuthorizationOnly = model.CheckoutPaymentType == Models.Enums.CheckOutTypes.Transfer ? _pay360Config.TransferIsAuthorization : _pay360Config.IsAuthorization,
						do3DSecure = _pay360Config.Do3DSecure,
						cardToken = model.CardToken,
						OverrideValidation = model.OverrideValidation,
						recurring = model.IsRecurring
					};
					break;
				case Pay360PaymentType.Default:
					request.Pay360PaymentRequestDefault = new Pay360PaymentBase()
					{
						Pay360PaymentType = Pay360PaymentType.Default,
						basket = baskets,
						cardCv2 = model.SecurityCode,
						customerMsisdn = model.CustomerMsisdn,
						customerUniqueRef = model.CustomerUniqueRef,
						customerEmail = model.CustomerEmail,
						transactionCurrency = model.Currency,
						ipAddress = model.IpAddress,
						productCode = ProductCode.THA.ToString(),
						transactionAmount = model.ChargeAmount,
						customFields = new customField() { fieldState = _fieldState },
						isDirectFullfilment = model.CheckoutPaymentType == Models.Enums.CheckOutTypes.Transfer ? false : _pay360Config.IsDirectFullfilment,
						isAuthorizationOnly = model.CheckoutPaymentType == Models.Enums.CheckOutTypes.Transfer ? _pay360Config.TransferIsAuthorization : _pay360Config.IsAuthorization,
						do3DSecure = _pay360Config.Do3DSecure,
					};
					break;
			}

			return request;
		}

		public async Task<GenericApiResponse<GetAddressByPostCodeResponseModel>> GetAddressByPostCode(GetAddressByPostCodeRequestModel model)
		{
			var response = await _pay360Service.GetAddressByPostCode(model);
			if (response.ErrorCode == 0)
				return GenericApiResponse<GetAddressByPostCodeResponseModel>.Success(response.Payload, response.Message);
			else
				return GenericApiResponse<GetAddressByPostCodeResponseModel>.Failure(response.Message, (ApiStatusCodes)response.ErrorCode);
		}



		private async Task Pay360CardPaymentFullfillment(
							GenericPay360ApiResponse<Pay360PaymentResponse> paymentResponse, string msisdn, string PaymentEmailAddress, bool isAuthorizeOnlyPayment, string account)
		{
			string pay360TransactionId = paymentResponse.Payload.transactionId;
			var userProfile = await _accountRepo.GetUserProfile(msisdn);

			var basket = await _paymentFullfillmentDL.GetBasketItemAsync(paymentResponse.Payload.transactionId);
			foreach (var item in basket)
			{

				var ccAuthCode = pay360TransactionId;
				var CssTransId = pay360TransactionId;
				var fulfillmentAmount = isAuthorizeOnlyPayment ? 0 : item.amount * 100;

				var bundleRef = item.bundleref;

				var result = await _paymentFullfillmentDL.
					ThaPay360cardCustomerFullfilmentAsync(msisdn, fulfillmentAmount, CssTransId, ccAuthCode, bundleRef);

				if (result != null && result.ErrorCode == 0)
				{
					await _paymentFullfillmentDL.UpdatePaymentTransactionsItemsAsync(true, item.id, null, true, result.BundleName);

					if (!string.IsNullOrEmpty(PaymentEmailAddress))
					{
						var profile = new Profile();
						if (userProfile != null)
						{
							profile = userProfile.Data;
						}

						if (!string.IsNullOrWhiteSpace(item.bundleref))
						{
							var bundleDetails = await _bundleRepo.GetBundleById(item.bundleref, account);
							await SendBundlePurchasePaymentReceiptAsync(PaymentEmailAddress, bundleDetails, item.Transactioncurrency, profile, "Card");
						}
						else if (!isAuthorizeOnlyPayment)
						{
							await SendTopupPaymentReceiptAsync(PaymentEmailAddress, msisdn, (decimal)item.amount, profile, "Card");
						}
					}

				}
				else
				{
					await _paymentFullfillmentDL.UpdatePaymentTransactionsItemsAsync(false, item.id, result.ErrorMessage, false, result.BundleName);
				}
			}

		}


		private GenericApiResponse<TOutput> HandlePay360PaymentFailureResponse<TInput, TOutput>(
							GenericPay360ApiResponse<TInput> paymentResponse, Models.Enums.CheckOutTypes type)
		{
			if (paymentResponse == null)
			{
				return GenericApiResponse<TOutput>.Failure(_localizer["PaymentNotAuthorized"], ApiStatusCodes.UnSuccessful);
			}
			if (paymentResponse.Pay360ApiCode == "D100")
			{
				return GenericApiResponse<TOutput>.Failure(_localizer["PaymentNotAuthorized"], ApiStatusCodes.UnSuccessful);
			}
			if (paymentResponse.Pay360ApiCode == "A136")
			{
				return GenericApiResponse<TOutput>.Failure(paymentResponse.Message, ApiStatusCodes.Pay360Error);
			}
			switch (type)
			{
				case Models.Enums.CheckOutTypes.Bundle://Bundle Purchase

					if (paymentResponse.ErrorCode == (int)Pay360StatusCodes.limitExceed_MaximumBundle)
					{
						return GenericApiResponse<TOutput>.Failure(_localizer["MaxNumberOfBundlesPurchased"], ApiStatusCodes.BundleLimitExceeded);
					}
					else if (paymentResponse.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
					{
						return GenericApiResponse<TOutput>.Failure(_localizer["DailyBundleLimitExceeded"], ApiStatusCodes.DailyLimitExceeded);
					}
					else
					{
						return GenericApiResponse<TOutput>.Failure(_localizer["PaymentError"], ApiStatusCodes.UnSuccessful);
					}
				case Models.Enums.CheckOutTypes.TopUp://Top-up
													  //Card + Paypal
					if (paymentResponse.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
					{
						return GenericApiResponse<TOutput>.Failure(_localizer["DailyTopupLimitExceeded"], ApiStatusCodes.DailyLimitExceeded);
					}
					else
					{
						return GenericApiResponse<TOutput>.Failure(_localizer["PaymentError"], ApiStatusCodes.UnSuccessful);
					}
				case Models.Enums.CheckOutTypes.Transfer:
					//International Top-up by Card + Paypal
					return GenericApiResponse<TOutput>.Failure(_localizer["PaymentError"], ApiStatusCodes.UnSuccessful);
				default:
					return GenericApiResponse<TOutput>.Failure(_localizer["PaymentError"], ApiStatusCodes.UnSuccessful);
			}
		}
		private GenericApiResponse<TOutput> HandlePaypalPaymentFailureResponse<TInput, TOutput>(
							PaypalPaymentResponse paymentResponse, Models.Enums.CheckOutTypes type)
		{
			if (paymentResponse == null)
			{
				return GenericApiResponse<TOutput>.Failure(_localizer["PaymentNotAuthorized"], ApiStatusCodes.UnSuccessful);
			}
			if (paymentResponse.ErrorCode == PaypalApiStatusCodes.PaymentProviderError)
			{
				return GenericApiResponse<TOutput>.Failure(_localizer["PaymentNotAuthorized"], ApiStatusCodes.UnSuccessful);
			}
			if (paymentResponse.ErrorCode == PaypalApiStatusCodes.PaymentServiceError)
			{
				return GenericApiResponse<TOutput>.Failure(paymentResponse.ErrorMessage, ApiStatusCodes.PaymentServiceError);
			}
			switch (type)
			{
				case Models.Enums.CheckOutTypes.Bundle://Bundle Purchase

					if (paymentResponse.ErrorCode == (int)Pay360StatusCodes.limitExceed_MaximumBundle)
					{
						return GenericApiResponse<TOutput>.Failure(_localizer["MaxNumberOfBundlesPurchased"], ApiStatusCodes.BundleLimitExceeded);
					}
					else if (paymentResponse.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
					{
						return GenericApiResponse<TOutput>.Failure(_localizer["DailyBundleLimitExceeded"], ApiStatusCodes.DailyLimitExceeded);
					}
					else
					{
						return GenericApiResponse<TOutput>.Failure(_localizer["PaymentError"], ApiStatusCodes.UnSuccessful);
					}
				case Models.Enums.CheckOutTypes.TopUp://Top-up
													  //Card + Paypal
					if (paymentResponse.ErrorCode == (int)Pay360StatusCodes.DailyLimitExceed)
					{
						return GenericApiResponse<TOutput>.Failure(_localizer["DailyTopupLimitExceeded"], ApiStatusCodes.DailyLimitExceeded);
					}
					else
					{
						return GenericApiResponse<TOutput>.Failure(_localizer["PaymentError"], ApiStatusCodes.UnSuccessful);
					}
				case Models.Enums.CheckOutTypes.Transfer:
					//International Top-up by Card + Paypal
					return GenericApiResponse<TOutput>.Failure(_localizer["PaymentError"], ApiStatusCodes.UnSuccessful);
				default:
					return GenericApiResponse<TOutput>.Failure(_localizer["PaymentError"], ApiStatusCodes.UnSuccessful);
			}
		}

		private async Task Pay360PaypalPaymentFullfillment(
							GenericPay360ApiResponse<PayPalByPay360ESPaymentResponse> paymentResponse, string msisdn, string PaymentEmailAddress, string account, decimal discountAmount)
		{
			string pay360TransactionId = paymentResponse.Payload.transactionId;

			var basket = await _paymentFullfillmentDL.GetBasketItemAsync(paymentResponse.Payload.transactionId);
			var userProfile = await _accountRepo.GetUserProfile(msisdn);

			foreach (var item in basket)
			{
				PaymentEmailAddress = item.Email;

				var ccAuthCode = pay360TransactionId;
				var CssTransId = pay360TransactionId;
				var amount = item.amount * 100 + discountAmount * 100;
				var bundleRef = item.bundleref;

				var result = await _paymentFullfillmentDL.ThaPay360paypalStraightCustomerFullfilmentAsync(CssTransId, bundleRef, (decimal)amount, msisdn);

				if (result != null && result.ErrorCode == 0)
				{
					await _paymentFullfillmentDL.UpdatePaymentTransactionsItemsAsync(true, item.id, null, true, result.BundleName);
					if (!string.IsNullOrEmpty(PaymentEmailAddress))
					{
						var profile = new Profile();
						if (userProfile != null)
						{
							profile = userProfile.Data;
						}

						if (!string.IsNullOrWhiteSpace(item.bundleref))
						{
							var bundleDetails = await _bundleRepo.GetBundleById(item.bundleref, account);
							await SendBundlePurchasePaymentReceiptAsync(PaymentEmailAddress, bundleDetails, item.Transactioncurrency, profile, "PayPal");
						}
						else
						{
							await SendTopupPaymentReceiptAsync(PaymentEmailAddress, msisdn, (decimal)item.amount, profile, "PayPal");
						}
					}

				}
				else
				{
					await _paymentFullfillmentDL.UpdatePaymentTransactionsItemsAsync(false, item.id, result.ErrorMessage, false, result.BundleName);
				}
			}

		}
		private async Task PaypalPaymentFullfillment(
							PaypalPaymentResponse paymentResponse, string msisdn, string PaymentEmailAddress, string account)
		{
			string pay360TransactionId = paymentResponse.TransactionId;

			var basket = await _paymentFullfillmentDL.GetBasketItemAsync(paymentResponse.TransactionId);
			var userProfile = await _accountRepo.GetUserProfile(msisdn);

			foreach (var item in basket)
			{
				PaymentEmailAddress = item.Email;

				var ccAuthCode = pay360TransactionId;
				var CssTransId = pay360TransactionId;
				var amount = item.amount * 100;
				var bundleRef = item.bundleref;

				var result = await _paymentFullfillmentDL.ThaPay360paypalStraightCustomerFullfilmentAsync(CssTransId, bundleRef, (decimal)amount, msisdn);

				if (result != null && result.ErrorCode == 0)
				{
					await _paymentFullfillmentDL.UpdatePaymentTransactionsItemsAsync(true, item.id, null, true, result.BundleName);
					if (!string.IsNullOrEmpty(PaymentEmailAddress))
					{
						var profile = new Profile();
						if (userProfile != null)
						{
							profile = userProfile.Data;
						}

						if (!string.IsNullOrWhiteSpace(item.bundleref))
						{
							var bundleDetails = await _bundleRepo.GetBundleById(item.bundleref, account);
							await SendBundlePurchasePaymentReceiptAsync(PaymentEmailAddress, bundleDetails, item.Transactioncurrency, profile, "PayPal");
						}
						else
						{
							await SendTopupPaymentReceiptAsync(PaymentEmailAddress, msisdn, (decimal)item.amount, profile, "PayPal");
						}
					}

				}
				else
				{
					await _paymentFullfillmentDL.UpdatePaymentTransactionsItemsAsync(false, item.id, result.ErrorMessage, false, result.BundleName);
				}
			}

		}

		#endregion

		#endregion

		#region Version v2
		#region Card Payments Topup and Bundle
		public async Task<GenericApiResponse<CardPaymentResponseModel>> NewCustomerPaymentV2Async(NewCustomerPaymentRequestModelV2 model, string msisdn, string currency, string ipAddress, string email, string advertiserID)
		{
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));
			// new user (if customer does not have any transactional record)

			var hasUserDoneTransaction = await _accountRepo.IsNewUser(msisdn);
			var isFirstTopup = await _accountRepo.IsFirstTopUp(msisdn);
			var isFirstInternationalTopup = await _attRepo.IsFirstATTTransaction(accountDetails.AccountID);

			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						email = userInfo.Data.email.Trim();
				}
			}



			//DeviceType deviceType = (DeviceType)Enum.Parse(typeof(DeviceType), model.DeviceType, true);
			GenericApiResponse<StackableDiscountResponse> redemptionResult = null;
			DeviceType deviceType = (DeviceType)model.DeviceType;
			string bundleName = "";
			string bundleDest = "";
			string Currency = "";
			decimal bundlePrice = 0;
			string msisdnOrigin = _helperService.GetCountryCode(msisdn);
			BundleType bundleType = BundleType.PAYG;
			bool isTrialBundle = false;
			decimal ChargeAmount;
			decimal discountAmount = 0;
			decimal extraBalance = 0;
			int topupRewardPoints = 0;
			int bundleRewardPoints = 0;


			////Get Product Info
			//var product = await _attRepo.GetProductByNowtelTransactionReference(
			//                            model.nowtelTransactionReference, model.product);

			if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				if (model.BundleInfo == null
					|| string.IsNullOrWhiteSpace(model.BundleInfo.BundleId))
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
					   _localizer["BundleInfoMissing"],
					   ApiStatusCodes.BadRequest);
				}

				//Check Bundle Limit
				var bundlesResponse = await _accountRepo.GetBundlesHistory(accountDetails.AccountID);
				if (bundlesResponse.Count() >= 10)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
						_localizer["MaxNumberOfBundlesPurchased"],
						ApiStatusCodes.BundleLimitExceeded);
				}

				//Get Bundle details
				var bundleResponse = await _bundleRepo.GetBundleById(model.BundleInfo.BundleId, accountDetails.AccountID);
				bundleRewardPoints = bundleResponse.RewardPoints;

				if (bundleResponse == null)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
						_localizer["InvalidBundle"],
						ApiStatusCodes.InvalidBundle);
				}

				bundleDest = bundleResponse.Description.Replace(" ", "").Replace(",", "");
				bundleType = bundleResponse.BundleType;
				Currency = accountDetails.Currency;
				bundlePrice = Convert.ToDecimal(bundleResponse.TotalCostPence / 100, CultureInfo.InvariantCulture);

				if (bundleResponse.IsTrial
					&& bundleResponse.TrialId != null
					&& !(await _bundleRepo.IsBundlePurchasedPreviously(accountDetails.AccountID, bundleResponse.TrialId.ToString())))
				{
					//Trial bundle
					var trialBundle = await _bundleRepo.GetBundleById(bundleResponse.TrialId.ToString(), accountDetails.AccountID);
					if (trialBundle == null)
					{
						return GenericApiResponse<CardPaymentResponseModel>.Failure(_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
					}
					bundleName = trialBundle.BrandedName;
					bundleDest = trialBundle.Description.Replace(" ", "").Replace(",", "");
					bundleType = trialBundle.BundleType;
					bundleRewardPoints = trialBundle.RewardPoints;
					isTrialBundle = true;
					ChargeAmount = _pay360Config.TestPaymentAmount;//This amount is just for testing payment method, after successfull transaction this amount will be refunded
					model.BundleInfo = new BundleInfo()
					{
						BundleId = bundleResponse.TrialId.ToString(),
						IsBundleAutoRenew = true//Autorenewal will be true for trial bundle so that our backgroudn service can start primary bundle
					};
					model.CardInfo.ShouldSaveCard = true;//Save card bit will be true always for trial bundles
				}
				else
				{
					//Normal bundle
					bundleName = bundleResponse.BrandedName;
					ChargeAmount = bundleResponse.TotalCostPence / 100;
					bundleRewardPoints = bundleResponse.RewardPoints;
					if (bundleResponse.BundleType == BundleType.Monthly || bundleResponse.BundleType == BundleType.Welcome)
					{
						model.BundleInfo.IsBundleAutoRenew = true;//Monthly and Welcome bundles autorenewal will be true always
						model.CardInfo.ShouldSaveCard = true;//Save card bit will be true always for montly bundles
					}
				}
			}
			else
			{
				if (model.TopupInfo == null || model.TopupInfo.TopUpAmount <= 0)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
					   _localizer["TopupInfoMissing"],
					   ApiStatusCodes.BadRequest);
				}
				ChargeAmount = model.TopupInfo.TopUpAmount;
				// TODO:Voucherify logic to handle discounts and promotions

				if (!string.IsNullOrEmpty(model.DiscountCode))
				{
					//if(model.DiscountType == dis)
					var discountRequest = new StackableDiscountRequest
					{
						DiscountCode = model.DiscountCode,
						DiscountCodeType = model.DiscountCodeType,
						CheckoutType = CheckOutTypes.TopUp,
						Amount = model.TopupInfo.TopUpAmount,
						PaymentMethod = PaymentMethods.Card,
					};
					var validationResult = await _voucherifyService.ValidateDiscount(discountRequest, msisdn, accountDetails.AccountID, new CustomerMetadata()
					{
						FirstInternationalTopup = isFirstInternationalTopup,
						FirstTopup = isFirstTopup,
						TransactionDone = !hasUserDoneTransaction,
					});
					if (validationResult?.Payload != null)
					{
						discountAmount = validationResult.Payload.DiscountAmount;
						ChargeAmount -= discountAmount;
					}
				}
			}

			var paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
			{
				CustomerMsisdn = msisdn,
				ChargeAmount = ChargeAmount,
				DiscountAmount = discountAmount,
				CheckoutPaymentType = model.CheckoutType,
				BundleId = (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle ? model.BundleInfo.BundleId : ""),
				IpAddress = ipAddress,
				CustomerEmail = email,
				Currency = currency,
				Pay360PaymentType = Pay360PaymentType.New,
				CustomerAddressData = new AddressData()
				{
					AddressL1 = model.AddressInfo.AddressL1,
					AddressL2 = model.AddressInfo.AddressL2,
					AddressL3 = model.AddressInfo.AddressL3,
					AddressL4 = model.AddressInfo.AddressL4,
					PostCode = model.AddressInfo.PostCode,
					City = model.AddressInfo.City,
					Region = model.AddressInfo.Region,
					CountryCode = model.AddressInfo.CountryCode
				},
				CustomerCardData = new CardData()
				{
					CardNumber = model.CardInfo.CardNumber,
					NameOnCard = model.CardInfo.NameOnCard,
					SecurityCode = model.CardInfo.SecurityCode,
					ExpiryDate = model.CardInfo.ExpiryDate
				},
				ShouldSaveCard = model.CardInfo.ShouldSaveCard,
				IsDefaultCard = model.CardInfo.IsDefaultCard,
				accountNumber = accountDetails.AccountID,
				CustomerUniqueRef = msisdn
			});

			//Don't do 3d secure process in case of trial bundle
			if (isTrialBundle)
			{
				paymentrequest.Pay360PaymentRequestNew.do3DSecure = false;
			}
			//Recurring payment if bundle renewal or auto topup is on
			if (model.BundleInfo?.IsBundleAutoRenew == true
				|| model.TopupInfo?.AutoTopupInfo?.isActive == true)
			{
				paymentrequest.Pay360PaymentRequestNew.recurring = true;
			}
			var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.New);



			//save transaction
			var paymentTransactionId = await _paymentFullfillmentDL.InsertTransactionPaymentAsync(
				paymentrequest.Pay360PaymentRequestNew.basket,
				paymentrequest.Pay360PaymentRequestNew.transactionCurrency,
				paymentrequest.Pay360PaymentRequestNew.customerEmail,
				paymentrequest.Pay360PaymentRequestNew.productCode,
				paymentResponse != null && paymentResponse.Payload != null && !string.IsNullOrEmpty(paymentResponse.Payload.transactionId) ?
				paymentResponse.Payload.transactionId : null,
				paymentrequest.Pay360PaymentRequestNew.customerMsisdn,
				TransactionsPaymentType.Card,
				0,
				isTrialBundle,
				model.DiscountCode,
				model.DiscountCodeType);

			//Handle Error Scenarios
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = true,
							Msisdn = msisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});


					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
				}
				else
				{
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							IsCard = true,
							Msisdn = msisdn,
							Amount = ChargeAmount.ToString(CultureInfo.InvariantCulture)
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(advertiserID, false, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, false, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);
				}

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId,
						false,
						null,
						paymentResponse == null ? "Payment Service Not Responding - Null Response - New Customer"
						: $"{paymentResponse.ErrorCode} - {paymentResponse.Message} - New Customer");

				return HandlePay360PaymentFailureResponse
					<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, model.CheckoutType);
			}

			if (paymentResponse.Payload.outcome.reasonCode == "U100") //3d Secure Scenario
			{
				/*Make sure to encrypt url here
                   * Convert the hardcoded string to classs
                   * and Implement the class to query string convertsion method
                   */

				var secure3dType = paymentResponse.Payload.clientRedirect.type.ToLower().Contains("v2") ? "v2" : "v1";

				var airshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();
				var returnUrlBuilder = new StringBuilder();
				returnUrlBuilder.Append($"{_inAppPageConfig.BaseUrl}/v2/Pay360/Resume3DTransaction")
					.Append($"?CheckoutType={(int)model.CheckoutType}")
					.Append($"&CustomerEmail={email}")
					.Append($"&CustomerMsisdn={msisdn}")
					.Append($"&Currency={currency}")
					.Append($"&BundleId={(model.CheckoutType == Models.Enums.CheckOutTypes.Bundle ? model.BundleInfo.BundleId : "")}")
					.Append($"&Secure3dType={secure3dType}")
					.Append($"&PTId={paymentTransactionId}")
					.Append($"&Ip={ipAddress}")
					.Append($"&advertiserID={advertiserID}")
					.Append($"&airshipEventsDisable={airshipEventsDisable}")
					.Append($"&SaveCard={paymentrequest.Pay360PaymentRequestNew.saveCard}")
					.Append($"&culture={_localizer["Locale"]}");

				if (!string.IsNullOrEmpty(model.DiscountCode))
				{
					returnUrlBuilder.Append($"&DiscountCode={model.DiscountCode}")
						.Append( $"&DiscountCodeType={model.DiscountCodeType}");
				}

				if (model.AppsFlyerId != null)
				{
					returnUrlBuilder.Append($"&AppsFlyerId={model.AppsFlyerId}")
							.Append($"DeviceType={model.DeviceType}");
				}

				if (model.TopupInfo != null && model.TopupInfo.AutoTopupInfo != null)
				{
					returnUrlBuilder.Append($"&IsAutoTopUp={model.TopupInfo.AutoTopupInfo.isActive}")
								 .Append($"&AutoToupAmount={model.TopupInfo.AutoTopupInfo.amount}")
								 .Append($"&AutoTopupThreshold={model.TopupInfo.AutoTopupInfo.thresholdBalanceAmount}");
				}
				if (model.TopupInfo != null)
				{
					returnUrlBuilder.Append($"&TopupAmount={model.TopupInfo.TopUpAmount}");
				}
				if (model.BundleInfo != null)
				{
					returnUrlBuilder.Append($"&IsAutoRenewal={model.BundleInfo.IsBundleAutoRenew}");
				}

				if (model.UtmParamsInfo != null)
				{
					returnUrlBuilder.Append($"&UtmCampaign={model.UtmParamsInfo.utm_campaign}")
								 .Append($"&UtmMedium={model.UtmParamsInfo.utm_medium}")
								 .Append($"&UtmSource={model.UtmParamsInfo.utm_source}");
				}

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId, false, paymentResponse.Payload.transactionId);

				//Send Response
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
												new CardPaymentResponseModel()
												{
													threeDSecureData = new ThreeDSecureData()
													{
														pareq = paymentResponse.Payload.clientRedirect.pareq,
														redirectUrl = paymentResponse.Payload.clientRedirect.url,
														transactionId = paymentResponse.Payload.transactionId,
														returnUrl = returnUrlBuilder.ToString(),
														type = secure3dType,
														threeDSServerTransId = paymentResponse.Payload.clientRedirect.threeDSServerTransId
													}
												}, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);
			}
			else if (paymentResponse.Payload.outcome.reasonCode == "S100")
			{
				if (!string.IsNullOrEmpty(model.DiscountCode))
				{
					//Redeem promotion
					if (model.CheckoutType == CheckOutTypes.TopUp)
					{
						var discountRequest = new StackableDiscountRequest
						{
							DiscountCode = model.DiscountCode,
							DiscountCodeType = model.DiscountCodeType,
							CheckoutType = CheckOutTypes.TopUp,
							Amount = (decimal)model.TopupInfo.TopUpAmount,
							PaymentMethod = PaymentMethods.Card
						};
						redemptionResult = await _voucherifyService.RedeemDiscount(discountRequest, msisdn, accountDetails.AccountID, new CustomerMetadata()
						{
							FirstInternationalTopup = isFirstInternationalTopup,
							FirstTopup = isFirstTopup,
							TransactionDone = !hasUserDoneTransaction,
						});
					}
				}

				if (model.CheckoutType == Models.Enums.CheckOutTypes.TopUp)
				{
					var topupPoints = Utility.CalculateTopupRewardPoints(model.TopupInfo.TopUpAmount, _voucherifyConfig);
					await _voucherifyService.PurchaseEvent(msisdn, VoucherifyEventsNames.Topup, new VoucherifyEventsMetadata
					{
						ChargeAmount = model.TopupInfo.TopUpAmount,
						Timestamp = DateTime.UtcNow,
						LoyaltyPoints = topupPoints
					});
					topupRewardPoints = _pay360Config.TopupAmounts.Find(x => x.Amount == model.TopupInfo.TopUpAmount).RewardPoints;
				}
				// Voucherify Events
				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					if (bundleType == BundleType.Welcome)
					{
						await _voucherifyService.PurchaseEvent(msisdn, VoucherifyEventsNames.WelcomeBundle, new VoucherifyEventsMetadata
						{
							ChargeAmount = bundlePrice,
							Timestamp = DateTime.UtcNow,
							LoyaltyPoints = bundleRewardPoints
						});
					}
					if (bundleType == BundleType.PAYG)
					{
						await _voucherifyService.PurchaseEvent(msisdn, VoucherifyEventsNames.PayGBundle, new VoucherifyEventsMetadata
						{
							ChargeAmount = bundlePrice,
							Timestamp = DateTime.UtcNow,
							LoyaltyPoints = bundleRewardPoints
						});
					}
				}

				//Payment successfull
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, true);

				//Fulfillment
				await Pay360CardPaymentFullfillment(paymentResponse, msisdn, email, isTrialBundle, accountDetails.AccountID);

				//Get Updated User Balance
				var userBalance = await _accountRepo.GetUserAccountBalanceAsync(msisdn);

				var currencySymbol = _helperService.ToCurrencySymbol(currency);

				if (paymentrequest.Pay360PaymentRequestNew.saveCard)
				{
					await _airShipService.AddNamedUserTags(
						new NamedUserTagsRequest()
						{
							NamedUser = msisdn,
							Tags = new List<string>() { "addcard_app" },
							TagGroup = _airShipConfig.ActivityTagGroupName
						});
				}

				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					//var isFirstBundle = await _accountRepo.IsFirstBundle(msisdn);
					string cardMaskedPan = paymentResponse.Payload.recurring ? paymentResponse.Payload.maskedPan : null;
					string initialTransactionId = paymentResponse.Payload.recurring ? paymentResponse.Payload.transactionId : null;
					var autoRenewResp = await _bundleRepo.SetBundleAutoRenewalV2(
					model.BundleInfo.IsBundleAutoRenew, msisdn, accountDetails.AccountID,
					model.BundleInfo.BundleId, isTrialBundle, PaymentMethods.Card, cardMaskedPan, initialTransactionId, null);

					if (autoRenewResp.isValid && bundleType != BundleType.Welcome)
					{
						await _airShipService.HandleAutoRenew(
							msisdn, model.BundleInfo.IsBundleAutoRenew, bundleDest, bundleType);
					}

					//Refund payment if trial bundle
					if (isTrialBundle)
					{
						await _pay360Service.RefundFullPayment(
							new Models.Contracts.Request.RefundFullPaymentRequestModel()
							{
								transactionId = paymentResponse.Payload.transactionId,
							});
					}

					//Airship events
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = true,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = true,
							Msisdn = msisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});
					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);
					//Handle Appsflyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);

					return GenericApiResponse<CardPaymentResponseModel>.Success(
						new CardPaymentResponseModel()
						{
							CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
							IsRedeemedSuccess = redemptionResult != null && redemptionResult?.Payload?.RedemptionId != null,
							bundlePurchaseInfo = new BundlePurchaseInfo()
							{
								TransactionId = paymentResponse.Payload.transactionId,
								BundleAmount = isTrialBundle ? "0" : paymentResponse.Payload.transactionAmount,
								BundleName = bundleName,
								Msisdn = msisdn,
								Currency = currencySymbol,
								Destination = bundleDest,
								Type = bundleType,
								RewardPoints = bundleRewardPoints,
							},
							customerMsisdn = msisdn,
							transactionId = paymentResponse.Payload.transactionId
						}, _localizer["BundlePurchasedSuccessfully"]);
				}
				else
				{
					if (model.TopupInfo.AutoTopupInfo != null)
					{
						var autoTopup = new AutoTopupDetail
						{
							Topup = model.TopupInfo.AutoTopupInfo.amount,
							ThresHold = model.TopupInfo.AutoTopupInfo.thresholdBalanceAmount,
							Msisdn = msisdn,
							Currency = currency,
							Status = model.TopupInfo.AutoTopupInfo.isActive,
							PaymentMethod = PaymentMethods.Card,
							CardMaskedPAN = paymentResponse.Payload.recurring ? paymentResponse.Payload.maskedPan : null,
							CardInitialTransactionId = paymentResponse.Payload.recurring ? paymentResponse.Payload.transactionId : null,
							PaypalSubscriptionId = null,
						};
						var autoTopupResult = await _autoTopupDL.Set(autoTopup);
						if (autoTopupResult > 0)
						{
							await _airShipService.HandleAutoTopup(msisdn, model.TopupInfo.AutoTopupInfo.isActive);
						}
					}

					//Airship events
					await _airShipService.HandleTopupTagsAndEvents(
							 new TopupInfoAirship()
							 {
								 IsSuccess = true,
								 Origination = msisdnOrigin,
								 IsCard = true,
								 Msisdn = msisdn,
								 Amount = ChargeAmount.ToString(CultureInfo.InvariantCulture)
							 });


					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(advertiserID, true, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, true, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					return GenericApiResponse<CardPaymentResponseModel>.Success(
						new CardPaymentResponseModel()
						{
							CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
							IsRedeemedSuccess = redemptionResult != null && redemptionResult?.Payload?.RedemptionId != null,
							topupInfo = new TopupInfo()
							{
								TopupAmount = paymentResponse.Payload.transactionAmount,
								Msisdn = msisdn,
								TransactionId = paymentResponse.Payload.transactionId,
								Currency = currencySymbol,
								NewBalance = userBalance.Balance,
								IsFirstTopup = isFirstTopup,
								RewardPoints = topupRewardPoints,
							},
							customerMsisdn = msisdn,
							transactionId = paymentResponse.Payload.transactionId
						}, _localizer["TopUpSuccessful", paymentResponse.Payload.transactionAmount]);
				}
			}

			return GenericApiResponse<CardPaymentResponseModel>.Failure(
				null, _localizer["PaymentServiceNotResponding"], ApiStatusCodes.PaymentServiceError);
		}

		public async Task<GenericApiResponse<CardPaymentResponseModel>> ExistingCardPaymentV2Async(
							  ExistingCardPaymentRequestModelV2 model, string msisdn, string currency, string ipAddress, string email, string advertiserID)
		{
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));

			var hasUserDoneTransaction = await _accountRepo.IsNewUser(msisdn);
			var isFirstTopup = await _accountRepo.IsFirstTopUp(msisdn);
			var isFirstInternationalTopup = await _attRepo.IsFirstATTTransaction(accountDetails.AccountID);

			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						email = userInfo.Data.email.Trim();
				}
			}


			DeviceType deviceType = (DeviceType)model.DeviceType;
			string bundleName = "";
			string bundleDest = "";
			string Currency = "";
			decimal bundlePrice = 0;
			string msisdnOrigin = _helperService.GetCountryCode(msisdn);
			BundleType bundleType = BundleType.PAYG;
			bool isTrialBundle = false;
			decimal ChargeAmount;
			decimal discountAmount = 0;
			int topupRewardPoints = 0;
			int bundleRewardPoints = 0;
			GenericApiResponse<StackableDiscountResponse> redemptionResult = null;
			if (model.CheckoutType == Models.Enums.CheckOutTypes.TopUp)
			{
				topupRewardPoints = _pay360Config.TopupAmounts.FirstOrDefault(x => x.Amount == model.TopupInfo.TopUpAmount).RewardPoints;
			}
			if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				if (model.BundleInfo == null
							|| string.IsNullOrEmpty(model.BundleInfo.BundleId))
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
												_localizer["BundleInfoMissing"], ApiStatusCodes.BadRequest);
				}

				//Check Bundle Limit
				var bundlesResponse = await _accountRepo.GetBundlesHistory(accountDetails.AccountID);
				if (bundlesResponse.Count() >= 10)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
												_localizer["MaxNumberOfBundlesPurchased"], ApiStatusCodes.BundleLimitExceeded);
				}

				//Get Bundle details
				var bundleResponse = await _bundleRepo.GetBundleById(model.BundleInfo.BundleId, accountDetails.AccountID);
				if (bundleResponse == null)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
												_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
				}

				bundleDest = bundleResponse.Description.Replace(" ", "").Replace(",", "");
				bundleType = bundleResponse.BundleType;
				bundleRewardPoints = bundleResponse.RewardPoints;
				Currency = accountDetails.Currency;
				bundlePrice = Convert.ToDecimal(bundleResponse.TotalCostPence / 100, CultureInfo.InvariantCulture);

				if (bundleResponse.IsTrial
					&& bundleResponse.TrialId != null
					&& !(await _bundleRepo.IsBundlePurchasedPreviously(accountDetails.AccountID, bundleResponse.TrialId.ToString())))
				{
					isTrialBundle = true;
					var trialBundle = await _bundleRepo.GetBundleById(
						bundleResponse.TrialId.ToString(), accountDetails.AccountID);
					if (trialBundle == null)
					{
						return GenericApiResponse<CardPaymentResponseModel>.Failure(
												_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
					}
					bundleName = trialBundle.BrandedName;
					bundleDest = trialBundle.Description.Replace(" ", "").Replace(",", "");
					bundleType = trialBundle.BundleType;
					ChargeAmount = _pay360Config.TestPaymentAmount;//This is just test amount which will be refunded after successfull payment
					model.BundleInfo = new BundleInfo()
					{
						BundleId = bundleResponse.TrialId.ToString(),
						IsBundleAutoRenew = true//Autorenewal will be true for trial bundles so that background service can start primary bundle after expire
					};
				}
				else
				{
					bundleName = bundleResponse.BrandedName;
					bundleRewardPoints = bundleResponse.RewardPoints;
					ChargeAmount = bundleResponse.TotalCostPence / 100;
					if (bundleResponse.BundleType == BundleType.Monthly || bundleResponse.BundleType == BundleType.Welcome)
					{
						//Autorenewal will be true for montly and welcome bundles always
						model.BundleInfo.IsBundleAutoRenew = true;
					}
				}
				//TODO:Voucherify logic to handle discounts and promotions
				if (!string.IsNullOrEmpty(model.DiscountCode))
				{
					var discountRequest = new StackableDiscountRequest
					{
						DiscountCode = model.DiscountCode,
						DiscountCodeType = model.DiscountCodeType,
						Amount = bundlePrice,
						CheckoutType = CheckOutTypes.Bundle,
						PaymentMethod = PaymentMethods.Card,
						BundleRef = model.BundleInfo.BundleId,
					};
					var validationResult = await _voucherifyService.ValidateDiscount(discountRequest, msisdn, accountDetails.AccountID, new CustomerMetadata()
					{
						FirstInternationalTopup = isFirstInternationalTopup,
						FirstTopup = isFirstTopup,
						TransactionDone = !hasUserDoneTransaction,
					});
					if (validationResult?.Payload != null)
					{
						discountAmount = validationResult.Payload.DiscountAmount;
						ChargeAmount -= discountAmount;
					}
				}
			}
			else
			{
				if (model.TopupInfo == null || model.TopupInfo.TopUpAmount <= 0)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
											_localizer["TopupInfoMissing"], ApiStatusCodes.BadRequest);
				}
				ChargeAmount = model.TopupInfo.TopUpAmount;
				//TODO:Voucherify logic to handle discounts and promotions
				if (!string.IsNullOrEmpty(model.DiscountCode))
				{
					var discountRequest = new StackableDiscountRequest
					{
						DiscountCode = model.DiscountCode,
						DiscountCodeType = model.DiscountCodeType,
						CheckoutType = CheckOutTypes.TopUp,
						Amount = (decimal)model.TopupInfo.TopUpAmount,
						PaymentMethod = PaymentMethods.Card

					};
					var validationResult = await _voucherifyService.ValidateDiscount(discountRequest, msisdn, accountDetails.AccountID, new CustomerMetadata()
					{
						FirstInternationalTopup = isFirstInternationalTopup,
						FirstTopup = isFirstTopup,
						TransactionDone = !hasUserDoneTransaction,
					});
					if (validationResult?.Payload != null)
					{
						discountAmount = validationResult.Payload.DiscountAmount;
						ChargeAmount -= discountAmount;
					}
				}
			}

			var paymentrequest = await GeneratePay360PaymentRequest(
				new Pay360PaymentRequestData()
				{
					CustomerMsisdn = msisdn,
					ChargeAmount = ChargeAmount,
					DiscountAmount = discountAmount,
					CheckoutPaymentType = model.CheckoutType,
					BundleId = (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle ? model.BundleInfo.BundleId : ""),
					IpAddress = ipAddress,
					CustomerEmail = email,
					Currency = currency,
					Pay360PaymentType = Pay360PaymentType.Token,
					accountNumber = accountDetails.AccountID,
					CustomerUniqueRef = msisdn,
					CardToken = model.CardToken,
					SecurityCode = model.SecurityCode
				});

			//Don't do 3d secure process in case of trial bundle
			if (isTrialBundle)
			{
				paymentrequest.Pay360PaymentRequestToken.do3DSecure = false;
			}
			//TODO:Recurring payment if bundle renewal or auto topup is on
			if (model.BundleInfo?.IsBundleAutoRenew == true
				|| model.TopupInfo?.AutoTopupInfo.isActive == true)
			{
				paymentrequest.Pay360PaymentRequestToken.recurring = true;
			}
			var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.Token);

			//Save transaction
			var paymentTransactionId = await _paymentFullfillmentDL.InsertTransactionPaymentAsync(
				paymentrequest.Pay360PaymentRequestToken.basket,
				paymentrequest.Pay360PaymentRequestToken.transactionCurrency,
				paymentrequest.Pay360PaymentRequestToken.customerEmail,
				paymentrequest.Pay360PaymentRequestToken.productCode,
				paymentResponse != null && paymentResponse.Payload != null
										&& !string.IsNullOrEmpty(paymentResponse.Payload.transactionId) ?
				paymentResponse.Payload.transactionId : null,
				paymentrequest.Pay360PaymentRequestToken.customerMsisdn,
				TransactionsPaymentType.Card,
				0,
				isTrialBundle,
				model.DiscountCode,
				model.DiscountCodeType);

			//Handle Error Scenarios
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = true,
							Msisdn = msisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});


					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
				}
				else
				{
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							IsCard = true,
							Msisdn = msisdn,
							Amount = ChargeAmount.ToString(CultureInfo.InvariantCulture)
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(advertiserID, false, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					//Handle AppFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, false, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);
				}


				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId,
						false,
						null,
						paymentResponse == null
						? "Payment Service Not Responding - Null Response - Exist Customer"
						 : $"{paymentResponse.ErrorCode} - {paymentResponse.Message} - Exist Customer");

				return HandlePay360PaymentFailureResponse
					<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, model.CheckoutType);
			}
			if (paymentResponse.Payload.outcome.reasonCode == "U100") //3d Secure Scenario
			{
				//Set default card
				if (model.IsDefaultCard)
				{
					await _pay360Service.SetDefaultCard(msisdn, new SetDefaultCardUserRequest
					{
						CardToken = model.CardToken,
						CV2 = model.SecurityCode
					});
				}
				/*Make sure to encrypt url here
                 * Convert the hardcoded string to classs
                 * and Implement the class to query string convertsion method
                 */

				var secure3dType = paymentResponse.Payload.clientRedirect.type.ToLower().Contains("v2") ? "v2" : "v1";

				var AirshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();
				var returnUrlBuilder = new StringBuilder();
				returnUrlBuilder.Append($"{_inAppPageConfig.BaseUrl}/v2/Pay360/Resume3DTransaction")
					.Append($"?CheckoutType={(int)model.CheckoutType}")
					.Append($"&CustomerEmail={email}")
					.Append($"&CustomerMsisdn={msisdn}")
					.Append($"&Currency={currency}")
					.Append($"&BundleId={(model.CheckoutType == Models.Enums.CheckOutTypes.Bundle ? model.BundleInfo.BundleId : "")}")
					.Append($"&Secure3dType={secure3dType}")
					.Append($"&PTId={paymentTransactionId}")
					.Append($"&Ip={ipAddress}")
					.Append($"&advertiserID={advertiserID}")
					.Append($"&AirshipEventsDisable={AirshipEventsDisable}")
					.Append($"&IsDefaultCard={model.IsDefaultCard}")
					.Append($"&culture={_localizer["Locale"]}");

				if (!string.IsNullOrEmpty(model.DiscountCode))
				{
					returnUrlBuilder.Append($"&DiscountCode={model.DiscountCode}")
						.Append($"&DiscountCodeType={model.DiscountCodeType}");
				}

				if (model.AppsFlyerId != null)
				{
					returnUrlBuilder.Append($"&AppsFlyerId={model.AppsFlyerId}")
								 .Append($"&DeviceType={model.DeviceType}");
				}
				if (model.TopupInfo != null && model.TopupInfo.AutoTopupInfo != null)
				{
					returnUrlBuilder
						.Append($"&IsAutoTopUp={model.TopupInfo.AutoTopupInfo.isActive}")
								 .Append($"&AutoToupAmount={model.TopupInfo.AutoTopupInfo.amount}")
								 .Append($"&AutoTopupThreshold={model.TopupInfo.AutoTopupInfo.thresholdBalanceAmount}");
				}
				if (model.TopupInfo != null)
				{
					returnUrlBuilder.Append($"&TopupAmount={model.TopupInfo.TopUpAmount}");
				}
				if (model.BundleInfo != null)
				{
					returnUrlBuilder.Append($"&IsAutoRenewal={model.BundleInfo.IsBundleAutoRenew}");
				}
				if (model.UtmParamsInfo != null)
				{
					returnUrlBuilder.Append($"&UtmCampaign={model.UtmParamsInfo.utm_campaign}")
								 .Append($"&UtmMedium={model.UtmParamsInfo.utm_medium}")
								 .Append($"&UtmSource={model.UtmParamsInfo.utm_source}");
				}


				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
							paymentTransactionId, false, paymentResponse.Payload.transactionId);

				//Send Response
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
												new CardPaymentResponseModel()
												{
													threeDSecureData = new ThreeDSecureData()
													{
														pareq = paymentResponse.Payload.clientRedirect.pareq,
														redirectUrl = paymentResponse.Payload.clientRedirect.url,
														transactionId = paymentResponse.Payload.transactionId,
														returnUrl = returnUrlBuilder.ToString(),
														type = secure3dType,
														threeDSServerTransId = paymentResponse.Payload.clientRedirect.threeDSServerTransId
													}
												}, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);
			}
			else if (paymentResponse.Payload.outcome.reasonCode == "S100")
			{
				//Set default card
				if (model.IsDefaultCard)
				{
					await _pay360Service.SetDefaultCard(msisdn, new SetDefaultCardUserRequest
					{
						CardToken = model.CardToken,
						CV2 = model.SecurityCode
					});
				}
				if (!string.IsNullOrEmpty(model.DiscountCode))
				{
					//Redeem promotion
					if (model.CheckoutType == CheckOutTypes.TopUp)
					{
						var discountRequest = new StackableDiscountRequest
						{
							DiscountCode = model.DiscountCode,
							DiscountCodeType = model.DiscountCodeType,
							CheckoutType = CheckOutTypes.TopUp,
							Amount = (decimal)model.TopupInfo.TopUpAmount,
							PaymentMethod = PaymentMethods.Card,
						};
						redemptionResult = await _voucherifyService.RedeemDiscount(discountRequest, msisdn, accountDetails.AccountID, new CustomerMetadata()
						{
							FirstInternationalTopup = isFirstInternationalTopup,
							FirstTopup = isFirstTopup,
							TransactionDone = !hasUserDoneTransaction,
						});

					}
				}

				if (model.CheckoutType == CheckOutTypes.TopUp)
				{
					var topupPoints = Utility.CalculateTopupRewardPoints(model.TopupInfo.TopUpAmount, _voucherifyConfig);
					await _voucherifyService.PurchaseEvent(msisdn, VoucherifyEventsNames.Topup, new VoucherifyEventsMetadata
					{
						ChargeAmount = model.TopupInfo.TopUpAmount,
						Timestamp = DateTime.UtcNow,
						LoyaltyPoints = topupPoints
					});
				}
				if (model.CheckoutType == CheckOutTypes.Bundle)
				{
					if (bundleType == BundleType.Welcome)
					{
						await _voucherifyService.PurchaseEvent(msisdn, VoucherifyEventsNames.WelcomeBundle, new VoucherifyEventsMetadata
						{
							ChargeAmount = bundlePrice,
							Timestamp = DateTime.UtcNow,
							LoyaltyPoints = bundleRewardPoints
						});
					}
					if (bundleType == BundleType.PAYG)
					{
						await _voucherifyService.PurchaseEvent(msisdn, VoucherifyEventsNames.PayGBundle, new VoucherifyEventsMetadata
						{
							ChargeAmount = bundlePrice,
							Timestamp = DateTime.UtcNow,
							LoyaltyPoints = bundleRewardPoints
						});
					}
				}

				//Payment successfull
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, true);

				//fullfill
				await Pay360CardPaymentFullfillment(paymentResponse, msisdn, email, isTrialBundle, accountDetails.AccountID);

				//Get Updated User Balance
				var userBalance = await _accountRepo.GetUserAccountBalanceAsync(msisdn);

				var currencySymbol = _helperService.ToCurrencySymbol(currency);

				if (model.CheckoutType == CheckOutTypes.Bundle)
				{
					if (model.BundleInfo != null)
					{
						string cardMaskedPan = paymentResponse.Payload.recurring ? paymentResponse.Payload.maskedPan : null;
						string initialTransactionId = paymentResponse.Payload.recurring ? paymentResponse.Payload.transactionId : null;

						var autoRenewRes = await _bundleRepo.SetBundleAutoRenewalV2(
							model.BundleInfo.IsBundleAutoRenew,
							msisdn,
							accountDetails.AccountID,
							model.BundleInfo.BundleId,
							isTrialBundle,
							PaymentMethods.Card,
							cardMaskedPan,
							initialTransactionId,
							null);
						if (autoRenewRes.isValid && bundleType != BundleType.Welcome)
						{
							await _airShipService.HandleAutoRenew(
								msisdn, model.BundleInfo.IsBundleAutoRenew, bundleDest, bundleType);
						}
					}

					//Airship events
					await _airShipService.HandleBundleTagsAndEvents(new BundleInfoAirShip()
					{
						IsSuccess = true,
						Origination = msisdnOrigin,
						Destination = bundleDest,
						IsCard = true,
						Msisdn = msisdn,
						BundleType = bundleType,
						Amount = bundlePrice
					});

					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);
					//Handle Appflyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);

					//Refund payment if trial bundle
					if (isTrialBundle)
					{
						await _pay360Service.RefundFullPayment(
							new Models.Contracts.Request.RefundFullPaymentRequestModel()
							{
								transactionId = paymentResponse.Payload.transactionId
							});
					}

					return GenericApiResponse<CardPaymentResponseModel>.Success(
						new CardPaymentResponseModel()
						{
							CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
							IsRedeemedSuccess = redemptionResult != null && redemptionResult?.Payload?.RedemptionId != null,
							bundlePurchaseInfo = new BundlePurchaseInfo()
							{
								TransactionId = paymentResponse.Payload.transactionId,
								BundleAmount = isTrialBundle ? "0" : paymentResponse.Payload.transactionAmount,
								BundleName = bundleName,
								Msisdn = msisdn,
								Currency = currencySymbol,
								Destination = bundleDest,
								Type = bundleType,
								RewardPoints = bundleRewardPoints
							},
							customerMsisdn = msisdn,
							transactionId = paymentResponse.Payload.transactionId
						}, _localizer["BundlePurchasedSuccessfully"]);
				}
				else
				{
					if (model.TopupInfo.AutoTopupInfo != null)
					{
						var autoTopupResult = await _autoTopupDL.Set(new AutoTopupDetail
						{
							Topup = model.TopupInfo.AutoTopupInfo.amount,
							ThresHold = model.TopupInfo.AutoTopupInfo.thresholdBalanceAmount,
							Msisdn = msisdn,
							Currency = currency,
							Status = model.TopupInfo.AutoTopupInfo.isActive,
							PaymentMethod = PaymentMethods.Card,
							CardMaskedPAN = paymentResponse.Payload.recurring ? paymentResponse.Payload.maskedPan : null,
							CardInitialTransactionId = paymentResponse.Payload.recurring ? paymentResponse.Payload.transactionId : null,
							PaypalSubscriptionId = null,
						});
						if (autoTopupResult > 0)
						{
							await _airShipService.HandleAutoTopup(msisdn, model.TopupInfo.AutoTopupInfo.isActive);
						}
					}

					//Airship events
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = true,
							Origination = msisdnOrigin,
							IsCard = true,
							Msisdn = msisdn,
							Amount = ChargeAmount.ToString(CultureInfo.InvariantCulture)
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(advertiserID, true, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, true, true, Convert.ToDecimal(ChargeAmount.ToString(CultureInfo.InvariantCulture)), Currency, msisdnOrigin);

					return GenericApiResponse<CardPaymentResponseModel>.Success(
						new CardPaymentResponseModel()
						{
							CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
							IsRedeemedSuccess = redemptionResult != null && redemptionResult?.Payload?.RedemptionId != null,
							topupInfo = new TopupInfo()
							{
								TopupAmount = paymentResponse.Payload.transactionAmount,
								Msisdn = msisdn,
								TransactionId = paymentResponse.Payload.transactionId,
								Currency = currencySymbol,
								NewBalance = userBalance.Balance,
								IsFirstTopup = isFirstTopup,
								RewardPoints = topupRewardPoints
							},
							customerMsisdn = msisdn,
							transactionId = paymentResponse.Payload.transactionId
						}, _localizer["TopUpSuccessful", paymentResponse.Payload.transactionAmount]);
				}
			}

			return GenericApiResponse<CardPaymentResponseModel>.Failure(
				null, _localizer["PaymentServiceNotResponding"], ApiStatusCodes.PaymentServiceError);
		}
		public async Task<GenericApiResponse<CardPaymentResponseModel>> Resume3DTransactionV2Async(Resume3DPaymentRequest request, Resume3DPaymentDataRequestV2 data)
		{
			DeviceType deviceType = (DeviceType)data.DeviceType;
			string bundleName = "";
			string bundleDest = "";
			string Currency = "";
			decimal bundlePrice = 0;
			decimal discountAmount = 0;
			int bundleRewardPoints = 0;
			int topupRewardPoints = 0;
			GenericApiResponse<StackableDiscountResponse> redemptionResult = null;
			var msisdnOrigin = _helperService.GetCountryCode(data.CustomerMsisdn);
			BundleType bundleType = BundleType.PAYG;
			bool isTrialBundle = false;

			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(
											_helperService.GetSipUserName(data.CustomerMsisdn));

			var hasUserDoneTransaction = await _accountRepo.IsNewUser(data.CustomerMsisdn);
			var isFirstTopup = await _accountRepo.IsFirstTopUp(data.CustomerMsisdn);
			var isFirstInternationalTopup = await _attRepo.IsFirstATTTransaction(accountDetails.AccountID);

			GenericPay360ApiResponse<Pay360PaymentResponse> paymentResponse;
			if (data.Secure3dType.Equals("v1", StringComparison.InvariantCultureIgnoreCase))
			{
				paymentResponse = await _pay360Service.Resume3DV1Transaction(
					new Pay360Resume3DRequest()
					{
						pareq = request.PaRes,
						pay360TransactionId = request.MD,
						customerEmail = data.CustomerEmail
					});
			}
			else
			{
				paymentResponse = await _pay360Service.Resume3DV2Transaction(
					new Pay360Resume3DRequest()
					{
						pay360TransactionId = request.MD,
						customerEmail = data.CustomerEmail,
						overallStatus = request.OverallStatus
					});
			}

			// Cannot resume again scenario 
			if (paymentResponse != null
				&& paymentResponse.ErrorCode > 0
				&& (paymentResponse.Pay360ApiCode.Equals("V107")))
			{
				return HandlePay360PaymentFailureResponse<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, data.CheckoutType);
			}




			if (data.CheckoutType == Models.Enums.CheckOutTypes.TopUp)
			{
				topupRewardPoints = _pay360Config.TopupAmounts.FirstOrDefault(x => x.Amount == data.TopupAmount).RewardPoints;
			}
			if (data.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				Bundles bundleInfo = await _bundleRepo.GetBundleById(data.BundleId, accountDetails.AccountID);
				bundleDest = bundleInfo.Description.Replace(" ", "").Replace(",", "");
				bundleType = bundleInfo.BundleType;
				Currency = accountDetails.Currency;
				bundleRewardPoints = bundleInfo.RewardPoints;
				bundleName = bundleInfo.BrandedName;
				bundlePrice = Convert.ToDecimal(bundleInfo.TotalCostPence / 100, CultureInfo.InvariantCulture);
				if (bundleInfo.IsTrial && bundleInfo.TrialId != null)
					isTrialBundle = bundleInfo.IsTrial;
			}

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				if (data.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = true,
							Msisdn = data.CustomerMsisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});


					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(data.advertiserID, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(data.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, true, bundlePrice, Currency);
				}
				else
				{
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							IsCard = true,
							Msisdn = data.CustomerMsisdn,
							Amount = ""
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(data.advertiserID, false, true, 0, Currency, msisdnOrigin);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(data.AppsFlyerId, deviceType, false, true, 0, Currency, msisdnOrigin);
				}

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
					data.PTId,
					false,
					null,
					paymentResponse == null ? "Payment Service Not Responding - Resume" : paymentResponse.ErrorCode + " - " + paymentResponse.Message + " - Resume");

				return HandlePay360PaymentFailureResponse
						 <Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, data.CheckoutType);
			}

			//Successful payment
			await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(data.PTId, true);

			if (data.CheckoutType == CheckOutTypes.TopUp && !string.IsNullOrEmpty(data.DiscountCode))
			{
				var discountRequest = new StackableDiscountRequest
				{
					DiscountCode = data.DiscountCode,
					DiscountCodeType = data.DiscountCodeType,
					CheckoutType = CheckOutTypes.TopUp,
					Amount = data.TopupAmount,
					PaymentMethod = PaymentMethods.Card,
				};
				redemptionResult = await _voucherifyService.RedeemDiscount(discountRequest, data.CustomerMsisdn, accountDetails.AccountID, new CustomerMetadata()
				{
					FirstInternationalTopup = isFirstInternationalTopup,
					FirstTopup = isFirstTopup,
					TransactionDone = !hasUserDoneTransaction,
				});
				discountAmount = redemptionResult?.Payload?.Order?.DiscountAmount != null ? Convert.ToDecimal(redemptionResult.Payload.Order.DiscountAmount) : 0;
			}
			if (data.CheckoutType == CheckOutTypes.TopUp)
			{
				var topupPoints = Utility.CalculateTopupRewardPoints(data.TopupAmount, _voucherifyConfig);
				await _voucherifyService.PurchaseEvent(data.CustomerMsisdn, VoucherifyEventsNames.Topup, new VoucherifyEventsMetadata
				{
					ChargeAmount = data.TopupAmount,
					Timestamp = DateTime.UtcNow,
					LoyaltyPoints = topupPoints
				});
			}
			if (data.CheckoutType == CheckOutTypes.Bundle)
			{
				if (bundleType == BundleType.Welcome)
				{

					await _voucherifyService.PurchaseEvent(data.CustomerMsisdn, VoucherifyEventsNames.WelcomeBundle, new VoucherifyEventsMetadata
					{
						ChargeAmount = bundlePrice,
						Timestamp = DateTime.UtcNow,
						LoyaltyPoints = bundleRewardPoints
					});
				}
				if (bundleType == BundleType.PAYG)
				{
					await _voucherifyService.PurchaseEvent(data.CustomerMsisdn, VoucherifyEventsNames.PayGBundle, new VoucherifyEventsMetadata
					{
						ChargeAmount = bundlePrice,
						Timestamp = DateTime.UtcNow,
						LoyaltyPoints = bundleRewardPoints
					});
				}
			}
			//Fulfillment
			await Pay360CardPaymentFullfillment(paymentResponse, data.CustomerMsisdn, data.CustomerEmail, isTrialBundle, accountDetails.AccountID);

			//GetUserBalance
			var userBalance = await _accountRepo.GetUserAccountBalanceAsync(data.CustomerMsisdn);

			var currencySymbol = _helperService.ToCurrencySymbol(data.Currency);
			if (data.SaveCard)
			{
				await _airShipService.AddNamedUserTags(
					new NamedUserTagsRequest()
					{
						NamedUser = data.CustomerMsisdn,
						Tags = new List<string>() { "addcard_app" },
						TagGroup = _airShipConfig.ActivityTagGroupName
					});
			}
			if (data.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				//Refund payment if trial bundle
				if (isTrialBundle)
				{
					await _pay360Service.RefundFullPayment(
						new Models.Contracts.Request.RefundFullPaymentRequestModel()
						{
							transactionId = paymentResponse.Payload.transactionId,
						});
				}

				//Set Bundle Auto Renewal
				string cardMaskedPan = paymentResponse.Payload.recurring ? paymentResponse.Payload.maskedPan : null;
				string initialTransactionId = paymentResponse.Payload.recurring ? paymentResponse.Payload.transactionId : null;

				var autoRenewResp = await _bundleRepo.SetBundleAutoRenewalV2(
					data.IsAutoRenewal,
					data.CustomerMsisdn,
					accountDetails.AccountID,
					data.BundleId,
					   false,
						 PaymentMethods.Card,
						   cardMaskedPan,
						   initialTransactionId,
							null);

				if (bundleType != BundleType.Welcome && autoRenewResp.isValid)
				{
					await _airShipService.HandleAutoRenew(data.CustomerMsisdn, data.IsAutoRenewal, bundleDest, bundleType);
				}

				//Airship event
				await _airShipService.HandleBundleTagsAndEvents(
					new BundleInfoAirShip()
					{
						IsSuccess = true,
						Origination = msisdnOrigin,
						Destination = bundleDest,
						IsCard = true,
						Msisdn = data.CustomerMsisdn,
						BundleType = bundleType,
						Amount = bundlePrice
					});

				//Handle FaceBook Events
				await _faceBookService.HandleBundlePurchaseEvents(data.advertiserID, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);
				//Handle AppsFlyer Events
				await _appsFlyerService.HandleBundlePurchaseEvents(data.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, true, true, bundlePrice, Currency);

				return GenericApiResponse<CardPaymentResponseModel>.Success(
					new CardPaymentResponseModel()
					{
						CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
						IsRedeemedSuccess = redemptionResult?.Payload?.RedemptionId != null,
						bundlePurchaseInfo = new BundlePurchaseInfo()
						{
							TransactionId = paymentResponse.Payload.transactionId,
							BundleAmount = isTrialBundle ? "0" : paymentResponse.Payload.transactionAmount,
							BundleName = bundleName,
							Msisdn = data.CustomerMsisdn,
							Currency = currencySymbol,
							Destination = bundleDest,
							Type = bundleType,
							RewardPoints = bundleRewardPoints
						},
						customerMsisdn = data.CustomerMsisdn,
						transactionId = paymentResponse.Payload.transactionId
					}, _localizer["BundlePurchasedSuccessfully"]);
			}
			else
			{
				//Set auto top-up
				if (data.AutoTopupThreshold > 0 && data.AutoToupAmount > 0)
				{
					var autoTopupResult = await _autoTopupDL.Set(new AutoTopupDetail
					{
						Topup = data.AutoToupAmount,
						ThresHold = data.AutoTopupThreshold,
						Msisdn = data.CustomerMsisdn,
						Currency = data.Currency,
						Status = data.IsAutoTopUp,
						PaymentMethod = PaymentMethods.Card,
						CardMaskedPAN = paymentResponse.Payload.recurring ? paymentResponse.Payload.maskedPan : null,
						CardInitialTransactionId = paymentResponse.Payload.recurring ? paymentResponse.Payload.transactionId : null,
						PaypalSubscriptionId = null,
					});
					if (autoTopupResult > 0)
					{
						await _airShipService.HandleAutoTopup(data.CustomerMsisdn, data.IsAutoTopUp);
					}
				}

				//Airship Event
				await _airShipService.HandleTopupTagsAndEvents(
					 new TopupInfoAirship()
					 {
						 IsSuccess = true,
						 Origination = msisdnOrigin,
						 IsCard = true,
						 Msisdn = data.CustomerMsisdn,
						 Amount = paymentResponse.Payload.transactionAmount
					 });

				//Handle FaceBook Events
				await _faceBookService.HandleTopupEvents(data.advertiserID, true, true, Convert.ToDecimal(paymentResponse.Payload.transactionAmount), Currency, msisdnOrigin);

				//Handle AppsFlyer Events
				await _appsFlyerService.HandleTopupEvents(data.AppsFlyerId, deviceType, true, true, Convert.ToDecimal(paymentResponse.Payload.transactionAmount), Currency, msisdnOrigin);

				return GenericApiResponse<CardPaymentResponseModel>.Success(
					new CardPaymentResponseModel()
					{
						CampaignName = redemptionResult?.Payload != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
						IsRedeemedSuccess = redemptionResult?.Payload?.RedemptionId != null,
						topupInfo = new TopupInfo()
						{
							TopupAmount = paymentResponse.Payload.transactionAmount,
							Msisdn = data.CustomerMsisdn,
							TransactionId = paymentResponse.Payload.transactionId,
							Currency = currencySymbol,
							NewBalance = userBalance.Balance,
							IsFirstTopup = isFirstTopup,
							RewardPoints = topupRewardPoints
						},
						customerMsisdn = data.CustomerMsisdn,
						transactionId = paymentResponse.Payload.transactionId
					}, _localizer["TopUpSuccessful", paymentResponse.Payload.transactionAmount]);
			}
		}


		private async Task<GenericApiResponse<TransferByCardResponseModel>> HandleTransferByCardResponseV2(
			Pay360PaymentResponse model,
			dynamic request,
			decimal amountToCharge,
			decimal discountAmount,
			string fromMsisdn,
			string toMsisdn,
			string currency,
			string accountId,
			string ipAddress,
			string email,
			string advertiserID,
			string AppsFlyerId,
			DeviceType DeviceType,
			bool IsTransferRequest,
			decimal fromAmount,
			bool isFirstInternationalTopup,
			bool isFirstTopup,
			bool hasUserDoneTransaction,
			decimal totalServiceFee,
			decimal serviceFee,
			decimal serviceFeeDiscount)
		{
			if (request is TransferByNewCustomerRequestModelV2)
			{
				request = request as TransferByNewCustomerRequestModelV2;
			}
			if (request is TransferByExistingCustomerRequestModelV2)
			{
				request = request as TransferByExistingCustomerRequestModelV2;
			}
			//Get Product Details for international topup
			DBProduct product = await _attRepo.GetProductByNowtelTransactionReference(request.nowtelRef, request.product);
			var transactionLog = await _attRepo.GetTransactionLog(request.nowtelRef, request.product);
			GenericApiResponse<StackableDiscountResponse> redemptionResult = null;

			if (model.outcome.reasonCode == "U100") //3d Secure Scenario
			{
				var threeDsV = model.clientRedirect.type.Contains(
						"V2", StringComparison.InvariantCultureIgnoreCase) ? "V2" : "V1";
				var airshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();
				//Send Response
				var returnUrlBuilder = new StringBuilder();
				returnUrlBuilder.Append(_inAppPageConfig.BaseUrl).Append("/v2/transfer/Resume3DTransaction?")
							 .Append("NowtelRef=").Append(request.nowtelRef)
							 .Append("&Product=").Append(request.product)
							 .Append("&OperatorId=").Append(request.operatorId)
							 .Append("&CustomerEmail=").Append(email)
							 .Append("&ThreeDsV=").Append(threeDsV)
							 .Append("&Msisdn=").Append(fromMsisdn)
							 .Append("&Account=").Append(accountId)
							 .Append("&IpAddress=").Append(ipAddress)
							 .Append("&advertiserID=").Append(advertiserID)
							 .Append("&AirshipEventsDisable=").Append(airshipEventsDisable)
							 .Append("&IsTransferRequest=").Append(IsTransferRequest)
							 .Append("&culture=").Append(_localizer["Locale"]);

				if (!string.IsNullOrEmpty(request.DiscountCode))
				{
					returnUrlBuilder.Append("&DiscountCode=").Append(request.DiscountCode)
						.Append("&DiscountCodeType=").Append(request.DiscountCodeType);
				}

				if (AppsFlyerId != null)
				{
					returnUrlBuilder.Append($"&AppsFlyerId=").Append(AppsFlyerId)
								 .Append($"&DeviceType=").Append(DeviceType);
				}
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
												new TransferByCardResponseModel()
												{
													threeDSecureData = new ThreeDSecureData()
													{
														pareq = model.clientRedirect.pareq,
														type = model.clientRedirect.type,
														redirectUrl = model.clientRedirect.url,
														threeDSServerTransId = model.clientRedirect.threeDSServerTransId,
														transactionId = model.transactionId,
														returnUrl = returnUrlBuilder.ToString()
													}
												}, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

			}
			else if (model.outcome.reasonCode.Equals("S100"))//Non 3d secure
			{
				//Transfer balance
				var executeTransResponse = await _attService.TransferBalance(
					new TransFerTotransferConfirm()
					{
						nowtelTransactionReference = request.nowtelRef,
						product = request.product,
						operatorid = request.operatorId,
						messageToRecipient = ""
					}, fromMsisdn);

				if (executeTransResponse == null || executeTransResponse.errorCode > 0)
				{
					//Save ATT transaction
					await _attRepo.SaveTransactionAsync(
						new DBTransferTransaction()
						{
							AccountId = accountId,
							ClientCurrecny = product.fromCurrency,
							CountryCode = _helperService.GetCountryCode(product.tomsisdn),
							FromMsisdn = product.fromMsisdn,
							ToMsisdn = product.tomsisdn,
							ItemPrice = fromAmount,
							TotalPrice = amountToCharge,
							Discount = discountAmount,
							ServiceFee = serviceFee,
							ServiceFeeDiscount = serviceFeeDiscount,
							TotalServiceFee = totalServiceFee,
							DiscountCode = request.DiscountCode,
							DiscountCodeType = request.DiscountCodeType,
							NowtelRef = request.nowtelRef,
							OperatorCountryName = product.operatorCountryName,
							OperatorLogoUrl = product.operatorLogoUrl,
							OperatorName = product.operatorName,
							PaymentErrorMsg = null,
							TransferErrorMsg = executeTransResponse == null
												? "Transfer service not responding" : executeTransResponse?.message,
							PaymentRef = model.transactionId,
							TransferRef = null,
							PaymentTypeId = InternationalTopupPaymentType.Card,
							StatusId = TransferTransactionStatus.Failure,
							Product = Convert.ToDecimal(request.product, CultureInfo.InvariantCulture),
							ReceiverCurrecny = product.toCurrency
						});

					//cancel catpured payment
					if (_pay360Config.TransferIsAuthorization)
					{
						await _pay360Service.CancelTransaction(
							new CancelTransactionRequestModel()
							{
								transactionId = model.transactionId
							});
					}
					_logger.Debug($"Class=> Payment_BL, Method=> HandleTransferByCardResponse, Message=>Balance transfer failed, FromMsisdn=>{fromMsisdn}, NowTelRef=>{request.nowtelRef},Product=>{request.product},Amount=>{product.CustomerChargeValue}");
					PrepareUpdateTransactionLog(transactionLog, discountAmount, 2, "Balance transfer failed");
					await _attRepo.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(
								null, _localizer["BalanceTransferFailed"], ApiStatusCodes.UnSuccessful);
				}
				var fromMsisdnCode = _helperService.GetCountryCode(fromMsisdn);
				var toMsisdnCode = _helperService.GetCountryCode(toMsisdn);

				//capture payment
				var isCapturePaymentSuccess = true;
				if (_pay360Config.TransferIsAuthorization)
				{
					string captureFailedMessage = $"Payment capture failed==> Payment TransactionId:{model.transactionId} " +
												  $"Transfer TransactionId:{executeTransResponse.reference}";
					try
					{
						var captureResponse = await _pay360Service.CaptureTransaction(
							new CaptureTransactionRequestModel()
							{
								transactionId = model.transactionId
							});
						if (captureResponse == null || captureResponse.ErrorCode > 0)
						{
							isCapturePaymentSuccess = false;
							await _emailService.SendEmail(
								_pay360Config.PaymentCaptureFailureEmail,
								captureFailedMessage,
								false,
								"Capture Failed-THA-App-" + model.transactionId);
							_logger.Error($"Class=>Payment_BL, Method=> HandleTransferByCardResponse,Message=>Capture transaction failed, {captureFailedMessage}");
						}
						else
						{
							isCapturePaymentSuccess = true;
						}
					}
					catch (Exception ex)
					{
						isCapturePaymentSuccess = false;
						await _emailService.SendEmail(
							_pay360Config.PaymentCaptureFailureEmail,
							captureFailedMessage + "-" + ex.Message,
							false,
							"Capture Failed-THA-App-" + model.transactionId);
						_logger.Error(ex, $"Class=>Payment_BL, Method=> HandleTransferByCardResponse,Message=>Capture transaction failed, {captureFailedMessage}");
					}
				}

				if (!string.IsNullOrEmpty(request.DiscountCode))
				{
					redemptionResult = await _voucherifyService.RedeemDiscount(new StackableDiscountRequest
					{
						Amount = fromAmount,
						CheckoutType = CheckOutTypes.Transfer,
						DiscountCode = request.DiscountCode,
						DiscountCodeType = request.DiscountCodeType,
						PaymentMethod = PaymentMethods.Card,
						DestinationCountryISOCode = toMsisdnCode,
						Operator = product.operatorName
					}, fromMsisdn, accountId, new CustomerMetadata()
					{
						FirstInternationalTopup = isFirstInternationalTopup,
						FirstTopup = isFirstTopup,
						TransactionDone = !hasUserDoneTransaction,
					});
				}
				var internationalTopupPoints = Utility.CalculateInternationalTopupRewardPointsRange(fromAmount, _voucherifyConfig.LoyaltyEarningRules.International);
				await _voucherifyService.PurchaseEvent(product.fromMsisdn, string.Format(VoucherifyEventsNames.InternationalTopup, internationalTopupPoints), new VoucherifyEventsMetadata { ChargeAmount = Convert.ToDecimal(product.CustomerChargeValue), Timestamp = DateTime.UtcNow, LoyaltyPoints = internationalTopupPoints });

				//Airship events
				await _airShipService.HandleIntTopupTagsAndEvents(
					 new IntTopupInfoAirShip()
					 {
						 IsSuccess = true,
						 IsCard = true,
						 Msisdn = fromMsisdn,
						 Destination = toMsisdnCode,
						 Origination = fromMsisdnCode,
						 Amount = amountToCharge,
						 IsTransferRequest = IsTransferRequest
					 });

				//Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(advertiserID, fromMsisdnCode, toMsisdnCode, true, true, amountToCharge, IsTransferRequest);

				//Handle FaceBook Events
				await _appsFlyerService.HandleIntTopupEvents(AppsFlyerId, DeviceType, fromMsisdnCode, toMsisdnCode, true, true, amountToCharge, null, IsTransferRequest);

				//Save Att transaction
				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = accountId,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = fromAmount,
						TotalPrice = amountToCharge,
						Discount = discountAmount,
						ServiceFee = serviceFee,
						ServiceFeeDiscount = serviceFeeDiscount,
						TotalServiceFee = totalServiceFee,
						DiscountCode = request.DiscountCode,
						DiscountCodeType = request.DiscountCodeType,
						NowtelRef = request.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = isCapturePaymentSuccess ? null : "Payment capture failed",
						TransferErrorMsg = null,
						PaymentRef = model.transactionId,
						TransferRef = executeTransResponse.reference,
						PaymentTypeId = InternationalTopupPaymentType.Card,
						StatusId = TransferTransactionStatus.Success,
						Product = Convert.ToDecimal(request.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency
					});

				var userProfile = await _accountRepo.GetUserProfile(fromMsisdn);
				if (!string.IsNullOrEmpty(userProfile?.Data?.email))
				{
					await SendInternationalTopupPaymentReceiptAsync(userProfile.Data.email, product, userProfile.Data, "Card", totalServiceFee, discountAmount, request.DiscountCode, 0, executeTransResponse.reference, executeTransResponse.pinCode);
				}

				PrepareUpdateTransactionLog(transactionLog, discountAmount, 1, "Success");
				await _attRepo.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Success(
					new TransferByCardResponseModel()
					{
						CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
						IsRedeemedSuccess = redemptionResult?.Payload?.RedemptionId != null,
						intTopupInfo = new InternationalTopupInfo()
						{
							TopupAmount = amountToCharge.ToString(CultureInfo.InvariantCulture),
							Msisdn = fromMsisdn,
							TransactionId = model.transactionId,
							Currency = _helperService.ToCurrencySymbol(currency),
							CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
							IsRedeemedSuccess = redemptionResult?.Payload?.RedemptionId != null,
							FromAmount = fromAmount,
							IsFirstInternationalTopup = isFirstInternationalTopup
						},
						transferData = new TransferData
						{
							toMsisdn = product.tomsisdn,
						},
						IsFirstInternationalTopup = isFirstInternationalTopup,
						FromAmount = fromAmount
					}, _localizer["InternationalTopupSuccessfull"]);
			}
			else
			{
				_logger.Debug($"Class=> Payment_BL, Method=> HandleTransferByCardResponse, Message=> Payment Error, FromMsisdn=>{fromMsisdn}, NowTelRef=>{request.nowtelRef},Product=>{request.product},Amount=>{product.CustomerChargeValue}, Response=>{JsonConvert.SerializeObject(model)}");
				PrepareUpdateTransactionLog(transactionLog, discountAmount, 2, "Payment Error");
				await _attRepo.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
					null, _localizer["BalanceTransferFailed"], ApiStatusCodes.PaymentServiceError);
			}
		}

		#endregion

		#region Card Payments Transfer Credit
		public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByNewCardV2Async(
							  TransferByNewCustomerRequestModelV2 model, string currency, string ipAddress, string msisdn, string emailAddress, string advertiserID)
		{
			var transactionLog = await _attRepo.GetTransactionLog(model.nowtelRef, model.product);
			if (transactionLog is null)
			{
				transactionLog = await PrepareTransactionLogAsync(model.nowtelRef, model.product, 0);
				await _attRepo.CreateTransactionLogAsync(transactionLog);
			}
			var product = await _attRepo.GetProductByNowtelTransactionReference(model.nowtelRef, model.product);
			if (product == null || !float.TryParse(product.CustomerChargeValue, out var productPrice) || productPrice <= 0)
			{
				_logger.Warning($"Class=>Payment_BL, Method=> TransferByNewCardAsync, Message=>No product available for destination, NowTelRef=>{model.nowtelRef},Product=>{model.product}");
				PrepareUpdateTransactionLog(transactionLog, 0, 2, "No product available for destination");
				await _attRepo.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
				   _localizer["NoProductAvailableForDestination"],
				   ApiStatusCodes.BadRequest);
			}

			var msisdnOrigin = _helperService.GetCountryCode(product.fromMsisdn);
			var msisdnDest = _helperService.GetCountryCode(product.tomsisdn);
			var chargeAmount = Convert.ToDecimal(product.CustomerChargeValue);
			var productAmount = decimal.Parse(product.fromAmount, CultureInfo.InvariantCulture);
			//calcualte service fee
			(decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(msisdnOrigin, msisdnDest, currency, productAmount);
			//deduct service fee from charged amount
			chargeAmount += totalServiceFee;
			decimal discountAmount = 0;
			DeviceType deviceType = (DeviceType)model.DeviceType;

			var custValidate = await _attRepo.ValidateNowtelCustomerNew(
				  msisdn,
				  model.nowtelRef,
				  model.product,
				  chargeAmount);

			if (custValidate.isAllowed != 1)
			{
				_logger.Warning($"Class=>Payment_BL, Method=> TransferByNewCardAsync, Message=>Balance transfer failed, FromMsisdn=>{msisdn}, NowTelRef=>{model.nowtelRef},Product=>{model.product},Amount=>{product.CustomerChargeValue}");
				PrepareUpdateTransactionLog(transactionLog, 0, 2, "Balance transfer failed");
				await _attRepo.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
							_localizer["BalanceTransferFailed"], ApiStatusCodes.BadRequest);
			}

			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));

			var hasUserDoneTransaction = await _accountRepo.IsNewUser(msisdn);
			var isFirstTopup = await _accountRepo.IsFirstTopUp(msisdn);
			var isFirstInternationalTopup = await _attRepo.IsFirstATTTransaction(accountDetails.AccountID);

			if (string.IsNullOrEmpty(emailAddress))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						emailAddress = userInfo.Data.email.Trim();
				}
			}
			//TODO:Voucherify logic to handle discounts and promotions
			if (!string.IsNullOrEmpty(model.DiscountCode))
			{
				var discountRequest = new StackableDiscountRequest
				{
					DiscountCode = model.DiscountCode,
					DiscountCodeType = model.DiscountCodeType,
					Amount = productAmount,
					CheckoutType = CheckOutTypes.Transfer,
					PaymentMethod = PaymentMethods.Card,
					DestinationCountryISOCode = msisdnDest,
					Operator = product.operatorName
				};
				var validationResult = await _voucherifyService.ValidateDiscount(discountRequest, msisdn, accountDetails.AccountID, new CustomerMetadata()
				{
					FirstInternationalTopup = isFirstInternationalTopup,
					FirstTopup = isFirstTopup,
					TransactionDone = !hasUserDoneTransaction,
				});
				if (validationResult?.Payload != null)
				{
					discountAmount = validationResult.Payload.DiscountAmount;
					chargeAmount -= discountAmount;
				}
			}
			var paymentResponse = await _pay360Service.Pay360Payment(
				await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
				{
					CustomerUniqueRef = msisdn,
					CustomerMsisdn = msisdn,
					ChargeAmount = chargeAmount,
					DiscountAmount = discountAmount,
					IpAddress = ipAddress,
					Currency = currency,
					toMsisdn = product.tomsisdn,
					CustomerEmail = emailAddress,
					Pay360PaymentType = Pay360PaymentType.New,
					CustomerAddressData = new AddressData()
					{
						AddressL1 = model.billingAddressData.AddressL1,
						AddressL2 = model.billingAddressData.AddressL2,
						AddressL3 = model.billingAddressData.AddressL3,
						AddressL4 = model.billingAddressData.AddressL4,
						PostCode = model.billingAddressData.PostCode,
						City = model.billingAddressData.City,
						Region = model.billingAddressData.Region,
						CountryCode = model.billingAddressData.CountryCode
					},
					CustomerCardData = new CardData()
					{
						CardNumber = model.cardData.CardNumber,
						NameOnCard = model.cardData.NameOnCard,
						SecurityCode = model.cardData.SecurityCode,
						ExpiryDate = model.cardData.ExpiryDate
					},
					ShouldSaveCard = model.cardData.ShouldSaveCard,
					IsDefaultCard = model.cardData.IsDefaultCard,
					accountNumber = accountDetails.AccountID,
					CheckoutPaymentType = Models.Enums.CheckOutTypes.Transfer
				}),
				Pay360PaymentType.New);

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
					new IntTopupInfoAirShip()
					{
						IsTransferRequest = model.IsTransferRequest,
						IsSuccess = false,
						Origination = msisdnOrigin,
						Destination = msisdnDest,
						IsCard = true,
						Msisdn = msisdn,
						Amount = chargeAmount,
					});


				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(advertiserID, msisdnOrigin, msisdnDest, false, true, Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture), model.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnOrigin, msisdnDest, false, true, Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture), ipAddress = null, model.IsTransferRequest);

				//Save transaction
				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = accountDetails.AccountID,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = productAmount,
						TotalPrice = chargeAmount,
						Discount = discountAmount,
						ServiceFee = serviceFee,
						ServiceFeeDiscount = serviceFeeDiscount,
						TotalServiceFee = totalServiceFee,
						DiscountCode = model.DiscountCode,
						DiscountCodeType = model.DiscountCodeType,
						NowtelRef = model.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = paymentResponse == null
									? "Payment service not responding" : paymentResponse.Message,
						TransferErrorMsg = null,
						PaymentRef = null,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Card,
						StatusId = TransferTransactionStatus.Failure,
						Product = Convert.ToDecimal(model.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency
					});
				PrepareUpdateTransactionLog(transactionLog, 0, 2, paymentResponse == null ? "Payment service not responding" : paymentResponse.Message);
				await _attRepo.UpdateTransactionLog(transactionLog);
				return HandlePay360PaymentFailureResponse<Pay360PaymentResponse, TransferByCardResponseModel>(paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}

			return await HandleTransferByCardResponseV2(
							paymentResponse.Payload,
							model,
							chargeAmount,
							discountAmount,
							product.fromMsisdn,
							product.tomsisdn,
							currency,
							accountDetails.AccountID,
							ipAddress,
							emailAddress,
							advertiserID,
							model.AppsFlyerId,
							deviceType,
							model.IsTransferRequest,
							productAmount,
							isFirstInternationalTopup,
							isFirstTopup,
							hasUserDoneTransaction,
							totalServiceFee, serviceFee, serviceFeeDiscount);
		}

		public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByExistingCardV2Async(
							  TransferByExistingCustomerRequestModelV2 model, string currency, string ipAddress, string msisdn, string emailAddress, string advertiserID)
		{
			var product = await _attRepo.GetProductByNowtelTransactionReference(model.nowtelRef, model.product);
			if (product == null || !float.TryParse(product.CustomerChargeValue, out var productPrice) || productPrice <= 0)
			{
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
				   _localizer["NoProductAvailableForDestination"],
				   ApiStatusCodes.BadRequest);
			}
			var transactionLog = await _attRepo.GetTransactionLog(model.nowtelRef, model.product);
			if (transactionLog is null)
			{
				transactionLog = await PrepareTransactionLogAsync(model.nowtelRef, model.product, 0);
				await _attRepo.CreateTransactionLogAsync(transactionLog);
			}
			var msisdnOrigin = _helperService.GetCountryCode(product.fromMsisdn);
			var msisdnDest = _helperService.GetCountryCode(product.tomsisdn);

			DeviceType deviceType = (DeviceType)model.DeviceType;

			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));

			var hasUserDoneTransaction = await _accountRepo.IsNewUser(msisdn);
			var isFirstTopup = await _accountRepo.IsFirstTopUp(msisdn);
			var isFirstInternationalTopup = await _attRepo.IsFirstATTTransaction(accountDetails.AccountID);

			var custValidate = await _attRepo.ValidateNowtelCustomerNew(
				  msisdn,
				  model.nowtelRef,
				  model.product,
				  Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture));
			if (custValidate.isAllowed != 1)
			{
				_logger.Information($"Class=>Payment_BL, Method=>TransferByExistingCardAsync, Message=>Unable to validate nowtel customer, FromMsisdn=>{msisdn},NowtelRef=>{model.nowtelRef}, Product=>{model.product}, Amount=>{product.CustomerChargeValue}");
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Unable to validate nowtel customer");
				await _attRepo.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Failure(
							_localizer["BalanceTransferFailed"], ApiStatusCodes.BadRequest);
			}



			if (string.IsNullOrEmpty(emailAddress))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						emailAddress = userInfo.Data.email.Trim();
				}
			}
			var chargeAmount = Convert.ToDecimal(product.CustomerChargeValue);
			var productAmount = decimal.Parse(product.fromAmount, CultureInfo.InvariantCulture);
			//calculate service fee
			var (totalServiceFee, serviceFee, serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(msisdnOrigin, msisdnDest, currency, productAmount);
			//deduct service fee
			chargeAmount += totalServiceFee;
			decimal discountAmount = 0;
			//TODO:Voucherify logic to handle discounts and promotions
			if (!string.IsNullOrEmpty(model.DiscountCode))
			{
				var discountRequest = new StackableDiscountRequest
				{
					DiscountCode = model.DiscountCode,
					DiscountCodeType = model.DiscountCodeType,
					Amount = chargeAmount,
					CheckoutType = CheckOutTypes.Transfer,
					DestinationCountryISOCode = msisdnDest,
					Operator = product.operatorName,
					PaymentMethod = PaymentMethods.Card
				};
				var redemptionResult = await _voucherifyService.ValidateDiscount(discountRequest, msisdn, accountDetails.AccountID, new CustomerMetadata()
				{
					FirstInternationalTopup = isFirstInternationalTopup,
					FirstTopup = isFirstTopup,
					TransactionDone = !hasUserDoneTransaction,
				});
				if (redemptionResult?.Payload != null)
				{
					discountAmount = redemptionResult.Payload.DiscountAmount;
					chargeAmount -= discountAmount;
				}
			}
			var paymentResponse = await _pay360Service.Pay360Payment(
				await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
				{
					CustomerMsisdn = msisdn,
					ChargeAmount = chargeAmount,
					DiscountAmount = discountAmount,
					IpAddress = ipAddress,
					Currency = currency,
					toMsisdn = product.tomsisdn,
					Pay360PaymentType = Pay360PaymentType.Token,
					CardToken = model.CardToken,
					SecurityCode = model.SecurityCode,
					accountNumber = accountDetails.AccountID,
					CustomerEmail = emailAddress,
					CustomerUniqueRef = msisdn,
					CheckoutPaymentType = Models.Enums.CheckOutTypes.Transfer
				}), Pay360PaymentType.Token);

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
					new IntTopupInfoAirShip()
					{
						IsSuccess = false,
						Origination = msisdnOrigin,
						Destination = msisdnDest,
						IsCard = true,
						Msisdn = msisdn,
						Amount = chargeAmount,
						IsTransferRequest = model.IsTransferRequest
					});


				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(advertiserID, msisdnOrigin, msisdnDest, false, true, Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture), model.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnOrigin, msisdnDest, false, true, Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture), null, model.IsTransferRequest);

				//Save transaction
				await _attRepo.SaveTransactionAsync(new DBTransferTransaction()
				{
					AccountId = accountDetails.AccountID,
					ClientCurrecny = product.fromCurrency,
					CountryCode = _helperService.GetCountryCode(product.tomsisdn),
					FromMsisdn = product.fromMsisdn,
					ToMsisdn = product.tomsisdn,
					ItemPrice = productAmount,
					TotalPrice = chargeAmount,
					Discount = discountAmount,
					ServiceFee = serviceFee,
					TotalServiceFee = totalServiceFee,
					ServiceFeeDiscount = serviceFeeDiscount,
					DiscountCode = model.DiscountCode,
					DiscountCodeType = model.DiscountCodeType,
					NowtelRef = model.nowtelRef,
					OperatorCountryName = product.operatorCountryName,
					OperatorLogoUrl = product.operatorLogoUrl,
					OperatorName = product.operatorName,
					PaymentErrorMsg = paymentResponse == null
										? "Payment service not responding" : paymentResponse.Message,
					TransferErrorMsg = null,
					PaymentRef = null,
					TransferRef = null,
					PaymentTypeId = InternationalTopupPaymentType.Card,
					StatusId = TransferTransactionStatus.Failure,
					Product = Convert.ToDecimal(model.product, CultureInfo.InvariantCulture),
					ReceiverCurrecny = product.toCurrency
				});
				PrepareUpdateTransactionLog(transactionLog, discountAmount, 2, paymentResponse == null ? "Payment service not responding" : paymentResponse.Message);
				await _attRepo.UpdateTransactionLog(transactionLog);
				return HandlePay360PaymentFailureResponse<Pay360PaymentResponse, TransferByCardResponseModel>
																			(paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}
			if (model.IsDefaultCard)
			{
				await _pay360Service.SetDefaultCard(msisdn, new SetDefaultCardUserRequest
				{
					CardToken = model.CardToken,
					CV2 = model.SecurityCode
				});
			}
			return await HandleTransferByCardResponseV2(
				paymentResponse.Payload,
				model,
				chargeAmount,
				discountAmount,
				product.fromMsisdn,
				product.tomsisdn,
				currency,
				accountDetails.AccountID,
				ipAddress,
				emailAddress,
				advertiserID,
				model.AppsFlyerId,
				deviceType,
				model.IsTransferRequest,
				Convert.ToDecimal(product.fromAmount, CultureInfo.InvariantCulture),
				isFirstInternationalTopup,
				isFirstTopup,
				hasUserDoneTransaction,
				totalServiceFee, serviceFee, serviceFeeDiscount);
		}
		public async Task<GenericApiResponse<InternationalTopupInfo>> TransferByCardResume3DTransactionCallbackV2Async(TransferByPay360Resume3DDataV2 data, Resume3DPaymentRequest request, string userAccountId)
		{
			GenericPay360ApiResponse<Pay360PaymentResponse> paymentResponse;
			GenericApiResponse<StackableDiscountResponse> redemptionResult = null;
			var transactionLog = await _attRepo.GetTransactionLog(data.nowtelRef, data.product);
			if (transactionLog is null)
			{
				transactionLog = await PrepareTransactionLogAsync(data.nowtelRef, data.product, 0);
				await _attRepo.CreateTransactionLogAsync(transactionLog);
			}
			var isFirstInternationalTopup = await _attRepo.IsFirstATTTransaction(userAccountId);
			var hasUserDoneTransaction = await _accountRepo.IsNewUser(data.msisdn);
			var isFirstTopup = await _accountRepo.IsFirstTopUp(data.msisdn);

			if (data.threeDsV.Equals("V2", StringComparison.InvariantCultureIgnoreCase))
			{
				//3ds v2
				paymentResponse = await _pay360Service.Resume3DV2Transaction(
					new Pay360Resume3DRequest()
					{
						pay360TransactionId = request.MD,
						customerEmail = data.customerEmail,
					});
			}
			else
			{
				//3ds v1
				paymentResponse = await _pay360Service.Resume3DV1Transaction(
					new Pay360Resume3DRequest()
					{
						pay360TransactionId = request.MD,
						customerEmail = data.customerEmail,
						pareq = request.PaRes,
					});
			}


			// Cannot resume again scenario 
			if (paymentResponse?.ErrorCode > 0 && paymentResponse.Pay360ApiCode.Equals("V107"))
			{
				PrepareUpdateTransactionLog(transactionLog, null, 2, paymentResponse?.Message);
				await _attRepo.UpdateTransactionLog(transactionLog);
				return HandlePay360PaymentFailureResponse
					<Pay360PaymentResponse, InternationalTopupInfo>(paymentResponse, CheckOutTypes.Transfer);
			}

			//Get Product Details for international topup
			var product = await _attRepo.GetProductByNowtelTransactionReference(data.nowtelRef, data.product);
			var custCharge = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture);
			var discountAmount = decimal.Zero;
			var productAmount = decimal.Parse(product.fromAmount, CultureInfo.InvariantCulture);
			var msisdnOrigin = _helperService.GetCountryCode(product.fromMsisdn);
			var msisdnDest = _helperService.GetCountryCode(product.tomsisdn);
			//calculate service fee
			var (totalServiceFee, serviceFee, serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(msisdnOrigin, msisdnDest, product.fromCurrency, productAmount);
			//deduct service fee
			custCharge += totalServiceFee;
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
				   new IntTopupInfoAirShip()
				   {
					   IsSuccess = false,
					   Origination = msisdnOrigin,
					   Destination = msisdnDest,
					   IsCard = true,
					   Msisdn = data.msisdn,
					   Amount = custCharge,
					   IsTransferRequest = data.IsTransferRequest
				   });

				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(data.advertiserID, msisdnOrigin, msisdnDest, false, true, custCharge, data.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(data.AppsFlyerId, data.DeviceType, msisdnOrigin, msisdnDest, false, true, custCharge, null, data.IsTransferRequest);

				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = data.account,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = productAmount,
						ServiceFee = serviceFee,
						TotalServiceFee = totalServiceFee,
						ServiceFeeDiscount = serviceFeeDiscount,
						TotalPrice = custCharge,
						Discount = discountAmount,
						DiscountCode = data.DiscountCode,
						DiscountCodeType = data.DiscountCodeType,
						NowtelRef = data.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = paymentResponse == null
										? "Payment service not responding" : paymentResponse.Message,
						TransferErrorMsg = null,
						PaymentRef = null,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Card,
						StatusId = TransferTransactionStatus.Failure,
						Product = Convert.ToDecimal(data.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency
					});
				PrepareUpdateTransactionLog(transactionLog, null, 2, paymentResponse == null ? "Payment service not responding" : paymentResponse.Message);
				await _attRepo.UpdateTransactionLog(transactionLog);
				return HandlePay360PaymentFailureResponse
						<Pay360PaymentResponse, InternationalTopupInfo>(paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}

			//Payment is success, Now Transfer balance
			var executeTransResponse = await _attService.TransferBalance(
				new TransFerTotransferConfirm()
				{
					nowtelTransactionReference = data.nowtelRef,
					product = data.product,
					operatorid = int.Parse(data.operatorId),
					messageToRecipient = "",
				}, data.msisdn);

			if (executeTransResponse == null || executeTransResponse.errorCode > 0)
			{
				//cancel catpured payment
				if (_pay360Config.TransferIsAuthorization)
				{
					await _pay360Service.CancelTransaction(
						new CancelTransactionRequestModel()
						{
							transactionId = paymentResponse.Payload.transactionId
						});
				}

				await _airShipService.HandleIntTopupTagsAndEvents(
				   new IntTopupInfoAirShip()
				   {
					   IsSuccess = false,
					   Origination = msisdnOrigin,
					   Destination = msisdnDest,
					   IsCard = true,
					   Msisdn = data.msisdn,
					   Amount = custCharge,
					   IsTransferRequest = data.IsTransferRequest
				   });


				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(data.advertiserID, msisdnOrigin, msisdnDest, false, true, custCharge, data.IsTransferRequest);
				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(data.AppsFlyerId, data.DeviceType, msisdnOrigin, msisdnDest, false, true, custCharge, null, data.IsTransferRequest);

				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = data.account,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = productAmount,
						ServiceFee = serviceFee,
						TotalServiceFee = totalServiceFee,
						ServiceFeeDiscount = serviceFeeDiscount,
						TotalPrice = custCharge,
						Discount = discountAmount,
						DiscountCode = data.DiscountCode,
						DiscountCodeType = data.DiscountCodeType,
						NowtelRef = data.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = null,
						TransferErrorMsg = executeTransResponse == null
											? "Transfer service not responding" : executeTransResponse?.message,
						PaymentRef = paymentResponse.Payload.transactionId,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Card,
						StatusId = TransferTransactionStatus.Failure,
						Product = Convert.ToDecimal(data.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency
					});
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Unable to transfer balance");
				await _attRepo.UpdateTransactionLog(transactionLog);
				_logger.Information($"Class=>Payment_BL, Method=>TransferByCardResume3DTransactionCallbackAsync, Message=>Unable to transfer balance, FromMsisdn=>{data.msisdn},NowtelRef=>{data.nowtelRef},Operator=>{data.operatorId}, Product=>{data.product}, Amount=>{custCharge}");
				return GenericApiResponse<InternationalTopupInfo>.Failure(null,
							  _localizer["PaymentServiceNotResponding"], ApiStatusCodes.InternalServerError);
			}

			//capture payment
			var isCapturePaymentSuccess = true;
			if (_pay360Config.TransferIsAuthorization)
			{
				string captureFailedMessage = $"Payment capture failed==> Payment TransactionId:{paymentResponse.Payload.transactionId} " +
											  $"Transfer TransactionId:{executeTransResponse.reference}";
				try
				{
					var captureResponse = await _pay360Service.CaptureTransaction(
						new CaptureTransactionRequestModel()
						{
							transactionId = paymentResponse.Payload.transactionId
						});
					if (captureResponse == null || captureResponse.ErrorCode > 0)
					{
						isCapturePaymentSuccess = false;
						await _emailService.SendEmail(
							_pay360Config.PaymentCaptureFailureEmail,
							captureFailedMessage,
							false,
							"Capture Failed-THA-App-" + paymentResponse.Payload.transactionId);
						_logger.Error($"Class=>Payment_BL, Method=>TransferByCardResume3DTransactionCallbackAsync, Message=>Capture transaction failed, FromMsisdn=>{data.msisdn},NowtelRef=>{data.nowtelRef},Operator=>{data.operatorId}, Product=>{data.product}, Amount=>{custCharge},ErrorMessage=>{captureFailedMessage}");
					}
				}
				catch (Exception ex)
				{
					isCapturePaymentSuccess = false;
					await _emailService.SendEmail(
						_pay360Config.PaymentCaptureFailureEmail,
						captureFailedMessage + "-" + ex.Message,
						false,
						"Capture Failed-THA-App-" + paymentResponse.Payload.transactionId);
					_logger.Error(ex, $"Class=>Payment_BL, Method=>TransferByCardResume3DTransactionCallbackAsync, Message=>Capture transaction failed, FromMsisdn=>{data.msisdn},NowtelRef=>{data.nowtelRef},Operator=>{data.operatorId}, Product=>{data.product}, Amount=>{custCharge},ErrorMessage=>{captureFailedMessage}");
				}
			}

			if (!string.IsNullOrEmpty(data.DiscountCode))
			{
				var discountRequest = new StackableDiscountRequest
				{
					DiscountCode = data.DiscountCode,
					DiscountCodeType = data.DiscountCodeType,
					CheckoutType = CheckOutTypes.Transfer,
					Amount = Convert.ToDecimal(product.CustomerChargeValue),
					PaymentMethod = PaymentMethods.Card,
					DestinationCountryISOCode = msisdnDest,
					Operator = product.operatorName,
				};
				redemptionResult = await _voucherifyService.RedeemDiscount(discountRequest, product.fromMsisdn, product.account, new CustomerMetadata()
				{
					FirstInternationalTopup = isFirstInternationalTopup,
					FirstTopup = isFirstTopup,
					TransactionDone = !hasUserDoneTransaction,
				});
				discountAmount = redemptionResult?.Payload?.Order?.DiscountAmount != null ? Convert.ToDecimal(redemptionResult.Payload.Order.DiscountAmount) : 0;
				custCharge -= discountAmount;
			}
			var internationalTopupPoints = Utility.CalculateInternationalTopupRewardPointsRange(productAmount, _voucherifyConfig.LoyaltyEarningRules.International);
			await _voucherifyService.PurchaseEvent(product.fromMsisdn, string.Format(VoucherifyEventsNames.InternationalTopup, internationalTopupPoints), new VoucherifyEventsMetadata { ChargeAmount = Convert.ToDecimal(product.CustomerChargeValue), Timestamp = DateTime.UtcNow, LoyaltyPoints = internationalTopupPoints });

			//Airship events
			await _airShipService.HandleIntTopupTagsAndEvents(
					new IntTopupInfoAirShip()
					{
						IsSuccess = true,
						IsCard = true,
						Msisdn = data.msisdn,
						Destination = msisdnDest,
						Origination = msisdnOrigin,
						Amount = custCharge,
						IsTransferRequest = data.IsTransferRequest,
					});

			// Handle FaceBook Events
			await _faceBookService.HandleIntTopupEvents(data.advertiserID, msisdnOrigin, msisdnDest, true, true, custCharge, data.IsTransferRequest);
			// Handle AppsFlyer Events
			await _appsFlyerService.HandleIntTopupEvents(data.AppsFlyerId, data.DeviceType, msisdnOrigin, msisdnDest, true, true, custCharge, null, data.IsTransferRequest);

			//Save transaction with success
			await _attRepo.SaveTransactionAsync(
				new DBTransferTransaction()
				{
					AccountId = data.account,
					ClientCurrecny = product.fromCurrency,
					CountryCode = _helperService.GetCountryCode(product.tomsisdn),
					FromMsisdn = product.fromMsisdn,
					ToMsisdn = product.tomsisdn,
					ItemPrice = productAmount,
					ServiceFee = serviceFee,
					TotalServiceFee = totalServiceFee,
					ServiceFeeDiscount = serviceFeeDiscount,
					TotalPrice = custCharge,
					Discount = discountAmount,
					DiscountCode = data.DiscountCode,
					DiscountCodeType = data.DiscountCodeType,
					NowtelRef = data.nowtelRef,
					OperatorCountryName = product.operatorCountryName,
					OperatorLogoUrl = product.operatorLogoUrl,
					OperatorName = product.operatorName,
					PaymentErrorMsg = isCapturePaymentSuccess ? null : "Payment capture failed",
					TransferErrorMsg = null,
					PaymentRef = paymentResponse.Payload.transactionId,
					TransferRef = executeTransResponse.reference,
					PaymentTypeId = InternationalTopupPaymentType.Card,
					StatusId = TransferTransactionStatus.Success,
					Product = Convert.ToDecimal(data.product, CultureInfo.InvariantCulture),
					ReceiverCurrecny = product.toCurrency
				});

			//Send Email
			var userProfile = await _accountRepo.GetUserProfile(product.fromMsisdn);
			if (!string.IsNullOrEmpty(userProfile?.Data?.email))
			{
				var rewardPoints = Utility.CalculateInternationalTopupRewardPointsRange(productAmount, _voucherifyConfig.LoyaltyEarningRules.International);

				await SendInternationalTopupPaymentReceiptAsync(userProfile.Data.email, product, userProfile.Data, "Card", totalServiceFee, discountAmount, data.DiscountCode, rewardPoints, executeTransResponse.reference, executeTransResponse.pinCode);
			}

			var userBalance = await _accountRepo.GetUserAccountBalanceAsync(data.msisdn);
			PrepareUpdateTransactionLog(transactionLog, null, 1, "Success");
			await _attRepo.UpdateTransactionLog(transactionLog);
			return GenericApiResponse<InternationalTopupInfo>.Success(
				new InternationalTopupInfo()
				{
					CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
					IsRedeemedSuccess = redemptionResult?.Payload?.RedemptionId != null,
					TopupAmount = paymentResponse.Payload.transactionAmount,
					Msisdn = data.msisdn,
					TransactionId = paymentResponse.Payload.transactionId,
					IsFirstInternationalTopup = isFirstInternationalTopup,
					Currency = _helperService.ToCurrencySymbol(userBalance.Currency),
					NewBalance = userBalance.Balance,
					FromAmount = Convert.ToDecimal(product.fromAmount, CultureInfo.InvariantCulture)
				}, _localizer["InternationalTopupSuccessfull"]);
		}

		#endregion

		#region Paypal Payments Bundle and Topup
		public async Task<GenericApiResponse<PaypalPaymentResponseModel>> PaypalPaymentV2Async(PaypalPaymentRequestModelV2 model, string msisdn, string currency, string ipAddress, string advertiserID)
		{
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));

			var hasUserDoneTransaction = await _accountRepo.IsNewUser(msisdn);
			var isFirstTopup = await _accountRepo.IsFirstTopUp(msisdn);
			var isFirstInternationalTopup = await _attRepo.IsFirstATTTransaction(accountDetails.AccountID);

			var bundleDest = "";
			string Currency = "";
			decimal bundlePrice = 0;
			decimal ChargeAmount = model.TopUpAmount;
			decimal DiscountAmount = 0;
			var msisdnOrigin = _helperService.GetCountryCode(msisdn);

			BundleType bundleType = BundleType.PAYG;
			DeviceType deviceType = (DeviceType)model.DeviceType;

			if (model.CheckoutType == CheckOutTypes.Bundle)
			{
				//Check Bundle Limit
				var bundlesResponse = await _accountRepo.GetBundlesHistory(accountDetails.AccountID);
				if (bundlesResponse.Count() >= 10)
				{
					return GenericApiResponse<PaypalPaymentResponseModel>.Failure(
						_localizer["MaxNumberOfBundlesPurchased"], ApiStatusCodes.BundleLimitExceeded);
				}

				//Get Bundle details
				var bundleResponse = await _bundleRepo.GetBundleById(model.BundleId, accountDetails.AccountID);

				if (bundleResponse == null)
				{
					return GenericApiResponse<PaypalPaymentResponseModel>.Failure(
						_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
				}
				bundlePrice = Convert.ToDecimal(bundleResponse.TotalCostPence / 100, CultureInfo.InvariantCulture);
				if (bundleResponse.BundleType == BundleType.Monthly)
				{
					//Montly bundles cannot be purchased with paypal payment
					return GenericApiResponse<PaypalPaymentResponseModel>.Failure(
						_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
				}
				ChargeAmount = bundleResponse.TotalCostPence / 100;
				bundleDest = bundleResponse.Description.Replace(" ", "").Replace(",", "");
				bundleType = bundleResponse.BundleType;
				Currency = accountDetails.Currency;
			}

			var userInfo = await _accountRepo.GetUserProfile(msisdn);

			string name = msisdn;
			string emailAddress = "";

			if (userInfo.Status == Models.Enums.Status.Success)
			{
				if (userInfo.Data != null)
				{
					if (!string.IsNullOrEmpty(userInfo.Data.email))
						emailAddress = userInfo.Data.email.Trim();
					if (!string.IsNullOrEmpty(userInfo.Data.firstName))
					{
						name = $"{userInfo.Data.firstName} {userInfo.Data.lastName}";
					}
				}
			}

			//TODO:Voucherify logic to handle discounts and promotions
			if (!string.IsNullOrEmpty(model.DiscountCode) && model.CheckoutType == CheckOutTypes.TopUp)
			{
				var discountRequest = new StackableDiscountRequest
				{
					DiscountCode = model.DiscountCode,
					DiscountCodeType = model.DiscountCodeType,
					CheckoutType = CheckOutTypes.TopUp,
					Amount = (decimal)model.TopUpAmount,
					PaymentMethod = PaymentMethods.Paypal,
				};
				var validationResult = await _voucherifyService.ValidateDiscount(
					discountRequest, msisdn, accountDetails.AccountID, new CustomerMetadata()
					{
						FirstInternationalTopup = isFirstInternationalTopup,
						FirstTopup = isFirstTopup,
						TransactionDone = !hasUserDoneTransaction,
					});
				if (validationResult?.Payload != null)
				{
					DiscountAmount = validationResult.Payload.DiscountAmount;
					ChargeAmount -= DiscountAmount;
				}
			}

			var airshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();
			var request = new PaypalPaymentRequest
			{
				CustomerName = name,
				Email = emailAddress,
				Msisdn = msisdn,
				Currency = currency,
				IpAddress = ipAddress,
				BundleUuid = model.CheckoutType == CheckOutTypes.Bundle ? model.BundleId : "",
				BundleAmount = ChargeAmount,
				BundleDiscount = DiscountAmount,
				TopupAmount = ChargeAmount,
				OrderId = 0,
				CheckoutType = model.CheckoutType,
				IsAppRequest = true,
				TopupDiscount = DiscountAmount,
			};
			var callBackData = new PaypalPaymentCallbackData
			{
				ThemeMode = (int)_httpContext.HttpContext.ThemeMode(),
				AdvertiserId = advertiserID,
				AirshipEventsDisable = airshipEventsDisable,
				AppsFlyerId = model.AppsFlyerId,
				Culture = _localizer["Locale"],
				DeviceType = model.DeviceType,
				DiscountCode = model.DiscountCode,
				DiscountCodeType = model.DiscountCodeType,
				IpAddress = ipAddress,
				Msisdn = msisdn,
				Email = emailAddress,
				BundleId = model.CheckoutType == CheckOutTypes.Bundle ? model.BundleId : "",
				CheckoutType = model.CheckoutType,
				TopupAmount = model.TopUpAmount,
				UtmCampaign = model.UtmParamsInfo?.utm_campaign,
				UtmSource = model.UtmParamsInfo?.utm_source,
				UtmMedium = model.UtmParamsInfo?.utm_medium,
			};

			//Save transaction
			var paymentTransactionId = await _paymentFullfillmentDL.InsertPaypalTransactionPaymentAsync(
				new List<PayPalByPay360Basket>
				{
					new PayPalByPay360Basket
					{
						chargeAmount=ChargeAmount,
						discountAmount=DiscountAmount,
						bundleRef=model.CheckoutType==CheckOutTypes.Bundle?model.BundleId:"",
						productItemCode=nameof(ProductItemCode.THADTA),
						productRef=msisdn
					}
				},
				currency,
				request.Email,
				nameof(ProductCode.THA),
				null,
				request.Msisdn,
				TransactionsPaymentType.Paypal,
				0,
				model.DiscountCode,
				model.DiscountCodeType);

			callBackData.PTId = paymentTransactionId;

			var paymentResponse = await payPalService.PayPalCreateSalePayment(request, callBackData);

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				if (model.CheckoutType == CheckOutTypes.Bundle)
				{

					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = false,
							Msisdn = msisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});

					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(advertiserID, msisdnOrigin, bundleDest, bundleType, false, false, bundlePrice, Currency);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, false, bundlePrice, Currency);
				}
				else
				{
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							IsCard = false,
							Msisdn = msisdn,
							Amount = ""
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(advertiserID, false, false, 0, Currency, msisdnOrigin);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, false, false, 0, Currency, msisdnOrigin);
				}

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
					paymentTransactionId,
					false,
					null,
				 paymentResponse == null ? "Payment service not responding" : paymentResponse.ErrorMessage);

				return HandlePaypalPaymentFailureResponse
					<PayPalByPay360CSPaymentResponse, PaypalPaymentResponseModel>(paymentResponse, model.CheckoutType);
			}

			await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, false, paymentResponse.TransactionId);

			return GenericApiResponse<PaypalPaymentResponseModel>.Success(
				new PaypalPaymentResponseModel()
				{
					clientRedirectUrl = paymentResponse.RedirectUrl
				}, _localizer["PaymentCreatedSuccessfully"]);
		}
		public async Task<GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>> PaypalPaymentCallBackV2Async(PaypalPaymentCallbackData model)
		{
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(
												_helperService.GetSipUserName(model.Msisdn));
			var hasUserDoneTransaction = await _accountRepo.IsNewUser(model.Msisdn);
			var isFirstTopup = await _accountRepo.IsFirstTopUp(model.Msisdn);
			var isFirstInternationalTopup = await _attRepo.IsFirstATTTransaction(accountDetails.AccountID);

			string bundleName = "";
			string bundleDest = "";
			string Currency = "";
			decimal bundlePrice = 0;
			decimal discountAmount = 0;
			int bundleRewardPoints = 0;
			int topupRewardPoints = 0;
			GenericApiResponse<StackableDiscountResponse> redemptionResult = null;

			var msisdnOrigin = _helperService.GetCountryCode(model.Msisdn);
			BundleType bundleType = BundleType.PAYG;
			bool isTrialBundle = false;
			DeviceType deviceType = (DeviceType)model.DeviceType;
			if (model.CheckoutType == Models.Enums.CheckOutTypes.TopUp)
			{
				topupRewardPoints = _pay360Config.TopupAmounts.FirstOrDefault(x => x.Amount == model.TopupAmount).RewardPoints;
			}
			if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
			{
				var bundleInfo = await _bundleRepo.GetBundleById(model.BundleId, accountDetails.AccountID);
				bundleDest = bundleInfo.Description.Replace(" ", "").Replace(",", "");
				bundleType = bundleInfo.BundleType;
				bundleRewardPoints = bundleInfo.RewardPoints;
				Currency = accountDetails.Currency;

				bundleName = bundleInfo.BrandedName;
				bundlePrice = Convert.ToDecimal(bundleInfo.TotalCostPence / 100, CultureInfo.InvariantCulture);
				if (bundleInfo.IsTrial && bundleInfo.TrialId != null)
					isTrialBundle = bundleInfo.IsTrial;
			}
			var transactionAmount = model.CheckoutType == CheckOutTypes.Bundle ? bundlePrice : model.TopupAmount;
			var paymentResponse = await payPalService.DirectPayPalExecuteSalePayment(model.Msisdn, model.PayerId, model.PaymentId);

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				if (model.CheckoutType == Models.Enums.CheckOutTypes.Bundle)
				{
					await _airShipService.HandleBundleTagsAndEvents(
						new BundleInfoAirShip()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							Destination = bundleDest,
							IsCard = false,
							Msisdn = model.Msisdn,
							BundleType = bundleType,
							Amount = bundlePrice
						});

					//Handle FaceBook Events
					await _faceBookService.HandleBundlePurchaseEvents(model.AdvertiserId, msisdnOrigin, bundleDest, bundleType, false, false, bundlePrice, Currency);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, false, false, bundlePrice, Currency);
				}
				else
				{
					await _airShipService.HandleTopupTagsAndEvents(
						new TopupInfoAirship()
						{
							IsSuccess = false,
							Origination = msisdnOrigin,
							IsCard = false,
							Msisdn = model.Msisdn,
							Amount = ""
						});

					//Handle FaceBook Events
					await _faceBookService.HandleTopupEvents(model.AdvertiserId, false, false, 0, Currency, msisdnOrigin);
					//Handle AppsFlyer Events
					await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, false, false, 0, Currency, msisdnOrigin);
				}

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
										model.PTId.Value,
										false,
										null,
										paymentResponse == null ? "Payment Service Not Responding" : (paymentResponse.ErrorCode + " - " + paymentResponse.ErrorMessage));

				return HandlePaypalPaymentFailureResponse<PayPalByPay360ESPaymentResponse,
								PaypalByPay360PaymentCallBackResponseModel>(paymentResponse, (CheckOutTypes)model.CheckoutType);
			}

			//Successfull payment
			await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(model.PTId.Value, true);

			//Redeem promotion
			if (model.CheckoutType == CheckOutTypes.TopUp && !string.IsNullOrEmpty(model.DiscountCode))
			{
				var discountRequest = new StackableDiscountRequest
				{
					DiscountCode = model.DiscountCode,
					DiscountCodeType = model.DiscountCodeType,
					CheckoutType = CheckOutTypes.TopUp,
					Amount = model.TopupAmount,
					PaymentMethod = PaymentMethods.Paypal,
				};
				redemptionResult = await _voucherifyService.RedeemDiscount(discountRequest, model.Msisdn, accountDetails.AccountID, new CustomerMetadata()
				{
					FirstInternationalTopup = isFirstInternationalTopup,
					FirstTopup = isFirstTopup,
					TransactionDone = !hasUserDoneTransaction,
				});
				discountAmount = redemptionResult?.Payload?.Order?.DiscountAmount != null ? Convert.ToDecimal(redemptionResult.Payload.Order.DiscountAmount) : 0;
			}

			if (model.CheckoutType == CheckOutTypes.TopUp)
			{
				var topupPoints = Utility.CalculateTopupRewardPoints(model.TopupAmount, _voucherifyConfig);
				await _voucherifyService.PurchaseEvent(model.Msisdn, VoucherifyEventsNames.Topup, new VoucherifyEventsMetadata
				{
					ChargeAmount = model.TopupAmount,
					Timestamp = DateTime.UtcNow,
					LoyaltyPoints = topupPoints
				});
			}
			if (model.CheckoutType == CheckOutTypes.Bundle)
			{
				if (bundleType == BundleType.Welcome)
				{
					await _voucherifyService.PurchaseEvent(model.Msisdn, VoucherifyEventsNames.WelcomeBundle, new VoucherifyEventsMetadata
					{
						ChargeAmount = bundlePrice,
						Timestamp = DateTime.UtcNow,
						LoyaltyPoints = bundleRewardPoints
					});
				}
				if (bundleType == BundleType.PAYG)
				{
					await _voucherifyService.PurchaseEvent(model.Msisdn, VoucherifyEventsNames.WelcomeBundle, new VoucherifyEventsMetadata
					{
						ChargeAmount = bundlePrice,
						Timestamp = DateTime.UtcNow,
						LoyaltyPoints = bundleRewardPoints
					});
				}
			}

			//Fulfillment
			await PaypalPaymentFullfillment(paymentResponse, model.Msisdn, model.Email, accountDetails.AccountID);

			var userBalance = await _accountRepo.GetUserAccountBalanceAsync(model.Msisdn);
			var currencySymbol = _helperService.ToCurrencySymbol(accountDetails.Currency);

			if (model.CheckoutType == CheckOutTypes.Bundle)
			{
				//Airship events
				await _airShipService.HandleBundleTagsAndEvents(
					 new BundleInfoAirShip()
					 {
						 IsSuccess = true,
						 Origination = msisdnOrigin,
						 Destination = bundleDest,
						 IsCard = false,
						 Msisdn = model.Msisdn,
						 BundleType = bundleType,
						 Amount = bundlePrice
					 });

				await _faceBookService.HandleBundlePurchaseEvents(model.AdvertiserId, msisdnOrigin, bundleDest, bundleType, true, false, bundlePrice, Currency);

				await _appsFlyerService.HandleBundlePurchaseEvents(model.AppsFlyerId, deviceType, msisdnOrigin, bundleDest, bundleType, true, false, bundlePrice, Currency);

				return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Success(
					new PaypalByPay360PaymentCallBackResponseModel()
					{
						CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
						IsRedeemedSuccess = redemptionResult?.Payload?.RedemptionId != null,
						bundlePurchaseInfo = new BundlePurchaseInfo()
						{
							TransactionId = paymentResponse.TransactionId,
							BundleAmount = isTrialBundle ? "0" : bundlePrice.ToString(),
							BundleName = bundleName,
							Currency = currencySymbol,
							Msisdn = model.Msisdn,
							Destination = bundleDest,
							Type = bundleType,
							RewardPoints = bundleRewardPoints,
						}
					}, _localizer["BundlePurchasedSuccessfully"]);
			}
			else
			{
				//Airship events
				await _airShipService.HandleTopupTagsAndEvents(
				   new TopupInfoAirship()
				   {
					   IsSuccess = true,
					   Origination = msisdnOrigin,
					   IsCard = false,
					   Msisdn = model.Msisdn,
					   Amount = model.CheckoutType == CheckOutTypes.Bundle ? bundlePrice.ToString() : model.TopupAmount.ToString()
				   });

				//Handle FaceBook Events
				await _faceBookService.HandleTopupEvents(model.AdvertiserId, true, false, transactionAmount, Currency, msisdnOrigin);
				//Handle AppsFlyer Events
				await _appsFlyerService.HandleTopupEvents(model.AppsFlyerId, deviceType, true, false, transactionAmount, Currency, msisdnOrigin);

				return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Success(
					new PaypalByPay360PaymentCallBackResponseModel()
					{
						CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
						IsRedeemedSuccess = redemptionResult?.Payload?.RedemptionId != null,
						topupInfo = new TopupInfo()
						{
							TopupAmount = model.TopupAmount.ToString(),
							Msisdn = model.Msisdn,
							TransactionId = paymentResponse.TransactionId,
							Currency = currencySymbol,
							NewBalance = userBalance.Balance,
							IsFirstTopup = isFirstTopup,
							RewardPoints = topupRewardPoints
						}
					}, _localizer["TopUpSuccessful", model.TopupAmount]);
			}
		}


		#endregion

		#region Paypal Payments Transfer Credit
		private InternationalTopupTransactionLog PrepareUpdateTransactionLog(InternationalTopupTransactionLog transaction, decimal? discount, int checkoutStatus, string message)
		{
			if (discount.HasValue)
			{
				transaction.DiscountApplied = discount.Value;
				transaction.TotalPrice -= discount.Value;
			}
			transaction.CheckoutStatus = checkoutStatus;
			transaction.Message = message;
			return transaction;
		}
		private async Task<InternationalTopupTransactionLog> PrepareTransactionLogAsync(string nowtelRef, string productId, decimal discount = 0)
		{
			var product = await _attRepo.GetProductByNowtelTransactionReference(nowtelRef, productId);
			var productAmount = decimal.Parse(product.fromAmount, CultureInfo.InvariantCulture);
			var origination = _helperService.GetCountryCode(product.fromMsisdn);
			var destination = _helperService.GetCountryCode(product.tomsisdn);
			var amountToCharge = decimal.Parse(product.CustomerChargeValue, CultureInfo.InvariantCulture);
			(decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, product.fromCurrency, productAmount);
			amountToCharge += totalServiceFee;
			amountToCharge -= discount;
			return new InternationalTopupTransactionLog
			{
				CheckoutStatus = 0,
				Currency = product.fromCurrency,
				CustomerIdentifier = product.fromMsisdn,
				ToMsisdn = product.tomsisdn,
				TransactionIdentifier = nowtelRef,
				ProductPrice = productAmount,
				DiscountOnServiceFee = serviceFeeDiscount,
				DiscountApplied = discount,
				Message = "",
				ProductIdentifier = product.product,
				TotalPrice = amountToCharge,
				ServiceFee = totalServiceFee,
				SalePrice = productAmount,
			};
		}
		public async Task<GenericApiResponse<TransferByPayPalResponseModel>> TransferByPayPalV2Async(TransferByPayPalRequestModelV2 model, string currency, string ipAddress, string msisdn, string advertiserID)
		{
			var transactionLog = await _attRepo.GetTransactionLog(model.nowtelRef, model.product);
			if (transactionLog == null)
			{
				transactionLog = await PrepareTransactionLogAsync(model.nowtelRef, model.product, 0);
				await _attRepo.CreateTransactionLogAsync(transactionLog);
			}
			var product = await _attRepo.GetProductByNowtelTransactionReference(model.nowtelRef, model.product);
			if (product == null || !decimal.TryParse(product.CustomerChargeValue, out var chargedAmount) || chargedAmount <= 0)
			{
				_logger.Information($"Class=>Payment_BL, Method=>TransferByPayPalAsync, Message=> No product available for this destination, FromMsisdn=>{msisdn},Product=>{model.product}, NowTelRef=>{model.nowtelRef}");
				PrepareUpdateTransactionLog(transactionLog, null, 2, "No product avilable for this destination");
				await _attRepo.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalResponseModel>.Failure(
											_localizer["NoProductAvailableForDestination"], ApiStatusCodes.BadRequest);
			}
			DeviceType deviceType = (DeviceType)model.DeviceType;

			var custValidate = await _attRepo.ValidateNowtelCustomerNew(
				msisdn,
				model.nowtelRef,
				model.product,
				Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture));
			if (custValidate.isAllowed != 1)
			{
				_logger.Information($"Class=>Payment_BL, Method=>TransferByPayPalAsync, Message=> Unable to validate nowtel customer, FromMsisdn=>{msisdn},Product=>{model.product}, NowTelRef=>{model.nowtelRef}");
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Unable to validate nowtel customer");
				await _attRepo.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalResponseModel>.Failure(
							_localizer["BalanceTransferFailed"], ApiStatusCodes.BadRequest);
			}

			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(msisdn));

			var hasUserDoneTransaction = await _accountRepo.IsNewUser(msisdn);
			var isFirstTopup = await _accountRepo.IsFirstTopUp(msisdn);
			var isFirstInternationalTopup = await _attRepo.IsFirstATTTransaction(accountDetails.AccountID);
			//Order calculations
			string msisdndestination = _helperService.GetCountryCode(product.tomsisdn);
			string msisdnorigination = _helperService.GetCountryCode(product.fromMsisdn);
			(decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(msisdnorigination, msisdndestination, currency, decimal.Parse(product.fromAmount));
			string emailAddress = "";
			decimal ChargedAmount = decimal.Parse(product.CustomerChargeValue, CultureInfo.InvariantCulture);
			//Include service fee in charged amount
			ChargedAmount += totalServiceFee;
			decimal ProductAmount = decimal.Parse(product.fromAmount, CultureInfo.InvariantCulture);
			decimal DiscountAmount = 0;
			if (!string.IsNullOrEmpty(model.DiscountCode))
			{
				var validationResult = await _voucherifyService.ValidateDiscount(
					new StackableDiscountRequest
					{
						Amount = ProductAmount,
						CheckoutType = CheckOutTypes.Transfer,
						DiscountCode = model.DiscountCode,
						DiscountCodeType = model.DiscountCodeType,
						PaymentMethod = PaymentMethods.Paypal,
						Operator = product.operatorName,
						DestinationCountryISOCode = msisdndestination,
					}, msisdn, accountDetails.AccountID,
					new CustomerMetadata()
					{
						FirstInternationalTopup = isFirstInternationalTopup,
						FirstTopup = isFirstTopup,
						TransactionDone = !hasUserDoneTransaction,
					});
				if (validationResult?.Payload != null)
				{
					DiscountAmount = validationResult.Payload.DiscountAmount;
					ChargedAmount -= DiscountAmount;
				}
			}

			var userInfo = await _accountRepo.GetUserProfile(msisdn);
			if (userInfo.Status == Models.Enums.Status.Success)
			{
				if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
					emailAddress = userInfo.Data.email.Trim();
			}

			var airshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();
			var request = new PaypalPaymentRequest()
			{
				TransferAmount = ChargedAmount,
				TransferDiscount = DiscountAmount,
				TransferDestinationMsisdn = product.tomsisdn,
				IpAddress = ipAddress,
				CustomerName = userInfo != null ? !string.IsNullOrEmpty(userInfo.Data.firstName) ? userInfo.Data.firstName : msisdn : msisdn,
				Msisdn = msisdn,
				Email = emailAddress,
				Currency = currency,
				CheckoutType = CheckOutTypes.Transfer,
				IsAppRequest = true,
				OrderId = 0,
			};
			var callBackData = new PaypalPaymentCallbackData
			{
				TransferNowtelRef = model.nowtelRef,
				TransferProduct = model.product,
				TransferOperatorId = int.Parse(model.operatorId),
				Msisdn = msisdn,
				ThemeMode = (int)_httpContext.HttpContext.ThemeMode(),
				IpAddress = ipAddress,
				AdvertiserId = advertiserID,
				AirshipEventsDisable = airshipEventsDisable,
				IsTransferRequest = model.IsTransferRequest,
				DiscountCode = model.DiscountCode,
				DiscountCodeType = model.DiscountCodeType,
				Culture = _localizer["Locale"],
				AppsFlyerId = model.AppsFlyerId,
				DeviceType = model.DeviceType,
				CheckoutType = CheckOutTypes.Transfer
			};
			var paymentResponse = await payPalService.PayPalCreateSalePayment(request, callBackData);
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
					new IntTopupInfoAirShip()
					{
						IsSuccess = false,
						Origination = msisdnorigination,
						Destination = msisdndestination,
						IsCard = false,
						Msisdn = msisdn,
						Amount = ChargedAmount,
						IsTransferRequest = model.IsTransferRequest
					});

				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(advertiserID, msisdnorigination, msisdndestination, false, false, Convert.ToDecimal(ChargedAmount), model.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnorigination, msisdndestination, false, false, Convert.ToDecimal(ChargedAmount), null, model.IsTransferRequest);

				//Save transaction
				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = accountDetails.AccountID,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = ProductAmount,
						ServiceFee = serviceFee,
						TotalServiceFee = totalServiceFee,
						ServiceFeeDiscount = serviceFeeDiscount,
						TotalPrice = ChargedAmount,
						Discount = DiscountAmount,
						DiscountCode = model.DiscountCode,
						DiscountCodeType = model.DiscountCodeType,
						NowtelRef = model.nowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = paymentResponse == null ? "Payment service not responding" : paymentResponse.ErrorMessage,
						TransferErrorMsg = null,
						PaymentRef = null,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Paypal,
						Product = Convert.ToDecimal(model.product, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency,
						StatusId = TransferTransactionStatus.Failure
					});
				PrepareUpdateTransactionLog(transactionLog, null, 2, paymentResponse == null ? "Payment service not responding" : paymentResponse.ErrorMessage);
				await _attRepo.UpdateTransactionLog(transactionLog);
				return HandlePaypalPaymentFailureResponse<PayPalByPay360CSPaymentResponse, TransferByPayPalResponseModel>(
							 paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}

			PrepareUpdateTransactionLog(transactionLog, DiscountAmount, 1, string.Empty);
			await _attRepo.UpdateTransactionLog(transactionLog);
			//We will save transaction after successfull calback
			return GenericApiResponse<TransferByPayPalResponseModel>.Success(
				new TransferByPayPalResponseModel()
				{
					clientRedirectUrl = paymentResponse.RedirectUrl
				}, _localizer["PaymentCreatedSuccessfully"]);
		}
		public async Task<GenericApiResponse<InternationalTopupInfo>> TransferByPayPalCallbackV2Async(PaypalPaymentCallbackData model)
		{
			GenericApiResponse<StackableDiscountResponse> redemptionResult = null;
			var trasnactionLog = await _attRepo.GetTransactionLog(model.TransferNowtelRef, model.TransferProduct);
			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(_helperService.GetSipUserName(model.Msisdn));

			var isFirstInternationalTopup = await _attRepo.IsFirstATTTransaction(accountDetails.AccountID);
			var hasUserDoneTransaction = await _accountRepo.IsNewUser(model.Msisdn);
			var isFirstTopup = await _accountRepo.IsFirstTopUp(model.Msisdn);

			var paymentResponse = await payPalService.DirectPayPalExecuteSalePayment(
				model.Msisdn,
				model.PayerId,
				model.PaymentId);

			var product = await _attRepo.GetProductByNowtelTransactionReference(model.TransferNowtelRef, model.TransferProduct);
			var productAmount = Convert.ToDecimal(product.fromAmount, CultureInfo.InvariantCulture);
			var chargeAmount = Convert.ToDecimal(product.CustomerChargeValue, CultureInfo.InvariantCulture);

			var msisdnOrigin = _helperService.GetCountryCode(product.fromMsisdn);
			var msisdnDest = _helperService.GetCountryCode(product.tomsisdn);
			//Calcualte service fee and add that into chargeAmount
			(decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(msisdnOrigin, msisdnDest, accountDetails.Currency, productAmount);
			chargeAmount += totalServiceFee;
			var discountAmount = decimal.Zero;
			DeviceType deviceType = (DeviceType)model.DeviceType;

			if (!string.IsNullOrEmpty(model.DiscountCode))
			{
				var validationResult = await _voucherifyService.ValidateDiscount(
					new StackableDiscountRequest
					{
						Amount = productAmount,
						CheckoutType = CheckOutTypes.Transfer,
						DiscountCode = model.DiscountCode,
						DiscountCodeType = model.DiscountCodeType,
						DestinationCountryISOCode = msisdnDest,
						Operator = product.operatorName,
						PaymentMethod = PaymentMethods.Paypal,
					}, product.fromMsisdn, accountDetails.AccountID,
				new CustomerMetadata()
				{
					FirstInternationalTopup = isFirstInternationalTopup,
					FirstTopup = isFirstTopup,
					TransactionDone = !hasUserDoneTransaction,
				});
				if (validationResult?.Payload != null)
				{
					discountAmount = validationResult.Payload.DiscountAmount;
					chargeAmount -= discountAmount;
				}
			}

			//handle payment failiure scenarios
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
				   new IntTopupInfoAirShip()
				   {
					   IsSuccess = false,
					   Origination = msisdnOrigin,
					   Destination = msisdnDest,
					   IsCard = false,
					   Msisdn = model.Msisdn,
					   Amount = chargeAmount,
					   IsTransferRequest = model.IsTransferRequest
				   });

				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(model.AdvertiserId, msisdnOrigin, msisdnDest, false, false, chargeAmount, model.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnOrigin, msisdnDest, false, false, chargeAmount, null, model.IsTransferRequest);

				//Save transaction
				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = accountDetails.AccountID,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = productAmount,
						TotalPrice = chargeAmount,
						ServiceFee = serviceFee,
						ServiceFeeDiscount = serviceFeeDiscount,
						TotalServiceFee = totalServiceFee,
						Discount = discountAmount,
						DiscountCode = model.DiscountCode,
						DiscountCodeType = model.DiscountCodeType,
						NowtelRef = model.TransferNowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = paymentResponse == null ? "Payment service not responding" : paymentResponse.ErrorMessage,
						TransferErrorMsg = null,
						PaymentRef = null,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Paypal,
						Product = Convert.ToDecimal(model.TransferProduct, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency,
						StatusId = TransferTransactionStatus.Failure
					});
				PrepareUpdateTransactionLog(trasnactionLog, 0, 2, paymentResponse == null ? "Payment service not responding" : paymentResponse.ErrorMessage);
				await _attRepo.UpdateTransactionLog(trasnactionLog);
				return HandlePaypalPaymentFailureResponse<PayPalByPay360ESPaymentResponse, InternationalTopupInfo>
																			(paymentResponse, Models.Enums.CheckOutTypes.Transfer);
			}

			//Now payment is success, then start tranfer balance
			var executeTransResponse = await _attService.TransferBalance(new TransFerTotransferConfirm()
			{
				nowtelTransactionReference = model.TransferNowtelRef,
				product = model.TransferProduct,
				operatorid = model.TransferOperatorId.Value,
				messageToRecipient = ""
			}, model.Msisdn);

			if (executeTransResponse == null || executeTransResponse.errorCode > 0)
			{
				await _airShipService.HandleIntTopupTagsAndEvents(
				   new IntTopupInfoAirShip()
				   {
					   IsSuccess = false,
					   Origination = msisdnOrigin,
					   Destination = msisdnDest,
					   IsCard = false,
					   Msisdn = model.Msisdn,
					   Amount = chargeAmount,
					   IsTransferRequest = model.IsTransferRequest,
				   });


				// Handle FaceBook Events
				await _faceBookService.HandleIntTopupEvents(model.AdvertiserId, msisdnOrigin, msisdnDest, false, false, chargeAmount, model.IsTransferRequest);

				// Handle AppsFlyer Events
				await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnOrigin, msisdnDest, false, false, chargeAmount, null, model.IsTransferRequest);

				//Save transaction
				await _attRepo.SaveTransactionAsync(
					new DBTransferTransaction()
					{
						AccountId = accountDetails.AccountID,
						ClientCurrecny = product.fromCurrency,
						CountryCode = _helperService.GetCountryCode(product.tomsisdn),
						FromMsisdn = product.fromMsisdn,
						ToMsisdn = product.tomsisdn,
						ItemPrice = productAmount,
						TotalPrice = chargeAmount,
						ServiceFee = serviceFee,
						ServiceFeeDiscount = serviceFeeDiscount,
						TotalServiceFee = totalServiceFee,
						Discount = discountAmount,
						DiscountCode = model.DiscountCode,
						DiscountCodeType = model.DiscountCodeType,
						NowtelRef = model.TransferNowtelRef,
						OperatorCountryName = product.operatorCountryName,
						OperatorLogoUrl = product.operatorLogoUrl,
						OperatorName = product.operatorName,
						PaymentErrorMsg = null,
						TransferErrorMsg = executeTransResponse == null
												? "Transfer service not responding" : executeTransResponse?.message,
						PaymentRef = paymentResponse.TransactionId,
						TransferRef = null,
						PaymentTypeId = InternationalTopupPaymentType.Paypal,
						StatusId = TransferTransactionStatus.Failure,
						Product = Convert.ToDecimal(model.TransferProduct, CultureInfo.InvariantCulture),
						ReceiverCurrecny = product.toCurrency
					});

				//Refund Paypal Payment
				if (_payPalConfig.IsTransferAutoRefund)
				{
					string refundFailedMessage = $"Payment refund failed==> Payment TransactionId:{paymentResponse.TransactionId}";

					try
					{
						var refundResponse = await _payPalByPay360Service.PaypalRefund(
							  new Models.Contracts.PaypalApiContracts.RefundFullPaymentRequestModel()
							  {
								  transactionId = paymentResponse.TransactionId
							  });

						if (refundResponse == null || refundResponse.errorCode > 0)
						{
							await _emailService.SendEmail(
								_pay360Config.PaymentCaptureFailureEmail,
								refundFailedMessage,
								false,
								"Refund Paypal Failed-THA-App-" + paymentResponse.TransactionId);
						}
					}
					catch (Exception ex)
					{
						await _emailService.SendEmail(
							_pay360Config.PaymentCaptureFailureEmail,
							refundFailedMessage + "-" + ex.Message,
							false,
							"Refund Paypal Failed-THA-App-" + paymentResponse.TransactionId);
						_logger.Error(ex, "Class: Payment_BL, Method: TransferByPayPalCallbackV2Async");
					}
				}
				else
				{
					string refundFailedMessage = $"Need to refund the transaction:{paymentResponse.TransactionId}";

					await _emailService.SendEmail(
						_pay360Config.PaymentCaptureFailureEmail,
						refundFailedMessage,
						false,
						"Transfer Via Paypal Failed-THA-App-" + paymentResponse.TransactionId);
				}
				_logger.Information($"Class=>Payment_BL, Method=>TransferByPayPalCallbackAsync, Message=> Balance transfer failed after successful payment, FromMsisdn=>{model.Msisdn},Product=>{model.TransferProduct}, NowTelRef=>{model.TransferNowtelRef}");
				PrepareUpdateTransactionLog(trasnactionLog, discountAmount, 2, "Balance transfer failed after successful payment");
				await _attRepo.UpdateTransactionLog(trasnactionLog);
				return GenericApiResponse<InternationalTopupInfo>.Failure(null,
												_localizer["BalanceTransferFailed"], ApiStatusCodes.UnSuccessful);
			}

			//var isFirstTopup = await AccountRepo.IsFirstTopUp(model.msisdn);
			var userBalance = await _accountRepo.GetUserAccountBalanceAsync(model.Msisdn);

			//Airship events
			await _airShipService.HandleIntTopupTagsAndEvents(
				   new IntTopupInfoAirShip()
				   {
					   IsSuccess = true,
					   IsCard = false,
					   Msisdn = model.Msisdn,
					   Destination = msisdnDest,
					   Origination = msisdnOrigin,
					   Amount = chargeAmount,
					   IsTransferRequest = model.IsTransferRequest,
				   });

			// Handle FaceBook Events
			await _faceBookService.HandleIntTopupEvents(model.AdvertiserId, msisdnOrigin, msisdnDest, true, false, chargeAmount, model.IsTransferRequest);

			// Handle AppsFlyer Events
			await _appsFlyerService.HandleIntTopupEvents(model.AppsFlyerId, deviceType, msisdnOrigin, msisdnDest, true, false, chargeAmount, null, model.IsTransferRequest);

			//TODO:Redeem promotion
			if (!string.IsNullOrEmpty(model.DiscountCode))
			{
				redemptionResult = await _voucherifyService.RedeemDiscount(
					new StackableDiscountRequest
					{
						Amount = productAmount,
						CheckoutType = CheckOutTypes.Transfer,
						DiscountCode = model.DiscountCode,
						DiscountCodeType = model.DiscountCodeType,
						DestinationCountryISOCode = msisdnDest,
						Operator = product.operatorName,
						PaymentMethod = PaymentMethods.Paypal,
					}, model.Msisdn, accountDetails.AccountID,
					new CustomerMetadata()
					{
						FirstInternationalTopup = isFirstInternationalTopup,
						FirstTopup = isFirstTopup,
						TransactionDone = !hasUserDoneTransaction,
					});
			}

			//Voucherify Events
			var internationalTopupPoints = Utility.CalculateInternationalTopupRewardPointsRange(productAmount, _voucherifyConfig.LoyaltyEarningRules.International);
			await _voucherifyService.PurchaseEvent(product.fromMsisdn, string.Format(VoucherifyEventsNames.InternationalTopup, internationalTopupPoints), new VoucherifyEventsMetadata { ChargeAmount = Convert.ToDecimal(product.CustomerChargeValue), Timestamp = DateTime.UtcNow, LoyaltyPoints = internationalTopupPoints });

			//Save transaction
			await _attRepo.SaveTransactionAsync(
				new DBTransferTransaction()
				{
					AccountId = accountDetails.AccountID,
					ClientCurrecny = product.fromCurrency,
					CountryCode = _helperService.GetCountryCode(product.tomsisdn),
					FromMsisdn = product.fromMsisdn,
					ToMsisdn = product.tomsisdn,
					ItemPrice = productAmount,
					ServiceFee = serviceFee,
					TotalPrice = chargeAmount,
					ServiceFeeDiscount = serviceFeeDiscount,
					TotalServiceFee = totalServiceFee,
					Discount = discountAmount,
					DiscountCode = model.DiscountCode,
					DiscountCodeType = model.DiscountCodeType,
					NowtelRef = model.TransferNowtelRef,
					OperatorCountryName = product.operatorCountryName,
					OperatorLogoUrl = product.operatorLogoUrl,
					OperatorName = product.operatorName,
					PaymentErrorMsg = null,
					TransferErrorMsg = null,
					PaymentRef = paymentResponse.TransactionId,
					TransferRef = executeTransResponse.reference,
					PaymentTypeId = InternationalTopupPaymentType.Paypal,
					StatusId = TransferTransactionStatus.Success,
					Product = Convert.ToDecimal(model.TransferProduct, CultureInfo.InvariantCulture),
					ReceiverCurrecny = product.toCurrency
				});

			//Send Email
			var userProfile = await _accountRepo.GetUserProfile(model.Msisdn);
			if (!string.IsNullOrEmpty(userProfile?.Data?.email))
			{
				var rewardPoints = Utility.CalculateInternationalTopupRewardPointsRange(productAmount, _voucherifyConfig.LoyaltyEarningRules.International);
				await SendInternationalTopupPaymentReceiptAsync(userProfile.Data.email, product, userProfile.Data, "Paypal", totalServiceFee, discountAmount, model.DiscountCode, rewardPoints, executeTransResponse.reference, executeTransResponse.pinCode);
			}
			PrepareUpdateTransactionLog(trasnactionLog, discountAmount, 1, string.Empty);
			await _attRepo.UpdateTransactionLog(trasnactionLog);
			return GenericApiResponse<InternationalTopupInfo>.Success(
				new InternationalTopupInfo()
				{
					CampaignName = redemptionResult != null ? redemptionResult?.Payload?.CampaignName : string.Empty,
					IsRedeemedSuccess = redemptionResult?.Payload?.RedemptionId != null,
					TopupAmount = product.fromAmount,
					Msisdn = model.Msisdn,
					TransactionId = paymentResponse.TransactionId,
					Currency = _helperService.ToCurrencySymbol(userBalance.Currency),
					NewBalance = userBalance.Balance,
					IsFirstInternationalTopup = isFirstInternationalTopup,
					FromAmount = Convert.ToDecimal(product.fromAmount, CultureInfo.InvariantCulture)
				}, _localizer["InternationalTopupSuccessfull"]);
		}

		#endregion

		#region Autotopup management and topup methods

		public async Task<GenericApiResponse<Pay360PaymentAmountResponseV2>> GetPaymentAmountsV2(string currency, string msisdn, string email, string accountTopupDescription)
		{
			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				if (userInfo.Status == Models.Enums.Status.Success)
				{
					if (userInfo.Data != null && !string.IsNullOrEmpty(userInfo.Data.email))
						email = userInfo.Data.email.Trim();
				}

			}

			var paymentAmount = new Pay360PaymentAmountResponseV2()
			{
				topupAmounts = _pay360Config.TopupAmounts,
				autoTopupAmounts = _pay360Config.AutoTopupAmount.Split(","),
				autoTopupThresholdAmount = _pay360Config.AutoTopupThresholdAmount.Split(","),
				currency = currency,
				AccountTopupPopup = new PopupInfo()
				{
					Description = accountTopupDescription,
					Heading = _localizer["AccountTopupHeading"]
				}
			};

			var autoTopupSettings = await _pay360Service.GetAutoTopUp(msisdn, email);

			if (autoTopupSettings.ErrorCode == 0)
			{
				paymentAmount.autoTopupSettings = autoTopupSettings.Payload;
				return GenericApiResponse<Pay360PaymentAmountResponseV2>.Success(paymentAmount, "Success");
			}
			else
			{
				return GenericApiResponse<Pay360PaymentAmountResponseV2>.Failure(
					autoTopupSettings.Message, ApiStatusCodes.InternalServerError);
			}
		}

		#endregion

		#endregion
		#region Set Auto Topup by Card
		public async Task<GenericApiResponse<CardPaymentResponseModel>> SetAutoTopupWithCard(SetAutoTopupWithCardRequestModel model, string msisdn, string accountId, string currency, string ipAddress, string email, string advertiserID)
		{
			if (model.AutoTopupInfo == null || model.AutoTopupInfo.TopupAmount <= 0)
			{
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
				   _localizer["TopupInfoMissing"],
				   ApiStatusCodes.BadRequest);
			}
			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				email = userInfo.Status == Models.Enums.Status.Success ? userInfo?.Data?.email?.Trim() : string.Empty;
			}
			DeviceType deviceType = (DeviceType)model.DeviceType;
			Pay360PaymentRequest paymentrequest = null;
			Pay360PaymentType paymentType = default;
			if (model.NewCardInfo is NewCardModel)
			{
				paymentType = Pay360PaymentType.New;
				paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
				{
					CustomerMsisdn = msisdn,
					ChargeAmount = _pay360Config.TestPaymentAmount,
					DiscountAmount = decimal.Zero,
					CheckoutPaymentType = CheckOutTypes.TopUp,
					BundleId = string.Empty,
					IpAddress = ipAddress,
					CustomerEmail = email,
					Currency = currency,
					Pay360PaymentType = Pay360PaymentType.New,
					CustomerAddressData = new AddressData()
					{
						AddressL1 = model.AddressInfo.AddressL1,
						AddressL2 = model.AddressInfo.AddressL2,
						AddressL3 = model.AddressInfo.AddressL3,
						AddressL4 = model.AddressInfo.AddressL4,
						PostCode = model.AddressInfo.PostCode,
						City = model.AddressInfo.City,
						Region = model.AddressInfo.Region,
						CountryCode = model.AddressInfo.CountryCode
					},
					CustomerCardData = new CardData()
					{
						CardNumber = model.NewCardInfo.CardNumber,
						NameOnCard = model.NewCardInfo.NameOnCard,
						SecurityCode = model.NewCardInfo.SecurityCode,
						ExpiryDate = model.NewCardInfo.ExpiryDate
					},
					ShouldSaveCard = true,
					IsDefaultCard = true,
					IsRecurring = true,
					accountNumber = accountId,
					CustomerUniqueRef = msisdn,
					OverrideValidation = true
				});

			}
			else if (model.ExistingCardInfo is ExistingCardModel)
			{
				paymentType = Pay360PaymentType.Token;
				paymentrequest = await GeneratePay360PaymentRequest(
				new Pay360PaymentRequestData()
				{
					CustomerMsisdn = msisdn,
					ChargeAmount = _pay360Config.TestPaymentAmount,
					DiscountAmount = decimal.Zero,
					CheckoutPaymentType = CheckOutTypes.TopUp,
					BundleId = string.Empty,
					IpAddress = ipAddress,
					CustomerEmail = email,
					Currency = currency,
					Pay360PaymentType = Pay360PaymentType.Token,
					accountNumber = accountId,
					CustomerUniqueRef = msisdn,
					CardToken = model.ExistingCardInfo.CardToken,
					SecurityCode = model.ExistingCardInfo.SecurityCode,
					OverrideValidation = true,
					IsRecurring = true
				});
			}
			var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, paymentType);
			return await HandleSetuAutoTopupWithCardPaymentResponse(model, msisdn, currency, ipAddress, email, advertiserID, accountId, deviceType, paymentrequest, paymentResponse);
		}
		public async Task<GenericApiResponse<CardPaymentResponseModel>> SetAutoTopupWithCardResume3DTransactionAsync(Resume3DPaymentRequest request, Resume3DPaymentDataRequest data)
		{
			GenericPay360ApiResponse<Pay360PaymentResponse> paymentResponse;

			if (data.Secure3dType.Equals("v1", StringComparison.InvariantCultureIgnoreCase))
			{
				paymentResponse = await _pay360Service.Resume3DV1Transaction(
					new Pay360Resume3DRequest()
					{
						pareq = request.PaRes,
						pay360TransactionId = request.MD,
						customerEmail = data.CustomerEmail
					});
			}
			else
			{
				paymentResponse = await _pay360Service.Resume3DV2Transaction(
					new Pay360Resume3DRequest()
					{
						pay360TransactionId = request.MD,
						customerEmail = data.CustomerEmail,
						overallStatus = request.OverallStatus
					});
			}

			// Cannot resume again scenario 
			if (paymentResponse != null
				&& paymentResponse.ErrorCode > 0
				&& (paymentResponse.Pay360ApiCode.Equals("V107")))
			{
				return HandlePay360PaymentFailureResponse<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, data.CheckoutType);
			}

			DeviceType deviceType = (DeviceType)data.DeviceType;
			var msisdnOrigin = _helperService.GetCountryCode(data.CustomerMsisdn);

			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(
											_helperService.GetSipUserName(data.CustomerMsisdn));

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
					data.PTId,
					false,
					null,
					paymentResponse == null ? "Payment Service Not Responding - Resume" : paymentResponse.ErrorCode + " - " + paymentResponse.Message + " - Resume",
					isTestPayment: true);

				return HandlePay360PaymentFailureResponse
						 <Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, data.CheckoutType);
			}

			//Successful payment
			//await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(data.PTId, true);

			//Fulfillment
			await Pay360CardPaymentFullfillment(paymentResponse, data.CustomerMsisdn, data.CustomerEmail, true, accountDetails.AccountID);

			//GetUserBalance
			var userBalance = await _accountRepo.GetUserAccountBalanceAsync(data.CustomerMsisdn);

			var currencySymbol = _helperService.ToCurrencySymbol(data.Currency);
			if (data.SaveCard)
			{
				await _airShipService.AddNamedUserTags(
					new NamedUserTagsRequest()
					{
						NamedUser = data.CustomerMsisdn,
						Tags = new List<string>() { "addcard_app" },
						TagGroup = _airShipConfig.ActivityTagGroupName
					});
			}

			//Set auto top-up
			if (data.AutoTopupThreshold > 0 && data.AutoToupAmount > 0)
			{
				var autoTopupRes = await _autoTopupDL.Set(
					new AutoTopupDetail()
					{
						Topup = data.AutoToupAmount,
						Status = true,
						ThresHold = data.AutoTopupThreshold,
						Msisdn = data.CustomerMsisdn,
						Currency = data.Currency,
						PaymentMethod = PaymentMethods.Card,
						CardInitialTransactionId = paymentResponse.Payload.transactionId,
						CardMaskedPAN = paymentResponse.Payload.maskedPan,
						PaypalSubscriptionId = null
					});

				if (autoTopupRes > 0)
				{
					await _airShipService.HandleAutoTopup(data.CustomerMsisdn, data.IsAutoTopUp);
				}
			}
			//Refund amount as this was test transaction
			var refundResponse = await _pay360Service.RefundFullPayment(new Models.Contracts.Request.RefundFullPaymentRequestModel
			{
				transactionId = paymentResponse.Payload.transactionId
			});
			if (refundResponse?.ErrorCode != 0)
			{
				_logger.Error($"Payment refund error Transaction Id:{paymentResponse.Payload.transactionId}");
			}
			//Payment successfull
			await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(data.PTId, true, isTestPayment: true);
			return GenericApiResponse<CardPaymentResponseModel>.Success(
				new CardPaymentResponseModel()
				{
					topupInfo = new TopupInfo()
					{
						TopupAmount = paymentResponse.Payload.transactionAmount,
						Msisdn = data.CustomerMsisdn,
						TransactionId = paymentResponse.Payload.transactionId,
						Currency = currencySymbol,
						NewBalance = userBalance.Balance
					},
					customerMsisdn = data.CustomerMsisdn,
					transactionId = paymentResponse.Payload.transactionId
				}, _localizer["TopUpSuccessful", paymentResponse.Payload.transactionAmount]);
		}

		private async Task<GenericApiResponse<CardPaymentResponseModel>> HandleSetuAutoTopupWithCardPaymentResponse(SetAutoTopupWithCardRequestModel model, string msisdn, string currency, string ipAddress, string email, string advertiserID, string accountId, DeviceType deviceType, Pay360PaymentRequest paymentrequest, GenericPay360ApiResponse<Pay360PaymentResponse> paymentResponse)
		{
			string msisdnOrigin = _helperService.GetCountryCode(msisdn);
			int paymentTransactionId = default;
			if (model.NewCardInfo is NewCardModel)
			{
				//save transaction
				paymentTransactionId = await _paymentFullfillmentDL.InsertTransactionPaymentAsync(
				   paymentrequest.Pay360PaymentRequestNew.basket,
				   paymentrequest.Pay360PaymentRequestNew.transactionCurrency,
				   paymentrequest.Pay360PaymentRequestNew.customerEmail,
				   paymentrequest.Pay360PaymentRequestNew.productCode,
				   paymentResponse?.Payload?.transactionId,
				   paymentrequest.Pay360PaymentRequestNew.customerMsisdn,
				   TransactionsPaymentType.Card,
				   0,
				   false,
				   null, null);
			}
			else
			{
				paymentTransactionId = await _paymentFullfillmentDL.InsertTransactionPaymentAsync(
				   paymentrequest.Pay360PaymentRequestToken.basket,
				   paymentrequest.Pay360PaymentRequestToken.transactionCurrency,
				   paymentrequest.Pay360PaymentRequestToken.customerEmail,
				   paymentrequest.Pay360PaymentRequestToken.productCode,
				   paymentResponse?.Payload?.transactionId,
				   paymentrequest.Pay360PaymentRequestToken.customerMsisdn,
				   TransactionsPaymentType.Card,
				   0,
				   false,
				   null, null);
			}

			//Handle Error Scenarios
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId,
						false,
						null,
						paymentResponse == null ? "Payment Service Not Responding - Null Response - New Customer"
						: $"{paymentResponse.ErrorCode} - {paymentResponse.Message} - New Customer",
						isTestPayment: true);

				return HandlePay360PaymentFailureResponse
					<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, CheckOutTypes.TopUp);
			}

			if (paymentResponse.Payload.outcome.reasonCode == "U100") //3d Secure Scenario
			{
				/*Make sure to encrypt url here
                   * Convert the hardcoded string to classs
                   * and Implement the class to query string convertsion method
                   */

				var secure3dType = paymentResponse.Payload.clientRedirect.type.ToLower().Contains("v2") ? "v2" : "v1";

				var airshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();

				var returnUrlBuilder = new StringBuilder();
				returnUrlBuilder.Append($"{_inAppPageConfig.BaseUrl}/SetAutoTopupWithCardResume3DTransaction")
					.Append($"?CheckoutType={(int)CheckOutTypes.TopUp}")
					.Append($"&CustomerEmail={email}")
					.Append($"&CustomerMsisdn={msisdn}")
					.Append($"&Currency={currency}")
					.Append($"&BundleId={string.Empty}")
					.Append($"&Secure3dType={secure3dType}")
					.Append($"&PTId={paymentTransactionId}")
					.Append($"&Ip={ipAddress}")
					.Append($"&advertiserID={advertiserID}")
					.Append($"&airshipEventsDisable={airshipEventsDisable}")
					.Append($"&SaveCard={true}")
					.Append($"&culture={_localizer["Locale"]}");

				if (model.AppsFlyerId != null)
				{
					returnUrlBuilder.Append($"&AppsFlyerId={model.AppsFlyerId}")
								 .Append($"&DeviceType={model.DeviceType}");
				}

				returnUrlBuilder.Append($"&IsAutoTopUp={true}")
							 .Append($"&AutoToupAmount={model.AutoTopupInfo.TopupAmount}")
							 .Append($"&AutoTopupThreshold={model.AutoTopupInfo.ThresholdAmount}");

				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId, false, paymentResponse.Payload.transactionId, isTestPayment: true);

				//Send Response
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
												new CardPaymentResponseModel()
												{
													threeDSecureData = new ThreeDSecureData()
													{
														pareq = paymentResponse.Payload.clientRedirect.pareq,
														redirectUrl = paymentResponse.Payload.clientRedirect.url,
														transactionId = paymentResponse.Payload.transactionId,
														returnUrl = returnUrlBuilder.ToString(),
														type = secure3dType,
														threeDSServerTransId = paymentResponse.Payload.clientRedirect.threeDSServerTransId
													}
												}, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);
			}
			else if (paymentResponse.Payload.outcome.reasonCode == "S100")
			{
				//Payment successfull
				//await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, true);

				//Fulfillment
				await Pay360CardPaymentFullfillment(paymentResponse, msisdn, email, true, accountId);

				//Get Updated User Balance
				var userBalance = await _accountRepo.GetUserAccountBalanceAsync(msisdn);

				var currencySymbol = _helperService.ToCurrencySymbol(currency);

				await _airShipService.AddNamedUserTags(
					new NamedUserTagsRequest()
					{
						NamedUser = msisdn,
						Tags = new List<string>() { "addcard_app" },
						TagGroup = _airShipConfig.ActivityTagGroupName
					});

				var autoTopupResp = await _autoTopupDL.Set(new AutoTopupDetail
				{
					Status = true,
					CardInitialTransactionId = paymentResponse.Payload.transactionId,
					CardMaskedPAN = paymentResponse.Payload.maskedPan,
					Currency = currency,
					Msisdn = msisdn,
					PaymentMethod = PaymentMethods.Card,
					PaypalSubscriptionId = null,
					ThresHold = model.AutoTopupInfo.ThresholdAmount,
					Topup = model.AutoTopupInfo.TopupAmount,
				});
				if (autoTopupResp > 0)
				{
					await _airShipService.HandleAutoTopup(msisdn, true);
				}
				//Refund amount as this was test transaction
				var refundResponse = await _pay360Service.RefundFullPayment(new Models.Contracts.Request.RefundFullPaymentRequestModel
				{
					transactionId = paymentResponse.Payload.transactionId
				});
				if (refundResponse?.ErrorCode != 0)
				{
					_logger.Error($"Payment refund error Transaction Id:{paymentResponse.Payload.transactionId}");
				}
				//Payment successfull
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, true, isTestPayment: true);


				return GenericApiResponse<CardPaymentResponseModel>.Success(
					new CardPaymentResponseModel()
					{
						topupInfo = new TopupInfo()
						{
							TopupAmount = paymentResponse.Payload.transactionAmount,
							Msisdn = msisdn,
							TransactionId = paymentResponse.Payload.transactionId,
							Currency = currencySymbol,
							NewBalance = userBalance.Balance,
						},
						customerMsisdn = msisdn,
						transactionId = paymentResponse.Payload.transactionId
					}, _localizer["TopUpSuccessful", paymentResponse.Payload.transactionAmount]);
			}

			return GenericApiResponse<CardPaymentResponseModel>.Failure(
				null, _localizer["PaymentServiceNotResponding"], ApiStatusCodes.PaymentServiceError);
		}

		//created method to handle bundle auto renewal request with card
		public async Task<GenericApiResponse<CardPaymentResponseModel>> SetAutoBundleRenewalWithCard(SetAutoRenewalCardRequestModel model, string msisdn, string accountId, string currency, string ipAddress, string email, string advertiserID)
		{

			if (string.IsNullOrEmpty(email))
			{
				var userInfo = await _accountRepo.GetUserProfile(msisdn);
				email = userInfo.Status == Models.Enums.Status.Success ? userInfo?.Data?.email?.Trim() : string.Empty;
			}
			DeviceType deviceType = (DeviceType)model.DeviceType;
			Pay360PaymentRequest paymentrequest = null;
			Pay360PaymentType paymentType = default;

			if (model.NewCardInfo is NewCardModel)
			{
				paymentType = Pay360PaymentType.New;
				paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
				{
					CustomerMsisdn = msisdn,
					ChargeAmount = _pay360Config.TestPaymentAmount,
					DiscountAmount = decimal.Zero,
					CheckoutPaymentType = CheckOutTypes.Bundle,
					BundleId = model.AutoRenewalInfo.BundleId,
					IpAddress = ipAddress,
					CustomerEmail = email,
					Currency = currency,
					Pay360PaymentType = Pay360PaymentType.New,
					CustomerAddressData = new AddressData()
					{
						AddressL1 = model.AddressInfo.AddressL1,
						AddressL2 = model.AddressInfo.AddressL2,
						AddressL3 = model.AddressInfo.AddressL3,
						AddressL4 = model.AddressInfo.AddressL4,
						PostCode = model.AddressInfo.PostCode,
						City = model.AddressInfo.City,
						Region = model.AddressInfo.Region,
						CountryCode = model.AddressInfo.CountryCode
					},
					CustomerCardData = new CardData()
					{
						CardNumber = model.NewCardInfo.CardNumber,
						NameOnCard = model.NewCardInfo.NameOnCard,
						SecurityCode = model.NewCardInfo.SecurityCode,
						ExpiryDate = model.NewCardInfo.ExpiryDate
					},
					ShouldSaveCard = true,
					IsDefaultCard = true,
					IsRecurring = true,
					accountNumber = accountId,
					CustomerUniqueRef = msisdn,
					OverrideValidation = true
				});

			}
			else if (model.ExistingCardInfo is ExistingCardModel)
			{
				paymentType = Pay360PaymentType.Token;
				paymentrequest = await GeneratePay360PaymentRequest(
				new Pay360PaymentRequestData()
				{
					CustomerMsisdn = msisdn,
					ChargeAmount = _pay360Config.TestPaymentAmount,
					DiscountAmount = decimal.Zero,
					CheckoutPaymentType = CheckOutTypes.Bundle,
					BundleId = model.AutoRenewalInfo.BundleId,
					IpAddress = ipAddress,
					CustomerEmail = email,
					Currency = currency,
					Pay360PaymentType = Pay360PaymentType.Token,
					accountNumber = accountId,
					CustomerUniqueRef = msisdn,
					CardToken = model.ExistingCardInfo.CardToken,
					SecurityCode = model.ExistingCardInfo.SecurityCode,
					OverrideValidation = true,
					IsRecurring = true
				});
			}

			var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, paymentType);
			return await HandleAutoBundleRenewalWithCardPaymentResponse(model, msisdn, currency, ipAddress, email, advertiserID, accountId, deviceType, paymentrequest, paymentResponse);
		}

		//Method for handling payment response and creating fullfillment with refund amount based on card type
		private async Task<GenericApiResponse<CardPaymentResponseModel>> HandleAutoBundleRenewalWithCardPaymentResponse(SetAutoRenewalCardRequestModel model, string msisdn, string currency, string ipAddress, string email, string advertiserID, string accountId, DeviceType deviceType, Pay360PaymentRequest paymentrequest, GenericPay360ApiResponse<Pay360PaymentResponse> paymentResponse)
		{
			int paymentTransactionId = default;
			if (model.NewCardInfo is NewCardModel)
			{
				//save transaction
				paymentTransactionId = await _paymentFullfillmentDL.InsertTransactionPaymentAsync(
				   paymentrequest.Pay360PaymentRequestNew.basket,
				   paymentrequest.Pay360PaymentRequestNew.transactionCurrency,
				   paymentrequest.Pay360PaymentRequestNew.customerEmail,
				   paymentrequest.Pay360PaymentRequestNew.productCode,
				   paymentResponse?.Payload?.transactionId,
				   paymentrequest.Pay360PaymentRequestNew.customerMsisdn,
				   TransactionsPaymentType.Card,
				   0,
				   false,
				   null, null);
			}
			else
			{
				//update transaction
				paymentTransactionId = await _paymentFullfillmentDL.InsertTransactionPaymentAsync(
				   paymentrequest.Pay360PaymentRequestToken.basket,
				   paymentrequest.Pay360PaymentRequestToken.transactionCurrency,
				   paymentrequest.Pay360PaymentRequestToken.customerEmail,
				   paymentrequest.Pay360PaymentRequestToken.productCode,
				   paymentResponse?.Payload?.transactionId,
				   paymentrequest.Pay360PaymentRequestToken.customerMsisdn,
				   TransactionsPaymentType.Card,
				   0,
				   false,
				   null, null);
			}

			//Handle Error Scenarios
			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId,
						false,
						null,
						paymentResponse == null ? "Payment Service Not Responding - Null Response - New Customer"
						: $"{paymentResponse.ErrorCode} - {paymentResponse.Message} - New Customer",
						isTestPayment: true);

				return HandlePay360PaymentFailureResponse
					<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, CheckOutTypes.TopUp);
			}

			if (paymentResponse.Payload.outcome.reasonCode == "U100") //3d Secure Scenario
			{
				/*Make sure to encrypt url here
                   * Convert the hardcoded string to classs
                   * and Implement the class to query string convertsion method
                   */

				var secure3dType = paymentResponse.Payload.clientRedirect.type.ToLower().Contains("v2") ? "v2" : "v1";

				var airshipEventsDisable = _httpContext.HttpContext.AirshipEventsDisable();

				var returnUrlBuilder = new StringBuilder();
				returnUrlBuilder.Append($"{_inAppPageConfig.BaseUrl}/SetAutoRenewalWithCardResume3DTransaction")
					.Append($"?CheckoutType={(int)CheckOutTypes.Bundle}")
					.Append($"&CustomerEmail={email}")
					.Append($"&CustomerMsisdn={msisdn}")
					.Append($"&Currency={currency}")
					.Append($"&Secure3dType={secure3dType}")
					.Append($"&PTId={paymentTransactionId}")
					.Append($"&Ip={ ipAddress}")
					.Append($"&advertiserID={advertiserID}")
					.Append($"&airshipEventsDisable={airshipEventsDisable}")
					.Append($"&SaveCard={true}")
					.Append($"&culture={_localizer["Locale"]}")
					.Append($"&IsAutoRenewal={true}")
					.Append($"&BundleId={model.AutoRenewalInfo.BundleId}");

				if (model.AppsFlyerId != null)
				{
					returnUrlBuilder.Append($"&AppsFlyerId={model.AppsFlyerId}")
								.Append($"&DeviceType={model.DeviceType}");
				}


				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
						paymentTransactionId, false, paymentResponse.Payload.transactionId, isTestPayment: true);

				//Send Response
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
												new CardPaymentResponseModel()
												{
													threeDSecureData = new ThreeDSecureData()
													{
														pareq = paymentResponse.Payload.clientRedirect.pareq,
														redirectUrl = paymentResponse.Payload.clientRedirect.url,
														transactionId = paymentResponse.Payload.transactionId,
														returnUrl = returnUrlBuilder.ToString(),
														type = secure3dType,
														threeDSServerTransId = paymentResponse.Payload.clientRedirect.threeDSServerTransId
													}
												}, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);
			}
			else if (paymentResponse.Payload.outcome.reasonCode == "S100")
			{
				//Payment successfull
				//await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, true, isPaymentRefund: true);//this method will set the is payment success bit

				//Fulfillment
				await Pay360CardPaymentFullfillment(paymentResponse, msisdn, email, true, accountId);

				var currencySymbol = _helperService.ToCurrencySymbol(currency);

				await _airShipService.AddNamedUserTags(
					new NamedUserTagsRequest()
					{
						NamedUser = msisdn,
						Tags = new List<string>() { "addcard_app" },
						TagGroup = _airShipConfig.ActivityTagGroupName
					});

				string bundleDest = string.Empty;

				//Get Bundle details
				var bundleResponse = await _bundleRepo.GetBundleById(model.AutoRenewalInfo.BundleId, accountId);
				if (bundleResponse == null)
				{
					return GenericApiResponse<CardPaymentResponseModel>.Failure(
												_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
				}

				//Refund amount as this was test transaction
				var refundResponse = await _pay360Service.RefundFullPayment(new Models.Contracts.Request.RefundFullPaymentRequestModel
				{
					transactionId = paymentResponse.Payload.transactionId
				});

				//Payment successfull
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(paymentTransactionId, true, isTestPayment: true);

				bundleDest = bundleResponse.Description.Replace(" ", "").Replace(",", "");

				var autoRenewRes = await _bundleRepo.SetBundleAutoRenewalV2(
					true,
					msisdn,
					accountId,
					model.AutoRenewalInfo.BundleId,
					false,
					PaymentMethods.Card,
					paymentResponse.Payload.maskedPan,
					paymentResponse.Payload.transactionId,
					null);
				if (autoRenewRes.isValid && bundleResponse.BundleType != BundleType.Welcome)
				{
					await _airShipService.HandleAutoRenew(
						msisdn, true, bundleDest, bundleResponse.BundleType);
				}

				return GenericApiResponse<CardPaymentResponseModel>.Success(
					new CardPaymentResponseModel()
					{
						bundlePurchaseInfo = new BundlePurchaseInfo()
						{
							TransactionId = paymentResponse.Payload.transactionId,
							BundleAmount = paymentResponse.Payload.transactionAmount,
							BundleName = bundleResponse.BrandedName,
							Msisdn = msisdn,
							Currency = currencySymbol,
							Destination = bundleDest,
							Type = bundleResponse.BundleType,
						},
						customerMsisdn = msisdn,
						transactionId = paymentResponse.Payload.transactionId
					}, _localizer["SetBundleAutoRenewalSuccessfull", paymentResponse.Payload.transactionAmount]);
			}

			return GenericApiResponse<CardPaymentResponseModel>.Failure(
				null, _localizer["PaymentServiceNotResponding"], ApiStatusCodes.PaymentServiceError);
		}
		/// <summary>
		/// This method will be call from the SetAutoRenewalWithCardResume3DTransaction method to update transaction details 
		/// and set bundble auto renewal for the specified bundle with card details 3Ds or Non 3Ds
		/// </summary>
		/// <param name="request"></param>
		/// <param name="data"></param>
		/// <returns></returns>
		public async Task<GenericApiResponse<CardPaymentResponseModel>> SetAutoBundleRenewalCardResume3DTransactionAsync(Resume3DPaymentRequest request, Resume3DPaymentDataRequest data)
		{
			GenericPay360ApiResponse<Pay360PaymentResponse> paymentResponse;

			if (data.Secure3dType.Equals("v1", StringComparison.InvariantCultureIgnoreCase))
			{
				paymentResponse = await _pay360Service.Resume3DV1Transaction(
					new Pay360Resume3DRequest()
					{
						pareq = request.PaRes,
						pay360TransactionId = request.MD,
						customerEmail = data.CustomerEmail
					});
			}
			else
			{
				paymentResponse = await _pay360Service.Resume3DV2Transaction(
					new Pay360Resume3DRequest()
					{
						pay360TransactionId = request.MD,
						customerEmail = data.CustomerEmail,
						overallStatus = request.OverallStatus
					});
			}

			// Cannot resume again scenario 
			if (paymentResponse != null
				&& paymentResponse.ErrorCode > 0
				&& (paymentResponse.Pay360ApiCode.Equals("V107")))
			{
				return HandlePay360PaymentFailureResponse<Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, data.CheckoutType);
			}

			var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername(
											_helperService.GetSipUserName(data.CustomerMsisdn));

			if (paymentResponse == null || paymentResponse.ErrorCode > 0)
			{
				await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(
					data.PTId,
					false,
					null,
					paymentResponse == null ? "Payment Service Not Responding - Resume" : paymentResponse.ErrorCode + " - " + paymentResponse.Message + " - Resume",
					isTestPayment: true);

				return HandlePay360PaymentFailureResponse
						 <Pay360PaymentResponse, CardPaymentResponseModel>(paymentResponse, data.CheckoutType);
			}

			//Successful payment
			//await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(data.PTId, true);

			//Fulfillment
			await Pay360CardPaymentFullfillment(paymentResponse, data.CustomerMsisdn, data.CustomerEmail, true, accountDetails.AccountID);

			//GetUserBalance
			//var userBalance = await _accountRepo.GetUserAccountBalanceAsync(data.CustomerMsisdn);

			var currencySymbol = _helperService.ToCurrencySymbol(data.Currency);
			if (data.SaveCard)
			{
				await _airShipService.AddNamedUserTags(
					new NamedUserTagsRequest()
					{
						NamedUser = data.CustomerMsisdn,
						Tags = new List<string>() { "addcard_app" },
						TagGroup = _airShipConfig.ActivityTagGroupName
					});
			}


			string bundleDest = string.Empty;

			//Get Bundle details
			var bundleResponse = await _bundleRepo.GetBundleById(data.BundleId, accountDetails.AccountID);
			if (bundleResponse == null)
			{
				return GenericApiResponse<CardPaymentResponseModel>.Failure(
											_localizer["InvalidBundle"], ApiStatusCodes.InvalidBundle);
			}

			//Refund amount as this was test transaction
			var refundResponse = await _pay360Service.RefundFullPayment(new Models.Contracts.Request.RefundFullPaymentRequestModel
			{
				transactionId = paymentResponse.Payload.transactionId
			});
			if (refundResponse?.ErrorCode != 0)
			{
				_logger.Error($"Payment refund error Transaction Id:{paymentResponse.Payload.transactionId}");
			}

			//Payment successfull
			await _paymentFullfillmentDL.UpdatePaymentTransactionAsync(data.PTId, true, isTestPayment: true);


			bundleDest = bundleResponse.Description.Replace(" ", "").Replace(",", "");

			var autoRenewRes = await _bundleRepo.SetBundleAutoRenewalV2(
				true,
				data.CustomerMsisdn,
				accountDetails.AccountID,
				data.BundleId,
				false,
				PaymentMethods.Card,
				paymentResponse.Payload.maskedPan,
				paymentResponse.Payload.transactionId,
				null);
			if (autoRenewRes.isValid && bundleResponse.BundleType != BundleType.Welcome)
			{
				await _airShipService.HandleAutoRenew(
					data.CustomerMsisdn, true, bundleDest, bundleResponse.BundleType);
			}

			return GenericApiResponse<CardPaymentResponseModel>.Success(
				new CardPaymentResponseModel()
				{
					bundlePurchaseInfo = new BundlePurchaseInfo()
					{
						TransactionId = paymentResponse.Payload.transactionId,
						BundleAmount = paymentResponse.Payload.transactionAmount,
						BundleName = bundleResponse.BrandedName,
						Msisdn = data.CustomerMsisdn,
						Currency = currencySymbol,
						Destination = bundleDest,
						Type = bundleResponse.BundleType,
					},
					customerMsisdn = data.CustomerMsisdn,
					transactionId = paymentResponse.Payload.transactionId
				}, _localizer["SetBundleRenewalSuccessful", paymentResponse.Payload.transactionAmount]);
		}


		#endregion

		#region Email Helper methods

		private async Task SendInternationalTopupPaymentReceiptAsync(string PaymentEmailAddress, DBProduct product, Profile userProfile, string paymentMethod, decimal serviceFee, decimal discountAmount, string discountCode, int rewardPointsEarned, string transactionId, string pinCode)
		{
			try
			{
				if (!userProfile.emailVerified)
					return;
				var builder = new BodyBuilder();
				using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\International-topup-payment-reciept.html").Replace("~\\", ""))))
				{
					builder.HtmlBody = SourceReader.ReadToEnd();
				}

				string messageBody = builder.HtmlBody
					.Replace("%TIMESTAMP%", DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"))
					.Replace("%FIRST_NAME%", userProfile?.firstName)
					.Replace("%EMAIL%", userProfile?.email)
					.Replace("%TOPUPNUMBER%", product.tomsisdn)
					.Replace("%TOPUPCOUNTRY%", product.operatorCountryName)
					.Replace("%RCVAMOUNT%", _helperService.ToMonetaryUnit(product.toAmount, product.toCurrency))
					.Replace("%AMOUNT%", _helperService.ToMonetaryUnit(product.fromAmount, product.fromCurrency))
					.Replace("%SERVICEFEE%", _helperService.ToMonetaryUnit(serviceFee, product.fromCurrency))
					.Replace("%SERVICEFEE%", _helperService.ToMonetaryUnit(serviceFee, product.fromCurrency))
					.Replace("%DISCOUNT%", _helperService.ToMonetaryUnit(discountAmount, product.fromCurrency))
					.Replace("%DISCOUNTCODE%", discountCode)
					.Replace("%REWARDPOINTSEARNED%", rewardPointsEarned.ToString())
					.Replace("%TOPUPOPERATOR%", product.operatorName)
					.Replace("%PAYMENTMETHOD%", paymentMethod)
						  .Replace("%TRANSACTIONID%", transactionId);

				if (string.IsNullOrEmpty(pinCode))
				{
					if (messageBody.Contains("<tr id=\"row_pinCode\">"))
					{
						messageBody = messageBody.Replace("<tr id=\"row_pinCode\">", "<tr id=\"row_pinCode\" style=\"display:none\">");
					}
				}
				else
				{
					messageBody = messageBody.Replace("%PINCODE%", pinCode);
				}

				await _emailService.SendEmail(PaymentEmailAddress, messageBody, true, "Mobile Top-up Sent Successfully");

			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: Payment_BL, Method: SendInternationalTopupPaymentReceiptAsync");
			}
		}
		private async Task SendBundlePurchasePaymentReceiptAsync(string PaymentEmailAddress, Bundles bundleDetails, string currency, Profile profile, string paymentMethod)
		{
			try
			{
				if (!profile.emailVerified)
					return;
				var builder = new BodyBuilder();
				using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\Bundle-purchase-reciept.html").Replace("~\\", ""))))
				{
					builder.HtmlBody = SourceReader.ReadToEnd();
				}
				string messageBody = builder.HtmlBody
					.Replace("%FIRST_NAME%", profile.firstName)
					.Replace("%EMAIL%", profile.email)
					.Replace("%BUNDLE_NAME%", bundleDetails?.BrandedName)
					.Replace("%PAYMENT_METHOD%", paymentMethod)
					.Replace("%COUNTRY%", _helperService.GetCountryNamebyCoutryISCode(bundleDetails.Description).ToUpper())
					.Replace("%TOTAL_MINUTES%", bundleDetails?.Minutes.ToString())
					.Replace("%AMOUNT%", _helperService.ToMonetaryUnit(bundleDetails.TotalCostPence / 100, currency))
					.Replace("%TIMESTAMP%", DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"));
				await _emailService.SendEmail(PaymentEmailAddress, messageBody, true, "Bundle Payment Reciept");
			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: Payment_BL, Method: SendInternationalTopupPaymentReceiptAsync");
			}
		}
		private async Task SendTopupPaymentReceiptAsync(string PaymentEmailAddress, string missdn, decimal amount, Profile profile, string paymentMethod)
		{
			try
			{
				if (!profile.emailVerified)
					return;
				var accountDetails = await _accountRepo.GetAccountDetailsBySipUsername("THA" + missdn);
				var builder = new BodyBuilder();
				using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\Topup-payment-reciept.html").Replace("~\\", ""))))
				{
					builder.HtmlBody = SourceReader.ReadToEnd();
				}


				string messageBody = builder.HtmlBody
					.Replace("%FIRST_NAME%", profile.firstName)
					.Replace("%EMAIL%", profile.email)
					.Replace("%TIMESTAMP%", DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"))
					.Replace("%PAYMENT_METHOD%", paymentMethod)
					.Replace("%SOURCE%", "Top-Up")
					.Replace("%AVAILABLE_BALANCE%", _helperService.ToMonetaryUnit(accountDetails.Balance, accountDetails.Currency))
					.Replace("%AMOUNT%", _helperService.ToMonetaryUnit(amount, accountDetails.Currency));

				await _emailService.SendEmail(PaymentEmailAddress, messageBody, true, "Topup Payment Reciept");

			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: Payment_BL, Method: SendTopupPaymentReceiptAsync");
			}
		}

		#endregion
	}
}