﻿namespace THAApi.Resources
{
    public class Language
    {
    }
}
