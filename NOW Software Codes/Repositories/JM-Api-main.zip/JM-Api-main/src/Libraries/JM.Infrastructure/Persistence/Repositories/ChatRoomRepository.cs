using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.EntityFrameworkCore;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;

public sealed class ChatRoomRepository(AppDbContext context, ILogger logger) : IChatRoomRepository
{
    private readonly AppDbContext _context = context;
    private readonly ILogger _logger = logger;

    public async Task<ChatRoom> AddChatRoom(ChatRoom friChatRoom)
    {
        try
        {
            var addedChatRoom = await _context.Set<ChatRoom>().AddAsync(friChatRoom);
            await _context.Entry(addedChatRoom.Entity).Reference(f => f.Trip).LoadAsync();

            return addedChatRoom.Entity;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ChatRoomRepository), nameof(AddChatRoom));
            return default!;
        }
    }
    public void UpdateChatRoom(ChatRoom friChatRoom)
    {
        try
        {
            _context.Entry(friChatRoom).CurrentValues.SetValues(friChatRoom);
            _context.Entry(friChatRoom).State = EntityState.Modified;
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ChatRoomRepository), nameof(UpdateChatRoom));
        }
    }
    public async Task<ChatRoom?> GetChatRoom(Expression<Func<ChatRoom, bool>> expression)
    {
        try
        {
            return await _context.Set<ChatRoom>()
                .Where(expression)
                .Include(x => x.Trip)
                .ThenInclude(x => x.Travelers).ThenInclude(x => x.User).ThenInclude(x => x.UserDetail)
                .FirstOrDefaultAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ChatRoomRepository), nameof(GetChatRoom));
            return default!;
        }
    }
    public async Task<IEnumerable<ChatRoom>> GetChatRoomList(Expression<Func<ChatRoom, bool>> expression = default!)
    {
        try
        {
            var query = _context.Set<ChatRoom>()
               .Include(x => x.Trip)
                .ThenInclude(x => x.Travelers).ThenInclude(x => x.User).ThenInclude(x => x.UserDetail);
            return expression is null ? await query.ToListAsync() : await query.Where(expression).ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ChatRoomRepository), nameof(GetChatRoomList));
            return default!;
        }
    }
}
