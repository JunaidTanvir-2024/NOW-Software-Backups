﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static TalkhomeWebApp.Models.ViewModels.LandingPageModel;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class CountryBundleInfoModel
    {
        public CountryBundleInfoModel()
        {
            CountryContent = new CountryContent();
            CountryRates = new Rates();
            Bundles = new List<Bundles>();
        }
        public Rates CountryRates { get; set; }
        public List<Topup> Topups { get; set; } = new List<Topup>();
        public List<Bundles> Bundles { get; set; }
        public CountryContent CountryContent { get; set; }
        public string MinorCurrencyunit { get; set; }
        public string CurrencySymbol { get; set; }
        public string CurrentCurreny { get; set; }
    }

    public class LandingPageModel
    {
        public LandingPageModel()
        {
            CountryContent = new CountryContent();
            CountryData = new CountryModel();
            CountryRates = new Rates();
            Bundles = new List<Bundles>();
        }
        public CountryContent CountryContent { get; set; }
        public CountryModel CountryData { get; set; }
        public Rates CountryRates { get; set; }
        public string MinorCurrencyunit { get; set; }
        public string CurrencySymbol { get; set; }
        public List<Bundles> Bundles { get; set; }
        public string CurrentCurreny { get; set; }
        public List<Topup> Topups { get; set; } = new List<Topup>();
        public class Topup
        {
            public decimal Price { get; set; }
            public int Minutes { get; set; }
        }
        public SendCreditByCountryViewModel sendCreditByCountry { get; set; }
    }
    public class CountryContent
    {
        public string Keywords { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public string MainHeadline { get; set; }
        public string MainHeadlinesDescription { get; set; }
        public string InternationalCallingRatesHeading { get; set; }
        public string InternationalCallingRatesDescription { get; set; }
        public string InternationalTopupHeading { get; set; }
        public string InternationalTopupDescription { get; set; }
        public string PopularDestinationHeading { get; set; }
        public string PopularDestinationDescription { get; set; }
        public List<popularDestinations> PopularDestinations { get; set; }
        public string THAHeading { get; set; }
        public string THADescription { get; set; }
        public string WhyChooseTHMHeading { get; set; }
        public List<WhyChooseTHMDescription> WhyChooseTHMDescription { get; set; }
        public string CompletePackageHeading { get; set; }
        public string CompletePackageDescription { get; set; }
        public string UserExperiencesDescription { get; set; }
        public List<UserExperience> UserExperiences { get; set; }
        public List<Faq> Faqs { get; set; }
        public string picurl1 { get; set; }
        public string picurl2 { get; set; }
        public string picurl3 { get; set; }
        public string metakeywords { get; set; }
        public string metadesc { get; set; }
        public string metaTitle { get; set; }


    }
    public class popularDestinations
    {
        public string DestinationName { get; set; }
        public string DestinationISO { get; set; }
    }
    public class WhyChooseTHMDescription
    {
        public string ItemHeading { get; set; }
        public string ItemText { get; set; }
    }

    public class UserExperience
    {
        public string UserName { get; set; }
        public string ExperienceTitle { get; set; }
        public string UserExperienceText { get; set; }
    }

    public class Faq
    {
        public string Question { get; set; }
        public string Answer { get; set; }
    }

}
