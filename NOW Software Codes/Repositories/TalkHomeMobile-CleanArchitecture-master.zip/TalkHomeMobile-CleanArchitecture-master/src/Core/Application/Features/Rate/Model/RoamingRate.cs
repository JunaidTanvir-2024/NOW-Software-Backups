namespace Application.Features.Rate.Model;

//public class RoamingRate
//{
//    public int Id { get; set; }
//    public string? IsoCode { get; set; }
//    public string? Country { get; set; }
//    public int CountryCode { get; set; }
//    public decimal UkCall { get; set; }
//    public decimal LocalCall { get; set; }
//    public decimal EuCall { get; set; }
//    public decimal InternationalCall { get; set; }
//    public decimal OutboundSms { get; set; }
//    public decimal InboundSms { get; set; }
//    public decimal Data { get; set; }
//    public decimal InboundCall { get; set; }
//}

public class RoamingRate
{
    public int FromCountry { get; set; }
    public int ToCountry { get; set; }
    public float Call { get; set; }
    public float SMS { get; set; }
    public float Data { get; set; }
    public float ReceivedCall { get; set; }
    public string Code { get; set; } = string.Empty;
    public bool IsEU { get; set; } = false;
}
