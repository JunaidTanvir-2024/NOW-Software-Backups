﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;

namespace THAAPI.Filters
{
    public class SwaggerAuthFilters : IOperationFilter
	{
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            var actionName = context.ApiDescription.ActionDescriptor.RouteValues["action"];
            var controllerName = context.ApiDescription.ActionDescriptor.RouteValues["controller"];
            if (controllerName.Equals("useraccount", StringComparison.CurrentCultureIgnoreCase)
                && actionName.Equals("login", StringComparison.InvariantCultureIgnoreCase))
            {
                operation.Security ??= new List<OpenApiSecurityRequirement>();

                var securityScheme = new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Basic Auth"
                    },
                };
                operation.Security.Add(new OpenApiSecurityRequirement
                {
                    [securityScheme] = Array.Empty<string>()
                });
            }
            else
            {
                var allowAnonymous = context.ApiDescription.ActionDescriptor.EndpointMetadata
                    .Any(e => e.GetType() == typeof(AllowAnonymousAttribute));

                if (!allowAnonymous)
                {
                    operation.Security ??= new List<OpenApiSecurityRequirement>();

                    var securityScheme = new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference
                        {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer Token"
                        },
                    };

                    operation.Security.Add(new OpenApiSecurityRequirement
                    {
                        [securityScheme] = Array.Empty<string>()
                    });
                }
            }
            operation.Parameters.Add(new OpenApiParameter
            {
                Name = "NowtelAuth",
                In = ParameterLocation.Header,
                Required = true
            });
        }
    }
}
