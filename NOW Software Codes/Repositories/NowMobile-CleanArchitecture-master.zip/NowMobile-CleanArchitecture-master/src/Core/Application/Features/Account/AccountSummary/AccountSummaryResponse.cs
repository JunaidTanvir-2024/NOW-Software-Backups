﻿using Application.Common.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Application.Features.Account.AccountSummary;

public class AccountSummaryResponse
{
    public IEnumerable<UserProductInfo>? ProductInfo { get; set; }
    public UserInfo UserInfo { get; set; } = new UserInfo();
    public PaymentRenewalSetting PaymentRenewalSettings { get; set; }= new PaymentRenewalSetting();
    public string? DisablePaymentVersion { get;set; }
}
