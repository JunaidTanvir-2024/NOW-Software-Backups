﻿using System.Collections.Generic;

namespace BasketWebPanel.BindingModels
{
    public class CategoriesBindingModel
    {
        public List<CategoryBindingModel> Categories { get; set; }
    }
}