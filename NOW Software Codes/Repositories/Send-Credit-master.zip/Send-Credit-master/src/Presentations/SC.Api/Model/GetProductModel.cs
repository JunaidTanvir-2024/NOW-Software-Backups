﻿using SC.Api.Model.Common;
using SC.Core.Common.Model;
using System.ComponentModel;

using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Model;
public class GetProductModel
{
    public int Page { get; set; } = default(int);
    public int RecordsPerPage { get; set; } = default(int);
    public Filter? Filters { get; set; }
    public GetProductModel()
    {
        this.RecordsPerPage =  AppConstants.CommonAppConfig.DefaultRecordsPerPageSize;
    }
}

