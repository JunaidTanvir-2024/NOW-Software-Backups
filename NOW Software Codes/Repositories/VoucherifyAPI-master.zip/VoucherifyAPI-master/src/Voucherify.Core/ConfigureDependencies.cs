using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using PhoneNumbers;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Commons.Settings;
using Voucherify.Core.Services.Http;
using Voucherify.Core.Services.Loggers;
using Voucherify.Core.Services.OpenApi;
using Voucherify.Core.Services.VoucherifyApi;

namespace Voucherify.Core;

public static class ConfigureDependencies
{
    public static IServiceCollection AddCoreDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.RegisterJsonSettings(configuration);
        services.RegisterServices();
        services.RegisterRepositorires();
        services.RegisterExternalServices();
        DatabaseExtensions.SetConfiguration(configuration);
        return services;
    }

    private static IServiceCollection RegisterJsonSettings(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<VoucherifySetting>(configuration.GetSection(VoucherifySetting.SectionName));
        services.Configure<OpenApiSetting>(configuration.GetSection(OpenApiSetting.SectionName));
        services.Configure<EndpointsSettings>(configuration.GetSection(EndpointsSettings.SectionName));
        return services;
    }

    private static IServiceCollection RegisterServices(this IServiceCollection services)
    {
        services.AddHttpClient();
        services.AddOpenApiConfiguration();
        services.AddHttpContextAccessor();
        services.AddSingleton(PhoneNumberUtil.GetInstance());
        return services;
    }
    private static IServiceCollection RegisterExternalServices(this IServiceCollection services)
    {
        services.AddScoped<IVoucherifyImplementation, VoucherifyImplementation>();
        services.AddScoped<IHttpService, HttpService>();
        return services;
    }
    private static IServiceCollection RegisterRepositorires(this IServiceCollection services)
    {
        services.AddTransient<ILoggerRepository, LoggerRepository>();
        return services;
    }
}
