-- DROP TYPE [dbo].[currency_unit_type]
-- DROP TYPE [dbo].[operator_type]
-- DROP TYPE [dbo].[product_benefit_type]
-- DROP TYPE [dbo].[product_category_type]
-- DROP TYPE [dbo].[product_price_type]
-- DROP TYPE [dbo].[product_subcategory_type]
-- DROP TYPE [dbo].[product_type]
-- DROP TYPE [dbo].[vendor_operator_type]
-- DROP TYPE [dbo].[country_filters_type]
-- DROP TYPE [dbo].[operator_filters_type]
-- DROP TYPE [dbo].[product_filters]
-- DROP TYPE [dbo].[product_status_type]
-- DROP TYPE [dbo].[operator_alias_type]
-- DROP TYPE [dbo].[product_alias_type]
-- DROP TYPE [dbo].[product_subcategory_filters_type ]



CREATE TYPE [dbo].[currency_unit_type] AS TABLE(
  [code] [nvarchar](50) NOT NULL,
  [name] [nvarchar](50) NOT NULL,
  [is_default] [bit] NOT NULL
)

GO
CREATE TYPE [dbo].[operator_type] AS TABLE(
  [name] [nvarchar](50) NULL,
  [logo] [nvarchar](100) NULL,
  [description] [nvarchar](500) NULL,
  [country_id] [bigint] NULL
)


GO
CREATE TYPE [dbo].[vendor_operator_type] AS TABLE(
  [name] [nvarchar](50) NULL,
  [logo] [nvarchar](100) NULL,
  [operator_id] [bigint] NULL,
  [vendor_operator_code] [nvarchar](50) NULL,
  [country_id] [bigint] NULL
)

GO
CREATE TYPE [dbo].[product_category_type] AS TABLE(
  [name] [nvarchar](50) NOT NULL,
  [description] [nvarchar](max) NULL
)

GO
CREATE TYPE [dbo].[product_subcategory_type] AS TABLE(
  [name] [nvarchar](50) NOT NULL,
  [description] [nvarchar](max) NULL,
  [product_category_id] [bigint] NULL
)


GO
CREATE TYPE [dbo].[product_type] AS TABLE(
  [name] [nvarchar](150) NULL,
  [description] [nvarchar](max) NULL,
  [operator_id] [bigint] NOT NULL,
  [product_price_id] [bigint] NOT NULL,
  [vendor_operator_code] [nvarchar](50) NOT NULL,
  [vendor_product_code] [nvarchar](50) NOT NULL,
  [currency_unit_id] [bigint] NOT NULL,
  [product_category_id] [bigint] NOT NULL,
  [product_subcategory_id] [bigint] NOT NULL,
  [validity_unit] [nvarchar](100) NULL,
  [validity_value] [int] NULL,
  [vendor_id] [bigint] NOT NULL,
  [product_type] [bit] NULL
)

GO
CREATE TYPE [dbo].[product_price_type] AS TABLE(
  [data_dump_reference] NVARCHAR(55) NOT NULL,
  [price] [decimal](18, 2) NULL,
  [tax] [decimal](18, 2) NULL,
  [fee] [decimal](18, 2) NULL,
  [discount_percentage] [decimal](18, 2) NULL,
  [range_min_price] [decimal](18, 2) NULL,
  [range_max_price] [decimal](18, 2) NULL,
  [effective_from] [datetime2](7) NULL,
  [effective_to] [datetime2](7) NULL
)

GO
CREATE TYPE [dbo].[product_benefit_type] AS TABLE(
  [data_dump_reference] NVARCHAR(55) NOT NULL,
  [description] [nvarchar](max) NULL,
  [benefit_with_tax] [decimal](18, 2) NULL,
  [benefit_without_tax] [decimal](18, 2) NULL,
  [range_min_benefit_with_tax] [DECIMAL](18, 2) NULL,
  [range_max_benefit_with_tax] [DECIMAL](18, 2) NULL,
  [range_min_benefit_without_tax] [DECIMAL](18, 2) NULL,
  [range_max_benefit_without_tax] [DECIMAL](18, 2) NULL,
  [unit] [nvarchar](50) NULL,
  [unit_type] [nvarchar](50) NULL,
  [benefit_type] [nvarchar](50) NULL,
  [product_id] [bigint] NOT NULL
)


CREATE TYPE [dbo].[country_filters_type] AS TABLE(
  [name] [nvarchar](50) NULL,
  [calling_code] [smallint] NULL,
  [iso_code2] [nvarchar](2) NULL,
  [iso_code3] [nvarchar](3) NULL
)
GO


CREATE TYPE [dbo].[operator_filters_type] AS TABLE(
  [operator_name] [nvarchar](50) NULL,
  [country_iso_code] [nvarchar](2) NULL
)
GO


CREATE TYPE [dbo].[product_filters] AS TABLE(
  [country_iso_code] [NVARCHAR](2) NULL,
  [currency_code] [NVARCHAR](50) NULL,
  [calling_code] [SMALLINT] NULL,
  [validity_unit] [NVARCHAR](100) NULL,
  [operator_id] [BIGINT] NULL,
  [product_id] [BIGINT] NULL,
  [product_category_id] [BIGINT] NULL,
  [product_alias_name] [NVARCHAR](250) NULL,
  [operator_name] [NVARCHAR](150) NULL,
  [product_subcategory_name] [NVARCHAR](150) NULL

)
GO



CREATE TYPE [dbo].[product_status_type] AS TABLE(
  [ProductId] [bigint] NULL
)
GO

CREATE TYPE dbo.product_alias_type AS TABLE
(
  product_id BIGINT,
  name_alias NVARCHAR(250),
  description NVARCHAR(max)
);
GO

CREATE TYPE dbo.operator_alias_type AS TABLE
(
  operator_id BIGINT,
  name_alias NVARCHAR(250),
  description NVARCHAR(max)
);
GO


CREATE TYPE [dbo].[product_subcategory_filters_type ] AS TABLE(
	[country_isocode2] [NVARCHAR](50) NULL,
	[currency_code] [NVARCHAR](50) NULL,
	[category_name_alias] [NVARCHAR](50) NULL
)
GO

