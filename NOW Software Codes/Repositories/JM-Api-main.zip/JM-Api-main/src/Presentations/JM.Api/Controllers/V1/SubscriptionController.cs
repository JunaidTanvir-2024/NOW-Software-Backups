using JM.Api.Controllers.Common;
using JM.Core.Features.Subscription;
using JM.Core.Utilities.Definitions;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using RW.Common;
using RW.Failures;
using RW.Models;
using RW.Successes;
namespace JM.Api.Controllers.V1;
[Authorize]
public class SubscriptionController : V1ApiController
{
    [HttpPost]
    [ProducesResponseType<SuccessPayload<CreateSubscription.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.InternalServerError)]
    public async Task<ActionResult> AddSubscription([FromBody] CreateSubscription.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }

    [HttpGet]
    [ProducesResponseType<SuccessPayload<GetSubscriptionList.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    public async Task<ActionResult> GetSubscriptions()
    {
        var result = await Mediator.Send(new GetSubscriptionList.Query(), HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpGet("id")]
    [ProducesResponseType<SuccessPayload<GetSubscription.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    public async Task<ActionResult> GetSubscription([FromQuery] GetSubscription.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpPatch]
    [ProducesResponseType<SuccessPayload<UpdateSubscription.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.InternalServerError)]
    public async Task<ActionResult> UpdateSubscription([FromBody] UpdateSubscription.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
}
