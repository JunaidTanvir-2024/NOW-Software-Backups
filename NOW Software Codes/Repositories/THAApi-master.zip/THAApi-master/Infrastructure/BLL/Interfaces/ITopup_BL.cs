﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Database;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface ITopup_BL
    {
        Task<GenericApiResponse<LastTopup>> GetLastTopUp(string accountNumber,string msisdn,string email);
        Task<GenericApiResponse<TopUpPaymentHistoryResponseModel>> GetTopUpPaymentHistory(string accountNumber);
        Task<GenericApiResponse<VerifyReceiptResponse>> VerifyInAppPurchaseReceipt(VerifyReceiptRequest request);
        Task<GenericApiResponse<ValidateResponse>> ValidateCustomer(string msisdn, string typePayment);
        Task<GenericApiResponse<InAppPurchaseOptions>> GetInAppIosPurchaseOptions1(string msisdn, string version);
        Task<GenericApiResponse<IList<PaymentButtons>>> GetAndroidPurchaseOptions(string msisdn);
        Task<GenericApiResponse<VoucherTopupResponse>> VoucherTopup(VoucherTopupRequest request);
    }
}
