using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

public class VoucherUpdate
{
    [JsonPropertyName("category")]
    public string? Category { get; private set; }

    [JsonPropertyName("start_date")]
    public DateTime? StartDate { get; private set; }

    [JsonPropertyName("expiration_date")]
    public DateTime? ExpirationDate { get; private set; }

    [JsonPropertyName("active")]
    public bool Active { get; private set; }

    [JsonPropertyName("additional_info")]
    public string? AdditionalInfo { get; private set; }

    [JsonPropertyName("gift")]
    public GiftUpdate? Gift { get; private set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; private set; }

    public static VoucherUpdate FromEmpty()
    {
        return new VoucherUpdate();
    }

    public static VoucherUpdate FromVoucher(Voucher voucher)
    {
        Metadata? metadata = null;

        if (voucher.Metadata != null)
        {
            metadata = new Metadata();

            foreach (var key in voucher.Metadata.Keys)
            {
                metadata.Add(key, voucher.Metadata[key]);
            }
        }

        return new VoucherUpdate()
        {
            AdditionalInfo = voucher.AdditionalInfo,
            Category = voucher.Category,
            ExpirationDate = voucher.ExpirationDate,
            StartDate = voucher.StartDate,
            Active = voucher.Active,
            Metadata = metadata
        };
    }

    public VoucherUpdate WithCategory(string category)
    {
        Category = category;
        return this;
    }

    public VoucherUpdate WithStartDate(DateTime? startDate)
    {
        StartDate = startDate;
        return this;
    }

    public VoucherUpdate WithExpirationDate(DateTime? expirationDate)
    {
        ExpirationDate = expirationDate;
        return this;
    }

    public VoucherUpdate WithActive(bool active)
    {
        Active = active;
        return this;
    }

    public VoucherUpdate WithAdditionalInfo(string additionalInfo)
    {
        AdditionalInfo = additionalInfo;
        return this;
    }

    public VoucherUpdate WithMetadata(Metadata metadata)
    {
        Metadata = metadata;
        return this;
    }

    public VoucherUpdate WithGift(GiftUpdate gift)
    {
        Gift = gift;
        return this;
    }
}
