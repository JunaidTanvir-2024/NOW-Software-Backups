﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class GetSingleListRequest
    {
        [JsonProperty("list_name")]
        [Required]
        public string list_name { get; set; }

        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; }
    }
}
