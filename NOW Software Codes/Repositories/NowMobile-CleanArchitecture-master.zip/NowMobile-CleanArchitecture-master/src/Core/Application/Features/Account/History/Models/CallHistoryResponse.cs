﻿namespace Application.Features.Account.History.Models;
public class CallHistoryResponse
{
    public IEnumerable<CallHistoryInfo> History { get; set; } = new List<CallHistoryInfo>();
    public int TotalCount { get; set; }
    public int RecordsFiltered { get; set; }
    public int PageNo { get; set; }
}

