﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models
{
    public class TopupCountry
    {
        public List<TopupCountryVariation> Variations { get; set; }
    }

    public class TopupCountryVariation
    {
        public string CountryCodeStartsWith { get; set; }
        public string MetaTitle { get; set; }
        public string MetaDescription { get; set; }
        public string MetaKeywords { get; set; }
        public string Heading1 { get; set; }
        public string Description1 { get; set; }
        public string Heading2 { get; set; }
        public string Description2 { get; set; }
        public string Heading3 { get; set; }
        public string Description3 { get; set; }
        public string Heading4 { get; set; }
        public string Description4 { get; set; }
    }
    public class LandingPageRate
    {
        public List<RateLandingPageVariation> Variations { get; set; }
    }

    public class RateLandingPageVariation
    {
        public string CountryCodeStartsWith { get; set; }
        public string MainHeading { get; set; }
        public string MainDescription { get; set; }
        public string IntCallingHeading { get; set; }
        public string IntCallingDesc { get; set; }
        public string MobileTopUpHeading { get; set; }
        public string MobileTopUpDesc { get; set; }
        public string MetaDescription { get; set; }

    }
    public class AllCurrenciesModel
    {
        public List<IDictionary<string, string>> Currencies { get; set; }
    }
}
