﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts
{
    public class PreAuthRequest
    {
        public string Msisdn { get; set; }
        public string DeviceUuid { get; set; }
        public string Email { get; set; }
        public string ProductCode { get; set; }
        public string ProductItemCode { get; set; }

    }

    public class VerifyPreAuthRequest
    {
        public string AuthTx { get; set; }       
        public string ProductCode { get; set; }
        public string ProductItemCode { get; set; }

    }
}
