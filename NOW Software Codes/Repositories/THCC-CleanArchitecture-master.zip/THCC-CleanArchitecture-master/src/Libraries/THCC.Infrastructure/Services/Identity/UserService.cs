using System.Data;
using System.Net.Http;

using Microsoft.AspNetCore.Identity;

using Newtonsoft.Json;

using Serilog;

using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Domain.Entities;

using static THCC.Domain.Constants.ThccConstants;
using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Services.Identity;

internal sealed class UserService : IUserService
{
    #region Fields

    private readonly UserManager<User> _userManager;
    private readonly SignInManager<User> _signInManager;
    private readonly ILogger _logger;
    private readonly IJwtService _jwtService;
    private readonly IUserRepository _userRepo;
    private readonly IOtpService _otpService;
    private readonly IMailService _mailService;
    private readonly ICommonService _commonService;

    #endregion

    #region Ctors

    public UserService(
        UserManager<User> userManager,
        SignInManager<User> signInManager,
        ILogger logger,
        IJwtService jwtService,
        IUserRepository userRepository,
        IOtpService otpService,
        IMailService mailService,
        ICommonService commonService)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _logger = logger;
        _jwtService = jwtService;
        _userRepo = userRepository;
        _otpService = otpService;
        _mailService = mailService;
        _commonService = commonService;
    }

    #endregion

    #region Public Methods

    public async Task<LoginInfoDto> LoginAsync(
        User user,
        string password,
        bool lockoutOnFailure)
    {
        var response = new LoginInfoDto() { IsSuccess = false };
        var loginResponse = await _signInManager.CheckPasswordSignInAsync(user, password, lockoutOnFailure);

        if (loginResponse.Succeeded)
        {
            response.IsSuccess = true;

            //generate jwt token
            var tokenInfo = await _jwtService.GetToken(user, _commonService.GetIpAddress());
            response.Token = tokenInfo.Token;
            response.RefreshToken = tokenInfo.RefreshToken;
            return response;
        }
        else
        {
            if (loginResponse.IsNotAllowed)
            {
                if (await _userManager.CheckPasswordAsync(user, password)
                    && !await _userManager.IsEmailConfirmedAsync(user))
                {

                    var token = await _userManager.GenerateEmailConfirmationTokenAsync(user!);
                    var otp = await _otpService.SaveToken(user.Email!, token, OtpType.SignUp);
                    await _mailService.SendEmailVerificationEmail(user.Email!, otp);

                    response.ErrorCode = CustomStatusCode.EmailNotVerified;
                    response.ErrorMessage = CustomStatusKey.EmailNotVerified;
                    return response;
                }
            }
            else if (loginResponse.RequiresTwoFactor)
            {
                throw new Exception("two factor is not enabled yet");
            }
            else if (loginResponse.IsLockedOut)
            {
                //For future 
                //Get lockout time to append in message

                response.ErrorCode = CustomStatusCode.BadRequest;
                response.ErrorMessage = CustomStatusKey.AccountLocked;
                return response;
            }

            response.ErrorCode = CustomStatusCode.BadRequest;
            response.ErrorMessage = CustomStatusKey.InvalidCredentials;
            return response;
        }
    }

    public async Task<SignUpInfoDto> SignUpAsync(
        string firstname,
        string lastname,
        string email,
        string password,
        string role,
        bool isConfirmedUser)
    {
        var user = new User()
        {
            FirstName = firstname,
            LastName = lastname,
            Email = email,
            EmailConfirmed = isConfirmedUser,
            UserName = email,
            IsSubscribedToNewsletter = true
        };

        var (id, isSuccess, errors) = await _userRepo.Create(user, password);
        if (!isSuccess)
        {
            _logger.Error($"Failied {email} registration to new DB: {JsonConvert.SerializeObject(errors)}");
            return new SignUpInfoDto() { Id = id, IsSuccess = isSuccess, Errors = errors };
        }

        user = await _userRepo.GetUserByEmailAsync(email);
        var roleResponse = await _userManager.AddToRoleAsync(user!, role!);
        if (!roleResponse.Succeeded)
        {
            _logger.Error($"Failied {email} add user role to new DB: {JsonConvert.SerializeObject(errors)}");
            return new SignUpInfoDto() { Id = id, IsSuccess = isSuccess, Errors = errors };
        }

        if (!isConfirmedUser && !UserRole.Guest.Equals(role,
                                    StringComparison.InvariantCultureIgnoreCase))
        {
            var token = await _userManager.GenerateEmailConfirmationTokenAsync(user!);
            var otp = await _otpService.SaveToken(email, token, OtpType.SignUp);
            await _mailService.SendEmailVerificationEmail(email, otp);
        }

        return new SignUpInfoDto() { Id = id, IsSuccess = isSuccess };
    }

    public async Task<LoginInfoDto> SocialLoginAsync(
        User user,
        string providerKey,
        SocialLoginType loginprovider)
    {
        var response = new LoginInfoDto() { IsSuccess = false };
        var userResponse = await _userManager.FindByLoginAsync(
            Enum.GetName(typeof(SocialLoginType), loginprovider)!, providerKey);
        if (userResponse == null)
        {
            await _userManager.AddLoginAsync(user, new UserLoginInfo(
                loginProvider: Enum.GetName(typeof(SocialLoginType), loginprovider)!,
                providerKey: providerKey,
                displayName: user.Email));
        }
        var loginResponse = await _signInManager.ExternalLoginSignInAsync(
            Enum.GetName(typeof(SocialLoginType), loginprovider)!, providerKey!, false);
        if (loginResponse.Succeeded)
        {
            response.IsSuccess = true;
            //generate jwt token

            var tokenInfo = await _jwtService.GetToken(user!, _commonService.GetIpAddress());
            response.Token = tokenInfo.Token;
            response.RefreshToken = tokenInfo.RefreshToken;
            return response;
        }
        else
        {
            if (loginResponse.IsLockedOut)
            {
                response.ErrorCode = CustomStatusCode.BadRequest;
                response.ErrorMessage = CustomStatusKey.AccountLocked;
                return response;
            }
            response.ErrorCode = CustomStatusCode.BadRequest;
            response.ErrorMessage = CustomStatusKey.InvalidCredentials;
            return response;
        }
    }

    public async Task<SignUpInfoDto> SocialSignUpAsync(
        string? userId,
        string? firstname,
        string? lastname,
        string email,
        SocialLoginType type)
    {
        try
        {
            var user = new User()
            {
                FirstName = firstname,
                LastName = lastname,
                Email = email,
                EmailConfirmed = true,
                UserName = email,
                IsSubscribedToNewsletter = true
            };
            var (id, isSuccess, errors) = await _userRepo.Create(user, null!);
            if (!isSuccess)
            {
                _logger.Error($"SocialSignUpAsync: Failed {email} registration to new DB: {JsonConvert.SerializeObject(errors)}");

                return new SignUpInfoDto() { Id = id, IsSuccess = isSuccess, Errors = errors };
            }
            user = await _userRepo.GetUserByEmailAsync(email);
            await _userManager.AddLoginAsync(user!,
                new UserLoginInfo(
                   loginProvider: Enum.GetName(typeof(SocialLoginType), type)!,
                   providerKey: userId!,
                   displayName: email));
            var roleResponse = await _userManager.AddToRoleAsync(user!, UserRole.Customer);
            if (!roleResponse.Succeeded)
            {
                _logger.Error($"SocialSignUpAsync:AddToRoleAsync Failed {email} add user role to new DB: {JsonConvert.SerializeObject(errors)}");
                return new SignUpInfoDto() { Id = id, IsSuccess = isSuccess, Errors = errors };
            }
            return new SignUpInfoDto() { Id = id, IsSuccess = isSuccess, Errors = errors };
        }
        catch (Exception ex)
        {
            _logger.Error(ex, $"SocialSignUpAsync: Failed {email} for social login signup: {ex.Message}");
            return new SignUpInfoDto() { IsSuccess = false };
        }
    }

    public async Task<SignUpInfoDto> UpdateUserAsync(
        User? user,
        string firstname,
        string lastname,
        string password,
        bool isConfirmedUser)
    {
        var response = await _userRepo.UpdatUserAsync(user!, firstname, lastname, password);
        if (!response.Succeeded)
        {
            _logger.Error($"Failied {user!.Email} update user info: {JsonConvert.SerializeObject(response?.Errors)}");
            return new SignUpInfoDto() { IsSuccess = response!.Succeeded, Errors = response!.Succeeded ? null : response?.Errors.Select(e => new IdentityErrorDto(e.Code, e.Description)) };
        }

        if (!await _userManager.IsInRoleAsync(user!, UserRole.Customer))
        {
            await _userManager.AddToRoleAsync(user!, UserRole.Customer);
        }

        if (!isConfirmedUser)
        {
            user = await _userRepo.GetUserByEmailAsync(user!.Email!);
            var token = await _userManager.GenerateEmailConfirmationTokenAsync(user!);
            var otp = await _otpService.SaveToken(user!.Email!, token, OtpType.SignUp);
            await _mailService.SendEmailVerificationEmail(user.Email!, otp);
        }
        return new SignUpInfoDto() { IsSuccess = response.Succeeded, Errors = response.Succeeded ? null : response.Errors.Select(e => new IdentityErrorDto(e.Code, e.Description)) };
    }
    public async Task<SignUpInfoDto> SendGuestUserOtp(string userId)
    {
        var user = await _userRepo.GetUserByIdAsync(userId);
        var token = await _userManager.GenerateEmailConfirmationTokenAsync(user!);
        var otp = await _otpService.SaveToken(user!.Email!, token, OtpType.SignUp);
        var response = await _mailService.SendEmailVerificationEmail(user.Email!, otp);

        return new SignUpInfoDto() { IsSuccess = !string.IsNullOrEmpty(otp), Errors = null };
    }

    public async Task<bool> VerifyPasswordAsync(User user, string password)
    {
        return await _userManager.CheckPasswordAsync(user, password);
    }

    public async Task<IdentityResult?> ChangePasswordAsync(User appUser, string newPassword, string oldpassword)
    {
        return await _userManager.ChangePasswordAsync(appUser, oldpassword, newPassword);
    }

    public async Task<IdentityResult?> AddPasswordAsync(User appUser, string password)
    {
        return await _userManager.AddPasswordAsync(appUser, password);
    }



    #endregion
}