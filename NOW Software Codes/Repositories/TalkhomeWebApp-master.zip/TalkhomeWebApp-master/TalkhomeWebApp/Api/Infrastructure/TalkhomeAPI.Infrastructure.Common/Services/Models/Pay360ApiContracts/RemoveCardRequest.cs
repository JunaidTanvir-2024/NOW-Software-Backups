﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeAPI.Models.Pay360ApiContracts
{
    public class RemoveCardRequest
    {
        public string cardToken { get; set; }
        public string pay360CustomerID { get; set; }
    }
}
