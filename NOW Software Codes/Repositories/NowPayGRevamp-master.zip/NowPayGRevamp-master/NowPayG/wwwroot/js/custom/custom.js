// JavaScript Document
$(document).ready(function () {

    'use strict';

    /************************************************************************************ SLICK SLIDER STARTS */
    $('.js-slick')
        .on('init', function (slick) {
            $('.js-slick').css("overflow", "visible");
        })
        .slick({
            autoplay: true,
            autoplaySpeed: 3500,
            dots: true,
            draggable: false,
            fade: true,
            focusOnSelect: true,
            lazyLoad: 'ondemand',
            speed: 1000
        });
    /************************************************************************************ SLICK SLIDER ENDS */


    /************************************************************************************ CAROUSEL SLIDER STARTS */

    $('.home-blog-posts-carousel').owlCarousel({
        loop: true,
        margin: 20,
        responsiveClass: true,
        autoHeight: true,
        navText: [
            "<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"
        ],
        responsive: {
            0: {
                items: 1,
                nav: true,
                dots: true
            },
            768: {
                items: 2,
                nav: true,
                dots: true
            },
            992: {
                items: 3,
                nav: true,
                dots: true,
                loop: true
            }
        }
    });

    $('.testimonials-carousel').owlCarousel({
        loop: true,
        margin: 20,
        responsiveClass: true,
        autoHeight: true,
        navText: [
            "<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"
        ],
        responsive: {
            0: {
                items: 1,
                nav: true,
                dots: true
            },
            768: {
                items: 2,
                nav: true,
                dots: true
            },
            992: {
                items: 2,
                nav: true,
                dots: true,
                loop: true
            }
        }
    });


    $('.slider-1').owlCarousel({
        center: true,
        items: 1,
        loop: true,
        nav: true,
        dots: false,
        smartSpeed: 600,
        margin: 20,
        navText: [
            "<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"
        ],
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 1
            },
            992: {
                items: 1
            }
        }
    });

    $('.slider-2').owlCarousel({
        center: true,
        items: 2,
        loop: true,
        nav: true,
        dots: false,
        smartSpeed: 600,
        margin: 20,
        navText: [
            "<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"
        ],
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 2
            },
            992: {
                items: 2
            }
        }
    });

    $('.slider-3').owlCarousel({
        center: true,
        items: 3,
        loop: true,
        nav: true,
        dots: false,
        smartSpeed: 600,
        margin: 20,
        navText: [
            "<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"
        ],
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 2
            },
            992: {
                items: 3
            }
        }
    });

    $('.slider-4').owlCarousel({
        loop: true,
        margin: 20,
        responsiveClass: true,
        autoHeight: true,
        navText: [
            "<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"
        ],
        responsive: {
            0: {
                items: 1,
                nav: false
            },
            768: {
                items: 2,
                nav: false
            },
            992: {
                items: 4,
                nav: false,
                dots: false,
                loop: false
            }
        }
    })

    /************************************************************************************ SLIDER CAROUSEL ENDS */



    /************************************************************************************ TO TOP STARTS */

    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.scrollup').fadeIn();
        } else {
            $('.scrollup').fadeOut();
        }
    });

    $('.scrollup').on("click", function () {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });

    /************************************************************************************ TO TOP ENDS */



    /************************************************************************************ MAGNIFIC POPUP STARTS */

    $('.popup-modal').magnificPopup({
        type: 'inline',
        preloader: false,
        focus: '#username',
        modal: true
    });

    $(document).on('click', '.popup-modal-dismiss', function (e) {
        e.preventDefault();
        $.magnificPopup.close();
    });



    $('.popup-with-zoom-anim').magnificPopup({
        type: 'inline',

        fixedContentPos: false,
        fixedBgPos: true,
        modal: true,
        overflowY: 'auto',

        closeBtnInside: true,
        preloader: false,

        midClick: true,
        removalDelay: 300,
        mainClass: 'my-mfp-zoom-in'
    });

    $('.popup-with-move-anim').magnificPopup({
        type: 'inline',

        fixedContentPos: false,
        fixedBgPos: true,

        overflowY: 'auto',
        modal: true,
        closeBtnInside: true,
        preloader: false,

        midClick: true,
        removalDelay: 300,
        mainClass: 'my-mfp-slide-bottom',
        callbacks: {
            open: function () {
                if (this.currItem.src == "#signin-form") {
                    $('#LoginErrorSpan').text('');
                    $('#RememberMe_ModalLogin').attr('checked', false);
                }
                else if (this.currItem.src == "#register-form") {
                    $('#MailSubscription').attr('checked', false);
                }
            }
        }
    });

    $('.popup-with-form').magnificPopup({
        type: 'inline',
        preloader: false,
        focus: '#name',
        modal: true,
        // When elemened is focused, some mobile browsers in some cases zoom in
        // It looks not nice, so we disable it:
        callbacks: {
            beforeOpen: function () {
                if ($(window).width() < 700) {
                    this.st.focus = false;
                } else {
                    this.st.focus = '#name';
                }
            }
        }
    });


    /************************************************************************************ MAGNIFIC POPUP ENDS */



    /************************************************************************************ STICKEY NAV STARTS */

    $("#sticky-nav").sticky({
        topSpacing: 0
    });

    /************************************************************************************ STICKEY NAV ENDS */

    $("#LoginBtn").on("click", function () {
        $("#LoginForm").submit();
    });

    $("#LoginForm").on("submit", function () {
        //var FormValidate = $("#RegisterForm").validate();
        if ($("#LoginForm").valid() !== true) {
            return;
        }
        else {
            var model = {};
            model.Email = $("#Email").val();
            model.Password = $("#Password").val();
            model.RememberMe = $('#RememberMe_ModalLogin').is(':checked') ? true : false;
            $.ajax({
                type: "POST",
                url: "/Login",
                data: model,
                async: false,
                success: function (json) {
                    //var json = $.parseJSON(result);
                    if (json.errorCode === 0) {
                        window.location.href = "/home";
                    }
                    else if (json.errorCode > 0) {
                        $("#LoginErrorSpan").show();
                        $("#LoginErrorSpan").text(json.message);
                    }
                    else {
                        alert("something went wrong");
                    }
                },
                error: function (error) {
                    var a = error;
                    alert("Error" + a.responseText);
                }
            });
        }
        return false;
    });

    $("#LoginBtnLoginPage").on("click", function () {
        $('#LoginViewBagMessage').hide();
        $("#LoginFormPage").submit();
    });

    $("#LoginFormPage").on("submit", function () {
        if ($("#LoginFormPage").valid() !== true) {
            return;
        }
        else {
            var model = {};
            model.Email = $("#EmailLoginPage").val();
            model.Password = $("#PasswordLoginPage").val();
            model.RememberMe = $('#RememberMe_Form').is(':checked') ? true : false;
            $.ajax({
                type: "POST",
                url: "/Login",
                data: model,
                async: false,
                success: function (json) {
                    if (json.errorCode === 0) {

                        try {
                            if (RedirectURL != null && RedirectURL != "" && RedirectURL != undefined) {
                                window.location.href = RedirectURL;
                            }
                            else {
                                window.location.href = "/home";
                            }

                        } catch (e) {
                            window.location.href = "/home";
                        }
                    }
                    else if (json.errorCode === 2) {
                        window.location.href = "/resend-verification-email";
                    }
                    else if (json.errorCode > 0) {
                        $("#LoginErrorSpanLoginPage").show();
                        $("#LoginErrorSpanLoginPage").text(json.message);
                    }
                    else {
                        alert("Something went wrong on ther server.");
                    }
                },
                error: function (error) {
                    var a = error;
                    alert("Error: " + a.responseText);
                }
            });
        }
        return false;
    });

    $("#LoginFormPage").submit(function () {
        var LoginFormValidate = $("#LoginFormPage").validate();
        if (!LoginFormValidate) {
            return;
        }
    });

    $("#RegisterBtn").on("click", function () {
        $("#RegisterForm").submit();
    });

    $("#RegisterForm").on("submit", function () {
        if ($("#RegisterForm").valid() !== true) {
            return;
        }
        else {
            var model = {};
            model.Email = $("#RegEmail").val();
            model.FirstName = $("#RegFirstName").val();
            model.LastName = $("#RegLastName").val();
            model.Password = $("#RegPassword").val();
            model.MailSubscription = $('#MailSubscription').is(':checked') ? true : false;
            $.ajax({
                type: "POST",
                url: "/Register",
                data: model,
                async: false,
                success: function (json) {
                    if (json.errorCode === 0) {
                        window.location.href = "/successful-register";
                    }
                    else if (json.errorCode === 4) {
                        $("#RegEmailErrorSpan").show();
                        $("#RegEmailErrorSpan").text(json.message);
                    }
                    else {
                        Alert("something went wrong");
                    }
                },
                error: function (error) {
                    var a = error;
                    alert("Error: " + a.responseText);
                }
            });
        }
        return false;
    });

    $("#RegEmail").change(function () {
        $("#RegEmailErrorSpan").hide();
    });

    $("#UpdatePasswordBtn").on("click", function () {
        $("#UpdatePasswordForm").submit();
    });

    $("#UpdatePasswordForm").on("submit", function () {
        if ($("#UpdatePasswordForm").valid() !== true) {
            return;
        }
        else {
            var model = {};
            model.Token = $("#UpdatePasswordtoken").val();
            model.Password = $("#PasswordUpdatePassword").val();
            $.ajax({
                type: "POST",
                url: "/UpdatePassword",
                data: model,
                async: false,
                success: function (json) {
                    if (json.errorCode === 0) {
                        $('#UpdatePasswordForm')[0].reset();
                        $('#UpdatePasswordSuccessSpan').show().delay(3000).queue(function (next) {
                            window.location.href = "/login";
                        });
                    }
                    else if (json.errorCode > 0) {
                        $("#UpdatePasswordErrorSpan").show();
                        $("#UpdatePasswordErrorSpan").text(json.message);
                    }
                    else {
                        Alert("something went wrong");
                    }
                },
                error: function (error) {
                    var a = error;
                    alert("Error: " + a.responseText);
                }
            });
        }
        return false;
    });

    $("#ForgetPasswordbtn").on("click", function () {
        $("#ForgetPasswordForm").submit();
    });

    $("#ForgetPasswordForm").on("submit", function () {
        //var FormValidate = $("#RegisterForm").validate();
        if ($("#ForgetPasswordForm").valid() !== true) {
            return;
        }
        else {
            var model = {};
            model.Email = $("#ResetPasswordEmail").val();
            $.ajax({
                type: "POST",
                url: "/ForgotPassword",
                data: model,
                async: false,
                success: function (json) {
                    //var json = $.parseJSON(result);
                    if (json.errorCode === 0) {
                        $("#ForgetPasswordForm").hide();
                        $("#ForgotPasswordSuccessMsgDiv").show();
                        $("#ForgotPasswordSuccessMsg").text(json.message);
                    }
                    else if (json.errorCode > 0) {
                        $("#ForgotPasswordEmailErrorSpan").show();
                        $("#ForgotPasswordEmailErrorSpan").text(json.message);
                    }
                    else {
                        Alert("something went wrong");
                    }
                },
                error: function (error) {
                    var a = error;
                    alert("Error: " + a.responseText);
                }
            });
        }
        return false;
    });

    $("#ShowForgotPasswordFormBtn").on("click", function () {
        $("#ForgetPasswordForm").show();
        $("#ForgotPasswordSuccessMsgDiv").hide();
        $("#ForgotPasswordSuccessMsg").text("");
    });

    $(".toggle-password").click(function () {

        $(this).toggleClass("fa-eye fa-eye-slash");
        var input = $($(this).attr("toggle"));
        if (input.attr("type") == "password") {
            input.attr("type", "text");
        } else {
            input.attr("type", "password");
        }

    });

});

/************************************************************************************ SEARCH START */

function openSearch() {
    document.getElementById("myOverlay").style.display = "block";
}

function closeSearch() {
    document.getElementById("myOverlay").style.display = "none";
}

/************************************************************************************ SEARCH ENDS */

/********************************************************* Form Validation Methods */

function ResetForm(formid) {

    $("#" + formid).validate().resetForm();
    $('#' + formid)[0].reset();

    //reset unobtrusive validation summary, if it exists
    $("#" + formid).find("[data-valmsg-summary=true]")
        .removeClass("validation-summary-errors")
        .addClass("validation-summary-valid")
        .find("ul").empty();

    //reset unobtrusive field level, if it exists
    $("#" + formid).find("[data-valmsg-replace]")
        .removeClass("field-validation-error")
        .addClass("field-validation-valid")
        .empty();

    //Remove the Fields border
    $("#" + formid).find('input').removeClass('input-validation-error');
    $("#" + formid).find('select').removeClass('input-validation-error');
}

function isNullOrWhitespace(input) {
    return !input || !input.trim();
}

/********************************************************* Global Ajax Error Handler */
$(document).ajaxError(function (event, jqxhr, settings, thrownError) {
    if (jqxhr.status == 403 || jqxhr.status == 401) {
        window.location.reload();
    }
});
