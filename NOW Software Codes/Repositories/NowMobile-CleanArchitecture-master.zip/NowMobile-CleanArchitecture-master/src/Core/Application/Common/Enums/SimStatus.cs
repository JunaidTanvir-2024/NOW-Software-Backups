﻿namespace Application.Common.Enums;

public enum SimStatus
{
    Completed = 1,
    FreeSimInProcess = 2,
    CreditSimInProcess = 3
}
