﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.Card.Topup.ExistingCard;

public class TopupExistingCardPaymentRequestHandler : IRequestHandler<TopupExistingCardPaymentRequest, object>
{
    #region Fields 

    private readonly IPaymentService _paymentService;
    private readonly ICurrentUser _currentUser;
    private readonly IUserRepository _userRepository;

    #endregion

    #region Ctors

    public TopupExistingCardPaymentRequestHandler(
        IPaymentService paymentService,
        ICurrentUser currentUser,
        IUserRepository userRepository)
    {
        _paymentService = paymentService;
        _currentUser = currentUser;
        _userRepository = userRepository;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(TopupExistingCardPaymentRequest request, CancellationToken cancellationToken)
    {
        var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
        if (userProduct == null)
        {
            return ErrorResult.Failure(
                    CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
        }

        if (!userProduct.Product.Equals(
            request.CardNumber, StringComparison.InvariantCultureIgnoreCase))
        {
            return ErrorResult.Failure(
                    CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
        }

        #region Trim Request

        request.CardNumber = request.CardNumber.Trim();
        request.PaymentCardInfo.CardToken = request.PaymentCardInfo.CardToken.Trim();
        request.PaymentCardInfo.SecurityCode = request.PaymentCardInfo.SecurityCode.Trim();

        #endregion

        return await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: null!,
            paymentAddressInfo: null!,
            paymentExistingCardInfo: request.PaymentCardInfo,
            autoTopupInfo: request.AutoTopupInfo,
            userInfo: new UserDto()
            {
                Id = _currentUser.GetUserId(),
                Email = _currentUser.GetUserEmail()
            },
            productType: ProductType.Topup,
            amount: request.Amount,
            cardNumber: request.CardNumber);
    }

    #endregion
}