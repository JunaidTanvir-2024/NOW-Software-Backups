﻿namespace SenderService.Core.Services.Mailing;

public sealed class MailRequest
{
    public List<string> ToEmails { get; set; } = new List<string>();

    public string? Subject { get; set; }

    public string? Body { get; set; }

    public string? FromEmail { get; set; }

    public string? FromName { get; set; }

    public string? DisplayName { get; set; }

    public string? ReplyToEmail { get; set; }

    public string? ReplyToName { get; set; }

    public List<string> BccEmails { get; set; } = new List<string>();

    public List<string> CcEmails { get; set; } = new List<string>();

    public IDictionary<string, byte[]> AttachmentData { get; set; } = new Dictionary<string, byte[]>();

    public IDictionary<string, string> Headers { get; set; } = new Dictionary<string, string>();
}

