﻿using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace THAPromotionsWEB
{
    public class ResponseTime
    {

        RequestDelegate _next;

        public ResponseTime(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            var sw = new Stopwatch();
            sw.Start();

            await _next(context);

            var isHtml = context.Response.ContentType.ToLower().Contains("text/html");

            var body = context.Response.Body;

            //using (var streamWriter = new StreamWriter(body))
            //{
            //    var textHtmI = string.Format(
            //   "<footer><div id = 'process' > Response Time {O) milliseconds. </div>",
            //    sw.ElapsedMilliseconds);
            //    streamWriter.Write(textHtmI);
            //}
        }
    }
}