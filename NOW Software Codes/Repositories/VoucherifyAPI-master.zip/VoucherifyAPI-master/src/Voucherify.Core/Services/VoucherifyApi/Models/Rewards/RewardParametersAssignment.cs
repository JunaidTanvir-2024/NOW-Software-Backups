using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Loyalties;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Rewards;

public class RewardParametersAssignment
{
    [JsonPropertyName("loyalty")]
    public Loyalty? Loyalty { get; set; }
}
