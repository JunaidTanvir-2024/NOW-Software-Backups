using DC.Core.Common.DependencyResolver;
using DC.Core.Common.Entities;
using DC.Core.Features.Notifications.Requests;


namespace DC.Core.Common.Interfaces.Database;

public interface IDigiTalkRepository : ServiceType.IScoped
{
    Task<List<ActiveMsisdnEntity>> GetNewRegisteredMsisdn(DateTime date,string state);
 


}
