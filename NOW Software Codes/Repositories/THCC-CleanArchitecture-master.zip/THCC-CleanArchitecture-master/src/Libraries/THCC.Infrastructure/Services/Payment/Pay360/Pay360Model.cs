﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using System.Transactions;

using Newtonsoft.Json;

namespace THCC.Infrastructure.Services.Payment.Pay360;

#region Enums

public enum Pay360PaymentType
{
    New,
    Default,
    Token,
    ExistingNew,
    Resume3d
}


public enum Pay360StatusCodes
{
    Success = 0,
    Basket_Isempty = 1,
    BasketTotal_TransactionAmount_NotSame = 2,
    Invalid_ProductRef_ProductItem_THM = 3,
    Invalid_ProductRef_ProductItem_THRCC = 4,
    DailyLimitExceed = 5,
    ProductItemNotConfigured = 6,
    Basketitem_THCC_NotAvailable = 7,
    Basketitem_THCC_AmountExceedLimit = 8,
    InvalidProduct = 9,
    PaymentCreationFailed_Pay360End = 10,
    TransactionSuccesfull_DatabaseUpdateFailed = 11,
    TransactionUnSuccessful = 12,
    TransactionUnSuccesfull_DatabaseInsertionError = 13,
    DatabaseError = 14,
    TransactionFailure_DatabaseUpdateFailed = 15,
    ThreeDSAuthenticationFailed = 16,
    Resume3DSFailed = 17,
    InvalidTransaction = 20,
    limitExceed_MaximumBundle = 21,
    TopupDenied_ContactCS = 22,
    CustomerNotExist = 23,
    InvalidProductRef_ProductItem_THA = 24,
    AccessTokenError = 25,
    FullFilmentError = 26,
    InvalidProductRefNowPayG = 27,
    ServiceNotAvailable = 111
}

#endregion

#region Customer Card

public class Pay360PaymentMethod
{
    public bool Registered { get; set; }
    public bool IsPrimary { get; set; }
    public Pay360Card? Card { get; set; }
    public string PaymentClass { get; set; } = string.Empty;
}

public class Pay360Card
{
    public string CardFingerprint { get; set; } = string.Empty;
    public string CardToken { get; set; } = string.Empty;
    public string CardType { get; set; } = string.Empty;
    [JsonPropertyName("new")]
    public bool NewCard { get; set; }
    public string CardUsageType { get; set; } = string.Empty;
    public string CardScheme { get; set; } = string.Empty;
    public string MaskedPan { get; set; } = string.Empty;
    public string ExpiryDate { get; set; } = string.Empty;
    public string Issuer { get; set; } = string.Empty;
    public string IssuerCountry { get; set; } = string.Empty;
    public string CardHolderName { get; set; } = string.Empty;

}

public class Pay360CustomerCard
{
    public List<Pay360PaymentMethod>? PaymentMethodResponses { get; set; }
}

#endregion

#region Customer

public class Pay360Customer
{
    public string DisplayName { get; set; } = string.Empty;
    public string MerchantRef { get; set; } = string.Empty;
    public string Pay360CustId { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string DefaultCurrency { get; set; } = string.Empty;
    public string Dob { get; set; } = string.Empty;
    public string AddressLine1 { get; set; } = string.Empty;
    public string AddressLine2 { get; set; } = string.Empty;
    public string AddressLine3 { get; set; } = string.Empty;
    public string AddressLine4 { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Region { get; set; } = string.Empty;
    public string PostCode { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string CountryCode { get; set; } = string.Empty;
    public string Telephone { get; set; } = string.Empty;
    public List<Pay360PaymentMethod>? PaymentMethods { get; set; }
}

#endregion

#region Custom Fields

public class CustomFields
{
    public List<FieldState> fieldState = new List<FieldState>();
}

public class FieldState
{
    public string Name { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public bool Transient { get; set; }
}

#endregion

#region Payment Request

public class Pay360PaymentRequest
{
    public Pay360PaymentRequestNew? Pay360PaymentRequestNew { get; set; }
    public Pay360PaymentBase? Pay360PaymentRequestDefault { get; set; }
    public Pay360PaymentRequestExistingNew? Pay360PaymentRequestExistingNew { get; set; }
    public Pay360PaymentRequestToken? Pay360PaymentRequestToken { get; set; }
}
public class Pay360PaymentRefundRequest
{
    public string? TransactionId { get; set; }
}
public class Pay360RefundPartialPaymentRequest
{
    public string? TransactionId { get; set; }
    public double Amount { get; set; }
    public string? Currency { get; set; }
}
public class Pay360PaymentRefundResponse
{
    public Processing? Processing { get; set; }
    public object? PaymentMethod { get; set; }
    public object? Customer { get; set; }
    public Outcome? Outcome { get; set; }
    public Transaction? Transaction { get; set; }
    public object? FinancialServices { get; set; }
    public object? History { get; set; }
    public object? ClientRedirect { get; set; }
    public object? FraudGuard { get; set; }
    public object? ThreeDSecure { get; set; }
    public object? BasketResponse { get; set; }
}
public class Pay360PaymentResponse
{
    public string CustomerId { get; set; } = string.Empty;
    public string TransactionId { get; set; } = string.Empty;
    public string TransactionAmount { get; set; } = string.Empty;
    public Outcome? Outcome { get; set; }
    public Processing? Processing { get; set; }
    public ClientRedirect? ClientRedirect { get; set; }
    public bool Recurring { get; set; }
}
public class Pay360PaymentBase
{
    public bool IsDirectFullfilment;
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerUniqueRef { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public string CustomerMsisdn { get; set; } = string.Empty;
    public string TransactionCurrency { get; set; } = string.Empty;
    public float TransactionAmount { get; set; }
    public string CardCv2 { get; set; } = string.Empty;
    public bool IsAuthorizationOnly { get; set; }
    public bool Do3DSecure { set; get; }
    public bool Recurring { get; set; }
    public string IpAddress { get; set; } = string.Empty;
    public string ProductCode { get; set; } = string.Empty;
    public List<Basket>? Basket { get; set; }
    public Address? BillingAddress { get; set; }
    public Address? CustomerBillingAddress { get; set; }
    public CustomFields? CustomFields { get; set; }
    public bool SendPay360Email { get; set; } = false;
    public bool OverrideValidation { get; set; }
}

public class Pay360PaymentRequestToken : Pay360PaymentBase
{
    public string CardToken { get; set; } = string.Empty;
}

public class Pay360PaymentRequestExistingNew : Pay360PaymentBase
{
    public string CardPan { get; set; } = string.Empty;
    public string CardExpiryDate { get; set; } = string.Empty;
    public bool IsDefaultCard { get; set; }
    public bool SaveCard { get; set; }
    public FinancialServices? FinancialServices { get; set; }
}

public class Pay360PaymentRecurring
{
    [JsonProperty("pay360TransactionId")]
    public string Pay360TransactionId { get; set; } = default!;
    [JsonProperty("productCode")]
    public string ProductCode { get; set; } = default!;
    [JsonProperty("amount")]
    public float Amount { get; set; }
    [JsonProperty("commerceType")]
    public string CommerceType { get; set; } = "MOTO";
}
public class Pay360PaymentRequestNew : Pay360PaymentRequestExistingNew { }

public class FinancialServices
{
    public string DateOfBirth { get; set; } = string.Empty;
    public string Surname { get; set; } = string.Empty;
    public string AccountNumber { get; set; } = string.Empty;
    public string PpostCode { get; set; } = string.Empty;
}

public class Address
{
    public string Line1 { get; set; } = string.Empty;
    public string Line2 { get; set; } = string.Empty;
    public string Line3 { get; set; } = string.Empty;
    public string Line4 { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Region { get; set; } = string.Empty;
    public string Postcode { get; set; } = string.Empty;
    public string CountryCode { get; set; } = string.Empty;
}

public class Basket
{
    public string ProductItemCode { get; set; } = string.Empty;
    public float Amount { get; set; }
    public string ProductRef { get; set; } = string.Empty;
    public string BundleRef { get; set; } = string.Empty;
}

#endregion

#region Payment Response

public class ClientRedirect
{
    public string Pareq { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string ThreeDSServerTransId { get; set; } = string.Empty;
}

public class Outcome
{
    public string Status { get; set; } = string.Empty;
    public string ReasonCode { get; set; } = string.Empty;
    public string ReasonMessage { get; set; } = string.Empty;
}

public class AuthResponse
{
    public string StatusCode { get; set; } = string.Empty;
    public string AcquirerName { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public string GatewayReference { get; set; } = string.Empty;
    public string GatewayMessage { get; set; } = string.Empty;
    public string AvsAddressCheck { get; set; } = string.Empty;
    public string Cv2Check { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string AuthCode { get; set; } = string.Empty;
    public string GatewaySettlement { get; set; } = string.Empty;
    public string GatewayCode { get; set; } = string.Empty;
    public string AvsPostcodeCheck { get; set; } = string.Empty;
}

public class Processing
{
    public AuthResponse? AuthResponse { get; set; }
    public string Route { get; set; } = string.Empty;
}



#endregion