using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Dtos.Auth;
using JM.Core.Utilities.Interfaces.Database;
using JM.Core.Utilities.Interfaces.Services;

using Mediator;

using RW;

namespace JM.Core.Features.Auth.Login;
public abstract class Login
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Email).NotNull().NotEmpty();
            RuleFor(x => x.Password).NotNull().NotEmpty();
        }
    }

    #endregion

    #region Response
    public sealed record Response
    {
        public required UserInfo User { get; set; }
        public required TokenInfo Token { get; set; }

        public record UserInfo
        {
            public required long Id { get; set; }
            public required string Email { get; set; }
            public string? Username { get; set; }
            public string? FullName { get; set; }
            public string? ProfilePhoto { get; set; }
            public CountryInfo? Country { get; set; }
        }
        public record TokenInfo
        {
            public required string JwtToken { get; set; }
            public required string RefreshToken { get; set; }
            public required DateTime JwtTokenExpiry { get; set; }
            public required DateTime RefreshTokenExpiry { get; set; }
        }
        public record CountryInfo
        {
            public required long Id { get; set; }
            public required string Name { get; set; }
            public required string IsoCode3 { get; set; }
        }
    }

    #endregion

    #region Handler
    internal sealed class Handler(IIdentityService authService, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IIdentityService _authService = authService;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var user = await _unitOfWork.UserRepository.GetUser(x => x.NormalizedEmail!.Equals(query.Email.ToUpperInvariant()));

            if (user is null)
            {
                return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
            }

            var loggedInResult = await _authService.LoginAsync(new LoginDto.Request()
            {
                Id = user.Id!,
                Email = user?.Email!,
                Password = query.Password,
                Username = user?.UserName!,
                LockoutOnFailure = true,
                RememberMe = true
            });

            if (loggedInResult.IsNotAllowed)
            {
                return ResultWrapper.Failure(AppConstant.StatusKey.Forbidden, AppConstant.StatusCode.Forbidden);
            }

            if (loggedInResult.IsSuccess)
            {
                return ResultWrapper.Success(
                new Response()
                {
                    User = loggedInResult.User is not null ? new Response.UserInfo()
                    {
                        Email = loggedInResult?.User?.Email!,
                        FullName = loggedInResult?.User?.FullName,
                        Id = loggedInResult?.User?.Id ?? default,
                        ProfilePhoto = loggedInResult?.User?.ProfilePhoto,
                        Username = loggedInResult?.User?.Username,
                        Country = loggedInResult?.User?.Country is not null ? new Response.CountryInfo()
                        {
                            Id = loggedInResult?.User?.Country?.Id ?? default,
                            IsoCode3 = loggedInResult?.User?.Country?.IsoCode3!,
                            Name = loggedInResult?.User?.Country?.Name!
                        } : default!,
                    } : default!,
                    Token = loggedInResult?.User is not null ? new Response.TokenInfo()
                    {
                        JwtToken = loggedInResult?.Token?.JwtToken!,
                        RefreshToken = loggedInResult?.Token?.RefreshToken!,
                        RefreshTokenExpiry = loggedInResult?.Token?.RefreshTokenExpiry ?? default,
                        JwtTokenExpiry = loggedInResult?.Token?.JwtTokenExpiry ?? default
                    } : default!
                });
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.Unauthorized, AppConstant.StatusCode.Unauthorized);
        }
    }
    #endregion
}
