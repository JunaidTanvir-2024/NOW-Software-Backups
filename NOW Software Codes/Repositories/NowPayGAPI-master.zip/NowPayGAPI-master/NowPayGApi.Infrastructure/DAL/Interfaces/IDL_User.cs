﻿using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace NowPayGApi.Infrastructure.DAL.Interfaces
{
    public interface IDL_User
    {
        Task<DBUser> Login(DBUser model);
        Task<bool> IsUserExistByEmail(string email);
        Task<DBUser> GetUserByEmail(string email);
        Task<int> Register(DBUser model);
        Task<int> InsertUserToken(DBUserTokens model);
        Task<DBResult<int>> VerifyEmailByToken(string token, int expiryHours, int TokenTypeId);
        Task<int> RegisterSocialMediaUser(DBUser model);
        Task<DBResult<int>> UpdateUserPassword(string token, int expiryHours, string password);
        Task<int> SaveUserAddress(DBUserAddress model);
        Task<int> SaveUserSIMOrder(DBUserSIMOrder model);
        Task<int> SaveUserProduct(Models.DAOs.DBUserProduct model);
        Task<IEnumerable<DBUserProduct>> GetAllProductsByUserID(Models.DAOs.DBUserProduct model);
        Task<int> UpdateMailSubscription(DBUser user);
        Task<int> ChangeAccountPassword(ChangePasswordRequestModel model);
        Task<int> VerifyUserEmail(string email);

    }
}
