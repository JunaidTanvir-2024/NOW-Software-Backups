﻿namespace Models.Constants
{
    public class AccountDeleteMessages
    {
        public const string DeleteRequestMessage = "Account delete request submitted";
        public const string DeleteRequestInPendingMessage = "Account delete request is in process";
        public const string DeleteSuccessfulMessage = "Your account has been deleted. Please contact customer support";
        public const string DeleteRequestCancelledMessage = "Account delete request has been cancelled";
    }
}
