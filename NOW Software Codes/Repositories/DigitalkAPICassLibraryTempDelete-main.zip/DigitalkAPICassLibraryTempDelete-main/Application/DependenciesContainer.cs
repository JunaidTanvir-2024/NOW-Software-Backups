﻿using Application.Common.Extensions.DependencyResolver;
using Application.Common.Settings;
using Application.Features.Bundle.Bundle;
using Mapster;
using Microsoft.Extensions.Configuration;

namespace Application;

public static class DependenciesContainer
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration config)
    {
        #region Apply Auto Register Services Scanner

        //services.RegisterValidationRequests();

        services.AutoDependencyResolverServices();
        #endregion


        #region Fluent Validation and MediatR Registration

        services
            .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly())
            .AddMediatR(Assembly.GetExecutingAssembly());

        #endregion

        #region Get Section Settings

        services.Configure<DigitalkSettings>(config.GetSection(DigitalkSettings.SectionName));
        #endregion

        return services;
    }
    private static IServiceCollection RegisterValidationRequests(this IServiceCollection services)
    {
        // Customers Region
        services.AddScoped<IValidator<UnSubscribeBundlesRequest>, UnSubscribeBundlesRequestValidator>();

        return services;
    }
}
