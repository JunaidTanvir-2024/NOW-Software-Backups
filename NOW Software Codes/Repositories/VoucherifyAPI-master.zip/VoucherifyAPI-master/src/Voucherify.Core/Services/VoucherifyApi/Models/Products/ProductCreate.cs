using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Products;

public class ProductCreate
{
    [JsonPropertyName("source_id")]
    public string? SourceId { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("price")]
    public long? Price { get; set; }

    [JsonPropertyName("attributes")]
    public List<string>? Attributes { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}
