﻿using ATT.Models.Configurations;
using ATT.Models.Contracts.Reloadly.Request;
using ATT.Models.Contracts.Reloadly.Response;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.Reloadly
{
    public class ReloadlyAuth_BL : IReloadlyAuth_BL
    {
        ReloadlyConfig _reloadlyConf;
        private ILogger _logger;
        private readonly HttpConfig _httpConfig;

        public ReloadlyAuth_BL(
            ILogger appLoggers, 
            IOptions<ReloadlyConfig> reloadlyConfig, 
            IOptions<HttpConfig> http)
        {
            _logger = appLoggers;
            _reloadlyConf = reloadlyConfig.Value;
            _httpConfig = http.Value;
        }
        
        public async Task<ReloadlyAuthResponse> getAuthToken()
        {
            var authRequest = new ReloadlyAuthRequest
            {
                AuthApiEndPoint = _reloadlyConf.AuthApiEndPoint,
                grant_type = _reloadlyConf.grant_type
            };

            if (_reloadlyConf.SimulationMode)
            {
                authRequest.audience = _reloadlyConf.simulation_audience;
                authRequest.client_id = _reloadlyConf.simulation_client_id;
                authRequest.client_secret = _reloadlyConf.simulation_client_secret;
            }
            else
            {
                authRequest.audience = _reloadlyConf.prod_audience;
                authRequest.client_id = _reloadlyConf.prod_client_id_eur;
                authRequest.client_secret = _reloadlyConf.prod_client_secret_eur;
            }

            var response = await getReloadlyAuthToken(authRequest);
            return response;
        }
        public async Task<ReloadlyAuthResponse> getAuthToken(string currency)
        {
            var authRequest = new ReloadlyAuthRequest
            {
                AuthApiEndPoint = _reloadlyConf.AuthApiEndPoint,
                grant_type = _reloadlyConf.grant_type
            };

            if (_reloadlyConf.SimulationMode)
            {
                authRequest.audience = _reloadlyConf.simulation_audience;
                authRequest.client_id = _reloadlyConf.simulation_client_id;
                authRequest.client_secret = _reloadlyConf.simulation_client_secret;
            }
            else
            {
                authRequest.audience = _reloadlyConf.prod_audience;
                if(currency.ToUpper() == "GBP")
                {
                    authRequest.client_id = _reloadlyConf.prod_client_id_gbp;
                    authRequest.client_secret = _reloadlyConf.prod_client_secret_gbp;
                }
                else if (currency.ToUpper() == "EUR")
                {
                    authRequest.client_id = _reloadlyConf.prod_client_id_eur;
                    authRequest.client_secret = _reloadlyConf.prod_client_secret_eur;
                }
                else if (currency.ToUpper() == "USD")
                {
                    authRequest.client_id = _reloadlyConf.prod_client_id_usd;
                    authRequest.client_secret = _reloadlyConf.prod_client_secret_usd;
                }
                else // default EUR
                {
                    authRequest.client_id = _reloadlyConf.prod_client_id_eur;
                    authRequest.client_secret = _reloadlyConf.prod_client_secret_eur;
                }
            }

            var response = await getReloadlyAuthToken(authRequest);
            return response;
        }
        public async Task<ReloadlyAuthResponse> CRM_ATT_getAuthToken(string currency, string productId)
        {
            if (!productId.ToLower().Trim().Equals("trhivr"))
            {
                var authRequest = new ReloadlyAuthRequest
                {
                    AuthApiEndPoint = _reloadlyConf.AuthApiEndPoint,
                    grant_type = _reloadlyConf.grant_type
                };

                if (_reloadlyConf.SimulationMode)
                {
                    authRequest.audience = _reloadlyConf.simulation_audience;
                    authRequest.client_id = _reloadlyConf.simulation_client_id;
                    authRequest.client_secret = _reloadlyConf.simulation_client_secret;
                }
                else
                {
                    authRequest.audience = _reloadlyConf.prod_audience;
                    if (currency.ToUpper() == "GBP")
                    {
                        authRequest.client_id = _reloadlyConf.prod_client_id_gbp;
                        authRequest.client_secret = _reloadlyConf.prod_client_secret_gbp;
                    }
                    else if (currency.ToUpper() == "EUR")
                    {
                        authRequest.client_id = _reloadlyConf.prod_client_id_eur;
                        authRequest.client_secret = _reloadlyConf.prod_client_secret_eur;
                    }
                    else if (currency.ToUpper() == "USD")
                    {
                        authRequest.client_id = _reloadlyConf.prod_client_id_usd;
                        authRequest.client_secret = _reloadlyConf.prod_client_secret_usd;
                    }
                    else // default EUR
                    {
                        authRequest.client_id = _reloadlyConf.prod_client_id_eur;
                        authRequest.client_secret = _reloadlyConf.prod_client_secret_eur;
                    }
                }

                var response = await getReloadlyAuthToken(authRequest);
                return response;
            }
            else
            {
                var authRequest = new ReloadlyAuthRequest
                {
                    AuthApiEndPoint = _reloadlyConf.AuthApiEndPoint,
                    grant_type = _reloadlyConf.grant_type
                };

                if (_reloadlyConf.SimulationMode)
                {
                    authRequest.audience = _reloadlyConf.simulation_audience;
                    authRequest.client_id = _reloadlyConf.simulation_client_id;
                    authRequest.client_secret = _reloadlyConf.simulation_client_secret;
                }
                else
                {
                    authRequest.audience = _reloadlyConf.prod_audience;
                    authRequest.client_id = _reloadlyConf.prod_client_id_eur;
                    authRequest.client_secret = _reloadlyConf.prod_client_secret_eur;
                }

                var response = await getReloadlyAuthToken(authRequest);
                return response;
            }

        }

        private async Task<ReloadlyAuthResponse> getReloadlyAuthToken(ReloadlyAuthRequest request)
        {
            ReloadlyAuthResponse authResponse = new ReloadlyAuthResponse();
            var baseAddress = new Uri(_reloadlyConf.AuthApiEndPoint);
            HttpClient ReloadlyHttpClient = new HttpClient { Timeout =TimeSpan.FromSeconds(_httpConfig.TimeOut), BaseAddress = baseAddress };
            var json = JsonConvert.SerializeObject(request);
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");


            try
            {
                var httpResponse = await ReloadlyHttpClient.PostAsync("", httpContent);

                if (httpResponse.StatusCode == HttpStatusCode.OK && httpResponse.Content != null)
                {
                    string returnData = "";
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                    authResponse = JsonConvert.DeserializeObject<ReloadlyAuthResponse>(returnData);
                }
                else
                {
                    Exception ex = new Exception($"Reloadly API Call Exception - Empty Contents Received - {json}");
                    throw ex;
                }
            }
            catch (WebException wex)
            {
                _logger.Debug($"\"Post  Reloadly API Web Access\"     Failed      Data:{json}     Message:{wex.ToString()}");
                throw wex;
            }
            catch (Exception ex)
            {
                _logger.Debug($"\"Post  Reloadly API\"  Failed       Generasl Exception       Data:{json}      Message:{ex.ToString()}");
                throw ex;
            }

            return authResponse;
        }
    }
}
