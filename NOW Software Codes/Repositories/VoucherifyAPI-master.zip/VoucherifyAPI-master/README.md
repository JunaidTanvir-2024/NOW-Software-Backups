# Nowtel Voucherify

Nowtel Voucherify is a .NET application built on the ASP.NET Core framework. It follows a minimal API style and adopts a Vertical Slices architecture. This README provides an overview of the project, including its external services and dependencies, application information, architecture, and common libraries used.

## Table of Contents

- [Nowtel Voucherify](#nowtel-voucherify)
  - [Table of Contents](#table-of-contents)
  - [External Services and Dependencies](#external-services-and-dependencies)
  - [Application Info](#application-info)
  - [Architecture](#architecture)
  - [Common Libraries](#common-libraries)
  - [Setup and Configuration](#setup-and-configuration)

## External Services and Dependencies

The project relies on the following external service:

- [Voucherify.IO API](https://voucherify.io/) - Used for vouchers, promotions, campaigns etc. management and integration.

## Application Info

- **Framework**: ASP.NET Core
- **Version**: .NET 7 SDK
- **API Style**: Minimal API

## Architecture

The project follows the Vertical Slices architecture pattern. This architecture organizes the codebase based on features or capabilities, enabling a more modular and maintainable approach. Each vertical slice represents a self-contained feature encapsulating all the necessary components such as controllers, models, services, and repositories.

## Common Libraries

The project utilizes the following common libraries:

- **RW** - The ResultWrapper package provides a set of static methods in the ResultWrapper class, allowing you to easily create and work with success and failure scenarios. These wrappers encapsulate various data, including payloads, errors, success and error messages, status codes, and pagination information, providing a standardized way to handle and represent the results of operations.
- **Serilog** - Logging: Serilog provides structured and flexible logging capabilities for the application. It supports various output sinks, log levels, and filtering options, making it easier to manage and analyze logs.
- **Microsoft JwtBearer** - JSON Web Tokens: JwtBearer is used for authentication and authorization using JSON Web Tokens (JWT). It provides middleware for validating and processing JWTs, allowing secure access to protected endpoints.
- **Swagger OpenAPI** - Documentation: Swagger OpenAPI is used to generate API documentation automatically. It provides an interactive and user-friendly interface for exploring the API endpoints, request/response models, and available operations.


## Setup and Configuration

Follow these steps to set up and configure the project:

1. Clone the repository from GitHub: `git clone https://github.com/nowtel/VoucherifyAPI.git`.
2. Install the .NET 7 SDK if not already installed: [Download .NET 7 SDK](https://dotnet.microsoft.com/download).
3. Open the project in your preferred IDE (e.g., Visual Studio, Visual Studio Code).
4. Configure the external dependencies:
   - Obtain API credentials from `https://Voucherify.IO`.
   - Update the configuration file (`appsettings.json` or depends on the environment) with the necessary API credentials.
5. Build the project: `dotnet build`.
6. Run the project: `dotnet run`.
7. The application should now be running and accessible at the specified URL.