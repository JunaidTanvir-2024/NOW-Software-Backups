﻿using CallingCode.Mvc.Persistence;
using Microsoft.AspNetCore.Mvc;

namespace CallingCode.Mvc.Controllers;

public class SearchCountryViewComponent : ViewComponent
{

    public IViewComponentResult Invoke()
    {
        var countries = JsonDataStore.Countries?.OrderBy(x => x.Cca2).ToList();
        return View("~/Views/Shared/Components/_SearchCountryViewComponent.cshtml", countries);
    }
}