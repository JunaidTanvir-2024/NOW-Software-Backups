using Application.Common.Extensions.DependencyResolver;
using Application.Common.Models;

namespace Application.Common.Interfaces.Repositories;
public interface IOtpRepository : IServicesType.IScopedService
{
    Task<DbResult> VerifyOtp(int otp, string uniqueRef, OtpType type, bool? isEmail);
    Task<DbResult> IsValidOtp(string uniqueIdentifier, int otp, OtpType type);
    Task<OTPModel> InsertOtp(int otp, string uniqueRef, OtpType type, bool? isEmail);
}
