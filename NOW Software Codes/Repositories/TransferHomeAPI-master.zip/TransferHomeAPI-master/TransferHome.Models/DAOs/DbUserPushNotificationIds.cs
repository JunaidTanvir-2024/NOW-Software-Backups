﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.DAOs
{
    public class DbUserPushNotificationIds
    {
        public int Id { get; set; }
        public string Token { get; set; }
        public string UDID { get; set; }
        public int? UserId { get; set; }
        public DeviceType DeviceType { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public bool IsActive { get; set; }
    }
}
