﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.Dtos
{


    public sealed record GetContactPersonDto
    {
        public sealed record Request
        {
            public string UserId  { get; set; }
            public ContactFilter Contactfilters { get; set; } = new ContactFilter();
            public sealed record ContactFilter
            {
                public string? FirstName { get; set; }
                public string? LastName { get; set; }
                public string? Email { get; set; }
                public string? MobileNo { get; set; }
            }

        }
    }
}
