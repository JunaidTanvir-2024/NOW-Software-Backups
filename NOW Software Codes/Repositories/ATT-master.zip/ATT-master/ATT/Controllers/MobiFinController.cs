﻿using ATT.Infrastructure.BLL.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class MobiFinController : ControllerBase
    {


        private ICommon_BL Comm_BL;
        public MobiFinController(ICommon_BL comm_BL)
        {
            Comm_BL = comm_BL;
        }

        [HttpPost]
        [Route("GetProducts")]
        public async Task<IActionResult> GetProducts()
        {

            HttpClient SochitelHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(120) };
            SochitelHttpClient.Timeout = TimeSpan.FromSeconds(120);
            //SochitelHttpClient.BaseAddress = new Uri("http://URL-2.com/distributormobilerest/distributormobilerest");
            string data = "{\"RequestUniqueID\":\"5635666445675\",\"MethodName\":\"DstGenerateSessionID\"}";
            string eData = Comm_BL.AesEncrypt(data);
            eData = eData.Replace("+", "-").Replace("/", "_").Replace("=", ",");
            string dat = "{\"TerminalNumber\":\"20848609\",\"Data\":\"" + eData + "\"}";
            var httpContent = new StringContent(dat, Encoding.UTF8, "application/json");
            var httpResponse = await SochitelHttpClient.PostAsync("http://URL-2.com/distributormobilerest/distributormobilerest", httpContent);

            if (httpResponse.Content != null)
            {
                string returnData = await httpResponse.Content.ReadAsStringAsync();
            }
            return null;

            return Ok();
        }
    }
}
