﻿using Infrastructure.BLL.Services.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services
{
    public class AddressService : IAddressService
    {
        private readonly HttpClient AddressClient;
        public AddressService(HttpClient httpClient)
        {
            AddressClient = httpClient;
        }
        public async Task<HttpResponseMessage> GetAddress(string postCode)
        {
            return await AddressClient.GetAsync(postCode);
        }
    }
}
