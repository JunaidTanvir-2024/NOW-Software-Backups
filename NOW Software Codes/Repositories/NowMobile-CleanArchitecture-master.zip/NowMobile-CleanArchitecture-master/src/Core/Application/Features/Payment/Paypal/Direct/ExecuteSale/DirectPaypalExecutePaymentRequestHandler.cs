﻿using Application.Common.Interfaces;
using Application.Common.Interfaces.Payment;
using Application.Features.Payment.Paypal.Models;

namespace Application.Features.Payment.Paypal.Direct.ExecuteSale;

public class DirectPaypalExecutePaymentRequestHandler :
    IRequestHandler<DirectPaypalExecutePaymentRequest, Result<PaypalResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly ICommonService _commonService;

    public DirectPaypalExecutePaymentRequestHandler(IPaymentService paymentService,ICommonService commonService)
    {
        _paymentService = paymentService;
        _commonService = commonService;
    }

    public async Task<Result<PaypalResponse>> Handle(
        DirectPaypalExecutePaymentRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();
        return await _paymentService.HandleDirectPaypalExecuteRequest(
            request.PayerId!,
            request.PaymentId!,
            request.CustomerUniqueRef!,
            request.OrderId,
            request.IsFastTopup,
            IsAppRequest);
    }
}