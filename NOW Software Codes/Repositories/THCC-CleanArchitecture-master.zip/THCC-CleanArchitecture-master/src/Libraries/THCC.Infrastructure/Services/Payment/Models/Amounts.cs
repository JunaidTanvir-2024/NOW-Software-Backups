﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace THCC.Infrastructure.Services.Payment.Models
{
    public class Amounts
    {
        [Required]
        public decimal Total { get; set; }

        [Required]
        public string? Currency { get; set; }
    }
}
