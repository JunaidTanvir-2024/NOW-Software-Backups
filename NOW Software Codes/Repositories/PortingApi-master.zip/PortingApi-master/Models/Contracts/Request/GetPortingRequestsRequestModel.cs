﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class GetPortingRequestsRequestModel
    {
        [Required(ErrorMessage = "Email Is Required"), DataType(DataType.EmailAddress, ErrorMessage = "Invalid Email")]
        public string Email { get; set; }
        [Required]
        public Products Product { get; set; }
        [Required]
        public string Msisdn { get; set; }
    }
}
