﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;
using THM.Infrastructure.BLL;
using THM.Models.Enums;

namespace THM.Daemon
{
    public class SimOrderEmailsWorker : BackgroundService
    {
        private readonly ILogger<CreditSimFullfillmentWorker> _logger;
        private readonly ISimOrderEmails_BL _simEmail_BL;

        public SimOrderEmailsWorker(ILogger<CreditSimFullfillmentWorker> logger, ISimOrderEmails_BL simEmail_BL)
        {
            _logger = logger;
            _simEmail_BL = simEmail_BL;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    //Why and benefits 
                    await _simEmail_BL.SendWhyAndBenefitsEmail(SimOrderType.CreditSim);
                    await _simEmail_BL.SendWhyAndBenefitsEmail(SimOrderType.FreeSim);


                    //Sim is not active
                    await _simEmail_BL.SendNotActivatedSimEmail(SimOrderType.CreditSim);
                    await _simEmail_BL.SendNotActivatedSimEmail(SimOrderType.FreeSim);


                    //Not topped up
                    await _simEmail_BL.SendNotToppedUpEmail(SimOrderType.FreeSim);


                    //Other services email
                    await _simEmail_BL.SendOtherServicesEmail(SimOrderType.CreditSim);
                    await _simEmail_BL.SendOtherServicesEmail(SimOrderType.FreeSim);


                    //Social media emails
                    await _simEmail_BL.SendSocialMediaEmails(SimOrderType.CreditSim);
                    await _simEmail_BL.SendSocialMediaEmails(SimOrderType.FreeSim);
                }
                catch (Exception ex)
                {
                    _logger.LogError("SimOrderEmailsWorker,  " +
                                     "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                     "StackTrace: " + ex.StackTrace);
                }

                await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
            }
        }
    }
}