using Models.Enums;

namespace Models.Contracts.Request.Digitalk
{
	public class DigitalkBundleAllowance
	{
		public int AllowancePeriodLength { get; set; }
		public int AllowancePeriodType { get; set; }
		public int AllowanceRecurrence { get; set; }
		public string BrandedName { get; set; }
		public bool ChargeAtEndOfPeriod { get; set; }
		public int ChargePeriodLength { get; set; }
		public int ChargePeriodType { get; set; }
		public int ChargeRecurrence { get; set; }
		public CommonAllowance CommonAllowance { get; set; }
		public string Description { get; set; }
		public string FullType { get; set; }
		public GPRSAllowance GPRSAllowance { get; set; }
		public string InitialCharge { get; set; }
		public MMSAllowance MMSAllowance { get; set; }
		public object PIC { get; set; }
		public BundleCategory PackageCategory { get; set; }
		public string PackageId { get; set; }
		public string PackageName { get; set; }
		public BundleType PackageType { get; set; }
		public string RecurringCharge { get; set; }
		public SMSAllowance SMSAllowance { get; set; }
		public int ServiceType { get; set; }
		public string SubscriptionCharge { get; set; }
		public VoiceAllowance VoiceAllowance { get; set; }
	}
}