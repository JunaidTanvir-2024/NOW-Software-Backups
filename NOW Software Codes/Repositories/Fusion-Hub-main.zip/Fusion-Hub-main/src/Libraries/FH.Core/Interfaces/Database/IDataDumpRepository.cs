using FH.Core.DependencyResolver;
using FH.Core.Entities;

namespace FH.Core.Interfaces.Database;

public interface IDataDumpRepository : ServiceType.IScoped
{
    Task<IEnumerable<long>> DataDumpBulkUpsert(VendorDataHashEntity vendorDataHashDto);
    Task<IEnumerable<long>> GetVendorDataHash(VendorDataHashEntity vendorDataHashDto);
}
