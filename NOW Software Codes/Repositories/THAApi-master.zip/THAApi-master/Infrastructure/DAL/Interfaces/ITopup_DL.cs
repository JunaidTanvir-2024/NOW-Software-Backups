﻿using Models.Contracts.Request;
using Models.Contracts.Request.AndroidInAppPayment;
using Models.Contracts.Response;
using Models.Database;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
	public interface ITopup_DL
    {
        Task<IEnumerable<TopupPaymentHistory>> GetTopUpPaymentHistory(string accountNumber);
        Task<LastTopup> GetLastTopUpPayment(string msisdn);
        Task<bool> StoreDuplicateReceipt(VerifyReceiptRequest request);
        Task<bool> ApplyInAppPurchaseCredit(decimal amount, string transactionId, UserAccount userAccount);
        Task<bool> StoreInAppPurchaseData(VerifyReceiptRequest request, InAppPurchaseReceipt inAppPurchaseReceipt, decimal topupAmount,
                                                           string itunesTransactionStatus, string itunesStatus, string itunesReason);
        Task<bool> ReceiptDoesNotExist(string receipt);
        Task<ValidateResponse> Validate(string msisdn, string paymentType);
        Task<PaymentConfigurations> GetPaymentConfig(int na_service_id);
        Task<string> GetIVRTopupNumber(string locale, string msisdn);
        Task<PaymentConfigurations> GetPaymentConfigAndroid(int na_service_id);
        Task<string> ApplyVoucherCode(string voucherCode, UserAccount userAccount, VoucherTopupResponse voucherTopupResponse);
        Task<bool> VerifyVoucherCode(string voucherCode);
        Task<bool> IsEligible(string msisdn, string voucherCode);       
    }
}
