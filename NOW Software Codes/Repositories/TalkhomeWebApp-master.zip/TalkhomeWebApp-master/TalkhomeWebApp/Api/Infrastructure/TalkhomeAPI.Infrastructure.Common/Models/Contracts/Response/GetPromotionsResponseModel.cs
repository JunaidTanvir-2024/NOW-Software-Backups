﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
   public class GetPromotionsResponseModel
    {
        public DBPromotionsDetails PromotionsDetails { get; set; }
    }
}
