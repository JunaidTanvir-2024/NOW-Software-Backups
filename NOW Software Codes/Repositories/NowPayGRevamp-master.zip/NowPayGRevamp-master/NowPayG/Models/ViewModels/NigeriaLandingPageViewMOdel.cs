﻿using NowPayG.Models.ApiContracts.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class NigeriaLandingPageViewMOdel : BaseViewModel
    {
        public PlansResponseModel Plans { get; set; }
        public PlanResponseModel Plan { get; internal set; }
    }
}
