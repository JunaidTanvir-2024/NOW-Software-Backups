﻿using System.Data;

namespace Now.Models.DbConnections;

public class DbConnectionSettings : IDbConnectionSettings
{
    public IDbConnection SqlConnection { get; }

    public DbConnectionSettings(IDbConnection connection)
    {
        SqlConnection = connection;
    }
}
