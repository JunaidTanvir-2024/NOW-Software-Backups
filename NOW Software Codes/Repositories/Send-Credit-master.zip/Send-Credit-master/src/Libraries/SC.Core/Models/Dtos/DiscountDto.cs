﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.Dtos
{
    public class DiscountDto
    {
        public sealed record Request
        {
            public bool IsActive { get; set; }
            public bool IsDeleted { get; set; }
            public DiscountFilter? Filters { get; set; }

            public sealed record DiscountFilter
            {
                public string? Name { get; set; }
                public string? Type { get; set; }
                public decimal? Value { get; set; }
                public string? Promocode { get; set; }
                public DateTime? StartDate { get; set; }
                public DateTime? EndDate { get; set; }
            }
        }

        public sealed record Response
        {
            public long? Id { get; set; }
            public string? Name { get; set; }
            public string? Type { get; set; }
            public decimal? Value { get; set; }
            public string? PromoCode { get; set; }
            public DateTime? StartDate { get; set; }
            public DateTime? EndDate { get; set; }
            public bool? IsActive { get; set; }
            public bool? IsDeleted { get; set; }
            public int DiscountTypeId { get; set; }
            public int PerCustomerLimit { get; set; }
            public int MaxThreshold { get; set; }
            public int MaxValue { get; set; }
            public string ValueUnit { get; set; }
            public string Currency { get; set; }
        }
    }
}