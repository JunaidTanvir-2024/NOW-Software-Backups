﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSOutReach.Modal.Xeebi
{
    public class SMSJob
    {
        public int Id { get; set; }

        public int SmsCount { get; set; }

        public int SenderProductID { get; set; }

        public int CarrierId { get; set; }

        public string UserId { get; set; }

        public string Campaign { get; set; }

        public string Message { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime StartTime { get; set; }

        //public DateTime EndTime { get; set; }

        public int Priority { get; set; }

        public int Index { get; set; }

        public int FirstPendingJobId { get; set; }

        public int SecondPendingJobId { get; set; }

        public int FirstJobIndex { get; set; }

        public int SecondJobIndex { get; set; }

       

    }
}
