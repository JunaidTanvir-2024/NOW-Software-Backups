﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ViewModels
{
    public class THRCCPurchaseRegistrationModel
    {
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Enter ConfirmEmail"), Compare("Email", ErrorMessage = "Email do not match")]
        [DataType(DataType.EmailAddress)]
        public string ConfirmEmail { get; set; }
        [Required(ErrorMessage = "Enter Password")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Enter Confirm Password"), Compare("Password", ErrorMessage = "Passwod do not match")]
        public string ConfirmPassword { get; set; }
    }
}
