using System.Net;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

using static THCC.Domain.Constants.ThccConstants;
using Microsoft.Extensions.Options;
using THCC.Application.Interfaces.Services;

namespace THCC.Infrastructure.Services.Jwt;

internal static class JwtConfiguration
{
    internal static IServiceCollection AddJwtConfiguration(this IServiceCollection services, IConfiguration configuration)
    {
        // Get IJwtTokenService
        var jwtService = services.BuildServiceProvider().GetRequiredService<IJwtService>();

        // Bind jwt settings
        var jwtSettings = new JwtSettings();
        configuration.Bind(JwtSettings.SectionName, jwtSettings);
        services.Configure<JwtSettings>(configuration.GetSection(JwtSettings.SectionName));
        string publicKeyPath = string.Empty;

        // Get Secret Key Path;
        if (jwtSettings.AsymmetricFiles.SecretKeyFile != null)
        {
            publicKeyPath = Path.Combine(Directory.GetCurrentDirectory(), jwtSettings.AsymmetricFiles.SecretKeyFile);
        }

        // Authentication scheme
        services.AddAuthentication(authentication =>
        {
            authentication.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            authentication.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            authentication.DefaultSignInScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        // Jwt Bearer with events
        .AddJwtBearer(bearer =>
        {
            bearer.IncludeErrorDetails = false; // => true for easy debugging else remove it

            bearer.TokenValidationParameters = new TokenValidationParameters
            {
                IssuerSigningKey = new ECDsaSecurityKey(jwtService.GetSecurityKeyViaFile(publicKeyPath)),
                ValidIssuer = jwtSettings.Issuer,
                ValidAudience = jwtSettings.Audience,
                ValidateAudience = true,
                RequireSignedTokens = true,
                RequireExpirationTime = true,
                ValidateLifetime = true,
                ValidateIssuer = true,
                RoleClaimType = ClaimTypes.Role,
                ClockSkew = TimeSpan.Zero // Add zero tolerence on token expiration date/time
            };
            //bearer.Events = new JwtBearerEvents
            //{
            //    OnChallenge = async context =>
            //    {
            //        if (!context.HttpContext.Response.HasStarted)
            //        {
            //            context.Response.ContentType = ContentTypes.ApplicationJson;
            //            context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
            //            var responseData = new ErrorResult
            //            {
            //                Errors = !context.Request.Headers.ContainsKey("Authorization")
            //                ? new List<ErrorDto>()
            //                {
            //                new ErrorDto() {
            //                    Code = CustomStatusCode.JwtTokenMissing,
            //                    Message = CustomStatusKey.JwtTokenMissing
            //                }
            //                }
            //                : new List<ErrorDto>()
            //                {
            //                new ErrorDto() {
            //                    Code = CustomStatusCode.JwtInvalidToken,
            //                    Message = CustomStatusKey.JwtInvalidToken
            //                }
            //                }
            //            };
            //            await context.Response.WriteAsync(JsonConvert.SerializeObject(responseData, new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() }));
            //        }
            //        context.HandleResponse();
            //    },
            //    OnForbidden = context =>
            //    {
            //        context.Response.ContentType = ContentTypes.ApplicationJson;
            //        context.Response.StatusCode = CustomStatusCode.Forbidden;
            //        var responseData = new ErrorResult
            //        {
            //            Errors = new List<ErrorDto>(){
            //                new ErrorDto() {
            //                    Code = CustomStatusCode.Forbidden,
            //                    Message = CustomStatusKey.Forbidden
            //                }
            //           }
            //        };
            //        return context.Response.WriteAsync(JsonConvert.SerializeObject(responseData, new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() }));
            //    },
            //    OnAuthenticationFailed = async context =>
            //    {
            //        context.Response.ContentType = ContentTypes.ApplicationJson;
            //        context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
            //        if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
            //        {
            //            context.Response.Headers.Add("Token-Expired", "true");
            //            var responseData = new ErrorResult
            //            {
            //                Errors = new List<ErrorDto>(){
            //                new ErrorDto() {
            //                    Code = CustomStatusCode.JwtTokenExpired,
            //                    Message = CustomStatusKey.JwtTokenExpired
            //                }}
            //            };
            //            await context.Response.WriteAsync(JsonConvert.SerializeObject(responseData, new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() }));
            //        }
            //    }
            //};
        });
        return services;
    }
}
