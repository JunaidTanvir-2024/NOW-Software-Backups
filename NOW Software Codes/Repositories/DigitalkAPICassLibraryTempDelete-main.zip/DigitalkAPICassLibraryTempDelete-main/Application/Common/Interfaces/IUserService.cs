﻿using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces;

public interface IUserService : IServicesType.IScopedService
{    
    Task<MsisdnDetails> GetMsisdnDetail(string msisdn);
}