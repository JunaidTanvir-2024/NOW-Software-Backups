﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.CountryDestination
{

	public class CountryDestinationBundle
	{
		public CountryDestinationBundle()
		{
			Details = new List<string>();
		}

		public string Id { get; set; }
		public string Name { get; set; }
		public List<string> Details { get; set; }
		public string Price { get; set; }
		public bool isOffer { get; set; }
		public TrialBundle TrialBundle { get; set; }
		public int Category { get; set; }
		public string CategoryName { get; set; }
		public int Type { get; set; }
		public string TypeName { get; set; }
		public int DiscountPercentage { get; set; }
		public string bundleMobileRate { get; set; }
		public int RewardPoints { get; set; }
    }
	public class CountryDestinationWelcomeBundle
	{
		public CountryDestinationWelcomeBundle()
		{
		}

		public string Id { get; set; }
		public string Name { get; set; }
		public string Description { get; set; }
		public string Terms { get; set; }
		public string Price { get; set; }
		public int Category { get; set; }
		public string CategoryName { get; set; }
		public int DiscountPercentage { get; set; }
		public string MobileLandlineMinutes { get; set; }
		public string DestinationISOCode { get; set; }
		public string DestinationFlag { get; set; }
		public int Type { get; set; }
		public string TypeName { get; set; }
		public string Expiry { get; set; }
		public int RewardPoints { get; set; }
    }
    public class TrialBundle
	{
		public bool IsAvailable { get; set; }
		public string Minutes { get; set; }
		public string Days { get; set; }
		public bool IsMinutesExpired { get; set; }
		public Guid? Id { get; set; }
	}
}
