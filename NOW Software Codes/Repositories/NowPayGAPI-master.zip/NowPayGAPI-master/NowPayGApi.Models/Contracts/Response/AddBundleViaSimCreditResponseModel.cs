﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class AddBundleViaSimCreditResponseModel
    {
        public decimal Balance { get; set; }
    }
}
