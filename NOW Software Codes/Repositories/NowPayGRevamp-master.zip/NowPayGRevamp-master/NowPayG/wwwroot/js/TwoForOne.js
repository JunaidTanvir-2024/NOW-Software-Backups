﻿$(document).ready(function () {



}); 

function BuyPlan_twoForOne(current) {
    $('#SelectedPlan_Id').val(current.dataset.id);
    $('#BundleBuyForm').submit();
}