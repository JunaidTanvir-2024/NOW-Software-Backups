﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Now.Models.Contracts.AirShip;
public class CustomEventsRequest
{
    [JsonProperty("ProductCode")]
    [Required]
    public string ProductCode { get; set; }

    [JsonProperty("CustomEventName")]
    [Required]
    public string CustomEventName { get; set; }

    [JsonProperty("ChannelIdentifier")]
    [Required]
    [EnumDataType(typeof(CEventChannelIdentifier))]
    public CEventChannelIdentifier ChannelIdentifier { get; set; }

    [JsonProperty("ChannelIdentifierValue")]
    [Required]
    public string ChannelIdentifierValue { get; set; }

    [JsonProperty("Value")]
    public double Value { get; set; }

    [JsonProperty("Transaction")]
    public string Transaction { get; set; }

    [JsonProperty("InteractionId")]
    public string InteractionId { get; set; }

    [JsonProperty("InteractionType")]
    public string InteractionType { get; set; }

    [JsonProperty("Properties")]
    public Dictionary<string, string> Properties { get; set; }
}

public enum CEventChannelIdentifier
{
    named_user_id = 1,
    ios_channel = 2,
    android_channel = 3,
    web_channel = 4,
    amazon_channel = 5,
    channel = 6
}