﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{

    public class LoginSignUpEmailRequestModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [MinLength(length: 8, ErrorMessage = "Minimum length should be 8 characters")]
        public string Password { get; set; }
        [Required]
        public bool MailSubscription { get; set; }
    }
}
