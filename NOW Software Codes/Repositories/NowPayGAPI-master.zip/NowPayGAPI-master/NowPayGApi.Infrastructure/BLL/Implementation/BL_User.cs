﻿using Microsoft.Extensions.Options;
using MimeKit;
using NowPayGApi.Infrastructure.BLL.Interfaces;
using NowPayGApi.Infrastructure.DAL.Interfaces;
using NowPayGApi.Models.Configurations;
using NowPayGApi.Models.Contracts;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using NowPayGApi.Models.DAOs;
using NowPayGApi.Models.Utility;
using Serilog;
using System;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using NowPayGApi.Models.DAOs.Digitalk;

namespace NowPayGApi.Infrastructure.BLL.Implementation
{
    public class BL_User : IBL_User
    {
        private readonly IDL_User DL;
        private readonly IDL_CommonServices DL_Common;
        private readonly IDL_Digitalk DL_Digitalk;
        private readonly ILogger Logger;
        private readonly SmtpConfig SmtpConfig;
        private readonly RedirectUrls RedirectUrls;
        private readonly TokensConfig TokensConfig;

        public BL_User(IDL_User dl, IDL_CommonServices dl_common, IDL_Digitalk dL_Digitalk, ILogger logger, IOptions<SmtpConfig> smtpConfig, IOptions<RedirectUrls> redirectUrls, IOptions<TokensConfig> tokensConfig)
        {
            DL = dl;
            DL_Digitalk = dL_Digitalk;
            Logger = logger;
            SmtpConfig = smtpConfig.Value;
            RedirectUrls = redirectUrls.Value;
            TokensConfig = tokensConfig.Value;
            DL_Common = dl_common;
        }

        public async Task<GenericApiResponse<LoginResponseModel>> Login(LoginRequestModel model)
        {
            try
            {
                DBUser user = new DBUser()
                {
                    Email = model.Email,
                    Password = CryptoHelper.Hash(model.Password)
                };
                var result = await DL.Login(user);
                if (result != null)
                {
                    if (result.IsEmailVerified)
                    {
                        return GenericApiResponse<LoginResponseModel>.Success(new LoginResponseModel()
                        {
                            Id = result.Id,
                            FirstName = result.FirstName,
                            LastName = result.LastName,
                            Email = result.Email,
                            CountryId = result.CountryId,
                            ProductList = await UserProducts(result.Id)
                        }, "Login Successful");
                    }
                    else
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure("Email not verified", ApiStatusCodes.EmailNotVerified);
                    }

                }
                else
                {
                    return GenericApiResponse<LoginResponseModel>.Failure("Username & Password not matched.", ApiStatusCodes.InvalidEmailPassword);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetUserByEmailResponseModel>> GetUserByEmail(GetUserByEmailRequestModel model)
        {
            try
            {
                var result = await DL.GetUserByEmail(model.Email);
                if (result != null)
                {
                    GetUserByEmailResponseModel user = new GetUserByEmailResponseModel()
                    {
                        Id = result.Id,
                        FirstName = result.FirstName,
                        LastName = result.LastName,
                        Email = result.Email,
                        CountryId = result.CountryId,
                        MailSubscription = result.MailSubscription,
                        SocialSignUpTypeId = result.SocialSignUpTypeId
                    };
                    return GenericApiResponse<GetUserByEmailResponseModel>.Success(user, "Success");
                }
                else
                {
                    return GenericApiResponse<GetUserByEmailResponseModel>.Failure("User not found.", ApiStatusCodes.UserNotFound);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> IsUserExist(IsUserExistRequestModel model)
        {
            try
            {
                var result = await DL.IsUserExistByEmail(model.Email);
                if (result)
                {
                    return GenericApiResponse<bool>.Success(true, "User exist by given email");
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("User not found against this email", ApiStatusCodes.UserNotFound);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> RegisterUser(RegisterUserRequestModel model)
        {
            GenericApiResponse<bool> response;
            try
            {
                if (await DL.IsUserExistByEmail(model.Email))
                {
                    return response = GenericApiResponse<bool>.Failure("User already exist", ApiStatusCodes.UserAlreadyExist); ;
                }

                DBUser user = new DBUser()
                {
                    Email = model.Email,
                    Password = CryptoHelper.Hash(model.Password),
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    CountryId = model.CountryId,
                    Role = Roles.User,
                    MailSubscription = model.MailSubscription
                };
                var result = await DL.Register(user);

                if (result > 0)
                {
                    string token = Guid.NewGuid().ToString();
                    DBUserTokens userToken = new DBUserTokens()
                    {
                        Token = token,
                        TokenTypeId = (int)UserTokenTypes.SignUpVerificationToken,
                        UserId = result
                    };
                    var tResult = await DL.InsertUserToken(userToken);
                    if (tResult > 0)
                    {
                        var builder = new BodyBuilder();
                        using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\ConfirmEmailTemplate.html").Replace("~\\", ""))))
                        {

                            builder.HtmlBody = SourceReader.ReadToEnd();

                        }
                        string messageBody = string.Format(builder.HtmlBody,
                            model.FirstName,
                            RedirectUrls.VerifyEmailRedirectUrl + token,
                            model.Email
                            );
                        SendEmailToCustomer(model.Email, messageBody, "SignUp Email");
                        return response = GenericApiResponse<bool>.Success(true, "Registered Succesfully");
                    }
                    else
                    {
                        throw new Exception();
                    }
                }
                else
                {
                    throw new Exception();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> ForgotPassword(ForgotPasswordRequestModel model)
        {
            GenericApiResponse<bool> response;
            try
            {
                DBUser user = await DL.GetUserByEmail(model.Email);
                if (user == null)
                {
                    return response = GenericApiResponse<bool>.Failure("No user exist against this email", ApiStatusCodes.UserNotFound);
                }

                if (user.Id > 0)
                {
                    string token = Guid.NewGuid().ToString();
                    DBUserTokens userToken = new DBUserTokens()
                    {
                        Token = token,
                        TokenTypeId = (int)UserTokenTypes.ForgotPasswordVerificationToken,
                        UserId = user.Id
                    };
                    var tResult = await DL.InsertUserToken(userToken);
                    if (tResult > 0)
                    {
                        var builder = new BodyBuilder();
                        using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\ForgotPasswordEmailTemplate.html").Replace("~\\", ""))))
                        {

                            builder.HtmlBody = SourceReader.ReadToEnd();

                        }
                        string messageBody = string.Format(builder.HtmlBody,
                            user.FirstName,
                            RedirectUrls.ForgotPasswordRedirectUrl + token,
                            user.Email
                            );
                        SendEmailToCustomer(model.Email, messageBody, "Forgot Password Email");
                        return response = GenericApiResponse<bool>.Success(true, "Verified Succesfully");
                    }
                    else
                    {
                        throw new Exception();
                    }
                }
                else
                {
                    throw new Exception();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> ResendVerificationEmail(ReSendTokenRequestModel model)
        {
            GenericApiResponse<bool> response;
            try
            {
                DBUser user = await DL.GetUserByEmail(model.Email);
                if (user == null)
                {
                    return response = GenericApiResponse<bool>.Failure("User not registered with this email.", ApiStatusCodes.UserNotFound);
                }
                else
                {
                    if (!user.IsEmailVerified)
                    {
                        string token = Guid.NewGuid().ToString();
                        DBUserTokens userToken = new DBUserTokens()
                        {
                            Token = token,
                            TokenTypeId = (int)UserTokenTypes.SignUpVerificationToken,
                            UserId = user.Id
                        };
                        var tResult = await DL.InsertUserToken(userToken);
                        if (tResult > 0)
                        {
                            var builder = new BodyBuilder();
                            using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\ConfirmEmailTemplate.html").Replace("~\\", ""))))
                            {

                                builder.HtmlBody = SourceReader.ReadToEnd();

                            }
                            string messageBody = string.Format(builder.HtmlBody,
                                user.FirstName,
                                RedirectUrls.VerifyEmailRedirectUrl + token,
                                model.Email
                                );
                            SendEmailToCustomer(model.Email, messageBody, "Re-Verfication Email");
                            return response = GenericApiResponse<bool>.Success(true, "Verification email resent successfully.");
                        }
                        else
                        {
                            return response = GenericApiResponse<bool>.Failure("Something went wrong on the server.", ApiStatusCodes.DBError);
                        }
                    }
                    else
                    {
                        return response = GenericApiResponse<bool>.Failure("Email is already verified.", ApiStatusCodes.EmailAlreadyVerified);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> VerifyEmailbyToken(VerifyEmailRequestModel model)
        {
            try
            {
                var result = await DL.VerifyEmailByToken(model.Token, TokensConfig.EmailTokenExpiryMinutes, model.TokenTypeId);
                if (result != null)
                {
                    if (result.DBStatus == 1)
                    {
                        return GenericApiResponse<bool>.Success(true, "Email verified Successfully");
                    }
                    else
                    {
                        return GenericApiResponse<bool>.Failure("Token has expired already", ApiStatusCodes.ExpiredToken);
                    }
                }
                else
                {
                    throw new Exception();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> UpdatePassword(UpdateUserPasswordRequestModel model)
        {
            try
            {
                model.Password = CryptoHelper.Hash(model.Password);
                var result = await DL.UpdateUserPassword(model.Token, TokensConfig.EmailTokenExpiryMinutes, model.Password);
                if (result != null)
                {
                    if (result.DBStatus == 1)
                    {
                        return GenericApiResponse<bool>.Success(true, "Password Updated Successfully");
                    }
                    else
                    {
                        return GenericApiResponse<bool>.Failure("Expired Token", ApiStatusCodes.ExpiredToken);
                    }
                }
                else
                {
                    throw new Exception();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<LoginResponseModel>> RegisterSocialMediaUser(ExternalLoginRequestModel model)
        {
            try
            {
                SocialLogins socialLogin = new SocialLogins();

                SocialUserViewModel responseModel = new SocialUserViewModel();
                if (model.socialLoginType == (int)LoginTypes.Google)
                {
                    var googleUser = await socialLogin.GetUserFromGoogle(model.accessToken);
                    if (googleUser == null)
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure("Unable to fetch user from social app", ApiStatusCodes.UnableToFetchSocialAppUser);
                    }
                    else
                    {
                        responseModel = new SocialUserViewModel { Id = googleUser.id, Email = googleUser.email, name = googleUser.name, Picture = googleUser.picture, Type = LoginTypes.Google };
                    }

                }
                else if (model.socialLoginType == (int)LoginTypes.Facebook)
                {
                    var facebookUser = await socialLogin.GetUserFromFacebook(model.accessToken);
                    if (facebookUser == null)
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure("Unable to fetch user from social app", ApiStatusCodes.UnableToFetchSocialAppUser);
                    }
                    if (facebookUser.email == null)
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure("Invalid Social Account, Email not exist for the account", ApiStatusCodes.UnableToFetchSocialAppUser);
                    }
                    responseModel = new SocialUserViewModel { Id = facebookUser.id, Email = facebookUser.email, name = facebookUser.name, Picture = facebookUser.picture.Data.url, Type = LoginTypes.Facebook };
                }

                var existingUser = await DL.GetUserByEmail(responseModel.Email);

                if (existingUser != null)
                {
                    var User = new LoginResponseModel()
                    {
                        FirstName = existingUser.FirstName,
                        LastName = existingUser.LastName,
                        CountryId = existingUser.CountryId,
                        Email = existingUser.Email,
                        Id = existingUser.Id,
                        ProductList = await UserProducts(existingUser.Id)
                    };
                    return GenericApiResponse<LoginResponseModel>.Success(User, "Login Successful");
                }
                else
                {
                    var names = responseModel.name.Split(' ');
                    var newUser = await DL.RegisterSocialMediaUser(new DBUser()
                    {
                        FirstName = names[0],
                        LastName = names[names.Length - 1],
                        Email = responseModel.Email,
                        SocialSignUpTypeId = (LoginTypes)model.socialLoginType.Value,
                        Role = Roles.User
                    });
                    if (newUser > 0)
                    {
                        existingUser = await DL.GetUserByEmail(responseModel.Email);
                        if (existingUser != null)
                        {
                            var User = new LoginResponseModel()
                            {
                                FirstName = existingUser.FirstName,
                                LastName = existingUser.LastName,
                                CountryId = existingUser.CountryId,
                                Email = existingUser.Email,
                                Id = existingUser.Id,
                                ProductList = await UserProducts(existingUser.Id)
                            };
                            return GenericApiResponse<LoginResponseModel>.Success(User, "Login Successful");
                        }
                        else
                        {
                            throw new Exception();
                        }
                    }
                    else
                    {
                        throw new Exception();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<int>> SaveUserSimOrder(SaveUserSimOrderRequestModel model)
        {
            try
            {
                var UserID = 0;

                //Register User if not already register
                var result = await DL.GetUserByEmail(model.UserInfo.Email);

                if (result == null)
                {
                    var user = new DBUser()
                    {
                        Email = model.UserInfo.Email,
                        Password = CryptoHelper.Hash(model.UserInfo.Password),
                        FirstName = model.UserInfo.FirstName,
                        LastName = model.UserInfo.LastName,
                        CountryId = model.UserInfo.CountryId,
                        Role = Roles.User,
                        MailSubscription = model.UserInfo.MailSubscription
                    };
                    var UserResult = await DL.Register(user);
                    UserID = UserResult;

                    var verify_user = await DL.VerifyUserEmail(model.UserInfo.Email);

                }

                if (result != null || UserID > 0)
                {
                    //Save User Address
                    var address = new DBUserAddress()
                    {
                        AddressLine1 = model.UserAddressInfo.AddressLine1,
                        AddressLine2 = model.UserAddressInfo.AddressLine2,
                        AddressType = model.UserAddressInfo.AddressType,
                        IsDefaultAddress = false,
                        City = model.UserAddressInfo.City,
                        County = model.UserAddressInfo.County,
                        PostCode = model.UserAddressInfo.PostCode,
                        UserId = (result != null ? result.Id : UserID),
                        CountryId = model.UserAddressInfo.CountryId
                    };
                    var AddressResult = await DL.SaveUserAddress(address);

                    if (AddressResult > 0)
                    {
                        //Save Sim Order
                        var sim = new DBUserSIMOrder()
                        {
                            UserId = (result != null ? result.Id : UserID),
                            Product = model.UserSimInfo.Product,
                            UserAddessId = AddressResult,
                            IsReplacement = model.UserSimInfo.IsReplacement
                        };
                        var SimResult = await DL.SaveUserSIMOrder(sim);


                        if (SimResult > 1)
                        {
                            var builder = new BodyBuilder();

                            if (result != null)
                            {
                                using (StreamReader SourceReader = File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\SimOrderTemplate.html").Replace("~\\", ""))))
                                {
                                    builder.HtmlBody = SourceReader.ReadToEnd();
                                }
                                string messageBody = string.Format(builder.HtmlBody, model.UserInfo.FirstName, model.UserInfo.Email);

                                SendEmailToCustomer(model.UserInfo.Email, messageBody, "Sim Order Email");
                            }
                            else
                            {
                                //string token = Guid.NewGuid().ToString();
                                //DBUserTokens userToken = new DBUserTokens()
                                //{
                                //    Token = token,
                                //    TokenTypeId = (int)UserTokenTypes.SignUpVerificationToken,
                                //    UserId = UserID
                                //};
                                //await DL.InsertUserToken(userToken);

                                //using (StreamReader SourceReader = File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\SimOrder_RegistrationTemplate.html").Replace("~\\", ""))))
                                //{
                                //    builder.HtmlBody = SourceReader.ReadToEnd();
                                //}
                                //string messageBody = string.Format( builder.HtmlBody, model.UserInfo.FirstName, RedirectUrls.VerifyEmailRedirectUrl + token, model.UserInfo.Email);

                                //SendEmailToCustomer(model.UserInfo.Email, messageBody, "Sim Order & Registration Email");
                            }

                            return GenericApiResponse<int>.Success(SimResult, "Sim ordered successfully");
                        }
                        else
                        {
                            return GenericApiResponse<int>.Failure(0, "Sim order failed", ApiStatusCodes.SimOrderFailed);
                        }
                    }
                    else
                    {
                        return GenericApiResponse<int>.Failure(0, "Sim order failed", ApiStatusCodes.SimOrderFailed);
                    }
                }
                else
                {
                    return GenericApiResponse<int>.Failure(0, "Sim order failed", ApiStatusCodes.SimOrderFailed);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> ValidateMsisdnAndPUK(ValidateMsisdnAndPukRequestModel model)
        {
            try
            {
                var result = await DL_Digitalk.GetUserAccount(model.Msisdn);
                if (result != null)
                {
                    if (result.PUKCode == model.PUK)
                    {
                        return GenericApiResponse<bool>.Success(true, "Valid Msisdn and PUK");
                    }
                    else
                    {
                        return GenericApiResponse<bool>.Failure("Invalid Msisdn or PUK", ApiStatusCodes.InvalidMsisdnOrPUK);
                    }
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Invalid Msisdn or PUK", ApiStatusCodes.InvalidMsisdnOrPUK);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> ValidateMsisdn(ValidateMsisdnRequestModel model)
        {
            try
            {
                var result = await DL_Digitalk.GetUserAccount(model.Msisdn);
                if (result != null)
                {
                    return GenericApiResponse<bool>.Success(true, "Valid Msisdn");
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Invalid Msisdn", ApiStatusCodes.InvalidMsisdn);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> SaveUserProduct(SaveUserProductRequestModel model)
        {
            try
            {
                var validationResult = await DL_Digitalk.GetUserAccount(Convert.ToString(model.ProductRef));
                if (validationResult != null)
                {
                    if (validationResult.PUKCode == model.PUKCode)
                    {
                        var request = new DBUserProduct()
                        {
                            ProductId = ProductType.NowPayG,
                            ProductRef = model.ProductRef,
                            UserId = model.UserId,
                            AccountId = validationResult.AccountID
                        };
                        var result = await DL.SaveUserProduct(request);

                        if (result == 0)
                        {
                            return GenericApiResponse<bool>.Success(true, "User Product Saved Successfully.");
                        }
                        else
                        {
                            return GenericApiResponse<bool>.Failure(false, "Mobile Number already Registered.", ApiStatusCodes.MobileNumberAlreadyAttached);
                        }
                    }
                    else
                    {
                        return GenericApiResponse<bool>.Failure("Invalid Msisdn or PUK", ApiStatusCodes.InvalidMsisdnOrPUK);
                    }
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Invalid Msisdn or PUK", ApiStatusCodes.InvalidMsisdnOrPUK);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetAllProductsByUserIDResponseModel>> GetAllProductsByUserID(GetAllProductsByUserIDRequestModel model)
        {
            try
            {
                var result = await DL.GetAllProductsByUserID(new DBUserProduct() { UserId = model.UserId });
                if (result != null && result.Count() > 0)
                {
                    var list = result.Select(product => new UserProductsResponseModel()
                    {
                        Id = product.Id,
                        IsActive = product.IsActive,
                        ProductRef = product.ProductRef,
                        AccountId = product.AccountId
                    }).AsEnumerable();

                    return GenericApiResponse<GetAllProductsByUserIDResponseModel>.Success(new GetAllProductsByUserIDResponseModel() { ProductList = list }, "Found products data.");
                }
                return GenericApiResponse<GetAllProductsByUserIDResponseModel>.Failure("Products not found.", ApiStatusCodes.ProductsNotFound);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetUserSummaryResponseModel>> GetUserSummary(GetUserSummaryRequestModel model)
        {
            try
            {
                GetUserSummaryResponseModel summary = new GetUserSummaryResponseModel();

                //Mobile Account
                var account = await DL_Digitalk.GetUserAccountByAccountID(model.AccountId);
                if (account != null)
                {
                    summary.MobileAccount = new MobileAccountResponseModel()
                    {
                        AccountID = account.AccountID,
                        Credit = account.Credit,
                        FirstDate = account.FirstDate,
                        Msisdn = account.Msisdn,
                        PUKCode = account.PUKCode,
                        SubscriberId = account.SubscriberId
                    };
                }

                //Bundles List
                var bundle = await DL_Digitalk.GetUserAccountBundles(model.AccountId);
                if (bundle != null && bundle.Count() > 0)
                {
                    List<BundleResponseModel> bundleList = new List<BundleResponseModel>();

                    //Filter Record From NowPayG List According to Digitalk List
                    var dbBundles = await DL_Common.GetAllPlans();

                    if (dbBundles != null && dbBundles.Count() > 0)
                    {
                        var DbListbundles = dbBundles.ToList();
                        var Filteredbundles = new List<BundleResponseModel>();

                        foreach (var item in bundle)
                        {
                            int index = DbListbundles.FindIndex(x => x.UuId == item.Id.ToString().ToUpper() && x.IsActive == true);
                            if (index != -1)
                            {
                                Filteredbundles.Add(dbBundles.Select(bun => new BundleResponseModel()
                                {
                                    UUID = bun.UuId.ToString(),
                                    Id = bun.Id.ToString(),
                                    BrandedName = bun.Name,
                                    ChargePeriodDays = item.ChargePeriodDays,
                                    Data = item.Data,
                                    Expiry = item.Expiry,
                                    Minutes = item.Minutes,
                                    Name = bun.Name,
                                    PackageCategory = bun.PlanCategoryId,
                                    PackageType = item.PackageType,
                                    RemainingData = item.RemainingData,
                                    RemainingMinutes = item.RemainingMinutes,
                                    RemainingSeconds = item.RemainingSeconds,
                                    RemainingTexts = item.RemainingTexts,
                                    Seconds = item.Seconds,
                                    Texts = item.Texts,
                                    TotalCostPence = Convert.ToInt32(bun.Price),
                                    isRenew = item.isRenew
                                }).ElementAt(index));
                            }
                            else
                            {
                                Filteredbundles.Add(new BundleResponseModel()
                                {
                                    UUID = item.Id.ToString(),
                                    BrandedName = item.Name,
                                    ChargePeriodDays = item.ChargePeriodDays,
                                    Data = item.Data,
                                    Expiry = item.Expiry,
                                    Minutes = item.Minutes,
                                    Name = item.Name,
                                    PackageCategory = 8,
                                    PackageType = item.PackageType,
                                    RemainingData = item.RemainingData,
                                    RemainingMinutes = item.RemainingMinutes,
                                    RemainingSeconds = item.RemainingSeconds,
                                    RemainingTexts = item.RemainingTexts,
                                    Seconds = item.Seconds,
                                    Texts = item.Texts,
                                    TotalCostPence = Convert.ToInt32(item.TotalCostPence),
                                    isRenew = item.isRenew
                                });
                            }
                        }
                        summary.BundleList = Filteredbundles;
                    }
                }

                //Last top-up
                var lasttopup = await DL_Digitalk.GetLastTopUp(model.AccountId);
                if (lasttopup != null)
                {
                    summary.LastTopUp = new UserAccountLastTopupResponseModel()
                    {
                        amount = lasttopup.amount,
                        date = lasttopup.date
                    };
                }

                return GenericApiResponse<GetUserSummaryResponseModel>.Success(summary, "Success");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> UpdateMailSubscription(UpdateMailSubscriptionRequestModel model)
        {
            try
            {
                var result = await DL.UpdateMailSubscription(new DBUser() { Id = model.UserID, MailSubscription = model.MailSubscription });
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "Stauts updated successfully.");
                }
                else
                {
                    return GenericApiResponse<bool>.Failure(false, "Status updation failed.", ApiStatusCodes.DBError);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> ChangeAccountPassword(ChangePasswordRequestModel model)
        {
            try
            {
                model.NewPassword = CryptoHelper.Hash(model.NewPassword);
                model.OldPassword = CryptoHelper.Hash(model.OldPassword);

                var result = await DL.ChangeAccountPassword(model);
                if (result > 0)
                {
                    if (result == 1)
                    {
                        return GenericApiResponse<bool>.Success(true, "Pasword Changed Successfully.");
                    }
                    else
                    {
                        return GenericApiResponse<bool>.Failure(false, "Invalid Old Pasword", ApiStatusCodes.InvalidOldPassword);
                    }
                }
                else
                {
                    return GenericApiResponse<bool>.Failure(false, "Something went wrong on server.", ApiStatusCodes.DBError);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<AddBundleViaSimCreditResponseModel>> AddBundleViaSimCredit(AddBundleViaSimCreditRequestModel model)
        {
            try
            {
                var result = await DL_Digitalk.AddBundleViaSimCredit(model.AccountId, model.Uuid);
                if (result != null)
                {
                    if (result.error_code == 0)
                    {
                        var account = await DL_Digitalk.GetUserAccountByAccountID(model.AccountId);
                        AddBundleViaSimCreditResponseModel response = new AddBundleViaSimCreditResponseModel();
                        if (account != null)
                        {
                            response.Balance = account.Credit;
                        }
                        return GenericApiResponse<AddBundleViaSimCreditResponseModel>.Success(response, result.error_msg);
                    }
                    else if (result.error_code == 102005)
                    {
                        return GenericApiResponse<AddBundleViaSimCreditResponseModel>.Failure("Your balance is insufficient to purchase this bundle.", ApiStatusCodes.InsufficientBalanceInSim);
                    }
                    else
                    {
                        return GenericApiResponse<AddBundleViaSimCreditResponseModel>.Failure(result.error_msg, ApiStatusCodes.AddBundleViaSimCreditFailed);
                    }
                }
                else
                {
                    throw new Exception();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<string>> SetBundleAutoRenewal(BundleAutoRenewalRequestModel model)
        {
            try
            {
                var result = await DL_Digitalk.SetBundleAutoRenewal(model.isAutoRenew, model.Msisdn, model.AccountId, model.Uuid, model.ProductCode, model.Email, model.BundleAmount);
                if (result != null)
                {
                    if (result.error_code == 0)
                    {
                        return GenericApiResponse<string>.Success(result.error_msg, result.error_msg);
                    }
                    else
                    {
                        return GenericApiResponse<string>.Failure(result.error_msg, ApiStatusCodes.BundleAutoRenewalError);
                    }
                }
            }
            catch
            {

            }
            return GenericApiResponse<string>.Failure("Something went wrong on server.", ApiStatusCodes.BundleAutoRenewalError);

        }

        private async Task<bool> SendEmailToCustomer(string customerEmail, string Message, string Subject)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                if (string.IsNullOrEmpty(Message))
                {
                    Logger.Error($"Class: BL_User, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {""}, ErrorMessage: Empty Message");
                    return false;
                }

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }
                else
                {
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                }

                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SmtpConfig.fromForNowPayGSignUp);
                mailMessage.To.Add(customerEmail);
                mailMessage.Body = Message;
                mailMessage.Subject = Subject;
                mailMessage.IsBodyHtml = true;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: BL_User, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }

        }

        private async Task<IEnumerable<UserProductsResponseModel>> UserProducts(int userID)
        {
            IEnumerable<UserProductsResponseModel> list;

            var response = await DL.GetAllProductsByUserID(new DBUserProduct() { UserId = userID });
            if (response != null && response.Count() > 0)
            {
                list = response.Select(product => new UserProductsResponseModel()
                {
                    Id = product.Id,
                    IsActive = product.IsActive,
                    ProductRef = product.ProductRef,
                    AccountId = product.AccountId
                }).AsEnumerable();

                return list;
            }
            else
            {
                return null;
            }
        }

        public async Task<GenericApiResponse<GetUserCallHistoryResponseModel>> GetUserCallHistory(GetUserCallHistoryRequestModel model)
        {
            var reponse = new GetUserCallHistoryResponseModel();

            var totalCount = await DL_Digitalk.GetCallHistoryTotalCount(model.AccountId);
            var historyList = await DL_Digitalk.GetCallHistory(model.AccountId, 1, totalCount);

            if (totalCount > 0
                && historyList != null
                && historyList.Count() > 0)
            {
                reponse = new GetUserCallHistoryResponseModel()
                {
                    CallingHisotryTotalRecords = totalCount,
                    CallingHistory = historyList.Take(totalCount)
                };

                return GenericApiResponse<GetUserCallHistoryResponseModel>.Success(reponse, "found calling history");
            }
            else
            {
                reponse = new GetUserCallHistoryResponseModel()
                {
                    CallingHisotryTotalRecords = totalCount,
                    CallingHistory = Enumerable.Empty<DbCallingHistory>()
                };

                return GenericApiResponse<GetUserCallHistoryResponseModel>.Success(reponse, "calling history not found");
            }
        }

        public async Task<GenericApiResponse<GetUserSmsHistoryResponseModel>> GetUserSmsHistory(GetUserSmsHistoryRequestModel model)
        {
            var reponse = new GetUserSmsHistoryResponseModel();

            var totalCount = await DL_Digitalk.GetSmsHistoryTotalCount(model.AccountId);
            var historyList = await DL_Digitalk.GetSmsHistory(model.AccountId, 1, totalCount);

            if (totalCount > 0
                && historyList != null
                && historyList.Count() > 0)
            {
                reponse = new GetUserSmsHistoryResponseModel()
                {
                    SmsHisotryTotalRecords = totalCount,
                    SmsHistory = historyList.Take(totalCount)
                };

                return GenericApiResponse<GetUserSmsHistoryResponseModel>.Success(reponse, "found sms history");
            }
            else
            {
                reponse = new GetUserSmsHistoryResponseModel()
                {
                    SmsHisotryTotalRecords = totalCount,
                    SmsHistory = Enumerable.Empty<DBSmsHistory>()
                };

                return GenericApiResponse<GetUserSmsHistoryResponseModel>.Success(reponse, "sms history not found");
            }
        }

        public async Task<GenericApiResponse<GetUserDataHistoryResponseModel>> GetUserDataHistory(GetUserDataHistoryRequestModel model)
        {
            var reponse = new GetUserDataHistoryResponseModel();

            var totalCount = await DL_Digitalk.GetDataHistoryTotalCount(model.AccountId);
            var historyList = await DL_Digitalk.GetDataHistory(model.AccountId, 1, totalCount);

            if (totalCount > 0
                && historyList != null
                && historyList.Count() > 0)
            {
                reponse = new GetUserDataHistoryResponseModel()
                {
                    DataHisotryTotalRecords = totalCount,
                    DataHistory = historyList.Take(totalCount)
                };

                return GenericApiResponse<GetUserDataHistoryResponseModel>.Success(reponse, "found data history");
            }
            else
            {
                reponse = new GetUserDataHistoryResponseModel()
                {
                    DataHisotryTotalRecords = totalCount,
                    DataHistory = Enumerable.Empty<DBDataHistory>()
                };

                return GenericApiResponse<GetUserDataHistoryResponseModel>.Success(reponse, "data history not found");
            }
        }

        public async Task<GenericApiResponse<GetUserPaymentHistoryResponseModel>> GetUserPaymentHistory(GetUserPaymentHistoryRequestModel model)
        {
            var reponse = new GetUserPaymentHistoryResponseModel();

            var totalCount = await DL_Digitalk.GetPaymentHistoryTotalCount(model.AccountId);
            var historyList = await DL_Digitalk.GetPaymentHistory(model.AccountId, 1, totalCount);

            if (totalCount > 0
                && historyList != null
                && historyList.Count() > 0)
            {
                reponse = new GetUserPaymentHistoryResponseModel()
                {
                    PaymentHisotryTotalRecords = totalCount,
                    PaymentHistory = historyList.Take(totalCount)
                };

                return GenericApiResponse<GetUserPaymentHistoryResponseModel>.Success(reponse, "found data history");
            }
            else
            {
                reponse = new GetUserPaymentHistoryResponseModel()
                {
                    PaymentHisotryTotalRecords = totalCount,
                    PaymentHistory = Enumerable.Empty<DBPaymentHistory>()
                };

                return GenericApiResponse<GetUserPaymentHistoryResponseModel>.Success(reponse, "data history not found");
            }
        }
    }
}
