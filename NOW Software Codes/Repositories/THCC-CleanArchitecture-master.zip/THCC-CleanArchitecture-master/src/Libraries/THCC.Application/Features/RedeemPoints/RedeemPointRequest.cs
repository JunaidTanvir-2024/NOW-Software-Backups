﻿namespace THCC.Application.Features.RedeemPoints
{
    public class RedeemPointRequest : IRequest<object>
    {
        public int Points { get; set; }
    }
    public class RedeemPointRequestValidator : AbstractValidator<RedeemPointRequest>
    {
        public RedeemPointRequestValidator()
        {
            RuleFor(p => p.Points)
                .NotNull()
                .NotEmpty()
                .Must(x => x % 500 == 0)
                .WithMessage("Points must be a multiple of 500.");
        }
    }
}
