﻿using CallingCode.Mvc.Common.Enums;

namespace CallingCode.Mvc.Common.Models;

public class CountryBundleInfoModel
{
    public CountryBundleInfoModel()
    {
        CountryContent = new CountryContent();
        CountryRates = new Rates();
        Bundles = new List<Bundles>();
    }
    public Rates CountryRates { get; set; }
    public List<Topup> Topups { get; set; } = new List<Topup>();
    public List<Bundles> Bundles { get; set; }
    public CountryContent CountryContent { get; set; }
    public string MinorCurrencyunit { get; set; }
    public string CurrencySymbol { get; set; }
    public string CurrentCurreny { get; set; }
}
public class Topup
{
    public decimal Price { get; set; }
    public int Minutes { get; set; }
}

public class Rates
{
    public int Id { get; set; }
    public string Destination { get; set; }
    public decimal Landline { get; set; }
    public decimal Mobile { get; set; }
    public decimal SMS { get; set; }
    public decimal OffPeakLandline { get; set; }
    public decimal OffPeakMobile { get; set; }
    public decimal OffPeakSMS { get; set; }
    public string ISO2Code { get; set; }
}
public class CountryContent
{
    public string Keywords { get; set; }
    public string CountryName { get; set; }
    public string CountryCode { get; set; }
    public string MainHeadline { get; set; }
    public string MainHeadlinesDescription { get; set; }
    public string InternationalCallingRatesHeading { get; set; }
    public string InternationalCallingRatesDescription { get; set; }
    public string InternationalTopupHeading { get; set; }
    public string InternationalTopupDescription { get; set; }
    public string PopularDestinationHeading { get; set; }
    public string PopularDestinationDescription { get; set; }
    public List<PopularDestinations> PopularDestinations { get; set; }
    public string THAHeading { get; set; }
    public string THADescription { get; set; }
    public string WhyChooseTHMHeading { get; set; }
    public List<WhyChooseTHMDescription> WhyChooseTHMDescription { get; set; }
    public string CompletePackageHeading { get; set; }
    public string CompletePackageDescription { get; set; }
    public string UserExperiencesDescription { get; set; }
    public List<UserExperience> UserExperiences { get; set; }
    public List<Faq> Faqs { get; set; }
    public string Picurl1 { get; set; }
    public string Picurl2 { get; set; }
    public string Picurl3 { get; set; }
    public string Metakeywords { get; set; }
    public string Metadesc { get; set; }
    public string MetaTitle { get; set; }
}
public class UserExperience
{
    public string UserName { get; set; }
    public string ExperienceTitle { get; set; }
    public string UserExperienceText { get; set; }
}
public class WhyChooseTHMDescription
{
    public string ItemHeading { get; set; }
    public string ItemText { get; set; }
}

public class Bundles
{
    public Guid ID { get; set; }
    public string BrandedName { get; set; }
    public string Description { get; set; }
    public string PackageType { get; set; }
    public string PackageCategory { get; set; }
    public int TotalCostPence { get; set; }
    public int ChargePeriodDays { get; set; }
    public int Texts { get; set; }
    public int Seconds { get; set; }
    public int Minutes { get; set; }
    public string Remarks { get; set; }
    public string RemainingMinutes { get; set; }
    public DateTime Expiry { get; set; }
    public int ExpiryInDays { get; set; }
    public string BundleInfo { get; set; }
    public string CountryName { get; set; }
    public BundleCategory BundleCategory { get; set; }
    public BundleType BundleType { get; set; }
    public string BundleCategoryName { get; set; }
    public string BundleTypeName { get; set; }
    public Guid? TrialId { get; set; }
    public bool IsTrial { get; set; }
    public int TrialChargePeriodDays { get; set; }
    public int TrialMinutes { get; set; }
    public int OffPercentage { get; set; }
    public bool IsRenew { get; set; }
    public bool IsTrialMinutesExpired { get; set; }
}

public class PopularDestinations
{
    public string DestinationName { get; set; }
    public string DestinationISO { get; set; }
}
public class Faq
{
    public string Question { get; set; }
    public string Answer { get; set; }
}