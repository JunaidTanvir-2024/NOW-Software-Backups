using FluentValidation;

namespace Voucherify.Api.Features.Products.Requests;

public class GetSkusRequest
{
    public string? ProductNameOrId { get; set; }
}

internal class GetSkusRequestValidator : AbstractValidator<GetSkusRequest>
{
    public GetSkusRequestValidator()
    {
        RuleFor(p => p.ProductNameOrId).NotEmpty().NotNull();
    }
}