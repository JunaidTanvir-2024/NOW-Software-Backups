﻿namespace Application.Features.Carousel;
public sealed class CarouselResponse
{
    public string? ImageUrl { get; set; }
    public string? DeepLink { get; set; }
    public string? WebLink { get; set; }
}
