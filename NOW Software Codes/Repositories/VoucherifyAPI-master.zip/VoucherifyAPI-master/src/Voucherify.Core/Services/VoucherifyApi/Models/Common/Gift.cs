using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class Gift
{
    [JsonPropertyName("object")]
    public string? Object { get; set; }

    [JsonPropertyName("amount")]
    public long Amount { get; set; }

    [JsonPropertyName("balance")]
    public long Balance { get; set; }
}
