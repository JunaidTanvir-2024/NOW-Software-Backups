﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.User.Login;

public class LoginRequest : IRequest<object>
{
    public string Email { get; set; } = default!;
    public string Password { get; set; } = default!;
}

public class TokenRequestValidator : AbstractValidator<LoginRequest>
{
    public TokenRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Email)
            .NotNull()
            .NotEmpty()
            .MaximumLength(100);

        RuleFor(p => p.Password)
            .NotNull()
            .NotEmpty()
            .MaximumLength(20);

        RuleFor(p => p.Email)
            .Must(p => commonService.IsValidEmailAddress(p))
            .When(p => !string.IsNullOrEmpty(p.Email))
            .WithMessage("Invalid email address");
    }
}
