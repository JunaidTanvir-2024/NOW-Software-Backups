namespace Application.Common.Settings;

public class JwtSettings
{
    public const string SectionName = "SecuritySettings:JwtSettings";
    public static JwtSettings Bind  = new JwtSettings();
    public string? Key { get; set; }
    public int TokenExpirationInMinutes { get; set; }
    public int RefreshTokenExpirationInDays { get; set; }
}