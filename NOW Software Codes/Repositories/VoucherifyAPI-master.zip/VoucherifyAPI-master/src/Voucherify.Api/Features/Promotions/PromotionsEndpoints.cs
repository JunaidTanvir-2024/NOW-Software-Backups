using Microsoft.AspNetCore.Mvc;

using Voucherify.Api.Features.Promotions.Requests;

using Voucherify.Core.Commons.Filters;

namespace Voucherify.Api.Features.Promotions;

public static class PromotionsEndpoints
{
    private const string EndpointPrefix = "/api/promotions";
    private const string EndpointTag = "Promotions Endpoints";

    public static void AddPromotionsEndpoints(this WebApplication app)
    {
        var promotionEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);

        promotionEndpoints.MapGet("", GetPromotionTiers)
            .AddEndpointFilter<FluentValidationFilter<GetPromotionTiersRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        promotionEndpoints.MapPost("", GetCustomerSpecificPromotionTiers)
        .AddEndpointFilter<FluentValidationFilter<GetCustomerSpecificPromotionTiersRequest>>()
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound);

        promotionEndpoints.MapGet("/{promotionTierId}", GetPromotionTierById)
            .AddEndpointFilter<FluentValidationFilter<GetPromotionTierByIdRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        promotionEndpoints.MapPost("/validate", ValidatePromotionTier)
                    .AddEndpointFilter<FluentValidationFilter<ValidatePromotionTierRequest>>()
                    .Produces(StatusCodes.Status400BadRequest)
                    .Produces(StatusCodes.Status200OK)
                    .Produces(StatusCodes.Status404NotFound);

        promotionEndpoints.MapPost("/redeem", RedeemPromotionTier)
            .AddEndpointFilter<FluentValidationFilter<RedeemPromotionTierRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);
    }
    private static async Task<IResult> GetPromotionTierById(IPromotionsHandler promotionsHandler, [AsParameters] GetPromotionTierByIdRequest request)
    {
        var result = await promotionsHandler.GetPromotionTier(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetPromotionTiers(IPromotionsHandler promotionsHandler, [AsParameters] GetPromotionTiersRequest request)
    {
        var result = await promotionsHandler.GetPromotionTiers(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetCustomerSpecificPromotionTiers(IPromotionsHandler promotionsHandler, [FromBody] GetCustomerSpecificPromotionTiersRequest request)
    {
        var result = await promotionsHandler.GetPromotionTiersForCustomer(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> ValidatePromotionTier(IPromotionsHandler promotionsHandler, [FromBody] ValidatePromotionTierRequest request)
    {
        var result = await promotionsHandler.PromotionTierValidation(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.BadRequest(result);
    }

    private static async Task<IResult> RedeemPromotionTier(IPromotionsHandler promotionsHandler, [FromBody] RedeemPromotionTierRequest request)
    {
        var result = await promotionsHandler.PromotionTierRedemption(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.BadRequest(result);
    }
}
