﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Models.Payments
{
    public class MiPayCustomerModel
    {
        public string responseCode { get; set; }

        public Customer customer { get; set; }

        public IEnumerable<UniqueId> uniqueIDs { get; set; }

        public bool accountEnabled { get; set; }

        public bool topupEnabled { get; set; }

        public IEnumerable<PaymentMethod> paymentMethods { get; set; }

        public IEnumerable<Friend> friends { get; set; }

        public IEnumerable<RecurringPayment> recurringPayments { get; set; }

        public bool deleteAccount { get; set; }

        public string salutation { get; set; }

        public string firstName { get; set; }

        public string lastName { get; set; }

        public string emailAddress { get; set; }

        public string homeTelephoneNumber { get; set; }

        public string preferedCurrency { get; set; }

        public string languagePreference { get; set; }

        public BillingAddress billingAddress { get; set; }

        public string customerPIN { get; set; }

        public string dateCreatedAccount { get; set; }

        public int custStatusCode { get; set; }
    }

    public class Customer
    {
        public string defaultMethodOfPaymentType { get; set; }

        public bool notifyByEmail { get; set; }

        public string pdocumentIdType { get; set; }

        public string documentIdNumber { get; set; }

        public string registrationLocation { get; set; }

        public string documentIdExpiryDate { get; set; }

        public string documentIdIssueDate { get; set; }

    }

    public class UniqueId
    {
        public string uniqueIDValue { get; set; }

        public string uniqueIDType { get; set; }
    }

    public class PaymentMethod
    {
        public string primaryAccountNumber { get; set; }

        public string issueNumber { get; set; }

        public string startYear { get; set; }

        public string startMonth { get; set; }

        public string expiryYear { get; set; }

        public string expiryMonth { get; set; }

        public string cvv { get; set; }

        public string nameOnCard { get; set; }

        public string cardType { get; set; }

        public bool isAllowedToBeDeleted { get; set; }

        public bool enabled { get; set; }

        public string typeOfMethodOfPayment { get; set; }

        public string methodOfPaymentIdentifier { get; set; }

        public bool isDefault { get; set; }

        public bool storeDetails { get; set; }
    }

    public class Friend
    {
        public string friendsNickname { get; set; }

        public string msisdn { get; set; }

        public bool defaultNum { get; set; }

        public string network { get; set; }
    }

    public class RecurringPayment
    {
    }

    public class BillingAddress
    {
        public string addressLine1 { get; set; }

        public string addressLine2 { get; set; }

        public string city { get; set; }

        public string county { get; set; }

        public string postCode { get; set; }

        public string country { get; set; }
    }
}
