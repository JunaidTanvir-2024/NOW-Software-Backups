﻿namespace NTCB.Api.Commons.Definations;

public class NTCBConstants
{
    public class StoreProcedures
    {
        public const string VerifyDTOneTransaction = "Usp_VerifyDTOneTransaction";
        public const string UpdateDTOneTransaction = "Usp_UpdateDTOneTransactionStatus";
        public const string UpdateCallbackStatus = "Usp_UpdateCallbackStatus";
    }
    public class ConnectionStrings
    {
        public const string LiveDbAtt = "LiveDbAtt";
        public const string LabDbAtt = "LabDbAtt";
    }
    public class DTOneTransactionStatus
    {
        public const string COMPLETED = "COMPLETED";
        public const string DECLINED = "DECLINED";
        public const string DECLINEDEXCEPTION = "DECLINED-EXCEPTION";
        public const string DECLINEDBARREDCREDITPARTY = "DECLINED-BARRED-CREDIT-PARTY";
        public const string DECLINEDINVALIDCREDITPARTY = "DECLINED-INVALID-CREDIT-PARTY";
        public const string DECLINEDDUPLICATEDTRANSACTION = "DECLINED-DUPLICATED-TRANSACTION";
        public const string DECLINEDOPERATORCURRENTLYUNAVAILABLE = "DECLINED-OPERATOR-CURRENTLY-UNAVAILABLE";
    }
}
