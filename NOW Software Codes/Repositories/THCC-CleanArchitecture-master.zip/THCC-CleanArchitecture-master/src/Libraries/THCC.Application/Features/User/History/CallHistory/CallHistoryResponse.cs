﻿using THCC.Application.Models.Dtos;

namespace THCC.Application.Features.User.History.CallHistory
{
    public class CallHistoryResponse
    {
        public List<CallHistory> CallHistory { get; set; } = default!;
    }

    public class CallHistory
    {
        public string? DateTime { get; set; }
        public CountryDto? Country { get; set; }
        public string? DialedNumber { get; set; }
        public string? ReceiverNumber { get; set; }
        public string? AccessNumber { get; set; }
        public string? Duration { get; set; }
    }
}
