using FH.UseCases.Operators;
using FH.UseCases.Products;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.Common;
[Route("alias")]
public class AliasMapperController : BaseApiController
{
	[HttpPost("product")]
	public async Task<ActionResult> UpdateProductInfo([FromForm] ProductAliasMapper.Query query)
	{
		var result = await Mediator.Send(query);
		if (result.IsSuccess)
		{
			return Ok(result);
		}
		return BadRequest(result);
	}
	[HttpPost("operator")]
	public async Task<ActionResult> UpdateOperatorInfo([FromForm] OperatorAliasMapper.Query query)
	{
		var result = await Mediator.Send(query);
		if (result.IsSuccess)
		{
			return Ok(result);
		}
		return BadRequest(result);
	}
}
