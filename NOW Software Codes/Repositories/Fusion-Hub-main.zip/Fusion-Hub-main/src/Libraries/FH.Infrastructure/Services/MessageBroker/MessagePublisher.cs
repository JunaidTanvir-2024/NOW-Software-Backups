
using FH.Core.Interfaces.Services;

using MassTransit;

using MessageBrokerModel;

namespace FH.Infrastructure.Services.MessageBroker;
internal class MessagePublisher(IBus bus, MessageBrokerDbContext messageBrokerDbContext) : IMessagePublisher
{
    private readonly IBus _bus = bus;
    private readonly MessageBrokerDbContext _messageBrokerDbContext = messageBrokerDbContext;

    public async Task PublishMessage(TransactionMessageDto message)
    {
        await _bus.Publish(message);
        await _messageBrokerDbContext.SaveChangesAsync();
    }
}
