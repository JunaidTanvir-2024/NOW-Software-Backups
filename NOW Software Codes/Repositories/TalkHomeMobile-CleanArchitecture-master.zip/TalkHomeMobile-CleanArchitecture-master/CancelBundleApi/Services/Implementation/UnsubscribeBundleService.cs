﻿using CancelBundleApi.Constants.Enums;
using CancelBundleApi.Helpers.HttpService;
using CancelBundleApi.Models.RequestModels;
using CancelBundleApi.Services.Interfaces;
using CancelBundleApi.Settings.Database;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CancelBundleApi.Services.Implementation;
internal class UnsubscribeBundleService : IUnsubscribeBundleService
{
    private readonly IHttpService _httpService;
    private readonly DigitalkSettings _digiTalkSettings;
    private readonly IDigitalkService _digitalkService;
    private readonly ILogger<IUnsubscribeBundleService> _logger;
    public UnsubscribeBundleService(IHttpService httpService, IOptions<DigitalkSettings> digiTalkSettings, ILogger<IUnsubscribeBundleService> logger, IDigitalkService digitalkService)
    {
        _httpService = httpService;
        _digiTalkSettings = digiTalkSettings.Value;
        _httpService.WithBasicAuth(_digiTalkSettings.UserName, _digiTalkSettings.Password).EnableLogging();
        _logger = logger;
        _digitalkService = digitalkService;
    }

    public async Task<bool> UnSubscribeBundle(UnSubscribeBundlesRequest request)
    {
        try
        {

            string outPutData = string.Empty;
            string serviceCorrelationGuid = Guid.NewGuid().ToString();

            var bundlesResponse = await _digitalkService.GetSubscribedBundles(request, serviceCorrelationGuid);
            if (!bundlesResponse.IsSuccessStatusCode)
            {
                return await Task.FromResult(bundlesResponse.IsSuccessStatusCode);
            }

            //if the status code is not 500 and items list is empty return false
            if (bundlesResponse.Items != null && bundlesResponse.Items.Count == 0)
            {
                return await Task.FromResult(false);
            }
            var bundleItem = bundlesResponse.Items?.FirstOrDefault(t => t.Id == request.SubscriberBundleId);
            if (bundleItem != null)
            {
                bundleItem.ServiceCorrelationGuid = serviceCorrelationGuid;
                var removeBundleResponse = await _digitalkService.DeleteSubscribedBundles(request, bundleItem);

                return await Task.FromResult(removeBundleResponse.IsSuccessStatusCode);
            }
            else
            {
                //if no subscription item found in the list insert log for No subscription bundle item found             
                await _digitalkService.NoDataFound(string.Empty, CustomStatusKey.NoSubscriptionBundleItemFound, request, serviceCorrelationGuid);
                return await Task.FromResult(false);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Message: {ex.Message}, " +
                $"Class: BundleService, " +
           $"Method: UnSubscribeBundle, " +
           $"Exception: {ex.StackTrace}");
            return await Task.FromResult(false);
        }

    }
}

