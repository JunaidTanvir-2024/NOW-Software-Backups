﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Pay360ApiContracts;
using TalkhomeAPI.Models.PaypalApiContracts;
using TalkhomeAPI.Services.Interfaces;
using ThmApi.Filters;

namespace TalkhomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentService _paymentService;
        private readonly ILogger _logger;

        public PaymentController(
            IPaymentService paymentService,
            ILogger logger)
        {
            _paymentService = paymentService;
            _logger = logger;
        }

        [HttpPost]
        [Route("NewCustomerPayment")]
        [BasicAuth]
        public async Task<IActionResult> NewCustomerPayment([FromBody]NewCustomerPaymentRequestModel model)
        {
            try
            {
                if (model.CheckoutType == CheckOutTypes.Bundle)
                    if (string.IsNullOrEmpty(model.BundleId.Trim()))
                        return BadRequest("Bundle Id is required");

                if (model.CheckoutType == CheckOutTypes.TopUp)
                    if (model.TopUpAmount == 0)
                        return BadRequest("Invalid Top-up amount");

                return Ok(await _paymentService.NewCustomerPayment(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: NewCustomerPayment, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("NewCardPayment")]
        [BasicAuth]
        public async Task<IActionResult> NewCardPayment([FromBody]NewCardPaymentRequestModel model)
        {
            try
            {
                if (model.CheckoutType == CheckOutTypes.Bundle)
                    if (string.IsNullOrEmpty(model.BundleId.Trim()))
                        return BadRequest("Bundle Id is required");

                if (model.CheckoutType == CheckOutTypes.TopUp)
                    if (model.TopUpAmount == 0)
                        return BadRequest("Invalid Top-up amount");

                return Ok(await _paymentService.NewCardPayment(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: NewCardPayment, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("ExistingCardPayment")]
        [BasicAuth]
        public async Task<IActionResult> ExistingCardPayment([FromBody]ExistingCardPaymentRequestModel model)
        {
            try
            {
                return Ok(await _paymentService.ExistingCardPayment(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: ExistingCardPayment, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetCustomerCards")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetCustomerCards()
        {
            try
            {
                return Ok(await _paymentService.Pay360GetCards(User.Claims.First(i => i.Type == "msisdn").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: GetCustomerCards, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetAutoTopup")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetAutoTopup()
        {
            try
            {
                return Ok(await _paymentService.GetAutoTopUp(
                                            User.Claims.First(i => i.Type == "msisdn").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: GetAutoTopup, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("SetAutoTopup")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> SetAutoTopup([FromBody]SetAutoTopUpRequestModel model)
        {
            try
            {
                return Ok(await _paymentService.SetAutoTopUp(model,
                                            User.Claims.First(i => i.Type == "msisdn").Value,
                                            User.Claims.First(i => i.Type == "currency").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: SetAutoTopup, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("SetCustomerDefaultCard")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> SetCustomerDefaultCard([FromBody]SetCustomerDefaultCardRequestModel model)
        {
            try
            {
                return Ok(await _paymentService.SetCustomerDefaultCard(model, User.Claims.First(i => i.Type == "msisdn").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: SetCustomerDefaultCard, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("RemoveCard")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> RemoveCard([FromBody]RemoveCardRequestModel model)
        {
            try
            {
                return Ok(await _paymentService.RemoveCard(model, User.Claims.First(i => i.Type == "msisdn").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: RemoveCard, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("GetCustomer")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetCustomer([FromBody]Pay360CustomerRequestModel model)
        {
            try
            {
                return Ok(await _paymentService.GetCustomer(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: GetCustomer, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("Resume3DTransaction")]
        [BasicAuth]
        public async Task<IActionResult> Resume3DTransaction([FromBody]Pay360Resume3DRequestModel request)
        {
            try
            {
                return Ok(await _paymentService.Resume3DTransaction(request));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: Resume3DTransaction, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("PaypalPayment")]
        [BasicAuth]
        public async Task<IActionResult> PaypalPayment([FromBody]PaypalPaymentRequestModel model)
        {
            try
            {
                return Ok(await _paymentService.PaypalPayment(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: PaypalPayment, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("PaypalPaymentCallBack")]
        [HttpPost]
        [BasicAuth]
        public async Task<IActionResult> PaypalPaymentCallBack([FromBody]PaypalPaymentCallBackRequestModel model)
        {
            try
            {
                return Ok(await _paymentService.PaypalPaymentCallBack(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: PaypalPaymentCallBack, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("PaypalByPay360PaymentCallBack")]
        [HttpPost]
        [BasicAuth]
        public async Task<IActionResult> PaypalByPay360PaymentCallBack([FromBody]PaypalByPay360PaymentCallBackRequestModel model)
        {
            try
            {
                return Ok(await _paymentService.PaypalByPay360PaymentCallBack(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: PaypalByPay360PaymentCallBack, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("BundlePurchaseViaAccountBalance")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> BundlePurchaseViaAccountBalance([FromBody]BundlePurchaseViaABRequestModel model)
        {
            try
            {
                return Ok(await _paymentService.BundlePurchaseViaAccountBalance(model,
                                                    User.Claims.First(i => i.Type == "accountId").Value,
                                                    User.Claims.First(i => i.Type == "msisdn").Value,
                                                    User.Claims.First(i => i.Type == "currency").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: BundlePurchaseViaAccountBalance, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("VoucherRecharge")]
        [BasicAuth]
        public async Task<IActionResult> VoucherRecharge(VoucherRequestModel model)
        {
            try
            {
                return Ok(await _paymentService.VoucherRecharge(model));
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: PaymentController, Method: VoucherRecharge , " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetAutoTopupSettings")]
        [BasicAuth]
        public async Task<IActionResult> GetAutoTopupSettings(string msisdn)
        {
            try
            {
                return Ok(await _paymentService.GetAutoTopUp(msisdn));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentController, Method: GetAutoTopup, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
    }
}
