﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NowPayG.Models.ViewModels;
using NowPayG.Services.Interfaces;
using NowPayG.Utility;
using NowPayG.Models.Pay360ApiContracts;
using Microsoft.AspNetCore.Http;
using Serilog;
using NowPayG.Models;
using Newtonsoft.Json;
using NowPayG.Resources;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using NowPayG.Configurations;
using NowPayG.Models.ApiContracts.Response;
using System.Globalization;
using PhoneNumbers;

namespace NowPayG.Controllers
{
    public class Pay360Controller : Controller
    {
        private readonly EndPoints _endPointsSettings;
        private readonly IPay360Service Pay360Service;
        private readonly ILogger Logger;

        public Pay360Controller(IOptions<EndPoints> endPointsSettings, IPay360Service pay360Service, ILogger logger)
        {
            _endPointsSettings = endPointsSettings.Value;
            Pay360Service = pay360Service;
            Logger = logger;
        }

        [ActionName("SecureReturn")]
        public async Task<IActionResult> SecureReturn(Secure3DViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    //redirect back with validation errors
                    return BadRequest(ModelState);
                }

                Pay360Resume3DRequest request = new Pay360Resume3DRequest
                {
                    pareq = model.PaRes,
                    pay360TransactionId = model.MD
                };

                var response = await Pay360Service.Resume3DTransaction(request);

                MessageViewModel ViewModel = new MessageViewModel();

                await ViewModel.SetSharedDataAsync(User);

                if (response != null)
                {
                    if (response.errorCode > 0)
                    {
                        if (response.pay360ApiCode == "V107")
                        {
                            if (response.message.Contains("SUCCESS"))
                            {
                                await SecureReturnSuccess(model, response);
                                return RedirectToAction("PaymentSuccessful");
                            }
                            else
                            {
                                TempData["Heading"] = "Payment Failed";
                                TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";
                                return RedirectToAction("Error", "Error");
                            }
                        }
                        else if (response.pay360ApiCode == "A125")
                        {
                            return RedirectToAction("Inprogress");
                        }
                        else
                        {
                            TempData["Heading"] = "Payment Failed";

                            var ErrorCodes = new int[] { 5, 11, 21, 22, 27 };

                            if (ErrorCodes.Contains(response.errorCode))
                            {
                                TempData["Message"] = PaymentAPIMessagesResource.ResourceManager.GetString(Enum.GetName(typeof(Pay360StatusCodes), response.errorCode));
                            }
                            else if (response.errorCode == 12)
                            {
                                TempData["Message"] = response.message;
                            }
                            else
                            {
                                TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";
                            }

                            Logger.Error($"Class: Pay360Controller, Method: SecureReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorCode: { response.errorCode} , ErrorMessage: {response.message}");

                            return RedirectToAction("Error", "Error");
                        }
                    }
                    else
                    {
                        await SecureReturnSuccess(model, response);
                        return RedirectToAction("PaymentSuccessful");

                    }
                }
                else
                {
                    return RedirectToAction("Error", "Error");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: SecureReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }
        private async Task SecureReturnSuccess(Secure3DViewModel model, GenericPay360ApiResponse<Pay360PaymentResponse> response)
        {
            //Get Pay360Model To Set AutoToup
            TempData["Heading"] = "Payment";

            //Get Pay360Model To Set AutoToup
            if (model.Checkout == CheckOutTypes.FastTopUp)
            {
                TempData["Message"] = "Topup of £" + model.Amount + " is done successfully.";

                Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                bundleDetail.Add("Id", model.Msisdn);
                bundleDetail.Add("name", "£" + model.Amount.ToString());
                bundleDetail.Add("amount", model.Amount.ToString());
                bundleDetail.Add("category", model.Checkout.ToString());
                TempData["BundleDetail"] = bundleDetail;

                if (model.IsAutenticated)
                {
                    await SetAutoToUpSettings(model.Msisdn, model.IsAutoTopUp, model.Amount, model.Email);
                }
            }
            else if (model.Checkout == CheckOutTypes.TopUp)
            {
                TempData["Message"] = "Topup of £" + model.Amount + " is done successfully.";

                Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                bundleDetail.Add("Id", model.Msisdn);
                bundleDetail.Add("name", "£" + model.Amount.ToString());
                bundleDetail.Add("amount", model.Amount.ToString());
                bundleDetail.Add("category", model.Checkout.ToString());
                TempData["BundleDetail"] = bundleDetail;

                if (model.IsAutenticated)
                {
                    await SetAutoToUpSettings(model.Msisdn, model.IsAutoTopUp, model.Amount, model.Email);
                }
            }
            else
            {
                if (model.IsAutenticated)
                {
                    try
                    {
                        var productCode = ProductCode.NOWPAYG.ToString();
                        var res = await Api.CallApi(_endPointsSettings.NowPaygApiEndPoint + "User/SetBundleAutoRenewal", User, new Models.ApiContracts.Request.BundleAutoRenewalRequestModel() { Uuid = model.Uuid, AccountId = model.AccountId, isAutoRenew = model.isAutoRenew, Msisdn = model.Msisdn, BundleAmount = Convert.ToInt32(model.Amount), ProductCode = productCode, Email = model.Email });
                    }
                    catch
                    {

                    }
                }
                TempData["Message"] = "Plan of £" + model.Amount + " is purchased successfully.";

                Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                bundleDetail.Add("Id", model.Msisdn);
                bundleDetail.Add("name", model.bundleName);
                bundleDetail.Add("amount", model.Amount.ToString());
                bundleDetail.Add("category", model.Checkout.ToString());
                TempData["BundleDetail"] = bundleDetail;

            }

        }
        private async Task SetAutoToUpSettings(string msisdn, bool isAutoTopUp, float amount, string email = null)
        {
            Pay360GetAutoTopUpRequest autoTopUpRequest = new Pay360GetAutoTopUpRequest
            {
                Msisdn = msisdn,
                Email = string.IsNullOrEmpty(email) ? User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value : email,
                ProductCode = ProductCode.NOWPAYG.ToString()
            };

            var pay360AutoTopUpDefaultSettings = await Pay360Service.GetAutoTopUp(autoTopUpRequest);

            var modelAutoTopUpRequest = new Pay360SetAutoTopUpRequest
            {
                isAutoTopup = isAutoTopUp,
                topupAmount = Convert.ToDecimal(amount),
                productRef = msisdn,
                topupCurrency = Currency.GBP.ToString(),
                productCode = ProductCode.NOWPAYG.ToString(),
                productItemCode = ProductItemCode.NOWPG.ToString(),
                thresholdBalanceAmount = pay360AutoTopUpDefaultSettings.payload.ThresHold,
                Email = string.IsNullOrEmpty(email) ? User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value : email
            };

            await Pay360Service.SetAutoTopUp(modelAutoTopUpRequest);
        }

        [HttpPost]
        [Route("StartPayment")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> StartPayment(Pay360ViewModel model)
        {
            try
            {
                if (string.IsNullOrEmpty(model.AddressL1))
                {
                    ModelState.Clear();
                }
                var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                model.Msisdn = phoneNumberUtil.Format(phoneNumberUtil.Parse(model.Msisdn, "GB"), PhoneNumberFormat.E164).Replace("+", "").Trim();
                var productCode = ProductCode.NOWPAYG.ToString();
                //User logged in and choose One of its card for Payment
                if (User.Identity.IsAuthenticated && (model.Pay360PaymentType == Pay360PaymentType.Token || model.Pay360PaymentType == Pay360PaymentType.Default))
                {
                    ModelState.Remove("UserCard.NameOnCard");
                    ModelState.Remove("UserCard.CardNumber");
                    ModelState.Remove("UserCard.ExpiryMonth");
                    ModelState.Remove("UserCard.ExpiryYear");
                    ModelState.Remove("UserCard.SecurityCode");
                }

                //User choose payment method other than card
                if (model.Pay360PaymentType == Pay360PaymentType.New || model.Pay360PaymentType == Pay360PaymentType.ExistingNew)
                {
                    ModelState.Remove("SecurityCode");
                    ModelState.Remove("UserCard.Token");
                }

                //Check ModelState
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }





                var Pay360PaymentResponse = await Pay360Service.Pay360Payment(await CreatePay360PaymentRequest(model), model.Pay360PaymentType);

                MessageViewModel ViewModel = new MessageViewModel();
                await ViewModel.SetSharedDataAsync(User);

                if (Pay360PaymentResponse != null)
                {
                    if (Pay360PaymentResponse.errorCode > 0)
                    {

                        TempData["Heading"] = "Payment Failed";

                        var ErrorCodes = new int[] { 5, 11, 21, 22, 27 };

                        if (ErrorCodes.Contains(Pay360PaymentResponse.errorCode))
                        {
                            TempData["Message"] = PaymentAPIMessagesResource.ResourceManager.GetString(Enum.GetName(typeof(Pay360StatusCodes), Pay360PaymentResponse.errorCode));
                        }
                        else if (Pay360PaymentResponse.errorCode == 12)
                        {
                            TempData["Message"] = Pay360PaymentResponse.message;
                        }
                        else
                        {
                            TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";
                        }

                        Logger.Error($"Class: Pay360Controller, Method: StartPayment, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorCode: { Pay360PaymentResponse.errorCode}, ErrorMessage: { Pay360PaymentResponse.message}");

                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        if (Pay360PaymentResponse.payload != null)
                        {

                            if (User.Identity.IsAuthenticated)
                            {
                                try
                                {
                                    var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                                    if (!string.IsNullOrEmpty(products))
                                    {
                                        model.AccountId = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Where(x => x.ProductRef == model.Msisdn).FirstOrDefault().AccountId;
                                    }
                                }
                                catch
                                {

                                }
                            }
                            var payload = Pay360PaymentResponse.payload;
                            string domain = $"https://{this.Request.Host}{this.Request.PathBase}/pay360/SecureReturn?Msisdn=" + model.Msisdn + "&Amount=" + model.Amount + "&IsAutoTopUp=" + model.AutoTopUp + "&Checkout=" + model.CheckoutPaymentType + "&IsAutenticated=" + (User.Identity.IsAuthenticated ? true : false) + "&Email=" + (User.Identity.IsAuthenticated ? User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value : null) + "&bundleName=" + model.BundleName;


                            if (User.Identity.IsAuthenticated && model.CheckoutPaymentType == CheckOutTypes.Bundle)
                            {
                                domain += "&AccountId=" + model.AccountId.TrimEnd() + "&Uuid=" + model.UUID + "&isAutoRenew=" + model.isAutoRenew;
                            }
                            if (new Uri(domain).IsAbsoluteUri)
                            {
                                domain = new Uri(domain).AbsoluteUri.ToString();
                            }

                            Pay360TransactionViewModel pvm = null;
                            string view = string.Format("~/Views/Account/Redirect3dSecure.cshtml");

                            if (payload.outcome.reasonCode == "U100")
                            {
                                pvm = new Pay360TransactionViewModel
                                {
                                    url = payload.clientRedirect.url,
                                    pareq = payload.clientRedirect.pareq,
                                    type = payload.clientRedirect.type,
                                    TransactionId = Pay360PaymentResponse.payload.transactionId,
                                    returnUrl = domain
                                };
                                return View(view, pvm);
                            }
                            else
                            {
                                TempData["Heading"] = "Payment";

                                if (model.CheckoutPaymentType == CheckOutTypes.FastTopUp)
                                {
                                    TempData["Message"] = "Topup of £" + model.Amount + " is done successfully.";

                                    //Passing Data to view for Google Analytics 
                                    Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                                    bundleDetail.Add("Id", model.Msisdn);
                                    bundleDetail.Add("name", "£" + model.Amount.ToString());
                                    bundleDetail.Add("amount", model.Amount.ToString());
                                    bundleDetail.Add("category", model.CheckoutPaymentType.ToString());
                                    TempData["BundleDetail"] = bundleDetail;

                                    if (User.Identity.IsAuthenticated)
                                    {
                                        await SetAutoToUpSettings(model.Msisdn, model.AutoTopUp, model.Amount);
                                    }
                                }
                                else if (model.CheckoutPaymentType == CheckOutTypes.TopUp)
                                {
                                    TempData["Message"] = "Topup of £" + model.Amount + " is done successfully.";

                                    //Passing Data to view for Google Analytics 
                                    Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                                    bundleDetail.Add("Id", model.Msisdn);
                                    bundleDetail.Add("name", "£" + model.Amount.ToString());
                                    bundleDetail.Add("amount", model.Amount.ToString());
                                    bundleDetail.Add("category", model.CheckoutPaymentType.ToString());
                                    TempData["BundleDetail"] = bundleDetail;

                                    if (User.Identity.IsAuthenticated)
                                    {
                                        await SetAutoToUpSettings(model.Msisdn, model.AutoTopUp, model.Amount);
                                    }
                                }
                                else
                                {
                                    try
                                    {
                                        var response = await Api.CallApi(_endPointsSettings.NowPaygApiEndPoint + "User/SetBundleAutoRenewal", User, new Models.ApiContracts.Request.BundleAutoRenewalRequestModel() { Uuid = model.UUID, AccountId = model.AccountId, isAutoRenew = model.isAutoRenew, Msisdn = model.Msisdn, BundleAmount = Convert.ToInt32(model.Amount), ProductCode = productCode, Email = (User.Identity.IsAuthenticated ? User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value : null) });
                                    }
                                    catch
                                    {

                                    }

                                    TempData["Message"] = "Plan of £" + model.Amount + " is purchased successfully.";

                                    Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                                    bundleDetail.Add("Id", model.Msisdn);
                                    bundleDetail.Add("name", model.BundleName);
                                    bundleDetail.Add("amount", model.Amount.ToString());
                                    bundleDetail.Add("category", CheckOutTypes.Bundle.ToString());
                                    TempData["BundleDetail"] = bundleDetail;
                                }

                                return RedirectToAction("PaymentSuccessful");
                            }
                        }
                        else
                        {
                            return RedirectToAction("Error", "Error");
                        }
                    }
                }
                else
                {
                    return RedirectToAction("Error", "Error");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: StartPayment, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        private async Task<Pay360PaymentRequest> CreatePay360PaymentRequest(Pay360ViewModel model)
        {
            string FirstRegistrationDate;
            try
            {
                var response = await Api.CallApi(_endPointsSettings.NowPaygApiEndPoint + "CommonServices/GetFirstUseDate", User, GetRequest: true, parameters: "Msisdn=" + model.Msisdn);
                if (response is Error)
                {
                    FirstRegistrationDate = "";
                }
                else
                {
                    FirstRegistrationDate = Convert.ToDateTime(response.GetValue("payload").ToObject<string>()).ToString("yyyy-MM-dd");
                }
            }
            catch
            {
                FirstRegistrationDate = "";
            }

            List<fieldstate> _fieldState = new List<fieldstate>()
                {
                    new fieldstate() { name = "ProductCode", value = "NOWPAYG", transient = false },
                    new fieldstate() { name = "ProductItemCode", value = "NOWPG", transient = false },
                    new fieldstate() { name = "FirstUseDate", value = FirstRegistrationDate, transient = false },
                };


            List<basket> baskets = new List<basket>();
            if (model.CheckoutPaymentType == CheckOutTypes.Bundle)
            {
                basket basket = new basket()
                {
                    amount = model.Amount,
                    bundleRef = model.UUID,
                    productItemCode = ProductItemCode.NOWPG.ToString(),
                    productRef = model.Msisdn
                };

                baskets.Add(basket);
            }
            else
            {
                basket basket = new basket()
                {
                    amount = model.Amount,
                    bundleRef = "",
                    productItemCode = ProductItemCode.NOWPG.ToString(),
                    productRef = model.Msisdn
                };

                baskets.Add(basket);
            }

            string email = User.Identity.IsAuthenticated ? User.Claims.Where(e => e.Type == "Email").FirstOrDefault().Value : model.EmailAddress;
            model.CustomerEmail = email;

            Pay360PaymentRequest request = new Pay360PaymentRequest();
            switch (model.Pay360PaymentType)
            {
                case Pay360PaymentType.New:
                    var PaymentNewBaseRequest = Pay360Service.CreatePay360PaymentRequestNew(model);
                    request.Pay360PaymentRequestNew = PaymentNewBaseRequest;
                    request.Pay360PaymentRequestNew.basket = baskets;
                    request.Pay360PaymentRequestNew.customerMsisdn = model.Msisdn;
                    request.Pay360PaymentRequestNew.customerUniqueRef = model.CustomerEmail;
                    request.Pay360PaymentRequestNew.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestNew.transactionCurrency = Currency.GBP.ToString();
                    request.Pay360PaymentRequestNew.ipAddress = ExtensionMethods.GetRemoteIPAddress(HttpContext);
                    request.Pay360PaymentRequestNew.productCode = ProductCode.NOWPAYG.ToString();
                    request.Pay360PaymentRequestNew.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestNew.customFields = new customField() { fieldState = _fieldState };

                    break;
                case Pay360PaymentType.Token:
                    var PaymentTokenBaseRequest = Pay360Service.CreatePay360PaymentRequestToken(model);
                    request.Pay360PaymentRequestToken = PaymentTokenBaseRequest;
                    request.Pay360PaymentRequestToken.basket = baskets;
                    request.Pay360PaymentRequestToken.customerMsisdn = model.Msisdn;
                    request.Pay360PaymentRequestToken.customerUniqueRef = model.CustomerEmail;
                    request.Pay360PaymentRequestToken.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestToken.transactionCurrency = Currency.GBP.ToString();
                    request.Pay360PaymentRequestToken.ipAddress = ExtensionMethods.GetRemoteIPAddress(HttpContext);
                    request.Pay360PaymentRequestToken.productCode = ProductCode.NOWPAYG.ToString();
                    request.Pay360PaymentRequestToken.cardCv2 = model.SecurityCode;
                    request.Pay360PaymentRequestToken.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestToken.customFields = new customField() { fieldState = _fieldState };
                    break;

                case Pay360PaymentType.ExistingNew:
                    var PaymentExistingNewBaseRequest = Pay360Service.CreatePay360PaymentRequestExistingNew(model);
                    request.Pay360PaymentRequestExistingNew = PaymentExistingNewBaseRequest;
                    request.Pay360PaymentRequestExistingNew.basket = baskets;
                    request.Pay360PaymentRequestExistingNew.customerMsisdn = model.Msisdn;
                    request.Pay360PaymentRequestExistingNew.customerUniqueRef = model.CustomerEmail;
                    request.Pay360PaymentRequestExistingNew.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestExistingNew.transactionCurrency = Currency.GBP.ToString();
                    request.Pay360PaymentRequestExistingNew.ipAddress = ExtensionMethods.GetRemoteIPAddress(HttpContext);
                    request.Pay360PaymentRequestExistingNew.productCode = ProductCode.NOWPAYG.ToString();
                    request.Pay360PaymentRequestExistingNew.cardCv2 = model.UserCard.SecurityCode;
                    request.Pay360PaymentRequestExistingNew.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestExistingNew.customFields = new customField() { fieldState = _fieldState };
                    break;

            }
            return request;
        }

        [HttpGet]
        [Route("myPaymentMethods")]
        [Authorize]
        public async Task<IActionResult> PaymentMethodsSettings()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: PaymentMethodsSettings, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetMyPaymentMethods()
        {
            try
            {
                var Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value;
                if (!string.IsNullOrEmpty(Email))
                {

                    //Get User Pay360 Cards
                    var cardsResponse = await Pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
                    {
                        customerUniqueRef = Email,
                        productCode = ProductCode.NOWPAYG.ToString(),
                    });

                    if (cardsResponse != null)
                    {
                        if (cardsResponse.errorCode > 0)
                        {
                            return GenericResponseMessagePay360(cardsResponse.errorCode, cardsResponse.message);
                        }
                        else
                        {
                            if (cardsResponse.payload != null)
                            {
                                return Json(new { status = true, message = string.Empty, data = cardsResponse.payload });
                            }
                            else
                            {
                                return Json(new { status = false, message = "Something went wrong on server.", data = string.Empty });
                            }
                        }
                    }
                    else
                    {
                        return Json(new { status = false, message = "Something went wrong on server.", data = string.Empty });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: GetMyPaymentMethods, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> SetCustomerDefaultCard(SetCustomerDefaultCardRequest model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }

                var Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value;
                if (!string.IsNullOrEmpty(Email))
                {
                    //Getting Pay360 CustomerID
                    var customerResponse = await Pay360Service.GetCustomer(new Pay360CustomerRequestModel() { customerUniqueRef = Email, productCode = ProductCode.NOWPAYG.ToString() });

                    if (customerResponse != null)
                    {
                        if (customerResponse.errorCode > 0)
                        {
                            return GenericResponseMessagePay360(customerResponse.errorCode, customerResponse.message);
                        }
                        else
                        {
                            if (customerResponse.payload != null)
                            {
                                //Getting Card Response
                                var cardResponse = await Pay360Service.SetCustomerDefaultCard(new SetCustomerDefaultCardRequest() { cardToken = model.cardToken, defaultCardCV2 = model.defaultCardCV2, pay360CustomerID = customerResponse.payload.pay360CustId });
                                if (cardResponse != null)
                                {
                                    if (cardResponse.errorCode > 0)
                                    {
                                        return GenericResponseMessagePay360(cardResponse.errorCode, cardResponse.message);
                                    }
                                    else
                                    {
                                        return Json(new { status = true, message = string.Empty, data = cardResponse.payload });
                                    }
                                }
                            }
                            return Json(new { status = false, message = "Something went wrong on server.", data = string.Empty });
                        }
                    }
                    else
                    {
                        return Json(new { status = false, message = "Something went wrong on server.", data = string.Empty });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: GetMyPaymentMethods, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> RemoveCard(RemoveCardRequest model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }

                var Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value;
                if (!string.IsNullOrEmpty(Email))
                {
                    //Getting Pay360 CustomerID
                    var customerResponse = await Pay360Service.GetCustomer(new Pay360CustomerRequestModel() { customerUniqueRef = Email, productCode = ProductCode.NOWPAYG.ToString() });

                    if (customerResponse != null)
                    {
                        if (customerResponse.errorCode > 0)
                        {
                            return GenericResponseMessagePay360(customerResponse.errorCode, customerResponse.message);
                        }
                        else
                        {
                            if (customerResponse.payload != null)
                            {
                                //Getting Card Response
                                var cardResponse = await Pay360Service.RemoveCard(new RemoveCardRequest() { cardToken = model.cardToken, pay360CustomerID = customerResponse.payload.pay360CustId });
                                if (cardResponse != null)
                                {
                                    if (cardResponse.errorCode > 0)
                                    {
                                        return GenericResponseMessagePay360(cardResponse.errorCode, cardResponse.message);
                                    }
                                    else
                                    {
                                        return Json(new { status = true, message = string.Empty });
                                    }
                                }
                            }
                            return Json(new { status = false, message = "Something went wrong on server.", data = string.Empty });
                        }
                    }
                    else
                    {
                        return Json(new { status = false, message = "Something went wrong on server.", data = string.Empty });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: RemoveCard, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> RemoveDefaultCard(RemoveCardRequest model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }


                var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                if (!string.IsNullOrEmpty(products))
                {
                    var list = Newtonsoft.Json.JsonConvert.DeserializeObject<IEnumerable<NowPayG.Models.ApiContracts.Response.UserProductsResponseModel>>(products);
                    foreach (var item in list)
                    {
                        var autoToupResponse = await Pay360Service.GetAutoTopUp(new Pay360GetAutoTopUpRequest() { Msisdn = item.ProductRef, Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value, ProductCode = ProductCode.NOWPAYG.ToString() });
                        if (autoToupResponse != null && autoToupResponse.errorCode == 0 && autoToupResponse.payload != null)
                        {
                            await SetAutoToUpSettings(item.ProductRef, false, autoToupResponse.payload.Topup);
                        }
                    }
                }

                var Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value;

                if (!string.IsNullOrEmpty(Email))
                {
                    //Getting Pay360 CustomerID
                    var customerResponse = await Pay360Service.GetCustomer(new Pay360CustomerRequestModel() { customerUniqueRef = Email, productCode = ProductCode.NOWPAYG.ToString() });

                    if (customerResponse != null)
                    {
                        if (customerResponse.errorCode > 0)
                        {
                            return GenericResponseMessagePay360(customerResponse.errorCode, customerResponse.message);
                        }
                        else
                        {
                            if (customerResponse.payload != null)
                            {
                                //Getting Card Response
                                var cardResponse = await Pay360Service.RemoveCard(new RemoveCardRequest() { cardToken = model.cardToken, pay360CustomerID = customerResponse.payload.pay360CustId });
                                if (cardResponse != null)
                                {
                                    if (cardResponse.errorCode > 0)
                                    {
                                        return GenericResponseMessagePay360(cardResponse.errorCode, cardResponse.message);
                                    }
                                    else
                                    {
                                        return Json(new { status = true, message = string.Empty });
                                    }
                                }
                            }
                            return Json(new { status = false, message = "Something went wrong on server.", data = string.Empty });
                        }
                    }
                    else
                    {
                        return Json(new { status = false, message = "Something went wrong on server.", data = string.Empty });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: RemoveDefaultCard, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> GetAutoTopup(AutoTopupSettingsViewModel model)
        {
            try
            {
                ModelState.Remove("productCode");
                ModelState.Remove("productItemCode");
                ModelState.Remove("thresholdBalanceAmount");
                ModelState.Remove("isAutoTopup");
                ModelState.Remove("topupAmount");
                ModelState.Remove("topupCurrency");

                //Getting Pay360 CustomerID
                var settingResponse = await Pay360Service.GetAutoTopUp(new Pay360GetAutoTopUpRequest() { Msisdn = model.productRef, Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value, ProductCode = ProductCode.NOWPAYG.ToString() });

                if (settingResponse != null)
                {
                    if (settingResponse.errorCode > 0)
                    {
                        return GenericResponseMessagePay360(settingResponse.errorCode, settingResponse.message);
                    }
                    else
                    {
                        if (settingResponse.payload != null)
                        {
                            return Json(new { status = true, message = string.Empty, data = settingResponse.payload });
                        }
                        else
                        {
                            return Json(new { status = false, message = "Something went wrong on server.", data = string.Empty });
                        }
                    }
                }
                else
                {
                    return Json(new { status = false, message = "Something went wrong on server.", data = string.Empty });
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: GetAutoTopup, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> SetAutoTopup(AutoTopupSettingsViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var cardsResponse = await Pay360Service.Pay360GetCards(new Pay360CustomerRequestModel() { customerUniqueRef = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value, productCode = ProductCode.NOWPAYG.ToString() });
                    if (cardsResponse != null)
                    {
                        if (cardsResponse.errorCode == 0
                            && cardsResponse.payload != null
                            && cardsResponse.payload.paymentMethodResponses != null
                            && cardsResponse.payload.paymentMethodResponses.Count > 0)
                        {
                            //Getting Pay360 CustomerID
                            var settingResponse = await Pay360Service.SetAutoTopUp(new Pay360SetAutoTopUpRequest()
                            {
                                isAutoTopup = model.isAutoTopup,
                                productCode = ProductCode.NOWPAYG.ToString(),
                                productRef = model.productRef,
                                topupAmount = model.topupAmount,
                                topupCurrency = Currency.GBP.ToString(),
                                thresholdBalanceAmount = model.thresholdBalanceAmount,
                                productItemCode = ProductItemCode.NOWPG.ToString(),
                                Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value
                            });

                            if (settingResponse != null)
                            {
                                if (settingResponse.errorCode > 0)
                                {
                                    return GenericResponseMessagePay360(settingResponse.errorCode, settingResponse.message);
                                }
                                else
                                {
                                    if (settingResponse.payload != null)
                                    {
                                        return Json(new { status = true, message = "Auto top up  settings updated successfully.", cards = true });
                                    }
                                    else
                                    {
                                        return Json(new { status = false, message = "Something went wrong on server.", cards = true });
                                    }
                                }
                            }
                            else
                            {
                                return Json(new { status = false, message = "Something went wrong on server.", cards = true });
                            }
                        }
                        else
                        {
                            return Json(new { status = false, message = "No Cards", cards = false });
                        }
                    }
                    else
                    {
                        return Json(new { status = false, message = "Something went wrong on server.", cards = false });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest, ModelState);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: SetAutoTopup, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        private JsonResult GenericResponseMessagePay360(int ErrorCode, string Message)
        {
            if (Enum.IsDefined(typeof(Pay360StatusCodes), ErrorCode))
            {
                return Json(new { status = false, message = PaymentAPIMessagesResource.ResourceManager.GetString(Enum.GetName(typeof(Pay360StatusCodes), ErrorCode)), data = string.Empty });
            }
            else
            {
                return Json(new { status = false, message = string.IsNullOrEmpty(Message) ? "Something went wrong the server." : Message, data = string.Empty });
            }
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("PaymentSuccessful")]
        [ActionName("PaymentSuccessful")]
        public async Task<IActionResult> Success()
        {
            var model = new MessageViewModel()
            {
                Heading = (string)TempData["Heading"],
                Message = (string)TempData["Message"]
            };

            //Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
            //bundleDetail.Add("Id", "1234");
            //bundleDetail.Add("name", "10");
            //bundleDetail.Add("amount", "10");
            //bundleDetail.Add("category", CheckOutTypes.TopUp.ToString());
            //TempData["BundleDetail"] = bundleDetail;

            ViewBag.BundleDetail = (TempData["BundleDetail"] != null) ? TempData["BundleDetail"] : new Dictionary<string, string>();
            TempData.Keep();
            await model.SetSharedDataAsync(User);
            return View("~/Views/Shared/Success.cshtml", model);
        }
        [HttpGet]
        [AllowAnonymous]
        [Route("Inprogress")]
        [ActionName("Inprogress")]
        public async Task<IActionResult> Inprogress()
        {
            var model = new MessageViewModel()
            {
                Heading = (string)TempData["Heading"],
                Message = (string)TempData["Message"]
            };

            ViewBag.BundleDetail = (TempData["BundleDetail"] != null) ? TempData["BundleDetail"] : new Dictionary<string, string>();
            TempData.Keep();
            await model.SetSharedDataAsync(User);
            return View("~/Views/Shared/Inprogress.cshtml", model);
        }
    }
}
