﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Services
{
    public interface IPhoneNumberService : ServiceType.ITransient
    {
        Task<CountryDto?> GetCountry(string msisdn);
    }
}