﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Database
{
    public class TransactionItems
    {
        public int Id { get; set; }
        public string ProductItemCode { get; set; }
        public float Amount { get; set; }
        public string ProductRef { get; set; }
        public string BundleRef { get; set; }
        public int TransactionId { get; set; }
        public int IsFullfilled { get; set; }
        public string FullfillmentError { get; set; }
        public bool IsEmailSent { get; set; }
        public bool IsSmsSent { get; set; }
        public DateTime SmsSent_DateTime { get; set; }
        public DateTime FulfilmentDateTime { get; set; }
        public DateTime EmailSent_DateTime { get; set; }
    }
}
