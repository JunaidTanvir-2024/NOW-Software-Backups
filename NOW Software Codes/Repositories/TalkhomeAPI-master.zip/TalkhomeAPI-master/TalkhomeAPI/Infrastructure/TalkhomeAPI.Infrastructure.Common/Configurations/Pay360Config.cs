﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeAPI.Models.Configurations
{
    public class Pay360Config
    {
        public string Pay360ApiEndpoint { get; set; }
        public bool IsAuthorization { get; set; }
        public bool TransferIsAuthorization { get; set; }
        
        public bool Do3DSecure { get; set; }
        public bool IsDirectFullfilment { get; set; }
        public bool IsBillingAndCustomerAddressSame { get; set; }
        public Pay360TransferSettings TransferSettings { get; set; }
        public Pay360TopUpSettings TopUpSettings { get; set; }
    }

    public class Pay360TransferSettings
    {
        public string ReturnUrl { get; set; }
    }

    public class Pay360TopUpSettings
    {
        public string ReturnUrl { get; set; }
    }
}
