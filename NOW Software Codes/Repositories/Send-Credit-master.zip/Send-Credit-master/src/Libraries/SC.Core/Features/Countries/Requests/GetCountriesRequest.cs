﻿using Microsoft.AspNetCore.Mvc;

using System.Text.Json.Serialization;

namespace SC.Core.Features.Countries.Requests;

public sealed class GetCountriesRequest : IRequest<IResultWrapper>
{
    [JsonPropertyName("page")]
    public int Page { get; set; } = default!;

    [JsonPropertyName("recordsPerPage")]
    public int RecordsPerPage { get; set; } = default!;

    [JsonPropertyName("countryFilters")]
    public CountryFilter? CountryFilters { get; set; }

    public sealed record CountryFilter
    {
        public string? CountryName { get; set; }
        public string? CountryCallingCode { get; set; }
        public string? IsoCode2 { get; set; }
        public string? IsoCode3 { get; set; }
    }
}

public sealed class GetAllCountriesRequestValidator : AbstractValidator<GetCountriesRequest>
{
    public GetAllCountriesRequestValidator()
    { }
}