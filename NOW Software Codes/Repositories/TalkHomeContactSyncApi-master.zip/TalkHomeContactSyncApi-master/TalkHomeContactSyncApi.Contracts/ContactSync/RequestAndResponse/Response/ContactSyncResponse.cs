﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Response
{
    public class ContactSyncResponse
    {
        public string Contact { get; set; } 
        //public bool IsTalkHomeUser { get; set; }
    }
}
