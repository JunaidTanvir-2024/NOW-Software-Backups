﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ViewModels
{
    public class SuccessMessageViewModel
    {
        public string Key { get; set; }
        public string Pin { get; set; }
        public string CardNumber { get; set; }
        public string PurchaseType { get; set; }
        public string ProductItemCode { get; set; }
        public int NewPoints { get; set; }
        public string NewBalnce { get; set; }
        public int TotalPoints { get; set; }
        public string TransectionAmmount { get; set; }
        public string TransactionID { get; set; }
        public bool IsAutoProductAttached { get; set; }
    }
}
