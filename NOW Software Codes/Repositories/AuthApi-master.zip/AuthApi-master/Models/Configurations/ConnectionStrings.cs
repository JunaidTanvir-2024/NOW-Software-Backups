﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    
    public class ConnectionStrings
    {
        public string DefaultConnection { get; set; }
        public string DigiTalkConnection { get; set; }
        public string NowPaygConnection { get; set; }
        public string THMConnection { get; set; }
        

    }

}
