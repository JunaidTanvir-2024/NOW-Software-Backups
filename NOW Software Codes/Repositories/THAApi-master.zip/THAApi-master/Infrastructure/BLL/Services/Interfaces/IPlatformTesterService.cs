﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface IPlatformTesterService
    {
        bool CanTestInAppPurchase(string msisdn);

        bool CanTestBundles(string msisdn);

        bool CanUseBundes(string msisdn);
    }
}
