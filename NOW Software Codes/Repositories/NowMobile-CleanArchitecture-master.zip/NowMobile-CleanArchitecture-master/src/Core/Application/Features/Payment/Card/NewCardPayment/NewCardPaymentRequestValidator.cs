﻿using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.Payment.Card.NewCardPayment;

public class NewCardPaymentRequestValidator : AbstractValidator<NewCardPaymentRequest>
{
    public NewCardPaymentRequestValidator(ICommonService commonService, IOptions<TopupSettings> options)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
             .NotEmpty()
             .NotNull()
             .Must(p => commonService.IsValidMsisdn(p!))
             .WithMessage("Invalid msisdn");

        RuleFor(p => p.PaymentCardInfo.CardNumber).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MaximumLength(19);
        RuleFor(p => p.PaymentCardInfo.ExpiryMonth).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(2).MaximumLength(2);
        RuleFor(p => p.PaymentCardInfo.ExpiryYear).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(2).MaximumLength(2);
        RuleFor(p => p.PaymentCardInfo.NameOnCard).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.PaymentCardInfo.SecurityCode).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(3).MaximumLength(4);

        RuleFor(p => p.PaymentAddressInfo.AddressL1).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.PaymentAddressInfo.City).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.PaymentAddressInfo.PostCode).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.PaymentAddressInfo.CountryCode).Cascade(CascadeMode.Stop).NotNull().NotEmpty();

      
     
        RuleFor(p => p.TopupInfo!.TopupAmount).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => options.Value.TopUpAmounts.Contains(p))
            .When(p => p.TopupInfo != null)
            .WithMessage("Invalid topup amount");

        RuleFor(p => p.TopupInfo!.AutoTopupInfo).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => options.Value.AutoTopupThresholdAmounts.Contains(p!.ThresHoldAmount)).WithMessage("Invalid threshold amount")
            .Must(p => options.Value.TopUpAmounts.Contains(p!.TopupAmount)).WithMessage("Invalid auto top-up amount")
            .When(p => p.TopupInfo != null && p.TopupInfo.AutoTopupInfo != null);

        RuleFor(p => p.BundleInfo).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => p!.BundleId > 0).WithMessage("Invalid bundle reference")
            .When(p => p.BundleInfo != null);

    }
}