﻿
namespace THCC.Application.Features.User.CallingCardSummary
{
    public class CallingCardSummaryResponse
    {
        public string Status { get; set; } = default!;
        public string ExpiryDate { get; set; } = default!;
        public string RemainingBalance { get; set; } = default!;
    }
}
