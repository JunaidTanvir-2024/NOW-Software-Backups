﻿using SC.Core.Common.Model.EventNotification;
using SC.Core.Features.Notification.Request;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace SC.Api.Model.EventTracking;
public class EventTrackingModel
{
    //  public IEnumerable<FacebookEventData> FacebookEvents { get; set; }=default!;

    [Required(ErrorMessage = "The {0} field is required.")]
    [DefaultValue("")]
    public string EventName { get; set; } = default!;
    [DefaultValue("")]
    public string EventValue { get; set; } = default!;
    [DefaultValue("")]
    public string EventCurrency { get; set; } = default!;
    [DefaultValue("")]
    public string Email { get; set; } = default!;
    [DefaultValue("")]
    public string PhoneNumber { get; set; } = default!;
    [Required(ErrorMessage = "The {0} field is required.")]
    [DefaultValue("")]
    public string ClientId { get; set; } = default!;
    [Required(ErrorMessage = "The {0} field is required.")]
    [DefaultValue("")]
    public string PlatForm { get; set; } = default!;
    [DefaultValue("")]
    public string Uri { get; set; } = default!;

    public EventTrackingRequest Map()
    {
        return new EventTrackingRequest
        {
            EventName = EventName,
            EventValue = EventValue,
            EventCurrency = EventCurrency,
            Email = Email,
            PhoneNumber = PhoneNumber,
            ClientId = string.IsNullOrEmpty(ClientId) == true ? Guid.NewGuid().ToString() : ClientId,
            PlatForm = PlatForm,
            Uri = Uri,
            ProductCode = "SC",
            RequestDateTime = DateTime.UtcNow
        };

    }
}

