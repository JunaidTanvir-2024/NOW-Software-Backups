﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services
{

    public class HttpService : IHttpService
    {
        private readonly HttpClient client;
        public HttpService(HttpClient client)
        {
            this.client = client;
        }
        public async Task<string> GetAsync(string address)
        {
            return await GetAsync(address, null, null);
        }
        public async Task<string> GetAsync(string address, string username, string password)
        {
            try
            {
                //client.BaseAddress = new Uri(address);
                if (!String.IsNullOrEmpty(username) && !String.IsNullOrEmpty(password))
                {
                    client.DefaultRequestHeaders.Add(username, password);
                }

                HttpResponseMessage response = await client.GetAsync(address);
                response.EnsureSuccessStatusCode();

                if (response.IsSuccessStatusCode && response.Content != null)
                {
                    return await response.Content.ReadAsStringAsync();
                }
                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            return null;
        }
        public async Task<string> PostAsync(string address, string json)
        {
            return await PostAsync(address, json, null, null);
        }
        public async Task<string> PostAsync(string address, string json, string username, string password)
        {
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                //client.BaseAddress = new Uri(address);
                if (!String.IsNullOrEmpty(username) && !String.IsNullOrEmpty(password))
                {
                    client.DefaultRequestHeaders.Add(username, password);
                }

                HttpResponseMessage response = await client.PostAsync(address, content);
                response.EnsureSuccessStatusCode();

                if (response.IsSuccessStatusCode && response.Content != null)
                {
                    return await response.Content.ReadAsStringAsync();
                }
                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            return null;
        }
    }
}
