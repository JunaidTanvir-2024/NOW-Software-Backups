﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class StandardResponse
    {
        public int ErrorCode { get; set; }

        public string ErrorMsg { get; set; }
    }
}
