﻿/*******************
 *   Internaltional Rates
 *   UK Rates
 *   Roaming Rates
 *   Countries
 *************************************/
var InternationalRatesList_Rates = [];

$(document).ready(function () {
    GetAllCountries();
    GetAllNationalRates();
    GetAllInternationalRates();

    //Validate Dropdowns
    $('#dpl_RoamingCountry').change(function () {
        var valid = $('#RoamingCountriesForm').data('validator').element('#dpl_RoamingCountry');
        if (valid) {

            var item = $('#dpl_RoamingCountry').val();
            $("#dpl_FromRoamingCountry option").prop('disabled', false);
            $("#dpl_FromRoamingCountry option[value='" + item + "']").prop('disabled', true);

            //Check validity of 
            if ($('#RoamingCountriesForm').data('validator').element('#dpl_FromRoamingCountry')) {
                GetRoamingRates(item, $('#dpl_FromRoamingCountry').val());
            }
        }
        else {
            $("#dpl_FromRoamingCountry option").prop('disabled', false);
        }

    });

    $('#dpl_FromRoamingCountry').change(function () {
        var valid = $('#RoamingCountriesForm').data('validator').element('#dpl_FromRoamingCountry');
        if (valid) {
            var item = $('#dpl_FromRoamingCountry').val();
            $("#dpl_RoamingCountry option").prop('disabled', false);
            $("#dpl_RoamingCountry option[value='" + item + "']").prop('disabled', true);

            //Check validity of 
            if ($('#RoamingCountriesForm').data('validator').element('#dpl_RoamingCountry')) {
                GetRoamingRates($('#dpl_RoamingCountry').val(), item);
            }
        }
        else {
            $("#dpl_RoamingCountry option").prop('disabled', false);
        }
    });

});

function GetAllNationalRates() {

    $.ajax({
        url: "/Home/GetAllUKRates",
        type: "GET",
        beforeSend: function (xhr) {

        },
        success: function (response) {
            $('#lbl_LandlineNat').html(response.data.ukRatesList[0].landline);
            $('#lbl_DataNat').html(response.data.ukRatesList[0].data);
            $('#lbl_MobileNat').html(response.data.ukRatesList[0].mobile);
            $('#lbl_TextNat').html(response.data.ukRatesList[0].text);
        },
        complete: function (xhr, status) {

        },
        error: function (xhr, status, error) {

        }
    });

}

function GetAllInternationalRates() {

    $.ajax({
        url: "/Home/GetInternationalRates",
        type: "GET",
        beforeSend: function (xhr) {

        },
        success: function (response) {
            InternationalRatesList_Rates = response.data.internationalRatesList;
        },
        complete: function (xhr, status) {

        },
        error: function (xhr, status, error) {

        }
    });

}

function ShowInternationalRates() {

    var CountryID = $('#dpl_InternationalCountry').val();
    var InternationalRatesData = InternationalRatesList_Rates.filter(function (x) { return x.countryId === parseInt(CountryID) });

    if (InternationalRatesData != undefined) {
        $('#Rates_IR_Landline').html(parseFloat(parseFloat(InternationalRatesData[0].landlineRate) * 100).toFixed(0) + "p");
        $('#Rates_IR_Mobile').html(parseFloat(parseFloat(InternationalRatesData[0].mobileRate) * 100).toFixed(0) + "p");
        $('#Rates_IR_Text').html(parseFloat(parseFloat(InternationalRatesData[0].smsRate) * 100).toFixed(0) + "p");
        $('.IRduration').show();
    }
    else {
        $('#Rates_IR_Landline').html('');
        $('#Rates_IR_Mobile').html('');
        $('#Rates_IR_Text').html('');
        $('.IRduration').hide();
    }

}

function GetRoamingRates(FromCountry, ToCountry) {

    $.ajax({
        url: "/Home/GetRoamingRates",
        type: "GET",
        data: { FromCountryId: FromCountry, ToCountryId: ToCountry },
        beforeSend: function (xhr) {

        },
        success: function (response) {

            if (response != null) {

                //Mobile Rates
                if (response.data.roamingRates.voiceRate > 0) {
                    $('#txtLandline_romaingrate').text(response.data.roamingRates.voiceRate);
                    $('.mobilerateexist').show();
                    $('.mobileratenotexist').hide();
                }
                else {
                    $('.mobilerateexist').hide();
                    $('.mobileratenotexist').show();
                }

                //Landline Rates
                if (response.data.roamingRates.voiceRate > 0) {
                    $('#txtMobile_romaingrate').text(response.data.roamingRates.voiceRate);
                    $('.mobilerateexist').show();
                    $('.mobileratenotexist').hide();
                }
                else {
                    $('.mobilerateexist').hide();
                    $('.mobileratenotexist').show();
                }

                //Sms Rates
                if (response.data.roamingRates.smsRate > 0) {
                    $('#txtSms_romaingrate').text(response.data.roamingRates.smsRate);
                    $('.smsrateexist').show();
                    $('.smsratenotxist').hide();
                }
                else {
                    $('.smsrateexist').hide();
                    $('.smsratenotxist').show();
                }

                $('#RoamingRatesSection').show();
                $('#RoamingRatesSectionFailure').slideUp();
            }
            else {
                $('#RoamingRatesSection').hide();
                $('#RoamingRatesSectionFailure').slideDown();
            }
        },
        complete: function (xhr, status) {

        },
        error: function (xhr, status, error) {
            $('#RoamingRatesSection').hide();
            $('#RoamingRatesSectionFailure').slideDown();
        }
    });
}

function GetAllCountries() {

    $.ajax({
        url: "/Home/GetAllCountries",
        type: "GET",
        beforeSend: function (xhr) {

        },
        success: function (response) {

            var international = $("#dpl_InternationalCountry");
            var roaming = $('#dpl_RoamingCountry,#dpl_FromRoamingCountry');

            $.each(response.data.countries, function () {
                international.append(new Option(this.name, this.id));
                roaming.append(new Option(this.name, this.id));
            });
        },
        complete: function (xhr, status) {

        },
        error: function (xhr, status, error) {

        }
    });
}

