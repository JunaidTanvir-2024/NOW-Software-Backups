﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetUserByIDResponseModel
    {
        public UserResponseModel userData { get; set; }
        public IEnumerable<UserAddressResponseModel> userAddressList { get; set; }
    }

    public class UserAddressResponseModel
    {
        public int Id { get; set; }
        public int UserID { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string County { get; set; }
        public string PostCode { get; set; }
        public string Country { get; set; }
        public int AddressTypeID { get; set; }
    }
}
