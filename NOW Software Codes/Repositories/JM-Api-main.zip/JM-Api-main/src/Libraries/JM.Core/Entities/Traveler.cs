using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class Traveler : IBaseEntity<long>
{
	public long Id { get; set; }
	public long UserId { get; set; }
	public long TripId { get; set; }
	public User User { get; set; } = null!;
	public Trip Trip { get; set; } = null!;
	public ICollection<Expense> Expenses { get; set; } = [];
	public ICollection<Media> Media { get; set; } = [];
}
