using Asp.Versioning;

using FH.Api.Controllers.Common;
using FH.UseCases.Products;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.V1;

[ApiVersion(1.0)]
public sealed class ProductController : BaseApiController
{
    [HttpPost]
    public async Task<ActionResult> GetProducts([FromBody] GetProducts.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
    [HttpPost("Status")]
	public async Task<ActionResult> GetProductStatus(GetProductStatus.Query request)
	{
		var result = await Mediator.Send(request);
		if (result.IsSuccess)
		{
			return Ok(result);
		}

		return NotFound(result);
	}


    [HttpPost("ByOperator")]
    public async Task<ActionResult> GetProductByOperator([FromBody] GetProductOperator.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }

    [HttpPost("Category")]
    public async Task<ActionResult> GetByCategory(GetProductByCategory.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}
