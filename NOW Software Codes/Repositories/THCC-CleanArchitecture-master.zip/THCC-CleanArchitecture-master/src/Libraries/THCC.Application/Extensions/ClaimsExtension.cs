// namespace Servicely.Api.Commons.Extensions;

// public static class ClaimsExtension
// {
//     public static void GetPermissions(this List<UserRoleClaimDto> allPermissions, Type policy)
//     {
//         foreach (FieldInfo fi in policy.GetFields(BindingFlags.Static | BindingFlags.Public))
//         {
//             allPermissions.Add(new UserRoleClaimDto { Value = fi.GetValue(null)?.ToString(), Type = "Permissions" });
//         }
//     }
//     public static async Task AddPermissionClaim(this RoleManager<IdentityRole> roleManager, IdentityRole role, string permission)
//     {
//         var allClaims = await roleManager.GetClaimsAsync(role);
//         if (!allClaims.Any(a => a.Type == "Permission" && a.Value == permission))
//         {
//             await roleManager.AddClaimAsync(role, new Claim("Permission", permission));
//         }
//     }
// }
