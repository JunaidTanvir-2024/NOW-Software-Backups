﻿namespace THCC.Application.Models.Dtos
{
    public class AutoTopupDto
    {
        public decimal Amount { get; set; }
        public bool Status { get; set; }
    }
}