﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request.Paypal
{
    public class ProductBasket
    {
        public string ProductItemCode { get; set; }

        public float Amount { get; set; }


        public string ProductRef { get; set; }


        public string BundleRef { get; set; }
    }
}
