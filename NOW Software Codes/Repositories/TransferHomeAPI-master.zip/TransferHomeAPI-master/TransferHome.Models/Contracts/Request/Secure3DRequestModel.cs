﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.Request
{
    public class Secure3DRequestModel
    {
        [Required]
        public string MD { get; set; }
        [Required]
        public string PaRes { get; set; }
        [Required]
        public string Ref { get; set; }
        [Required]
        public string Currency { get; set; }
        [Required]
        public CheckOutTypes Checkout { get; set; }
        [Required]
        public string NowtelTransactionRef { get; set; }
        [Required]
        public string Product { get; set; }
        [Required]
        public string OperatorId { get; set; }
        [Required]
        public string MessageToRecipient { get; set; }
        [Required]
        public string FromMSISDN { get; set; }
    }
}
