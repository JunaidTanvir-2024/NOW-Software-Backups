﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PushSharp.Apple;
using PushSharp.Google;
using Serilog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class Push_BL : IPush_BL
    {
        private IApiCall ApiCall;
        private readonly ILogger Logger;
        private IPush_DL Db;
        private readonly PushNotificationApiConfig PushNotificationApiConfig;
        private GcmServiceBroker gcmBroker;
        private ApnsServiceBroker apnsBroker;
        private ApnsServiceBroker apnsSandboxBroker;
        private ApnsServiceBroker pushKitBroker;
        private ApnsServiceBroker pushKitSandboxBroker;

        // APNS certificate files must be in p12 format and contain ONLY the private key
        private static string APNS_PRODUCTION_KEY = "App_Data/apns_production_key.p12";
        private static string APNS_SANDBOX_KEY = "App_Data/apns_sandbox_key.p12";
        private static string APNS_VOIP_KEY = "App_Data/apns_voip_key.p12";

        private static string GCM_AUTH_TOKEN = "AIzaSyDp4WU-JK4qkQph_SSTIAuJwNuL3xNnALA";
        private static string GCM_SENDER_ID = "34157615997";


        public Push_BL(ILogger logger, IPush_DL db, IApiCall apiCall, IOptions<PushNotificationApiConfig> pushNotificationApiConfig)
        {
            Logger = logger;
            Db = db;
            ApiCall = apiCall;
            PushNotificationApiConfig = pushNotificationApiConfig.Value;
        }

        public async Task<bool> SendNotification(string msisdn, PushPayload payload)
        {
            try
            {
                var registration = await Db.GetPushRegistration(msisdn);
                if (registration == null)
                {
                    Logger.Warning($"Dest={msisdn} no registration found");
                    return false;
                }
                return await SendNotification(payload, registration);
            }
            catch (Exception ex)
            {
                Logger.Error("SendNotification Failed:" + ex.ToString());
                return false;
            }
        }

        public async Task<bool> SendNotification(PushPayload payload, PushRegistration registration)
        {
            try
            {
                if (payload.PrefersPushKit && registration.pushKit != null)
                {
                    var notificationTag = new NotificationTag(registration.msisdn);
                    var notification = new ApnsNotification();
                    notification.DeviceToken = registration.pushKit;
                    notification.Payload = PushKitPayload(payload);
                    //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                    notification.Tag = notificationTag;
                    if (payload.ExpiresImmediately)
                    {
                        notification.Expiration = ApnsNotification.DoNotStore;
                    }
                    Logger.Information($"Dest={registration.msisdn + (registration.sandbox ? " (sandbox)" : "")} Sending Apple VoIP Notification {JsonConvert.SerializeObject(notification.Payload)}");
                    if (registration.sandbox)
                        pushKitSandboxBroker.QueueNotification(notification);
                    //pushKitBroker.QueueNotification(notification);
                    else
                        pushKitBroker.QueueNotification(notification);
                    return await notificationTag.GetResultAsync();
                }

                if (registration.gcm != null)
                {
                    var notificationTag = new NotificationTag(registration.msisdn);
                    var notification = new GcmNotification();
                    notification.To = registration.gcm;
                    notification.Data = GcmPayload(payload);
                    notification.Tag = notificationTag;
                    Logger.Information($"Dest={registration.msisdn} Sending GCM Notification {JsonConvert.SerializeObject(notification.Data)}");
                    gcmBroker.QueueNotification(notification);
                    return await notificationTag.GetResultAsync();
                }

                if (registration.apns != null)
                {
                    var notificationTag = new NotificationTag(registration.msisdn);
                    var notification = new ApnsNotification();
                    notification.DeviceToken = registration.apns;
                    notification.Payload = ApnsPayload(payload);
                    notification.Tag = notificationTag;
                    if (payload.ExpiresImmediately)
                    {
                        notification.Expiration = ApnsNotification.DoNotStore;
                    }
                    Logger.Information($"Dest={registration.msisdn + (registration.sandbox ? " (sandbox)" : "")} Sending Apple Notification {JsonConvert.SerializeObject(notification.Payload)}");
                    if (registration.sandbox)
                        apnsSandboxBroker.QueueNotification(notification);
                    else
                        apnsBroker.QueueNotification(notification);

                    return await notificationTag.GetResultAsync();
                }

                Logger.Error($"Dest={registration.msisdn} no valid registration found");
                return false;
            }
            catch (Exception ex)
            {
                Logger.Error("SendNotification Failed:" + ex.ToString());
                return false;
            }
        }

        private static JObject ApnsPayload(PushPayload payload)
        {
            JObject apns = new JObject();

            apns["aps"] = new JObject();

            if (payload.MessageBody != null || payload.MessageTitle != null)
            {
                if (payload.MessageTitle != null)
                {
                    apns["aps"]["alert"] = new JObject();
                    apns["aps"]["alert"]["body"] = payload.MessageBody;
                    apns["aps"]["alert"]["title"] = payload.MessageTitle;
                }
                else
                {
                    apns["aps"]["alert"] = payload.MessageBody;
                }
            }

            if (payload.Data != null)
            {
                // note: silent pushes are rate limited by Apple
                // adding an empty "sound" parameter appears to work around this
                // http://stackoverflow.com/a/19427960
                apns["aps"]["content-available"] = 1;
                apns["aps"]["sound"] = "";

                apns["tha"] = payload.Data;
            }

            return apns;
        }
        private static JObject GcmPayload(PushPayload payload)
        {
            //
            // https://developers.google.com/cloud-messaging/concept-options#notifications_and_data_messages
            //
            JObject gcm = new JObject();

            if (payload.MessageBody != null || payload.MessageTitle != null)
                gcm["notification"] = new JObject();
            if (payload.MessageBody != null)
                gcm["notification"]["body"] = payload.MessageBody;
            if (payload.MessageTitle != null)
                gcm["notification"]["title"] = payload.MessageTitle;

            if (payload.Data != null)
            {
                gcm["data"] = new JObject();
                gcm["data"]["tha"] = payload.Data;
            }

            if (payload.ExpiresImmediately)
                gcm["time_to_live"] = 10;

            return gcm;
        }

        private static JObject PushKitPayload(PushPayload payload)
        {
            JObject apns = new JObject();

            if (payload.Data != null)
            {
                apns["tha"] = payload.Data;
            }

            return apns;
        }
        public async Task<GenericApiResponse<string>> GetFCMToken(string msisdn)
        {
            try
            {
                var result = await Db.GetFCMToken(msisdn);
                if (result.Status == Models.Enums.Status.Success)
                {
                    return GenericApiResponse<string>.Success(result.Data, "Token get successfully");
                }
                else
                {
                    return GenericApiResponse<string>.Failure(result.ErrorMessage, (result.ErrorCode == 1 ? ApiStatusCodes.TokenNotFound : ApiStatusCodes.CodeException));
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Push_BL, Method: GetFCMToken, Parameters: msisdn: {msisdn} ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }
        }

        public async Task<GenericApiResponse<APNSToken>> GetAPNSToken(string msisdn)
        {
            try
            {
                var result = await Db.GetAPNSToken(msisdn);
                if (result.Status == Models.Enums.Status.Success)
                {
                    return GenericApiResponse<APNSToken>.Success(result.Data, "Token get successfully");
                }
                else
                {
                    return GenericApiResponse<APNSToken>.Failure(result.ErrorMessage, (result.ErrorCode == 1 ? ApiStatusCodes.TokenNotFound : ApiStatusCodes.CodeException));
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Push_BL, Method: GetFCMToken, Parameters: msisdn: {msisdn} ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<APNSToken>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }
        }

        public async Task<GenericApiResponse<FcmPushPayload>> SendFCMPush(FCMPushRequest request)
        {

            try
            {
                string url = PushNotificationApiConfig.ApiEndPoint + "/push/SendFCMPush";
                string jsonRequest = JsonConvert.SerializeObject(request);
                HttpResponseMessage httpResponse = await ApiCall.PostAsync(url, jsonRequest);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Push_BL, Method: SendFCMPush, Parameters: {jsonRequest}, ErrorMessage: Null response received from Push Notification Api.");
                    return GenericApiResponse<FcmPushPayload>.Failure("Null response received from Push Notification Api.", ApiStatusCodes.CodeException);
                }
                else
                {
                    if (httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        FcmPushResponse apiResponseModel = JsonConvert.DeserializeObject<FcmPushResponse>(responseJson);
                        if (apiResponseModel.errorCode == 0) // Success
                        {
                            return GenericApiResponse<FcmPushPayload>.Success(apiResponseModel.payload, "Success");
                        }
                        else // Error
                        {
                            return GenericApiResponse<FcmPushPayload>.Failure(apiResponseModel.payload, apiResponseModel.message, ApiStatusCodes.UnSuccessful);
                        }
                    }
                    else if (httpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        return GenericApiResponse<FcmPushPayload>.Failure(responseJson, ApiStatusCodes.BadRequest);
                    }
                    else
                    {
                        return GenericApiResponse<FcmPushPayload>.Failure("Failure", ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Push_BL, Method: SendFCMPush, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<FcmPushPayload>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }

        public async Task<GenericApiResponse<ApnsPayload>> SendAPNSPush(APNSPushRequest request)
        {

            try
            {
                string url = PushNotificationApiConfig.ApiEndPoint + "/push/SendAPNSPush";
                string jsonRequest = JsonConvert.SerializeObject(request);
                HttpResponseMessage httpResponse = await ApiCall.PostAsync(url, jsonRequest);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Push_BL, Method: SendAPNSPush, Parameters: {jsonRequest}, ErrorMessage: Null response received from Push Notification Api.");
                    return GenericApiResponse<ApnsPayload>.Failure("Null response received from Push Notification Api.", ApiStatusCodes.CodeException);
                }
                else
                {
                    if (httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        APNSResponse apiResponseModel = JsonConvert.DeserializeObject<APNSResponse>(responseJson);
                        if (apiResponseModel.errorCode == 0) // Success
                        {
                            return GenericApiResponse<ApnsPayload>.Success(apiResponseModel.payload, "Success");
                        }
                        else // Error
                        {
                            return GenericApiResponse<ApnsPayload>.Failure(new ApnsPayload() { Reason = apiResponseModel.payload.Reason.ToString(CultureInfo.InvariantCulture)}, "Failure", (ApiStatusCodes)apiResponseModel.errorCode);
                        }
                    }
                    else if (httpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        return GenericApiResponse<ApnsPayload>.Failure(responseJson, ApiStatusCodes.BadRequest);
                    }
                    else
                    {
                        return GenericApiResponse<ApnsPayload>.Failure("Failure", ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Push_BL, Method: SendFCMPush, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApnsPayload>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }


    }
}
