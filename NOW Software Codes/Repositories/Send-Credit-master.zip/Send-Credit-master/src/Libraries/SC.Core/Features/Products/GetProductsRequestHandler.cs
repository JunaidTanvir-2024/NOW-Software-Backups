﻿


using MapsterMapper;
using RW.Models;
using SC.Core.Features.Products.Responses;
using SC.Core.Features.Users.Responses;
using SC.Core.Vendors.FusionHub;
using static SC.Core.Features.Products.Responses.GetProductResponseRapper;

namespace SC.Core.Features.Products;
internal sealed class GetProductsRequestHandler : IRequestHandler<GetProductsRequest, IResultWrapper>
{
    private readonly IFusionHubService _fusionHubService;
    private readonly IMapper _mapper;
    public GetProductsRequestHandler(IFusionHubService fusionHubService, IMapper mapper)
    {
        _fusionHubService = fusionHubService;
        _mapper = mapper;
    }

    public async Task<IResultWrapper> Handle(GetProductsRequest request, CancellationToken cancellationToken)
    {
        var response = await _fusionHubService.GetProductsAsync(request);
        if (response?.Payload == null)
        {
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
        }
        return ResultWrapper.Success(response?.Payload, new Pagination(response?.PaginationInfo.TotalCount, response?.PaginationInfo.PageCount, response?.PaginationInfo.CurrentPage, response?.PaginationInfo.PageSize));
    }
}

