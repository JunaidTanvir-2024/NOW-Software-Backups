﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ViewModels
{
    public class Secure3DModel
    {
        [Required]
        public string Id { get; set; }
        [Required]
        public string MD { get; set; }
        [Required]
        public string PaRes { get; set; }
    }
}
