﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Products.Requests
{
    public class GetProductSkusRequest
    {
        public string ProductNameOrId { get; set; }
    }
}
