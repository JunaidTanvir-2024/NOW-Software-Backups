﻿using Newtonsoft.Json;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using System;
using System.ComponentModel.DataAnnotations;

namespace PaymentsApi.Models.Contracts.Pay360.Request.Api
{

	public class ApiPaymentRequestNewCustomer
	{
		[JsonProperty("transaction")]
		public TransactionRequestModel Transaction { get; set; }

		[JsonProperty("customer")]
		public CustomerRequestModel Customer { get; set; }

		[JsonProperty("paymentMethod")]
		public PaymentMethodRequestModel PaymentMethod { get; set; }

		[JsonProperty("transactionOptions")]
		public TransactionOptionsModel TransactionOptions { get; set; }

		[JsonProperty("order")]
		public Order Order { get; set; }

		[JsonProperty("customFields")]
		public CustomFields CustomFields { get; set; }

		public bool ShouldSerializeCustomFields()
		{

			if (CustomFields == null)
			{
				return false;
			}
			else
			{
				return true;
			}
		}

	}
	public class ApiRequestRepeatTransactionOverride
	{
		[JsonProperty("transaction")]
		public RepeatTransactionRequestModel Transaction { get; set; }
		public class RepeatTransactionRequestModel
		{
			[JsonProperty("currency")]
			public string Currency { get; set; }
			[JsonProperty("amount")]
			public float Amount { get; set; }
			[JsonProperty("commerceType")]
			public string CommerceType { get; set; }
			[JsonProperty("deferred")]
			public bool Deferred { get; set; }
			[JsonProperty("recurring")]
			public bool Recurring { get; set; }
			[JsonProperty("merchantRef")]
			public string MerchantRef { get; set; }
			[JsonProperty("description")]
			public string Description { get; set; }
		}
	}
	public class ApiPaymentRequestNewCustomerWithFinancialServices
	{
		[JsonProperty("transaction")]
		public TransactionRequestModel Transaction { get; set; }

		[JsonProperty("customer")]
		public CustomerRequestModel Customer { get; set; }

		[JsonProperty("paymentMethod")]
		public PaymentMethodRequestModel PaymentMethod { get; set; }

		[JsonProperty("financialServices")]
		public UserFinancialServicesModel FinancialServices { get; set; }

		[JsonProperty("transactionOptions")]
		public TransactionOptionsModel TransactionOptions { get; set; }

		[JsonProperty("order")]
		public Order Order { get; set; }

		[JsonProperty("customFields")]
		public CustomFields CustomFields { get; set; }

		public bool ShouldSerializeCustomFields()
		{

			if (CustomFields == null)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}

	public class ApiPaymentRequestExistingCustomerDefaultCard
	{
		[JsonProperty("transaction")]
		public TransactionRequestModel Transaction { get; set; }

		[JsonProperty("customer")]
		public CustomerRequestModelExistingCustomer Customer { get; set; }

		[JsonProperty("paymentMethod")]
		public PaymentMethodRequestModelExistingCustomer PaymentMethod { get; set; }
		[JsonProperty("transactionOptions")]
		public TransactionOptionsModel TransactionOptions { get; set; }

		[JsonProperty("order")]
		public Order Order { get; set; }

		[JsonProperty("customFields")]
		public CustomFields CustomFields { get; set; }

		public bool ShouldSerializeCustomFields()
		{

			if (CustomFields == null)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}

	public class ApiPaymentRequestExistingCustomerDefaultCardWithFinancialServices
	{
		[JsonProperty("transaction")]
		public TransactionRequestModel Transaction { get; set; }

		[JsonProperty("customer")]
		public CustomerRequestModelExistingCustomer Customer { get; set; }

		[JsonProperty("paymentMethod")]
		public PaymentMethodRequestModelExistingCustomer PaymentMethod { get; set; }

		[JsonProperty("financialServices")]
		public UserFinancialServicesModel FinancialServices { get; set; }
		[JsonProperty("transactionOptions")]
		public TransactionOptionsModel TransactionOptions { get; set; }

		[JsonProperty("order")]
		public Order Order { get; set; }

		[JsonProperty("customFields")]
		public CustomFields CustomFields { get; set; }

		public bool ShouldSerializeCustomFields()
		{

			if (CustomFields == null)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}

	public class ApiPaymentRequestExistingCustomerNewCard
	{
		[JsonProperty("transaction")]
		public TransactionRequestModel Transaction { get; set; }

		[JsonProperty("customer")]
		public CustomerRequestModelExistingCustomer Customer { get; set; }

		[JsonProperty("paymentMethod")]
		public PaymentMethodRequestModel PaymentMethod { get; set; }
		[JsonProperty("transactionOptions")]
		public TransactionOptionsModel TransactionOptions { get; set; }

		[JsonProperty("order")]
		public Order Order { get; set; }

		[JsonProperty("customFields")]
		public CustomFields CustomFields { get; set; }

		public bool ShouldSerializeCustomFields()
		{

			if (CustomFields == null)
			{
				return false;
			}
			else
			{
				return true;
			}
		}

	}

	public class ApiPaymentRequestExistingCustomerNewCardWithFinancialServices
	{
		[JsonProperty("transaction")]
		public TransactionRequestModel Transaction { get; set; }

		[JsonProperty("customer")]
		public CustomerRequestModelExistingCustomer Customer { get; set; }

		[JsonProperty("paymentMethod")]
		public PaymentMethodRequestModel PaymentMethod { get; set; }

		[JsonProperty("financialServices")]
		public UserFinancialServicesModel FinancialServices { get; set; }
		[JsonProperty("transactionOptions")]
		public TransactionOptionsModel TransactionOptions { get; set; }

		[JsonProperty("order")]
		public Order Order { get; set; }

		[JsonProperty("customFields")]
		public CustomFields CustomFields { get; set; }

		public bool ShouldSerializeCustomFields()
		{

			if (CustomFields == null)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}

	public class ApiPaymentRequestCardToken
	{
		[JsonProperty("transaction")]
		public TransactionRequestModel Transaction { get; set; }

		[JsonProperty("customer")]
		public CustomerRequestModelExistingCustomer Customer { get; set; }

		[JsonProperty("paymentMethod")]
		public CardTokenPaymentMethodRequestModel PaymentMethod { get; set; }

		[JsonProperty("transactionOptions")]
		public TransactionOptionsModel TransactionOptions { get; set; }

		[JsonProperty("order")]
		public Order Order { get; set; }

		[JsonProperty("customFields")]
		public CustomFields CustomFields { get; set; }

		public bool ShouldSerializeCustomFields()
		{

			if (CustomFields == null)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}

	public class ApiPaymentRequestCardTokenWithFinancialServices
	{
		[JsonProperty("transaction")]
		public TransactionRequestModel Transaction { get; set; }

		[JsonProperty("customer")]
		public CustomerRequestModelExistingCustomer Customer { get; set; }

		[JsonProperty("paymentMethod")]
		public CardTokenPaymentMethodRequestModel PaymentMethod { get; set; }

		[JsonProperty("financialServices")]
		public UserFinancialServicesModel FinancialServices { get; set; }

		[JsonProperty("transactionOptions")]
		public TransactionOptionsModel TransactionOptions { get; set; }

		[JsonProperty("order")]
		public Order Order { get; set; }

		[JsonProperty("customFields")]
		public CustomFields CustomFields { get; set; }

		public bool ShouldSerializeCustomFields()
		{

			if (CustomFields == null)
			{
				return false;
			}
			else
			{
				return true;
			}
		}

	}


	//-----------------------------------------------------------------------------------------------

	public class Order
	{
		[JsonProperty("orderRef")]
		public string OrderRef { get; set; }

		[JsonProperty("shippingAddress")]
		public ShippingAddress ShippingAddress { get; set; }
	}

	public class CardRequestModel
	{

		[JsonProperty("cardHolderName")]
		public string CardHolderName { get; set; }

		[JsonProperty("pan")]
		public string Pan { get; set; }

		[JsonProperty("cv2")]
		public string CV2 { get; set; }

		[JsonProperty("expiryDate")]
		public string ExpiryDate { get; set; }

		[JsonProperty("defaultCard")]
		public bool DefaultCard { get; set; }

	}

	public class CardRequestModelExistingCustomer
	{
		[JsonProperty("cv2")]
		public string CV2 { get; set; }
	}

	public class CustomerBillingAddress
	{
		[JsonProperty("line1")]
		//[Required]
		public string Line1 { get; set; }

		[JsonProperty("line2")]
		public string Line2 { get; set; }

		[JsonProperty("line3")]
		public string Line3 { get; set; }

		[JsonProperty("line4")]
		public string Line4 { get; set; }

		[JsonProperty("city")]
		//[Required]
		public string City { get; set; }

		[JsonProperty("region")]
		//[Required]
		public string Region { get; set; }

		[JsonProperty("postcode")]
		//[Required]
		public string PostCode { get; set; }

		[JsonProperty("countryCode")]
		//[Required]
		public string CountryCode { get; set; }

	}

	public class CustomerRequestModel
	{
		[JsonProperty("merchantRef")]
		public string MerchantRef { get; set; }

		[JsonProperty("displayName")]
		public string DisplayName { get; set; }

		[JsonProperty("registered")]
		public string Registered { get; set; }

		[JsonProperty("email")]
		public string Email { get; set; }

		[JsonProperty("ip")]
		public string IpAddress { get; set; }

		[JsonProperty("telephone")]
		public string Telephone { get; set; }

		public bool ShouldSerializeTelephone()
		{
			// don't serialize the Telephone property if it is NULL or Empty
			if (string.IsNullOrWhiteSpace(Telephone))
			{
				return false;
			}
			else
			{
				return true;
			}
		}

		[JsonProperty("billingAddress")]
		public CustomerBillingAddress CustomerBillingAddress { get; set; }

	}
	public class CustomerRequestModelExistingCustomer
	{
		[JsonProperty("merchantRef")]
		public string MerchantRef { get; set; }

		[JsonProperty("ip")]
		public string IpAddress { get; set; }

		[JsonProperty("email")]
		public string Email { get; set; }

		public bool ShouldSerializeEmail()
		{
			// don't serialize the Telephone property if it is NULL or Empty
			if (string.IsNullOrWhiteSpace(Email))
			{
				return false;
			}
			else
			{
				return true;
			}
		}

		//[JsonProperty("update")]
		//public bool Update { get; set; }

		[JsonProperty("telephone")]
		public string Telephone { get; set; }

		public bool ShouldSerializeTelephone()
		{
			// don't serialize the Telephone property if it is NULL or Empty
			if (string.IsNullOrWhiteSpace(Telephone))
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}

	public class TransactionOptionsModel
	{
		[JsonProperty("do3DSecure")]
		public bool Do3DSecure { get; set; }

		[JsonProperty("sendEmailReceipt")]
		public bool SendEmailReceipt { get; set; }
	}



	public class PaymentMethodRequestModel
	{
		[JsonProperty("registered")]
		public bool Registered { get; set; }

		[JsonProperty("card")]
		public CardRequestModel Card { get; set; }

		[JsonProperty("billingAddress")]
		public CardBillingAddress CardBillingAddress { get; set; }

	}

	public class PaymentMethodRequestModelExistingCustomer
	{
		[JsonProperty("fromCustomer")]
		public CardRequestModelExistingCustomer FromCustomer { get; set; }
	}

	public class TransactionRequestModel
	{
		[JsonProperty("currency")]
		public string Currency { get; set; }
		[JsonProperty("amount")]
		public float Amount { get; set; }
		[JsonProperty("commerceType")]
		public string CommerceType { get; set; }
		[JsonProperty("deferred")]
		public bool Deferred { get; set; }
		[JsonProperty("recurring")]
		public bool Recurring { get; set; }
		[JsonProperty("merchantRef")]
		public string MerchantRef { get; set; }
		[JsonProperty("description")]
		public string Description { get; set; }
		[JsonProperty("continuousAuthorityAgreement")]
		public ContinuousAuthorityAgreement ContinuousAuthorityAgreement { get; set; }
	}

	public class ContinuousAuthorityAgreement
	{
		[JsonProperty("expiry")]
		public string Expiry { get; set; }
		[JsonProperty("minFrequency")]
		public int MinFrequency { get; set; }
	}
	public class PartialRefundModel
	{
		[JsonProperty("transaction")]
		public PartialRefundTransactionModel Transaction { get; set; }
	}

	public class FullRefundModel
	{
		[JsonProperty("transaction")]
		public FullRefundTransactionModel Transaction { get; set; }
	}

	public class FullRefundTransactionModel
	{
		[JsonProperty("merchantRef")]
		public string MerchantRef { get; set; }
	}

    public class PartialRefundTransactionModel
	{
		[JsonProperty("merchantRef")]
		public string MerchantRef { get; set; }
		[JsonProperty("amount")]
		public double Amount { get; set; }

		[JsonProperty("currency")]
		public string Currency { get; set; }
	}

	public class Resume3DSecureTransactionModel
	{

		[JsonProperty("threeDSecureResponse")]
		public ThreeDSecureResponseModel ThreeDSecureResponse { get; set; }
	}

	public class ThreeDSecureResponseModel
	{
		[JsonProperty("pares")]
		public string Pares { get; set; }
	}

	public class CardTokenPaymentMethodRequestModel
	{
		[JsonProperty("cardToken")]
		public CardTokenRequestModel CardToken { get; set; }
	}

	public class CardTokenRequestModel
	{
		[JsonProperty("token")]
		public string Token { get; set; }

		[JsonProperty("cv2")]
		public string Cv2 { get; set; }
	}

	public class CardBillingAddress
	{
		[JsonProperty("line1")]
		[Required]
		public string Line1 { get; set; }

		[JsonProperty("line2")]
		public string Line2 { get; set; }

		[JsonProperty("line3")]
		public string Line3 { get; set; }

		[JsonProperty("line4")]
		public string Line4 { get; set; }

		[JsonProperty("city")]
		[Required]
		public string City { get; set; }

		[JsonProperty("region")]
		[Required]
		public string Region { get; set; }

		[JsonProperty("postcode")]
		[Required]
		public string PostCode { get; set; }

		[JsonProperty("countryCode")]
		[Required]
		public string CountryCode { get; set; }

	}

}