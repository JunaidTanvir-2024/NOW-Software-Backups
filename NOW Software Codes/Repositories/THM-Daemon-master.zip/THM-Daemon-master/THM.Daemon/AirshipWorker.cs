﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using THM.Infrastructure.BLL;

namespace THM.Daemon
{
    public class AirshipWorker : BackgroundService
    {
        private readonly ILogger<AirshipWorker> _logger;
        private readonly IAirship_BL _airship_BL;
        private readonly Serilog.ILogger _serilogLogger;

        public AirshipWorker(
            ILogger<AirshipWorker> logger, 
            IAirship_BL airship_BL, 
            Serilog.ILogger serilogLogger)
        {
            _logger = logger;
            _airship_BL = airship_BL;
            _serilogLogger = serilogLogger;
        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            //await Task.Delay(TimeSpan.FromSeconds(CalculateDelaySeconds()), stoppingToken);

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await _airship_BL.AddAirShipEventsAndTags();
                }
                catch (Exception ex)
                {
                    _logger.LogError("AirshipWorker,  " +
                                     "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                     "StackTrace: " + ex.StackTrace);

                    _serilogLogger.Error("AirshipWorker,  " +
                                    "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                    "StackTrace: " + ex.StackTrace);
                }
                await Task.Delay(TimeSpan.FromMinutes(10), stoppingToken);
                //await Task.Delay(TimeSpan.FromSeconds(CalculateDelaySeconds()), stoppingToken);
            }
        }
        private static double CalculateDelaySeconds()
        {
            var timeToStartService = DateTime.Today.AddHours(3);
            var currentDateTime = DateTime.UtcNow;

            if (currentDateTime > timeToStartService)
            {
                timeToStartService = timeToStartService.AddDays(1);
            }

            var totalSeconds = timeToStartService.Subtract(currentDateTime).TotalSeconds;

            TimeSpan t = TimeSpan.FromSeconds(totalSeconds);

            string answer = string.Format("{0:D2}h:{1:D2}m:{2:D2}s:{3:D3}ms",
                            t.Hours,
                            t.Minutes,
                            t.Seconds,
                            t.Milliseconds);

            Console.WriteLine("Service will After : " + answer);

            return totalSeconds;
        }
    }
}