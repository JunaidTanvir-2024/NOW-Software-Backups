using System.Data;
using System.Data.SqlClient;

using Dapper;

using Microsoft.Extensions.Configuration;

using Voucherify.Core.Domain.Definitions;

namespace Voucherify.Core.Services.Loggers;

public interface ILoggerRepository
{
    void UpsertAppLogEntry(AppLogEntry logEntry);
    void InsertVoucherifyLogEntry(VoucherifyLogEntry logEntry);
}

internal class LoggerRepository : ILoggerRepository
{
    private const string UpsertAppLog_SP = "UpsertAppLogEntryV2";
    private const string InsertVoucherifyLog_SP = "InsertVoucherifyLogEntry";
    private readonly IConfiguration _configuration;

    public LoggerRepository(IConfiguration configuration)
    {
        _configuration = configuration;
    }
    public void UpsertAppLogEntry(AppLogEntry logEntry)
    {
        using (SqlConnection? connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.ConnectionStrings.DefaultConnection)))
        {
            connection.Open();
            var parameters = new DynamicParameters();
            parameters.Add("@Timestamp", logEntry.Timestamp);
            parameters.Add("@RequestPath", logEntry.RequestPath);
            parameters.Add("@RequestMethod", logEntry.RequestMethod);
            parameters.Add("@RequestBody", logEntry.RequestBody);
            parameters.Add("@ResponseBody", logEntry.ResponseBody);
            parameters.Add("@StatusCode", logEntry.StatusCode);
            parameters.Add("@Duration", logEntry.Duration);
            parameters.Add("@ClientIP", logEntry.ClientIP);
            parameters.Add("@UserAgent", logEntry.UserAgent);
            parameters.Add("@ResponseSize", logEntry.ResponseSize);
            parameters.Add("@ErrorMessage", logEntry.ErrorMessage);
            parameters.Add("@CorrelationId", logEntry.CorrelationId);
            parameters.Add("@Headers", logEntry.Headers);
            parameters.Add("@QueryString", logEntry.QueryString);
            parameters.Add("@UniqueReference", logEntry.UniqueReference);
            parameters.Add("@ProductCode", logEntry.ProductCode);
            parameters.Add("@ProductItemCode", logEntry.ProductItemCode);

            connection.Execute(UpsertAppLog_SP, parameters, commandType: CommandType.StoredProcedure);
            connection.Close();
        }
    }
    public void InsertVoucherifyLogEntry(VoucherifyLogEntry logEntry)
    {
        using (SqlConnection? connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.ConnectionStrings.DefaultConnection)))
        {
            connection.Open();
            var parameters = new DynamicParameters();
            parameters.Add("@Timestamp", logEntry.Timestamp);
            parameters.Add("@RequestPath", logEntry.RequestPath);
            parameters.Add("@RequestMethod", logEntry.RequestMethod);
            parameters.Add("@RequestBody", logEntry.RequestBody);
            parameters.Add("@ResponseBody", logEntry.ResponseBody);
            parameters.Add("@StatusCode", logEntry.StatusCode);
            parameters.Add("@Duration", logEntry.Duration);
            parameters.Add("@ClientIP", logEntry.ClientIP);
            parameters.Add("@UserAgent", logEntry.UserAgent);
            parameters.Add("@ResponseSize", logEntry.ResponseSize);
            parameters.Add("@ErrorMessage", logEntry.ErrorMessage);
            parameters.Add("@CorrelationId", logEntry.CorrelationId);
            parameters.Add("@Headers", logEntry.Headers);
            parameters.Add("@QueryString", logEntry.QueryString);

            connection.Execute(InsertVoucherifyLog_SP, parameters, commandType: CommandType.StoredProcedure);
            connection.Close();
        }
    }
}
