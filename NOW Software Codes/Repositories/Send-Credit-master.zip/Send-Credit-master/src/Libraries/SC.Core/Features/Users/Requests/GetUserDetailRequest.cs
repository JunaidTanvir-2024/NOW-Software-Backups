﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Users.Requests;
public sealed class GetUserDetailRequest : IRequest<IResultWrapper>
{
    public string UserID { get; set; } = default!;
}
public class GetUserDetailRequestValidator : AbstractValidator<GetUserDetailRequest>
{
    public GetUserDetailRequestValidator()
    {

    }
}

