﻿using System;

namespace Models.Database
{
    public class OfferBundleDetails
    {
        public Guid BundleGuid { get; set; }
        public bool IsOffer { get; set; }
        public int DiscountPercentage { get; set; }
    }
}
