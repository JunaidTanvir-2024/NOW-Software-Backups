﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBInternationalRates
    {
        public int Id { get; set; }
        public float LandlineRate { get; set; }
        public float SmsRate { get; set; }
        public int CountryId { get; set; }
        public float LandlineRateOffpeak { get; set; }
        public float MobileRateOffpeak { get; set; }
        public float SmsRateOffpeak { get; set; }
        public float MobileRate { get; set; }
        public int TopRateIndex { get; set; }
        public float TopRates { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int CreatedBy { get; set; }
        public int LastUpdatedBy { get; set; }
        public string CreatedByUsername { get; set; }
        public string LastUpdatedbyUsername { get; set; }
        public bool IsActive { get; set; }

        //CountryInfo
        public string Name { get; set; }
        public string PhoneCode { get; set; }
        public string IsoTwoCharacterCode { get; set; }
        public bool IsNational { get; set; }
    }
}
