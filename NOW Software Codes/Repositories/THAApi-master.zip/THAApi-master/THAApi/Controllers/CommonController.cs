﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using THAApi.Utilities;

namespace THAApi.Controllers
{
    [ApiController]
    public class CommonController : Controller
    {
        private readonly ICommon_BL CommonBL;
        public CommonController(ICommon_BL commonBL)
        {
            CommonBL = commonBL;
        }

        [HttpGet]
        [Route("appconfig")]
        public async Task<IActionResult> GetAppConfig(bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null)
        {
            var msisdn = User.Msisdn();
            var result = await CommonBL.GetAppConfig(msisdn, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);
            return Ok(result);
        }

        [HttpPost]
        [Route("IOS/Startup")]
        public async Task<IActionResult> GetIOSCarousel(CRIOSVersion version)
        {
            var msisdn = User.Msisdn();
            var result = await CommonBL.GetIosCarousel(msisdn, version.version, version.itVersion);
            return Ok(result);
        }

        [HttpPost]
        [Route("startup")]
        public async Task<IActionResult> GetAndroidCarousel(CRVersion version)
        {
            var msisdn = User.Msisdn();
            var result = await CommonBL.GetAndroidCarousel(msisdn, version.version);
            return Ok(result);
        }
        [HttpGet]
        [ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        [Route("homeBtnClicked")]
        [Route("bundlesBtnClicked")]
        [Route("internationalTopupBtnClicked")]
        [Route("inAppTransferButtonClicked")]
        [Route("contactBtnClicked")]
        [Route("tryAgainBtnClicked")]
        [Route("makeACallBtnClicked")]
        public IActionResult Empty()
        {
            return Ok("");
        }
    }
}
