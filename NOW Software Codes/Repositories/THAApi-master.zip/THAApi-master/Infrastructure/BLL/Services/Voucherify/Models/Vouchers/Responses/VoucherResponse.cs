﻿using Models.Common;
using System;
using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Vouchers.Responses
{
    public class VoucherResponse
    {
        [JsonPropertyName("code")]
        public string Code { get; set; }
        [JsonPropertyName("voucherType")]
        public string VoucherType { get; set; }
        [JsonPropertyName("campaign")]
        public string Campaign { get; set; }
        [JsonPropertyName("campaignId")]
        public string CampaignId { get; set; }
        [JsonPropertyName("category")]
        public string Category { get; set; }
        [JsonPropertyName("startDate")]
        public DateTime StartDate { get; set; }
        [JsonPropertyName("expirationDate")]
        public DateTime ExpirationDate { get; set; }
        [JsonPropertyName("active")]
        public bool Active { get; set; }
        [JsonPropertyName("metadata")]
        public Metadata Metadata { get; set; }
        [JsonPropertyName("isReferralCode")]
        public bool IsReferralCode { get; set; }
    }
}
