﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Request
{
    public class UpdateMailSubscriptionRequestModel
    {
        public int UserID { get; set; }
        public bool MailSubscription { get; set; }
    }
}
