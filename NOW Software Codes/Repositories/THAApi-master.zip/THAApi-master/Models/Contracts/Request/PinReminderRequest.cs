﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    
    public class PinReminderRequest
    {
        public string Msisdn { get; set; }

        public AppInfo AppInfo { get; set; }
    }
}
