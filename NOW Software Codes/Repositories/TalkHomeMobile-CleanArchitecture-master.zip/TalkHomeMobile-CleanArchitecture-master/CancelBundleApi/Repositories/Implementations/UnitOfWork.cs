using CancelBundleApi.Repositories.Interfaces;
using CancelBundleApi.Settings.Database;
using Microsoft.Extensions.Options;

namespace CancelBundleApi.Repositories.Implementations;

internal sealed class UnitOfWork : IUnitOfWork
{
    public UnitOfWork(

        IOptions<DatabaseSettings> databaseSettings)
    {
        UserRepo = new UserRepository(databaseSettings);

    }

    public IUserRepository UserRepo { get; }

}