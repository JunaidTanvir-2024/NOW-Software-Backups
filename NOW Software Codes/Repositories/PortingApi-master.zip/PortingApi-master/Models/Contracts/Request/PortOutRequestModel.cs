﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class PortOutRequestModel
    {
        [Required]
        public string Email { get; set; }
        [Required]
        public string NTMsisdn { get; set; }
        [Required]
        public int ReasonId { get; set; }
        [Required]
        public DateTime? UserPortingDate { get; set; }
        [Required]
        public Products Product { get; set; }
        [Required]
        public MediumTypes Medium { get; set; }
    }
}
