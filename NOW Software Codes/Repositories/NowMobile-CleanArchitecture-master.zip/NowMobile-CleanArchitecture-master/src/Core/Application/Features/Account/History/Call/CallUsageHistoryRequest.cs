using Application.Features.Account.History.Models;

namespace Application.Features.Account.History.Call;

public sealed class CallUsageHistoryRequest : IRequest<Result<CallHistoryResponse>>
{
    public string Msisdn { get; set; } = default!;

    [JsonIgnore]
    public DateTime StartDate { get; set; } = DateTime.UtcNow.AddDays(-7);

    [JsonIgnore]
    public DateTime EndDate { get; set; } = DateTime.UtcNow;

    [JsonIgnore]
    public int PageNo { get; set; } = 1;

    [JsonIgnore]
    public int PageSize { get; set; } = 20;
}