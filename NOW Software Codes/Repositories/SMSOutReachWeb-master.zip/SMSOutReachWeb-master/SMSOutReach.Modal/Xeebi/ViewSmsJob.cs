﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSOutReach.Modal.Xeebi
{
    public class ViewSmsJob
    {

        public int Id { get; set; }
        public string Campaign { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Message { get; set; }
        public DateTime StartDate { get; set; }
        public string Product { get; set; }
        public string Status { get; set; }
        public string Carrier { get; set; }
        public string User { get; set; }
        public string JobPriority { get; set; }
        public string JobIndex { get; set; }
        public int SmsCount { get; set; }
        public int SmsProcessed { get; set; }
        public int StatusId { get; set; }

    }
}
