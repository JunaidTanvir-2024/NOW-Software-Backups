﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Request.AndroidInAppPayment;
using Models.Contracts.Request.User_Account;
using Models.Contracts.Response;
using Models.Database;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using THAApi.Utilities;

namespace THAApi.Controllers
{
    [ApiController]
    public class UserAccountController : Controller
    {
        private readonly ILogger Logger;
        private readonly IUserAccount_BL UserAccountBL;
        private readonly IBundle_BL Bundle_BL;
        private readonly preAuthConfig _preAuthConfig;
        private readonly IHistory_BL History_BL;

        public UserAccountController(
            ILogger logger,
            IUserAccount_BL userAccountBL,
            IHistory_BL historyDL,
            IBundle_BL bundle_BL,
            IOptions<preAuthConfig> preAuthConfig)
        {
            Logger = logger;
            UserAccountBL = userAccountBL;
            History_BL = historyDL;
            Bundle_BL = bundle_BL;
            this._preAuthConfig = preAuthConfig.Value;
        }

        [HttpPost]
        [Route("useraccount/verifyEmail")]
        public async Task<IActionResult> VerifyEmail([FromBody] VerifyEmailRequest request)
        {
            var response = await UserAccountBL.SendEmailVerificationLink(request, User.Msisdn());
            return Ok(response);
        }

        [HttpGet]
        [Route("useraccount/getEntirePaymentHistory")]
        public async Task<IActionResult> GetEntirePaymentHistory()
        {
            return Ok(await History_BL.GetEntirePaymentHistory(User.Msisdn(), User.Account()));
        }

        [HttpGet]
        [Route("useraccount/subscriptions")]
        public async Task<IActionResult> GetAccountSubscription()
        {
            var result = await Bundle_BL.GetAccountSubscriptionsViaSQL(User.Msisdn(), User.Email());
            if (result != null)
            {
                return Ok(GenericApiResponse<AccountSubscriptionDetails>.Success(result, "Success"));
            }

            return Ok(GenericApiResponse<AccountSubscriptionDetails>.Failure("Failure", ApiStatusCodes.InternalServerError));
        }
        [HttpGet]
        [Route("useraccount/bundles")]
        public async Task<IActionResult> GetAccountBundles()
        {
            try
            {
                var msisdn = User.Msisdn();
                var currency = User.Currency();
                var account = User.Account();
                var result = await Bundle_BL.GetAccountBundlesViaSQL(msisdn, currency, account);
                if (result != null)
                {
                    return Ok(GenericApiResponse<List<AccountBundleDetails>>.Success(result.ToList(), "Success"));
                }

                return Ok(GenericApiResponse<List<AccountBundleDetails>>.Failure("Failure", ApiStatusCodes.InternalServerError));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: BundleController, Method: GetAccountBundles, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<List<AccountBundleDetails>>.Failure("Failure", ApiStatusCodes.InternalServerError));
            }
        }
        [HttpGet]
        [Route("useraccount/getNotifications")]
        public async Task<IActionResult> GetUserNotifications()
        {

            string msisdn = "";
            try
            {
                msisdn = User.Msisdn();
                var response = await UserAccountBL.GetUserNotifications(msisdn);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccountController, Method: GetUserNotifications, Parameters: msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<UserNotifications>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("useraccount/updateNotifications")]
        public async Task<IActionResult> UpdateUserNotifications([FromBody] UserNotifications request)
        {

            string msisdn = "";
            try
            {
                msisdn = User.Msisdn();
                var response = await UserAccountBL.UpdateUserNotifications(request, msisdn);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccountController, Method: UpdateUserNotifications, Parameters: {JsonConvert.SerializeObject(request)}, msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<UpdateUserProfileResponse>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("useraccount/updateProfile")]
        public async Task<IActionResult> UpdateUserProfile([FromForm] UpdateUserProfileRequest request)
        {
            var response = await UserAccountBL.UpdateUserProfile(request, User.Msisdn());
            return Ok(response);
        }

        [HttpGet]
        [Route("useraccount/getProfile")]
        public async Task<IActionResult> GetUserProfile()
        {

            string msisdn = "";
            try
            {
                //string loc = Localizer["Internal_Server_Error"];
                List<Claim> userClaims = this.User.Claims.ToList();
                msisdn = userClaims.Find(c => c.Type == "msisdn").Value;
                var response = await UserAccountBL.GetUserProfile(msisdn);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccountController, Method: GetUserProfile, Parameters: msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<Profile>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("useraccount/login")]
        public async Task<IActionResult> Login(LoginRequest loginRequest)
        {
            try
            {
                var remoteIp = string.Empty;
                var webAppRequestPrivateKey = HttpContext.Request.Headers["PrivateAccessKey"];
                if (webAppRequestPrivateKey.Equals(_preAuthConfig.PrivateAccessKey))
                {
                    //trusted consumer, use ip sent by consumer
                    remoteIp = HttpContext.Request.Headers["PrivateAccessIpAddress"];
                }
                else
                {
                    //not trusted user, use ip address from request
                    remoteIp = HttpContext.GetRemoteIPAddress();

                }
                bool IsIOS = loginRequest.IsIOS;
                bool IsAndroid = loginRequest.IsAndroid;
                var IOSAllowedVersion = loginRequest.IOSAllowedVersion;
                var AndroidAllowedVersion = loginRequest.AndroidAllowedVersion;
                List<Claim> userClaims = this.User.Claims.ToList();
                var msisdn = User.Msisdn();
                var result = await UserAccountBL.Login(msisdn, loginRequest?.AppInfo, remoteIp, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);

                if (result != null)
                {
                    return Ok(result);
                }

                return StatusCode(500);
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccountController, Method: Login, Parameters=> requestJson: {JsonConvert.SerializeObject(loginRequest)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return StatusCode(500);
            }

        }

        [HttpGet]
        [Route("useraccount/referrals")]
        public async Task<IActionResult> GetReferrals()
        {

            try
            {
                var msisdn = User.Msisdn();
                var response = await UserAccountBL.GetReferrals(msisdn);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserAccountController, Method: GetReferrals, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<Referrals>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }
        }

        [HttpGet]
        [Route("useraccount/balance")]
        public async Task<IActionResult> Balance()
        {
            try
            {
                var msisdn = User.Msisdn();
                var response = await UserAccountBL.GetUserAccountBalance(msisdn);

                if (response != null)
                {
                    return Ok(GenericApiResponse<UserAccountBalance>.Success(response, "Success"));
                }

                return Ok(GenericApiResponse<UserAccountBalance>.Failure("Failure", ApiStatusCodes.InternalServerError));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserAccountController, Method: Balance, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<UserAccountBalance>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }
        }

        [HttpPost]
        [Route("SaveCallQuality")]
        public async Task<IActionResult> SaveCallQuality(CallQualityRequest request)
        {

            try
            {
                var msisdn = User.Msisdn();

                var response = await UserAccountBL.SaveCallQuality(request, msisdn);

                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccountController, Method: SaveCallQuality, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("SaveClientCallLogs")]
        public async Task<IActionResult> SaveClientCallLogs(SaveClientCallRequest request)
        {

            try
            {
                List<Claim> userClaims = this.User.Claims.ToList();
                var msisdn = userClaims.Find(c => c.Type == "msisdn").Value;

                var response = await UserAccountBL.SaveClientCallLogs(request, msisdn);

                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                //Logger.Error($"Class: UserAccountController, Method: SaveClientCallLogs, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpGet]
        [Route("getAndriodPaymentOptions")]
        public async Task<IActionResult> GetAndriodPaymentOptions()
        {

            try
            {
                var currency = User.Currency();

                var response = await UserAccountBL.getAndriodPaymentOptions(currency);

                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccountController, Method: getAndriodPaymentOptions ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("andrionPaymentVerification")]
        public async Task<IActionResult> AndrionPaymentVerification(AndroidPaymentVerificationRequest request)
        {

            try
            {
                var msisdn = User.Msisdn();

                var response = await UserAccountBL.AndrionPaymentVerification(request, msisdn);

                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: UserAccountController, Method: AndrionPaymentVerification Parameters:{JsonConvert.SerializeObject(request)} ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpGet]
        [Route("useraccount/referralcode")]
        public async Task<IActionResult> GetReferral(string name)
        {
            var msisdn = User.Msisdn();
            var response = await UserAccountBL.CreateReferralCode(msisdn, HttpUtility.UrlDecode(name));

            return Ok(response);
        }

        [HttpPost]
        [Route("useraccount/referralcode")]
        public async Task<IActionResult> SetReferral(ReferralCode referralCode)
        {
            var msisdn = User.Msisdn();
            var response = await UserAccountBL.UpdateReferralCode(msisdn, referralCode);

            return Ok(response);
        }

        [HttpGet]
        [Route("useraccount/promotions")]
        public async Task<IActionResult> GetPromotions()
        {
            try
            {
                var msisdn = User.Msisdn();
                var response = await UserAccountBL.GetPromotions(msisdn);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserAccountController, Method: GetPromotions, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<RSS>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }
        }

        [HttpPost]
        [Route("useraccount/promotions")]
        public async Task<IActionResult> SetPromotions(Promotion promotion)
        {

            try
            {
                var msisdn = User.Msisdn();
                var response = await UserAccountBL.SetPromotions(msisdn, promotion);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserAccountController, Method: SetPromotions, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<bool>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }
        }

        [HttpPost]
        [Route("useraccount/FCMToken")]
        public async Task<IActionResult> SetFCMToken(FCMToKenReq fcmToken)
        {

            try
            {
                var msisdn = User.Msisdn();
                var response = await UserAccountBL.SetFCMToken(fcmToken, msisdn);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserAccountController, Method: SetFCMToken, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<bool>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }
        }

        [HttpGet]
        [Route("feedback/active")]
        public async Task<IActionResult> FeedbackIsActive()
        {

            try
            {
                var msisdn = User.Msisdn();
                var result = await UserAccountBL.FeedbackIsActive(msisdn);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserAccountController, Method: FeedbackIsActive, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<bool>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }
        }

        [HttpGet]
        [Route("useraccount/email")]
        public async Task<IActionResult> GetEmail()
        {

            try
            {
                var msisdn = User.Msisdn();
                var response = await UserAccountBL.getEmail(msisdn);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserAccountController, Method: GetEmail, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<bool>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }
        }

        [HttpPost]
        [Route("useraccount/email")]
        public async Task<IActionResult> SetEmail(Email email)
        {

            try
            {
                var msisdn = User.Msisdn();
                var response = await UserAccountBL.SetEmail(msisdn, email);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserAccountController, Method: SetEmail, email: {email}, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<bool>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }
        }

        [HttpPost]
        [Route("call/localaccess")]
        public async Task<IActionResult> SetWebCallThrough(WebCallThrough request)
        {

            try
            {
                var msisdn = User.Msisdn();

                if (request == null || string.IsNullOrEmpty(request.destination) || string.IsNullOrEmpty(request.via))
                {
                    return BadRequest("Invalid Data");
                }

                var webresponse = await UserAccountBL.ExecuteWebCallthrough(msisdn, request.destination, request.IsIOS, request.IsAndroid, request.IOSAllowedVersion, request.AndroidAllowedVersion);

                if (webresponse != null)
                {
                    return Ok(webresponse);
                }

                return StatusCode(500, GenericApiResponse<bool>.Failure("Failure", ApiStatusCodes.InternalServerError));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserAccountController, Method: SetWebCallThrough, RequestJson: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<bool>.Failure(ex.Message, ApiStatusCodes.InternalServerError));
            }

        }
        [HttpPost]
        [Route("useraccount/deleteaccount")]
        public async Task<IActionResult> DeleteAccount()
        {
            return Ok(await UserAccountBL.DeleteAccountAsync(User.Account(), User.Msisdn()));
        }
        [HttpGet]
        [Route("useraccount/GetAutoTopup")]
        public async Task<IActionResult> GetAutoTopup()
        {
            return Ok(await UserAccountBL.GetAutoTopupDetails(User.Msisdn()));
        }          
    }
}