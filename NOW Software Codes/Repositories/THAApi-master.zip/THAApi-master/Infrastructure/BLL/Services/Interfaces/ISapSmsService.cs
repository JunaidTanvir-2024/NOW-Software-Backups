﻿using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface ISapSmsService
    {
        Task<SmsResult> Send(string from, string to, string message, bool paid, bool isSignupPinSms = false, string language = "en");
    }
}
