﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using TalkhomeWebApp.Models;
using TalkhomeWebApp.Models.AirShip;
using TalkhomeWebApp.Models.ApiContracts.Request;
using TalkhomeWebApp.Models.ApiContracts.Response;
using TalkhomeWebApp.Models.Configurations;
using TalkhomeWebApp.Models.Facebook.CustomEvents;
using TalkhomeWebApp.Models.ViewModels;
using TalkhomeWebApp.Services;
using TalkhomeWebApp.Utilities;
using TalkhomeWebApp.Utilities.Extension;

namespace TalkhomeWebApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly ILogger _logger;
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly IAppsFlyerService _appsFlyerService;
        private readonly IAirshipService _airshipService;
        private readonly IHelperService _helperService;
        private readonly ApiClient _apiClient;
        private readonly IFacebookService _facebookService;
        private readonly IDataProtector _dataProtector;
        private readonly BasicAuthConfig _basicAuthConfig;
        //private readonly CaptchaConfig _captchaConfig;
        private readonly EndPoints _Endpoints;
        private readonly GoogleRecaptchaSettings _googleRecaptchaSettings;

        public AccountController(ILogger logger,
            IOptions<EndPoints> Endpoints,
            IWebHostEnvironment hostEnvironment,
            IOptions<BasicAuthConfig> basicAuthConfig,
            //IOptions<CaptchaConfig> captchaConfig,
            IOptions<GoogleRecaptchaSettings> googleRecaptchaSettings,
            IDataProtectionProvider provider,
            IFacebookService facebookService,
            IAppsFlyerService appsFlyerService,
            IAirshipService airshipService, IHelperService helperService,
            ApiClient apiClient)
        {
            _logger = logger;
            _appsFlyerService = appsFlyerService;
            _hostEnvironment = hostEnvironment;
            _airshipService = airshipService;
            this._helperService = helperService;
            this._apiClient = apiClient;
            _facebookService = facebookService;
            _dataProtector = provider.CreateProtector("THA-WEB-101");
            _basicAuthConfig = basicAuthConfig.Value;
            //_captchaConfig = captchaConfig.Value;
            _Endpoints = Endpoints.Value;
            _googleRecaptchaSettings = googleRecaptchaSettings.Value;
        }

        [HttpGet]
        [Route("login")]
        public IActionResult LogIn(string returnUrl)
        {
            try
            {
                var viewModel = new LogInViewModel();

                if (HttpContext.User.Identity.IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                else if (!string.IsNullOrEmpty(returnUrl))
                {
                    if (Url.IsLocalUrl(returnUrl))
                    {
                        viewModel.ReturnUrl = returnUrl;
                    }
                    else
                    {
                        viewModel.ReturnUrl = Url.Action("Index", "Home");
                    }
                }

                return View(viewModel);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: LogIn, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [HttpPost]
        [Route("login")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LogIn(LogInViewModel model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); }
                //validate recaptcha v3
                if (_googleRecaptchaSettings.IsActive)
                {
                    if (!string.IsNullOrEmpty(model.Token))
                    {
                        var verified = await VerifyCaptchaToken(model.Token!);
                        if (!verified)
                        {
                            return Json(new { errorCode = 10026, message = "Un-behavioral pattern detected. Please try again later" });
                        }
                    }
                    else
                    {
                        return Json(new { errorCode = 10026, message = "Invalid or no token detected. Please try again later" });
                    }
                }
                string token = Convert.ToBase64String(System.Text.Encoding.
                    GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":"
                    + _basicAuthConfig.Password));

                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/Login", User,
                    ApiCallType.BasicAuth, model: new SignInRequestModel
                    {
                        PhoneNumber = model.PhoneNumber,
                        PhoneNumberCountryCode = model.PhoneNumberCountryCode,
                        IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext)
                    }, basicauthtoken: token);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    string _message = responseJson.GetValue("message").ToObject<string>();
                    if (errorCode == 0)
                    {
                        string encryptedId = _dataProtector.Protect(
                            model.PhoneNumber +
                            "," + model.PhoneNumberCountryCode +
                            "," + model.RememberMe.ToString() +
                            "," + DateTime.Now.ToString() +
                            "," + model.ReturnUrl);


                        string msisdn = model.PhoneNumber;
                        #region Facebook Events
                        if (_facebookService.IsActive)
                        {
                            await _facebookService.CreateCustomEvent(msisdn, new EventDetailsModel
                            {
                                _eventName = "login_web"
                            });

                        }
                        #endregion
                        await _appsFlyerService.CreateEvent(msisdn, "login_web", CommonExtentionMethods.GetRemoteIPAddress(HttpContext));


                        return Json(new { errorCode = 0, data = HttpUtility.UrlEncode(encryptedId) });

                    }
                    else
                    {
                        if (errorCode == (int)ApiStatusCodes.InvalidNumber)
                        {
                            return Json(new { errorCode, message = "Phone Number is invalid" });
                        }
                        else if (errorCode == (int)ApiStatusCodes.UserNotRegistered)
                        {
                            return Json(new { errorCode, message = "Your Phone Number is not registered" });
                        }
                        else if (errorCode == (int)ApiStatusCodes.UserNotAuthorized)
                        {
                            return Json(new { errorCode, message = "User not authorized" });
                        }
                    }

                    return Json(new { errorCode, message = _message });
                }
                else if (response.StatusCode == HttpStatusCode.Forbidden)
                {
                    return Json(new { message = "Sorry, something’s not right. Please try again in a few minutes" });
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SignIn, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("verify-code")]
        public IActionResult VerifyCode(string data)
        {
            try
            {
                if (HttpContext.User.Identity.IsAuthenticated)
                    return RedirectToAction("Index", "Home");

                if (string.IsNullOrEmpty(data))
                    if (!ModelState.IsValid) { return BadRequest(); }

                string decryptedData;

                try
                {
                    data = HttpUtility.UrlDecode(data);

                    decryptedData = _dataProtector.Unprotect(data);
                }
                catch
                {
                    return BadRequest();
                }

                if (string.IsNullOrEmpty(decryptedData))
                    return BadRequest();

                var phoneData = decryptedData.Split(",");

                var viewModel = new VerifyCodeViewModel();

                //if (phoneData.Length == 4) //login
                //{
                //    if (Convert.ToDateTime(phoneData[3]).AddMinutes(1) < DateTime.Now)
                //    {
                //        return RedirectToAction("SignUp", "Account");
                //    }

                //    viewModel = new VerifyCodeViewModel()
                //    {
                //        PhoneNumber = phoneData[0],
                //        PhoneNumberCountryCode = phoneData[1],
                //        RememberMe = phoneData[2] == "True" ? true : false,
                //        ReturnUrl = string.Empty
                //    };
                //}
                //else //signup
                //{

                if (Convert.ToDateTime(phoneData[3]).AddMinutes(1) < DateTime.Now)
                {
                    return RedirectToAction("Index", "Home");
                }

                viewModel = new VerifyCodeViewModel()
                {
                    PhoneNumber = phoneData[0],
                    PhoneNumberCountryCode = phoneData[1],
                    RememberMe = phoneData[2] == "True" ? true : false,
                    ReturnUrl = phoneData[4]
                };

                //}

                return View(viewModel);

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyCode, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                throw ex;
            }
        }

        [HttpPost]
        [Route("verify-code")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> VerifyCode(VerifyCodeViewModel model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); }
                //validate recaptcha v3
                if (_googleRecaptchaSettings.IsActive)
                {
                    if (!string.IsNullOrEmpty(model.Token))
                    {
                        var verified = await VerifyCaptchaToken(model.Token!);
                        if (!verified)
                        {
                            return Json(new { errorCode = 10026, message = "Un-behavioral pattern detected. Please try again later" });
                        }
                    }
                    else
                    {
                        return Json(new { errorCode = 10026, message = "Invalid or no token detected. Please try again later" });
                    }
                }
                SignUpRequestModel signupRequest = null;
                if (TempData.ContainsKey("SignUpRequest"))
                {
                    var signupRequestViewModel = TempData.GetPeek<SignUpViewModel>("SignUpRequest");
                    signupRequest = new SignUpRequestModel
                    {
                        FirstName = signupRequestViewModel.FirstName,
                        LastName = signupRequestViewModel.LastName,
                        Email = signupRequestViewModel.Email,
                        MailSubscription = signupRequestViewModel.EmailSubscription,
                        IpAddress = HttpContext.GetRemoteIPAddress(),
                        PhoneNumber = signupRequestViewModel.SignUpPhoneNumber,
                        PhoneNumberCountryCode = signupRequestViewModel.SignUpPhoneNumberCC
                    };
                }
                string token = Convert.ToBase64String(System.Text.Encoding.
                    GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/VerifyPin", User,
                    ApiCallType.BasicAuth, model: new VerifyPinRequestModel
                    {
                        PhoneNumber = model.PhoneNumber,
                        PhoneNumberCountryCode = model.PhoneNumberCountryCode,
                        PinNumber = model.PinNumber,
                        IpAddress = HttpContext.GetRemoteIPAddress(),
                        SignupRequest = signupRequest
                    }, basicauthtoken: token);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0 || errorCode == (int)ApiStatusCodes.MissingPersonDetails)
                    {
                        if (errorCode == 0)
                        {
                            TempData.Remove("SignUpRequest");
                        }
                        var data = responseJson.GetValue("payload").ToObject<VerifyPinResponseModel>();

                        data.User.Msisdn = data.User.Msisdn.Replace("+", "").Trim();

                        var claims = new List<Claim>()
                            {
                                new Claim(ClaimTypes.NameIdentifier, data.User.Msisdn),
                                new Claim("phone_number", data.User.Msisdn),
                                new Claim("bearer_token", data.Token),
                                new Claim("currency", data.User.Currency),
                                new Claim("account_id", data.User.AccountID),
                                new Claim("service_id", data.User.Na_Service_Id),
                                new Claim("iso_two_country", data.User.ISO_Two_CountryCode.ToUpper())
                           };

                        if (!string.IsNullOrEmpty(data.User.Email) && data.User.IsEmailVerified)
                        {
                            claims.Add(new Claim("email", data.User.Email));
                        }

                        var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                        var authProperties = new AuthenticationProperties();

                        if (model.RememberMe)
                        {
                            authProperties = new AuthenticationProperties
                            {
                                ExpiresUtc = data.ValidTo.AddMinutes(-30),
                                IsPersistent = true,
                                AllowRefresh = false
                            };
                        }
                        else
                        {
                            authProperties = new AuthenticationProperties { IsPersistent = false, AllowRefresh = false };
                        }

                        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                            new ClaimsPrincipal(claimsIdentity), authProperties);

                        string url = "/account-summary";

                        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
                        {
                            url = model.ReturnUrl;
                        }

                        if (errorCode == (int)ApiStatusCodes.MissingPersonDetails)
                        {
                            url = "/update-missing-details?returnUrl=" + HttpUtility.UrlEncode(model.ReturnUrl);
                        }

                        #region AppsFlyer

                        try
                        {
                            if (_appsFlyerService.IsActive)
                            {
                                var afUserId = HttpContext.Request.Cookies["afUserId"];

                                var customerData = model.PhoneNumber.Replace("+", "").Trim();

                                if (!string.IsNullOrEmpty(afUserId))
                                {
                                    await _appsFlyerService.SetCustomerId(customerData, afUserId);
                                }
                            }
                        }
                        catch
                        {

                        }

                        #endregion

                        #region Airship

                        try
                        {
                            if (_airshipService.IsActive)
                            {
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed

                                string namedUserId = model.PhoneNumber.StartsWith("+") ? model.PhoneNumber.Split("+")[1] : model.PhoneNumber;
                                //Associate named web user
                                if (!string.IsNullOrEmpty(model.AirShipChannelId))
                                    _airshipService.AssociateNamedUserWeb(model.AirShipChannelId, namedUserId);

                                if (!string.IsNullOrEmpty(data.User.Email) && data.User.IsEmailVerified)
                                {
                                    if (data.User.IsMailSubscription.HasValue && data.User.IsMailSubscription.Value)
                                    {
                                        //Register with email channel
                                        _airshipService.AddEmailChannelCommercial(data.User.Email);
                                    }
                                    else
                                    {
                                        //Register with email channel
                                        _airshipService.AddEmailChannel(data.User.Email);
                                    }

                                    //Associate email with named user
                                    _airshipService.EmailAssociationWithNamedUser(namedUserId, data.User.Email);
                                }


                                //events
                                var customEventsRequest = new CustomEventsRequest()
                                {
                                    ProductCode = "THA",
                                    ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                    ChannelIdentifierValue = namedUserId
                                };

                                customEventsRequest.CustomEventName = "login_web";
                                _airshipService.AddCustomEvent(customEventsRequest);

#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed

                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.Error($"Class: AccountController, Method: VerifyCode-AirshipEvents, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                        }

                        #endregion

                        return Json(new { errorCode = 0, url });
                    }
                    else
                    {
                        string errorMessage;
                        if (errorCode == (int)ApiStatusCodes.InvalidNumber)
                        {
                            errorMessage = "Your phone number is invalid";
                        }
                        else if (errorCode == (int)ApiStatusCodes.UserNotRegistered)
                        {
                            errorMessage = "User is not registered";
                        }
                        else if (errorCode == (int)ApiStatusCodes.InvalidPinNumber)
                        {
                            errorMessage = "Verification code is invalid";
                        }
                        else if (errorCode == (int)ApiStatusCodes.UserNotAuthorized)
                        {
                            errorMessage = "User not authorized";
                        }
                        else
                        {
                            errorMessage = "Something went wrong on server";
                        }

                        return Json(new { errorCode, message = errorMessage });
                    }
                }
                else if (response.StatusCode == HttpStatusCode.Forbidden)
                {
                    return Json(new { message = "Sorry, something’s not right. Please try again in a few minutes" });
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyCode, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("update-missing-details")]
        [Authorize]
        public async Task<IActionResult> UpdateMissingDetails(string returnUrl)
        {
            try
            {
                //Get Account Details
                var accountResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                    "Account/GetAccountDetails", User, ApiCallType.Bearer, GetRequest: true);

                if (accountResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var response = accountResponseJson.GetValue("payload").ToObject<GetAccountDetailsResponseModel>();

                        if (string.IsNullOrEmpty(response.FirstName)
                             || string.IsNullOrEmpty(response.LastName)
                             || string.IsNullOrEmpty(response.Email))
                        {
                            return View(new UpdateMissingDetailsViewModel()
                            {
                                Email = response.Email,
                                FirstName = response.FirstName,
                                LastName = response.LastName,
                                EmailSubscription = response.EmailSubscription,
                                ReturnUrl = returnUrl
                            });
                        }
                        else
                        {
                            return RedirectToAction("Index", "Home");
                        }
                    }
                    else
                    {
                        throw new Exception("UpdateMissingDetails - Error while getting data from API: ErrorCode" + errorCode);
                    }
                }
                else if (accountResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("UpdateMissingDetails - Error while getting data from API: StatusCode" + accountResponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: UpdateMissingDetails, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                throw ex;
            }
        }

        [HttpGet]
        [Route("offers")]
        public async Task<IActionResult> GetPromotions()
        {
            try
            {
                string token = Convert.ToBase64String(System.Text.Encoding.
                    GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":"
                    + _basicAuthConfig.Password));

                var msisdn = User.Identity.IsAuthenticated ? User.Claims.First(i => i.Type == "phone_number").Value : null;


                var APIresponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/Promotions", User,
                                                         ApiCallType.BasicAuth, parameters: new string[] { "msisdn=" + msisdn }, GetRequest: true, basicauthtoken: token);

                if (APIresponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(APIresponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var response = accountResponseJson.GetValue("payload").ToObject<RSS>();

                        //Get Countries List
                        var json = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json");
                        var _countries = JsonConvert.DeserializeObject<CountriesResponseModel>(json);
                        if (response != null)
                        {
                            foreach (var item in response.channel.item)
                            {
                                item.countryCode = _countries.countries.Any(x => x.Name.Equals(item.countryName, StringComparison.InvariantCultureIgnoreCase)) ?
                                    _countries.countries.Where(x => x.Name.Equals(item.countryName, StringComparison.InvariantCultureIgnoreCase)).First().IsoTwoCharacterCode : null;
                            }
                        }
                        //if (User.Identity.IsAuthenticated)
                        //{
                        //    string namedUserId = User.Claims.First(i => i.Type == "phone_number").Value;
                        //    #region Airship
                        //    if (_airshipService.IsActive)
                        //    {
                        //        namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value; ;
                        //        //events
                        //        var customEventsRequest = new CustomEventsRequest()
                        //        {
                        //            ProductCode = "THA",
                        //            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        //            ChannelIdentifierValue = namedUserId,
                        //            CustomEventName = "view_offers_web"
                        //        };
                        //        _airshipService.AddCustomEvent(customEventsRequest);
                        //    }
                        //    #endregion

                        //    #region Facebook Events
                        //    if (_facebookService.IsActive)
                        //    {
                        //        _facebookService.CreateCustomEvent(namedUserId, new EventDetailsModel
                        //        {
                        //            _eventName = "view_offers_web"
                        //        });
                        //    }
                        //    #endregion

                        //}


                        return View("~/Views/Account/Promotions.cshtml", response);
                    }
                    else
                    {
                        throw new Exception("Error while getting Promotions from API" + errorCode);
                    }
                }
                else if (APIresponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("Error while getting Promotions from API: StatusCode" + APIresponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetPromotions, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                throw ex;
            }
        }

        [HttpGet]
        [Route("offer-details")]
        public async Task<IActionResult> GetPromotionDetails(string operatorName, string promotionName)
        {
            try
            {
                string token = Convert.ToBase64String(System.Text.Encoding.
                    GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":"
                    + _basicAuthConfig.Password));

                var APIresponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/Promotions", User,
                                                         ApiCallType.BasicAuth, GetRequest: true, basicauthtoken: token);

                if (APIresponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(APIresponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();


                    if (errorCode == 0)
                    {
                        var response = accountResponseJson.GetValue("payload").ToObject<RSS>();
                        var channelData = response.channel.item.
                        Where(x => x.title.Split("From")[0].Trim().Equals(operatorName)
                                && x.title2.Equals(promotionName)).FirstOrDefault();
                        if (channelData == null)
                        {
                            return RedirectToAction("Error", "Home", new { statuscode = 404 });
                        }
                        var json = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json");
                        var _countries = JsonConvert.DeserializeObject<CountriesResponseModel>(json);
                        if (response != null)
                        {
                            channelData.countryCode = _countries.countries.Any(x => x.Name.Equals(channelData.countryName, StringComparison.InvariantCultureIgnoreCase)) ?
                                _countries.countries.Where(x => x.Name.Equals(channelData.countryName, StringComparison.InvariantCultureIgnoreCase)).First().IsoTwoCharacterCode : null;
                        }

                        #region Facebook Events
                        //if (_facebookService.IsActive)
                        //{
                        //    var json = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json");
                        //    var _countries = JsonConvert.DeserializeObject<CountriesResponseModel>(json);
                        //    if (response != null)
                        //    {
                        //        channelData.countryCode = _countries.countries.Any(x => x.Name.Equals(channelData.countryName, StringComparison.InvariantCultureIgnoreCase)) ?
                        //            _countries.countries.Where(x => x.Name.Equals(channelData.countryName, StringComparison.InvariantCultureIgnoreCase)).First().IsoTwoCharacterCode : null;
                        //    }

                        //    string msisdn = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                        //    _facebookService.CreateCustomEvent(msisdn, new EventDetailsModel
                        //    {
                        //        _eventName = $"view_offers_{channelData.countryCode.ToLower()}_web"
                        //    });

                        //}
                        #endregion

                        return View("~/Views/Account/PromotionDetails.cshtml", channelData);
                    }
                    else
                    {
                        throw new Exception("Error while getting Promotions from API" + errorCode);
                    }
                }
                else if (APIresponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("Error while getting Promotions from API: StatusCode" + APIresponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetPromotions, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                throw ex;
            }
        }

        [HttpPost]
        [Route("SetPromotions")]
        [Authorize]
        public async Task<IActionResult> SetPromotions(Promotion promotion)
        {
            try
            {
                var APIresponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/Promotions", User,
                                                         ApiCallType.Bearer, new Promotion()
                                                         {
                                                             countryId = promotion.countryId,
                                                             countryName = promotion.countryName,
                                                             status = promotion.status
                                                         });

                if (APIresponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(APIresponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var response = accountResponseJson.GetValue("payload").ToObject<bool>();
                        return Json(new { errorCode = 0, response = "success", alertCase = promotion.status, countryId = promotion.countryId });
                    }
                    else
                    {
                        throw new Exception("Error while setting Promotions from API" + errorCode);
                    }
                }
                else if (APIresponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("Error while getting Promotions from API: StatusCode" + APIresponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetPromotions, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                throw ex;
            }
        }

        [HttpPost]
        [Route("update-missing-details")]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateMissingDetails(UpdateMissingDetailsViewModel model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); }

                //Get Account Details
                var accountResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                "Account/UpdateMissingDetails", User, ApiCallType.Bearer, model);

                if (accountResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    return Json(new { errorCode });
                }
                else
                {
                    return StatusCode((int)accountResponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: UpdateMissingDetails, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("update-account-details")]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateAccountDetails(AccountDetailsViewModel model)
        {
            try
            {
                ModelState.Remove("model.Email");

                if (!ModelState.IsValid) { return BadRequest(); };


                if (!model.IsEmailVerified)
                {
                    //string msisdn = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                    string msisdn = model.Email;
                    #region Facebook Events
                    if (_facebookService.IsActive)
                    {
                        await _facebookService.CreateCustomEvent(msisdn, new EventDetailsModel
                        {
                            _eventName = $"email_add_web"
                        });

                    }
                    #endregion
                    await _appsFlyerService.CreateEvent(msisdn, "email_add_web", CommonExtentionMethods.GetRemoteIPAddress(HttpContext));

                }
                //Get Account Details
                var accountResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                "Account/UpdateAccountDetails", User, ApiCallType.Bearer, model);


                if (accountResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var data = accountResponseJson.GetValue("payload").ToObject<UpdateAccountDetailsResponseModel>();

                        return Json(new { errorCode, data });
                    }
                    else
                    {
                        return Json(new { errorCode });
                    }
                }
                else
                {
                    return StatusCode((int)accountResponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: UpdateAccountDetails, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("resend-email-verification")]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResendEmailVerificationToken()
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); }

                //Get Account Details
                var accountResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                "Account/ReSendEmailVerificationLink", User, ApiCallType.Bearer);

                if (accountResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        return Json(new { errorCode = 0 }); //Email already verified
                    }

                    else if (errorCode == (int)ApiStatusCodes.EmailAlreadyVerified)
                    {
                        return Json(new { errorCode = 1 }); //Email already verified
                    }
                    else
                    {
                        return Json(new { errorCode = 2 }); //User is not registered
                    }
                }
                else
                {
                    return StatusCode((int)accountResponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: ResendEmailVerificationToken, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("resend-pin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ReSendPin(ReSendPinRequest model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); }
                //validate recaptcha v3
                if (_googleRecaptchaSettings.IsActive)
                {
                    if (!string.IsNullOrEmpty(model.Token))
                    {
                        var verified = await VerifyCaptchaToken(model.Token!);
                        if (!verified)
                        {
                            return Json(new { errorCode = 10026, message = "Un-behavioral pattern detected. Please try again later" });
                        }
                    }
                    else
                    {
                        return Json(new { errorCode = 10026, message = "Invalid or no token detected. Please try again later" });
                    }
                }
                string token = Convert.ToBase64String(System.Text.Encoding.
                    GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                model.IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext);

                //Get Account Details
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                        "Account/ReSendPin", User, ApiCallType.BasicAuth, model, basicauthtoken: token);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        return Json(new { errorCode });
                    }
                    else if (errorCode == (int)ApiStatusCodes.InvalidNumber)
                    {
                        return Json(new { errorCode, message = "Phone Number is invalid" });
                    }
                    else if (errorCode == (int)ApiStatusCodes.UserNotRegistered)
                    {
                        return Json(new { errorCode, message = "Your Phone Number is not registered" });
                    }

                    return StatusCode(500);
                }
                else if (response.StatusCode == HttpStatusCode.Forbidden)
                {
                    return Json(new { message = "Sorry, something’s not right. Please try again in a few minutes" });
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: ReSendPin, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("verify-email/{token}")]
        public async Task<IActionResult> VerifyEmail(string token)
        {
            try
            {
                if (string.IsNullOrEmpty(token))
                    return BadRequest();

                string authToken = Convert.ToBase64String(System.Text.Encoding.
                        GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                //verify email
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                "Account/VerifyEmail", User, ApiCallType.BasicAuth, new VerifyEmailRequestModel() { Token = token }, basicauthtoken: authToken);

                if (response.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        return RedirectToAction("SuccessMessage", "Home", new { key = "EmailVerificationSuccess" });
                    }
                    else if (errorCode == (int)ApiStatusCodes.InvalidToken)
                    {
                        return RedirectToAction("Error", "Home", new { statuscode = 404 });
                    }

                    throw new Exception("VerifyEmail - Error while getting data from API: Error Code" + errorCode);
                }
                else
                {
                    throw new Exception("VerifyEmail - Error while getting data from API: Status Code" + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyEmail, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [HttpPost]
        [Route("logout")]
        [Authorize]
        public async Task<IActionResult> Logout(string airChannelId)
        {
            await HttpContext.SignOutAsync();

            #region Airship
            try
            {
                if (_airshipService.IsActive)
                {
                    string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;

                    //events
                    var customEventsRequest = new CustomEventsRequest()
                    {
                        ProductCode = "THA",
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = namedUserId
                    };

                    customEventsRequest.CustomEventName = "logout_web";
                    await _airshipService.AddCustomEvent(customEventsRequest);

#pragma warning disable CS4014
                    if (!string.IsNullOrEmpty(airChannelId))
                    {
                        //Associate email with named user
                        await _airshipService.DisassociationNamedUserFromWebChannel(namedUserId, airChannelId);
                    }
#pragma warning restore CS4014
                }
            }
            catch
            {

            }
            #endregion

            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        [Route("unauthorized")]
        public async Task<IActionResult> UnauthorizedResponseAjax()
        {
            try { await HttpContext.SignOutAsync(); } catch { }
            return RedirectToAction("LogIn", "Account");
        }

        [HttpGet]
        [Route("unauthorized-api")]
        public async Task<IActionResult> UnauthorizedResponseApiCall()
        {
            try { await HttpContext.SignOutAsync(); } catch { }
            return RedirectToAction("LogIn", "Account");
        }

        [HttpGet]
        [Route("join-talkhome")]
        public IActionResult SignUp_old(string returnUrl)
        {
            return RedirectToActionPermanent("SignUp", new { returnUrl = returnUrl });

        }
        [HttpGet]
        [Route("register")]
        public IActionResult SignUp(string returnUrl)
        {
            try
            {
                //ViewBag.Key = _captchaConfig.Key;
                if (HttpContext.User.Identity.IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                var model = new SignUpViewModel()
                {
                    ReturnUrl = returnUrl
                };
                return View(model);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SignUp, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }

        }
        [HttpPost]
        [Route("signup")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SignUp(SignUpViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    //if (string.IsNullOrEmpty(model.captchaResponse))
                    //{
                    //return Json(new { errorCode = 500, message = "Valid re-captcha response is required" });
                    //}
                    //else { return BadRequest(); }
                    return BadRequest();
                }

                //var CaptchaResponse = VerifyCaptcha(model.captchaResponse);
                //if(CaptchaResponse != null && CaptchaResponse.success)
                //{

                //}
                //else
                //{
                //    return BadRequest();
                //}
                //validate recaptcha v3
                if (_googleRecaptchaSettings.IsActive)
                {
                    if (!string.IsNullOrEmpty(model.Token))
                    {
                        var verified = await VerifyCaptchaToken(model.Token!);
                        if (!verified)
                        {
                            return Json(new { errorCode = 10026, message = "Un-behavioral pattern detected. Please try again later" });
                        }
                    }
                    else
                    {
                        return Json(new
                        {
                            errorCode = 10026,
                            message = "Invalid or no token detected. Please try again later"
                        });
                    }
                }
                TempData.Put("SignUpRequest", model);
                TempData.Keep("SignUpRequest");
                string token = Convert.ToBase64String(System.Text.Encoding.
                                        GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":"
                                        + _basicAuthConfig.Password));

                //Get Account Details
                var accountResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                        "Account/SignUp", User, ApiCallType.BasicAuth, basicauthtoken: token, model: new SignUpRequestModel()
                        {
                            FirstName = model.FirstName,
                            LastName = model.LastName,
                            Email = model.Email,
                            MailSubscription = model.EmailSubscription,
                            PhoneNumber = model.SignUpPhoneNumber,
                            PhoneNumberCountryCode = model.SignUpPhoneNumberCC,
                            IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext)
                        });

                if (accountResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();
                    string message = accountResponseJson.GetValue("message").ToObject<string>();
                    if (errorCode == 0)
                    {
                        string namedUserId = model.SignUpPhoneNumber.Replace("+", "").Trim();

                        #region AppsFlyer
                        try
                        {
                            if (_appsFlyerService.IsActive)
                            {
                                var customerData = model.SignUpPhoneNumber.Replace("+", "").Trim();

                                var afUserId = HttpContext.Request.Cookies["afUserId"];

                                if (!string.IsNullOrEmpty(afUserId))
                                {
                                    await _appsFlyerService.SetCustomerId(customerData, afUserId);
                                }
#pragma warning disable CS4014
                                //_appsFlyerService.CreateEvent(customerData, "msisdn_webuser", CommonExtentionMethods.GetRemoteIPAddress(HttpContext));

                                //_appsFlyerService.CreateEvent(customerData, "registered_webuser", CommonExtentionMethods.GetRemoteIPAddress(HttpContext));

                                //_appsFlyerService.CreateEvent(customerData, "first_login", CommonExtentionMethods.GetRemoteIPAddress(HttpContext));

                                await _appsFlyerService.CreateEvent(customerData, "signup_web", CommonExtentionMethods.GetRemoteIPAddress(HttpContext));
#pragma warning restore CS4014
                            }
                        }
                        catch
                        {
                        }
                        #endregion

                        #region Facebook Events
                        if (_facebookService.IsActive)
                        {
                            await _facebookService.CreateCustomEvent(namedUserId, new EventDetailsModel
                            {
                                _eventName = $"signup_web"
                            });

                        }
                        #endregion

                        string encryptedId = _dataProtector.Protect(
                                                model.SignUpPhoneNumber +
                                                "," + model.SignUpPhoneNumberCC +
                                                "," + model.RememberMe.ToString() +
                                                "," + DateTime.Now.ToString() +
                                                "," + model.ReturnUrl);

                        return Json(new { errorCode = 0, data = HttpUtility.UrlEncode(encryptedId) });
                    }
                    else
                    {
                        if (errorCode == (int)ApiStatusCodes.InvalidNumber)
                        {
                            return Json(new { errorCode, message = "Phone Number is invalid" });
                        }
                        else if (errorCode == (int)ApiStatusCodes.UserAlreadyRegistered)
                        {
                            return Json(new { errorCode, message = "User is already registered. Please login" });
                        }
                        else if (errorCode == (int)ApiStatusCodes.SignUpFailed)
                        {
                            return Json(new { errorCode, message = message });
                        }
                    }

                    return Json(new { errorCode, message = message });
                }
                else if (accountResponse.StatusCode == HttpStatusCode.Forbidden)
                {
                    return Json(new { message = "Sorry, something’s not right. Please try again in a few minutes" });
                }
                else
                {
                    return StatusCode(500);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SignUp, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetUserAccountDetaills")]
        [Authorize]
        public async Task<IActionResult> GetUserAccountDetaills()
        {
            try
            {
                //Get Account Details
                var accountResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                    "Account/GetAccountDetails", User, ApiCallType.Bearer, GetRequest: true);

                if (accountResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var responseModel = accountResponseJson.GetValue("payload").ToObject<GetAccountDetailsResponseModel>();

                        string userCurrency = User.Claims.Where(x => x.Type == "currency").FirstOrDefault().Value;

                        return Json(new
                        {
                            currencySymbol = CommonExtentionMethods.GetCurrencySymbol(userCurrency),
                            balance = responseModel.Balance,
                            email = responseModel.Email,
                            isEmailVerified = responseModel.IsEmailVerified
                        });
                    }
                    else
                    {
                        return StatusCode(500);
                    }
                }
                else
                {
                    return StatusCode((int)accountResponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetUserAccountDetaills, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("IsTrialAutoRenewalBundleOn")]
        [Authorize]
        public async Task<IActionResult> AnyTrialAutoRenewalBundleOn()
        {
            try
            {
                var account = User.Claims.Where(x => x.Type == "account_id").First().Value;
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                    "Bundles/IsAnyActiveAutoBundleRenwal", User, ApiCallType.Bearer, GetRequest: true, parameters: new string[] { "account=" + account });

                if (response.IsSuccessStatusCode)
                {
                    var result = Convert.ToBoolean(response.Content.ReadAsStringAsync().Result);
                    return Json(new { data = result });
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetAutoTopUpSettings, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetAutoTopUpSettings")]
        [Authorize]
        public async Task<IActionResult> GetAutoTopUpSettings()
        {
            try
            {
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                    "Payment/GetAutoTopup", User, ApiCallType.Bearer, GetRequest: true);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var responseModel = responseJson.GetValue("payload").ToObject<GetAutoTopUpResponse>();
                        return Json(new { data = responseModel });
                    }
                    else
                    {
                        return StatusCode(500);
                    }
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetAutoTopUpSettings, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("SetAutoTopupWithCard")]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SetAutoTopupWithCard(SetAutoTopupWithCardRequestModel model)
        {
            try
            {
                model.IpAddress = HttpContext.GetRemoteIPAddress();
                var paymentResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Payment/SetAutoTopupWithCard", User, ApiCallType.Bearer, model);
                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();
                    var purchaseInfo = paymentResponseJson.GetValue("payload").ToObject<SetAutoTopupWithCardResponseModel>();

                    if (errorCode == 0)
                    {
                        TempData.Put("TopupInfo", purchaseInfo.AutoTopupInfo);

                        var successPageUrl = Url.Action("SetAutoTopupSuccess", "Home", new SetAutoTopupTransactionModel
                        {
                            MaxSpendLimit = purchaseInfo.AutoTopupInfo.MaxSpendLimit,
                            ThresholdAmount = purchaseInfo.AutoTopupInfo.ThresholdAmount,
                            TopupAmount = purchaseInfo.AutoTopupInfo.TopupAmount,
                            CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(purchaseInfo.AutoTopupInfo.Currency)
                        });
                        return Ok(new { errorCode = 0, redirectUrl = successPageUrl });
                    }
                    else if (errorCode == (int)ApiStatusCodes.Pending3dSecure)
                    {

                        var payload = paymentResponseJson.GetValue("payload").ToObject<SetAutoTopupWithCardResponseModel>().threeDSecureData;

                        if (!payload.clientRedirectType.Contains("V2"))
                        {
                            var transactionViewModel = new Pay360TransactionViewModel
                            {
                                url = payload.redirectUrl,
                                pareq = payload.pareq,
                                TransactionId = payload.transactionId,
                                returnUrl = payload.returnUrl,
                                threeDSVersion = "V2",
                                PaymentSuccessAction = "/PaymentSuccess",
                                PaymentErrorAction = "/PaymentError"
                            };
                            var threeDSPageUrl = Url.Action("ThreeDSecure", transactionViewModel);
                            return Ok(new { errorCode = 13, redirectUrl = threeDSPageUrl });
                        }
                        else
                        {
                            var transactionViewModel = new Pay360TransactionViewModel
                            {
                                url = payload.redirectUrl,
                                pareq = payload.pareq,
                                TransactionId = payload.transactionId,
                                returnUrl = payload.returnUrl,
                                threeDSServerTransId = payload.threeDSServerTransId,
                                threeDSVersion = "V1",
                                PaymentSuccessAction = "/PaymentSuccess",
                                PaymentErrorAction = "/PaymentError"
                            };
                            var threeDSPageUrl = Url.Action("ThreeDSecure", transactionViewModel);
                            return Ok(new { errorCode = 13, redirectUrl = threeDSPageUrl });
                        }
                    }
                    return Ok(new { errorCode = errorCode, errorMessage = paymentResponseJson.GetValue("message").ToObject<string>() });
                }
                else if (paymentResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    var json = await paymentResponse.Content.ReadAsStringAsync();
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SetAutoTopupWithCard," +
                    $" ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [Route("ThreeDSecure")]
        [Authorize]
        public IActionResult ThreeDSecure(Pay360TransactionViewModel model)
        {
            if (model.threeDSVersion.Equals("V1"))
            {
                return View("~/Views/shared/View3DSecure.cshtml", model);
            }
            else
            {
                return View("~/Views/shared/View3DSecureV2.cshtml", model);
            }
        }
        [Route("SetAutoTopupWithCardSecureReturnPayment")]
        public async Task<IActionResult> SetAutoTopupWithCardSecureReturn(SetAutoTopupWithCardSecureReturnPaymentRequest model)
        {
            try
            {
                if (model.clientRedirectType.Contains("V2", StringComparison.InvariantCultureIgnoreCase))
                {
                    ModelState.Remove("PaRes");
                }
                if (!ModelState.IsValid) { return BadRequest(); };

                String encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var paymentResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                        "Payment/SetAutoTopupWithCardResume3DTransaction", User, ApiCallType.BasicAuth,
                                                         new SetAutoTopupWithCardPay360Resume3DRequestModel()
                                                         {
                                                             MD = model.MD,
                                                             PaRes = model.PaRes,
                                                             type = model.type,
                                                             customerEmail = model.customerEmail,
                                                             clientRedirectType = model.clientRedirectType,
                                                             customerMsisdn = model.customerMsisdn,
                                                             currency = model.currency,
                                                             IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext),
                                                             PTId = model.PTId,
                                                             ShouldSaveCard = model.shouldSave,
                                                             ThresholdAmount = model.ThresholdAmount,
                                                             TopupAmount = model.TopupAmount,

                                                         }, basicauthtoken: encoded);

                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(await paymentResponse.Content.ReadAsStringAsync());
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();
                    var purchaseInfo = paymentResponseJson.GetValue("payload").ToObject<SetAutoTopupWithCardPay360Resume3DResponseModel>();
                    SetAutoTopupTransactionModel resultPageModel = new SetAutoTopupTransactionModel
                    {
                        ThresholdAmount = purchaseInfo.AutoTopupInfo.ThresholdAmount,
                        CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(purchaseInfo.AutoTopupInfo.Currency),
                        MaxSpendLimit = purchaseInfo.AutoTopupInfo.MaxSpendLimit,
                        TopupAmount = purchaseInfo.AutoTopupInfo.TopupAmount
                    };
                    if (errorCode == 0)
                    {
                        var successPageUrl = Url.Action("SetAutoTopupSuccess", "Home", resultPageModel);
                        return PartialView("~/Views/Home/UrlRedirection.cshtml", successPageUrl);
                    }
                    else
                    {
                        var errorPageUrl = Url.Action("SetAutoTopupError", "Home", resultPageModel);
                        return PartialView("~/Views/Home/UrlRedirection.cshtml", errorPageUrl);
                    }
                }
                else
                {
                    var errorPageUrl = Url.Action("SetAutoTopupError", "Home", new { });
                    return PartialView("~/Views/Home/UrlRedirection.cshtml", errorPageUrl);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SetAutoTopupWithCardSecureReturn, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                var errorPageUrl = Url.Action("SetAutoTopupError", "Home", new { });
                return PartialView("~/Views/Home/UrlRedirection.cshtml", errorPageUrl);
            }
        }
        [HttpPost]
        [Route("SetAutoRenewalWithCard")]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SetAutoRenewalWithCard(SetAutoRenewalWithCardRequestModel model)
        {
            try
            {
                model.IpAddress = HttpContext.GetRemoteIPAddress();
                var paymentResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Payment/SetAutoRenewalWithCard", User, ApiCallType.Bearer, model);
                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var successPageUrl = Url.Action("SetAutoRenewalSuccess", "Home");
                        return Ok(new { errorCode = 0, redirectUrl = successPageUrl });
                    }
                    else if (errorCode == (int)ApiStatusCodes.Pending3dSecure)
                    {

                        var payload = paymentResponseJson.GetValue("payload").ToObject<SetAutoRenewalWithCardResponseModel>().threeDSecureData;

                        if (!payload.clientRedirectType.Contains("V2"))
                        {
                            var transactionViewModel = new Pay360TransactionViewModel
                            {
                                url = payload.redirectUrl,
                                pareq = payload.pareq,
                                TransactionId = payload.transactionId,
                                returnUrl = payload.returnUrl,
                                threeDSVersion = "V2",
                                PaymentSuccessAction = "/PaymentSuccess",
                                PaymentErrorAction = "/PaymentError"
                            };
                            var threeDSPageUrl = Url.Action("ThreeDSecure", transactionViewModel);
                            return Ok(new { errorCode = 13, redirectUrl = threeDSPageUrl });
                        }
                        else
                        {
                            var transactionViewModel = new Pay360TransactionViewModel
                            {
                                url = payload.redirectUrl,
                                pareq = payload.pareq,
                                TransactionId = payload.transactionId,
                                returnUrl = payload.returnUrl,
                                threeDSServerTransId = payload.threeDSServerTransId,
                                threeDSVersion = "V1",
                                PaymentSuccessAction = "/PaymentSuccess",
                                PaymentErrorAction = "/PaymentError"
                            };
                            var threeDSPageUrl = Url.Action("ThreeDSecure", transactionViewModel);
                            return Ok(new { errorCode = 13, redirectUrl = threeDSPageUrl });
                        }
                    }

                    return Ok(new { errorCode = errorCode, errorMessage = paymentResponseJson.GetValue("message").ToObject<string>() });
                }
                else if (paymentResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    var json = await paymentResponse.Content.ReadAsStringAsync();
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SetAutoRenewalWithCard," +
                    $" ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [Route("SetAutoRenewalWithCardSecureReturnPayment")]
        public async Task<IActionResult> SetAutoRenewalWithCardSecureReturn(SetAutoRenewalWithCardSecureReturnPaymentRequest model)
        {
            try
            {
                if (model.clientRedirectType.Contains("V2", StringComparison.InvariantCultureIgnoreCase))
                {
                    ModelState.Remove("PaRes");
                }
                if (!ModelState.IsValid) { return BadRequest(); };

                String encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var paymentResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                        "Payment/SetAutoRenewalWithCardResume3DTransaction", User, ApiCallType.BasicAuth,
                                                         new SetAutoRenewalWithCardPay360Resume3DRequestModel()
                                                         {
                                                             MD = model.MD,
                                                             PaRes = model.PaRes,
                                                             type = model.type,
                                                             customerEmail = model.customerEmail,
                                                             clientRedirectType = model.clientRedirectType,
                                                             customerMsisdn = model.customerMsisdn,
                                                             currency = model.currency,
                                                             IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext),
                                                             PTId = model.PTId,
                                                             BundleId = model.BundleId,
                                                         }, basicauthtoken: encoded);

                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(await paymentResponse.Content.ReadAsStringAsync());
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();
                    var purchaseInfo = paymentResponseJson.GetValue("payload").ToObject<SetAutoRenewalWithCardPay360Resume3DResponseModel>();

                    if (errorCode == 0)
                    {
                        var successPageUrl = Url.Action("SetAutoRenewalSuccess", "Home");
                        return PartialView("~/Views/Home/UrlRedirection.cshtml", successPageUrl);
                    }
                    else
                    {
                        var errorPageUrl = Url.Action("SetAutoRenewalError", "Home");
                        return PartialView("~/Views/Home/UrlRedirection.cshtml", errorPageUrl);
                    }
                }
                else
                {
                    var errorPageUrl = Url.Action("SetAutoRenewalError", "Home");
                    return PartialView("~/Views/Home/UrlRedirection.cshtml", errorPageUrl);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SetAutoRenewalWithCardSecureReturn, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                var errorPageUrl = Url.Action("SetAutoRenewalError", "Home", new { });
                return PartialView("~/Views/Home/UrlRedirection.cshtml", errorPageUrl);
            }
        }
        [HttpPost]
        [Route("DisableAutoTopup")]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DisableAutoTopup()
        {
            try
            {
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Payment/DisableAutoTopup", User, ApiCallType.Bearer, null);
                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        #region Facebook Events
                        if (_facebookService.IsActive)
                        {
                            string msisdn = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                            await _facebookService.CreateCustomEvent(msisdn, new EventDetailsModel
                            {
                                _eventName = $"{"disable_autotop_web"}"
                            });
                        }
                        #endregion
                        return Json(new { data = responseJson.GetValue("payload").ToObject<bool>() });
                    }
                    else
                    {
                        return StatusCode(500);
                    }
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SetAutoTopup," +
                    $" ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetCallHistory")]
        [Authorize]
        public async Task<IActionResult> GetCallHistory()
        {
            try
            {
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/GetCallingHistory", User, ApiCallType.Bearer, GetRequest: true);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);

                    var payload = responseJson.GetValue("payload").ToObject<CallHistoryResponseModel>().CallHistory;

                    if (payload.Count > 0)
                    {
                        var callingHistory = payload.OrderByDescending(x => x.formattedDateTime);

                        string minorCurrency = CommonExtentionMethods.GetMinorCurrencyUnit(User.Claims.Where(x => x.Type == "currency").
                                                                                                                        FirstOrDefault().Value);
                        foreach (var item in callingHistory)
                        {
                            TimeSpan time = TimeSpan.FromSeconds(Convert.ToDouble(item.Duration));
                            item.Duration = time.ToString(@"hh\:mm\:ss");
                            item.formattedDateTime = item.DateTime.ToString("yyyy-MM-dd HH:mm");
                            item.TotalCharge = item.TotalCharge + minorCurrency;
                        }

                        return Json(new { data = callingHistory });
                    }
                    else
                    {
                        return Json(new { data = new List<CallHistory>() { } });
                    }
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetCallHistory, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetTopupHistory")]
        [Authorize]
        public async Task<IActionResult> GetTopupHistory()
        {
            try
            {
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/GetTopUpPaymentHistory", User, ApiCallType.Bearer, GetRequest: true);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);

                    var payload = responseJson.GetValue("payload").ToObject<GetTopUpPaymentHistoryResponseModel>().TopUpHistory;

                    foreach (var item in payload)
                    {
                        item.formattedTransDate = item.TransDate.ToString("dd-MM-yyyy");
                    }

                    return Json(new
                    {
                        data = payload,
                        currencySymbol = CommonExtentionMethods.GetCurrencySymbol(User.Claims.Where(x => x.Type == "currency").FirstOrDefault().Value)
                    });
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: AccountController, Method: GetTopupHistory, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [HttpGet]
        [Route("GetEntirePaymentHistory")]
        [Authorize]
        public async Task<IActionResult> GetEntirePaymentHistory()
        {
            try
            {
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/GetEntirePaymentHistory", User, ApiCallType.Bearer, GetRequest: true);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);

                    var payload = responseJson.GetValue("payload").ToObject<List<EntirePaymentHistory>>().Where(e => e.Type != "AirTimeTransfer" && e.Type != "InAppTransfer");
                    foreach (var item in payload)
                    {
                        item.FormattedTransDate = item.TransDate.ToString("dd-MM-yyyy");
                    }

                    return Json(new
                    {
                        data = payload,
                        currencySymbol = CommonExtentionMethods.GetCurrencySymbol(User.Claims.Where(x => x.Type == "currency").FirstOrDefault().Value)
                    });
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: AccountController, Method: GetEntirePaymentHistory, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetInternationalTopUptHistory")]
        [Authorize]
        public async Task<IActionResult> GetInternationalTopUptHistory()
        {
            try
            {
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/GetInternationalTopUpHistory",
                                                                                    User, ApiCallType.Bearer, GetRequest: true);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);

                    var payload = responseJson.GetValue("payload").ToObject<GetInternationalTopUpHistoryResponseModel>().TopUpHistory;

                    foreach (var item in payload)
                    {
                        item.formattedTransDate = item.TransactionDateTime.ToString("dd-MM-yyyy");
                        item.ToMsisdnEncrypted = _dataProtector.Protect(item.ToMsisdn);
                    }

                    return Json(new
                    {
                        data = payload,
                        clientCS = CommonExtentionMethods.GetCurrencySymbol(User.Claims.Where(x => x.Type == "currency").FirstOrDefault().Value)
                    });
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: AccountController, Method: GetInternationalTopUptHistory, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetBundlesHistory")]
        [Authorize]
        public async Task<IActionResult> GetBundlesHistory()
        {
            try
            {
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/GetBundlesHistory", User, ApiCallType.Bearer, GetRequest: true);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);

                    var payload = responseJson.GetValue("payload").ToObject<GetBundlesHistoryResponseModel>().BundlesHistory.ToList();

                    foreach (var item in payload)
                    {
                        item.ExpiryInDays = Convert.ToInt32((item.Expiry - DateTime.Now).TotalDays);
                        item.BundleCategoryName = item.BundleCategory.ToString();
                        item.BundleTypeName = item.BundleType.ToString();
                    }

                    return Json(new
                    {
                        data = payload,
                        clientCS = CommonExtentionMethods.GetCurrencySymbol(User.Claims.Where(x => x.Type == "currency").FirstOrDefault().Value)
                    });
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: AccountController, Method: GetBundlesHistory, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetCustomerCards")]
        [Authorize]
        public async Task<IActionResult> GetCustomerCards()
        {
            try
            {
                var result = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Payment/GetCustomerCards", User,
                    ApiCallType.Bearer, GetRequest: true);

                if (result.IsSuccessStatusCode)
                {
                    var response = JObject.Parse(await result.Content.ReadAsStringAsync());

                    var errorCode = response.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = response.GetValue("payload").ToObject<Pay360CardsData>();

                        return Json(new { status = true, data = payload });
                    }
                    else
                    {
                        return Json(new { status = false });
                    }
                }
                else
                {
                    return StatusCode((int)result.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetCustomerCards, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Authorize]
        [Route("SetCustomerDefaultCard")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SetCustomerDefaultCard(SetCustomerDefaultCardRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid) { return StatusCode((int)HttpStatusCode.BadRequest); }

                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Payment/SetCustomerDefaultCard", User, ApiCallType.Bearer,
                    model: model);

                if (response.IsSuccessStatusCode)
                {
                    var cardResult = JObject.Parse(response.Content.ReadAsStringAsync().Result);

                    var errorCode = cardResult.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        return Json(new { status = true });
                    }
                    else
                    {
                        return Json(new { status = false, message = cardResult.GetValue("message").ToObject<string>() });
                    }
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SetCustomerDefaultCard, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Authorize]
        [Route("RemoveCard")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveCard(RemoveCardRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid) { return StatusCode((int)HttpStatusCode.BadRequest); }

                //Get cards
                var result = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Payment/GetCustomerCards", User,
                ApiCallType.Bearer, GetRequest: true);

                if (result.IsSuccessStatusCode)
                {
                    var cardsresponse = JObject.Parse(result.Content.ReadAsStringAsync().Result);
                    var errorCode = cardsresponse.GetValue("errorCode").ToObject<int>();
                    if (errorCode == 0)
                    {
                        var payload = cardsresponse.GetValue("payload").ToObject<Pay360CardsData>();

                        if (payload.paymentMethodResponses.Count == 1)
                        {

                            try
                            {
                                //get autotopup settings
                                var get_topup_settings_response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                                        "Payment/GetAutoTopup", User, ApiCallType.Bearer, GetRequest: true);
                                if (get_topup_settings_response.IsSuccessStatusCode)
                                {
                                    var responseJson = JObject.Parse(get_topup_settings_response.Content.ReadAsStringAsync().Result);

                                    if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                                    {
                                        var responseModel = responseJson.GetValue("payload").ToObject<GetAutoTopUpResponse>();

                                        AutoTopUpSettings autoTopUpSettings = new AutoTopUpSettings();
                                        autoTopUpSettings.amount = Convert.ToInt32(responseModel.Topup);
                                        autoTopUpSettings.isActive = false;
                                        autoTopUpSettings.thresholdBalanceAmount = Convert.ToInt32(responseModel.ThresHold);


                                        //Set autotopup settings off                                    
                                        await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Payment/SetAutoTopup", User, ApiCallType.Bearer, autoTopUpSettings);
                                    }
                                }
                                else
                                {
                                    return StatusCode((int)get_topup_settings_response.StatusCode);
                                }

                            }
                            catch (Exception ex)
                            {
                                _logger.Error($"Class: AccountController, Method: RemoveCard - GetAutoTopup - SetAutoTopup, " +
                                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                            }
                        }
                    }

                }
                else
                {
                    return StatusCode((int)result.StatusCode);
                }


                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Payment/RemoveCard", User, ApiCallType.Bearer, model: model);
                if (response.IsSuccessStatusCode)
                {
                    var cardResult = JObject.Parse(response.Content.ReadAsStringAsync().Result);

                    var errorCode = cardResult.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        return Json(new { status = true });
                    }
                    else
                    {
                        return Json(new { status = false, message = cardResult.GetValue("message").ToObject<string>() });
                    }
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: RemoveCard, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        public async Task<IActionResult> ValidateMsisdn(string Msisdn)
        {
            try
            {
                if (string.IsNullOrEmpty(Msisdn))
                    return BadRequest();

                string authToken = Convert.ToBase64String(System.Text.Encoding.
                        GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                //verify msisdn
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                "Account/IsMsisdnRegistered", User, ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "Msisdn=" + Msisdn }, basicauthtoken: authToken);

                if (response.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        return Json(new { validNumber = true });
                    }
                    else
                    {
                        return Json(new { validNumber = false, message = "Please enter a valid Number" });
                    }
                }
                else
                {
                    return Json(new { validNumber = false, message = "Something went wrong. Try again" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: ValidateMsisdn, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return Json(new { validNumber = false, message = "Something went wrong. Try again" });
            }
        }

        [Route("verifymsisdn")]
        [HttpGet]
        public async Task<bool> VerifyMsisdn(string Msisdn)
        {
            try
            {
                if (string.IsNullOrEmpty(Msisdn))
                    return false;

                string authToken = Convert.ToBase64String(System.Text.Encoding.
                        GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                //verify msisdn
                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                "Account/IsMsisdnRegistered", User, ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "Msisdn=" + Msisdn }, basicauthtoken: authToken);

                if (response.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyMsisdn, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return false;
            }
        }
        public async Task<bool> VerifyCaptchaToken(string Token)
        {
            if (String.IsNullOrEmpty(Token))
            {
                throw new Exception("Token cannot be null!");
            }
            using (var client = new HttpClient())
            {
                var response = await client.GetStringAsync($"{_googleRecaptchaSettings.VerifyAPIAddress}?secret={_googleRecaptchaSettings.Secretkey}&response={Token}");
                var tokenResponse = JsonConvert.DeserializeObject<GoogleCaptchaTokenResponseModel>(response);
                if (!tokenResponse.Success || tokenResponse.Score < _googleRecaptchaSettings.RecaptchaThreshold)
                {
                    return false;
                }
            }
            return true;
        }
        //private CaptchaViewModel VerifyCaptcha(string CaptchaResponse)
        //{
        //    string url = "https://www.google.com/recaptcha/api/siteverify?secret=" + _captchaConfig.Secret + "&response=" + CaptchaResponse;
        //    CaptchaViewModel data = JsonConvert.DeserializeObject<CaptchaViewModel>((new WebClient()).DownloadString(url));

        //    return data;
        //}                
        /// <summary>
        /// This method will log the user delete account request
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateDeleteAccountRequest")]
        public async Task<IActionResult> CreateDeleteAccountRequest(DeleteAccountViewModel model)
        {
            try
            {
                var requestModel = new DeleteAccountRequestModel();
                requestModel.DeleteAccountReason = model.SeletedAccountReasons.Count() > 0 ? string.Join(',', model.SeletedAccountReasons) : null;
                requestModel.Comments = model.Comments;
                requestModel.AccountId = User.AccountId();
                requestModel.Msisdn = User.PhoneNumber();
                //Get Account Details
                var apiResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                "Account/CreateDeleteAccountRequest", User, ApiCallType.Bearer, requestModel);

                if (apiResponse.IsSuccessStatusCode)
                {
                    var apiResponseJson = JObject.Parse(apiResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = apiResponseJson.GetValue("errorCode").ToObject<int>();
                    string message = apiResponseJson.GetValue("message").ToObject<string>();
                    await HttpContext.SignOutAsync();
                    return Json(new { errorCode, message = message });

                }
                else if (apiResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("CreateDeleteAccountRequest - Error while getting data from API: StatusCode" + apiResponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: CreateDeleteAccountRequest, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                throw ex;
            }
        }

        [HttpGet]
        [Route("DeleteAccount")]
        [Authorize]        
        public IActionResult DeleteAccount()
        {
            return RedirectToAction("AccountDetails", "Home");
        }
        
        [HttpPost]
        [Route("DeleteAccount")]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteAccount(VerifyPinViewModel model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); }
                //validate recaptcha v3
                if (_googleRecaptchaSettings.IsActive)
                {
                    if (!string.IsNullOrEmpty(model.Token))
                    {
                        var verified = await VerifyCaptchaToken(model.Token!);
                        if (!verified)
                        {
                            return RedirectToAction("AccountDetails", "Home");                           
                        }
                    }
                    else
                    {
                        return RedirectToAction("AccountDetails", "Home");
                    }
                }

                string token = Convert.ToBase64String(System.Text.Encoding.
                    GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var response = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Account/VerifyPinCode", User,
                    ApiCallType.BasicAuth, model: new PinVerificationCodeRequestModel
                    {
                        PinCode = model.PinCode,
                        PhoneNumber = User.PhoneNumber(),
                        PhoneNumberCountryCode = User.CountryCode()
                    }, basicauthtoken: token);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (errorCode == 0)
                    {
                        //Get Account Details
                        var apiResponse = await _apiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                        "Account/GetDeleteAccountReasons", User, ApiCallType.Bearer);

                        if (apiResponse.IsSuccessStatusCode)
                        {
                            var deleteAccountApiResponseJson = JObject.Parse(apiResponse.Content.ReadAsStringAsync().Result);
                            int deleteAccountApiResponseErrorCode = deleteAccountApiResponseJson.GetValue("errorCode").ToObject<int>();
                            string message = deleteAccountApiResponseJson.GetValue("message").ToObject<string>();


                            if (deleteAccountApiResponseErrorCode == 0)
                            {
                                var deleteAccountReasonsList = deleteAccountApiResponseJson.GetValue("payload").ToObject<List<DeleteAccountReason>>();

                                return View(new DeleteAccountViewModel { DeleteAccountReasons = deleteAccountReasonsList });                        
                            }
                            else
                            {
                                return RedirectToAction("Error", "Home", new { statuscode = 500 });
                            }
                        }
                        else if (apiResponse.StatusCode == HttpStatusCode.Unauthorized)
                        {
                            return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                        }
                        else
                        {
                            throw new Exception("DeleteAccount - Error while getting data from API: StatusCode" + apiResponse.StatusCode);
                        }
                    }
                    else
                    {
                        string message = responseJson.GetValue("message").ToObject<string>();

                        return Json(new { errorCode, message = message });
                    }

                }
                else if (response.StatusCode == HttpStatusCode.Forbidden)
                {
                    return Json(new { message = "Sorry, something’s not right. Please try again in a few minutes" });
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: DeleteAccount, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                throw ex;
            }
        }
    }
}