﻿using ATT.Models.Configurations;
using ATT.Models.Contracts.TransferTo.Response;
using ATT.Models.Database;
using ATT.Models.DbConnections;
using Dapper;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ATT.Infrastructure.DAL
{
    public class DataBundlesDb_DL : IDataBundlesDb_DL
    {        

        private readonly ILogger loggerAPIAccess;
        private IDbConnectionSettings AirtimeTransferConnection;

        public DataBundlesDb_DL(ILogger logger, IOptions<ConnectionString> connectionString)
        {
            loggerAPIAccess = logger;
            AirtimeTransferConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
        }


        public async Task<ServiceProvider> GetDataBundleServiceProviderRecord(int nsid, string destinationMsisdn)
        {
            ServiceProvider servcieProvider = null;
            try
            {

                var p = new DynamicParameters();
                p.Add("@nsid", nsid, DbType.Int16);
                p.Add("@destinationMsisdn", destinationMsisdn, DbType.String);
                servcieProvider = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<ServiceProvider>("at_getDataBundlesServiceProviderByNSID", p, commandType: CommandType.StoredProcedure);
                
            }
            catch (Exception ex)
            {
                loggerAPIAccess.Debug($"\"Database Error  getServiceProviderRecord    Message:{ex.ToString()}");
            }

            return servcieProvider;
        }



        public  List<EndRateDataBundleProductList> GetDataBundleEndRates(int serviceProviderOperaorId, string account, int serviceProviderId, int originDestinationId)
        {
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@serviceproviderId", serviceProviderId);
                parameters.Add("@serviceProviderOperatorID", serviceProviderOperaorId);
                parameters.Add("@clientccy", account);
                parameters.Add("@originDestinationId", originDestinationId);
                
                var result =  AirtimeTransferConnection.Connection.Query<EndRateDataBundleProductList>("at_getDataBundleOperatorServiceProviderRateRecord", parameters, commandType: CommandType.StoredProcedure);
                //  result = (List<EndRateDataBundleProductList>)_db.Query<EndRateDataBundleProductList>("at_getDataBundleOperatorServiceProviderRateRecord", parameters, commandType: CommandType.StoredProcedure);
                return result.ToList<EndRateDataBundleProductList>();

            }
            catch (Exception ex)
            {
                loggerAPIAccess.Debug($"\"Database Error     GetDataBundleEndRates    Message:{ex.ToString()}");
                return null;
            }


           
        }

        // This method is used to insert nowtelTransactionReference , ProductApiType and other data neccessary for sending transfer request. 
     

        public async Task<int> insertDataBundleAccessDetails(string nowtelTransactionReference, string account, string toMsisdn, string productApiType, string clientccy,string receiverccy,string productId,string productValue, string productDesc, string wholeSalePrice,string customerChargePrice)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@nowtelTransactionReference", nowtelTransactionReference);
                parameters.Add("@account", account);
                parameters.Add("@toMsisdn", toMsisdn);
                parameters.Add("@productApiType", productApiType);

                
                parameters.Add("@clientccy", clientccy);
                parameters.Add("@receiverccy", receiverccy);
                parameters.Add("@productIdList", productId);
                parameters.Add("@productValueList", productValue);
                parameters.Add("@productDescList", productDesc);
                parameters.Add("@wholeSalePriceList", wholeSalePrice);
                parameters.Add("@customerChargePriceList", customerChargePrice);
               

              int result =  await AirtimeTransferConnection.Connection.ExecuteAsync("at_createDataBundleAccessDetails", parameters, commandType: CommandType.StoredProcedure);

               return result;

            }
            catch (Exception ex)
            {
                loggerAPIAccess.Debug($"\"Database Error     insertDataBundleAccessDetails    Message:{ex.ToString()}");

            }


            return 0;

        }


        async public Task<DataBundleAPIAccess> getDataBundleAccessRecord(string nowtelTransactionReference, string productValue,string productApiType)
        {
            DataBundleAPIAccess data = null;
            try
            {

                var parameters = new DynamicParameters();
                parameters.Add("@nowtelTransactionReference", nowtelTransactionReference);
                parameters.Add("@productValue", productValue);
                parameters.Add("@productApiType", productApiType);

                data = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DataBundleAPIAccess>("at_getDataBundleAccessRecord", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                loggerAPIAccess.Debug($"\"Database Error   getDataBundleAccessRecord    Message:{ex.ToString()}");
            }



            return data;
        }


        async public Task<bool> InsertDataBundleTransaction(string Date, string AccountID, decimal Amount, decimal BuyAmount, string Currency, string OperatorCurrency, string DestinationCountry, string Status, string ErrorMessage, string OperaterID, string ProductID, string Product, string ProductDesc, string ProductApiType, string OperatorName, string NowtelTranscationRefrence, string TransactionRefrence, string frommsisdn, string tomsisdn, int ServiceProviderID, string message_to_recipient)
        {
            bool result = false;
            try
            {

                var p = new DynamicParameters();

                p.Add("@CurrencyAccountID", AccountID, dbType: DbType.String);
                p.Add("Amount", Amount, dbType: DbType.Decimal);
                p.Add("@BuyAmount", BuyAmount, dbType: DbType.String);
                p.Add("@Currency", Currency, dbType: DbType.String);
                p.Add("@OperatorCurrency", OperatorCurrency, dbType: DbType.String);
                p.Add("@DestinationCountry", DestinationCountry, dbType: DbType.String);
                p.Add("@Status", Status, dbType: DbType.String);
                p.Add("@ErrorMessage", ErrorMessage, dbType: DbType.String);
                p.Add("@OperaterID", OperaterID, dbType: DbType.String);
                p.Add("@ProductID", ProductID, dbType: DbType.String);
                p.Add("@Product", Product, dbType: DbType.String);
                p.Add("@ProductDesc", ProductDesc, dbType: DbType.String);
                p.Add("@ProductApiType", ProductApiType, DbType.String);
                p.Add("@OperatorName", OperatorName, dbType: DbType.String);
                p.Add("@NowtelTranscationRefrence", NowtelTranscationRefrence, dbType: DbType.String);
                p.Add("@TransactionRefrence", TransactionRefrence, dbType: DbType.String);
                p.Add("@FromMsisdn", frommsisdn, dbType: DbType.String);
                p.Add("@ToMsisdn", tomsisdn, dbType: DbType.String);
                p.Add("@ServiceProviderID", ServiceProviderID, dbType: DbType.String);
                p.Add("@MessageToRecipient", message_to_recipient, dbType: DbType.String);

               int  dbresult =  await AirtimeTransferConnection.Connection.ExecuteAsync("at_createDataBundleTransaction", p, commandType: CommandType.StoredProcedure);

           
                if(dbresult == 1)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                loggerAPIAccess.Debug($"\"Database Error     at_createDataBundleTransaction    Message:{ex.ToString()}");
            }

            return result;
        }

    }
}
