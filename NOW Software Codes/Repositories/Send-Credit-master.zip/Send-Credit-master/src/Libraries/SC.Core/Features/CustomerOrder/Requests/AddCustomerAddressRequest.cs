﻿

using System.ComponentModel;
using System.Data.SqlTypes;
using System.Text.Json.Serialization;


namespace SC.Core.Features.CustomerOrder.Requests;
public sealed class AddCustomerAddressRequest : IRequest<IResultWrapper>
{
    public string CustomerId { get; set; } = default!;

    public string AddressType { get; set; } = default!;

    public string StreetAddress1 { get; set; } = default!;

    public string StreetAddress2 { get; set; } = default!;

    public string City { get; set; } = default!;

    public string State { get; set; } = default!;

    public string PostalCode { get; set; } = default!;

    public string Country { get; set; } = default!;

    public string Email { get; set; } = default!;

    public string Phone { get; set; } = default!;
    public string Region { get; set; } = default!;
    public string CountryCode { get; set; } = default!;
}
public sealed class AddCustomerAddressRequestValidator : AbstractValidator<AddCustomerAddressRequest>
{
    public AddCustomerAddressRequestValidator()
    {
        RuleFor(x => x.Email).NotEmpty();
    }
}

