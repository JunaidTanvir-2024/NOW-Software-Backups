﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

using Newtonsoft.Json;

using Serilog;

using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Application.Settings;

using UAParser;

namespace THCC.Infrastructure.Services
{
    public class LocationService : ILocationService
    {
        #region Fields

        private readonly ILogger _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ICommonService _commonService;
        private readonly GeoLocationSettings _locationSettings;

        #endregion

        #region Ctor

        public LocationService(
            ILogger logger,
            IHttpClientFactory httpClientFactory,
            IHttpContextAccessor httpContextAccessor,
            ICommonService commonService,
            IOptions<GeoLocationSettings> locationSettings)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
            _httpContextAccessor = httpContextAccessor;
            _commonService = commonService;
            _locationSettings = locationSettings.Value;
        }

        #endregion

        #region Methods

        public async Task<GeoLocationDto> GetLocationInfo()
        {
            try
            {
                string ipAddress = _httpContextAccessor?.HttpContext?.Request?.Headers["x-th-ipaddress"]!;
                if (string.IsNullOrEmpty(ipAddress))
                {
                    ipAddress = _commonService.GetIpAddress();
                }
                string deviceName = _httpContextAccessor?.HttpContext?.Request?.Headers["x-th-browser"]!;
                if (string.IsNullOrEmpty(deviceName))
                {
                    string userAgent = _httpContextAccessor?.HttpContext?.Request?.Headers["User-Agent"]!;
                    deviceName = GetBrowserName(userAgent);
                }
                var location = await GetLocationInfoByIpAddress(ipAddress);
                return new GeoLocationDto
                {
                    IpAddress = ipAddress,
                    Device = deviceName,
                    CityName = location?.CityName,
                    CountryName = location?.CountryName
                };
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message);
                return null!;
            }
        }

        private async Task<LocationDto?> GetLocationInfoByIpAddress(string ipAddress)
        {
            try
            {
                if (!_locationSettings.IsActive) { return null!; }

                var httpClient = _httpClientFactory.CreateClient();
                var endpoint = $"{_locationSettings.ApiBaseUrl}{ipAddress}/json";
                var output = await httpClient.GetAsync(endpoint);
                string outputData = await output.Content.ReadAsStringAsync();
                if (output.IsSuccessStatusCode)
                {
                    string jsonResponse = await output.Content.ReadAsStringAsync();
                    dynamic locationData = JsonConvert.DeserializeObject(jsonResponse)!;
                    return new LocationDto()
                    {
                        CityName = locationData?.city!,
                        CountryName = locationData?.country_name!,
                    };
                }
                else
                {
                    var errorMessage = await output.Content.ReadAsStringAsync();
                    _logger.Error("AddressService: GetAddresses=> " + errorMessage);
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.Error($"GetLocationInfoByIpAddress=> Method:GetLocationInfoByIpAddress, Error:{ex.Message}");
                return null;
            }
        }

        #endregion

        #region Private

        private string GetBrowserName(string userAgent)
        {
            var uaParser = Parser.GetDefault();
            ClientInfo c = uaParser.Parse(userAgent);
            return c.UA.Family;
        }

        #endregion
    }
}
