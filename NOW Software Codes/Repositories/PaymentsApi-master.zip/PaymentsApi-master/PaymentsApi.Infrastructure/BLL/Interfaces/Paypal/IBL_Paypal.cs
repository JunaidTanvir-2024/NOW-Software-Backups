﻿using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Paypal.Request.User;
using PaymentsApi.Models.Contracts.Paypal.Response.User;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PaymentsApi.Infrastructure.BLL.Interfaces.Paypal
{
    public interface IBL_Paypal
    {
        Task<GenericApiResponse<UserPaypalPaymentResponse>> PaypalPayment(UserPaypalPaymentRequest userRequest);
        Task<GenericApiResponse<UserPaypalResumeResponse>> PaypalResume(UserPaypalResumeRequest userRequest);
        Task<GenericApiResponse<UserPaypalRefundResponse>> PaypalRefund(UserPaypalRefundRequest userRequest);
    }
}
