﻿namespace THCC.Application.Models.Dtos
{
    public class FullfilmentDto
    {
        public string? AuditId { get; set; }
        public string? NewBalance { get; set; }
        public string? PinNumber { get; set; }
        public string? CardNumber { get; set; }
        public string? Newpoints { get; set; }

        public int ErrorCode { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
