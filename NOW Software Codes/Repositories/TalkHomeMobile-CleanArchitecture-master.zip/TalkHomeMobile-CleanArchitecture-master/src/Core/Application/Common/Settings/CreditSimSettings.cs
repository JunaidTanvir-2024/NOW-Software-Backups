﻿namespace Application.Common.Settings;

public class CreditSimSettings
{
    public const string SectionName = "CreditSimSettings";
    public static CreditSimSettings Bind = new CreditSimSettings();
    public bool UseValidMsisdnFromPool { get; set; }
}
