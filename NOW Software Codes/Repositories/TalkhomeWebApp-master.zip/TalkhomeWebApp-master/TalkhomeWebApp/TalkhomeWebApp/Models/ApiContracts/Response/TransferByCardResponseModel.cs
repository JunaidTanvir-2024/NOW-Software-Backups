﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class TransferByCardResponseModel
    {
        public TransferData transferData { get; set; }
        public ThreeDSecureData threeDSecureData { get; set; }
        public TransferProduct productData { get; set; }
    }
    public class TransferProduct
    {
        public string GUID { get; set; }
        public string fromCurrency { get; set; }
        public string toCurrency { get; set; }
        public string fromMsisdn { get; set; }
        public string tomsisdn { get; set; }
        public string toAmount { get; set; }
        public string fromAmount { get; set; }
        public string account { get; set; }
        public string CustomerChargeValue { get; set; }
        public string product { get; set; }
        public string operatorCountryName { get; set; }
        public string operatorLogoUrl { get; set; }
        public string operatorName { get; set; }
    }
    public class TransferData
    {
        public string TransactionId { get; set; }
        public string fromMsisdn { get; set; }
        public string fromAmount { get; set; }
        public string fromCurrency { get; set; }

        public string toMsisdn { get; set; }
        public bool shouldSave { get; set; }
        public string toAmount { get; set; }
        public string toCurrency { get; set; }

        public string fromCountry { get; set; }
        public string toCountry { get; set; }
        public PaymentMethodTypes PaymentMethod { get; set; }
        public string operatorName { get; set; }
    }

    public class ThreeDSecureData
    {
        public string redirectUrl { get; set; }
        public string returnUrl { get; set; }
        public string pareq { get; set; }
        public string transactionId { get; set; }
        public string clientRedirectType { get; set; }
        public string threeDSServerTransId { get; set; }
    }
}
