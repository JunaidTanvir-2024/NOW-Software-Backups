﻿using Now.Models.Enums;


namespace Now.Models.Database;
public class DbNowSims
    {
        public string? Account { get; set; }
        public SimStauts Sim_current_state { get; set; }
        public SimStauts Sim_previous_state { get; set; }
    }

