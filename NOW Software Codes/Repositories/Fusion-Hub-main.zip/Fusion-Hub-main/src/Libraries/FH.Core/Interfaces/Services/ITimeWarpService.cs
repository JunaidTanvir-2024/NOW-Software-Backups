using FH.Core.DependencyResolver;

namespace FH.Core.Interfaces.Services;

public interface ITimeWarpService : ServiceType.IScoped
{
    DateTime UtcNow { get; }
}
