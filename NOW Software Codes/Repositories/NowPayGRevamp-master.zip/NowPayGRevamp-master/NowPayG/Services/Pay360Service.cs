﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NowPayG.Configurations;
using NowPayG.Models.Pay360ApiContracts;
using NowPayG.Models.ViewModels;
using NowPayG.Services.Interfaces;
using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http.Extensions;

namespace NowPayG.Services
{
    public class Pay360Service : IPay360Service
    {
        private readonly Pay360Config _Pay360Setting;

        public Pay360Service(IOptions<Pay360Config> Pay360Setting)
        {
            _Pay360Setting = Pay360Setting.Value;
        }

        public async Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Resume3DTransaction(Pay360Resume3DRequest request)
        {

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/Resume3DSecureTransaction";

            GenericPay360ApiResponse<Pay360PaymentResponse> ret = new GenericPay360ApiResponse<Pay360PaymentResponse>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360PaymentResponse>>(Result);

            return ret;

        }

        public async Task<GenericPay360ApiResponse<Pay360CardsResponse>> Pay360GetCards(Pay360CustomerRequestModel request)
        {
            GenericPay360ApiResponse<Pay360CardsResponse> ret = new GenericPay360ApiResponse<Pay360CardsResponse>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/GetCustomerPaymentMethodsByCustomerUniqueRef";

            var json = JsonConvert.SerializeObject(request);

            var Result = await Post(endpoint, json);

            if (Result == null)
            {
                return null;
            }

            //LoggerService.Debug(GetType(), Result);

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360CardsResponse>>(Result);

            return ret;
        }

        public async Task<GenericPay360ApiResponse<Pay360CustomerModel>> GetCustomer(Pay360CustomerRequestModel model)
        {

            GenericPay360ApiResponse<Pay360CustomerModel> ret = new GenericPay360ApiResponse<Pay360CustomerModel>();

            string endpoint = "";

            endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/GetCustomerByCustomerUniqueRef";

            var Json = JsonConvert.SerializeObject(model);

            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360CustomerModel>>(Result);

            return ret;


        }

        public async Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType)
        {
            GenericPay360ApiResponse<Pay360PaymentResponse> ret = new GenericPay360ApiResponse<Pay360PaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";

            switch (paymentType)
            {
                case Pay360PaymentType.New:
                    endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/NewCustomerPayment";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestNew);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.Default:
                    endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/ExistingCustomerPaymentDefaultCard";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestDefault);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.ExistingNew:
                    endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/ExistingCustomerPaymentNewCard";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestExistingNew);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.Token:
                    endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CashierApi/PaymentToken";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestToken);
                    Result = await Post(endpoint, Json);
                    break;
            }
            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360PaymentResponse>>(Result);
            return ret;

        }

        public Pay360PaymentRequestToken CreatePay360PaymentRequestToken(Pay360ViewModel model)
        {
            Pay360PaymentRequestToken result = new Pay360PaymentRequestToken
            {
                cardCv2 = model.UserCard.SecurityCode,
                customerMsisdn = model.Msisdn,
                isAuthorizationOnly = _Pay360Setting.IsAuthorization,
                transactionAmount = model.Amount,
                transactionCurrency = Currency.GBP.ToString(),
                do3DSecure = _Pay360Setting.Do3DSecure,
                cardToken = model.UserCard.Token,
                isDirectFullfilment = _Pay360Setting.IsDirectFullfilment

            };

            return result;
        }

        public Pay360PaymentBase CreatePay360PaymentBaseRequest(StartPay360ViewModel model)
        {
            Pay360PaymentBase result = new Pay360PaymentBase
            {
                cardCv2 = model.CardCv2,
                customerMsisdn = model.Msisdn,
                isAuthorizationOnly = _Pay360Setting.IsAuthorization,
                transactionAmount = model.Amount,
                transactionCurrency = model.Currency,
                do3DSecure = _Pay360Setting.Do3DSecure,
                isDirectFullfilment = _Pay360Setting.IsDirectFullfilment
            };

            return result;
        }

        public Pay360PaymentRequestExistingNew CreatePay360PaymentRequestExistingNew(Pay360ViewModel model)
        {
            Pay360PaymentRequestExistingNew result = new Pay360PaymentRequestExistingNew
            {

                cardCv2 = model.UserCard.SecurityCode,
                cardExpiryDate = model.UserCard.ExpiryMonth + model.UserCard.ExpiryYear,
                cardPan = model.UserCard.CardNumber,
                customerMsisdn = model.Msisdn,
                isAuthorizationOnly = _Pay360Setting.IsAuthorization,
                isDirectFullfilment = _Pay360Setting.IsDirectFullfilment,
                isDefaultCard = false,
                do3DSecure = _Pay360Setting.Do3DSecure,
                transactionAmount = model.Amount,
                transactionCurrency = Currency.GBP.ToString(),
                customerName = model.UserCard.NameOnCard,
                billingAddress = new billingAddress
                {
                    line1 = model.AddressL1,
                    line2 = model.AddressL2,
                    line3 = model.AddressL3,
                    line4 = model.AddressL4,
                    region = model.Region,
                    city = model.City,
                    postcode = model.PostCode,
                    countryCode = model.UserCard.SelectedCountry
                }
            };

            return result;
        }

        public Pay360PaymentRequestNew CreatePay360PaymentRequestNew(Pay360ViewModel model)
        {
            Pay360PaymentRequestNew result = new Pay360PaymentRequestNew
            {
                customerName = model.UserCard.NameOnCard,
                cardCv2 = model.UserCard.SecurityCode,
                cardExpiryDate = model.UserCard.ExpiryMonth + model.UserCard.ExpiryYear,
                cardPan = model.UserCard.CardNumber,
                customerMsisdn = model.Msisdn,
                isDirectFullfilment = _Pay360Setting.IsDirectFullfilment,
                isAuthorizationOnly = _Pay360Setting.IsAuthorization,
                isDefaultCard = true,
                do3DSecure = _Pay360Setting.Do3DSecure,
                transactionAmount = model.Amount,
                transactionCurrency = Currency.GBP.ToString(),
                billingAddress = new billingAddress
                {
                    line1 = model.AddressL1,
                    line2 = model.AddressL2,
                    line3 = model.AddressL3,
                    line4 = model.AddressL4,
                    region = model.Region,
                    city = model.City,
                    postcode = model.PostCode,
                    countryCode = model.UserCard.SelectedCountry
                }
            };
            if (_Pay360Setting.IsCustomerAddressCopy == true)
            {
                result.customerBillingAddress = result.billingAddress;
            }

            return result;
        }

        public async Task<GenericPay360ApiResponse<string>> SetAutoTopUp(Pay360SetAutoTopUpRequest model)
        {

            GenericPay360ApiResponse<string> ret = new GenericPay360ApiResponse<string>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/SetAutoTopup";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<string>>(Result);
                return ret;
            }

            return ret;

        }

        public async Task<GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(Pay360GetAutoTopUpRequest model)
        {

            GenericPay360ApiResponse<Pay360GetAutoTopUpResponse> ret = new GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/GetAutoTopup";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>>(Result);
                return ret;
            }

            return ret;

        }

        public async Task<GenericPay360ApiResponse<paymentMethodResponse>> SetCustomerDefaultCard(SetCustomerDefaultCardRequest model)
        {

            GenericPay360ApiResponse<paymentMethodResponse> ret = new GenericPay360ApiResponse<paymentMethodResponse>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/SetCustomerDefaultCard";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<paymentMethodResponse>>(Result);
                return ret;
            }

            return ret;

        }

        public async Task<GenericPay360ApiResponse<string>> RemoveCard(RemoveCardRequest model)
        {

            GenericPay360ApiResponse<string> ret = new GenericPay360ApiResponse<string>();

            string endpoint = _Pay360Setting.Pay360ApiEndpoint + "Pay360CommonServices/RemoveCard";

            if (model != null)
            {
                var Json = JsonConvert.SerializeObject(model);

                var Result = await Post(endpoint, Json);

                if (Result == null)
                {
                    return null;
                }

                ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<string>>(Result);
                return ret;
            }

            return ret;

        }

        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address), Timeout = TimeSpan.FromSeconds(60) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                    {
                        throw new WebException();
                    }

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch(Exception ex)
            {
                return null;
            }
        }
    }
}
