﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using THCC.Api.Controllers.Common;
using THCC.Application.Features.Address;
using THCC.Application.Features.Country;
using THCC.Application.Models.Dtos;

namespace THCC.Api.Controllers;

[AllowAnonymous]
public class AddressController : BaseApiController
{
    [HttpGet("{postcode}")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AddressDto))]
    public async Task<IActionResult> GetAddress([FromRoute] string postcode, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(new GetAddressRequest() { PostCode = postcode }, cancellationToken));
    }

    [HttpGet("country")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CountryDetailsDto))]
    public async Task<IActionResult> GetCountries(CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(new CountryRequest(), cancellationToken));
    }
}
