﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeAPI.Enums
{
    public enum Pay360PaymentType
    {
        New,
        Default,
        Token,
        ExistingNew
    }
}
