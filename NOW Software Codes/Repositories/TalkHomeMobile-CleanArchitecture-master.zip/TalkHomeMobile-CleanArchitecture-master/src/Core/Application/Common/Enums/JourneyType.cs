﻿
namespace Application.Common.Enums;
public enum JourneyType
{
    FreeSim = 1,
    PlanFreeSim = 2,
    TopupFreeSim = 3,
    MyPlan = 4,
    FastBuy = 5,
    MyTopup = 6,
    FastTopup = 7,
    SimLandingPage = 8,
    SimOrderingLandingPage = 9,
    CreditSim
}
