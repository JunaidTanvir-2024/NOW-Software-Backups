﻿using Newtonsoft.Json;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts.Paypal.Response.User
{
    public class UserPaypalRefundResponse
    {
        [JsonProperty("customerId")]
        public string CustomerId { get; set; }
        [JsonProperty("transactionId")]
        public string TransactionId { get; set; }
        [JsonProperty("relatedTransactionId")]
        public string RelatedTransactionId { get; set; }

        [JsonProperty("transactionAmount")]
        public string TransactionAmount { get; set; }

        [JsonProperty("outcome")]
        public OutcomeModel OutcomeModel { get; set; }

    }
}
