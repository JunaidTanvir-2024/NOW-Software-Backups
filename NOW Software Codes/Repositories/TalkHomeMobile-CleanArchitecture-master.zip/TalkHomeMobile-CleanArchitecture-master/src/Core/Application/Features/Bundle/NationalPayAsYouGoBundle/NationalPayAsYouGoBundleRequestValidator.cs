namespace Application.Features.Bundle.NationalPayAsYouGoBundle;

public sealed class NationalPayAsYouGoBundleRequestValidator : AbstractValidator<NationalPayAsYouGoBundleRequest>
{
    public NationalPayAsYouGoBundleRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
    }
}
