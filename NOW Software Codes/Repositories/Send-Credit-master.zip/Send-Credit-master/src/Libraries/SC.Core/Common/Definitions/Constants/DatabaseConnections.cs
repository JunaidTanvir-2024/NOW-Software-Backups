﻿namespace SC.Core.Common.Definitions.Constants;
public static partial class AppConstants
{
    public static class DatabaseConnections
    {
        public const string SendCredit = "SendCredit";
        public const string MessageBroker = "MessageBroker";
    }

    public static class TableTypes
    {
        public const string StatusUpdateType = "dbo.StatusTableType";

    }
}

