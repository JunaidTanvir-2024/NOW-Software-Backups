﻿

namespace Application.Features.Payment.Models;
public class PaymentEarlyTerminationChargesInfo
{
    public string BundleGuidId { set; get; }


    public double EarlyTerminationAmount { set; get; }
    public int SubscriberBundleId { set; get; }
}
