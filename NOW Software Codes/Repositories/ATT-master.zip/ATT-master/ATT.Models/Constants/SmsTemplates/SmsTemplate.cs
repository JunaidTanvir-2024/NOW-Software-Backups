﻿namespace ATT.Models.Constants.SmsTemplates
{
    public static class SmsTemplate
    {
        public static string FundsTransfered = "You've been sent a top-up of £{AmountTransfered} using Talk Home App. Your PIN is {PinCode}. If you don't know how to redeem this voucher, contact your provider.";
    }
}
