﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Request
{
    public class ChangePasswordRequestModel
    {
        public string NewPassword { get; set; }
        public string OldPassword { get; set; }
        public int UserID { get; set; }
    }
}
