﻿using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;

namespace Application.Features.Payment.Paypal.CreateSale;
public class PaypalCreateSalePaymentRequest : IRequest<Result<PaypalResponse>>
{
    public string? Msisdn { get; set; }
   

    public PaymentTopupInfo? TopupInfo { get; set; }

    public PaymentBundleInfo? BundleInfo { get; set; }

    //public PaymentCreditSimInfo? CreditSimInfo { get; set; }

    [JsonIgnore]
    public string? Email { get; set; }

    [JsonIgnore]
    public string? IpAddress { get; set; }

}
