﻿using System.Net;

namespace SC.Api;
public class ApiGenericResponse
{
    public int Code { get; set; } = default(int);
    public string Message { get; set; } = default!;
}

