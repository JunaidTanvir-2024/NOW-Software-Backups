﻿using Application.Common.Interfaces.Infrastructure.Identity;

namespace Application.Features.Identity.Signup.SignupConfirm;
internal class SignupConfirmRequestHandler : IRequestHandler<SignupConfirmRequest, Result<TokenResponse>>
{
    private readonly IOtpService _otpService;
    private readonly IStringLocalizer<TokenResponse> _localizer;
    private readonly ICommonService _commonService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly ITokenService _tokenService;
    private readonly IAirshipService _airshipService;

    public SignupConfirmRequestHandler(
        IOtpService otpService,
        IStringLocalizer<TokenResponse> localizer,
        ICommonService commonService,
        IUnitOfWork unitOfWork,
        IMapper mapper,
        ITokenService tokenService,
        IAirshipService airshipService
       )
    {
        _otpService = otpService;
        _localizer = localizer;
        _commonService = commonService;
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _tokenService = tokenService;
        _airshipService = airshipService;
    }

    public async Task<Result<TokenResponse>> Handle(SignupConfirmRequest request, CancellationToken cancellationToken)
    {
        request.UserInfo.Msisdn = _commonService.FormatMsisdn(request.UserInfo.Msisdn);
          (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();

        //Check for any type of deactivation

        //get user by email
        var userResponse = await _unitOfWork.UserRepo.GetUserByEmail(request.UserInfo.Email);
        if (userResponse != null)
        {
            return Result<TokenResponse>.Failure(_localizer[CustomStatusKey.EmailAlreadyRegistered],
                  CustomStatusCode.EmailAlreadyRegistered);
        }
        //Is valid msisdn
        var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.UserInfo.Msisdn);
        if (msisdnDetails == null)
        {
            return Result<TokenResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Check if msisdn already attached
        if (await _unitOfWork.UserRepo.IsProductAlreadyAttached(request.UserInfo.Msisdn))
        {
            return Result<TokenResponse>.Failure(_localizer[CustomStatusKey.MsisdnAlreadyRegistered], CustomStatusCode.MsisdnAlreadyRegistered);
        }

        //Validate Email Otp
        var emailOtpResponse = await _otpService.IsValidOtp(
            request.UserInfo.Email, request.OtpInfo.EmailOtp, OtpType.SignUp);
        if (emailOtpResponse.Code == (int) CustomStatusCode.InvalidOtp)
        {
            return Result<TokenResponse>.Failure(
                null!, _localizer[CustomStatusKey.InvalidOtp], CustomStatusCode.InvalidOtp);
        }

        //Validate Msisdn Otp
        var msisdnOtpResponse = await _otpService.IsValidOtp(request.UserInfo.Msisdn, request.OtpInfo.MsisdnOtp, OtpType.SignUp);
        if (msisdnOtpResponse.Code == (int) CustomStatusCode.InvalidOtp)
        {
            return Result<TokenResponse>.Failure(
                null!, _localizer[CustomStatusKey.InvalidOtp], CustomStatusCode.InvalidOtp);
        }

        //Get Msisdn Info
        var msisdnInfo = await _unitOfWork.UserRepo.GetMsisdnDetail(request.UserInfo.Msisdn);
        if (msisdnInfo == null)
        {
            return Result<TokenResponse>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //User data
        var confirmSignupRequest = _mapper.Map<User>(request);

        //User product data
        var userProduct = new UserProduct() { AccountId = msisdnInfo.AccountId!, Msisdn = request.UserInfo.Msisdn };

        //Register user
        userResponse = await _unitOfWork.UserRepo.RegisterCompleteUser(
            confirmSignupRequest,
            userProduct,
            request.OtpInfo.MsisdnOtp,
            request.OtpInfo.EmailOtp,
            MediumType);

        if (IsAppRequest)
        {
            //Save Device Info
            var userDeviceLog = _mapper.Map<UserDeviceLog>(request.AppInfo);
            userDeviceLog.UserId = userResponse.Id;
            await _unitOfWork.DeviceRepo.SaveDeviceLog(userDeviceLog);


            //Mark current device as active and confirmed for this user
            await _unitOfWork.DeviceRepo.SaveDeviceAsActiveAndConfirmed(
                request.AppInfo.DevicePersistentID, (DeviceType) deviceType!, userResponse.Id);

            //Register with email channel
            await _airshipService!.AddEmailChannelCommercial(request.UserInfo.Email);

            //Associate email with named user
            _airshipService.EmailAssociationWithNamedUser(request.UserInfo.Email, request.UserInfo.Email);
        }

        //Generate Otp
        var tokenData = await _tokenService.GetTokenAsync(userResponse, request.IpAddress!, cancellationToken);

        return Result<TokenResponse>.Success(tokenData, _localizer[CustomStatusKey.Success]);
        //return Result<User>.Success(signupResponse, _localizer[CustomStatusKey.Success]);
    }
}