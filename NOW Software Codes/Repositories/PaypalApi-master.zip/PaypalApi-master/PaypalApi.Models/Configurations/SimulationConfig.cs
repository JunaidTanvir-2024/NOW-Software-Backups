﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Configurations
{
    public class SimulationConfig
    {
        public bool SimulationMode { get; set; }
    }
}
