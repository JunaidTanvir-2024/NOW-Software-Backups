﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeAPI.Models.Pay360ApiContracts
{
    public class Pay360GetAutoTopUpRequest
    {
        public string Msisdn { get; set; }
        public string Email { get; set; }
        public string ProductCode { get; set; }
    }
}
