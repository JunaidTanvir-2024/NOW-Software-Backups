﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.User.ForgotPassword.ForgotPasswod;

public class ForgotPasswordRequest : IRequest<object>
{
    public string Email { get; set; } = default!;
}

public class ForgotPasswordRequestValidator : AbstractValidator<ForgotPasswordRequest>
{
    public ForgotPasswordRequestValidator(ICommonService commonService)
    {
        RuleFor(data => data.Email)
            .NotNull()
            .NotEmpty()
            .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
            .Must(p => commonService.IsValidEmailAddress(p))
            .WithMessage("Invalid email address");
    }
}
