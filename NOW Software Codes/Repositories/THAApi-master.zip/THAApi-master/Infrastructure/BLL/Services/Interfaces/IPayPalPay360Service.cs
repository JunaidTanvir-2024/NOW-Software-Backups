﻿using Models.Contracts.PaypalApiContracts;
using Models.Contracts.Response;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
	public interface IPayPalPay360Service
    {
        Task<GenericPay360ApiResponse<PayPalByPay360CSPaymentResponse>> PayPalByPay360CS(PayPalByPay360CSPaymentRequest request);
        Task<GenericPay360ApiResponse<PayPalByPay360ESPaymentResponse>> PayPalByPay360ES(PayPalByPay360ESPaymentRequest request);
        Task<GenericPayPalApiResponse<PaypalRefundResponse>> PaypalRefund(RefundFullPaymentRequestModel request);
    }
}
