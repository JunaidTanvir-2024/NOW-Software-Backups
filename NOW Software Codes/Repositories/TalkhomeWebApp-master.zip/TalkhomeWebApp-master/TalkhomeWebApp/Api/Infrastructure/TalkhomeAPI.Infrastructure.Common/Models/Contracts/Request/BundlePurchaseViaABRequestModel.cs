﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class BundlePurchaseViaABRequestModel
    {
        [Required]
        [MaxLength(300)]
        public string BundleId { get; set; }

        [Required(ErrorMessage = "Enter email address"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [EmailAddress(ErrorMessage = "Email is invalid")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Email is invalid")]
        public string EmailAddress { get; set; }
        public string IpAddress { get; set; }

        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }
    }
}
