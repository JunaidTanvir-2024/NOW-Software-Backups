using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

public class VoucherSubjectList
{
    [JsonPropertyName("object")]
    public string? Object { get; set; }

    [JsonPropertyName("data")]
    public List<VoucherSubject>? Entries { get; set; }
}
