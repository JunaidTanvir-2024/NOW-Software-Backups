﻿namespace Application.Features.Account.History.Models;
public class DataHistoryResponse
{
    public IEnumerable<DataHistoryInfo> History { get; set; } = new List<DataHistoryInfo>();
    public int TotalCount { get; set; }
    public int RecordsFiltered { get; set; }
    public int PageNo { get; set; }
}
