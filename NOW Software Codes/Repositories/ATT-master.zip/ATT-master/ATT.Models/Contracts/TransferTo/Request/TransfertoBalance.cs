﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Request
{
    public class TransfertoBalance : TransfertoBaseRequest
    {
        public string action = "check_wallet";

        public string toXML()
        {
            return "<TransferTo>" + base.toXML() + $"<action>{action}</action></TransferTo>";
        }
    }
}
