using System.Text.Json;

using Voucherify.Core.Commons.Converters;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Core.Commons.Extensions;

public static class JsonSerializerExtensions
{
    public static T? Deserialize<T>(this JsonSerializerOptions options, string json)
    {
        return JsonSerializer.Deserialize<T>(json, options);
    }

    public static T? Deserialize<T>(string json)
    {
        return JsonSerializer.Deserialize<T>(json, GetVoucherifyOptions());
    }

    private static JsonSerializerOptions GetVoucherifyOptions()
    {
        var options = new JsonSerializerOptions();
        options.Converters.Add(new EnumConverter<VoucherType>());
        options.Converters.Add(new EnumConverter<OrderStatus>());
        options.Converters.Add(new EnumConverter<DiscountType>());
        options.Converters.Add(new EnumConverter<DiscountEffect>());
        options.Converters.Add(new EnumConverter<RedemptionResult>());
        options.Converters.Add(new EnumConverter<CampaignExtensionType>());
        options.Converters.Add(new EnumConverter<CampaignType>());
        options.Converters.Add(new EnumConverter<CampaignVoucherGenerationStatus>());
        options.Converters.Add(new EnumConverter<FailureCode>());
        options.Converters.Add(new EnumConverter<RewardType>());
        return options;
    }
}
