using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Services;

public interface IJsonSerilizerService : ServiceType.IScoped
{
    T? Deserialize<T>(string text);
    string Serialize<T>(T obj);
    string Serialize<T>(T obj, Type type);
}