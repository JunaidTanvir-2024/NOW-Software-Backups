﻿namespace Application.Features.Account;

public class MsisdnInfo
{
    public string? FirstDate { get; set; }
    public string? LastTopUpDate { get; set; }
    public decimal LastTopUpAmount { get; set; }
    public decimal Credit { get; set; }
    public string CurrencySymbol { get; set; } = Common.Models.CurrencySymbol.GBP;
}
