﻿

namespace Application.Common.Interfaces;
public interface IDiscountService : ISerivcesType.ITransientService
{
     float GetDiscount(DateTime? lasttopupdate, float topupAmount, CheckOutType checkOutTypes);
}
