﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Airship;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public interface IAirShipService
    {
        public bool IsActive { get; }
        public string PaymentTagGroupName { get; }
        public string CustomerTagGroupName { get; }
        public string ActivityTagGroupName { get; }
        public string TransactionTagGroupName { get; }
        public string ServiceTagGroupName { get; }
        Task<GenericAirShipApiResponse<string>> RemoveNamedUserTags(NamedUserTagsRequest request);
        Task<GenericAirShipApiResponse<string>> AddNamedUserTags(NamedUserTagsRequest request);
        //Task<GenericAirShipApiResponse<string>> AddCustomEvent(CustomEventsRequest request);
        Task AddCustomEvent(CustomEventsRequest data);
        Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress);
        Task AddEmailChannel(string emailAddress);
        Task DisassociateEmailChannelFromNamedUser(string namedUserId, string emailAddress);
        Task AddEmailChannelCommercial(string emailAddress);
        Task RemoveEmailChannelCommercial(string emailAddress);
        Task HandleIntTopupTagsAndEvents(IntTopupInfoAirShip info);
        Task HandleBundleTagsAndEvents(BundleInfoAirShip info);
        Task HandleTopupTagsAndEvents(TopupInfoAirship info);
        Task HandleAutoTopup(string msisdn, bool IsActive);
        Task HandlePaymentMethodTag(string msisdn, bool IsActive);
        Task HandleSignUpTagsAndEvents(string msisdn, bool MailSubscription);
        Task HandleMailTagsAndEvents(string msisdn, bool MailSubscription);
    }

    public class AirShipService : IAirShipService
    {
        private List<string> transactionTags;
        private readonly string AirShipApiEndpoint;
        private readonly ILogger Logger;

        public bool IsActive { get; }
        public string PaymentTagGroupName { get; }
        public string CustomerTagGroupName { get; }
        public string ActivityTagGroupName { get; }
        public string TransactionTagGroupName { get; }
        public string ServiceTagGroupName { get; }


        public AirShipService(ILogger logger, IOptions<AirShipConfig> appConfig)
        {
            Logger = logger;
            AirShipApiEndpoint = appConfig.Value.AirShipApiEndpoint;
            IsActive = appConfig.Value.IsActive;
            PaymentTagGroupName = appConfig.Value.PaymentTagGroupName;
            CustomerTagGroupName = appConfig.Value.CustomerTagGroupName;
            TransactionTagGroupName = appConfig.Value.TransactionTagGroupName;
            ServiceTagGroupName = appConfig.Value.ServiceTagGroupName;
            ActivityTagGroupName = appConfig.Value.ActivityTagGroupName;
        }

        public async Task<GenericAirShipApiResponse<string>> RemoveNamedUserTags(NamedUserTagsRequest request)
        {
            GenericAirShipApiResponse<string> ret = new GenericAirShipApiResponse<string>();
            string endpoint = AirShipApiEndpoint + "NamedUser/RemoveNuserTags";
            var json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, json);
            if (Result == null)
            {
                Logger.Error($"Controller: AirShipService, Method: RemoveNamedUserTags, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:null ");
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericAirShipApiResponse<string>>(Result);

            if (ret.errorCode != 0)
            {
                Logger.Error($"Controller: AirShipService, Method: RemoveNamedUserTags, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:{Result} ");
            }

            return ret;
        }
        public async Task<GenericAirShipApiResponse<string>> AddNamedUserTags(NamedUserTagsRequest request)
        {
            string endpoint = AirShipApiEndpoint + "NamedUser/AddNuserTags";

            GenericAirShipApiResponse<string> ret = new GenericAirShipApiResponse<string>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                Logger.Error($"Controller: AirShipService, Method: AddNamedUserTags, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:null ");
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericAirShipApiResponse<string>>(Result);

            if (ret.errorCode != 0)
            {
                Logger.Error($"Controller: AirShipService, Method: AddNamedUserTags, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:{Result} ");
            }

            return ret;
        }

        //public async Task<GenericAirShipApiResponse<string>> AddCustomEvent(CustomEventsRequest request)
        //{
        //    try
        //    {
        //        string endpoint = AirShipApiEndpoint + "CustomEvent/AddCustomEvent";

        //        GenericAirShipApiResponse<string> ret = new GenericAirShipApiResponse<string>();

        //        var Json = JsonConvert.SerializeObject(request);
        //        var Result = await Post(endpoint, Json);

        //        if (Result == null)
        //        {
        //            Logger.Error($"Controller: AirShipService, Method: AddCustomEvent, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:null ");
        //            return null;
        //        }

        //        ret = JsonConvert.DeserializeObject<GenericAirShipApiResponse<string>>(Result);
        //        if (ret.errorCode != 0)
        //        {
        //            Logger.Error($"Controller: AirShipService, Method: AddCustomEvent, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:{Result} ");
        //        }

        //        return ret;
        //    }
        //    catch (Exception ex)
        //    {
        //        string a =ex.ToString();
        //        return "";
        //        //throw;
        //    }

        //}

        public async Task AddCustomEvent(CustomEventsRequest data)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "CustomEvent/AddCustomEvent")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "NamedUser/EmailAssociationWithNamedUser")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        EmailAddress = emailAddress,
                        NamedUserId = namedUserId,
                        ProductCode = "THA"
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task AddEmailChannel(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THA"
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task AddEmailChannelCommercial(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THA",
                        commercialOptedIn = DateTime.UtcNow
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task RemoveEmailChannelCommercial(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THA",
                        commercialOptedOut = DateTime.UtcNow
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DisassociateEmailChannelFromNamedUser(string namedUserId, string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, AirShipApiEndpoint + "NamedUser/DisassociateEmailChannelFromNamedUser")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        EmailAddress = emailAddress,
                        NamedUserId = namedUserId,
                        ProductCode = "THA"
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task HandleIntTopupTagsAndEvents(IntTopupInfoAirShip info)
        {
            try
            {
                if (!IsActive) return;

                transactionTags = new List<string>();

                var customEventRequest = new CustomEventsRequest()
                {
                    ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                    ChannelIdentifierValue = info.Msisdn,
                    InteractionType = "URL",
                    InteractionId = info.IsCard.HasValue ? info.IsCard.Value ? "IntTopup/Card" : "IntTopup/Paypal" : "IntTopup/AccountBalance"
                };

                string paymentMethod = "";
                if (info.IsCard.HasValue)
                {
                    if (info.IsCard.Value)
                    {
                        paymentMethod = "card";
                    }
                    else
                    {
                        paymentMethod = "paypal";
                    }
                }
                else
                {
                    paymentMethod = "balance";
                }

                if (!string.IsNullOrEmpty(info.Origination))
                    info.Origination = info.Origination.ToLower().Trim();
                if (!string.IsNullOrEmpty(info.Destination))
                    info.Destination = info.Destination.ToLower().Trim();

                if (info.IsSuccess)
                {
                    if (info.IsCard == true)
                    {
                        if (info.SaveCard)
                        {
                            await HandlePaymentMethodTag(info.Msisdn, true);
                        }
                    }

                    if (info.IsCard == null) // Cards Payment
                    {
                        if (info.RemainingBalance < 1)
                        {
                            customEventRequest.CustomEventName = $"acc_bal_low_web";
                            await this.AddCustomEvent(customEventRequest);
                        }
                    }

                    customEventRequest.CustomEventName = $"inttop_dest_{info.Destination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"inttop_orig_{info.Origination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"inttop_{paymentMethod}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"inttop_any_{info.Origination}_to_{info.Destination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    transactionTags = new List<string>();

                    transactionTags.Add("inttop_web");
                    transactionTags.Add($"inttop_orig_{info.Origination}_web");
                    transactionTags.Add($"inttop_dest_{info.Destination}_web");
                    transactionTags.Add($"inttop_{info.Origination}_to_{info.Destination}_web");

                }
                else
                {
                    customEventRequest.CustomEventName = $"inttop_failure_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"inttopfail_any_{info.Origination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"inttopfail_{paymentMethod}_web";
                    await this.AddCustomEvent(customEventRequest);
                }

                if (transactionTags.Count > 0)
                {
                    await this.AddNamedUserTags(
                          new NamedUserTagsRequest()
                          {
                              NamedUser = info.Msisdn,
                              Tags = transactionTags,
                              TagGroup = TransactionTagGroupName
                          });
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //Logger.Error($"Class: AirshipService, Method: HandleIntTopupTagsAndEvents, " +
                //             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }

        public async Task HandleBundleTagsAndEvents(BundleInfoAirShip info)
        {
            try
            {
                if (!IsActive) return;

                var transactionTags = new List<string>();

                var customEventRequest = new CustomEventsRequest()
                {
                    ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                    ChannelIdentifierValue = info.Msisdn,
                    InteractionType = "URL",
                    Value=Convert.ToDouble(info.Amount),
                    InteractionId = info.IsCard.HasValue ? info.IsCard.Value ? "Bundle/Card" : "Bundle/Paypal" : "Bundle/AccountBalance"
                };

                if (!string.IsNullOrEmpty(info.Origination))
                    info.Origination = info.Origination.ToLower().Trim();
                if (!string.IsNullOrEmpty(info.Destination))
                    info.Destination = info.Destination.ToLower().Trim();

                if (info.IsSuccess)
                {
                    if (info.IsCard == true)
                    {
                        if (info.SaveCard)
                        {
                            await HandlePaymentMethodTag(info.Msisdn, true);
                        }
                    }
                    transactionTags = new List<string>();

                    string bundleType = "";
                    switch (info.BundleType)
                    {
                        case (int)BundleType.Welcome:
                            bundleType = "welcome";
                            break;
                        case (int)BundleType.Monthly:
                            bundleType = "roll";
                            break;
                        case (int)BundleType.PAYG:
                            bundleType = "payg";
                            break;
                        case (int)BundleType.Trial:
                            bundleType = "trial";
                            break;
                        default:
                            break;
                    }
                    string paymentMethod = "";
                    if (info.IsCard.HasValue)
                    {
                        if (info.IsCard.Value)
                        {
                            paymentMethod = "card";
                        }
                        else
                        {
                            paymentMethod = "paypal";
                        }
                    }
                    else
                    {
                        paymentMethod = "balance";
                    }

                    customEventRequest.CustomEventName = "bun_any_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"bun_{bundleType}_any_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"bun_dest_any_{info.Destination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"bun_orig_any_{info.Origination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"bun_dest_{bundleType}_{info.Destination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"bun_orig_{bundleType}_{info.Origination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"bun_any_{info.Origination}_{info.Destination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"bun_{bundleType}_{info.Origination}_{info.Destination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"bun_{bundleType}_{paymentMethod}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"bun_{bundleType}_{info.Origination}_{info.Destination}_{paymentMethod}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"bun_{paymentMethod}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"view_bun_buy_via_{paymentMethod}_web";
                    await this.AddCustomEvent(customEventRequest);

                    transactionTags.Add($"bundle_web");
                    transactionTags.Add($"bun_any_web");
                    transactionTags.Add($"bun_{bundleType}_any_web");
                    transactionTags.Add($"bun_dest_any_{info.Destination}_web");
                    transactionTags.Add($"bun_orig_any_{info.Origination}_web");
                    transactionTags.Add($"bun_dest_{bundleType}_{info.Destination}_web");
                    transactionTags.Add($"bun_orig_{bundleType}_{info.Origination}_web");
                    transactionTags.Add($"bun_{bundleType}_{info.Origination}_{info.Destination}_web");
                    transactionTags.Add($"bun_{bundleType}_{paymentMethod}_web");
                    transactionTags.Add($"bun_{bundleType}_{info.Origination}_{info.Destination}_{paymentMethod}_web");
                    transactionTags.Add($"bun_{paymentMethod}_web");

                    if (info.IsCard == null) // Balance Payment
                    {
                        if (info.RemainingBalance < 1)
                        {
                            customEventRequest.CustomEventName = $"acc_bal_low_web";
                            await this.AddCustomEvent(customEventRequest);
                        }
                    }
                }

                if (transactionTags.Count > 0)
                {
                    await this.AddNamedUserTags(
                          new NamedUserTagsRequest()
                          {
                              NamedUser = info.Msisdn,
                              Tags = transactionTags,
                              TagGroup = TransactionTagGroupName
                          });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task HandleTopupTagsAndEvents(TopupInfoAirship info)
        {
            try
            {
                if (!IsActive) return;

                transactionTags = new List<string>();

                if (info.IsCard == true)
                {
                    if (info.IsAutoTopUp)
                    {
                        await HandleAutoTopup(info.Msisdn, true);
                    }
                }

                var customEventRequest = new CustomEventsRequest()
                {
                    ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                    ChannelIdentifierValue = info.Msisdn,
                    InteractionType = "URL",
                    Value=Convert.ToDouble(info.Amount),
                    InteractionId = info.IsCard.HasValue ? info.IsCard.Value ? "Topup/Card" : "Topup/Paypal" : "Topup/Voucher"
                };

                string paymentMethod = "";
                if (info.IsCard.HasValue)
                {
                    if (info.IsCard.Value)
                    {
                        paymentMethod = "card";
                    }
                    else
                    {
                        paymentMethod = "paypal";
                    }
                }
                else
                {
                    paymentMethod = "voucher";
                }

                if (!string.IsNullOrEmpty(info.Origination))
                    info.Origination = info.Origination.ToLower().Trim();
                
                if (info.IsSuccess)
                {
                    if (info.IsCard == true)
                    {
                        if (info.SaveCard)
                        {
                            await HandlePaymentMethodTag(info.Msisdn, true);
                        }
                    }

                    customEventRequest.CustomEventName = $"topup_success_{paymentMethod}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"topup_any_{info.Origination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"topup_any_{info.Origination}_{paymentMethod}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"topup_{info.Amount}_{info.Origination}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"topup_{info.Amount}_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"topup_any_web";
                    await this.AddCustomEvent(customEventRequest);

                    transactionTags = new List<string>();
                    transactionTags.Add("topup_web");


                }
                else
                {
                    customEventRequest.CustomEventName = $"topup_payfail_{paymentMethod}_web";
                    await this.AddCustomEvent(customEventRequest);

                    //customEventRequest.CustomEventName = $"topup_failure_{paymentMethod}_web";
                    //await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"topup_payfail_any_web";
                    await this.AddCustomEvent(customEventRequest);

                    customEventRequest.CustomEventName = $"topup_payfail_any_{info.Origination}_web";
                    await this.AddCustomEvent(customEventRequest);
                }

                if (transactionTags.Count > 0)
                {
                    await this.AddNamedUserTags(
                          new NamedUserTagsRequest()
                          {
                              NamedUser = info.Msisdn,
                              Tags = transactionTags,
                              TagGroup = TransactionTagGroupName
                          });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task HandleAutoTopup(string msisdn, bool isActive)
        {
            if (!IsActive) return;

            transactionTags = new List<string>();
            //Handle Airship Events
            var eventReq = new NamedUserTagsRequest()
            {
                NamedUser = msisdn,
                Tags = new List<string>() { "autotopup_web" },
                TagGroup = ActivityTagGroupName,
            };

            if (isActive)
                await this.AddNamedUserTags(eventReq);
            else
                await this.RemoveNamedUserTags(eventReq);
        }
        public async Task HandleSignUpTagsAndEvents(string msisdn, bool MailSubscription)
        {
            if (!IsActive) return;

            transactionTags = new List<string>();

            transactionTags.Add("signup_web");
            transactionTags.Add("email_web");

            if (MailSubscription)
            {
                transactionTags.Add("allow_notification_web");
            }
            //Handle Airship Events
            var eventReq = new NamedUserTagsRequest()
            {
                NamedUser = msisdn,
                Tags = transactionTags,
                TagGroup = ActivityTagGroupName,
            };

            await this.AddNamedUserTags(eventReq);
        }

        public async Task HandleMailTagsAndEvents(string msisdn, bool MailSubscription)
        {
            if (!IsActive) return;
            transactionTags = new List<string>();

            transactionTags.Add("email_web");
            //Handle Airship Events
            var eventReq = new NamedUserTagsRequest()
            {
                NamedUser = msisdn,
                Tags = transactionTags,
                TagGroup = ActivityTagGroupName,
            };

            await this.AddNamedUserTags(eventReq);

            transactionTags = new List<string>();

            transactionTags.Add("allow_notification_web");


            //Handle Airship Events
            eventReq = new NamedUserTagsRequest()
            {
                NamedUser = msisdn,
                Tags = transactionTags,
                TagGroup = ActivityTagGroupName,
            };

            if (MailSubscription)
                await this.AddNamedUserTags(eventReq);
            else
                await this.RemoveNamedUserTags(eventReq);
        }

        public async Task HandlePaymentMethodTag(string msisdn, bool isActive)
        {
            if (!IsActive) return;

            transactionTags = new List<string>();
            //Handle Airship Events
            var eventReq = new NamedUserTagsRequest()
            {
                NamedUser = msisdn,
                Tags = new List<string>() { "addcard_web" },
                TagGroup = ActivityTagGroupName,
            };

            if (isActive)
                await this.AddNamedUserTags(eventReq);
            else
                await this.RemoveNamedUserTags(eventReq);
        }
        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                        throw new WebException();

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch
            {
                return null;
            }
        }
    }
}
