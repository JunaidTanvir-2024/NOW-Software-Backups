﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SmsOutReachCallBackUrlApi.Models.Connections
{
    public class DbConnectionSettings : IDbConnectionSettings
    {

        public IDbConnection SqlConnection { get; }


        public DbConnectionSettings(IDbConnection connection)
        {
            //SqlConnection = new SqlConnection(connection.SqlConnection);
            SqlConnection = connection;
        }

    }
}
