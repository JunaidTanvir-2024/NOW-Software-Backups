﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Response
{
    public class UKRateResponseModel
    {
        public int Id { get; set; }
        public float Landline { get; set; }
        public float Data { get; set; }
        public float Mobile { get; set; }
        public float Text { get; set; }

        public int CreatedBy { get; set; }
        public int LastUpdatedBy { get; set; }
        public bool isActive { get; set; }
    }
}
