﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Now.Models.Configurations;

public class ConnectionStrings
{
    public static ConnectionStrings Bind = new ConnectionStrings();
    public string? DigiTalkNowMobileConnection { get; set; }
    public string? DefaultConnection { get; set; }
    public string? NowGeneral { get; set; }
}
