﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;

namespace Models.Contracts.Response
{
    public class JwtToken
    {
        public string token { get; set; }
        public string expiry { get; set; }
    }

    public class JwtTokenValidationResponse
    {
        public List<Claim> claims { get; set; }
        public bool isTokenValid { get; set; }
        public string ErrorMessage { get; set; }
    }
}
