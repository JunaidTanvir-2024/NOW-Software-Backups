﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class SaveClientCallRequest
    {
        public int callDurationSeconds { get; set; }
        public string callId { get; set; }
        public bool callSuccess { get; set; }
        public bool registration { get; set; }
        public string networkType { get; set; }
        public string publicIP { get; set; }
        public decimal? mos { get; set; }
        public string stackTrace { get; set; }
        public string hangUpReason { get; set; }
        public string deviceType { get; set; }
        public string deviceModel { get; set; }
        public string DeviceOS { get; set; }
        public string appVersion { get; set; }
        public string cpuArchitecture { get; set; }

        public string[] Logs { get; set; }

    }

    public class ClientCallLogsDetails
    {
        public string[] logs { get; set; }
    }
}
