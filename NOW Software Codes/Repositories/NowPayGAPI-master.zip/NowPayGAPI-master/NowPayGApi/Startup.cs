﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using NowPayGApi.Infrastructure.BLL.Implementation;
using NowPayGApi.Infrastructure.BLL.Interfaces;
using NowPayGApi.Infrastructure.DAL.Impelmentation;
using NowPayGApi.Infrastructure.DAL.Interfaces;
using NowPayGApi.Models.Configurations;
using Serilog;
using Swashbuckle.AspNetCore.Swagger;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace NowPayGApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
              .AddJwtBearer(options =>
              {
                  options.TokenValidationParameters = new TokenValidationParameters
                  {
                      ValidateIssuer = true,
                      ValidateAudience = true,
                      ValidateLifetime = true,
                      ValidateIssuerSigningKey = true,
                      ValidIssuer = Configuration.GetValue<string>("JwtIssuer"),
                      ValidAudience = Configuration.GetValue<string>("JwtAudience"),
                      IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration.GetValue<string>("JwtSecretKey")))
                  };
              });

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "NowPayG API", Version = "v1" });
                c.AddSecurityDefinition("Bearer", new ApiKeyScheme { In = "header", Description = "Please enter JWT with Bearer into field", Name = "Authorization", Type = "apiKey" });
                c.AddSecurityRequirement(new Dictionary<string, IEnumerable<string>> {
                { "Bearer", Enumerable.Empty<string>() }});
            });


            services.Configure<ConnectionString>(Configuration.GetSection("ConnectionStrings"));

            services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));

            services.Configure<RedirectUrls>(Configuration.GetSection("RedirectUrls"));

            services.Configure<TokensConfig>(Configuration.GetSection("TokensConfig"));

            services.Configure<OtpExpirationTimeConfig>(Configuration.GetSection("OtpExpirationTimeConfig"));

            services.Configure<AddressApiConfig>(Configuration.GetSection("AddressApiConfig"));

            services.Configure<SmtpConfig>(options => Configuration.GetSection("Smtp").Bind(options));

            services.AddSingleton((ILogger)new LoggerConfiguration()
             .MinimumLevel.Debug()
             .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "NowPayGAPi-log-{Date}.txt"))
             .CreateLogger());

            services.AddTransient<IBL_User, BL_User>();
            services.AddTransient<IDL_User, DL_User>();
            services.AddTransient<IDL_CommonServices, DL_CommonServices>();
            services.AddTransient<IBL_CommonServices, BL_CommonServices>();
            services.AddTransient<IDL_Admin, DL_Admin>();
            services.AddTransient<IBL_Admin, BL_Admin>();
            services.AddTransient<IDL_Digitalk, DL_Digitalk>();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            try
            {
                if (env.IsDevelopment())
                {
                    app.UseDeveloperExceptionPage();
                }
                else
                {
                    app.UseHsts();
                }
                app.UseAuthentication();
                app.UseMvc();
                app.UseSwagger();
                app.UseSwaggerUI(c => { c.SwaggerEndpoint("/swagger/v1/swagger.json", "NowPayG API V1"); });
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }
    }
}
