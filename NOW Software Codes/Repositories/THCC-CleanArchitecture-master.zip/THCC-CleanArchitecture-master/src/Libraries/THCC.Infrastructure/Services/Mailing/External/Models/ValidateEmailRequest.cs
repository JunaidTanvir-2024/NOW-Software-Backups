﻿using System.ComponentModel.DataAnnotations;

namespace THCC.Infrastructure.Services.Mailing.External.Models;

public class ValidateEmailRequest
{
    public string Email { get; set; } = default!;
    public string ProductCode { get; set; } = default!;
    public string? IpAddress { get; set; }
}
