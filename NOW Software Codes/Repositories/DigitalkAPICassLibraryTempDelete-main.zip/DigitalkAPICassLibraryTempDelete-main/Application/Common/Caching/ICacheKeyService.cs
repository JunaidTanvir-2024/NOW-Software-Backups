﻿using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Caching;

public interface ICacheKeyService : IServicesType.IScopedService
{
    public string GetCacheKey(string name, string id);
}