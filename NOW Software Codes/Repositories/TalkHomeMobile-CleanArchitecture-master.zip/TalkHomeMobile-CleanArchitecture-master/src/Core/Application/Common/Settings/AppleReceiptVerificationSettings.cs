﻿namespace Application.Common.Settings;

public class AppleReceiptVerificationSettings
{
    public const string SectionName = "AppleReceiptVerificationSettings";
    public static AppleReceiptVerificationSettings Bind = new AppleReceiptVerificationSettings();
    public string? DisablePaymentVersion { get; set; }
    public bool IsActive { get; set; } = false;
    public string LiveUrl { get; set; } = default!;
    public string SandboxUrl { get; set; } = default!;
    public List<string>? WhiteListNumbers { get; set; }
}