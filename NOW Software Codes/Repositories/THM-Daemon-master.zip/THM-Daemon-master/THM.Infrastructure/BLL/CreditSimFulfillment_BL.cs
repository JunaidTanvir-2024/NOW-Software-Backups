﻿using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using THM.Infrastructure.DAL;
using THM.Infrastructure.Services;
using THM.Models.Enums;

namespace THM.Infrastructure.BLL
{
    public class CreditSimFulfillment_BL : ICreditSimFulfillment_BL
    {
        private readonly ILogger<CreditSimFulfillment_BL> _logger;
        private readonly ICreditSimFulfillment_DL _creditSimFulfillment_DL;
        private readonly IEmail_BL _email_BL;

        public CreditSimFulfillment_BL(
            ILogger<CreditSimFulfillment_BL> logger, 
            ICreditSimFulfillment_DL creditSimFulfillment_DL, 
            IEmail_BL email_BL)
        {
            _logger = logger;
            _creditSimFulfillment_DL = creditSimFulfillment_DL;
            _email_BL = email_BL;
        }

        public async Task StartFulfillment()
        {
            //Get active numbers for fullfillment
            var activeNumbers = await _creditSimFulfillment_DL.GetActiveNumbersFromPool();

            foreach (var item in activeNumbers)
            {
                var result = await _creditSimFulfillment_DL.GetCreditSimOrderDetail(item.msisdn);

                if (result.DBStatus == DbStatus.Success && result.Data.Count > 0)
                {
                    //Generate Email Message
                    string emailMessage = $"Dear {result.Data[0].fullName}," + Environment.NewLine;

                    string topupText;
                    if (result.Data[0].creditSim_type == CreditSimType.Bundle)
                    {
                        topupText = "Bundle";
                    }
                    else if (result.Data[0].creditSim_type == CreditSimType.Topup)
                    {
                        topupText = "Topup";
                    }

                    else
                    {
                        topupText = "Topup and bundle";
                    }
                    emailMessage += $"{topupText} added in your credit sim" + Environment.NewLine;
                    emailMessage += $"Msisdn: {item.msisdn}" + Environment.NewLine;


                    bool isFullfiled = false;

                    for (int i = 0; i < result.Data.Count; i++)
                    {
                        if (result.Data[i].isProcessed == false)
                        {
                            var dbResult = await _creditSimFulfillment_DL.AddBundleOrTopup(result.Data[i].payment_tran_id, result.Data[i].bundleId,
                                                                                                result.Data[i].amount, item.msisdn, result.Data[i].payment_type, result.Data[i].email);
                            string errorMessage = null;

                            isFullfiled = true;

                            if (dbResult.DBStatus == DbStatus.Failure)
                            {
                                isFullfiled = false;
                                errorMessage = dbResult.DBErrorMessage;
                            }
                            else
                            {
                                if (string.IsNullOrWhiteSpace(result.Data[i].bundleId))
                                {
                                    emailMessage += $"Topup: £{result.Data[i].amount}" + Environment.NewLine;
                                }
                                else
                                {
                                    emailMessage += $"Bundle: {dbResult.Data.bundleName}" + Environment.NewLine;
                                }

                            }

                            string fullfilmentRef = (dbResult.DBStatus == DbStatus.Failure ? null : dbResult.Data.audit_id);

                            await _creditSimFulfillment_DL.UpdateCreditSimFullfilment(result.Data[i].id, isFullfiled, errorMessage, fullfilmentRef);

                            await _creditSimFulfillment_DL.UpdateCreditSimFullfilmentInSimPool(item.id, isFullfiled, errorMessage);

                        }
                    }

                    if (isFullfiled)
                    {
                        _logger.LogInformation($"Complete fullfilment for : {result.Data[0].email}, time: {DateTimeOffset.Now}");

                        await _email_BL.SendFullfillmentEmail(result.Data[0].email, emailMessage, false, "Sim Order");
                    }
                    else
                    {
                        _logger.LogError($"Failed fullfilment for : {result.Data[0].email}, time: {DateTimeOffset.Now}");
                    }
                }
            }
        }
    }
}
