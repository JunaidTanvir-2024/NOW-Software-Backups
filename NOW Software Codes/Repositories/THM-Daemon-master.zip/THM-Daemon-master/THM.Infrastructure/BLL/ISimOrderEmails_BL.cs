﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using THM.Models.Enums;

namespace THM.Infrastructure.BLL
{
    public interface ISimOrderEmails_BL
    {
        Task SendWhyAndBenefitsEmail(SimOrderType simOrderType);
        Task SendNotActivatedSimEmail(SimOrderType simOrderType);
        Task SendOtherServicesEmail(SimOrderType simOrderType);
        Task SendSocialMediaEmails(SimOrderType simOrderType);
        Task SendNotToppedUpEmail(SimOrderType freeSim);
    }
}
