﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Now.Infrastructure.DAL;
using Now.Infrastructure.Services;
using Now.Models.Contracts.AirShip;
using Now.Models.Database;
using Now.Models.Enums;

namespace Now.Infrastructure.BLL;
public class CreditSimFulfillment_BL : ICreditSimFulfillment_BL
{
    private readonly ILogger<CreditSimFulfillment_BL> _logger;
    private readonly ICreditSimFulfillment_DL _creditSimFulfillment_DL;
    private readonly IEmail_BL _email_BL;
    private readonly IAirshipService _airshipService;

    public CreditSimFulfillment_BL(
        ILogger<CreditSimFulfillment_BL> logger,
        ICreditSimFulfillment_DL creditSimFulfillment_DL,
        IEmail_BL email_BL,
        IAirshipService airshipService)
    {
        _logger = logger;
        _creditSimFulfillment_DL = creditSimFulfillment_DL;
        _email_BL = email_BL;
        _airshipService = airshipService;
    }

    public async Task StartFulfillment()
    {
        //Get active numbers for fullfillment
        var activeNumbers = await _creditSimFulfillment_DL.GetActiveNumbersFromPool();

        foreach (var item in activeNumbers)
        {
            var result = await _creditSimFulfillment_DL.GetCreditSimOrderDetail(item.Msisdn);

            if (result.DBStatus == DbStatus.Success && result.Data.Count > 0)
            {
                //Generate Email Message
                string emailMessage = $"Dear {result.Data[0].FullName}," + Environment.NewLine;

                string topupText;
                if (result.Data[0].CreditSim_type == CreditSimType.Bundle)
                {
                    topupText = "Bundle";
                }
                else if (result.Data[0].CreditSim_type == CreditSimType.Topup)
                {
                    topupText = "Topup";
                }

                else
                {
                    topupText = "Topup and bundle";
                }
                emailMessage += $"{topupText} added in your credit sim" + Environment.NewLine;
                emailMessage += $"Msisdn: {item.Msisdn}" + Environment.NewLine;


                bool isFullfiled = false, IsTopupIncluded = false, IsBundleIncluded = false;
                double TopupAmount = 0;
                for (int i = 0; i < result.Data.Count; i++)
                {
                    if (result.Data[i].IsProcessed == false)
                    {
                        var dbResult = await _creditSimFulfillment_DL.AddBundleOrTopup(result.Data[i].Paymenttranid, result.Data[i].BundleId,
                                                                                            result.Data[i].Amount, item.Msisdn, result.Data[i].Payment_type, result.Data[i].Email!);
                        string errorMessage = null;

                        isFullfiled = true;

                        if (dbResult.DBStatus == DbStatus.Failure)
                        {
                            isFullfiled = false;
                            errorMessage = dbResult.DBErrorMessage;
                        }
                        else
                        {

                            if (!IsBundleIncluded)
                            {
                                IsBundleIncluded = !string.IsNullOrEmpty(result.Data[i].BundleId) ? true : false;
                            }
                            if (!IsTopupIncluded)
                            {
                                IsTopupIncluded = string.IsNullOrEmpty(result.Data[i].BundleId) ? true : false;
                                TopupAmount = Convert.ToDouble(result.Data[i].Amount);
                            }

                            if (string.IsNullOrWhiteSpace(result.Data[i].BundleId))
                            {
                                emailMessage += $"Topup: £{result.Data[i].Amount}" + Environment.NewLine;
                            }
                            else
                            {
                                emailMessage += $"Bundle: {dbResult.Data.BundleName}" + Environment.NewLine;
                            }
                        }
                        string fullfilmentRef = (dbResult.DBStatus == DbStatus.Failure ? null : dbResult.Data.Audit_id);

                        await _creditSimFulfillment_DL.UpdateCreditSimFullfilment(result.Data[i].Id, isFullfiled, errorMessage, fullfilmentRef);

                        await _creditSimFulfillment_DL.UpdateCreditSimFullfilmentInSimPool(item.Id, isFullfiled, errorMessage);

                    }
                }
             
                if (isFullfiled)
                {
                    //Update SIM Status
                    await _creditSimFulfillment_DL.UpdateSimStatus(item.Msisdn);

                    #region AutoTopUp/Renewal
                    PaymentType paymentType = result.Data[0].Payment_type;
                    if (paymentType == PaymentType.Card)
                    {
                        var transactionID = result?.Data?.FirstOrDefault()?.Paymenttranid;
                        if (!string.IsNullOrEmpty(transactionID))
                        {
                            var (isSuccess, orderDetails, orderItemDetails) = await _creditSimFulfillment_DL.GetOrderDetails(transactionID);
                            if (orderDetails != null)
                            {
                                var orderData = JsonConvert.DeserializeObject<OrderData>(orderDetails.OrderData!)!;
                                //Handle Auto Topup
                                if (orderData.AutoTopupInfo != null)
                                {
                                    await _creditSimFulfillment_DL.SetAutoTopup(
                                         orderData.AutoTopupInfo.Status,
                                          orderDetails.Msisdn,
                                          orderDetails.Email,
                                          orderData.AutoTopupInfo.TopupAmount,
                                          topupCurrency: "GBP",
                                          orderData.AutoTopupInfo.ThresHoldAmount,
                                          PaymentType.Card
                                          );

                                }

                                //Handle Auto Renew
                                if (orderData.BundleInfo != null && orderData.BundleInfo.IsRenewable && orderData.BundleInfo.BundleId > 0)
                                {
                                    var bundleInfo = await _creditSimFulfillment_DL.GetBundleById(orderData.BundleInfo.BundleId);
                                    var MsisdnDetails = await _creditSimFulfillment_DL.GetMsisdnDetail(orderDetails.Msisdn);
                                    await _creditSimFulfillment_DL.SetBundleAutoRenewal(
                                        true,
                                        orderDetails.Msisdn,
                                        MsisdnDetails.AccountId!,
                                        bundleInfo.UuId!,
                                        orderDetails.Email,
                                        PaymentType.Card);
                                }
                            }
                            else
                            {
                                _logger.LogInformation($"Auto Renewal/Topup Failed due to no order detail found, for : {result.Data[0].Email}, time: {DateTimeOffset.Now}");

                            }

                        }
                        else
                        {
                            _logger.LogInformation($"Auto Renewal/Topup Failed due to empty transactionId, for : {result.Data[0].Email}, time: {DateTimeOffset.Now}");

                        }
                    }
                    #endregion

                    _logger.LogInformation($"Complete fullfilment for : {result.Data[0].Email}, time: {DateTimeOffset.Now}");

                    await _email_BL.SendFullfillmentEmail(result.Data[0].Email, emailMessage, false, "Sim Order");

                    #region AirShipEvents
                    string email = result.Data[0].Email;
                    if (!String.IsNullOrEmpty(email))
                    {
                        List<string> transactionTags = new List<string>();
                        if (IsTopupIncluded && !IsBundleIncluded)
                        {
                            _airshipService.AddCustomEvent(new CustomEventsRequest
                            {

                                ProductCode = ProductCode.NOWPAYG.ToString(),
                                ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                ChannelIdentifierValue = email,
                                InteractionType = "URL",
                                InteractionId = "Free SIM + Credit",
                                CustomEventName = "activate_any_sim_credit_dash"
                            });
                            transactionTags.Add("activate_any_sim_credit_dash");

                        }
                        if (IsBundleIncluded && !IsTopupIncluded)
                        {
                            _airshipService.AddCustomEvent(new CustomEventsRequest
                            {

                                ProductCode = ProductCode.NOWPAYG.ToString(),
                                ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                ChannelIdentifierValue = email,
                                InteractionType = "URL",
                                InteractionId = "Free SIM + Plan",
                                CustomEventName = "activate_any_sim_plan_dash"
                            });
                            transactionTags.Add("activate_any_sim_plan_dash");
                        }
                        if (IsTopupIncluded && IsBundleIncluded)
                        {
                            _airshipService.AddCustomEvent(new CustomEventsRequest
                            {

                                ProductCode = ProductCode.NOWPAYG.ToString(),
                                ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                ChannelIdentifierValue = email,
                                InteractionType = "URL",
                                InteractionId = "Free SIM + Plan + Credit",
                                CustomEventName = "activate_any_sim_plan_credit_dash"
                            });
                            transactionTags.Add("activate_any_sim_plan_credit_dash");
                        }
                        transactionTags.Add("activate_any_paid_sim_dash");
                        transactionTags.Add("activate_any_sim_dash");

                        _airshipService.AddCustomEvent(new CustomEventsRequest
                        {

                            ProductCode = ProductCode.NOWPAYG.ToString(),
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = email,
                            InteractionType = "URL",
                            InteractionId = "Credit-SIM/Activation",
                            CustomEventName = "activate_any_paid_sim_dash"
                        });
                        _airshipService.AddCustomEvent(new CustomEventsRequest
                        {

                            ProductCode = ProductCode.NOWPAYG.ToString(),
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = email,
                            InteractionType = "URL",
                            InteractionId = "Credit-SIM/Activation",
                            CustomEventName = "activate_any_sim_dash"
                        });

                        _airshipService.AddNamedUserTags(new NamedUserTagsRequest
                        {
                            NamedUser = email,
                            ProductCode = ProductCode.NOWPAYG.ToString(),
                            TagGroup = "behaviour",
                            Tags = transactionTags
                        });

                    }
                    #endregion AirShipEvents
                }
                else
                {
                    _logger.LogError($"Failed fullfilment for : {result.Data[0].Email}, time: {DateTimeOffset.Now}");
                }
            }
        }
    }
}
