﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Settings;

namespace THCC.Application.Features.User.Profile.UserProfile;
public class UserProfileRequestHandler : IRequestHandler<UserProfileRequest, object>
{
    #region Fields

    private readonly ProfileSettings _profileSetting;
    private readonly ICurrentUser _currentUser;
    private readonly IUserRepository _userRepository;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly IHttpContextAccessor _httpContext;

    #endregion

    #region Ctor

    public UserProfileRequestHandler(
        ICurrentUser currentUser,
        IUserRepository userRepository,
        IOptions<ProfileSettings> profileSetting,
        IMapper mapper,
        ICommonService commonService,
        IHttpContextAccessor httpContext)
    {
        _profileSetting = profileSetting.Value;
        _currentUser = currentUser;
        _userRepository = userRepository;
        _mapper = mapper;
        _commonService = commonService;
        _httpContext = httpContext;
    }

    #endregion

    #region Method

    public async Task<object> Handle(UserProfileRequest request, CancellationToken cancellationToken)
    {
        var user = await _userRepository.GetUserByEmailAsync(_currentUser.GetUserEmail());

        if (!string.IsNullOrEmpty(user!.ProfileImage))
        {
            user.ProfileImage = $"{_commonService.GetHostRequestUrl()}{_profileSetting.VirtualDirectoryName}/{user!.Id}/{user.ProfileImage}";
        }
        var userProfileResonse = _mapper.Map<UserProfileResponse>(user)!;
        if (!string.IsNullOrEmpty(user.PasswordHash))
        {
            userProfileResonse.HasPassword = true;
        }
        return userProfileResonse;

    }
    #endregion
}
