﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TransferHome.Models.Contracts.Service.Pay360ApiContracts
{
    public class Pay360CustomerRequestModel
    {
        public string customerUniqueRef { get; set; }
        public string productCode { get; set; }
    }
}
