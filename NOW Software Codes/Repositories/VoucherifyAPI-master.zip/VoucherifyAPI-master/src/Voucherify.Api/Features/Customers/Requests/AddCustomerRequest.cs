using FluentValidation;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Customers.Requests;

public class AddCustomerRequest
{
    public string SourceId { get; set; } = null!;

    public string? Name { get; set; }

    public string? Email { get; set; }

    public string? Description { get; set; }

    public string? Phone { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public string? AddressLine1 { get; set; }

    public string? AddressLine2 { get; set; }

    public string? Country { get; set; }

    public string? PostalCode { get; set; }

    public Metadata? Metadata { get; set; }
}
internal class AddCustomerRequestValidator : AbstractValidator<AddCustomerRequest>
{
    public AddCustomerRequestValidator()
    {
        RuleFor(p => p.SourceId).NotNull().NotEmpty();
        RuleFor(p => p.Phone)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.Phone = phoneNumber);
    }
}
