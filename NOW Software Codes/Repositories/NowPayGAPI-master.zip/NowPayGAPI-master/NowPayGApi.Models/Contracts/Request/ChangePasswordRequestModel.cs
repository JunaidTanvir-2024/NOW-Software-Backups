﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class ChangePasswordRequestModel
    {
        public string NewPassword { get; set; }
        public string OldPassword { get; set; }
        public int UserID { get; set; }
    }
}
