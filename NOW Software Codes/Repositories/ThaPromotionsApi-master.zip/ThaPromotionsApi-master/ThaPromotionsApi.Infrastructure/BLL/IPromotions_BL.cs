﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ThaPromotionsApi.Models.Contracts.Response;

namespace ThaPromotionsApi.Infrastructure.BLL
{
    public interface IPromotions_BL
    {
        Task<GenericApiResponse<RSS>> GetTransferToPromotions();
    }
}
