using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

public class VoucherPublishList
{
    [JsonPropertyName("object")]
    public string? Object { get; set; }

    [JsonPropertyName("entries")]
    public List<VoucherPublish>? Entries { get; set; }
}