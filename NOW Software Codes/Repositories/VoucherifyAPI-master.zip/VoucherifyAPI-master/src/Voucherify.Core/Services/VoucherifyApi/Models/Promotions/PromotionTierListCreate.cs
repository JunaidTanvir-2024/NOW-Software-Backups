using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Promotions;

public class PromotionTierListCreate
{
    [JsonPropertyName("tiers")]
    public List<PromotionTierCreate>? Tiers { get; set; }
}
