﻿using RW.Models;

using SC.Core.Features.Countries.Requests;
using SC.Core.Vendors.FusionHub;

namespace SC.Core.Features.Countries;

internal sealed class GetAllCountriesHandler : IRequestHandler<GetCountriesRequest, IResultWrapper>
{
    private readonly IFusionHubService _fusionHubService;
    private readonly IDiscountRepository discountRepository;

    public GetAllCountriesHandler(IFusionHubService fusionHubService, IDiscountRepository discountRepository)
    {
        _fusionHubService = fusionHubService;
        this.discountRepository = discountRepository;
    }

    public async Task<IResultWrapper> Handle(GetCountriesRequest request, CancellationToken cancellationToken)
    {
        //var res = discountRepository.GetDiscounts(new DiscountDto.Request() { IsActive = true, IsDeleted = false, CountryFilters = new DiscountDto.Request.DiscountFilter() { Name = "NewYear", Type = null, Promocode = null, Value = null, StartDate = null, EndDate = null } });

        var response = await _fusionHubService.GetCountriesAsync(request);
        if (response?.Payload == null)
        {
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
        }
        return ResultWrapper.Success(response.Payload, new Pagination(response.PaginationInfo.TotalCount, response.PaginationInfo.PageCount, response.PaginationInfo.CurrentPage, response.PaginationInfo.PageSize));
    }
}