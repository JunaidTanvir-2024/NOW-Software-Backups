﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using THCC.Api.Controllers.Common;
using THCC.Application.Features.Rates;
using THCC.Application.Models.Dtos;

namespace THCC.Api.Controllers
{
    public class RatesController : BaseApiController
    {
        [AllowAnonymous]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<RatesDto>))]
        public async Task<IActionResult> GetRates()
        {
            return HandleResponse(await Mediator.Send(new RatesRequest()));
        }
    }
}
