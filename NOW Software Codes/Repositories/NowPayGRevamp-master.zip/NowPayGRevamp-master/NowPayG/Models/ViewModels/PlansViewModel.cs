﻿using NowPayG.Models.ApiContracts.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class PlansViewModel : BaseViewModel
    {
        public List<PlanResponseModel> Plans { get; set; }
        public GetAllCountriesWithPlansResponseModel PlansCountries { get; set; }
        public bool Filter { get; set; }
    }
}
