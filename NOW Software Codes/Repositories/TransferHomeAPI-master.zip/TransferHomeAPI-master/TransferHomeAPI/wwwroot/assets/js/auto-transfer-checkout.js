﻿$(document).ready(function () {

    var settngs = $.data($('#AutoTransfercheckOut-form')[0], 'validator').settings;
    settngs.ignore = ".ignore";

    $('#overlay').hide);

    if ($('input[name="CardData.NoCards"]').val() == "Yes") {
        $(".cardsData").removeClass('ignore');
        $('#SecurityCode').addClass('ignore');
    }
    else {
        if ($('input[name="AllCards"]').is(':checked')) {
            $('#Token').val($('input[name="AllCards"]:checked').val());
        }
        $('#SecurityCode').removeClass('ignore');
        $(".cardsData").addClass('ignore');
    }

    $('#btnAutoTransferSubmit').click(function () {
        if ($('#AutoTransfercheckOut-form').valid()) {

            $('#overlay').show();

            //Save Card
            if ($('#chk_SaveCard').is(':checked')) {
                $('#IsRegistered').val(true);
            }
            else {
                $('#IsRegistered').val(false);
            }

            $('#AutoTransfercheckOut-form').submit();
        } else {
            return false;
        }
    });

    $('input[name="AllCards"]').click(function () {
        if ($(this).is(':checked')) {
            $('#NewCardSection').hide();
            $('#Token').val($('input[name="AllCards"]:checked').val());
            $("#new-card").prop("checked", false);
            $('#ExistingCardSecurityCodeSection_auto').show();
            $(".cardsData").addClass('ignore');
            $('#SecurityCode').removeClass('ignore');
            ResetForm('AutoTransfercheckOut-form');
        }
    });

    $('#new-card').click(function () {
        if ($(this).is(':checked')) {
            $('#NewCardSection').show();
            $('input[name="AllCards"]').prop("checked", false);
            $('#Token').val('');
            $('#ExistingCardSecurityCodeSection_auto').hide();
            $(".cardsData").removeClass('ignore');
            $('#SecurityCode').addClass('ignore');
            ResetForm('AutoTransfercheckOut-form');
        }
    });

});

function ResetForm(formid) {

    $("#" + formid).validate().resetForm();

    //reset unobtrusive validation summary, if it exists
    $("#" + formid).find("[data-valmsg-summary=true]")
        .removeClass("validation-summary-errors")
        .addClass("validation-summary-valid")
        .find("ul").empty();

    //reset unobtrusive field level, if it exists
    $("#" + formid).find("[data-valmsg-replace]")
        .removeClass("field-validation-error")
        .addClass("field-validation-valid")
        .empty();

    //Remove the Fields border
    $("#" + formid).find('input').removeClass('input-validation-error');
    $("#" + formid).find('select').removeClass('input-validation-error');
}