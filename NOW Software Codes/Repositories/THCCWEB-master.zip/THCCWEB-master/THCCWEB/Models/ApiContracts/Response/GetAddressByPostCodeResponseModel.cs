﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Response
{
    public class GetAddressByPostCodeResponseModel
    {
        public AddressModel AddressData { get; set; }
    }
    public class AddressModel
    {
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public IList<string> Addresses { get; set; }
        public string Message { get; set; }
    }
}
