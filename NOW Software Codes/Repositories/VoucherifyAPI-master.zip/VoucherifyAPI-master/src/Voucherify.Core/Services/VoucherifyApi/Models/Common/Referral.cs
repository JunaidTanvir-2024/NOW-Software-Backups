using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class Referral
{
    [JsonPropertyName("code")]
    public string? Code { get; set; }
}
