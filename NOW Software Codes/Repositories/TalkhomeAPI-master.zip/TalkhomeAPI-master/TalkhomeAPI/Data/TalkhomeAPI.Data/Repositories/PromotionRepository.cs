﻿using Dapper;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.DbConnections;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Repositories
{
    public class PromotionRepository : IPromotionRepository
    {
        private readonly IDbConnectionSettings DGT_Db;
        private readonly IDbConnectionSettings THA_Db;
        private readonly IDbConnectionSettings THA_Accounts_Db;
        private readonly IDbConnectionSettings DefaultConnection;

        public PromotionRepository(IOptions<ConnectionString> connectionString)
        {
            DGT_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigitalkDbConnection));
            THA_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppDbConnection));
            THA_Accounts_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppsAccountsDbConnection));
            DefaultConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
        }

        public async Task<DBPromotionsDetails> GetAccountPromotions(string msisdn)
        {
            DBPromotionsDetails dBPromotionsDetails = new DBPromotionsDetails();
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", msisdn);

            var @audience = await THA_Accounts_Db.SqlConnection.QueryFirstOrDefaultAsync<string>("tha_web_user_loggedin_device", parameters, commandType: CommandType.StoredProcedure);

            if (audience != null)
            {
                parameters = new DynamicParameters();
                parameters.Add("@audience", @audience);
                var result = await THA_Db.SqlConnection.QueryMultipleAsync("tha_web_get_user_promotions", parameters, commandType: CommandType.StoredProcedure);

                dBPromotionsDetails.Promotions = result.Read<DBPromotions>();
                dBPromotionsDetails.PromotionPaymentMethods = result.Read<DBPromotionPaymentMethods>();
            }

            return dBPromotionsDetails;
        }
    }
}
