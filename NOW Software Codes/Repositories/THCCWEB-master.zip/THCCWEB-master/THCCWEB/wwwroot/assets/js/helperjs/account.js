﻿$(document).ready(function () {
    $("#RegistationBTN").click(function (event) {

        $("#emailErrorDiv").hide();
        if (!$("#RegisterForm").valid()) {
            return false;
        }
        var model = {};
        model.Email = $("#Email").val();
        model.FirstName = $("#FirtName").val();
        model.LastName = $("#LastName").val();
        model.Password = $("#Password").val();
        model.ConfirmPassword = $("#ConfirmPassword").val();
        model.MailSubscription = $('#MailSubscription').is(':checked') ? true : false;
        model.ChkTermsConditionsSignUp = $('#ChkTermsConditionsSignUp').is(':checked') ? true : false;

        $.ajax({
            beforeSend: function () {
                loader.btnloadershow(event);
                loader.mainloaderShow();
            },
            type: "POST",
            url: "/Account/Register",
            data: model,
            success: function (json) {
                loader.btnloaderhide(event);
                if (json && json.errorCode == 4) {
                    window.location.href = "/login?isexist=true"
                } else if (json && json.errorCode == 0) {

                    //Attach username
                    THCC_AirShip.AttachNamedUser(
                        $("#Email").val().trim(),
                        (returnValue) => {
                            if (returnValue) {
                                window.location.href = "/success/" + json.key;
                            } 
                            //Add tag
                            THCC_AirShip.AddTag(
                                THCC_AirShip.Tags.names.signup_web,
                                THCC_AirShip.Tags.types.customer,
                                false,
                                () => {

                                    //Add custom event
                                    THCC_AirShip.FireCustomEvent(THCC_AirShip.Events.signedup_web,
                                        {
                                        }
                                        , () => {
                                            if (model.MailSubscription) {
                                                THCC_AirShip.AddTag(
                                                    THCC_AirShip.Tags.names.thrcc_signedup_offers_web,
                                                    THCC_AirShip.Tags.types.customer,
                                                    false,
                                                    () => {
                                                        window.location.href = "/success/" + json.key;
                                                    });
                                            } else {
                                                window.location.href = "/success/" + json.key;
                                            }
                                           
                                        });

                                });
                            
                        });
                }
            },
            complete: function () {
                loader.mainloaderHide();
            },
            error: function (error) {
                loader.btnloaderhide(event);
                AddErrorTags();
            },

        });
    });



    function AddErrorTags() {
        THCC_AirShip.AttachNamedUser(
            $("#Email").val().trim(),
            () => {

                //Add tag
                THCC_AirShip.AddTag(
                    THCC_AirShip.Tags.names.signup_web,
                    THCC_AirShip.Tags.types.customer,
                    () => {

                        //Add custom event
                        THCC_AirShip.FireCustomEvent(THCC_AirShip.Events.signedup_web,
                            {
                                //user_type: "1"
                            }
                            , () => {
                            });

                    });
            });
    }
    $("#editInfoBtn").click(function () {
        $("#basicInfoFrom [aria-label='check']").removeAttr('disabled');
        $("#updateInfoBtn").show();
        $(this).hide();
    });
    $("#updateInfoBtn").click(function (event) {
        event.preventDefault();
        if (!$("#basicInfoFrom").valid()) return;
        let model = $("#basicInfoFrom").serialize();
        $.ajax({
            beforeSend: function () {
                loader.btnloadershow(event);
            },
            type: "POST",
            url: "/updatebasicinfo",
            dataType: 'json',
            contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
            data: model,
            async: true,
            success: function (json) {
                if (json && json.errorCode == 0) {
                    $("#basicInfoFrom [aria-label='check']").attr('disabled', 'true');
                    $("#updateInfoBtn").hide();
                    $("#editInfoBtn").show();
                }

            },
            error: function (error) {
            }, complete: function () {
                loader.btnloaderhide(event)
            }
        });
    });




    $("#passwordUpdateBtn").click(function (event) {
        event.preventDefault();
        if ($("#passwordUpdateFrom").valid() !== true) {
            return;
        }
        else {
            var model = $("#passwordUpdateFrom").serialize();
            $("#passwordMessage").empty();
            $("#ErrorMessage").empty();
            $.ajax({
                beforeSend: function () {
                    loader.btnloadershow(event);
                },
                type: "POST",
                url: "/updatenewpassword",
                data: model,
                async: true,
                dataType: 'json',
                contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                success: function (json) {
                    if (json && json.errorCode == 0) {
                        $("#passwordUpdateFrom")[0].reset();
                        $("#passwordMessage").text("Your new password has been updated !");
                    } else {
                        $("#ErrorMessage").text(json.message);
                    }
                },
                error: function (error) {

                },
                complete: function () {
                    loader.btnloaderhide(event);
                },
            });
        }

    });

    $("#rechargeid").change(function () {
        if ($(this).val()) {
            $("#topUpBtn").prop('disabled', false);
        } else {
            $("#topUpBtn").prop('disabled', true);
        }
    });

});
