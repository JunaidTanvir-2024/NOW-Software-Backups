﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THAPromotionsWEB.Models
{
    public class TransferToPromotionsRootObject
    {

        public RSS rss { get; set; }
    }


    public class Item
    {
        public string title { get; set; }
        public string description { get; set; }
        public string dateFrom { get; set; }
        public string dateTo { get; set; }
        public string pubDate { get; set; }
        public string operatorName { get; set; }
        public string operatorId { get; set; }
        public string subOperatorId { get; set; }
        public string countryId { get; set; }
        public string countryName { get; set; }
        public string title2 { get; set; }
        public string denomination { get; set; }
        public string denominationLocal { get; set; }
        public string promotionstatus { get; set; }
    }

    public class Channel
    {
        public string title { get; set; }
        public string description { get; set; }
        public string link { get; set; }
        public string pubDate { get; set; }
        public string lastBuildDate { get; set; }
        public string ttl { get; set; }
        public List<Item> item { get; set; }
    }

    public class RSS
    {
        public List<Country> country { get; set; }
        public Channel channel { get; set; }
    }

    public class Country
    {
        public string countryId { get; set; }
        public string countryName { get; set; }
    }

}

