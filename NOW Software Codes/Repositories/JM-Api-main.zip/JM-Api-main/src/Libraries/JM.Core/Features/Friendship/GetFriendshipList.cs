using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Friendship;

public abstract class GetFriendshipList
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public Filter? Filters { get; set; }
        public sealed record Filter
        {
            public long UserId { get; set; }
            public AppEnum.FriendshipStatus Status { get; set; }
        }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {

        }
        #endregion
    }
    #region Response
    public sealed record Response
    {
        public required UserInfo Initiator { get; set; }
        public required UserInfo Responder { get; set; }
        public required string Status { get; set; }

        public sealed record UserInfo
        {
            public required long Id { get; set; }
            public required string Email { get; set; }
            public required string Username { get; set; }
            public string? FullName { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var friendships = query.Filters is null ?
            await _unitOfWork.FriendshipRepository.GetFriendshipList()
            : await _unitOfWork.FriendshipRepository.GetFriendshipList(x => (x.InitiatorId.Equals(query.Filters.UserId) || x.ResponderId.Equals(query.Filters.UserId)) && x.Status.Equals(Enum.GetName(typeof(AppEnum
            .FriendshipStatus), query.Filters.Status)));

            if (friendships is not null)
            {
                return ResultWrapper.Success(friendships.Select(friendship => new Response()
                {
                    Status = friendship?.Status!,
                    Initiator = new Response.UserInfo()
                    {
                        Id = friendship?.Initiator?.Id ?? default,
                        Email = friendship?.Initiator?.Email!,
                        Username = friendship?.Initiator?.UserName!,
                        FullName = friendship?.Initiator?.UserDetail?.FullName,
                    },
                    Responder = new Response.UserInfo()
                    {
                        Id = friendship?.Responder?.Id ?? default,
                        Email = friendship?.Responder?.Email!,
                        Username = friendship?.Responder?.UserName!,
                        FullName = friendship?.Responder?.UserDetail?.FullName,
                    },
                }));
            }

            return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
        }
    }
    #endregion
}
