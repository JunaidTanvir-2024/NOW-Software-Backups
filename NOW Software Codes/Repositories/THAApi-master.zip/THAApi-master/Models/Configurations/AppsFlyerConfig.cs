﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class AppsFlyerConfig
    {
        public string ApiEndpoint { get; set; }
        public bool IsActive { get; set; }
    }
}
