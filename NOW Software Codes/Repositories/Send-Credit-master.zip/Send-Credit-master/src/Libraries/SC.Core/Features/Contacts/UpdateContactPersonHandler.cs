﻿using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.Contacts.Requests;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Contacts
{
    internal class UpdateContactPersonHandler : IRequestHandler<UpdateContactPersonRequest, IResultWrapper>
    {
        private readonly IContactPersonRepository _contactPersonRepository;
        private readonly ICommonService _commonService;

        public UpdateContactPersonHandler(IContactPersonRepository contactPersonRepository, ICommonService commonService)
        {
            this._contactPersonRepository = contactPersonRepository;
            this._commonService = commonService;
        }

        public async Task<IResultWrapper> Handle(UpdateContactPersonRequest request, CancellationToken cancellationToken)
        {
            var loggedUserId = _commonService.GetUserID();

            var contactPersonDto = new ContactPersonDto()
            {
                UserId = loggedUserId,
                Id = int.Parse(CipherHelper.Decrypt(request.Id)),
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                MobileNo = request.MobileNo,
                UpdatedAt = DateTime.UtcNow,
                UpdatedBy = loggedUserId,
            };

            var res = await _contactPersonRepository.UpdateContactPerson(contactPersonDto);
            return ResultWrapper.Success(res);
        }
    }
}