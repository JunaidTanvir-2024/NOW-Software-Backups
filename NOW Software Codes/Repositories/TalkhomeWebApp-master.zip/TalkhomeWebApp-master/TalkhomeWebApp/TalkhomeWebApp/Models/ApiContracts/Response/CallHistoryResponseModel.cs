﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class CallHistoryResponseModel
    {
        public List<CallHistory> CallHistory { get; set; }
    }

    public class CallHistory
    {
        public string Destination { get; set; }
        public string Zone { get; set; }
        public string Duration { get; set; }
        public string TotalCharge { get; set; }
        public string Type { get; set; }
        public DateTime DateTime { get; set; }
        public string formattedDateTime { get; set; }
    }
}
