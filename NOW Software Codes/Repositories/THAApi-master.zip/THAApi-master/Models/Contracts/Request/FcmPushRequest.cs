﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class FcmPushRequest
    {
        [JsonProperty("to")]
        [Required]
        public string To { get; set; }

        [JsonProperty("title")]
        [Required]
        public string Title { get; set; }

        [JsonProperty("body")]
        [Required]
        public string Body { get; set; }
    }
}
