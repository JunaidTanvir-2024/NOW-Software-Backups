﻿
using Now.Models.Database;
using Now.Models.Enums;

namespace Now.Infrastructure.DAL;

public interface ISimOrderEmails_DL
{
    Task<IEnumerable<DbSimOrder>> GetWhyAndBenefitsEmails(SimOrderType simOrderType);
    Task<IEnumerable<DbSimOrder>> GetNotActivatedSimOrders(SimOrderType simOrderType);
    Task<IEnumerable<DbSimOrder>> GetOrdersForOtherServicesEmail(SimOrderType simOrderType);
    Task<IEnumerable<DbSimOrder>> GetOrdersForSocialMediaEmails(SimOrderType simOrderType);
    Task<IEnumerable<DbSimOrder>> GetNotToppedUpSimOrders(SimOrderType simOrderType);

    Task<DbSimOrder> GetCreditSimOrderDetails(int OrderId);
    Task<IEnumerable<DbEmailLogs>> GetSentEmailsDetail(int OrderId, SimOrderType simOrderType, EmailsType whyAndBenefits);
    Task LogEmail(int simOrderId, SimOrderType simOrderType, EmailsType emailsType,
                                                    bool emailResponse, string emailErrorMessage);
}
