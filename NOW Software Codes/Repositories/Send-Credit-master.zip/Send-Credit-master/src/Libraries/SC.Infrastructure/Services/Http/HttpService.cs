﻿using SC.Core.Extensions;

using System.Text.Json.Serialization;
using System.Web;

namespace SC.Infrastructure.Services.Http;

internal sealed class HttpService : IHttpService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILoggerRepository _loggerRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ITimeWarpService _timeWarpService;
    private readonly ICommonService _commonService;
    private string? _bearerToken;
    private string? _basicAuthUsername;
    private string? _basicAuthPassword;
    private bool _isLoggingEnabled;
    private int _vendorId;
    private Uri? _baseUrl;
    private bool _isHeaderPaginationEnabled;
    private string? _totalPagesHeaderKey;
    private string? _totalRecordsHeaderKey;
    private readonly List<Dictionary<string, string>> _headers;

    public HttpService(
        IHttpClientFactory httpClientFactory,
        ILoggerRepository loggerRepository,
        IHttpContextAccessor httpContextAccessor,
        ITimeWarpService timeWarpService,
        ICommonService commonService)
    {
        _httpClientFactory = httpClientFactory;
        _loggerRepository = loggerRepository;
        _httpContextAccessor = httpContextAccessor;
        _timeWarpService = timeWarpService;
        _commonService = commonService;
        _headers = new List<Dictionary<string, string>>();
    }

    IHttpService IHttpService.WithBearerAuth(string? token)
    {
        _bearerToken = token;
        return this;
    }

    IHttpService IHttpService.BaseUrl(string baseUrl)
    {
        _baseUrl = new Uri(baseUrl);
        return this;
    }

    IHttpService IHttpService.WithBasicAuth(string? username, string? password)
    {
        _basicAuthUsername = username;
        _basicAuthPassword = password;
        return this;
    }

    IHttpService IHttpService.WithHeaders(IEnumerable<Dictionary<string, string>> headers)
    {
        _headers.AddRange(headers);
        return this;
    }

    IHttpService IHttpService.EnableLogging()
    {
        _isLoggingEnabled = true;
        return this;
    }

    IHttpService IHttpService.SetVendor(AppEnums.Vendors vendor)
    {
        _vendorId = (int)vendor;
        return this;
    }

    IHttpService IHttpService.GetPaginationFromHeader(string totalPagesHeaderKey, string totalRecordHeaderKey)
    {
        _isHeaderPaginationEnabled = true;
        _totalPagesHeaderKey = totalPagesHeaderKey;
        _totalRecordsHeaderKey = totalRecordHeaderKey;
        return this;
    }

    public async Task<(bool IsFailure, string Json)> GetAsync(string requestUri, object? queryParams = default)
    {
        if (queryParams is null)
        {
            return await BuildRequestAsync(HttpMethod.Get, requestUri);
        }

        return await BuildRequestAsync(HttpMethod.Get, BuildQueryParams(requestUri, queryParams));
    }

    public async Task<(bool IsFailure, string Json)> PostAsync(string requestUri, object? data = default)
    {
        return await BuildRequestAsync(HttpMethod.Post, requestUri, CreateJsonContent(data));
    }

    public async Task<(bool IsFailure, string Json)> PutAsync(string requestUri, object? data = default)
    {
        return await BuildRequestAsync(HttpMethod.Put, requestUri, CreateJsonContent(data));
    }

    public async Task<(bool IsFailure, string Json)> DeleteAsync(string requestUri)
    {
        return await BuildRequestAsync(HttpMethod.Delete, requestUri);
    }

    private async Task<(bool IsFailure, string Json)> BuildRequestAsync(HttpMethod method, string requestUri, HttpContent? content = null)
    {
        var stopwatch = Stopwatch.StartNew();
        var client = _httpClientFactory.CreateClient();

        //var apiUrl = requestUri;
        var apiUrl = $"{_baseUrl}{requestUri}";

        var request = new HttpRequestMessage(method, apiUrl);

        if (_bearerToken is not null)
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _bearerToken);
        }
        else if (_basicAuthUsername is not null && _basicAuthPassword is not null)
        {
            var authValue = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_basicAuthUsername}:{_basicAuthPassword}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authValue);
        }

        foreach (var header in _headers)
        {
            foreach (var value in header)
            {
                client.DefaultRequestHeaders.Add(value.Key, value.Value);
            }
        }

        if (content is not null)
        {
            request.Content = content;
        }

        var requestBody = request?.Content is not null ? await request.Content.ReadAsStringAsync() : string.Empty;

        return await SendAndLogRequest(stopwatch, client, request, requestBody);
    }

    private async Task<(bool IsFailure, string Json)> SendAndLogRequest(Stopwatch stopwatch, HttpClient client, HttpRequestMessage? request, string requestBody)
    {
        var responseBody = string.Empty;
        int statusCode;
        try
        {
            var httpResposneMessage = await client.SendAsync(request!);

            responseBody = await httpResposneMessage.Content.ReadAsStringAsync();
            statusCode = (int)httpResposneMessage.StatusCode;

            if (_isHeaderPaginationEnabled)
            {
                (int totalPages, int totalRecords) = httpResposneMessage.GetPaginationInfoFromHeader(_totalPagesHeaderKey, _totalRecordsHeaderKey);

                responseBody = JsonSerializer.Serialize(new { data = JsonSerializer.Deserialize<object>(responseBody), pagination = new { totalRecords, totalPages } });
            }

            if (_isLoggingEnabled)
            {
                InsertVendorLogs(stopwatch, request, statusCode, responseBody, requestBody, Encoding.UTF8.GetByteCount(responseBody), string.Empty);
            }

            return new() { IsFailure = !httpResposneMessage.IsSuccessStatusCode, Json = responseBody };
        }
        catch (Exception ex)
        {
            if (_isLoggingEnabled)
            {
                InsertVendorLogs(stopwatch, request, AppConstants.StatusCodes.InternalServerError, string.Empty, requestBody, 0, ex.StackTrace?.ToString());
            }

            return new() { IsFailure = true, Json = responseBody };
        }
    }

    private static StringContent CreateJsonContent(object? data)
    {
        var json = JsonSerializer.Serialize(data, new JsonSerializerOptions
        {
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        });
        return new StringContent(json, Encoding.UTF8, AppConstants.ContentTypes.ApplicationJson);
    }

    private void InsertVendorLogs(Stopwatch stopwatch, HttpRequestMessage? request, int statusCode, string? responseBody, string? reqeustBody, int responseSize, string? stackTraceError)
    {
        var logEntry = new VendorLogDto
        {
            CorrelationId = _httpContextAccessor.HttpContext?.Items["CorrelationIdKey"]?.ToString()!,
            Timestamp = _timeWarpService.UtcNow,
            RequestPath = request?.RequestUri?.ToString(),
            RequestBody = reqeustBody,
            ResponseBody = responseBody,
            StatusCode = statusCode,
            Duration = stopwatch.ElapsedMilliseconds,
            Headers = JsonSerializer.Serialize(request?.Headers),
            QueryString = request?.RequestUri?.Query,
            ErrorReason = stackTraceError,
            ResponseSize = responseSize,
            RequestMethod = request?.Method.ToString(),
            VendorId = _vendorId,
            RequestID = _commonService.GetRequestID(),
        };

        _loggerRepository.VendorLogInsertAsync(logEntry);
    }

    private string BuildQueryParams(string requestUrl, object queryParams)
    {
        var properties = queryParams.GetType().GetProperties()
                            .Where(p => p.GetValue(queryParams, null) != null)
                            .Select(p => p.Name + "=" + HttpUtility.UrlEncode(p.GetValue(queryParams, null)?.ToString()));

        var queryString = string.Join("&", properties.ToArray());
        return $"{requestUrl}?{queryString}";
    }
}