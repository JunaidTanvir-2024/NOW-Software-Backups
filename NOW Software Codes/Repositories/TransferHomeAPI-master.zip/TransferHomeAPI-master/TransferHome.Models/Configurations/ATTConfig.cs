﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Configurations
{
    public class ATTConfig
    {
        public string ApiEndPoint { get; set; }
    }
}
