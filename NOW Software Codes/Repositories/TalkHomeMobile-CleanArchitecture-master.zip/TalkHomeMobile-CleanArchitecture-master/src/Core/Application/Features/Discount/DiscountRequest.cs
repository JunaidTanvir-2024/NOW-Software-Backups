﻿namespace Application.Features.Discount;

public class DiscountRequest : IRequest<Result<DiscountResponse>>
{
    public string? Msisdn { get; set; }
    public float TopupAmount { get; set; } = default!;
    public int BundleId { get; set; } = default!;
    public CheckOutType CheckoutType { get; set; } = new CheckOutType();
}