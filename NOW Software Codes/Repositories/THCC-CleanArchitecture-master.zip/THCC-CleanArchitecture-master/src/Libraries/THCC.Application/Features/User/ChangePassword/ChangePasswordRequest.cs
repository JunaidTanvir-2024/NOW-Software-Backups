﻿namespace THCC.Application.Features.User.ChangePassword;

public class ChangePasswordRequest : IRequest<object>
{
    public string OldPassword { get; set; } = default!;
    public string NewPassword { get; set; } = default!;
}
public class ChangePasswordRequestValidator : AbstractValidator<ChangePasswordRequest>
{
    public ChangePasswordRequestValidator()
    {
        RuleFor(p => p.NewPassword).NotEmpty().NotNull()
        .MinimumLength(6).WithMessage("Your password length must be at least 6.")
        .MaximumLength(20).WithMessage("Your password length must not exceed 20.")
        .Matches(@"[A-Z]+").WithMessage("Your password must contain at least one uppercase letter.")
        .Matches(@"[a-z]+").WithMessage("Your password must contain at least one lowercase letter.")
        .Matches(@"[0-9]+").WithMessage("Your password must contain at least one number.");

        RuleFor(p => p.OldPassword)
            .NotEmpty()
            .NotNull();

    }
}
