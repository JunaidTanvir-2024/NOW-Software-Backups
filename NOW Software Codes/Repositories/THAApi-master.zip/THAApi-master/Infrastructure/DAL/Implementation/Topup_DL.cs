﻿using Dapper;
using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Request.AndroidInAppPayment;
using Models.Contracts.Response;
using Models.Database;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
	public class Topup_DL : ITopup_DL
	{

		private readonly IHistory_BL _historyService;
		private readonly ILogger _logger;
		private readonly ConnectionStrings _dbConnections;
		private readonly IConfiguration _configuration;

		public Topup_DL(
			IConfiguration config,
			ILogger logger,
			IOptions<ConnectionStrings> dbConnections,
			IHistory_BL historyService)
		{
			_logger = logger;
			_dbConnections = dbConnections.Value;
			_historyService = historyService;
			_configuration = config;
		}

		/// <summary>
		/// Get TopUp Payment History
		/// </summary>
		/// <param name="accountNumber"></param>
		/// <returns></returns>
		public async Task<IEnumerable<TopupPaymentHistory>> GetTopUpPaymentHistory(string accountNumber)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@account", accountNumber, dbType: DbType.String);

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
			{
				return await dbConnection.QueryAsync<TopupPaymentHistory>("tha_app_payment_history", parameters, commandType: CommandType.StoredProcedure);
			}
		}

		/// <summary>
		/// Get Last TopUp Payment
		/// </summary>
		/// <param name="msisdn"></param>
		/// <returns></returns>
		public async Task<LastTopup> GetLastTopUpPayment(string msisdn)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", msisdn, dbType: DbType.String);

			try
			{
				using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
				{
					return await dbConnection.QueryFirstOrDefaultAsync<LastTopup>("tha_last_topup_payment_history", parameters, commandType: CommandType.StoredProcedure);
				}
			}
			catch (Exception ex)
			{
				_logger.Error("Show Voucher exception {Ex}", ex.ToString());
				Debug.Write("Show Voucher exception: " + ex.ToString());
				return null;
			}
		}

		/// <summary>
		/// Store Duplicate Receipt
		/// </summary>
		/// <param name="request"></param>
		/// <returns></returns>
		public async Task<bool> StoreDuplicateReceipt(VerifyReceiptRequest request)
		{
			var transactionTime = DateTime.Now;
			var sqlInsertPrefix = "INSERT INTO trc_itunes_account_topup";
			var sqlInsertColumns = "(it_msisdn, it_token, it_uak, it_receipt_info, it_reason, it_trans_date_created, it_trans_last_updated)";

			var sqlInsert = String.Format("{0} {1} VALUES('{2}','{3}','{4}','{5}','{6}', convert(datetime,'{7}',103), convert(datetime,'{8}', 103));",
				sqlInsertPrefix,
				sqlInsertColumns,
				request.Msisdn,
				Guid.NewGuid().ToString(),
				"UAK?",
				request.Receipt,
				"Failed - Duplicate",
				transactionTime,
				transactionTime);

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
			{
				var numberOfUpdatedRows = await dbConnection.ExecuteAsync(sqlInsert);
				return numberOfUpdatedRows == 1;
			}
		}

		/// <summary>
		/// Apply InApp Purchase Credit
		/// </summary>
		/// <param name="amount"></param>
		/// <param name="transactionId"></param>
		/// <param name="userAccount"></param>
		/// <returns></returns>
		public async Task<bool> ApplyInAppPurchaseCredit(decimal amount, string transactionId, UserAccount userAccount)
		{
			var creditAmount = (amount * 100);
			try
			{
				using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
				{
					await dbConnection.ExecuteAsync("AccountUpdateBalance", new
					{
						account = userAccount.AccountID,
						channel = 1,
						amount = creditAmount,
						bonus = 0m,
						creditReason = "TALK HOME Apps - iTunes Topup",
						paymentMethod = "iTunes Top Up",
						rechargeType = 45,
						reference = "TALK HOME Apps - iTunes Topup",
						ccsTransId = 0,
						ccAuthCode = transactionId,
					}, commandType: CommandType.StoredProcedure);
				}
			}
			catch (Exception ex)
			{
				_logger.Error("InAppPurchaseCredit exception {Ex}", ex.ToString());
				Debug.Write("InAppPurchaseCredit exception: " + ex.ToString());
			}
			return true;
		}

		/// <summary>
		/// Store InApp Purchase Data
		/// </summary>
		/// <param name="request"></param>
		/// <param name="inAppPurchaseReceipt"></param>
		/// <param name="topupAmount"></param>
		/// <param name="itunesTransactionStatus"></param>
		/// <param name="itunesStatus"></param>
		/// <param name="itunesReason"></param>
		/// <returns></returns>
		public async Task<bool> StoreInAppPurchaseData(VerifyReceiptRequest request, InAppPurchaseReceipt inAppPurchaseReceipt, decimal topupAmount,
														   string itunesTransactionStatus, string itunesStatus, string itunesReason)
		{
			var transactionTime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss tt");
			var sqlInsertPrefix = "INSERT INTO trc_itunes_account_topup";
			var sqlInsertColumns = "(it_msisdn, it_token, it_uak, it_amount, it_transaction_id, it_transaction_status,"
								 + "it_status, it_receipt_info, it_reason, it_trans_date_created, it_trans_last_updated)";

			//Hacky fix to handle unique identifier field - it_token
			var uniqueVendorIdentifier = Guid.NewGuid().ToString();
			if (!String.IsNullOrEmpty(inAppPurchaseReceipt.Receipt.UniqueVendorIdentifier))
			{
				uniqueVendorIdentifier = inAppPurchaseReceipt.Receipt.UniqueVendorIdentifier;
			}

			var sqlInsert = String.Format("{0} {1} VALUES('{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}', convert(datetime,'{11}',103), convert(datetime,'{12}', 103));",
				sqlInsertPrefix,
				sqlInsertColumns,
				request.Msisdn,
				uniqueVendorIdentifier,
				"UAK?",
				topupAmount,
				inAppPurchaseReceipt.Receipt.InAppData[0].TransactionId,
				itunesTransactionStatus,
				itunesStatus,
				request.Receipt,
				itunesReason,
				transactionTime,
				transactionTime);

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
			{
				var numberOfUpdatedRows = await dbConnection.ExecuteAsync(sqlInsert);
				return numberOfUpdatedRows == 1;
			}
		}

		/// <summary>
		/// Receipt Does Not Exist
		/// </summary>
		/// <param name="receipt"></param>
		/// <returns></returns>
		public async Task<bool> ReceiptDoesNotExist(string receipt)
		{
			var sqlQuery = "select it_receipt_info " +
					  "from trc_itunes_account_topup(nolock) " +
					  $"where it_receipt_info = '{receipt}'";

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
			{
				var result = await dbConnection.QueryAsync<string>(sqlQuery);
				return !result.Any();
			}
		}

		/// <summary>
		/// Validate
		/// </summary>
		/// <param name="msisdn"></param>
		/// <param name="paymentType"></param>
		/// <returns></returns>
		public async Task<ValidateResponse> Validate(string msisdn, string paymentType)
		{
			ValidateResponse error = new ValidateResponse();

			var storedProcedure = "tha_validate_payment";

			var parameters = new DynamicParameters();

			parameters.Add("@msisdn", msisdn);
			parameters.Add("@paymentType", paymentType);
			parameters.Add("@isValid", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@errorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
			parameters.Add("@errorMsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
			try
			{
				using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
				{
					await dbConnection.ExecuteAsync(storedProcedure, parameters,
					commandType: CommandType.StoredProcedure);

					error.isValid = parameters.Get<bool>("@isValid");
					error.errorMessage = parameters.Get<String>("@errorMsg");
					error.errorCode = parameters.Get<Int32>("@errorCode");
				}
				return error;
			}
			catch (Exception ex)
			{
				_logger.Error("Show Validation exception {Ex}", ex.ToString());
				Debug.Write("Show Validation exception: " + ex.ToString());
			}
			return error;
		}

		/// <summary>
		/// Get IVR Topup Number
		/// </summary>
		/// <param name="locale"></param>
		/// <param name="msisdn"></param>
		/// <returns></returns>
		public async Task<string> GetIVRTopupNumber(string locale, string msisdn)
		{
			var storedProcedure = "tha_getIVRNumber";

			var parameters = new DynamicParameters();
			parameters.Add("@locale", locale);
			parameters.Add("@msisdn", msisdn);
			parameters.Add("@IVRNumber", dbType: DbType.String, direction: ParameterDirection.Output, size: 20);
			try
			{
				using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
				{
					await dbConnection.ExecuteAsync(storedProcedure, parameters,
				   commandType: CommandType.StoredProcedure);

					//parse output values
					return parameters.Get<string>("@IVRNumber");
				}
			}
			catch (Exception ex)
			{
				_logger.Error("IVR Topup number exception {Ex}", ex.ToString());
				Debug.Write("IVR Topup number exception: " + ex.ToString());
			}
			return null;
		}

		public async Task<PaymentConfigurations> GetPaymentConfig(int na_service_id)
		{
			PaymentConfigurations pc = new PaymentConfigurations();
			var storedProcedure = "tha_GetPaymentConfiguration_v2";

			var parameters = new DynamicParameters();

			parameters.Add("@na_service_id", na_service_id);
			parameters.Add("@isVoucher", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@isCard", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@isPaypal", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@isAmazon", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@isIvr", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@isInApp", dbType: DbType.Boolean, direction: ParameterDirection.Output);

			try
			{
				using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
				{
					await dbConnection.ExecuteAsync(storedProcedure, parameters,
					commandType: CommandType.StoredProcedure);

					//parse output values
					pc.ShowVoucherPayment = parameters.Get<bool>("@isVoucher");
					pc.ShowCardPayment = parameters.Get<bool>("@isCard");
					pc.ShowPaypalPayment = parameters.Get<bool>("@isPaypal");
					pc.ShowAmazonPayment = parameters.Get<bool>("@isAmazon");
					pc.ShowIvrPayment = parameters.Get<bool>("@isIvr");
					pc.InAppPayment = parameters.Get<bool>("@isInApp");
				}
			}
			catch (Exception ex)
			{
				_logger.Error("Show Voucher exception {Ex}", ex.ToString());
				Debug.Write("Show Voucher exception: " + ex.ToString());
			}
			return pc;
		}

		/// <summary>
		/// Get Payment Config Android
		/// </summary>
		/// <param name="na_service_id"></param>
		/// <returns></returns>
		public async Task<PaymentConfigurations> GetPaymentConfigAndroid(int na_service_id)
		{
			PaymentConfigurations pc = new PaymentConfigurations();

			var storedProcedure = string.Empty;

			if (_configuration["swift_simulation"] == null || Convert.ToBoolean(_configuration["swift_simulation"]) == false)
			{
				storedProcedure = "tha_GetAndroidPaymentConfiguration_v2";
			}
			else
			{
				storedProcedure = "tha_GetAndroidPaymentConfiguration_v3";
			}

			var parameters = new DynamicParameters();

			parameters.Add("@na_service_id", na_service_id);
			parameters.Add("@isVoucher", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@isCard", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@isPaypal", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@isAmazon", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@isIvr", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			parameters.Add("@isInApp", dbType: DbType.Boolean, direction: ParameterDirection.Output);

			try
			{
				using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
				{
					await dbConnection.ExecuteAsync(storedProcedure, parameters,
					commandType: CommandType.StoredProcedure);

					//parse output values
					pc.ShowVoucherPayment = parameters.Get<bool>("@isVoucher");
					pc.ShowCardPayment = parameters.Get<bool>("@isCard");
					pc.ShowPaypalPayment = parameters.Get<bool>("@isPaypal");
					pc.ShowAmazonPayment = parameters.Get<bool>("@isAmazon");
					pc.ShowIvrPayment = parameters.Get<bool>("@isIvr");
					pc.InAppPayment = parameters.Get<bool>("@isInApp");
				}
			}
			catch (Exception ex)
			{
				_logger.Error("Show Voucher exception {Ex}", ex.ToString());
				Debug.Write("Show Voucher exception: " + ex.ToString());
			}

			return pc;
		}

		/// <summary>
		/// Apply Voucher Code
		/// </summary>
		/// <param name="voucherCode"></param>
		/// <param name="userAccount"></param>
		/// <param name="voucherTopupResponse"></param>
		/// <returns></returns>
		public async Task<string> ApplyVoucherCode(string voucherCode, UserAccount userAccount, VoucherTopupResponse voucherTopupResponse)
		{
			var storedProcedure = "vchApplyVoucher";

			var parameters = new DynamicParameters();
			parameters.Add("@channel", 1);
			parameters.Add("@pin", voucherCode);
			parameters.Add("@account", userAccount.AccountID);
			parameters.Add("@card_credit", dbType: DbType.Decimal, direction: ParameterDirection.Output);
			parameters.Add("@voucher_id", dbType: DbType.Int32, direction: ParameterDirection.Output);
			parameters.Add("@voucher_currency", dbType: DbType.String, direction: ParameterDirection.Output, size: 1000);
			parameters.Add("@result_status", dbType: DbType.Int32, direction: ParameterDirection.Output);
			parameters.Add("@result_message", dbType: DbType.String, direction: ParameterDirection.Output, size: 1000);

			string resultMessage = string.Empty;

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
			{
				var result = await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

				resultMessage = parameters.Get<string>("@result_message");
			}


			if (!String.IsNullOrEmpty(resultMessage) && resultMessage == "Success")
			{
				//Parse output values
				voucherTopupResponse.VoucherId = parameters.Get<int>("@voucher_id");
				var cardCredit = parameters.Get<decimal>("@card_credit");
				voucherTopupResponse.CreditApplied = (cardCredit / 100).ToString(CultureInfo.InvariantCulture);
				voucherTopupResponse.Currency = parameters.Get<string>("@voucher_currency");
			}

			return resultMessage;
		}

		/// <summary>
		/// Is Eligible
		/// </summary>
		/// <param name="msisdn"></param>
		/// <param name="voucherCode"></param>
		/// <returns></returns>
		public async Task<bool> IsEligible(string msisdn, string voucherCode)
		{
			var sqlQuery = "select pin as VoucherCode, used as Used, credit as Credit " +
							   "from dbo.cards " +
							   $"where pin = '{voucherCode}'";

			VoucherDetails voucherDetails = null;

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
			{
				voucherDetails = await dbConnection.QueryFirstOrDefaultAsync<VoucherDetails>(sqlQuery);
			}

			if (voucherDetails != null && voucherDetails.Credit == 100m)
			{
				var paymentHistory = await _historyService.GetPaymentHistory(msisdn);
				if (paymentHistory != null && paymentHistory.Any(e => e.Amount == "€1"))
				{
					return false;
				}
			}
			return true;
		}

		/// <summary>
		/// Verify Voucher Code
		/// </summary>
		/// <param name="voucherCode"></param>
		/// <returns></returns>
		public async Task<bool> VerifyVoucherCode(string voucherCode)
		{
			var storedProcedure = "THA_Web_VoucherCheck";

			var parameters = new DynamicParameters();
			parameters.Add("@pin", voucherCode);

			using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
			{
				var result = await dbConnection.QueryFirstOrDefaultAsync<Int16>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
				return result == 1;
			}
		}
	}
}
