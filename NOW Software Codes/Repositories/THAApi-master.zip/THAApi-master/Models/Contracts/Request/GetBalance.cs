﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class GetBalance
    {
        public string Currency { get; set; }

        public decimal Balance { get; set; }
    }
}
