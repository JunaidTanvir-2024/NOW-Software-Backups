﻿using System.Text;

namespace THCC.Application.Extensions.Security;

public static class SHA
{
    #region GenerateHashDescription
    /// <summary>
    /// Generates a hash for the given plain text value and returns a
    /// base64-encoded result.
    /// </summary>
    /// 
    /// 
    /// 
    /// <param name="plainText">
    /// Plaintext value to be hashed. The function does not check whether
    /// this parameter is null.
    /// </param>
    /// 
    /// 
    /// 
    /// <param name="hashAlgorithm">
    /// Name of the hash algorithm. Allowed values are: "MD5", "SHA1",
    /// "SHA256", "SHA384", and "SHA512" (if any other value is specified
    /// MD5 hashing algorithm will be used). This value is case-insensitive.
    /// </param>
    /// 
    ///
    /// <returns>
    /// Hash value formatted as a base64-encoded string.
    /// </returns>
    #endregion
    public static string ComputeHash(string plainText, string hashAlgorithm)
    {
        // Convert plain text into a byte array.
        byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
        HashAlgorithm hash;
#pragma warning disable SYSLIB0021 // Type or member is obsolete

        switch (hashAlgorithm.ToUpper())
        {
            case "SHA1":
                hash = new SHA1Managed();
                break;

            case "SHA256":
                hash = new SHA256Managed();
                break;

            case "SHA384":
                hash = new SHA384Managed();
                break;

            case "SHA512":
                hash = new SHA512Managed();
                break;

            default:
                hash = new MD5CryptoServiceProvider();
                break;
        }
#pragma warning restore SYSLIB0021 // Type or member is obsolete

        byte[] hashBytes = hash.ComputeHash(plainTextBytes);
        string hashValue = Convert.ToBase64String(hashBytes);

        return hashValue;
    }

    #region VerifyHashDescription
    /// <summary>
    /// Compares a hash of the specified plain text value to a given hash
    /// value.
    /// </summary>
    /// 
    /// <param name="plainText">
    /// Plain text to be verified against the specified hash. The function
    /// does not check whether this parameter is null.
    /// </param>
    /// 
    /// <param name="hashAlgorithm">
    /// Name of the hash algorithm. Allowed values are: "MD5", "SHA1", 
    /// "SHA256", "SHA384", and "SHA512" (if any other value is specified,
    /// MD5 hashing algorithm will be used). This value is case-insensitive.
    /// </param>
    /// 
    /// <param name="hashValue">
    /// Base64-encoded hash value produced by ComputeHash function. This value
    /// includes the original salt appended to it.
    /// </param>
    /// 
    /// 
    /// <returns>
    /// If computed hash mathes the specified hash the function the return
    /// value is true; otherwise, the function returns false.
    /// </returns>
    /// 
    #endregion
    public static bool VerifyHash(string plainText, string hashAlgorithm, string hashValue)
    {
        // Convert base64-encoded hash value into a byte array.
        byte[] hashWithSaltBytes = Convert.FromBase64String(hashValue);

        // We must know size of hash (without salt).
        int hashSizeInBits, hashSizeInBytes;

        // Make sure that hashing algorithm name is specified.
        if (hashAlgorithm == null)
            hashAlgorithm = "";

        // Size of hash is based on the specified algorithm.
        switch (hashAlgorithm.ToUpper())
        {
            case "SHA1":
                hashSizeInBits = 160;
                break;

            case "SHA256":
                hashSizeInBits = 256;
                break;

            case "SHA384":
                hashSizeInBits = 384;
                break;

            case "SHA512":
                hashSizeInBits = 512;
                break;

            default: // Must be MD5
                hashSizeInBits = 128;
                break;
        }

        // Convert size of hash from bits to bytes.
        hashSizeInBytes = hashSizeInBits / 8;

        // Make sure that the specified hash value is long enough.
        if (hashWithSaltBytes.Length < hashSizeInBytes)
        {
            return false;
        }

        // Compute a new hash string.
        string expectedHashString = ComputeHash(plainText, hashAlgorithm);

        // If the computed hash matches the specified hash,
        // the plain text value must be correct.
        return hashValue == expectedHashString;
    }
}
