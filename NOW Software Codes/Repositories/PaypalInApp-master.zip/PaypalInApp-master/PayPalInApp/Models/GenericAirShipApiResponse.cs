﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Models
{
    public class GenericAirShipApiResponse<T>
    {


        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public T payload { get; set; }
        //public static GenericAirShipApiResponse<T> Success(T payload, string message)
        //{
        //    return new GenericAirShipApiResponse<T>
        //    {
        //        errorCode = 0,
        //        status = "Success",
        //        message = message,
        //        payload = payload
        //    };
        //}
        //public static GenericAirShipApiResponse<T> Success(string message)
        //{
        //    return new GenericAirShipApiResponse<T>
        //    {
        //        errorCode = 0,
        //        status = "Success",
        //        message = message
        //    };
        //}
        //public static GenericAirShipApiResponse<T> Failure(string message, ApiStatusCodes errorCode)
        //{
        //    return new GenericAirShipApiResponse<T>
        //    {
        //        errorCode = (int)errorCode,
        //        status = "Failure",
        //        message = message

        //    };
        //}
        //public static GenericAirShipApiResponse<T> Failure(T payload, string message, ApiStatusCodes errorCode)
        //{
        //    return new GenericAirShipApiResponse<T>
        //    {
        //        errorCode = (int)errorCode,
        //        status = "Failure",
        //        message = message,
        //        payload = payload
        //    };
        //}



    }
}
