﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    
    public class SipConfigurationsResponse
    {
        public SipConfigurationsResponse()
        {
            transport = "TLS";
        }

        public string Port { get; set; }
        public bool is_tls { get; set; }
        public string realm_ipv4 { get; set; }
        public string realm_ipv6 { get; set; }
        public bool is_default { get; set; }
        public bool is_somme_user { get; }
        public string transport { get; }
    }
}
