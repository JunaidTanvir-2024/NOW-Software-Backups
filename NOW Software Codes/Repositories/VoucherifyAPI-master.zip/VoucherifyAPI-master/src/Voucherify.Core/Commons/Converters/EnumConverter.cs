﻿using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Definations;

namespace Voucherify.Core.Commons.Converters;

public class EnumConverter<T> : JsonConverter<T>
{
    public override T Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType == JsonTokenType.String)
        {
            var enumString = reader.GetString();
            var enumValue = EnumConverter<T>.GetEnumValueFromAttribute(enumString!);
            if (enumValue != null)
            {
                return (T)enumValue;
            }
        }

        throw new JsonException($"Unable to convert \"{reader.GetString()}\" to enum type \"{typeof(T)}\".");
    }

    public override void Write(Utf8JsonWriter writer, T? value, JsonSerializerOptions options)
    {
        var enumString = GetEnumAttributeValue(value);
        writer.WriteStringValue(enumString);
    }

    private static object? GetEnumValueFromAttribute(string enumString)
    {
        Type enumType = typeof(T);
        foreach (var field in enumType.GetFields(BindingFlags.Public | BindingFlags.Static))
        {
            var attribute = field.GetCustomAttribute<VoucherifyAttributes.JsonEnumValueAttribute>();
            if (attribute != null && attribute.Value == enumString)
            {
                return field.GetValue(null);
            }
        }
        return null;
    }

    private static string GetEnumAttributeValue(T? value)
    {
        if (value == null)
        {
            return string.Empty;
        }
        var attribute = typeof(T).GetField(value.ToString()!)?.GetCustomAttribute<VoucherifyAttributes.JsonEnumValueAttribute>();
        return attribute?.Value ?? string.Empty;
    }
}
