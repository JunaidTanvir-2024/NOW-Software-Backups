﻿using MapsterMapper;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.Users.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Users;
public sealed class GetAccountDetailHander : IRequestHandler<GetAccountDetailRequest, IResultWrapper>
{
    private readonly IUserRepository _userRepository;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    public GetAccountDetailHander(
     IUserRepository IUserRepository, IMapper mapper,ICommonService commonService)
    {
        _userRepository = IUserRepository;
        _mapper = mapper;
        _commonService = commonService;
    }
    public async Task<IResultWrapper> Handle(GetAccountDetailRequest request, CancellationToken cancellationToken)
    {
        var response = await _userRepository.GetUserDetailByUserID(_commonService.GetUserID());
        var responseResult = _mapper.Map<GetAccountDetailResponse>(response);
        return ResultWrapper.Success(responseResult);
    }
}

