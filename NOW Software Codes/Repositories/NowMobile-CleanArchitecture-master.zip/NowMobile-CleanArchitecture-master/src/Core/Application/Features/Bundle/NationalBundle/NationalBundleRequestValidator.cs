namespace Application.Features.Bundle.NationalBundle;

public sealed class NationalBundleRequestValidator : AbstractValidator<NationalBundleRequest>
{
    public NationalBundleRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
    }
}
