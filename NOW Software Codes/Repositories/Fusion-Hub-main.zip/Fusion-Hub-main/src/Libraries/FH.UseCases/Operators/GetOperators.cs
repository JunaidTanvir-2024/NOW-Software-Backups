using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;
using RW.Models;

using static FH.Core.Definitions.AppEnums;

namespace FH.UseCases.Operators;
public sealed class GetOperators
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public OperatorRequestType RequestType { get; set; }
        public OperatorFilter? OperatorFilters { get; set; }

        public sealed record OperatorFilter
        {
            public string? OperatorName { get; set; }
            public string? CountryIsoCode { get; set; }
        }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Page).GreaterThan(0);
            RuleFor(x => x.RecordsPerPage).LessThan(101);
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public OperatorInfo Operator { get; set; } = new OperatorInfo();
        public sealed record OperatorInfo
        {
            public long Id { get; set; }
            public string? OperatorName { get; set; }
            public string? Description { get; set; }
            public string? OperatorLogo { get; set; }
            public OperatorCountryInfo Country { get; set; } = new OperatorCountryInfo();
        }
        public sealed record OperatorCountryInfo
        {
            public string? Name { get; set; }
            public string? IsoCode { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IMapper _mapper = mapper;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var getOperatorsRequest = _mapper.Map<OperatorDto.Request>(request);

            // Setting Default Values
            getOperatorsRequest.IsActive = true;
            getOperatorsRequest.IsDeleted = false;

            (IEnumerable<OperatorDto.Response> operators, DatabasePaginationDto pagination) = await _unitOfWork.OperatorRepository.GetOperators(getOperatorsRequest);
            if (operators is null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
            }
            var getOperatorsResponse = _mapper.Map<List<Response>>(operators);
            return ResultWrapper.Success(getOperatorsResponse, new Pagination(pagination.TotalRecords, pagination.TotalPages, request.Page, request.RecordsPerPage));
        }
    }
    #endregion
}
