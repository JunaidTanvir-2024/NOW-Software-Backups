﻿using System.Text;

using DinkToPdf;
using DinkToPdf.Contracts;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using THCC.Api.Controllers.Common;
using THCC.Application.Features.Invoice;
using THCC.Application.Features.Payment.Card.AutoTopup.ExistingCard;
using THCC.Application.Features.Payment.Card.AutoTopup.NewCard;
using THCC.Application.Features.Payment.Card.CallingCard.ExistingCard;
using THCC.Application.Features.Payment.Card.CallingCard.GuestCheckout.NewCard;
using THCC.Application.Features.Payment.Card.CallingCard.NewCard;
using THCC.Application.Features.Payment.Card.CustomerCards;
using THCC.Application.Features.Payment.Card.MakeCardDefault;
using THCC.Application.Features.Payment.Card.RechargeableCallingCard.ExistingCard;
using THCC.Application.Features.Payment.Card.RechargeableCallingCard.NewCard;
using THCC.Application.Features.Payment.Card.RemoveCard;
using THCC.Application.Features.Payment.Card.Resume3d;
using THCC.Application.Features.Payment.Card.Topup.ExistingCard;
using THCC.Application.Features.Payment.Card.Topup.FastTopup.ExistingCard;
using THCC.Application.Features.Payment.Card.Topup.FastTopup.NewCard;
using THCC.Application.Features.Payment.Card.Topup.NewCard;
using THCC.Application.Features.Payment.Discount;
using THCC.Application.Features.Payment.PayPal.CallingCard;
using THCC.Application.Features.Payment.PayPal.ExecuteSale;
using THCC.Application.Features.Payment.PayPal.FastTopup;
using THCC.Application.Features.Payment.PayPal.GuestCheckout.CallingCard;
using THCC.Application.Features.Payment.PayPal.Models;
using THCC.Application.Features.Payment.PayPal.RechargeableCallingCard;
using THCC.Application.Features.Payment.PayPal.Topup;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Api.Controllers;

public class PaymentController : BaseApiController
{
    #region Fields

    private readonly ICommonService _commonService;
    private readonly IConverter _converter;

    #endregion

    #region Ctors

    public PaymentController(
        ICommonService commonService,
        IConverter converter)
    {
        _commonService = commonService;
        _converter = converter;
    }

    #endregion

    #region Methods

    #region Card Payment

    [HttpPost("thcc/card/new"), Authorize]
    public async Task<IActionResult> THCCNewCardPayment([FromBody] THCCNewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("thcc/card/existing"), Authorize]
    public async Task<IActionResult> THCCExistingCardPayment([FromBody] THCCExistingCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("thrcc/card/new"), Authorize]
    public async Task<IActionResult> THRCCNewCardPayment([FromBody] THRCCNewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("thrcc/card/existing"), Authorize]
    public async Task<IActionResult> THCCExistingCardPayment([FromBody] THRCCExistingCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpGet("thrcc/discount/{Amount}"), AllowAnonymous]
    public async Task<IActionResult> GetTHRCCDiscount([FromRoute] DiscountRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("topup/card/new"), Authorize]
    public async Task<IActionResult> TopupNewCardPayment([FromBody] TopupNewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("topup/card/existing"), Authorize]
    public async Task<IActionResult> TopupExistingCardPayment([FromBody] TopupExistingCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("fast-topup/card/new"), AllowAnonymous]
    public async Task<IActionResult> FastTopupNewCardPayment([FromBody] FastTopupNewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("fast-topup/card/existing"), Authorize]
    public async Task<IActionResult> FastTopupExistingCardPayment([FromBody] FastTopupExistingCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("auto-topup/card/new"), Authorize]
    public async Task<IActionResult> AutoTopupNewCardPayment([FromBody] AutoTopupNewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("auto-topup/card/existing"), Authorize]
    public async Task<IActionResult> AutoTopupExistingCardPayment([FromBody] AutoTopupExistingCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [AllowAnonymous]
    [HttpPost("card/Resume")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CardResponseDto))]
    public async Task<IActionResult> Resume3d([FromBody] Resume3dRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    #region Customer Card Management

    [HttpGet("card"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IList<CustomerCardDto>))]
    public async Task<IActionResult> GetCustomerCards(CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(new CustomerCardsRequest(), cancellationToken));
    }

    [HttpPost("card/default"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IList<CustomerCardDto>))]
    public async Task<IActionResult> MakeCardDefault([FromBody] MakeCardDefaultRequest request)
    {
        return HandleResponse(await Mediator.Send(request));
    }

    [HttpPost("card/remove"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IList<CustomerCardDto>))]
    public async Task<IActionResult> RemoveCustomerCard([FromBody] RemoveCardRequest request)
    {
        return HandleResponse(await Mediator.Send(request));
    }

    #endregion

    #endregion

    #region Paypal

    [HttpPost("thcc/paypal"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PaypalPaymentResponse))]
    public async Task<IActionResult> BuyClassicCallingCard([FromBody] PaypalCallingCardRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }
    [HttpPost("thcc/guest/paypal"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PaypalPaymentResponse))]
    public async Task<IActionResult> GuestCheckoutBuyClassicCallingCard([FromBody] GuestCheckoutPaypalCallingCardRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("thrcc/paypal"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PaypalPaymentResponse))]
    public async Task<IActionResult> BuyRechargeCallingCard([FromBody] PaypalRechargeableCallingCardRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("topup/paypal"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PaypalPaymentResponse))]
    public async Task<IActionResult> Topup([FromBody] PaypalTopupRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("fast-topup/paypal"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PaypalPaymentResponse))]
    public async Task<IActionResult> FastTopup([FromBody] PaypalFastTopupRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("paypal/execute"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PaypalResponseDto))]
    public async Task<IActionResult> PaypalExecuteSale([FromBody] DirectPaypalExecutePaymentRequest request)
    {
        return HandleResponse(await Mediator.Send(request));
    }

    #endregion

    #region Invoice

    [HttpPost("invoice"), AllowAnonymous]
    public async Task<IActionResult> InvoiceAsync([FromBody] InvoiceRequest request, CancellationToken cancellationToken)
    {
        var response = await Mediator.Send(request, cancellationToken);
        if (response != null)
        {
            if (response is ErrorResult)
            {
                return HandleResponse(response);
            }
        }
        var htmlDoc = new StringBuilder();
        htmlDoc.Append(response);
        var doc = new HtmlToPdfDocument()
        {
            Objects = { new ObjectSettings() {
                     HtmlContent = htmlDoc.ToString(),
                     WebSettings = { DefaultEncoding = "utf-8",UserStyleSheet= _commonService.GetHostRequestUrl()+ "css/pdf-fonts.css" }
                } }
        };

        var pdf = _converter.Convert(doc);
        var stream = new MemoryStream(pdf);
        stream.Seek(0, SeekOrigin.Begin);
        return File(stream, "application/pdf", $"Invoice_{request.ReferenceId}.pdf");
    }

    #endregion

    #region Guest Checkout Card Payment
 
    [HttpPost("thcc/guest/card/new")]
    public async Task<IActionResult> GuestCheckoutTHCCNewCardPayment([FromBody] GuestCheckoutTHCCNewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }
    #endregion

    #endregion
}