﻿//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using SenderService.Core.Persistence.Entities;

//namespace SenderService.Core.Persistence.Configurations;
//public class BlockDomainConfiguration : IEntityTypeConfiguration<BlockDomain>
//{
//    public void Configure(EntityTypeBuilder<BlockDomain> entity)
//    {
//        entity.HasIndex(e => e.Domain, "IX_BlockedDomains_Domain").IsUnique();

//        entity.Property(e => e.Domain).HasMaxLength(250);
//    }
//}