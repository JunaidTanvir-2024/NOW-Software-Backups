﻿using System.Collections.Generic;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.Pay360ApiContracts
{
    public class RemoveAllPaymentMethodsResponse
    {
        public List<string> SuccesfullyRemovedCards { get; set; }
        public List<string> FailedToRemoveCards { get; set; }
    }
}
