﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Utility
{
    public enum Messages
    {
        SuccesfullRegistration,
        EmailVerificationUnsuccess,
        EmailVerificationSuccess,
        EmailVerificationTokenExpired,
        EmailNotVerified,
        UserNotFoundbyEmail,
        UserAlreadyExist,
        InvalidEmailOrPassword,
        LoginSuccessful,
        ForgotPasswordVerificationTokenExpired,
        PasswordResetEmail,
        PasswordUpdatedSuccessfully,
        NoPlanFound,
        NoCountryFound,
        NoInternationalRatesFound,
        NoRoamingRatesFound,
        NoUKRatesFound,
        NoAddressFound,
        MobileNumberAlreadyAttached,
        InvalidMsisdnOrPUK,
        InternalServerError,
        NewUserSimOrder,
        ExistingUserSimOrder,
        EmailAlreadyVerified,
        InvalidOldPassword,
        PaymentRequestFailed,
        InvalidMsisdn,
        MailOrderSuccessPortInfail,
        MonthlySimOrderValidation,
        AccountSimOrderValidation
    }
}
