﻿namespace Application.Features.Payment.Card.CustomerCards;

public class CustomerCardsRequest : IRequest<Result<List<CustomerCard>>> { }
