﻿namespace SC.Infrastructure.Services.OpenApi;
internal static class ConfigureOpenApi
{
    internal static IServiceCollection AddOpenApiConfiguration(this IServiceCollection services)
    {
        // Get Open Api setting
        var openApiSettings = services.BuildServiceProvider().GetRequiredService<IOptions<OpenApiSetting>>().Value;

        services.AddEndpointsApiExplorer();

        services.AddSwaggerGen(options =>
        {
            options.AddSwaggerDocumentation(openApiSettings, services);
            options.AddSecurityDefinition(JwtBearerDefaults.AuthenticationScheme, SecurityDefinations(openApiSettings));

            // Check for //   [Authorize] attribute on endpoints
            options.OperationFilter<GlobalAuthFilter>();
        });
        return services;
    }

    internal static IApplicationBuilder UseOpenApiConfiguration(this IApplicationBuilder app)
    {
        var apiVersionDescriptionProvider = app.ApplicationServices.GetRequiredService<IApiVersionDescriptionProvider>();

        app.UseSwagger();
        app.UseSwaggerUI(options =>
        {
            foreach (var desc in apiVersionDescriptionProvider.ApiVersionDescriptions)
            {
                options.SwaggerEndpoint($"/swagger/{desc.GroupName}/swagger.json", $"{desc.GroupName}");
            }
        });

        return app;
    }

    private static OpenApiSecurityScheme SecurityDefinations(OpenApiSetting openApiSettings)
    {
        return new OpenApiSecurityScheme
        {
            Name = openApiSettings.JwtSecurityDefinitionName,
            Description = openApiSettings.JwtSecurityDefinitionDescription,
            In = ParameterLocation.Header,
            Type = SecuritySchemeType.Http,
            Scheme = JwtBearerDefaults.AuthenticationScheme,
            BearerFormat = openApiSettings.JwtSecurityDefinitionBearerFormat,
        };
    }

    private static void AddSwaggerDocumentation(this SwaggerGenOptions options, OpenApiSetting openApiSettings, IServiceCollection services)
    {
        var apiVersionDescriptionProvider = services.BuildServiceProvider().GetRequiredService<IApiVersionDescriptionProvider>();

        foreach (var versionDescription in apiVersionDescriptionProvider.ApiVersionDescriptions)
        {
            options.SwaggerDoc(versionDescription.GroupName,
                CreateOpenApiInfo(versionDescription, openApiSettings));
        }
    }
    private static OpenApiInfo CreateOpenApiInfo(
            ApiVersionDescription versionDescription, OpenApiSetting openApiSettings)
    {
        var openApiInfo = new OpenApiInfo
        {
            Version = Convert.ToString(versionDescription.ApiVersion),
            Title = openApiSettings.Title,
            Description = openApiSettings.Description,
            TermsOfService = new Uri(openApiSettings.TermsOfService)
        };

        if (versionDescription.IsDeprecated)
        {
            openApiInfo.Description += " This API version has been deprecated. Please use one of the new APIs available from the explorer.";
        }
        openApiInfo.Contact = new OpenApiContact
        {
            Name = openApiSettings.ContactName,
            Url = new Uri(openApiSettings.ContactUrl)
        };
        openApiInfo.License = new OpenApiLicense
        {
            Name = openApiSettings.LicenseName,
            Url = new Uri(openApiSettings.LicenseUrl)
        };
        return openApiInfo;
    }


}
