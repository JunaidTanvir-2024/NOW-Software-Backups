using CancelBundleApi.Constants.Enums;
using CancelBundleApi.Models.GenericModels;
using CancelBundleApi.Models.RequestModels;
using CancelBundleApi.Services.Interfaces;
using Microsoft.Extensions.Logging;

namespace CancelBundleApi.Services.Implementation;

public sealed class UnSubscribeBundlesRequestService : IUnSubscribeBundlesRequestService
{
    private readonly IUnsubscribeBundleService _bundleService;
    private readonly ILogger<UnSubscribeBundlesRequestService> _logger;
    public UnSubscribeBundlesRequestService(
        IUnsubscribeBundleService bundleService, ILogger<UnSubscribeBundlesRequestService> logger)
    {
        _bundleService = bundleService;
        _logger = logger;
    }

    public async Task<Result<bool>> UnSubscribeService(UnSubscribeBundlesRequest request)
    {
        try
        {
            var result = await _bundleService.UnSubscribeBundle(request);
            if (result == false)
            {
                return Result<bool>.Success(result, CustomStatusKey.BundleUnSubscribeFail);
            }
            return Result<bool>.Success(result, CustomStatusKey.BundleUnSubscribeSuccess);
        }
        catch (Exception ex)
        {
            _logger.LogError($"Message: {ex.Message}, " +
                $"Class: UnSubscribeBundlesRequestService, " +
           $"Method: UnSubscribeService, " +
           $"Exception: {ex.StackTrace}");
            return Result<bool>.Success(false, CustomStatusKey.BundleUnSubscribeFail);
        }
    }
}