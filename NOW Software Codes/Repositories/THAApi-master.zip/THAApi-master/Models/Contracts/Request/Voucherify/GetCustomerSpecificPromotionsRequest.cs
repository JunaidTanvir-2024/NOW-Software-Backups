﻿using Models.Enums;

namespace Models.Contracts.Request.Voucherify
{
    public class GetCustomerSpecificPromotionsRequest
    {
        public decimal Amount { get; set; }
        public string BundleRef { get; set; }
        public CheckOutTypes CheckoutType { get; set; }
		public PaymentMethods PaymentMethod { get; set; }
		public string DestinationCountryISOCode { get; set; }
		public string TransferToMsisdn { get; set; }
		public string Operator { get; set; }
	}
	public class GetCustomerSpecificPromotionRequestV3
	{
		public decimal Amount { get; set; }
		public string BundleRef { get; set; }
		public CheckOutTypes CheckoutType { get; set; }
		public PaymentMethods PaymentMethod { get; set; }
		public string TransferNowtelRef { get; set; }
		public string TransferProduct { get; set; }

	}
}


