﻿namespace Application.Features.AutoTopup.Paypal;

public class SetAutoTopupPaypalRequest : IRequest<Result<SetAutoTopupPaypalResponse>>
{
    public string Msisdn { get; set; } = default!;
    public float TopupAmount { get; set; } = default!;
    public bool Status { get; set; }
    public string? IpAddress { get; set; } = default;
}
public class SetAutoTopupPaypalResponse
{
    public string? RedirectUrl { get; set; }
}