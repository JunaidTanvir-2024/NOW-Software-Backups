﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using TransferHome.Infrastructure.Services.Interfaces;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.Contracts.Response;
using TransferHome.Models.Contracts.Service.Pay360ApiContracts;
using TransferHome.Models.Utility;
using TrasnferHome.Infrastructure.BLL.Interfaces;
using TrasnferHome.Models.Contracts;
using TrasnferHome.Models.Utility;
using PhoneNumbers;
using TransferHome.Infrastructure.BLL.Interfaces;
using TransferHome.Models.DAOs;

namespace TransferHomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Pay360Controller : ControllerBase
    {
        private readonly IPay360Service Pay360Service;
        private readonly IBL_User UserBL;
        private readonly IBL_Transfer TransferBL;
        private readonly ILogger Logger;

        public Pay360Controller(IPay360Service pay360Service, ILogger logger, IBL_User userBl, IBL_Transfer transferBL)
        {
            Pay360Service = pay360Service;
            Logger = logger;
            UserBL = userBl;
            TransferBL = transferBL;
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("GetCutomerInfo")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> GetCutomerInfo([FromBody]GetCutomerInfoRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                GenericApiResponse<GetCutomerInfoResponseModel> response;
                GetCutomerInfoResponseModel responseModel = new GetCutomerInfoResponseModel();

                var userResponse = await UserBL.GetUserById(model.UserId);

                if (userResponse != null)
                {
                    responseModel.Balance = userResponse.Balance;
                    responseModel.BalanceCurrency = userResponse.BalanceCurrency;

                    var cardsResponse = await Pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
                    {
                        customerUniqueRef = string.IsNullOrEmpty(userResponse.Email) ? userResponse.PhoneNumber : userResponse.Email,
                        productCode = "TRH"
                    });

                    if (cardsResponse != null && cardsResponse.errorCode == 0)
                    {
                        responseModel.Pay360Cards = cardsResponse.payload;
                        response = GenericApiResponse<GetCutomerInfoResponseModel>.Success(responseModel, "Success");
                    }
                    else if (cardsResponse != null && cardsResponse.errorCode == (int)PaymentAPIStatusCodes.CustomerNotExist)
                    {

                        response = GenericApiResponse<GetCutomerInfoResponseModel>.Success(responseModel, "Success");
                    }
                    else
                    {
                        response = GenericApiResponse<GetCutomerInfoResponseModel>.Failure("Payment Service not responding at the moment", ApiStatusCodes.PaymentApiNotResponding);
                    }
                }
                else
                {
                    response = GenericApiResponse<GetCutomerInfoResponseModel>.Failure("User not found", ApiStatusCodes.UserNotFound);
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: Topup, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("StartPayment")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> StartPayment([FromBody]Pay360StartPaymentRequestModel model)
        {
            try
            {
                //User logged in and choose One of its card for Payment
                if (model.UserId > 0 && (model.Pay360PaymentType == Pay360PaymentType.Token || model.Pay360PaymentType == Pay360PaymentType.Default))
                {
                    ModelState.Remove("UserCard.NameOnCard");
                    ModelState.Remove("UserCard.CardNumber");
                    ModelState.Remove("UserCard.ExpiryMonth");
                    ModelState.Remove("UserCard.ExpiryYear");
                }

                //User choose payment method other than card
                if (model.Pay360PaymentType == Pay360PaymentType.New || model.Pay360PaymentType == Pay360PaymentType.ExistingNew)
                {
                    ModelState.Remove("UserCard.Token");
                }

                if (model.CheckoutPaymentType != CheckOutTypes.DirectTransfer)
                {
                    ModelState.Remove("TransferTransaction");
                    ModelState.Remove("TransferTransaction.product");
                    ModelState.Remove("TransferTransaction.fromMSISDN");
                    ModelState.Remove("TransferTransaction.operatorid");
                    ModelState.Remove("TransferTransaction.messageToRecipient");
                    ModelState.Remove("TransferTransaction.nowtelTransactionReference");
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var Ref = "";

                if (model.UserId > 0)
                {
                    var user = await UserBL.GetUserById(model.UserId);
                    if (user != null)
                    {
                        if (!string.IsNullOrEmpty(user.PhoneNumber))
                        {
                            model.CustomerPhoneNumber = user.PhoneNumber;
                        }
                        Ref = user.Id.ToString();
                        model.CustomerEmail = string.IsNullOrEmpty(model.CustomerEmail) ? user.Email : model.CustomerEmail;
                        model.Currency = user.BalanceCurrency;
                    }
                    else
                    {
                        GenericApiResponse<Pay360StartPaymentResponseModel>.Failure("User Not Found", ApiStatusCodes.UserNotFound);
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(model.CustomerPhoneNumber) && string.IsNullOrEmpty(model.CustomerEmail))
                    {
                        return BadRequest("Please provide either CustomerPhoneNumber or CustomerEmail");
                    }
                    Ref = !string.IsNullOrEmpty(model.CustomerPhoneNumber) ? model.CustomerPhoneNumber : model.CustomerEmail;
                }

                var Pay360PaymentResponse = await Pay360Service.Pay360Payment(await CreatePay360PaymentRequest(model), model.Pay360PaymentType);
                if (Pay360PaymentResponse != null)
                {
                    if (Pay360PaymentResponse.errorCode > 0)
                    {
                        return Ok(GenericApiResponse<Pay360StartPaymentResponseModel>.Failure(Pay360PaymentResponse.message, ApiStatusCodes.PaymentFailure));
                    }
                    else
                    {
                        if (Pay360PaymentResponse.payload != null)
                        {
                            var payload = Pay360PaymentResponse.payload;
                            string domain = "";
                            if (model.CheckoutPaymentType == CheckOutTypes.DirectTransfer)
                            {
                                var TransferTransactionDb = await TransferBL.GetTransferTransactionByNowtelTransactionReference(model.TransferTransaction.nowtelTransactionReference, model.TransferTransaction.product);
                                if (TransferTransactionDb != null)
                                {
                                    if (model.Currency != TransferTransactionDb.fromCurrency || Convert.ToDecimal(payload.transactionAmount) < Convert.ToDecimal(TransferTransactionDb.CustomerChargeValue))
                                    {
                                        return Ok(GenericApiResponse<Pay360StartPaymentResponseModel>.Failure("Payment amount or currency do not match transfer amount or currency", ApiStatusCodes.PaymentFailure));
                                    }
                                }
                                else
                                {
                                    return Ok(GenericApiResponse<Pay360StartPaymentResponseModel>.Failure("DtOne Db not responding", ApiStatusCodes.DTOneServiceError));
                                }

                                domain = $"https://{this.Request.Host}{this.Request.PathBase}/pay360/SecureReturn?Ref=" + Ref + "&Currency=" + model.Currency + "&Checkout=" + model.CheckoutPaymentType + "&NowtelTransactionRef=" + model.TransferTransaction.nowtelTransactionReference + "&Product=" + model.TransferTransaction.product + "&OperatorId=" + model.TransferTransaction.operatorid + "&MessageToRecipient=" + model.TransferTransaction.messageToRecipient + "&FromMSISDN=" + model.TransferTransaction.fromMSISDN;
                            }
                            else
                            {
                                domain = $"https://{this.Request.Host}{this.Request.PathBase}/pay360/SecureReturn?Ref=" + Ref + "&Checkout=" + model.CheckoutPaymentType + "&Currency=" + model.Currency;
                            }

                            if (payload.outcome.reasonCode == "U100")
                            {
                                var Secure3D = new Secure3DModel()
                                {
                                    url = payload.clientRedirect.url,
                                    pareq = payload.clientRedirect.pareq,
                                    type = payload.clientRedirect.type,
                                    TransactionId = Pay360PaymentResponse.payload.transactionId,
                                    returnUrl = domain
                                };

                                return Ok(GenericApiResponse<Pay360StartPaymentResponseModel>.Success(new Pay360StartPaymentResponseModel() { Secure3D = Secure3D }, "Secure3D is pending."));
                            }
                            else
                            {
                                if (model.CheckoutPaymentType == CheckOutTypes.DirectTransfer)
                                {
                                    var request = new ExecuteDirectTransferRequestModel
                                    {
                                        nowtelTransactionReference = model.TransferTransaction.nowtelTransactionReference,
                                        product = model.TransferTransaction.product,
                                        fromMSISDN = model.TransferTransaction.fromMSISDN,
                                        messageToRecipient = model.TransferTransaction.messageToRecipient,
                                        operatorid = model.TransferTransaction.operatorid,
                                        TransactionType = TransferTransactionType.TRHDT,
                                        PaymentType = PaymentType.Card
                                    };
                                    return Ok(await TransferBL.ExecuteDirectTransfer(request));
                                }
                                else
                                {
                                    var response = await TransferBL.CreditBalance(new DBCredit() { TransactionNumber = payload.transactionId, type = TopUpType.Pay360, Amount = Convert.ToDecimal(model.Amount), Currency = model.Currency, UseId = Convert.ToInt32(Ref) });
                                    return Ok(GenericApiResponse<Pay360SuccessfullPaymentResponseModel>.Success(new Pay360SuccessfullPaymentResponseModel() { CurrentBalance = response, TopupAmount = Convert.ToDecimal(model.Amount) }, "Topup is done successfully."));
                                }
                            }
                        }
                        else
                        {
                            return Ok(GenericApiResponse<Pay360StartPaymentResponseModel>.Failure(Pay360PaymentResponse.message, ApiStatusCodes.PaymentFailure));
                        }
                    }
                }
                else
                {
                    return Ok(GenericApiResponse<Pay360StartPaymentResponseModel>.Failure("Payment service in not responding.", ApiStatusCodes.PaymentApiNotResponding));
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: StartPayment, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        [HttpPost]
        [Route("SecureReturn")]
        public async Task<IActionResult> SecureReturn([FromBody]Secure3DRequestModel model)
        {
            try
            {
                if (model.Checkout != CheckOutTypes.DirectTransfer)
                {
                    ModelState.Remove("NowtelTransactionRef");
                    ModelState.Remove("Product");
                    ModelState.Remove("FromMSISDN");
                    ModelState.Remove("MessageToRecipient");
                    ModelState.Remove("OperatorId");
                }
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                Pay360Resume3DRequest request = new Pay360Resume3DRequest
                {
                    pareq = model.PaRes,
                    pay360TransactionId = model.MD
                };

                var response = await Pay360Service.Resume3DTransaction(request);

                if (response != null)
                {
                    if (response.errorCode > 0)
                    {
                        return Ok(GenericApiResponse<Pay360StartPaymentResponseModel>.Failure(response.message, ApiStatusCodes.PaymentFailure));
                    }
                    else
                    {
                        var payload = response.payload;


                        if (model.Checkout == CheckOutTypes.DirectTransfer)
                        {
                            var TransferRequest = new ExecuteDirectTransferRequestModel
                            {
                                nowtelTransactionReference = model.NowtelTransactionRef,
                                product = model.Product,
                                fromMSISDN = model.FromMSISDN,
                                messageToRecipient = model.MessageToRecipient,
                                operatorid = model.OperatorId,
                                TransactionType = TransferTransactionType.TRHDT,
                                PaymentType = PaymentType.Card
                            };
                            return Ok(await TransferBL.ExecuteDirectTransfer(TransferRequest));
                        }
                        else
                        {
                            var credit = await TransferBL.CreditBalance(new DBCredit() { TransactionNumber = payload.transactionId, Amount = Convert.ToDecimal(payload.transactionAmount), Currency = model.Currency, type = TopUpType.Pay360, UseId = Convert.ToInt32(model.Ref) });
                            return Ok(GenericApiResponse<Pay360SuccessfullPaymentResponseModel>.Success(new Pay360SuccessfullPaymentResponseModel() { CurrentBalance = credit, TopupAmount = Convert.ToDecimal(payload.transactionAmount) }, "Topup is done successfully."));
                        }
                    }
                }
                else
                {
                    return Ok(GenericApiResponse<Pay360StartPaymentResponseModel>.Failure("Payment service in not responding.", ApiStatusCodes.PaymentApiNotResponding));
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: SecureReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        private async Task<Pay360PaymentRequest> CreatePay360PaymentRequest(Pay360StartPaymentRequestModel model)
        {
            List<basket> baskets = new List<basket>();

            basket basket = new basket()
            {
                amount = model.Amount,
                bundleRef = "",
                productItemCode = model.CheckoutPaymentType == CheckOutTypes.DirectTransfer ? ProductItemCode.TRHDT.ToString() : ProductItemCode.TRHAT.ToString(),
                productRef = ""
            };

            baskets.Add(basket);

            Pay360PaymentRequest request = new Pay360PaymentRequest();
            switch (model.Pay360PaymentType)
            {
                case Pay360PaymentType.New:
                    var PaymentNewBaseRequest = Pay360Service.CreatePay360PaymentRequestNew(model);
                    request.Pay360PaymentRequestNew = PaymentNewBaseRequest;
                    request.Pay360PaymentRequestNew.basket = baskets;
                    request.Pay360PaymentRequestNew.customerMsisdn = model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestNew.customerUniqueRef = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestNew.customerEmail = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : string.Empty;
                    request.Pay360PaymentRequestNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestNew.ipAddress = model.IPAddress;
                    request.Pay360PaymentRequestNew.productCode = ProductCode.TRH.ToString();
                    request.Pay360PaymentRequestNew.transactionAmount = model.Amount;
                    break;
                case Pay360PaymentType.Token:
                    var PaymentTokenBaseRequest = Pay360Service.CreatePay360PaymentRequestToken(model);
                    request.Pay360PaymentRequestToken = PaymentTokenBaseRequest;
                    request.Pay360PaymentRequestToken.basket = baskets;
                    request.Pay360PaymentRequestToken.customerMsisdn = model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestToken.customerUniqueRef = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestToken.customerEmail = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : string.Empty;
                    request.Pay360PaymentRequestToken.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestToken.ipAddress = model.IPAddress;
                    request.Pay360PaymentRequestToken.productCode = ProductCode.TRH.ToString();
                    request.Pay360PaymentRequestToken.cardCv2 = model.UserCard.SecurityCode;
                    request.Pay360PaymentRequestToken.transactionAmount = model.Amount;
                    break;
                case Pay360PaymentType.ExistingNew:
                    var PaymentExistingNewBaseRequest = Pay360Service.CreatePay360PaymentRequestExistingNew(model);
                    request.Pay360PaymentRequestExistingNew = PaymentExistingNewBaseRequest;
                    request.Pay360PaymentRequestExistingNew.basket = baskets;
                    request.Pay360PaymentRequestExistingNew.customerMsisdn = model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestExistingNew.customerUniqueRef = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestExistingNew.customerEmail = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : string.Empty;
                    request.Pay360PaymentRequestExistingNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestExistingNew.ipAddress = model.IPAddress;
                    request.Pay360PaymentRequestExistingNew.productCode = ProductCode.TRH.ToString();
                    request.Pay360PaymentRequestExistingNew.cardCv2 = model.UserCard.SecurityCode;
                    request.Pay360PaymentRequestExistingNew.transactionAmount = model.Amount;
                    break;

            }
            return request;
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpGet]
        [Route("GetCustomerCards")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> GetCustomerCards()
        {
            try
            {
                var userResponse = await UserBL.GetUserById(Convert.ToInt32(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value));
                var cardsResponse = await Pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
                {
                    customerUniqueRef = !string.IsNullOrEmpty(userResponse.Email) ? userResponse.Email : userResponse.PhoneNumber,
                    productCode = "TRH"
                });

                if (cardsResponse == null)
                {
                    return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                }

                if (cardsResponse.errorCode == 0)
                {
                    return Ok(GenericApiResponse<object>.Success(cardsResponse.payload.paymentMethodResponses, "Success"));
                }
                else
                {
                    if (cardsResponse.errorCode == (int)PaymentAPIStatusCodes.CustomerNotExist)
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, "Customer not exist", ApiStatusCodes.CardCustomerNotExist));
                    }
                    else
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, cardsResponse.message, ApiStatusCodes.Pay360ServiceError));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: GetCustomerCards , ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("RemoveCustomerCard")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> RemoveCustomerCard(RemoveCustomerCardRequestModel model)
        {
            try
            {
                var userResponse = await UserBL.GetUserById(Convert.ToInt32(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value));
                var customerResponse = await Pay360Service.GetCustomer(new Pay360CustomerRequestModel()
                {
                    customerUniqueRef = !string.IsNullOrEmpty(userResponse.Email) ? userResponse.Email : userResponse.PhoneNumber,
                    productCode = "TRH"
                });

                if (customerResponse == null)
                {
                    return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                }

                if (customerResponse.errorCode == 0)
                {
                    var cardResponse = await Pay360Service.RemoveCard(new RemoveCardRequest()
                    {
                        cardToken = model.CardToken,
                        pay360CustomerID = customerResponse.payload.pay360CustId
                    });

                    if (cardResponse == null)
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                    }
                    if (cardResponse.errorCode == 0)
                    {
                        var AllCardsResponse = await Pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
                        {
                            customerUniqueRef = !string.IsNullOrEmpty(userResponse.Email) ? userResponse.Email : userResponse.PhoneNumber,
                            productCode = "TRH"
                        });

                        return Ok(GenericApiResponse<object>.Success(AllCardsResponse == null || AllCardsResponse.errorCode > 0 ? new List<paymentMethodResponse>() { } : AllCardsResponse.payload.paymentMethodResponses, "Card removed successfully"));
                    }
                    else
                    {
                        if (customerResponse.errorCode == (int)PaymentAPIStatusCodes.CustomerNotExist)
                        {
                            return Ok(GenericApiResponse<object>.Failure(new { }, "Customer not exist", ApiStatusCodes.CardCustomerNotExist));
                        }
                        else
                        {
                            return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                        }
                    }
                }
                else
                {
                    if (customerResponse.errorCode == (int)PaymentAPIStatusCodes.CustomerNotExist)
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, "Customer not exist", ApiStatusCodes.CardCustomerNotExist));
                    }
                    else
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: RemoveCustomerCard , ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("SetCustomerDefaultCard")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> SetCustomerDefaultCard(SetCustomerDefaultCardRequestModel model)
        {
            try
            {
                var userResponse = await UserBL.GetUserById(Convert.ToInt32(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value));
                var customerResponse = await Pay360Service.GetCustomer(new Pay360CustomerRequestModel()
                {
                    customerUniqueRef = !string.IsNullOrEmpty(userResponse.Email) ? userResponse.Email : userResponse.PhoneNumber,
                    productCode = "TRH"
                });

                if (customerResponse == null)
                {
                    return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                }
                if (customerResponse.errorCode == 0)
                {
                    var cardResponse = await Pay360Service.SetCustomerDefaultCard(new SetCustomerDefaultCardRequest()
                    {
                        cardToken = model.CardToken,
                        defaultCardCV2 = model.CardCV2,
                        pay360CustomerID = customerResponse.payload.pay360CustId
                    });

                    if (cardResponse == null)
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                    }

                    if (cardResponse.errorCode == 0)
                    {
                        var AllCardsResponse = await Pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
                        {
                            customerUniqueRef = !string.IsNullOrEmpty(userResponse.Email) ? userResponse.Email : userResponse.PhoneNumber,
                            productCode = "TRH"
                        });

                        return Ok(GenericApiResponse<object>.Success(AllCardsResponse == null || AllCardsResponse.errorCode > 0 ? new List<paymentMethodResponse>() { } : AllCardsResponse.payload.paymentMethodResponses, "Success"));
                    }
                    else
                    {
                        if (cardResponse.errorCode == (int)PaymentAPIStatusCodes.CustomerNotExist)
                        {
                            return Ok(GenericApiResponse<object>.Failure(new { }, "Customer not exist", ApiStatusCodes.CardCustomerNotExist));
                        }
                        else
                        {
                            return Ok(GenericApiResponse<object>.Failure(new { }, cardResponse.message, ApiStatusCodes.Pay360ServiceError));
                        }
                    }
                }
                else
                {
                    if (customerResponse.errorCode == (int)PaymentAPIStatusCodes.CustomerNotExist)
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, "Customer not exist", ApiStatusCodes.CardCustomerNotExist));
                    }
                    else
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: GetCustomerCards , ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("RemoveDefaultCustomerCard")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> RemoveDefaultCustomerCard(RemoveCustomerCardRequestModel model)
        {
            try
            {
                var userResponse = await UserBL.GetUserById(Convert.ToInt32(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value));
                var customerResponse = await Pay360Service.GetCustomer(new Pay360CustomerRequestModel()
                {
                    customerUniqueRef = !string.IsNullOrEmpty(userResponse.Email) ? userResponse.Email : userResponse.PhoneNumber,
                    productCode = "TRH"
                });

                if (customerResponse == null)
                {
                    return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                }

                if (customerResponse.errorCode == 0)
                {
                    var cardResponse = await Pay360Service.RemoveCard(new RemoveCardRequest()
                    {
                        cardToken = model.CardToken,
                        pay360CustomerID = customerResponse.payload.pay360CustId
                    });

                    if (cardResponse == null)
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                    }
                    if (cardResponse.errorCode == 0)
                    {
                        var AllCardsResponse = await Pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
                        {
                            customerUniqueRef = !string.IsNullOrEmpty(userResponse.Email) ? userResponse.Email : userResponse.PhoneNumber,
                            productCode = "TRH"
                        });

                        return Ok(GenericApiResponse<object>.Success(AllCardsResponse == null || AllCardsResponse.errorCode > 0 ? new List<paymentMethodResponse>() { } : AllCardsResponse.payload.paymentMethodResponses, "Card removed successfully"));
                    }
                    else
                    {
                        if (cardResponse.errorCode == (int)PaymentAPIStatusCodes.CustomerNotExist)
                        {
                            return Ok(GenericApiResponse<object>.Failure(new { }, "Customer not exist", ApiStatusCodes.CardCustomerNotExist));
                        }
                        else
                        {
                            return Ok(GenericApiResponse<object>.Failure(new { }, cardResponse.message, ApiStatusCodes.Pay360ServiceError));
                        }
                    }
                }
                else
                {
                    if (customerResponse.errorCode == (int)PaymentAPIStatusCodes.CustomerNotExist)
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, "Customer not exist", ApiStatusCodes.CardCustomerNotExist));
                    }
                    else
                    {
                        return Ok(GenericApiResponse<object>.Failure(new { }, "This service is not available at the moment. Please try again later", ApiStatusCodes.Pay360ServiceError));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360Controller, Method: RemoveDefaultCustomerCard , ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }
    }
}