﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Serilog.Events;
using System.Data;

namespace SenderService.Core.Common.Extensions;
public static class CommonExtension
{
    public static string ConvertToCommaSeparatedString(this List<object> list)
    {
        // Convert all objects in the list to strings
        var stringList = list.ConvertAll(x => x.ToString());

        // Join the strings with commas and return the result
        return string.Join(", ", stringList);
    }
    public static IQueryable<T> GetPaginationResult<T>(this IQueryable<T> queryable, int pageNumber = 1, int pageSize = 50)
    {
        int skip = (pageNumber - 1) * pageSize;
        return queryable.Skip(skip).Take(pageSize);
    }
    public static void CaptureApi(this Serilog.ILogger logger, string requestUrl, string requestBody, string responseBody, int statusCode)
    {
        logger.Write(
            LogEventLevel.Information,
            "API request captured. RequestUrl: {RequestUrl}, RequestBody: {RequestBody}, ResponseBody: {ResponseBody}, StatusCode: {StatusCode}",
            requestUrl,
            requestBody,
            responseBody,
            statusCode);
    }
}