﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public class PaypalTransaction
    {

        public long Id { get; set; }
        public string CustomerMerchantRef { get; set; }

        public long Pay360CustomerId { get; set; }
        public int Customer_Id { get; set; }
        public string TransactionMerchantRef { get; set; }
        public string Pay360TransactionId { get; set; }
        public string TransactionDescription { get; set; }
        public int TransactionStatus_Id { get; set; }
        public int TransactionType_Id { get; set; }
        public double? TransactionAmount { get; set; }
        public string TransactionCurrency { get; set; }
        public DateTime? TransactionTime { get; set; }
        public DateTime? TransactionReceivedTime { get; set; }
        public DateTime? RequestTime { get; set; }
        public string OutcomeStatus { get; set; }
        public string OutcomeReasonCode { get; set; }
        public string OutcomeReasonMessage { get; set; }
        public string AuthAcquirerName { get; set; }
        public string AuthGatewayReference { get; set; }
        public string AuthGatewayMessage { get; set; }
        public string RelatedTransactionId { get; set; }
        public string ClientRedirectUrl { get; set; }
        public string PaypalPayerID { get; set; }
        public string PaypalPayerEmail { get; set; }
        public bool PaypalAccountVerified { get; set; }
        public string PaypalCheckoutToken { get; set; }
        public string UserRequestJson { get; set; }
        public string RequestJsonToPay360 { get; set; }
        public string ResponseJsonFromPay360 { get; set; }
        public string IpAddress { get; set; }
        public bool IsDirectFullfilment { get; set; }
        public string ApiInstallationIdCashierApi { get; set; }

    }
}
