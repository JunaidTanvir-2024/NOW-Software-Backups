﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class TransferByPayPalResponseModel
    {
        public string clientRedirectUrl { get; set; }
        public TransferProduct productData { get; set; }
    }
}
