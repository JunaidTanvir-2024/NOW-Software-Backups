﻿using Serilog.Context;
using Serilog;
using System.Text;

namespace THCC.Api.Middlewares
{
    internal sealed class RequestLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly Serilog.ILogger _logger;
        private readonly IConfiguration _configuration;

        public RequestLoggingMiddleware(
            RequestDelegate next,
            Serilog.ILogger logger,
            IConfiguration configuration)
        {
            _next = next;
            _logger = logger;
            _configuration = configuration;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            if (Convert.ToBoolean(_configuration.GetSection("RequestLoggingSettings:IsActive").Value))
            {
                string requestBody = string.Empty;
                if (httpContext.Request.Path.ToString().Contains("tokens"))
                {
                    requestBody = "[Redacted] Contains Sensitive Information.";
                }
                else
                {
                    var request = httpContext.Request;
                    if (!string.IsNullOrEmpty(request.ContentType)
                        && request.ContentType.StartsWith("application/json"))
                    {
                        request.EnableBuffering();
                        using var reader = new StreamReader(request.Body, Encoding.UTF8, true, 4096, true);
                        requestBody = await reader.ReadToEndAsync();

                        // rewind for next middleware.
                        request.Body.Position = 0;
                    }
                }
                _logger.Debug($"RequestPath:{httpContext.Request.Path} RequestBody:{requestBody}" );
            }

            await _next(httpContext);
        }
    }

    internal static class RequestLoggingMiddlewareExtensions
    {
        internal static IApplicationBuilder UseRequestLogging(this IApplicationBuilder app)
        {
            return app.UseMiddleware<RequestLoggingMiddleware>();
        }
    }
}
