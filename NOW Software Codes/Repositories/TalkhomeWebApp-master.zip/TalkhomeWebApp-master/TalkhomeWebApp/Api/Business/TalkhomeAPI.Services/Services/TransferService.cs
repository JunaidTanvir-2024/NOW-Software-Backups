﻿using Microsoft.Extensions.Options;
using MimeKit;
using Newtonsoft.Json;
using Org.BouncyCastle.Asn1;
using PhoneNumbers;
using Serilog;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.ExtensionMethods;
using TalkhomeAPI.Infrastructure.Common.Models;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Implementations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Airship;
using TalkhomeAPI.Infrastructure.Common.Services.Models.ATTApiContracts;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Configurations;
using TalkhomeAPI.Models.Pay360ApiContracts;
using TalkhomeAPI.Models.PaypalApiContracts;
using TalkhomeAPI.Services.Interfaces;
namespace TalkhomeAPI.Services.Services
{
    public class TransferService : ITransferService
    {
        private readonly IATTService _aTTService;
        private readonly IPayPalService _payPalService;
        private readonly IPay360Service _pay360Service;
        private readonly ILogger _logger;
        private readonly ITransferRepository _transferRepository;
        private readonly IAccountRepository _accountRepository;
        private readonly IAppsFlyerService _appsFlyerService;
        private readonly IAirShipService _airShipService;
        private readonly IHelperService _helperService;
        private readonly IPhoneNumberService _phoneNumberService;
        private readonly IInternationalTopupServiceFeeCalculator _internationalTopupServiceFeeCalculator;
        private readonly IEmailService _emailService;
        private readonly IFaceBookService _faceBookService;

        private readonly Pay360Config _pay360Config;
        private readonly PayPalConfig _payPalConfig;

        private readonly bool TransferIsAuthorization;

        public TransferService(IEmailService emailService,
                                IATTService aTTService,
                                IPayPalService payPalService,
                                IPay360Service pay360Service,
                                ILogger logger,
                                ITransferRepository transferRepository,
                                IAccountRepository accountRepository,
                                IAppsFlyerService appsFlyerService,
                                IOptions<PayPalConfig> paypalConfig,
                                IOptions<Pay360Config> pay360Config,
                                IAirShipService airShipService,
                                IFaceBookService faceBookService,
                                IHelperService helperService,
                                IPhoneNumberService phoneNumberService,
                                IInternationalTopupServiceFeeCalculator internationalTopupServiceFeeCalculator)
        {
            _emailService = emailService;
            _aTTService = aTTService;
            _payPalService = payPalService;
            _pay360Service = pay360Service;
            _logger = logger;
            _transferRepository = transferRepository;
            _accountRepository = accountRepository;
            _appsFlyerService = appsFlyerService;
            _airShipService = airShipService;
            _faceBookService = faceBookService;
            _helperService = helperService;
            _phoneNumberService = phoneNumberService;
            this._internationalTopupServiceFeeCalculator = internationalTopupServiceFeeCalculator;
            _pay360Config = pay360Config.Value;
            _payPalConfig = paypalConfig.Value;
            TransferIsAuthorization = pay360Config.Value.TransferIsAuthorization;
        }

        public async Task<GenericApiResponse<GetProductsResponseModel>> GetProducts(
            string toMsisdn,
            string fromMsisdn,
            string currency)
        {
            var productsResponse = await _aTTService.GetProducts(fromMsisdn.Trim(), toMsisdn.Trim(), currency);

            if (productsResponse == null)
            {
                return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                        "Transfer service for this number is not available at the moment. Please, try again later.",
                        ApiStatusCodes.DTOneServiceError);
            }

            if (productsResponse.errorCode == 0
                    && productsResponse.errorCodeDtOne == 0
                    && productsResponse.payload != null
                    && productsResponse.payload.operators != null
                    && productsResponse.payload.operators.Count > 0)
            {
                var responseData = productsResponse.payload.operators.FirstOrDefault();
                var origin = _phoneNumberService.GetCountryCode(fromMsisdn);
                var destination = _phoneNumberService.GetCountryCode(toMsisdn);

                if (responseData.products != null)
                {
                    var response = new GetProductsResponseModel()
                    {
                        Operator = new ATTOperator()
                        {
                            Accessid = responseData.accessid,
                            Country = responseData.country,
                            IconUri = responseData.iconUri,
                            Id = responseData.id,
                            Name = responseData.name,
                            NowtelTransactionReference = responseData.nowtelTransactionReference
                        }
                    };

                    if (responseData.products.Count > 0)
                    {
                        response.Products = (from item in responseData.products
                                             let fee = _internationalTopupServiceFeeCalculator.Calculate(origin, destination, currency, decimal.Parse(item.itemPriceClientccy))
                                             let totalPrice = decimal.Parse(item.totalPriceClientccy, CultureInfo.InvariantCulture) + fee.totalServiceFee
                                             select new ATTProduct()
                                             {
                                                 ClientCurrecny = item.clientccy,
                                                 ItemPriceClientCurrency = item.itemPriceClientccy,
                                                 Product = item.product,
                                                 ReceiverCurrecny = item.receiverccy,
                                                 TotalPriceClientCurrency = totalPrice.ToString("F"),
                                                 TransactionFeeClientCurrency = item.transactionfeeClientccy,
                                                 orignalAmount = item.orignalAmount,
                                                 discountPercentage = item.discountPercentage,
                                                 ServiceFee = fee.serviceFee.ToString(),
                                                 ServiceFeeDiscount = fee.serviceFeeDiscount.ToString(),
                                                 TotalServiceFee = fee.totalServiceFee.ToString(),
                                             }).ToList();
                    };

                    return GenericApiResponse<GetProductsResponseModel>.Success(response, "products successfully found");
                }
                else
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                        "Transfer service for this number is not available at the moment. Please, try again later.",
                        ApiStatusCodes.DTOneServiceError);
                }
            }
            else
            {
                if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.DenominationsNotAvailable)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                       "Transfer service for this country is not available at the moment. " +
                       "Pease try again later.", ApiStatusCodes.DenominationsNotAvailable);
                }

                else if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.DenominationBlocked)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                        "Transfer service for this number is not available at the moment. " +
                        "Pease try again later.", ApiStatusCodes.DenominationBlocked);
                }
                else if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.OperatorBlocked)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                         "Transfer service for this number is not available at the moment. " +
                         "Pease try again later.", ApiStatusCodes.OperatorBlocked);
                }

                else if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.DestinationMsisdnOutOfRange)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                       "Destination number is invalid", ApiStatusCodes.DestinationMsisdnOutOfRange);
                }

                _logger.Error($"Class: TransferService, Method: GetProducts, " +
                    $"Parameters=> Model : {JsonConvert.SerializeObject(toMsisdn + fromMsisdn + currency)}, " +
                    $"ErrorMessage: {JsonConvert.SerializeObject(productsResponse)}");

                return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                    "Transfer service for this number is not available at the moment. Please, try again later.",
                    ApiStatusCodes.DTOneServiceError);
            }
        }

        public async Task<GenericApiResponse<TransferByAccountBalanceResponseModel>> TransferByAccountBalance(
           TransferByAccountBalanceRequestModel model,
           string msisdn,
           string currency)
        {
            var response = new TransferByAccountBalanceResponseModel();
            var transactionLog = await _transferRepository.GetTransactionLog(model.nowtelRef, model.product);
            if(transactionLog is null)
            {
                transactionLog = await PrepareTransactionLogAsync(model.nowtelRef, model.product, 0);
            }
            var packageDetails = await _transferRepository.
                        GetProductByNowtelTransactionReference(model.nowtelRef, model.product.ToString());

            if (packageDetails == null)
            {
                PrepareUpdateTransactionLog(transactionLog, null, 2, "Invalid product/reference");
                await _transferRepository.UpdateTransactionLog(transactionLog);
                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                            "Invalid product/reference",
                            ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }
            response.productData = packageDetails;


            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            if (accountResponse == null)
            {
				PrepareUpdateTransactionLog(transactionLog, null, 2, "User is not registered");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                           "User is not registered",
                           ApiStatusCodes.UserNotRegistered);
            }

            //var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            //var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            //if (promoResponse != null && promoResponse.payload != null)
            //{
            //    amountToCharge = promoResponse.payload.retAmount;
            //}
            string destination = _phoneNumberService.GetCountryCode(packageDetails.tomsisdn);
            string origination = _phoneNumberService.GetCountryCode(packageDetails.fromMsisdn);
            decimal amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            decimal productAmount = decimal.Parse(packageDetails.fromAmount, CultureInfo.InvariantCulture);
            //calcualte service fee
            var (totalServiceFee, serviceFee, serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, currency, productAmount);
            //deduct service fee
            amountToCharge += totalServiceFee;
            //Validate trasnfer request 
            /*var validationResponse = await ValidateTransferRequest(
                    accountResponse.AccountID,
                    amountToCharge,
                    packageDetails.fromMsisdn,
                    packageDetails.tomsisdn,
                    currency
                );

            if (validationResponse == TransferValidationResponse.DailyLimitExceeded)
            {
                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                                             "Your daily limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
            }
            else if (validationResponse == TransferValidationResponse.Unauthorized)
            {
                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                                             "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
            }*/


            var custValidate = await ValidateNowtelCustomerNew(packageDetails.fromMsisdn, packageDetails.GUID, packageDetails.product, amountToCharge);

            if (custValidate.isAllowed != 1)
            {


                _logger.Error($"Class: TransferService, Method: TransferByAccountBalance, Parameters=> Model :" +
                            $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(custValidate)} ,frommisdn: {packageDetails.fromMsisdn},tomisdn: {packageDetails.tomsisdn}, nowtelref : {packageDetails.GUID}");
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Customer validation failed");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                            "Sorry we were not able to complete the transaction at the moment, please try again later",
                                                        ApiStatusCodes.TransferServiceNotAvailable);
            }

            if (accountResponse.Balance < amountToCharge)
            {
                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                                            "Balance is insufficient", ApiStatusCodes.InsufficientBalance);
            }

            //Send Credit
            var transferResponse = await _aTTService.Execute(new ExecuteDataRequest()
            {
                fromMSISDN = packageDetails.fromMsisdn,
                messageToRecipient = string.Empty,
                nowtelTransactionReference = packageDetails.GUID,
                operatorid = model.operatorId.ToString(),
                product = model.product.ToString()
            });

            if (transferResponse == null)
            {
                _logger.Error($"Class: TransferService, Method: TransferByAccountBalance, Parameters=> Model :" +
                            $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(transferResponse)}");
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Balance transfer failed");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                            "Something went wrong on server",
                                                        ApiStatusCodes.InternalServerError);
            }

            var paymentResponse = new DBAccountBalance();

            if (transferResponse.errorCode == "0")
            {
                //Deduct Balance passing actual value because sp is deducting the promo amount already in case of credit 
                paymentResponse = await _transferRepository.UpdateAccountBalance(
                                                -amountToCharge, accountResponse.AccountID, "");
            }

            //Save transaction


            await _transferRepository.SaveTransaction(new DBTransferTransaction()
            {
                AccountId = accountResponse.AccountID,
                ClientCurrecny = packageDetails.fromCurrency,
                CountryCode = destination,
                FromMsisdn = packageDetails.fromMsisdn,
                ToMsisdn = packageDetails.tomsisdn,
                ItemPrice = productAmount,
                ServiceFee = serviceFee,
                ServiceFeeDiscount = serviceFeeDiscount,
                TotalServiceFee = totalServiceFee,
                TotalPrice = amountToCharge,
                NowtelRef = packageDetails.GUID,
                OperatorCountryName = packageDetails.operatorCountryName,
                OperatorLogoUrl = packageDetails.operatorLogoUrl,
                OperatorName = packageDetails.operatorName,
                Product = Convert.ToDecimal(packageDetails.product),
                ReceiverCurrecny = packageDetails.toCurrency,
                PaymentTypeId = PaymentType.AccountBalance,

                PaymentRef = paymentResponse != null && !string.IsNullOrEmpty(paymentResponse.audit_id)
                            ? paymentResponse.audit_id : null,

                TransferRef = transferResponse != null && transferResponse.errorCode == "0"
                            ? transferResponse.reference : null,

                StatusId = transferResponse != null && transferResponse.errorCode == "0"
                            ? TransferTransactionStatus.Success : TransferTransactionStatus.Failure
            });

            if (transferResponse.errorCode == "0")
            {
                //await HandleIntTopupEvents(toNumberCountryCode, FromNumberCountryCode, null, false, false, packageDetails.fromMsisdn, 0, 0, currency);

                if (paymentResponse == null)
                {

                    _logger.Error($"Class: TransferService, Method: TransferByAccountBalance-BalanceDeduction, Parameters=> Model :" +
                                     $" {JsonConvert.SerializeObject(model)}, Error: NULL Response - Need to deduct");

                    //return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                    //                            "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
                else if (string.IsNullOrEmpty(paymentResponse.audit_id))
                {
                    _logger.Error($"Class: TransferService, Method: TransferByAccountBalance-BalanceDeduction, Parameters=> Model :" +
                            $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(paymentResponse)},  - Need to deduct");

                    //return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                    //                            "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            if (transferResponse.errorCode != "0")
            {
                await HandleIntTopupEvents(destination, origination, null, false, false, packageDetails.fromMsisdn, 0, 0, currency);

                _logger.Error($"Class: TransferService, Method: TransferByAccountBalance, Parameters=> Model :" +
                                $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(transferResponse)}");

                if (transferResponse.errorCode == "3")
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "transfer not authorized");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                                            "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
                }

                if (!string.IsNullOrEmpty(transferResponse.errorCodeDtOne))
                {
                    int AttErrorCode = Convert.ToInt32(transferResponse.errorCodeDtOne);

                    if (AttErrorCode == (int)ATTStatusCodes.TopupNumberLimitExceed)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Recipient reached maximum topup number");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                            "Recipient reached maximum topup number.", ApiStatusCodes.TopupNumberLimitExceed);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.TopupAmountLimitExceed)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Recipient reached maximum topup amount");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                            "Recipient reached maximum topup amount.", ApiStatusCodes.TopupAmountLimitExceed);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationsNotAvailable)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this number is not available at the moment.");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
							"Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.DenominationsNotAvailable);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationBlocked)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this number is not available at the moment.");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
							"Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.DenominationBlocked);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.OperatorBlocked)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this number is not available at the moment.");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                            "Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.OperatorBlocked);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DestinationMsisdnOutOfRange)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Destination number is invalid.");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                            "Destination number is invalid.", ApiStatusCodes.DestinationMsisdnOutOfRange);
                    }
                }
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service is not responding at the moment");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(response,
                                "Transfer service is not responding at the moment", ApiStatusCodes.DTOneServiceError);
            }

            //Need to send email

            try
            {
                int isFirstiTopup = await _transferRepository.IsFirstInternationTopup(accountResponse.AccountID);
                var customerResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + packageDetails.fromMsisdn);

                await HandleIntTopupEvents(destination, origination, null, false, true, packageDetails.fromMsisdn, paymentResponse.new_balance / 100, amountToCharge, currency);

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferService, Method: TransferByAccountBalance-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            var userProfile = await _accountRepository.GetUserByPhoneNumber(packageDetails.fromMsisdn);
            if (!string.IsNullOrEmpty(userProfile?.email))
            {
                await SendInternationalTopupPaymentReceiptAsync(userProfile.email, packageDetails, userProfile, "AccountBalance",totalServiceFee,decimal.Zero,string.Empty,0,transferResponse.reference,transferResponse.pinCode);
            }
			PrepareUpdateTransactionLog(transactionLog, null, 1, "Success");
			await _transferRepository.UpdateTransactionLog(transactionLog);
			//Send Response
			return GenericApiResponse<TransferByAccountBalanceResponseModel>.Success(
                new TransferByAccountBalanceResponseModel()
                {
                    RemainingBalance = paymentResponse.new_balance / 100,
                    TransferData = new TransferData()
                    {
                        TransactionId = transferResponse.reference,
                        fromAmount = amountToCharge.ToString(),
                        toAmount = packageDetails.product,
                        fromCurrency = packageDetails.fromCurrency,
                        fromMsisdn = packageDetails.fromMsisdn,
                        toCurrency = packageDetails.toCurrency,
                        toMsisdn = packageDetails.tomsisdn,
                        toCountry = destination,
                        fromCountry = origination,
                        operatorName = packageDetails.operatorName,
                    }
                }, "Successfull top-up");
        }

        public async Task<GenericApiResponse<GetSpecialPromotionBalanceToDeductResponseModel>> GetSpecialPromotionBalanceToDeduct(
            string msisdn,
            decimal amount,
            string nowtelRef=null,
            string product=null)
        {

            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            if (accountResponse == null)
            {
                return GenericApiResponse<GetSpecialPromotionBalanceToDeductResponseModel>.Failure(null,
                           "User is not registered",
                           ApiStatusCodes.UserNotRegistered);
            }
            if(!string.IsNullOrEmpty(nowtelRef) && !string.IsNullOrEmpty(product))
            {
                var transactionLog=await _transferRepository.GetTransactionLog(nowtelRef, product);
                if(transactionLog is null)
                {
                    transactionLog = await PrepareTransactionLogAsync(nowtelRef, product);
                    await _transferRepository.CreateTransactionLogAsync(transactionLog);
                }
            }

            //Deduct Balance
            var promoResponse = await _transferRepository.GetSpecialPromotionBalanceToDeduct(
                                            amount, accountResponse.AccountID);

            if (promoResponse == null)
            {
                return GenericApiResponse<GetSpecialPromotionBalanceToDeductResponseModel>.Failure(null,
                                            "Service is not responding", ApiStatusCodes.PaymentServiceError);
            }

            //Send Response
            return GenericApiResponse<GetSpecialPromotionBalanceToDeductResponseModel>.Success(
                new GetSpecialPromotionBalanceToDeductResponseModel()
                {
                    retAmount = promoResponse.retAmount,
                    retcreditReason = promoResponse.retcreditReason
                }, "Successfull");
        }

        public async Task<GenericApiResponse<TransferByPayPalResponseModel>> TransferByPayPal(
            TransferByPayPalRequestModel model,
            string msisdn,
            string currency,
            string account)
        {
            var response = new TransferByPayPalResponseModel();
            var transactionLog = await _transferRepository.GetTransactionLog(model.nowtelRef, model.product);
            if(transactionLog is null)
            {
                transactionLog = await PrepareTransactionLogAsync(model.nowtelRef, model.product, 0);
                await _transferRepository.CreateTransactionLogAsync(transactionLog);
            }
            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(model.nowtelRef, model.product.ToString());
            if (packageDetails == null)
            {
                PrepareUpdateTransactionLog(transactionLog, null, 2, "Invalid product/reference");
                await _transferRepository.UpdateTransactionLog(transactionLog);
                return GenericApiResponse<TransferByPayPalResponseModel>.Failure(
                                    null, "Invalid product/reference",
                                    ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }
            response.productData = packageDetails;


            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }
            var productAmount = decimal.Parse(packageDetails.fromAmount, CultureInfo.InvariantCulture);
            //calculate service fee
            var origination = _phoneNumberService.GetCountryCode(packageDetails.fromMsisdn);
            var destination = _phoneNumberService.GetCountryCode(packageDetails.tomsisdn);
            var (totalServiceFee, serviceFee, serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, currency, productAmount);
            //deduct service fee
            amountToCharge += totalServiceFee;
            //Validate trasnfer request 
            /*var validationResponse = await ValidateTransferRequest(
                    account,
                    amountToCharge,
                    packageDetails.fromMsisdn,
                    packageDetails.tomsisdn,
                    currency
                );

            if (validationResponse == TransferValidationResponse.DailyLimitExceeded)
            {
                return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                             "Your daily limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
            }
            else if (validationResponse == TransferValidationResponse.Unauthorized)
            {
                return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                             "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
            }*/

            var custValidate = await ValidateNowtelCustomerNew(packageDetails.fromMsisdn, packageDetails.GUID, packageDetails.product, amountToCharge);

            if (custValidate.isAllowed != 1)
            {
                _logger.Error($"Class: TransferService, Method: TransferByPayPal, Parameters=> Model :" +
                            $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(custValidate)} ,frommisdn: {packageDetails.fromMsisdn},tomisdn: {packageDetails.tomsisdn}, nowtelref : {packageDetails.GUID}");
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Invalid product/reference");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                             "Sorry we were not able to complete the transaction at the moment, please try again later", ApiStatusCodes.TransferServiceNotAvailable);
            }


            //Get user details
            var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);

            if (_payPalConfig.IsPaypalByPay360)
            {
                //Get User Registration Date
                var userRegistrationDate = await _accountRepository.GetUserRegistrationDate(account);

                var request = new PayPalByPay360CSPaymentRequest()
                {
                    Basket = new List<PayPalByPay360Basket>() {
                        new PayPalByPay360Basket()
                        {
                            amount = Convert.ToSingle(amountToCharge),
                            bundleRef = "",
                            productItemCode = ProductItemCode.THADTW.ToString(),
                            productRef = ""
                        }
                    },
                    ipAddress = model.ipAddress,

                    CustomerName = userResponse != null ? !string.IsNullOrEmpty(userResponse.firstname)
                                                                    ? userResponse.firstname : msisdn : msisdn,
                    CustomerMsisdn = msisdn,
                    CustomerEmail = userResponse != null ? !string.IsNullOrEmpty(userResponse.email)
                                                                    ? userResponse.email : string.Empty : string.Empty,
                    transactionCurrency = currency,
                    transactionAmount = Convert.ToSingle(amountToCharge),
                    PaymentMethod = new PayPalByPay360PaymentMethod()
                    {
                        Paypal = new PayPalByPay360Urls()
                        {
                            returnUrl = _payPalConfig.TransferSettings.PayPalByPay360ReturnUrl +
                                        "nowtelRef=" + model.nowtelRef +
                                        "&product=" + model.product + "&operatorId=" + model.operatorId,

                            cancelUrl = _payPalConfig.TransferSettings.CancelUrl +
                                            "?destination=" + packageDetails.tomsisdn +
                                            "&network=" + packageDetails.operatorName.Trim().Replace(" ", "-") +
                                            "&amount=" + packageDetails.CustomerChargeValue +
                                            "&id=" + packageDetails.GUID
                        }
                    },
                    CustomFields = new PayPalByPay360CustomField()
                    {
                        fieldState = new List<PayPalByPay360FieldState>()
                            {
                                new PayPalByPay360FieldState() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
                                new PayPalByPay360FieldState() { name = "ProductItemCode", value = ProductItemCode.THADTW.ToString(), transient = false },
                                new PayPalByPay360FieldState() { name = "FirstUseDate",
                                    value = userRegistrationDate.ToString("yyyy-MM-dd"), transient = false },
                                new PayPalByPay360FieldState() { name = "ANumber", value = packageDetails.fromMsisdn, transient = false },
                                new PayPalByPay360FieldState() { name = "BNumber", value = packageDetails.tomsisdn, transient = false }
                            }
                    },
                    CustomerUniqueRef = msisdn,
                    ProductCode = ProductCode.THA.ToString(),
                };

                var paymentResponse = await _payPalService.PayPalByPay360CS(request);

                if (paymentResponse == null)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                  "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }

                if (paymentResponse.errorCode > 0)
                {
                    if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Your daily payment limit is exceeded");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                            "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                    }
                    else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, paymentResponse.message);
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                                paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                    }
                    else
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                            "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                    }
                }
				PrepareUpdateTransactionLog(transactionLog, null, 0, "Payment created successfully");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalResponseModel>.Success(
                    new TransferByPayPalResponseModel()
                    {
                        clientRedirectUrl = paymentResponse.payload.clientRedirectUrl
                    }, "Payment created successfully");

            }
            else
            {
                var baskets = new List<ProductBasket>();
                var basket = new ProductBasket()
                {
                    Amount = Convert.ToSingle(amountToCharge),
                    BundleRef = "",
                    ProductItemCode = ProductItemCode.THADTW.ToString(),
                    ProductRef = ""
                };

                baskets.Add(basket);

                var request = new PayPalCreateSalePaymentRequest
                {
                    CustomerName = userResponse != null ? !string.IsNullOrEmpty(userResponse.firstname)
                                                                                        ? userResponse.firstname : msisdn : msisdn,
                    CustomerMsisdn = msisdn,
                    CustomerUniqueRef = msisdn,
                    CustomerEmail = userResponse != null ? !string.IsNullOrEmpty(userResponse.email)
                                                                                        ? userResponse.email : string.Empty : string.Empty,
                    ProductCode = ProductCode.THA.ToString(),
                    Transaction = new Transactions()
                    {
                        Amount = new Amounts()
                        {
                            Total = Convert.ToSingle(amountToCharge),
                            Currency = currency
                        },
                        Description = "Transfer payment request from THA-Home"
                    },
                    RedirectUrl = new RedirectUrls
                    {
                        ReturnUrl = _payPalConfig.TransferSettings.PayPalReturnUrl +
                                           "nowtelRef=" + model.nowtelRef +
                                           "&product=" + model.product + "&operatorId=" + model.operatorId,

                        CancelUrl = _payPalConfig.TransferSettings.CancelUrl
                    },
                    Basket = baskets
                };

                var paymentResponse = await _payPalService.PayPalCreateSalePayment(request);

                if (paymentResponse == null)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                  "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }

                if (paymentResponse.errorCode > 0)
                {
                    _logger.Error($"Class: TransferService, Method: TransferByPayPal - PaymentResponse - V1, " +
                                            $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                            $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                    if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Your daily payment limit isi exceeded");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                            "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                    }
                    else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2,paymentResponse.message);
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                                paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                    }
                    else
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalResponseModel>.Failure(response,
                                            "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                    }
                }

                response.clientRedirectUrl = paymentResponse.payload.RedirectUrl;
				PrepareUpdateTransactionLog(transactionLog, null, 0, "Payment create successfully");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalResponseModel>.Success(response, "Payment created successfully");
            }
        }

        public async Task<GenericApiResponse<TransferByPayPalCallBackResponseModel>> TransferByPayPalCallBackV2(
            TransferByPayPalCallBackV2RequestModel model,
            string msisdn,
            string currency)
        {
            var transactionLog = await _transferRepository.GetTransactionLog(model.NowtelRef, model.Product);
            if(transactionLog is null)
            {
                transactionLog = await PrepareTransactionLogAsync(model.NowtelRef, model.Product);
                await _transferRepository.CreateTransactionLogAsync(transactionLog);
            }
            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(model.NowtelRef, model.Product);
            if (packageDetails == null)
            {
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Invalid product/reference");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                            "Invalid product/reference",
                            ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }

            var response = new TransferByPayPalCallBackResponseModel();
            response.productData = packageDetails;

            var paymentResponse = await _payPalService.PayPalByPay360ES(
                new PayPalByPay360ESPaymentRequest()
                {
                    PaypalCheckoutToken = model.Token
                });

            if (paymentResponse == null)
            {
                _logger.Error($"Class: TransferService, Method: TransferByPayPalCallBackV2 - PaymentResponse, " +
                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                     $"Response => Model : NULL");
				//try
				//{
				//    //send payment not captured email
				//    string messageBody = "Paypal Payment Execute Failed! , Transfered Sucessfully! ---> Request: " + JsonConvert.SerializeObject(model) + " , Response: null";

				//    await _emailService.SendEmail("usama.kiyani@now.net.pk", messageBody, false, "Paypal Payment Execution Failed - THADTW");
				//}
				//catch
				//{

				//}
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
            }
            if (paymentResponse.errorCode > 0)
            {
                //try
                //{
                //    //send payment not captured email
                //    string messageBody = "Paypal Payment Execute Failed! , Transfered Sucessfully! ---> Request: " + JsonConvert.SerializeObject(model) + " Response: " + JsonConvert.SerializeObject(paymentResponse) + "";

                //    await _emailService.SendEmail("usama.kiyani@now.net.pk", messageBody, false, "Paypal Payment Execution Failed - THADTW");
                //}
                //catch
                //{

                //}

                _logger.Error($"Class: TransferService, Method: TransferByPayPalCallBackV2 - PaymentResponse, " +
                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Your daily payment limit is exceeded");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, paymentResponse.message);
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            //Send Credit
            var transferResponse = await _aTTService.Execute(
                new ExecuteDataRequest()
                {
                    fromMSISDN = packageDetails.fromMsisdn,
                    messageToRecipient = string.Empty,
                    nowtelTransactionReference = packageDetails.GUID,
                    operatorid = model.OperatorId,
                    product = model.Product
                });

            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);

            //Get account details
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            if (accountResponse == null)
            {
				PrepareUpdateTransactionLog(transactionLog, null, 2, "User is not registered");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                           "User is not registered",
                           ApiStatusCodes.UserNotRegistered);
            }

            //Save transaction

            string toNumberCountryCode = _phoneNumberService.GetCountryCode(packageDetails.tomsisdn);
            string FromNumberCountryCode = _phoneNumberService.GetCountryCode(packageDetails.fromMsisdn);

            await _transferRepository.SaveTransaction(new DBTransferTransaction()
            {
                AccountId = accountResponse.AccountID,
                ClientCurrecny = packageDetails.fromCurrency,
                CountryCode = toNumberCountryCode,
                FromMsisdn = packageDetails.fromMsisdn,
                ToMsisdn = packageDetails.tomsisdn,
                ItemPrice = amountToCharge,
                TotalPrice = amountToCharge,
                NowtelRef = packageDetails.GUID,
                OperatorCountryName = packageDetails.operatorCountryName,
                OperatorLogoUrl = packageDetails.operatorLogoUrl,
                OperatorName = packageDetails.operatorName,
                Product = Convert.ToDecimal(packageDetails.product),
                ReceiverCurrecny = packageDetails.toCurrency,
                PaymentTypeId = PaymentType.Paypal,
                PaymentRef = (paymentResponse != null && paymentResponse.errorCode == 0 && paymentResponse.payload != null)
                                    ? paymentResponse.payload.transactionId : null,
                TransferRef = transferResponse != null && transferResponse.errorCode == "0"
                                        ? transferResponse.reference : null,
                StatusId = transferResponse != null && transferResponse.errorCode == "0"
                                        ? TransferTransactionStatus.Success : TransferTransactionStatus.Failure
            });

            if (transferResponse == null)
            {
                await HandleIntTopupEvents(toNumberCountryCode, FromNumberCountryCode, false, false, false, packageDetails.fromMsisdn, 0, 0, currency);

                _logger.Error($"Class: TransferService, Method: TransferByPayPalCallBackV2, Parameters=> Model :" +
                                                $" {JsonConvert.SerializeObject(packageDetails)}, " +
                                                $"Error:{JsonConvert.SerializeObject(transferResponse)}, Response: NULL");
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Balance transfer failed");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                                "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (transferResponse.errorCode != "0")
            {
                await HandleIntTopupEvents(toNumberCountryCode, FromNumberCountryCode, false, false, false, packageDetails.fromMsisdn, 0, 0, currency);

                _logger.Error($"Class: TransferService, Method: TransferByPayPalCallBackV2, Parameters=> Model :" +
                                $" {JsonConvert.SerializeObject(packageDetails)}, " +
                                $"Error:{JsonConvert.SerializeObject(transferResponse)}");

                if (transferResponse.errorCode == "3")
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer not authorized");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                                "Transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
                }

                if (!string.IsNullOrEmpty(transferResponse.errorCodeDtOne))
                {
                    int AttErrorCode = Convert.ToInt32(transferResponse.errorCodeDtOne);

                    if (AttErrorCode == (int)ATTStatusCodes.TopupNumberLimitExceed)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Recepient reached maximum topup number");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Recipient reached maximum topup number.", ApiStatusCodes.TopupNumberLimitExceed);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.TopupAmountLimitExceed)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Recipient reached maximum topup amount");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Recipient reached maximum topup amount.", ApiStatusCodes.TopupAmountLimitExceed);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationsNotAvailable)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this country is not avilalbe at the moment");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Transfer service for this country is not available at the moment.",
                            ApiStatusCodes.DenominationsNotAvailable);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationBlocked)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this number is not available at the moment");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.DenominationBlocked);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.OperatorBlocked)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this number is not available at the moment");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.OperatorBlocked);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DestinationMsisdnOutOfRange)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Destination number is invalid");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Destination number is invalid.", ApiStatusCodes.DestinationMsisdnOutOfRange);
                    }
                }
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Server error");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                "", ApiStatusCodes.DTOneServiceError);
            }

            //Events
            try
            {
                var isFirstiTopup = await _transferRepository.IsFirstInternationTopup(accountResponse.AccountID);
                var customerResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + packageDetails.fromMsisdn);

                await HandleIntTopupEvents(toNumberCountryCode, FromNumberCountryCode, false, false, true, packageDetails.fromMsisdn, customerResponse.Balance, amountToCharge, currency);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferService, Method: SendTransferByPayPal-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }

            var userProfile = await _accountRepository.GetUserByPhoneNumber(packageDetails.fromMsisdn);
            if (!string.IsNullOrEmpty(userProfile?.email))
            {
                await SendInternationalTopupPaymentReceiptAsync(userProfile.email, packageDetails, userProfile, "PayPal",decimal.Zero,decimal.Zero,string.Empty,0, transferResponse.reference, transferResponse.pinCode);
            }
			PrepareUpdateTransactionLog(transactionLog, null, 1, "Success");
			await _transferRepository.UpdateTransactionLog(transactionLog);
			//Send Response
			return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Success(
                new TransferByPayPalCallBackResponseModel()
                {
                    TransferData = new TransferData()
                    {
                        TransactionId = transferResponse.reference,
                        fromAmount = amountToCharge.ToString(),
                        toAmount = packageDetails.product,
                        fromCurrency = packageDetails.fromCurrency,
                        toCurrency = packageDetails.toCurrency,
                        fromMsisdn = packageDetails.fromMsisdn,
                        toMsisdn = packageDetails.tomsisdn,
                        fromCountry = FromNumberCountryCode,
                        toCountry = toNumberCountryCode,
                        operatorName = packageDetails.operatorName
                    }
                }, "Successfull top-up");
        }
        public async Task<GenericApiResponse<TransferByPayPalCallBackResponseModel>> TransferByPayPalCallBackV1(
            TransferByPayPalCallBackV1RequestModel model,
            string msisdn,
            string currency)
        {
            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(model.NowtelRef, model.Product.ToString());
            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                            "Invalid product/reference",
                            ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }
            var transactionLog = await _transferRepository.GetTransactionLog(model.NowtelRef, model.Product.ToString());
            if(transactionLog is null)
            {
                transactionLog = await PrepareTransactionLogAsync(model.NowtelRef, model.Product.ToString());
                await _transferRepository.CreateTransactionLogAsync(transactionLog);
            }
            var response = new TransferByPayPalCallBackResponseModel();
            response.productData = packageDetails;
            var origination = _phoneNumberService.GetCountryCode(packageDetails.fromMsisdn);
            var destination = _phoneNumberService.GetCountryCode(packageDetails.tomsisdn);
            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var productAmount = decimal.Parse(packageDetails.fromAmount, CultureInfo.InvariantCulture);
            //calcualte service fee
            var (totalServiceFee, serviceFee, serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, currency, productAmount);
            //deduct service fee
            amountToCharge += totalServiceFee;
            var paymentResponse = await _payPalService.PayPalExecuteSalePayment(
                new PayPalExecuteSalePaymentRequest()
                {
                    CustomerUniqueRef = msisdn,
                    PayerId = model.PayerID,
                    PaymentId = model.PaymentId,
                    ProductCode = ProductCode.THA.ToString()
                });

            if (paymentResponse == null)
            {
                _logger.Error($"Class: TransferService, Method: TransferByPayPalCallBackV2 - PaymentResponse, " +
                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                     $"Response => Model : NULL");
                //try
                //{
                //    //send payment not captured email
                //    string messageBody = "Paypal Payment Execute Failed! , Transfered Sucessfully! ---> Request: " + JsonConvert.SerializeObject(model) + " , Response: null";

                //    await _emailService.SendEmail("usama.kiyani@now.net.pk", messageBody, false, "Paypal Payment Execution Failed - THADTW");
                //}
                //catch
                //{

                //}
                PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment serivce is not responding");
                await _transferRepository.UpdateTransactionLog(transactionLog);
                return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
            }
            if (paymentResponse.errorCode > 0)
            {
                //try
                //{
                //    //send payment not captured email
                //    string messageBody = "Paypal Payment Execute Failed! , Transfered Sucessfully! ---> Request: " + JsonConvert.SerializeObject(model) + " Response: " + JsonConvert.SerializeObject(paymentResponse) + "";

                //    await _emailService.SendEmail("usama.kiyani@now.net.pk", messageBody, false, "Paypal Payment Execution Failed - THADTW");
                //}
                //catch
                //{

                //}

                _logger.Error($"Class: TransferService, Method: TransferByPayPalCallBackV2 - PaymentResponse, " +
                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Your daily payment limit is exceeded");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, paymentResponse.message);
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment serivce is not responding");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            //Send Credit
            var transferResponse = await _aTTService.Execute(
                new ExecuteDataRequest()
                {
                    fromMSISDN = packageDetails.fromMsisdn,
                    messageToRecipient = string.Empty,
                    nowtelTransactionReference = packageDetails.GUID,
                    operatorid = model.OperatorId.ToString(),
                    product = model.Product.ToString()
                });


            //Get account details
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            if (accountResponse == null)
            {
				PrepareUpdateTransactionLog(transactionLog, null, 2, "User is not registered");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                           "User is not registered",
                           ApiStatusCodes.UserNotRegistered);
            }

            //Save transaction

            string toNumberCountryCode = _phoneNumberService.GetCountryCode(packageDetails.tomsisdn);
            string FromNumberCountryCode = _phoneNumberService.GetCountryCode(packageDetails.fromMsisdn);

            await _transferRepository.SaveTransaction(new DBTransferTransaction()
            {
                AccountId = accountResponse.AccountID,
                ClientCurrecny = packageDetails.fromCurrency,
                CountryCode = toNumberCountryCode,
                FromMsisdn = packageDetails.fromMsisdn,
                ToMsisdn = packageDetails.tomsisdn,
                TotalPrice = amountToCharge,
                ItemPrice = productAmount,
                ServiceFee = serviceFee,
                ServiceFeeDiscount = serviceFeeDiscount,
                TotalServiceFee = totalServiceFee,
                NowtelRef = packageDetails.GUID,
                OperatorCountryName = packageDetails.operatorCountryName,
                OperatorLogoUrl = packageDetails.operatorLogoUrl,
                OperatorName = packageDetails.operatorName,
                Product = Convert.ToDecimal(packageDetails.product),
                ReceiverCurrecny = packageDetails.toCurrency,
                PaymentTypeId = PaymentType.Paypal,
                PaymentRef = (paymentResponse != null && paymentResponse.errorCode == 0 && paymentResponse.payload != null)
                                    ? paymentResponse.payload.PaypalTransactionId.ToString() : null,
                TransferRef = transferResponse != null && transferResponse.errorCode == "0"
                                        ? transferResponse.reference : null,
                StatusId = transferResponse != null && transferResponse.errorCode == "0"
                                        ? TransferTransactionStatus.Success : TransferTransactionStatus.Failure
            });

            if (transferResponse == null)
            {
                await HandleIntTopupEvents(toNumberCountryCode, FromNumberCountryCode, false, false, false, packageDetails.fromMsisdn, 0, 0, currency);

                _logger.Error($"Class: TransferService, Method: TransferByPayPalCallBackV2, Parameters=> Model :" +
                                                $" {JsonConvert.SerializeObject(packageDetails)}, " +
                                                $"Error:{JsonConvert.SerializeObject(transferResponse)}, Response: NULL");
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Balance transfer failed");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                                "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (transferResponse.errorCode != "0")
            {
                await HandleIntTopupEvents(toNumberCountryCode, FromNumberCountryCode, false, false, false, packageDetails.fromMsisdn, 0, 0, currency);

                _logger.Error($"Class: TransferService, Method: TransferByPayPalCallBackV2, Parameters=> Model :" +
                                $" {JsonConvert.SerializeObject(packageDetails)}, " +
                                $"Error:{JsonConvert.SerializeObject(transferResponse)}");

                if (transferResponse.errorCode == "3")
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer not authorized");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                                "Transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
                }

                if (!string.IsNullOrEmpty(transferResponse.errorCodeDtOne))
                {
                    int AttErrorCode = Convert.ToInt32(transferResponse.errorCodeDtOne);

                    if (AttErrorCode == (int)ATTStatusCodes.TopupNumberLimitExceed)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Recipient reached maximum topup number.");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Recipient reached maximum topup number.", ApiStatusCodes.TopupNumberLimitExceed);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.TopupAmountLimitExceed)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Recipient reached maximum topup amount.");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Recipient reached maximum topup amount.", ApiStatusCodes.TopupAmountLimitExceed);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationsNotAvailable)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this country is not available at the moment.");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Transfer service for this country is not available at the moment.",
                            ApiStatusCodes.DenominationsNotAvailable);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationBlocked)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this number is not available at the moment.");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.DenominationBlocked);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.OperatorBlocked)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this number is not available at the moment.");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.OperatorBlocked);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DestinationMsisdnOutOfRange)
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Destination number is invalid.");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                            "Destination number is invalid.", ApiStatusCodes.DestinationMsisdnOutOfRange);
                    }
                }
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Error");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(response,
                                "", ApiStatusCodes.DTOneServiceError);
            }

            //Events
            try
            {
                var isFirstiTopup = await _transferRepository.IsFirstInternationTopup(accountResponse.AccountID);
                var customerResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + packageDetails.fromMsisdn);

                await HandleIntTopupEvents(toNumberCountryCode, FromNumberCountryCode, false, false, true, packageDetails.fromMsisdn, customerResponse.Balance, amountToCharge, currency);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferService, Method: SendTransferByPayPal-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }

            var userProfile = await _accountRepository.GetUserByPhoneNumber(packageDetails.fromMsisdn);
            if (!string.IsNullOrEmpty(userProfile?.email))
            {
                await SendInternationalTopupPaymentReceiptAsync(userProfile.email, packageDetails, userProfile, "PayPal",totalServiceFee,decimal.Zero,string.Empty,0, transferResponse.reference, transferResponse.pinCode);
            }
			PrepareUpdateTransactionLog(transactionLog, null, 1, "Success");
			await _transferRepository.UpdateTransactionLog(transactionLog);
			//Send Response
			return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Success(
                new TransferByPayPalCallBackResponseModel()
                {
                    TransferData = new TransferData()
                    {
                        TransactionId = transferResponse.reference,
                        fromAmount = amountToCharge.ToString(),
                        toAmount = packageDetails.product,
                        fromCurrency = packageDetails.fromCurrency,
                        toCurrency = packageDetails.toCurrency,
                        fromMsisdn = packageDetails.fromMsisdn,
                        toMsisdn = packageDetails.tomsisdn,
                        fromCountry = FromNumberCountryCode,
                        toCountry = toNumberCountryCode,
                        operatorName = packageDetails.operatorName
                    }
                }, "Successfull top-up");
        }

        public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByExistingCard(
            TransferByExistingCardRequestModel model,
            string msisdn,
            string currency,
            string account)
        {

            var response = new TransferByCardResponseModel();

            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(
                                                                                        model.nowtelRef, model.product.ToString());
            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Invalid product/reference", ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }
            var transactionLog = await _transferRepository.GetTransactionLog(model.nowtelRef, model.product);
            if(transactionLog is null)
            {
                transactionLog = await PrepareTransactionLogAsync(model.nowtelRef, model.product);
                await _transferRepository.CreateTransactionLogAsync(transactionLog);
            }
            response.productData = packageDetails;


            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }
            var productAmount = decimal.Parse(packageDetails.fromAmount, CultureInfo.InvariantCulture);
            //calculate service fee
            var origination = _phoneNumberService.GetCountryCode(packageDetails.fromMsisdn);
            var destination = _phoneNumberService.GetCountryCode(packageDetails.tomsisdn);
            var (totalServiceFee, serviceFee, serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, currency, productAmount);
            amountToCharge += totalServiceFee;
            //Validate trasnfer request 
            /*var validationResponse = await ValidateTransferRequest(
                    account,
                    amountToCharge,
                    packageDetails.fromMsisdn,
                    packageDetails.tomsisdn,
                    currency
                );

            if (validationResponse == TransferValidationResponse.DailyLimitExceeded)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                             "Your daily limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
            }
            else if (validationResponse == TransferValidationResponse.Unauthorized)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                             "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
            }*/

            var custValidate = await ValidateNowtelCustomerNew(packageDetails.fromMsisdn, packageDetails.GUID, packageDetails.product, amountToCharge);

            if (custValidate.isAllowed != 1)
            {
                _logger.Error($"Class: TransferService, Method: TransferByExistingCard, Parameters=> Model :" +
                            $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(custValidate)} ,frommisdn: {packageDetails.fromMsisdn},tomisdn: {packageDetails.tomsisdn}, nowtelref : {packageDetails.GUID}");
                PrepareUpdateTransactionLog(transactionLog, null, 2, "Customer is not allowed");
                await _transferRepository.UpdateTransactionLog(transactionLog);
                return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                             "Sorry we were not able to complete the transaction at the moment, please try again later", ApiStatusCodes.TransferServiceNotAvailable);
            }

            var paymentResponse = await _pay360Service.Pay360Payment(await CreatePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                CustomerMsisdn = msisdn,
                Amount = Convert.ToSingle(amountToCharge),
                IpAddress = model.ipAddress,
                Currency = currency,
                SecurityCode = model.SecurityCode,
                toMsisdn = packageDetails.tomsisdn,
                Pay360PaymentType = Pay360PaymentType.Token,
                CardToken = model.cardToken,
                accountNumber = account,
            }), Pay360PaymentType.Token);


            if (paymentResponse == null)
            {
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Failure(response, "Payment service not responding",
                                                                                                ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: TransferService, Method: TransferByExistingCard - PaymentResponse, " +
                                                  $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                  $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Your daily payment limit is exceeded");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            return await SendTransferByCard(paymentResponse.payload, packageDetails,
                                            model.operatorId.ToString(),
                                            model.product.ToString(),
                                            account, model.ipAddress, amountToCharge, productAmount, totalServiceFee, serviceFee, serviceFeeDiscount);

        }

        public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByNewCustomer(
            TransferByNewCustomerRequestModel model,
            string msisdn,
            string currency,
            string account)
        {
            var response = new TransferByCardResponseModel();

            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(model.nowtelRef, model.product.ToString());
            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Invalid product/reference", ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }
            var transactionLog = await _transferRepository.GetTransactionLog(model.nowtelRef, model.product);
            if(transactionLog is null)
            {
                transactionLog = await PrepareTransactionLogAsync(model.nowtelRef, model.product);
                await _transferRepository.CreateTransactionLogAsync(transactionLog);
            }
            response.productData = packageDetails;

            var productAmount = decimal.Parse(packageDetails.fromAmount, CultureInfo.InvariantCulture);
            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }

            var origination = _phoneNumberService.GetCountryCode(packageDetails.fromMsisdn);
            var destination = _phoneNumberService.GetCountryCode(packageDetails.tomsisdn);
            //calculate service fee
            var (totalServiceFee, serviceFee, serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, currency, productAmount);
            //deduct service fee
            amountToCharge += totalServiceFee;
            //Validate trasnfer request 
            /*var validationResponse = await ValidateTransferRequest(
                    account,
                    amountToCharge,
                    packageDetails.fromMsisdn,
                    packageDetails.tomsisdn,
                    currency
                );

            if (validationResponse == TransferValidationResponse.DailyLimitExceeded)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                             "Your daily limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
            }
            else if (validationResponse == TransferValidationResponse.Unauthorized)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                             "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
            }*/

            var custValidate = await ValidateNowtelCustomerNew(packageDetails.fromMsisdn, packageDetails.GUID, packageDetails.product, amountToCharge);

            if (custValidate.isAllowed != 1)
            {
                _logger.Error($"Class: TransferService, Method: TransferByNewCustomer, Parameters=> Model :" +
                            $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(custValidate)} ,frommisdn: {packageDetails.fromMsisdn},tomisdn: {packageDetails.tomsisdn}, nowtelref : {packageDetails.GUID}");
                PrepareUpdateTransactionLog(transactionLog, null, 2, "Invalid customer");
                await _transferRepository.UpdateTransactionLog(transactionLog);
                return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                             "Sorry we were not able to complete the transaction at the moment, please try again later", ApiStatusCodes.TransferServiceNotAvailable);
            }

            var paymentResponse = await _pay360Service.Pay360Payment(await CreatePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                CustomerMsisdn = msisdn,
                Amount = Convert.ToSingle(amountToCharge),
                IpAddress = model.ipAddress,
                Currency = currency,
                toMsisdn = packageDetails.tomsisdn,
                Pay360PaymentType = Pay360PaymentType.New,
                CustomerAddressData = new AddressData()
                {
                    AddressL1 = model.billingAddressData.AddressL1,
                    AddressL2 = model.billingAddressData.AddressL2,
                    AddressL3 = model.billingAddressData.AddressL3,
                    AddressL4 = model.billingAddressData.AddressL4,
                    PostCode = model.billingAddressData.PostCode,
                    City = model.billingAddressData.City,
                    Region = model.billingAddressData.Region,
                    CountryCode = model.billingAddressData.CountryCode
                },
                CustomerCardData = new CardData()
                {
                    CardNumber = model.cardData.CardNumber,
                    NameOnCard = model.cardData.NameOnCard,
                    SecurityCode = model.cardData.SecurityCode,
                    ExpiryMonth = model.cardData.ExpiryMonth,
                    ExpiryYear = model.cardData.ExpiryYear
                },
                ShouldSaveCard = model.cardData.ShouldSaveCard,
                accountNumber = account
            }), Pay360PaymentType.New);


            if (paymentResponse == null)
            {
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Failure(response, "Payment service not responding",
                                                                                         ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: TransferService, Method: TransferByNewCustomer - PaymentResponse , " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Your daily payment limit is exceeded");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, paymentResponse.message);
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                            paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            return await SendTransferByCard(paymentResponse.payload, packageDetails,
                model.operatorId.ToString(),
                model.product.ToString(),
                account, model.ipAddress,
                amountToCharge, productAmount,
                totalServiceFee, serviceFee, serviceFeeDiscount);
        }

        public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByNewCard(
            TransferByNewCardRequestModel model,
            string msisdn,
            string currency,
            string account)
        {
            var response = new TransferByCardResponseModel();

            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(model.nowtelRef, model.product.ToString());
            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Invalid product/reference", ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }
            var transactionLog = await _transferRepository.GetTransactionLog(model.nowtelRef, model.product);
            if(transactionLog is null)
            {
                transactionLog=await PrepareTransactionLogAsync(model.nowtelRef,model.product);
                await _transferRepository.CreateTransactionLogAsync(transactionLog);
            }
            response.productData = packageDetails;


            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }
            var productAmount = decimal.Parse(packageDetails.fromAmount, CultureInfo.InvariantCulture);
            //calculate service fee
            var origination = _phoneNumberService.GetCountryCode(packageDetails.fromMsisdn);
            var destination = _phoneNumberService.GetCountryCode(packageDetails.tomsisdn);
            var (totalServiceFee, serviceFee, serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, currency, productAmount);
            amountToCharge += totalServiceFee;
            //Validate trasnfer request 
            /*var validationResponse = await ValidateTransferRequest(
                    account,
                    amountToCharge,
                    packageDetails.fromMsisdn,
                    packageDetails.tomsisdn,
                    currency
                );

            if (validationResponse == TransferValidationResponse.DailyLimitExceeded)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                             "Your daily limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
            }
            else if (validationResponse == TransferValidationResponse.Unauthorized)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                             "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
            }*/

            var custValidate = await ValidateNowtelCustomerNew(packageDetails.fromMsisdn, packageDetails.GUID, packageDetails.product, amountToCharge);

            if (custValidate.isAllowed != 1)
            {
                _logger.Error($"Class: TransferService, Method: TransferByNewCard, Parameters=> Model :" +
                            $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(custValidate)} ,frommisdn: {packageDetails.fromMsisdn},tomisdn: {packageDetails.tomsisdn}, nowtelref : {packageDetails.GUID}");
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Customer is not allowed");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                             "Sorry we were not able to complete the transaction at the moment, please try again later", ApiStatusCodes.TransferServiceNotAvailable);
            }

            var paymentResponse = await _pay360Service.Pay360Payment(await CreatePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                CustomerMsisdn = msisdn,
                Amount = Convert.ToSingle(amountToCharge),
                IpAddress = model.ipAddress,
                Currency = currency,
                toMsisdn = packageDetails.tomsisdn,
                Pay360PaymentType = Pay360PaymentType.ExistingNew,
                CustomerAddressData = new AddressData()
                {
                    AddressL1 = model.billingAddressData.AddressL1,
                    AddressL2 = model.billingAddressData.AddressL2,
                    AddressL3 = model.billingAddressData.AddressL3,
                    AddressL4 = model.billingAddressData.AddressL4,
                    PostCode = model.billingAddressData.PostCode,
                    City = model.billingAddressData.City,
                    Region = model.billingAddressData.Region,
                    CountryCode = model.billingAddressData.CountryCode
                },
                CustomerCardData = new CardData()
                {
                    CardNumber = model.cardData.CardNumber,
                    NameOnCard = model.cardData.NameOnCard,
                    SecurityCode = model.cardData.SecurityCode,
                    ExpiryMonth = model.cardData.ExpiryMonth,
                    ExpiryYear = model.cardData.ExpiryYear
                },
                ShouldSaveCard = model.cardData.ShouldSaveCard,
                accountNumber = account
            }), Pay360PaymentType.ExistingNew);


            if (paymentResponse == null)
            {
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Failure(response, "Payment service not responding",
                                                                                         ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {
                _logger.Error($"Class: TransferService, Method: TransferByNewCard - PaymentResponse, " +
                                                           $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                           $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Your daily payment limit is exceeded");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, paymentResponse.message);
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            return await SendTransferByCard(paymentResponse.payload, packageDetails,
                model.operatorId.ToString(),
                model.product.ToString(),
                account, model.ipAddress, amountToCharge,productAmount,
                totalServiceFee,serviceFee,serviceFeeDiscount);
        }

        public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByCard3dSecureCallBack(
            TransferByCardCallBackRequestModel model)
        {
            var response = new TransferByCardResponseModel();

            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(model.nowtelRef, model.product.ToString());
            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Invalid product/reference",
                                                                                         ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }
            var transactionLog = await _transferRepository.GetTransactionLog(model.nowtelRef, model.product);
            if(transactionLog is null)
            {
                transactionLog = await PrepareTransactionLogAsync(model.nowtelRef, model.product);
                await _transferRepository.CreateTransactionLogAsync(transactionLog);
            }
            response.productData = packageDetails;

            string destination = _phoneNumberService.GetCountryCode(packageDetails.tomsisdn);
            string origination = _phoneNumberService.GetCountryCode(packageDetails.fromMsisdn);

            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(packageDetails.fromMsisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }
            var productAmount = decimal.Parse(packageDetails.fromAmount, CultureInfo.InvariantCulture);
            //calculate service fee
            var (totalServiceFee, serviceFee, serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, packageDetails.fromCurrency, productAmount);
            amountToCharge += totalServiceFee;
            //Get user account response
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + packageDetails.fromMsisdn);
            if (accountResponse == null)
            {
				PrepareUpdateTransactionLog(transactionLog, null, 2, "User is not registered");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Failure(response, "User is not registered",
                                                                                        ApiStatusCodes.UserNotRegistered);
            }

            //payment response 
            GenericApiResponse<Pay360PaymentResponse> paymentResponse;
            if (!model.clientRedirectType.Contains("V2", StringComparison.CurrentCultureIgnoreCase))
            {
                paymentResponse = await _pay360Service.Resume3DTransaction(new Pay360Resume3DRequest()
                {
                    pareq = model.PaRes,
                    pay360TransactionId = model.MD,
                    customerEmail = model.customerEmail
                });
            }
            else
            {
                paymentResponse = await _pay360Service.Resume3DTransactionV2(new Pay360Resume3DRequest()
                {
                    pay360TransactionId = model.MD,
                    customerEmail = model.customerEmail
                });
            }


            if (paymentResponse == null)
            {
                await HandleIntTopupEvents(destination, origination, true, false, false, packageDetails.fromMsisdn, 0, 0, packageDetails.toCurrency);
				PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service not responding");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				return GenericApiResponse<TransferByCardResponseModel>.Failure(response, "Payment service not responding",
                                                                                         ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {
                await HandleIntTopupEvents(destination, origination, true, false, false, packageDetails.fromMsisdn, 0, 0, packageDetails.toCurrency);
                _logger.Error($"Class: TransferService, Method: TransferByCard3dSecureCallBack - PaymentResponse, " +
                                                            $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                            $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Your daily payment limit is exceeded");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, paymentResponse.message);
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Payment service is not responding");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            return await SendTransferByCard(paymentResponse.payload, packageDetails,
                                                     model.operatorId.ToString(),
                                                     model.product.ToString(),
                                                     accountResponse.AccountID.ToString(), model.IpAddress, amountToCharge,productAmount,
                                                     totalServiceFee,serviceFee,serviceFeeDiscount);
        }

        private async Task<GenericApiResponse<TransferByCardResponseModel>> SendTransferByCard(
            Pay360PaymentResponse paymentResponse,
            InternationalTopupProduct packageDetails,
            string operatorId,
            string product,
            string accountId,
            string IpAddress,
            decimal amountToCharge,
            decimal productAmount,
            decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount)
        {
            var transactionLog = await _transferRepository.GetTransactionLog(packageDetails.GUID, product);
            var response = new TransferByCardResponseModel
            {
                productData = packageDetails
            };

            if (paymentResponse.outcome.reasonCode == "U100") //3d Secure Scenario
            {
                var userResponse = await _accountRepository.GetUserByPhoneNumber(packageDetails.fromMsisdn);

                string customerEmail = userResponse != null && !string.IsNullOrEmpty(userResponse.email) ? userResponse.email : "";

                //Send Response
                return GenericApiResponse<TransferByCardResponseModel>.Failure(
                                                new TransferByCardResponseModel()
                                                {
                                                    threeDSecureData = new ThreeDSecureData()
                                                    {
                                                        pareq = paymentResponse.clientRedirect.pareq,
                                                        redirectUrl = paymentResponse.clientRedirect.url,
                                                        transactionId = paymentResponse.transactionId,
                                                        clientRedirectType = paymentResponse.clientRedirect.type,
                                                        threeDSServerTransId = paymentResponse.clientRedirect.threeDSServerTransId,
                                                        returnUrl = _pay360Config.TransferSettings.ReturnUrl +
                                                                        "nowtelRef=" + packageDetails.GUID +
                                                                        "&product=" + packageDetails.product +
                                                                        "&operatorId=" + operatorId +
                                                                        "&customerEmail=" + customerEmail +
                                                                        "&clientRedirectType=" + paymentResponse.clientRedirect.type +
                                                                        "&customerMsisdn=" + packageDetails.fromMsisdn
                                                    }

                                                }, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

            }
            else if (paymentResponse.outcome.reasonCode == "S100")
            {
                //Send Credit
                var transferResponse = await _aTTService.Execute(new ExecuteDataRequest()
                {
                    fromMSISDN = packageDetails.fromMsisdn,
                    messageToRecipient = string.Empty,
                    nowtelTransactionReference = packageDetails.GUID,
                    operatorid = operatorId,
                    product = product
                });

                //Save transaction
                string toNumberCountryCode = _phoneNumberService.GetCountryCode(packageDetails.tomsisdn);
                string FromNumberCountryCode = _phoneNumberService.GetCountryCode(packageDetails.fromMsisdn);

                await _transferRepository.SaveTransaction(new DBTransferTransaction()
                {
                    AccountId = accountId,
                    ClientCurrecny = packageDetails.fromCurrency,
                    CountryCode = toNumberCountryCode,
                    FromMsisdn = packageDetails.fromMsisdn,
                    ToMsisdn = packageDetails.tomsisdn,
                    ItemPrice = productAmount,
                    ServiceFee = serviceFee,
                    TotalServiceFee = totalServiceFee,
                    ServiceFeeDiscount = serviceFeeDiscount,
                    TotalPrice = amountToCharge,
                    NowtelRef = packageDetails.GUID,
                    OperatorCountryName = packageDetails.operatorCountryName,
                    OperatorLogoUrl = packageDetails.operatorLogoUrl,
                    OperatorName = packageDetails.operatorName,
                    Product = Convert.ToDecimal(packageDetails.product),
                    ReceiverCurrecny = packageDetails.toCurrency,
                    PaymentTypeId = PaymentType.Card,
                    PaymentRef = paymentResponse.transactionId,
                    TransferRef = transferResponse != null && transferResponse.errorCode == "0" ? transferResponse.reference : null,
                    StatusId = transferResponse != null && transferResponse.errorCode == "0"
                                            ? TransferTransactionStatus.Success : TransferTransactionStatus.Failure
                });

                if (transferResponse == null)
                {
                    await HandleIntTopupEvents(toNumberCountryCode, FromNumberCountryCode, true, false, false, packageDetails.fromMsisdn, 0, 0, packageDetails.toCurrency);

                    _logger.Error($"Class: TransferService, Method: SendTransferByCard, Parameters=> Model :" +
                                $" {JsonConvert.SerializeObject(packageDetails)}, " +
                                $"Error:{JsonConvert.SerializeObject(transferResponse)}, Response: NULL, Need to Refund");
                    PrepareUpdateTransactionLog(transactionLog, null, 2, "Balance transfer failed");
                    await _transferRepository.UpdateTransactionLog(transactionLog);
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                                "Something went wrong on server", ApiStatusCodes.InternalServerError);
                }

                if (transferResponse.errorCode != "0")
                {
                    await HandleIntTopupEvents(toNumberCountryCode, FromNumberCountryCode, true, false, false, packageDetails.fromMsisdn, 0, 0, packageDetails.toCurrency);

                    // Cancel Payment
                    if (TransferIsAuthorization)
                    {
                        try
                        {
                            var CapturePaymentResponse = _pay360Service.cancelTransaction(
                                new CancelTransactionRequestModel
                                {
                                    transactionId = paymentResponse.transactionId
                                });

                            if (CapturePaymentResponse == null || (CapturePaymentResponse != null && CapturePaymentResponse.Result.errorCode > 0))
                            {
                                _logger.Error(
                                    $"Class: TransferService, Method: transferpayment-cancelTransaction, ErrorMessage: Cancel Failed for transaction {paymentResponse.transactionId}");

                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.Error(
                                $"Class: TransferService, Method: transferpayment-cancelTransaction, Transaction:{paymentResponse.transactionId}, ErrorMessage: " +
                                $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                        }
                    }

                    _logger.Error($"Class: TransferService, Method: SendTransferByCard, Parameters=> Model :" +
                                                                    $" {JsonConvert.SerializeObject(packageDetails)}, " +
                                                                    $"Error:{JsonConvert.SerializeObject(transferResponse)}");

                    //await CardPaymentRefund(paymentResponse.transactionId);

                    if (transferResponse.errorCode == "3")
                    {
						PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer not authorized");
						await _transferRepository.UpdateTransactionLog(transactionLog);
						return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                "Transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
                    }

                    if (!string.IsNullOrEmpty(transferResponse.errorCodeDtOne))
                    {
                        int AttErrorCode = Convert.ToInt32(transferResponse.errorCodeDtOne);

                        if (AttErrorCode == (int)ATTStatusCodes.TopupNumberLimitExceed)
                        {
							PrepareUpdateTransactionLog(transactionLog, null, 2, "Recipient reached maximum topup number");
							await _transferRepository.UpdateTransactionLog(transactionLog);
							return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                "Recipient reached maximum topup number.", ApiStatusCodes.TopupNumberLimitExceed);
                        }
                        else if (AttErrorCode == (int)ATTStatusCodes.TopupAmountLimitExceed)
                        {
							PrepareUpdateTransactionLog(transactionLog, null, 2, "Recipient reached maximum topup amount");
							await _transferRepository.UpdateTransactionLog(transactionLog);
							return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                "Recipient reached maximum topup amount.", ApiStatusCodes.TopupAmountLimitExceed);
                        }
                        else if (AttErrorCode == (int)ATTStatusCodes.DenominationsNotAvailable)
                        {
							PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this country is not available at the moment");
							await _transferRepository.UpdateTransactionLog(transactionLog);
							return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                "Transfer service for this country is not available at the moment.",
                                ApiStatusCodes.DenominationsNotAvailable);
                        }
                        else if (AttErrorCode == (int)ATTStatusCodes.DenominationBlocked)
                        {
							PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this number is not available at the moment.");
							await _transferRepository.UpdateTransactionLog(transactionLog);
							return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                "Transfer service for this number is not available at the moment.",
                                ApiStatusCodes.DenominationBlocked);
                        }
                        else if (AttErrorCode == (int)ATTStatusCodes.OperatorBlocked)
                        {
							PrepareUpdateTransactionLog(transactionLog, null, 2, "Transfer service for this number is not available at the moment.");
							await _transferRepository.UpdateTransactionLog(transactionLog);
							return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                "Transfer service for this number is not available at the moment.",
                                ApiStatusCodes.OperatorBlocked);
                        }
                        else if (AttErrorCode == (int)ATTStatusCodes.DestinationMsisdnOutOfRange)
                        {
							PrepareUpdateTransactionLog(transactionLog, null, 2, "Destination number is invalid");
							await _transferRepository.UpdateTransactionLog(transactionLog);
							return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                "Destination number is invalid.", ApiStatusCodes.DestinationMsisdnOutOfRange);
                        }
                    }
					PrepareUpdateTransactionLog(transactionLog, null, 2, "Error");
					await _transferRepository.UpdateTransactionLog(transactionLog);
					return GenericApiResponse<TransferByCardResponseModel>.Failure(response,
                                                                "", ApiStatusCodes.DTOneServiceError);
                }


                if (transferResponse.errorCode == "0")
                {
                    //CapturePayment
                    if (TransferIsAuthorization == true)
                    {
                        try
                        {
                            CaptureTransactionRequestModel capturetransmodel = new CaptureTransactionRequestModel();
                            capturetransmodel.transactionId = paymentResponse.transactionId.ToString();
                            var CapturePaymentResponse = _pay360Service.CaptureTransaction(capturetransmodel);


                            if (CapturePaymentResponse == null || (CapturePaymentResponse != null && CapturePaymentResponse.Result.errorCode > 0))
                            {
                                string messageBody = " Payment Captured Fail! , Transfered Sucessfully! Transaction id : " + paymentResponse.transactionId.ToString();
                                await _emailService.SendEmail("usama.kiyani@now.net.pk", messageBody, false, "Balance Transfer");
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.Error($"Class: TransferService, Method: transferpayment-capturepayment, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");

                            string messageBody = " Payment Captured Failed! , Transfered Sucessfully! Transaction id : " + paymentResponse.transactionId.ToString();
                            await _emailService.SendEmail("usama.kiyani@now.net.pk", messageBody, false, "Balance Transfer");
                        }

                    }
                }

                //Events
                await _transferRepository.InsertSpecialPromotionLogs(-Decimal.Parse(packageDetails.CustomerChargeValue), accountId, "", "Balance Transfer Card");


                try
                {
                    int isFirstiTopup = await _transferRepository.IsFirstInternationTopup(accountId);
                    var customerResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + packageDetails.fromMsisdn);

                    await HandleIntTopupEvents(toNumberCountryCode, FromNumberCountryCode, true, false, true, packageDetails.fromMsisdn, customerResponse.Balance, amountToCharge, packageDetails.toCurrency);
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: TransferService, Method: SendTransferByCard-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }

                var userProfile = await _accountRepository.GetUserByPhoneNumber(packageDetails.fromMsisdn);
                if (!string.IsNullOrEmpty(userProfile?.email))
                {
                    await SendInternationalTopupPaymentReceiptAsync(userProfile.email, packageDetails, userProfile, "Card",totalServiceFee,decimal.Zero,string.Empty,0, transferResponse.reference,transferResponse.pinCode);
                }
				PrepareUpdateTransactionLog(transactionLog, null, 1, "Success");
				await _transferRepository.UpdateTransactionLog(transactionLog);
				//Send Response
				return GenericApiResponse<TransferByCardResponseModel>.Success(
                                                new TransferByCardResponseModel()
                                                {
                                                    transferData = new TransferData()
                                                    {
                                                        TransactionId = transferResponse.reference,
                                                        fromAmount = amountToCharge.ToString(),
                                                        toAmount = packageDetails.product,
                                                        fromCurrency = packageDetails.fromCurrency,
                                                        toCurrency = packageDetails.toCurrency,
                                                        fromMsisdn = packageDetails.fromMsisdn,
                                                        toMsisdn = packageDetails.tomsisdn,
                                                        fromCountry = FromNumberCountryCode,
                                                        toCountry = toNumberCountryCode,
                                                        operatorName = packageDetails.operatorName
                                                    }
                                                }, "Successfull top-up");
            }
            else
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(response, "Payment service not responding", ApiStatusCodes.PaymentServiceError);
            }
        }
		private InternationalTopupTransactionLog PrepareUpdateTransactionLog(InternationalTopupTransactionLog transaction, decimal? discount, int checkoutStatus, string message)
		{
			if (discount.HasValue)
			{
				transaction.DiscountApplied = discount.Value;
				transaction.TotalPrice -= discount.Value;
			}
			transaction.CheckoutStatus = checkoutStatus;
			transaction.Message = message;
			return transaction;
		}
		private async Task<InternationalTopupTransactionLog> PrepareTransactionLogAsync(string nowtelRef, string productId, decimal discount = 0)
		{
			var product = await _transferRepository.GetProductByNowtelTransactionReference(nowtelRef, productId);
			var productAmount = decimal.Parse(product.fromAmount, CultureInfo.InvariantCulture);
			var origination = _phoneNumberService.GetCountryCode(product.fromMsisdn);
			var destination = _phoneNumberService.GetCountryCode(product.tomsisdn);
			var amountToCharge = decimal.Parse(product.CustomerChargeValue, CultureInfo.InvariantCulture);
			(decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) = _internationalTopupServiceFeeCalculator.Calculate(origination, destination, product.fromCurrency, productAmount);
			amountToCharge += totalServiceFee;
			amountToCharge -= discount;
			return new InternationalTopupTransactionLog
			{
				CheckoutStatus = 0,
				Currency = product.fromCurrency,
				CustomerIdentifier = product.fromMsisdn,
				ToMsisdn = product.tomsisdn,
				TransactionIdentifier = nowtelRef,
				ProductPrice = productAmount,
				DiscountOnServiceFee = serviceFeeDiscount,
				DiscountApplied = discount,
				Message = "",
				ProductIdentifier = product.product,
				TotalPrice = amountToCharge,
				ServiceFee = totalServiceFee,
				SalePrice = productAmount,
			};
		}
		private async Task<Pay360PaymentRequest> CreatePay360PaymentRequest(Pay360PaymentRequestData model)
        {

            //Get User-Info 
            var userResponse = await _accountRepository.GetUserByPhoneNumber(model.CustomerMsisdn);
            model.CustomerEmail = userResponse == null ? string.Empty : !string.IsNullOrEmpty(userResponse.email)
                                                                                                        ? userResponse.email : string.Empty;

            //Get User Registration Date
            var userRegistrationDate = await _accountRepository.GetUserRegistrationDate(model.accountNumber);

            List<fieldstate> _fieldState = new List<fieldstate>()
                {
                    new fieldstate() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
                    new fieldstate() { name = "ProductItemCode", value = ProductItemCode.THADTW.ToString(), transient = false },
                };

            _fieldState.Add(new fieldstate()
            {
                name = "FirstUseDate",
                value = userRegistrationDate.ToString("yyyy-MM-dd"),
                transient = false
            });
            _fieldState.Add(new fieldstate() { name = "ANumber", value = model.CustomerMsisdn, transient = false });
            _fieldState.Add(new fieldstate() { name = "BNumber", value = model.toMsisdn, transient = false });

            List<basket> baskets = new List<basket>();

            basket basket = new basket()
            {
                amount = model.Amount,
                bundleRef = "",
                productItemCode = ProductItemCode.THADTW.ToString(),
                productRef = model.CustomerMsisdn
            };

            baskets.Add(basket);

            Pay360PaymentRequest request = new Pay360PaymentRequest();
            switch (model.Pay360PaymentType)
            {
                case Pay360PaymentType.New:
                    request.Pay360PaymentRequestNew = new Pay360PaymentRequestNew();
                    request.Pay360PaymentRequestNew.basket = baskets;
                    request.Pay360PaymentRequestNew.customerName = model.CustomerCardData.NameOnCard;
                    request.Pay360PaymentRequestNew.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestNew.customerUniqueRef = model.CustomerMsisdn;
                    request.Pay360PaymentRequestNew.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestNew.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestNew.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestNew.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestNew.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestNew.cardCv2 = model.CustomerCardData.SecurityCode;
                    request.Pay360PaymentRequestNew.cardExpiryDate = model.CustomerCardData.ExpiryMonth + model.CustomerCardData.ExpiryYear;
                    request.Pay360PaymentRequestNew.cardPan = model.CustomerCardData.CardNumber;
                    request.Pay360PaymentRequestNew.isDirectFullfilment = false;
                    request.Pay360PaymentRequestNew.isAuthorizationOnly = TransferIsAuthorization;
                    request.Pay360PaymentRequestNew.isDefaultCard = true;
                    request.Pay360PaymentRequestNew.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestNew.saveCard = model.ShouldSaveCard;
                    request.Pay360PaymentRequestNew.billingAddress = new billingAddress()
                    {
                        line1 = model.CustomerAddressData.AddressL1,
                        line2 = model.CustomerAddressData.AddressL2,
                        line3 = model.CustomerAddressData.AddressL3,
                        line4 = model.CustomerAddressData.AddressL4,
                        region = model.CustomerAddressData.Region,
                        city = model.CustomerAddressData.City,
                        postcode = model.CustomerAddressData.PostCode,
                        countryCode = model.CustomerAddressData.CountryCode
                    };
                    if (_pay360Config.IsBillingAndCustomerAddressSame == true)
                        request.Pay360PaymentRequestNew.customerBillingAddress = request.Pay360PaymentRequestNew.billingAddress;
                    break;
                case Pay360PaymentType.Token:
                    request.Pay360PaymentRequestToken = new Pay360PaymentRequestToken();
                    request.Pay360PaymentRequestToken.basket = baskets;
                    request.Pay360PaymentRequestToken.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestToken.customerUniqueRef = model.CustomerMsisdn;
                    request.Pay360PaymentRequestToken.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestToken.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestToken.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestToken.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestToken.cardCv2 = model.SecurityCode;
                    request.Pay360PaymentRequestToken.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestToken.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestToken.isDirectFullfilment = false;
                    request.Pay360PaymentRequestToken.isAuthorizationOnly = TransferIsAuthorization;
                    request.Pay360PaymentRequestToken.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestToken.cardToken = model.CardToken;
                    break;
                case Pay360PaymentType.ExistingNew:
                    request.Pay360PaymentRequestExistingNew = new Pay360PaymentRequestExistingNew();
                    request.Pay360PaymentRequestExistingNew.basket = baskets;
                    request.Pay360PaymentRequestExistingNew.customerName = model.CustomerCardData.NameOnCard;
                    request.Pay360PaymentRequestExistingNew.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestExistingNew.customerUniqueRef = model.CustomerMsisdn;
                    request.Pay360PaymentRequestExistingNew.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestExistingNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestExistingNew.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestExistingNew.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestExistingNew.cardCv2 = model.CustomerCardData.SecurityCode;
                    request.Pay360PaymentRequestExistingNew.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestExistingNew.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestExistingNew.cardExpiryDate = model.CustomerCardData.ExpiryMonth + model.CustomerCardData.ExpiryYear;
                    request.Pay360PaymentRequestExistingNew.cardPan = model.CustomerCardData.CardNumber;
                    request.Pay360PaymentRequestExistingNew.isDirectFullfilment = false;
                    request.Pay360PaymentRequestExistingNew.isAuthorizationOnly = TransferIsAuthorization;
                    request.Pay360PaymentRequestExistingNew.isDefaultCard = true;
                    request.Pay360PaymentRequestExistingNew.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestExistingNew.saveCard = model.ShouldSaveCard;
                    request.Pay360PaymentRequestExistingNew.billingAddress = new billingAddress()
                    {
                        line1 = model.CustomerAddressData.AddressL1,
                        line2 = model.CustomerAddressData.AddressL2,
                        line3 = model.CustomerAddressData.AddressL3,
                        line4 = model.CustomerAddressData.AddressL4,
                        region = model.CustomerAddressData.Region,
                        city = model.CustomerAddressData.City,
                        postcode = model.CustomerAddressData.PostCode,
                        countryCode = model.CustomerAddressData.CountryCode
                    };
                    break;
            }

            return request;
        }
        private async Task SendInternationalTopupPaymentReceiptAsync(string paymentEmailAddress, InternationalTopupProduct packageDetails, DBUser userProfile, string paymentMethod,decimal serviceFee,decimal discountAmount,string discountCode,int rewardPointsEarned, string transactionId, string pinCode)
        {
            try
            {
                var builder = new BodyBuilder();
                using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\International-topup-payment-reciept.html").Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();
                }

                string messageBody = builder.HtmlBody
                    .Replace("%TIMESTAMP%", DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"))
                    .Replace("%EMAIL%", userProfile?.email)
                    .Replace("%FIRST_NAME%", userProfile?.firstname)
                    .Replace("%TOPUPNUMBER%", packageDetails.tomsisdn)
                    .Replace("%TOPUPCOUNTRY%", packageDetails.operatorCountryName)
                    .Replace("%RCVAMOUNT%", _helperService.ToMonetaryUnit(packageDetails.toAmount, packageDetails.toCurrency))
                    .Replace("%AMOUNT%", _helperService.ToMonetaryUnit(packageDetails.fromAmount, packageDetails.fromCurrency))
                    .Replace("%DISCOUNTCODE%", discountCode)
                    .Replace("%DISCOUNT%", _helperService.ToMonetaryUnit(discountAmount, packageDetails.fromCurrency))
                    .Replace("%SERVICEFEE%", _helperService.ToMonetaryUnit(serviceFee, packageDetails.fromCurrency))
                    .Replace("%REWARDPOINTSEARNED%", rewardPointsEarned.ToString())
                    .Replace("%TOPUPOPERATOR%", packageDetails.operatorName)
                    .Replace("%PAYMENTMETHOD%", paymentMethod.Equals("AccountBalance", StringComparison.InvariantCultureIgnoreCase) ? "Account Balance" : paymentMethod)
                    .Replace("%TRANSACTIONID%", transactionId);

				if (string.IsNullOrEmpty(pinCode))
				{
					if (messageBody.Contains("<tr id=\"row_pinCode\">"))
					{
						messageBody = messageBody.Replace("<tr id=\"row_pinCode\">", "<tr id=\"row_pinCode\" style=\"display:none\">");
					}
				}
				else
				{
					messageBody = messageBody.Replace("%PINCODE%", pinCode);
				}

				await _emailService.SendEmail(paymentEmailAddress, messageBody, true, "Mobile Top-up Sent Successfully");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Class: TransferService,Method: SendInternationalTopupPaymentReceiptAsync");
            }
        }
        private async Task HandleIntTopupEvents(string Destination, string Origination, Boolean? IsCard, Boolean SaveCard, Boolean IsSuccess, string Msisdn, decimal RemainingBalance, decimal Amount, string currency)
        {

            await _airShipService.HandleIntTopupTagsAndEvents(
                  new IntTopupInfoAirShip()
                  {
                      Destination = Destination,
                      IsCard = IsCard,
                      SaveCard = SaveCard,
                      IsSuccess = IsSuccess,
                      Msisdn = Msisdn,
                      Origination = Origination,
                      RemainingBalance = RemainingBalance
                  });


            await _faceBookService.HandleIntTopupEvents(Msisdn, Origination, Destination, IsSuccess, IsCard, Amount, RemainingBalance, currency);



            await _appsFlyerService.HandleIntTopupEvents(Msisdn, Origination, Destination, IsSuccess, IsCard, Amount, RemainingBalance, currency);
        }
        private async Task<ValidateCustomer> ValidateNowtelCustomerNew(string frommsisdn, string nowtelreference, string product, decimal amount)
        {
            return await _transferRepository.ValidateNowtelCustomerNew(frommsisdn, nowtelreference, product, amount);
        }
    }
}