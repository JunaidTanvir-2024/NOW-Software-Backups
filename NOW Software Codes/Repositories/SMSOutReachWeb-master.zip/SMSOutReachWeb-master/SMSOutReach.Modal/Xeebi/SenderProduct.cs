﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSOutReach.Modal.Xeebi
{
    public class SenderProduct
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string  Code { get; set; }
    }
}
