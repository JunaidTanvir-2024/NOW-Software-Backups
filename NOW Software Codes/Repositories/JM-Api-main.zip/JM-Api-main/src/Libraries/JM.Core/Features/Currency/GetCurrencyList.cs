using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using Microsoft.EntityFrameworkCore;

using RW;
namespace JM.Core.Features.Currency;

public abstract class GetCurrencyList
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
		}
	}
	#endregion

	#region Response
	public sealed record Response
	{
		public long Id { get; set; }
		public required string Name { get; set; }
		public required string Code { get; set; }
		public required string Symbol { get; set; }
	}
	#endregion

	#region Handler
	internal sealed class Handler(IAppDbContext context) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IAppDbContext _context = context;
		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{
			var currencyList = await _context.Currency.ToListAsync(cancellationToken: cancellationToken);

			if (currencyList is not null)
			{
				return ResultWrapper.Success(currencyList.Select(x => new Response()
				{
					Id = x.Id,
					Code = x.Code,
					Name = x.Name,
					Symbol = x.Symbol
				}));
			}
			return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
		}
	}
	#endregion
}
