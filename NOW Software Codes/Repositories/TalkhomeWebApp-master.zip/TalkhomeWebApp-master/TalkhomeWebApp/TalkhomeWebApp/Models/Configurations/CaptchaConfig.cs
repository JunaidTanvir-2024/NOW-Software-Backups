﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.Configurations
{
    public class GoogleRecaptchaSettings
    {
        public const string SectionName = "GoogleRecaptchaSettings";
        public static GoogleRecaptchaSettings Bind = new GoogleRecaptchaSettings();
        public string VerifyAPIAddress { get; set; }
        public string Sitekey { get; set; }
        public string Secretkey { get; set; }
        public decimal? RecaptchaThreshold { get; set; }
        public bool IsActive { get; set; } = false;
    }
}
