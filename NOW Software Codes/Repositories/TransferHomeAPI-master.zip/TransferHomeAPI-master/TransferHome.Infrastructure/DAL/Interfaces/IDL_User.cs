﻿using TrasnferHome.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Models.DAOs;
using TransferHome.Models.Contracts.Request;
using TrasnferHome.Models.Utility;

namespace TrasnferHome.Infrastructure.DAL.Interfaces
{
    public interface IDL_User
    {
        Task<int> IsUserExistByEmail(string email);
        Task<int> RegisterUserByEmail(DBUser user);
        Task<int> InsertUserToken(DBUserTokens userToken);
        Task<int> RegisterUserByPhoneNumber(DBUser user);
        Task<int> IsUserExistByPhoneNumber(string phoneNumber);
        Task<int> VerifyToken(string token, int tokenExpiryMinutes, int tokenTypeId);
        Task<int> VerifyPin(string token, int tokenExpiryMinutes, int tokenTypeId, int userId);
        Task<DBUser> GetUserByEmail(string email);
        Task<int> ReSendToken(DBUserTokens userToken);
        Task<DBUser> GetUserByPhoneNumber(string phoneNumber);
        Task<DBUser> GetUserById(int Id);
        Task<int> UpdatePassword(string token, int emailTokenExpiryMinutes, string password);
        Task<List<DBUserTokens>> GetAllActiveDeviceTokens();
        Task<IEnumerable<DbCreditHistory>> GetCreditHistory(int userId);
        Task<IEnumerable<DbTransferCreditHistory>> GetTransferCreditHistory(int userId);
        Task<int> EditProfile(EditProfileRequestModel model, string userId);
        Task<IEnumerable<DBTransferTransactions>> GetFavouriteTransactionNumbers(int userId);
        Task<IEnumerable<DBTransferTransactions>> GetFrequentTransactionNumbers(int userId);
        Task<int> SaveFavouriteTransactionNumber(DBFavouriteNumber model);
        Task<int> RemoveFavouriteTransactionNumber(DBFavouriteNumber model);
        Task<int> SaveUpdateFCMToken(DbUserPushNotificationIds model);
        Task<List<DBUserTokens>> GetSpecificUsersActiveDeviceTokens(List<string> userMsisdns);
        Task<int> RemoveCreditHistory(DbCreditHistory model);
        Task<int> RemoveTransferCreditHistory(DbTransferCreditHistory model);
        Task<DBUser> UpdateUserNotificationsSetting(bool status, int userId);
        Task<DBUser> UpdateMailSubscription(bool status, int userId);
        Task<bool> IsUserDeviceActive(string UDID);
        Task MarkDeviceAsInActive(string UDID);
        Task<bool> IsUserDeviceActive(string UDID, string Bearertoken, string userId, string path, string method);

        /// <summary>
        /// Marks all devices as inactive against this user. Returns List of userdevices that are marked inactive and were previously active
        /// </summary>
        /// <param name="UserId"></param>
        /// <param name="UDID"></param>
        /// <param name="deviceType"></param>
        /// <param name="phoneNumber"></param>
        /// <returns>List of userdevices that are marked inactive and were previously active</returns>
        Task<List<DBUserTokens>> MarkDeviceAsActive(int UserId, string UDID, DeviceType deviceType, string phoneNumber);
        Task<bool> IsValidTopUpRequest(int id, string balanceCurrency, decimal amount);
    }
}
