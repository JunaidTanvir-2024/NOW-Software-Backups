﻿using Application.Common.Models.EmailValidation;

namespace Application.Common.Interfaces.Infrastructure.Services;
public interface IEmailValidationService : ISerivcesType.ITransientService
{
    Task<VerifyEmailResponse?> VerifyEmailAddress(string email, string? ipAddress);
}