using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Serilog;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Data.Repositories;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Implementations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.DependencyInjection.DependencyModules;
using TalkhomeAPI.Models.Configurations;
using TalkhomeAPI.Services.Interfaces;
using TalkhomeAPI.Services.Services;

namespace TalkhomeAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
               .AddJwtBearer(options =>
               {
                   options.TokenValidationParameters = new TokenValidationParameters
                   {
                       ValidateIssuer = true,
                       ValidateAudience = true,
                       ValidateLifetime = true,
                       ClockSkew = TimeSpan.Zero,
                       ValidateIssuerSigningKey = true,
                       ValidIssuer = Configuration.GetSection("JWTConfig")["JwtIssuer"],
                       ValidAudience = Configuration.GetSection("JWTConfig")["JwtAudience"],
                       IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration.GetSection("JWTConfig")["JwtSecretKey"]))
                   };
                });

            services.AddSingleton((ILogger)new LoggerConfiguration()
               .MinimumLevel.Debug()
               .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("SerilogConfig")["FilePath"], "Tha-WebApi-log-{Date}.txt"))
               .CreateLogger());

            services.AddTalkHomeServices(Configuration);

            services.AddHttpClient<IATTService, ATTService>();
            services.AddHttpClient<ITalkHomeService, TalkHomeService>();
            services.AddHttpClient<IAddressService, AddressService>();

            services.AddTransient<IPay360Service, Pay360Service>();
            services.AddTransient<IPayPalService, PayPalService>();
            services.AddTransient<IPaymentService, PaymentService>();
            services.AddTransient<IAppsFlyerService, AppsFlyerService>();
            services.AddTransient<IAirShipService, AirShipService>();
            services.AddTransient<IPaymentFullfillmentRepository, PaymentFullfillmentRepository>();
            services.AddTransient<IPromotionService, PromotionService>();
            services.AddTransient<IPromotionRepository, PromotionRepository>();

            services.Configure<ConnectionString>(Configuration.GetSection("ConnectionStrings"));
            services.Configure<ATTConfig>(Configuration.GetSection("ATTConfig"));
            services.Configure<TwilioConfig>(Configuration.GetSection("TwilioConfig"));
            services.Configure<TalkHomeConfig>(Configuration.GetSection("TalkHomeConfig"));
            services.Configure<SmtpConfig>(Configuration.GetSection("SmtpConfig"));
            services.Configure<RedirectUrlsConfig>(Configuration.GetSection("RedirectUrlsConfig"));
            services.Configure<Pay360Config>(Configuration.GetSection("Pay360Config"));
            services.Configure<PayPalConfig>(Configuration.GetSection("PayPalConfig"));
            services.Configure<AddressApiConfig>(Configuration.GetSection("AddressApiConfig"));
            services.Configure<RatesConfig>(Configuration.GetSection("RatesConfig"));
            services.Configure<IpAddressConfig>(Configuration.GetSection("IpAddressConfig"));
            services.Configure<SMSConfig>(Configuration.GetSection("SMSConfig"));
            services.Configure<AppsFlyerConfig>(Configuration.GetSection("AppsFlyerConfig"));
            services.Configure<AirShipConfig>(Configuration.GetSection("AirShipConfig"));

            services.AddHttpContextAccessor();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
