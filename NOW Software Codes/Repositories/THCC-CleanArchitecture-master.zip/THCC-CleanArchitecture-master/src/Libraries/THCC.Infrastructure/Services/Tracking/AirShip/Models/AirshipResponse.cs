﻿
namespace THCC.Infrastructure.Services.Tracking.AirShip.Models
{
    public class AirshipResponse
    {
        public bool IsSuccess { get; set; }
        public string? Message { get; set; }

    }
}
