﻿using THCC.Application.Interfaces.Services.Tracking;

namespace THCC.Daemon
{
    internal class ClassicCardCallingWorker : BackgroundService
    {
        private readonly ILogger<ClassicCardCallingWorker> _logger;
        private readonly IServiceScopeFactory _serviceProvider;

        public ClassicCardCallingWorker(
            ILogger<ClassicCardCallingWorker> logger,
            IServiceScopeFactory serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using var scope = _serviceProvider.CreateScope();
                    var callingCardService = scope.ServiceProvider.GetRequiredService<ICallingCardConsumptionService>();
                    await callingCardService.ClassicCardCallingJob();
                }
                catch (Exception ex)
                {
                    _logger.LogError("ClassicCardCallingWorker, " +
                                     "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                     "StackTrace: " + ex.StackTrace);
                }
                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
        }
    }
}