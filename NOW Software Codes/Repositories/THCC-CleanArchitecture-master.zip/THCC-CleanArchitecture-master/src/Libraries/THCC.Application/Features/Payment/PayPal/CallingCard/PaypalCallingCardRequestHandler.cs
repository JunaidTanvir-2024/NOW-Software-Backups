﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Features.Payment.PayPal.CallingCard
{
    public class PaypalCallingCardRequestHandler : IRequestHandler<PaypalCallingCardRequest, object>
    {
        #region Fields

        private readonly IPaymentService _paymentService;
        private readonly ICurrentUser _currentUser;

        #endregion

        #region Ctor

        public PaypalCallingCardRequestHandler(
            IPaymentService paymentService,
            ICurrentUser currentUser)
        {
            _paymentService = paymentService;
            _currentUser = currentUser;
        }

        #endregion

        #region Method

        public async Task<object> Handle(PaypalCallingCardRequest request, CancellationToken cancellationToken)
        {
            return await _paymentService.HandlePaypalPaymentRequest(
                productType: ProductType.CallingCard,
                userInfo: new UserDto()
                {
                    Id = _currentUser.GetUserId(),
                    Email = _currentUser.GetUserEmail()
                },
                amount: request.Amount,
                cardNumber: null!
           );
        }

        #endregion
    }
}
