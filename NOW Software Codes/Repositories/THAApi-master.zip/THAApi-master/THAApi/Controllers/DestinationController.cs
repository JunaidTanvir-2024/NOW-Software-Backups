﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using Models.Contracts.Request.CountryDestination;
using System.Linq;
using System.Threading.Tasks;
using THAApi.Utilities;

namespace THAApi.Controllers
{
	[ApiController]
    public class DestinationController : Controller
    {
        private readonly IBundle_BL BundleBL;
        public DestinationController(IBundle_BL bundleBL)
        {
            BundleBL = bundleBL;
        }

        [HttpGet]
        [Route("bundles")]
        public async Task<IActionResult> GetCountryWithBundles()
        {
            return Ok(await BundleBL.GetCountryWithBundles(User.Msisdn()));
        }

        [Route("bundleswithtop")]
        [HttpGet]
        public async Task<IActionResult> GetCountryWithBundlesAndTopBundles()
        {
            return Ok(await BundleBL.GetCountryWithBundlesAndTopBundles(User.Msisdn(),null));
        }
        
        [HttpPost]
        [Route("bundleswithtop")]
        public async Task<IActionResult> GetCountryWithBundlesAndTopBundles([FromBody] SuggestedBundleRequest request)
        {
            return Ok(await BundleBL.GetCountryWithBundlesAndTopBundles(User.Msisdn(), request.CountryCodes));
        }
        
        [HttpPost]
        [Route("bundles")]
        public async Task<IActionResult> GetBundleDetails(BundleIsoRequest request)
        {
            return Ok(await BundleBL.GetBundleDetails(request.isoCode, User.Msisdn(), User.Currency()));
        }

        [HttpGet]
        [Route("rates/{id}")]
        public async Task<IActionResult> GetRateDetails(string id)
        {
            return Ok(await BundleBL.GetRateDetails(id, User.Msisdn()));
        }

        [HttpGet]
        [Route("rateswithtop")]
        public async Task<IActionResult> GetRatesAndTopRates()
        {
            return Ok(await BundleBL.GetRatesAndTopRates(User.Msisdn()));
        }

        //[HttpGet]
        //[Route("rates")]
        //public async Task<IActionResult> GetAllRates()
        //{
        //    return Ok(await BundleBL.GetAllRates(User.Msisdn()));
        //}

        //[HttpGet]
        //[Route("rates/destination")]
        //public async Task<IActionResult> GetDestination(string destinationMsisdn)
        //{
        //    return Ok(await BundleBL.GetDestinationRate(User.Msisdn(), destinationMsisdn));
        //}
    }
}