﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Configurations
{
    public class TokensConfig
    {
        public int EmailTokenExpiryMinutes { get; set; }
    }
}
