﻿namespace SC.Core.Common.Helpers;

public static class EnumExtensions
{
    public static string Getkey(this Enum value)
    {
        FieldInfo fi = value.GetType().GetField(value.ToString());

        KeyAttribute[] attributes =
            (KeyAttribute[])fi.GetCustomAttributes(
            typeof(KeyAttribute),
            false);

        if (attributes != null &&
            attributes.Length > 0)
            return attributes[0].Id;
        else
            return value.ToString();
    }
}
