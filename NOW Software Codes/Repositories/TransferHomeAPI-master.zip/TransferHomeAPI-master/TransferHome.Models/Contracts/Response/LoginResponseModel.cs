﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.Response
{
    public class LoginResponseModel
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public decimal Balance { get; set; }
        public string BalanceCurrency { get; set; }
        public string BalanceCurrencySymbol { get; set; }
        public bool MailSubscription { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public Roles Role { get; set; }
        public string Token { get; set; }
        public DateTime TokenExpirationDateTime { get; set; }
        public bool IsNotificationsOn { get; set; }
        public string IOSAppVersion { get; set; }
    }
}
