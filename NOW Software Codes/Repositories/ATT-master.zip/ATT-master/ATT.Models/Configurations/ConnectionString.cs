﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{
    
    public class ConnectionString
    {
        public string DefaultConnection { get; set; }
        public string DigiTalkConnection { get; set; }
        public string SmsLoggingDbConnection { get; set; }
    }
}
