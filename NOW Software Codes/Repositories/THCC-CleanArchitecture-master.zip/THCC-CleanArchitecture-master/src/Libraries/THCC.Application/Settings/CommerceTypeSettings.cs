﻿namespace THCC.Application.Settings
{
    public class CommerceTypeSettings
    {
        public const string SectionName = "CommerceTypeSettings";
        public static CommerceTypeSettings Bind = new CommerceTypeSettings();
        public string CommerceType { get; set; } = "MOTO";
    }
}
