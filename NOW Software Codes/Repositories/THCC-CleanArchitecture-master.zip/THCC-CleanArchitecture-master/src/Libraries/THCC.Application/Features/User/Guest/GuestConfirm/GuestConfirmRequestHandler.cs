﻿using THCC.Application.Features.User.Login;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.Guest.GuestConfirm;

internal class GuestConfirmRequestHandler : IRequestHandler<GuestConfirmRequest, object>
{
    private readonly IMapper _mapper;
    private readonly IOtpService _otpService;
    private readonly IUserRepository _userRepository;
    private readonly IJwtService _jwtService;
    private readonly ICommonService _commonService;
    private readonly IMailService _mailService;
    private readonly IAirshipService _airshipService;

    public GuestConfirmRequestHandler(
        IMapper mapper,
        IOtpService otpService,
        IUserRepository userRepository,
        IJwtService jwtService,
        ICommonService commonService,
        IMailService mailService,
        IAirshipService airshipService)
    {
        _mapper = mapper;
        _otpService = otpService;
        _userRepository = userRepository;
        _jwtService = jwtService;
        _commonService = commonService;
        _mailService = mailService;
        _airshipService = airshipService;
    }

    public async Task<object> Handle(GuestConfirmRequest request, CancellationToken cancellationToken)
    {
        request.Email = request.Email.Trim();

        var user = await _userRepository.GetUserByEmailAsync(request.Email);
        if (user == null)
        {
            return ErrorResult.Failure(CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
        }

        //get confirmation token
        var emailToken = await _otpService.GetTokenAgainstOtp(
                        request.Email, request.EmailOtp!, OtpType.SignUp);
        if (string.IsNullOrEmpty(emailToken))
        {
            return ErrorResult.Failure(CustomStatusKey.InvalidOtp, CustomStatusCode.BadRequest);
        }
        else
        {
            return new LoginResponse();
        }
    }
}