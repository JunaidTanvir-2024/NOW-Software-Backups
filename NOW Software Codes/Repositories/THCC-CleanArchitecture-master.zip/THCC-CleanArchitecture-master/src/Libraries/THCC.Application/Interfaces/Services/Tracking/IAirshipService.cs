﻿using THCC.Application.Models.Airship;

namespace THCC.Application.Interfaces.Services.Tracking
{
    public interface IAirshipService : ServiceType.ITransient
    {
        Task<(bool IsSuccess, string? ErrorMessage)> CreateEmailChannelAndAssociation(string emailAddress, bool isNew = false);
        Task<(bool IsSuccess, string? ErrorMessage)> EmailAssociationWithNamedUser(string namedUserId, string emailAddress);
        Task<(bool IsSuccess, string? ErrorMessage)> CreateEmailChannelCommercial(string emailAddress);
        Task<bool?> IsEmailChannelAlreadyExists(string emailAddress);
        Task<bool> AddCustomEvents(CustomEventsRequest request);
        Task<bool> AddCustomUserTags(CustomUserTagsRequest request);
    }
}
