﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface IPhoneNumberService
    {
        string GetCountryCode(string phoneNumber);
    }
}
