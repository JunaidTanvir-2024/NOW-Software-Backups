﻿namespace THCC.Application.Models.Dtos
{
    public sealed class IdentityErrorDto
    {
        public string Code { get; }
        public string Description { get; }

        public IdentityErrorDto(string code, string description)
        {
            Code = code;
            Description = description;
        }
    }
}
