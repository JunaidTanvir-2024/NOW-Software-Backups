﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request.Voucherify;
using Models.Contracts.Response.Voucherify;
using Newtonsoft.Json;
using Serilog;
using System.Threading.Tasks;
using THAApi.Utilities;

namespace THAApi.Controllers.v2
{
    [ApiController]
    [ApiVersion("2.0")]
    [Route("v{v:apiVersion}/[Controller]")]
    public class VoucherifyController : Controller
    {
        private readonly IVoucherify_BL _voucherify_BL;
        private readonly IPayment_BL _payment_BL;

        public VoucherifyController(
            IVoucherify_BL voucherify_BL,
            IPayment_BL payment_BL)
        {
            _voucherify_BL = voucherify_BL;
            _payment_BL = payment_BL;
        }

        [HttpGet("loyalties")]
        public async Task<ActionResult> GetLoyaltyInformation()
        {
            string loyaltyDescription = await this.RenderViewAsync(Pages.LoyaltyInfo, new VoucherifyLoyaltiesResponse(), false);
            var result = await _voucherify_BL.GetLoyaltiesInfo(User.Msisdn(), User.Email(), loyaltyDescription);
            return Ok(result);
        }

        [HttpPost("promotions")]
        public async Task<ActionResult> GetPromotions(GetCustomerSpecificPromotionsRequest request)
        {
            var userMsidn = User.Msisdn();
            var userAccount = User.Account();
            var currency = User.Currency();
            var result = await _voucherify_BL.GetCustomerSpecificPromotionsTiers(request, userMsidn, userAccount,currency);
            return Ok(result);
        }
        [ApiVersion("3.0")]
        [HttpPost("promotions")]
        public async Task<ActionResult> GetPromotionsV3(GetCustomerSpecificPromotionRequestV3 request)
        {
            var userMsidn = User.Msisdn();
            var userAccount = User.Account();
            var currency = User.Currency();
            var result = await _voucherify_BL.GetCustomerSpecificPromotionsTiersV3(request, userMsidn, userAccount,currency);
            return Ok(result);
        }

        [HttpPost("loyalties/redeem")]
        public async Task<ActionResult> RedeemLoyaltyPoints(LoyaltyPointsRedemptionRequest request)
        {
            var result = await _voucherify_BL.RedeemLoyaltyPoints(User.Msisdn(), request);
            return Ok(result);
        }

        // Refer a friend
        [HttpGet("invite/eligible")]
        public async Task<ActionResult> IsCustomerEligibleToGenerateInviationCode()
        {
            var userMsidn = User.Msisdn();
            var result = await _voucherify_BL.IsUserEligibleToGenerateInvitationCode(userMsidn);
            return Ok(result);
        }

        [HttpGet("invite")]
        public async Task<ActionResult> GenerateInviationCode()
        {
            var userMsidn = User.Msisdn();
            var result = await _voucherify_BL.GetReferralCode(userMsidn);
            return Ok(result);
        }

        [HttpPost("referral/validate")]
        public async Task<ActionResult> ValidateReferralCode(ReferralCodeValidationRequest request)
        {
            var userMsidn = User.Msisdn();
            var userAccount = User.Account();
            var result = await _voucherify_BL.ValidateReferralCode(request: request, userMsidn, userAccount);
            return Ok(result);
        }

        [HttpPost("discount/validate")]
        public async Task<ActionResult> ValidateDiscount(StackableDiscountRequest request)
        {
            request.DiscountCodeType = DiscountCodeType.Voucher;
            var userMsisdn = User.Msisdn();
            var userAccount = User.Account();
            var result = await _voucherify_BL.ValidateDiscount(request, userMsisdn, userAccount);
            return Ok(result);
        }
        [ApiVersion("3.0")]
        [HttpPost("discount/validate")]
        public async Task<ActionResult> ValidateDiscountV3(StackableDiscountRequestV3 request)
        {
            request.DiscountCodeType = DiscountCodeType.Voucher;
            var userMsisdn = User.Msisdn();
            var userAccount = User.Account();
            var result = await _voucherify_BL.ValidateDiscountV3(request, userMsisdn, userAccount);
            return Ok(result);
        }

        #region Old Unused Endpoints
        //[HttpGet]
        //public async Task<ActionResult> GetCustomers([FromQuery] GetVoucherifyCustomersRequest request)
        //{
        //    var result = await _voucherifyService.GetCustomers(request);
        //    return Ok(result);
        //}
        //[HttpGet("id")]
        //public async Task<ActionResult> GetCustomerById([FromQuery] GetVoucherifyCustomerRequest request)
        //{
        //    var result = await _voucherifyService.GetCustomerBySourceId(request);
        //    return Ok(result);
        //}
        //[HttpPost("redeem")]
        //public async Task<ActionResult> RedeemVoucher([FromBody] RedeemVoucherRequest request)
        //{
        //    var result = await _voucherifyService.RedeemVoucher(request);
        //    return Ok(result);
        //}

        //[HttpPost("loyalty/redeem")]
        //public async Task<ActionResult> RedeemPoints([FromBody] LoyaltyPointsRedemptionRequest request)
        //{
        //    var result = await _voucherifyService.RedeemVoucher(request);
        //    return Ok(result);
        //}
        #endregion
    }
}