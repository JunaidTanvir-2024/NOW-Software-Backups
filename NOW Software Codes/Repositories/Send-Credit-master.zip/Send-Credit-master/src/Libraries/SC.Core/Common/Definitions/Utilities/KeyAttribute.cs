﻿using System;
namespace SC.Core.Common.Definitions.Utilities;
[AttributeUsage(AttributeTargets.Field)]
public class KeyAttribute : Attribute
{
    public string Id { get; protected set; }
    public KeyAttribute(string id)
    {
        Id = id;
    }
}

