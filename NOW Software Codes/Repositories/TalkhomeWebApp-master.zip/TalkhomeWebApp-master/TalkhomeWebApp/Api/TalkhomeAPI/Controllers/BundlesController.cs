﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Services.Interfaces;
using TalkhomeAPI.Utilities;
using ThmApi.Filters;

namespace TalkhomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BundlesController : ControllerBase
    {
        private readonly IBundleService _bundleService;
        private readonly ILogger _logger;

        public BundlesController(IBundleService bundleService, ILogger logger)
        {
            _bundleService = bundleService;
            _logger = logger;
        }
        [HttpPost]
        [Route("ValidateBundlePurchase/{bundleId}")]
        [Authorize]
        public async Task<IActionResult> ValidateBundlePurchase(string bundleId,bool startTrial)
        {
            return Ok(await _bundleService.ValidateBundlePurchase(User.AccountId(), User.Msisdn(), bundleId,startTrial));
        }
        [HttpGet]
        [Route("GetCountriesByBundle")]
        [BasicAuth]
        public async Task<IActionResult> GetCountriesByBundle()
        {
            try
            {
                return Ok(await _bundleService.GetCountriesByBundle());
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: BundlesController, Method: GetCountriesByBundle, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetBundleByCountry")]
        [BasicAuth]
        public async Task<IActionResult> GetBundleByCountry(string ServiceId,string account=null)
        {
            try
            {
                return Ok(await _bundleService.GetBundleByCountry(ServiceId,account));
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: BundlesController, Method: GetBundleByCountry, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }

        }
        [HttpGet]
        [Route("GetBundleByDestinationCountry")]
        [BasicAuth]
        public async Task<IActionResult> GetBundleByDestinationCountry(string ServiceId,string toCountryCode,string account=null)
        {
            try
            {
                return Ok(await _bundleService.GetBundleByDestinationCountry(ServiceId,toCountryCode,account));
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: BundlesController, Method: GetBundleByCountry, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }

        }

        [HttpGet]
        [Route("GetBundleByID")]
        [BasicAuth]
        public async Task<IActionResult> GetBundleByID(string Id)
        {
            try
            {
                Guid id = Guid.Parse(Id);
                return Ok(await _bundleService.GetBundleById(Id));
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: BundlesController, Method: GetBundleByID, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [HttpPost]
        [Route("SetBundleAutoRenew")]
        [Authorize]
        public async Task<IActionResult> SetBundleAutoRenew([FromBody]SetBundleAutoRenewRequestModel model)
        {
            try
            {
                var msisdn = User.Msisdn();
                return Ok(await _bundleService.SetAutoRenew(model.IsAutoRenew, msisdn, model.BundleId));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: BundlesController, Method: SetBundleAutoRenew, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [HttpGet]
        [Route("IsAnyActiveAutoBundleRenwal")]
        [Authorize]
        public async Task<IActionResult> AnyActiveAutoBundleRenwal(string account)
        {
            try
            {
                return Ok(await _bundleService.AnyActiveAutoBundleRenwal(account));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: BundlesController, Method: IsAnyActiveAutoBundleRenwal, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
    }
}