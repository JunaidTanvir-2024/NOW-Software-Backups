namespace Application.Features.Bundle.BundleRenewal;

public sealed class BundleAutoRenewalRequestValidator : AbstractValidator<BundleAutoRenewalRequest>
{
    public BundleAutoRenewalRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn)
            .Cascade(CascadeMode.Stop)
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid Msisdn");
        RuleFor(p => p.BundleId).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.IsAutoRenew).Cascade(CascadeMode.Stop).NotNull();
    }
}