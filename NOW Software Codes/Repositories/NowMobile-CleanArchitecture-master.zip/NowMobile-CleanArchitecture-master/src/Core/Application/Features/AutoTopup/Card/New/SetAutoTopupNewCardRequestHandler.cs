using Application.Common.Interfaces.Payment;
using Application.Common.Settings;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;
using Microsoft.Extensions.Options;

namespace Application.Features.AutoTopup.Card.New;

public class SetAutoTopupNewCardRequestHandler : IRequestHandler<SetAutoTopupNewCardRequest, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly TopupSettings _topupSettings;

    public SetAutoTopupNewCardRequestHandler(
        IPaymentService paymentService,
        ICurrentUser currentUser,
        IMapper mapper,
        IOptions<TopupSettings> topupSettings)
    {
        _paymentService = paymentService;
        _currentUser = currentUser;
        _mapper = mapper;
        _topupSettings = topupSettings.Value;
    }
    public async Task<Result<CardResponse>> Handle(SetAutoTopupNewCardRequest request, CancellationToken cancellationToken)
    {
        request.ThresHoldAmount = _topupSettings.ThresholdAmount;
        request.PaymentCardInfo.SaveCard = true;
        request.PaymentCardInfo.MakeDefault = true;
        var paymentTopupInfo = _mapper.Map<PaymentTopupInfo>(request);
        return await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: request.PaymentCardInfo,
            paymentExistingCardInfo: null!,
            paymentAddressInfo: request.PaymentAddressInfo,
            topupInfo: paymentTopupInfo,
            bundleInfo: null!,
            creditSimInfo: null!,
            msisdn: request.Msisdn,
            email: _currentUser.GetUserEmail()!,
            ipAddress: request.IpAddress,
            cardMaskedPan: null!,
            cardScheme: null!,
            isAuthorizeOnly: true
            );
    }
}