using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Promotions.Common;

public class PromotionTierOrderInfo
{
    public long? Amount { get; set; }
    public string? SkuId { get; set; }
    public int? Quantity { get; set; } = 1;
    public Metadata? Metadata { get; set; }
}
