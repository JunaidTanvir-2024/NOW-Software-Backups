﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class BundleResponseModel
    {
        public string UUID { get; set; }
        public string Id { get; set; }
        public string BrandedName { get; set; }
        public int PackageType { get; set; }
        public int PackageCategory { get; set; }
        public int TotalCostPence { get; set; }
        public int ChargePeriodDays { get; set; }
        public int Texts { get; set; }
        public int Seconds { get; set; }
        public int Minutes { get; set; }
        public int Data { get; set; }
        public DateTime Expiry { get; set; }
        public int RemainingTexts { get; set; }
        public int RemainingSeconds { get; set; }
        public int RemainingMinutes { get; set; }
        public int RemainingData { get; set; }
        public string Name { get; set; }
        public bool isRenew { get; set; }
    }
}
