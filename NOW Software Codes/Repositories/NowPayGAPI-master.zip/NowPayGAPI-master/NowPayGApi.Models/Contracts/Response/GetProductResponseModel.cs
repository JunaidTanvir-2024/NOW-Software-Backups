﻿using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
   public  class GetProductResponseModel
    {
        public IEnumerable<DBProduct> Products { get; set; }
    }
}
