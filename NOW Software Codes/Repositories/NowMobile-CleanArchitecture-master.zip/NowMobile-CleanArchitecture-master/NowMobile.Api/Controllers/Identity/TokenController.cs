﻿using Application.Common.Models.ResponseWrappers;
using Application.Features.Identity.SocialLogin;
using Application.Features.Identity.Tokens;
using Application.Features.Identity.Tokens.RefreshToken;
using Application.Features.Identity.Tokens.Token;

namespace NowMobile.Api.Controllers.Identity;

public class TokenController : VersionedApiController
{
    [HttpPost]
    [AllowAnonymous]
    [OpenApiOperation("Request an access token using credentials.", "")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Result<TokenResponse>))]
    public async Task<IActionResult> TokenAsync([FromBody] TokenRequest request, CancellationToken cancellationToken)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("refresh")]
    [AllowAnonymous]
    [OpenApiOperation("Request an access token using a refresh token.", "")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Result<TokenResponse>))]
    public async Task<IActionResult> RefreshAsync([FromBody] RefreshTokenRequest request, CancellationToken cancellationToken)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("socialLogin"), AllowAnonymous, OpenApiOperation("login by using Social Account", "")]
    public async Task<IActionResult> SocialLogin([FromBody] SocialLoginRequest request)
    {
        // request.AccessToken = "EAADz3Oh6yowBANU3fzcNW7fLyt5jhjtCWFeds4OVRKqilZBGZCOKANZCR3ndnLOYS4J92x4R9833aUOkzLtraJjLOr9XSHHYSuBTRoHlZCc0CfwKayjjOLCXvgYCJVpdgcVY9W6pZBWhyerGPghfaYNKN3kZBtqBORCOUlnlsvtfLTqMzpakafKl9nAZBxMYKicbrT0FEoEA3qb1pFDR0W1z0AgAhZBTIZAZBaRJJmoATk5X6WdE7L070ZAA305PJ6ZBy9oZD";
        //  request.SocialLoginType = SocialLoginType.Facebook;
        return Ok(await Mediator.Send(request));
    }

    private string GetIpAddress() =>
        Request.Headers.ContainsKey("X-Forwarded-For")
            ? Request.Headers["X-Forwarded-For"]
            : HttpContext.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "N/A";
}
