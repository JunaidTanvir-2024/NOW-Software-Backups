﻿using Microsoft.AspNetCore.Authorization;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TrasnferHome.Infrastructure.DAL.Interfaces;

namespace TransferHomeAPI.BasicAuth
{
    public class ActiveDeviceRequirement : IAuthorizationRequirement { }

    public class ActiveDeviceHandler : AuthorizationHandler<ActiveDeviceRequirement>
    {
        private readonly ILogger Logger;

        private readonly IDL_User DlUser;

        public ActiveDeviceHandler(IDL_User dlUser, ILogger logger)
        {
            Logger = logger;
            DlUser = dlUser;
        }

        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, ActiveDeviceRequirement requirement)
        {
            var authFilterCtx = (Microsoft.AspNetCore.Mvc.Filters.AuthorizationFilterContext)context.Resource;
            var httpContext = authFilterCtx.HttpContext;

            try
            {
                if (!httpContext.Request.Headers.ContainsKey("Authorization"))
                {
                    context.Fail();
                    //Logger.Error($"Class: ActiveDevice, Method: ForbiddenNoToken,EndPoint=> {authFilterCtx.ActionDescriptor.DisplayName}");
                }
                else
                {
                    string Bearertoken = "";

                    try
                    {
                        var basicAuthToken = httpContext.Request.Headers["Authorization"].ToString();
                        var authHeader = AuthenticationHeaderValue.Parse(basicAuthToken).ToString();
                        Bearertoken = authHeader.Split(" ")[1];
                    }
                    catch (Exception)
                    {

                    }

                    string userDeviceId = "";
                    string userId = "";

                    try
                    {
                        userDeviceId = httpContext.User.Claims.Where(x => x.Type == "UDID").FirstOrDefault().Value;
                        userId = httpContext.User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                    }
                    catch (Exception)
                    {

                    }

                    var IsActiveDevice = await DlUser.IsUserDeviceActive(userDeviceId, Bearertoken, userId, httpContext.Request.Path.Value, authFilterCtx.RouteData.Values["action"].ToString());

                    if (IsActiveDevice)
                    {
                        context.Succeed(requirement);
                        //Logger.Information($"Class: ActiveDevice, Method: ForbiddenSuccess, EndPoint=> {authFilterCtx.ActionDescriptor.DisplayName}, Parameters=> UDID: {userDeviceId}, FullToken : {Bearertoken} : UserId:{userId}");
                    }
                    else
                    {
                        context.Fail();
                        //Logger.Information($"Class: ActiveDevice, Method: Forbidden,EndPoint=> {authFilterCtx.ActionDescriptor.DisplayName}, Parameters=> UDID: {userDeviceId}, FullToken : {Bearertoken} : UserId:{userId}");
                    }
                }
            }
            catch (Exception ex)
            {
                context.Succeed(requirement);
                //  Logger.Error($"Class: ActiveDevice, Method: ForbiddenException,EndPoint=> {authFilterCtx.ActionDescriptor.DisplayName}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                //return Task.FromResult(0);
            }
        }
    }
}
