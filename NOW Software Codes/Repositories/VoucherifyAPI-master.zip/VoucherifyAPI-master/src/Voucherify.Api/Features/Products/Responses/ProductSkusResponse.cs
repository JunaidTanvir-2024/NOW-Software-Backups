namespace Voucherify.Api.Features.Products.Responses;

public class ProductSkusResponse
{
    public string? ProductId { get; set; }
    public string? SkuId { get; set; }
    public string? SourceId { get; set; }
    public long? Price { get; set; }
    public string? Currency { get; set; }
    public long Points { get; set; }
}
