using FluentValidation;
using Mediator;
using RW;
using JM.Core.Utilities.Interfaces.Services;
using JM.Core.Utilities.Dtos.Auth;
using JM.Infrastructure.Services.Mailing;
using JM.Core.Utilities.Dtos.Mail;
using JM.Core.Utilities.Definitions;
using JM.Core.Features.Auth.Otp;
using JM.Core.Utilities.Interfaces.Database;

namespace JM.Core.Features.Auth.Register;
public abstract class Register
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public string Email { get; set; } = string.Empty;
		public string Password { get; set; } = string.Empty;
	}

	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.Email).NotNull().NotEmpty();
			RuleFor(x => x.Password).NotNull().NotEmpty();
		}
	}

	#endregion

	#region Response
	public sealed record Response { }

	#endregion

	#region Handler
	internal sealed class Handler(IIdentityService authService, IMailService mailService, IUnitOfWork unitOfWork, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IIdentityService _authService = authService;
		private readonly IMailService _mailService = mailService;
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		private readonly IMediator _mediator = mediator;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{
			var user = await _unitOfWork.UserRepository.GetUser(x => x.NormalizedEmail!.Equals(query.Email.ToUpperInvariant()));

			if (user is not null)
			{
				return ResultWrapper.Failure(AppConstant.StatusKey.Conflict, AppConstant.StatusCode.Conflict);
			}

			var signupResult = await _authService.RegisterAsync(new RegisterDto.Request()
			{
				Email = query.Email,
				Password = query.Password,
			});
			if (signupResult.IsSuccess)
			{
				var sendOtpResult = (await _mediator.Send(new GetOtp.Query
				{
					Type = AppEnum.OtpType.Signup,
					Email = query.Email
				}, cancellationToken));

				if (sendOtpResult.IsSuccess)
				{
					var otpResult = sendOtpResult.TypedPayload<GetOtp.Response>();
					await _mailService.SendEmail(new MailDto.Request()
					{
						Subject = "Welcome",
						To = [query.Email],
						Body = $"<h1>Here is your code {sendOtpResult!.Code}</h1>",
					}, cancellationToken);

					return ResultWrapper.Success(AppConstant.StatusKey.UserCreated, AppConstant.StatusCode.Created);
				}
				return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
			}

			return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
		}
	}
	#endregion
}
