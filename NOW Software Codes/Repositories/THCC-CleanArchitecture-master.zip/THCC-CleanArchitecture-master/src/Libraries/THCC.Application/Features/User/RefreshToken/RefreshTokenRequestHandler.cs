﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

namespace THCC.Application.Features.User.RefreshToken;

public class RefreshTokenRequestHandler : IRequestHandler<RefreshTokenRequest, object>
{
    #region Fields

    private readonly IJwtService _jwtService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly ProfileSettings _profileSetting;
    private readonly IUserRepository _userRepository;

    #endregion

    #region Ctors

    public RefreshTokenRequestHandler(
        IJwtService jwtService,
        ICurrentUser currentUser,
        IMapper mapper,
        ICommonService commonService,
        IOptions<ProfileSettings> profileSetting,
        IUserRepository userRepository)
    {
        _jwtService = jwtService;
        _currentUser = currentUser;
        _mapper = mapper;
        _commonService = commonService;
        _profileSetting = profileSetting.Value;
        _userRepository = userRepository;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(RefreshTokenRequest request, CancellationToken cancellationToken)
    {
        var response = await _jwtService.RefreshTokenAsync(request.Token, request.RefreshToken);
        if (response == null)
        {
          return ErrorResult.Failure(CustomStatusKey.Unauthorized, CustomStatusCode.Unauthorized);
        }
        response.User.ImagePath = !string.IsNullOrEmpty(response.User?.ImagePath!.Trim()) ? $"{_commonService.GetHostRequestUrl()}{_profileSetting.VirtualDirectoryName}/{response.User!.Id}/{response.User.ImagePath}" : null;
        return response!;
    }

    #endregion
}