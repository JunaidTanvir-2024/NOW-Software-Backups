﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBUserTokens
    {
        public int Id { get; set; }
        public string Token { get; set; }
        public int TokenTypeId { get; set; }
        public bool IsUsed { get; set; }
        public int UserId { get; set; }
    }
}