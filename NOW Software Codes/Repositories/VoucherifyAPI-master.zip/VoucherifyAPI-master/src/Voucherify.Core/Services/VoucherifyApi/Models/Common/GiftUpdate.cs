using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class GiftUpdate
{
    [JsonPropertyName("amount")]
    public long Amount { get; set; }
}
