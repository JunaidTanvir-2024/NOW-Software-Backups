
using DC.Infrastructure.Common.Middlewares;
using DC.Infrastructure.Services.OpenApi;


namespace DC.Infrastructure;

public static class ConfigureDependencies
{
    public static IServiceCollection AddInfrastructureDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddDistributedMemoryCache();
        services.RegisterJsonSettings(configuration);
        services.RegisterBuiltInServices();
        services.AddApiVersioningConfiguration();
        services.AddOpenApiConfiguration();
        return services;
    }
    private static IServiceCollection RegisterBuiltInServices(this IServiceCollection services)
    {
        services.AddHttpClient();
        services.AddHttpContextAccessor();
        return services;
    }

    private static IServiceCollection RegisterJsonSettings(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<OpenApiSetting>(configuration.GetSection(OpenApiSetting.SectionName));
        services.Configure<SecurityHeaderSetting>(configuration.GetSection(SecurityHeaderSetting.SectionName));
        services.Configure<PhishingSetting>(configuration.GetSection(PhishingSetting.SectionName));
        return services;
    }
    public static IApplicationBuilder UseInfrastructureMiddlewares(this IApplicationBuilder app)
    {
        app.UseAppExceptionMiddleware();
        app.UseOpenApiConfiguration();
        app.UseSecurityHeadersMiddleware();
        app.UseAppLoggingMiddleware();
        return app;
    }
}
