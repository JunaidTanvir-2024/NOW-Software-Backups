﻿using MapsterMapper;
using RW.Models;

using SC.Core.Features.Products.Requests;
using SC.Core.Features.Products.Responses;
using SC.Core.Vendors.FusionHub;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static SC.Core.Features.Products.Responses.GetProductResponseRapper;

namespace SC.Core.Features.Products
{
  
    internal sealed class GetProductByCategoryHandler : IRequestHandler<GetProductByCategoryRequest, IResultWrapper>
    {
        private readonly IFusionHubService _fusionHubService;
        private readonly IMapper _mapper;
        public GetProductByCategoryHandler(IFusionHubService fusionHubService, IMapper mapper)
        {
            _fusionHubService = fusionHubService;
            _mapper = mapper;
        }

        public async Task<IResultWrapper> Handle(GetProductByCategoryRequest request, CancellationToken cancellationToken)
        {
            var request1 = _mapper.Map<GetProductsRequest>(request);


            var response = await _fusionHubService.GetProductsAsync(request1);
            if (response?.Payload == null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
            }


       

           var GroupingProducts = response.Payload.
                                                                           GroupBy(x => x.Product.ProductSubCategory.SubCategoryName).ToDictionary(
                                                                                 group => group.Key!,
                                                                                 group => group.ToList()
                                                                             );

            List<GetProductResponseRapper> ProductsResponse = new List<GetProductResponseRapper>();
            foreach (var group in GroupingProducts)
            {
                GetProductResponseRapper resultItem = new GetProductResponseRapper
                {
                    Category = new ParticularCategoryProducts
                    {
                        Name = group.Key,
                        Products = group.Value.Select(x => x.Product).ToList()
                    }

                };

                ProductsResponse.Add(resultItem);
            }




            return ResultWrapper.Success(ProductsResponse, new Pagination(response?.PaginationInfo.TotalCount, response?.PaginationInfo.PageCount, response?.PaginationInfo.CurrentPage, response?.PaginationInfo.PageSize));
        }
    }
}
