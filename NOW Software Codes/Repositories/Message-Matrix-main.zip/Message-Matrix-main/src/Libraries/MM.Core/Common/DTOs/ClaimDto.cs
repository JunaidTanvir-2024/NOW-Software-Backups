namespace MM.Core.Common.DTOs;
public record ClaimDto();
