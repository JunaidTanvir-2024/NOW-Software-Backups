﻿namespace THCC.Domain.Aggregates
{
    public class PaymentDetail
    {
        public string? ProductType { get; set; }
        public string? OrderDate { get; set; }
        public string? CardNumber { get; set; }
        public string? CardPin { get; set; }
        public string? PaymentType { get; set; }
        public string? TotalAmount { get; set; }
        public string? OrderRef { get; set; }
        public string? Description { get; set; }
    }
}
