﻿using SenderService.Core.Features.Domain.Request;
using SenderService.Core.Features.Domain.Response;
using SenderService.Core.Persistence.Repository;

namespace SenderService.Core.Features.Domain;
internal class BlockedDomainService : IBlockedDomainService
{
    private readonly IBlockedDomainRepository _blockedDomainRepository;

    public BlockedDomainService(IBlockedDomainRepository blockedDomainRepository)
    {
        _blockedDomainRepository = blockedDomainRepository;
    }
    public async Task<long> AddBlockedDomainAsync(AddBlockedDomainRequest request)
    {
        // Product and Product Item Chunk
        var blockedDomain = new Persistence.Entities.BlockDomain()
        {
            Domain = request.Domain,
            BlockDate = DateTime.Now,
        };

        var blockedDomainId = await _blockedDomainRepository.AddBlockedDomainAsync(blockedDomain);
        return blockedDomainId;
    }
    public async Task<List<BlockedDomainResponse>> GetBlockedDomainsAsync()
    {
        var blockedDomains = (await _blockedDomainRepository.GetAllBlockedDomainsAsync()).ToList();
        var result = blockedDomains.ConvertAll(x => new BlockedDomainResponse()
        {
            Domain = x.Domain,
            BlockDate = x.BlockDate,
        });
        return result;
    }
    public async Task<BlockedDomainResponse> GetBlockedDomainByNameAsync(GetDomainByNameRequest request)
    {
        var blockedDomainByName = await _blockedDomainRepository.GetSpecificBlockedDomainAsync(request.Domain);
        var result = new BlockedDomainResponse()
        {
            Domain = blockedDomainByName?.Domain,
            BlockDate = blockedDomainByName!.BlockDate,
        };
        return result;
    }
}
