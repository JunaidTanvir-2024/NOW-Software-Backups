﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.IO;

namespace PaymentsApi
{
    public class Program
    {
        public static IConfiguration Configuration { get; set; }

        public static void Main(string[] args)
        {
            var builder = new ConfigurationBuilder()
                                .SetBasePath(Directory.GetCurrentDirectory())
                                .AddJsonFile("appsettings.json");
            Configuration = builder.Build();

            string environment = Configuration["Environment"];
            Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", environment);
            builder = new ConfigurationBuilder()
                                .SetBasePath(Directory.GetCurrentDirectory())
                                .AddJsonFile("appsettings.json")
                                .AddJsonFile($"appsettings.{environment}.json");
            Configuration = builder.Build();
            string port = Configuration["HostPort"];
            WebHost.CreateDefaultBuilder(args)
               .UseStartup<Startup>()
               .UseUrls($"http://*:{port}")
               .UseSentry()
               .Build()
               .Run();
        }
    }
}




