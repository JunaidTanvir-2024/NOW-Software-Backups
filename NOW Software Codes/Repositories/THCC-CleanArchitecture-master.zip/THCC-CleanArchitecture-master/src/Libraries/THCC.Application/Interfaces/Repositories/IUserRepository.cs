﻿using Microsoft.AspNetCore.Identity;
using THCC.Application.Models.Dtos;
using THCC.Domain.Aggregates;

namespace THCC.Application.Interfaces.Repositories;

public interface IUserRepository : ServiceType.IScoped
{
    Task<User?> GetUserByEmailAsync(string userEmail);
    Task<User?> GetUserByIdAsync(string userId);
    Task<IEnumerable<string>> GetUserRoleAsync(User user);
    Task<(string id, bool isSuccess, IEnumerable<IdentityErrorDto>? errors)> Create(User user, string password);
    Task<(bool isSuccess, int errorCode, string errorMessage)> CreateProduct(string product, string userId, DateTime dateCreated);
    Task<IdentityResult> ConfirmEmailAsync(User user, string token);
    Task UpdateRefreshTokenAsync(string email, string refreshToken, DateTime refreshTokenExpiryTime);
    Task<string> GeneratePasswordResetTokenAsync(User user);
    Task<IdentityResult> PasswordResetAsync(User appUser, string token, string newPassword);
    Task<string> GenerateEmailConfirmationTokenAsync(User appUser);
    Task<bool> IsValidToken(User user, string token, OtpType type);
    Task<IdentityResult> UpdatUserAsync(User user, string firstname, string lastname, string password = null!);
    Task<IdentityResult> UpdateprofileImage(User user, string path);
    Task<UserProduct> GetUserProducts(string userId);
    Task<AccountDto> GetAccountDetails(string cardnumber);
    Task<LastTopupDto> GetLastTopup(string cardnumber);
    Task<(int, IList<PaymentDetail>)> PaymentHistory(string userId, int pageNo, int pageSize, int productType);
    Task AddRating(int rating, string userId);
    Task<List<PinDetail>> CallingCardsHistory(string userId);
    Task<User> GetUserByProduct(string cardNumber);
    Task<bool> IsSocialLoginUser(User user);
}