﻿using System;
using Microsoft.Extensions.Configuration;
using TransferHome.Models.Contracts.Response;

namespace TransferHomeAPI.JwtHelpers
{
    public static class JwtExtensions
    {   
        public static void GenerateToken(this LoginResponseModel user, IConfiguration configuration, string UDID)
        {
            try
            {
                var token = new JwtTokenBuilder()
                                .AddSecurityKey(JwtSecurityKey.Create(configuration.GetValue<string>("JwtSecretKey")))
                                .AddIssuer(configuration.GetValue<string>("JwtIssuer"))
                                .AddAudience(configuration.GetValue<string>("JwtAudience"))
                                .AddExpiryInDays(30)
                                .AddClaim("Id", user.Id.ToString())
                                .AddClaim("UDID", UDID)
                                .Build();

                user.Token = token.Value;
                user.TokenExpirationDateTime = token.ValidTo;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
