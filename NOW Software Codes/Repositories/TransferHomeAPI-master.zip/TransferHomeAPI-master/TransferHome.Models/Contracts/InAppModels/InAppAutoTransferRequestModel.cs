﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.InAppModels
{
    public class InAppAutoTransferRequestModel
    {
        [Required]
        public string nowtelTransactionReference { get; set; }
        [Required]
        public string operatorid { get; set; }
        [Required]
        public string product { get; set; }
        [Required]
        public string messageToRecipient { get; set; }
        [Required]
        public string fromMSISDN { get; set; }

        [Required]
        public decimal Amount { get; set; }
        [Required]
        public string Currency { get; set; }

        [Required]
        public RegularityType RegularityType { get; set; }
    }
}
