﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Models.Enums
{
    public enum Tags
    {
        topup_app,
        tha_customer_app,
        topupany_app,
        topup5_app,
        topup10_app,
        topup15_app,
        topup20_app,
        topup25_app,
        en_topup_app,
        dis_topup_app,
        purchase_success,
        purchase_failure,


    }
}
