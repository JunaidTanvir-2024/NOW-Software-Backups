﻿namespace Models.Contracts.Request
{
    public class UserAccountRatesSheet
    {
        public string NetworkAccessServiceName { get; set; }

        public string NetworkAccessServiceId { get; set; }

        public string TariffName { get; set; }
    }
}
