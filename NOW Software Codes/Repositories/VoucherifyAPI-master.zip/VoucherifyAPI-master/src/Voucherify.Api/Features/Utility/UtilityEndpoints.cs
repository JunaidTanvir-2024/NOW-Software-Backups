using Microsoft.AspNetCore.Mvc;

using Voucherify.Api.Features.Utility.Requests;
using Voucherify.Core.Commons.Filters;

namespace Voucherify.Api.Features.Utility;

public static class UtilityEndpoints
{
    private const string EndpointPrefix = "/api/events";
    private const string EndpointTag = "Utility Endpoints";

    public static void AddUtilityEndpoints(this WebApplication app)
    {
        var vouchersEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);

        vouchersEndpoints.MapPost("", InvokeVoucherifyEvent)
            .AddEndpointFilter<FluentValidationFilter<InvokeEventRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

    }
    private static async Task<IResult> InvokeVoucherifyEvent(IUtilityHandler utilityHandler, [FromBody] InvokeEventRequest request)
    {
        var result = await utilityHandler.InvokeVoucherifyEvent(request);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
}
