using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;

namespace FH.UseCases.Countries;
public sealed class GetCountryByIsoCode
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public required string IsoCode { get; set; }
		public bool IsActive { get; set; } = true;
		public bool IsDeleted { get; set; } = false;
	}

	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.IsoCode)
				.NotNull()
				.Length(2)
				.WithMessage("ISO Code length must be in 2 letters")
				.Matches("^[A-Za-z]+$")
				.WithMessage("ISO Code must contain only alphabets");
		}
	}

	#endregion

	#region Response
	public sealed record Response
	{
		public long CountryId { get; set; }
		public string? IsoCode2 { get; set; }
		public string? IsoCode3 { get; set; }
		public int CallingCode { get; set; }
		public string? CountryName { get; set; }
		public int IsoNumericCode { get; set; }
		public string? Continent { get; set; }
	}

	#endregion

	#region Handler
	internal sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IMapper _mapper = mapper;
		private readonly IUnitOfWork _unitOfWork = unitOfWork;

		public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
		{
			var getCountryRequest = _mapper.Map<CountryByIsoCodeDto.Request>(request);

			// Assigning Default Values
			getCountryRequest.IsActive = true;
			getCountryRequest.IsDeleted = false;

			var country = await _unitOfWork.CountryRepository.GetCountryByIsoCode(getCountryRequest);

			if (country is null)
			{
				ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
			}

			var getCountry = _mapper.Map<Response>(country!);

			return ResultWrapper.Success(getCountry);
		}
	}
	#endregion
}
