﻿$(document).ready(function () {

    GetUserPortDetails_port();
    GetSwitchingInfo_port();
    SetMinDate_port();

    $('#dplUserProducts').change(function () {
        GetSwitchingInfo_port();
        GetUserPortDetails_port();
    });

    $('#btnPortOutModal').click(function () {
        $('#PortOut_NTMsisdn').val($('#dplUserProducts').val());
    });

    $('[data-toggle="tooltip"]').tooltip({ trigger: 'hover' });

    $('.modal').on('shown.bs.modal', function (e) {
        $('body').css('padding-right', 0);
    });

    $('#BtnConfirmPortInCancel').click(function () {
        $('#ConfirmPortInModal').modal('hide');
        $('#PortInModal').modal('show');
    });

    $('#BtnConfirmPortIn').click(function () {

        var data = {
            NTMsisdn: $('#dplUserProducts').val(),
            PortMsisdn: $("#PortIn_PortMsisdn").val().trim(),
            UserPortingDate: $("#PortIn_UserPortingDate").val(),
            Code: $("#PortIn_Code").val().trim()
        };

        $.ajax({
            type: "POST",
            url: "/Account/PortIn",
            data: data,
            beforeSend: function () {
                $('#BtnConfirmPortInSpinner').fadeIn();
                $('#BtnConfirmPortInCancel,#BtnConfirmPortIn').attr('disabled', true);
            },
            success: function (result) {
                if (result != null) {
                    if (result.statusCode == 1 && result.data != null) {
                        if (result.data.errorCode == 0) {
                            $('#ConfirmPortInModal').modal('hide');
                            toastr.success(result.data.message, 'Success', { positionClass: 'toast-top-center', timeOut: "2000" });
                            GetUserPortDetails_port($('#dplUserProducts').val());
                        }
                        else {
                            toastr.error(result.data.message, 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
                        }
                    }
                    else if (result.statusCode == 0) {
                        var html = '';
                        $(result.data, function (key, val) {
                            html += val.errorMessage + "<br/>";
                        });
                        toastr.error(html, 'Validation Errors', { positionClass: 'toast-top-center', timeOut: "3000" });
                    }
                    else { toastr.error('Something went wrong on server.', 'Error', { positionClass: 'toast-top-center', timeOut: "2000" }); }
                }
                else { toastr.error('Something went wrong on server.', 'Error', { positionClass: 'toast-top-center', timeOut: "2000" }); }
            },
            error: function () {
                toastr.error('Something went wrong on server.', 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
            },
            complete: function () {
                $('#BtnConfirmPortInSpinner').fadeOut();
                $('#BtnConfirmPortInCancel,#BtnConfirmPortIn').attr('disabled', false);
            }
        });


    });

});

function SetMinDate_port() {

    //Set Minimum Date
    $('#PortOut_UserPortingDate,#PortIn_UserPortingDate').attr("min", new Date().toISOString().split("T")[0])

    //Set Today Date
    $('#PortOut_UserPortingDate,#PortIn_UserPortingDate').attr("value", new Date().toISOString().split("T")[0])

}

function NumberValidation_port(evt) {

    var TotalLength = $("#" + evt.currentTarget.id).val().length;

    var theEvent = evt || window.event;

    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }
    var regex = /[0-9]/;
    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }
    if (TotalLength >= 14) {
        theEvent.returnValue = false;
        theEvent.preventDefault();
    }
}

function GetUserPortDetails_port() {
    $.ajax({
        type: "POST",
        url: "/Account/GetUserPortDetials",
        data: { Number: $('#dplUserProducts').val() },
        beforeSend: function () {
            $('.loading-bar').show();
        },
        success: function (result) {
            if (result != null) {
                if (result.errorCode == 0) {
                    var html = '';
                    $.each(result.payload.portingRequestList, function (key, val) {
                        html += "<tr><td> " + (val.portType == 1 ? "Port In" : (val.portType == 2 ? "Port In New Order " : "Port Out ")) + "</td > " +
                            "<td>" + (val.portMsisdn == null ? "" : val.portMsisdn) + "</td>" +
                            "<td>" + (val.code == null ? "N/A" : val.code) + "</td>";

                        if (val.codeType == 0) {
                            html += "<td>N/A</td>";
                        }
                        else {
                            html += "<td>" + (val.codeType == 1 ? "PAC" : "STAC") + "</td>";
                        }
                        if (val.userPortingDate != null) {
                            var RequestPortingDate = new Date(val.userPortingDate);
                            html += "<td>" + RequestPortingDate.getDate() + "/" + (RequestPortingDate.getMonth() + 1) + "/" + RequestPortingDate.getFullYear() + "</td>";
                        }
                        else {
                            html += "<td>N/A</td>";
                        }
                        if (val.expiryDate != null) {
                            var RequestExpiryDate = new Date(val.expiryDate);
                            html += "<td>" + RequestExpiryDate.getDate() + "/" + (RequestExpiryDate.getMonth() + 1) + "/" + RequestExpiryDate.getFullYear() + "</td>";
                        }
                        else {
                            html += "<td>N/A</td>";
                        }
                        if (isNullOrWhitespace(val.status)) {
                            html += "<td>Requested</td>";
                        }
                        else if (val.status == "Error") {
                            if (val.daemonErrorMessage == null) {
                                html += "<td><span class=\"label-danger\">Error</span></td>";
                            }
                            else {
                                html += "<td><span class=\"label-danger\" data-showError=\"Yes\" data-toggle=\"tooltip\" data-placement=\"top\" data-original-title='" + val.daemonErrorMessage + "'>" + val.status + "</span></td>";
                            }
                        }
                        else {
                            html += "<td>" + val.status + "</td>";
                        }
                        if (val.PortType === 1 || val.PortType === 2 || val.isCancelled == true || val.isError == true || val.status == "Complete" || val.status == "Completed") {
                            html += "<td></td>";
                        }
                        else {
                            if (val.portType == 3) {
                                html += "<td><a class=\"btn btn-success text-white\" onclick=\"ConfirmCancel_port(" + val.id + ")\">Cancel</a></td>";
                            }
                        }
                        html += "</tr>";
                    });

                    $('#porting-information-tbody').html(html);

                    $('[data-showError="Yes"]').tooltip({ trigger: 'hover' });
                }
                else {
                    $('#porting-information-tbody').html('');
                    toastr.error(result.message, 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
                }
            }
            else {
                $('#porting-information-tbody').html('');
                toastr.error('Something went wrong on server.', 'Porting Request Data', { positionClass: 'toast-top-center', timeOut: "2000" });
            }
        },
        error: function () {
            toastr.error('Something went wrong on server.', 'Porting  Request Data', { positionClass: 'toast-top-center', timeOut: "2000" });
        },
        complete: function () {
            $('.loading-bar').hide();
        }
    });
}

function PortIn_port() {


    if ($('#PortInForm').valid()) {

        $('#PortInModal').modal('hide');

        $('#txtPortInMsisdn').text($("#PortIn_PortMsisdn").val().trim());
        $('#txtNTMsisdn').text($('#dplUserProducts').val());

        $('#ConfirmPortInModal').modal('show');

    }
    else {
        return false;
    }

}

function PortOut_port() {
    var data = {
        NTMsisdn: $('#dplUserProducts').val(),
        UserPortingDate: $("#PortOut_UserPortingDate").val(),
        CodeType: $("input[name='optCodeType']:checked").val().trim(),
        ReasonId: $('#PortOut_ReasonId').val()
    };
    $.ajax({
        type: "POST",
        url: "/Account/PortOut",
        data: data,
        beforeSend: function () {
            $('#BtnCnfrmPortOutSpinner').fadeIn();
            $('#BtnNoCnfrmPortOut,#BtnYesCnfrmPortOut').attr('disabled', true);
        },
        success: function (result) {
            if (result.statusCode == 1 && result.data != null) {
                if (result.data.errorCode == 0) {
                    $('#ConfirmPortOutModal').modal('hide');
                    toastr.success(result.data.message, 'Success', { positionClass: 'toast-top-center', timeOut: "2000" });
                    GetUserPortDetails_port($('#dplUserProducts').val());
                }
                else {
                    toastr.error(result.data.message, 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
                }
            }
            else if (result.statusCode == 0) {
                var html = '';
                $(result.data, function (key, val) {
                    html += val.errorMessage + "<br/>";
                });
                toastr.error(html, 'Validation Errors', { positionClass: 'toast-top-center', timeOut: "2000" });
            }
            else {
                toastr.error('Something went wrong on server.', 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
            }
        },
        error: function () {
            toastr.error('Something went wrong on server.', 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
        },
        complete: function () {
            $('#BtnCnfrmPortOutSpinner').fadeOut();
            $('#BtnNoCnfrmPortOut,#BtnYesCnfrmPortOut').attr('disabled', false);
        }
    });

}

function CancelRequest_port() {

    $.ajax({
        type: "POST",
        url: "/Account/CancelPortingRequest",
        data: { RequestID: $('#hdnPortingRequestID').val() },
        beforeSend: function () {
            $('#BtnCancelSpinner').fadeIn();
            $('#BtnNoCancel,#BtnYesCancel').attr('disabled', true);
        },
        success: function (result) {
            if (result != null) {
                if (result.errorCode == 0) {
                    $('#ConfirmCancelModal').modal('hide');
                    toastr.success(result.message, 'Scuccess', { positionClass: 'toast-top-center', timeOut: "2000" });

                    GetUserPortDetails_port($('#dplUserProducts').val());
                }
                else {
                    toastr.error(result.message, 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
                }
            }
            else {
                toastr.error(result.message, 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
            }
        },
        error: function () {
            toastr.error('Something went wrong on server.', 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
        },
        complete: function () {
            $('#BtnCancelSpinner').fadeOut();
            $('#BtnNoCancel,#BtnYesCancel').attr('disabled', false);
        }
    });

}

function ConfirmCancel_port(id) {

    $('#hdnPortingRequestID').val(id);
    $('#ConfirmCancelModal').modal('show');

}

function ShowConfirmPortOutModal_port() {

    if (!$("#PortOutForm").valid()) {
        return;
    }
    $.ajax({
        type: "POST",
        url: "/Account/GetSwitchingInfo",
        data: { Number: $('#dplUserProducts').val() },
        beforeSend: function () {
            $('#BtnPortOutSpinner').fadeIn();
            $('#BtnCancelPortOut,#BtnPortOut').attr('disabled', true);
        },
        success: function (result) {
            if (result != null) {
                if (result.payload != null) {
                    $('#txtSwtingInfoBalance').text("£" + result.payload.balance);
                    $('#PortOutModal').modal('hide');
                    $('#ConfirmPortOutModal').modal('show');
                }
                else {
                    toastr.error('Something went wrong on server.', 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
                }
            }
            else {
                toastr.error('Something went wrong on server.', 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
            }
        },
        error: function () {
            toastr.error('Something went wrong on server.', 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
        },
        complete: function () {
            $('#BtnPortOutSpinner').fadeOut();
            $('#BtnCancelPortOut,#BtnPortOut').attr('disabled', false);
        }
    });
}

function GetSwitchingInfo_port() {
    $.ajax({
        type: "POST",
        url: "/Account/GetSwitchingInfo",
        data: { Number: $('#dplUserProducts').val() },
        beforeSend: function () {
            $('#BtnSwitchinginfo').attr('disabled', true);
            $('.loading-bar').show();
        },
        success: function (result) {
            if (result != null) {
                if (result.payload != null) {
                    $('#txtBalance').text("£" + result.payload.balance);
                }
                else {
                    toastr.error('Unable to load switching informtaion', 'Switching Information', { positionClass: 'toast-top-center', timeOut: "2000" });
                }
            }
            else {
                toastr.error('Unable to load switching informtaion', 'Switching Information', { positionClass: 'toast-top-center', timeOut: "2000" })
            }
        },
        error: function () {
            toastr.error('Something went wrong on server.', 'Error', { positionClass: 'toast-top-center', timeOut: "2000" });
        },
        complete: function () {
            $('#BtnSwitchinginfo').attr('disabled', false);
            $('.loading-bar').hide();
        }
    });
}