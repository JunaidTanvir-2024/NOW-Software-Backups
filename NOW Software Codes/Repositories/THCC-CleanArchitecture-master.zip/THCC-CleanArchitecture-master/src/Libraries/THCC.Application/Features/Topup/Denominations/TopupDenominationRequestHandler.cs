﻿using THCC.Application.Interfaces.Services;
using THCC.Application.Settings;

namespace THCC.Application.Features.Topup.Denominations
{
    public class TopupDenominationRequestHandler
            : IRequestHandler<TopupDenominationRequest, TopupSettings>
    {
        private readonly TopupSettings _topupSettings;
        private readonly IDiscountService _discountservice;

        public TopupDenominationRequestHandler(
                  IDiscountService discountservice,
                  IOptions<TopupSettings> topupSettings)
        {
            _topupSettings = topupSettings.Value;
            _discountservice = discountservice;
        }

        Task<TopupSettings> IRequestHandler<TopupDenominationRequest, TopupSettings>.Handle(
                                TopupDenominationRequest request, CancellationToken cancellationToken)
        {
            var response = _topupSettings;
            response.Amounts.ForEach(amount =>
            {
                amount.Discount = _discountservice.GetDiscount(amount.Amount);
                //amount.Discountpercent = amount.Amount >= 16 ? 20 : 10;
                amount.Discountpercent = 10;

            });
            return Task.FromResult<TopupSettings>(response);
        }
    }
}
