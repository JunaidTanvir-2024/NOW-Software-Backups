﻿namespace Application.Features.Account;
public class UserInfo
{
    public long Id { get; set; }
    public string Email { get; set; } = default!;
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public string Image { get; set; } = default!;
    public bool MailSubscription { get; set; }
    public int? SocialSignUpType { get; set; }
    public bool HasPassword { get; set; }
}
