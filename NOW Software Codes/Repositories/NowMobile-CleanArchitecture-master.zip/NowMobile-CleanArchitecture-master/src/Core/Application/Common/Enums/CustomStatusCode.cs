﻿namespace Application.Common.Enums;

public static class CustomStatusCode
{
    public const int BadRequest = 100400;
    public const int Forbidden = 100403;
    public const int NotFound = 100404;
    public const int Unauthorized = 100401;
    public const int InternalServerError = 100500;

    public const int AccountNotRegistered = 100100;
    public const int InvalidCredentials = 100101;
    public const int InvalidOtp = 100102;
    public const int DeviceNotVerified = 100103;
    public const int EmailNotVerified = 100104;
    public const int EmailAlreadyRegistered = 100105;
    public const int MsisdnAlreadyRegistered = 100106;
    public const int InvalidMsisdn = 100107;
    public const int InvalidAuthToken = 100108;
    public const int AddressNotFound = 100109;

    public const int EmailMonthlyLimitExceed = 100110;
    public const int EmailYearlyLimitExceed = 100111;
    public const int AddressYearlyLimitExceed = 100112;
    public const int AddressMonthlyLimitExceed = 100113;
    public const int DailyLimitExceeded = 100114;
    public const int IpAddressLimitExceeded = 100115;

    public const int InvalidBundle = 100116;
    public const int InvalidProductReference = 100117;
    public const int SimReplacementLimitExceeded = 100118;

    public const int MakeDefaultCardSuccess = 100119;
    public const int RemoveCardSuccess = 100120;
    public const int SetAutoTopupSuccess = 100121;

    public const int BundlePurchaseFailed = 100122;
    public const int BundlePurchaseLimitExceeded = 100123;

    public const int InsufficientBalance = 100124;

    public const int DailyPaymentLimitExceeded = 100125;
    public const int PaymentProviderError = 100126;
    public const int PaymentServiceError = 100127;

    public const int Need3dSecure = 100128;

    public const int CreditSimOrderNotExists = 100129;
    public const int CreditSimPaymentAlreadyExists = 100130;
    public const int CreditSimMsisdnNotAvailable = 100131;

    public const int InvalidPaymentCard = 100132;
    public const int PaypalPaymentCancelled = 100133;

    public const int FileUploadedError = 100134;

    //public const int PortingRequestAlreadyInProgress = 100134;
    public const int PortingRequestFailed = 100135;
    public const int OtpIsNotCreated = 100136;
    //public const int UnableToGetSwitchingInfo = 100136;
    
    
    public const int SocialLoginFailed = 100138;
    public const int SocialEmailMissing = 100137;
    public const int InvalidEmail = 100138;
    public const int UpdatePasswordSuccess =  100139;
}

public static class CustomStatusKey
{
    public const string BadRequest = "We ran into an error - try again";
    public const string Unauthorized = "You're not authorized - please try again";
    public const string NotFound = "We couldn’t find it. Try searching for something else.";
    public const string InternalServerError = "Our server ran into an error - let's try again.";
    public const string Forbidden = "Oops, you're not authorized to access this.";
    public const string Success = "Success";
    public const string UpdatePasswordSuccess = "Password updated successfully.";

    public const string AccountNotRegistered = "Account doesn't exist, please try again.";
    public const string InvalidCredentials = "Sorry, you have entered wrong credentials. Please try again.";
    public const string InvalidOtp = "Sorry, you have entered an incorrect PIN. Please try again.";
    public const string DeviceNotVerified = "Device not verified";
    public const string EmailNotVerified = "Email not verified";
    public const string EmailAlreadyRegistered = "This email is already registered with us. Please log in.";
    public const string MsisdnAlreadyRegistered = "This number is already registered with us. Please log in.";
    public const string InvalidMsisdn = "Please enter a valid Now Mobile number.";
    public const string InvalidAuthToken = "Invalid authentication token";
    public const string AddressNotFound = "We couldn't find any addresses for your postal code.";

    public const string EmailMonthlyLimitExceed = "You have reached the maximum number of SIM orders for this month. Please contact support for assistance.";
    public const string EmailYearlyLimitExceed = "You have reached the maximum number of SIM orders for this account. Please contact support for assistance.";
    public const string AddressYearlyLimitExceed = "You have reached the maximum number of SIM orders for this account. Please contact support for assistance.";
    public const string AddressMonthlyLimitExceed = "You have reached the maximum number of SIM orders for this month. Please contact support for assistance.";
    public const string DailyLimitExceeded = "You have reached the maximum number of SIM orders for this month. Please contact support for assistance.";
    public const string IpAddressLimitExceeded = "You have reached the maximum number of SIM orders for this account. Please contact support for assistance.";

    public const string InvalidBundle = "Invalid Bundle";
    public const string SimReplacementLimitExceeded = "You have already ordered a replacement SIM. Please contact support for assistance.";
    public const string InvalidProductReference = "Invalid product refernce";

    public const string MakeDefaultCardError = "Your changes were not saved. Please try again.";
    public const string MakeDefaultCardSuccess = "Your changes were saved successfully.";
    public const string RemoveCardError = "Sorry, we were unable to remove your card. Please try again or contact support for assistance.";
    public const string RemoveCardAutoRenewalOnError = "Sorry, you have plan(s) with auto renew enabled. Please contact support for assistance.";

    public const string RemoveCardSuccess = "Your payment method was removed successfully.";

    public const string GetAutoTopupFailure = "We couldn't fetch your details, please try again.";
    public const string SetAutoTopupFailure = "We couldn't save your details, please try again.";
    public const string SetAutoTopupSuccess = "Auto top-up {status} successfully";

    public const string AddProductSuccess = "New SIM added successfully";

    public const string BundlePurchaseFailed = "Plan purchase unsuccessful. Please try again.";
    public const string BundlePurchaseLimitExceeded = "Sorry, you have reached the maximum number of plan activations. Please contact support for assistance.";

    public const string InsufficientBalance = "Sorry, you have insufficient balance.";

    public const string DailyPaymentLimitExceeded = "Sorry, you have already hit your maximum daily purchase limit. Please contact support for assistance.";
    public const string PaymentServiceError = "Payment not authorized. Please try again or contact support for assistance.";

    public const string Need3dSecure = "Payment required 3d secure";

    public const string CreditSimOrderNotExists = "Credit SIM order does not exist";
    public const string CreditSimPaymentAlreadyExists = "Credit SIM payment already exists";
    public const string CreditSimMsisdnNotAvailable = "Credit SIM MSISDN not available";
    public const string PortingRequestFailed = "Your porting request failed. Please try again or contact support for assistance.";
    public const string PortingRequestAlreadyInProgress = "Your porting request is already in process. Please wait.";
    public const string UnableToGetSwitchingInfo = "Sorry, we were unable to fetch your details. Please try again or contact support for assistance.";
    public const string PaypalPaymentCancelled = "Your PayPal payment was cancelled. Please try again.";
    public const string InvalidPaymentCard = "Invalid payment card";

    public const string InvalidFileExtension = "Unsupported file type. Please upload a {extensions} file.";
    public const string InvalidFileSize = "File size is too large. Maximum file size is {size}.";
    public const string UnableToCreateDirectory = "Sorry, we were unable to process your changes. Please try again.";
    public const string UnableToSaveFile = "We were unable to save your file. Please try again later.";
    public const string OtpIsNotCreated = "You have tried too many times. Please try again later.";


    public const string SocialLoginFailed = "Unable to fetch user from social app.";
    public const string SocialEmailMissing = "Email not found.";
    public const string InvalidEmail = "Invalid email. Please try again with valid email.";
}
public static class CustomStatusExtensions
{
    public static string? GetStatusNameByStatusCode(this int value)
    {
        var existingProperties = typeof(CustomStatusCode).GetFields(BindingFlags.Static | BindingFlags.Public).ToList();
        var statusName = string.Empty;
        if (existingProperties.Count > 0)
        {
            foreach (var item in existingProperties)
            {
                if(Convert.ToInt32(item.GetValue(item.Name)) == value)
                {
                    statusName = Convert.ToString(item.Name);
                    break;
                }
            }
        }
        return statusName;
    }
    public static int GetStatusCodeByStatusName(this string value)
    {
        var existingProperty = typeof(CustomStatusCode).GetField(value);
        var statusCode = 0;
        if (existingProperty != null)
        {
            statusCode = Convert.ToInt32(existingProperty.GetValue(existingProperty.Name));
        }
        return statusCode;
    }
    public static string? GetStatusNameByStatusCode<T>(this Result<T> value)
    {
        var existingProperties = typeof(CustomStatusCode).GetFields(BindingFlags.Static | BindingFlags.Public).ToList();
        if (existingProperties.Count > 0)
        {
            foreach (var item in existingProperties)
            {
                return Convert.ToInt32(item.GetValue(item.Name)) == value.ErrorCode ? Convert.ToString(item.Name) : string.Empty;
            }
        }
        return string.Empty;
    }
}