using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Country;

public abstract class CountryList
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper> { }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query> { }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public required string Name { get; set; }
        public required string IsoCode3 { get; set; }
        public ushort CallingCode { get; set; }
        public required string NumericCode { get; set; }
        public required string FlagEmoji { get; set; }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var country = await _unitOfWork.CountryRepository.GetCountries();
            if (country is not null)
            {
                return ResultWrapper.Success(country.Select(x => new Response()
                {
                    Id = x.Id,
                    Name = x.Name,
                    IsoCode3 = x.IsoCode3,
                    CallingCode = x.CallingCode,
                    NumericCode = x.NumericCode,
                    FlagEmoji = x.IsoCode2.IsoCodeToFlagEmoji()
                }));
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
        }
    }
    #endregion
}
