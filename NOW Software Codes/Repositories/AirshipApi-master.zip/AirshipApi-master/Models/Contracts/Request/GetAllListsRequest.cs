﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class GetAllListsRequest
    {
        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; }
    }
}
