﻿using Models.Configurations;
using Models.Contracts;
using Models.Enums;
using RestSharp;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IApiCall
    {
        Task<IRestResponse> Get(string Uri, AuthType authType, string authHeader, string contentType = "application/json", string acceptHeader = "application/vnd.urbanairship+json;version=3", Dictionary<string, string> otherHeaders = null);
        Task<IRestResponse> Post(string Uri, string requestJson, AuthType authType, string authHeader, string contentType = "application/json", string acceptHeader = "application/vnd.urbanairship+json;version=3", Dictionary<string, string> otherHeaders = null);
        Task<IRestResponse> Put(string Uri, string requestJson, AuthType authType, string authHeader, string contentType = "application/json", string acceptHeader = "application/vnd.urbanairship+json;version=3", Dictionary<string, string> otherHeaders = null);
        Task<HttpResponseMessage> PostUrlEncoded(string Uri, AuthType authTokenType, string authToken, List<KeyValuePair<string, string>> postDataModel);
        GenericResult<Credentials> GetCredentials(string productCode);
    }
}
