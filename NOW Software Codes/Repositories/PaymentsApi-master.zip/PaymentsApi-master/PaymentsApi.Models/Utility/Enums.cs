﻿namespace PaymentsApi.Models.Utility
{
    public enum Pay360TransactionStatuses
    {
        SUCCESS = 1,
        FAILED = 2,
        ERROR = 3,
        PENDING = 4
    }

    public enum Pay360TransactionTypes
    {
        PREAUTH = 1,
        PAYMENT = 2,
        PAYOUT = 3,
        REFUND = 4,
        CAPTURE = 5,
        CANCEL = 6,
        REPEAT = 7,
        CASH_ISSUE = 8,
        CASH_PAYMENT = 9,
        PREAUTH_VOID = 10
    }

    public enum PaymentMethods
    {
        Card = 1,
        Paypal = 2
    }

    public enum Pay360SummaryTransactionStatuses
    {
        PREAUTH = 1,
        SINGLEPAYMENT = 2,
        CAPTURE = 3,
        FULFILMENT = 4,
        CANCEL = 5,
        PARTIALREFUND = 6,
        FULLREFUND = 7,
        CAPTUREFAILED = 8,
        FULFILMENTFAILED = 9,
        CANCELFAILED = 10,
        RESUME3DFAILED = 11,
        _3DSAUTHENTICATIONFAILED = 12,
        RESUMETIMEOUT = 13
    }

    public enum Pay360SummaryTransactionTypes
    {
        NEWCUSTOMER = 1,
        EXISTINGCUSTOMER_DEFAULTCARD = 2,
        EXISTINGCUSTOMER_NEWCARD = 3,
        PAYMENTTOKEN = 4,
        REPEAT = 5,
        CAPTURE = 6
    }
}
