﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Service.PaypalApiContracts
{
    public class SuccessReturnPayPalViewModel
    {
        public string paymentId { get; set; }
        public string token { get; set; }
        public string PayerID { get; set; }
        public string reference { get; set; }
        public string amount { get; set; }
        public int userId { get; set; }
        public string currency { get; set; }
    }
}
