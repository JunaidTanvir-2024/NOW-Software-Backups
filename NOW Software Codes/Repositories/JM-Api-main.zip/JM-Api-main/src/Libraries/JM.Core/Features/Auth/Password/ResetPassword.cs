using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Dtos.Auth;
using JM.Core.Utilities.Interfaces.Database;
using JM.Core.Utilities.Interfaces.Services;

using Mediator;

using RW;

namespace JM.Core.Features.Auth.Password;

public abstract class ResetPassword
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string ConfirmPassword { get; set; } = string.Empty;
        public string OtpCode { get; set; } = string.Empty;
    }

    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Email).NotNull().NotEmpty();
            RuleFor(x => x.Password).NotNull().NotEmpty();
            RuleFor(x => x.OtpCode).NotNull().NotNull().NotEmpty();
            RuleFor(x => x.ConfirmPassword).Equal(x => x.Password).WithMessage("Passwords should match");
        }
    }

    #endregion

    #region Response
    public sealed record Response { }

    #endregion

    #region Handler
    internal sealed class Handler(IIdentityService authService, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IIdentityService _authService = authService;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var user = await _unitOfWork.UserRepository.GetUser(x => x.NormalizedEmail!.Equals(query.Email.ToUpperInvariant()));

            if (user is null)
            {
                return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
            }

            var changePasswordResponse = await _authService.ResetPassword(new ResetPasswordDto.Request()
            {
                Email = query.Email,
                Password = query.Password
            });
            if (changePasswordResponse.IsSuccess)
            {
                return ResultWrapper.Success(AppConstant.StatusKey.ChangePassword, AppConstant.StatusCode.Success);
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.InternalServerError, AppConstant.StatusCode.InternalServerError);
        }
    }
    #endregion
}
