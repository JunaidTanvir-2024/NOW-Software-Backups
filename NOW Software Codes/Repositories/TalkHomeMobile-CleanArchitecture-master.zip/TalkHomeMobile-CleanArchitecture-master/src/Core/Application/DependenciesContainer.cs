﻿using Application.Common.Extensions.DependencyResolver;
using Application.Common.Interfaces.Infrastructure.Services;
using Application.Common.Settings;
using Mapster;
using Microsoft.Extensions.Configuration;

namespace Application;

public static class DependenciesContainer
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration config)
    {
        #region Apply Auto Register Services Scanner

        services.AutoDependencyResolverServices();

        #endregion
        
        #region Mapster Configurations

        var mapperConfiguration = TypeAdapterConfig.GlobalSettings;
        mapperConfiguration.Scan(Assembly.GetExecutingAssembly());
        services.AddSingleton(mapperConfiguration);
        services.AddScoped<IMapper, ServiceMapper>();

        #endregion

        #region Fluent Validation and MediatR Registration

        services

            .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly())
            .AddMediatR(Assembly.GetExecutingAssembly());

        #endregion

        #region Get Section Settings

        services.Configure<LoginSettings>(config.GetSection(LoginSettings.SectionName));
        services.Configure<PostCodeSettings>(config.GetSection(PostCodeSettings.SectionName));
        services.Configure<MailSettings>(config.GetSection(MailSettings.SectionName));
        services.Configure<SmsSettings>(config.GetSection(SmsSettings.SectionName));
        services.Configure<OtpSettings>(config.GetSection(OtpSettings.SectionName));
        services.Configure<BasicAuthSetting>(config.GetSection(BasicAuthSetting.SectionName));
        services.Configure<SimOrderIpSettings>(config.GetSection(SimOrderIpSettings.SectionName));
        services.Configure<AddressSettings>(config.GetSection(AddressSettings.SectionName));
        services.Configure<DeleteAccountSettings>(config.GetSection(DeleteAccountSettings.SectionName));
        services.Configure<TopupSettings>(config.GetSection(TopupSettings.SectionName));
        services.Configure<WebLinksSettings>(config.GetSection(WebLinksSettings.SectionName));
        services.Configure<ProfileSettings>(config.GetSection(ProfileSettings.SectionName));
        services.Configure<RatingSettings>(config.GetSection(RatingSettings.SectionName));
        services.Configure<DiscountSettings>(config.GetSection(DiscountSettings.SectionName));
        services.Configure<CallBackSettings>(config.GetSection(CallBackSettings.SectionName));
        services.Configure<ReplacementSimSettings>(config.GetSection(ReplacementSimSettings.SectionName));
        services.Configure<Pay360Setting>(config.GetSection(Pay360Setting.SectionName));
        services.Configure<PayPalSetting>(config.GetSection(PayPalSetting.SectionName));
        services.Configure<PortingSettings>(config.GetSection(PortingSettings.SectionName));
        services.Configure<CreditSimSettings>(config.GetSection(CreditSimSettings.SectionName));
        services.Configure<FileUploadSettings>(config.GetSection(FileUploadSettings.SectionName));
        services.Configure<AirShipSettings>(config.GetSection(AirShipSettings.SectionName));
        services.Configure<FaceBookSettings>(config.GetSection(FaceBookSettings.SectionName));
        services.Configure<AppsFlyerSettings>(config.GetSection(AppsFlyerSettings.SectionName));
        services.Configure<GoogleAnalytics4Settings>(config.GetSection(GoogleAnalytics4Settings.SectionName));
        services.Configure<BundleLimitSettings>(config.GetSection(BundleLimitSettings.SectionName));
        services.Configure<AppleReceiptVerificationSettings>(config.GetSection(AppleReceiptVerificationSettings.SectionName));
        services.Configure<WebtoAppSettings>(config: config.GetSection(WebtoAppSettings.SectionName));
        services.Configure<EmailValidationServiceSettings>(config.GetSection(EmailValidationServiceSettings.SectionName));
        services.Configure<GoogleRecaptchaSettings>(config: config.GetSection(GoogleRecaptchaSettings.SectionName));
        services.Configure<BundlesSettings>(config: config.GetSection(BundlesSettings.SectionName));
        services.Configure<CancelBundlesSettings>(config: config.GetSection(CancelBundlesSettings.SectionName));

        #endregion

        return services;
    }
}
