﻿using Application.Common.Caching;
using Application.Common.Interfaces;
using Application.Common.Interfaces.Payment;
using Application.Common.Mailing;
using Application.Common.Models;
using Application.Common.Models.Airship;
using Application.Common.Settings;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Bundle.Model;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.InAppReceipt;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;
using Domain.Aggregate;
using Microsoft.CodeAnalysis;
using Microsoft.Extensions.Options;
using Microsoft.Web.Administration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RazorEngineCore;
using Serilog;
using System.Globalization;
using System.Net.Http;
using System.Text;
using System.Threading;

namespace Application.Features.Payment;
public class PaymentService : IPaymentService
{
    #region Fields

    private readonly IStringLocalizer<PaymentService> _localizer;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly AppleReceiptVerificationSettings _appleReceiptVerificationSettings;
    private readonly ICardService _cardService;
    private readonly ICommonService _commonService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IUserService _userService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly IBundleService _bundleService;
    private readonly IDiscountService _discountService;
    private readonly IAutoTopupService _autoTopupService;
    private readonly IPayPalService _payPalService;
    private readonly IMailService _mailService;
    private readonly ITopupRepository _topupRepo;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;
    private readonly IAirshipService _airshipService;
    private readonly ILogger _logger;
    private readonly PayPalSetting _payPalSetting;
    private readonly Pay360Setting _pay360Setting;
    private readonly CallBackSettings _callbackSettings;

    #endregion

    #region Ctor

    public PaymentService(
        IStringLocalizer<PaymentService> localizer,
        IHttpClientFactory httpClientFactory,
        IOptions<AppleReceiptVerificationSettings> appleReceiptVerificationSettings,
        ICardService cardService,
        ICommonService commonService,
        IUnitOfWork unitOfWork,
        IUserService userService,
        ICurrentUser currentUser,
        IMapper mapper,
        IBundleService bundleService,
        IDiscountService discountService,
        IAutoTopupService autoTopupService,
        IPayPalService payPalService,
        IOptions<CallBackSettings> callbackSettings,
        IOptions<Pay360Setting> pay360Setting,
        IOptions<PayPalSetting> payPalSetting,
        IMailService mailService,
        ITopupRepository topupRepo,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService,
        IAirshipService airshipService,
        ILogger logger)
    {
        _localizer = localizer;
        _httpClientFactory = httpClientFactory;
        _appleReceiptVerificationSettings = appleReceiptVerificationSettings.Value;
        _cardService = cardService;
        _commonService = commonService;
        _unitOfWork = unitOfWork;
        _userService = userService;
        _currentUser = currentUser;
        _mapper = mapper;
        _bundleService = bundleService;
        _discountService = discountService;
        _autoTopupService = autoTopupService;
        _payPalService = payPalService;
        _payPalSetting = payPalSetting.Value;
        _pay360Setting = pay360Setting.Value;
        _callbackSettings = callbackSettings.Value;
        _mailService = mailService;
        _topupRepo = topupRepo;
        _cacheService = cacheService;
        _cacheKeyService = cacheKeyService;
        _airshipService = airshipService;
        _logger = logger;
    }

    #endregion

    #region Methods

    #region Public

    #region Card

    public async Task<Result<CardResponse>> HandleCardPaymentRequest(
        PaymentNewCardInfo paymentNewCardInfo,
        PaymentExistingCardInfo paymentExistingCardInfo,
        PaymentAddressInfo paymentAddressInfo,
        PaymentTopupInfo topupInfo,
        PaymentBundleInfo bundleInfo,
        PaymentCreditSimInfo creditSimInfo,
        string msisdn,
        string email,
        string ipAddress,
        string cardMaskedPan,
        string cardScheme,
        bool isAuthorizeOnly = default)
    {
        (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();

        if (paymentNewCardInfo != null)
        {
            if (topupInfo != null && topupInfo.AutoTopupInfo != null && topupInfo.AutoTopupInfo.Status)
            {
                paymentNewCardInfo.SaveCard = true;
            }
            if (bundleInfo != null && bundleInfo.IsRenewable)
            {
                paymentNewCardInfo.SaveCard = true;
            }
        }
        if (!string.IsNullOrEmpty(msisdn))
        {
            msisdn = _commonService.FormatMsisdn(msisdn);
        }

        var checkoutType = GetCheckoutType(creditSimInfo, topupInfo, bundleInfo);

        var cardPaymentRequet = new CardPaymentRequest()
        {
            Address = paymentAddressInfo,
            IpAddress = ipAddress,
            CheckoutType = checkoutType,
            PaymentNewCardInfo = paymentNewCardInfo,
            PaymentExistingCardInfo = paymentExistingCardInfo,
            IsRecurring = topupInfo?.AutoTopupInfo?.Status == true || bundleInfo?.IsRenewable == true
        };
        var order = new Order();
        var orderhistoryBasket = new List<OrderItem>();
        var fulfillmentBasket = new List<FulfillmentItem>();
        OrderBundleInfo orderBundleInfo = new OrderBundleInfo();

        //Handle bundle and topup
        if (checkoutType == CheckOutType.TopUp
            || checkoutType == CheckOutType.Bundle
            || checkoutType == CheckOutType.TopupBundle)
        {
            cardPaymentRequet.Msisdn = msisdn;

            //Handle Email
            if (IsAppRequest)
            {
                if (!await _userService.IsUserMsisdn(cardPaymentRequet.Msisdn))
                {
                    return Result<CardResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
                }
                cardPaymentRequet.Email = _currentUser.GetUserEmail()!;
            }
            else
            {
                cardPaymentRequet.Email = email;
            }

            //Is valid THM msisdn
            var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(msisdn);
            if (msisdnDetails == null)
            {
                return Result<CardResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            }

            //Handle bundle case
            if (checkoutType == CheckOutType.Bundle
                || checkoutType == CheckOutType.TopupBundle)
            {
                var bundleData = await _unitOfWork.BundleRepo.GetBundleById(new BundleByIdRequest() { Id = bundleInfo!.BundleId.ToString() });
                if (bundleData == null)
                {
                    return Result<CardResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
                }

                //Handle Bundle
                BundleInfo? bundle = _mapper.Map<BundleInfo>(bundleData);

                if (bundle.Type == (int) BundleType.Rolling)
                {
                    bundleInfo.IsRenewable = true;
                }

                orderBundleInfo = _mapper.Map<OrderBundleInfo>(bundleInfo);

                orderBundleInfo.GoodyBagColorCode = bundleData.GoodyBagColorCode!;
                if (!isAuthorizeOnly)
                {
                    //Bundle purcahse validation
                    (int errorCode, string errorMessge) = await _bundleService.BundlePurchaseValidation(msisdnDetails.AccountId!, bundle.UuId!);
                    if (errorCode > 0)
                    {

                        #region Order History Record

                        order.OrderBaskets = orderhistoryBasket;
                        order.Email = cardPaymentRequet.Email;
                        order.TransactionId = null!;
                        order.Msisdn = cardPaymentRequet.Msisdn;
                        order.PaymentMethod = (int) PaymentMethod.Card;
                        order.OrderData = JsonConvert.SerializeObject(new OrderData()
                        {
                            IsAppRequest = IsAppRequest,
                            CheckoutType = (int) checkoutType,
                            AutoTopupInfo = topupInfo?.AutoTopupInfo,
                            BundleInfo = orderBundleInfo,
                            CreditSimOrderId = Convert.ToInt64(order.CreditSimOrderId),
                            CardMaskedPan = paymentNewCardInfo == null
                                    ? cardMaskedPan : _commonService.GetCardMaskedPan(paymentNewCardInfo.CardNumber!),
                            CardScheme = paymentNewCardInfo == null
                                    ? cardScheme : _commonService.GetCardScheme(paymentNewCardInfo.CardNumber!),
                            Alias = creditSimInfo == null ? null! : creditSimInfo.Alias,
                            SaveCard = paymentNewCardInfo == null ? false : paymentNewCardInfo.SaveCard
                        });

                        int OrderID = await _unitOfWork.PaymentRepo.SaveOrderHistory(order, MediumType);

                        #endregion

                        return Result<CardResponse>.Failure(new CardResponse() { OrderId = OrderID }, errorMessge, CustomStatusCode.BundlePurchaseFailed);
                    }
                    fulfillmentBasket.Add(new FulfillmentItem()
                    {
                        Amount = (float) bundle.TotalPrice,
                        BundleRef = bundle.UuId!,
                        ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                        ProductRef = msisdn
                    });
                }
                cardPaymentRequet.BundleUuid = bundle.UuId;
                if (isAuthorizeOnly)
                {
                    cardPaymentRequet.BundleAmount = _pay360Setting.AuthorizeCardTestAmount;
                }
                else
                {
                    cardPaymentRequet.BundleAmount = (float) bundle.TotalPrice;
                }

                orderhistoryBasket.Add(new OrderItem
                {
                    Amount = isAuthorizeOnly ? _pay360Setting.AuthorizeCardTestAmount : (float) bundle.Price,
                    DiscountAmount = (float) bundle.Discount,
                    BundleRef = bundle.UuId!
                });

                order.BundleId = bundle.UuId;
                order.BundleName = bundle.DisplayName!;
                order.BundleCountryCode = bundle.CountryCode!;

            }

            //Handle topup case
            if (checkoutType == CheckOutType.TopUp
                || checkoutType == CheckOutType.TopupBundle)
            {

                //Get msisdn last topup date
                var lastTopup = await _unitOfWork.UserRepo.GetUserLastTopupInfo(msisdnDetails.AccountId!);

                var discount = _discountService.GetDiscount(lastTopup?.Date, topupInfo!.TopupAmount, checkoutType);

                orderhistoryBasket.Add(new OrderItem
                {
                    Amount = isAuthorizeOnly ? _pay360Setting.AuthorizeCardTestAmount : topupInfo.TopupAmount,
                    DiscountAmount = discount,
                    BundleRef = null!
                });

                //If just authorizing card so don't need to do fulfillment
                if (!isAuthorizeOnly)
                {
                    fulfillmentBasket.Add(new FulfillmentItem()
                    {
                        Amount = topupInfo.TopupAmount,
                        ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                        ProductRef = msisdn
                    });
                }
                cardPaymentRequet.TopupAmount = topupInfo.TopupAmount - discount;

                if (isAuthorizeOnly)
                {
                    cardPaymentRequet.TopupAmount = _pay360Setting.AuthorizeCardTestAmount;
                }
            }
        }

        //Handle credit sim
        if (checkoutType == CheckOutType.CreditSim)
        {
            var creditSimDetails = await _unitOfWork.SimRepo.GetCreditSimOrderDetails(creditSimInfo.OrderId);

            cardPaymentRequet.Email = creditSimDetails.First().Email!;
            cardPaymentRequet.Msisdn = null!;

            foreach (var item in creditSimDetails)
            {
                if (string.IsNullOrEmpty(item.BundleId))
                {
                    var topupAmount = Convert.ToSingle(item.Amount);

                    var discount = _discountService.GetDiscount(null, topupAmount, checkoutType);

                    orderhistoryBasket.Add(new OrderItem
                    {
                        Amount = topupAmount,
                        DiscountAmount = discount,
                        BundleRef = null!
                    });

                    order.TopupAmount = topupAmount.ToString();

                    fulfillmentBasket.Add(new FulfillmentItem()
                    {
                        Amount = topupAmount,
                        ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                        ProductRef = msisdn
                    });

                    cardPaymentRequet.TopupAmount = topupAmount - discount;
                }
                else
                {
                    cardPaymentRequet.BundleUuid = item.BundleId;

                    var bundleData = await _unitOfWork.BundleRepo.GetBundleById(cardPaymentRequet.BundleUuid!);
                    var bundle = _mapper.Map<BundleInfo>(bundleData);

                    if (bundle.Type == (int) BundleType.Rolling)
                    {
                        if (bundleInfo == null)
                        {
                            bundleInfo = new PaymentBundleInfo()
                            {
                                BundleId = 0,
                                IsRenewable = true
                            };
                        }
                        else
                        {
                            bundleInfo.IsRenewable = true;
                        }
                    }

                    cardPaymentRequet.BundleAmount = (float) bundle.TotalPrice;

                    orderhistoryBasket.Add(new OrderItem
                    {
                        Amount = (float) bundle.Price,
                        DiscountAmount = (float) bundle.Discount,
                        BundleRef = bundle.UuId!
                    });

                    order.BundleId = bundle.UuId;
                    order.BundleName = bundle.DisplayName!;
                    order.BundleCountryCode = bundle.CountryCode!;


                    orderBundleInfo = _mapper.Map<OrderBundleInfo>(bundleInfo);

                    // orderBundleInfo.GoodyBagColorCode = bundle.GoodyBagColorCode!;

                    fulfillmentBasket.Add(new FulfillmentItem()
                    {
                        Amount = (float) bundle.TotalPrice,
                        ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                        ProductRef = msisdn,
                        BundleRef = bundle.UuId!
                    });
                }
            }

            order.CreditSimOrderId = creditSimInfo.OrderId.ToString();
        }

        #region Order History Record

        order.OrderBaskets = orderhistoryBasket;
        order.Email = cardPaymentRequet.Email;
        order.TransactionId = null!;
        order.Msisdn = cardPaymentRequet.Msisdn;
        order.PaymentMethod = (int) PaymentMethod.Card;
        order.OrderData = JsonConvert.SerializeObject(new OrderData()
        {
            IsAppRequest = IsAppRequest,
            CheckoutType = (int) checkoutType,
            AutoTopupInfo = topupInfo?.AutoTopupInfo,
            BundleInfo = orderBundleInfo,
            CreditSimOrderId = Convert.ToInt64(order.CreditSimOrderId),
            CardMaskedPan = paymentNewCardInfo == null
                    ? cardMaskedPan : _commonService.GetCardMaskedPan(paymentNewCardInfo.CardNumber!),
            CardScheme = paymentNewCardInfo == null
                    ? cardScheme : _commonService.GetCardScheme(paymentNewCardInfo.CardNumber!),
            Alias = creditSimInfo == null ? null! : creditSimInfo.Alias,
            SaveCard = paymentNewCardInfo == null ? false : paymentNewCardInfo.SaveCard
        });

        int orderID = await _unitOfWork.PaymentRepo.SaveOrderHistory(order, MediumType);

        #endregion
        //Override pay360 basket validation for authorize only payments
        cardPaymentRequet.OverrideValidation = isAuthorizeOnly;
        var paymentResponse = await _cardService.CardPayment(cardPaymentRequet);

        #region Fulfilment Record
        if (!isAuthorizeOnly)
        {
            await _unitOfWork.PaymentRepo.SaveFulfillmentRecord(
                fulfillmentBasket,
                email,
                paymentResponse != null && paymentResponse.IsSuccess ? paymentResponse.TransactionId! : null!,
                msisdn);
        }
        #endregion

        return await HandleCardPaymentResponse(orderID, paymentResponse!, isAuthorizeOnly, topupInfo == default ? false : topupInfo.IsFastTopup, IsAppRequest);
    }

    public async Task<Result<CardResponse>> HandleCardPaymentResume3dRequest(
        string transactionId,
        int orderId,
        bool IsAuthorizeOnly,
        bool IsFastTopup = false,
        bool IsAppRequest = false)
    {
        var response = await _cardService.Resume3dCardPayment(transactionId);
        return await HandleCardPaymentResponse(orderId, response, IsAuthorizeOnly, IsFastTopup, IsAppRequest);
    }

    #endregion

    #region Paypal

    public async Task<Result<PaypalResponse>> HandlePaypalPaymentRequest(
        PaymentTopupInfo topupInfo,
        PaymentBundleInfo bundleInfo,
        PaymentCreditSimInfo creditSimInfo,
        string msisdn,
        string email,
        string ipAddress,
        bool isSubscriptionRequest = default,
        bool subscriptionWithInitialSale = default)
    {
        (bool isAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();
        if (!string.IsNullOrEmpty(msisdn))
        {
            msisdn = _commonService.FormatMsisdn(msisdn);
        }

        var checkoutType = GetCheckoutType(creditSimInfo, topupInfo, bundleInfo);

        var paypalPaymentRequest = new PaypalPaymentRequest()
        {
            IpAddress = ipAddress,
            CheckoutType = checkoutType,
            IsAppRequest = isAppRequest,
            IsFastTopup = topupInfo == default ? false : topupInfo.IsFastTopup,
        };

        var order = new Order();
        OrderBundleInfo orderBundleInfo = new OrderBundleInfo();
        var orderhistoryBasket = new List<OrderItem>();
        var fulfillmentBasket = new List<FulfillmentItem>();

        //Handle bundle and topup
        if (checkoutType == CheckOutType.TopUp
            || checkoutType == CheckOutType.Bundle
            || checkoutType == CheckOutType.TopupBundle)
        {
            paypalPaymentRequest.Msisdn = msisdn;

            //Handle Email
            if (isAppRequest)
            {
                if (!await _userService.IsUserMsisdn(paypalPaymentRequest.Msisdn))
                {
                    return Result<PaypalResponse>.Failure(
                        _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
                }
                paypalPaymentRequest.Email = _currentUser.GetUserEmail()!;
            }
            else
            {
                paypalPaymentRequest.Email = email;
            }

            //Is valid THM msisdn
            var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(msisdn);
            //if (msisdnDetails == null)
            //{
            //    return Result<PaypalResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            //}

            //Handle bundle case
            if (checkoutType == CheckOutType.Bundle || checkoutType == CheckOutType.TopupBundle)
            {
                var bundleData = await _unitOfWork.BundleRepo.GetBundleById(new BundleByIdRequest() { Id = bundleInfo!.BundleId.ToString() });
                if (bundleData == null)
                {
                    return Result<PaypalResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
                }

                //Handle Bundle
                BundleInfo? bundle = _mapper.Map<BundleInfo>(bundleData);
                if (!isSubscriptionRequest || (isSubscriptionRequest && subscriptionWithInitialSale))
                {
                    //Bundle purcahse validation
                    (int errorCode, string errorMessge) = await _bundleService.BundlePurchaseValidation(msisdnDetails.AccountId!, bundle.UuId!);
                    if (errorCode > 0)
                    {
                        return Result<PaypalResponse>.Failure(errorMessge, CustomStatusCode.BundlePurchaseFailed);
                    }
                }

                paypalPaymentRequest.BundleUuid = bundle.UuId;
                paypalPaymentRequest.BundleAmount = (float) bundle.TotalPrice;

                fulfillmentBasket.Add(new FulfillmentItem()
                {
                    Amount = (float) bundle.TotalPrice,
                    BundleRef = bundle.UuId!,
                    ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                    ProductRef = msisdn
                });

                orderhistoryBasket.Add(new OrderItem
                {
                    Amount = (float) bundle.Price,
                    DiscountAmount = (float) bundle.Discount,
                    BundleRef = bundle.UuId!
                });

                order.BundleId = bundle.UuId;
                order.BundleName = bundle.DisplayName!;
                order.BundleCountryCode = bundle.CountryCode!;

                if (bundle.Type == (int) BundleType.Rolling)
                {
                    bundleInfo.IsRenewable = true;
                }

                orderBundleInfo = _mapper.Map<OrderBundleInfo>(bundleInfo);
                // orderBundleInfo.GoodyBagColorCode = bundle.GoodyBagColorCode;

            }

            //Handle topup case
            if (checkoutType == CheckOutType.TopUp || checkoutType == CheckOutType.TopupBundle)
            {
                //Get msisdn last topup date
                var lastTopup = await _unitOfWork.UserRepo.GetUserLastTopupInfo(msisdnDetails.AccountId!);

                var discount = _discountService.GetDiscount(lastTopup?.Date, topupInfo!.TopupAmount, checkoutType);

                orderhistoryBasket.Add(new OrderItem
                {
                    Amount = topupInfo.TopupAmount,
                    DiscountAmount = discount,
                    BundleRef = null!
                });

                order.TopupAmount = paypalPaymentRequest.TopupAmount.ToString();

                fulfillmentBasket.Add(new FulfillmentItem()
                {
                    Amount = topupInfo.TopupAmount,
                    ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                    ProductRef = msisdn
                });

                paypalPaymentRequest.TopupAmount = topupInfo.TopupAmount - discount;
            }
        }

        //Handle credit sim
        if (checkoutType == CheckOutType.CreditSim)
        {
            var creditSimDetails = await _unitOfWork.SimRepo.GetCreditSimOrderDetails(creditSimInfo.OrderId);

            paypalPaymentRequest.Email = creditSimDetails.First().Email!;
            paypalPaymentRequest.Msisdn = null!;

            foreach (var item in creditSimDetails)
            {
                if (string.IsNullOrEmpty(item.BundleId))
                {
                    var topupAmount = Convert.ToSingle(item.Amount);

                    var discount = _discountService.GetDiscount(null, topupAmount, checkoutType);

                    orderhistoryBasket.Add(new OrderItem
                    {
                        Amount = topupAmount,
                        DiscountAmount = discount,
                        BundleRef = null!
                    });

                    order.TopupAmount = topupAmount.ToString();

                    fulfillmentBasket.Add(new FulfillmentItem()
                    {
                        Amount = topupAmount,
                        ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                        ProductRef = msisdn
                    });

                    paypalPaymentRequest.TopupAmount = topupAmount - discount;
                }
                else
                {
                    paypalPaymentRequest.BundleUuid = item.BundleId;

                    var bundleData = await _unitOfWork.BundleRepo.GetBundleById(paypalPaymentRequest.BundleUuid!);
                    var bundle = _mapper.Map<BundleInfo>(bundleData);

                    paypalPaymentRequest.BundleAmount = (float) bundle.TotalPrice;

                    orderhistoryBasket.Add(new OrderItem
                    {
                        Amount = (float) bundle.Price,
                        DiscountAmount = (float) bundle.Discount,
                        BundleRef = bundle.UuId!
                    });

                    order.BundleId = bundle.UuId;
                    order.BundleName = bundle.DisplayName!;
                    order.BundleCountryCode = bundle.CountryCode!;


                    orderBundleInfo = _mapper.Map<OrderBundleInfo>(bundleInfo);
                    //orderBundleInfo.GoodyBagColorCode = bundle.GoodyBagColorCode!;

                    fulfillmentBasket.Add(new FulfillmentItem()
                    {
                        Amount = (float) bundle.TotalPrice,
                        ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                        ProductRef = msisdn,
                        BundleRef = bundle.UuId!
                    });

                    if (bundle.Type == (int) BundleType.Rolling)
                    {
                        if (bundleInfo == null)
                        {
                            bundleInfo = new PaymentBundleInfo()
                            {
                                BundleId = 0,
                                IsRenewable = true
                            };
                        }
                        else
                        {
                            bundleInfo.IsRenewable = true;
                        }
                    }
                }
            }

            order.CreditSimOrderId = creditSimInfo.OrderId.ToString();
        }

        #region Order History Record

        order.OrderBaskets = orderhistoryBasket;
        order.Email = paypalPaymentRequest.Email;
        order.TransactionId = null!;
        order.Msisdn = paypalPaymentRequest.Msisdn;
        order.PaymentMethod = (int) PaymentMethod.Paypal;
        order.OrderData = JsonConvert.SerializeObject(new OrderData()
        {
            IsAppRequest = isAppRequest,
            CheckoutType = (int) checkoutType,
            AutoTopupInfo = topupInfo?.AutoTopupInfo,
            BundleInfo = orderBundleInfo,
            CreditSimOrderId = Convert.ToInt64(order.CreditSimOrderId),
            Alias = creditSimInfo == null ? null! : creditSimInfo.Alias,
            SaveCard = false
        });

        int orderID = await _unitOfWork.PaymentRepo.SaveOrderHistory(order, MediumType);
        paypalPaymentRequest.OrderId = orderID;

        #endregion
        PaypalPaymentResponse paymentResponse = null!;

        //Currently disabling paypal subscription
        //if (isSubscriptionRequest)
        if (false)
        {
            paymentResponse = await _payPalService.PayPalCreateSalePaymentWithSubscription(paypalPaymentRequest, subscriptionWithInitialSale);
        }
        else
        {
            paymentResponse = await _payPalService.PayPalCreateSalePayment(paypalPaymentRequest);
        }

        #region Fulfilment Record

        await _unitOfWork.PaymentRepo.SaveFulfillmentRecord(
            fulfillmentBasket,
            email,
            paymentResponse != null && paymentResponse.IsSuccess ? paymentResponse.TransactionId! : null!,
            msisdn);

        #endregion

        return await HandlePaypalPaymentResponse(orderID, paymentResponse!, false, topupInfo == default ? false : topupInfo.IsFastTopup, isAppRequest);
    }

    public async Task<Result<PaypalResponse>> HandleDirectPaypalExecuteRequest(
        string payerId,
        string paymentId,
        string uniqueRef,
        int orderId,
        bool IsFastTopup = false,
        bool IsAppRequest = false)
    {
        var response = await _payPalService.DirectPayPalExecuteSalePayment(uniqueRef, payerId, paymentId);
        return await HandlePaypalPaymentResponse(orderId, response, false, IsFastTopup, IsAppRequest);
    }

    public async Task<Result<PaypalResponse>> HandlePaypalSubscriptionRequest(
        PaymentTopupInfo topupInfo,
        PaymentBundleInfo bundleInfo,
        PaymentCreditSimInfo creditSimInfo,
        string msisdn,
        string email,
        string ipAddress)
    {
        (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();

        if (!string.IsNullOrEmpty(msisdn))
        {
            msisdn = _commonService.FormatMsisdn(msisdn);
        }

        var checkoutType = GetCheckoutType(creditSimInfo, topupInfo, bundleInfo);

        var paypalPaymentRequest = new PaypalPaymentRequest()
        {
            IpAddress = ipAddress,
            CheckoutType = checkoutType,
            IsAppRequest = IsAppRequest
        };

        var order = new Order();
        OrderBundleInfo orderBundleInfo = new OrderBundleInfo();
        var orderhistoryBasket = new List<OrderItem>();
        var fulfillmentBasket = new List<FulfillmentItem>();

        //Handle bundle and topup
        if (checkoutType == CheckOutType.TopUp
            || checkoutType == CheckOutType.Bundle
            || checkoutType == CheckOutType.TopupBundle)
        {
            paypalPaymentRequest.Msisdn = msisdn;

            //Handle Email
            if (IsAppRequest)
            {
                if (!await _userService.IsUserMsisdn(paypalPaymentRequest.Msisdn))
                {
                    return Result<PaypalResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
                }
                paypalPaymentRequest.Email = _currentUser.GetUserEmail()!;
            }
            else
            {
                paypalPaymentRequest.Email = email;
            }

            //Is valid THM msisdn
            var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(msisdn);
            if (msisdnDetails == null)
            {
                return Result<PaypalResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            }

            //Handle bundle case
            if (bundleInfo != null && bundleInfo.BundleId > 0
                && checkoutType == CheckOutType.Bundle
                || checkoutType == CheckOutType.TopupBundle)
            {
                var bundleData = await _unitOfWork.BundleRepo.GetBundleById(new BundleByIdRequest() { Id = bundleInfo!.BundleId.ToString() });
                if (bundleData == null)
                {
                    return Result<PaypalResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
                }

                //Handle Bundle
                BundleInfo? bundle = _mapper.Map<BundleInfo>(bundleData);

                paypalPaymentRequest.BundleUuid = bundle.UuId;
                paypalPaymentRequest.BundleAmount = (float) bundle.TotalPrice;

                orderhistoryBasket.Add(new OrderItem
                {
                    Amount = (float) bundle.Price,
                    DiscountAmount = (float) bundle.Discount,
                    BundleRef = bundle.UuId!
                });

                order.BundleId = bundle.UuId;
                order.BundleName = bundle.DisplayName!;
                order.BundleCountryCode = bundle.CountryCode!;

                if (bundle.Type == (int) BundleType.Rolling)
                {
                    bundleInfo.IsRenewable = true;
                }

                orderBundleInfo = _mapper.Map<OrderBundleInfo>(bundleInfo);
                // orderBundleInfo.GoodyBagColorCode = bundle.GoodyBagColorCode;

            }

            //Handle topup case
            if (checkoutType == CheckOutType.TopUp
                || checkoutType == CheckOutType.TopupBundle)
            {

                //Get msisdn last topup date
                var lastTopup = await _unitOfWork.UserRepo.GetUserLastTopupInfo(msisdnDetails.AccountId!);

                var discount = _discountService.GetDiscount(lastTopup?.Date, topupInfo.TopupAmount, checkoutType);

                orderhistoryBasket.Add(new OrderItem
                {
                    Amount = topupInfo.TopupAmount,
                    DiscountAmount = discount,
                    BundleRef = null!
                });

                order.TopupAmount = paypalPaymentRequest.TopupAmount.ToString();

                fulfillmentBasket.Add(new FulfillmentItem()
                {
                    Amount = topupInfo.TopupAmount,
                    ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                    ProductRef = msisdn
                });

                paypalPaymentRequest.TopupAmount = topupInfo.TopupAmount - discount;
            }
        }

        //Handle credit sim
        if (checkoutType == CheckOutType.CreditSim)
        {
            var creditSimDetails = await _unitOfWork.SimRepo.GetCreditSimOrderDetails(creditSimInfo.OrderId);


            paypalPaymentRequest.Email = creditSimDetails.First().Email!;
            paypalPaymentRequest.Msisdn = null!;

            foreach (var item in creditSimDetails)
            {
                if (string.IsNullOrEmpty(item.BundleId))
                {
                    var topupAmount = Convert.ToSingle(item.Amount);

                    var discount = _discountService.GetDiscount(null, topupAmount, checkoutType);

                    orderhistoryBasket.Add(new OrderItem
                    {
                        Amount = topupAmount,
                        DiscountAmount = discount,
                        BundleRef = null!
                    });

                    order.TopupAmount = topupAmount.ToString();

                    fulfillmentBasket.Add(new FulfillmentItem()
                    {
                        Amount = topupAmount,
                        ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                        ProductRef = msisdn
                    });

                    paypalPaymentRequest.TopupAmount = topupAmount - discount;
                }
                else
                {
                    paypalPaymentRequest.BundleUuid = item.BundleId;

                    var bundleData = await _unitOfWork.BundleRepo.GetBundleById(paypalPaymentRequest.BundleUuid!);
                    var bundle = _mapper.Map<BundleInfo>(bundleData);

                    paypalPaymentRequest.BundleAmount = (float) bundle.TotalPrice;

                    orderhistoryBasket.Add(new OrderItem
                    {
                        Amount = (float) bundle.Price,
                        DiscountAmount = (float) bundle.Discount,
                        BundleRef = bundle.UuId!
                    });

                    order.BundleId = bundle.UuId;
                    order.BundleName = bundle.DisplayName!;
                    order.BundleCountryCode = bundle.CountryCode!;

                    fulfillmentBasket.Add(new FulfillmentItem()
                    {
                        Amount = (float) bundle.TotalPrice,
                        ProductItemCode = ProductItemCode.NOWCRSIM.ToString(),
                        ProductRef = msisdn,
                        BundleRef = bundle.UuId!
                    });

                    if (bundle.Type == (int) BundleType.Rolling)
                    {
                        if (bundleInfo == null)
                        {
                            bundleInfo = new PaymentBundleInfo()
                            {
                                BundleId = 0,
                                IsRenewable = true
                            };
                        }
                        else
                        {
                            bundleInfo.IsRenewable = true;
                        }
                    }
                }
            }

            order.CreditSimOrderId = creditSimInfo.OrderId.ToString();
        }

        #region Order History Record

        order.OrderBaskets = orderhistoryBasket;
        order.Email = paypalPaymentRequest.Email;
        order.TransactionId = null!;
        order.Msisdn = paypalPaymentRequest.Msisdn;
        order.PaymentMethod = (int) PaymentMethod.Paypal;
        order.OrderData = JsonConvert.SerializeObject(new OrderData()
        {
            IsAppRequest = IsAppRequest,
            CheckoutType = (int) checkoutType,
            AutoTopupInfo = topupInfo?.AutoTopupInfo,
            BundleInfo = orderBundleInfo,
            CreditSimOrderId = Convert.ToInt64(order.CreditSimOrderId),
            Alias = creditSimInfo == null ? null! : creditSimInfo.Alias,
            SaveCard = false
        });

        int orderID = await _unitOfWork.PaymentRepo.SaveOrderHistory(order, MediumType);
        paypalPaymentRequest.OrderId = orderID;

        #endregion

        var paymentResponse = await _payPalService.PayPalCreateSalePaymentWithSubscription(paypalPaymentRequest);

        return await HandlePaypalPaymentResponse(orderID, paymentResponse!, true, topupInfo == default ? false : topupInfo.IsFastTopup, IsAppRequest);
    }

    #endregion

    #endregion

    #region Private

    private async Task<Result<CardResponse>> HandleCardPaymentResponse(int orderId, CardPaymentResponse response, bool isAuthorizeOnly = false, bool isFastTopup = false, bool IsAppRequest = false)
    {
        bool IsTopupIncluded = false, IsNewCustomer = true, IsBundleIncluded = false;
        string planId = "", planName = "", planCountryCode = "";
        decimal topupAmount = 0, planAmount = 0;
        int planCategory = 0, planType = 0;
        //get order Details 
        var (isSuccess, orderDetails, orderItemDetails) = await _unitOfWork.PaymentRepo.GetOrderDetails(orderId);

        var orderData = JsonConvert.DeserializeObject<OrderData>(orderDetails.OrderData!)!;

        if (!isSuccess)
        {
            return Result<CardResponse>.Failure(new CardResponse() { OrderId = orderId }, _localizer[CustomStatusKey.PaymentServiceError], CustomStatusCode.PaymentServiceError);
        }
        if (!IsAppRequest)
        {
            if (orderData != null && orderData.BundleInfo != null && orderData.BundleInfo.BundleId > 0)
            {
                IsBundleIncluded = true;
                var bundleInfo = await _unitOfWork.BundleRepo.GetBundleById(
                         new BundleByIdRequest() { Id = orderData.BundleInfo.BundleId.ToString() });
                planId = Convert.ToString(orderData.BundleInfo.BundleId);
                planAmount = bundleInfo.TotalPrice;
                planCountryCode = bundleInfo.CountryCode!;
                planName = bundleInfo.DisplayName!;
                planType = bundleInfo.Type;
                planCategory = bundleInfo.Category;
            }
            if (orderItemDetails.Any(x => x.TransactionItemType == (int) BasketItemType.TopUp))
            {
                IsTopupIncluded = true;
                topupAmount = Convert.ToDecimal(orderItemDetails.FirstOrDefault(x => x.TransactionItemType == (int) BasketItemType.TopUp)?.TotalAmount);
            }
            if (!String.IsNullOrEmpty(orderDetails.Email))
            {
                var userResponse = await _unitOfWork.UserRepo.GetUserByEmail(orderDetails.Email);
                if (userResponse != null)
                {
                    var userProductResponse = await _unitOfWork.UserRepo.GetUserProducts(userResponse.Id);
                    if (userProductResponse != null && userProductResponse.Where(x => x.Status == (int) SimStatus.Completed).Count() > 1)
                    {
                        IsNewCustomer = false;
                    }
                }
            }
        }
        if (response == null)
        {
            #region Airship
            if (!IsAppRequest)
            {
                if (orderData.CheckoutType == (int) CheckOutType.CreditSim)
                {
                    _airshipService.HandleCreditSIMPurchaseTagsAndEvents(new SimPurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = Convert.ToDecimal(orderDetails.TotalAmount),
                        IsCard = true,
                        IsSuccess = false,
                        IsBundleIncluded = IsBundleIncluded,
                        IsTopupIncluded = IsTopupIncluded,
                        AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                        IsNewCustomer = IsNewCustomer,
                        IsCreditSIM = true,
                        SaveCard = orderData.SaveCard
                    });

                    if (IsTopupIncluded)
                    {
                        _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = true,
                            IsSuccess = false,
                            SaveCard = false,
                            AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        });
                    }
                    if (IsBundleIncluded)
                    {
                        _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = planAmount,
                            AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                            IsCard = true,
                            IsSuccess = false,
                            BundleType = planType,
                            BundleCategory = planCategory,
                            BundleName = planName,
                            Destination = planCountryCode,
                            SaveCard = false,
                        });
                    }
                }
                if (orderData.CheckoutType == (int) CheckOutType.TopUp)
                {
                    if (isFastTopup)
                    {
                        _airshipService.HandleFastTopupPurchaseTagsAndEvents(new FastTopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = true,
                            IsSuccess = false,
                            SaveCard = orderData.SaveCard
                        });
                    }
                    else
                    {
                        _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = true,
                            IsSuccess = false,
                            SaveCard = orderData.SaveCard,
                            AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        });
                    }
                }
                if (orderData.CheckoutType == (int) CheckOutType.Bundle)
                {
                    _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = planAmount,
                        AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                        IsCard = true,
                        IsSuccess = false,
                        BundleType = planType,
                        BundleCategory = planCategory,
                        BundleName = planName,
                        Destination = planCountryCode,
                        SaveCard = orderData.SaveCard,
                    });
                }
            }
            #endregion
            return Result<CardResponse>.Failure(new CardResponse() { OrderId = orderId }, _localizer[CustomStatusKey.PaymentServiceError], CustomStatusCode.PaymentServiceError);
        }

        //Handle errors case
        if (!response.IsSuccess)
        {
            #region Airship
            if (!IsAppRequest)
            {
                if (orderData.CheckoutType == (int) CheckOutType.CreditSim)
                {
                    _airshipService.HandleCreditSIMPurchaseTagsAndEvents(new SimPurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = Convert.ToDecimal(orderDetails.TotalAmount),
                        IsCard = true,
                        IsSuccess = false,
                        IsBundleIncluded = IsBundleIncluded,
                        IsTopupIncluded = IsTopupIncluded,
                        AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                        IsNewCustomer = IsNewCustomer,
                        IsCreditSIM = true,
                        SaveCard = orderData.SaveCard
                    });

                    if (IsTopupIncluded)
                    {
                        _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = true,
                            IsSuccess = false,
                            SaveCard = false,
                            AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        });
                    }
                    if (IsBundleIncluded)
                    {
                        _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = planAmount,
                            AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                            IsCard = true,
                            IsSuccess = false,
                            BundleType = planType,
                            BundleCategory = planCategory,
                            BundleName = planName,
                            Destination = planCountryCode,
                            SaveCard = false,
                        });
                    }
                }
                if (orderData.CheckoutType == (int) CheckOutType.TopUp)
                {
                    if (isFastTopup)
                    {
                        _airshipService.HandleFastTopupPurchaseTagsAndEvents(new FastTopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = true,
                            IsSuccess = false,
                            SaveCard = orderData.SaveCard
                        });
                    }
                    else
                    {
                        _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = true,
                            IsSuccess = false,
                            SaveCard = orderData.SaveCard,
                            AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        });
                    }
                }
                if (orderData.CheckoutType == (int) CheckOutType.Bundle)
                {
                    _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = planAmount,
                        AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                        IsCard = true,
                        IsSuccess = false,
                        BundleType = planType,
                        BundleCategory = planCategory,
                        BundleName = planName,
                        Destination = planCountryCode,
                        SaveCard = orderData.SaveCard,
                    });
                }
            }
            #endregion

            if (orderData!.CheckoutType == (int) CheckOutType.CreditSim)
            {
                //Update credit sim status
                await _unitOfWork.SimRepo.UpdateCreditSimPayment(orderDetails.UserId, orderData.CreditSimOrderId, PaymentMethod.Card, null!, false, response.ErrorMessage!, response.ErrorCode.ToString());
            }

            //Update payment history status
            await _unitOfWork.PaymentRepo.UpdateOrderHistoryStatus(new OrderStatusDetails()
            {
                OrderId = orderId,
                Status = (int) OrderStatus.Failure,
                ErrorCode = response.ErrorCode.ToString(),
                ErrorMessage = response.ErrorMessage!,
                TransactionId = null!
            });

            if (response.ErrorCode == CustomStatusCode.DailyPaymentLimitExceeded)
            {
                return Result<CardResponse>.Failure(new CardResponse() { OrderId = orderId }, _localizer[CustomStatusKey.DailyPaymentLimitExceeded], CustomStatusCode.DailyPaymentLimitExceeded);
            }
            else if (response.ErrorCode == CustomStatusCode.BundlePurchaseLimitExceeded)
            {
                return Result<CardResponse>.Failure(new CardResponse() { OrderId = orderId }, _localizer[CustomStatusKey.BundlePurchaseLimitExceeded], CustomStatusCode.BundlePurchaseLimitExceeded);
            }
            else if (response.ErrorCode == CustomStatusCode.PaymentProviderError)
            {
                return Result<CardResponse>.Failure(new CardResponse() { OrderId = orderId }, response.ErrorMessage!, CustomStatusCode.PaymentProviderError);
            }
            else
            {
                return Result<CardResponse>.Failure(new CardResponse() { OrderId = orderId }, _localizer[CustomStatusKey.PaymentServiceError], CustomStatusCode.PaymentServiceError);
            }
        }

        //Handle 3d secure return case
        if (response.Need3dSecure)
        {
            if (orderData.IsAppRequest)
            {
                if (response.ThreeDSecureData!.Type!.Contains("V2", StringComparison.InvariantCultureIgnoreCase))
                {
                    var model = new Resume3DV2Info()
                    {
                        ReturnUrl = _callbackSettings.AppBaseUrl + _pay360Setting.AppPaymentCallBackUrl + "?OrderID=" + orderId,
                        TransactionId = response.ThreeDSecureData.TransactionId,
                        ThreeDSServerTransId = response.ThreeDSecureData.ThreeDSServerTransId,
                        Url = response.ThreeDSecureData.RedirectUrl,
                    };

                    return Result<CardResponse>.Failure(new CardResponse()
                    {
                        PaymentHtmlData = GetViewHtml("Resume3DV2", model),
                        OrderId = orderId
                    }, _localizer[CustomStatusKey.Need3dSecure], CustomStatusCode.Need3dSecure);
                }
                else
                {
                    return Result<CardResponse>.Failure(new CardResponse() { OrderId = orderId }, _localizer[CustomStatusKey.PaymentServiceError], CustomStatusCode.PaymentServiceError);
                }
            }
            else
            {
                response.ThreeDSecureData!.ReturnUrl =
                    _callbackSettings.WebBaseUrl + _pay360Setting.WebPaymentCallBackUrl + "?OrderID=" + orderId;
                return Result<CardResponse>.Failure(
                    new CardResponse()
                    {
                        ThreeDSecureData = response.ThreeDSecureData!,
                        OrderId = orderId
                    }, _localizer[CustomStatusKey.Need3dSecure], CustomStatusCode.Need3dSecure);
            }
        }

        if (orderData!.CheckoutType == (int) CheckOutType.CreditSim)
        {
            var result = await _unitOfWork.SimRepo.UpdateCreditSimPayment(
                orderDetails.UserId, orderData.CreditSimOrderId, PaymentMethod.Card, response.TransactionId!, true, null!, null!);
            if (result.DBStatus == DbStatus.Success)
            {
                string Alias = null!;
                if (orderData != null)
                {
                    if (!string.IsNullOrEmpty(orderData.Alias))
                    {
                        Alias = orderData.Alias;
                    }
                }

                //Update payment history status
                await _unitOfWork.PaymentRepo.UpdateOrderHistoryStatus(new OrderStatusDetails()
                {
                    OrderId = orderId,
                    Status = (int) OrderStatus.Success,
                    ErrorCode = null!,
                    ErrorMessage = null!,
                    TransactionId = response.TransactionId!,
                    Msisdn = result.Data
                });

                var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(result.Data!);

                await _unitOfWork.UserRepo.AddProduct(new UserProduct()
                {
                    AccountId = msisdnDetails == null ? "12345678" : msisdnDetails?.AccountId,
                    Msisdn = result.Data!,
                    Status = (int) SimStatus.CreditSimInProcess,
                    UserId = orderDetails.UserId,
                    Name = Alias
                });

                await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.UserProduct, orderDetails.UserId.ToString()));

                orderDetails.Msisdn = result.Data!;
            }
            else
            {
                if (result.ErrorCode == 1)
                {
                    return Result<CardResponse>.Failure(new CardResponse() { OrderId = orderId }, _localizer[CustomStatusKey.CreditSimOrderNotExists], CustomStatusCode.CreditSimOrderNotExists);
                }
                else if (result.ErrorCode == 2)
                {
                    return Result<CardResponse>.Failure(new CardResponse() { OrderId = orderId }, _localizer[CustomStatusKey.CreditSimPaymentAlreadyExists], CustomStatusCode.CreditSimPaymentAlreadyExists);
                }
                else if (result.ErrorCode == 3)
                {
                    return Result<CardResponse>.Failure(new CardResponse() { OrderId = orderId }, _localizer[CustomStatusKey.CreditSimMsisdnNotAvailable], CustomStatusCode.CreditSimMsisdnNotAvailable);
                }
            }

            //Send Credit Sim Email
            orderDetails.TransactionId = response.TransactionId;
            await _mailService.SendCreditSimOrderEmail(orderDetails, orderItemDetails);
        }
        else
        {

            //Refund payment if authorize only call
            if (isAuthorizeOnly)
            {
                var refundPaymentSuccess = await _cardService.RefundFullPayment(response.TransactionId!);

                await _unitOfWork.PaymentRepo.UpdateOrderHistoryStatus(new OrderStatusDetails()
                {
                    OrderId = orderId,
                    Status = refundPaymentSuccess ? (int) OrderStatus.Refunded : (int) OrderStatus.Success,
                    ErrorCode = null!,
                    ErrorMessage = null!,
                    TransactionId = response.TransactionId!,
                    Msisdn = null
                });
            }
            else
            {
                //Update payment history status
                await _unitOfWork.PaymentRepo.UpdateOrderHistoryStatus(new OrderStatusDetails()
                {
                    OrderId = orderId,
                    Status = (int) OrderStatus.Success,
                    ErrorCode = null!,
                    ErrorMessage = null!,
                    TransactionId = response.TransactionId!,
                    Msisdn = null
                });
            }

            //Handle Fulfillment Record
            if (!_pay360Setting.IsDirectFullfilment && isAuthorizeOnly == false)
            {
                await PaymentFulfillment(response.TransactionId!, orderDetails.Msisdn, orderDetails.Email,
                    orderDetails.Discount, true);
            }

            //Handle Auto Topup
            if (orderData.AutoTopupInfo != null)
            {
                if (response.IsRecurring)
                {
                    await _topupRepo.SetAutoTopup(
                        orderData.AutoTopupInfo.Status,
                         orderDetails.Msisdn,
                         orderDetails.Email,
                         orderData.AutoTopupInfo.TopupAmount,
                         topupCurrency: Currency.GBP.ToString(),
                         orderData.AutoTopupInfo.ThresHoldAmount,
                         PaymentMethod.Card,
                         orderData.CardMaskedPan!,
                         response.TransactionId!
                         );
                }
                else
                {
                    await _topupRepo.SetAutoTopup(
                         orderData.AutoTopupInfo.Status,
                          orderDetails.Msisdn,
                          orderDetails.Email,
                          orderData.AutoTopupInfo.TopupAmount,
                          topupCurrency: Currency.GBP.ToString(),
                          orderData.AutoTopupInfo.ThresHoldAmount,
                          PaymentMethod.Card
                          );

                }

            }

            //Handle Auto Renew
            if (orderData.BundleInfo != null && orderData.BundleInfo.IsRenewable && orderData.BundleInfo.BundleId > 0)
            {
                var bundleInfo = await _unitOfWork.BundleRepo.GetBundleById(
                    new BundleByIdRequest() { Id = orderData.BundleInfo.BundleId.ToString() });
                var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(orderDetails.Msisdn);
                if (response.IsRecurring)
                {
                    await _unitOfWork.BundleRepo.SetBundleAutoRenewal(
                        true,
                        orderDetails.Msisdn,
                        msisdnDetails.AccountId!,
                        bundleInfo.UuId!,
                        orderDetails.Email,
                        PaymentMethod.Card,
                        orderData.CardMaskedPan!,
                         response.TransactionId!);
                }
                else
                {
                    await _unitOfWork.BundleRepo.SetBundleAutoRenewal(
                        true,
                        orderDetails.Msisdn,
                        msisdnDetails.AccountId!,
                        bundleInfo.UuId!,
                        orderDetails.Email,
                        PaymentMethod.Card);
                }
            }
        }

        #region Email

        if (!isAuthorizeOnly && orderData.CheckoutType == (int) CheckOutType.TopUp)
        {
            await _mailService.SendTopUpEmail(orderDetails, orderItemDetails);
        }
        else if (!isAuthorizeOnly && orderData.CheckoutType == (int) CheckOutType.Bundle)
        {
            await _mailService.SendBundleEmail(orderDetails, orderItemDetails);

        }

        #endregion

        #region Airship
        if (!IsAppRequest)
        {
            if (orderData.CheckoutType == (int) CheckOutType.CreditSim)
            {
                _airshipService.HandleCreditSIMPurchaseTagsAndEvents(new SimPurchaseEventData
                {
                    Email = orderDetails.Email,
                    Amount = Convert.ToDecimal(orderDetails.TotalAmount),
                    IsCard = true,
                    IsSuccess = true,
                    IsBundleIncluded = IsBundleIncluded,
                    IsTopupIncluded = IsTopupIncluded,
                    AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                    AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                    IsNewCustomer = IsNewCustomer,
                    IsCreditSIM = true,
                    SaveCard = orderData.SaveCard
                });

                if (IsTopupIncluded)
                {
                    _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = topupAmount,
                        IsCard = true,
                        IsSuccess = true,
                        SaveCard = false,
                        AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                    });
                }
                if (IsBundleIncluded)
                {
                    _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = planAmount,
                        AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                        IsCard = true,
                        IsSuccess = true,
                        BundleType = planType,
                        BundleCategory = planCategory,
                        BundleName = planName,
                        Destination = planCountryCode,
                        SaveCard = false,
                    });
                }
            }
            if (orderData.CheckoutType == (int) CheckOutType.TopUp)
            {
                if (isFastTopup)
                {
                    _airshipService.HandleFastTopupPurchaseTagsAndEvents(new FastTopupPurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = topupAmount,
                        IsCard = true,
                        IsSuccess = true,
                        SaveCard = orderData.SaveCard
                    });
                }
                else
                {
                    _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = topupAmount,
                        IsCard = true,
                        IsSuccess = true,
                        SaveCard = orderData.SaveCard,
                        AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                    });
                }
            }
            if (orderData.CheckoutType == (int) CheckOutType.Bundle)
            {
                _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                {
                    Email = orderDetails.Email,
                    Amount = planAmount,
                    AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                    IsCard = true,
                    IsSuccess = true,
                    BundleType = planType,
                    BundleCategory = planCategory,
                    BundleName = planName,
                    Destination = planCountryCode,
                    SaveCard = orderData.SaveCard,
                });
            }
        }
        #endregion

        //Hande success case
        return Result<CardResponse>.Success(new CardResponse() { OrderId = orderId }, _localizer[CustomStatusKey.Success]);
    }

    private async Task<Result<PaypalResponse>> HandlePaypalPaymentResponse(int orderId, PaypalPaymentResponse response, bool isSubscriptionRequest = default, bool isFastTopup = false, bool IsAppRequest = false)
    {
        bool IsTopupIncluded = false, IsNewCustomer = false, IsBundleIncluded = false;
        string planId = "", planName = "", planCountryCode = "";
        decimal topupAmount = 0, planAmount = 0;
        int planCategory = 0, planType = 0;
        //get order Details 
        var (isSuccess, orderDetails, orderItemDetails) = await _unitOfWork.PaymentRepo.GetOrderDetails(orderId);

        var orderData = JsonConvert.DeserializeObject<OrderData>(orderDetails.OrderData!)!;

        if (!isSuccess)
        {
            return Result<PaypalResponse>.Failure(new PaypalResponse() { OrderId = orderId }, _localizer[CustomStatusKey.PaymentServiceError], CustomStatusCode.PaymentServiceError);
        }
        if (!IsAppRequest)
        {
            if (orderData != null && orderData.BundleInfo != null && orderData.BundleInfo.BundleId > 0)
            {
                IsBundleIncluded = true;
                var bundleInfo = await _unitOfWork.BundleRepo.GetBundleById(
                         new BundleByIdRequest() { Id = orderData.BundleInfo.BundleId.ToString() });
                planId = Convert.ToString(orderData.BundleInfo.BundleId);
                planAmount = bundleInfo.TotalPrice;
                planCountryCode = bundleInfo.CountryCode;
                planName = bundleInfo.DisplayName;
                planType = bundleInfo.Type;
                planCategory = bundleInfo.Category;
            }
            if (orderItemDetails.Any(x => x.TransactionItemType == (int) BasketItemType.TopUp))
            {
                IsTopupIncluded = true;
                topupAmount = Convert.ToDecimal(orderItemDetails.FirstOrDefault(x => x.TransactionItemType == (int) BasketItemType.TopUp)?.TotalAmount);
            }
            if (!String.IsNullOrEmpty(orderDetails.Email))
            {
                var userResponse = await _unitOfWork.UserRepo.GetUserByEmail(orderDetails.Email);
                if (userResponse != null)
                {
                    var userProductResponse = await _unitOfWork.UserRepo.GetUserProducts(userResponse.Id);
                    if (userProductResponse != null && userProductResponse.Where(x => x.Status == (int) SimStatus.Completed).Count() > 1)
                    {
                        IsNewCustomer = false;
                    }
                }
            }
        }

        if (response == null)
        {
            #region Airship
            if (!IsAppRequest)
            {
                if (orderData.CheckoutType == (int) CheckOutType.CreditSim)
                {
                    _airshipService.HandleCreditSIMPurchaseTagsAndEvents(new SimPurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = Convert.ToDecimal(orderDetails.TotalAmount),
                        IsCard = false,
                        IsSuccess = false,
                        IsBundleIncluded = IsBundleIncluded,
                        IsTopupIncluded = IsTopupIncluded,
                        AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                        IsNewCustomer = IsNewCustomer,
                        IsCreditSIM = true,
                        SaveCard = orderData.SaveCard
                    });

                    if (IsTopupIncluded)
                    {
                        _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = false,
                            IsSuccess = false,
                            SaveCard = false,
                            AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        });
                    }
                    if (IsBundleIncluded)
                    {
                        _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = planAmount,
                            AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                            IsCard = false,
                            IsSuccess = false,
                            BundleType = planType,
                            BundleCategory = planCategory,
                            BundleName = planName,
                            Destination = planCountryCode,
                            SaveCard = false,
                        });
                    }
                }
                if (orderData.CheckoutType == (int) CheckOutType.TopUp)
                {
                    if (isFastTopup)
                    {
                        _airshipService.HandleFastTopupPurchaseTagsAndEvents(new FastTopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = false,
                            IsSuccess = false,
                            SaveCard = orderData.SaveCard
                        });
                    }
                    else
                    {
                        _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = false,
                            IsSuccess = false,
                            SaveCard = orderData.SaveCard,
                            AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        });
                    }
                }
                if (orderData.CheckoutType == (int) CheckOutType.Bundle)
                {
                    _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = planAmount,
                        AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                        IsCard = false,
                        IsSuccess = false,
                        BundleType = planType,
                        BundleCategory = planCategory,
                        BundleName = planName,
                        Destination = planCountryCode,
                        SaveCard = orderData.SaveCard,
                    });
                }
            }
            #endregion

            return Result<PaypalResponse>.Failure(new PaypalResponse() { OrderId = orderId }, _localizer[CustomStatusKey.PaymentServiceError], CustomStatusCode.PaymentServiceError);
        }

        //Handle errors case
        if (!response.IsSuccess)
        {
            #region Airship
            if (!IsAppRequest)
            {
                if (orderData.CheckoutType == (int) CheckOutType.CreditSim)
                {
                    _airshipService.HandleCreditSIMPurchaseTagsAndEvents(new SimPurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = Convert.ToDecimal(orderDetails.TotalAmount),
                        IsCard = false,
                        IsSuccess = false,
                        IsBundleIncluded = IsBundleIncluded,
                        IsTopupIncluded = IsTopupIncluded,
                        AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                        IsNewCustomer = IsNewCustomer,
                        IsCreditSIM = true,
                        SaveCard = orderData.SaveCard
                    });

                    if (IsTopupIncluded)
                    {
                        _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = false,
                            IsSuccess = false,
                            SaveCard = false,
                            AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        });
                    }
                    if (IsBundleIncluded)
                    {
                        _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = planAmount,
                            AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                            IsCard = false,
                            IsSuccess = false,
                            BundleType = planType,
                            BundleCategory = planCategory,
                            BundleName = planName,
                            Destination = planCountryCode,
                            SaveCard = false,
                        });
                    }
                }
                if (orderData.CheckoutType == (int) CheckOutType.TopUp)
                {
                    if (isFastTopup)
                    {
                        _airshipService.HandleFastTopupPurchaseTagsAndEvents(new FastTopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = false,
                            IsSuccess = false,
                            SaveCard = orderData.SaveCard
                        });
                    }
                    else
                    {
                        _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                        {
                            Email = orderDetails.Email,
                            Amount = topupAmount,
                            IsCard = false,
                            IsSuccess = false,
                            SaveCard = orderData.SaveCard,
                            AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                        });
                    }
                }
                if (orderData.CheckoutType == (int) CheckOutType.Bundle)
                {
                    _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = planAmount,
                        AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                        IsCard = false,
                        IsSuccess = false,
                        BundleType = planType,
                        BundleCategory = planCategory,
                        BundleName = planName,
                        Destination = planCountryCode,
                        SaveCard = orderData.SaveCard,
                    });
                }
            }
            #endregion

            if (orderData.CheckoutType == (int) CheckOutType.CreditSim)
            {
                //Update credit sim status
                await _unitOfWork.SimRepo.UpdateCreditSimPayment(orderDetails.UserId, orderData.CreditSimOrderId, PaymentMethod.Card, null!, false, response.ErrorMessage!, response.ErrorCode.ToString());
            }

            //Update payment history status
            await _unitOfWork.PaymentRepo.UpdateOrderHistoryStatus(new OrderStatusDetails()
            {
                OrderId = orderId,
                Status = (int) OrderStatus.Failure,
                ErrorCode = response.ErrorCode.ToString(),
                ErrorMessage = response.ErrorMessage!,
                TransactionId = null!
            });

            if (response.ErrorCode == CustomStatusCode.DailyPaymentLimitExceeded)
            {
                return Result<PaypalResponse>.Failure(new PaypalResponse() { OrderId = orderId }, _localizer[CustomStatusKey.DailyPaymentLimitExceeded], CustomStatusCode.DailyPaymentLimitExceeded);
            }
            else if (response.ErrorCode == CustomStatusCode.BundlePurchaseLimitExceeded)
            {
                return Result<PaypalResponse>.Failure(new PaypalResponse() { OrderId = orderId }, _localizer[CustomStatusKey.BundlePurchaseLimitExceeded], CustomStatusCode.BundlePurchaseLimitExceeded);
            }
            else if (response.ErrorCode == CustomStatusCode.PaymentProviderError)
            {
                return Result<PaypalResponse>.Failure(new PaypalResponse() { OrderId = orderId }, response.ErrorMessage!, CustomStatusCode.PaymentProviderError);
            }
            else
            {
                return Result<PaypalResponse>.Failure(new PaypalResponse() { OrderId = orderId }, _localizer[CustomStatusKey.PaymentServiceError], CustomStatusCode.PaymentServiceError);
            }
        }

        //Handle paypal callback response
        if (!string.IsNullOrEmpty(response.RedirectUrl))
        {
            //Update payment history status
            await _unitOfWork.PaymentRepo.UpdateOrderHistoryStatus(new OrderStatusDetails()
            {
                OrderId = orderId,
                Status = (int) OrderStatus.Create,
                ErrorCode = response.ErrorCode.ToString(),
                ErrorMessage = response.ErrorMessage!,
                TransactionId = response.TransactionId!
            });
            return Result<PaypalResponse>.Success(new PaypalResponse() { OrderId = orderId, RedirectUrl = response.RedirectUrl }, _localizer[CustomStatusKey.Success]);
        }
        if (orderData.CheckoutType == (int) CheckOutType.CreditSim)
        {
            var result = await _unitOfWork.SimRepo.UpdateCreditSimPayment(
                orderDetails.UserId,
                orderData.CreditSimOrderId,
                PaymentMethod.Paypal,
                response.TransactionId!,
                true,
                null!,
                null!);

            if (result.DBStatus == DbStatus.Success)
            {
                string Alias = null!;
                if (orderData != null)
                {
                    if (!string.IsNullOrEmpty(orderData.Alias))
                    {
                        Alias = orderData.Alias;
                    }
                }

                //Update payment history status
                await _unitOfWork.PaymentRepo.UpdateOrderHistoryStatus(
                    new OrderStatusDetails()
                    {
                        OrderId = orderId,
                        Status = (int) OrderStatus.Success,
                        ErrorCode = null!,
                        ErrorMessage = null!,
                        TransactionId = response.TransactionId!,
                        Msisdn = result.Data
                    });

                var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(result.Data!);

                await _unitOfWork.UserRepo.AddProduct(new UserProduct()
                {
                    AccountId = msisdnDetails == null ? "12345678" : msisdnDetails?.AccountId,
                    Msisdn = result.Data!,
                    Status = (int) SimStatus.CreditSimInProcess,
                    UserId = orderDetails.UserId,
                    Name = Alias
                });

                await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.UserProduct, orderDetails.UserId.ToString()));

                orderDetails.Msisdn = result.Data!;
            }
            else
            {
                if (result.ErrorCode == 1)
                {
                    return Result<PaypalResponse>.Failure(new PaypalResponse() { OrderId = orderId }, _localizer[CustomStatusKey.CreditSimOrderNotExists], CustomStatusCode.CreditSimOrderNotExists);
                }
                else if (result.ErrorCode == 2)
                {
                    return Result<PaypalResponse>.Failure(new PaypalResponse() { OrderId = orderId }, _localizer[CustomStatusKey.CreditSimPaymentAlreadyExists], CustomStatusCode.CreditSimPaymentAlreadyExists);
                }
                else if (result.ErrorCode == 3)
                {
                    return Result<PaypalResponse>.Failure(new PaypalResponse() { OrderId = orderId }, _localizer[CustomStatusKey.CreditSimMsisdnNotAvailable], CustomStatusCode.CreditSimMsisdnNotAvailable);
                }
            }

            //Send Credit Sim Email
            orderDetails.TransactionId = response.TransactionId!;
            await _mailService.SendCreditSimOrderEmail(orderDetails, orderItemDetails);
        }
        else
        {
            //Update payment history status
            await _unitOfWork.PaymentRepo.UpdateOrderHistoryStatus(
                new OrderStatusDetails()
                {
                    OrderId = orderId,
                    Status = (int) OrderStatus.Success,
                    ErrorCode = null!,
                    ErrorMessage = null!,
                    TransactionId = response.TransactionId!,
                    Msisdn = null
                });

            //Handle Fulfillment Record
            if (!_payPalSetting.IsDirectFullfilment)
            {
                await PaymentFulfillment(response.TransactionId!, orderDetails.Msisdn, orderDetails.Email, orderDetails.Discount, false);
            }
        }

        #region Email


        if (orderData.CheckoutType == (int) CheckOutType.TopUp)
        {
            await _mailService.SendTopUpEmail(orderDetails, orderItemDetails);
        }
        else if (orderData.CheckoutType == (int) CheckOutType.Bundle)
        {
            await _mailService.SendBundleEmail(orderDetails, orderItemDetails);

        }
        #endregion

        #region Airship
        if (!IsAppRequest)
        {
            if (orderData.CheckoutType == (int) CheckOutType.CreditSim)
            {
                _airshipService.HandleCreditSIMPurchaseTagsAndEvents(new SimPurchaseEventData
                {
                    Email = orderDetails.Email,
                    Amount = Convert.ToDecimal(orderDetails.TotalAmount),
                    IsCard = false,
                    IsSuccess = true,
                    IsBundleIncluded = IsBundleIncluded,
                    IsTopupIncluded = IsTopupIncluded,
                    AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                    AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                    IsNewCustomer = IsNewCustomer,
                    IsCreditSIM = true,
                    SaveCard = orderData.SaveCard
                });

                if (IsTopupIncluded)
                {
                    _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = topupAmount,
                        IsCard = false,
                        IsSuccess = true,
                        SaveCard = false,
                        AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                    });
                }
                if (IsBundleIncluded)
                {
                    _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = planAmount,
                        AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                        IsCard = false,
                        IsSuccess = true,
                        BundleType = planType,
                        BundleCategory = planCategory,
                        BundleName = planName,
                        Destination = planCountryCode,
                        SaveCard = false,
                    });
                }
            }
            if (orderData.CheckoutType == (int) CheckOutType.TopUp)
            {
                if (isFastTopup)
                {
                    _airshipService.HandleFastTopupPurchaseTagsAndEvents(new FastTopupPurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = topupAmount,
                        IsCard = false,
                        IsSuccess = true,
                        SaveCard = orderData.SaveCard
                    });
                }
                else
                {
                    _airshipService.HandleTopupPurchaseTagsAndEvents(new TopupPurchaseEventData
                    {
                        Email = orderDetails.Email,
                        Amount = topupAmount,
                        IsCard = false,
                        IsSuccess = true,
                        SaveCard = orderData.SaveCard,
                        AutoTopup = orderData.AutoTopupInfo == default ? false : orderData.AutoTopupInfo.Status,
                    });
                }
            }
            if (orderData.CheckoutType == (int) CheckOutType.Bundle)
            {
                _airshipService.HandleBundlePurchaseTagsAndEvents(new BundlePurchaseEventData
                {
                    Email = orderDetails.Email,
                    Amount = planAmount,
                    AutoRenew = orderData.BundleInfo == default ? false : orderData.BundleInfo.IsRenewable,
                    IsCard = false,
                    IsSuccess = true,
                    BundleType = planType,
                    BundleCategory = planCategory,
                    BundleName = planName,
                    Destination = planCountryCode,
                    SaveCard = orderData.SaveCard,
                });
            }
        }
        #endregion

        //Hande success case
        return Result<PaypalResponse>.Success(new PaypalResponse() { OrderId = orderId }, _localizer[CustomStatusKey.Success]);
    }

    private async Task PaymentFulfillment(string transactionId, string msisdn, string emailAddress, float discount, bool IsCardPayment)
    {
        var fulfillmentItems = await _unitOfWork.PaymentRepo.GetFulfillmentRecord(transactionId);
        if (fulfillmentItems != null)
        {
            foreach (var item in fulfillmentItems)
            {
                var response = new FulfillmentResponse();

                if (IsCardPayment)
                {
                    response = await _unitOfWork.PaymentRepo.CardFullfilment(
                       transactionId,
                       item.BundleRef,
                       item.Amount.ToString(),
                       msisdn,
                       emailAddress,
                       ProductCode.NOWPAYG.ToString());
                }
                else
                {
                    response = await _unitOfWork.PaymentRepo.DirectPaypalFullfilment(
                      transactionId,
                      item.BundleRef,
                      item.Amount.ToString(),
                      msisdn,
                      emailAddress,
                      ProductCode.NOWPAYG.ToString());
                }

                //Handle fulfillment errors
                if (response != null && response.ErrorCode > 0)
                {
                    //Send error email to customer
                    string Message = $"Now Mobile \r\n Transaction Sucessfull ! \r\n Fullfillment Failed! " +
                                     $"\r\nTransaction Id: {transactionId}";

                    await _mailService.SendEmailToCustomer(emailAddress, Message, TemplateSubject.FullfilmentFailed);

                    //Handle Fulfilment record
                    await _unitOfWork.PaymentRepo.UpdateFulfillmentItems(item.Id, response.ErrorMessage!, true);
                }
                else
                {
                    //Handle fulfillment success
                    await _unitOfWork.PaymentRepo.UpdateFulfillmentItems(item.Id, null!, true);

                }
            }
        }
    }

    private static CheckOutType GetCheckoutType(PaymentCreditSimInfo creditSimInfo, PaymentTopupInfo topupInfo, PaymentBundleInfo bundleInfo)
    {
        if (creditSimInfo != null && creditSimInfo.OrderId > 0)
        {
            return CheckOutType.CreditSim;
        }
        else if (topupInfo != null
            && topupInfo.TopupAmount > 0
            && bundleInfo != null
            && bundleInfo.BundleId > 0)
        {
            return CheckOutType.TopupBundle;
        }
        else if (topupInfo != null
            && topupInfo.TopupAmount > 0)
        {
            return CheckOutType.TopUp;
        }
        else
        {
            return CheckOutType.Bundle;
        }
    }

    #endregion

    #region InAppReceipt
    public async Task<Result<InAppReceiptResponse>> VerifyInAppPurchaseReceipt(InAppReceiptRequest request)
    {
        var response = new Result<InAppReceiptResponse>();

        if (!_appleReceiptVerificationSettings.IsActive)
        {
            return response;
        }

        if (request == null 
            || request.AppVersion == null 
            || request.AppVersion != _appleReceiptVerificationSettings.DisablePaymentVersion)
        {
            return response;
        }

        var whiteListedNumbers = _appleReceiptVerificationSettings.WhiteListNumbers;
        if (!whiteListedNumbers!.Contains(request.Msisdn!))
        {
            return response;
        }

        var verifyReceiptResponse = new InAppReceiptResponse();

        var _httpClient = _httpClientFactory.CreateClient();
        var json = new JObject(new JProperty("receipt-data", request.Receipt)).ToString();
        var content = new StringContent(json, Encoding.UTF8, "application/json");
        var output = await _httpClient.PostAsync(_appleReceiptVerificationSettings.LiveUrl, content);
        string result = await output.Content.ReadAsStringAsync();
        var inAppPurchaseReceipt = JsonConvert.DeserializeObject<InAppPurchaseReceipt>(result);
        if (inAppPurchaseReceipt != null && inAppPurchaseReceipt.Status == 21007)
        {
            //Valid sandbox receipt and tester
            //Try again using the sandbox endpoint
            var sandBoxOutPut = await _httpClient.PostAsync(_appleReceiptVerificationSettings.SandboxUrl, content);
            result = await sandBoxOutPut.Content.ReadAsStringAsync();

            //_logger.Debug("Before: " + JsonConvert.SerializeObject(inAppPurchaseReceipt));

            inAppPurchaseReceipt = JsonConvert.DeserializeObject<InAppPurchaseReceipt>(result);

            //_logger.Debug("After: " + JsonConvert.SerializeObject(inAppPurchaseReceipt));
        }

        var topupAmount = 0m;

        if (inAppPurchaseReceipt!.Status == 0 &&
            !String.IsNullOrEmpty(inAppPurchaseReceipt.Receipt.Bid) &&
            inAppPurchaseReceipt.Receipt != null &&
            !String.IsNullOrEmpty(inAppPurchaseReceipt.Receipt.Bid) &&
            inAppPurchaseReceipt.Receipt.Bid == "com.distribution.nowmobile")
        {
            var productId = inAppPurchaseReceipt.Receipt.InAppData[0].ProductId;
            var purchaseAmount = productId.Replace("NowMobile_GBP_", "").Trim();
            topupAmount = Convert.ToDecimal(purchaseAmount, CultureInfo.InvariantCulture);


            //Update account balance here!
            var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn!);

            await _unitOfWork.PaymentRepo.ApplyInAppPurchaseCredit(topupAmount, inAppPurchaseReceipt.Receipt.InAppData[0].TransactionId, msisdnDetails?.AccountId!);
            //Get Updated account balance here!
            var UpdatedmsisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn!);

            verifyReceiptResponse.Credit = topupAmount.ToString(CultureInfo.InvariantCulture);
            verifyReceiptResponse.Balance = UpdatedmsisdnDetails?.Credit.ToString(CultureInfo.InvariantCulture);
            verifyReceiptResponse.TransactionId = Guid.NewGuid().ToString();
            response.Status = true;
            response.Message = "Successful in-app purchase";
            response.Data = verifyReceiptResponse;
        }
        else
        {
            verifyReceiptResponse.TransactionId = Guid.NewGuid().ToString();
            response.Status = false;
            response.Message = "Receipt verification failed";
            response.Data = verifyReceiptResponse;
        }
        return response;
    }
    #endregion

    #endregion

    #region Helper

    private static string GetViewHtml<T>(string viewName, T mailTemplateModel)
    {
        string template = GetView(viewName);

        IRazorEngine razorEngine = new RazorEngine();
        IRazorEngineCompiledTemplate modifiedTemplate = razorEngine.Compile(template);

        return modifiedTemplate.Run(mailTemplateModel);
    }

    private static string GetView(string templateName)
    {
        string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
        string tmplFolder = Path.Combine(baseDirectory, "Views");
        string filePath = Path.Combine(tmplFolder, $"{templateName}.cshtml");
        // string filePath = Path.Combine("C:\\workspace\\NowMobile-CleanArchitecture\\NowMobile-CleanArchitecture\\NowMobile.Api\\Views", $"{templateName}.cshtml");
        using var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using var sr = new StreamReader(fs, Encoding.Default);
        string mailText = sr.ReadToEnd();
        sr.Close();

        return mailText;
    }

    #endregion
}
