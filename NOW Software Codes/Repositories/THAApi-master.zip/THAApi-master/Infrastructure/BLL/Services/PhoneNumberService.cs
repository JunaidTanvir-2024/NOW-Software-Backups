﻿using System;
using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Models.Contracts.Request;
using PhoneNumbers;
using Twilio.Types;

namespace Infrastructure.BLL.Services
{
    /// <summary>
    /// Gets the full and validated phone number 
    /// </summary>
    public class PhoneNumberService : IPhoneNumberService
    {
        private readonly PhoneNumberUtil phoneNumberUtil;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="phoneNumberUtil">Instance of PhoneNumberUtil</param>
        public PhoneNumberService(PhoneNumberUtil phoneNumberUtil)
        {
            this.phoneNumberUtil = phoneNumberUtil;
        }

        /// <summary>
        /// Gets the full and validated phone number
        /// </summary>
        /// <param name="originator">Sender phone number, this must be in E164 format</param>
        /// <param name="contact">Target phone number, this can be in either national format or E164 format</param>
        /// <returns>Target phone number in E164 without the + infront</returns>
        public string GetFullNumber(string originator, string contact)
        {
            try
            {
                var originRegion = GetCountry(originator);

                if (originRegion == null)
                {
                    return null;
                }

                var result = phoneNumberUtil.Parse(contact, originRegion);

                return phoneNumberUtil.IsValidNumber(result) ?
                    phoneNumberUtil.Format(result, PhoneNumberFormat.E164).Replace("+", "") :
                    null;
            }
            catch (NumberParseException)
            {
                return null;
            }
        }

        /// <summary>
        /// Gets the region from a phone number
        /// </summary>
        /// <param name="originator">Phone number, this must be in E164 format</param>
        /// <returns>Country Code</returns>
        public string GetCountry(string originator)
        {
            try
            {
                originator = originator.Trim();

                if (!originator.StartsWith("+"))
                {
                    originator = $"+{originator}";
                }

                if (originator.StartsWith("+1"))
                {
                    string countryCode = null;
                    string[] countries = { "US", "CA" };
                    String phoneNumber = originator;

                    foreach (var c in countries)
                    {
                        bool isValid = phoneNumberUtil.IsPossibleNumber(phoneNumber, c);
                        if (isValid)
                        {
                            try
                            {
                                var number = phoneNumberUtil.Parse(phoneNumber, c);
                                isValid = phoneNumberUtil.IsValidNumberForRegion(number, c);
                                if (isValid)
                                {
                                    countryCode = c;
                                }
                            }
                            catch (Exception e)
                            {
                                countryCode = null;
                            }
                        }
                    }

                    if (string.IsNullOrEmpty(countryCode))
                    {
                        var number = phoneNumberUtil.Parse(originator, "");
                        return phoneNumberUtil.GetRegionCodeForNumber(number);
                    }

                    return countryCode;
                }
                else
                {
                    var number = phoneNumberUtil.Parse(originator, "");
                    return phoneNumberUtil.GetRegionCodeForNumber(number);
                }
            }
            catch (NumberParseException)
            {
                return null;
            }
        }
        public string GetCountryIsoCode(string msisdn)
        {
            try
            {
                var phoneNumber = phoneNumberUtil.Parse(msisdn, null);
                var sss = phoneNumberUtil.GetRegionCodeForNumber(phoneNumber);
                var sss2 = phoneNumberUtil.GetCountryCodeForRegion(sss);

                return sss;
            }
            catch (NumberParseException)
            {
                return null;
            }
        }
    }
}
