﻿namespace NTCB.Api.Features.DTOne;

public interface IDTOneRepository
{
    Task<bool> UpdateCallbackRecord(string transactionReferenceId, string transactionStatus, string dtOneJsonResponse);
    Task<bool> UpdateTransactionRecord(string transactionReferenceId, string transactionStatus, string dtOneJsonResponse, string? transactionErrorMessage);
    Task<bool> VerifyTransactionStatus(string transactionReferenceId);
}