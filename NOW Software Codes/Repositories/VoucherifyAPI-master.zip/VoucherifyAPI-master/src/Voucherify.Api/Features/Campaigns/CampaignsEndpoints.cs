using Voucherify.Api.Features.Campaigns.Requests;
using Voucherify.Core.Commons.Filters;

namespace Voucherify.Api.Features.Campaigns;

public static class CampaignsEndpoints
{
    private const string EndpointPrefix = "/api/campaigns";
    private const string EndpointTag = "Campaigns Endpoints";

    public static void AddCampaignsEndpoints(this WebApplication app)
    {
        var campaignEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);
        campaignEndpoints.MapGet("", GetCampaigns)
            .AddEndpointFilter<FluentValidationFilter<GetCampaignsRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        campaignEndpoints.MapGet("/{campaignNameOrId}", GetCampaign)
            .AddEndpointFilter<FluentValidationFilter<GetCampaignRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

    }
    private static async Task<IResult> GetCampaigns(ICampaignsHandler campaignsHandler, [AsParameters] GetCampaignsRequest request)
    {
        var result = await campaignsHandler.GetCampaignsList(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetCampaign(ICampaignsHandler campaignsHandler, [AsParameters] GetCampaignRequest request)
    {
        var result = await campaignsHandler.GetSpecificCampaign(request);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
}
