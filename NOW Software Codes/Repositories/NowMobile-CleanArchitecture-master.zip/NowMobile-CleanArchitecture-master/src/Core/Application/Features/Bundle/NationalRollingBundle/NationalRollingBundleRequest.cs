using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.NationalRollingBundle;

public sealed class NationalRollingBundleRequest : IRequest<Result<List<BundleInfo>>>
{
    public string Msisdn { get; set; } = default!;
}
