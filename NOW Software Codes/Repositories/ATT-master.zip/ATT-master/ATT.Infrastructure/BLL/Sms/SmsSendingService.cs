﻿using ATT.Infrastructure.BLL.Common;
using ATT.Infrastructure.DAL.SmsLogging;
using ATT.Infrastructure.Helper;
using ATT.Models.Configurations;
using ATT.Models.Constants.Enums;
using ATT.Models.Constants.SmsTemplates;
using ATT.Models.Contracts.Common;
using ATT.Models.Database;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Threading.Tasks;
using Twilio.Rest.Api.V2010.Account;

namespace ATT.Infrastructure.BLL.Sms
{
    public class SmsSendingService : ISmsSendingService
    {
        private ICommon_BL _common_BL;
        private ISmsLoggingRepository _smsLoggingRepository;
        private ILogger _logger;
        private SmsServiceConfig _smsServiceConfig;
        public SmsSendingService(ICommon_BL common_BL, ISmsLoggingRepository smsLoggingRepository, ILogger logger,IOptions<SmsServiceConfig> smsServiceConfig)
        {
            _common_BL = common_BL;
            _smsLoggingRepository = smsLoggingRepository;
            _logger = logger;
            _smsServiceConfig = smsServiceConfig.Value;
        }
        public async Task SendTopupSmsDetailsToRecipients(TopupSmsDetailsModel topupSmsDetailsModel)
        {
            try
            {
                //if sms service is not enabled, it will be log in the table
                if (!_smsServiceConfig.EnableSmsSendingService)
                {
                    await LogSmsTransactionResponse(topupSmsDetailsModel.FromMsisdn, topupSmsDetailsModel.ToMsisdn, string.Empty, topupSmsDetailsModel.TransactionId, (int)SmsStatusEnum.Error, "SMS service is disabled", string.Empty, Guid.Empty.ToString());
                    return;
                }
                // if pin code is null or empty check ReceiptText if this is also null, no need to send sms. log it in db 
                if (string.IsNullOrEmpty(topupSmsDetailsModel.PinCode) && string.IsNullOrEmpty(topupSmsDetailsModel.ReceiptText))
                {
                    await LogSmsTransactionResponse(topupSmsDetailsModel.FromMsisdn, topupSmsDetailsModel.ToMsisdn, string.Empty, topupSmsDetailsModel.TransactionId, (int)SmsStatusEnum.Error, "Pin code and ReceiptText is empty", string.Empty, Guid.Empty.ToString());
                    return;
                }

                if (!string.IsNullOrEmpty(topupSmsDetailsModel.ReceiptText) && string.IsNullOrEmpty(topupSmsDetailsModel.PinCode))
                {
                    if (topupSmsDetailsModel.ReceiptText.Contains("Pin:", StringComparison.OrdinalIgnoreCase))
                    {
                        int pinStartIndex = topupSmsDetailsModel.ReceiptText.IndexOf("Pin:");
                        topupSmsDetailsModel.PinCode = topupSmsDetailsModel.ReceiptText.Substring(pinStartIndex);
                    }
                }

                //calling the sms service to send the sms to sender               
                topupSmsDetailsModel.SmsToSend = SmsTemplate.FundsTransfered
                    .Replace("{AmountTransfered}", topupSmsDetailsModel.AmountTransfered)
                    .Replace("{PinCode}", topupSmsDetailsModel.PinCode);

                //sending sms to receiver 
                await SendSmsAndLog(topupSmsDetailsModel);

            }
            catch (Exception ex)
            {
                _logger.Error($"  \"/SendTopupSmsDetailsToRecipients\"  Failed, Parameters- sourceMSISDN: {topupSmsDetailsModel.ToMsisdn}, destinationMSISDN: {topupSmsDetailsModel.FromMsisdn}, transactionId:{topupSmsDetailsModel.TransactionId}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");
                var errorResult = new { errorCode = 2, status = "Failure", message = ex.Message };

            }
        }
        /// <summary>
        /// This method will send sms and log the data in the db
        /// </summary>
        /// <param name="topupSmsDetailsModel"></param>
        /// <param name="isSender"></param>
        /// <returns></returns>
        private async Task SendSmsAndLog(TopupSmsDetailsModel topupSmsDetailsModel, bool isSender)
        {
            string smsErrorMessage = string.Empty;            

            string recipientMsisdn = string.Empty;
            string fromMsisdn = null;
            string toMsisdn = null;

            if (isSender)
            {                
                recipientMsisdn = topupSmsDetailsModel.FromMsisdn;
                fromMsisdn = topupSmsDetailsModel.FromMsisdn;
                toMsisdn = null;
            }
            else
            {
                recipientMsisdn = topupSmsDetailsModel.ToMsisdn;
                toMsisdn = topupSmsDetailsModel.ToMsisdn;
                fromMsisdn = null;
            }

            //sending message to receiver about the top up transfer details
            var smsSendResponse = await SendSms(recipientMsisdn, topupSmsDetailsModel.SmsToSend);

            if (smsSendResponse.status == (int)SmsStatusEnum.Error && smsSendResponse.smsSid == null)//in case of exception if the message service not responding and error occurs 
            {
                smsErrorMessage = smsSendResponse.message;
                smsSendResponse.smsSid = Guid.Empty.ToString();
            }

            await LogSmsTransactionResponse(fromMsisdn, toMsisdn, topupSmsDetailsModel.PinCode, topupSmsDetailsModel.TransactionId, smsSendResponse.status, smsErrorMessage, topupSmsDetailsModel.SmsToSend, smsSendResponse.smsSid);

        }
        private async Task SendSmsAndLog(TopupSmsDetailsModel topupSmsDetailsModel)
        {
            string smsErrorMessage = string.Empty;
          
            //sending message to receiver about the top up transfer details
            var smsSendResponse = await SendSms(topupSmsDetailsModel.ToMsisdn, topupSmsDetailsModel.SmsToSend);

            if (smsSendResponse.status == (int)SmsStatusEnum.Error && smsSendResponse.smsSid == null)//in case of exception if the message service not responding and error occurs 
            {
                smsErrorMessage = smsSendResponse.message;
                smsSendResponse.smsSid = Guid.Empty.ToString();
            }

            await LogSmsTransactionResponse(topupSmsDetailsModel.FromMsisdn, topupSmsDetailsModel.ToMsisdn, topupSmsDetailsModel.PinCode, topupSmsDetailsModel.TransactionId, smsSendResponse.status, smsErrorMessage, topupSmsDetailsModel.SmsToSend, smsSendResponse.smsSid);
        }
        /// <summary>
        /// This method will send the top sms to recipient
        /// </summary>
        /// <param name="recipientMsisdn"></param>
        /// <param name="smsToSend"></param>
        /// <param name="statusCallbackUrl"></param>
        /// <returns></returns>
        private async Task<(int status, string message, string smsSid)> SendSms(string recipientMsisdn, string smsToSend, string statusCallbackUrl = null)
        {
            try
            {
                var response = await _common_BL.SendTwilioSmsWithCallback(recipientMsisdn, smsToSend);
                if (response != null && MessageResource.StatusEnum.Failed == response.Status)
                {
                    return ((int)SmsStatusEnum.Error, response.ErrorMessage, response.Sid);
                }
                return ((int)SmsStatusEnum.Pending, response.Body, response.Sid);
            }
            catch (Exception ex)
            {
                _logger.Error($"  \"/SendSms\"  Failed, Parameters- recipientMsisdn: {recipientMsisdn}, smsToSend:{smsToSend}  Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");
                return ((int)SmsStatusEnum.Error, $"Unable to send message. Message:{ex.ToString()}", null);
            }
        }
        /// <summary>
        /// This method will 
        /// </summary>
        /// <param name="fromMsisdn"></param>
        /// <param name="toMsisdn"></param>
        /// <param name="pinCode"></param>
        /// <param name="transactionId"></param>
        /// <param name="smsStatus"></param>
        /// <param name="smsError"></param>
        /// <param name="smsText"></param>
        /// <param name="smsSID"></param>
        /// <returns></returns>
        private async Task LogSmsTransactionResponse(string fromMsisdn, string toMsisdn, string pinCode, string transactionId, int smsStatus, string smsError, string smsText, string smsSID)
        {
            try
            {
                //inserting sms log response in to logging table
                AttSmsLogging attSmsLogging = new AttSmsLogging();
                attSmsLogging.TransactionId = transactionId;
                attSmsLogging.SenderMsisdn = fromMsisdn;
                attSmsLogging.ReceiverMsisdn = toMsisdn;
                attSmsLogging.PinCode = pinCode;
                attSmsLogging.SmsStatus = smsStatus;
                attSmsLogging.SmsError = smsError;
                attSmsLogging.SmsText = smsText;
                attSmsLogging.UnixTimeStamp = TimeConverter.GetUnixTimeStamp();
                attSmsLogging.SmsSid = smsSID;
                await _smsLoggingRepository.InsertSmsLog(attSmsLogging);
            }
            catch (Exception ex)
            {
                _logger.Error($"  \"/LogSmsTransactionResponse\"  Failed, Object - sourceMSISDN: {toMsisdn}, destinationMSISDN: {fromMsisdn}, transactionId: {transactionId}, pinCode:{pinCode},smsSID: {smsSID}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");
            }
        }
    }
}
