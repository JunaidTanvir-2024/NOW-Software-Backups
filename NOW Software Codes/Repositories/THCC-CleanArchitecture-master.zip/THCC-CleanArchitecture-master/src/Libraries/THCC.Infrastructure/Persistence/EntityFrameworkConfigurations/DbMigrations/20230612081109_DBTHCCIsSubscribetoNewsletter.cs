﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace THCC.Infrastructure.Persistence.EntityFrameworkConfigurations.DbMigrations
{
    /// <inheritdoc />
    public partial class DBTHCCIsSubscribetoNewsletter : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsSubscribedToNewsletter",
                table: "Users",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsSubscribedToNewsletter",
                table: "Users");
        }
    }
}
