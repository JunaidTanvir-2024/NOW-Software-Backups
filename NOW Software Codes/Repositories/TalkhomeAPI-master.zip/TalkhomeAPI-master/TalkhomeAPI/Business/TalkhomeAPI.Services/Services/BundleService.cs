﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Services.Interfaces;

namespace TalkhomeAPI.Services.Services
{
    public class BundleService : IBundleService
    {
        private readonly IBundleRepository _bundleRepository;

        public BundleService(IBundleRepository bundleRepository)
        {
            _bundleRepository = bundleRepository;
        }
        public async Task<IEnumerable<BundlesCountries>> GetCountriesByBundle()
        {
            return await _bundleRepository.GetCountriesByBundle();
        }
        public async Task<IEnumerable<Bundles>> GetBundleByCountry(string ServiceId)
        {
            return await _bundleRepository.GetBundleByCountry(ServiceId);
        }
        public async Task<Bundles> GetBundleById(string Id) 
        {
            return await _bundleRepository.GetBundleById(Id);
        }
    }
}
