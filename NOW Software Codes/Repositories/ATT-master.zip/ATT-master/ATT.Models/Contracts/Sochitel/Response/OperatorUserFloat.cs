﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Response
{
    public class OperatorUserFloat
    {
        public decimal @operator { get; set; }
        public decimal user { get; set; }
    }
}
