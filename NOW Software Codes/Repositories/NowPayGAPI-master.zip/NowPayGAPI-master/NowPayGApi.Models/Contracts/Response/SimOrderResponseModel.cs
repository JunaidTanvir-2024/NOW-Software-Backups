﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class SimOrderResponseModel
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public string City { get; set; }
        public DateTime OrderDateTime { get; set; }
        public bool IsReplacement { get; set; }
        public bool IsDispatched { get; set; }
        public DateTime? DispatchDateTime { get; set; }
        public string DispatchedByName { get; set; }
    }
}