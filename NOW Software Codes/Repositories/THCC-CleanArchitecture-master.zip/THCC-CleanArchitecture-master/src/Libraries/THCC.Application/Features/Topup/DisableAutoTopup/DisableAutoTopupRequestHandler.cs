﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

namespace THCC.Application.Features.Topup.DisableAutoTopup
{
    public class DisableAutoTopupRequestHandler : IRequestHandler<DisableAutoTopupRequest, object>
    {
        #region Fields 

        private readonly IMapper _mapper;
        private readonly ICurrentUser _currentUser;
        private readonly IUserRepository _userRepository;
        private readonly ITopupRepository _topupRepository;
        private readonly TopupSettings _topupSettings;

        #endregion

        #region Ctors

        public DisableAutoTopupRequestHandler(
            IMapper mapper,
            ICurrentUser currentUser,
            IUserRepository userRepository,
            ITopupRepository topupRepository,
            IOptions<TopupSettings> topupSettings)
        {
            _mapper = mapper;
            _currentUser = currentUser;
            _userRepository = userRepository;
            _topupRepository = topupRepository;
            _topupSettings = topupSettings.Value;
        }

        #endregion

        #region Method
        public async Task<object> Handle(DisableAutoTopupRequest request, CancellationToken cancellationToken)
        {
            var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
            if (userProduct == null)
            {
                return ErrorResult.Failure(CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
            }
            var autoTopup = await _topupRepository.GetAutoTopup(userProduct!.Product!, _currentUser.GetUserEmail()!);
            if (autoTopup != null && autoTopup?.Status == true)
            {
                await _topupRepository.DisableAutoTopup(userProduct.Product!);
            }
            return Unit.Value;
        }

        #endregion
    }
}
