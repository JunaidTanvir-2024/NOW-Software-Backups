﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Ding.Response
{
    public class DingTopUpResponse
    {
        public int ResultCode { get; set; }
        public List<ErrorCodes> ErrorCodes { get; set; }
        public TransferRecord transferRecord { get; set; }         
    }

    public class TransferRecord
    {
        public TransferId transferId { get; set; }
        public string SkuCode { get; set; }
        public DingRates price { get; set; }
        public decimal CommissionApplied { get; set; }
        public string ReceiptText { set; get; }
        public ReceiptParams ReceiptParams { set; get; }
    }
    public class TransferId
    {
        public string TransferRef { get; set; }
        public string DistributorRef { get; set; }
    }
    public class ReceiptParams
    {
        public string Pin { set; get; }
    }
}
