using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DC.Infrastructure.Sms.Common;
public class SmsMeta
{
    internal static class Endpoints
    {
        public const string MarketingSMS = "api/v1/SMS";
    }
}
