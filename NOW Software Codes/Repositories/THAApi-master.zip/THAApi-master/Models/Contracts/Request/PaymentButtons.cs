﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
   
    public class PaymentButtons
    {
        public string title { get; set; }

        public string link { get; set; }

        public string colour { get; set; }
    }
}
