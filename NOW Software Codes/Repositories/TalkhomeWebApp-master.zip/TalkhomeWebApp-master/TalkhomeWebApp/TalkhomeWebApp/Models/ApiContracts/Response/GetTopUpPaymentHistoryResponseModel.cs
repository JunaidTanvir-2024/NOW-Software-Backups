﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class GetTopUpPaymentHistoryResponseModel
    {
        public IEnumerable<DBTopUpPaymentHistory> TopUpHistory { get; set; }
    }

    public class DBTopUpPaymentHistory
    {
        public DateTime TransDate { get; set; }
        public string formattedTransDate { get; set; }
        public string Amount { get; set; }
        public string Method { get; set; }
        public string Reference { get; set; }
    }
}
