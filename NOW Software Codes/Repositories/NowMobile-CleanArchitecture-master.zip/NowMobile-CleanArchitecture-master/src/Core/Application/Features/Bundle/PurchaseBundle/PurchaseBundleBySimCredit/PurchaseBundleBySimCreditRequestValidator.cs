﻿namespace Application.Features.Bundle.PurchaseBundle.PurchaseBundleBySimCredit;

public class PurchaseBundleBySimCreditRequestValidator : AbstractValidator<PurchaseBundleBySimCreditRequest>
{
    public PurchaseBundleBySimCreditRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
        RuleFor(p => p.BundleId).Cascade(CascadeMode.Stop).NotNull().NotEmpty().Must(p => p > 0).WithMessage("Invalid Bundle Reference");
    }
}
