﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PaymentsApi.Models.Utility
{
    public interface IApiCall
    {
        Task<HttpResponseMessage> Get(string Uri, string authToken, params string[] parameters);
        Task<HttpResponseMessage> Post(string Uri, object model, string AuthToken);
    }
}
