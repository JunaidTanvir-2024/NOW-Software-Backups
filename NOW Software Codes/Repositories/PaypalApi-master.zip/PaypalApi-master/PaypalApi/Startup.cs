﻿
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PaypalApi.Infrastructure.BLL;
using PaypalApi.Infrastructure.DAL;
using PaypalApi.Models.Configurations;
using PaypalApi.Models.Contracts.Request;
using Serilog;
using Swashbuckle.AspNetCore.Swagger;
using System.IO;

namespace PaypalApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddSingleton((ILogger)new LoggerConfiguration()
             .MinimumLevel.Debug()
             .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "PaypalApi-log-{Date}.txt"))
             .CreateLogger());

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);            
            services.Configure<ConnectionString>(Configuration.GetSection("ConnectionStrings"));
            services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));
            services.Configure<PaypalConfig>(Configuration.GetSection("Paypal"));
            services.Configure<SmsConfig>(options => Configuration.GetSection("SmsConfig").Bind(options));
            services.Configure<SmtpConfig>(options => Configuration.GetSection("Smtp").Bind(options));
            services.Configure<PushConfig>(options => Configuration.GetSection("PushConfig").Bind(options));
            services.Configure<FailureTopUpEmailConfig>(options => Configuration.GetSection("FailureTopUpEmailConfig").Bind(options));
            services.AddTransient<IPaypal_BL, Paypal_BL>();            
            services.AddTransient<IPaypalDb_DL, PaypalDb_DL>();
            services.AddSingleton<IApiCall, ApiCall>();
            services.AddSingleton<IAccessToken, AccessToken>();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "Paypal API",
                    Description = "Paypal Api for payments.",
                    TermsOfService = "None",
                    Contact = new Contact() { Name = "ATT", Email = "hello@talkhomemobile.com", Url = "https://talkhome.co.uk/" }
                });
            });

            //services.AddDbContext<DatabaseContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            //app.UseMiddleware<DogStatsDMiddleware>();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            //app.UseHttpsRedirection();
            app.UseMvc();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Paypal API V1");
            });
        }
    }
}
