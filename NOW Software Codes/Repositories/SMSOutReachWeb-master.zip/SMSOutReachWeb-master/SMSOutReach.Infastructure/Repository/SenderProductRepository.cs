﻿using Dapper;
using Microsoft.Extensions.Options;
using SMSOutReach.Infastructure.Interface;
using SMSOutReach.Modal;
using SMSOutReach.Modal.Xeebi;
using SMSOutReach.Model.Configurations;
using SMSOutReach.Model.Connections;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace SMSOutReach.Infastructure.Repository
{
    public class SenderProductRepository : ISenderProduct
    {
        
        private IDbConnectionSettings DbConnection;
       

        public SenderProductRepository(IOptions<ConnectionString> connectionString)
        {

            DbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));

        }

        public List<SenderProduct> GetSenderProducts()
        {
            var product = DbConnection.SqlConnection.Query<SenderProduct>("Sp_Ui_GetAllSenderProducts");
            var resultSet = product.ToList();
            return resultSet;
        }





    }
}
