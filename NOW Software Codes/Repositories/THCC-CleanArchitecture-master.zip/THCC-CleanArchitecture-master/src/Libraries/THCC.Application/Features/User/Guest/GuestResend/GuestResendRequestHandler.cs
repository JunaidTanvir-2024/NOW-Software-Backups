﻿using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.Guest.GuestResend;

internal class GuestResendRequestHandler : IRequestHandler<GuestResendRequest, object>
{
    #region Fields 

    private readonly IOtpService _otpService;
    private readonly IUserRepository _userRepository;
    private readonly IMailService _mailService;

    #endregion

    #region Ctors

    public GuestResendRequestHandler(
        IOtpService otpService,
        IUserRepository userRepository,
        IMailService mailService)
    {
        _otpService = otpService;
        _userRepository = userRepository;
        _mailService = mailService;
    }

    #endregion

    #region Handler Method

    public async Task<object> Handle(GuestResendRequest request, CancellationToken cancellationToken)
    {
        request.Email = request.Email.Trim();

        //Check if email already attached
        var user = await _userRepository.GetUserByEmailAsync(request.Email);
        if (user == null)
        {
            return ErrorResult.Failure(CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
        }

        var token = await _userRepository.GenerateEmailConfirmationTokenAsync(user!);

        //Create Email Otp
        var emailOtp = await _otpService.SaveToken(request.Email, token, OtpType.SignUp);
        await _mailService.SendEmailVerificationEmail(request.Email, emailOtp);

        return Unit.Value;
    }

    #endregion

}