﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class FaceBookConfig
    {
        public string ApiEndpoint { get; set; }
        public string APPID { get; set; }
        public string APPAccessToken { get; set; }
        public bool IsActive { get; set; }
    }
}
