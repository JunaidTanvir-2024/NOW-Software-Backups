﻿namespace Application.Features.Account.DeleteAccount;
public class DeleteAccountRequest : IRequest<Result<object>>
{
}
