using Application.Features.Bundle.Bundle;

namespace TestServiceApi.Controllers;

public class BundleController : BaseApiController
{
    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> UnSubscribeBundle([FromQuery] UnSubscribeBundlesRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

}