﻿namespace Application.Features.Bundle;
public class OfferBundleValidationResponseModel
{
    public int ErrorCode { get; set; }
    public string ErrorMessage { get; set; } = default!;
}
