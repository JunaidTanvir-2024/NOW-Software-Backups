﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.User.ForgotPassword.ForgotPasswordResend;
public class ForgotPasswordResendRequest : IRequest<object>
{
    public string Email { get; set; } = default!;

    [JsonIgnore]
    public string? IpAddress { get; set; } = null;
}
public class ForgotPasswordResendValidator : AbstractValidator<ForgotPasswordResendRequest>
{
    public ForgotPasswordResendValidator(ICommonService commonService)
    {
        RuleFor(data => data.Email)
            .NotNull().NotEmpty()
            .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
            .Must(p => commonService.IsValidEmailAddress(p))
            .WithMessage("Invalid Email Address");
    }
}
