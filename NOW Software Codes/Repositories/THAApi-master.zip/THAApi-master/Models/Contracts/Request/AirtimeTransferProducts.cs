﻿using Models.Contracts.Request.Voucherify;
using Models.Enums;
using Models.Services.Airship;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{

    public class TransFerToTransactionNumbers
    {
        public string recipientNumber { get; set; }
    }
    public class AirtimeTransferProducts
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public payload payload { get; set; }
    }

    public class Product
    {
        public string clientccy { get; set; }
        public string receiverccy { get; set; }
        public string product { get; set; }
        public string itemPriceClientccy { get; set; }
        public string transactionfeeClientccy { get; set; }
        public string totalPriceClientccy { get; set; }
    }

    public class operators
    {
        public string id { get; set; }
        public string name { get; set; }
        public string country { get; set; }
        public string nowtelTransactionReference { get; set; }
        public string iconUri { get; set; }
        public IList<Product> products { get; set; }
    }

    public class payload
    {
        public IList<operators> operators { get; set; }
    }

    public class AirtimeTransferExecute
    {
        public int errorCode { get; set; }
        public string status { get; set; }
        public string message { get; set; }
        public decimal amount { get; set; }
        public string currency { get; set; }
        public string reference { get; set; }
        public string pinCode { set; get; }
        public VoucherifyAirshipInfo VoucherifyInfo { get; set; }

    }

    public class SochitelValidateExec
    {
        public string nowtelTransactionReference { get; set; }
        public decimal transferAmount { get; set; }
    }
    public class DBProduct
    {
        public string GUID { get; set; }
        public string fromCurrency { get; set; }
        public string toCurrency { get; set; }
        public string fromMsisdn { get; set; }
        public string tomsisdn { get; set; }
        public string toAmount { get; set; }
        public string fromAmount { get; set; }
        public string account { get; set; }
        public string CustomerChargeValue { get; set; }
        public string product { get; set; }
        public string operatorCountryName { get; set; }
        public string operatorLogoUrl { get; set; }
        public string operatorName { get; set; }
    }
    public class SochitelValidateCustomer
    {
        public int errorCode { get; set; }
        public int isAllowed { get; set; }
        public string Message { get; set; }
    }

    public class AirtimeTransferHstory
    {
        public string Amount { get; set; }
        public string CustomerServiceid { get; set; }
        //public string NowtelTransactionReference { get; set; }
        public string RecipientNumber { get; set; }
        public string Status { get; set; }
        public string Transactioncurrency { get; set; }
        public DateTime? TrxDateTIme { get; set; }
        public string Trxtimestamp { get; set; }
        public string OperatorName { get; set; }
        public string operatorLogoUrl { get; set; }
        //public int Type { get; set; } // 1 -att ,2 - sent app2app ,3 -received app2app
        public string TransactionRef { get; set; }
        public string PaymentMethod { get; set; }

        //mobile team not using therese keys
        //public string OperaterID { get; set; }
        //public string ProductID { get; set; }
        //public string reference { get; set; }
        //public string message { get; set; }
    }


    public class ATTTransactions
    {
        public IEnumerable<AirtimeTransferHstory> transactions { get; set; }
    }

    public class TransFerTotransferConfirm
    {
        public string nowtelTransactionReference { get; set; }
        public int operatorid { get; set; }
        public string product { get; set; }
        public string messageToRecipient { get; set; }
        public string advertiserID { get; set; }
        //public AppsFlyerInfo AppsFlyerInfo { get; set; }
        public string AppsFlyerId { get; set; }
        public int DeviceType { get; set; }
        public bool IsTransferRequest { get; set; } = false;
    }
    public class TransFerTotransferConfirmV2 : TransFerTotransferConfirm
	{
        public DiscountCodeType DiscountCodeType { get; set; }
        public string DiscountCode { get; set; }
    }

    public class TransferToTransactionsListRequest
    {
        public string clientNumber { get; set; }
        public int maxItems { get; set; }
    }

    public class TransferToCountries
    {
        public string ISOCode2 { get; set; }
        public string TransfertoCountryID { get; set; }
    }
}
