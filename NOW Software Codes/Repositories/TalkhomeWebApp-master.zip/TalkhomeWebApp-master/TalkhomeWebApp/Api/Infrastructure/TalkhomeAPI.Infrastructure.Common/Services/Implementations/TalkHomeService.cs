﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class TalkHomeService : ITalkHomeService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger _logger;
        private readonly TalkHomeConfig _talkHomeConfig;

        public TalkHomeService(HttpClient httpClient,
                            IOptions<TalkHomeConfig> talkHomeConfig,
                            ILogger logger)
        {
            _httpClient = httpClient;
            _logger = logger;
            _talkHomeConfig = talkHomeConfig.Value;
        }

        public async Task<GenericApiResponse<SignUpResponse>> SignUp(SignUpRequest request)
        {
            string endpoint = _talkHomeConfig.ApiEndPoint;

            var Json = JsonConvert.SerializeObject(request);

            _httpClient.DefaultRequestHeaders.Clear();

            _httpClient.DefaultRequestHeaders.Add("NowtelAuth", _talkHomeConfig.NowtelAuthToken);

            var content = new StringContent(Json, Encoding.UTF8, "application/json");

            var output = await _httpClient.PostAsync(endpoint, content);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<GenericApiResponse<SignUpResponse>>(outputData);
            }
            else
            {
                _logger.Error($"Class: TalkHomeService, Method: SignUp, " +
                    $"ResponseCode :{JsonConvert.SerializeObject(output.StatusCode)}, " +
                    $"Response :{JsonConvert.SerializeObject(await output.Content.ReadAsStringAsync())}, " +
                    $"Request: {JsonConvert.SerializeObject(request)}");
                return null;
            }
        }
        public async Task<GenericApiResponse<SignUpResponse>> SignUpWithPreAuth(SignUpWithPreAuthRequest request, string token)
        {
            string endpoint = _talkHomeConfig.SignUpPreAuthAEndPoint;

            endpoint = endpoint.Replace("{token}", token);

            var Json = JsonConvert.SerializeObject(request);

            _httpClient.DefaultRequestHeaders.Clear();

            _httpClient.DefaultRequestHeaders.Add("NowtelAuth", _talkHomeConfig.NowtelAuthToken);

            var content = new StringContent(Json, Encoding.UTF8, "application/json");

            var output = await _httpClient.PostAsync(endpoint, content);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<GenericApiResponse<SignUpResponse>>(outputData);
            }
            else
            {
                _logger.Error($"Class: TalkHomeService, Method: SignUpWithPreAuth, " +
                    $"ResponseCode :{JsonConvert.SerializeObject(output.StatusCode)}, " +
                    $"Response :{JsonConvert.SerializeObject(await output.Content.ReadAsStringAsync())}, " +
                    $"Request: {JsonConvert.SerializeObject(request)}");
                return null;
            }
        }
        public async Task<GenericApiResponse<SignUpResponse>> SignUpOrSignInWithPreAuth(SignupWithPreAuthRequestV2 request, string remoteIp)
        {
            string endpoint = _talkHomeConfig.SignUpPreAuthAEndPointV2;

            //endpoint = endpoint.Replace("{token}", token);

            var Json = JsonConvert.SerializeObject(request);

            _httpClient.DefaultRequestHeaders.Clear();

            _httpClient.DefaultRequestHeaders.Add("NowtelAuth", _talkHomeConfig.NowtelAuthToken);

            var content = new StringContent(Json, Encoding.UTF8, "application/json");
            content.Headers.Add("PrivateAccessKey", _talkHomeConfig.SignupPreAuthAPrivateAccessKey);
            content.Headers.Add("PrivateAccessIpAddress", remoteIp);
            var output = await _httpClient.PostAsync(endpoint, content);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<GenericApiResponse<SignUpResponse>>(outputData);
            }
            else
            {
                _logger.Error($"Class: TalkHomeService, Method: SignUpWithPreAuth, " +
                    $"ResponseCode :{JsonConvert.SerializeObject(output.StatusCode)}, " +
                    $"Response :{JsonConvert.SerializeObject(await output.Content.ReadAsStringAsync())}, " +
                    $"Request: {JsonConvert.SerializeObject(request)}");
                return null;
            }
        }


        public async Task<GenericApiResponse<PreAuthResponseModel>> PreAuth(PreAuthRequestModel request)
        {
            string endpoint = _talkHomeConfig.PreAuthEndPoint;

            var Json = JsonConvert.SerializeObject(request);

            _httpClient.DefaultRequestHeaders.Clear();

            _httpClient.DefaultRequestHeaders.Add("NowtelAuth", _talkHomeConfig.NowtelAuthToken);

            var content = new StringContent(Json, Encoding.UTF8, "application/json");

            var output = await _httpClient.PostAsync(endpoint, content);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<GenericApiResponse<PreAuthResponseModel>>(outputData);
            }
            else
            {
                _logger.Error($"Class: TalkHomeService, Method: PreAuth, " +
                    $"ResponseCode :{JsonConvert.SerializeObject(output.StatusCode)}, " +
                    $"Response :{JsonConvert.SerializeObject(await output.Content.ReadAsStringAsync())}, " +
                    $"Request: {JsonConvert.SerializeObject(request)}");
                return null;
            }
        }
        private string BasicAuthToken(string username, string password)
        {
            var tokenBytes = UTF8Encoding.UTF8.GetBytes($"{username}:{password}");
            return Convert.ToBase64String(tokenBytes);
        }
        public async Task<GenericApiResponse<LoginApiResponseModel>> VerifyPin(LoginRequest request, string username, string password, string remoteIp)
        {
            string endpoint = _talkHomeConfig.LoginEndPoint;

            var Json = JsonConvert.SerializeObject(request);

            _httpClient.DefaultRequestHeaders.Clear();

            _httpClient.DefaultRequestHeaders.Add("NowtelAuth", _talkHomeConfig.NowtelAuthToken);
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", BasicAuthToken(username, password));

            var content = new StringContent(Json, Encoding.UTF8, "application/json");

            content.Headers.Add("PrivateAccessKey", _talkHomeConfig.SignupPreAuthAPrivateAccessKey);
            content.Headers.Add("PrivateAccessIpAddress", remoteIp);

            var output = await _httpClient.PostAsync(endpoint, content);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<GenericApiResponse<LoginApiResponseModel>>(outputData);
            }
            else if (output.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                return GenericApiResponse<LoginApiResponseModel>.Failure(null, Enums.ApiStatusCodes.InvalidPinNumber);
            }
            else
            {
                _logger.Error($"Class: TalkHomeService, Method: VerifyPin, " +
                    $"ResponseCode :{JsonConvert.SerializeObject(output.StatusCode)}, " +
                    $"Response :{JsonConvert.SerializeObject(await output.Content.ReadAsStringAsync())}, " +
                    $"Request: {JsonConvert.SerializeObject(request)}");
                return null;
            }
        }
    }
}