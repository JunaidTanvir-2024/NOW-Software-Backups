﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum Algo
    {
        HMACSHA256 = 1
    }
}
