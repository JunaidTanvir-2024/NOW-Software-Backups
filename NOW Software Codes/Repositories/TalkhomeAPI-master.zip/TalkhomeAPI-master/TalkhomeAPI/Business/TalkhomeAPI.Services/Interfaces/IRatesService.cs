﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Services.Interfaces
{
    public interface IRatesService
    {
        Task<GenericApiResponse<IList<Rates>>> GetRates(string IsoCode);
    }
}
