using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Application.Features.Rate.International;

public class InternationalRatesRequestValidator : AbstractValidator<InternationalRatesRequest>
{

}
