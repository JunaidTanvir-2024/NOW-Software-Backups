﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    public class InAPPAndroidPaymentSettings
    {
        public string productId { get; set; }
        public string currency { get; set; }
        public decimal credit { get; set; }
    }
}
