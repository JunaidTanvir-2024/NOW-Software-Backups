﻿using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Vouchers.Responses
{
    public class VoucherValidationResponse
    {
        [JsonPropertyName("isValid")]
        public bool IsValid { get; set; }
        [JsonPropertyName("voucherCode")]
        public string VoucherCode { get; set; }
    }
}
