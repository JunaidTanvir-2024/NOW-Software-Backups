﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Contracts.Response.Api
{
    public class PoppayoutsSendSmsResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public PayLoad payload { get; set; }

    }
    public class PayLoad
    {
        public string error_string { get; set; }
        public string status { get; set; }
        public int error { get; set; }
        public string timestamp { get; set; }
        public PayLoadPoppayout[] data { get; set; }
    }
    public class PayLoadPoppayout
    {
        public string status { get; set; }
        public int error { get; set; }
        public string smslog_id { get; set; }
        public string queue { get; set; }
        public string to { get; set; }
    }
}
