﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace PaypalApi.Models.Contracts.Request.Api
{
   public enum TokenType
    {
        Basic = 1,
        Bearer = 2
    }
       
}
