﻿namespace SC.Core.Common.DTOs;
public record TokensDto
(
string JwtToken,
string RefreshToken,
DateTime RefreshTokenExpiry,
string Id
);

