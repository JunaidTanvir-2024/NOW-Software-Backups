﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum PortTypes
    {
        PortIn=1,
        PortInNew=2,
        PortOut=3
    }
}
