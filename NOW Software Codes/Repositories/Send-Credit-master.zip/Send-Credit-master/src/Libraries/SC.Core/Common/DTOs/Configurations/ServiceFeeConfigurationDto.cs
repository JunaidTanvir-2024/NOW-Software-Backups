﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.DTOs.Configurations;
public record ServiceFeeConfigurationDto
{
    public int ServiceFeeConfigurationId { get; set; }
    public decimal LowerValue { get; set; }
    public string LeftBusinessCondition { get; set; } = default!;
    public string RightBusinessCondition { get; set; } = default!;
    public decimal UpperValue { get; set; }
    public decimal AppliedValue { get; set; }
    public string BusinessCriteria { get; set; } = default!;
    public bool IsActivem { get; set; } = default;
}

