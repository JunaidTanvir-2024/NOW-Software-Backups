﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Pay360.Response
{
    public class ApiOkResponse
    {
        [JsonProperty("ok")]
        public bool Ok { get; set; }
      
    }
   
}
