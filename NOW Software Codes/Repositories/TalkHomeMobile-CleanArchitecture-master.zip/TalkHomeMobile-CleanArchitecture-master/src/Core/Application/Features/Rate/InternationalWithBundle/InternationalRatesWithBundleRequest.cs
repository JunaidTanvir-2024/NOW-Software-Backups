using Application.Features.Rate.Model;

namespace Application.Features.Rate.InternationalWithBundle;

public class InternationalRatesWithBundleRequest : IRequest<Result<InternationalRatesWithBundleInfo>>
{
    public string CountryCode { get; set; } = default!;
}