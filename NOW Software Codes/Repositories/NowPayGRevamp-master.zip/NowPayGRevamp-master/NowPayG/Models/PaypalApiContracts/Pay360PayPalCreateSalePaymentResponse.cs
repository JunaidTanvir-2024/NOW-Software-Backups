﻿using NowPayG.Models.Pay360ApiContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.PaypalApiContracts
{
    public class Pay360PayPalCreateSalePaymentResponse
    {
        public string customerId { get; set; }
        public string transactionId { get; set; }
        public string transactionAmount { get; set; }
        public outcome outcome { get; set; }
        public string clientRedirectUrl { get; set; }
        public string checkoutToken { get; set; }
    }
}
