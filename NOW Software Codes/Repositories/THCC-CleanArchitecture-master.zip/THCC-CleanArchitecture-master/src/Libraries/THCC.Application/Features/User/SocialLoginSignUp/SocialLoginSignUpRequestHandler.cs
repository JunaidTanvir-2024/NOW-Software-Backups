﻿using THCC.Application.Features.User.Login;
using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

namespace THCC.Application.Features.User.SocialLoginSignUp;

public class SocialLoginSignUpRequestHandler : IRequestHandler<SocialLoginSignUpRequest, object>
{
    #region Fields

    private readonly IMapper _mapper;
    private readonly ISocialLoginService _socialLoginService;
    private readonly IUserRepository _userRepository;
    private readonly ILegacyRepository _legacyRepo;
    private readonly ICommonService _commonService;
    private readonly ProfileSettings _profileSettings;
    private readonly IFileService _fileService;
    private readonly ILogger _logger;
    private readonly IUserService _userService;
    private readonly IAirshipService _airshipService;

    #endregion

    #region Ctor

    public SocialLoginSignUpRequestHandler(
        IMapper mapper,
        ISocialLoginService socialLoginService,
        IUserRepository userRepository,
         ILegacyRepository legacyRepository,
        IOptions<ProfileSettings> profileSettings,
        ICommonService commonService,
       IFileService fileService,
       ILogger logger,
        IUserService userService,
        IAirshipService airshipService)
    {
        _mapper = mapper;
        _socialLoginService = socialLoginService;
        _userRepository = userRepository;
        _legacyRepo = legacyRepository;
        _commonService = commonService;
        _profileSettings = profileSettings.Value;
        _fileService = fileService;
        _logger = logger;
        _userService = userService;
        _airshipService = airshipService;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(SocialLoginSignUpRequest request, CancellationToken cancellationToken)
    {
        var userResponse = new SocialUserDto();
        if (request.SocialLoginType == SocialLoginType.Google)
        {
            var googleUser = await _socialLoginService.GetUserFromGoogle(request.AccessToken);
            if (googleUser == null
                || string.IsNullOrEmpty(googleUser.Email)
                || !googleUser.EmailVerified!.Equals("true"))
            {
                return ErrorResult.Failure(CustomStatusKey.LoginFailed, CustomStatusCode.BadRequest);
            }

            userResponse.Id = googleUser.Id;
            userResponse.Email = googleUser.Email;
            userResponse.FirstName = googleUser.Given_name;
            userResponse.LastName = googleUser.Family_name;
            userResponse.Picture = googleUser.Picture;
            userResponse.Type = SocialLoginType.Google;
        }
        else if (request.SocialLoginType == SocialLoginType.Facebook)
        {
            var facebookUser = await _socialLoginService.GetUserFromFacebook(request.AccessToken)!;
            if (facebookUser == null || string.IsNullOrEmpty(facebookUser.Email))
            {
                return ErrorResult.Failure(CustomStatusKey.LoginFailed, CustomStatusCode.BadRequest);
            }

            userResponse.Id = facebookUser.Id;
            userResponse.FirstName = facebookUser.FirstName;
            userResponse.LastName = facebookUser.LastName;
            userResponse.Email = facebookUser.Email;
            userResponse.Picture = facebookUser.Picture?.Data?.Url;
            userResponse.Type = SocialLoginType.Facebook;
        }
        else
        {
            return ErrorResult.Failure(CustomStatusKey.LoginFailed, CustomStatusCode.BadRequest);
        }
        var user = await _userRepository.GetUserByEmailAsync(userResponse.Email!);
        if (user == null)
        {
            var legacyUserProduct = new LegacyProduct();

            //Check if user exists in legacy db
            var legacyUser = await _legacyRepo.GetUserByEmail(userResponse.Email!);
            if (legacyUser?.IsConfirmedUser == true)
            {
                userResponse.FirstName = legacyUser.FirstName;
                userResponse.LastName = legacyUser.LastName;

                //Get legacy user product
                legacyUserProduct = await _legacyRepo.GetUserProducts(legacyUser.Id);
            }

            //Register this user in new db 
            var signupResponse = await _userService.SocialSignUpAsync(
                userResponse.Id,
                userResponse.FirstName,
                userResponse.LastName,
                userResponse.Email!,
                userResponse.Type);

            if (!signupResponse.IsSuccess)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
            }

            //Register products in new db
            if (legacyUserProduct != null && !string.IsNullOrEmpty(legacyUserProduct.ProductRef))
            {
                (bool isProductSuccess, int errorCode, string errorMessage) = await _userRepository.CreateProduct(
                        legacyUserProduct.ProductRef!,
                        signupResponse.Id!,
                        legacyUserProduct.DateCreated);
                if (!isProductSuccess && errorCode > 0)
                {
                    _logger.Error(
                        $"Failied {legacyUser!.Email} product registration to new DB with errorCode: " +
                        $"{errorCode} {errorMessage}");
                }
            }

            user = await _userRepository.GetUserByEmailAsync(userResponse.Email!);
            if (!string.IsNullOrEmpty(userResponse.Picture))
            {
                user!.ProfileImage = await _fileService.DownloadImageAsync(userResponse.Picture.Trim(), user.Id, _profileSettings.SiteName!, _profileSettings.VirtualDirectoryName!);
                if (!string.IsNullOrEmpty(user.ProfileImage))
                {
                    var imageResponse = await _userRepository.UpdateprofileImage(user, user.ProfileImage);
                    if (!imageResponse.Succeeded)
                    {
                        _logger.Debug($"SocialSignUpAsync: Failed {user!.Email} update user profile image info: Image path not saved to database");
                    }
                }
            }
        }

        var loginResponse = await _userService.SocialLoginAsync(user!, userResponse.Id!, userResponse.Type);
        if (!loginResponse.IsSuccess)
        {
            ErrorResult.Failure(loginResponse.ErrorMessage!, loginResponse.ErrorCode);
        }
        if (!string.IsNullOrEmpty(user!.ProfileImage))
        {
            user!.ProfileImage = $"{_commonService.GetHostRequestUrl()}{_profileSettings.VirtualDirectoryName}/{user.Id}/{user.ProfileImage}";
        }

        #region Airship

        await _airshipService.CreateEmailChannelAndAssociation(user.Email!);

        #endregion

        return new LoginResponse()
        {
            User = _mapper.Map<UserDto>(user!),
            RefreshToken = loginResponse.RefreshToken!,
            Token = loginResponse.Token!
        };
    }

    #endregion
}