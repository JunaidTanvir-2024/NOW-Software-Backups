﻿using System.ComponentModel.DataAnnotations;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class SetBundleAutoRenewRequestModel
    {
        [Required]
        public string BundleId { get; set; }
        public bool IsAutoRenew { get; set; }
    }
}
