﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayG.Models.ApiContracts.Response
{
    public class UserAccountLastTopupResponseModel
    {
        public string amount { get; set; }
        public string date { get; set; }
    }
}
