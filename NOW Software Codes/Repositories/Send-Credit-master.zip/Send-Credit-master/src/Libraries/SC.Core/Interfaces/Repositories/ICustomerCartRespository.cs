﻿using SC.Core.Common.DTOs.Configurations;
using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Common.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Interfaces.Repositories;
public interface ICustomerCartRespository
{
    Task<long> OrderCreationAsync(OrderCreationDto order);
    Task<long> CartCreationAsync(CartCreationDto cart);
    Task<long> CartItemCreationAsync(CartItemCreationDto cart);
    Task<bool?> RemoveCartAsync(long productID, long CustomerCartID, long orderID);
    Task<List<GetCustomerCartDto>> GetCustomerCart(string customerID);
    Task<GetCustomerOrderDto> GetCustomerOrder(string customerID, string orderStatus);
    Task<long> AddCustomerAddressAsync(AddCustomerAddressDto Address);
    Task<List<GetPaymentMethodDto>> GetPaymentMethods();
    Task<CustomerOrderDetailDto> GetCustomerOrderDetail(string customerID, string orderStatus, long orderID = 0);
    Task<long> OrderPaymentCreationAsync(OrderPaymentDto order);
    Task<List<GetCustomerOrderDto>> GetCustomerOrders(string customerID, string orderStatus, long orderID = 0);
    Task<bool> CheckValidUserAsync(string? userID);
    Task<string?> CreateGuestUserAsync();
    Task<bool> MigrateGuestData(string? userID, string singInUserID);
    Task<long> GetOrderIDbyTransactionIDAsync(string customerID, string orderStatus, string transactionID);
    Task<List<CartStatusUpdateDto>> CartUpdateAsync(IEnumerable<CartStatusUpdateDto> cart);
    Task<List<CartStatusUpdateDto>> UpdateCartFinalStatusAsync(IEnumerable<CartStatusUpdateDto> cart);
    Task<List<ServiceFeeConfigurationDto>> GetServiceFeeConfiguration();
    Task<decimal> GetTotalOrderAmountPerDay(string customerID, string orderStatus, DateTime creationDate);


}

