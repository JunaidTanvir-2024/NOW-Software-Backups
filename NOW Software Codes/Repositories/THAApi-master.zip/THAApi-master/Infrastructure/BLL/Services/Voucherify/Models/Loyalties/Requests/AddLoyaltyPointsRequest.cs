using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.Loyalties.Requests
{
    public class AddLoyaltyPointsRequest
    {
        public string EventName { get; set; } = null!;
        public string CustomerId { get; set; } = null!;
        public Metadata CustomerMetadata { get; set; }
        public Metadata EventMetadata { get; set; }
    }
}