﻿using Application.Common.Extensions.DependencyResolver;
using Application.Features.Payment.Card.CustomerCards;
using Application.Features.Payment.Card.Models;

namespace Application.Common.Interfaces.Payment;

public interface ICardService : IServicesType.ITransientService
{
    Task<List<CustomerCard>> GetCustomerCards(string customerUniqueRef);
    Task<bool> MakeCustomerDefaultCard(string cv2, string cardToken, string customerUniqueRef);
    Task<bool> RemoveCard(string cardToken, string customerUniqueRef);
    Task<CardPaymentResponse> CardPayment(CardPaymentRequest request);
    Task<CardPaymentResponse> Resume3dCardPayment(string transactionId);
    Task<(bool, string)> RefundFullPayment(string transactionId);
    Task<(bool, string)> RefundPartailPayment(string transactionId, decimal amount);
}