using MM.Core.Features.SMS.Request;
namespace MM.Api.Controllers.V1;
using Microsoft.AspNetCore.Authorization;
public class SMSController : BaseApiController
{
    [HttpPost, AllowAnonymous]
    public async Task<ActionResult> SendSMS(SendSMSRequest request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}
