using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces.Shared;

public interface ISerializerService : IServicesType.ITransientService
{
    string Serialize<T>(T obj);

    string Serialize<T>(T obj, Type type);

    T Deserialize<T>(string text);
}