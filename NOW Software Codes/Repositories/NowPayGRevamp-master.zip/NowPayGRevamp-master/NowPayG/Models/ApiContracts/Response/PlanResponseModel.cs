﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Response
{
    public class PlanResponseModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string UuId { get; set; }
        public double Price { get; set; }
        public string Currency { get; set; }
        public string CurrencySymbol { get; set; }
        public string SubByTextNumber { get; set; }
        public string SubByTextCode { get; set; }
        public string Data { get; set; }
        public string OldData { get; set; }
        public bool MostPopular { get; set; }
        public string DataUnits { get; set; }
        public string LocalMins { get; set; }
        public string InternationalMins { get; set; }
        public string Sms { get; set; }
        public int ValidityDays { get; set; }
        public int ProductId { get; set; }
        public int CountryId { get; set; }
        public string CountryName { get; set; }
        public bool IsNational { get; set; }
        public bool IsTopPlan { get; set; }
        public int PlanCategoryId { get; set; }
        public string PlanInfo { get; set; }
        
    }
}
