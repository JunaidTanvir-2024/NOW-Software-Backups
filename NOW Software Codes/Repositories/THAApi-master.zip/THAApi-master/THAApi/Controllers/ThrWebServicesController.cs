﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Infrastructure.BLL.Services.Interfaces;
using System.Globalization;
using Models.Configurations;
using Microsoft.Extensions.Options;
using System.Net;
using System.Text.RegularExpressions;

namespace THAApi.Controllers
{
    [ApiController]
    [Route("THRWebServices")]
    public class ThrWebServicesController : Controller
    {
        private readonly IHelper_BL helperService;
        private readonly ILogger logger;
        private readonly IUserAccount_DL UserAccount_DL;
        private readonly ITopup_BL TopupService;
        private readonly IStringLocalizer _localizer;
        private readonly IUserAccount_BL UserAccount_BL;
        private readonly IConfiguration Config;
        private readonly IHslSms_BL HslSms_BL;

        public ThrWebServicesController(IHslSms_BL hslSms_BL, IConfiguration config,IUserAccount_BL userAccount_BL, IUserAccount_DL userAccount_DL,IHelper_BL helperService, ILogger logger, ITopup_BL topupService,IStringLocalizer localizer)
        {            
            this.helperService = helperService;
            this.logger = logger;
            TopupService = topupService;
            this._localizer = localizer;
            UserAccount_DL = userAccount_DL;
            UserAccount_BL = userAccount_BL;
            Config = config;
            HslSms_BL = hslSms_BL;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
		private bool ContainsUrl(string input)
		{
			string pattern = @"(https?|ftp):\/\/[^\s/$.?#].[^\s]*";
			// Use RegexOptions.IgnoreCase to make the pattern case-insensitive
			Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);

			return regex.IsMatch(input);
		}
		[HttpPost]
        [Route("SendSMS")]
        public async Task<IActionResult> SendSms([FromBody] SendSms request)
        {
            try
            {
                var tags = new string[] { $"sender:{request.StrMsisdn}", $"receiver:{request.StrContacts}" };

                request.StrMsisdn = helperService.StripLeadingZeros(request.StrMsisdn);
                if (ContainsUrl(request.StrMessage))
                {
					return Ok(new
					{
						error = "URL is not allowed in Message.",
						result = "fail",
					});
				}
                if (!await UserAccount_BL.AuthenticateAsync(request.StrMsisdn, request.StrPin))
                {
                    return Ok(new
                    {
                        error = _localizer["AccountDoesNotExist"],
                        result = "fail",
                    });
                }

                if (request.StrContacts == "842")
                {
                    return await HandleTopUp(request);
                }

                var accountst = await UserAccount_DL.GetUserAccount(request.StrMsisdn);
                
                if (Config["p2p_sms"].ToString(CultureInfo.InvariantCulture).Equals("0"))
                    return Ok(new
                    {
                        balance = accountst.UserAccountBalance.Balance,
                        results = new
                        {
                            error = "Service not available ",
                            status = "failed",
                            result = "failed",
                            errorCode = "1",
                        }
                    });

                var responseTask = new List<Task<SmsResult>>();
                foreach (var contact in request.StrContacts.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    responseTask.Add(HslSms_BL.Send1(request.StrMsisdn, contact.Trim(), request.StrMessage, true));
                }
                var response = await Task.WhenAll(responseTask);
                var account = await UserAccount_DL.GetUserAccount(request.StrMsisdn);

                return Ok(new
                {
                    balance = account.UserAccountBalance.Balance,
                    results = response.Select(i => new
                    {
                        status = i.Success ? "success" : "failed",
                        destination = i.Contact,
                        //message = i.Success ? "SMS Processed" : $"{i.ErrorCode.ToString(CultureInfo.InvariantCulture)} {i.ErrorMessage}"
                        message = i.Success ? "SMS Processed" : ((i.ErrorCode == SmsErrorCode.InsufficentBalance) ? "Insufficient Balance" : $"{i.ErrorCode.ToString()} {i.ErrorMessage}")
                    }).ToArray()
                });
            }
            catch (Exception ex)
            {
                var error = ex.GetType().Name;

                logger.Fatal(ex, "Error processing SMS {User} to {To}", request.StrMsisdn, request.StrContacts);

                return Ok(new
                {
                    error = _localizer["AccountDoesNotExist"],
                    result = "failed",
                    errorCode = ex.GetType().Name,
                });
            }
        }

        private async Task<IActionResult> HandleTopUp(SendSms request)
        {
            try
            {
                var voucherRequest = new VoucherTopupRequest
                {
                    Msisdn = request.StrMsisdn,
                    Pin = request.StrPin,
                    VoucherCode = request.StrMessage
                };

                var result = await TopupService.VoucherTopup(voucherRequest);

                var response = result.Payload;

                if (!string.IsNullOrEmpty(response.CreditApplied))
                {
                    return Ok(new
                    {
                        balance = response.BalanceAfter,
                        results = new[]
                        {
                            new
                            {
                                destination = "842",
                                message = _localizer["AccountCreditedBalanceIsNow",
                                    response.CreditApplied,
                                    response.BalanceAfter,
                                    response.Currency],
                                status = "success"
                            }
                        }
                    });
                }

                return Ok(new
                {
                    balance = response.BalanceAfter,
                    results = new[]
                        {
                            new
                            {
                                destination = "842",
                                message = result.Message,
                                status = "failed",
                            }
                        }
                });
            }
            catch (Exception ex)
            {
                var userAccount = await UserAccount_DL.GetUserAccount(request.StrMsisdn);
                var balance = userAccount.UserAccountBalance.Balance;

                var error = ex.GetType().Name;

                logger.Fatal(ex, "Error handling Top-Up from {User}", request.StrMsisdn);

                return Ok(new
                {
                    balance,
                    results = new[]
                        {
                            new
                            {
                                destination = "842",
                                message = _localizer["VoucherCodeInvalidPleaseEnterValidCode"],
                                status = "failed",
                            }
                        }
                });
            }
        }

    }
}
