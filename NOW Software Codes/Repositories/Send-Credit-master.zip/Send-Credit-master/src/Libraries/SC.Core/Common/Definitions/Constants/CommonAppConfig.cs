﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants;

public static partial class AppConstants
{
    public static class CommonAppConfig
    {
        public const int DefaultPageSize = 1;
        public const int DefaultRecordsPerPageSize = 25;
        public const string DateFormat = "yyyyMMdd";
        public const bool Require3dSecure = true;
    }
}