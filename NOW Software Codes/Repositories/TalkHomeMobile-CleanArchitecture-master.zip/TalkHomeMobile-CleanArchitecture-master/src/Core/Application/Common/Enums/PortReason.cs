namespace Application.Common.Enums;

public enum PortReason
{
    CallQuality = 1,
    Coverage,
    CustomerService,
    Other,
    Promotion,
    Rates,
    SubscriptionChange
}
