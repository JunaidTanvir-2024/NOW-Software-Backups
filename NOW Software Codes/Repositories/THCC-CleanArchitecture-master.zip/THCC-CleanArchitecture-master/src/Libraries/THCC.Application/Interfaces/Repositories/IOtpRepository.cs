using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Repositories;
public interface IOtpRepository : ServiceType.IScoped
{
    Task SaveToken(string otp, string uniqueRef, string token, OtpType type);
    Task<string> GetToken(string otp, string uniqueRef, OtpType type);
}
