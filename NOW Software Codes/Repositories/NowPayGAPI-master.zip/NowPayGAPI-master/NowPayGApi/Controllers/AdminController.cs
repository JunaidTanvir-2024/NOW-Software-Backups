﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NowPayGApi.Infrastructure.BLL.Interfaces;
using NowPayGApi.JwtHelpers;
using NowPayGApi.Models.Contracts;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using NowPayGApi.Models.Utility;
using Serilog;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860
namespace NowPayGApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : Controller
    {
        private IConfiguration _configuration { get; }
        private readonly IBL_Admin Bl;
        private readonly ILogger Logger;

        public AdminController(IConfiguration configuration, IBL_Admin bl, ILogger logger)
        {
            _configuration = configuration;
            Bl = bl;
            Logger = logger;
        }

        [HttpPost]
        [Route("Login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login(LoginRequestModel model)
        {
            try
            {
                GenericApiResponse<LoginResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var user = await Bl.Login(model);
                if (user != null)
                {
                    user.GenerateToken(_configuration);
                    response = GenericApiResponse<LoginResponseModel>.Success(user, "Success");
                }
                else
                {
                    response = GenericApiResponse<LoginResponseModel>.Failure("Invalid Credentials Provided", ApiStatusCodes.InvalidEmailPassword);
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: Login, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetUsers")]
        [Authorize]
        public async Task<IActionResult> GetUsers([FromQuery]GetUsersRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.GetAllUsers(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: GetUsers, Parameters => model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetUserByID")]
        [Authorize]
        public async Task<IActionResult> GetUserByID(GetUserByIDRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.GetUserByID(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: GetUserByID, Parameters => moedl:{JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("UpdateUserStatus")]
        [Authorize]
        public async Task<IActionResult> UpdateUserStatus(UpdateUserStatusModel request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.UpdateUserStatus(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: UpdateUserStatus, Parameters => model: { JsonConvert.SerializeObject(request)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("SaveUpdateAdmin")]
        [Authorize]
        public async Task<IActionResult> SaveUpdateAdmin(SaveUpdateAdminRequestModel request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.SaveUpdateAdmin(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: SaveUpdateAdmin, Parameters => model: { JsonConvert.SerializeObject(request)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetAllAdmins")]
        [Authorize]
        public async Task<IActionResult> GetAllAdmins(GetAllAdminsRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.GetAllAdmins(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: GetAllAdmins, Parameters => model:{JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("UpdateAdminStatus")]
        [Authorize]
        public async Task<IActionResult> UpdateAdminStatus(UpdateAdminStatusRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.UpdateAdminStatus(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: UpdateAdminStatus, Parameters => model:{JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("UpdatePlanStatus")]
        [Authorize]
        public async Task<IActionResult> UpdatePlanStatus(UpdatePlanStatusModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.UpdatePlanStatus(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: UpdatePlanStatus, Parameters => model:{JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("UpdatePlan")]
        [Authorize]
        public async Task<IActionResult> UpdatePlan(AddPlanRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                model.AddedByAdminId = Convert.ToInt32(User.Claims.FirstOrDefault(x => x.Type == "Id").Value);

                response = await Bl.UpdatePlan(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: UpdatePlan, Parameters => model:{JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Json("Internal Server Error");
            }
        }

        [HttpPost]
        [Route("AddPlan")]
        [Authorize]
        public async Task<IActionResult> AddPlan(AddPlanRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                model.AddedByAdminId = Convert.ToInt32(User.Claims.FirstOrDefault(x => x.Type == "Id").Value);

                response = await Bl.AddPlan(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: AddPlan, Parameters => model:{JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Json("Internal Server Error");
            }
        }

        [HttpPost]
        [Route("DispatchOrder")]
        [Authorize]
        public async Task<IActionResult> DispatchOrder(DispatchOrderRequestModel model)
        {
            try
            {
                return Ok(await Bl.DispatchOrder(model, Convert.ToInt32(User.Claims.FirstOrDefault(x => x.Type == "Id").Value)));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: DispatchOrder, Parameters => model:{JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetSpecificSimOrderDetails")]
        [Authorize]
        public async Task<ActionResult> GetSpecificSimOrderDetails([FromQuery]GetSpecificSimOrderDetailsRequestModel model)
        {
            try
            {
                return Ok(await Bl.GetSpecificSimOrderDetails(model));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: GetSpecificSimOrderDetails, Parameters => model:{JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetAllSimOrders")]
        [Authorize]
        public async Task<IActionResult> GetAllSimOrders()
        {
            try
            {
                return Ok(await Bl.GetAllSimOrders());
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: GetAllSimOrders, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("Insertotp")]
        [AllowAnonymous]
        public async Task<IActionResult> Insertotp(InsertotpRequestModel model)
        {
            try
            {
                GenericApiResponse<int> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Bl.Insertotp(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: Insertotp, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("Verifyotp")]
        [AllowAnonymous]
        public async Task<IActionResult> Verifyotp(VerifyotpRequestModel model)
        {
            try
            {
                GenericApiResponse<int> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Bl.Verifyotp(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: Verifyotp, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("VerifyUserSimOrder")]
        [AllowAnonymous]
        public async Task<IActionResult> VerifyUserSimOrder(VerifyUserSimOrderRequestModel model)
        {
            try
            {
                GenericApiResponse<int> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Bl.VerifyUserSimOrder(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: VerifyUserSimOrder, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("IsverifiedUser")]
        [AllowAnonymous]
        public async Task<IActionResult> IsverifiedUser([FromBody] IsUserExistRequestModel model)
        {
            try
            {
                GenericApiResponse<int> response;

             
                response = await Bl.IsverifiedUser(model.Email);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AdminController, Method: IsverifiedUser, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

    }
}
