﻿using Azure;
using SenderService.Core.Common;
using SenderService.Core.Features.Email.Request;
using SenderService.Core.Features.EmailValidation.Response;
using SenderService.Core.Persistence.Repository;
using SenderService.Core.Services.ZeroBounce;
using Serilog.Events;
using Serilog;
using System.Net;
using System.Text.Json;

namespace SenderService.Core.Features.EmailValidation;

public interface IEmailValidationService
{
    Task<ApiResult<EmailValidationResponse>> ValidateEmailAsync(ValidateEmailRequest request);
}

public class EmailValidationService : IEmailValidationService
{
    private readonly IEmailValidationRepository _emailValidationRepository;
    private readonly IZeroBounceImplementation _zeroBounceImplementation;
    private readonly IProductCodeRepository _productCodeRepository;

    public EmailValidationService(
        IEmailValidationRepository emailValidationRepository,
        IZeroBounceImplementation zeroBounceImplementation,
        IProductCodeRepository productCodeRepository)
    {
        _emailValidationRepository = emailValidationRepository;
        _zeroBounceImplementation = zeroBounceImplementation;
        _productCodeRepository = productCodeRepository;
    }

    public async Task<ApiResult<EmailValidationResponse>> ValidateEmailAsync(ValidateEmailRequest request)
    {
        var requestJson = JsonSerializer.Serialize(request);
        
        var email = request.Email;
        // Split email address into username and domain
        var emailParts = email.Split('@');
        var domain = emailParts[1];
        //We can use this email to verify that
        EmailValidationResponse emailValidationResponse = new EmailValidationResponse();
        var emailStatus = _emailValidationRepository.CheckEmailStatus(domain, email);

        if (emailStatus != null)
        {
            // Return success if domain or email is in whitelist
            if (emailStatus?.IsDomainWhitelist == true || emailStatus?.IsEmailWhitelist == true)
            {
                emailValidationResponse.IsEmailValid = true;
                return ApiResult<EmailValidationResponse>.Success("Email is valid", data: emailValidationResponse);
            }

            // Return failure if domain is blocked
            if (emailStatus?.IsDomainBlocked == true)
            {
                Log.Write(LogEventLevel.Error, "Email Validation Fail {Status}, {EmailValidationRequest}", "Domain is Blocked", requestJson);

                emailValidationResponse.IsEmailValid = false;
                return ApiResult<EmailValidationResponse>.Failure("Domain is blocked", data: emailValidationResponse);
            }

            // Return success if email is verified
            if (emailStatus?.IsEmailAlreadyProcessed == true && emailStatus?.IsEmailVerified == true)
            {
                emailValidationResponse.IsEmailValid = true;
                return ApiResult<EmailValidationResponse>.Success("Email is valid", data: emailValidationResponse);
            }

            // Return fail if email is processed and not verified
            if (emailStatus?.IsEmailAlreadyProcessed == true && emailStatus?.IsEmailVerified == false)
            {
                Log.Write(LogEventLevel.Error, "Email Validation Fail {Status}, {EmailValidationRequest}", $"Email is Verified = {emailStatus?.IsEmailVerified} and IsEmailAlreadyProcessed = {emailStatus?.IsEmailAlreadyProcessed}", requestJson);

                emailValidationResponse.IsEmailValid = false;
                return ApiResult<EmailValidationResponse>.Failure("Email is invalid", data: emailValidationResponse);
            }

            // Verify email if it not in whitelist of domain and emails and not processed yet
            if (emailStatus?.IsEmailAlreadyProcessed == false)
            {
                var formatedProductCode = request.ProductCode.Trim().ToUpperInvariant();

                // Validate email using ZeroBounce
                var zeroBounceResult = await _zeroBounceImplementation.ValidateEmailAsync(email);
                if (zeroBounceResult.Result != null)
                {
                    // Handle email validation
                    await _emailValidationRepository.AddEmailValidation(email, zeroBounceResult.Result?.Status!, domain, zeroBounceResult.Result?.SubStatus!, formatedProductCode, null!, zeroBounceResult.ApiResponse, request.IpAddress!);

                    if (!(zeroBounceResult.Result?.Status == ZeroBounceStatus.Valid))
                    {
                        return ApiResult<EmailValidationResponse>.Failure("Email is not valid", data: emailValidationResponse);
                    }
                    else
                    {
                        emailValidationResponse.IsEmailValid = true;
                        return ApiResult<EmailValidationResponse>.Success("Email is valid", data: emailValidationResponse);
                    }
                }
                else
                {
                    // Handle email validation in case of api failed
                    await _emailValidationRepository.AddEmailValidation(email, ZeroBounceStatus.Valid, domain, string.Empty, formatedProductCode, null!, zeroBounceResult.ApiResponse, request.IpAddress!);

                    emailValidationResponse.IsEmailValid = true;
                    return ApiResult<EmailValidationResponse>.Success("Email is valid", data: emailValidationResponse);
                }
            }
        }
        // Email status is null
        return ApiResult<EmailValidationResponse>.Failure("Email is not valid", errorCode: (int) HttpStatusCode.BadRequest);
    }
}
