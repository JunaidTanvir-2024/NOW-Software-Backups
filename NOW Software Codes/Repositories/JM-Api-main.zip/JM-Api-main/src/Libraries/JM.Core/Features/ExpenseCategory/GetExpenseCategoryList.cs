using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;
namespace JM.Core.Features.ExpenseCategory;
public abstract class GetExpenseCategoryList
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public required string Name { get; set; }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var expenseCategory = await _unitOfWork.ExpenseRepository.GetExpenseCategoryList();
            if (expenseCategory is not null)
            {
                return ResultWrapper.Success(expenseCategory.Select(x => new Response()
                {
                    Name = x.Name,
                    Id = x.Id
                }));
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
    }
    #endregion
}
