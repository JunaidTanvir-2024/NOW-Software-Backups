﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class GetProductsRequestModel
    {
        [Required(ErrorMessage = "top-up number is required")]
        public string ToMsisdn { get; set; }
        public string FromMsisdn { get; set; }
        public string Currency { get; set; }
    }
    public class GetTransferSummaryRequestModel
    {
        [Required(ErrorMessage = "top-up number is required")]
        public string ToMsisdn { get; set; }
        public string FromMsisdn { get; set; }
        public string Currency { get; set; }
    }
}
