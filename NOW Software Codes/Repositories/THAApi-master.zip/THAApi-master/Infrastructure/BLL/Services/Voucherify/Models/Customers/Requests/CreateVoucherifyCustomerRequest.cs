﻿using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests
{
    public class CreateVoucherifyCustomerRequest
    {
        public string SourceId { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public string Description { get; set; }

        public string Phone { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public string Country { get; set; }

        public string PostalCode { get; set; }

        public Metadata Metadata { get; set; }
    }
}