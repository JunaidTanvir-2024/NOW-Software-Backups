﻿using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IChannel_BL
    {
        Task<GenericApiResponse<ApiGetChannelByIdResponse>> GetChannelById(GetChannelRequest request);
        Task<GenericApiResponse<ApiGetChannelsResponse>> GetChannels(GetAllChannelsRequest request);
        Task<GenericApiResponse<string>> AddChannel(AddChannelRequest request);
        Task<GenericApiResponse<string>> AddChannelTags(AddChannelTagsRequest request);
    }
}
