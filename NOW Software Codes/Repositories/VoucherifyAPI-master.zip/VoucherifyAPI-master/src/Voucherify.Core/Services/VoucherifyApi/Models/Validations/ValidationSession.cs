using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Validations;

public class ValidationSession
{
    [JsonPropertyName("key")]
    public string? Key { get; set; }

    [JsonPropertyName("type")]
    public string? Type { get; set; }

    [JsonPropertyName("ttl")]
    public string? TTL { get; set; }

    [JsonPropertyName("ttl_unit")]
    public string? TTLUnit { get; set; }
}
