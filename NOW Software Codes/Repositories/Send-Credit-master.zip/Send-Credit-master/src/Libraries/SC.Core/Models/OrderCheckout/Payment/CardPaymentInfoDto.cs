﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.OrderCheckout.Payment;
public class CardPaymentInfoDto
{

    public string Currency { get; set; } = default!;
    public float Amount { get; set; } = default!;
    public bool Do3DSecure { get; set; }
    public bool Deferred { get; set; }
    public bool Recurring { get; set; }
    public RecurringAgreementDto? RecurringAgreement { get; set; }
    public bool Scheduling { get; set; }
    public SchedulingAgreementDto? SchedulingAgreement { get; set; }
}
public class RecurringAgreementDto
{
    public string Expiry { get; set; } = default!;
    public int MinFrequency { get; set; }
}

public class SchedulingAgreementDto
{
    public string Unit { get; set; } = default!;
    public int EpisodeLimit { get; set; }
    public decimal[] Amounts { get; set; } = default!;
}

