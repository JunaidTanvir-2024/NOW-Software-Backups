using FluentValidation;

using Voucherify.Core.Commons.Extensions;

namespace Voucherify.Api.Features.Customers.Requests;

public class GetReferralCodeRequest
{
    public string? CampaignNameOrId { get; set; }
    public string? CustomerSourceId { get; set; }
}
internal class GetReferralCodeRequestValidator : AbstractValidator<GetReferralCodeRequest>
{
    public GetReferralCodeRequestValidator()
    {
        RuleFor(p => p.CampaignNameOrId).NotNull().NotEmpty();
        RuleFor(p => p.CustomerSourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.CustomerSourceId = phoneNumber);
    }
}
