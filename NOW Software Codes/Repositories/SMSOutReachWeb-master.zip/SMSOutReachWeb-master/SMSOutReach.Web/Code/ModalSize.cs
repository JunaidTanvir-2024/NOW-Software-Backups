﻿namespace SMSOutReach.Web.Code
{
    public enum ModalSize
    {
        Small,
        Large,
        Medium
    }
}
