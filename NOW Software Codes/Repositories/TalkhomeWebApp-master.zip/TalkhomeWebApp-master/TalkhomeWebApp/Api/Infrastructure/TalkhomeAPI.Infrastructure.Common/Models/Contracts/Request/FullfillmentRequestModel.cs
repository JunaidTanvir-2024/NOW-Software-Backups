﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class FullfillmentRequestModel
    {
        public string tranId { get; set; }
        public string bundleref { get; set; }
        public string transamount { get; set; }
        public string prodref { get; set; }
        public float amount { get; set; }
    }
}
