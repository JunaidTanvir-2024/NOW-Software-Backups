using System.Text.Json;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.DependencyResolver;

using Microsoft.AspNetCore.Http;

namespace JM.Core.Utilities.Helpers;

public interface IGlobalHelper : ResolveAs.ISingleton
{
    string? GetProductReference();
    string? GetRequestReference();
}

public sealed class GlobalHelper(IHttpContextAccessor httpContextAccessor) : IGlobalHelper
{
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;

    public string? GetProductReference()
    {
        return _httpContextAccessor.HttpContext!.Request.Headers[AppConstant.Headers.ProductReference];
    }
    public string? GetRequestReference()
    {
        return _httpContextAccessor.HttpContext!.Request.Headers[AppConstant.Headers.RequestReference];
    }

    #region Static Methods
    public static string GenerateUniqueReference()
    {
        return Guid.NewGuid().ToString();
    }
    public static (string firstName, string lastName) SplitNames(string fullName)
    {
        var parts = fullName.Split('_');

        return (parts[0], parts[1]);
    }

    public static bool IsJsonList(string jsonString)
    {
        try
        {
            JsonDocument doc = JsonDocument.Parse(jsonString);

            return doc.RootElement.ValueKind == JsonValueKind.Array;
        }
        catch (JsonException)
        {
            return false;
        }
    }
    #endregion
}
