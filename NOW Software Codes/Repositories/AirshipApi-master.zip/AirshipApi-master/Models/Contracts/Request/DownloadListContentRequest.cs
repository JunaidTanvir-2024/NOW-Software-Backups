﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class DownloadListContentRequest
    {
        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("list_name")]
        [Required]
        public string list_name { get; set; }
    }
}
