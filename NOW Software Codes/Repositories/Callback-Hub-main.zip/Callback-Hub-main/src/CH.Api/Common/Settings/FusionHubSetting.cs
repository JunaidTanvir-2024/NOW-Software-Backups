namespace CH.Api.Common.Settings;

public class FusionHubSetting
{
    public const string SectionName = nameof(FusionHubSetting);

    public required string BaseUrl { get; set; }

    public required Endpoints CallbackEndpoints { get; set; }

    public class Endpoints
    {
        public string? DtOneTransaction { get; set; }
    }
}
