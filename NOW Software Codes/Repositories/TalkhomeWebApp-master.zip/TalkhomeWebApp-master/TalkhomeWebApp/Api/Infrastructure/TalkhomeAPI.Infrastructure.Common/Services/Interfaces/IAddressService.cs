﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface IAddressService
    {
        Task<HttpResponseMessage> GetAddress(string postCode);
    }
}
