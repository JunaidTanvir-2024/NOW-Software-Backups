﻿using Dapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NowPayGApi.Infrastructure.DAL.Interfaces;
using NowPayGApi.Models.Configurations;
using NowPayGApi.Models.DAOs;
using NowPayGApi.Models.DbConnections;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using Serilog;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using System.Linq;

namespace NowPayGApi.Infrastructure.DAL.Impelmentation
{
    public class DL_Admin : IDL_Admin
    {
        private readonly IDbConnectionSettings Db;
        private readonly ILogger Logger;

        public DL_Admin(IOptions<ConnectionString> connectionString, ILogger logger)
        {
            Logger = logger;
            Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.NowPaygDbConnection));
        }

        public async Task<DBUser> Login(DBUser model)
        {
            DBUser result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", model.Email);
                parameters.Add("@Password", model.Password);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("NowPayG_Api_LoginAdmin", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Admin, Method: Login, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null;
            }
        }

        public async Task<int> AddPlans(DBUser model)
        {
            int result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", model.Email);
                parameters.Add("@Password", model.Password);
                parameters.Add("@CountryId", model.CountryId);
                parameters.Add("@Firstname", model.FirstName);
                parameters.Add("@Lastname", model.LastName);
                parameters.Add("@Role", model.Role);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("NowPayG_Api_RegisterUser", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> IsUserExistByEmail(string email)
        {
            DBUser result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", email);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("NowPayG_Api_IsUserExistByEmail", parameters, commandType: CommandType.StoredProcedure);
                if (result != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<User>> GetAllUsers(string CSVNumbers)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@CSVNumbers", CSVNumbers);

                return await Db.SqlConnection.QueryAsync<User>("NowPayG_Api_GetAllUsers", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<DBUserDetails> GetUserByID(User user)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@pID", user.Id);

                var result = await Db.SqlConnection.QueryMultipleAsync("NowPayG_Api_GetUserByID", parameters, commandType: CommandType.StoredProcedure);

                return new DBUserDetails()
                {
                    userData = result.Read<User>().FirstOrDefault(),
                    userAddressList = result.Read<DBUserAddress>().ToList()
                };
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> UpdateUserStatus(UpdateUserStatusModel model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@pUserID", model.UserID);
                parameters.Add("@pStatusID", model.StatusID);

                var result = await Db.SqlConnection.ExecuteAsync("NowPayG_Api_UpdateUserStatus", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> SaveUpdateAdmin(DBAdmin model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@pID", model.Id);
                parameters.Add("@pFirstName", model.Firstname);
                parameters.Add("@pLastName", model.Lastname);
                parameters.Add("@pRoleID", model.RoleId);
                parameters.Add("@pAddress", model.Address);
                parameters.Add("@pEmail", model.Email);
                parameters.Add("@pPassword", model.Password);
                parameters.Add("@pCreatedBy", model.CreatedBy);
                parameters.Add("@pLastUpdatedBy", model.LastUpdatedBy);


                return await Db.SqlConnection.ExecuteAsync("NowPayG_Api_SaveUpdateAdmin", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<DBAdmin>> GetAllAdmins(DBAdmin model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@pName", model.Firstname);
                parameters.Add("@pRoleID", model.RoleId);
                parameters.Add("@pEmail", model.Email);

                return await Db.SqlConnection.QueryAsync<DBAdmin>("NowPayG_Api_GetAllAdmins", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> UpdateAdminStatus(DBAdmin model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@pAdminID", model.Id);
                parameters.Add("@pStatusID", model.IsActive);
                parameters.Add("@pLastUpdatedBy", model.LastUpdatedBy);

                return await Db.SqlConnection.ExecuteAsync("NowPayG_Api_UpdateAdminStatus", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> UpdatePlanStatus(UpdatePlanStatusModel model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@pPlanID", model.PlanID);
                parameters.Add("@pStatusID", model.StatusID);

                var result = await Db.SqlConnection.ExecuteAsync("NowPayG_Api_UpdatePlanStatus", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> UpdatePlan(AddPlanRequestModel model)
        {
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@ID", model.Id);
                parameters.Add("@Name", model.Name);
                parameters.Add("@Description", model.Description);
                parameters.Add("@UuId", model.UuId);
                parameters.Add("@Price", model.Price);
                parameters.Add("@CurrencyID", model.CurrencyID);
                parameters.Add("@SubByTextNumber", model.SubByTextNumber);
                parameters.Add("@SubByTextCode", model.SubByTextCode);

                parameters.Add("@Data", model.Data);
                parameters.Add("@DataUnits", model.DataUnits);
                parameters.Add("@LocalMins", model.LocalMins);
                parameters.Add("@InternationalMins", model.InternationalMins);
                parameters.Add("@Sms", model.Sms);
                parameters.Add("@ValidityDays", model.ValidityDays);
                parameters.Add("@ProductId", model.ProductId);

                parameters.Add("@CountryId", model.CountryId);
                parameters.Add("@IsNational", model.IsNational);
                parameters.Add("@IsTopPlan", model.IsTopPlan);
                parameters.Add("@PlanCategoryId", model.PlanCategoryId);
                parameters.Add("@AddedByAdminId", model.AddedByAdminId);
                parameters.Add("@isActive", model.IsActive);

                var result = await Db.SqlConnection.QueryFirstAsync<int>("NowPayG_Api_Updateplan", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> AddPlan(AddPlanRequestModel model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@Name", model.Name);
                parameters.Add("@Description", model.Description);
                parameters.Add("@UuId", model.UuId);
                parameters.Add("@Price", model.Price);
                parameters.Add("@CurrencyID", model.CurrencyID);
                parameters.Add("@SubByTextNumber", model.SubByTextNumber);
                parameters.Add("@SubByTextCode", model.SubByTextCode);

                parameters.Add("@Data", model.Data);
                parameters.Add("@DataUnits", model.DataUnits);
                parameters.Add("@LocalMins", model.LocalMins);
                parameters.Add("@InternationalMins", model.InternationalMins);
                parameters.Add("@Sms", model.Sms);
                parameters.Add("@ValidityDays", model.ValidityDays);
                parameters.Add("@ProductId", model.ProductId);

                parameters.Add("@CountryId", model.CountryId);
                parameters.Add("@IsNational", model.IsNational);
                parameters.Add("@IsTopPlan", model.IsTopPlan);
                parameters.Add("@PlanCategoryId", model.PlanCategoryId);
                parameters.Add("@AddedByAdminId", model.AddedByAdminId);
                parameters.Add("@isActive", model.IsActive);

                var result = await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("NowPayG_Api_Addplan", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> DispatchOrder(int orderId, int userId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Id", orderId);
            parameters.Add("@UserId", userId);

            return await Db.SqlConnection.ExecuteAsync("NowPayG_Api_SetDispachStatus", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<DbUserSimOrderDetails> GetSpecificSimOrderDetails(int orderId)
        {
            var parameter = new DynamicParameters();
            parameter.Add("@Id", orderId);

            var result = await Db.SqlConnection.QueryMultipleAsync("NowPayG_Api_GetSpecificSimOrderDetails", parameter, commandType: CommandType.StoredProcedure);

            var response = new DbUserSimOrderDetails();

            if (result != null)
            {
                response.OrderDetails = await result.ReadSingleOrDefaultAsync<DBUserSIMOrder>();
                response.UserInfo = await result.ReadSingleOrDefaultAsync<DBUser>();
                response.AddressInfo = await result.ReadSingleOrDefaultAsync<DBUserAddress>();
                response.UserProducts = await result.ReadAsync<DBUserProduct>();
                return response;
            }
            else { response = null; }

            return response;
        }

        public async Task<IEnumerable<DBUserSIMOrder>> GetAllSimOrders()
        {
            return await Db.SqlConnection.QueryAsync<DBUserSIMOrder>("NowPayG_Api_GetAllSimOrders", commandType: CommandType.StoredProcedure);
        }

        public async Task<int> Insertotp(InsertotpRequestModel model)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@email", model.Email);
            parameters.Add("@otp", model.otpcode);

            return await Db.SqlConnection.ExecuteAsync("NowPayG_Api_Insert_otp", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> Verifyotp(VerifyotpRequestModel model)
        {

            var parameters = new DynamicParameters();
            parameters.Add("@email", model.Email);
            parameters.Add("@otp", model.Otpcode); 
            parameters.Add("@ExpiryHours",model.ExpiryMinutes);           
            var result =  Db.SqlConnection.ExecuteScalar("NowPayG_Api_VerifyUserby_otp", parameters, commandType: CommandType.StoredProcedure);
            return (int)result;
        }

        public async Task<int> VerifyUserSimOrder(VerifyUserSimOrderRequestModel model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", model.Email);
                parameters.Add("@PostCode", model.PostCode);
                parameters.Add("@Address", model.Address);
                var result =  Db.SqlConnection.ExecuteScalar("NowPayG_Api_sim_order_validation", parameters, commandType: CommandType.StoredProcedure);
                return (int)result;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> IsverifiedUser(string email)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", email);
                var result =  Db.SqlConnection.ExecuteScalar("NowPayG_Api_IsverifiedUser", parameters, commandType: CommandType.StoredProcedure);
                return (int)result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
