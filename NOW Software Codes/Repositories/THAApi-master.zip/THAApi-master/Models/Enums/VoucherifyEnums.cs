﻿namespace Models.Enums
{
    public enum CreditReason
    {
        Points,
        Referee,
        Referrer
    }
}
