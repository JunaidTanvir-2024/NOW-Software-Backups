namespace FH.Core.DTOs.Database;
public sealed class CountryByIsoCodeDto
{
    public sealed record Request
    {
        public string? IsoCode { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }

    public sealed record Response
    {
        public long CountryId { get; set; }
        public string? IsoCode2 { get; set; }
        public string? IsoCode3 { get; set; }
        public int CallingCode { get; set; }
        public string? CountryName { get; set; }
        public int IsoNumericCode { get; set; }
        public string? Continent { get; set; }
    }
}
