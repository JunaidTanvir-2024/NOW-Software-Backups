using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Orders;
using Voucherify.Core.Services.VoucherifyApi.Models.Validations;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Promotions;

public class PromotionTier : BaseObject
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("banner")]
    public string? Banner { get; set; }

    [JsonPropertyName("campaign")]
    public PromotionTierCampaign? Campaign { get; set; }

    [JsonPropertyName("action")]
    public PromotionTierAction? Action { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    [JsonPropertyName("active")]
    public bool Active { get; set; }

    [JsonPropertyName("category")]
    public string? Category { get; set; }

    [JsonPropertyName("discount")]
    public Discount? Discount { get; set; }

    [JsonPropertyName("categoryId")]
    public string? CategoryId { get; set; }
    [JsonPropertyName("valid")]
    public bool Valid { get; set; }

    [JsonPropertyName("applicable_to")]
    public ApplicableTo? ApplicableTo { get; set; }

    [JsonPropertyName("inapplicable_to")]
    public ApplicableTo? InapplicableTo { get; set; }

    [JsonPropertyName("tracking_id")]
    public string? TrackingId { get; set; }

    [JsonPropertyName("order")]
    public Order? Order { get; set; }

    [JsonPropertyName("validation_rule_assignments")]
    public BusinessValidationRuleAssignmentList? Assignments { get; set; }
}
