﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class TransferByNewCustomerRequestModel
    {
        public string nowtelRef { get; set; }
        public string product { get; set; }
        public string operatorId { get; set; }
        public PaymentCardModel cardData { get; set; }
        public BillingAddressModel billingAddressData { get; set; }
        public string ipAddress { get; set; }
    }

    public class PaymentCardModel
    {
        public string NameOnCard { get; set; }
        public string CardNumber { get; set; }
        public string ExpiryMonth { get; set; }
        public string ExpiryYear { get; set; }
        public string SecurityCode { get; set; }
        public bool ShouldSaveCard { get; set; }
    }

    public class BillingAddressModel
    {
        public string CountryCode { get; set; }
        public string AddressL1 { get; set; }
        public string AddressL2 { get; set; }
        public string AddressL3 { get; set; }
        public string AddressL4 { get; set; }
        public string City { get; set; }
        public string Region { get; set; }
        public string PostCode { get; set; }
    }
}
