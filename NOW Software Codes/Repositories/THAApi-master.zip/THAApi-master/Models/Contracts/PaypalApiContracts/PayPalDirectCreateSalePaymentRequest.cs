﻿using Models.Contracts.Request;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Models.Contracts.PaypalApiContracts
{
	public class PayPalDirectExecuteSalePaymentResponse
	{
		[JsonProperty("paypalTransactionId")]
		public string PaypalTransactionId { get; set; }

		[JsonProperty("createTime")]
		public DateTime CreateTime { get; set; }

		[JsonProperty("intent")]
		public string Intent { get; set; }

		[JsonProperty("state")]
		public string State { get; set; }

		[JsonProperty("saleId")]
		public string SaleId { get; set; }
	}
	public class PayPalDirectExecuteSalePaymentRequest
	{
		public string Payer_id { get; set; } = string.Empty;
		public string Payment_id { get; set; } = string.Empty;
		public string CustomerUniqueRef { get; set; } = string.Empty;
		public string ProductCode { get; set; } = string.Empty;
		public bool IsDirectFullfilment { get; set; }
	}
	public class PayPalDirectCreateSalePaymentWithSubscriptionRequest : PayPalDirectCreateSalePaymentRequest
	{
		[JsonProperty("subscriptionWithInitialSale")]
		public bool SubscriptionWithInitialSale { get; set; }
		[JsonProperty("subscriptionStartDate")]
		public DateTime SubscriptionStartDate { get; set; }
		[JsonProperty("basket")]
		public new List<PaypalSubscriptionBasket> Basket { get; set; }
	}
	public class Basket
	{
		public string ProductItemCode { get; set; } = string.Empty;
		[JsonPropertyName("Amount")]
		public decimal ChargeAmount { get; set; }
		public string ProductRef { get; set; } = string.Empty;
		public string BundleRef { get; set; } = string.Empty;
		public decimal Discount { get; set; }
	}
	public class PaypalSubscriptionBasket : Basket
	{
		public int? NoOfCycles { get; set; } = 12;
		public int? FollowedByBundleNoOfCycles { get; set; }
		public string FollowedByBundleRef { get; set; }
		public float? FollowedByBundleAmount { get; set; }
	}
	public class PayPalDirectSuspendSubscriptionRequest
	{
		[JsonProperty("productCode")]
		[Required]
		public string ProductCode { get; set; } = string.Empty;
		public string SubscriptionId { get; set; } = string.Empty;
	}
	public class PayPalDirectCreateSalePaymentResponse
	{
		[JsonProperty("redirectUrl")]
		public string RedirectUrl { get; set; }
		public string TransactionID { get; set; }
	}
	public class PayPalDirectCreateSalePaymentWithSubscriptionResponse : PayPalDirectCreateSalePaymentResponse
	{
		[JsonProperty("subscription_id")]
		public string SubscriptionId { get; set; } = string.Empty;
	}
	public class PayPalDirectCreateSalePaymentRequest
	{
		public PayPalDirectCreateSalePaymentRequest()
		{
			RedirectUrl = new PayPalRedirectUrls();
			Transaction = new PayPalTransactions();
			Basket = new List<Basket>();
		}

		[JsonProperty("customerName")]
		public string CustomerName { get; set; } = string.Empty;

		[JsonProperty("customerUniqueRef")]
		public string CustomerUniqueRef { get; set; } = string.Empty;

		[JsonProperty("customerMsisdn")]
		public string CustomerMsisdn { get; set; } = string.Empty;

		[JsonProperty("CustomerEmail")]
		public string CustomerEmail { get; set; } = string.Empty;

		[JsonProperty("productCode")]
		public string ProductCode { get; set; } = string.Empty;

		[JsonProperty("redirect_urls")]
		public PayPalRedirectUrls RedirectUrl { get; set; }

		[JsonProperty("transactions")]
		public PayPalTransactions Transaction { get; set; }

		[JsonProperty("basket")]
		public List<Basket> Basket { get; set; }
	}
	public class PayPalRedirectUrls
	{
		[JsonProperty("return_url")]
		public string ReturnUrl { get; set; } = string.Empty;

		[JsonProperty("cancel_url")]
		public string CancelUrl { get; set; } = string.Empty;
	}
	public class PayPalTransactions
	{
		[JsonProperty("amount")]
		public PayPalAmounts Amount { get; set; }

		[JsonProperty("description")]
		public string Description { get; set; } = string.Empty;
	}
	public class PayPalAmounts
	{
		[JsonProperty("total")]
		public decimal Total { get; set; }

		[JsonProperty("currency")]
		public string Currency { get; set; } = string.Empty;
	}
}
