using FluentValidation;

using JM.Core.Features.ExpenseCategory;
using JM.Core.Features.Traveler;
using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using Microsoft.AspNetCore.Http;

using RW;

namespace JM.Core.Features.Auth.Expense;

public abstract class CreateExpense
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public long CategoryId { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Amount).GreaterThan(0);
            RuleFor(x => x.CategoryId).GreaterThan(0);
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public string? Description { get; set; }
        public decimal Amount { get; set; }
        public long TravelerId { get; set; }
        public ExpenseCategoryInfo? Category { get; set; }

        public sealed record ExpenseCategoryInfo
        {
            public required long Id { get; set; }
            public required string Name { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IMediator mediator, IHttpContextAccessor contextAccessor) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IMediator _mediator = mediator;
        private readonly IHttpContextAccessor _contextAccessor = contextAccessor;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var userId = _contextAccessor.HttpContext?.User.GetId();

            var getTraveler = await _mediator.Send(new GetTraveler.Query()
            {
                Id = userId ?? default
            }, cancellationToken);

            if (getTraveler.IsSuccess)
            {
                var travelerInfo = getTraveler.TypedPayload<GetTraveler.Response>()?.Trip;

                var expense = await _unitOfWork.ExpenseRepository.AddExpense(new Entities.Expense()
                {
                    Amount = query.Amount,
                    CategoryId = query.CategoryId,
                    Description = query.Description,
                    IsActive = true,
                    TravelerId = travelerInfo?.Traveler?.Id ?? default,
                    TripId = travelerInfo?.Id ?? default
                });
                _unitOfWork.SaveChanges();

                if (expense is not null)
                {
                    var getExpenseCategoryResult = (await _mediator.Send(new GetExpenseCategory.Query()
                    {
                        Id = query.CategoryId
                    }, cancellationToken));

                    if (getExpenseCategoryResult.IsSuccess)
                    {
                        var expenseCategory = getExpenseCategoryResult.TypedPayload<GetExpenseCategory.Response>();

                        return ResultWrapper.Success(new Response()
                        {
                            Id = expense.Id,
                            Amount = expense.Amount,
                            Description = expense.Description,
                            TravelerId = expense.TravelerId,
                            Category = expenseCategory is not null ? new Response.ExpenseCategoryInfo()
                            {
                                Id = expenseCategory.Id,
                                Name = expenseCategory.Name
                            } : default
                        });
                    }
                }
                return ResultWrapper.Failure(AppConstant.StatusKey.Forbidden, AppConstant.StatusCode.Forbidden);
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
    }
    #endregion
}
