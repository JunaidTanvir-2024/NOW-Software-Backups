﻿namespace Application.Features.AutoTopup;

public class AutoTopupInfoV2
{
    public float ThresHoldAmount { get; set; }
    public float TopupAmount { get; set; }
    public string CurrencySymbol { get; set; } = Common.Models.CurrencySymbol.GBP;
    public bool Status { get; set; }
    public string? PaymentMethod { get; set; }
    public string? CardPanMasked { get; set; } = default!;
}
