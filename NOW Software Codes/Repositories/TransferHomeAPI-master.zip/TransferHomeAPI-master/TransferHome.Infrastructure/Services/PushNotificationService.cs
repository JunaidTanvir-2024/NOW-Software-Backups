﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Infrastructure.Services.Interfaces;
using TransferHome.Models.Configurations;
using TrasnferHome.Infrastructure.DAL.Interfaces;
using TrasnferHome.Models.DAOs;

namespace TransferHome.Infrastructure.Services
{
    public class PushNotificationService : IPushNotificationService
    {
        private readonly ILogger Logger;
        private readonly FCMConfig FCMConfig;
        private readonly IDL_User DL;

        public PushNotificationService(ILogger logger, IDL_User dL_User, IOptions<FCMConfig> fCMConfig)
        {
            FCMConfig = fCMConfig.Value;
            Logger = logger;
            DL = dL_User;
        }

        /// <summary>
        /// Sends push notification to all active devices
        /// </summary>
        /// <param name="Text">Message to be sent</param>
        /// <returns></returns>
        public async Task SendPushNotificationToAll(string Title, string Text)
        {
            try
            {
                //Get All Active User Devices
                var userDevices = await DL.GetAllActiveDeviceTokens();

                foreach (var userDevice in userDevices)
                {
                    if (userDevice.DeviceTypeId == TrasnferHome.Models.Utility.DeviceType.Android)
                    {
                        var data = new
                        {
                            to = userDevice.Token, // Recipient device token
                            data = new { title = Title, body = Text }
                        };

                        // Using Newtonsoft.Json
                        var jsonBody = JsonConvert.SerializeObject(data);

                        await CallFCM(jsonBody);
                    }
                    else
                    {
                        var data = new
                        {
                            to = userDevice.Token, // Recipient device token
                            notification = new { title = Title, body = Text }
                        };

                        // Using Newtonsoft.Json
                        var jsonBody = JsonConvert.SerializeObject(data);

                        await CallFCM(jsonBody);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PushNotificationService, Method: SendPushNotification, Parameters=> text: {Text}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
            }
        }

        /// <summary>
        /// Sends notification to users with specified msisdns
        /// </summary>
        /// <param name="userMsisdns">Msisdns of the recipient users</param>
        /// <param name="Text">Message to be sent</param>
        /// <returns></returns>
        public async Task SendPushNotificationToSpecificUsers(List<string> userMsisdns, string Title, string Text)
        {
            try
            {
                //Get User Devices of Specific Users
                var userDevices = await DL.GetSpecificUsersActiveDeviceTokens(userMsisdns);

                foreach (var userDevice in userDevices)
                {

                    if (userDevice.DeviceTypeId == TrasnferHome.Models.Utility.DeviceType.Android)
                    {
                        var data = new
                        {
                            to = userDevice.Token, // Recipient device token
                            data = new { title = Title, body = Text }
                        };

                        // Using Newtonsoft.Json
                        var jsonBody = JsonConvert.SerializeObject(data);

                        await CallFCM(jsonBody);
                    }
                    else
                    {
                        var data = new
                        {
                            to = userDevice.Token, // Recipient device token
                            notification = new { title = Title, body = Text }
                        };

                        // Using Newtonsoft.Json
                        var jsonBody = JsonConvert.SerializeObject(data);

                        await CallFCM(jsonBody);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PushNotificationService, Method: SendPushNotificationToSpecificUsers, Parameters=> userMsisdns: {userMsisdns}, Text:{Text} ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
            }
        }

        public async Task SendPushNotificationToSpecificTokens(List<DBUserTokens> userDevices, string Title, string Text)
        {
            try
            {
                foreach (var userDevice in userDevices)
                {

                    if (userDevice.DeviceTypeId == TrasnferHome.Models.Utility.DeviceType.Android)
                    {
                        var data = new
                        {
                            to = userDevice.Token, // Recipient device token
                            data = new { title = Title, body = Text }
                        };

                        // Using Newtonsoft.Json
                        var jsonBody = JsonConvert.SerializeObject(data);

                        await CallFCM(jsonBody);
                    }
                    else
                    {
                        var data = new
                        {
                            to = userDevice.Token, // Recipient device token
                            notification = new { title = Title, body = Text }
                        };

                        // Using Newtonsoft.Json
                        var jsonBody = JsonConvert.SerializeObject(data);

                        await CallFCM(jsonBody);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PushNotificationService, Method: SendPushNotificationToSpecificTokens, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
            }
        }

        /// <summary>
        /// Centralised method to for sending api call to FCM
        /// </summary>
        /// <param name="json">Json of model to be sent</param>
        /// <returns></returns>
        private async Task CallFCM(string json)
        {
            try
            {
                using (var httpRequest = new HttpRequestMessage(HttpMethod.Post, "https://fcm.googleapis.com/fcm/send"))
                {
                    httpRequest.Headers.TryAddWithoutValidation("Authorization", "key=" + FCMConfig.LegacyServer);
                    httpRequest.Headers.TryAddWithoutValidation("Sender", FCMConfig.SenderId);
                    httpRequest.Content = new StringContent(json, Encoding.UTF8, "application/json");

                    using (var httpClient = new HttpClient())
                    {
                        var result = await httpClient.SendAsync(httpRequest);

                        if (result.IsSuccessStatusCode)
                        {
                            //return true;
                        }
                        else
                        {
                            // Use result.StatusCode to handle failure
                            // Your custom error handler here
                            Logger.Error($"Error sending notification. Status Code: {result.StatusCode}, Message : {result.ReasonPhrase}");
                        }
                    }
                }
            }
            catch (Exception)
            {
                //throw;
            }
        }
    }
}
