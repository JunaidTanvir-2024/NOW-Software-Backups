﻿

using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces;
public interface IDiscountService : IServicesType.ITransientService
{
     float GetDiscount(DateTime? lasttopupdate, float topupAmount, CheckOutType checkOutTypes);
}
