﻿namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class AccountDeleteSettings
    {
        public int SignUpAllowedAfterDays { get; set; }
    }
}
