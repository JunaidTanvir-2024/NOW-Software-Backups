using Application.Common.Extensions.DependencyResolver;
using Application.Features.Account.History.Models;
using Application.Features.Bundle.Model;

namespace Application.Common.Interfaces.Repositories;

public interface IUserRepository : IServicesType.IScopedService
{
    /// <summary>
    /// Get user products
    /// </summary>
    /// <param name="userId"></param>
    /// <returns>User products list</returns>
    Task<List<UserProduct>> GetUserProducts(long userId);

    Task<AccountDetail> GetAccountDetail(string account);

    /// <summary>
    /// Get user by email
    /// </summary>
    /// <param name="email"></param>
    /// <returns>User details object</returns>
    Task<User?> GetUserByEmail(string email);

    /// <summary>
    /// 
    /// 
    /// Get user by msisdn
    /// </summary>
    /// <param name="msisdn"></param>
    /// <returns>User details object</returns>
    Task<User?> GetUserByMsisdn(string msisdn);

    /// <summary>
    /// Get user by id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>User details object</returns>
    Task<User?> GetUserByIdAsync(long id);

    /// <summary>
    /// Save invalid login attempt
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="IpAddress"></param>
    /// <returns></returns>
    Task SaveInvalidLoginAttempt(long userId, string? IpAddress);
    /// <summary>
    /// Update user refresh token
    /// </summary>
    /// <param name="user"></param>
    /// <returns></returns>
    Task UpdateUserRefreshTokenAsync(User user);

    /// <summary>
    /// Is number belongs to THM
    /// </summary>
    /// <param name="msisdn"></param>
    /// <returns></returns>
    Task<bool> IsThmMsisdn(string msisdn);

    /// <summary>
    /// update user profile
    /// </summary>
    /// <param name="userid"></param>
    /// <param name="firstname"></param>
    /// <param name="lastname"></param>
    /// <param name="isSubscribedToNewsletter"></param>
    /// <returns></returns>
    Task<int> UpdateUserDetails(long userid, string firstname, string lastname, bool isSubscribedToNewsletter);

    /// <summary>
    /// update  profile image
    /// </summary>
    /// <param name="userid"></param>
    /// <param name="imagePath"></param>
    /// <returns></returns>
    Task<int> UpdateProfileImage(long userid, string imagePath);

    /// <summary>
    /// get msisdn detail
    /// </summary>
    /// <param name="msisdn"></param>
    /// <returns></returns>
    Task<MsisdnDetails> GetMsisdnDetail(string msisdn);

    /// <summary>
    /// Get User account last topup amount and date by account Id
    /// </summary>
    /// <param name="accountId"></param>
    /// <returns>User account last topup info</returns>
    Task<AccountLastTopup> GetUserLastTopupInfo(string accountId);

    /// <summary>
    /// Get User subscribe bundles info by account Id
    /// </summary>
    /// <param name="accountId"></param>
    /// <returns>User subscribe bundles info list</returns>
    Task<IEnumerable<SubscribedBundle>> GetSubscribedBundles(string accountId);
    Task<IEnumerable<SubscribedBundle>> GetSubscribedBundlesV3(string accountId);

    /// <summary>
    /// Get User account balance by account Id's
    /// </summary>
    /// <param name="accountId"></param>
    /// <returns>User account balance List</returns>
    Task<IEnumerable<AccountBalance>> GetAccountBalance(string msisdns);

    /// <summary>
    /// Get payment usage history
    /// </summary>
    /// <param name="userAccount"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="pageNo"></param>
    /// <param name="pageSize"></param>
    /// <returns></returns>
    //  Task<IEnumerable<PaymentHistory>> PaymentHistory(string userAccount, DateTime startDate, DateTime endDate, int pageNo, int pageSize);
    Task<IEnumerable<PaymentHistory>> PaymentHistory(string userAccount, DateTime startDate, DateTime endDate, int pageNo, int pageSize);
    Task<IEnumerable<PaymentHistory>> PaymentHistoryForApi(string userAccount, DateTime startDate, DateTime endDate, int pageNo, int pageSize, bool isAppRequest = false);

    /// <summary>
    /// Get call usage history
    /// </summary>
    /// <param name="userAccount"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="pageNo"></param>
    /// <param name="pageSize"></param>
    /// <returns></returns>
    Task<IEnumerable<CallHistoryInfo>> CallHistory(string userAccount, DateTime startDate, DateTime endDate, int pageNo, int pageSize);
    /// <summary>
    /// Get data usage history
    /// </summary>
    /// <param name="userAccount"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="pageNo"></param>
    /// <param name="pageSize"></param>
    /// <returns></returns>
    Task<IEnumerable<DataHistoryInfo>> DataHistory(string userAccount, DateTime startDate, DateTime endDate, int pageNo, int pageSize);
    /// <summary>
    /// Get sms usage history
    /// </summary>
    /// <param name="userAccount"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="pageNo"></param>
    /// <param name="pageSize"></param>
    /// <returns></returns>
    Task<IEnumerable<SmsHistoryInfo>> SmsHistory(string userAccount, DateTime startDate, DateTime endDate, int pageNo, int pageSize);


    /// <summary>
    /// Is User first Topup
    /// </summary>
    /// <param name="msisdn"></param>
    /// <returns></returns>
    Task<bool> IsUserFirstTopup(string msisdn);

    /// <summary>
    /// register complete user
    /// </summary>
    /// <param name="user"></param>
    /// <returns></returns>
    Task<User> RegisterCompleteUser(User user, UserProduct userProduct, int msisdnOtp, int emailOtp, int MediumType);

    /// <summary>
    /// register new user
    /// </summary>
    /// <param name="user"></param>
    /// <returns></returns>
    Task<User> RegisterUser(User user);

    /// <summary>
    /// Add user product
    /// </summary>
    /// <param name="msisdn"></param>
    /// <returns></returns>
    Task<UserProduct> AddProduct(UserProduct userProduct);

    /// <summary>
    /// Rename user product
    /// </summary>
    /// <param name="msisdn"></param>
    /// <param name="Name"></param>
    /// <returns></returns>
    Task<UserProduct> RenameProduct(UserProduct userProduct);

    /// <summary>
    /// Set Default product
    /// </summary>
    /// <param name="msisdn"></param>
    /// <param name="UserId"></param>
    /// <returns></returns>
    Task<UserProduct> SetDefaultProduct(UserProduct userProduct);

    /// <summary>
    /// Check If Product Is already attached with Someone or not
    /// </summary>
    /// <param name="accountId"></param>
    /// <returns></returns>
    /// 

    Task<bool> IsProductAlreadyAttached(string msisdn);

    /// <summary>
    /// newpassword
    /// </summary>
    /// <param name="User"></param>
    /// <returns></returns>
    Task<int> ChangePassword(User user);

    /// <summary>
    /// User delete account
    /// </summary>
    /// <param name="userid"></param>
    ///  /// <param name="email"></param>
    /// <returns></returns>
    Task<DbResult> DeleteAccount(long userid, string email);

    /// <summary>
    /// Get Delete Account Logs
    /// </summary>
    /// <param name="email"></param>
    /// <returns></returns>
    Task<int> GetDeleteAccountLogs(string email);

    /// <summary>
    /// Check if new user
    /// </summary>
    /// <param name="accountId"></param>
    /// <returns>True/False</returns>
    Task<bool> IsNewUser(string accountId);
    Task<bool> IsUserIn12MonthContract(string accountId);
    Task<bool> IsFollowedByPlan12MonthContract(string bundleId);
}