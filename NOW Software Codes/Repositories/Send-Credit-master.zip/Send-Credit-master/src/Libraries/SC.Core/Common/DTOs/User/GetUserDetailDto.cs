﻿namespace SC.Core.Common.DTOs;
public record GetUserDetailDto
{
    public string UserID { get; set; } = default!;
    public string UserStatus { get; set; } = default!;
    public string UserToken { get; set; } = default!;
    public string TokenPurpose { get; set; } = default!;

    public string Avatar { get; set; } = default!;
    public DateTime DateOfBirth { get; set; } = default!;
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public string FrontName { get; set; } = default!;
    public GenderEnum Gender { get; set; } = default!;

    public string Email { get; set; } = default!;
    public string Mobile { get; set; } = default!;
}

