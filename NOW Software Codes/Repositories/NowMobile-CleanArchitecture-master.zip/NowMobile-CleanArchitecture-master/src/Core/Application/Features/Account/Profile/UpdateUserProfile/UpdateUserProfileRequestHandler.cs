﻿using Application.Common.Caching;
using Application.Common.Interfaces.Repositories;
using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.Account.Profile.UpdateUserProfile;
public class UpdateUserProfileRequestHandler : IRequestHandler<UpdateUserProfileRequest, Result<UserInfo>>
{
    #region Fields

    private readonly IStringLocalizer<UpdateUserProfileRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly CallBackSettings _callBackSettings;
    private readonly ProfileSettings _profileSettings;

    #endregion

    #region Ctor

    public UpdateUserProfileRequestHandler(

        IStringLocalizer<UpdateUserProfileRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService,
        ICurrentUser currentUser,
        IOptions<ProfileSettings> profileSettings,
        IOptions<CallBackSettings> callBackSettings,
        IMapper mapper)
    {

        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _cacheService = cacheService;
        _cacheKeyService = cacheKeyService;
        _currentUser = currentUser;
        _mapper = mapper;
        _callBackSettings = callBackSettings.Value;
        _profileSettings = profileSettings.Value;
    }

    #endregion

    public async Task<Result<UserInfo>> Handle(UpdateUserProfileRequest request, CancellationToken cancellationToken)
    {
        var userId = _currentUser.GetUserId();

        //update profile info
        await _unitOfWork.UserRepo.UpdateUserDetails(userId, request.FirstName, request.LastName, request.MailSubscription);

        //Clear cahe beacuse user password updated
        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, _currentUser.GetUserEmail()!), cancellationToken);
        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, userId.ToString()), cancellationToken);
        var userProducts = await _unitOfWork.UserRepo.GetUserProducts(userId);
        if (userProducts.Any())
        {
            foreach (var item in userProducts)
            {
                await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, item.Msisdn!), cancellationToken);
            }
        }

        var user = await _unitOfWork.UserRepo.GetUserByIdAsync(_currentUser.GetUserId());
        var userInfo = _mapper.Map<UserInfo>(user!);
        if (!string.IsNullOrEmpty(user!.Image))
        {
            userInfo.Image = $"{_callBackSettings.WebBaseUrl}{_profileSettings.VirtualDirectoryName}/{user.Id}/{user.Image}";
        }

        return Result<UserInfo>.Success(userInfo, _localizer[CustomStatusKey.Success]);
    }
}
