﻿using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Request
{
    public class SaveUserProductRequestModel
    {
        public ProductType ProductId { get; set; }
        public string ProductRef { get; set; }
        public string PUKCode { get; set; }
    }
}
