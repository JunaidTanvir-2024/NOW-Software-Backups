﻿namespace SC.Core.Features.Users.Responses;
public class GetTokenResponse
{
    public TokensDto TokenInfo { get; set; } = default!;
}

