namespace FH.Core.DTOs.Database;
public sealed class OperatorAliasDto
{
    public sealed record Request
    {
        public required long OperatorId { get; set; }
        public required string OperatorNameAlias { get; set; }
        public required string OperatorDescription { get; set; }
    }

    public sealed record Response
    {
    }
}
