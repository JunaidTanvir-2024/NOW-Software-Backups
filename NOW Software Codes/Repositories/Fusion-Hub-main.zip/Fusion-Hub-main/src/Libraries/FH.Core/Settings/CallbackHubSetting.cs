namespace FH.Core.Settings;
public sealed class CallbackHubSetting
{
    public const string SectionName = nameof(CallbackHubSetting);
    public required string BaseUrl { get; init; }
    public required Endpoint Endpoints { get; set; }
    public sealed record Endpoint
    {
        public required string DTOneTransaction { get; init; }
    }
}
