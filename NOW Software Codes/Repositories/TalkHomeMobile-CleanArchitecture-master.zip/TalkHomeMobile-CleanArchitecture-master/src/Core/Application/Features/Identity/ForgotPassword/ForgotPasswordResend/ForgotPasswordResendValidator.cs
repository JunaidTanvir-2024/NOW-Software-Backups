﻿namespace Application.Features.Identity.ForgotPassword.ForgotPasswordResend;
public class ForgotPasswordResendValidator : AbstractValidator<ForgotPasswordResendRequest>
{
    public ForgotPasswordResendValidator(ICommonService commonService)
    {
        RuleFor(data => data.EmailAddress)
            .Cascade(CascadeMode.Stop)
            .NotNull().NotEmpty()
            .Must(p => commonService.IsValidEmailAddress(p))
            .WithMessage("Invalid Email Address");
    }
}