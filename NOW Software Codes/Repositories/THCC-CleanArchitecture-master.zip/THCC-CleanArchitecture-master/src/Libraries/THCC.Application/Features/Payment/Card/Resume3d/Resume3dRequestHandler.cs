﻿using Newtonsoft.Json;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.Card.Resume3d;

public class Resume3dRequestHandler : IRequestHandler<Resume3dRequest, object>
{
    #region Fields

    private readonly IPaymentService _paymentService;
    private readonly IPaymentRepository _paymentRepo;
    private readonly ILogger _logger;

    #endregion

    #region Ctors

    public Resume3dRequestHandler(
        IPaymentService paymentService,
        IPaymentRepository paymentRepo,
        ILogger logger)
    {
        _paymentService = paymentService;
        _paymentRepo = paymentRepo;
        _logger = logger;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(Resume3dRequest request, CancellationToken cancellationToken)
    {
        var orderDetails = await _paymentRepo.GetOrderDetails(null!, request.TransactionId.Trim());
        if (orderDetails?.TransactionId!.Equals(request.TransactionId, StringComparison.InvariantCultureIgnoreCase) != true
                || orderDetails.OrderStatus != OrderStatus.Created)
        {
            _logger.Debug("Invalid resume data: " + JsonConvert.SerializeObject(request));
            return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
        }

        return await _paymentService.HandleCardPaymentResume3dRequest(
                            transactionId: request.TransactionId,
                            orderId: orderDetails.Id);
    }

    #endregion
}