﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PushNotifications.Controllers
{
    [ApiController]
    public class PushController : ControllerBase
    {
        private readonly ILogger Logger;
        private IPush_BL PushBl;
        public PushController(ILogger logger, IPush_BL pushBl)
        {
            Logger = logger;
            PushBl = pushBl;
        }

        [HttpPost]
        [Route("push/sendFCMPush")]
        public async Task<IActionResult> SendFCMPush(FCMPushRequest payload)
        {
            try
            {

                //var response = await PushBl.SendPush(request);
                //return Ok(response);
                var jsonBody = string.Empty;
                JObject fcm = new JObject();
                //var data = new
                //{
                //    to = request.DeviceToken,
                //    notification=new { 
                //        title="Portugal vs. Denmark",
                //        body="great match!" 
                //    },
                //    data = new
                //    {
                //        notification = new { request.Title, request.Body }
                //    }
                //};


                if (payload.NotificationType == FCMNotificationTypes.FCMNotificationMessage)
                {

                    if (payload.MessageBody != null || payload.MessageTitle != null)
                        fcm["notification"] = new JObject();
                    if (payload.MessageBody != null)
                        fcm["notification"]["body"] = payload.MessageBody;
                    if (payload.MessageTitle != null)
                        fcm["notification"]["title"] = payload.MessageTitle;

                    fcm["notification"]["sound"] = "default";
                    var notiMessage = new
                    {
                        to = payload.DeviceToken,
                        notification = fcm["notification"]
                    };

                    jsonBody = JsonConvert.SerializeObject(notiMessage);
                }
                else if (payload.NotificationType == FCMNotificationTypes.FCMDataMessage)
                {

                    fcm["data"] = new JObject();
                    fcm["data"]["tha"] = new JObject();
                    fcm["data"]["tha"]["sip_calling"] = payload.sip_calling;
                    fcm["data"]["tha"]["call_uuid"] = payload.call_uuid;
                    fcm["data"]["tha"]["call_type"] = payload.CallType;
                    fcm["data"]["tha"]["from_caller"] = payload.FromCaller;

                    var dataMessage = new
                    {
                        to = payload.DeviceToken,
                        data = fcm["data"]
                    };



                    jsonBody = JsonConvert.SerializeObject(dataMessage);
                }

                var response = await PushBl.SendToFCM(jsonBody);
                if (response.errorCode != 0)
                {
                    Logger.Information($"Class: PushController, Method: SendFCMPush Error, Parameters=> requestJson: {JsonConvert.SerializeObject(payload)} responseJSon {JsonConvert.SerializeObject(response)}");
                }
                return Ok(response);



            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: PushController, Method: SendFCMPush, Parameters=> requestJson: {JsonConvert.SerializeObject(payload)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("push/sendFCMPushToDevices")]
        public async Task<IActionResult> sendFCMPushToDevices(FCMPushRequest payload)
        {
            try
            {

                //var response = await PushBl.SendPush(request);
                //return Ok(response);
                var jsonBody = string.Empty;
                JObject fcm = new JObject();
                //var data = new
                //{
                //    to = request.DeviceToken,
                //    notification=new { 
                //        title="Portugal vs. Denmark",
                //        body="great match!" 
                //    },
                //    data = new
                //    {
                //        notification = new { request.Title, request.Body }
                //    }
                //};


                if (payload.NotificationType == FCMNotificationTypes.FCMNotificationMessage)
                {

                    if (payload.MessageBody != null || payload.MessageTitle != null)
                        fcm["notification"] = new JObject();
                    if (payload.MessageBody != null)
                        fcm["notification"]["body"] = payload.MessageBody;
                    if (payload.MessageTitle != null)
                        fcm["notification"]["title"] = payload.MessageTitle;

                    fcm["notification"]["sound"] = "enabled";
                    var notiMessage = new
                    {
                        registration_ids = payload.DeviceTokens,
                        notification = fcm["notification"]
                    };

                    jsonBody = JsonConvert.SerializeObject(notiMessage);
                }
                else if (payload.NotificationType == FCMNotificationTypes.FCMDataMessage)
                {

                    fcm["data"] = new JObject();
                    fcm["data"]["tha"] = new JObject();
                    fcm["data"]["tha"]["sip_calling"] = payload.sip_calling;
                    fcm["data"]["tha"]["call_uuid"] = payload.call_uuid;

                    var dataMessage = new
                    {
                        registration_ids = payload.DeviceTokens,
                        data = fcm["data"]
                    };



                    jsonBody = JsonConvert.SerializeObject(dataMessage);
                }

                var response = await PushBl.SendToFCM(jsonBody);
                if (response.errorCode != 0)
                {
                    Logger.Information($"Class: PushController, Method: SendFCMPush Error, Parameters=> requestJson: {JsonConvert.SerializeObject(payload)} responseJSon {JsonConvert.SerializeObject(response)}");
                }
                return Ok(response);



            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: PushController, Method: SendFCMPush, Parameters=> requestJson: {JsonConvert.SerializeObject(payload)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("push/sendAPNSPush")]
        public async Task<IActionResult> SendAPNSPush(APNSPushRequest payload)
        {
            try
            {
                JObject apns = new JObject();
                apns["aps"] = new JObject();

                var jsonBody = string.Empty;
                if (payload.NotificationType == APNSNotificationTypes.APNSRemotePushNotification)
                {


                    if (payload.MessageBody != null || payload.MessageTitle != null)
                    {
                        if (payload.MessageTitle != null)
                        {
                            apns["aps"]["alert"] = new JObject();
                            apns["aps"]["alert"]["body"] = payload.MessageBody;
                            apns["aps"]["alert"]["title"] = payload.MessageTitle;
                            apns["aps"]["sound"] = "default";
                        }
                        else
                        {
                            apns["aps"]["alert"] = payload.MessageBody;
                            apns["aps"]["sound"] = "default";
                        }
                    }
                    jsonBody = JsonConvert.SerializeObject(apns);
                }
                else if (payload.NotificationType == APNSNotificationTypes.APNSXMPPRemotePushNotification)
                {


                    if (payload.xmpp_message != null)
                    {
                        apns["aps"]["content-available"] = 1;
                        apns["body"] = new JObject();
                        apns["body"]["xmpp_message"] = payload.xmpp_message;
                        apns["aps"]["sound"] = "default";

                    }
                    jsonBody = JsonConvert.SerializeObject(apns);
                    Logger.Information($"Class: PushController, Method:xmpp SendAPNSPush Error, Parameters=> jsonBody: {jsonBody}");
                }
                else if (payload.NotificationType == APNSNotificationTypes.APNSVoipPushNotification)
                {


                    apns["aps"]["content-available"] = 1;
                    apns["aps"]["sound"] = "";
                    apns["tha"] = new JObject();
                    apns["tha"]["sip_calling"] = payload.sip_calling;
                    apns["tha"]["call_uuid"] = payload.call_uuid;
                    apns["tha"]["call_type"] = payload.CallType;
                    apns["tha"]["from_caller"] = payload.FromCaller;
                    jsonBody = JsonConvert.SerializeObject(apns);


                }
                var response = await PushBl.SendToIOS(jsonBody, payload.DeviceToken, payload.NotificationType, payload.server);
                if (response.errorCode != 0)
                {
                    Logger.Information($"Class: PushController, Method: SendAPNSPush Error, Parameters=> requestJson: {JsonConvert.SerializeObject(payload)} responseJSon {JsonConvert.SerializeObject(response)}");
                }
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: PushController, Method: sendAPNSPush, Parameters=> requestJson: {JsonConvert.SerializeObject(payload)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }


        [HttpPost]
        [Route("push/sendAPNSPushToDevices")]
        public async Task<IActionResult> sendAPNSPushToDevices(APNSPushRequest payload)
        {
            try
            {
                JObject apns = new JObject();
                apns["aps"] = new JObject();

                var jsonBody = string.Empty;
                if (payload.NotificationType == APNSNotificationTypes.APNSRemotePushNotification)
                {


                    if (payload.MessageBody != null || payload.MessageTitle != null)
                    {
                        if (payload.MessageTitle != null)
                        {
                            apns["aps"]["alert"] = new JObject();
                            apns["aps"]["alert"]["body"] = payload.MessageBody;
                            apns["aps"]["alert"]["title"] = payload.MessageTitle;
                            apns["aps"]["sound"] = "default";
                        }
                        else
                        {
                            apns["aps"]["alert"] = payload.MessageBody;
                            apns["aps"]["sound"] = "default";
                        }
                    }
                    jsonBody = JsonConvert.SerializeObject(apns);
                }
                else if (payload.NotificationType == APNSNotificationTypes.APNSVoipPushNotification)
                {


                    apns["aps"]["content-available"] = 1;
                    apns["aps"]["sound"] = "";

                    apns["tha"] = new JObject();
                    apns["tha"]["sip_calling"] = payload.sip_calling;
                    apns["tha"]["call_uuid"] = payload.call_uuid;
                    jsonBody = JsonConvert.SerializeObject(apns);


                }
                var response = await PushBl.SendToIOSBulk(jsonBody, payload.DeviceTokens, payload.NotificationType, payload.server);
                if (response.errorCode != 0)
                {
                    Logger.Information($"Class: PushController, Method: SendAPNSPush Error, Parameters=> requestJson: {JsonConvert.SerializeObject(payload)} responseJSon {JsonConvert.SerializeObject(response)}");
                }
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: PushController, Method: sendAPNSPush, Parameters=> requestJson: {JsonConvert.SerializeObject(payload)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        // Push with tls not recomended 

        //[HttpPost]
        //[Route("push/sendAPNS")]
        //public async Task<IActionResult> PushNotification(PushRequest request)
        //{
        //    int port = 2195;
        //    string hostname = "gateway.sandbox.push.apple.com";

        //    //I have removed certificate. Keep your certificate in wwwroot/certificate location. This location is not mandatory
        //    string certificatePath = $@"{Env.WebRootPath}\Certificate\Shahbaz_Certificates.p12";
        //    X509Certificate2 clientCertificate = new X509Certificate2(System.IO.File.ReadAllBytes(certificatePath), "");
        //    X509Certificate2Collection certificatesCollection = new X509Certificate2Collection(clientCertificate);

        //    TcpClient client = new TcpClient(AddressFamily.InterNetwork);
        //    await client.ConnectAsync(hostname, port);

        //    SslStream sslStream = new SslStream(
        //        client.GetStream(), false,
        //        new RemoteCertificateValidationCallback(ValidateServerCertificate),
        //        null);

        //    try
        //    {
        //        await sslStream.AuthenticateAsClientAsync(hostname, certificatesCollection, SslProtocols.Tls, false);
        //        MemoryStream memoryStream = new MemoryStream();
        //        BinaryWriter writer = new BinaryWriter(memoryStream);
        //        writer.Write((byte)0);
        //        writer.Write((byte)0);
        //        writer.Write((byte)32);

        //        writer.Write(HexStringToByteArray(request.DeviceToken.ToUpper()));
        //        string payload1 = "{\"aps\":{\"alert\":\"" + request.Title + "\",\"badge\":0,\"sound\":\"default\"}}";

        //        var payload = new Newtonsoft.Json.Linq.JObject{
        //                {
        //                    "aps", new Newtonsoft.Json.Linq.JObject
        //                    {
        //                        {
        //                            "alert", new Newtonsoft.Json.Linq.JObject
        //                                {
        //                                    {"title", request.Title},
        //                                    {"body", request.Body},
        //                                    {"action-loc-key", "PLAY"}
        //                                }
        //                        },
        //                        {
        //                            "sound", "default"
        //                        }
        //                        ,
        //                        {
        //                            "badge", 0
        //                        }
        //                    }
        //                }
        //            };
        //        var jsonBody = JsonConvert.SerializeObject(payload);


        //        writer.Write((byte)0);
        //        writer.Write((byte)jsonBody.Length);
        //        byte[] b1 = System.Text.Encoding.UTF8.GetBytes(jsonBody);
        //        writer.Write(b1);
        //        writer.Flush();
        //        byte[] array = memoryStream.ToArray();
        //        sslStream.Write(array);
        //        sslStream.Flush();
        //        client.Dispose();
        //    }
        //    catch (AuthenticationException ex)
        //    {
        //        client.Dispose();
        //    }
        //    catch (Exception e)
        //    {
        //        client.Dispose();
        //    }

        //    return Content("Notification sent. Check your device.");
        //}

        //private bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        //{
        //    if (sslPolicyErrors == SslPolicyErrors.None)
        //        return true;
        //    Console.WriteLine("Certificate error: { 0}", sslPolicyErrors);
        //    return false;
        //}

        //private static byte[] HexStringToByteArray(string hex)
        //{
        //    return Enumerable.Range(0, hex.Length)
        //                     .Where(x => x % 2 == 0)
        //                     .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
        //                     .ToArray();
        //}



        ///// <summary>
        ///// Certificate base user noti 
        ///// </summary>
        ///// <param name="model"></param>
        ///// <returns></returns>
        //[HttpPost]
        //[Route("push/APNSWithHTTP2")]
        //public  string APNSWithHTTP2(PushRequest model)
        //{
        //    var url = string.Format("https://api.development.push.apple.com/3/device/{0}", model.DeviceToken);
        //    var certData = System.IO.File.ReadAllBytes($@"{Env.WebRootPath}\Certificate\Shahbaz_Certificates.p12");
        //    var certificate = new X509Certificate2(certData, "", X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
        //    var topic = "com.distribution.talkhomeapps"; // App bundle Id
        //    using (var httpHandler = new HttpClientHandler { SslProtocols = SslProtocols.Tls12 })
        //    {
        //        httpHandler.ClientCertificates.Add(certificate);

        //        using (var httpClient = new HttpClient(httpHandler, true))
        //        using (var request = new HttpRequestMessage(HttpMethod.Post, url))
        //        {
        //            request.Headers.Add("apns-id", Guid.NewGuid().ToString("D"));
        //            request.Headers.Add("apns-push-type", "alert");
        //            request.Headers.Add("apns-priority", "10");
        //            request.Headers.Add("apns-topic", topic);

        //            var payload = new Newtonsoft.Json.Linq.JObject{
        //                {
        //                    "aps", new Newtonsoft.Json.Linq.JObject
        //                    {
        //                        {
        //                            "alert", new Newtonsoft.Json.Linq.JObject
        //                                {
        //                                    {"title", model.Title},
        //                                    {"body", model.Body},
        //                                    {"action-loc-key", "PLAY"}
        //                                }
        //                        },
        //                        {
        //                            "sound", "default"
        //                        }
        //                        ,
        //                        {
        //                            "badge", 0
        //                        }
        //                    }
        //                }
        //            };

        //            request.Content = new StringContent(payload.ToString());
        //            request.Version = new Version(2, 0);
        //            try
        //            {
        //                using (var httpResponseMessage = httpClient.SendAsync(request).GetAwaiter().GetResult())
        //                {
        //                    var responseContent = httpResponseMessage.Content.ReadAsStringAsync();
        //                    return $"status: {(int)httpResponseMessage.StatusCode} content: {JsonConvert.SerializeObject (responseContent)}";
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
        //                Logger.Error($"Class: PushController, Method: SendPush, Parameters=> requestJson: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
        //                return $"status: {ApiStatusCodes.CodeException} content: {errorMessage}";
        //            }
        //        }
        //    }
        //}
    }
}