﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Utility
{
    public class DbResponse<T>
    {
        public int ErrorCode { get; set; }  // 1 = Success, 2 = Error
        public string Message { get; set; }
        public T Data { get; set; }
    }
}
