﻿
using ILogger = Serilog.ILogger;
namespace Infrastructure.Services;

internal sealed class CommonServices : ICommonService
{
    #region Fields

    private readonly PhoneNumberUtil _phoneNumberUtil;
    //private readonly ILogger _logger;
    private readonly IHttpContextAccessor _context;
    private readonly IConfiguration _configuration;
    public static readonly string EmailValidation_Regex = @"^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$";
    public static readonly Regex EmailValidation_Regex_Compiled = new(EmailValidation_Regex, RegexOptions.IgnoreCase);
    public static readonly string EmailValidation_Regex_JS = $"/{EmailValidation_Regex}/";

    #endregion

    #region Ctor

    public CommonServices(
        PhoneNumberUtil phoneNumberUtil,
       // ILogger logger,
        IHttpContextAccessor httpContextAccessor,
        IConfiguration configuration)
    {
        _phoneNumberUtil = phoneNumberUtil;
       // _logger = logger;
        _context = httpContextAccessor;
        _configuration = configuration;
    }

    #endregion

    #region Msisdn 

    public bool IsValidMsisdn(string msisdn)
    {
        try
        {
            var formattedMsisdn = _phoneNumberUtil
                .Format(_phoneNumberUtil.Parse(msisdn, "GB"), PhoneNumberFormat.E164)
                .Replace("+", "");

            var phoneNumber = _phoneNumberUtil.Parse(formattedMsisdn, "GB");
            return _phoneNumberUtil.IsValidNumber(phoneNumber);
        }
        catch (Exception ex)
        {
          //  _logger.Error(ex.Message);
            return false;
        }
    }

    public string FormatMsisdn(string msisdn)
    {
        try
        {
            var formattedMsisdn = _phoneNumberUtil
                .Format(_phoneNumberUtil.Parse(msisdn, "GB"), PhoneNumberFormat.E164)
                .Replace("+", "");

            return formattedMsisdn;
        }
        catch (Exception ex)
        {
           // _logger.Error(ex.Message);
            return msisdn;
        }
    }

    #endregion

    #region Email

    public bool IsValidEmailAddress(string email, bool useRegEx = false, bool requireDotInDomainName = false)
    {
        try
        {
            var isValid = useRegEx
                     // see RegEx comments
                     ? email is not null && EmailValidation_Regex_Compiled.IsMatch(email)

        // ref.: https://stackoverflow.com/a/33931538/1233379
        : new EmailAddressAttribute().IsValid(email);

            if (isValid && requireDotInDomainName)
            {
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                var arr = email.Split('@', StringSplitOptions.RemoveEmptyEntries);
#pragma warning restore CS8602 // Dereference of a possibly null reference.
                isValid = arr.Length == 2 && arr[1].Contains(".");
            }
            return isValid;
        }
        catch (Exception ex)
        {
           //_logger.Error(ex.Message);
            return false;
        }
    }

    #endregion

    #region Device

    public bool IsWebRequest()
    {
        if (_context.HttpContext!.Request.Headers.ContainsKey("x-android-device")
            || _context.HttpContext.Request.Headers.ContainsKey("x-ios-device"))
        {
            return false;
        }
        return true;
    }
    public (bool IsMobileRequest, DeviceType? DeviceType, MediumType MediumType) IsAppRequest()
    {
        if (_context.HttpContext!.Request.Headers.ContainsKey("x-android-device"))
        {
            return (true, DeviceType.Android, MediumType.Android);
        }

        if (_context.HttpContext.Request.Headers.ContainsKey("x-ios-device"))
        {
            return (true, DeviceType.IOS, MediumType.IOS);
        }

        return (false, null, MediumType.Web);
    }

    #endregion
}
