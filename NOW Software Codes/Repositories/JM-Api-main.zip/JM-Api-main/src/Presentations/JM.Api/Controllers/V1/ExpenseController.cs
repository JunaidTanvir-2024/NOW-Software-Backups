using JM.Api.Controllers.Common;
using JM.Core.Features.Auth.Expense;
using JM.Core.Utilities.Definitions;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using RW.Common;
using RW.Failures;
using RW.Models;
using RW.Successes;
namespace JM.Api.Controllers.V1;

[Authorize]
public sealed class ExpenseController : V1ApiController
{
	[HttpPost]
	[ProducesResponseType<SuccessPayload<CreateExpense.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.InternalServerError)]
	public async Task<ActionResult> AddExpense([FromBody] CreateExpense.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}

	[HttpGet]
	[ProducesResponseType<SuccessPayload<GetExpenseList.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
	public async Task<ActionResult> GetExpenses([FromQuery] GetExpenseList.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
	[HttpGet("id")]
	[ProducesResponseType<SuccessPayload<GetExpense.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
	public async Task<ActionResult> GetExpense([FromQuery] GetExpense.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
	[HttpPatch]
	[ProducesResponseType<SuccessPayload<UpdateExpense.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.InternalServerError)]
	public async Task<ActionResult> UpdateExpense([FromBody] UpdateExpense.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
	[HttpDelete]
	[ProducesResponseType<SuccessPayload<RemoveExpense.Response>>(AppConstant.StatusCode.Success)]
	[ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
	[ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.BadRequest)]
	public async Task<ActionResult> RemoveExpense([FromQuery] RemoveExpense.Query query)
	{
		var result = await Mediator.Send(query, HttpContext.RequestAborted);
		if (result.IsSuccess)
		{
			return StatusCode(AppConstant.StatusCode.Success, result);
		}
		return StatusCode(result.Code, result);
	}
}
