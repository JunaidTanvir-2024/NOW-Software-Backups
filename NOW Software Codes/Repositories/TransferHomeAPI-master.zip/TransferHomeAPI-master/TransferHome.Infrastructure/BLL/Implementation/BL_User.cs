﻿using Microsoft.Extensions.Options;
using MimeKit;
using PhoneNumbers;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using TransferHome.Infrastructure.Services.Interfaces;
using TransferHome.Models.Configurations;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.Contracts.Response;
using TransferHome.Models.DAOs;
using TrasnferHome.Infrastructure.BLL.Interfaces;
using TrasnferHome.Infrastructure.DAL.Interfaces;
using TrasnferHome.Models.Configurations;
using TrasnferHome.Models.Contracts;
using TrasnferHome.Models.DAOs;
using TrasnferHome.Models.Utility;

namespace TrasnferHome.Infrastructure.BLL.Implementation
{
    public class BL_User : IBL_User
    {
        private readonly IDL_User DL;
        private readonly SmtpConfig SmtpConfig;
        private readonly RedirectUrls RedirectUrls;
        private readonly TokensConfig TokensConfig;
        private readonly ILogger Logger;
        private readonly ISmsService SmsService;
        private readonly CurrencyConfig CurrencyConfig;
        private readonly InAppPurchaseConfig InAppPurchaseConfig;
        private readonly IPushNotificationService PushService;


        public BL_User(ILogger logger, IDL_User dl, IOptions<SmtpConfig> smtpConfig, IOptions<RedirectUrls> redirectUrls, IOptions<TokensConfig> tokensConfig, ISmsService smsService, IOptions<CurrencyConfig> currencyConfig, IOptions<InAppPurchaseConfig> inAppPurchaseConfig, IPushNotificationService pushService)
        {
            DL = dl;
            SmtpConfig = smtpConfig.Value;
            RedirectUrls = redirectUrls.Value;
            TokensConfig = tokensConfig.Value;
            Logger = logger;
            SmsService = smsService;
            CurrencyConfig = currencyConfig.Value;
            InAppPurchaseConfig = inAppPurchaseConfig.Value;
            PushService = pushService;
        }

        public async Task<GenericApiResponse<bool>> IsEmailAlreadyExist(IsEmailAlreadyExistRequestModel model)
        {
            var response = await DL.IsUserExistByEmail(model.Email);
            if (response == 1)
            {
                return GenericApiResponse<bool>.Success(true, "Email exist");
            }
            else
            {
                return GenericApiResponse<bool>.Failure(false, "Email does not exist", ApiStatusCodes.EmailNotExist);
            }
        }

        public async Task<GenericApiResponse<bool>> IsPhoneNumberAlreadyExist(IsPhoneNumberAlreadyExistRequestModel model)
        {
            var response = await DL.IsUserExistByPhoneNumber(model.PhoneNumber);
            if (response == 1)
            {
                return GenericApiResponse<bool>.Success(true, "PhoneNumber already exist");
            }
            else
            {
                return GenericApiResponse<bool>.Failure(false, "PhoneNumber does not exist", ApiStatusCodes.RecordNotFound);
            }
        }

        public async Task<GenericApiResponse<LoginResponseModel>> RegisterSocialMediaUser(ExternalLoginRequestModel model)
        {
            try
            {
                SocialLogins socialLogin = new SocialLogins();
                SocialUserViewModel responseModel = new SocialUserViewModel();

                if (model.socialLoginType == (int)LoginType.Google)
                {
                    var googleUser = await socialLogin.GetUserFromGoogle(model.accessToken);
                    if (googleUser == null)
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure("Unable to fetch user from social app", ApiStatusCodes.UnableToFetchSocialAppUser);
                    }
                    else
                    {
                        responseModel = new SocialUserViewModel { Id = googleUser.id, Email = googleUser.email, name = googleUser.name, Picture = googleUser.picture, Type = LoginType.Google };
                    }

                }
                else if (model.socialLoginType == (int)LoginType.Facebook)
                {
                    var facebookUser = await socialLogin.GetUserFromFacebook(model.accessToken);
                    if (facebookUser == null)
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure("Unable to fetch user from social app", ApiStatusCodes.UnableToFetchSocialAppUser);
                    }

                    if (string.IsNullOrEmpty(facebookUser.email))
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure(null, "Invalid Social Account, Email not exist for the account", ApiStatusCodes.UnableToFetchSocialAppUser);
                    }

                    responseModel = new SocialUserViewModel { Id = facebookUser.id, Email = facebookUser.email, name = facebookUser.name, Picture = facebookUser.picture.Data.url, Type = LoginType.Facebook };
                }

                var existingUser = await DL.GetUserByEmail(responseModel.Email);

                if (existingUser != null)
                {
                    var User = new LoginResponseModel()
                    {
                        FirstName = existingUser.FirstName,
                        LastName = existingUser.LastName,
                        PhoneNumber = existingUser.PhoneNumber,
                        Email = existingUser.Email,
                        IsNotificationsOn = existingUser.IsNotificationsOn,
                        Id = existingUser.Id,
                        Balance = existingUser.Balance,
                        BalanceCurrency = existingUser.BalanceCurrency,
                        BalanceCurrencySymbol = existingUser.BalanceCurrencySymbol,
                        IOSAppVersion = InAppPurchaseConfig.IOSAppversion,
                        MailSubscription = existingUser.MailSubscription
                    };

                    return GenericApiResponse<LoginResponseModel>.Success(User, "Login Successful");
                }
                else
                {
                    var names = responseModel.name.Split(' ');

                    var newUser = await DL.RegisterUserByEmail(new DBUser()
                    {
                        FirstName = names[0],
                        LastName = names[names.Length - 1],
                        Email = responseModel.Email,
                        SignUpType = (SignUpType)model.socialLoginType,
                        IsEmailVerified = true,
                        Role = Roles.User,
                        BalanceCurrency = "USD",
                        BalanceCurrencySymbol = "$",
                        MailSubscription = model.MailSubscription
                    });

                    var User = new LoginResponseModel()
                    {
                        FirstName = names[0],
                        LastName = names[names.Length - 1],
                        Email = responseModel.Email,
                        IsNotificationsOn = true,
                        Id = newUser,
                        Balance = 0m,
                        BalanceCurrency = "USD",
                        BalanceCurrencySymbol = "$",
                        IOSAppVersion = InAppPurchaseConfig.IOSAppversion,
                        MailSubscription = model.MailSubscription
                    };

                    return GenericApiResponse<LoginResponseModel>.Success(User, "Login Successful");
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<bool>> ReSendEmailVerificationToken(ReSendTokenRequestModel model)
        {
            try
            {
                //Check User Already Exist
                var user = await DL.GetUserByEmail(model.Email);
                if (user == null)
                {
                    return GenericApiResponse<bool>.Failure("User not registered with this email.", ApiStatusCodes.UserNotFound);
                }

                if (user.IsEmailVerified == false)
                {
                    var userToken = new DBUserTokens()
                    {
                        Token = Guid.NewGuid().ToString(),
                        TokenTypeId = (int)UserTokenTypes.EmailVerificationToken,
                        UserId = user.Id
                    };

                    var tResult = await DL.ReSendToken(userToken);
                    if (tResult > 0)
                    {
                        var builder = new BodyBuilder();

                        using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\ConfirmEmailTemplate.html").Replace("~\\", ""))))
                        {
                            builder.HtmlBody = SourceReader.ReadToEnd();
                        }

                        string messageBody = string.Format(builder.HtmlBody,
                            user.Email,
                            RedirectUrls.VerifyEmailRedirectUrl + userToken.Token,
                            user.Email
                            );

                        SendEmailToCustomer(user.Email, messageBody, "Re-Verification Email");

                        return GenericApiResponse<bool>.Success(true, "Verification token sent successfully.");
                    }
                    else
                    {
                        return GenericApiResponse<bool>.Failure("Something went wrong on the server.", ApiStatusCodes.DBError);
                    }
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Email is already verified.", ApiStatusCodes.EmailAlreadyVerified);
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<bool>> ResendPinNumber(ResendPinNumberRequestModel model)
        {
            try
            {
                //Validate Phone Number
                bool IsValid = true;
                string FormattedPhoneNumber = model.PhoneNumber;
                int countryCode = 0;

                //Need to Validate Msisdn
                try
                {
                    var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                    PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

                    var isValid = phoneNumberUtil.IsValidNumber(Number);

                    if (isValid)
                    {
                        FormattedPhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164).Replace("+", "").Trim();
                        countryCode = Number.CountryCode;
                    }
                    else
                    {
                        IsValid = false;
                    }
                }
                catch
                {
                    IsValid = false;
                }

                if (IsValid)
                {
                    //Check User Already Exist
                    var user = await DL.GetUserByPhoneNumber(FormattedPhoneNumber);
                    if (user == null)
                    {
                        return GenericApiResponse<bool>.Failure("User not registered with this Phone Number.", ApiStatusCodes.UserNotFound);
                    }

                    //Send PinNumber
                    SmsService.ReSendSms(countryCode, user.PhoneNumber, $"{user.PinNumber} is your TransferHome verification code");

                    return GenericApiResponse<bool>.Success(true, "Verification Pin sent successfully.");
                }
                else
                {
                    return GenericApiResponse<bool>.Failure(false, "Phone number is invalid.", ApiStatusCodes.InvalidNumber);
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<LoginResponseModel>> LoginSignUpByEmail(LoginSignUpEmailRequestModel model)
        {
            try
            {
                //Check User Already Exist
                var response = await DL.GetUserByEmail(model.Email);
                if (response != null)
                {
                    if (CryptoHelper.Hash(model.Password) == response.Password)
                    {
                        if (response.IsEmailVerified == true)
                        {
                            return await GenerteTokenAndSendEmail(response, "Login");
                        }
                        else
                        {
                            return GenericApiResponse<LoginResponseModel>.Failure(null, "Email verification is pending", ApiStatusCodes.EmailNotVerified);
                        }
                    }
                    else
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure(null, "Invalid password.", ApiStatusCodes.InvalidEmailPassword);
                    }
                }
                else
                {
                    //Register User by Email
                    DBUser user = new DBUser()
                    {
                        Email = model.Email,
                        Password = CryptoHelper.Hash(model.Password),
                        Role = Roles.User,
                        SignUpType = SignUpType.Email,
                        MailSubscription = model.MailSubscription,
                        BalanceCurrency = "USD",
                        BalanceCurrencySymbol = "$"
                    };
                    var result = await DL.RegisterUserByEmail(user);
                    if (result < 1)
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure(null, "Something went wrong on server.", ApiStatusCodes.DBError);
                    }
                    user.Id = result;
                    return await GenerteTokenAndSendEmail(user, "Register");
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<bool>> Logout(string UDID)
        {
            try
            {
                await DL.MarkDeviceAsInActive(UDID);
                return GenericApiResponse<bool>.Success("Success.");
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<object>> LoginSignUpByPhoneNumber(LoginSignUpPhoneNumberRequestModel model)
        {
            //Validate Phone Number
            bool IsValid = true;
            string FormattedPhoneNumber = model.PhoneNumber;
            int countryCode = 0;

            //Need to Validate Msisdn
            try
            {
                var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);
                countryCode = Number.CountryCode;

                var isValid = phoneNumberUtil.IsValidNumber(Number);

                if (isValid)
                {
                    FormattedPhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164).Replace("+", "").Trim();
                }
                else
                {
                    IsValid = false;
                }
            }
            catch
            {
                IsValid = false;
            }

            if (IsValid)
            {
                //Check User Already Exist
                var result = await DL.GetUserByPhoneNumber(FormattedPhoneNumber);

                if (result != null)
                {
                    if (!result.IsActive)
                    {
                        await DL.MarkDeviceAsActive(result.Id, model.UDID, model.DeviceType.Value, FormattedPhoneNumber);

                        PushService.SendPushNotificationToSpecificUsers(new List<string>() { result.PhoneNumber }, "Attention", "Unfortunately, you can't log in to your account. Please contact Customer Support on hello@transferhome.org");
                        return GenericApiResponse<object>.Failure(null, "User is blocked", ApiStatusCodes.InvalidNumber);
                    }

                    if (model.MailSubscription != null)
                    {
                        await DL.EditProfile(new EditProfileRequestModel() { MailSubscription = (bool)model.MailSubscription }, Convert.ToString(result.Id));
                    }

                    //Mark Device as active
                    //DL.MarkDeviceAsActive(result.Id, model.UDID, model.DeviceType.Value, model.PhoneNumber);
                    SmsService.SendSms(result.PhoneNumber, $"{result.PinNumber} is your TransferHome verification code");
                    return GenericApiResponse<object>.Success(new LoginSignUpPhoneNumberResponseModel() { IsExisting = true }, "Verification Pin sent successfully");
                }
                else
                {
                    var cultureInfo = System.Globalization.CultureInfo.GetCultures(System.Globalization.CultureTypes.AllCultures).Where(c => c.Name.EndsWith("-" + model.PhoneNumberCountryCode)).First();
                    var regionCulture = new System.Globalization.RegionInfo(cultureInfo.LCID);

                    string ISOCurrencySymbol = regionCulture.ISOCurrencySymbol;
                    string CurrencySymbol = regionCulture.CurrencySymbol;

                    string[] Currencies = CurrencyConfig.AllowedCurrencies;

                    if (!Currencies.Contains(ISOCurrencySymbol))
                    {
                        ISOCurrencySymbol = "USD";
                        CurrencySymbol = "$";
                    }

                    //Check currency
                    var validCurrency = CurrencyConfig.CountryWiseCurrency.Where(x => x.Key == countryCode.ToString()).Select(x => x.Value).FirstOrDefault();
                    if (validCurrency != null && Currencies.Contains(validCurrency))
                    {
                        switch (validCurrency)
                        {
                            case "EUR":
                                ISOCurrencySymbol = validCurrency;
                                CurrencySymbol = "€";
                                break;
                            case "USD":
                                ISOCurrencySymbol = validCurrency;
                                CurrencySymbol = "$";
                                break;
                            case "GBP":
                                ISOCurrencySymbol = validCurrency;
                                CurrencySymbol = "£";
                                break;
                        }
                    }


                    Random RandNum = new Random();

                    //Register User
                    DBUser user = new DBUser()
                    {
                        PhoneNumber = FormattedPhoneNumber,
                        Role = Roles.User,
                        SignUpType = SignUpType.PhoneNumber,
                        BalanceCurrency = ISOCurrencySymbol,
                        BalanceCurrencySymbol = CurrencySymbol,
                        MailSubscription = (model.MailSubscription == null ? false : (bool)model.MailSubscription),
                        UDID = model.UDID,
                        DeviceType = model.DeviceType.Value,
                        PinNumber = RandNum.Next(1000, 9999).ToString()
                    };

                    var response = await DL.RegisterUserByPhoneNumber(user);
                    if (response > 0)
                    {
                        SmsService.SendSms(user.PhoneNumber, $"{user.PinNumber} is your TransferHome verification code");
                        return GenericApiResponse<object>.Success(new LoginSignUpPhoneNumberResponseModel() { IsExisting = false }, "Verification Pin sent successfully");
                    }
                    else
                    {
                        return GenericApiResponse<object>.Failure(new { }, "Record not found", ApiStatusCodes.RecordNotFound);
                    }
                }
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Invalid Number.", ApiStatusCodes.InvalidNumber);
            }
        }

        public async Task<GenericApiResponse<bool>> VerifyEmailbyToken(VerifyEmailRequestModel model, UserTokenTypes tokenType)
        {
            try
            {
                var result = await DL.VerifyToken(model.Token, TokensConfig.EmailTokenExpiryMinutes, (int)tokenType);
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "Email verified successfully");
                }
                else
                {
                    return GenericApiResponse<bool>.Failure(false, "Token is invalid or expired.", ApiStatusCodes.TokenExpiredorInvalid);
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<LoginResponseModel>> VerifyPinNumber(VerifyPinNumberRequestModel model)
        {
            try
            {
                //Validate Phone Number
                bool IsValid = true;
                string FormattedPhoneNumber = model.PhoneNumber;

                //Need to Validate Msisdn
                try
                {
                    var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                    PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

                    var isValid = phoneNumberUtil.IsValidNumber(Number);

                    if (isValid)
                    {
                        FormattedPhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164).Replace("+", "").Trim();
                    }
                    else
                    {
                        IsValid = false;
                    }
                }
                catch
                {
                    IsValid = false;
                }

                if (IsValid)
                {
                    var user = await DL.GetUserByPhoneNumber(FormattedPhoneNumber);
                    if (user == null)
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure(null, "User not exist against the phone number.", ApiStatusCodes.UserNotFound);
                    }

                    if (!user.IsActive)
                    {
                        PushService.SendPushNotificationToSpecificUsers(new List<string>() { user.PhoneNumber }, "Attention", "Unfortunately, you can't log in to your account. Please contact Customer Support on hello@transferhome.org");
                        return GenericApiResponse<LoginResponseModel>.Failure(null, "User is blocked", ApiStatusCodes.InvalidNumber);
                    }

                    if (model.PinNumber.Equals(user.PinNumber))
                    {
                        //Mark device as active
                        var devicesMadeInactive = await DL.MarkDeviceAsActive(user.Id, model.UDID, model.DeviceType.Value, model.PhoneNumber);

                        PushService.SendPushNotificationToSpecificTokens(devicesMadeInactive, "Attention", "Your account is being used by another device.");

                        return GenericApiResponse<LoginResponseModel>.Success(new LoginResponseModel()
                        {
                            FirstName = user.FirstName,
                            LastName = user.LastName,
                            Email = user.Email,
                            PhoneNumber = user.PhoneNumber,
                            Role = user.Role,
                            Id = user.Id,
                            IsNotificationsOn = user.IsNotificationsOn,
                            MailSubscription = user.MailSubscription,
                            Balance = user.Balance,
                            BalanceCurrency = user.BalanceCurrency,
                            BalanceCurrencySymbol = user.BalanceCurrencySymbol,
                            IOSAppVersion = InAppPurchaseConfig.IOSAppversion
                        }, "Login Successfully.");
                    }
                    else
                    {
                        return GenericApiResponse<LoginResponseModel>.Failure(null, "Pin is invalid", ApiStatusCodes.MobilePinExpiredorInvalid);
                    }
                }
                else
                {
                    return GenericApiResponse<LoginResponseModel>.Failure(null, "Phone number is invalid.", ApiStatusCodes.InvalidNumber);
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<bool>> ForgotPassword(ForgotPasswordRequestModel model)
        {
            try
            {
                var user = await DL.GetUserByEmail(model.Email);
                if (user == null)
                {
                    return GenericApiResponse<bool>.Failure("No user exist against this email", ApiStatusCodes.UserNotFound);
                }

                if (user.Id > 0)
                {
                    DBUserTokens userToken = new DBUserTokens()
                    {
                        Token = Guid.NewGuid().ToString(),
                        TokenTypeId = (int)UserTokenTypes.ForgotPasswordVerificationToken,
                        UserId = user.Id
                    };
                    var tResult = await DL.InsertUserToken(userToken);

                    if (tResult > 0)
                    {
                        var builder = new BodyBuilder();

                        using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\ForgotPasswordEmailTemplate.html").Replace("~\\", ""))))
                        {
                            builder.HtmlBody = SourceReader.ReadToEnd();
                        }

                        string messageBody = string.Format(builder.HtmlBody,
                            user.FirstName,
                            RedirectUrls.ForgotPasswordRedirectUrl + userToken.Token,
                            user.Email
                            );

                        SendEmailToCustomer(model.Email, messageBody, "Forgot Password Email");

                        return GenericApiResponse<bool>.Success(true, "Email sent successfully.");
                    }
                    else
                    {
                        return GenericApiResponse<bool>.Failure("Someting went wrong on server.", ApiStatusCodes.DBError);
                    }
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Someting went wrong on server.", ApiStatusCodes.DBError);
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<bool>> ReSendForgotPasswordToken(ReSendTokenRequestModel model)
        {
            try
            {
                //Check User Already Exist
                var user = await DL.GetUserByEmail(model.Email);
                if (user == null)
                {
                    return GenericApiResponse<bool>.Failure("User not registered with this email.", ApiStatusCodes.UserNotFound);
                }

                if (user.IsEmailVerified == false)
                {
                    return GenericApiResponse<bool>.Failure("Email is not verified.", ApiStatusCodes.EmailNotVerified);
                }
                else
                {
                    var userToken = new DBUserTokens()
                    {
                        Token = Guid.NewGuid().ToString(),
                        TokenTypeId = (int)UserTokenTypes.ForgotPasswordVerificationToken,
                        UserId = user.Id
                    };

                    var tResult = await DL.ReSendToken(userToken);
                    if (tResult > 0)
                    {
                        var builder = new BodyBuilder();

                        using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\ForgotPasswordEmailTemplate.html").Replace("~\\", ""))))
                        {
                            builder.HtmlBody = SourceReader.ReadToEnd();
                        }

                        string messageBody = string.Format(builder.HtmlBody,
                            user.Email,
                            RedirectUrls.VerifyEmailRedirectUrl + userToken.Token,
                            user.Email
                            );

                        SendEmailToCustomer(user.Email, messageBody, "Re-Verification Forgot Password Email");

                        return GenericApiResponse<bool>.Success(true, "Verification token sent successfully.");
                    }
                    else
                    {
                        return GenericApiResponse<bool>.Failure("Something went wrong on the server.", ApiStatusCodes.DBError);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<DBUser> GetUserById(int Id)
        {
            try
            {
                return await DL.GetUserById(Id);
            }
            catch
            {
                throw;
            }
        }

        private async Task<GenericApiResponse<LoginResponseModel>> GenerteTokenAndSendEmail(DBUser user, string Type)
        {
            if (Type.Equals("Register"))
            {
                DBUserTokens userToken = new DBUserTokens()
                {
                    Token = Guid.NewGuid().ToString(),
                    TokenTypeId = (int)UserTokenTypes.EmailVerificationToken,
                    UserId = user.Id
                };

                var tResult = await DL.InsertUserToken(userToken);
                if (tResult > 0)
                {
                    var builder = new BodyBuilder();

                    using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\ConfirmEmailTemplate.html").Replace("~\\", ""))))
                    {
                        builder.HtmlBody = SourceReader.ReadToEnd();
                    }

                    string messageBody = string.Format(builder.HtmlBody,
                        user.Email,
                        RedirectUrls.VerifyEmailRedirectUrl + userToken.Token,
                        user.Email
                        );

                    SendEmailToCustomer(user.Email, messageBody, "SignUp Email");

                    return GenericApiResponse<LoginResponseModel>.Pending(null, $"Activation link sent to your email {user.Email} successfully. Please check your inbox and verify", ApiStatusCodes.EmailVerificationPending);
                }
                else
                {
                    return GenericApiResponse<LoginResponseModel>.Failure(null, "Something went wrong on server.", ApiStatusCodes.DBError);
                }
            }
            else
            {
                return GenericApiResponse<LoginResponseModel>.Success(new LoginResponseModel()
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email,
                    PhoneNumber = user.PhoneNumber,
                    Role = Roles.User,
                    Id = user.Id,
                    IsNotificationsOn = user.IsNotificationsOn,
                    MailSubscription = user.MailSubscription,
                    Balance = user.Balance,
                    BalanceCurrency = user.BalanceCurrency,
                    BalanceCurrencySymbol = user.BalanceCurrencySymbol

                }, "Successfully Login.");
            }
        }

        private async Task<bool> SendEmailToCustomer(string customerEmail, string Message, string Subject)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                if (string.IsNullOrEmpty(Message))
                {
                    Logger.Error($"Class: BL_User, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {""}, ErrorMessage: Empty Message");
                    return false;
                }

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }
                else
                {
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                }

                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SmtpConfig.fromForTransferHome);
                mailMessage.To.Add(customerEmail);
                mailMessage.Body = Message;
                mailMessage.Subject = Subject;
                mailMessage.IsBodyHtml = true;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: BL_User, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }
        }

        public async Task<GenericApiResponse<bool>> UpdatePassword(UpdateUserPasswordRequestModel model)
        {
            model.Password = CryptoHelper.Hash(model.Password);
            var result = await DL.UpdatePassword(model.Token, TokensConfig.EmailTokenExpiryMinutes, model.Password);
            if (result > 0)
            {
                return GenericApiResponse<bool>.Success(true, "Password Updated Successfully");
            }
            else
            {
                return GenericApiResponse<bool>.Failure(false, "Token Invalid/Expired.", ApiStatusCodes.TokenExpiredorInvalid);
            }
        }

        public async Task<GenericApiResponse<GetCreditHistoryResponseModel>> GetCreditHistory(GetCreditHistoryRequestModel model)
        {
            var response = await DL.GetCreditHistory(model.UserId);
            if (response != null && response.Count() > 0)
            {
                var data = new GetCreditHistoryResponseModel()
                {
                    CreditHistory = response.Select(item => new CreditHistory()
                    {
                        TransactionNumber = item.Id,
                        Amount = item.Amount,
                        PaymentType = item.PaymentType,
                        Currency = item.Currency,
                        TransactionDate = item.TransactionDate
                    })
                };
                return GenericApiResponse<GetCreditHistoryResponseModel>.Success(data, "Found credit history.");
            }
            else
            {
                return GenericApiResponse<GetCreditHistoryResponseModel>.Failure(new GetCreditHistoryResponseModel() { CreditHistory = new List<CreditHistory>() }, "You Haven't Topped Up Yet", ApiStatusCodes.CreditHistoryNotFound);
            }
        }

        public async Task<GenericApiResponse<GetTransferCreditHistoryResponseModel>> GetTransferCreditHistory(GetTransferCreditHistoryRequestModel model)
        {
            var response = await DL.GetTransferCreditHistory(model.UserId);
            if (response != null && response.Count() > 0)

            {
                var data = new GetTransferCreditHistoryResponseModel()
                {
                    TransferCreditHistory = response.Select(item => new TransferCreditHistory()
                    {
                        TransactionReferenceNumber = item.Id,
                        TransactionDateTime = item.TransactionDateTime,
                        CountryCode = item.CountryCode,
                        OperatorName = item.OperatorName,
                        OperatorCountry = item.OperatorCountryName,
                        OperatorLogoUrl = item.OperatorLogoUrl,
                        Amount = item.TotalPrice,
                        AmountCurrency = item.ClientCurrecny,
                        ReceiverNumber = item.ToMsisdn,
                        ReceiverAmount = item.Product,
                        ReceiverCurrency = item.ReceiverCurrecny,
                        NowtelTransactionReference = item.NowtelTransactionReference,
                        OperatorId = item.OperatorId,
                        TransactionTypeId = (int)item.PaymentTypeId,
                        StatusId = (int)item.StatusId
                    })
                };

                return GenericApiResponse<GetTransferCreditHistoryResponseModel>.Success(data, "Found transfer credit history.");
            }
            else
            {
                return GenericApiResponse<GetTransferCreditHistoryResponseModel>.Failure(new GetTransferCreditHistoryResponseModel() { TransferCreditHistory = new List<TransferCreditHistory>() }, "No Transfers Made Just Yet", ApiStatusCodes.TransferCreditHistoryNotFound);
            }
        }

        public async Task<GenericApiResponse<GetUserInfoResponseModel>> GetUserinfo(GetUserInfoRequestModel model)
        {
            var response = await DL.GetUserById(model.UserId);
            if (response != null)
            {
                var data = new GetUserInfoResponseModel()
                {
                    Id = response.Id,
                    Balance = response.Balance,
                    BalanceCurrency = response.BalanceCurrency,
                    BalanceCurrencySymbol = response.BalanceCurrencySymbol,
                    CountryId = response.CountryId,
                    Email = response.Email,
                    FirstName = response.FirstName,
                    LastName = response.LastName,
                    IsNotificationsOn = response.IsNotificationsOn,
                    IsEmailVerified = response.IsEmailVerified,
                    MailSubscription = response.MailSubscription,
                    PinNumber = response.PinNumber,
                    PhoneNumber = response.PhoneNumber,
                    SignUpType = Enum.GetName(typeof(SignUpType), response.SignUpType)
                };

                return GenericApiResponse<GetUserInfoResponseModel>.Success(data, "Found user data.");
            }
            else
            {
                return GenericApiResponse<GetUserInfoResponseModel>.Failure("User not found.", ApiStatusCodes.UserNotFound);
            }
        }

        public async Task<GenericApiResponse<bool>> EditProfile(EditProfileRequestModel model, string userId)
        {
            var response = await DL.EditProfile(model, userId);
            if (response > 0)
            {
                return GenericApiResponse<bool>.Success(true, "User updated successfully");
            }
            else
            {
                return GenericApiResponse<bool>.Failure(false, "Record not found", ApiStatusCodes.RecordNotFound);
            }
        }

        public async Task<GenericApiResponse<GetUserBalanceResponseModel>> GetUserBalance(GetUserBalanceRequestModel model)
        {
            var response = await DL.GetUserById(model.UserId);
            if (response != null)
            {
                var data = new GetUserBalanceResponseModel()
                {
                    Balance = response.Balance,
                    BalanceCurrency = response.BalanceCurrency,
                    BalanceCurrencySymbol = response.BalanceCurrencySymbol
                };

                return GenericApiResponse<GetUserBalanceResponseModel>.Success(data, "Found user balance data.");
            }
            else
            {
                return GenericApiResponse<GetUserBalanceResponseModel>.Failure("User not found", ApiStatusCodes.UserNotFound);
            }
        }

        public async Task<GenericApiResponse<GetFavouriteTransactionNumbersResponseModel>> GetFavouriteTransactionNumbers(GetFavouriteTransactionNumbersRequestModel model)
        {
            try
            {
                var favouriteData = await DL.GetFavouriteTransactionNumbers(model.UserId);
                var frequentData = await DL.GetFrequentTransactionNumbers(model.UserId);

                if (favouriteData != null && favouriteData.Count() > 0
                    && frequentData != null && frequentData.Count() > 0)
                {

                    var favourite = favouriteData.Select(item => new FavouriteTransactionNumber()
                    {
                        Msisdn = item.ToMsisdn,
                        IsFrequent = false,
                        isfrequent = false
                    }).AsEnumerable();

                    var frequent = frequentData.Select(item => new FavouriteTransactionNumber()
                    {
                        Msisdn = item.ToMsisdn,
                        IsFrequent = true,
                        isfrequent = true
                    }).AsEnumerable();


                    var allnumbers = favourite.Concat(frequent).Select(x => new { x.Msisdn, x.IsFrequent }).AsEnumerable();

                    var data = new GetFavouriteTransactionNumbersResponseModel()
                    {
                        Numbers = allnumbers.Select(item => new FavouriteTransactionNumber()
                        {
                            Msisdn = item.Msisdn,
                            IsFrequent = item.IsFrequent,
                            isfrequent = item.IsFrequent
                        })
                    };

                    return GenericApiResponse<GetFavouriteTransactionNumbersResponseModel>.Success(data, "Found favourite numbers");
                }

                if (favouriteData != null && favouriteData.Count() > 0)
                {
                    var data = new GetFavouriteTransactionNumbersResponseModel()
                    {
                        Numbers = favouriteData.Select(item => new FavouriteTransactionNumber()
                        {
                            Msisdn = item.ToMsisdn,
                            IsFrequent = false,
                            isfrequent = false
                        })
                    };

                    return GenericApiResponse<GetFavouriteTransactionNumbersResponseModel>.Success(data, "Found favourite numbers");
                }

                if (frequentData != null && frequentData.Count() > 0)
                {
                    var data = new GetFavouriteTransactionNumbersResponseModel()
                    {
                        Numbers = frequentData.Select(item => new FavouriteTransactionNumber()
                        {
                            Msisdn = item.ToMsisdn,
                            IsFrequent = true,
                            isfrequent = true
                        })
                    };

                    return GenericApiResponse<GetFavouriteTransactionNumbersResponseModel>.Success(data, "Found favourite numbers");
                }

                return GenericApiResponse<GetFavouriteTransactionNumbersResponseModel>.Failure(new GetFavouriteTransactionNumbersResponseModel() { Numbers = new List<FavouriteTransactionNumber>() }, "No Favourites Added Just Yet", ApiStatusCodes.FavouriteTransactionNumbersNotFound);
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<object>> SaveFavouriteTransactionNumber(SaveFavouriteTransactionNumberRequestModel model, int userId)
        {
            var response = await DL.SaveFavouriteTransactionNumber(new DBFavouriteNumber
            {
                Number = model.Number,
                UserId = userId
            });

            if (response == 1)
            {
                var FavouriteNumbers = await GetFavouriteTransactionNumbers(new GetFavouriteTransactionNumbersRequestModel()
                {
                    UserId = userId
                });

                return GenericApiResponse<object>.Success(FavouriteNumbers.payload, "Number added successfully in favourites");
            }
            else if (response == 2)
            {
                return GenericApiResponse<object>.Failure(new { }, "Number already added in favourites", ApiStatusCodes.NumberAlreadyExistInFavourites);
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Failed to add number in favourites", ApiStatusCodes.DBError);
            }
        }

        public async Task<GenericApiResponse<object>> RemoveFavouriteTransactionNumber(SaveFavouriteTransactionNumberRequestModel model, int userId)
        {
            var response = await DL.RemoveFavouriteTransactionNumber(new DBFavouriteNumber
            {
                Number = model.Number,
                UserId = userId
            });
            if (response > 0)
            {
                var FavouriteNumbers = await GetFavouriteTransactionNumbers(new GetFavouriteTransactionNumbersRequestModel()
                {
                    UserId = userId
                });

                return GenericApiResponse<object>.Success(FavouriteNumbers.payload, "Number removed successfully from favourites");
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Record not found", ApiStatusCodes.RecordNotFound);
            }
        }

        public async Task<GenericApiResponse<object>> SaveUpdateFCMToken(SaveUpdateFCMTokenRequestModel model)
        {
            await DL.SaveUpdateFCMToken(new DbUserPushNotificationIds()
            {
                Token = model.Token,
                UDID = model.UDID,
                DeviceType = model.DeviceType
            });

            return GenericApiResponse<object>.Success(new { }, "Token saved successfully");
        }

        public async Task<GenericApiResponse<object>> RemoveCreditHistory(RemoveCreditHistoryRequestModel model, int userId)
        {
            var response = await DL.RemoveCreditHistory(new DbCreditHistory()
            {
                Id = model.TransactionReferenceNumber,
                UserId = userId
            });

            if (response > 0)
            {
                return GenericApiResponse<object>.Success(new { }, "Credit history removed successfully");
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Record not found", ApiStatusCodes.RecordNotFound);
            }
        }

        public async Task<GenericApiResponse<object>> RemoveTransferCreditHistory(RemoveTransferCreditHistoryRequestModel model, int userId)
        {
            var response = await DL.RemoveTransferCreditHistory(new DbTransferCreditHistory()
            {
                Id = model.TransactionReferenceNumber,
                UserId = userId
            });

            if (response > 0)
            {
                return GenericApiResponse<object>.Success(new { }, "Transfer credit history removed successfully");
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Record not found", ApiStatusCodes.RecordNotFound);
            }
        }

        public async Task<GenericApiResponse<object>> UpdateUserNotificationsSetting(UpdateUserNotificationsSettingRequestModel model, int userId)
        {
            var response = await DL.UpdateUserNotificationsSetting(model.Status, userId);
            if (response != null)
            {
                return GenericApiResponse<object>.Success(new UpdateUserNotificationsSettingResponseModel() { Status = response.IsNotificationsOn }, "Notifications status updated successfully");
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Record not found", ApiStatusCodes.RecordNotFound);
            }
        }

        public async Task<GenericApiResponse<object>> UpdateMailSubscription(UpdateMailSubscriptionRequestModel model, int userId)
        {
            var response = await DL.UpdateMailSubscription(model.Status, userId);
            if (response != null)
            {
                return GenericApiResponse<object>.Success(new UpdateMailSubscriptionResponseModel() { Status = response.MailSubscription }, "Mail subscription status updated successfully");
            }
            else
            {
                return GenericApiResponse<object>.Failure(new { }, "Record not found", ApiStatusCodes.RecordNotFound);
            }
        }

        public async Task<bool> IsValidTopUpRequest(int id, string balanceCurrency, decimal amount)
        {
            return await DL.IsValidTopUpRequest(id, balanceCurrency, amount);
        }
    }
}
