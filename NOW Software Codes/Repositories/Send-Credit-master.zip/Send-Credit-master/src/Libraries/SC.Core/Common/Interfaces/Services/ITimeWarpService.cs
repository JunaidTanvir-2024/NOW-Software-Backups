﻿public interface ITimeWarpService
{
    DateTime UtcNow { get; }
}

