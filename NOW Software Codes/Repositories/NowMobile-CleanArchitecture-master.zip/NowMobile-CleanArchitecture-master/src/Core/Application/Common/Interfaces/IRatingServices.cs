﻿using Application.Features.Rating;

namespace Application.Common.Interfaces;

public interface IRatingServices : ISerivcesType.ITransientService
{
    Task<IEnumerable<RatingEventInfo>> GetRatingEvents();
    Task AddCustomerRating(RatingInfo request);
    Task<IEnumerable<RatingStatus>> GetRatingStatus(string emailAddress);
}
