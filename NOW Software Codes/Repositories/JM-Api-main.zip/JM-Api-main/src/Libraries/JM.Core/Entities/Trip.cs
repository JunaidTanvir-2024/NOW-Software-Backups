using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class Trip : IBaseEntity<long>, IAuditEntity
{
    public long Id { get; set; }
    public string Name { get; set; } = null!;
    public DateTime StartingDate { get; set; }
    public DateTime EndingDate { get; set; }
    public string? Thumbnail { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsDeleted { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public DateTime? DeletedAt { get; set; }
    public long CreatorId { get; set; }
    public User Creator { get; set; } = null!;
    public long CurrencyId { get; set; }
    public Currency Currency { get; set; } = null!;
    public long ChatRoomId { get; set; }
    public ChatRoom ChatRoom { get; set; } = null!;
    public ICollection<Traveler> Travelers { get; set; } = [];
    public ICollection<Media> Media { get; set; } = [];
    public ICollection<Expense> Expenses { get; set; } = [];
    public ICollection<TripPlace> TripPlaces { get; set; } = [];
}
