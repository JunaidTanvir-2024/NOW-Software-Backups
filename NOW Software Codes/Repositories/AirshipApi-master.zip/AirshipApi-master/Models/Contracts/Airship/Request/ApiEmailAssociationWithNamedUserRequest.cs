﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Request
{
    public class ApiEmailAssociationWithNamedUserRequest
    {
        [JsonProperty("email_address")]
        public string EmailAddress { get; set; }

        [JsonProperty("named_user_id")]
        public string NamedUserId { get; set; }
    }
}
