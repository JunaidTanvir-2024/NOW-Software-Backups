﻿namespace Domain.Entities;

public class UserProduct
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public string? Msisdn { get; set; }
    public string? AccountId { get; set; }
    public int Status { get; set; }
    public bool IsDefault { get; set; }
    public long UserId { get; set; }
}
