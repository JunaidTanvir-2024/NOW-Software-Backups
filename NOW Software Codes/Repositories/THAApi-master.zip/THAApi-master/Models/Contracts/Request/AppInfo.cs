﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class Info
    {
        public AppInfo AppInfo { get; set; }
    }
    public class DeviceInf
    {
        public string cpuArchitecture { get; set; }
        public string ActionExecuted { get; set; }
        public string DeviceOS { get; set; }
        public string DeviceOSVersion { get; set; }
        public string DeviceMake { get; set; }
        public string DeviceModel { get; set; }
        public string DeviceLanguage { get; set; }
        public string DevicePersistentID { get; set; }
        public bool IsAndroid { get; set; }
        public bool isTrusted { get; set; }

    }

    public class AppInf
    {
        public string AppVersion { get; set; }
        public string AppLanguage { get; set; }
        public string ProductCode { get; set; }
        public string ProductItemCode { get; set; }

    }
    public class AppInfo
    {
        public string cpuArchitecture { get; set; }

        public string ActionExecuted { get; set; }

        public string DeviceOS { get; set; }

        public string DeviceOSVersion { get; set; }

        public string DeviceMake { get; set; }

        public string DeviceModel { get; set; }

        public string DeviceLanguage { get; set; }

        public string DevicePersistentID { get; set; }

        public string AppVersion { get; set; }

        public string AppLanguage { get; set; }
    }

    public class AppToken
    {
        public string Token { get; set; }
        public DateTime ExpiryDate { get; set; }
        public bool IsValid { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMsg { get; set; }
        public string UserID { get; set; }
    }
}
