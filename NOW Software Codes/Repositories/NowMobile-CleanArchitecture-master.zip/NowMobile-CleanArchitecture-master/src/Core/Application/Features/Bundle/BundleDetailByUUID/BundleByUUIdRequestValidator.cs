namespace Application.Features.Bundle.BundleDetailByUUID;

public sealed class BundleByUUIdRequestValidator : AbstractValidator<BundleByUUIdRequest>
{
    public BundleByUUIdRequestValidator()
    {
        RuleFor(p => p.Id).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
    }
}