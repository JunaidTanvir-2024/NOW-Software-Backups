using System.Text.Json.Serialization;

using Voucherify.Core.Commons.Converters;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;
using Voucherify.Core.Services.VoucherifyApi.Models.Orders;
using Voucherify.Core.Services.VoucherifyApi.Models.Promotions;
using Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Redemptions;

public class Redemption
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("result")]
    [JsonConverter(typeof(EnumConverter<RedemptionResult>))]
    public RedemptionResult Result { get; set; }

    [JsonPropertyName("failure_code")]
    [JsonConverter(typeof(EnumConverter<FailureCode>))]
    public FailureCode FailureCode { get; set; }

    [JsonPropertyName("date")]
    public DateTime? Date { get; set; }

    [JsonPropertyName("gift")]
    public RedemptionGift? Gift { get; set; }

    [JsonPropertyName("voucher")]
    public Voucher? Voucher { get; set; }

    [JsonPropertyName("customer_id")]
    public string? CustomerId { get; set; }

    [JsonPropertyName("tracking_id")]
    public string? TrackingId { get; set; }

    [JsonPropertyName("customer")]
    public CustomerSimple? Customer { get; set; }

    [JsonPropertyName("order")]
    public Order? Order { get; set; }

    [JsonPropertyName("promotion_tier")]
    public PromotionTier? PromotionTier { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    [JsonPropertyName("amount")]
    public long Amount { get; set; }

    [JsonPropertyName("redemption")]
    public string? ParentRedemptionId { get; set; }
}
