namespace Application.Common.Enums;
public enum CodeTypes
{
    PAC = 1,
    STAC = 2
}