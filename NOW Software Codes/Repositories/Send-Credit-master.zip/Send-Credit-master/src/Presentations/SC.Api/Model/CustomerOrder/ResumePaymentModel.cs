﻿using System.ComponentModel;

namespace SC.Api.Model.CustomerOrder;
public record ResumePaymentModel
{
    [DefaultValue("")]
    public string TransactionId { get; set; } = default!;
}

