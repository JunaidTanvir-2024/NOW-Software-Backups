﻿namespace Application.Common.Settings;
public class EmailValidationServiceSettings
{
    public const string SectionName = nameof(EmailValidationServiceSettings);
    public static EmailValidationServiceSettings Bind = new EmailValidationServiceSettings();
    public string? BaseUrl { get; set; }
    public bool IsEnable { get; set; }
}
