﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Airship.Request;
using Models.Contracts.Airship.Response;
using Models.Contracts.Pay360.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using RestSharp;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class StaticList_BL : IStaticList_BL
    {
        private IApiCall ApiCall;
        private readonly ILogger Logger;
        private IStaticList_DL StaticListDb;

        public StaticList_BL(ILogger logger, IApiCall apiCall, IStaticList_DL staticlistDb)
        {
            Logger = logger;
            ApiCall = apiCall;
            StaticListDb = staticlistDb;
        }

        public async Task<GenericApiResponse<ApiGetSingleListRespose>> GetSingleList(GetSingleListRequest request)
        {
            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<ApiGetSingleListRespose>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/lists/"+request.list_name;
                IRestResponse httpResponse = await ApiCall.Get(url, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Channel_BL, Method: GetSingleList, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<ApiGetSingleListRespose>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiGetSingleListRespose apiResponseModel = JsonConvert.DeserializeObject<ApiGetSingleListRespose>(responseJson);

                        return GenericApiResponse<ApiGetSingleListRespose>.Success(apiResponseModel, "Success");

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        ApiStatusCodes code = (httpResponse.StatusCode == System.Net.HttpStatusCode.NotFound ? ApiStatusCodes.InvalidChannel : ApiStatusCodes.UnSuccessful);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetSingleListRespose>.Failure(errorMessage, code);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetSingleListRespose>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class:  Channel_BL, Method: GetSingleList, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApiGetSingleListRespose>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }
        }

        public async Task<GenericApiResponse<ApiGetAllListsResponse>> GetAllLists(GetAllListsRequest request)
        {
            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<ApiGetAllListsResponse>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/lists";
                IRestResponse httpResponse = await ApiCall.Get(url, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Channel_BL, Method: GetAllLists, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<ApiGetAllListsResponse>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiGetAllListsResponse apiResponseModel = JsonConvert.DeserializeObject<ApiGetAllListsResponse>(responseJson);

                        return GenericApiResponse<ApiGetAllListsResponse>.Success(apiResponseModel, "Success");

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        ApiStatusCodes code = (httpResponse.StatusCode == System.Net.HttpStatusCode.NotFound ? ApiStatusCodes.InvalidChannel : ApiStatusCodes.UnSuccessful);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetAllListsResponse>.Failure(errorMessage, code);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetAllListsResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class:  Channel_BL, Method: GetAllLists, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApiGetAllListsResponse>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }

        public async Task<GenericApiResponse<string>> AddList(AddListRequest request)
        {
            try
            {
                AddListRequest listreq = new AddListRequest() { name = request.name, description = request.description, extra = request.extra };
                var dbResult = await StaticListDb.AddList(listreq, request.ProductCode);
                    if (dbResult.Status == Status.Success)
                    {
                        return GenericApiResponse<string>.Success("Success");
                    }
                    else // Failure
                    {
                        return GenericApiResponse<string>.Failure(dbResult.ErrorMessage, ApiStatusCodes.UnSuccessful);
                    }
             

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class:  Channel_BL, Method: AddChannel, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }

        public async Task<GenericApiResponse<string>> DownloadListContent(DownloadListContentRequest request)
        {
            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<string>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);
                string url = credentials.ApiEndPoint + "/api/lists/"+request.list_name+"/csv";
                IRestResponse httpResponse = await ApiCall.Get(url, credentials.AuthType, authHeader, "text/csv", "application/vnd.urbanairship+csv;version=3;");
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Channel_BL, Method: DownloadListContent, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<string>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        return GenericApiResponse<string>.Success(responseJson, "Success");

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        ApiStatusCodes code = (httpResponse.StatusCode == System.Net.HttpStatusCode.NotFound ? ApiStatusCodes.InvalidChannel : ApiStatusCodes.UnSuccessful);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, code);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class:  Channel_BL, Method: DownloadListContent, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }
        }
    }
    
}
