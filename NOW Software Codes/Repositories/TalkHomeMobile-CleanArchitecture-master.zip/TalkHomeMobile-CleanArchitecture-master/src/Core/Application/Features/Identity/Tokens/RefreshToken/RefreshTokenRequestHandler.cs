﻿namespace Application.Features.Identity.Tokens.RefreshToken;

public class RefreshTokenRequestHandler : IRequestHandler<RefreshTokenRequest, Result<TokenResponse>>
{
    private readonly ITokenService _tokenService;
    private readonly IStringLocalizer<RefreshTokenRequestHandler> _localizer;

    public RefreshTokenRequestHandler(
        ITokenService tokenService,
        IStringLocalizer<RefreshTokenRequestHandler> localizer)
    {
        _tokenService = tokenService;
        _localizer = localizer;
    }

    public async Task<Result<TokenResponse>> Handle(RefreshTokenRequest request, CancellationToken cancellationToken)
    {
        var response = await _tokenService.RefreshTokenAsync(request, request.IpAddress!);
        if (response == null)
        {
            return Result<TokenResponse>.Failure(
                null!, _localizer[CustomStatusKey.InvalidAuthToken], CustomStatusCode.InvalidAuthToken);
        }

        return Result<TokenResponse>.Success(response, _localizer[CustomStatusKey.Success]);
    }
}