﻿using PaymentsApi.Infrastructure.DAL.Database;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PaymentsApi.Infrastructure.DAL.Interfaces
{
    public interface IDL_Paypal
    {
        Task<int> PaypalFraudValidation(string customerMerchantRef, string email, string ipAddress, string productCode, string productItemCode);
        Task<bool> PaypalIsUserWhitelisted(string merchantRef);
        Task<DbResult<int>> AddUpdatePaypalCustomer(Customer customer);
        Task<DbResult<long>> AddTransaction(PaypalTransaction transaction, ProductBasket[] basket, bool AddSummaryTransaction = false);
        Task<PaypalTransactionSummary> GetResumeSummaryTran(string paypalCheckoutToken);
        Task<DbResult<long>> AddResumeTransaction(PaypalTransaction transaction);
        Task<List<TransactionItems>> GetTransactionItemsForFullfilment(string transactionId);
        Task<FullfilmentResponse> ThmStraightCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef, string customerEmail, string productItemCode);
        Task<FullfilmentResponse> ThccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<FullfilmentResponse> ThrccCustomerFullfilment(string transactionId, string amount, string productRef, string email, string firstname);
        Task<FullfilmentResponse> NowStraightCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef);
        Task<FullfilmentResponse> WtccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<FullfilmentResponse> ThaStraightCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef);
        Task<FullfilmentResponse> StccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<FullfilmentResponse> BtccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<FullfilmentResponse> MtccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<FullfilmentResponse> TdccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<int> UpdateTransactionItem(int Id, string FullfillmentError, bool IsSmsSent, bool IsEmailSent, bool IsFullfilled, DateTime? SmsSent_DateTime, DateTime? EmailSent_DateTime, DateTime? FulfilmentDateTime);
        Task<int> UpdateTransactionSummaryFullfilmentStatus(string Pay360TransactionId, int transactionStatusId, DateTime fulfilmentDate);
        Task<PaypalTransactionSummary> GetSummaryByPay360TransactionId(string pay360TransactionId);
        Task<DbResult<long>> AddRefundTransaction(PaypalTransaction transaction);
        Task<Customer> GetCustomerByMerchantRef(string merchantRef);
    }
}
