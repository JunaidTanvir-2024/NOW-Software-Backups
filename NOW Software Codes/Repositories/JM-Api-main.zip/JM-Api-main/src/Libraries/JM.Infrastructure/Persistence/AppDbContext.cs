using System.Reflection;

using JM.Core.Entities;
using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;
using JM.Infrastructure.Services.Identity;

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace JM.Infrastructure.Persistence;
public class AppDbContext(DbContextOptions<AppDbContext> options) : IdentityDbContext<User, Role, long>(options), IAppDbContext
{
    public DbSet<Country> Country => Set<Country>();
    public DbSet<UserDetail> UserDetail => Set<UserDetail>();
    public DbSet<Vendor> Vendor => Set<Vendor>();
    public DbSet<AppLog> AppLog => Set<AppLog>();
    public DbSet<VendorLog> VendorLog => Set<VendorLog>();
    public DbSet<Otp> Otp => Set<Otp>();
    public DbSet<Trip> Trip => Set<Trip>();
    public DbSet<Place> Place => Set<Place>();
    public DbSet<ExpenseCategory> ExpenseCategory => Set<ExpenseCategory>();
    public DbSet<Traveler> Traveler => Set<Traveler>();
    public DbSet<Media> Media => Set<Media>();
    public DbSet<Expense> Expense => Set<Expense>();
    public DbSet<ChatRoom> ChatRoom => Set<ChatRoom>();
    public DbSet<Subscription> Subscription => Set<Subscription>();
    public DbSet<TripPlace> TripPlace => Set<TripPlace>();
    public DbSet<Friendship> Friendship => Set<Friendship>();
    public DbSet<Currency> Currency => Set<Currency>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.HasDefaultSchema(AppConstant.Database.Schema);
        // Apply Entities Configurations
        modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        modelBuilder.Entity<Role>(b => b.ToTable(nameof(Role)));
        modelBuilder.Entity<IdentityUserClaim<long>>(b => b.ToTable("UserClaim"));
        modelBuilder.Entity<IdentityUserLogin<long>>(b => b.ToTable("UserLogin"));
        modelBuilder.Entity<IdentityUserToken<long>>(b => b.ToTable("UserToken"));
        modelBuilder.Entity<IdentityRoleClaim<long>>(b => b.ToTable("RoleClaim"));
        modelBuilder.Entity<IdentityUserRole<long>>(b => b.ToTable("UserRole"));
    }
    public async Task<IDbContextTransaction> BeginTransactionAsync()
    {
        return await Database.BeginTransactionAsync();
    }
    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return await base.SaveChangesAsync(cancellationToken);
    }
    public override int SaveChanges() { return base.SaveChanges(); }
    public IDbContextTransaction BeginTransaction() { return Database.BeginTransaction(); }
}

internal static class ConfigureAppContext
{
    internal static IServiceCollection AddAppContextConfigurations(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddDbContext<AppDbContext>(options => options.UseNpgsql(configuration.GetConnectionString(AppConstant.Database.JourneyMingle)));
        services.AddScoped<IAppDbContext>(provider => provider.GetRequiredService<AppDbContext>());
        // Bind auth setting
        var authSettings = services.BuildServiceProvider().GetRequiredService<IOptions<IdentitySetting>>().Value;

        services.AddIdentity<User, Role>().AddEntityFrameworkStores<AppDbContext>().AddDefaultTokenProviders();

        // Authentication Configurations Options
        services.Configure<IdentityOptions>(options =>
        {
            // Password settings.
            options.Password.RequireDigit = authSettings.PasswordOptions.RequireDigit;
            options.Password.RequireLowercase = authSettings.PasswordOptions.RequireLowercase;
            options.Password.RequireNonAlphanumeric = authSettings.PasswordOptions.RequireNonAlphanumeric;
            options.Password.RequireUppercase = authSettings.PasswordOptions.RequireUppercase;
            options.Password.RequiredLength = authSettings.PasswordOptions.RequiredLength;
            options.Password.RequiredUniqueChars = authSettings.PasswordOptions.RequiredUniqueChars;

            // Lockout settings.
            options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(authSettings.LockoutOptions.DefaultLockoutMinutes);
            options.Lockout.MaxFailedAccessAttempts = authSettings.LockoutOptions.MaxFailedAccessAttempts;
            options.Lockout.AllowedForNewUsers = authSettings.LockoutOptions.EnableLookoutForNewUser;

            // Signup settings.
            options.User.AllowedUserNameCharacters = authSettings.SignupOptions.AllowedUserNameCharacters;
            options.User.RequireUniqueEmail = authSettings.SignupOptions.RequireUniqueEmail;

            // Sign in Setting
            options.SignIn.RequireConfirmedPhoneNumber = authSettings.SignInOptions.RequireConfirmedPhoneNumber;
            options.SignIn.RequireConfirmedEmail = authSettings.SignInOptions.RequireConfirmedEmail;
            options.SignIn.RequireConfirmedAccount = authSettings.SignInOptions.RequireConfirmedAccount;
        });
        return services;
    }
}
