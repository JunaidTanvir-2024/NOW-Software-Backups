using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DC.Core.Common.DependencyResolver;
using DC.Core.Common.DTOs.Vendors.DTOne;

namespace DC.Core.Common.Interfaces.Services;
public interface ISMSService : ServiceType.IScoped
{
    Task<bool> SendSMS(SMSSend.Request request);
}
