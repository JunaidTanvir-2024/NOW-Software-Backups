CREATE DATABASE callback_hub
USE callback_hub

GO
CREATE TABLE [dbo].[app_log]
(
  [app_log_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
  [request_timestamp] [DATETIME2](7) NULL,
  [request_path] [NVARCHAR](255) NULL,
  [request_method] [NVARCHAR](10) NULL,
  [request_body] [NVARCHAR](MAX) NULL,
  [response_body] [NVARCHAR](MAX) NULL,
  [status_code] [INT] NULL,
  [duration] [BIGINT] NULL,
  [client_ip] [NVARCHAR](50) NULL,
  [user_agent] [NVARCHAR](255) NULL,
  [response_size] [BIGINT] NULL,
  [error_reason] [NVARCHAR](1500) NULL,
  [correlation_id] [UNIQUEIDENTIFIER] NOT NULL,
  [query_string] [NVARCHAR](250) NULL,
)

GO
CREATE TABLE [dbo].[vendor]
(
  [vendor_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
  [name] [NVARCHAR](50) NOT NULL,
  [description] [NVARCHAR](max) NULL,
  [is_active] BIT DEFAULT 1,
  [is_deleted] BIT DEFAULT 0,
  [created_at] DATETIME DEFAULT GETUTCDATE(),
  [updated_at] DATETIME DEFAULT GETUTCDATE(),
  [row_guid] UNIQUEIDENTIFIER DEFAULT NEWID(),
  [row_version] ROWVERSION
)


GO
CREATE TABLE [dbo].[vendor_log]
(
  [vendor_log_id] [BIGINT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
  [request_timestamp] [DATETIME2](7) NULL,
  [request_path] [NVARCHAR](255) NULL,
  [request_method] [NVARCHAR](10) NULL,
  [request_body] [NVARCHAR](MAX) NULL,
  [response_body] [NVARCHAR](MAX) NULL,
  [status_code] [INT] NULL,
  [duration] [BIGINT] NULL,
  [response_size] [BIGINT] NULL,
  [error_reason] [NVARCHAR](1000) NULL,
  [correlation_id] [UNIQUEIDENTIFIER] NOT NULL,
  [headers] [NVARCHAR](2000) NULL,
  [query_string] [NVARCHAR](500) NULL,
  [vendor_id] [BIGINT] NOT NULL,
  CONSTRAINT [FK_VendorLog_Vendor] FOREIGN KEY ([vendor_id]) REFERENCES [dbo].[vendor] ([vendor_id])
)