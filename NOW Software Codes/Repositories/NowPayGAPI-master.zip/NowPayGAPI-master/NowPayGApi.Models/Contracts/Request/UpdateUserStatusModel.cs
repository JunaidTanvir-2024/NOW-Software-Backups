﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class UpdateUserStatusModel
    {
        [Required]
        public int StatusID { get; set; }

        [Required]
        public int UserID { get; set; }
    }
}
