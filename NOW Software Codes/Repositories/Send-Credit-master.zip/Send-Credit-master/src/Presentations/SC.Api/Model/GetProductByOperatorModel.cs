﻿using SC.Core.Features.ProductByOperator;

namespace SC.Api.Model;

public class GetProductByOperatorModel
{
    public int Page { get; set; }
    public int RecordsPerPage { get; set; }
    public decimal? Price { get; set; }
    public string? CountryIsoCode { get; set; }
    public string? CurrencyCode { get; set; }
    public string? Category { get; set; }
    public string? SubCategory { get; set; }
    public string? Operator { get; set; }

    public ProductByOperator.Query map()
    {
        return new ProductByOperator.Query
        {
            Page = Page,
            RecordsPerPage = RecordsPerPage,
            Price = Price,
            CountryIsoCode = CountryIsoCode,
            CurrencyCode = CurrencyCode,
            Category = Category,
            SubCategory = SubCategory,
            Operator = Operator

        };
    }
}

