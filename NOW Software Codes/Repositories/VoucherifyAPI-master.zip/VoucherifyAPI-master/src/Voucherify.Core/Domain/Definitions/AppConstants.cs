namespace Voucherify.Core.Domain.Definitions;

public static class AppConstants
{
    public static class ConnectionStrings
    {
        public const string DefaultConnection = "VoucherifyDbConnection";
    }

    public static class StatusMessages
    {
        // Commonly Used Status Messages
        public const string Success = "Congratulations! Your request was fulfilled successfully.";
        public const string BadRequest = "Whoops! Something went wrong with your request. Please try again.";
        public const string Forbidden = "Sorry, you don't have permission to access this resource.";
        public const string NotFound = "Hmmm, we couldn't find what you're looking for.";
        public const string Unauthorized = "Oops! You need to be authorized to access this resource.";
        public const string InternalServerError = "Whoops! Something went wrong on our end. Please try again later.";

        // Vouchers Status Code Range 1000 - 1050
        public const string VoucherCodeExpired = "voucher code expired";
        public const string VoucherCodeInvalid = "voucher code invalid";
        public const string VoucherNotFound = "Unable to find voucher's record";

        // Promotions Status Code Range 1050 - 1100
        public const string PromotionInvalid = "promotion code expired";
        public const string PromotionExpired = "promotion code invalid";
        public const string PromotionNotFound = "Unable to find promotion's record";

        // Stackable Discount Status Code Range 1100 - 1150
        public const string StackableDiscountInvalid = "discount code invalid";
        public const string StackableDiscountExpired = "discount code expired";
        public const string StackableDiscountNotValidForCustomer = "You are not eligible for discount code";

        // Customers Status Code Range 1150 - 1200
        public const string CustomerNotFound = "Unable to find customer's record";
        public const string CustomerNotCreated = "Unable to create customer record";
        public const string CustomerNotUpdated = "Unable to update customer record";
        public const string CustomerNotDeleted = "Unable to delete customer record";

        // Referral Status Code Range 1200 - 1250
        public const string ReferralCodeExpired = "referral code expired";
        public const string ReferralCodeInvalid = "referral code invalid";
        public const string ReferralCodeNotCreated = "unable to create referral code";

        // Campaigns Status Code Range 1250 - 1300
        public const string CampaignNotFound = "Unable to find campaign's record";
        public const string CampaignNotCreated = "Unable to create campaign record";
        public const string CampaignNotUpdated = "Unable to update campaign record";
        public const string CampaignNotDeleted = "Unable to delete campaign record";

        // Redemption Status Code Range 1300 - 1350
        public const string RedemptionNotRollback = "unable to rollback redemption";
        public const string RedemptionIdInvalid = "redemption id is invalid";

        // Products Status Code Range 1350 - 1400
        public const string ProductNotFound = "Unable to find product's record";
        public const string ProductNotCreated = "Unable to create product record";
        public const string ProductNotUpdated = "Unable to update product record";
        public const string ProductNotDeleted = "Unable to delete product record";

        // Skus Status Code Range 1400 - 1450
        public const string SkuNotFound = "Unable to find sku's record";
        public const string SkuNotCreated = "Unable to create sku record";
        public const string SkuNotUpdated = "Unable to update sku record";
        public const string SkuNotDeleted = "Unable to delete sku record";

        // Voucherify Event Status Code Range 1450 - 1500
        public const string VoucherifyEventNotFound = "voucherify event not found";
        public const string VoucherifyEventNotInvoked = "unable to invoke voucherify event";

        // Loyalty Campaigns Status Code Range 1500 - 1550
        public const string LoyaltyCampaignNotFound = "Unable to find loyalty campaign's record";
        public const string LoyaltyCampaignNotCreated = "Unable to create loyalty campaign record";
        public const string LoyaltyCampaignNotUpdated = "Unable to update loyalty campaign record";
        public const string LoyaltyCampaignNotDeleted = "Unable to delete loyalty campaign record";


        // Earning Rules Status Code Range 1550 - 1600
        public const string EarningRuleNotFound = "Unable to find earning Rule's record";
        public const string EarningRuleNotCreated = "Unable to create earning Rule record";
        public const string EarningRuleNotUpdated = "Unable to update earning Rule record";
        public const string EarningRuleNotDeleted = "Unable to delete earning Rule record";
        public const string EarningRuleNotEnabled = "Unable to enable earning Rule";
        public const string EarningRuleNotDisabled = "Unable to disable earning Rule";
    }


    public static class StatusCodes
    {
        // Commonly Used Status Codes
        public const int Success = Microsoft.AspNetCore.Http.StatusCodes.Status200OK;
        public const int BadRequest = Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest;
        public const int Forbidden = Microsoft.AspNetCore.Http.StatusCodes.Status403Forbidden;
        public const int NotFound = Microsoft.AspNetCore.Http.StatusCodes.Status404NotFound;
        public const int Unauthorized = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;
        public const int InternalServerError = Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError;

        // Vouchers Status Code Range 1000 - 1050
        public const int VoucherCodeExpired = 1001;
        public const int VoucherCodeInvalid = 1002;
        public const int VoucherNotFound = 1003;

        // Promotions Status Code Range 1050 - 1100
        public const int PromotionInvalid = 1051;
        public const int PromotionExpired = 1052;
        public const int PromotionNotFound = 1053;

        // Stackable Discount Status Code Range 1100 - 1150
        public const int StackableDiscountInvalid = 1051;
        public const int StackableDiscountExpired = 1052;
        public const int StackableDiscountNotValidForCustomer = 1053;

        // Customers Status Code Range 1150 - 1200
        public const int CustomerNotFound = 1151;
        public const int CustomerNotCreated = 1152;
        public const int CustomerNotUpdated = 1153;
        public const int CustomerNotDeleted = 1154;

        // Referral Status Code Range 1200 - 1250
        public const int ReferralCodeExpired = 1201;
        public const int ReferralCodeInvalid = 1202;
        public const int ReferralCodeNotCreated = 1203;

        // Campaigns Status Code Range 1250 - 1300
        public const int CampaignNotFound = 1251;
        public const int CampaignNotCreated = 1252;
        public const int CampaignNotUpdated = 1253;
        public const int CampaignNotDeleted = 1254;

        // Redemption Status Code Range 1300 - 1350
        public const int RedemptionNotRollback = 1351;
        public const int RedemptionIdInvalid = 1352;

        // Products Status Code Range 1350 - 1400
        public const int ProductNotFound = 1351;
        public const int ProductNotCreated = 1352;
        public const int ProductNotUpdated = 1353;
        public const int ProductNotDeleted = 1354;

        // Skus Status Code Range 1400 - 1450
        public const int SkuNotFound = 1401;
        public const int SkuNotCreated = 1402;
        public const int SkuNotUpdated = 1403;
        public const int SkuNotDeleted = 1404;

        // Voucherify Event Status Code Range 1450 - 1500
        public const int VoucherifyEventNotFound = 1451;
        public const int VoucherifyEventNotInvoked = 1452;

        // Loyalty Campaigns Status Code Range 1500 - 1550
        public const int LoyaltyCampaignNotFound = 1501;
        public const int LoyaltyCampaignNotCreated = 1502;
        public const int LoyaltyCampaignNotUpdated = 1503;
        public const int LoyaltyCampaignNotDeleted = 1504;

        // Earning Rules Status Code Range 1550 - 1600
        public const int EarningRuleNotFound = 1551;
        public const int EarningRuleNotCreated = 1552;
        public const int EarningRuleNotUpdated = 1553;
        public const int EarningRuleNotDeleted = 1554;
        public const int EarningRuleNotEnabled = 1555;
        public const int EarningRuleNotDisabled = 1556;
    }
}
