﻿using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Events.Responses
{
    public class InvokedVoucherifyEventResponse
    {
        [JsonPropertyName("eventType")]
        public string EventType { get; set; }
        [JsonPropertyName("isEventInvoked")]
        public bool IsEventInvoked { get; set; }
    }
}
