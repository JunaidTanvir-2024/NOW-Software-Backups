﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class PaypalByPay360PaymentCallBackRequestModel
    {
        [Required]
        public string Token { get; set; }

        [Required]
        [Range(1, 2)]
        public CheckOutTypes type { get; set; }

        public string bundleId { get; set; }

        public string IpAddress { get; set; }

        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        public string Msisdn { get; set; }

        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }
        public int PTId { get; set; }
    }
}
