﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
   public class GetCurrencyResponseModel
    {
        public IEnumerable<Currencies> Currencies { get; set; }
    }
    public class Currencies
    {
        public int ID { get; set; }
        public string Country { get; set; }
        public string Currency { get; set; }
        public string Code { get; set; }
        public string symbol { get; set; }
    }

}
