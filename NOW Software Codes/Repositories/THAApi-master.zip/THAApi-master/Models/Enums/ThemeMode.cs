﻿namespace Models.Enums
{
    public enum ThemeMode
    {
        Light = 1,
        Dark = 2
    }
}
