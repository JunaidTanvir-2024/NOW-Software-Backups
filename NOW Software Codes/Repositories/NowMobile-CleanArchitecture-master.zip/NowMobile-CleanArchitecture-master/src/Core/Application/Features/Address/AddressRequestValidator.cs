﻿namespace Application.Features.Address;
public class AddressRequestValidator : AbstractValidator<AddressRequest>
{
    public AddressRequestValidator()
    {
        RuleFor(p => p.PostCode).Cascade(CascadeMode.Stop).NotNull().NotEmpty().WithMessage("Please provide valid Posatl code.");
    }
}
