﻿using Models.Enums;
using System;

namespace Models.Contracts.Request.Bundle
{
	public class BundleDetailsDB
	{
		public Guid Id { get; set; }
		public bool IsTrial { get; set; }
		public Guid? TrialId { get; set; }
		public int OffPercentage { get; set; }
		public BundleType Type { get; set; }
		public BundleCategory Category { get; set; }
		public string DisplayName { get; set; }
		public string Destination { get; set; }
	}
	public class BundleCompatibility
	{
		public Guid BundleId { get; set; }
		public bool IsCompatible { get; set; }
		public bool IsTrialAvailable { get; set; }
		public Guid? TrialId { get; set; }
		public bool IsTrialMinutesExpired { get; set; }
	}
	public class Bundle
	{
		public Guid Id { get; set; }

		public string Name { get; set; }

		public string BrandedName { get; set; }

		public string Description { get; set; }

		public int TotalCostPence { get; set; }

		public int ChargePeriodDays { get; set; }

		public int BundlePeriodDays { get; set; }

		public int Texts { get; set; }

		public string Landline { get; set; }

		public string Mobile { get; set; }

		public string SMS { get; set; }

		public int Seconds { get; set; }

		public int Minutes { get; set; }

		public DateTime CreatedDateTime { get; set; }

		public int RateSheetID { get; set; }

		public string Remarks { get; set; }

		public DateTime Expiry { get; set; }

		public int RemainingMinutes { get; set; }
		public bool IsAutoRenew { get; set; }
		public int DiscountPercentage { get; set; }
		public bool IsTrial { get; set; }
		public bool IsTrialMinutesExpired { get; set; }
		public Guid? TrialId { get; set; }
		public BundleCategory BundleCategory { get; set; }
		public BundleType BundleType { get; set; }
		public bool IsTop { get; set; }
		public string DestinationFlag { get; set; }
		public string DestinationISOCode { get; set; }
		public int RewardPoints { get; set; }
		public PaymentMethods PaymentMethod { set; get; }
		public string CardMaskedPAN { get; set;}
		public bool IsLastRenewalFailed { set; get; }

    }
}
