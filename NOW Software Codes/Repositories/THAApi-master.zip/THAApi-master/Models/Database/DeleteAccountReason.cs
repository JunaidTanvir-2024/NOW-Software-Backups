﻿namespace Models.Database
{
    public class DeleteAccountReason
    {
        public int Id { get; set; }
        public string Reason { get; set; }
    }
}
