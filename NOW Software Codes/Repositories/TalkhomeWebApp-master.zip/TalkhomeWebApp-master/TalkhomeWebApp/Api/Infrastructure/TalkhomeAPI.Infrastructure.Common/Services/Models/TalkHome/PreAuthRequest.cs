﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome
{
    public class PreAuthRequestModel
    {
        public string msisdn { get; set; }
        public string deviceUuid { get; set; } = Guid.NewGuid().ToString();
        public string email { get; set; }
        public string productCode { get; set; } = "THA";
        public string productItemCode { get; set; } = "THAWeb";
    }

    public class PreAuthResponseModel
    {
        public string token_tx { get; set; }
    }
    public class JwtToken
    {
        public string token { get; set; }
        public string expiry { get; set; }
    }
    public class LoginApiResponseModel
    {
        public LoginApiResponseModel()
        {
            //this.UserAccountBalance = new UserAccountBalance();

            //this.UserAccountDetails = new UserAccountDetails();

            //this.UserAccountBundles = new UserAccountBundles();
        }

        public JwtToken jwt { get; set; }
        //public List<LocalAccessNumber2> localaccess { get; set; }
        public List<string> stunServers { get; set; }
        public string Msisdn { get; set; }

        public string AccountID { get; set; }

        public int SubscriberId { get; set; }

        public string Pin { get; set; }

        public string Serial { get; set; }

        public bool canEnterReferralCode { get; set; }

        public bool isSIPCallLockedIPV6 { get; set; }

        public bool isIPV6MsgDisplay { get; set; }

        public bool isReturningUser { get; set; }

        public string scdisable { get; set; }

        public bool canShowApp2APP { get; set; }
        public bool multiStepFO { get; set; }
        //public ForceUpdateMessage forceUpdateMessage { get; set; }

        //public PaidCallSettings PaidCallSettings { get; set; }
        //public a2aCallSettings A2ACallSettings { get; set; }

        private string sipUserName;

        public string SipUserName
        {
            get
            {
                return String.Format("THA{0}", this.Msisdn);
            }
            set { this.sipUserName = value; }
        }

        public string SipPassword { get; set; }

        //public UserAccountBalance UserAccountBalance { get; set; }

        //public UserAccountDetails UserAccountDetails { get; set; }

        //public UserAccountBundles UserAccountBundles { get; set; }

        //public useremailRegistration emailRegistration { get; set; }

        //public Profile userProfile { get; set; }
    }
    public class SignupWithPreAuthRequestV2
    {
        public AppInf appInf { get; set; }
        public DeviceInf deviceInf { get; set; }
        public string Msisdn { get; set; }
        public string AuthTx { get; set; }
        public int signupVer { get; set; } = 2;
    }
    public class AppInf
    {
        public string AppVersion { get; set; } = "1.0.0";
        public string AppLanguage { get; set; } = "en";
        public string ProductCode { get; set; } = "THA";
        public string ProductItemCode { get; set; } = "THAWeb";
    }
    public class DeviceInf
    {
        public string cpuArchitecture { get; set; }
        public string ActionExecuted { get; set; } = "SignUp";
        public string DeviceOS { get; set; }
        public string DeviceOSVersion { get; set; } = "1.0.0";
        public string DeviceMake { get; set; } = "Web";
        public string DeviceModel { get; set; } = "Web";
        public string DeviceLanguage { get; set; } = "en_US";
        public string DevicePersistentID { get; set; }
        public bool IsAndroid { get; set; }
        public bool isTrusted { get; set; }

    }
}
