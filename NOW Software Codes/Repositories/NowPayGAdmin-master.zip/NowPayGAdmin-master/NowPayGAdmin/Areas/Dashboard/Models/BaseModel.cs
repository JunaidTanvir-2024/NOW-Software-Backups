﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models
{
    public class BaseModel
    {
        public int CreatedBy { get; set; }
        public string CreatedByName { get; set; }
        public int LastUpdatedBy { get; set; }
        public string LastUpdatedByName { get; set; }
        public DateTime createdDate { get; set; }
        public DateTime LastUpdatedDate { get; set; }
        public bool isActive { get; set; }
    }
}