using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

public class VoucherPublish : BaseObject
{
    [JsonPropertyName("customer")]
    public string? Customer { get; set; }

    [JsonPropertyName("channel")]
    public string? Channel { get; set; }

    [JsonPropertyName("published_at")]
    public DateTime? PublishedAt { get; set; }
}
