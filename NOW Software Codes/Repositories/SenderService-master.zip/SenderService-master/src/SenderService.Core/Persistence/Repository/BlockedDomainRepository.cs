﻿using Microsoft.EntityFrameworkCore;
using SenderService.Core.Persistence.Entities;

namespace SenderService.Core.Persistence.Repository;

public interface IBlockedDomainRepository
{
    Task<long> AddBlockedDomainAsync(BlockDomain blockedDomain);
    Task<IEnumerable<BlockDomain>> GetAllBlockedDomainsAsync();
    Task<BlockDomain?> GetSpecificBlockedDomainAsync(string domain);
    Task<bool> IsDomainBlockedAsync(string domain);
}

internal sealed class BlockedDomainRepository : IBlockedDomainRepository
{
    private readonly SenderServiceContext _context;

    public BlockedDomainRepository(SenderServiceContext context)
    {
        _context = context;
    }

    public async Task<bool> IsDomainBlockedAsync(string domain)
    {
        var blockedDomain = await _context.BlockedDomains.FirstOrDefaultAsync(x => x.Domain == domain);
        return blockedDomain != null;
    }

    public async Task<long> AddBlockedDomainAsync(BlockDomain blockedDomain)
    {
        var entity = await _context.BlockedDomains.AddAsync(blockedDomain);
        await _context.SaveChangesAsync();
        return entity.Entity.Id;
    }

    public async Task<IEnumerable<BlockDomain>> GetAllBlockedDomainsAsync()
    {
        return await _context.BlockedDomains.ToListAsync();
    }
    public async Task<BlockDomain?> GetSpecificBlockedDomainAsync(string domain)
    {
        return await _context.BlockedDomains.FirstOrDefaultAsync(x => x.Domain == domain);
    }
}