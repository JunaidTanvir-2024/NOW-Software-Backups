﻿using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class SendPushToNamedUserRequest
    {
        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("DeviceType")]
        [Required]        
        public List<DeviceType> DeviceTypes { get; set; }
        
        [JsonProperty("NamedUsers")]
        [Required]
        public List<string> NamedUsers { get; set; }

        [JsonProperty("Notification")]
        [Required]
        public NamedUserNotification Notification { get; set; }

        [JsonProperty("Actions")]
        public NamedUserAction Actions { get; set; }
    }

    public class NamedUserNotification
    {
        [JsonProperty("Alert")]
        [Required]
        public string Alert { get; set; }
    }

    public class NamedUserAction
    {
        [JsonProperty("Open")]
        [Required]
        public NamedUserOpen Open { get; set; }
    }

    public class NamedUserOpen
    {
        [JsonProperty("Type")]
        [Required]
        [EnumDataType(typeof(ActionOpenType))]
        public ActionOpenType Type { get; set; }

        [JsonProperty("Content")]
        [Required]
        public string Content { get; set; }

        [JsonProperty("FallbackUrl")]
        public string FallbackUrl { get; set; }
    }
}
