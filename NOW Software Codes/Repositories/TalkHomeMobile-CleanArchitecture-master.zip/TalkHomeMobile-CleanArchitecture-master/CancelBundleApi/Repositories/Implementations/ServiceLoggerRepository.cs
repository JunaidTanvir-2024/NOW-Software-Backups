﻿using Dapper;
using Microsoft.Extensions.Options;
using System.Data.SqlClient;
using System.Data;
using CancelBundleApi.Models.DbModels;
using CancelBundleApi.Settings.Database;
using CancelBundleApi.Repositories.Interfaces;

namespace CancelBundleApi.Repositories.Implementations;

public class ServiceLoggerRepository : IServiceLoggerRepository
{
    private readonly IDbConnectionSettings _dbConnection;

    public ServiceLoggerRepository(IOptions<DatabaseSettings> databaseSettings)
    {
        _dbConnection = new DbConnectionSettings(new SqlConnection(databaseSettings.Value.ServiceApiConnection));
    }
    public async Task<LkptService> GetServiceDetailsByName(string serviceName)
    {
        LkptService result;
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@service_name", serviceName);

            result = await _dbConnection.SqlConnection.QueryFirstOrDefaultAsync<LkptService>("get_service_details_by_name", parameters, commandType: CommandType.StoredProcedure);
            return result;

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public async Task<int> InsertServiceApiLog(ServiceApiAuditTrail serviceLog)
    {
        int result;
        try
        {

            var parameters = new DynamicParameters();
            parameters.Add("@lkpt_service_id", serviceLog.LkptServiceId);
            parameters.Add("@api_end_point", serviceLog.ApiEndPoint);
            parameters.Add("@start_time_unix_timestamp", serviceLog.StartTimeUnixTimeStamp);
            parameters.Add("@end_time_unix_timestamp", serviceLog.EndTimeUnixTimestamp);
            parameters.Add("@total_time_ms", serviceLog.TotalTimeMs);
            parameters.Add("@request_data", serviceLog.RequestData);
            parameters.Add("@response_data", serviceLog.ResponseData);
            parameters.Add("@is_viewable", serviceLog.IsViewable);
            parameters.Add("@error", serviceLog.Error);
            parameters.Add("@http_method", serviceLog.HttpMethod);
            parameters.Add("@service_correlation_guid", serviceLog.ServiceCorrelationGuid);

            result = await _dbConnection.SqlConnection.ExecuteAsync("add_bundle_service_api_log", parameters, commandType: CommandType.StoredProcedure);
            return result;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
