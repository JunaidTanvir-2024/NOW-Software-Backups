﻿namespace THCC.Application.Settings;

public class Pay360Setting
{
    public const string SectionName = "PaymentSettings:Pay360";
    public static Pay360Setting Bind = new();
    public string ApiEndpoint { get; set; } = default!;
    public bool IsAuthorization { get; set; } = default!;
    public bool Do3DSecure { get; set; } = default!;
    public bool IsCustomerAddressSameAsBilling { get; set; } = default!;
    public string PaymentCallBackUrl { get; set; } = default!;
    public decimal AutoTopupAmount { get; set; }
}
public class PayPalSetting
{
    public const string SectionName = "PaymentSettings:PayPal";
    public static PayPalSetting Bind = new();
    public string ApiEndpoint { get; set; } = default!;
    public string PaymentCallBackUrl { get; set; } = default!;
    public string PaymentCancelCallBackUrl { get; set; } = default!;
}