﻿namespace THCC.Application.Settings;
public class DiscountSettings
{
    public const string SectionName = nameof(DiscountSettings);
    public static DiscountSettings Bind = new DiscountSettings();
    public string? StartDate { get; set; }
    public string? EndDate { get; set; }
    public bool? IsActive { get; set; }
}
