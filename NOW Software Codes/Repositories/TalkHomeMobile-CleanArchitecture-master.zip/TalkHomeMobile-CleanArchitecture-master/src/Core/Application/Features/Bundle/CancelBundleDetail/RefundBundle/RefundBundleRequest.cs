﻿using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.CancelBundleDetail.RefundBundle;
public class RefundBundleRequest : IRequest<Result<RefundBundleResponse>>
{
    public int SubscriberBundleId { get; set; }
    public string BundleGuidId { get; set; } = default!;
    public string Msisdn { get; set; }= default!;
}
