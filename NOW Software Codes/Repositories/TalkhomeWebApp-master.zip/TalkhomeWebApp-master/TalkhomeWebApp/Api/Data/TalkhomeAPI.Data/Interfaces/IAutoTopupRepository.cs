﻿using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Interfaces
{
    public interface IAutoTopupRepository
    {
        Task<AutoTopupDetail> Get(string msisdn);
        Task<int> Set(AutoTopupDetail entity);
    }
}