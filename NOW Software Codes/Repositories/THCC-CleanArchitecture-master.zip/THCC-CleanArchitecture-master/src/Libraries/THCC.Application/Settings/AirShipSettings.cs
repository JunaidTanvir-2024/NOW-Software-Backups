﻿
namespace THCC.Application.Settings
{
    public class AirShipSettings
    {
        public const string SectionName = "AirShipSettings";
        public static AirShipSettings Bind = new();
        public virtual string ApiEndpoint { get; set; } = default!;
        public virtual bool IsActive { get; set; }
    }
}