﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class VoucherRequestModel
    {
        public string Pin { get; set; }
        public string IpAddress { get; set; }
        public string Msisdn { get; set; }
    }
}
