namespace FH.Core.DTOs.Database;

public sealed record OperatorByNameDto
{
    public sealed record Request
    {
        public string? OperatorName { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }

    public sealed record Response
    {
        public long OperatorId { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? CountryName { get; set; }
        public string? CountryIsoCode { get; set; }
    }
}

