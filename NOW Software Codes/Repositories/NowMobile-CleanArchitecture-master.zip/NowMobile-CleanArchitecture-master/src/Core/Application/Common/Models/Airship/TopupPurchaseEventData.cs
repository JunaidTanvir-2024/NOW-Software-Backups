﻿namespace Application.Common.Models.Airship;

public class TopupPurchaseEventData
{
    public string Email { get; set; } = string.Empty;
    public bool IsCard { get; set; } = false;
    public bool IsSuccess { get; set; }
    public bool AutoTopup { get; set; } = false;
    public bool SaveCard { get; set; } = false;
    public decimal Amount { get; set; }
}
