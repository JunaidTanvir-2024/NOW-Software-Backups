﻿using Application.Common.Interfaces.Payment;
using Application.Common.Settings;
using Application.Features.Payment.Card.CustomerCards;
using Microsoft.Extensions.Options;

namespace Application.Features.Payment.Card.MakeCardDefault;

public class MakeCardDefaultRequestHandler : IRequestHandler<MakeCardDefaultRequest, Result<List<CustomerCard>>>
{
    private readonly IStringLocalizer<MakeCardDefaultRequestHandler> _localizer;
    private readonly ICardService _cardService;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly CallBackSettings _callbackSettings;

    public MakeCardDefaultRequestHandler(
        IStringLocalizer<MakeCardDefaultRequestHandler> localizer,
        ICardService cardService,
        ICurrentUser currentUser,
        ICommonService commonService,
        IOptions<CallBackSettings> callbackSettings)
    {
        _localizer = localizer;
        _cardService = cardService;
        _currentUser = currentUser;
        _commonService = commonService;
        _callbackSettings = callbackSettings.Value;
    }

    public async Task<Result<List<CustomerCard>>> Handle(MakeCardDefaultRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();

        //Mark as default card
        var IsMakrDefault = await _cardService.MakeCustomerDefaultCard(request.CardCv2, request.CardToken, _currentUser.GetUserEmail()!);
        if (!IsMakrDefault)
        {
            return Result<List<CustomerCard>>.Failure(_localizer[CustomStatusKey.MakeDefaultCardError], CustomStatusCode.InternalServerError);
        }

        //Get customer cards
        var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);

        foreach (var card in cards)
        {
            card.ImageUrl = (IsAppRequest ? _callbackSettings.AppBaseUrl!
            : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(card.CardScheme);
        }

        return Result<List<CustomerCard>>.Success(cards, _localizer[CustomStatusKey.MakeDefaultCardSuccess]);
    }
}