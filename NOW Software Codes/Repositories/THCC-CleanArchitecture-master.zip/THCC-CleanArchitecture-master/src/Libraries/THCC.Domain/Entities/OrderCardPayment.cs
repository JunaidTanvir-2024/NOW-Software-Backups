﻿namespace THCC.Domain.Entities
{
    public class OrderCardPayment
    {
        public long PaymentId { get; set; }
        public string CardNumber { get; set; } = default!;
        public string CardType { get; set; } = default!;
        public string CardExpiry { get; set; } = default!;
        public bool MakeDefault { get; set; }
        public bool SaveCard { get; set; }
        public bool IsAutoPayment { get; set; }
        public decimal AutoPaymentAmount { get; set; }
        public decimal AutoPaymentThreshold { get; set; }
    }
}
