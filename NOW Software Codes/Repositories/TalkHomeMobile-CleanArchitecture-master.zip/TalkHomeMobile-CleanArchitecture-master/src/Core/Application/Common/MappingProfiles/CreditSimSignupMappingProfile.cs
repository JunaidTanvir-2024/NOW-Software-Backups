﻿using Application.Features.Sim.CreditSim.Confirm;
using Mapster;

namespace Application.Common.MappingProfiles;

internal sealed class CreditSimSignupMappingProfile : IRegister
{
    public UserCredentials UserCredentials { get; private set; } = default!;

    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<CreditSimConfirmRequest, User>
        .NewConfig()
        .BeforeMapping((user, _) => GetUserCredentials(user))
        .Map(user => user.FirstName, signupRequest => $"{signupRequest.UserInfo.FirstName}")
        .Map(user => user.LastName, signupRequest => $"{signupRequest.UserInfo.LastName}")
        .Map(user => user.Email, signupRequest => $"{signupRequest.UserInfo.Email}")
        .Map(user => user.IsSubscribedToNewsletter, signupRequest => $"{signupRequest.UserInfo.NewsLetter}")
        .Map(user => user.Password, _ => UserCredentials.Password)
        .Map(user => user.PasswordPrefix, _ => UserCredentials.PasswordPrefix)
        .Map(user => user.PasswordSuffix, _ => UserCredentials.PasswordSuffix)
        .Map(user => user.IV, _ => UserCredentials.IV)
        .Map(user => user.Key, _ => UserCredentials.Key);
    }

    private void GetUserCredentials(CreditSimConfirmRequest signupRequest)
    {
        var saltDict = SecurityHelper.CreatePasswordAppendages();
        var encryptedSaltDict = SecurityHelper.EncryptPasswordAppendages(saltDict);
        UserCredentials = SecurityHelper.CreateUserCredentials(saltDict, encryptedSaltDict, signupRequest.UserInfo.Password);
    }
}