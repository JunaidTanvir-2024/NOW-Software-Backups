using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MM.Core.Common.Interfaces.Database;
public interface ISmsLogRepository
{
    Task InsertSmsLog(MessageLog smsLogDto);
    Task<int> GetMessageCount(string receiver, string message, DateTime requestedDate);
    Task<bool> GetMessageSent(int smsCount, long smsTime, string senderMsisdn);
}
