﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Request
{
    public class GetTransactionRequest : BaseRequest
    {
        public string command = "getTransaction";

        public string userReference { get; set; }
    }
}
