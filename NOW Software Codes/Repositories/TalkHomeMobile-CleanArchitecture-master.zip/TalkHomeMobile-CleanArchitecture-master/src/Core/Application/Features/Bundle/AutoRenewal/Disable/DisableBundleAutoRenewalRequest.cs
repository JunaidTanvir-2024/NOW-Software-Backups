﻿namespace Application.Features.Bundle.AutoRenewal.Disable;

public sealed class DisableBundleAutoRenewalRequest : IRequest<Result<object>>
{
    public string Msisdn { get; set; } = default!;
    public int BundleId { get; set; } = default!;
    public long? SubcriberBundleId { get; set; } 
}
