using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class Expense : IBaseEntity<long>, IAuditEntity
{
    public long Id { get; set; }
    public string? Description { get; set; }
    public decimal Amount { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsDeleted { get; set; } = false;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public DateTime? DeletedAt { get; set; }
    public long TripId { get; set; }
    public long TravelerId { get; set; }
    public long CategoryId { get; set; }
    public Trip Trip { get; set; } = null!;
    public Traveler Traveler { get; set; } = null!;
    public ExpenseCategory Category { get; set; } = null!;
}
