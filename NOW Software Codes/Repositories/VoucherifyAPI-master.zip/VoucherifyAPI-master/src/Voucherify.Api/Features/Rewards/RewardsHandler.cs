﻿using Voucherify.Core.Services.VoucherifyApi;

namespace Voucherify.Api.Features.Rewards;

internal class RewardsHandler
{
    private readonly IVoucherifyImplementation _voucherifyImplementation;

    public RewardsHandler(IVoucherifyImplementation voucherifyImplementation)
    {
        _voucherifyImplementation = voucherifyImplementation;
    }
}
