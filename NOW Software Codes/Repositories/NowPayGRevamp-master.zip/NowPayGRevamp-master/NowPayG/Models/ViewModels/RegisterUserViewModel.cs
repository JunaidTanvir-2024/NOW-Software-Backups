﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class RegisterUserViewModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int CountryId { get; set; }
        public string Email { get; set; }
        [Required(ErrorMessage = "Enter Password")]
        public string Password { get; set; }
        public bool MailSubscription { get; set; }
        //[Required(ErrorMessage = "Enter Confirm Password"), Compare("Password", ErrorMessage = "Passwod do not match")]
        //public string ConfirmPassword { get; set; }
    }
}
