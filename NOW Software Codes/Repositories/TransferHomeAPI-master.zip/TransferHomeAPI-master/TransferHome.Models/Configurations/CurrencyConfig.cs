﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Configurations
{
    public class CurrencyConfig
    {
        public string[] AllowedCurrencies { get; set; }

        public Dictionary<string, string> CountryWiseCurrency { get; set; }
    }
}
