﻿namespace THCC.Application.Features.User.History.CallHistory
{
    public class CallHistoryRequest : IRequest<object>
    {
        public string CardPin { get; set; } = default!;
    }

    public class CallHistoryRequestValidator : AbstractValidator<CallHistoryRequest>
    {
        public CallHistoryRequestValidator()
        {
            RuleFor(data => data.CardPin)
                    .NotNull()
                    .NotEmpty()
                    .MaximumLength(25).WithMessage("Your card number length must not exceed {0}");
        }
    }
}