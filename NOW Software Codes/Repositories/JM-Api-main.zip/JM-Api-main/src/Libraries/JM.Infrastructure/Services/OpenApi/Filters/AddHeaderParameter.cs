using JM.Core.Utilities.Definitions;

using Microsoft.OpenApi.Models;

using Swashbuckle.AspNetCore.SwaggerGen;

namespace JM.Infrastructure.Services.OpenApi.Filters;


public class AddHeaderParameter : IOperationFilter
{
    public void Apply(OpenApiOperation operation, OperationFilterContext context)
    {
        operation.Parameters ??= [];

        // Add your global header parameter here
        operation.Parameters.Add(new OpenApiParameter
        {
            Name = AppConstant.Headers.RequestReference,
            In = ParameterLocation.Header,
            Required = true,
            Schema = new OpenApiSchema
            {
                Type = "string"
            }
        });
        operation.Parameters.Add(new OpenApiParameter
        {
            Name = AppConstant.Headers.ProductReference,
            In = ParameterLocation.Header,
            Required = true,
            Schema = new OpenApiSchema
            {
                Type = "string"
            }
        });
    }
}
