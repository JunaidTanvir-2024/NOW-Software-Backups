﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class GetUserBalanceResponseModel
    {
        public decimal Balance { get; set; }
        public string BalanceCurrency { get; set; }
        public string BalanceCurrencySymbol { get; set; }
    }
}
