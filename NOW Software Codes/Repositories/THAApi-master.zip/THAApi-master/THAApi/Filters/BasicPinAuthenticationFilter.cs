﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Response;
using Models.Database;
using Models.Enums;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using THAApi.Controllers;
using THAAPI.Controllers;

namespace THAAPI.Filters
{
	public class BasicPinAuthenticationFilter : ActionFilterAttribute
	{

		private readonly ILogger _logger;
		private readonly IUserAccount_DL _userAccountsDb;
		private readonly IStringLocalizer _localizer;
		private readonly IJwt_BL _jwtBL;
		private readonly JwtConfig _jwtConfig;
		public BasicPinAuthenticationFilter(
			IJwt_BL jwt_BL,
			IOptions<JwtConfig> jwtConfig,
			ILogger logger,
			IUserAccount_DL userAccountsDb,
			IStringLocalizer localizer)
		{
			_logger = logger;
			_userAccountsDb = userAccountsDb;
			_localizer = localizer;
			_jwtConfig = jwtConfig.Value;
			_jwtBL = jwt_BL;
		}
		public override async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
		{
			try
			{
				// Extract controller and action method names
				string controller = context.RouteData.Values["Controller"].ToString().ToLower();
				string actionMethod = context.RouteData.Values["Action"].ToString().ToLower();

				// Authorize if action is anonymous
				if (context.ActionDescriptor.EndpointMetadata.Any(e => e is AllowAnonymousAttribute) && !(controller.Equals("useraccount") && actionMethod.Equals("login")))
				{
					await base.OnActionExecutionAsync(context, next);
					return;
				}

				if (!await ValidateNowtelHeaderAsync(context))
				{
					Challenge(context, "Invalid or Missing Nowtel Authentication Header.");
					return;
				}

				if (context.Controller is UnauthorisedController)
				{
					await base.OnActionExecutionAsync(context, next);
					return;
				}

				if (_jwtConfig.IsJwtOn == true && !(controller.Equals("useraccount") && actionMethod.Equals("login")))
				{
					string token = ParseBearerHeader(context);

					if (token == null)
					{
						Challenge(context, "Bearer Authentication Header Missing.");

						return;
					}

					JwtTokenValidationResponse tokenResponse = _jwtBL.ValidateToken(token);

					if (tokenResponse == null || !tokenResponse.isTokenValid)
					{
						Challenge(context, "Invalid Token.");
						return;
					}

					var dId = tokenResponse?.claims?.Find(c => c.Type.Equals("dId")).Value;
					var ip = tokenResponse?.claims?.Find(c => c.Type.Equals("ip")).Value;
					var userMsisdn = tokenResponse?.claims?.Find(c => c.Type.Equals("msisdn")).Value;

					if (string.IsNullOrEmpty(dId) || string.IsNullOrEmpty(ip) || string.IsNullOrEmpty(userMsisdn))
					{
						Challenge(context, "Token claims are missing or empty.");
						return;
					}

					var isUserBlocked = await _userAccountsDb.IsUserBlockedAsync(userMsisdn);
					if (isUserBlocked) // Not Valid User
					{
						Challenge(context, "Access Blocked.");
						return;
					}

					var validationResp = await _userAccountsDb.ValidateDeviceAndIpAddressAsync(dId, ip);

					if (validationResp == null || validationResp.ValidationType != 1)
					{
						Challenge(context, "Access Blocked.");
						return;
					}

					var userDeleteAccountRequest = await _userAccountsDb.GetDeleteAccountLogRequest(userMsisdn);

					if (userDeleteAccountRequest != null
						&& userDeleteAccountRequest.AccountDeleteStatus != AccountDeleteStatus.Deleted
						&& userDeleteAccountRequest.AccountDeleteStatus != AccountDeleteStatus.Cancelled)
					{
						Challenge(context, "Access Blocked.");
						return;
					}

					ClaimsIdentity claimIdentity = new ClaimsIdentity(tokenResponse.claims, "Bearer");
					var claimPrincipal = new ClaimsPrincipal(new List<ClaimsIdentity>() { claimIdentity });
					Thread.CurrentPrincipal = claimPrincipal;
					context.HttpContext.User = claimPrincipal;
					await base.OnActionExecutionAsync(context, next);
					return;
				}

				string[] credentials = ParseAuthorizationHeader(context);

				if (credentials == null)
				{
					Challenge(context, "Basic Authentication Header Missing.");
					return;
				}

				string msisdn, pin;

				ExtractCredentials(credentials, out msisdn, out pin);

				(bool isAuthenticated, AccountInfo accountInfo) authorizeResult = await OnAuthorizeUserAsync(msisdn, pin);

				if (!authorizeResult.isAuthenticated)
				{
					Challenge(context, "Invalid Basic Authentication Header.");
					return;
				}

				List<Claim> claims = new List<Claim>() {
					new Claim("msisdn", msisdn),
					new Claim("pin", pin), 
                    //new Claim("naServiceId", accountInfo.na_service_id.Trim()),
                    new Claim("currency", authorizeResult.accountInfo.currency.Trim()),
                    //new Claim("account", accountInfo.account.Trim()),
                    //new Claim("language", language)
                };
				ClaimsIdentity identity = new ClaimsIdentity(claims, "Basic");

				var principal = new ClaimsPrincipal(new List<ClaimsIdentity>() { identity });

				Thread.CurrentPrincipal = principal;
				context.HttpContext.User = principal;
				//Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(language);
				//Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(language);
				await base.OnActionExecutionAsync(context, next);
				return;
			}
			catch (Exception ex)
			{
				_logger.Error($"Class: BasicPinAuthenticationFilter, Method: OnActionExecuting, ErrorMessage:{ex.Message}, StackTrace: {ex.StackTrace}");
				context.HttpContext.Response.StatusCode = 500; // Internal Server Error    
				context.Result = new JsonResult(new { Message = "Internal Server Error.", Payload = new { } });
				return;
			}
		}

		#region Helper Functions
		private static void ExtractCredentials(string[] credentials, out string msisdn, out string pin)
		{
			msisdn = credentials[0];
			pin = credentials[1];
		}

		private string ParseBearerHeader(ActionExecutingContext context)
		{
			try
			{
				string authHeader = context.HttpContext.Request.Headers["Authorization"];
				if (authHeader != null && authHeader.StartsWith("Bearer", StringComparison.OrdinalIgnoreCase))
				{
					//Extract credentials
					return authHeader.Replace("Bearer ", "").Trim();
				}

				// no authorization header
				return null;
			}
			catch (Exception ex)
			{
				_logger.Error($"Class: BasicPinAuthenticationFilter, Method: ParseBearerHeader, ErrorMessage:{ex.Message}, StackTrace: {ex.StackTrace}");
				return null;
			}
		}
		private string[] ParseAuthorizationHeader(ActionExecutingContext context)
		{
			try
			{
				string authHeader = context.HttpContext.Request.Headers["Authorization"];
				if (authHeader != null && authHeader.StartsWith("basic", StringComparison.OrdinalIgnoreCase))
				{
					//Extract credentials
					string encodedUsernamePassword = authHeader.Substring("Basic".Length).Trim();
					//Encoding encoding = Encoding.GetEncoding("iso-8859-1");
					//string usernamePassword = encoding.GetString(Convert.FromBase64String(encodedUsernamePassword));

					string usernamePassword = Encoding.UTF8.GetString(Convert.FromBase64String(encodedUsernamePassword));

					string[] credentials = usernamePassword.Split(':');

					return credentials.Length < 2 ? null : credentials;
				}

				// no authorization header
				return null;
			}
			catch (Exception ex)
			{
				_logger.Error($"Class: BasicPinAuthenticationFilter, Method: ParseAuthorizationHeader, ErrorMessage:{ex.Message}, StackTrace: {ex.StackTrace}");
				return null;
			}
		}
		private async Task<bool> ValidateNowtelHeaderAsync(ActionExecutingContext context)
		{
			try
			{
				string nowtelHeader = context.HttpContext.Request.Headers["NowtelAuth"];
				return !string.IsNullOrEmpty(nowtelHeader) && await _userAccountsDb.ValidateNowtelTokenAsync(nowtelHeader);
			}
			catch (Exception ex)
			{
				_logger.Error($"Class: BasicPinAuthenticationFilter, Method: ValidateNowtelHeader, ErrorMessage:{ex.Message}, StackTrace: {ex.StackTrace}");

				return false;
			}
		}
		private void Challenge(ActionExecutingContext context, string message)
		{
			var result = new { Message = message, Payload = new { } };
			context.HttpContext.Response.StatusCode = 401; // Unauthorized
			context.HttpContext.Response.Headers.Add("WWW-Authenticate", "Basic realm=\"realm\"");
			context.Result = new JsonResult(result);
		}
		private async Task<(bool isAuthenticated, AccountInfo accountInfo)> OnAuthorizeUserAsync(string msisdn, string pin)
		{
			var isUserBlocked = await _userAccountsDb.IsUserBlockedAsync(msisdn);
			if (isUserBlocked)
			{
				return (false, null);
			}
			//Login case
			var existingUserDeletedAccountRequest = await _userAccountsDb.GetDeleteAccountLogRequest(msisdn);
			//check if user try to login allowed after delete request submitted and account is in progress state
			if (existingUserDeletedAccountRequest != null && existingUserDeletedAccountRequest.AccountDeleteStatus != AccountDeleteStatus.Deleted && existingUserDeletedAccountRequest.AccountDeleteStatus != AccountDeleteStatus.Cancelled)
			{
				return (false,null);
			}
			var accountInfo = await _userAccountsDb.GetAccountCurrencyAndPin(msisdn);
			bool validPin = (accountInfo != null && pin.Equals(accountInfo?.pin?.Trim(), StringComparison.InvariantCulture));

			if (!validPin)
			{
				return (false, null);
			}
			return (true, accountInfo);
		}
		#endregion
	}
}
