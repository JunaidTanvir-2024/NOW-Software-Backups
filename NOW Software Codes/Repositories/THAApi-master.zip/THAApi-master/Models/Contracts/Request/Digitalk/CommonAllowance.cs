﻿namespace Models.Contracts.Request.Digitalk
{
	public class CommonAllowance
	{
		public string Spend { get; set; }
		public int SpendMode { get; set; }
		public string SpendText { get; set; }
	}
}