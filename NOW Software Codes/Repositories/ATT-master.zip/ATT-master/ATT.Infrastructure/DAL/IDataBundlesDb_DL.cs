﻿using ATT.Models.Contracts.TransferTo.Response;
using ATT.Models.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Infrastructure.DAL
{
    public interface IDataBundlesDb_DL
    {
        Task<ServiceProvider> GetDataBundleServiceProviderRecord(int nsid, string destinationMsisdn);
        List<EndRateDataBundleProductList> GetDataBundleEndRates(int serviceProviderOperaorId, string account, int serviceProviderId, int originDestinationId);

        Task<int> insertDataBundleAccessDetails(string nowtelTransactionReference, string account, string toMsisdn, string productApiType, string clientccy, string receiverccy, string productId, string productValue, string productDesc, string wholeSalePrice, string customerChargePrice);

        Task<DataBundleAPIAccess> getDataBundleAccessRecord(string nowtelTransactionReference, string productValue, string productApiType);
        Task<bool> InsertDataBundleTransaction(string Date, string AccountID, decimal Amount, decimal BuyAmount, string Currency, string OperatorCurrency, string DestinationCountry, string Status, string ErrorMessage, string OperaterID, string ProductID, string Product, string ProductDesc, string ProductApiType, string OperatorName, string NowtelTranscationRefrence, string TransactionRefrence, string frommsisdn, string tomsisdn, int ServiceProviderID, string message_to_recipient);
        
    }
}
