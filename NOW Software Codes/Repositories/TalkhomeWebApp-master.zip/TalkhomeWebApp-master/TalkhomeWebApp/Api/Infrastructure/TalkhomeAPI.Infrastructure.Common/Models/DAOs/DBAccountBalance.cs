﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBAccountBalance
    {
        public decimal new_balance { get; set; }
        public string audit_id { get; set; }
    }
}
