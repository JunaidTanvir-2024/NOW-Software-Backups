﻿namespace Application.Features.Carousel;
public class CarouselRequestHandler : IRequestHandler<CarouselRequest, Result<IEnumerable<CarouselResponse>>>
{
    #region Fields

    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<CarouselRequest> _localizer;
    private readonly ICurrentUser _currentUser;

    #endregion

    #region Ctors

    public CarouselRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<CarouselRequest> localizer,
        ICurrentUser currentUser
    )
    {
        _uow = uow;
        _localizer = localizer;
        _currentUser = currentUser;
    }

    #endregion

    #region Methods

    public async Task<Result<IEnumerable<CarouselResponse>>> Handle(CarouselRequest request, CancellationToken cancellationToken)
    {
        var promotions = await _uow.PromotionRepo.GetPromotionCarousel(_currentUser.GetUserId(), request.Msisdn!, null);
        return Result<IEnumerable<CarouselResponse>>.Success(promotions!, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
