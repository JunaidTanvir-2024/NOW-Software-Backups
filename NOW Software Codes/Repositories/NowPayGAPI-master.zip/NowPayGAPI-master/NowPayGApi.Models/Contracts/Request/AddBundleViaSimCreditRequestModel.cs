﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class AddBundleViaSimCreditRequestModel
    {
        [Required]
        public string AccountId { get; set; }
        [Required]
        public string Uuid { get; set; }
        public string Msisdn { get; set; }
        public bool isAutoRenew { get; set; }
    }
}
