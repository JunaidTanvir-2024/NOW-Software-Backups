﻿namespace THCC.Admin.Data
{
    public class SeedIdentityData
    {
    }
}
