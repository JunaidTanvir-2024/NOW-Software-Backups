using Microsoft.AspNetCore.Mvc;

using Voucherify.Api.Features.StackableDiscounts.Requests;

using Voucherify.Core.Commons.Filters;

namespace Voucherify.Api.Features.StackableDiscounts;

public static class StackableDiscountsEndpoints
{
    private const string EndpointPrefix = "/api/discounts";
    private const string EndpointTag = "Stackable Discounts Endpoints";

    public static void AddStackableDiscountsEndpoints(this WebApplication app)
    {
        var vouchersEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);

        vouchersEndpoints
            .MapPost("/validate", ValidateDiscounts)
            .AddEndpointFilter<FluentValidationFilter<StackableDiscountValidationRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK);

        vouchersEndpoints.MapPost("/redeem", RedeemDiscounts)
        .AddEndpointFilter<FluentValidationFilter<StackableDiscountRedemptionRequest>>()
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status200OK);

        vouchersEndpoints.MapPost("/rollback", RollbackDiscountRedemption)
        .AddEndpointFilter<FluentValidationFilter<StackableDiscountRollbackRequest>>()
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status200OK);
    }
    private static async Task<IResult> ValidateDiscounts(IStackableDiscountsHandler stackableDiscountsHandler, [FromBody] StackableDiscountValidationRequest request)
    {
        var result = await stackableDiscountsHandler.ValidateStackableDiscounts(request);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.BadRequest(result);
    }
    private static async Task<IResult> RedeemDiscounts(IStackableDiscountsHandler stackableDiscountsHandler, [FromBody] StackableDiscountRedemptionRequest request)
    {
        var result = await stackableDiscountsHandler.RedeemStackableDiscounts(request);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.BadRequest(result);
    }
    private static async Task<IResult> RollbackDiscountRedemption(IStackableDiscountsHandler stackableDiscountsHandler, [FromBody] StackableDiscountRollbackRequest request)
    {
        var result = await stackableDiscountsHandler.RollbackStackableDiscounts(request);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.BadRequest(result);
    }
}
