﻿

namespace Infrastructure.Localization;
internal static class DependenciesContainer
{
    internal static IServiceCollection AddLocalizationServices(this IServiceCollection services)
    {
        services.AddLocalization();
        services.AddSingleton<IStringLocalizerFactory, JsonStringLocalizerFactory>();
        return services;
    }
}