﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class AccountSummaryRequestModel
    {
        public string ClientNumber { get; set; }
        public string AccountNumber { get; set; }
    }
}
