﻿namespace TalkhomeWebApp.Models.ViewModels
{
    public class VerifyPinViewModel
    {
        public string PinCode { get; set; }
        public string Token { get; set; }
    }
}
