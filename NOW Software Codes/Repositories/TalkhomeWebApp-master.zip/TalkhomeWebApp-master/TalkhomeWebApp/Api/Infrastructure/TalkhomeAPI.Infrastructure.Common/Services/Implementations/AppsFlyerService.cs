﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Models.AppsFlyer;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public interface IAppsFlyerService
    {
        bool IsActive { get; }
        Task SetCustomerId(string customerUserId, string afUserId);
        Task CreateCustomEvent(List<CreateEventRequestModel> request);
        Task HandleAutoTopup(string msisdn, bool IsActive);
        Task HandleTopupEvents(string customerUserId, bool IsSuccess, bool? IsCard, decimal Amount, string currency, string origination, bool IsAutoTopUp, string ipAddress = null);
        Task HandleBundlePurchaseEvents(string customerUserId, string origination, string destination, int BundleType, bool IsSuccess, bool? IsCard, decimal Amount, decimal RemainingBalance, string currency, string ipAddress = null);
        Task HandleIntTopupEvents(string customerUserId, string origination, string destination, bool IsSuccess, bool? IsCard, decimal Amount, decimal RemainingBalance, string ipAddress = null);
    }

    public class AppsFlyerService : IAppsFlyerService
    {
        private readonly AppsFlyerConfig _websFlyerConfig;
        private readonly ILogger _logger;

        public bool IsActive { get; }

        public AppsFlyerService(
            IOptions<AppsFlyerConfig> appsFlyerConfig,
            ILogger logger)
        {
            _websFlyerConfig = appsFlyerConfig.Value;
            IsActive = appsFlyerConfig.Value.IsActive;
            _logger = logger;
        }

        public async Task HandleTopupEvents(string customerUserId, bool IsSuccess, bool? IsCard, decimal Amount, string currency, string origination, bool IsAutoTopUp, string ipAddress)
        {
            try
            {
                if (customerUserId == null)
                    return;
                if (!_websFlyerConfig.IsActive)
                    return;

                var transactionevents = new List<CreateEventRequestModel>();
                string paymentMethod = GetPaymentMethod(IsCard, "Topup");
                if (!String.IsNullOrEmpty(currency))
                {
                    ipAddress = currency;
                }

                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();
                if (IsSuccess)
                {
                    if (IsCard == true)
                    {
                        transactionevents.Add(new CreateEventRequestModel
                        {
                            customerUserId = customerUserId,
                            eventName = IsAutoTopUp ? "enable_autotop_web" : "disable_autotop_web",
                            eventRevenue = Amount
                        });
                    }

                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new CreateEventRequestModel
                        {
                            customerUserId = customerUserId,

                            eventName = "total_purchase_web",
                            eventValue = new
                            {
                                origination = origination,
                                af_revenue = Amount,
                            },
                            eventRevenue = Amount
                        });
                    }

                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,
                        eventName = "topup_any_web",
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,
                        eventName = "total_transaction_web",
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,
                        eventName = $"topup_any_{paymentMethod}_web",
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"topup_any_{origination}_{paymentMethod}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"topup_{Amount}_{origination}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"topup_{Amount}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"topup_any_{origination}_web",

                        eventRevenue = Amount
                    });
                }
                else
                {
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"payfail_any_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,
                        eventName = $"payfail_any_{origination}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"payfail_{paymentMethod}_web",

                        eventRevenue = Amount
                    });
                }
                await CreateCustomEvent(transactionevents);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AppsFlyerService, Method: FireTopupEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleBundlePurchaseEvents(string customerUserId, string origination, string destination, int BundleType, bool IsSuccess, bool? IsCard, decimal Amount, decimal RemainingBalance, string currency, string ipAddress)
        {
            try
            {
                if (customerUserId == null)
                    return;
                if (!_websFlyerConfig.IsActive)
                    return;

                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();

                if (!string.IsNullOrEmpty(destination))
                    destination = destination.ToLower().Trim();

                var transactionevents = new List<CreateEventRequestModel>();
                //string bundleType = GetBundleType(BundleType);
                string bundleType = GetBundleType(BundleType);


                string paymentMethod = GetPaymentMethod(IsCard);



                if (IsSuccess)
                {
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new CreateEventRequestModel
                        {
                            customerUserId = customerUserId,
                            eventName = $"total_purchase_web",
                            eventRevenue = Amount,
                            eventValue = new
                            {
                                origination = origination,
                                af_revenue = Amount,
                            },
                        });
                    }
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_any_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"total_transaction_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_{paymentMethod}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_{bundleType}_any_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_dest_{destination}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_orig_{origination}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_dest_{bundleType}_{destination}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_orig_{bundleType}_{origination}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_any_{origination}_{destination}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_{bundleType}_{origination}_{destination}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_{bundleType}_{paymentMethod}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"bun_{bundleType}_{origination}_{destination}_{paymentMethod}_web",

                        eventRevenue = Amount
                    });

                    if (IsCard == null) // Balance Payment
                    {
                        if (RemainingBalance < 1)
                        {
                            transactionevents.Add(new CreateEventRequestModel
                            {
                                customerUserId = customerUserId,
                                eventName = $"acc_bal_low",
                                eventRevenue = Amount
                            });
                        }
                    }

                }
                else
                {
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"payfail_bun_any_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"payfail_bun_{paymentMethod}_web",

                        eventRevenue = Amount
                    });
                }

                await this.CreateCustomEvent(transactionevents);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AppsFlyerService, Method: FireBundlePurchaseEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleIntTopupEvents(string customerUserId, string origination, string destination, bool IsSuccess, bool? IsCard, decimal Amount, decimal RemainingBalance, string ipAddress)
        {
            try
            {
                if (customerUserId == null)
                    return;
                if (!_websFlyerConfig.IsActive)
                    return;

                var transactionevents = new List<CreateEventRequestModel>();

                string paymentMethod = GetPaymentMethod(IsCard);

                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();

                if (!string.IsNullOrEmpty(destination))
                    destination = destination.ToLower().Trim();



                if (IsSuccess)
                {
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new CreateEventRequestModel
                        {
                            customerUserId = customerUserId,

                            eventName = $"total_purchase_web",

                            eventRevenue = Amount,
                            eventValue = new
                            {
                                origination = origination,
                                af_revenue = Amount,
                            },
                        });
                    }
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"inttop_any_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = "total_transaction_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"inttop_{paymentMethod}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"inttop_dest_{destination}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"inttop_orig_{origination}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"inttop_any_{origination}_to_{destination}_web",

                        eventRevenue = Amount
                    });
                }
                else
                {
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"inttop_failure_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"inttopfail_{paymentMethod}_web",

                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        customerUserId = customerUserId,

                        eventName = $"inttopfail_any_{origination}_web",

                        eventRevenue = Amount
                    });
                }
                await CreateCustomEvent(transactionevents);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AppsFlyerService, Method: HandleIntTopupEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleAutoTopup(string msisdn, bool isActive)
        {
            if (msisdn == null)
                return;
            if (!_websFlyerConfig.IsActive)
                return;


            var transactionevents = new List<CreateEventRequestModel>();
            transactionevents.Add(new CreateEventRequestModel
            {
                customerUserId = msisdn,
                eventName = isActive ? "enable_autotop_web" : "disable_autotop_web"
            });
            await CreateCustomEvent(transactionevents);
        }
        public async Task CreateCustomEvent(List<CreateEventRequestModel> requestModel)
        {
            try
            {
                var request = new HttpRequestMessage(
                    HttpMethod.Post, _websFlyerConfig.ApiEndpoint + "api/Home/CreateCustomEvent")
                {
                    Content = new StringContent(
                        JsonConvert.SerializeObject(requestModel), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AppsFlyerService, Method: CreateCustomEvent, " +
                     $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task SetCustomerId(string customerUserId, string afUserId)
        {
            try
            {
                var requestModel = new SetCustomerIdRequestModel()
                {
                    afUserId = afUserId,
                    customerUserId = customerUserId
                };

                var request = new HttpRequestMessage(HttpMethod.Post, _websFlyerConfig.ApiEndpoint + "api/Home/SetCuId")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(requestModel), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AppsFlyerService, Method: SetCustomerId, " +
                     $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }

        private string GetPaymentMethod(bool? IsCard, string type = null)
        {
            if (IsCard.HasValue)
            {
                if (IsCard.Value)
                {
                    return "card";
                }
                else
                {
                    return "paypal";
                }
            }
            else
            {
                if (type == "Topup")
                {
                    return "voucher";
                }
                else
                {
                    return "balance";
                }
            }
        }
        private string GetBundleType(int bundleType)
        {
            if (bundleType == (int)BundleType.Welcome)
            {
                return "welcome";
            }
            else if (bundleType == (int)BundleType.PAYG)
            {
                return "payg";
            }
            else if (bundleType == (int)BundleType.Monthly)
            {
                return "roll";
            }
            else
            {
                return "trial";
            }
        }
    }
}
