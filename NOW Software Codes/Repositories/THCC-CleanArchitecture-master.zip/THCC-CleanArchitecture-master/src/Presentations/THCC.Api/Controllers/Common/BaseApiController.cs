using System.Net;

using MediatR;

using Microsoft.AspNetCore.Mvc;

using THCC.Application.Models.ResponseWrappers;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Api.Controllers.Common;

[Route("api/[controller]")]
public abstract class BaseApiController : ControllerBase
{
    private ISender _mediator = null!;
    protected ISender Mediator => _mediator ??= HttpContext.RequestServices.GetRequiredService<ISender>();

    [ApiExplorerSettings(IgnoreApi = true)]
    [NonAction]
    public IActionResult HandleResponse(object response)
    {
        if (response != null)
        {
            if (response is ErrorResult result)
            {
                var responseData = result.Errors[0];
                return responseData.Code switch
                {
                    CustomStatusCode.BadRequest => BadRequest(response),
                    CustomStatusCode.InternalServerError => StatusCode((int)HttpStatusCode.InternalServerError, response),
                    CustomStatusCode.Unauthorized => Unauthorized(response),
                    CustomStatusCode.Forbidden => StatusCode((int)HttpStatusCode.Forbidden, response),
                    CustomStatusCode.NotFound => NotFound(response),
                    _ => BadRequest(response),
                };
            }
            else
            {
                return Ok(response);
            }
        }
        return Ok();
    }
}