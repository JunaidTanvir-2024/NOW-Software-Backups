namespace DC.Infrastructure.Common.Settings;
public class PhishingSetting
{
    public const string SectionName = nameof(PhishingSetting);
    public static PhishingSetting Bind { get; } = new PhishingSetting();


    public int SmsLimit { get; set; }

    public long SmsTimeLimitSec { get; set; }


}
