﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    public class VoucherDetails
    {
        public string VoucherCode { get; set; }

        public bool Used { get; set; }

        public decimal Credit { get; set; }
    }
}
