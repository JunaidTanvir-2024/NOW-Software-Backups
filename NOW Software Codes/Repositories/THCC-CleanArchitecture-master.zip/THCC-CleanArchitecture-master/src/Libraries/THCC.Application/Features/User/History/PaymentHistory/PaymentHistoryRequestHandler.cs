﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Domain.Aggregates;

namespace THCC.Application.Features.User.History.PaymentHistory
{
    public class PaymentHistoryRequestHandler : IRequestHandler<PaymentHistoryRequest, object>
    {
        #region Fields

        private readonly ICurrentUser _currentUser;
        private readonly IMapper _mapper;
        private readonly IUserRepository _userRepository;

        #endregion

        #region Ctor

        public PaymentHistoryRequestHandler(
            ICurrentUser currentUser,
            IMapper mapper,
            IUserRepository userRepository)
        {
            _currentUser = currentUser;
            _mapper = mapper;
            _userRepository = userRepository;
        }

        #endregion

        #region Method

        public async Task<object> Handle(PaymentHistoryRequest request, CancellationToken cancellationToken)
        {
           var ( totalcounts, paymentDetails) = await _userRepository.PaymentHistory(
                    _currentUser.GetUserId(),
                    request.PageNo,
                    request.PageSize,
                    request.ProductType);

            return new PaymentHistoryResponse()
            {
                TotalRecords = totalcounts,
                PaymentDetails = paymentDetails != null ? _mapper.Map<IList<PaymentDetail>>(paymentDetails!) : null!
            };
        }

        #endregion
    }
}
