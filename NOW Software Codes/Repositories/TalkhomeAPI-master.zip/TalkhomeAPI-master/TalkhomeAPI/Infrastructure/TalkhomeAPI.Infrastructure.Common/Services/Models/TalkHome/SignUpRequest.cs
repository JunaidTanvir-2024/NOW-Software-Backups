﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome
{
    public class SignUpRequest
    {
        public string msisdn { get; set; }
        public AppInfo appInfo { get; set; }
    }

    public class AppInfo
    {
        public string DeviceLanguage { get; set; } = "en_US";
        public string AppLanguage { get; set; } = "en";
        public string DevicePersistentID { get; set; }
        public string AppVersion { get; set; } = "1.0.0";
        public string DeviceMake { get; set; } = "Web";
        public string DeviceOSVersion { get; set; } = "1.0.0";
        public string DeviceModel { get; set; } = "Web";
        public string ActionExecuted { get; set; } = "SignUp";
    }
}
