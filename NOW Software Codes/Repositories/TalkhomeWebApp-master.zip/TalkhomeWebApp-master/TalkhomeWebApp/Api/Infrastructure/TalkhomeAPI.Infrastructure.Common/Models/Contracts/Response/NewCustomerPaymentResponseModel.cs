﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class NewCustomerPaymentResponseModel
    {
        public ThreeDSecureData threeDSecureData { get; set; }
        public BundlePurchaseInfo bundlePurchaseInfo { get; set; }
        public TopupInfo topupInfo { get; set; }
    }

    public class BundlePurchaseInfo
    {
        public string TransactionId { get; set; }
        public string BundleName { get; set; }
        public string BundleAmount { get; set; }
        public string Msisdn { get; set; }
        public string Currency { get; set; }
        public BundleType BundleType { get; set; }
        public string Origination { get; set; }
        public string Destination { get; set; }
        public bool AutoRenew { get; set; }
        public PaymentMethodTypes PaymentMethod { get; set; }
    }
    public class AutoTopupInfo
    {
        public string Currency { get; set; }
        public float MaxSpendLimit { get; set; }
        public float TopupAmount { get; set; }
        public float ThresholdAmount { get; set; }
    }
    public class TopupInfo
    {
        public string TransactionId { get; set; }
        public string TopupAmount { get; set; }
        public string Msisdn { get; set; }
        public string Currency { get; set; }
        public string Origination { get; set; }
        public bool AutoTopup { get; set; }
        public PaymentMethodTypes PaymentMethod { get; set; }
    }
}
