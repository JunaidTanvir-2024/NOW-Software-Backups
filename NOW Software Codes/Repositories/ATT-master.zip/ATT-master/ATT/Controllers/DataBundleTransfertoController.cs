﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ATT.Infrastructure.BLL.TransferTo;
using ATT.Infrastructure.DAL;
using ATT.Models.Contracts;
using ATT.Models.Contracts.TransferTo.Request;
using ATT.Models.Contracts.TransferTo.Response;
using ATT.Models.Database;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace ATT.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class DataBundleTransfertoController : ControllerBase
    {
   
        private ILogger loggerAPIAccess;
        private IDataBundlesDb_DL appDB;
        private ITransfertoAutomation_BL transfertoAutomation;
        private ITransfertoPost_BL transferToPost;
        private ITransfertoAuth_BL TransferToAuth;

        public DataBundleTransfertoController(ILogger appLoggers, IDataBundlesDb_DL appDB, ITransfertoAutomation_BL transfertoAutomation, ITransfertoPost_BL post, ITransfertoAuth_BL transferToAuth)
        {
            loggerAPIAccess = appLoggers;
            this.appDB = appDB;
            this.transfertoAutomation = transfertoAutomation;
            transferToPost = post;
            TransferToAuth = transferToAuth;
        }


        [HttpGet]
        [Route("transferToGetDataBundlesOperatorProductsMSISDN")]
        public async Task<IActionResult> transferToGetDataBundlesOperatorProductsMSISDN(int nsid, string destinationMSISDN, string account)
        {
            ServiceProvider serviceProviderRecord = await appDB.GetDataBundleServiceProviderRecord(nsid, destinationMSISDN);
            if (serviceProviderRecord != null)
            {
                var result = await transfertoAutomation.transferToGetDataBundlesOperatorProductsMSISDN(destinationMSISDN, account, serviceProviderRecord.OriginDestinationId);
                return Ok(result);
            }
            else
            {
                loggerAPIAccess.Debug($"  \"GET /transferToGetDataBundlesOperatorProductsMSISDN\"  Failed  Source:ATT API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}  NSID--{nsid}     Reason=Service Not Found ");
                var result2 = new { errorCode = 2, status = "Failure", message = "Service Not Found For this  MSISDN" };
                return Ok(result2);
            }

        }

        [HttpPost]
        [Route("transfertoExecuteDataBundleTransaction")]
        public async Task<IActionResult> transfertoExecuteDataBundleTransaction(TransfertoTranscationDataBundleRequest data)
        {
            if (ModelState.IsValid)
            {
                DataBundleAPIAccess guidReferneceRecord = null;
                try
                {
                    // First verify and get databundle access details from database and comapare with request if matched then do excution

                    guidReferneceRecord = await appDB.getDataBundleAccessRecord(data.nowtelTransactionReference, data.productValue, data.productType);
                    

                    if (guidReferneceRecord == null)
                    {
                        loggerAPIAccess.Debug($"  \"GET /transfertoTranscationDataBundleRequest\"  Failed   Source:General    Pasameters:     nowtelTransactionReference-{data.nowtelTransactionReference}     productValue-{data.productValue}       Message:nowtelTransactionReference transaction reference could not be found in database");
                        var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                        return Ok(result);
                    }
                    else
                    {

                        if (guidReferneceRecord.ProductApiType == "GS")
                        {
                            string[] DataBundleCredentials = TransferToAuth.GetDataBundlesCredentials(guidReferneceRecord.Account);

                            TransfertoTranscationDataBundleGSRequest transcationGSDataBundleRequest = new TransfertoTranscationDataBundleGSRequest();

                            transcationGSDataBundleRequest.currency = guidReferneceRecord.Account;
                            transcationGSDataBundleRequest.external_id = guidReferneceRecord.NowtelTransactionReference;
                            transcationGSDataBundleRequest.account_number = guidReferneceRecord.ToMsisdn;
                            transcationGSDataBundleRequest.product_id = guidReferneceRecord.ProductId.ToString();


                            transcationGSDataBundleRequest.sender_sms_notification = data.sender_sms_notification;
                            transcationGSDataBundleRequest.sender_sms_text = data.sender_sms_text;
                            transcationGSDataBundleRequest.sender = data.sender;

                            transcationGSDataBundleRequest.recipient_sms_notification = data.recipient_sms_notification;
                            transcationGSDataBundleRequest.recipient_sms_text = data.recipient_sms_text;
                            transcationGSDataBundleRequest.recipient = data.recipient;

                            var execGSTransactionResponse = await transferToPost.transfertoDataBundleTransaction(transcationGSDataBundleRequest);


                            TransfertoTranscationDataBundleReponse response = new TransfertoTranscationDataBundleReponse();
                            response.amount = guidReferneceRecord.CustomerChargePrice;
                            response.currency = guidReferneceRecord.Account;
                            response.reference = execGSTransactionResponse.Result.transaction_id;


                            if (execGSTransactionResponse.Result.status == "0" && execGSTransactionResponse.Result.errors == null) // transcation succesful
                            {

                                //Successful transaction GS
                                try
                                {
                                    bool dbresult = await appDB.InsertDataBundleTransaction(

                                        DateTime.Now.ToString(),
                                        DataBundleCredentials[0],
                                        decimal.Parse(guidReferneceRecord.CustomerChargePrice),         // Customer Charge Value
                                        decimal.Parse(execGSTransactionResponse.Result.wholesale_price.ToString()),  // whole sale  Charge Value
                                        execGSTransactionResponse.Result.account_currency,
                                        execGSTransactionResponse.Result.local_currency,
                                        execGSTransactionResponse.Result.country,
                                        "Success",
                                         execGSTransactionResponse.Result.status_message,
                                        execGSTransactionResponse.Result.operator_id,
                                        execGSTransactionResponse.Result.product_id,
                                        execGSTransactionResponse.Result.product,
                                        execGSTransactionResponse.Result.product_desc,
                                        "GS",
                                        execGSTransactionResponse.Result.@operator,
                                        execGSTransactionResponse.Result.external_id,
                                        execGSTransactionResponse.Result.transaction_id,
                                        data.sender_number,
                                        execGSTransactionResponse.Result.account_number,
                                        2,
                                        "your transaction is successful."

                                        );
                                }
                                catch (Exception ex)
                                {
                                    loggerAPIAccess.Debug($"  \"POST /execServiceTransactionResponse\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                                }

                                var resultPayload = new { data = response };
                                var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
                                return Ok(result);
                            }
                            else
                            {
                                string errormessage = execGSTransactionResponse.Result.errors.FirstOrDefault().message;

                                //Failed transaction GS
                                try
                                {

                                    bool dbresult = await appDB.InsertDataBundleTransaction(

                                          DateTime.Now.ToString(),
                                          DataBundleCredentials[0],
                                          decimal.Parse(guidReferneceRecord.CustomerChargePrice),         // Customer Charge Value
                                          decimal.Parse(guidReferneceRecord.WholeSalePrice.ToString()),  // Actual Charge Value
                                          guidReferneceRecord.Clientccy,
                                          guidReferneceRecord.Receiverccy,
                                          "",// Country
                                          "Failed",
                                          errormessage,
                                          data.operator_id.ToString(),
                                          guidReferneceRecord.ProductId.ToString(), // product id -1
                                          guidReferneceRecord.Product,
                                          guidReferneceRecord.ProductDesc,
                                          guidReferneceRecord.ProductApiType,
                                          "",
                                          guidReferneceRecord.NowtelTransactionReference,
                                          "",
                                          data.sender_number,
                                          guidReferneceRecord.ToMsisdn,
                                          2,
                                          "your transaction is not successful"

                                          );


                                }
                                catch (Exception ex)
                                {
                                    loggerAPIAccess.Debug($"  \"POST /execServiceTransactionResponse\"  Database error occured while registering the successful databundle transaction    Exception {ex.ToString()} ");

                                    bool dbresult = await appDB.InsertDataBundleTransaction(

                                           DateTime.Now.ToString(),
                                           DataBundleCredentials[0],
                                           decimal.Parse(guidReferneceRecord.CustomerChargePrice),         // Customer Charge Value
                                           decimal.Parse(guidReferneceRecord.WholeSalePrice.ToString()),  // Actual Charge Value
                                           guidReferneceRecord.Clientccy,
                                           guidReferneceRecord.Receiverccy,
                                           "",// Country
                                           "FailureException",
                                           ex.Message,
                                           data.operator_id.ToString(),
                                           guidReferneceRecord.ProductId.ToString(), // product id -1
                                           guidReferneceRecord.Product,
                                           guidReferneceRecord.ProductDesc,
                                           guidReferneceRecord.ProductApiType,
                                           "",
                                           guidReferneceRecord.NowtelTransactionReference,
                                           "",
                                           data.sender_number,
                                           guidReferneceRecord.ToMsisdn,
                                           2,
                                           "your transaction is not successful"

                                           );


                                }
                                //var resultPayload = new { message = errormessage };
                                var result = new { errorCode = 2, status = "Failed", message = errormessage };
                                return Ok(result);
                            }

                        }

                        else if (guidReferneceRecord.ProductApiType == "ATT")
                        {

                            string[] AttCredentials = TransferToAuth.GetAttCredentials(guidReferneceRecord.Account);
                            long RequestKey = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
                            GenericApiResponse<transfertoExecuteTransaction> execATTransactionResponse = await transferToPost.transfertoTransaction("", guidReferneceRecord.ToMsisdn, data.productValue, guidReferneceRecord.Account, data.operator_id.ToString(), "messageToRecipient", RequestKey);

                            if (execATTransactionResponse.Status == 0) // successful transcation
                            {

                                //ATT Successful transaction
                                try
                                {
                                    bool dbresult = await appDB.InsertDataBundleTransaction(

                                        DateTime.Now.ToString(),
                                        AttCredentials[0],
                                        decimal.Parse(guidReferneceRecord.CustomerChargePrice),         // Customer Charge Value
                                        decimal.Parse(execATTransactionResponse.Result.wholesale_price.ToString()),  // Actual Charge Value
                                        execATTransactionResponse.Result.originating_currency,
                                        execATTransactionResponse.Result.destination_currency,
                                        execATTransactionResponse.Result.country,
                                        "Success",
                                        "",// error message
                                        execATTransactionResponse.Result.operatorid,
                                        "-1", // product id -1
                                        execATTransactionResponse.Result.product_requested,
                                         guidReferneceRecord.ProductDesc,
                                        "ATT",
                                        execATTransactionResponse.Result.@operator,
                                        guidReferneceRecord.NowtelTransactionReference,
                                        execATTransactionResponse.Result.transactionid,
                                        data.sender_number,
                                        execATTransactionResponse.Result.destination_msisdn,
                                        2,
                                        "your transaction is successful."

                                        );

                                    TransfertoTranscationDataBundleReponse response = new TransfertoTranscationDataBundleReponse();
                                    response.amount = guidReferneceRecord.CustomerChargePrice;
                                    response.currency = execATTransactionResponse.Result.originating_currency;
                                    response.reference = execATTransactionResponse.Result.transactionid;



                                    var resultPayload = new { data = response };

                                    var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
                                    return Ok(result);
                                }
                                catch (Exception ex)
                                {
                                    loggerAPIAccess.Debug($"  \"POST /execATTransactionResponse\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                                    var result = new { errorCode = 2, status = "Failure", message = "Database error occured while registering the successful transaction " };
                                    return Ok(result);
                                }
                            }

                            else
                            {

                                if (execATTransactionResponse.Result != null)
                                {
                                    bool dbresult = await appDB.InsertDataBundleTransaction(

                                            DateTime.Now.ToString(),
                                             AttCredentials[0],
                                            decimal.Parse(guidReferneceRecord.CustomerChargePrice),         // Customer Charge Value
                                            decimal.Parse(guidReferneceRecord.WholeSalePrice.ToString()),  // Actual Charge Value
                                            guidReferneceRecord.Clientccy,
                                            guidReferneceRecord.Receiverccy,
                                            execATTransactionResponse.Result.country,
                                            "Failed",
                                            execATTransactionResponse.Result.error_txt,
                                            execATTransactionResponse.Result.operatorid,
                                            "-1", // product id -1
                                            execATTransactionResponse.Result.product_requested,
                                             guidReferneceRecord.ProductDesc,
                                            "ATT",
                                            execATTransactionResponse.Result.@operator,
                                            guidReferneceRecord.NowtelTransactionReference,
                                            execATTransactionResponse.Result.transactionid,
                                            data.sender_number,
                                            execATTransactionResponse.Result.destination_msisdn,
                                            2,
                                            "your transaction is not successful"

                                            );

                                }
                                else
                                {
                                    bool dbresult = await appDB.InsertDataBundleTransaction(

                                            DateTime.Now.ToString(),
                                             AttCredentials[0],
                                            decimal.Parse(guidReferneceRecord.CustomerChargePrice),         // Customer Charge Value
                                            decimal.Parse(guidReferneceRecord.WholeSalePrice.ToString()),  // Actual Charge Value
                                            guidReferneceRecord.Clientccy,
                                            guidReferneceRecord.Receiverccy,
                                            "",// Country
                                            "Failure",
                                            execATTransactionResponse.Message,
                                            data.operator_id.ToString(),
                                            guidReferneceRecord.ProductId.ToString(), // product id -1
                                            guidReferneceRecord.Product,
                                            guidReferneceRecord.ProductDesc,
                                            guidReferneceRecord.ProductApiType,
                                            "",
                                            guidReferneceRecord.NowtelTransactionReference,
                                            "",
                                            data.sender_number,
                                            guidReferneceRecord.ToMsisdn,
                                            2,
                                            "your transaction is not successful"

                                            );

                                }
                                var resultPayload = new { data = execATTransactionResponse };
                                var result = new { errorCode = 2, status = "Failed", payLoad = resultPayload };
                                return Ok(result);
                            }

                        }
                        else
                        {
                            var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference ProductApiType could not be found in database" };
                            return Ok(result);
                        }

                    }

                }
                catch (Exception ex)
                {
                    loggerAPIAccess.Debug($"  \"GET /transfertoExecuteServicesTransaction \"  Failed  Source:General  Parameters-  nowtelTransactionReference:{data.nowtelTransactionReference} , productType:{data.productType}  , productValue:{data.productValue}  ,   Message:{ex.ToString()}");



                    bool dbresult = await appDB.InsertDataBundleTransaction(

                                        DateTime.Now.ToString(),
                                        guidReferneceRecord.Account.ToString(),
                                        decimal.Parse(guidReferneceRecord.CustomerChargePrice),         // Customer Charge Value
                                        decimal.Parse(guidReferneceRecord.WholeSalePrice.ToString()),  // Actual Charge Value
                                        guidReferneceRecord.Clientccy,
                                        guidReferneceRecord.Receiverccy,
                                        "",// Country
                                        "FailureException",
                                        ex.Message,
                                        data.operator_id.ToString(),
                                        guidReferneceRecord.ProductId.ToString(), // product id -1
                                        guidReferneceRecord.Product,
                                        guidReferneceRecord.ProductDesc,
                                        guidReferneceRecord.ProductApiType,
                                        "",
                                        guidReferneceRecord.NowtelTransactionReference,
                                        "",
                                        data.sender_number,
                                        guidReferneceRecord.ToMsisdn,
                                        2,
                                        "your transaction is not successful"

                                        );







                    var resultPayload = new { reason = "General API Access Error." };
                    var errorResult = new { errorCode = 1, status = "FailureException", payLoad = resultPayload };
                    return Ok(errorResult);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }


        [HttpGet]
        [Route("transfertoDataBundleTransactionByTransactionid")]
        public async Task<IActionResult> transfertoGetDataBundleTransactionByTransactionid(string currency, int transactionid)
        {
            try
            {
                GenericApiResponse<TransfertoTranscationDataBundleGSReponse> transactiondetails = await transferToPost.transfertoGetDataBundleTransactionByTransactionid(currency, transactionid);
                var resultPayload = new { data = transactiondetails };
                var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
                return Ok(result);
            }
            catch (Exception ex)
            {
                loggerAPIAccess.Debug($"  \"GET /transfertoDataBundleTransactionByTransactionid \"  Failed  Source:General  Parameters-  currency:{currency} transactionid:{transactionid}    Message:{ex.ToString()}");
                var resultPayload = new { reason = "General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 2, status = "Failure", payLoad = resultPayload };
                return Ok(errorResult);
            }
        }


        // Data Bundle Services 


        [HttpGet]
        [Route("transfertoGetServiceList")]
        public async Task<IActionResult> transfertoServiceList(string currency)
        {
            try
            {
                GenericApiResponse<TransfertoServciesList> servicelist = await transferToPost.transfertoServiceList(currency);
                var resultPayload = new { data = servicelist.Result.services };
                var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
                return Ok(result);
            }
            catch (Exception ex)
            {
                loggerAPIAccess.Debug($"  \"GET /transferToGoodsServicesList\"  Failed  Source:General  Parameters-  currency:{currency}    Message:{ex.ToString()}");
                var resultPayload = new { reason = "General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 2, status = "Failure", payLoad = resultPayload };
                return Ok(errorResult);
            }
        }


        [HttpGet]
        [Route("transfertoGetCountryListByService")]
        public async Task<IActionResult> transfertoCountryListByService(string currency, int serviceId)
        {

            try
            {
                GenericApiResponse<TransferToCountriesListByServices> servicelist = await transferToPost.transfertoCountryListByService(currency, serviceId);

                var resultPayload = new { data = servicelist.Result.countries };
                var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
                return Ok(result);
            }
            catch (Exception ex)
            {
                loggerAPIAccess.Debug($"  \"GET /transferToCountryListBy Services \"  Failed  Source:General  Parameters-  currency:{currency} serviceId:{serviceId}    Message:{ex.ToString()}");
                var resultPayload = new { reason = "General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 2, status = "Failure", payLoad = resultPayload };
                return Ok(errorResult);
            }
        }


        [HttpGet]
        [Route("transfertoGetOperatorListByService")]
        public async Task<IActionResult> transfertoOperatorListByService(string currency, int serviceId)
        {

            try
            {
                GenericApiResponse<TransfertoOperatorListByServices> servicelist = await transferToPost.transfertoOperatorListByService(currency, serviceId);

                var resultPayload = new { data = servicelist.Result.operators };
                var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
                return Ok(result);
            }
            catch (Exception ex)
            {
                loggerAPIAccess.Debug($"  \"GET /transferToOperatorListBy Services \"  Failed  Source:General  Parameters-  currency:{currency} serviceId:{serviceId}    Message:{ex.ToString()}");
                var resultPayload = new { reason = ex.Message + " -  General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 2, status = "Failure", payLoad = resultPayload };
                return Ok(errorResult);
            }
        }


        [HttpGet]
        [Route("transfertoGetDataBundleProductList")]
        public async Task<IActionResult> transfertoDataBundleProductList(string currency, int serviceId, int operatorId, int countryId)
        {
            try
            {
                GenericApiResponse<TransfertoDataBundleProductList> servicelist = await transferToPost.transfertoDataBundleProductList(currency, serviceId, operatorId, countryId);

                var resultPayload = new { data = servicelist.Result };
                var result = new { errorCode = 0, status = "Success", payLoad = resultPayload };
                return Ok(result);
            }
            catch (Exception ex)
            {
                loggerAPIAccess.Debug($"  \"GET /transfertoDataBundleProductList \"  Failed  Source:General  Parameters-  currency:{currency} serviceId:{serviceId} operatorId:{countryId} serviceId:{countryId}    Message:{ex.ToString()}");
                var resultPayload = new { reason = ex.Message + "- General API Access Error. Check log for details" };
                var errorResult = new { errorCode = 2, status = "Failure", payLoad = resultPayload };
                return Ok(errorResult);
            }
        }


    }

}