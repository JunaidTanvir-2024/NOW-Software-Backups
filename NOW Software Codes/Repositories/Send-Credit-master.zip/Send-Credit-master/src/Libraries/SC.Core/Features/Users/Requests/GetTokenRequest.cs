﻿namespace SC.Core.Features.Users.Requests;
public class GetTokenRequest : IRequest<IResultWrapper>
{
    public ClaimDto UserInfo { get; set; } = default!;
}

public class GetTokenRequestValidator : AbstractValidator<GetTokenRequest>
{
    public GetTokenRequestValidator()
    {
        RuleFor(x => x.UserInfo).NotNull();
    }
}

