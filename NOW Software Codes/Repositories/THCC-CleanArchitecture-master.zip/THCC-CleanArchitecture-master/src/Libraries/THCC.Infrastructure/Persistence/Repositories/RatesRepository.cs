﻿using System.Data;

using Dapper;

using Microsoft.Extensions.Configuration;

using Serilog;


using THCC.Application.Interfaces.Repositories;
using THCC.Domain.Constants;
using THCC.Domain.Entities;
using THCC.Infrastructure.Persistence.DapperConfigurations;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Infrastructure.Persistence.Repositories
{
    internal class RatesRepository : IRatesRepository
    {
        #region Fields

        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;

        #endregion

        #region Ctors
        public RatesRepository(
            IConfiguration configuration,
            ILogger logger)
        {
            _configuration = configuration;
            _logger = logger;
        }
        #endregion

        #region Methods
        public async Task<IEnumerable<Rate>> GetRates()
        {
            try
            {
                var result = await DapperWrapper.QueryAsync<Rate>(StoredProcedures.GetRates, null, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ThccConstants.ConnectionStrings.DefaultConnection));
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error(exception: ex, "RatesRepository: GetRates=> " + ex.Message);
                return null!;
            }
        }

        #endregion
    }
}
