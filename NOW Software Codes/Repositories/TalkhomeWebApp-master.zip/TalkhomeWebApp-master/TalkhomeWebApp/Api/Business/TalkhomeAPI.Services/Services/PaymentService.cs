﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Models.Pay360ApiContracts;
using TalkhomeAPI.Models.PaypalApiContracts;
using TalkhomeAPI.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Models.Configurations;
using Microsoft.Extensions.Options;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using Serilog;
using System.Linq;
using TalkhomeAPI.Infrastructure.Common.Services.Implementations;
using PhoneNumbers;
using TalkhomeAPI.Infrastructure.Common.Models;
using System.IO;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Airship;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using System.Net.Mail;
using System.Net;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Utilities;
using MimeKit;
using TalkhomeAPI.Infrastructure.Common.Services.Models.AppsFlyer;

namespace TalkhomeAPI.Services.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly IPay360Service _pay360Service;
        private readonly IPayPalService _payPalService;
        private readonly IAccountRepository _accountRepository;
        private readonly ILogger _logger;
        private readonly IBundleRepository _bundleRepository;
        private readonly IAppsFlyerService _appsFlyerService;
        private readonly IAirShipService _airShipService;
        private readonly IFaceBookService _faceBookService;
        private readonly IPaymentFullfillmentRepository _PaymentFullfillment;
        private readonly IPromotionService _promotionService;
        private readonly IHelperService _helperService;
        private readonly IPhoneNumberService _phoneNumberService;
        private readonly IAutoTopupRepository _autoTopupRepo;
        private readonly PayPalConfig _payPalConfig;
        private readonly Pay360Config _pay360Config;
        private readonly SmtpConfig _SmtpConfig;

        public PaymentService(
            IPay360Service pay360Service,
            IPayPalService payPalService,
            IAccountRepository accountRepository,
            ILogger logger,
            IBundleRepository bundleRepository,
            IAppsFlyerService appsFlyerService,
            IAirShipService airShipService,
            IFaceBookService faceBookService,
            IPaymentFullfillmentRepository IPaymentFullfillment,
            IPromotionService promotionService,
            IOptions<PayPalConfig> paypalConfig,
            IOptions<Pay360Config> pay360Config,
            IOptions<SmtpConfig> SmtpConfig,
            IHelperService helperService,
            IPhoneNumberService phoneNumberService,
            IAutoTopupRepository autoTopupRepo)
        {
            _pay360Service = pay360Service;
            _payPalService = payPalService;
            _payPalConfig = paypalConfig.Value;
            _pay360Config = pay360Config.Value;
            _accountRepository = accountRepository;
            _logger = logger;
            _bundleRepository = bundleRepository;
            _appsFlyerService = appsFlyerService;
            _airShipService = airShipService;
            _faceBookService = faceBookService;
            _PaymentFullfillment = IPaymentFullfillment;
            _promotionService = promotionService;
            _helperService = helperService;
            _phoneNumberService = phoneNumberService;
            this._autoTopupRepo = autoTopupRepo;
            _SmtpConfig = SmtpConfig.Value;
        }

        public async Task<GenericApiResponse<VoucherRechargeResponseModel>> VoucherRecharge(VoucherRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<VoucherRechargeResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;
            var CountryCode = _phoneNumberService.GetCountryCode(msisdn);

            var result = await _accountRepository.VoucherRecharge(model.Pin, account);

            if (result == null)
            {
                await HandleTopupEvents(false, msisdn, false, false, null, 0, CountryCode);

                return GenericApiResponse<VoucherRechargeResponseModel>.Failure("Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (result.error_code == 0)
            {

                #region Events
                try
                {
                    var isFirstTopup = await _accountRepository.IsFirstTopUp(msisdn);
                    var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());
                    var topupAmount = result.card_credit / 100;
                    await HandleTopupEvents(false, msisdn, false, true, null, Convert.ToDecimal(topupAmount), CountryCode);
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: PaymentService, Method: VoucherRecharge-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }
                #endregion

                return GenericApiResponse<VoucherRechargeResponseModel>.Success(new VoucherRechargeResponseModel()
                {
                    card_credit = result.card_credit > 0 ? result.card_credit / 100 : result.card_credit,
                    voucher_currency = result.voucher_currency,
                    voucher_id = result.voucher_id,
                    customerMsisdn = msisdn,
                    origin = _phoneNumberService.GetCountryCode(msisdn)
                }, "voucher added successfully");
            }
            else
            {
                await HandleTopupEvents(false, msisdn, false, false, null, 0, CountryCode);
                return GenericApiResponse<VoucherRechargeResponseModel>.Failure(
                                                result.error_msg, ApiStatusCodes.VoucherRechargeFailed);
            }
        }
        public async Task<GenericApiResponse<Pay360CardsResponse>> Pay360GetCards(string msisdn)
        {
            var response = await _pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
            {
                customerUniqueRef = msisdn,
                productCode = ProductCode.THA.ToString()
            });

            if (response != null)
            {
                if (response.errorCode > 0)
                {
                    if (response.errorCode == (int)Pay360StatusCodes.CustomerNotExist) //Customer not Exist
                    {
                        return GenericApiResponse<Pay360CardsResponse>.Failure(
                                            "Customer Not Found", ApiStatusCodes.CustomerNotExist);
                    }
                }
                else
                {
                    if (response.payload != null)
                    {
                        return response;
                    }
                }
            }

            return GenericApiResponse<Pay360CardsResponse>.Failure(
                                  "Something went wrong on server", ApiStatusCodes.InternalServerError);
        }
        public async Task<GenericApiResponse<AutoTopupDetail>> GetAutoTopUp(string msisdn)
        {
            var response = await _autoTopupRepo.Get(msisdn);

            if (response == null)
                return GenericApiResponse<AutoTopupDetail>.Failure(
                            "Somehting went wrong on server", ApiStatusCodes.InternalServerError);
            response.MaxSpendLimit = _pay360Config.AutoTopupMaxSpendLimit;
            return GenericApiResponse<AutoTopupDetail>.Success(response, "Success");
        }
        public async Task<GenericApiResponse<SetAutoTopupWithCardResponseModel>> SetAutoTopUpWithCard(SetAutoTopUpWithCardRequestModel model, string msisdn, string currency)
        {

            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            var accountUser = await _accountRepository.GetUserByPhoneNumber(msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<SetAutoTopupWithCardResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            var origination = _phoneNumberService.GetCountryCode(msisdn);

            float ChargeAmount = _pay360Config.TestPaymentAmount;

            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };

            Pay360PaymentRequest paymentrequest = null;
            Pay360PaymentType paymentType = Pay360PaymentType.New;
            if (model.NewCardInfo is NewCardInfo)
            {
                paymentType = Pay360PaymentType.New;
                paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
                {
                    PromotionsDetails = promResponse,
                    CustomerMsisdn = msisdn,
                    Amount = ChargeAmount,
                    CheckoutPaymentType = CheckOutTypes.TopUp,
                    BundleId = null,
                    IpAddress = model.IpAddress,
                    CustomerEmail = accountUser?.email,
                    Currency = currency,
                    Pay360PaymentType = Pay360PaymentType.New,
                    CustomerAddressData = new AddressData()
                    {
                        AddressL1 = model.AddressInfo.AddressL1,
                        AddressL2 = model.AddressInfo.AddressL2,
                        AddressL3 = model.AddressInfo.AddressL3,
                        AddressL4 = model.AddressInfo.AddressL4,
                        PostCode = model.AddressInfo.PostCode,
                        City = model.AddressInfo.City,
                        Region = model.AddressInfo.Region,
                        CountryCode = model.AddressInfo.CountryCode
                    },
                    CustomerCardData = new CardData()
                    {
                        CardNumber = model.NewCardInfo.CardNumber,
                        NameOnCard = model.NewCardInfo.NameOnCard,
                        SecurityCode = model.NewCardInfo.SecurityCode,
                        ExpiryMonth = model.NewCardInfo.ExpiryMonth,
                        ExpiryYear = model.NewCardInfo.ExpiryYear
                    },
                    ShouldSaveCard = true,
                    accountNumber = account,
                    CustomerUniqueRef = msisdn
                });
                paymentrequest.Pay360PaymentRequestNew.recurring = true;
            }
            else
            {
                paymentType = Pay360PaymentType.Token;
                paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData
                {
                    CustomerMsisdn = msisdn,
                    PromotionsDetails = new PromotionPaymentDetails
                    {
                        ChargeAmount = ChargeAmount,
                    },
                    Amount = ChargeAmount,
                    CheckoutPaymentType = CheckOutTypes.TopUp,
                    BundleId = null,
                    IpAddress = model.IpAddress,
                    CustomerEmail = accountUser?.email,
                    Currency = currency,
                    Pay360PaymentType = Pay360PaymentType.Token,
                    CardToken = model.ExistingCardInfo.cardToken,
                    SecurityCode = model.ExistingCardInfo.securityCode,
                    accountNumber = account,
                    CustomerUniqueRef = msisdn
                });
                paymentrequest.Pay360PaymentRequestToken.recurring = true;
            }
            var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, paymentType);
            int paymentTransactionId = default;
            if (model.NewCardInfo is NewCardInfo)
            {
                paymentTransactionId = await _PaymentFullfillment.InsertTransactionPayment(
                        paymentrequest.Pay360PaymentRequestNew.basket,
                        paymentrequest.Pay360PaymentRequestNew.transactionCurrency,
                        paymentrequest.Pay360PaymentRequestNew.customerEmail,
                        paymentrequest.Pay360PaymentRequestNew.productCode,
                        paymentResponse?.payload?.transactionId,
                        paymentrequest.Pay360PaymentRequestNew.customerMsisdn,
                        Fullfillmenttype.Pay360,
                        0, false);
            }
            else
            {
                paymentTransactionId = await _PaymentFullfillment.InsertTransactionPayment(
                        paymentrequest.Pay360PaymentRequestToken.basket,
                        paymentrequest.Pay360PaymentRequestToken.transactionCurrency,
                        paymentrequest.Pay360PaymentRequestToken.customerEmail,
                        paymentrequest.Pay360PaymentRequestToken.productCode,
                        paymentResponse?.payload?.transactionId,
                        paymentrequest.Pay360PaymentRequestToken.customerMsisdn,
                        Fullfillmenttype.Pay360,
                        0, false);
            }

            var CountryCode = _phoneNumberService.GetCountryCode(msisdn);
            var responseModel = new SetAutoTopupWithCardResponseModel();
            if (paymentResponse == null)
            {
                await HandleTopupEvents(true, msisdn, true, false, true, 0, CountryCode);


                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, null, "Payment service not responding");
                return GenericApiResponse<SetAutoTopupWithCardResponseModel>.Failure(responseModel, "Payment service not responding", ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                await HandleTopupEvents(true, msisdn, true, false, true, 0, CountryCode);



                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, paymentResponse?.payload?.transactionId, paymentResponse.message);
                _logger.Error($"Class: PaymentService, Method: NewCustomerPayment - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<SetAutoTopupWithCardResponseModel>.Failure(responseModel,
                                "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<SetAutoTopupWithCardResponseModel>.Failure(responseModel,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<SetAutoTopupWithCardResponseModel>.Failure(responseModel,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            if (paymentResponse.payload.outcome.reasonCode == "U100") //3d Secure Scenario
            {
                //Send Response
                return GenericApiResponse<SetAutoTopupWithCardResponseModel>.Failure(
                                                new SetAutoTopupWithCardResponseModel()
                                                {
                                                    threeDSecureData = new ThreeDSecureData()
                                                    {
                                                        pareq = paymentResponse.payload.clientRedirect.pareq,
                                                        redirectUrl = paymentResponse.payload.clientRedirect.url,
                                                        transactionId = paymentResponse.payload.transactionId,
                                                        clientRedirectType = paymentResponse.payload.clientRedirect.type,
                                                        threeDSServerTransId = paymentResponse.payload.clientRedirect.threeDSServerTransId,
                                                        returnUrl = _pay360Config.TopUpSettings.SetAutoTopupWithCardReturnUrl +
                                                        "type=" + (int)CheckOutTypes.TopUp +
                                                        "&customerEmail=" + accountUser?.email +
                                                        "&customerMsisdn=" + msisdn +
                                                        "&currency=" + currency +
                                                        "&ShouldSaveCard=" + true +
                                                        "&IsAutoTopUp=" + true +
                                                        "&PTId=" + paymentTransactionId +
                                                        "&TopupAmount=" + model.Amount +
                                                        "&ThresholdAmount=" + model.ThresholdBalanceAmount +
                                                        "&clientRedirectType=" + paymentResponse.payload.clientRedirect.type
                                                    }
                                                }, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

            }
            else if (paymentResponse.payload.outcome.reasonCode == "S100")//success
            {

                //Full filment
                if (_pay360Config.IsDirectFullfilment == false)
                {
                    try
                    {
                        await Pay360CardPaymentFullfillment(paymentResponse, msisdn, accountUser?.email,true);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(
                                $"Class: Paymentservices, " +
                                $"Method: NewCustomerPayment - PaymentFullfillment, " +
                                $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                                $"ErrorMessage: {ex.Message}");
                    }
                }
                var paymentRefundResponse = await _pay360Service.RefundFullPayment(new RefundFullPaymentRequestModel
                {
                    transactionId=paymentResponse.payload.transactionId
                });
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, true, paymentResponse.payload.transactionId,null, paymentRefundResponse.errorCode==0);

                await SetAutoTopUpByCard(msisdn, currency,model.Amount,model.ThresholdBalanceAmount, paymentResponse.payload);

                return GenericApiResponse<SetAutoTopupWithCardResponseModel>.Success(new SetAutoTopupWithCardResponseModel()
                {
                    AutoTopupInfo = new AutoTopupInfo()
                    {
                        TopupAmount = model.Amount,
                        Currency = currency,
                        ThresholdAmount = model.ThresholdBalanceAmount,
                        MaxSpendLimit = _pay360Config.AutoTopupMaxSpendLimit
                    }
                }, "Top-Up Successfull");
            }

            return GenericApiResponse<SetAutoTopupWithCardResponseModel>.Failure(responseModel,
                                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
        }
        public async Task<GenericApiResponse<SetAutoRenewalWithCardResponseModel>> SetAutoRenewalWithCard(SetAutoRenewalWithCardRequestModel model, string msisdn, string currency)
        {

            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            var accountUser = await _accountRepository.GetUserByPhoneNumber(msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<SetAutoRenewalWithCardResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            var origination = _phoneNumberService.GetCountryCode(msisdn);
            

            float ChargeAmount = _pay360Config.TestPaymentAmount;

            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };

            Pay360PaymentRequest paymentrequest = null;
            Pay360PaymentType paymentType = Pay360PaymentType.New;
            if (model.NewCardInfo is NewCardInfo)
            {
                paymentType = Pay360PaymentType.New;
                paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
                {
                    PromotionsDetails = promResponse,
                    CustomerMsisdn = msisdn,
                    Amount = ChargeAmount,
                    CheckoutPaymentType = CheckOutTypes.Bundle,
                    BundleId = model.BundleId,
                    IpAddress = model.IpAddress,
                    CustomerEmail = accountUser?.email,
                    Currency = currency,
                    Pay360PaymentType = Pay360PaymentType.New,
                    CustomerAddressData = new AddressData()
                    {
                        AddressL1 = model.AddressInfo.AddressL1,
                        AddressL2 = model.AddressInfo.AddressL2,
                        AddressL3 = model.AddressInfo.AddressL3,
                        AddressL4 = model.AddressInfo.AddressL4,
                        PostCode = model.AddressInfo.PostCode,
                        City = model.AddressInfo.City,
                        Region = model.AddressInfo.Region,
                        CountryCode = model.AddressInfo.CountryCode
                    },
                    CustomerCardData = new CardData()
                    {
                        CardNumber = model.NewCardInfo.CardNumber,
                        NameOnCard = model.NewCardInfo.NameOnCard,
                        SecurityCode = model.NewCardInfo.SecurityCode,
                        ExpiryMonth = model.NewCardInfo.ExpiryMonth,
                        ExpiryYear = model.NewCardInfo.ExpiryYear
                    },
                    ShouldSaveCard = true,
                    accountNumber = account,
                    CustomerUniqueRef = msisdn
                });
                paymentrequest.Pay360PaymentRequestNew.recurring = true;
            }
            else
            {
                paymentType = Pay360PaymentType.Token;
                paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData
                {
                    CustomerMsisdn = msisdn,
                    PromotionsDetails = new PromotionPaymentDetails
                    {
                        ChargeAmount = ChargeAmount,
                    },
                    Amount = ChargeAmount,
                    CheckoutPaymentType = CheckOutTypes.Bundle,
                    BundleId = model.BundleId,
                    IpAddress = model.IpAddress,
                    CustomerEmail = accountUser?.email,
                    Currency = currency,
                    Pay360PaymentType = Pay360PaymentType.Token,
                    CardToken = model.ExistingCardInfo.cardToken,
                    SecurityCode = model.ExistingCardInfo.securityCode,
                    accountNumber = account,
                    CustomerUniqueRef = msisdn
                });
                paymentrequest.Pay360PaymentRequestToken.recurring = true;
            }
            var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, paymentType);
            int paymentTransactionId = default;
            if (model.NewCardInfo is NewCardInfo)
            {
                paymentTransactionId = await _PaymentFullfillment.InsertTransactionPayment(
                        paymentrequest.Pay360PaymentRequestNew.basket,
                        paymentrequest.Pay360PaymentRequestNew.transactionCurrency,
                        paymentrequest.Pay360PaymentRequestNew.customerEmail,
                        paymentrequest.Pay360PaymentRequestNew.productCode,
                        paymentResponse?.payload?.transactionId,
                        paymentrequest.Pay360PaymentRequestNew.customerMsisdn,
                        Fullfillmenttype.Pay360,
                        0, false);
            }
            else
            {
                paymentTransactionId = await _PaymentFullfillment.InsertTransactionPayment(
                        paymentrequest.Pay360PaymentRequestToken.basket,
                        paymentrequest.Pay360PaymentRequestToken.transactionCurrency,
                        paymentrequest.Pay360PaymentRequestToken.customerEmail,
                        paymentrequest.Pay360PaymentRequestToken.productCode,
                        paymentResponse?.payload?.transactionId,
                        paymentrequest.Pay360PaymentRequestToken.customerMsisdn,
                        Fullfillmenttype.Pay360,
                        0, false);
            }

            var CountryCode = _phoneNumberService.GetCountryCode(msisdn);
            var responseModel = new SetAutoRenewalWithCardResponseModel();
            if (paymentResponse == null)
            {
                await HandleTopupEvents(true, msisdn, true, false, true, 0, CountryCode);


                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, null, "Payment service not responding");
                return GenericApiResponse<SetAutoRenewalWithCardResponseModel>.Failure(responseModel, "Payment service not responding", ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                await HandleTopupEvents(true, msisdn, true, false, true, 0, CountryCode);



                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, paymentResponse?.payload?.transactionId, paymentResponse.message);
                _logger.Error($"Class: PaymentService, Method: NewCustomerPayment - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<SetAutoRenewalWithCardResponseModel>.Failure(responseModel,
                                "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<SetAutoRenewalWithCardResponseModel>.Failure(responseModel,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<SetAutoRenewalWithCardResponseModel>.Failure(responseModel,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            if (paymentResponse.payload.outcome.reasonCode == "U100") //3d Secure Scenario
            {
                //Send Response
                return GenericApiResponse<SetAutoRenewalWithCardResponseModel>.Failure(
                                                new SetAutoRenewalWithCardResponseModel()
                                                {
                                                    threeDSecureData = new ThreeDSecureData()
                                                    {
                                                        pareq = paymentResponse.payload.clientRedirect.pareq,
                                                        redirectUrl = paymentResponse.payload.clientRedirect.url,
                                                        transactionId = paymentResponse.payload.transactionId,
                                                        clientRedirectType = paymentResponse.payload.clientRedirect.type,
                                                        threeDSServerTransId = paymentResponse.payload.clientRedirect.threeDSServerTransId,
                                                        returnUrl = _pay360Config.BundleSettings.SetAutoRenewalWithCardReturnUrl +
                                                        "type=" + (int)CheckOutTypes.Bundle +
                                                        "&customerEmail=" + accountUser?.email +
                                                        "&customerMsisdn=" + msisdn +
                                                        "&currency=" + currency +
                                                        "&BundleId="+model.BundleId+
                                                        "&PTId=" + paymentTransactionId +
                                                        "&clientRedirectType=" + paymentResponse.payload.clientRedirect.type
                                                    }
                                                }, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

            }
            else if (paymentResponse.payload.outcome.reasonCode == "S100")//success
            {

                //Full filment
                if (_pay360Config.IsDirectFullfilment == false)
                {
                    try
                    {
                        await Pay360CardPaymentFullfillment(paymentResponse, msisdn, accountUser?.email, true);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(
                                $"Class: Paymentservices, " +
                                $"Method: SetAutoRenewalWithCard - PaymentFullfillment, " +
                                $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                                $"ErrorMessage: {ex.Message}");
                    }
                }
                var paymentRefundResponse = await _pay360Service.RefundFullPayment(new RefundFullPaymentRequestModel
                {
                    transactionId=paymentResponse.payload.transactionId
                });
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, true, paymentResponse.payload.transactionId,null, paymentRefundResponse.errorCode==0);

                await _bundleRepository.SetBundleAutoRenewal(true, msisdn, account, model.BundleId, false, PaymentMethods.Card, paymentResponse.payload.maskedPan, paymentResponse.payload.transactionId, null);

                return GenericApiResponse<SetAutoRenewalWithCardResponseModel>.Success(new SetAutoRenewalWithCardResponseModel()
                {
                }, "Top-Up Successfull");
            }

            return GenericApiResponse<SetAutoRenewalWithCardResponseModel>.Failure(responseModel,
                                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
        }
        public async Task<GenericApiResponse<bool>> DisableAutoTopUp(string msisdn, string currency)
        {
            var autoToupSettings = await _autoTopupRepo.Get(msisdn);
            var response = await _autoTopupRepo.Set(new AutoTopupDetail
            {
                Status = false,
                Msisdn = msisdn,
                Currency = currency,
                Topup = autoToupSettings.Topup,
                ThresHold = autoToupSettings.ThresHold,
                CardInitialTransactionId = null,
                CardMaskedPAN = null,
                PaymentMethod = autoToupSettings.PaymentMethod,
                PaypalSubscriptionId = null
            });
            if (response > 0)
            {
                await HandleAutoTopupevents(msisdn, false);
                return GenericApiResponse<bool>.Success(true, "Auto Top-Up disabled successfully");
            }
            else
            {
                return GenericApiResponse<bool>.Failure(
                            "Somehting went wrong on server", ApiStatusCodes.InternalServerError);
            }
        }
        public async Task<GenericApiResponse<bool>> SetCustomerDefaultCard(SetCustomerDefaultCardRequestModel model, string msisdn)
        {
            var customerResponse = await _pay360Service.GetCustomer(new Pay360CustomerRequestModel()
            {
                customerUniqueRef = msisdn,
                productCode = ProductCode.THA.ToString()
            });

            if (customerResponse == null)
            {
                return GenericApiResponse<bool>.Failure(
                            "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (customerResponse.errorCode > 0)
            {
                _logger.Error($"Class: PaymentService, Method: SetCustomerDefaultCard - customerResponse, " +
                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                     $"Response => Model : {JsonConvert.SerializeObject(customerResponse)}");

                if (customerResponse.errorCode == (int)Pay360StatusCodes.CustomerNotExist)
                {
                    return GenericApiResponse<bool>.Failure("Customer does not exist", ApiStatusCodes.CustomerNotExist);
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            var cardResponse = await _pay360Service.SetCustomerDefaultCard(new SetCustomerDefaultCardRequest()
            {
                cardToken = model.CardToken,
                defaultCardCV2 = model.CardCV2,
                pay360CustomerID = customerResponse.payload.pay360CustId
            });

            if (cardResponse == null)
            {
                return GenericApiResponse<bool>.Failure(
                                    "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (cardResponse.errorCode > 0)
            {
                _logger.Error($"Class: PaymentService, Method: SetCustomerDefaultCard - cardResponse, " +
                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                     $"Response => Model : {JsonConvert.SerializeObject(cardResponse)}");

                if (customerResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<bool>.Failure(customerResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            return GenericApiResponse<bool>.Success(true, "success");

        }
        public async Task<GenericApiResponse<bool>> RemoveCard(RemoveCardRequestModel model, string msisdn)
        {
            var customerResponse = await _pay360Service.GetCustomer(new Pay360CustomerRequestModel()
            {
                customerUniqueRef = msisdn,
                productCode = ProductCode.THA.ToString()
            });

            if (customerResponse == null)
            {
                return GenericApiResponse<bool>.Failure(
                            "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (customerResponse.errorCode > 0)
            {
                _logger.Error($"Class: PaymentService, Method: RemoveCard - customerResponse, " +
                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                     $"Response => Model : {JsonConvert.SerializeObject(customerResponse)}");

                if (customerResponse.errorCode == (int)Pay360StatusCodes.CustomerNotExist)
                {
                    return GenericApiResponse<bool>.Failure("Customer does not exist", ApiStatusCodes.CustomerNotExist);
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            var customerExistingCards = await _pay360Service.Pay360GetCards(new Pay360CustomerRequestModel() { customerUniqueRef = msisdn, productCode = ProductCode.THA.ToString() });
            var customerDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            var isAnyActiveAutoBundleRenewal = await _bundleRepository.AnyActiveAutoBundleRenwal(customerDetails.AccountID);
            if (customerExistingCards.payload.paymentMethodResponses.Count == 1 && isAnyActiveAutoBundleRenewal)
            {
                return GenericApiResponse<bool>.Failure("Payment method cannot be removed because auto bundle renewal is active.", ApiStatusCodes.InternalServerError);
            }
            var cardResponse = await _pay360Service.RemoveCard(new RemoveCardRequest()
            {
                cardToken = model.CardToken,
                pay360CustomerID = customerResponse.payload.pay360CustId
            });

            if (cardResponse == null)
            {
                return GenericApiResponse<bool>.Failure(
                                    "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (cardResponse.errorCode > 0)
            {
                _logger.Error($"Class: PaymentService, Method: RemoveCard - cardResponse, " +
                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                     $"Response => Model : {JsonConvert.SerializeObject(cardResponse)}");

                if (customerResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<bool>.Failure(customerResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<bool>.Failure("Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            //Handle AirShip Tags
            var response = await _pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
            {
                customerUniqueRef = msisdn,
                productCode = ProductCode.THA.ToString()
            });

            if (response.errorCode == 0 && response.payload != null && response.payload.paymentMethodResponses.Count() == 0)
            {
                await _airShipService.HandlePaymentMethodTag(msisdn, false);
            }

            //Handle AirShip Tags

            return GenericApiResponse<bool>.Success(true, "success");
        }
        public async Task<GenericApiResponse<Pay360CustomerModel>> GetCustomer(Pay360CustomerRequestModel model)
        {
            var response = await _pay360Service.GetCustomer(model);
            if (response != null)
            {
                if (response.errorCode > 0)
                {
                    return GenericApiResponse<Pay360CustomerModel>.Failure(
                                "Error Occured while Get Customer", ApiStatusCodes.TransactionUnSuccessful);
                }
                else
                {
                    if (response.payload != null)
                    {
                        return response;
                    }
                }
            }
            return response;
        }
        public async Task<GenericApiResponse<BundlePurchaseViaABResponseModel>> BundlePurchaseViaAccountBalance(
                                                    BundlePurchaseViaABRequestModel model, string accountId, string msisdn, string currency)
        {
            //Check Bundle Limit
            var bundlesResponse = await _accountRepository.GetBundlesHistory(accountId);
            if (bundlesResponse.Count() >= 10)
            {
                return GenericApiResponse<BundlePurchaseViaABResponseModel>.Failure("Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
            }

            //Get Bundle Info
            var bundleInfo = await _bundleRepository.GetBundleById(model.BundleId);

            if (bundleInfo == null)
            {
                return GenericApiResponse<BundlePurchaseViaABResponseModel>.Failure("Invalid Bundle", ApiStatusCodes.InvalidBundle);
            }

            //Check Balance
            var accountInfo = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);

            if (accountInfo.Balance < (bundleInfo.TotalCostPence / 100))
            {
                return GenericApiResponse<BundlePurchaseViaABResponseModel>.Failure("Insufficient Balance", ApiStatusCodes.InsufficientBalance);
            }

            //Purchase Bundle
            var response = await _bundleRepository.BundlePurchaseViaAccountBalance(accountId, model.BundleId);

            if (response > 0)
            {
                await _PaymentFullfillment.SaveBundlePurchaseData(false, bundleInfo.BrandedName, bundleInfo.ID.ToString(), bundleInfo.TotalCostPence / 100, accountId, (response == 1111 || response == 300 ? "Bundle limit is exceeded" : "Unable to purchase bundle"));
                _logger.Error($"Class: PaymentService, Method: BundlePurchaseViaAccountBalance" +
                                $"AccountId => {accountId}" +
                                $"BundleId =>  {model.BundleId}" +
                                $"ErrorCode => {response}");

                if (response == 1111 || response == 300)
                {
                    return GenericApiResponse<BundlePurchaseViaABResponseModel>.Failure("Bundle limit is exceeded", ApiStatusCodes.BundleLimitExceeded);
                }

                return GenericApiResponse<BundlePurchaseViaABResponseModel>.Failure("Unable to purchase bundle", ApiStatusCodes.BundlePurchasedFailed);
            }
            await _PaymentFullfillment.SaveBundlePurchaseData(true, bundleInfo.BrandedName, bundleInfo.ID.ToString(), bundleInfo.TotalCostPence / 100, accountId);

            #region Events
            try
            {
                var bundleAmount = (bundleInfo.TotalCostPence / 100);
                var IsBundleExists = await _accountRepository.IsBundleExists(msisdn);
                var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());

                await HandleBundleEvents(Convert.ToInt32(bundleInfo.PackageType), model.ToBundleISO2, model.FromBundleISO2, null, true, false, msisdn, customerResoonse.Balance, bundleAmount, currency);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentService, Method: BundlePurchaseViaAccountBalance-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            #endregion

            //Need to send email
            var profile = await _accountRepository.GetUserByPhoneNumber(msisdn);
            if (!string.IsNullOrEmpty(profile?.email))
            {
                await SendBundlePaymentReceiptAsync(profile.email, bundleInfo, currency, profile, "Account Balance");
            }
            var origin = _phoneNumberService.GetCountryCode(msisdn);
            return GenericApiResponse<BundlePurchaseViaABResponseModel>.Success(new BundlePurchaseViaABResponseModel()
            {
                bundlePurchaseInfo = new BundlePurchaseInfo()
                {
                    TransactionId = Guid.NewGuid().ToString(),
                    BundleAmount = (bundleInfo.TotalCostPence / 100).ToString(),
                    BundleName = bundleInfo.BrandedName,
                    Currency = accountInfo.Currency,
                    Msisdn = msisdn,
                    BundleType = bundleInfo.BundleType,
                    PaymentMethod = PaymentMethodTypes.AccountBalance,
                    Origination = origin,
                    Destination = bundleInfo.Description,
                    AutoRenew = false
                }
            }, "Bundle purchased successfully");
        }
        public async Task<GenericApiResponse<NewCustomerPaymentResponseModel>> NewCustomerPayment(NewCustomerPaymentRequestModel model)
        {
            int Bundletype = 0;
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;
            var origination = _phoneNumberService.GetCountryCode(msisdn);
            if (!string.IsNullOrEmpty(model.EmailAddress))
                model.EmailAddress = model.EmailAddress.Trim();
            var responseModel = new NewCustomerPaymentResponseModel();
            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                responseModel.bundlePurchaseInfo = new BundlePurchaseInfo()
                {
                    AutoRenew = model.IsAutoBundleRenew,
                    Currency = currency,
                    Origination = origination,
                    Msisdn = model.Msisdn,
                    PaymentMethod = PaymentMethodTypes.Card,
                    TransactionId = "-1",
                };
            }
            else
            {
                responseModel.topupInfo = new TopupInfo()
                {
                    AutoTopup = model.IsAutoTopUp,
                    Currency = currency,
                    Origination = origination,
                    TopupAmount = model.TopUpAmount.ToString(),
                    Msisdn = msisdn,
                    PaymentMethod = PaymentMethodTypes.Card,
                    TransactionId = "-1"
                };
            }
            //Get User registration Date
            float ChargeAmount;
            string BundleName = "";
            string bundleDestination = "";
            bool isTrialBundle = false;

            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                //Get Bundle details
                var bundleResponse = await _bundleRepository.GetBundleById(model.BundleId);
                if (bundleResponse == null)
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure("Invalid Bundle", ApiStatusCodes.InvalidBundle);
                }
                Bundletype = Convert.ToInt32(bundleResponse.BundleType);
                //Check for trial bundles
                if (bundleResponse.IsTrial
                    && bundleResponse.TrialId != null
                    && !await _bundleRepository.IsBundlePurchasedPreviously(account, bundleResponse.TrialId.ToString()))
                {
                    var trialDetails = await _bundleRepository.GetBundleById(bundleResponse.TrialId.ToString());
                    if (trialDetails == null) return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(responseModel, "Invalid Trial Bundle", ApiStatusCodes.InvalidBundle);
                    ChargeAmount = (float)_pay360Config.TestPaymentAmount;
                    BundleName = trialDetails.BrandedName;
                    isTrialBundle = true;
                    model.BundleId = bundleResponse.TrialId.ToString();
                    model.IsAutoBundleRenew = true;
                    bundleDestination = trialDetails.Description;
                }
                else
                {
                    BundleName = bundleResponse.BrandedName;
                    ChargeAmount = bundleResponse.TotalCostPence / 100;
                    bundleDestination = bundleResponse.Description;
                    if (Bundletype == (int)BundleType.Welcome)
                    {
                        model.IsAutoBundleRenew = true;
                    }
                }
                responseModel.bundlePurchaseInfo.Destination = bundleDestination;
                responseModel.bundlePurchaseInfo.BundleAmount = ChargeAmount.ToString();
                responseModel.bundlePurchaseInfo.BundleName = BundleName;
                responseModel.bundlePurchaseInfo.BundleType = (BundleType)Bundletype;

            }
            else
            {
                ChargeAmount = model.TopUpAmount;
            }

            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };

            if (model.CheckoutType == CheckOutTypes.TopUp)
            {
                promResponse = await _promotionService.CheckAnyActivePromotions(
                   ChargeAmount,
                   msisdn,
                   PaymentMethodTypes.Card,
                     new PromotionDependentTypes[] { PromotionDependentTypes.Topup, PromotionDependentTypes.AutoTopup },
                   model.IsAutoTopUp
                   );
            }
            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                //Check Bundle Limit
                var bundlesResponse = await _accountRepository.GetBundlesHistory(account);
                if (bundlesResponse.Count() >= 10)
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(responseModel, "Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
                }
            }
            var paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                PromotionsDetails = promResponse,
                CustomerMsisdn = msisdn,
                Amount = ChargeAmount,
                CheckoutPaymentType = model.CheckoutType,
                BundleId = model.BundleId,
                IpAddress = model.ipAddress,
                CustomerEmail = model.EmailAddress,
                Currency = currency,
                Pay360PaymentType = Pay360PaymentType.New,
                CustomerAddressData = new AddressData()
                {
                    AddressL1 = model.billingAddressData.AddressL1,
                    AddressL2 = model.billingAddressData.AddressL2,
                    AddressL3 = model.billingAddressData.AddressL3,
                    AddressL4 = model.billingAddressData.AddressL4,
                    PostCode = model.billingAddressData.PostCode,
                    City = model.billingAddressData.City,
                    Region = model.billingAddressData.Region,
                    CountryCode = model.billingAddressData.CountryCode
                },
                CustomerCardData = new CardData()
                {
                    CardNumber = model.cardData.CardNumber,
                    NameOnCard = model.cardData.NameOnCard,
                    SecurityCode = model.cardData.SecurityCode,
                    ExpiryMonth = model.cardData.ExpiryMonth,
                    ExpiryYear = model.cardData.ExpiryYear
                },
                ShouldSaveCard = model.cardData.ShouldSaveCard,
                accountNumber = account,
                CustomerUniqueRef = model.CustomerUniqueRef
            });

            if (isTrialBundle)
            {
                paymentrequest.Pay360PaymentRequestNew.do3DSecure = false;
                paymentrequest.Pay360PaymentRequestNew.saveCard = true;
            }
            if (model.CheckoutType == CheckOutTypes.Bundle && Bundletype == (int)BundleType.Welcome)
            {
                paymentrequest.Pay360PaymentRequestNew.saveCard = true;
            }
            //TODO: Recurring payment if AutoTopup or AutoRenewal is ON
            if (model.IsAutoBundleRenew || model.IsAutoTopUp)
            {
                paymentrequest.Pay360PaymentRequestNew.recurring = true;
            }
            var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.New);

            paymentrequest.Pay360PaymentRequestNew.basket.First().amount = (float)promResponse.FullfilmentAmount;

            var paymentTransactionId = await _PaymentFullfillment.InsertTransactionPayment(
                        paymentrequest.Pay360PaymentRequestNew.basket,
                        paymentrequest.Pay360PaymentRequestNew.transactionCurrency,
                        paymentrequest.Pay360PaymentRequestNew.customerEmail,
                        paymentrequest.Pay360PaymentRequestNew.productCode,
                        paymentResponse?.payload?.transactionId,
                        paymentrequest.Pay360PaymentRequestNew.customerMsisdn,
                        Fullfillmenttype.Pay360,
                        0, isTrialBundle);

            var CountryCode = _phoneNumberService.GetCountryCode(msisdn);

            if (paymentResponse == null)
            {
                if (model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(model.IsAutoTopUp, msisdn, model.cardData.ShouldSaveCard, false, true, 0, CountryCode);

                }
                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(Bundletype, model.ToBundleISO2, model.FromBundleISO2, true, false, model.cardData.ShouldSaveCard, msisdn, 0, 0, currency);
                }

                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, null, "Payment service not responding");
                return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(responseModel, "Payment service not responding", ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {
                if (model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(model.IsAutoTopUp, msisdn, model.cardData.ShouldSaveCard, false, true, 0, CountryCode);

                }
                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(Bundletype, model.ToBundleISO2, model.FromBundleISO2, true, false, model.cardData.ShouldSaveCard, msisdn, 0, 0, currency);
                }

                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, paymentResponse?.payload?.transactionId, paymentResponse.message);
                _logger.Error($"Class: PaymentService, Method: NewCustomerPayment - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(responseModel,
                                "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(responseModel,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(responseModel,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            if (paymentResponse.payload.outcome.reasonCode == "U100") //3d Secure Scenario
            {
                //Send Response
                return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(
                                                new NewCustomerPaymentResponseModel()
                                                {
                                                    threeDSecureData = new ThreeDSecureData()
                                                    {
                                                        pareq = paymentResponse.payload.clientRedirect.pareq,
                                                        redirectUrl = paymentResponse.payload.clientRedirect.url,
                                                        transactionId = paymentResponse.payload.transactionId,
                                                        clientRedirectType = paymentResponse.payload.clientRedirect.type,
                                                        threeDSServerTransId = paymentResponse.payload.clientRedirect.threeDSServerTransId,
                                                        returnUrl = _pay360Config.TopUpSettings.ReturnUrl +
                                                        "type=" + (int)model.CheckoutType +
                                                        "&customerEmail=" + model.EmailAddress +
                                                        "&customerMsisdn=" + msisdn +
                                                        "&currency=" + currency +
                                                        "&bundleId=" + model.BundleId +
                                                        "&BundleType=" + Bundletype +
                                                        "&FromBundleISO2=" + model.FromBundleISO2 +
                                                        "&ToBundleISO2=" + model.ToBundleISO2 +
                                                        "&ShouldSaveCard=" + model.cardData.ShouldSaveCard +
                                                        "&IsAutoTopUp=" + model.IsAutoTopUp +
                                                        "&IsAutoBundleRenew=" + model.IsAutoBundleRenew +
                                                        "&PTId=" + paymentTransactionId +
                                                        "&clientRedirectType=" + paymentResponse.payload.clientRedirect.type
                                                    }
                                                }, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

            }
            else if (paymentResponse.payload.outcome.reasonCode == "S100")
            {
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, true, paymentResponse.payload.transactionId);

                //Full filment
                if (_pay360Config.IsDirectFullfilment == false)
                {
                    try
                    {
                        await Pay360CardPaymentFullfillment(paymentResponse, paymentrequest.Pay360PaymentRequestNew.customerMsisdn, paymentrequest.Pay360PaymentRequestNew.customerEmail);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(
                                $"Class: Paymentservices, " +
                                $"Method: NewCustomerPayment - PaymentFullfillment, " +
                                $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                                $"ErrorMessage: {ex.Message}");
                    }
                }

                //Set auto topup
                if (model.IsAutoTopUp && model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await SetAutoTopUpByCard(msisdn, currency,model.TopUpAmount,-1,paymentResponse.payload);
                }
                //Set auto renewal
                if (model.IsAutoBundleRenew && model.CheckoutType == CheckOutTypes.Bundle)
                {
                    await SetAutoRenewalByCard(model.IsAutoBundleRenew, model.Msisdn, account, model.BundleId, isTrialBundle, paymentResponse.payload);
                }
                //Events
                try
                {
                    var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);
                    var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());
                    if (model.CheckoutType == CheckOutTypes.TopUp)
                    {
                        await HandleTopupEvents(model.IsAutoTopUp, msisdn, model.cardData.ShouldSaveCard, true, true, Convert.ToDecimal(paymentResponse.payload.transactionAmount), CountryCode);

                    }
                    if (model.CheckoutType == CheckOutTypes.Bundle)
                    {
                        await HandleBundleEvents(Bundletype, model.ToBundleISO2, model.FromBundleISO2, true, true, model.cardData.ShouldSaveCard, msisdn, customerResoonse.Balance, transactionAmount, currency);
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: PaymentService, Method: NewCustomerPayment-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }
                var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    if (isTrialBundle)
                    {
                        //Refund payment
                        await _pay360Service.RefundFullPayment(new RefundFullPaymentRequestModel()
                        {
                            transactionId = paymentResponse.payload.transactionId
                        });
                    }
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Success(new NewCustomerPaymentResponseModel()
                    {
                        bundlePurchaseInfo = new BundlePurchaseInfo()
                        {
                            Origination = origination,
                            Destination = bundleDestination,
                            TransactionId = paymentResponse.payload.transactionId,
                            BundleAmount = isTrialBundle ? "" : paymentResponse.payload.transactionAmount,
                            BundleName = BundleName,
                            Msisdn = msisdn,
                            Currency = currency,
                            BundleType = isTrialBundle ? Enums.BundleType.Trial : (BundleType)Bundletype,
                            AutoRenew = model.IsAutoBundleRenew,
                            PaymentMethod = PaymentMethodTypes.Card
                        }
                    }, "Bundle purchased successfully");
                }
                else
                {
                    return GenericApiResponse<NewCustomerPaymentResponseModel>.Success(new NewCustomerPaymentResponseModel()
                    {
                        topupInfo = new TopupInfo()
                        {
                            Origination = origination,
                            TopupAmount = paymentResponse.payload.transactionAmount,
                            Msisdn = msisdn,
                            TransactionId = paymentResponse.payload.transactionId,
                            Currency = currency,
                            AutoTopup = model.IsAutoTopUp,
                            PaymentMethod = PaymentMethodTypes.Card,
                        }
                    }, "Top-Up Successfull");
                }
            }

            return GenericApiResponse<NewCustomerPaymentResponseModel>.Failure(responseModel,
                                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
        }
        public async Task<GenericApiResponse<NewCardPaymentResponseModel>> NewCardPayment(NewCardPaymentRequestModel model)
        {
            int Bundletype = 0;
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<NewCardPaymentResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;
            string origination = _phoneNumberService.GetCountryCode(msisdn);
            var bundleDestination = "";
            if (!string.IsNullOrEmpty(model.EmailAddress))
                model.EmailAddress = model.EmailAddress.Trim();

            float ChargeAmount;
            string BundleName = "";
            bool IsTrialBundle = false;
            var responseModel = new NewCardPaymentResponseModel();
            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                responseModel.bundlePurchaseInfo = new BundlePurchaseInfo()
                {
                    Origination = origination,
                    Currency = currency,
                    Msisdn = msisdn,
                    BundleType = IsTrialBundle ? Enums.BundleType.Trial : (BundleType)Bundletype,
                    AutoRenew = model.IsAutoBundleRenew,
                    PaymentMethod = PaymentMethodTypes.Card,
                };
            }
            else
            {
                responseModel.topupInfo = new TopupInfo()
                {
                    Origination = origination,
                    TopupAmount = model.TopUpAmount.ToString(),
                    Msisdn = msisdn,
                    Currency = currency,
                    PaymentMethod = PaymentMethodTypes.Card,
                    AutoTopup = model.IsAutoTopUp,
                };
            }
            if (model.CheckoutType == CheckOutTypes.Bundle)
            {

                //Get Bundle details
                var bundleResponse = await _bundleRepository.GetBundleById(model.BundleId);
                if (bundleResponse == null)
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Failure(responseModel, "Invalid Bundle", ApiStatusCodes.InvalidBundle);
                }
                Bundletype = Convert.ToInt32(bundleResponse.BundleType);
                if (bundleResponse.IsTrial
                    && bundleResponse.TrialId != null
                    && !await _bundleRepository.IsBundlePurchasedPreviously(account, bundleResponse.TrialId.ToString()))
                {
                    var trialDetails = await _bundleRepository.GetBundleById(bundleResponse.TrialId.ToString());
                    if (trialDetails == null)
                    {
                        return GenericApiResponse<NewCardPaymentResponseModel>.Failure(responseModel, "Invalid Trial Bundle", ApiStatusCodes.InvalidBundle);
                    }
                    BundleName = trialDetails.BrandedName;
                    ChargeAmount = _pay360Config.TestPaymentAmount;
                    IsTrialBundle = true;
                    model.IsAutoBundleRenew = true;
                    model.BundleId = bundleResponse.TrialId.ToString();
                    bundleDestination = trialDetails.Description;
                }
                else
                {
                    BundleName = bundleResponse.BrandedName;
                    ChargeAmount = bundleResponse.TotalCostPence / 100;
                    bundleDestination = bundleResponse.Description;
                    if (Bundletype == (int)BundleType.Welcome)
                    {
                        model.IsAutoBundleRenew = true;
                        model.cardData.ShouldSaveCard = false;
                    }
                }
                responseModel.bundlePurchaseInfo.BundleAmount = ChargeAmount.ToString();
                responseModel.bundlePurchaseInfo.BundleName = BundleName;
                responseModel.bundlePurchaseInfo.Destination = bundleDestination;
            }
            else
            {
                ChargeAmount = model.TopUpAmount;
                responseModel.topupInfo.TopupAmount = ChargeAmount.ToString();
            }
            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                //Check Bundle Limit
                var bundlesResponse = await _accountRepository.GetBundlesHistory(account);
                if (bundlesResponse.Count() >= 10)
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Failure(responseModel, "Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
                }
            }
            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };

            if (model.CheckoutType == CheckOutTypes.TopUp)
            {
                promResponse = await _promotionService.CheckAnyActivePromotions(
                   ChargeAmount,
                   msisdn,
                   PaymentMethodTypes.Card,
                     new PromotionDependentTypes[] { PromotionDependentTypes.Topup, PromotionDependentTypes.AutoTopup },
                   model.IsAutoTopUp
                   );
            }
            var paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                PromotionsDetails = promResponse,
                CustomerMsisdn = msisdn,
                Amount = ChargeAmount,
                CheckoutPaymentType = model.CheckoutType,
                BundleId = model.BundleId,
                IpAddress = model.ipAddress,
                CustomerEmail = model.EmailAddress,
                Currency = currency,
                Pay360PaymentType = Pay360PaymentType.ExistingNew,
                CustomerAddressData = new AddressData()
                {
                    AddressL1 = model.billingAddressData.AddressL1,
                    AddressL2 = model.billingAddressData.AddressL2,
                    AddressL3 = model.billingAddressData.AddressL3,
                    AddressL4 = model.billingAddressData.AddressL4,
                    PostCode = model.billingAddressData.PostCode,
                    City = model.billingAddressData.City,
                    Region = model.billingAddressData.Region,
                    CountryCode = model.billingAddressData.CountryCode
                },
                CustomerCardData = new CardData()
                {
                    CardNumber = model.cardData.CardNumber,
                    NameOnCard = model.cardData.NameOnCard,
                    SecurityCode = model.cardData.SecurityCode,
                    ExpiryMonth = model.cardData.ExpiryMonth,
                    ExpiryYear = model.cardData.ExpiryYear
                },
                ShouldSaveCard = model.cardData.ShouldSaveCard,
                accountNumber = account,
                CustomerUniqueRef = model.CustomerUniqueRef
            });
            if (IsTrialBundle)
            {
                paymentrequest.Pay360PaymentRequestExistingNew.saveCard = true;
                paymentrequest.Pay360PaymentRequestExistingNew.do3DSecure = false;
            }
            if (model.CheckoutType == CheckOutTypes.Bundle && Bundletype == (int)BundleType.Welcome)
            {
                paymentrequest.Pay360PaymentRequestExistingNew.saveCard = true;
            }
            //TODO: Recurring payment if AutoTopup or AutoRenewal is ON
            if (model.IsAutoBundleRenew || model.IsAutoTopUp)
            {
                paymentrequest.Pay360PaymentRequestExistingNew.recurring = true;
            }
            var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.ExistingNew);
            paymentrequest.Pay360PaymentRequestExistingNew.basket.First().amount = (float)promResponse.FullfilmentAmount;
            var paymentTransactionId = await _PaymentFullfillment.InsertTransactionPayment(
                  paymentrequest.Pay360PaymentRequestExistingNew.basket,
                  paymentrequest.Pay360PaymentRequestExistingNew.transactionCurrency,
                  paymentrequest.Pay360PaymentRequestExistingNew.customerEmail,
                  paymentrequest.Pay360PaymentRequestExistingNew.productCode,
                  paymentResponse?.payload?.transactionId,
                  paymentrequest.Pay360PaymentRequestExistingNew.customerMsisdn,
                  Fullfillmenttype.Pay360,
                  0,
                  IsTrialBundle);

            var CountryCode = _phoneNumberService.GetCountryCode(msisdn);

            if (paymentResponse == null)
            {
                if (model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(model.IsAutoTopUp, msisdn, model.cardData.ShouldSaveCard, false, true, 0, CountryCode);

                }
                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(Bundletype, model.ToBundleISO2, model.FromBundleISO2, true, false, model.cardData.ShouldSaveCard, msisdn, 0, 0, currency);
                }

                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, null, "Payment service not responding");
                return GenericApiResponse<NewCardPaymentResponseModel>.Failure(responseModel, "Payment service not responding", ApiStatusCodes.PaymentServiceError);
            }


            if (paymentResponse.errorCode > 0)
            {
                if (model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(model.IsAutoTopUp, msisdn, model.cardData.ShouldSaveCard, false, true, 0, CountryCode);

                }
                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(Bundletype, model.ToBundleISO2, model.FromBundleISO2, true, false, model.cardData.ShouldSaveCard, msisdn, 0, 0, currency);
                }
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, paymentResponse?.payload?.transactionId, paymentResponse.message);

                _logger.Error($"Class: PaymentService, Method: NewCardPayment - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Failure(responseModel,
                                "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Failure(responseModel,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Failure(responseModel,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }
            if (paymentResponse.payload.outcome.reasonCode == "U100") //3d Secure Scenario
            {
                //Send Response
                return GenericApiResponse<NewCardPaymentResponseModel>.Failure(
                                                new NewCardPaymentResponseModel()
                                                {
                                                    threeDSecureData = new ThreeDSecureData()
                                                    {
                                                        pareq = paymentResponse.payload.clientRedirect.pareq,
                                                        redirectUrl = paymentResponse.payload.clientRedirect.url,
                                                        transactionId = paymentResponse.payload.transactionId,
                                                        clientRedirectType = paymentResponse.payload.clientRedirect.type,
                                                        threeDSServerTransId = paymentResponse.payload.clientRedirect.threeDSServerTransId,
                                                        returnUrl = _pay360Config.TopUpSettings.ReturnUrl +
                                                        "type=" + (int)model.CheckoutType +
                                                        "&customerEmail=" + model.EmailAddress +
                                                        "&customerMsisdn=" + msisdn +
                                                        "&currency=" + currency +
                                                        "&BundleType=" + Bundletype +
                                                        "&bundleId=" + model.BundleId +
                                                        "&FromBundleISO2=" + model.FromBundleISO2 +
                                                        "&ToBundleISO2=" + model.ToBundleISO2 +
                                                        "&ShouldSaveCard=" + model.cardData.ShouldSaveCard +
                                                        "&IsAutoTopUp=" + model.IsAutoTopUp +
                                                        "&IsAutoBundleRenew=" + model.IsAutoBundleRenew +
                                                        "&PTId=" + paymentTransactionId +
                                                        "&clientRedirectType=" + paymentResponse.payload.clientRedirect.type
                                                    }
                                                }, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

            }
            else if (paymentResponse.payload.outcome.reasonCode == "S100")
            {
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, true, paymentResponse.payload.transactionId);

                //Fullfilment
                if (_pay360Config.IsDirectFullfilment == false)
                {
                    try
                    {
                        await Pay360CardPaymentFullfillment(paymentResponse, paymentrequest.Pay360PaymentRequestExistingNew.customerMsisdn, paymentrequest.Pay360PaymentRequestExistingNew.customerEmail);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(
                                $"Class: Paymentservices, " +
                                $"Method: Pay360PaymentRequestExistingNew - PaymentFullfillment, " +
                                $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                                $"ErrorMessage: {ex.Message}");
                    }
                }


                //set auto topup
                if (model.IsAutoTopUp && model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await SetAutoTopUpByCard(msisdn, currency,model.TopUpAmount,-1, paymentResponse.payload);
                }
                //set auto renew
                if (model.IsAutoBundleRenew && model.CheckoutType == CheckOutTypes.Bundle)
                {
                    await SetAutoRenewalByCard(model.IsAutoBundleRenew, model.Msisdn, account, model.BundleId, IsTrialBundle, paymentResponse.payload);
                }
                try
                {

                    var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);
                    var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());
                    if (model.CheckoutType == CheckOutTypes.TopUp)
                    {
                        await HandleTopupEvents(model.IsAutoTopUp, msisdn, model.cardData.ShouldSaveCard, true, true, Convert.ToDecimal(paymentResponse.payload.transactionAmount), CountryCode);

                    }
                    if (model.CheckoutType == CheckOutTypes.Bundle)
                    {
                        await HandleBundleEvents(Bundletype, model.ToBundleISO2, model.FromBundleISO2, true, true, model.cardData.ShouldSaveCard, msisdn, customerResoonse.Balance, transactionAmount, currency);

                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: PaymentService, Method: NewCardPayment-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }

                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    //Refund if trial
                    if (IsTrialBundle)
                    {
                        await _pay360Service.RefundFullPayment(new RefundFullPaymentRequestModel() { transactionId = paymentResponse.payload.transactionId });
                    }
                    return GenericApiResponse<NewCardPaymentResponseModel>.Success(new NewCardPaymentResponseModel()
                    {
                        bundlePurchaseInfo = new BundlePurchaseInfo()
                        {
                            Origination = origination,
                            Destination = bundleDestination,
                            TransactionId = paymentResponse.payload.transactionId,
                            BundleAmount = IsTrialBundle ? "" : paymentResponse.payload.transactionAmount,
                            BundleName = BundleName,
                            Currency = currency,
                            Msisdn = msisdn,
                            BundleType = IsTrialBundle ? Enums.BundleType.Trial : (BundleType)Bundletype,
                            AutoRenew = model.IsAutoBundleRenew,
                            PaymentMethod = PaymentMethodTypes.Card,
                        }
                    }, "Bundle purchased successfully");
                }
                else
                {
                    return GenericApiResponse<NewCardPaymentResponseModel>.Success(new NewCardPaymentResponseModel()
                    {
                        topupInfo = new TopupInfo()
                        {
                            Origination = origination,
                            TopupAmount = paymentResponse.payload.transactionAmount,
                            Msisdn = msisdn,
                            TransactionId = paymentResponse.payload.transactionId,
                            Currency = currency,
                            PaymentMethod = PaymentMethodTypes.Card,
                            AutoTopup = model.IsAutoTopUp
                        }
                    }, "Top-Up Successfull");
                }
            }

            return GenericApiResponse<NewCardPaymentResponseModel>.Failure(null,
                                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
        }
        public async Task<GenericApiResponse<ExistingCardPaymentResponseModel>> ExistingCardPayment(ExistingCardPaymentRequestModel model)
        {
            int Bundletype = 0;
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;
            var origination = _phoneNumberService.GetCountryCode(msisdn);
            var bundleDestination = "";
            if (!string.IsNullOrEmpty(model.EmailAddress))
                model.EmailAddress = model.EmailAddress.Trim();
            var responseModel = new ExistingCardPaymentResponseModel();
            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                responseModel.bundlePurchaseInfo = new BundlePurchaseInfo
                {
                    AutoRenew = model.IsAutoBundleRenew,
                    Origination = origination,
                    Currency = currency,
                    Msisdn = model.Msisdn,
                    TransactionId = "-1",
                    PaymentMethod = PaymentMethodTypes.Card,
                };
            }
            else
            {
                responseModel.topupInfo = new TopupInfo
                {
                    AutoTopup = model.IsAutoTopUp,
                    Currency = currency,
                    Msisdn = model.Msisdn,
                    Origination = origination,
                    PaymentMethod = PaymentMethodTypes.Card,
                    TopupAmount = model.TopUpAmount.ToString(),
                    TransactionId = "-1",
                };
            }
            float ChargeAmount;
            string BundleName = "";
            bool isTrialBundle = false;

            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                //Get Bundle details
                var bundleResponse = await _bundleRepository.GetBundleById(model.BundleId);
                if (bundleResponse is null)
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(responseModel, "Invalid Bundle", ApiStatusCodes.InvalidBundle);
                }
                Bundletype = Convert.ToInt32(bundleResponse.BundleType);
                if (bundleResponse.IsTrial && bundleResponse.TrialId != null
                    && !await _bundleRepository.IsBundlePurchasedPreviously(account, bundleResponse.TrialId.ToString()))
                {
                    var trialDetails = await _bundleRepository.GetBundleById(bundleResponse.TrialId.ToString());
                    if (trialDetails is null)
                    {
                        return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(responseModel, "Invalid Trial Bundle", ApiStatusCodes.InvalidBundle);
                    }
                    BundleName = trialDetails.BrandedName;
                    ChargeAmount = _pay360Config.TestPaymentAmount;
                    isTrialBundle = true;
                    model.IsAutoBundleRenew = true;
                    model.BundleId = bundleResponse.TrialId.ToString();
                    bundleDestination = trialDetails.Description;
                }
                else
                {
                    BundleName = bundleResponse.BrandedName;
                    ChargeAmount = bundleResponse.TotalCostPence / 100;
                    bundleDestination = bundleResponse.Description;
                    if (Bundletype == (int)BundleType.Welcome)
                    {
                        model.IsAutoBundleRenew = true;
                    }
                }
                responseModel.bundlePurchaseInfo.BundleName = BundleName;
                responseModel.bundlePurchaseInfo.BundleAmount = ChargeAmount.ToString();
                responseModel.bundlePurchaseInfo.Destination = bundleDestination;
                responseModel.bundlePurchaseInfo.BundleType = (BundleType)Bundletype;
            }
            else
            {
                ChargeAmount = model.TopUpAmount;
            }

            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                //Check Bundle Limit
                var bundlesResponse = await _accountRepository.GetBundlesHistory(account);
                if (bundlesResponse.Count() >= 10)
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(responseModel, "Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
                }
            }
            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };

            if (model.CheckoutType == CheckOutTypes.TopUp)
            {
                promResponse = await _promotionService.CheckAnyActivePromotions(
                  ChargeAmount,
                   msisdn,
                   PaymentMethodTypes.Card,
                     new PromotionDependentTypes[] { PromotionDependentTypes.Topup, PromotionDependentTypes.AutoTopup },
                   model.IsAutoTopUp
                   );
            }

            var CountryCode = _phoneNumberService.GetCountryCode(msisdn);



            var paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                PromotionsDetails = promResponse,
                CustomerMsisdn = msisdn,
                Amount = ChargeAmount,
                CheckoutPaymentType = model.CheckoutType,
                BundleId = model.BundleId,
                IpAddress = model.ipAddress,
                CustomerEmail = model.EmailAddress,
                Currency = currency,
                Pay360PaymentType = Pay360PaymentType.Token,
                CardToken = model.cardToken,
                SecurityCode = model.securityCode,
                accountNumber = account,
                CustomerUniqueRef = model.CustomerUniqueRef
            });
            if (isTrialBundle)
            {
                paymentrequest.Pay360PaymentRequestToken.do3DSecure = false;
            }
            //TODO: Recurring payment if AutoTopup or AutoRenewal is ON
            if (model.IsAutoBundleRenew || model.IsAutoTopUp)
            {
                paymentrequest.Pay360PaymentRequestToken.recurring = true;
            }
            var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.Token);
            //save transaction details
            paymentrequest.Pay360PaymentRequestToken.basket.First().amount = (float)promResponse.FullfilmentAmount;
            var paymentTransactionId = await _PaymentFullfillment.InsertTransactionPayment(
                      paymentrequest.Pay360PaymentRequestToken.basket,
                      paymentrequest.Pay360PaymentRequestToken.transactionCurrency,
                      paymentrequest.Pay360PaymentRequestToken.customerEmail,
                      paymentrequest.Pay360PaymentRequestToken.productCode,
                      paymentResponse?.payload?.transactionId,
                      msisdn,
                      Fullfillmenttype.Pay360,
                      0,
                      isTrialBundle);

            if (paymentResponse == null)
            {
                if (model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(model.IsAutoTopUp, msisdn, false, false, true, 0, CountryCode);

                }
                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(Bundletype, model.ToBundleISO2, model.FromBundleISO2, true, false, false, msisdn, 0, 0, currency);
                }

                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, null, "Payment service not responding");
                return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(responseModel, "Payment service not responding",
                                                                                                    ApiStatusCodes.PaymentServiceError);
            }
            if (paymentResponse.errorCode > 0)
            {
                if (model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(model.IsAutoTopUp, msisdn, false, false, true, 0, CountryCode);

                }
                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(Bundletype, model.ToBundleISO2, model.FromBundleISO2, true, false, false, msisdn, 0, 0, currency);
                }

                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, paymentResponse?.payload?.transactionId, paymentResponse.message);
                _logger.Error($"Class: PaymentService, Method: ExistingCardPayment - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");

                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(responseModel,
                                "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(responseModel,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(responseModel,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }




            if (paymentResponse.payload.outcome.reasonCode == "U100") //3d Secure Scenario
            {
                //Send Response
                return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(
                                                new ExistingCardPaymentResponseModel()
                                                {
                                                    threeDSecureData = new ThreeDSecureData()
                                                    {
                                                        pareq = paymentResponse.payload.clientRedirect.pareq,
                                                        redirectUrl = paymentResponse.payload.clientRedirect.url,
                                                        transactionId = paymentResponse.payload.transactionId,
                                                        clientRedirectType = paymentResponse.payload.clientRedirect.type,
                                                        threeDSServerTransId = paymentResponse.payload.clientRedirect.threeDSServerTransId,
                                                        returnUrl = _pay360Config.TopUpSettings.ReturnUrl +
                                                        "type=" + (int)model.CheckoutType +
                                                        "&customerEmail=" + model.EmailAddress +
                                                        "&customerMsisdn=" + msisdn +
                                                        "&currency=" + currency +
                                                        "&bundleId=" + model.BundleId +
                                                        "&BundleType=" + Bundletype +
                                                        "&FromBundleISO2=" + model.FromBundleISO2 +
                                                        "&ToBundleISO2=" + model.ToBundleISO2 +
                                                        "&IsAutoTopUp=" + model.IsAutoTopUp +
                                                        "&IsAutoBundleRenew=" + model.IsAutoBundleRenew +
                                                        "&PTId=" + paymentTransactionId +
                                                        "&clientRedirectType=" + paymentResponse.payload.clientRedirect.type
                                                    }
                                                }, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

            }
            else if (paymentResponse.payload.outcome.reasonCode == "S100")
            {
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, true, paymentResponse.payload.transactionId);
                //Fullfilment
                if (_pay360Config.IsDirectFullfilment == false)
                {
                    try
                    {
                        await Pay360CardPaymentFullfillment(
                            paymentResponse,
                            paymentrequest.Pay360PaymentRequestToken.customerMsisdn,
                            paymentrequest.Pay360PaymentRequestToken.customerEmail);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(
                                $"Class: Paymentservices, " +
                                $"Method: Pay360PaymentRequestToken - PaymentFullfillment, " +
                                $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                                $"ErrorMessage: {ex.Message}");
                    }
                }

                //set auto topup
                if (model.IsAutoTopUp && model.CheckoutType == CheckOutTypes.TopUp)
                {
                    await SetAutoTopUpByCard(msisdn, currency,model.TopUpAmount,-1, paymentResponse.payload);
                }
                //set auto bundle renew
                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    await SetAutoRenewalByCard(model.IsAutoBundleRenew, model.Msisdn, account, model.BundleId, isTrialBundle, paymentResponse.payload);
                }
                //Events
                try
                {

                    var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);
                    var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());

                    if (model.CheckoutType == CheckOutTypes.TopUp)
                    {
                        await HandleTopupEvents(model.IsAutoTopUp, msisdn, false, true, true, Convert.ToDecimal(paymentResponse.payload.transactionAmount), CountryCode);

                    }
                    if (model.CheckoutType == CheckOutTypes.Bundle)
                    {
                        await HandleBundleEvents(Bundletype, model.ToBundleISO2, model.FromBundleISO2, true, true, false, msisdn, customerResoonse.Balance, transactionAmount, currency);
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: PaymentService, Method: ExistingCardPayment-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }

                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    //refund if trial bundle
                    if (isTrialBundle)
                    {
                        await _pay360Service.RefundFullPayment(new RefundFullPaymentRequestModel() { transactionId = paymentResponse.payload.transactionId });
                    }
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Success(new ExistingCardPaymentResponseModel()
                    {
                        bundlePurchaseInfo = new BundlePurchaseInfo()
                        {
                            Origination = origination,
                            Destination = bundleDestination,
                            TransactionId = paymentResponse.payload.transactionId,
                            BundleAmount = paymentResponse.payload.transactionAmount,
                            BundleName = BundleName,
                            Currency = currency,
                            Msisdn = msisdn,
                            BundleType = isTrialBundle ? Enums.BundleType.Trial : (BundleType)Bundletype,
                            AutoRenew = model.IsAutoBundleRenew,
                            PaymentMethod = PaymentMethodTypes.Card,
                        }
                    }, "Bundle purchased successfully");
                }
                else
                {
                    return GenericApiResponse<ExistingCardPaymentResponseModel>.Success(new ExistingCardPaymentResponseModel()
                    {
                        topupInfo = new TopupInfo()
                        {
                            Origination = origination,
                            TopupAmount = paymentResponse.payload.transactionAmount,
                            Msisdn = msisdn,
                            TransactionId = paymentResponse.payload.transactionId,
                            Currency = currency,
                            AutoTopup = model.IsAutoTopUp,
                            PaymentMethod = PaymentMethodTypes.Card
                        }
                    }, "Top-Up Successfull");
                }
            }

            return GenericApiResponse<ExistingCardPaymentResponseModel>.Failure(responseModel,
                                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
        }
        public async Task<GenericApiResponse<DefaultCardPaymentResponseModel>> ActivateBundleWithDefaultCardPayment(DefaultCardPaymentRequestModel model)
        {
            int BundleType = 0;
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<DefaultCardPaymentResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;

            string email = "";//Need to set this email

            float ChargeAmount;
            string BundleName = "";
            bool isTrialBundle = false;
            var origination = _phoneNumberService.GetCountryCode(msisdn);
            //Check Bundle Limit
            var bundlesResponse = await _accountRepository.GetBundlesHistory(account);
            if (bundlesResponse.Count() >= 10)
            {
                return GenericApiResponse<DefaultCardPaymentResponseModel>.Failure("Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
            }

            //Get Bundle details
            var bundleResponse = await _bundleRepository.GetBundleById(model.BundleId);
            if (bundleResponse is null || !bundleResponse.IsTrial || bundleResponse.TrialId is null)
            {
                return GenericApiResponse<DefaultCardPaymentResponseModel>.Failure("Invalid Bundle", ApiStatusCodes.InvalidBundle);
            }
            if (!await _bundleRepository.MonthlyBundleValidationAfterTrialExpire(account, msisdn, model.BundleId, bundleResponse.TrialId.ToString()))
            {
                return GenericApiResponse<DefaultCardPaymentResponseModel>.Failure("Invalid Bundle", ApiStatusCodes.InvalidBundle);
            }
            var destination = bundleResponse.Description;
            BundleType = Convert.ToInt32(bundleResponse.PackageType);

            //if (bundleResponse.IsTrial && bundleResponse.TrialId != null)
            //{
            //    var trialDetails = await _bundleRepository.GetBundleById(bundleResponse.TrialId.ToString());
            //    if (trialDetails is null)
            //    {
            //        return GenericApiResponse<DefaultCardPaymentResponseModel>.Failure("Invalid Trial Bundle", ApiStatusCodes.InvalidBundle);
            //    }
            //    BundleName = trialDetails.BrandedName;
            //    ChargeAmount = _pay360Config.TestPaymentAmount;
            //}
            //else
            //{
            BundleName = bundleResponse.BrandedName;
            ChargeAmount = bundleResponse.TotalCostPence / 100;
            //}

            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };
            var pay360Customer = await _PaymentFullfillment.GetCustomerByMerchantRef(model.CustomerUniqueRef);
            string cardCv2 = RijndaelEncryption.Decrypt(pay360Customer.DefaultCardCV2, pay360Customer.EncryptionKey);

            var paymentrequest = await GeneratePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                PromotionsDetails = promResponse,
                CustomerMsisdn = msisdn,
                Amount = ChargeAmount,
                CheckoutPaymentType = CheckOutTypes.Bundle,
                BundleId = model.BundleId,
                IpAddress = model.ipAddress,
                CustomerEmail = email,
                Currency = currency,
                Pay360PaymentType = Pay360PaymentType.Default,
                SecurityCode = cardCv2,
                accountNumber = account,
                CustomerUniqueRef = model.CustomerUniqueRef
            });

            paymentrequest.Pay360PaymentRequestDefault.do3DSecure = false;

            var paymentResponse = await _pay360Service.Pay360Payment(paymentrequest, Pay360PaymentType.Default);

            paymentrequest.Pay360PaymentRequestDefault.basket.First().amount = (float)promResponse.FullfilmentAmount;
            var paymentTransactionId = await _PaymentFullfillment.InsertTransactionPayment(
                      paymentrequest.Pay360PaymentRequestDefault.basket,
                      paymentrequest.Pay360PaymentRequestDefault.transactionCurrency,
                      paymentrequest.Pay360PaymentRequestDefault.customerEmail,
                      paymentrequest.Pay360PaymentRequestDefault.productCode,
                      paymentResponse?.payload?.transactionId,
                      msisdn,
                      Fullfillmenttype.Pay360,
                      0,
                      isTrialBundle);

            if (paymentResponse == null)
            {
                await HandleBundleEvents(BundleType, model.ToBundleISO2, model.FromBundleISO2, true, false, false, msisdn, 0, 0, currency);

                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, null, "Payment service not responding");
                return GenericApiResponse<DefaultCardPaymentResponseModel>.Failure(null, "Payment service not responding",
                                                                                                    ApiStatusCodes.PaymentServiceError);
            }
            if (paymentResponse.errorCode > 0)
            {
                await HandleBundleEvents(BundleType, model.ToBundleISO2, model.FromBundleISO2, true, false, false, msisdn, 0, 0, currency);
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, false, paymentResponse.payload?.transactionId, paymentResponse.message);
                _logger.Error($"Class: PaymentService, Method: ExistingCardPayment - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");

                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<DefaultCardPaymentResponseModel>.Failure(null,
                                "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<DefaultCardPaymentResponseModel>.Failure(null,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<DefaultCardPaymentResponseModel>.Failure(null,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }




            if (paymentResponse.payload.outcome.reasonCode == "S100")
            {
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(paymentTransactionId, true, paymentResponse.payload.transactionId);
                //Fullfilment
                if (_pay360Config.IsDirectFullfilment == false)
                {
                    try
                    {
                        await Pay360CardPaymentFullfillment(
                            paymentResponse,
                            paymentrequest.Pay360PaymentRequestDefault.customerMsisdn,
                            paymentrequest.Pay360PaymentRequestDefault.customerEmail);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(
                                $"Class: Paymentservices, " +
                                $"Method: Pay360PaymentRequestToken - PaymentFullfillment, " +
                                $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                                $"ErrorMessage: {ex.Message}");
                    }
                }
                //disable auto bundle renew for trial bundle so that it do not activate twice
                await _bundleRepository.SetBundleAutoRenewal(false, model.Msisdn, account, bundleResponse.TrialId.ToString(), true, PaymentMethods.Card, null, null, null);
                //set auto bundle renew for main bundle
                await SetAutoRenewalByCard(true, model.Msisdn, account, model.BundleId, false, paymentResponse
                .payload);
                //Events
                try
                {
                    var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);
                    var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());
                    await HandleBundleEvents(BundleType, model.ToBundleISO2, model.FromBundleISO2, true, true, false, msisdn, customerResoonse.Balance, transactionAmount, currency);

                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: PaymentService, Method: ExistingCardPayment-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }
                return GenericApiResponse<DefaultCardPaymentResponseModel>.Success(new DefaultCardPaymentResponseModel()
                {
                    bundlePurchaseInfo = new BundlePurchaseInfo()
                    {
                        TransactionId = paymentResponse.payload.transactionId,
                        BundleAmount = paymentResponse.payload.transactionAmount,
                        BundleName = BundleName,
                        Currency = currency,
                        Msisdn = msisdn,
                        BundleType = Enums.BundleType.Monthly,
                        Origination = origination,
                        Destination = destination,
                        PaymentMethod = PaymentMethodTypes.Card,
                        AutoRenew = true
                    }
                }, "Bundle purchased successfully");

            }

            return GenericApiResponse<DefaultCardPaymentResponseModel>.Failure(null,
                                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
        }

        public async Task<GenericApiResponse<Pay360Resume3DResponseModel>> Resume3DTransaction(Pay360Resume3DRequestModel request)
        {
            var CountryCode = _phoneNumberService.GetCountryCode(request.customerMsisdn);

            var account = await _accountRepository.GetAccountDetailsBySipUsername("THA" + request.customerMsisdn);
            Bundles bundle = null;
            if (request.type == CheckOutTypes.Bundle)
                bundle = await _bundleRepository.GetBundleById(request.bundleId);

            GenericApiResponse<Pay360PaymentResponse> paymentResponse;
            if (request.clientRedirectType.Contains("V2", StringComparison.CurrentCultureIgnoreCase))
            {
                paymentResponse = await _pay360Service.Resume3DTransactionV2(new Pay360Resume3DRequest()
                {
                    pay360TransactionId = request.MD,
                    customerEmail = request.customerEmail
                });
            }
            else
            {
                paymentResponse = await _pay360Service.Resume3DTransaction(new Pay360Resume3DRequest()
                {
                    pareq = request.PaRes,
                    pay360TransactionId = request.MD,
                    customerEmail = request.customerEmail
                });
            }

            if (paymentResponse == null)
            {
                if (request.type == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(request.IsAutoTopUp, request.customerMsisdn, request.ShouldSaveCard, false, true, 0, CountryCode);
                }
                if (request.type == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(Convert.ToInt32(bundle.BundleType), request.ToBundleISO2, request.FromBundleISO2, true, false, request.ShouldSaveCard, request.customerMsisdn, 0, 0, request.currency);
                }

                await _PaymentFullfillment.UpdatePaymentTransactionAsync(request.PTId, false, null, "Payment service not responding");
                return GenericApiResponse<Pay360Resume3DResponseModel>.Failure(null, "Payment service not responding",
                                                                                                ApiStatusCodes.PaymentServiceError);
            }
            var origination = _phoneNumberService.GetCountryCode(request.customerMsisdn);
            var errorResponse = new Pay360Resume3DResponseModel();
            if (request.type == CheckOutTypes.TopUp)
            {
                errorResponse.topupInfo = new TopupInfo
                {
                    AutoTopup = request.IsAutoTopUp,
                    Currency = request.currency,
                    Msisdn = request.customerMsisdn,
                    Origination = _phoneNumberService.GetCountryCode(request.customerMsisdn),
                    PaymentMethod = PaymentMethodTypes.Card,
                    TransactionId = paymentResponse.payload?.transactionId,
                };
            }
            else if (request.type == CheckOutTypes.Bundle)
            {
                errorResponse.bundlePurchaseInfo = new BundlePurchaseInfo
                {
                    AutoRenew = request.IsAutoRenew,
                    BundleAmount = (bundle.TotalCostPence / 100).ToString(),
                    BundleName = bundle.BrandedName,
                    BundleType = bundle.BundleType,
                    Currency = request.currency,
                    Msisdn = request.customerMsisdn,
                    Destination = bundle.Description,
                    Origination = _phoneNumberService.GetCountryCode(request.customerMsisdn),
                    PaymentMethod = PaymentMethodTypes.Card,
                    TransactionId = paymentResponse.payload?.transactionId
                };
            }
            if (paymentResponse.errorCode > 0)
            {
                if (request.type == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(request.IsAutoTopUp, request.customerMsisdn, request.ShouldSaveCard, false, true, 0, CountryCode);
                }
                if (request.type == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(Convert.ToInt32(bundle.BundleType), request.ToBundleISO2, request.FromBundleISO2, true, false, request.ShouldSaveCard, request.customerMsisdn, 0, 0, request.currency);
                }
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(request.PTId, false, paymentResponse.payload?.transactionId, paymentResponse.message);
                _logger.Error($"Class: PaymentService, Method: Resume3DTransaction - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(request)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<Pay360Resume3DResponseModel>.Failure(errorResponse,
                                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {

                    return GenericApiResponse<Pay360Resume3DResponseModel>.Failure(errorResponse,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<Pay360Resume3DResponseModel>.Failure(errorResponse,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            await _PaymentFullfillment.UpdatePaymentTransactionAsync(request.PTId, true, paymentResponse.payload.transactionId);
            //Full-filment
            if (_pay360Config.IsDirectFullfilment == false)
            {
                try
                {
                    await Pay360CardPaymentFullfillment(paymentResponse, request.customerMsisdn, request.customerEmail);
                }
                catch (Exception ex)
                {
                    _logger.Error(
                            $"Class: Pay360_BL, " +
                            $"Method: Resume3d - PaymentFullfillment, " +
                            $"Parameters=> Request: {JsonConvert.SerializeObject(request)}, " +
                            $"ErrorMessage: {ex.Message}");
                }
            }

            //Set auto top-up
            if (request.IsAutoTopUp && request.type == CheckOutTypes.TopUp)
            {
                await SetAutoTopUpByCard(request.customerMsisdn,paymentResponse.payload.transactionAmount, -1,-1, paymentResponse.payload);
            }

            try
            {

                var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);
                var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + request.customerMsisdn);

                if (request.type == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(request.IsAutoTopUp, request.customerMsisdn, request.ShouldSaveCard, true, true, Convert.ToDecimal(paymentResponse.payload.transactionAmount), CountryCode);
                }
                if (request.type == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(Convert.ToInt32(bundle.BundleType), request.ToBundleISO2, request.FromBundleISO2, true, true, request.ShouldSaveCard, request.customerMsisdn, customerResoonse.Balance, transactionAmount, request.currency);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentService, Method: Resume3DTransaction-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }

            if (request.type == CheckOutTypes.Bundle)
            {
                if (request.IsAutoBundleRenew)
                {
                    await SetAutoRenewalByCard(request.IsAutoBundleRenew, request.customerMsisdn, account.AccountID, request.bundleId, false, paymentResponse.payload);
                }
                return GenericApiResponse<Pay360Resume3DResponseModel>.Success(new Pay360Resume3DResponseModel()
                {
                    bundlePurchaseInfo = new BundlePurchaseInfo()
                    {
                        TransactionId = paymentResponse.payload?.transactionId,
                        BundleAmount = paymentResponse.payload.transactionAmount,
                        BundleName = bundle.BrandedName,
                        Msisdn = request.customerMsisdn,
                        Currency = request.currency,
                        BundleType = bundle.BundleType,
                        Origination = origination,
                        Destination = bundle.Description,
                        PaymentMethod = PaymentMethodTypes.Card,
                        AutoRenew = request.IsAutoRenew,
                    },
                }, "Bundle purchased successfully");
            }
            else
            {
                return GenericApiResponse<Pay360Resume3DResponseModel>.Success(new Pay360Resume3DResponseModel()
                {
                    topupInfo = new TopupInfo()
                    {
                        Origination = origination,
                        TopupAmount = paymentResponse.payload.transactionAmount,
                        Msisdn = request.customerMsisdn,
                        TransactionId = paymentResponse.payload?.transactionId,
                        Currency = request.currency,
                        PaymentMethod = PaymentMethodTypes.Card,
                        AutoTopup = request.IsAutoTopUp,
                    }
                }, "Top-Up Successfull");
            }
        }
        public async Task<GenericApiResponse<SetAutoTopupWithCardPay360Resume3DResponseModel>> SetAutoTopupWithCardResume3DTransaction(SetAutoTopupWithCardPay360Resume3DRequestModel request)
        {
            var CountryCode = _phoneNumberService.GetCountryCode(request.customerMsisdn);

            var account = await _accountRepository.GetAccountDetailsBySipUsername("THA" + request.customerMsisdn);

            GenericApiResponse<Pay360PaymentResponse> paymentResponse;
            if (request.clientRedirectType.Contains("V2", StringComparison.CurrentCultureIgnoreCase))
            {
                paymentResponse = await _pay360Service.Resume3DTransactionV2(new Pay360Resume3DRequest()
                {
                    pay360TransactionId = request.MD,
                    customerEmail = request.customerEmail
                });
            }
            else
            {
                paymentResponse = await _pay360Service.Resume3DTransaction(new Pay360Resume3DRequest()
                {
                    pareq = request.PaRes,
                    pay360TransactionId = request.MD,
                    customerEmail = request.customerEmail
                });
            }

            if (paymentResponse == null)
            {
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(request.PTId, false, null, "Payment service not responding");
                return GenericApiResponse<SetAutoTopupWithCardPay360Resume3DResponseModel>.Failure(null, "Payment service not responding",
                                                                                                ApiStatusCodes.PaymentServiceError);
            }
            var origination = _phoneNumberService.GetCountryCode(request.customerMsisdn);
            var errorResponse = new SetAutoTopupWithCardPay360Resume3DResponseModel();

            errorResponse.AutoTopupInfo = new AutoTopupInfo
            {
                TopupAmount = request.TopupAmount,
                Currency = request.currency,
                MaxSpendLimit = _pay360Config.AutoTopupMaxSpendLimit,
                ThresholdAmount = request.ThresholdAmount,
            };

            if (paymentResponse.errorCode > 0)
            {
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(request.PTId, false, paymentResponse.payload?.transactionId, paymentResponse.message,true);
                _logger.Error($"Class: PaymentService, Method: Resume3DTransaction - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(request)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<SetAutoTopupWithCardPay360Resume3DResponseModel>.Failure(errorResponse,
                                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {

                    return GenericApiResponse<SetAutoTopupWithCardPay360Resume3DResponseModel>.Failure(errorResponse,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<SetAutoTopupWithCardPay360Resume3DResponseModel>.Failure(errorResponse,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            //Full-filment
            if (_pay360Config.IsDirectFullfilment == false)
            {
                try
                {
                    await Pay360CardPaymentFullfillment(paymentResponse, request.customerMsisdn, request.customerEmail,true);
                }
                catch (Exception ex)
                {
                    _logger.Error(
                            $"Class: Pay360_BL, " +
                            $"Method: Resume3d - PaymentFullfillment, " +
                            $"Parameters=> Request: {JsonConvert.SerializeObject(request)}, " +
                            $"ErrorMessage: {ex.Message}");
                }
            }
            var paymentRefundResponse=await _pay360Service.RefundFullPayment(new RefundFullPaymentRequestModel
            {
                transactionId = paymentResponse.payload.transactionId
            });
            await _PaymentFullfillment.UpdatePaymentTransactionAsync(request.PTId, true, paymentResponse.payload.transactionId,null, paymentRefundResponse.errorCode==0);

            await SetAutoTopUpByCard(request.customerMsisdn,request.currency,request.TopupAmount,request.ThresholdAmount, paymentResponse.payload);

            return GenericApiResponse<SetAutoTopupWithCardPay360Resume3DResponseModel>.Success(new SetAutoTopupWithCardPay360Resume3DResponseModel()
            {
                AutoTopupInfo = new AutoTopupInfo()
                {
                    TopupAmount = request.TopupAmount,
                    Currency = request.currency,
                    MaxSpendLimit = _pay360Config.AutoTopupMaxSpendLimit,
                    ThresholdAmount = request.ThresholdAmount,
                }
            }, "Set Auto Top-Up With Card Successfull");
        }
        public async Task<GenericApiResponse<SetAutoRenewalWithCardPay360Resume3DResponseModel>> SetAutoRenewalWithCardResume3DTransaction(SetAutoRenewalWithCardPay360Resume3DRequestModel request)
        {
            var CountryCode = _phoneNumberService.GetCountryCode(request.customerMsisdn);

            var account = await _accountRepository.GetAccountDetailsBySipUsername("THA" + request.customerMsisdn);

            GenericApiResponse<Pay360PaymentResponse> paymentResponse;
            if (request.clientRedirectType.Contains("V2", StringComparison.CurrentCultureIgnoreCase))
            {
                paymentResponse = await _pay360Service.Resume3DTransactionV2(new Pay360Resume3DRequest()
                {
                    pay360TransactionId = request.MD,
                    customerEmail = request.customerEmail
                });
            }
            else
            {
                paymentResponse = await _pay360Service.Resume3DTransaction(new Pay360Resume3DRequest()
                {
                    pareq = request.PaRes,
                    pay360TransactionId = request.MD,
                    customerEmail = request.customerEmail
                });
            }

            if (paymentResponse == null)
            {
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(request.PTId, false, null, "Payment service not responding");
                return GenericApiResponse<SetAutoRenewalWithCardPay360Resume3DResponseModel>.Failure(null, "Payment service not responding",
                                                                                                ApiStatusCodes.PaymentServiceError);
            }
            var origination = _phoneNumberService.GetCountryCode(request.customerMsisdn);
            var errorResponse = new SetAutoRenewalWithCardPay360Resume3DResponseModel();

            if (paymentResponse.errorCode > 0)
            {
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(request.PTId, false, paymentResponse.payload?.transactionId, paymentResponse.message,true);
                _logger.Error($"Class: PaymentService, Method: SetAutoRenewalWithCardResume3DTransaction - PaymentResponse, " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(request)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<SetAutoRenewalWithCardPay360Resume3DResponseModel>.Failure(errorResponse,
                                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {

                    return GenericApiResponse<SetAutoRenewalWithCardPay360Resume3DResponseModel>.Failure(errorResponse,
                                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<SetAutoRenewalWithCardPay360Resume3DResponseModel>.Failure(errorResponse,
                                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            //Full-filment
            if (_pay360Config.IsDirectFullfilment == false)
            {
                try
                {
                    await Pay360CardPaymentFullfillment(paymentResponse, request.customerMsisdn, request.customerEmail, true);
                }
                catch (Exception ex)
                {
                    _logger.Error(
                            $"Class: Pay360_BL, " +
                            $"Method: Resume3d - PaymentFullfillment, " +
                            $"Parameters=> Request: {JsonConvert.SerializeObject(request)}, " +
                            $"ErrorMessage: {ex.Message}");
                }
            }
            var paymentRefundResponse=await _pay360Service.RefundFullPayment(new RefundFullPaymentRequestModel
            {
                transactionId = paymentResponse.payload.transactionId
            });
            await _PaymentFullfillment.UpdatePaymentTransactionAsync(request.PTId, true, paymentResponse.payload.transactionId,null, paymentRefundResponse.errorCode==0);

            await _bundleRepository.SetBundleAutoRenewal(true, request.customerMsisdn, account.AccountID, request.BundleId, false, PaymentMethods.Card, paymentResponse.payload.maskedPan, paymentResponse.payload.transactionId, null);

            return GenericApiResponse<SetAutoRenewalWithCardPay360Resume3DResponseModel>.Success("Set Auto Top-Up With Card Successfull");
        }

        public async Task<GenericApiResponse<PaypalPaymentResponseModel>> PaypalPayment(PaypalPaymentRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<PaypalPaymentResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string account = accountDetails.AccountID;
            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;
            var origination = _phoneNumberService.GetCountryCode(msisdn);
            //Get User registration Date
            float ChargeAmount;

            if (model.CheckoutType == CheckOutTypes.Bundle)
            {
                //Check Bundle Limit
                var bundlesResponse = await _accountRepository.GetBundlesHistory(account);
                if (bundlesResponse.Count() >= 10)
                {
                    return GenericApiResponse<PaypalPaymentResponseModel>.Failure("Max number of bundles purchased", ApiStatusCodes.BundleLimitExceeded);
                }

                //Get Bundle details
                var bundleResponse = await _bundleRepository.GetBundleById(model.BundleId);
                if (bundleResponse == null)
                {
                    return GenericApiResponse<PaypalPaymentResponseModel>.Failure("Invalid Bundle", ApiStatusCodes.InvalidBundle);
                }

                ChargeAmount = bundleResponse.TotalCostPence / 100;
            }
            else
            {
                ChargeAmount = model.TopUpAmount;
            }


            var promResponse = new PromotionPaymentDetails()
            {
                ChargeAmount = ChargeAmount,
                FullfilmentAmount = ChargeAmount
            };

            if (model.CheckoutType == CheckOutTypes.TopUp)
            {
                promResponse = await _promotionService.CheckAnyActivePromotions(
                   ChargeAmount,
                   msisdn,
                   PaymentMethodTypes.Paypal,
                   new PromotionDependentTypes[] { PromotionDependentTypes.Topup, PromotionDependentTypes.AutoTopup },
                   false
                   );
            }


            //Get user details
            var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);

            if (_payPalConfig.IsPaypalByPay360)
            {
                //Get User Registration Date
                var userRegistrationDate = await _accountRepository.GetUserRegistrationDate(account);

                PayPalByPay360CSPaymentRequest request = new PayPalByPay360CSPaymentRequest
                {
                    CustomerName = userResponse != null ? !string.IsNullOrEmpty(userResponse.firstname) ? userResponse.firstname : msisdn : msisdn,
                    CustomerEmail = model.EmailAddress,
                    CustomerMsisdn = msisdn,
                    CustomerUniqueRef = msisdn,
                    ProductCode = ProductCode.THA.ToString(),
                    isDirectFullfilment = _pay360Config.IsDirectFullfilment,
                    transactionCurrency = currency,
                    PaymentMethod = new PayPalByPay360PaymentMethod()
                    {
                        Paypal = new PayPalByPay360Urls()
                        {
                            returnUrl = _payPalConfig.TopupByPayPalReturnUrl.TopupPayPalByPay360ReturnUrl + "type=" + (int)model.CheckoutType + "&bundleId=" + model.BundleId + "&FromBundleISO2=" + model.FromBundleISO2 +
                                                        "&ToBundleISO2=" + model.ToBundleISO2 + "&BundleType=" + model.BundleType + "&Msisdn=" + model.Msisdn.Trim(),
                            cancelUrl = _payPalConfig.TopupByPayPalReturnUrl.TopupCancelUrl + "?CheckoutType=" + (int)model.CheckoutType + "&bundleId=" + model.BundleId + "&FromBundleISO2=" + model.FromBundleISO2 + "&TopUpAmount=" + ChargeAmount +
                                                        "&ToBundleISO2=" + model.ToBundleISO2 + "&BundleType=" + model.BundleType + "&Msisdn=" + model.Msisdn.Trim()
                        }
                    },
                    ipAddress = model.ipAddress,
                    Basket = new List<PayPalByPay360Basket>() {
                            new PayPalByPay360Basket()
                            {
                                amount =  promResponse.ChargeAmount,
                                bundleRef = model.CheckoutType == CheckOutTypes.Bundle ? model.BundleId:"",
                                productItemCode = ProductItemCode.THAATW.ToString(),
                                productRef = msisdn
                            }
                        },
                    transactionAmount = promResponse.ChargeAmount,
                    CustomFields = new PayPalByPay360CustomField()
                    {
                        fieldState = new List<PayPalByPay360FieldState>()
                            {
                                new PayPalByPay360FieldState() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
                                new PayPalByPay360FieldState() { name = "ProductItemCode", value = ProductItemCode.THAATW.ToString(), transient = false },
                                new PayPalByPay360FieldState() { name = "FirstUseDate", value = userRegistrationDate.ToString("yyyy-MM-dd"), transient = false  }
                            }
                    }
                };
                request.Basket.First().amount = promResponse.FullfilmentAmount;
                var PTId = await _PaymentFullfillment.InsertPaypalByPay360TransactionPayment(
                       request.Basket,
                       request.transactionCurrency,
                       request.CustomerEmail,
                       request.ProductCode,
                       null,
                       request.CustomerMsisdn,
                       Fullfillmenttype.Pay360Paypal,
                       0);
                request.PaymentMethod.Paypal.returnUrl += $"&PTId={PTId}";
                request.Basket.First().amount = promResponse.ChargeAmount;
                var paymentResponse = await _payPalService.PayPalByPay360CS(request);

                if (paymentResponse == null)
                {

                    await _PaymentFullfillment.UpdatePaymentTransactionAsync(PTId, false, null, "Payment service not responding");
                    return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                  "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }



                if (paymentResponse.errorCode > 0)
                {
                    await _PaymentFullfillment.UpdatePaymentTransactionAsync(PTId, false, paymentResponse.payload?.transactionId, paymentResponse.message);
                    _logger.Error($"Class: PaymentService, Method: PaypalPayment - PaymentResponse - V2, " +
                                            $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                            $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                    if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                    "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                    }
                    else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                                          paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                    }
                    else
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                            "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                    }
                }
                return GenericApiResponse<PaypalPaymentResponseModel>.Success(
                    new PaypalPaymentResponseModel()
                    {
                        clientRedirectUrl = paymentResponse.payload.clientRedirectUrl
                    }, "Payment created successfully");

            }
            else
            {
                var baskets = new List<ProductBasket>();
                var basket = new ProductBasket()
                {
                    Amount = ChargeAmount,
                    BundleRef = model.CheckoutType == CheckOutTypes.Bundle ? model.BundleId : "",
                    ProductItemCode = ProductItemCode.THAATW.ToString(),
                    ProductRef = msisdn
                };

                baskets.Add(basket);

                var request = new PayPalCreateSalePaymentRequest
                {
                    CustomerName = !string.IsNullOrEmpty(userResponse.firstname)
                                                            ? userResponse.firstname : msisdn,
                    CustomerMsisdn = msisdn,
                    CustomerUniqueRef = msisdn,
                    CustomerEmail = model.EmailAddress,
                    ProductCode = ProductCode.THA.ToString(),
                    Transaction = new Transactions()
                    {
                        Amount = new Amounts()
                        {
                            Total = ChargeAmount,
                            Currency = currency
                        },
                        Description = model.CheckoutType == CheckOutTypes.TopUp
                        ? "Topup payment request from THA-Web" : "Bundle payment request from THA-Web"
                    },
                    RedirectUrl = new RedirectUrls
                    {
                        ReturnUrl = _payPalConfig.TopupByPayPalReturnUrl.TopupPayPalReturnUrl + "type=" + (int)model.CheckoutType + "&bundleId=" + model.BundleId + "&Msisdn=" + model.Msisdn.Trim()
                        + "&TopUpAmount=" + ChargeAmount,
                        CancelUrl = _payPalConfig.TopupByPayPalReturnUrl.TopupCancelUrl + "checkoutType=" + (int)model.CheckoutType + "&bundleId=" + model.BundleId + "&Msisdn=" + model.Msisdn.Trim()
                        + "&TopUpAmount=" + ChargeAmount
                    },
                    Basket = baskets
                };
                var PTId = await _PaymentFullfillment.InsertPaypalTransactionPayment(
                       request.Basket,
                       currency,
                       request.CustomerEmail,
                       request.ProductCode,
                       null,
                       request.CustomerMsisdn,
                       Fullfillmenttype.Pay360Paypal,
                       0);
                request.RedirectUrl.ReturnUrl += $"&PTId={PTId}";
                var paymentResponse = await _payPalService.PayPalCreateSalePayment(request);

                if (paymentResponse == null)
                {
                    await _PaymentFullfillment.UpdatePaymentTransactionAsync(PTId, false, null, "Payment service not responding");
                    return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                  "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }

                if (paymentResponse.errorCode > 0)
                {
                    await _PaymentFullfillment.UpdatePaymentTransactionAsync(PTId, false, null, paymentResponse.message);

                    _logger.Error($"Class: PaymentService, Method: PaypalPayment - PaymentResponse - V1, " +
                                            $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                            $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                    if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                    "Your daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                    }
                    else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                                          paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                    }
                    else
                    {
                        return GenericApiResponse<PaypalPaymentResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                    }
                }

                return GenericApiResponse<PaypalPaymentResponseModel>.Success(
                    new PaypalPaymentResponseModel()
                    {
                        clientRedirectUrl = paymentResponse.payload.RedirectUrl
                    }, "Payment created successfully");
            }
        }
        public async Task<GenericApiResponse<PaypalPaymentCallBackResponseModel>> PaypalPaymentCallBack(
                                                                                        PaypalPaymentCallBackRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string msisdn = model.Msisdn;
            string currency = accountDetails.Currency;
            Bundles bundleResponse = null;
            var origin = _phoneNumberService.GetCountryCode(msisdn);

            if (model.type == CheckOutTypes.Bundle)
            {
                bundleResponse = await _bundleRepository.GetBundleById(model.bundleId);
            }
            var paymentResponse = await _payPalService.PayPalExecuteSalePayment(new PayPalExecuteSalePaymentRequest()
            {
                PayerId = model.PayerId,
                PaymentId = model.PaymentId,
                ProductCode = ProductCode.THA.ToString(),
                CustomerUniqueRef = msisdn
            });
            if (paymentResponse == null)
            {
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(model.PTId, false, null, "Payment service not responding");
                if (model.type == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(false, msisdn, false, false, false, 0, origin);
                }
                if (model.type == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents((int)bundleResponse.BundleType, bundleResponse.Description, origin, false, false, false, msisdn, 0, 0, currency);
                }
                return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Failure(null,
                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {
                if (model.type == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(false, msisdn, false, false, false, 0, origin);
                }
                if (model.type == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents((int)bundleResponse.BundleType, bundleResponse.Description, origin, false, false, false, msisdn, 0, 0, currency);
                }
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(model.PTId, false, paymentResponse.payload?.PaypalTransactionId, paymentResponse.message);

                _logger.Error($"Class: PaymentService, Method: PaypalPaymentCallBack - PaymentResponse, " +
                                             $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                             $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Failure(null,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Failure(null,
                                                    paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }
            await _PaymentFullfillment.UpdatePaymentTransactionAsync(model.PTId, true, paymentResponse.payload?.PaypalTransactionId, paymentResponse.message);

            if (model.type == CheckOutTypes.Bundle)
            {
                //Get Bundle details
                await HandleBundleEvents((int)bundleResponse.BundleType, bundleResponse.Description, origin, false, true, false, msisdn, accountDetails.Balance, bundleResponse.TotalCostPence / 100, currency);

                return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Success(new PaypalPaymentCallBackResponseModel()
                {
                    bundlePurchaseInfo = new BundlePurchaseInfo()
                    {
                        TransactionId = paymentResponse.payload.PaypalTransactionId,
                        BundleAmount = ((bundleResponse.TotalCostPence) / 100).ToString(),
                        BundleName = bundleResponse.BrandedName,
                        Msisdn = msisdn,
                        Currency = currency,
                        BundleType = bundleResponse.BundleType,
                        PaymentMethod = PaymentMethodTypes.Paypal,
                        Destination = bundleResponse.Description,
                        Origination = origin,
                        AutoRenew = false,
                    }

                }, "Bundle purchased successfully");
            }
            else
            {
                await HandleTopupEvents(false, msisdn, false, true, false, Convert.ToDecimal(model.TopUpAmount), origin);

                return GenericApiResponse<PaypalPaymentCallBackResponseModel>.Success(new PaypalPaymentCallBackResponseModel()
                {
                    topupInfo = new TopupInfo()
                    {
                        Msisdn = msisdn,
                        TransactionId = paymentResponse.payload.PaypalTransactionId,
                        Currency = currency,
                        AutoTopup = false,
                        Origination = origin,
                        PaymentMethod = PaymentMethodTypes.Paypal,
                    }
                }, "Top-Up Successfull");
            }
        }
        public async Task<GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>> PaypalByPay360PaymentCallBack(
                                                                                            PaypalByPay360PaymentCallBackRequestModel model)
        {
            var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.Msisdn);

            if (accountDetails == null)
            {
                return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Failure("Msisdn is invalid", ApiStatusCodes.InvalidNumber);
            }

            string msisdn = model.Msisdn;
            var origination = _phoneNumberService.GetCountryCode(msisdn);
            string currency = accountDetails.Currency;

            var paymentResponse = await _payPalService.PayPalByPay360ES(new PayPalByPay360ESPaymentRequest()
            {
                PaypalCheckoutToken = model.Token
            });
            string bundleName = "";
            int BundleType = 0;
            var bundleDestination = "";
            if (model.type == CheckOutTypes.Bundle)
            {
                var bundle = await _bundleRepository.GetBundleById(model.bundleId);
                bundleName = bundle.BrandedName;
                BundleType = Convert.ToInt32(bundle.BundleType);
                bundleDestination = bundle.Description;
            }

            if (paymentResponse == null)
            {
                if (model.type == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(false, msisdn, false, false, true, 0, origination);
                }
                if (model.type == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(BundleType, model.ToBundleISO2, model.FromBundleISO2, true, false, false, msisdn, 0, 0, currency);
                }

                await _PaymentFullfillment.UpdatePaymentTransactionAsync(model.PTId, false, null, "Payment service not responding");
                return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Failure(null,
                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {
                if (model.type == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(false, msisdn, false, false, true, 0, origination);
                }
                if (model.type == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(BundleType, model.ToBundleISO2, model.FromBundleISO2, true, false, false, msisdn, 0, 0, currency);
                }
                await _PaymentFullfillment.UpdatePaymentTransactionAsync(model.PTId, false, paymentResponse.payload?.transactionId, paymentResponse.message);
                _logger.Error($"Class: PaymentService, Method: PaypalByPay360PaymentCallBack - PaymentResponse, " +
                                             $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                             $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Failure(null,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Failure(null,
                                                    paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            await _PaymentFullfillment.UpdatePaymentTransactionAsync(model.PTId, true, paymentResponse.payload?.transactionId, paymentResponse.message);
            //Fullfilment
            if (_payPalConfig.IsDirectFullfilment == false)
            {
                try
                {
                    await Pay360PaypalPaymentFullfillment(paymentResponse, model.Msisdn, "");
                }
                catch (Exception ex)
                {
                    _logger.Error(
                            $"Class: Paymentservices, " +
                            $"Method: PaypalByPay360PaymentCallBack - PaymentFullfillment, " +
                            $"Parameters=> Request: {JsonConvert.SerializeObject(model)}, " +
                            $"ErrorMessage: {ex.Message}");
                }
            }




            //Events
            try
            {
                var transactionAmount = Convert.ToDecimal(paymentResponse.payload.transactionAmount);
                var customerResoonse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn.Trim());

                if (model.type == CheckOutTypes.TopUp)
                {
                    await HandleTopupEvents(false, msisdn, false, true, false, Convert.ToDecimal(paymentResponse.payload.transactionAmount), origination);
                }
                if (model.type == CheckOutTypes.Bundle)
                {
                    await HandleBundleEvents(BundleType, model.ToBundleISO2, model.FromBundleISO2, false, true, false, msisdn, customerResoonse.Balance, transactionAmount, currency);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentService, Method: PaypalByPay360PaymentCallBack-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }


            if (model.type == CheckOutTypes.Bundle)
            {
                return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Success(
                    new PaypalByPay360PaymentCallBackResponseModel()
                    {
                        bundlePurchaseInfo = new BundlePurchaseInfo()
                        {
                            TransactionId = paymentResponse.payload.transactionId,
                            BundleAmount = paymentResponse.payload.transactionAmount,
                            BundleName = bundleName,
                            Currency = currency,
                            Msisdn = msisdn,
                            BundleType = (BundleType)BundleType,
                            Destination = bundleDestination,
                            Origination = origination,
                            PaymentMethod = PaymentMethodTypes.Paypal,
                            AutoRenew = false
                        }

                    }, "Bundle purchased successfully");
            }
            else
            {
                return GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>.Success(new PaypalByPay360PaymentCallBackResponseModel()
                {
                    topupInfo = new TopupInfo()
                    {
                        TopupAmount = paymentResponse.payload.transactionAmount,
                        Msisdn = msisdn,
                        TransactionId = paymentResponse.payload.transactionId,
                        Currency = currency,
                        Origination = origination,
                        PaymentMethod = PaymentMethodTypes.Paypal,
                        AutoTopup = false,
                    }
                }, "Top-Up Successfull");
            }
        }
        private async Task<Pay360PaymentRequest> GeneratePay360PaymentRequest(Pay360PaymentRequestData model)
        {
            //Get User Registration Date
            var userRegistrationDate = await _accountRepository.GetUserRegistrationDate(model.accountNumber);

            List<fieldstate> _fieldState = new List<fieldstate>()
                {
                    new fieldstate() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
                    new fieldstate() { name = "ProductItemCode", value = ProductItemCode.THAATW.ToString(), transient = false },
                    new fieldstate() { name = "FirstUseDate", value = userRegistrationDate.ToString("yyyy-MM-dd"), transient = false },
                };

            List<basket> baskets = new List<basket>();

            if (model.CheckoutPaymentType == CheckOutTypes.Bundle)
            {
                basket basket = new basket()
                {
                    amount = model.Amount,
                    bundleRef = model.BundleId,
                    productItemCode = ProductItemCode.THAATW.ToString(),
                    productRef = model.CustomerMsisdn
                };

                baskets.Add(basket);
            }
            else
            {
                basket basket = new basket()
                {
                    amount = model.PromotionsDetails.ChargeAmount,
                    bundleRef = "",
                    productItemCode = ProductItemCode.THAATW.ToString(),
                    productRef = model.CustomerMsisdn
                };

                baskets.Add(basket);
            }

            Pay360PaymentRequest request = new Pay360PaymentRequest();

            switch (model.Pay360PaymentType)
            {
                case Pay360PaymentType.New:
                    request.Pay360PaymentRequestNew = new Pay360PaymentRequestNew();
                    request.Pay360PaymentRequestNew.basket = baskets;
                    request.Pay360PaymentRequestNew.customerName = model.CustomerCardData.NameOnCard;
                    request.Pay360PaymentRequestNew.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestNew.customerUniqueRef = model.CustomerUniqueRef;
                    request.Pay360PaymentRequestNew.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestNew.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestNew.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestNew.transactionAmount = model.PromotionsDetails.ChargeAmount;
                    request.Pay360PaymentRequestNew.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestNew.cardCv2 = model.CustomerCardData.SecurityCode;
                    request.Pay360PaymentRequestNew.cardExpiryDate = model.CustomerCardData.ExpiryMonth + model.CustomerCardData.ExpiryYear;
                    request.Pay360PaymentRequestNew.cardPan = model.CustomerCardData.CardNumber;
                    request.Pay360PaymentRequestNew.isDirectFullfilment = _pay360Config.IsDirectFullfilment;
                    request.Pay360PaymentRequestNew.isAuthorizationOnly = _pay360Config.IsAuthorization;
                    request.Pay360PaymentRequestNew.isDefaultCard = true;
                    request.Pay360PaymentRequestNew.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestNew.saveCard = model.ShouldSaveCard;
                    request.Pay360PaymentRequestNew.billingAddress = new billingAddress()
                    {
                        line1 = model.CustomerAddressData.AddressL1,
                        line2 = model.CustomerAddressData.AddressL2,
                        line3 = model.CustomerAddressData.AddressL3,
                        line4 = model.CustomerAddressData.AddressL4,
                        region = model.CustomerAddressData.Region,
                        city = model.CustomerAddressData.City,
                        postcode = model.CustomerAddressData.PostCode,
                        countryCode = model.CustomerAddressData.CountryCode
                    };
                    if (_pay360Config.IsBillingAndCustomerAddressSame == true)
                        request.Pay360PaymentRequestNew.customerBillingAddress = request.Pay360PaymentRequestNew.billingAddress;
                    break;
                case Pay360PaymentType.Token:
                    request.Pay360PaymentRequestToken = new Pay360PaymentRequestToken();
                    request.Pay360PaymentRequestToken.basket = baskets;
                    request.Pay360PaymentRequestToken.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestToken.customerUniqueRef = model.CustomerUniqueRef;
                    request.Pay360PaymentRequestToken.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestToken.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestToken.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestToken.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestToken.cardCv2 = model.SecurityCode;
                    request.Pay360PaymentRequestToken.transactionAmount = model.PromotionsDetails.ChargeAmount;
                    request.Pay360PaymentRequestToken.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestToken.isDirectFullfilment = _pay360Config.IsDirectFullfilment;
                    request.Pay360PaymentRequestToken.isAuthorizationOnly = _pay360Config.IsAuthorization;
                    request.Pay360PaymentRequestToken.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestToken.cardToken = model.CardToken;
                    break;
                case Pay360PaymentType.ExistingNew:
                    request.Pay360PaymentRequestExistingNew = new Pay360PaymentRequestExistingNew();
                    request.Pay360PaymentRequestExistingNew.basket = baskets;
                    request.Pay360PaymentRequestExistingNew.customerName = model.CustomerCardData.NameOnCard;
                    request.Pay360PaymentRequestExistingNew.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestExistingNew.customerUniqueRef = model.CustomerUniqueRef;
                    request.Pay360PaymentRequestExistingNew.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestExistingNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestExistingNew.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestExistingNew.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestExistingNew.cardCv2 = model.CustomerCardData.SecurityCode;
                    request.Pay360PaymentRequestExistingNew.transactionAmount = model.PromotionsDetails.ChargeAmount;
                    request.Pay360PaymentRequestExistingNew.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestExistingNew.cardExpiryDate = model.CustomerCardData.ExpiryMonth + model.CustomerCardData.ExpiryYear;
                    request.Pay360PaymentRequestExistingNew.cardPan = model.CustomerCardData.CardNumber;
                    request.Pay360PaymentRequestExistingNew.isDirectFullfilment = _pay360Config.IsDirectFullfilment;
                    request.Pay360PaymentRequestExistingNew.isAuthorizationOnly = _pay360Config.IsAuthorization;
                    request.Pay360PaymentRequestExistingNew.isDefaultCard = true;
                    request.Pay360PaymentRequestExistingNew.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestExistingNew.saveCard = model.ShouldSaveCard;
                    request.Pay360PaymentRequestExistingNew.billingAddress = new billingAddress()
                    {
                        line1 = model.CustomerAddressData.AddressL1,
                        line2 = model.CustomerAddressData.AddressL2,
                        line3 = model.CustomerAddressData.AddressL3,
                        line4 = model.CustomerAddressData.AddressL4,
                        region = model.CustomerAddressData.Region,
                        city = model.CustomerAddressData.City,
                        postcode = model.CustomerAddressData.PostCode,
                        countryCode = model.CustomerAddressData.CountryCode
                    };
                    break;
                case Pay360PaymentType.Default:
                    request.Pay360PaymentRequestDefault = new Pay360PaymentBase();
                    request.Pay360PaymentRequestDefault.basket = baskets;
                    request.Pay360PaymentRequestDefault.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestDefault.customerUniqueRef = model.CustomerUniqueRef;
                    request.Pay360PaymentRequestDefault.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestDefault.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestDefault.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestDefault.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestDefault.cardCv2 = model.SecurityCode;
                    request.Pay360PaymentRequestDefault.transactionAmount = model.PromotionsDetails.ChargeAmount;
                    request.Pay360PaymentRequestDefault.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestDefault.isDirectFullfilment = _pay360Config.IsDirectFullfilment;
                    request.Pay360PaymentRequestDefault.isAuthorizationOnly = _pay360Config.IsAuthorization;
                    request.Pay360PaymentRequestDefault.do3DSecure = _pay360Config.Do3DSecure;
                    break;
            }

            return request;
        }

        private string GetCountryNameByCountryCode(string code)
        {
            var completePath = Path.GetFullPath(Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot/CountriesName.json"));

            var json = System.IO.File.ReadAllText(completePath);

            var _countries = JsonConvert.DeserializeObject<CountriesData>(json);

            return _countries.countries.Where(x => x.IsoTwoCharacterCode.ToLower().Equals(code.ToLower())).First().Name.ToLower().Replace(" ", "").Trim();
        }

        private async Task Pay360CardPaymentFullfillment(
            GenericApiResponse<Pay360PaymentResponse> paymentResponse, string msisdn, string PaymentEmailAddress, bool isAuthorizeOnly=false)
        {
            string pay360TransactionId = paymentResponse.payload.transactionId;

            var basket = await _PaymentFullfillment.Getbasketitem(paymentResponse.payload.transactionId);
            foreach (var item in basket)
            {

                var ccAuthCode = pay360TransactionId;
                var CssTransId = pay360TransactionId;
                var amount = isAuthorizeOnly ? 0f : item.amount * 100;
                var bundleRef = item.bundleref;

                var result = await _PaymentFullfillment.
                    ThaPay360cardCustomerFullfilment(msisdn, (decimal)amount, CssTransId, ccAuthCode, bundleRef);

                if (result != null && result.ErrorCode == 0)
                {
                    await _PaymentFullfillment.UpdatePaymenttransactionsItemsAsync(true, item.id, null, true);


                    //if (PaymentEmailAddress != null && _SmtpConfig.sendEmailToCustomer)
                    //{
                    //    string customerEmailMsg = $"Talkhome App \r\nYou have successfully Topped Up. \r\nTop Up Amount: {newBalanceCurrency}{item.amount}\r\nTransaction Id: {pay360TransactionId}";
                    //    if (!string.IsNullOrWhiteSpace(item.bundleref))
                    //    {
                    //        customerEmailMsg = $"Talkhome App\r\nYou have successfully purchased a bundle. \r\nBundle Name: {result.BundleName} \r\nBundle Amount: {newBalanceCurrency}{item.amount}\r\nTransaction Id: {pay360TransactionId}";
                    //    }
                    //    await SendEmailToCustomer(PaymentEmailAddress, customerEmailMsg);
                    //}
                    if (!string.IsNullOrEmpty(PaymentEmailAddress) && _SmtpConfig.sendEmailToCustomer)
                    {
                        var userProfile = _accountRepository.GetUserByPhoneNumber(msisdn);
                        var profile = new DBUser();
                        if (userProfile?.Result != null)
                        {
                            profile = userProfile.Result;
                        }

                        //string customerEmailMsg = FormattableString.Invariant($"Talkhome App \r\nYou have successfully Topped Up. \r\nTop Up Amount: {newBalanceCurrency}{item.amount}\r\nTransaction Id: {pay360TransactionId}");
                        if (!string.IsNullOrWhiteSpace(item.bundleref) && !isAuthorizeOnly)
                        {
                            var bundleDetails = await _bundleRepository.GetBundleById(item.bundleref);
                            await SendBundlePaymentReceiptAsync(PaymentEmailAddress, bundleDetails, item.Transactioncurrency, profile, "Card");
                        }
                        else if (!isAuthorizeOnly)
                        {
                            await SendTopupPaymentReceiptAsync(PaymentEmailAddress, msisdn, (decimal)item.amount, item.Transactioncurrency, profile, "Card");
                        }
                    }

                }
                else
                {
                    await _PaymentFullfillment.UpdatePaymenttransactionsItemsAsync(false, item.id, result.ErrorMessage, false);
                }
            }

        }



        private async Task Pay360PaypalPaymentFullfillment(
            GenericPayPalApiResponse<PayPalByPay360ESPaymentResponse> paymentResponse, string msisdn, string PaymentEmailAddress)
        {
            string pay360TransactionId = paymentResponse.payload.transactionId;

            var basket = await _PaymentFullfillment.Getbasketitem(paymentResponse.payload.transactionId);

            foreach (var item in basket)
            {
                PaymentEmailAddress = item.Email;

                var ccAuthCode = pay360TransactionId;
                var CssTransId = pay360TransactionId;
                var amount = item.amount * 100;
                var bundleRef = item.bundleref;

                var result = await _PaymentFullfillment.ThaPay360paypalStraightCustomerFullfilment(CssTransId, bundleRef, (decimal)amount, msisdn);

                if (result != null && result.ErrorCode == 0)
                {
                    await _PaymentFullfillment.UpdatePaymenttransactionsItemsAsync(true, item.id, null, true);


                    if (!string.IsNullOrEmpty(PaymentEmailAddress) && _SmtpConfig.sendEmailToCustomer)
                    {
                        var userProfile = await _accountRepository.GetUserByPhoneNumber(msisdn);
                        var profile = new DBUser();
                        if (userProfile != null)
                        {
                            profile = userProfile;
                        }

                        //string customerEmailMsg = FormattableString.Invariant($"Talkhome App \r\nYou have successfully Topped Up. \r\nTop Up Amount: {newBalanceCurrency}{item.amount}\r\nTransaction Id: {pay360TransactionId}");
                        if (!string.IsNullOrWhiteSpace(item.bundleref))
                        {
                            var bundleDetails = await _bundleRepository.GetBundleById(item.bundleref);
                            await SendBundlePaymentReceiptAsync(PaymentEmailAddress, bundleDetails, item.Transactioncurrency, profile, "PayPal");
                        }
                        else
                        {
                            await SendTopupPaymentReceiptAsync(PaymentEmailAddress, msisdn, (decimal)item.amount, item.Transactioncurrency, profile, "PayPal");
                        }
                    }

                }
                else
                {
                    await _PaymentFullfillment.UpdatePaymenttransactionsItemsAsync(false, item.id, result.ErrorMessage, false);
                }
            }

        }
        private async Task<bool> SendEmailToCustomer(string customerEmail, string Message, bool IsHtmlBody = false)
        {
            try
            {
                SmtpClient client = new SmtpClient(_SmtpConfig.server);

                if (_SmtpConfig.userName != "" && _SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(_SmtpConfig.userName, _SmtpConfig.password);
                }



                //client.DeliveryMethod = SmtpDeliveryMethod.Network;
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(_SmtpConfig.fromForCustomer);
                mailMessage.To.Add(customerEmail);
                if (IsHtmlBody)
                {
                    mailMessage.IsBodyHtml = IsHtmlBody;
                }
                mailMessage.Body = Message;
                mailMessage.Subject = _SmtpConfig.subjectForCustomer;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Paymentservice, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }

        }
        private async Task SetAutoTopUpByCard(string msisdn, string currency,float TopupAmount,float ThresHoldAmount, Pay360PaymentResponse paymentResponse)
        {
            var response = await _autoTopupRepo.Get(msisdn);

            if (response != null)
            {
                await _autoTopupRepo.Set(new AutoTopupDetail
                {
                    Status = true,
                    ThresHold = ThresHoldAmount==-1?response.ThresHold:ThresHoldAmount,
                    Topup = TopupAmount==-1?response.Topup:TopupAmount,
                    Currency = currency,
                    Msisdn = msisdn,
                    PaymentMethod = PaymentMethods.Card,
                    CardInitialTransactionId = paymentResponse.recurring ? paymentResponse.transactionId : null,
                    CardMaskedPAN = paymentResponse.recurring ? paymentResponse.maskedPan : null,
                    PaypalSubscriptionId = null
                });
            }
        }
        private async Task SetAutoRenewalByCard(bool isRenew, string msisdn, string account, string bundleId, bool isTrial, Pay360PaymentResponse paymentResponse)
        {
            await _bundleRepository.SetBundleAutoRenewal(isRenew,
                msisdn,
                account,
                bundleId,
                isTrial,
                PaymentMethods.Card,
                paymentResponse.maskedPan,
                   paymentResponse.transactionId,
                     null);
        }
        private async Task SendTopupPaymentReceiptAsync(string PaymentEmailAddress, string msisdn, decimal amount, string currency, DBUser profile, string paymentMethod)
        {
            try
            {
                var accountDetails = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
                var builder = new BodyBuilder();
                using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\Topup-payment-reciept.html").Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();
                }


                string messageBody = builder.HtmlBody
                    .Replace("%FIRST_NAME%", profile.firstname)
                    .Replace("%EMAIL%", profile.email)
                    .Replace("%TIMESTAMP%", DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"))
                    .Replace("%PAYMENT_METHOD%", paymentMethod)
                    .Replace("%SOURCE%", "Top-Up")
                    .Replace("%AVAILABLE_BALANCE%", _helperService.ToMonetaryUnit(accountDetails.Balance, currency))
                    .Replace("%AMOUNT%", _helperService.ToMonetaryUnit(amount, currency));

                await SendEmailToCustomer(PaymentEmailAddress, messageBody, true);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Class: TransferService,Method: SendTopupPaymentReceiptAsync");
            }
        }
        private async Task SendBundlePaymentReceiptAsync(string PaymentEmailAddress, Bundles bundleDetails, string currency, DBUser profile, string paymentMethod)
        {
            try
            {
                var builder = new BodyBuilder();
                using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\Bundle-purchase-reciept.html").Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();
                }

                string messageBody = builder.HtmlBody
                    .Replace("%FIRST_NAME%", profile.firstname)
                    .Replace("%EMAIL%", profile.email)
                    .Replace("%BUNDLE_NAME%", bundleDetails?.BrandedName)
                    .Replace("%PAYMENT_METHOD%", paymentMethod)
                    .Replace("%COUNTRY%", GetCountryNameByCountryCode(bundleDetails?.Description).ToUpper())
                    .Replace("%TOTAL_MINUTES%", bundleDetails?.Minutes.ToString())
                    .Replace("%AMOUNT%", _helperService.ToMonetaryUnit((decimal)bundleDetails.TotalCostPence / 100, currency))
                    .Replace("%TIMESTAMP%", DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"));

                await SendEmailToCustomer(PaymentEmailAddress, messageBody, true);

            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Class: TransferService,Method: SendBundlePaymentReceiptAsync");
            }
        }

        private async Task HandleTopupEvents(Boolean IsAutoTopUp, string msisdn, Boolean ShouldSaveCard, bool IsSuccess, bool? IsCard, decimal transactionAmount, string CountryCode)
        {
            await _airShipService.HandleTopupTagsAndEvents(
           new TopupInfoAirship()
           {
               IsAutoTopUp = IsAutoTopUp,
               IsCard = IsCard,
               IsSuccess = IsSuccess,
               Msisdn = msisdn,
               SaveCard = ShouldSaveCard,
               Amount = Convert.ToString(transactionAmount),
               Origination = CountryCode
           }); ;
            await _faceBookService.HandleTopupEvents(msisdn, IsSuccess, IsCard, transactionAmount, "", CountryCode, IsAutoTopUp);

            await _appsFlyerService.HandleTopupEvents(msisdn, IsSuccess, IsCard, transactionAmount, "", CountryCode, IsAutoTopUp);


        }

        private async Task HandleBundleEvents(int bundleType, string Destination, string Origination, bool? IsCard, bool IsSuccess, bool ShouldSaveCard, string msisdn, decimal RemainingBalance, decimal Amount, string currency)
        {
            await _airShipService.HandleBundleTagsAndEvents(
                new BundleInfoAirShip()
                {
                    BundleType = bundleType,
                    Destination = Destination,
                    IsCard = IsCard,
                    IsSuccess = IsSuccess,
                    SaveCard = ShouldSaveCard,
                    Msisdn = msisdn,
                    Origination = Origination,
                    RemainingBalance = RemainingBalance,
                    Amount = Amount
                }); ;

            await _faceBookService.HandleBundlePurchaseEvents(msisdn, Origination, Destination, bundleType, IsSuccess, IsCard, Amount, RemainingBalance, currency);

            await _appsFlyerService.HandleBundlePurchaseEvents(msisdn, Origination, Destination, bundleType, IsSuccess, IsCard, Amount, RemainingBalance, currency);
        }
        private async Task HandleAutoTopupevents(string msisdn, bool isActive)
        {
            await _airShipService.HandleAutoTopup(msisdn, isActive);

            await _appsFlyerService.HandleAutoTopup(msisdn, isActive);
        }
    }
}