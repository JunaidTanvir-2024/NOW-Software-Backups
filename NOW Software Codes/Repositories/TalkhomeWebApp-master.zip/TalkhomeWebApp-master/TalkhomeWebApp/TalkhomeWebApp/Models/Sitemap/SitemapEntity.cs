﻿using System;
using System.Xml.Serialization;
using System.Collections.Generic;
namespace TalkhomeWebApp.Models
{
	[XmlRoot(ElementName = "url", Namespace = "https://www.sitemaps.org/schemas/sitemap/0.9")]
	public class Url
	{
		[XmlElement(ElementName = "loc", Namespace = "https://www.sitemaps.org/schemas/sitemap/0.9")]
		public string Loc { get; set; }
		[XmlElement(ElementName = "changefreq", Namespace = "https://www.sitemaps.org/schemas/sitemap/0.9")]
		public string Changefreq { get; set; }
		[XmlElement(ElementName = "priority", Namespace = "https://www.sitemaps.org/schemas/sitemap/0.9")]
		public string Priority { get; set; }
	}

	[XmlRoot(ElementName = "urlset", Namespace = "https://www.sitemaps.org/schemas/sitemap/0.9")]
	public class Urlset
	{
		[XmlElement(ElementName = "url", Namespace = "https://www.sitemaps.org/schemas/sitemap/0.9")]
		public List<Url> Url { get; set; }
		[XmlAttribute(AttributeName = "xmlns")]
		public string Xmlns { get; set; }
	}

}
