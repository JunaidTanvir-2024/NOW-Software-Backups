﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace PaymentsApi.Models.Contracts.Paypal.Request.User
{
    public class UserPaypalResumeRequest
    {
        [Required]
        [JsonProperty("PaypalCheckoutToken")]
        public string PaypalCheckoutToken { get; set; }
    }
}
