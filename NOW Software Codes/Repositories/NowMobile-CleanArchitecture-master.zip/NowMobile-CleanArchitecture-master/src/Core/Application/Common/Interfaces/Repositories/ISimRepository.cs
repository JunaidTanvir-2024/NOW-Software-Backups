﻿using Application.Features.Sim;
using Domain.Aggregate;

namespace Application.Common.Interfaces.Repositories;

public interface ISimRepository : ISerivcesType.IScopedService
{
    Task<int> ValidateSimOrder(string email, string addressL1, string postCode, string IpAddress);
    Task<int> FreeSimOrder(FreeSimOrder model, int MediumType);
    Task<int> PortInSimOrder(FreeSimOrder model);
    Task<long> CreditSimOrder(CreditSimOrder model,int MediumType);
    Task UpdateCreditSimOrderItem(long itemId, long creditSimOrderId, float amount, string bundleUUId);
    Task RemoveCreditSimOrderItem(long itemId);
    Task<IEnumerable<CreditSimOrderDetail>> GetCreditSimOrderDetails(long creditSimOrderId);
    Task<int> AddReplacementSimOrder(SimAddressInfo model, string msisdn, long userId);

    Task<DbResult<string>> UpdateCreditSimPayment(
            long userId,
            long orderId,
            PaymentMethod paymentMethod,
            string transactionId,
            bool isPaymentSuccess,
            string errorMessage,
            string errorCode);
}
