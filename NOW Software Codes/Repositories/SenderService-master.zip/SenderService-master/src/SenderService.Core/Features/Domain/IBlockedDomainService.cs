﻿using SenderService.Core.Features.Domain.Request;
using SenderService.Core.Features.Domain.Response;

namespace SenderService.Core.Features.Domain;
public interface IBlockedDomainService
{
    Task<long> AddBlockedDomainAsync(AddBlockedDomainRequest request);
    Task<BlockedDomainResponse> GetBlockedDomainByNameAsync(GetDomainByNameRequest request);
    Task<List<BlockedDomainResponse>> GetBlockedDomainsAsync();
}