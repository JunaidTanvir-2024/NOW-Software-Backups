﻿namespace THCC.Application.Features.User.Profile.UpdateProfileImage
{
    public class UpdateProfileImageResponse
    {
        public string ImagePath { get; set; } = default!;
    }
}
