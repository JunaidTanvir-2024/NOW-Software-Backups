﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.User.ForgotPassword.NewPassword;

public class NewPasswordRequest : IRequest<object>
{
    public string Password { get; set; } = default!;
    public string Email { get; set; } = default!;
    public string Otp { get; set; } = default!;
}

public class NewPasswordRequestValidator : AbstractValidator<NewPasswordRequest>
{
    public NewPasswordRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Password)
            .NotEmpty()
            .NotNull()
            .MinimumLength(6).WithMessage("Your password length must be at least 6.")
            .MaximumLength(20).WithMessage("Your password length must not exceed 20.")
            .Matches(@"[A-Z]+").WithMessage("Your password must contain at least one uppercase letter.")
            .Matches(@"[a-z]+").WithMessage("Your password must contain at least one lowercase letter.")
            .Matches(@"[0-9]+").WithMessage("Your password must contain at least one number.");

        RuleFor(data => data.Email)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
            .Must(p => commonService.IsValidEmailAddress(p))
            .WithMessage("Invalid email adddress");

        RuleFor(p => p.Otp)
            .NotEmpty()
            .NotNull()
            .MaximumLength(4).WithMessage("Your otp length must not exceed 4.");
    }
}
