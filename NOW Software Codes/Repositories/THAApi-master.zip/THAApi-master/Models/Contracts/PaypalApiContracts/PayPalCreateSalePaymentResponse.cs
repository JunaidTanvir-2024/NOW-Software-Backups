﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Models.Contracts.PaypalApiContracts
{
	public class PayPalCreateSalePaymentResponse
	{
		[JsonProperty("redirectUrl")]
		public string RedirectUrl { get; set; }
	}
}
