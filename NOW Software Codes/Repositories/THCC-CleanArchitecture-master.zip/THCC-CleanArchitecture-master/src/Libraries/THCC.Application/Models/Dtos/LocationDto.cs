﻿namespace THCC.Application.Models.Dtos
{
    public class LocationDto
    {
        public string? CountryName { get; set; }
        public string? CityName { get; set; }
    }
}
