﻿namespace THCC.Application.Features.User.Product.AddProduct
{
    public class AddProductRequest : IRequest<object>
    {
        public string CardNumber { get; set; } = default!;
        public string CardPin { get; set; } = default!;
    }
    public class AddProductRequestValidator : AbstractValidator<AddProductRequest>
    {
        public AddProductRequestValidator()
        {
            RuleFor(p => p.CardNumber)
                 .NotEmpty()
                 .NotNull()
                 .MaximumLength(20);

            RuleFor(p => p.CardPin)
                 .NotEmpty()
                 .NotNull()
                 .MaximumLength(20);
        }
    }
}
