﻿using SenderService.Core.Features.ProductCode.Request;
using SenderService.Core.Features.ProductCode.Response;
using SenderService.Core.Persistence.Repository;

namespace SenderService.Core.Features.ProductCode;
internal class ProductCodeService : IProductCodeService
{
    private readonly IProductCodeRepository _productCodeRepository;

    public ProductCodeService(IProductCodeRepository productCodeRepository)
    {
        _productCodeRepository = productCodeRepository;
    }

    public async Task<long> AddProductCodeAsync(AddProductCodeRequest request)
    {
        // Product and Product Item Chunk
        var productCode = new Persistence.Entities.ProductCode()
        {
            Code = request.Code,
            ItemCode = request.ItemCode,
        };

        var productCodeId = await _productCodeRepository.AddProductCodeAsync(productCode);
        return productCodeId;
    }
    public async Task<List<ProductCodeResponse>> GetProductCodesAsync()
    {
        var productCodes = (await _productCodeRepository.GetProductCodesAsync()).ToList();
        var result = productCodes.ConvertAll(x => new ProductCodeResponse()
        {
            Id = x.Id,
            Code = x.Code,
            ItemCode = x.ItemCode,
        });
        return result;
    }
    public async Task<ProductCodeResponse> GetProductCodeByIdAsync(GetProductCodeByIdRequest request)
    {
        var productCodeById = await _productCodeRepository.GetProductCodeByIdAsync(request.Id);
        var result = new ProductCodeResponse()
        {
            Id = productCodeById!.Id,
            Code = productCodeById?.Code,
            ItemCode = productCodeById?.ItemCode,
        };
        return result;
    }
}
