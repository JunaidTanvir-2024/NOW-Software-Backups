﻿using Models.Contracts;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface IEmail_DL
    {
        Task<GenericResult<bool>> AddEmailChannel(AddEmailChannelRequest emailChannel,string channelId);
    }
}
