﻿using Microsoft.Extensions.Configuration;
using System;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;

namespace TalkhomeAPI.JwtHelpers
{
    public static class JwtExtensions
    {
        public static void GenerateToken(this VerifyPinResponseModel verifyPinResponse, IConfiguration configuration)
        {
            var token = new JwtTokenBuilder()
                                 .AddSecurityKey(JwtSecurityKey.Create(configuration.GetSection("JWTConfig")["JwtSecretKey"]))
                                 .AddIssuer(configuration.GetSection("JWTConfig")["JwtIssuer"])
                                 .AddAudience(configuration.GetSection("JWTConfig")["JwtAudience"])
                                 .AddExpiryInDays(7)
                                 .AddClaim("msisdn", verifyPinResponse.User.Msisdn)
                                 .AddClaim("currency", verifyPinResponse.User.Currency)
                                 .AddClaim("accountId", verifyPinResponse.User.AccountID)
                                 .Build();

            verifyPinResponse.Token = token.Value;
            verifyPinResponse.ValidTo = token.ValidTo;
        }
    }
}
