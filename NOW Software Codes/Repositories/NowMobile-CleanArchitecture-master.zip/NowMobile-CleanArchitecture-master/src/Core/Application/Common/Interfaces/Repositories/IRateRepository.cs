using Application.Features.Rate.Model;

namespace Application.Common.Interfaces.Repositories;

public interface IRateRepository
{
    Task<List<InternationalRate>> GetInternationalRates();
    Task<RoamingRate> GetRoamingRates(int fromCountry, int toFrom);
    Task<List<UkRate>> GetUKRates();
}