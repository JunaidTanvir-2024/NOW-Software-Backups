﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Configurations
{
    public class TwoFactorAuthenticationConfig
    {
        public bool TwoFactorAuthentication { get; set; }
        public int TokenExpiryMinutes { get; set; }
    }
}
