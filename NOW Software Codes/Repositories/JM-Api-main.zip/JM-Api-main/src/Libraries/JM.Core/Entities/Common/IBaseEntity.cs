namespace JM.Core.Entities.Common;
public interface IBaseEntity<T>
{
    T Id { get; set; }
}
