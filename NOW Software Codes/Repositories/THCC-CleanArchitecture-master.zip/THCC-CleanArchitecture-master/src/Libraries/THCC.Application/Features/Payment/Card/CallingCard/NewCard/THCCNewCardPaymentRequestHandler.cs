﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Features.Payment.Card.CallingCard.NewCard;

public class THCCNewCardPaymentRequestHandler : IRequestHandler<THCCNewCardPaymentRequest, object>
{
    #region Fields

    private readonly IPaymentService _paymentService;
    private readonly ICurrentUser _currentUser;

    #endregion

    #region Ctors

    public THCCNewCardPaymentRequestHandler(
        IPaymentService paymentService,
        ICurrentUser currentUser)
    {
        _paymentService = paymentService;
        _currentUser = currentUser;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(THCCNewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        #region Trim Request

        request.PaymentCardInfo.NameOnCard = request.PaymentCardInfo.NameOnCard.Trim();
        request.PaymentCardInfo.CardNumber = request.PaymentCardInfo.CardNumber.Trim();
        request.PaymentCardInfo.SecurityCode = request.PaymentCardInfo.SecurityCode.Trim();
        request.PaymentCardInfo.ExpiryMonth = request.PaymentCardInfo.ExpiryMonth.Trim();
        request.PaymentCardInfo.ExpiryYear = request.PaymentCardInfo.ExpiryYear.Trim();

        request.PaymentAddressInfo.AddressL1 = request.PaymentAddressInfo.AddressL1!.Trim();
        request.PaymentAddressInfo.City = request.PaymentAddressInfo.City!.Trim();
        request.PaymentAddressInfo.PostCode = request.PaymentAddressInfo.PostCode!.Trim();
        request.PaymentAddressInfo.CountryCode = request.PaymentAddressInfo.CountryCode!.Trim();

        #endregion

        return await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: request.PaymentCardInfo,
            paymentAddressInfo: request.PaymentAddressInfo,
            paymentExistingCardInfo: null!,
            autoTopupInfo: null!,
            userInfo: new UserDto()
            {
                Id = _currentUser.GetUserId(),
                Email = _currentUser.GetUserEmail()
            },
            productType: ProductType.CallingCard,
            amount: request.Amount,
            cardNumber: null!);
    }

    #endregion
}