﻿namespace Application.Features.Account.ProductSummary;
public class ProductSummaryRequest : IRequest<Result<ProductSummaryResponse>>
{
    public string Msisdn { get; set; } = default!;
}
