﻿namespace THCC.Application.Models.Dtos
{
    public class FulfillmentItemDto
    {
        public int Id { get; set; }
        public string ProductItemCode { get; set; } = string.Empty;
        public float Amount { get; set; }
        public string ProductRef { get; set; } = string.Empty;
    }
}
