namespace Application.Features.Bundle.Model;


#region Bundle Info Model
public sealed class BundleInfo
{
    public int Id { get; set; }
    public string UuId { get; set; } = default!;
    public string DisplayName { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? CountryCode { get; set; }
    public int Category { get; set; }
    public int Type { get; set; }
    public decimal Price { get; set; }
    public decimal Discount { get; set; }
    public decimal TotalPrice { get; set; }
    public string? LocalMinutes { get; set; }
    public string? InternationalMinutes { get; set; }
    public bool LocalMinutesOrSms { get; set; }
    public bool InternationalMinutesOrSms { get; set; }
    public string? Data { get; set; }
    public string? DataUnit { get; set; }
    public string? LocalSms { get; set; }
    public string? InternationalSms { get; set; }
    public int ValidityDays { get; set; }
    public bool IsAddOn { get; set; }
    public bool IsSaverPlan { get; set; }
    public string? AddOnData { get; set; }
    public string? AddOnDataUnit { get; set; }
    public string? DisplayDescription { get; set; }
    public string? GoodyBagColorCode { get; set; }
    public bool IsAvailable { get; set; }
    public string? AddonPackageDescription { get; set; }
    public bool ShowBadge { get; set; }
    public string? BadgeDescription { get; set; }
    public bool ShowRenewal { get; set; }
    public bool IsPopular { get; set; }
    public string? CommissionGroup { get; set; }
    public int? NoOfRenewals { get; set; }
    public bool OfferExpired { get; set; } = false;
    public string? RoamingCap { get; set; }
    public bool IsSubscribed { get; set; } = false;
    public DateTime? NewBillingDate { get; set; }
    public bool IsChangePlan { get; set; } = false;
    public bool ShowChangePlan { get; set; } = false;
    public bool ShowCancelPlan { get; set; } = false;
    public BundleInfo? NewPlan { get; set; } = null;
    public bool Is12MonthAffiliate { set; get; } = false;
}
#endregion