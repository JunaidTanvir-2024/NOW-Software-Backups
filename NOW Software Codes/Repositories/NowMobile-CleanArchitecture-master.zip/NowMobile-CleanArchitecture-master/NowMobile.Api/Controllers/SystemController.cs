﻿using Application.Common.Enums;
using System.Reflection;

namespace NowMobile.Api.Controllers;

[Route("api/[controller]")]
[ApiController]
public class SystemController : VersionNeutralApiController
{
    [HttpGet("ErrorCodes"), AllowAnonymous]
    [OpenApiOperation("Get system error codes", "")]
    public IActionResult GetTopupAmounts()
    {
        var t = typeof(CustomStatusCode);
        var fields = t.GetFields(BindingFlags.Static | BindingFlags.Public);
#pragma warning disable CS8602 // Dereference of a possibly null reference.
        var list = fields.Select(x => new { Field = x.Name, Value = x.GetValue(null).ToString() });
#pragma warning restore CS8602 // Dereference of a possibly null reference.
        return Ok(list);
    }
}