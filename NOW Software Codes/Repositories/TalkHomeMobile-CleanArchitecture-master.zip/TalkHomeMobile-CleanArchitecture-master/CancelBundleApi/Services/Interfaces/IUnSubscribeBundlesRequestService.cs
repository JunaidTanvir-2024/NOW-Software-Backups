﻿using CancelBundleApi.Models.GenericModels;
using CancelBundleApi.Models.RequestModels;

namespace CancelBundleApi.Services.Interfaces;

public interface IUnSubscribeBundlesRequestService
{
    Task<Result<bool>> UnSubscribeService(UnSubscribeBundlesRequest request);
}
