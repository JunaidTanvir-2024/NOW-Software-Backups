namespace Application.Features.Account.Balance;

public class AccountBalanceRequest : IRequest<Result<AccountBalanceResponse>>
{
    public string Msisdn { get; set; } = default!;
}