﻿using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces;

public interface ICommonService : IServicesType.ITransientService
{
    bool IsValidMsisdn(string msisdn);
    bool IsValidEmailAddress(string email, bool useRegEx = false, bool requireDotInDomainName = false);
    bool IsWebRequest();
    (bool IsMobileRequest, DeviceType? DeviceType, MediumType MediumType) IsAppRequest();
    string FormatMsisdn(string msisdn);

    string GetBundleType(int bundleCategory, double bundleType);
    string GetCardLogo(string cardScheme);
    string GetCardScheme(string cardNumber);
    string GetCardMaskedPan(string cardNumber);
    string GetPaymentMethodName(int paymentMethod);
    string GetTransactionTypeName(int TransactionType);
    bool IsEUCountry(string code);
    Task<bool> VerifyCaptchaToken(string Token);
    string GetTotalDataSize(long byteCount);
    string GetDataSize(long byteCount);

}
