﻿using Newtonsoft.Json;

using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.ChangePassword;
public class ChangePasswordRequestHandler : IRequestHandler<ChangePasswordRequest, object>
{
    #region Fields

    private readonly ILogger _logger;
    private readonly IUserRepository _userRepository;
    private readonly IUserService _userService;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly IMailService _mailService;
    private readonly ILocationService _locationService;

    #endregion

    #region Ctor

    public ChangePasswordRequestHandler(
        ILogger logger,
        IUserRepository userRepository,
        IUserService userService,
        ICurrentUser currentUser,
        ICommonService commonService,
        IMailService mailService,
        ILocationService locationService)
    {
        _logger = logger;
        _userRepository = userRepository;
        _userService = userService;
        _currentUser = currentUser;
        _commonService = commonService;
        _mailService = mailService;
        _locationService = locationService;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(ChangePasswordRequest request, CancellationToken cancellationToken)
    {
        var user = await _userRepository.GetUserByEmailAsync(_currentUser.GetUserEmail());
        var isVerified = await _userService.VerifyPasswordAsync(user!, request.OldPassword);
        if (!isVerified)
        {
            return ErrorResult.Failure(CustomStatusKey.InvalidCredentials, CustomStatusCode.BadRequest);
        }
        var response = await _userService.ChangePasswordAsync(user!, request.NewPassword, request.OldPassword);
        if (response?.Succeeded == false)
        {
            _logger.Debug($"ChangePasswordRequestHandler: Failed change password for {user!.Email}: {JsonConvert.SerializeObject(response.Errors)}");
            return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
        }

        var location = await _locationService.GetLocationInfo();
        await _mailService.SendChangePasswordEmail(
              toEmail: _currentUser.GetUserEmail(),
              browser: location.Device!,
              ipAddress: location.IpAddress!,
              location: location?.CountryName == null ? null! : $"{location.CityName},{location.CountryName}");

        return Unit.Value;
    }

    #endregion
}
