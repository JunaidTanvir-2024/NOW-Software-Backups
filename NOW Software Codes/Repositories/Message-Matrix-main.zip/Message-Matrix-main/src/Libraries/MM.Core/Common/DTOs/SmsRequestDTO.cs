namespace MM.Core.Common.DTOs;
public class SmsRequestDTO
{
    public string? To { get; set; }
    public string TextMessage { get; set; }
    public string ProductCode { get; set; }
    public string Requestid { get; set; }
    public bool IsOptionMessage { get; set; }
}
