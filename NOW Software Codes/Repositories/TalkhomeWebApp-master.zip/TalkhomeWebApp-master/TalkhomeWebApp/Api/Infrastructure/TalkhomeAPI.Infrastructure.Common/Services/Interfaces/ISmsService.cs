﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface ISmsService
    {
        Task SendSms(int phoneCountryCode, string to, string textMessage);
        Task ReSendSms(int phoneCountryCode, string to, string textMessage);
    }
}
