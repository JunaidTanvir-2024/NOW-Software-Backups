﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TH.Models.Database
{
    public class TopupHistory
    {
        public DateTime date { get; set; }
        public decimal amount { get; set; }
        public string remarks { get; set; }
    }
}
