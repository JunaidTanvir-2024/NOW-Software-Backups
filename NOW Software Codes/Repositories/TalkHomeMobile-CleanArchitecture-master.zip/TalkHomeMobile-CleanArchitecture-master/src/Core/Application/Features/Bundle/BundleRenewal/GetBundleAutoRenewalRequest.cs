﻿using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.BundleRenewal;

public sealed class GetBundleAutoRenewalRequest:IRequest<Result<GetBundleAutoRenewalStatus>>
{
    public string Msisdn { get; set; } = default!;
    public string BundleId { get; set; } = default!;
}