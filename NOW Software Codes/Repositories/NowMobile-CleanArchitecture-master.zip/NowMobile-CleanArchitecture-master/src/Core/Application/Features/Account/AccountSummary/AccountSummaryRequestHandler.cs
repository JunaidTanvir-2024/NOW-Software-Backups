﻿using Application.Common.Settings;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using System.Security.Claims;

namespace Application.Features.Account.AccountSummary;
public class AccountSummaryRequestHandler : IRequestHandler<AccountSummaryRequest, Result<AccountSummaryResponse>>
{
    #region Fields

    private readonly IStringLocalizer<AccountSummaryRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;
    private readonly AppleReceiptVerificationSettings _appleReceiptVerificationSettings;
    private readonly ProfileSettings _profileSetting;
    private readonly CallBackSettings _callBackSettings;
    private readonly PaymentRenewalSettings _paymentRenewalSettings;

    #endregion

    #region Ctor

    public AccountSummaryRequestHandler(
         IStringLocalizer<AccountSummaryRequestHandler> localizer,
         IUnitOfWork unitOfWork,
         IMapper mapper,
         ICurrentUser currentUser,
         IOptions<CallBackSettings> callBackSettings,
         IOptions<AppleReceiptVerificationSettings> appleReceiptVerificationSettings,
         IOptions<ProfileSettings> profileSetting,
         IOptions<PaymentRenewalSettings> paymentRenewalSettings)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _currentUser = currentUser;
        _appleReceiptVerificationSettings = appleReceiptVerificationSettings.Value;
        _profileSetting = profileSetting.Value;
        _callBackSettings = callBackSettings.Value;
        _paymentRenewalSettings = paymentRenewalSettings.Value;
    }

    #endregion

    #region Methods

    public async Task<Result<AccountSummaryResponse>> Handle(AccountSummaryRequest request, CancellationToken cancellationToken)
    {
        var response = new AccountSummaryResponse();

        //hardcoded beacuse in-app payments not needed
        response.DisablePaymentVersion = "0.0.0.0";
        var user = await _unitOfWork.UserRepo.GetUserByIdAsync(_currentUser.GetUserId());
        response.UserInfo = _mapper.Map<UserInfo>(user!);
        if (!string.IsNullOrEmpty(response.UserInfo!.Image))
        {
            response.UserInfo!.Image = $"{_callBackSettings.WebBaseUrl}{_profileSetting.VirtualDirectoryName}/{user!.Id}/{user.Image}";
        }
        var products = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        if (products.Any())
        {
            var accounts = await _unitOfWork.UserRepo.GetAccountBalance(
                   string.Join(",", products.Where(x => x.Msisdn != null).Select(x => x.Msisdn.Trim())));
            var userProducts = _mapper.Map<IEnumerable<UserProductInfo>>(products).ToList();
            foreach (var item in userProducts)
            {
                if (accounts.Any() && item.Msisdn != null)
                {
                    var currentMsisdnAccount = products.First(x =>
                         x.Msisdn != null && x.Msisdn.Equals(item.Msisdn, StringComparison.InvariantCultureIgnoreCase)).AccountId;
                    if (!string.IsNullOrEmpty(currentMsisdnAccount))
                    {
                        var currentMsisdnData = accounts.FirstOrDefault(x => x.AccountId.Trim() == currentMsisdnAccount!.Trim());
                        if (currentMsisdnAccount != null && currentMsisdnData != null)
                        {
                            item.Balance = currentMsisdnData!.Balance;
                            string formatbal = item.Balance.ToString("F2"); // "4.50"
                            
                        }
                    }
                }
            }
            response.ProductInfo = userProducts;
        }
        else
        {
            response.ProductInfo = Enumerable.Empty<UserProductInfo>();
        }
        response.PaymentRenewalSettings.IsDefaultCard = _paymentRenewalSettings.IsDefaultCard;
        response.PaymentRenewalSettings.IsNewCard = _paymentRenewalSettings.IsNewCard;
        response.PaymentRenewalSettings.IsPaypal = _paymentRenewalSettings.IsPaypal;
        return Result<AccountSummaryResponse>.Success(response, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
