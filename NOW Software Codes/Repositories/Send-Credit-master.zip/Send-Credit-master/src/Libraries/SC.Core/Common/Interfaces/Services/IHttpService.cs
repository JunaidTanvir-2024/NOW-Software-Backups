﻿using SC.Core.DependencyResolver;

namespace SC.Core.Common.Interfaces.Services;
public interface IHttpService : ServiceType.IScoped
{
    Task<(bool IsFailure, string Json)> DeleteAsync(string requestUri);
    Task<(bool IsFailure, string Json)> GetAsync(string requestUri, object? queryParams = default);
    Task<(bool IsFailure, string Json)> PostAsync(string requestUri, object? data = default);
    Task<(bool IsFailure, string Json)> PutAsync(string requestUri, object? data = default);
    IHttpService EnableLogging();
    IHttpService WithBasicAuth(string? username, string? password);
    IHttpService WithBearerAuth(string? token);
    IHttpService BaseUrl(string baseUrl);
    IHttpService WithHeaders(IEnumerable<Dictionary<string, string>> headers);
    IHttpService SetVendor(AppEnums.Vendors vendor);
    IHttpService GetPaginationFromHeader(string totalPagesHeaderKey, string totalRecordHeaderKey);

}

