﻿using Application.Common.Interfaces.Payment;
using Application.Common.Interfaces.Repositories;
using Application.Common.Settings;
using Application.Features.AutoTopup;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;
using Microsoft.Extensions.Options;

namespace Application.Features.Payment.Card.NewCardPaymentV2;

public class NewCardPaymentRequestHandlerV2 : IRequestHandler<NewCardPaymentRequestV2, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly IMapper _mapper;
    private readonly ITopupRepository _topupRepo;
    private readonly IPayPalService _payPalService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly TopupSettings _topupSettings;

    public NewCardPaymentRequestHandlerV2(IPaymentService paymentService,
        IMapper mapper,
        ITopupRepository topupRepo,
        IPayPalService payPalService,
        IUnitOfWork unitOfWork,
        IOptions<TopupSettings> topupSettings
        )
    {
        _paymentService = paymentService;
        _mapper = mapper;
        _topupRepo = topupRepo;
        _payPalService = payPalService;
        _unitOfWork = unitOfWork;
        _topupSettings = topupSettings.Value;
    }

    public async Task<Result<CardResponse>> Handle(NewCardPaymentRequestV2 request, CancellationToken cancellationToken)
    {
        request.PaymentCardInfo.CardNumber = request.PaymentCardInfo.CardNumber!.Trim().Replace(" ","");
        var setAutoTopupInfo = _mapper.Map<PaymentTopupInfo>(request.TopupInfo!);
        if (setAutoTopupInfo?.AutoTopupInfo != null)
        {
            setAutoTopupInfo.AutoTopupInfo.ThresHoldAmount = _topupSettings.ThresholdAmount;
        }
        return await _paymentService.HandleCardPaymentRequest(
                request.PaymentCardInfo,
                null!,
                request.PaymentAddressInfo,
                setAutoTopupInfo!,
                request.BundleInfo!,
                request.CreditSimInfo!,
                request.Msisdn!,
                request.Email!,
                request.IpAddress!,
                null!,
                null!,
                false,
                request.ConversionID,
                (int) request.ConversionPlatFormID,
                request.IsRetry);
    }
}