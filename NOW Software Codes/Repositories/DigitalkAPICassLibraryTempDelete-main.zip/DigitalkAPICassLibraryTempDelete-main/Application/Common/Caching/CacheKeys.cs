﻿namespace Application.Common.Caching;

public static class CacheKeys
{
    public static string User { get { return "user"; } }
    public static string UserProduct { get { return "userprod"; } }
}
