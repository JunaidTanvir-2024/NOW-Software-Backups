
using DC.Core.Common.Definitions;
using DC.Core.Common.DependencyResolver;
using DC.Core.Common.DTOs.Vendors;
using DC.Core.Common.Extensions;
using DC.Core.Common.Setting;
using DC.Infrastructure.Sms.Common;
using DC.Infrastructure.Sms.DTOs;

using MapsterMapper;
namespace DC.Infrastructure.Sms;
internal interface ISmsIntegration : ServiceType.IScoped
{
    Task<bool> SendSMS(SMSDto.Request request);
}

internal sealed class SmsIntegration : ISmsIntegration
{
    private readonly IHttpService _httpService;
    private readonly SMSMarketingSetting _smsSetting;
    private readonly ILogger _logger;
    //private readonly IMapper _mapper;

    public SmsIntegration(
        IOptions<SMSMarketingSetting> _smsSetting,
        IHttpService httpService,
        ILogger logger)
    {
        _httpService = httpService.EnableLogging()
                                  .SetVendor(AppEnums.Vendor.MessageMatrix);
        this._smsSetting = _smsSetting.Value;
        _logger = logger;

    }
    public async Task<bool> SendSMS(SMSDto.Request request)
    {
        try
        {
            if (_smsSetting.IsAcitve == "true")
            {
                var apiRequestUrl = BuildRequestUrl(SmsMeta.Endpoints.MarketingSMS);

                var response = await _httpService.PostAsync(apiRequestUrl, request);
                return !response.IsFailure;
            }
            return false;

        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(SmsIntegration), nameof(SmsIntegration));
            return default;
        }
    }
    private string BuildRequestUrl(string endpointName, string? internalEndpointParam = null)
    {
        return !string.IsNullOrEmpty(internalEndpointParam) ? $"{string.Format(_smsSetting.BaseUrl, internalEndpointParam)}/{endpointName}" : $"{_smsSetting.BaseUrl}/{endpointName}";
    }
}

