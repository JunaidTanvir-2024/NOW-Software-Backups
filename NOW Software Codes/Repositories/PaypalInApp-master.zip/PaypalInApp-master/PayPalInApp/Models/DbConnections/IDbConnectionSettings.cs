﻿using System.Data;

namespace PayPalInApp.Models.DbConnections
{

    public interface IDbConnectionSettings
    {
        IDbConnection SqlConnection { get; }
    }
}
