﻿namespace THCC.Application.Models.Dtos
{
    public class OrderInfoJsonDto
    {
        public bool SaveCard { get; set; } = false;
        public string? CardMaskedPan { get; set; }
        public string? CardScheme { get; set; }
        public AutoTopupDto? AutoTopupDto { get; set; }
        public decimal RewardPoints { get; set; }
        public int RedeemPoints { get; set; }
        public decimal OpeningBalance { get; set; }
        public decimal ClosingBalance { get; set; }
        public decimal OpeningPoints { get; set; }
        public decimal ClosingPoints { get; set; }
        public string? Location { get; set; }
        public string? Browser { get; set; }
    }
}