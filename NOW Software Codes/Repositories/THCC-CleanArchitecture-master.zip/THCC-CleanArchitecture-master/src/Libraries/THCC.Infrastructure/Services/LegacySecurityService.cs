﻿using System.Security.Cryptography;

using THCC.Application.Extensions.Security;
using THCC.Application.Interfaces.Services;
using THCC.Domain.Entities;

namespace THCC.Infrastructure.Services
{
    public class LegacySecurityService : ILegacySecurityService
    {
        protected string HashPassword(string password, string hashingAlgorithm = "SHA512")
        {
            var hashedPassword = SHA.ComputeHash(password, hashingAlgorithm);
            return hashedPassword;
        }

        protected Dictionary<string, string> CreatePasswordAppendages()
        {
            // Define min and max salt sizes.
            int minSaltSize = 4;
            int maxSaltSize = 8;

            // Generate a random number for the size of the salt.
            Random random = new Random();
            int saltSize = random.Next(minSaltSize, maxSaltSize);

            // Allocate a byte array, which will hold the salt.
            byte[] saltBytesPrefix = new byte[saltSize];
            byte[] saltBytesSuffix = new byte[saltSize];

            // Initialize a random number generator.
#pragma warning disable SYSLIB0023 // Type or member is obsolete
            var rng = new RNGCryptoServiceProvider();
#pragma warning restore SYSLIB0023 // Type or member is obsolete

            // Fill the salt with cryptographically strong byte values.
            rng.GetNonZeroBytes(saltBytesPrefix);
            rng.GetNonZeroBytes(saltBytesSuffix);

            Dictionary<string, string> passwordAppendages = new Dictionary<string, string>();
            passwordAppendages.Add("prefix", Convert.ToBase64String(saltBytesPrefix));
            passwordAppendages.Add("suffix", Convert.ToBase64String(saltBytesSuffix));

            return passwordAppendages;
        }

        protected Dictionary<string, byte[]> EncryptPasswordAppendages(Dictionary<string, string> passwordAppendagesDict)
        {
#pragma warning disable SYSLIB0022 // Type or member is obsolete
            using var myRijndael = new RijndaelManaged();
#pragma warning restore SYSLIB0022 // Type or member is obsolete

            myRijndael.GenerateKey();
            myRijndael.GenerateIV();

            //string initVector = "@1B2c3D4e5F6g7H8"; // must be 16 bytes
            var cipherText = string.Empty;
            Dictionary<string, byte[]> encryptedAppendages = new Dictionary<string, byte[]>();
            byte[] aesKey, aesIv;

            aesKey = myRijndael.Key;
            aesIv = myRijndael.IV;

            foreach (var kvp in passwordAppendagesDict)
            {
                //RijndaelEnhanced rijndaelKey = new RijndaelEnhanced(kvp.Value, initVector);

                switch (kvp.Key.ToUpper())
                {
                    case "PREFIX":
                        var prefixCipherText = RijndaelEnhanced.EncryptStringToBytes(kvp.Value, aesKey, aesIv);
                        encryptedAppendages.Add("prefix", prefixCipherText);
                        break;
                    case "SUFFIX":
                        var suffixCipherText = RijndaelEnhanced.EncryptStringToBytes(kvp.Value, aesKey, aesIv);
                        encryptedAppendages.Add("suffix", suffixCipherText);
                        break;
                }
            }

            encryptedAppendages.Add("key", aesKey);
            encryptedAppendages.Add("iv", aesIv);
            return encryptedAppendages;
        }

        protected Dictionary<string, string> DecryptPasswordAppendages(Dictionary<string, byte[]> passwordAppendagesDict)
        {
            var cipherText = string.Empty;
            Dictionary<string, string> decryptedAppendages = new Dictionary<string, string>();
            byte[] key = passwordAppendagesDict["key"];
            byte[] iv = passwordAppendagesDict["iv"];

            foreach (var kvp in passwordAppendagesDict)
            {
                //RijndaelEnhanced rijndaelKey = new RijndaelEnhanced(kvp.Value, initVector);

                switch (kvp.Key.ToUpper())
                {
                    case "PREFIX":
                        var prefixCipherText = RijndaelEnhanced.DecryptStringFromBytes(kvp.Value, key, iv);
                        decryptedAppendages.Add("prefix", prefixCipherText);
                        break;
                    case "SUFFIX":
                        var suffixCipherText = RijndaelEnhanced.DecryptStringFromBytes(kvp.Value, key, iv);
                        decryptedAppendages.Add("suffix", suffixCipherText);
                        break;
                }
            }
            return decryptedAppendages;
        }

        protected string ConstructPassword(string password, Dictionary<string, string> passwordAppendagesDict)
        {
            string passwordWithAppendages = string.Empty;

            if (passwordAppendagesDict.ContainsKey("prefix") && passwordAppendagesDict.ContainsKey("suffix"))
            {
                passwordWithAppendages = passwordAppendagesDict["prefix"] + password + passwordAppendagesDict["suffix"];
            }
            else
            {
                throw new Exception("Prefix & suffix not found.");
            }

            return passwordWithAppendages;
        }

        protected bool IsValid(string receivedPasswordWithDecryptedSalt, string hashedPasswordFromDb, string hashingAlgorithm = "SHA512")
        {
            var isValid = SHA.VerifyHash(receivedPasswordWithDecryptedSalt, hashingAlgorithm, hashedPasswordFromDb);
            return isValid;
        }

        public bool CheckPassword(string pasword, LegacyUser user)
        {
            //Decrypt password
            Dictionary<string, byte[]> passwordAppendages = new()
        {
            { "prefix", user.PasswordPrefix },
            { "suffix", user.PasswordSuffix },
            { "key", user.Key },
            { "iv", user.IV }
        };

            var dPasswordAppendages = DecryptPasswordAppendages(passwordAppendages);
            var fullPassword = ConstructPassword(pasword, dPasswordAppendages);
            fullPassword = fullPassword.Replace("\0", "");

            //Check password validity
            bool isAuthenticated = IsValid(fullPassword, Convert.ToBase64String(user.Password));
            return isAuthenticated;
        }
    }
}
