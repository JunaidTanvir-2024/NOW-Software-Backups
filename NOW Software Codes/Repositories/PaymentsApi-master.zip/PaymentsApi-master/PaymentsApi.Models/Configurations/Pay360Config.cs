﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Configurations
{
    public class Pay360Config
    {
        public string ApiEndPoint { get; set; }
        public string ApiUserName { get; set; }
        public string ApiPassword { get; set; }
        public string ApiInstallationIdCashierApi { get; set; }
        public List<Pay60CountryAccountConfig> Pay60CountryAccountConfig { get; set; }
    }

    public class Pay60CountryAccountConfig
    {
        public string CountryCode { get; set; }
        public string ProductCode { get; set; }
        public string PaymentType { get; set; }
        public string ApiUserName { get; set; }
        public string ApiPassword { get; set; }
        public string ApiInstallationIdCashierApi { get; set; }
    }

    public enum Pay360PaymentType
    {
        CARD,
        PAYPAL
    }
}
