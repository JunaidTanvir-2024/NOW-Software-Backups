namespace Application.Common.Interfaces.Shared;

public interface ISerivcesType
{
    public interface IScopedService { }
    public interface ISingletonService { }
    public interface ITransientService { }
}