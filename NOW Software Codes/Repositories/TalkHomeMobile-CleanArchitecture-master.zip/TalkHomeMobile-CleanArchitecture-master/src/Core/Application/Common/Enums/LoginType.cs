﻿namespace Application.Common.Enums;

public enum LoginType : byte
{
    Email = 1,
    PhoneNumber = 2
}