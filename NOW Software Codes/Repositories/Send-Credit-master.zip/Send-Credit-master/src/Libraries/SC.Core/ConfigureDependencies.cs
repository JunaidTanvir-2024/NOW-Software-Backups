﻿using Mapster;
using MapsterMapper;
using MassTransit;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using SC.Core.Common.MessageEvents;
using SC.Core.Features.Countries.Requests;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.Operators;
using SC.Core.Features.PaymentMethod;
using SC.Core.Features.Products;
using SC.Core.MessageBroker;

namespace SC.Core;
public static class ConfigureDependencies
{
    public static IServiceCollection AddCoreDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.RegisterJsonSettings(configuration);
        services.RegisterCoreServices();
        services.RegisterRequestValidators();
        services.RegisterMapsterConfiguration();
        //services.RegisterMessageConsumerEvents(configuration);
        return services;
    }

    private static IServiceCollection RegisterCoreServices(this IServiceCollection services)
    {
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
        services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
        return services;
    }
    private static IServiceCollection RegisterMapsterConfiguration(this IServiceCollection services)
    {
        var mapperConfiguration = TypeAdapterConfig.GlobalSettings;
        mapperConfiguration.Scan(Assembly.GetExecutingAssembly());
        services.AddSingleton(mapperConfiguration);
        services.AddScoped<IMapper, ServiceMapper>();
        return services;
    }
    //private static IServiceCollection RegisterMessageConsumerEvents(this IServiceCollection services, IConfiguration configuration)
    //{
    //    var messageBrokerSetting = configuration.GetSection(MessageBrokerSetting.SectionName)
    //                                         .Get<MessageBrokerSetting>();

    //    services.AddMassTransit(config =>
    //    {
    //        // Configure all consumers withing assebmly
    //        config.AddConsumers(Assembly.GetExecutingAssembly());
    //        //config.AddConsumer<OrderConsumer>();
    //        config.UsingRabbitMq((context, config) =>
    //        {
    //            config.Host(messageBrokerSetting!.Host, messageBrokerSetting!.Port, messageBrokerSetting!.VirtualHost, h =>
    //            {
    //                h.Username(messageBrokerSetting!.UserName);
    //                h.Password(messageBrokerSetting!.Password);
    //            });
    //            // Configure endpoints to receive message from publisher
    //            config.ReceiveEndpoint(messageBrokerSetting!.Queue, configureEndpoint: e =>
    //            {
    //                e.ConfigureConsumer<OrderConsumer>(context);
    //            });
    //        });
    //    });
    //    return services;
    //}

    private static IServiceCollection RegisterRequestValidators(this IServiceCollection services)
    {
        services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
        return services;
    }
    private static IServiceCollection RegisterJsonSettings(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<MessageBrokerSetting>(configuration.GetSection(MessageBrokerSetting.SectionName));
        return services;
    }

}

