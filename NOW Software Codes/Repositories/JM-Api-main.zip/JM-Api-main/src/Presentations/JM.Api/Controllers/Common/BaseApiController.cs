using Mediator;

using Microsoft.AspNetCore.Mvc;

namespace JM.Api.Controllers.Common;

[ApiController]
[ApiExplorerSettings(GroupName = "Journey Mingle")]
[Route("api/v{version:apiVersion}/[controller]")]
public abstract class BaseApiController : ControllerBase
{
    private ISender _mediator = null!;
    protected ISender Mediator => _mediator ??= HttpContext.RequestServices.GetRequiredService<ISender>();
}
