using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Rewards;

public class RewardAssignment
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("reward_id")]
    public string? RewardId { get; set; }

    [JsonPropertyName("related_object_id")]
    public string? CampaignId { get; set; }

    [JsonPropertyName("parameters")]
    public RewardParametersAssignment? Parameters { get; set; }

}