﻿using Dapper;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using TransferHome.Infrastructure.DAL.Interfaces;
using TransferHome.Models.DAOs;
using TrasnferHome.Models.Configurations;
using TrasnferHome.Models.DbConnections;
using Serilog;
using Newtonsoft.Json;
using TransferHome.Models.Contracts.Request;

namespace TransferHome.Infrastructure.DAL.Impelmentation
{
    public class DL_Transfer : IDL_Transfer
    {
        private readonly IDbConnectionSettings ATTDb;
        private readonly IDbConnectionSettings TransferHomeDb;
        private readonly ILogger Logger;

        public DL_Transfer(IOptions<ConnectionString> connectionString, ILogger logger)
        {
            ATTDb = new DbConnectionSettings(new SqlConnection(connectionString.Value.ATTDbConnection));
            TransferHomeDb = new DbConnectionSettings(new SqlConnection(connectionString.Value.TransferHomeDbConnection));
            Logger = logger;
        }

        public async Task<DBProduct> GetProductByNowtelTransactionReference(string guid, string product)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@guid", guid);
                parameters.Add("@product", product);

                return await ATTDb.SqlConnection.QueryFirstOrDefaultAsync<DBProduct>("[dbo].[at_getAPIAccessGUIDRecord_Trh]", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<int> SaveTransferTransaction(DBTransferTransactions model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserId", model.UserId);
                parameters.Add("@NowtelTransactionReference", model.NowtelTransactionReference);
                parameters.Add("@OperatorId", model.OperatorId);
                parameters.Add("@TransactionTypeId", (int)model.TransactionTypeId);
                parameters.Add("@PaymentTypeId", (int)model.PaymentTypeId);
                parameters.Add("@ClientCurrency", model.ClientCurrecny);
                parameters.Add("@ReceiverCurrency", model.ReceiverCurrecny);
                parameters.Add("@Product", model.Product);
                parameters.Add("@ItemPrice", model.ItemPrice);
                parameters.Add("@TotalPrice", model.TotalPrice);
                parameters.Add("@OperatorCountryName", model.OperatorCountryName);
                parameters.Add("@CountryCode", model.CountryCode);
                parameters.Add("@OperatorLogoUrl", model.OperatorLogoUrl);
                parameters.Add("@OperatorName", model.OperatorName);
                parameters.Add("@ExecuteReferenceNumber", model.ExecuteReferenceNumber);
                parameters.Add("@StatusId", (int)model.StatusId);
                parameters.Add("@FromMsisdn", model.FromMsisdn);
                parameters.Add("@ToMsisdn", model.ToMsisdn);

                int result = await TransferHomeDb.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_SaveTransferTransaction]", parameters, commandType: CommandType.StoredProcedure);
                if (result > 0)
                {
                    return result;
                }
                else
                {
                    Logger.Error($"Class: DL_Transfer, Method: SaveTransferTransaction, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: unable to save transaction into database");
                    return 0;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Transfer, Method: SaveTransferTransaction, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return 0;
            }
        }

        public async Task<int> UpdateTransferTransaction(DBTransferTransactions model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@Id", model.Id);
                parameters.Add("@ExecuteReferenceNumber", model.ExecuteReferenceNumber);
                parameters.Add("@StatusId", (int)model.StatusId);

                return await TransferHomeDb.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_UpdateTransferTransaction]", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<int> DebitUserBalance(DbDebit model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserId", model.UseId);
                parameters.Add("@Amount", model.Amount);
                parameters.Add("@ToupUpTypeId", (int)model.type);
                parameters.Add("@Currency", model.Currency);

                int result = await TransferHomeDb.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_DebitUserBalance]", parameters, commandType: CommandType.StoredProcedure);
                if (result > 0)
                {
                    return result;
                }
                else
                {
                    Logger.Error($"Class: DL_Transfer, Method: DebitUserBalance, Parameters=> userId: {model.UseId}, amount: {model.Amount}, ErrorMessage: unable to save transaction into database");
                    return 0;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Transfer, Method: DebitUserBalance, Parameters=> userId: {model.UseId}, amount: {model.Amount}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return 0;
            }
        }

        public async Task<decimal> CreditUserBalance(DBCredit model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserId", model.UseId);
                parameters.Add("@Amount", model.Amount);
                parameters.Add("@ToupUpTypeId", (int)model.type);
                parameters.Add("@Currency", model.Currency);
                parameters.Add("@TransactionReferenceNumber", model.TransactionNumber);

                var result = await TransferHomeDb.SqlConnection.QueryFirstOrDefaultAsync<decimal>("[dbo].[Transferhome_Api_Common_CreditUserBalance]", parameters, commandType: CommandType.StoredProcedure);
                if (result > 0)
                {
                    return result;
                }
                else
                {
                    Logger.Error($"Class: DL_Transfer, Method: CreditUserBalance, Parameters=> userId: {model.UseId}, amount: {model.Amount}, transactionNumber: {model.TransactionNumber}, ErrorMessage: unable to save transaction into database");
                    return 0;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: DL_Transfer, Method: CreditUserBalance, Parameters=> userId: {model.UseId}, amount: {model.Amount}, transactionNumber: {model.TransactionNumber}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return 0;
            }
        }

        public async Task<int> SaveTwoFactorAuthenticationToken(DBTwoFactorAuthenticationToken model)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@Token", model.Token);
            parameters.Add("@TokenTypeId", (int)model.TokenTypeId);
            parameters.Add("@UserId", model.UserId);
            parameters.Add("@NowtelTransactionReference", model.NowtelTransactionReference);

            return await TransferHomeDb.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_SaveTwoFactorAuthenticationToken]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> VerifyTwoFactorToken(DBTwoFactorAuthenticationToken model)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@Token", model.Token);
            parameters.Add("@TokenTypeId", (int)model.TokenTypeId);
            parameters.Add("@UserId", model.UserId);
            parameters.Add("@NowtelTransactionReference", model.NowtelTransactionReference);
            parameters.Add("@ExpiryMinutes", model.ExpiryMinutes);

            return await TransferHomeDb.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_VerifyAuthenticationToken]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> SaveAutoTransferSettings(DBAutoTransfer model)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@UserId", model.UserId);
            parameters.Add("@PaymentTypeId", (int)model.PaymentType);
            parameters.Add("@RegularityId", model.RegularityType);
            parameters.Add("@NowtelTransactionReference", model.NowtelTransactionReference);
            parameters.Add("@OperatorId", model.OperatorId);
            parameters.Add("@Product", model.Product);
            parameters.Add("@FromMsisdn", model.FromMsisdn);
            parameters.Add("@RequestedDateTime", model.RequestDateTime);
            parameters.Add("@LastTransactionExecutionDateTime", model.LastTransactionExecutionDateTime);

            return await TransferHomeDb.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_SaveAutoTransferSettings]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<DBAutoTransfer>> GetUserAutoTransferNumbers(int userId)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@UserId", userId);

            return await TransferHomeDb.SqlConnection.QueryAsync<DBAutoTransfer>("[dbo].[Transferhome_Api_Common_GetUserAutoTransferNumbers]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<DBAutoTransfer> UpdateAutoTransferStatus(int id, bool status, int userId)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@Status", status);
            parameters.Add("@UserId", userId);
            parameters.Add("@Id", id);

            return await TransferHomeDb.SqlConnection.QueryFirstOrDefaultAsync<DBAutoTransfer>("[dbo].[Transferhome_Api_Common_UpdateAutoTransferStatus]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> RemoveAutoTransferNumber(int id, int userId)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@UserId", userId);
            parameters.Add("@Id", id);

            return await TransferHomeDb.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_RemoveAutoTransferNumber]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> UpdateAutoTransferSettings(UpdateAutoTransferSettingsRequestModel model, int userId)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@UserId", userId);
            parameters.Add("@RegularityId", model.RegularityTypeId);
            parameters.Add("@Id", model.Id);

            return await TransferHomeDb.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_UpdateAutoTransferSettings]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> ValidateTransferRequest(int userId, decimal amount)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", userId);
            parameters.Add("@Amount", amount);
            parameters.Add(name: "@RetVal", dbType: DbType.Int32, direction: ParameterDirection.ReturnValue);

            await TransferHomeDb.SqlConnection.ExecuteAsync("Transferhome_Api_Common_ValidateTransferRequest", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@RetVal");
        }
    }
}
