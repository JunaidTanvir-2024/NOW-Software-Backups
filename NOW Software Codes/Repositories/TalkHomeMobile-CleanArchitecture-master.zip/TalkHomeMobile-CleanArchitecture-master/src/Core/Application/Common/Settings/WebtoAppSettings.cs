﻿namespace Application.Common.Settings;

public class WebtoAppSettings
{
    public const string SectionName = "WebtoAppSettings";
    public static WebtoAppSettings Bind = new WebtoAppSettings();
    public bool IsActive { get; set; } = false;
}
