﻿using THCC.Application.Settings;

namespace THCC.Application.Features.Payment.PayPal.Topup
{
    public class PaypalTopupRequest : IRequest<object>
    {
        public decimal Amount { get; set; }
        public string CardNumber { get; set; } = default!;
    }

    public class TopupRequestValidator : AbstractValidator<PaypalTopupRequest>
    {
        public TopupRequestValidator(IOptions<TopupSettings> topupSettings)
        {
            RuleFor(p => p.Amount).Cascade(CascadeMode.Stop)
              .NotEmpty()
              .NotNull()
              .Must(x => topupSettings.Value.Amounts.Any(a => a.Amount == x))
              .WithMessage("Please only use: " + string.Join(",", values: topupSettings.Value.Amounts.Select(a => a.Amount)));

            RuleFor(p => p.CardNumber)
                 .NotEmpty()
                 .NotNull()
                 .MaximumLength(20);
        }
    }
}
