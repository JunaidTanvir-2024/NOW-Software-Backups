﻿namespace Application.Features.Account.Product.Add;
public class AddProductRequestValidator : AbstractValidator<AddProductRequest>
{
    public AddProductRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");

        RuleFor(p => p.Alias).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull();
    }
}
