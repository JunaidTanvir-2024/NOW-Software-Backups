using Application.Features.Bundle.AutoRenewal.ExistingCard;
using Application.Features.Bundle.AutoRenewal.NewCard;
using Application.Features.Bundle.Bundle;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Bundle.BundleRenewal;
using Application.Features.Bundle.BundleRenewalPaypal;
using Application.Features.Bundle.DataBundle;
using Application.Features.Bundle.InternationalBundle;
using Application.Features.Bundle.NationalBundle;
using Application.Features.Bundle.PurchaseBundle.PurchaseBundleBySimCredit;
using Application.Features.Bundle.SimBundle;
using Application.Features.Bundle.SubscribedBundle;
using Application.Features.Bundle.SuggestedBundle;

namespace NowMobile.Api.Controllers;

public class BundleController : VersionedApiController
{
    [HttpGet]
    [OpenApiOperation("Get bundles.", "")]
    public async Task<IActionResult> GetBundles([FromQuery] BundlesRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpGet("{Id}")]
    [OpenApiOperation("Get bundle by Id.", "")]
    public async Task<IActionResult> GetBundleById([FromRoute] BundleByIdRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpGet("Sim"), AllowAnonymous]
    [OpenApiOperation("Get sim bundles.", "")]
    public async Task<IActionResult> GetSimBundles()
    {
        return Ok(await Mediator.Send(new SimBundleRequest()));
    }

    [HttpGet("Data")]
    [OpenApiOperation("Get data bundles.", "")]
    public async Task<IActionResult> GetDataBundles([FromQuery] DataBundleRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpGet("International")]
    [OpenApiOperation("Get all international bundles or by country code.", "")]
    public async Task<IActionResult> GetInternationalBundles([FromQuery] InternationalBundleRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpGet("National")]
    [OpenApiOperation("Get national bundles.", "")]
    public async Task<IActionResult> GetNationalBundles([FromQuery] NationalBundleRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    //[HttpGet("National/Rolling")]
    //[OpenApiOperation("Get national rolling bundles.", "")]
    //public async Task<IActionResult> GetNationalRollingBundles([FromQuery] NationalRollingBundleRequest request)
    //{
    //    return Ok(await Mediator.Send(request));
    //}

    //[HttpGet("National/PAYG")]
    //[OpenApiOperation("Get national pay as you go bundles.", "")]
    //public async Task<IActionResult> GetNationalPayAsYouGoBundles([FromQuery] NationalPayAsYouGoBundleRequest request)
    //{
    //    return Ok(await Mediator.Send(request));
    //}

    [HttpGet("Suggested")]
    [OpenApiOperation("Get suggested bundles.", "")]
    public async Task<IActionResult> GetSuggestedBundles([FromQuery] SuggestedBundleRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpGet("Subscribed")]
    [OpenApiOperation("Get subscribed bundles.", "")]
    public async Task<IActionResult> GetSubscribedBundles([FromQuery] SubscribedBundleRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("Purchase/SimCredit")]
    [OpenApiOperation("Purchase bundle by sim credit.", "")]
    public async Task<IActionResult> BundlePurchaseBySimCredit([FromBody] PurchaseBundleBySimCreditRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("Renewal")]
    [OpenApiOperation("set bundle auto renewal", "")]
    public async Task<IActionResult> BundleAutoRenewal([FromBody] BundleAutoRenewalRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("Renewal/NewCard")]
    [OpenApiOperation("set bundle auto renewal via new card", "")]
    public async Task<IActionResult> BundleAutoRenewalNewCard([FromBody] AutoRenewalNewCardRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("Renewal/ExistingCard")]
    [OpenApiOperation("set bundle auto renewal via existing card", "")]
    public async Task<IActionResult> BundleAutoRenewalExisting([FromBody] AutoRenewalExistingCardRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("Renewal/Paypal")]
    [OpenApiOperation("set bundle auto renewal", "")]
    public async Task<IActionResult> BundleAutoRenewalByPaypal([FromBody] BundleAutoRenewalPaypalRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    private string GetIpAddress() =>
    Request.Headers.ContainsKey("X-Forwarded-For")
        ? Request.Headers["X-Forwarded-For"]
        : HttpContext.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "N/A";

}