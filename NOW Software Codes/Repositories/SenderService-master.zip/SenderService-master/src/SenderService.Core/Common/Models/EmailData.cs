﻿namespace SenderService.Core.Common.Models;
public class EmailData
{
    public long Id { get; set; }

    public string FromEmail { get; set; } = default!;

    public string? FromName { get; set; }

    public string? Subject { get; set; }

    public string? Body { get; set; }

    public int Attempts { get; set; }

    public byte Priority { get; set; }

    public byte ProcessingStatus { get; set; }

    public DateTime CreatedOnUtc { get; set; }

    public bool IsSent { get; set; }

    public DateTime SentDateTimeUtc { get; set; }

    public DateTime LastAttemptDateTimeUtc { get; set; }

    public string? ErrorMessage { get; set; }

    public long ProductCodeId { get; set; }

    public string EmailAddress { get; set; } = default!;

    public byte RecipientType { get; set; }

    public string? ItemCode { get; set; }

    public string? Code { get; set; }
}
