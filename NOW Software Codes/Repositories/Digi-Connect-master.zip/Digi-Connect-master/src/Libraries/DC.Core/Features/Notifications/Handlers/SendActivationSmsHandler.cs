using DC.Core.Common.Definitions;
using DC.Core.Common.Entities;
using DC.Core.Common.Helpers;
using DC.Core.Common.Interfaces.Database;
using DC.Core.Features.HangFire;
using DC.Core.Features.Notifications.Requests;

using Serilog;

namespace DC.Core.Features.Notifications.Handlers;
internal class SendActivationSmsHandler : IRequestHandler<SendActivationSmsRequest, IResultWrapper>
{

    private readonly IDigiConnectRepository _digiConnectRepository;
    private readonly ISmsHelper _smsHelper;
    private readonly ILogger _logger;

    public SendActivationSmsHandler(IDigiConnectRepository digiConnectRepository, ISmsHelper smsHelper, ILogger logger)
    {
        _digiConnectRepository = digiConnectRepository;
        _smsHelper = smsHelper;
        _logger = logger;
    }
    public async Task<IResultWrapper> Handle(SendActivationSmsRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var allActivationSMS = await _digiConnectRepository.GetMessageContent(AppEnums.SmsType.Activation.ToString());
            await GetMsisdnToSendMessage(allActivationSMS);
        }
        catch (Exception ex)
        {
            _logger.Error(ex, nameof(SendActivationSmsHandler), nameof(SendActivationSmsHandler));
        }
        return ResultWrapper.Success("Message send successfully", AppConstants.StatusCode.Success);
    }

    private async Task GetMsisdnToSendMessage(List<SmsDetails> messageContent)
    {
        try
        {
            var dateFrom = DateTime.UtcNow.AddHours(-130);
            var activeMsisdn = await _digiConnectRepository.GetActiveMsisdnLog(dateFrom, string.Empty);
            var res = activeMsisdn.DistinctBy(x => x.Msisdn).ToList();
            foreach (var record in res)
            {
                DateTime createdOn = record.CreatedOn;
                TimeSpan timeDifference = DateTime.UtcNow - createdOn;
                int hours = (int)timeDifference.TotalHours;

                string category = record.Product;
                record.CreatedBy = "Hangfire"; 
                if ((record.Cadence is null || record.SmsStatus == "false") && hours < 12)
                {
                    record.Cadence = AppEnums.Cadence.Immediate.ToString();
                    var message = messageContent.Where(x => x.Cadence.Equals(AppEnums.Cadence.Immediate.ToString()) && x.SmsSubCategory == AppEnums.SmsSubCategory.OnlineSim.ToString()).FirstOrDefault();
                    await _smsHelper.sendSms(record, message.SmsContent, category);
                }
                else if ((record.Cadence is null || record.SmsStatus == "false") && (hours > 11 && hours < 24))
                {
                    record.Cadence = AppEnums.Cadence.T12hours.ToString();
                    var message = messageContent.Where(x => x.Cadence.Equals(AppEnums.Cadence.T12hours.ToString()) && x.SmsSubCategory == AppEnums.SmsSubCategory.NoThmApp.ToString()).FirstOrDefault();
                    await _smsHelper.sendSms(record, message.SmsContent, category);
                }
                else if ((record.Cadence is null || record.SmsStatus == "false") && (hours > 23 && hours < 48))
                {
                    record.Cadence = AppEnums.Cadence.T24hours.ToString();
                    var message = messageContent.Where(x => x.Cadence.Equals(AppEnums.Cadence.T24hours.ToString()) && x.SmsSubCategory == AppEnums.SmsSubCategory.All.ToString()).FirstOrDefault();
                    await _smsHelper.sendSms(record, message.SmsContent, category);
                }
                else if ((record.Cadence is null || record.SmsStatus == "false") && (hours > 47 && hours < 72))
                {
                    record.Cadence = AppEnums.Cadence.T48hours.ToString();
                    var message = messageContent.Where(x => x.Cadence.Equals(AppEnums.Cadence.T48hours.ToString()) && x.SmsSubCategory == AppEnums.SmsSubCategory.ActivationWithoutPlan.ToString()).FirstOrDefault();
                    await _smsHelper.sendSms(record, message.SmsContent, category);
                }
                else if ((record.Cadence is null || record.SmsStatus == "false") && (hours > 71 && hours < 96))
                {
                    record.Cadence = AppEnums.Cadence.T72hours.ToString();
                    var message = messageContent.Where(x => x.Cadence.Equals(AppEnums.Cadence.T72hours.ToString()) && x.SmsSubCategory == AppEnums.SmsSubCategory.ActivationWithoutPlan.ToString()).FirstOrDefault();
                    await _smsHelper.sendSms(record, message.SmsContent, category);
                }
                else if ((record.Cadence is null || record.SmsStatus == "false") && (hours > 95 && hours < 120))
                {
                    record.Cadence = AppEnums.Cadence.T96hours.ToString();
                    var message = messageContent.Where(x => x.Cadence.Equals(AppEnums.Cadence.T96hours.ToString()) && x.SmsSubCategory == AppEnums.SmsSubCategory.ActivationWithoutPlanAndTopup.ToString()).FirstOrDefault();
                    await _smsHelper.sendSms(record, message.SmsContent, category);
                }
                else if ((record.Cadence is null || record.SmsStatus == "false") && (hours > 120))
                {
                    record.Cadence = AppEnums.Cadence.T120hours.ToString();
                    var message = messageContent.Where(x => x.Cadence.Equals(AppEnums.Cadence.T120hours.ToString()) && x.SmsSubCategory == AppEnums.SmsSubCategory.ActivationWithoutPlanAndTopup.ToString()).FirstOrDefault();
                    await _smsHelper.sendSms(record, message.SmsContent, category);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.Error(ex, nameof(SendActivationSmsHandler), nameof(SendActivationSmsHandler));
        }

    }
}
