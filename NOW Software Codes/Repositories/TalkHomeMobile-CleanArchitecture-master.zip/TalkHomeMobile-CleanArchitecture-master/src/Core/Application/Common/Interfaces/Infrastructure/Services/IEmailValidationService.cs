﻿using Application.Common.Extensions.DependencyResolver;
using Application.Common.Models.EmailValidation;

namespace Application.Common.Interfaces.Infrastructure.Services;
public interface IEmailValidationService : IServicesType.ITransientService
{
    Task<VerifyEmailResponse?> VerifyEmailAddress(string email, string? ipAddress);
}