using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Services;

public interface ICommonService : ServiceType.IScoped
{
    bool IsValidEmailAddress(string email, bool useRegEx = false, bool requireDotInDomainName = false);
    string GetIpAddress();
    string GetCardScheme(string cardNumber);
    string GetCardMaskedPan(string cardNumber);
    string GetHostRequestUrl();
    string GetOriginRequestUrl();
}