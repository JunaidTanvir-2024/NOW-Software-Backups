﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class AccountSummaryRequestModel
    {
        public string ClientNumber { get; set; }
        public string AccountNumber { get; set; }
    }
}
