﻿$(document).ready(function () { 
    $('#PostCode').keyup(function () {
        if ($('#dpl_CheckoutAddresses_sec').is(':visible')) {
            $('#dpl_CheckoutAddresses_sec').hide();
        }
    });
    $('#yearddl').change(function () {
        if (new Date().getFullYear().toString().substr(2, 2) == this.value && parseInt($('#monthddl').val() == '' ? 0 : $('#monthddl').val()) < parseInt(String(new Date().getMonth() + 1).padStart(2, '0'))) {
            var html = '<option value="">Month</option>';
            for (i = 1; i <= 12; i++) {
                if (new Date().getFullYear().toString().substr(2, 2) == this.value) {
                    if (i >= new Date().getMonth() + 1)
                        html += '<option>' + String(i).padStart(2, '0') + '</option>';
                }
                else
                    html += '<option>' + String(i).padStart(2, '0') + '</option>';
            }
            $('#monthddl').html(html);
        }
        if (new Date().getFullYear().toString().substr(2, 2) != this.value) {
            var html = '<option value="">Month</option>';
            for (i = 1; i <= 12; i++) {
                if (String(i).padStart(2, '0') == $('#monthddl').val())
                    html += '<option selected>' + String(i).padStart(2, '0') + '</option>';
                else
                    html += '<option>' + String(i).padStart(2, '0') + '</option>';
            }
            $('#monthddl').html(html);
        }

    });

    //Get Addresses
    $('#btnAddressLookup_topup').click(function () {
        Checkout.GetAddressByPostalCode();
    });
    //Change Address
    $('#Country').change(function () {
        Checkout.ChangeCountry();
    });
    //Payment Button Click
    $("#payBtn").click(function () {
        if (!$('#aPay360PayWithPaypal').is(':checked')) {
            if ($('#PostCode').val() != '' && (!$('#dpl_CheckoutAddresses_sec').is(':visible')) && $('#Country').val() == 'GBR' && !$('#AddressSection').is(':visible')) {
                Checkout.GetAddressByPostalCode();
                return false;
            }
        }
        if (!$('#CheckoutForm').valid()) {
            if (!$('#termnCondition').is(":checked") && $('#termnCondition').is(":visible")) {
                $('#TermsError').show();
                return false;
            }

            return false;
        }
        if ($('#aPay360PayWithPaypal').is(':checked')) {

            if ($('#chkQuickTopUp').is(':checked')) {
                $("#TermsError").hide();
                $('#CreditModalContent').modal();
                return;
            }
            else
                $("#checkOutPay").modal();
        }
        $("#TermsError").hide();
        $("#checkOutPay").modal();
    });

    //Payment button click on paypal confirmation Model
    $("#sendPaymentRequestBTN,#sendPaymentRequestBTN1").click(function (event) {
        loader.btnloadershow(event);
        $("#payBtn").prop('disabled', true);
        if ($('#aPay360PayWithPaypal').is(':checked')) {
            $('#CheckoutForm').attr('action', '/Paypal/SendPaypalRequest');
            $('#CheckoutForm').submit();
        }
        else {
            Checkout.StartCheckOut();
        }
        //sendPaymentUsingPaypal();
    });
    $('#NewCard').click(function () {
        Checkout.ShowNewCardSection();
    });

    $("#termnCondition").change(function () {
        if (this.checked)
            $('#TermsError').hide();
        else
            $('#TermsError').show();
    });
});

var Checkout = {
    GetAddressByPostalCode: function () {

        if (!$('#PostCode').valid())
            return false;
        $('#LookupSpinner').show();
        $.ajax({
            url: "/GetAddressByPostCode",
            type: "GET",
            async: false,
            data: { postCode: $('#PostCode').val().trim() },
            beforeSend: function (xhr) {
                $('#overlay').fadeIn();
            },
            success: function (response) {
                if (response.errorCode > 0) {
                    if (response.errorCode == 1) //-----> No Address Found
                    {
                        $('#AddressSection').show();
                    }
                    else {
                        $('#AddressSection').hide();
                    }

                    $('#lbl-address-txt').text(response.message);
                    $('#lbl-address-error').slideDown();
                    if ($('#AddressSection').is(':visible'))
                    Checkout.ClearAddressFields();

                    $('#dpl_CheckoutAddresses_sec').hide();

                    Checkout.AddressData = null;
                    Checkout.PostCode = null;

                }
                else {

                    $('#lbl-address-error').hide();
                    $('#AddressSection').hide();

                    Checkout.ClearAddressFields();

                    $("#dpl_CheckoutAddresses").empty();

                    Checkout.AddressData = response.payload.addresses;

                    $.each(response.payload.addresses, function (key, val) {

                        if (key == 0) {
                            var Address = val.split(',');
                            $('#BillingAddress_AddressL1').val(Address[0] + " " + Address[1]);
                            $('#BillingAddress_AddressL2').val(Address[2] + " " + Address[3]);
                            $('#BillingAddress_City').val(Address[5]);
                            $('#BillingAddress_Region').val(Address[6]);
                        }

                        var newaddress = Checkout.FormatAddress(val).slice(0, -1);

                        $("#dpl_CheckoutAddresses").append(new Option(newaddress, val));
                    });

                    $("#dpl_CheckoutAddresses").append(new Option("Add new address", "NewAddress"));

                    Checkout.PostCode = $('#PostCode').val().trim();

                    $('#dpl_CheckoutAddresses option').each(function () {
                        var text = $(this).text();
                        if (text.length > 10) {
                            text = text.substring(0, 35) + '...';
                            $(this).text(text);
                        }
                    });

                    $('#dpl_CheckoutAddresses').prop('title', $("#dpl_CheckoutAddresses").val());

                    $('#dpl_CheckoutAddresses_sec').show();
                }
            },
            complete: function (xhr, status) {
                $('#overlay').fadeOut();
                $('#LookupSpinner').hide();
            },
            error: function (xhr, status, error) {
                $('#lbl-address-txt').text(Global.Messages.error);
                $('#lbl-address-error').slideDown().delay(3000).slideUp();

                $('#AddressSection').hide();
                $('#dpl_CheckoutAddresses_sec').hide();
                $('#PostCode').val('');

                Checkout.AddressData = null;
                Checkout.PostCode = null;

                Checkout.ClearAddressFields();
            }
        });
    },
    ClearAddressFields: function () {
        $("#BillingAddress_AddressL1").val("");
        $("#BillingAddress_AddressL2").val("");
        $("#BillingAddress_AddressL3").val("");
        $("#BillingAddress_AddressL4").val("");
        $("#BillingAddress_City").val("");
        $("#BillingAddress_Region").val("");
    },
    FormatAddress: function (address) {

        var splitaddress = address.split(',');

        var newaddresss = "";

        $.each(splitaddress, function (key, val) {
            if (key == 6) {
                newaddresss += splitaddress[6];
            } else {
                if (splitaddress[key] != " ") {
                    newaddresss += splitaddress[key] + ",";
                }
            }
        });

        return newaddresss;
    },
    UpdateAddress: function () {
        Checkout.ClearAddressFields();
        if ($("#dpl_CheckoutAddresses").val() == "NewAddress") {
            $('#AddressSection').show();
        }
        else {
            var CurrentAddressData = Checkout.AddressData[$("#dpl_CheckoutAddresses")[0].selectedIndex];
            var Address = CurrentAddressData.split(',');

            $('#BillingAddress_AddressL1').val(Address[0] + " " + Address[1]);
            $('#BillingAddress_AddressL2').val(Address[2] + " " + Address[3]);
            $('#BillingAddress_City').val(Address[5]);
            $('#BillingAddress_Region').val(Address[6]);

            $('#AddressSection').hide();

            $('#dpl_CheckoutAddresses').prop('title', $("#dpl_CheckoutAddresses").val());
        }
    },
    ChangeCountry: function () {

        $('#lbl-address-error').hide();

        var countryValue = $('#Country').val();
        if (countryValue == "") {
            $('#PostCodeSection,#AddressSection').hide();
        }
        else if (countryValue == "GBR") {
            $('#PostCodeSection').show();
            $('#AddressSection').hide();

            $('#PostCode').val('');
            $('#dpl_CheckoutAddresses_sec').hide();
            $("#dpl_CheckoutAddresses").empty();

            Checkout.AddressData = null;
        }
        else {
            $('#AddressSection').show();
            $('#PostCodeSection').hide();
            $("#dpl_CheckoutAddresses").empty();
            $('#dpl_CheckoutAddresses_sec').hide();
            Checkout.ClearAddressFields();
            $('#PostCode').val('');
        }
    },
    StartCheckOut: function () {

        if ($('#IsAuthenticated').val() == "True") {

            if ($('.pay360cards').length > 0) {

                if ($('.pay360cards').is(':checked')) {

                    if ($('.pay360cards.active').hasClass('default')) {

                        $('#UserCard_Token').val($('.pay360cards:checked')[0].dataset.cardtoken);
                        $('#Pay360PaymentType').val(2);  //Default
                    }
                    else {
                        $('#UserCard_Token').val($('.pay360cards:checked')[0].dataset.cardtoken);
                        $('#Pay360PaymentType').val(2);  //Token
                    }
                }
                else {
                    if ($('#pay360Newcard').is(':checked')) {
                        $('#Pay360PaymentType').val(3);  //ExistingNew
                    }
                }
            }
            else {
                $('#Pay360PaymentType').val(0);  //New
            }

        } else {
            $('#Pay360PaymentType').val(0); //New
        }
        $('#CheckoutForm').attr('action', '/StartPay360Payment');
        $('#CheckoutForm').submit();


    },
    ShowNewCardSection: function () {
        //$('#SavedCardSection').hide();
        $('#SaveCardSecurityCode').hide();
        //$(".pay360cards").prop("checked", false);
        //$('#cardToken').val('');
        $('#Paymentdiv').show();
        //$('.or-divider').css({ 'padding': '0', });
    },
    SelectExistingCard: function (control) {
        $('#cardToken').val($(control).attr("data-cardtoken"));
        $('#' + $(control).attr("data-cardtoken")).prop("checked", true);
        $('#Paymentdiv').hide();
        $('#SaveCardSecurityCode').show();
        //$('#BtnShowNewCardSection').removeClass('active');
        //$('#BtnShowNewCardSection').show();
        //$('.or-divider').css({ 'padding': '2rem 0', 'margin-bottom': '0px' });
    }
}
function validateRechargablePin(event) {
    $("#payBtn").prop('disabled', false);
    $("#errorMessage").empty();
    let pin = event.target.value;;
    if (!pin || pin == 0) {
        return;
    }
    var model = {};
    model.pin = pin;
    $.ajax({
        beforeSend: function () {
            loader.mainloaderShow();
        },
        type: "POST",
        url: "/Account/VerifyPinNumber",
        data: model,
        async: true,
        success: function (json) {
            loader.mainloaderHide();
            if (json.errorCode == 0) {
                return;
            } else {
                $("#payBtn").prop('disabled', true);
                $('#errorMessage').show();
                $('#errorMessage').text('Please enter valid pin');
                return;
            }
        },
        error: function (error) {
            return;
        }
        , complete: function () {
            loader.mainloaderHide();
        }
    });
}
$('#RechargePIN').keyup(function () {
    if ($('#errorMessage').is(':visible'))
        $('#errorMessage').hide();
});
