﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants;
public static partial class AppEnums
{
    public enum GenderEnum
    {
        Male = 1,
        Female = 2,
        Other=3,
        NotToSay=4
    }
}
