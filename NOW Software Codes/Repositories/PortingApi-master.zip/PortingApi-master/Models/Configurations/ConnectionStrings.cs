﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    
    public class ConnectionStrings
    {
        public string DefaultConnection { get; set; }
        public string NowMobileConnection { get; set; }
    }

}
