﻿using MapsterMapper;
using SC.Core.Features.Users.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Users;
public sealed class GetUserDetailHander : IRequestHandler<GetUserDetailRequest, IResultWrapper>
{
    private readonly IUserRepository _userRepository;
    private readonly IMapper _mapper;
    public GetUserDetailHander(
     IUserRepository IUserRepository, IMapper mapper)
    {
        _userRepository = IUserRepository;
        _mapper = mapper;
    }
    public async Task<IResultWrapper> Handle(GetUserDetailRequest request, CancellationToken cancellationToken)
    {
        var response = await _userRepository.GetUserDetailByUserID(request.UserID);
        var responseResult = _mapper.Map<GetUserDetailResponse>(response);
        return ResultWrapper.Success(responseResult);
    }
}

