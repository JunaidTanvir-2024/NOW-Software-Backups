﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class MobileAccountResponseModel
    {
        public string Msisdn { get; set; }

        public string AccountID { get; set; }

        public int? SubscriberId { get; set; }

        public string PUKCode { get; set; }

        public decimal Credit { get; set; }

        public string FirstDate { get; set; }
    }
}
