﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TH.Models.Database
{
    public class DBResponse
    {
        public int DBStatus { get; set; } // 1 for Success and 0 for Failure
        public string DBErrorSP { get; set; } // Error Stored Procedure Name
        public string DBErrorMessage { get; set; } // Error Message
        public int InsertId { get; set; } // Table insertion identity column(id) value 
    }

    public class DbResult<T>
    {
        public int ErrorCode { get; set; }
        public string ErrorMsg { get; set; }
        public T Data { get; set; }
    }
}
