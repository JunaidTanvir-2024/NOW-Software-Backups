using FH.Core.DependencyResolver;
using FH.Core.Settings;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
namespace FH.Core;

public static class ConfigureDependencies
{
    public static IServiceCollection AddCoreDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.AutoResolve();
        services.RegisterJsonSettings(configuration);
        return services;
    }
    private static IServiceCollection RegisterJsonSettings(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<CallbackHubSetting>(configuration.GetSection(CallbackHubSetting.SectionName));
        services.Configure<SecuritySetting>(configuration.GetSection(SecuritySetting.SectionName));
        return services;
    }
}
