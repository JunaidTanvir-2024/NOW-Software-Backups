﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class InternationalRatesResponseModel
    {
        public int Id { get; set; }
        public float LandlineRate { get; set; }
        public float SmsRate { get; set; }
        public float MobileRate { get; set; }
        public int CountryId { get; set; }
        public float LandlineRateOffpeak { get; set; }
        public float MobileRateOffpeak { get; set; }
        public float SmsRateOffpeak { get; set; }
        public int TopRateIndex { get; set; }
        public float TopRates { get; set; }
        public int CreatedBy { get; set; }
        public int LastUpdatedBy { get; set; }
        public bool isActive { get; set; }

        //CountryInfo
        public string Name { get; set; }
        public string PhoneCode { get; set; }
        public string IsoTwoCharacterCode { get; set; }
        public bool IsNational { get; set; }
    }
}
