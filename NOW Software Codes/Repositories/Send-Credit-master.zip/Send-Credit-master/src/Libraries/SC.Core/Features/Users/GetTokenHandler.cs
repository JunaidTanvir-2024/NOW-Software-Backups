﻿using SC.Core.Common.Interfaces.Services;
namespace SC.Core.Features.Users;
internal class GetTokenHandler : IRequestHandler<GetTokenRequest, IResultWrapper>
{
    private readonly IJwtService _jwtService;
    public GetTokenHandler(
       IJwtService jwtService)
    {
        _jwtService = jwtService;
    }
    public async Task<IResultWrapper> Handle(GetTokenRequest request, CancellationToken cancellationToken)
    {
        var tokenInfo = await _jwtService.GetTokensAsync(request.UserInfo);
        if (tokenInfo is null)
        {
            return ResultWrapper.Failure("No Record Found", 404);
        }
        return ResultWrapper.Success(tokenInfo);
    }
}

