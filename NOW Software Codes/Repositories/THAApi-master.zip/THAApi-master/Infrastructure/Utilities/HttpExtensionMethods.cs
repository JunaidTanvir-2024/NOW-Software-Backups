﻿using Microsoft.AspNetCore.Http;
using Models.Enums;
using System;
using System.Globalization;
using System.Linq;

namespace Infrastructure.Utilities
{

    public static class HttpExtensionMethods
    {

        public static bool AirshipEventsDisable(this HttpContext context)
        {
            try
            {
                return context.Request.Headers["AirshipEventsDisable"] == "1";
            }
            catch
            {
                return false;
            }
        }
        public static ThemeMode ThemeMode(this HttpContext context)
        {
            try
            {
                return (ThemeMode)Enum.Parse(typeof(ThemeMode), context.Request.Headers.FirstOrDefault(e => e.Key == "ThemeMode").Value.ToString());
            }
            catch
            {
                return Models.Enums.ThemeMode.Light;
            }
        }
        public static string GetAdvertiserID(this HttpContext context)
        {
            string advertiserID = Convert.ToString(context.Request.Headers["advertiserID"].FirstOrDefault());
            return advertiserID;
        }
    }
}
