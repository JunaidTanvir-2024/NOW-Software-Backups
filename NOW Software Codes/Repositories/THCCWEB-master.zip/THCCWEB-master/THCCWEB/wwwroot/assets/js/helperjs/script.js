﻿$(function () {
    $("#overlay").hide();
    $('.only_valid_numbers').keyup(function () {
        Global.IsValidNumber($(this));
    });

    $('.only_valid_alphabets').keyup(function () {
        Global.IsValidAlphabets($(this));
    });
});
var Global = {
    IsValidNumber: function (control) {
        var $input = $(control);
        $input.val($input.val().replace(/[^\d]+/g, ''))
    },
    IsValidAlphabets: function (control) {
        var regexp = /[^ a-zA-Z]/g;
        if ($(control).val().match(regexp)) {
            $(control).val($(control).val().replace(regexp, ''));
        }
    }
}
var loader = {
    btnloadershow: function (event) {
        if (event && event.target) {
            $(event.target).prepend("<i class='fas fa-spin fa-spinner'></i>");
            $(event.target).prop('disabled', true);
        }
    },
    btnloaderhide: function (event) {
        if (event && event.target && event.target.id) {
            $("#" + event.target.id + " i").remove();
            $(event.target).prop('disabled', false);
        }
    },
    mainloaderShow: function () {
        $("#overlay").show();
    },
    mainloaderHide: function () {
        $("#overlay").hide();
    }
} 

