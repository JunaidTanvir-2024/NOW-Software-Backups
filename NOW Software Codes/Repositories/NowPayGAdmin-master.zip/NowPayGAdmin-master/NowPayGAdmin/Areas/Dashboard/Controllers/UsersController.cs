﻿using BasketWebPanel.Areas.Dashboard.Models.ApiRequest.Users;
using BasketWebPanel.Areas.Dashboard.Models.ApiResponse.Users;
using BasketWebPanel.Areas.Dashboard.ViewModels;
using BasketWebPanel.BindingModels;
using BasketWebPanel.ViewModels;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace BasketWebPanel.Areas.Dashboard.Controllers
{
    [Authorize]
    public class UsersController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ManageUsers()
        {
            var response = AsyncHelpers.RunSync<JObject>(() => ApiCall.CallApi("api/Admin/GetUsers", User, null, true, false, null));

            SearchUserViewModel model = new SearchUserViewModel();

            if (response is Error)
                return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, "Internal Server Error");
            else
                model = response.GetValue("Result").ToObject<SearchUserViewModel>();

            foreach (var user in model.Users)
            {
                user.StatusName = user.IsDeleted ? "Blocked" : "Active";
                if (user.ProfilePictureUrl == null || user.ProfilePictureUrl == "")
                    user.ProfilePictureUrl = "UserImages/Default.png";
            }
            model.StatusOptions = Utility.GetUserStatusOptions();

            model.SetSharedData(User);

            return View(model);
        }

        public ActionResult ManageAllUsers()
        {
            try
            {
                Global.sharedDataModel.SetSharedData(User);
                return View(Global.sharedDataModel);
            }
            catch (Exception ex)
            {
                return new HttpStatusCodeResult(Utility.LogError(ex), "Internal Server Error");
            }
        }

        public async Task<JsonResult> GetAllUsers()
        {
            try
            {
                var Email = string.IsNullOrEmpty(Request.Form["Email"]) ? null : Request.Form["Email"];
                var SocialLoginType = string.IsNullOrEmpty(Request.Form["SocialLoginType"]) ? 0 : Convert.ToInt32(Request.Form["SocialLoginType"]);
                var ActiveRangeList = Request.Form["ActiveRange"].Split('-');

                var response = await ApiCall.CallApi("api/Admin/GetUsers", User, GetRequest: true, parameters: "Email=" + Email + "&SocialSignUpTypeId=" + SocialLoginType + "&LastActiveFrom=" + ActiveRangeList[0] + "&LastActiveTo=" + ActiveRangeList[1]);

                if (response == null || response is Error)
                {
                    return Json(new { data = string.Empty }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    var responseData = response.GetValue("payload").ToObject<GetAllUsersResponse>();
                    return Json(responseData.UserList, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                Utility.LogError(ex);
                return Json(string.Empty, JsonRequestBehavior.AllowGet);
            }
        }

        public async Task<ActionResult> UserDetails(int id)
        {
            try
            {
                var response = await ApiCall.CallApi("api/Admin/GetUserByID", User, null, true, false, null, "ID=" + id);
                if (response is Error)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, "Internal Server Error");
                }
                else
                {
                    var modelData = response.GetValue("payload").ToObject<UserDetailBindingModel>();

                    modelData.SetSharedData(User);
                    return View("~/Areas/Dashboard/Views/Users/UserDetails.cshtml", modelData);
                }
            }
            catch (Exception ex)
            {
                Utility.LogError(ex);
                return new HttpStatusCodeResult((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpPost]
        public async Task<ActionResult> UpdateUserStatus(int StatusID, int UserID)
        {
            try
            {
                var request = new UpdateUserStatusRequestModel()
                {
                    UserID = UserID,
                    StatusID = StatusID
                };
                var response = await ApiCall.CallApi("api/Admin/UpdateUserStatus", User, request);
                if (response == null || response is Error)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    return Json("Error", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    var responseData = response.GetValue("payload").ToObject<bool>();
                    if (responseData == true)
                    {
                        return Json("Success", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        return Json("Error", JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.LogError(ex);
                return new HttpStatusCodeResult((int)HttpStatusCode.InternalServerError, "Some Error Occured");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SaveUserStatuses(List<ChangeUserStatusModel> selectedUsers)
        {
            try
            {
                if (selectedUsers == null)
                {
                    return new HttpStatusCodeResult((int)HttpStatusCode.Forbidden, "Select a user to save");
                }

                ChangeUserStatusListModel postModel = new ChangeUserStatusListModel();
                postModel.Users = selectedUsers;

                var apiResponse = AsyncHelpers.RunSync<JObject>(() => ApiCall.CallApi("api/Admin/ChangeUserStatuses", User, postModel));

                if (apiResponse == null || apiResponse is Error)
                    return new HttpStatusCodeResult(500, "Internal Server Error");
                else
                {
                    return Json("Success");
                }

            }
            catch (Exception ex)
            {
                Utility.LogError(ex);
                return new HttpStatusCodeResult((int)HttpStatusCode.InternalServerError, "Some Error Occured");
            }
        }

        public ActionResult GetUser(int UserId)
        {
            try
            {
                var response = AsyncHelpers.RunSync<JObject>(() => ApiCall.CallApi("api/User/GetUser", User, null, true, false, null, "UserId=" + UserId, "SignInType=0"));

                UserBindingModel model = null;

                if (response is Error)
                    return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, "Internal Server Error");
                else
                    model = response.GetValue("Result").ToObject<UserBindingModel>();

                if (model.ProfilePictureUrl == null || model.ProfilePictureUrl == "")
                    model.ProfilePictureUrl = "UserImages/Default.png";

                model.UserAddresses = model.UserAddresses.Where(x => x.IsDeleted == false).ToList();
                model.PaymentCards = model.PaymentCards.Where(x => x.IsDeleted == false).ToList();

                foreach (var order in model.Orders)
                {
                    order.PaymentStatusName = Utility.GetPaymentStatusName(order.PaymentStatus);
                    order.PaymentMethodName = Utility.GetPaymentMethodName(order.PaymentMethod);

                }

                model.SetSharedData(User);

                return View("User", model);
            }
            catch (Exception ex)
            {
                Utility.LogError(ex);
                return new HttpStatusCodeResult((int)HttpStatusCode.InternalServerError, "Some Error Occured");
            }
        }
    }

}