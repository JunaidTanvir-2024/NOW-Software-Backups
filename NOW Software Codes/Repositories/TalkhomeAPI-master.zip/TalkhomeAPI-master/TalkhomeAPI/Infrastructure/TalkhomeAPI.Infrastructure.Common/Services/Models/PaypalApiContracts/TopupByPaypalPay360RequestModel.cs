﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts
{
    public class TopupByPaypalPay360RequestModel
    {
        [Required]
        public string Token { get; set; }
    }
}
