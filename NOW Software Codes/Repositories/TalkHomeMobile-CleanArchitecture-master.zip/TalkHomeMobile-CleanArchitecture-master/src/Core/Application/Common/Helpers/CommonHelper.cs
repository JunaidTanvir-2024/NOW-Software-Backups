﻿
namespace Application.Common.Helpers;
public static class CommonHelper
{
    public static string GenerateSimOrderValidationMessage(this int validationResponse)
    {
        if (validationResponse == 100110) { return CustomStatusKey.EmailMonthlyLimitExceed; }
        else if (validationResponse == 100111) { return CustomStatusKey.EmailYearlyLimitExceed; }
        else if (validationResponse == 100112) { return CustomStatusKey.AddressYearlyLimitExceed; }
        else if (validationResponse == 100113) { return CustomStatusKey.AddressMonthlyLimitExceed; }
        else if (validationResponse == 100114) { return CustomStatusKey.DailyLimitExceeded; }
        else if (validationResponse == 100115) { return CustomStatusKey.IpAddressLimitExceeded; }
        else if (validationResponse == 100118) { return CustomStatusKey.SimReplacementLimitExceeded; }
        else { return ""; }

    }
    public static int GenerateSimOrderValidationCode(this int validationResponse)
    {
        if (validationResponse == 100110) { return CustomStatusCode.EmailMonthlyLimitExceed; }
        else if (validationResponse == 100111) { return CustomStatusCode.EmailYearlyLimitExceed; }
        else if (validationResponse == 100112) { return CustomStatusCode.AddressYearlyLimitExceed; }
        else if (validationResponse == 100113) { return CustomStatusCode.AddressMonthlyLimitExceed; }
        else if (validationResponse == 100114) { return CustomStatusCode.DailyLimitExceeded; }
        else if (validationResponse == 100115) { return CustomStatusCode.IpAddressLimitExceeded; }
        else if (validationResponse == 100118) { return CustomStatusCode.SimReplacementLimitExceeded; }
        else { return CustomStatusCode.NotFound; }
    }
}
