﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Database
{
    
    public class DbResult<T>
    {
        public int DBStatus { get; set; }
        public string DBErrorMessage { get; set; }
        public T Data { get; set; }
    }
}
