﻿using Microsoft.Extensions.Configuration;
using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Models.Dtos.CustomerCard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Infrastructure.Persistence.Repositories;
internal sealed class CustomerCardRepository : ICustomerCardRepository
{
    private readonly IConfiguration _configuration;
    private readonly ILogger _logger;
    public CustomerCardRepository(IConfiguration configuration, ILogger logger)
    {
        _configuration = configuration;
        _logger = logger;
    }
    public async Task<long> AddCustomerCardAsync(CustomerCardDto order)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {

            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_user_id", order.UserId);
                parameters.Add("@p_pan", order.Pan);
                parameters.Add("@p_name_on_card", order.NameOnCard);
                parameters.Add("@p_card_type", order.CardType);
                parameters.Add("@p_expiry", order.Expiry.Date);
                parameters.Add("@p_is_default", order.IsDefault);
                parameters.Add("@p_is_active", true);
                parameters.Add("@p_is_deleted", false);
                parameters.Add("@p_insrt_dte", DateTime.UtcNow);
                parameters.Add("@p_updte_dte", DateTime.UtcNow);
                parameters.Add("@p_insrt_by", order.UserId);
                parameters.Add("@p_updte_by", order.UserId);
                var result = await connection.ExecuteScalarAsync<long>(AppConstants.StoreProcedures.CustomerCardInsert, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {

                _logger.Error("AddCustomerCardAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<List<CustomerCardDto>> GetCustomerCardsAsync(string userID)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_user_id", userID);

                return (await connection.QueryAsync<CustomerCardDto>(AppConstants.StoreProcedures.CustomerCardGet, parameters, commandType: CommandType.StoredProcedure)).ToList();

            }
            catch (Exception ex)
            {
                _logger.Error("GetCustomerCards, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }
    public async Task<bool?> RemoveCardAsync(long CardId)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {

            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_customer_card_id", CardId);
                var result = await connection.ExecuteScalarAsync<int>(AppConstants.StoreProcedures.CustomerCardRemove, parameters, commandType: CommandType.StoredProcedure);
                return result > 0 ? true : false;
            }
            catch (Exception ex)
            {

                _logger.Error("RemoveCardAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }

    public async Task<bool?> MarkCardAsDefaultAsync(long CardId,string UserID)
    {
        using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {

            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_customer_card_id", CardId);
                parameters.Add("@p_user_id", UserID);
                var result = await connection.ExecuteScalarAsync<int>(AppConstants.StoreProcedures.CustomerCardMarkDefault, parameters, commandType: CommandType.StoredProcedure);
                return result > 0 ? true : false;
            }
            catch (Exception ex)
            {

                _logger.Error("MarkCardAsDefaultAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }
}

