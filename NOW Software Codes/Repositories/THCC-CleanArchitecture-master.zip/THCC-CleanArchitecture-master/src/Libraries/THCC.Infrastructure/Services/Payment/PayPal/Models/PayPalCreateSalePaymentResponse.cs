﻿using Newtonsoft.Json;

namespace THCC.Infrastructure.Services.Payment.PayPal.Models
{
    public class PayPalCreateSalePaymentResponse
    {
        [JsonProperty("redirectUrl")]
        public string? RedirectUrl { get; set; }
        public string? TransactionId { get; set; }
    }
}
