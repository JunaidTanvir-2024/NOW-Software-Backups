﻿namespace SenderService.Core.Persistence.Entities;

//public class EmailValidation
//{
//    public long Id { get; set; }

//    public string Account { get; set; } = null!;

//    public string Domain { get; set; } = null!;

//    public string Email { get; set; } = null!;

//    public bool IsVerified { get; set; }

//    public DateTimeOffset ProcessDate { get; set; }

//    public string InvalidReason { get; set; } = null!;
//}

public class EmailValidation
{
    public long Id { get; set; }

    public string Email { get; set; } = null!;

    public bool IsVerified { get; set; }

    public DateTimeOffset ProcessDate { get; set; }

    public string InvalidReason { get; set; } = null!;

    public string RequestBody { get; set; } = null!;
    
    public string ResponseBody { get; set; } = null!;

    public long ProductCodeId { get; set; }

    public virtual ProductCode ProductCode { get; set; } = null!;
}
