﻿using System.Text.Json.Serialization;

namespace Models.Contracts.Response.Voucherify
{
    public class ReferralCodeResponse
    {
        [JsonPropertyName("referralCode")]
        public string ReferralCode { get; set; }
    }
}
