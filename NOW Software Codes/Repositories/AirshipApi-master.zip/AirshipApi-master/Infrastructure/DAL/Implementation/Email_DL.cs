﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Request;
using Models.DbConnections;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class Email_DL : IEmail_DL
    {

        private IDbConnectionSettings DefaultConnection;
        private ILogger Logger;

        public Email_DL(IOptions<ConnectionStrings> connectionConfig, ILogger logger)
        {

            DefaultConnection = new DbConnectionSettings(new SqlConnection(connectionConfig.Value.DefaultConnection));
            Logger = logger;
        }


        public async Task<GenericResult<bool>> AddEmailChannel(AddEmailChannelRequest emailChannel,string channelId)
        {

            string logParameters = $"  {JsonConvert.SerializeObject(emailChannel)} ";
            try
            {

                var parameter = new DynamicParameters();
                parameter.Add("@channel_id", channelId);
                parameter.Add("@product_code", emailChannel.productCode);
                parameter.Add("@device_type_id", (int)DeviceType.email);
                parameter.Add("@commercial_opted_in", emailChannel.commercialOptedIn);
                parameter.Add("@commercial_opted_out", emailChannel.commercialOptedOut);
                parameter.Add("@transactional_opted_in", emailChannel.transactionalOptedIn);
                parameter.Add("@transactional_opted_out", emailChannel.transactionalOptedOut);
                parameter.Add("@email", emailChannel.Address);
                parameter.Add("@device_local_timezone", emailChannel.TimeZone);
                parameter.Add("@device_country", emailChannel.LocaleCountry);
                parameter.Add("@device_language", emailChannel.LocaleLanguage);

                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("[Api_AddEmailChannel]", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Email_DL, Method: AddEmailChannel, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }

    }
}
