using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

using static JM.Core.Utilities.Definitions.AppEnum;

namespace JM.Core.Utilities.Interfaces.Database;

public interface ITripRepository : ResolveAs.IScoped
{
	Task<Trip> AddTrip(Trip tripTrip);
	Task<IEnumerable<Trip>> GetTripList(Expression<Func<Trip, bool>> expression, OrderByDirection orderByDirection = OrderByDirection.Ascending,
	 TripType tripType = TripType.All, long userId = default);
	void UpdateTrip(Trip tripTrip);
	Task<Trip?> GetTrip(Expression<Func<Trip, bool>> predicate);
	Task<TripPlace> AddPlaceToTrip(TripPlace trip);
}
