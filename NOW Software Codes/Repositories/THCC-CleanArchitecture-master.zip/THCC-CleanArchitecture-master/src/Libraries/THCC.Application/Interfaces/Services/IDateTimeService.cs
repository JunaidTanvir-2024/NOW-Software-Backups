using THCC.Application.Common.Extensions.DependencyResolver;

namespace THCC.Application.Common.Interfaces.Services;

public interface IDateTimeService : ServiceType.IScoped
{
    DateTime UtcTimeNow { get; }
}