﻿namespace Application.Features.Identity.ForgotPassword.ForgotPasswordResend;
public class ForgotPasswordResendRequest : IRequest<Result<object>>
{
    public string EmailAddress { get; set; } = default!;

    [JsonIgnore]
    public string? IpAddress { get; set; } = null;
}
