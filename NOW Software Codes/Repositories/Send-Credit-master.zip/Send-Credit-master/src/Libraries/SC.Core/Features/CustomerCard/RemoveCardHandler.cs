﻿using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.CustomerOrder.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder;
internal sealed class RemoveCardHandler : IRequestHandler<RemoveCardRequest, IResultWrapper>
{
    private readonly ICustomerCardRepository _customerCardRespository;
    public RemoveCardHandler(ICustomerCardRepository customerCardRespository)
    {
        _customerCardRespository = customerCardRespository;
    }
    public async Task<IResultWrapper> Handle(RemoveCardRequest request, CancellationToken cancellationToken)
    {
        

        var RemovedCard = await _customerCardRespository.RemoveCardAsync(request.CardID);
        
        return ResultWrapper.Success(new {IsRemoved= RemovedCard });
    }
    
}

