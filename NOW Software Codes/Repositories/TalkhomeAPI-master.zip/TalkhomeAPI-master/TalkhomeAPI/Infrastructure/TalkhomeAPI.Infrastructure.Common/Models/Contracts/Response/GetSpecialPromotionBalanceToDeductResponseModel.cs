﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class GetSpecialPromotionBalanceToDeductResponseModel
    {
        public decimal retAmount { get; set; }
        public string retcreditReason { get; set; }
    }
}
