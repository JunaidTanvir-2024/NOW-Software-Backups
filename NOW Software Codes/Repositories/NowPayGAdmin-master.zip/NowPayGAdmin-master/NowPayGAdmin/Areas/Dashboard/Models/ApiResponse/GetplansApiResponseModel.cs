﻿using BasketWebPanel.Areas.Dashboard.Models.ApiRequest;
using BasketWebPanel.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models.ApiResponse
{
    public class GetplansApiResponseModel : BaseViewModel
    {
        public IEnumerable<Addplan> GetPlans { get; set; }
    }
}