namespace FH.Core.DTOs.Database;

public sealed record ProductDto
{
    public sealed record Request
    {
        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public bool IsActive { get; set; } = true;
        public bool IsDeleted { get; set; } = false;
        public Filter? Filters { get; set; }

        public sealed record Filter
        {
            public string? CountryIsoCode { get; set; }
            public string? CurrencyCode { get; set; }
            public int? CallingCode { get; set; }
            public string? ValidityUnit { get; set; }
            public string? OperatorId { get; set; }
            public int? ProductId { get; set; }
            public int? ProductCategoryId { get; set; }
            public string? ProductAliasName { get; set; }
            public string? OperatorShortCode { get; set; }
            public string? ProductSubCategoryShortCode { get; set; }
        }
    }

    public sealed record Response
    {
        public long ProductId { get; set; }
        public string? ProductName { get; set; }
        public string? ProductAliasName { get; set; }
        public string? Description { get; set; }
        public string? Logo { get; set; }
        public string? ValidityUnit { get; set; }
        public string? ValidityValue { get; set; }
        public string? VendorProductCode { get; set; }
        public string? VendorOperatorCode { get; set; }
        public string? ProductType { get; set; }

        // ProductOperatorInfo
        public string? OperatorName { get; set; }
        public string? OperatorDescription { get; set; }

        // ProductCountryInfo
        public string? CountryName { get; set; }
        public string? CountryIsoCode2 { get; set; }
        public string? CountryIsoCode3 { get; set; }
        public string? Continent { get; set; }
        public string? CallingCode { get; set; }

        //ProductCategoryInfo
        public string? CategoryName { get; set; }
        public string? CategoryDescription { get; set; }

        //ProductSubCategoryInfo
        public string? SubCategoryName { get; set; }
        public string? SubCategoryDescription { get; set; }

        //ProductVendorInfo
        public string? VendorName { get; set; }
        public string? VendorDescription { get; set; }

        //CurrencyInfo
        public string? CurrencyName { get; set; }
        public string? CurrencyCode { get; set; }
        public bool? CurrencyIsDefault { get; set; }

        //ProductPriceInfo
        public decimal? SellingPrice { get; set; }
        public decimal? Tax { get; set; }
        public decimal? Fee { get; set; }
        public decimal? MaxPrice { get; set; }
        public decimal? MinPrice { get; set; }
        public string? ProductBenefitsJson { get; set; }
    }
}
