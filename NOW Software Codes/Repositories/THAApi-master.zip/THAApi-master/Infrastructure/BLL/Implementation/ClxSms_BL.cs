﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.Extensions.Configuration;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Infrastructure.BLL.Implementation
{
    public class ClxSms_BL : IClxSms_BL
    {
        private readonly IUserAccount_DL UserAccount_DL;
        private readonly IConfiguration Config;
        
        public ClxSms_BL(IUserAccount_DL userAccount_DL, IConfiguration config)
        {
            UserAccount_DL = userAccount_DL;
            Config = config;
        }

        public async Task<SmsResult> Send(string sentFrom, string sentTo, string message, bool paid, bool isSignupPinSms = false, string language = "en")
        {
            if (isSignupPinSms)
            {
                await UserAccount_DL.BeginPinSend(sentTo);
            }

            if (string.IsNullOrEmpty(sentFrom))
                throw new ArgumentException("Value cannot be null or empty.", nameof(sentFrom));
            if (string.IsNullOrWhiteSpace(sentTo))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(sentTo));
            if (string.IsNullOrWhiteSpace(message))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(message));

            if (isSignupPinSms)
            {
                await UserAccount_DL.PassesSmsValidation(sentTo);
            }

            var receivedToMsisdn = sentTo;

            sentTo = sentTo.Trim();
            sentFrom = sentFrom.Trim();

            string formattedFrom = sentFrom;
            string formattedTo = sentTo;

            if (!isSignupPinSms)
            {
                formattedFrom = ParseNumber(sentFrom);
                if (formattedFrom.ToLower() != "talk home")
                {
                    formattedTo = PhoneNumberFixer.Fix(formattedTo);
                }
            }

            if (formattedTo == null)
            {
                if (isSignupPinSms)
                {
                    await UserAccount_DL.SendToNumberParseFailed(receivedToMsisdn);
                }

                return SmsResult.Error(sentTo, SmsErrorCode.Unknown);
            }

            Sms smsStatus = null;

            smsStatus = new Sms
            {
                Provider = Provider.ClxNetWorks,
                Sender = formattedFrom,
                To = formattedTo,
                Status = Status.Pending,
                Sent = DateTime.UtcNow,
                ProviderError = null,
                ProviderId = null
            };

            int result = await UserAccount_DL.SaveSms(smsStatus);
            if (result < 1)
            {
                await UserAccount_DL.SmsDbContextSaveFailed(receivedToMsisdn);
            }


            HttpResponseMessage response = null;
            string queryString = string.Empty;
            string encodingType = string.Empty;

            try
            {
                encodingType = GetEncoding(message);

                if (paid)
                {
                    var balance = await UserAccount_DL.GetUserAccountBalanceAsync(sentFrom);

                    var messageCount = GetMessageCount(message, encodingType);

                    //We really should be working out multiple message counts
                    var totalMessageCost = 0.10m;

                    if (decimal.Parse(balance.Balance, CultureInfo.InvariantCulture) < totalMessageCost)
                    {
                        return SmsResult.Error(sentTo, SmsErrorCode.InsufficentBalance);
                    }

                    var wasUserCharged = await UserAccount_DL.ChargeUser(sentFrom, sentTo, messageCount);
                    if (!wasUserCharged)
                    {
                        return SmsResult.Error(sentTo, SmsErrorCode.InsufficentBalance);
                    }
                }

                if (isSignupPinSms)
                {
                    await UserAccount_DL.StorePinMessageLengthAndEncodingType(receivedToMsisdn, message.Length, encodingType);
                }

                //Actually send the SMS
                var encodingEnum = encodingType == "GSM7" ? 0 : 2;
                queryString = $"username={Config["Clx:Username"]}" +
                          $"&password={Config["Clx:Password"]}" +
                          $"&to={HttpUtility.UrlEncode(formattedTo)}" +
                          $"&text={HttpUtility.UrlEncode(message)}" +
                          $"&from={HttpUtility.UrlEncode(formattedFrom)}" +
                           "&dlr-mask=7" +
                            $"&coding={encodingEnum}" +
                          $"&validity={Config["Clx:Validity"]}" +
                          $"&dlr-url={HttpUtility.UrlEncode($"{Config["Clx:CallbackUrl"]}?type=%d&dr-msg=%A&from=%p&to=%P&time=%t")}";

                HttpClient client = new HttpClient
                {
                    BaseAddress = new Uri(Config["Clx:ApiEndPoint"])
                };

                response = await client.GetAsync($"sendsms?{queryString}");

                if (isSignupPinSms)
                {
                    await UserAccount_DL.PinSent(sentTo, formattedTo, queryString);
                }
            }
            catch (Exception ex)
            {
                if (isSignupPinSms)
                {
                    await UserAccount_DL.SmsHttpSendFailed(receivedToMsisdn, queryString);
                }

                Debug.WriteLine(ex.ToString());
            }


            try
            {
                var messageCount = GetMessageCount(message, encodingType);

                if (isSignupPinSms)
                {
                    await UserAccount_DL.StoreMessageCount(receivedToMsisdn, messageCount);
                }

                if (isSignupPinSms && messageCount > 2)
                {
                    return SmsResult.Error(sentTo, SmsErrorCode.MessageTooLong);
                }
                else if (messageCount > 1)
                {
                    return SmsResult.Error(sentTo, SmsErrorCode.MessageTooLong);
                }


            }
            catch (Exception ex)
            {

            }

            var tags = new string[] { $"sender:{smsStatus.Sender}", $"receiver:{smsStatus.To}" };

            string clxId = string.Empty;
            string clxError = string.Empty;

            if (response.IsSuccessStatusCode)
            {
                clxId = await response.Content.ReadAsStringAsync();
                smsStatus.Provider = Provider.ClxNetWorks;
                smsStatus.ProviderId = clxId;
                smsStatus.Status = Status.Pending;

                int result2 = await UserAccount_DL.SaveSms(smsStatus);
                return SmsResult.Ok(smsStatus.To);

            }
            else
            {
                try
                {
                    clxError = await response.Content.ReadAsStringAsync();
                }
                catch (Exception)
                {

                }
            }

            smsStatus.Provider = Provider.ClxNetWorks;
            smsStatus.ProviderId = clxId;
            smsStatus.ProviderError = clxError;
            smsStatus.Status = Status.Error;
            int result3 = await UserAccount_DL.SaveSms(smsStatus);

            var errorTag = new[] { $"error:{clxError}" };

            var unifiedTags = tags.Union(errorTag).ToArray();

            //await emailService.SendAsync(DateTime.UtcNow.ToString(CultureInfo.InvariantCulture), smsStatus.Id.ToString(CultureInfo.InvariantCulture), smsStatus.Sender, smsStatus.To, smsStatus.ProviderError, "Send SMS");

            return SmsResult.Error(smsStatus.To, SmsErrorCode.ProviderError, smsStatus.ProviderError);
        }
        public static int GetMessageCount(string message, string encoding)
        {
            if (encoding == "GSM7")
            {
                return (int)Math.Ceiling(message.Length / 160d);
            }

            return (int)Math.Ceiling(message.Length / 70d);
        }
        public static string GetEncoding(string message)
        {
            const string charSet = "@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞ\x1bÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?" +
                                   "¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ`¿abcdefghijklmnopqrstuvwxyzäöñüà";

            return message.Select(c => charSet.IndexOf(c)).Any(index => index == -1) ? "UCS2" : "GSM7";
        }

        private string ParseNumber(string number)
        {
            var returnNumber = number.Replace("+", "");

            return returnNumber.StartsWith("00") ? returnNumber.Remove(0, 2) : returnNumber;
        }
    }
}
