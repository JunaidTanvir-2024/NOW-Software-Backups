﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
   
    public class SerilogConfig
    {
        public string FilePath { get; set; }
    }
}
