﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Definitions.Constants;

public static partial class AppEnums
{
    public enum CustomerCardEnum
    {
        IsCardNumberAlreadyExist = -1,
    }
}