﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Request.AndroidInAppPayment;
using Models.Database;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using static Models.Configurations.ATTConfig;

namespace Infrastructure.DAL.Implementation
{
    public class ATT_DL : IATT_DL
    {
        private readonly ConnectionStrings _dbConnections;
        private readonly ILogger _logger;

        public ATT_DL(
            IOptions<ConnectionStrings> dbConnections,
            ILogger logger)
        {
            _logger = logger;
            _dbConnections = dbConnections.Value;
        }

        /// <summary>
        /// Is First ATT Transaction
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        public async Task<bool> IsFirstATTTransaction(string accountId)
        {
            var storedProcedure = "tha_web_isfirstitopup";

            var parameters = new DynamicParameters();
            parameters.Add("@AccountId", accountId);
            parameters.Add("@IsFirstTopup", dbType: DbType.Boolean, direction: ParameterDirection.Output);
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var response = await dbConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                    return parameters.Get<bool>("@IsFirstTopup");
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Class: ATT_DL, Method: IsFirstATTTransaction");
            }
            return false;
        }

        /// <summary>
        /// Get ATT History
        /// </summary>
        /// <param name="request"></param>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task<ATTTransactions> GetATTHistory(TransferToTransactionsListRequest request, string account)
        {
            var paymentParm = new DynamicParameters();
            paymentParm.Add("@account", account, dbType: System.Data.DbType.String);

            IEnumerable<PaymentHistory> airTimeHistory = Enumerable.Empty<PaymentHistory>();

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                airTimeHistory = await dbConnection.QueryAsync<PaymentHistory>(
              "tha_itopup_history", paymentParm, commandType: System.Data.CommandType.StoredProcedure);
            }

			return new ATTTransactions()
			{
				transactions = airTimeHistory.Select(e => new AirtimeTransferHstory()
				{
					Amount = e.Amount.ToString(CultureInfo.InvariantCulture),
					//Type = 1,
					RecipientNumber = e.Msisdn,
					Status = e.IsSuccess ? "Sent" : "Failed",
					//NowtelTransactionReference = e.NowtelTransactionReference,
					TrxDateTIme = e.PaymentDate,
					Trxtimestamp = e.PaymentDate.ToString("HHmmssffff"),
					operatorLogoUrl = e.OperatorLogoUrl,
					OperatorName = e.OperatorName,
					Transactioncurrency = e.Currency,
					CustomerServiceid = "",
					PaymentMethod = e.Method,
					TransactionRef = e.IsSuccess ? e.Reference : "N/A"
				})
			};

		}
		//public async Task<ATTTransactions> GetATTHistory(TransferToTransactionsListRequest request)
		//{

		//    var response = new List<AirtimeTransferHstory>();

		//    ATTTransactions transactions = new ATTTransactions();

		//    List<AirtimeTransferHstory> listATT = new List<AirtimeTransferHstory>();

		//    //Transfer2Setting

		//    var storedProcedure = (string)null;

		//    //att_history '447903766622'

		//    var parameters = new DynamicParameters();
		//    parameters.Add("@clientNumber", request.clientNumber);

		//    try
		//    {
		//        storedProcedure = "tha_airtime_history";
		//        var result1 = await
		//        TalkHomeAppDb.SqlConnection.QueryAsync<AirtimeTransferHstory>(
		//            storedProcedure, parameters, commandType: CommandType.StoredProcedure);

		//        response.AddRange(result1);

		//        //return response;

		//    }
		//    catch (Exception ex)
		//    {
		//        Logger.Warning("Airtime Transfer history  Exception :" + ex.ToString());
		//    }


		//    try
		//    {
		//        storedProcedure = "tha_app2app_history";
		//        var result2 = await
		//        TalkHomeAppDigitalkDbConnection.SqlConnection.QueryAsync<AirtimeTransferHstory>(storedProcedure, parameters,
		//            commandType: CommandType.StoredProcedure);
		//        if (result2 != null && result2.ToList<AirtimeTransferHstory>().Count > 0)
		//            response.AddRange(result2);
		//    }
		//    catch (Exception ex)
		//    {
		//        Logger.Warning("Airtime Transfer history  Exception :" + ex.ToString());
		//    }


		//    try
		//    {
		//        storedProcedure = "transf2_history";
		//        var result3 = await
		//        TransferToDbConnection.SqlConnection.QueryAsync<AirtimeTransferHstory>(storedProcedure, parameters,
		//            commandType: CommandType.StoredProcedure);

		//        if (result3 != null && result3.ToList<AirtimeTransferHstory>().Count > 0)
		//            response.AddRange(result3);
		//    }
		//    catch (Exception ex)
		//    {
		//        Logger.Warning("Airtime Transfer history  Exception :" + ex.ToString());
		//    }
		//    if (response != null)
		//    {
		//        transactions.transactions = response.OrderByDescending(o => o.TrxDateTIme).ToList();
		//        return transactions;
		//    }
		//    else
		//        return transactions;

        //}

        /// <summary>
        /// Validate Nowtel Reference New
        /// </summary>
        /// <param name="nowtelreference"></param>
        /// <param name="product"></param>
        /// <returns></returns>
        public async Task<SochitelValidateExec> ValidateNowtelReferenceNew(string nowtelreference, string product)
        {
            PaymentConfigurations pc = new PaymentConfigurations();
            var storedProcedure = "at_att_getinfor";

			var parameters = new DynamicParameters();

			parameters.Add("@nowtelreference", nowtelreference);
			parameters.Add("@product", product);

            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.AttDb))
                {
                    var response = await dbConnection.QueryAsync<SochitelValidateExec>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

                    return response.FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                _logger.Warning("Airtime Transfer Exception :" + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Validate Nowtel Customer New
        /// </summary>
        /// <param name="frommsisdn"></param>
        /// <param name="nowtelreference"></param>
        /// <param name="product"></param>
        /// <param name="amount"></param>
        /// <returns></returns>
        public async Task<SochitelValidateCustomer> ValidateNowtelCustomerNew(string frommsisdn, string nowtelreference, string product, decimal amount)
        {
            SochitelValidateCustomer sochres = new SochitelValidateCustomer();
            var storedProcedure = "at_validate_customer_v5_pending";

			var parameters = new DynamicParameters();
			parameters.Add("@frommsisdn", frommsisdn);
			parameters.Add("@nowtelreference", nowtelreference);
			parameters.Add("@amount", amount);
			parameters.Add("@product", product);
			parameters.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
			parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
			parameters.Add("@isAllowed", dbType: DbType.Int32, direction: ParameterDirection.Output);

            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.AttDb))
                {
                    var response = await dbConnection.ExecuteAsync(storedProcedure, parameters,
                    commandType: CommandType.StoredProcedure);

                    if (parameters.Get<string>("@error_msg") != null)
                    {
                        sochres.errorCode = parameters.Get<Int32>("@error_code");
                        sochres.isAllowed = parameters.Get<Int32>("@isAllowed");
                        sochres.Message = parameters.Get<string>("@error_msg");
                    }
                    return sochres;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Class: ATT_DL, Method: ValidateNowtelCustomerNew");
            }
            return null;
        }

        /// <summary>
        /// Get Product By Nowtel Transaction Reference
        /// </summary>
        /// <param name="guid"></param>
        /// <param name="product"></param>
        /// <returns></returns>
        public async Task<DBProduct> GetProductByNowtelTransactionReference(string guid, string product)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@guid", guid);
            parameters.Add("@product", product);

            using (var dbConnection = new SqlConnection(_dbConnections.AttDb))
            {
                return await dbConnection.QueryFirstOrDefaultAsync<DBProduct>("at_getAPIAccessGUIDRecord_v3", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        /// <summary>
        /// Save Transaction
        /// </summary>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task SaveTransactionAsync(DBTransferTransaction transaction)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@AccountId", transaction.AccountId);
                parameters.Add("@PaymentTypeId", (int)transaction.PaymentTypeId); //app
                parameters.Add("@PaymentRef", transaction.PaymentRef);
                parameters.Add("@StatusId", transaction.StatusId);
                parameters.Add("@NowtelRef", transaction.NowtelRef);
                parameters.Add("@ClientCurrency", transaction.ClientCurrecny);
                parameters.Add("@ReceiverCurrency", transaction.ReceiverCurrecny);
                parameters.Add("@Product", transaction.Product);
                parameters.Add("@ItemPrice", transaction.ItemPrice);
                parameters.Add("@TotalPrice", transaction.TotalPrice);
                parameters.Add("@ServiceFee", transaction.ServiceFee);
                parameters.Add("@ServiceFeeDiscount", transaction.ServiceFeeDiscount);
                parameters.Add("@TotalServiceFee", transaction.TotalServiceFee);
                parameters.Add("@Discount", transaction.Discount);
                parameters.Add("@DiscountCode", transaction.DiscountCode);
                parameters.Add("@DiscountCodeType", transaction.DiscountCodeType);
                parameters.Add("@FromMsisdn", transaction.FromMsisdn);
                parameters.Add("@ToMsisdn", transaction.ToMsisdn);
                parameters.Add("@OperatorCountryName", transaction.OperatorCountryName);
                parameters.Add("@CountryCode", transaction.CountryCode);
                parameters.Add("@OperatorName", transaction.OperatorName);
                parameters.Add("@OperatorLogoUrl", transaction.OperatorLogoUrl);
                parameters.Add("@TransferRef", transaction.TransferRef);
                parameters.Add("@PaymentErrorMsg", transaction.PaymentErrorMsg);
                parameters.Add("@TransferErrorMsg", transaction.TransferErrorMsg);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync(
                        "tha_app_save_itopup_transactions_v2", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Class: ATT_DL, Method: ValidateNowtelCustomerNew");
            }
        }

        /// <summary>
        /// Get TranferTo Countries
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<TransferToCountries>> GetTranferToCountries()
        {

            using (var dbConnection = new SqlConnection(_dbConnections.AttDb))
            {
                return await dbConnection.QueryAsync<TransferToCountries>(
                             "at_GetTranferToCountries", commandType: CommandType.StoredProcedure);
            }
        }
		public async Task CreateTransactionLogAsync(InternationalTopupTransactionLog transaction)
		{
			try
			{
                using(var dbConnection=new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
				    var parameters = new DynamicParameters();
				    parameters.Add("@TransactionIdentifier", transaction.TransactionIdentifier);
				    parameters.Add("@ProductIdentifier", transaction.ProductIdentifier);
				    parameters.Add("@CustomerIdentifier", transaction.CustomerIdentifier);
				    parameters.Add("@ToMsisdn", transaction.ToMsisdn);
				    parameters.Add("@Currency", transaction.Currency);
				    parameters.Add("@ProductPrice", transaction.ProductPrice);
				    parameters.Add("@SalePrice", transaction.SalePrice);
				    parameters.Add("@DiscountApplied", transaction.DiscountApplied);
				    parameters.Add("@ServiceFee", transaction.ServiceFee);
				    parameters.Add("@DiscountOnServiceFee", transaction.DiscountOnServiceFee);
				    parameters.Add("@TotalPrice", transaction.TotalPrice);
				    parameters.Add("@CheckoutStatus", transaction.CheckoutStatus);
				    parameters.Add("@Message", transaction.Message);
				    await dbConnection.ExecuteAsync(
							    "tha_international_topup_logs_create", parameters, commandType: CommandType.StoredProcedure);
                }
			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: ATT_DL, Method: CreateTransactionLog");
			}
		}
		public async Task<InternationalTopupTransactionLog> GetTransactionLog(string nowtelRef, string product)
		{
			try
			{
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@TransactionIdentifier", nowtelRef);
                    parameters.Add("@ProductIdentifier", product);
                    return await dbConnection.QueryFirstOrDefaultAsync<InternationalTopupTransactionLog>(
                                "tha_international_topup_logs_get", parameters, commandType: CommandType.StoredProcedure);
                }
			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: ATT_DL, Method: GetTransactionLog");
				return null;
			}
		}
		public async Task UpdateTransactionLog(InternationalTopupTransactionLog transaction)
		{
			try
			{
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@TransactionIdentifier", transaction.TransactionIdentifier);
                    parameters.Add("@ProductIdentifier", transaction.ProductIdentifier);
                    parameters.Add("@ProductPrice", transaction.ProductPrice);
                    parameters.Add("@SalePrice", transaction.SalePrice);
                    parameters.Add("@DiscountApplied", transaction.DiscountApplied);
                    parameters.Add("@ServiceFee", transaction.ServiceFee);
                    parameters.Add("@DiscountOnServiceFee", transaction.DiscountOnServiceFee);
                    parameters.Add("@TotalPrice", transaction.TotalPrice);
                    parameters.Add("@CheckoutStatus", transaction.CheckoutStatus);
                    parameters.Add("@Message", transaction.Message);
                    await dbConnection.ExecuteAsync(
                                "tha_international_topup_logs_update", parameters, commandType: CommandType.StoredProcedure);
                }
			}
			catch (Exception ex)
			{
				_logger.Error(ex, "Class: ATT_DL, Method: UpdateTransactionLog");
			}
		}
	}
}
