﻿using Models.Enums;

namespace Models.Contracts.Request.Voucherify
{
    public class ValidateDiscountResponse
	{
        public string CampaignName { get; set; }
        public decimal Value { get; set; }
        public string DiscountCode  { get; set; }
        public DiscountType DiscountType { get; set; }
        public decimal Amount { get; set; }
        public decimal DiscountAmount { get; set; }
        public OrderDetail OrderDetails { get; set; }
		public class OrderDetail
		{
			public decimal ServiceFee { get; set; }
			public decimal ServiceFeeDiscount { get; set; }
			public decimal TotalServiceFee { get; set; }
		}
	}
}


