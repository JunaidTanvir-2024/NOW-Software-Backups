﻿using Serilog;

namespace SC.Core.Common.Helpers
{
    public static class EmailHelper
    {
        private static ILogger _logger;

        public static void RegisterLogger(ILogger logger, IConfiguration configuration)
        {
            _logger = logger;

        }

        public static string GenerateEmailContent(string templateName, Dictionary<string, string> templateparameters,string emailTemplatePath)
        {
            try
            {
                
                string projectFolder = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;
                string basePath = Path.Combine(projectFolder, emailTemplatePath);
                string filepath = Path.Combine(basePath, $"{templateName}.html");


                if (File.Exists(filepath))
                {
                    var templateContentBody = File.ReadAllText(filepath);

                    foreach (var item in templateparameters)
                    {
                        templateContentBody = templateContentBody.Replace(item.Key, item.Value);
                    }

                    return templateContentBody;
                }
                _logger.Error("Email Template does not Exist ");

                return default!;
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                throw;
            }
        }

        public static string GenerateEmailContentPurchase(string emailTemplatePath ,string templateName, Dictionary<string, string> templateparameters, string productsTable)
        {
            try
            {
                string projectFolder = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;
                string basePath = Path.Combine(projectFolder, emailTemplatePath);
                string filepath = Path.Combine(basePath, $"{templateName}.html");

                if (File.Exists(filepath))
                {
                    var templateContentBody = File.ReadAllText(filepath);

                    string templateString = string.Empty;
                    templateString = templateContentBody.Replace("{ProductBody}", productsTable);
                    foreach (var item in templateparameters)
                    {
                        templateString = templateString.Replace(item.Key, item.Value);
                    }

                      return templateString;
                }

                _logger.Error("Email Template does not Exist ");

                return default!;
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                throw;
            }
        }
    }
}