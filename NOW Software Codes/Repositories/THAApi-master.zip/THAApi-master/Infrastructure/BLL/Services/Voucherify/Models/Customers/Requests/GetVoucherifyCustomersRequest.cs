﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests
{
    public class GetVoucherifyCustomersRequest
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
