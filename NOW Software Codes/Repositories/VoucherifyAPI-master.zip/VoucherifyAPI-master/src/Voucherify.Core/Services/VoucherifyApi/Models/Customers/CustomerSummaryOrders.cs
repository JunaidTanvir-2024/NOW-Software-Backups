using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Customers;

public class CustomerSummaryOrders
{
    [JsonPropertyName("total_amount")]
    public long TotalAmount { get; }

    [JsonPropertyName("total_count")]
    public int TotalCount { get; }

    [JsonPropertyName("average_amount")]
    public long? AverageAmount { get; set; }

    [JsonPropertyName("last_order_amount")]
    public int? LastOrderAmount { get; set; }

    [JsonPropertyName("last_order_date")]
    public DateTime? LastOrderDate { get; set; }
}