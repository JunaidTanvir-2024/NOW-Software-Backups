﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface ITransfer_BL
    {
        Task<GenericApiResponse<UserAccountBalance>> ExecuteBalanceTransfer(TransferBalanceTransaction transaction);
        Task<GenericApiResponse<TransferBalanceTransaction>> SummariseBalanceTransfer(TransferBalanceRequest request);
    }
}
