﻿using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces;

public interface IUserService : IServicesType.IScopedService
{
    Task<bool> IsUserMsisdn(string msisdn);
    Task<bool> IsUserIn12MonthContract(string accountId);
}