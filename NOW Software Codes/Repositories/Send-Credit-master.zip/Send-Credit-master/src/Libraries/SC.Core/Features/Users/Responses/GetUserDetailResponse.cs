﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Users.Responses;
public sealed class GetUserDetailResponse
{
    public string UserID { get; set; } = default!;
    public string UserStatus { get; set; } = default!;
    public string UserToken { get; set; } = default!;
    public string TokenPurpose { get; set; } = default!;
}

