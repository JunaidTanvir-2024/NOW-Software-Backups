﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Infrastructure.Persistence.EntityFrameworkConfigurations
{
    public static class InititalizeDatabase
    {
        public static async Task InitializeDataBase(this IApplicationBuilder app)
        {
            var scopeFactory = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>();
            var scope = scopeFactory.CreateScope();
            {
                var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
                foreach (var item in new List<string>() { nameof(UserRole.Admin), nameof(UserRole.Customer), nameof(UserRole.Guest) })
                {
                    if (!await roleManager.RoleExistsAsync(item))
                    {
                        await roleManager.CreateAsync(new IdentityRole(item));
                    }
                }
            }
        }
    }
}