﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ThaPromotionsApi.Infrastructure.BLL
{
   
    public interface IApiCall
    {
        Task<HttpResponseMessage> Get(string Uri, params string[] parameters);
        Task<HttpResponseMessage> Get(string Uri);
        Task<HttpResponseMessage> Post(string Uri, object postDataModel);
        Task<HttpResponseMessage> PostUrlEncoded(string Uri, List<KeyValuePair<string, string>> postDataModel);
    }
}
