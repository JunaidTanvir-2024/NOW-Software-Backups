using Application.Features.Bundle.AutoRenewal.ExistingCard;
using Application.Features.Bundle.AutoRenewal.NewCard;
using Application.Features.Payment.Models;
using Mapster;

namespace Application.Common.MappingProfiles;

public class AutoRenewalNewCardProfile : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<AutoRenewalNewCardRequest, PaymentBundleInfo>
       .NewConfig()
       .Map(paymentBundleInfo => paymentBundleInfo.BundleId!, source => source.BundleId)
       .Map(paymentBundleInfo => paymentBundleInfo.IsRenewable, source => source.IsAutoRenew);
    }
}

public class AutoRenewalExistingCardProfile : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<AutoRenewalExistingCardRequest, PaymentBundleInfo>
       .NewConfig()
       .Map(paymentBundleInfo => paymentBundleInfo.BundleId!, source => source.BundleId)
       .Map(paymentBundleInfo => paymentBundleInfo.IsRenewable, source => source.IsAutoRenew);
    }
}