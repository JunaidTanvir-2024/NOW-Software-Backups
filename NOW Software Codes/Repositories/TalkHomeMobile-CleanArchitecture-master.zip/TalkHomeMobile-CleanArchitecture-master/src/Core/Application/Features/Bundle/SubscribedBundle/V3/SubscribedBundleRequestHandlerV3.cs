﻿using Application.Common.Interfaces;
using Application.Features.Account.ProductSummary;
using Application.Features.Bundle.Bundle;
using Application.Features.Bundle.Model;
using Domain.Entities;

namespace Application.Features.Bundle.SubscribedBundle.V3;
public class SubscribedBundleRequestHandlerV3 : IRequestHandler<SubscribedBundleRequestV3, Result<List<SubscribedBundleInfo>>>
{
    #region Fields

    private readonly IUnitOfWork _unitOfWork;
    private readonly IStringLocalizer<SubscribedBundleRequestHandlerV3> _localizer;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;
    private readonly IBundleService _bundleService;
    #endregion

    #region Ctors

    public SubscribedBundleRequestHandlerV3(
        IUnitOfWork unitOfWork,
        IStringLocalizer<SubscribedBundleRequestHandlerV3> localizer,
        IMapper mapper,
        ICommonService commonService,
        IUserService userService,
        IBundleService bundleService)
    {
        _unitOfWork = unitOfWork;
        _localizer = localizer;
        _mapper = mapper;
        _commonService = commonService;
        _userService = userService;
        _bundleService = bundleService;
    }

    #endregion
    #region Methods

    public async Task<Result<List<SubscribedBundleInfo>>> Handle(SubscribedBundleRequestV3 request, CancellationToken cancellationToken)
    {
        (bool IsMobileRequest, DeviceType? DeviceType, MediumType MediumType) = _commonService.IsAppRequest();
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<List<SubscribedBundleInfo>>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdnDetails == null)
        {
            return Result<List<SubscribedBundleInfo>>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var subscribeBundlesList = await _bundleService.GetSubscribedBundlesByAccountId(msisdnDetails);

        return Result<List<SubscribedBundleInfo>>.Success(subscribeBundlesList, _localizer[CustomStatusKey.Success]);
    }

    #endregion

}
