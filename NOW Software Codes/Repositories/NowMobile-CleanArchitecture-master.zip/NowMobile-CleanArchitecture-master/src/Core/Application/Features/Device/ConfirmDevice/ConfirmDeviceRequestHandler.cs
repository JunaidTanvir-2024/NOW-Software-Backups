﻿using Application.Common.Interfaces.Infrastructure.Identity;

namespace Application.Features.Device.ConfirmDevice;

public class ConfirmDeviceRequestHandler : IRequestHandler<ConfirmDeviceRequest, Result<object>>
{
    #region Fields

    private readonly IStringLocalizer<ConfirmDeviceRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly IOtpService _otpService;

    #endregion

    #region Ctor

    public ConfirmDeviceRequestHandler(
        IStringLocalizer<ConfirmDeviceRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService,
        IOtpService otpService)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _otpService = otpService;
    }

    #endregion

    #region Methods

    public async Task<Result<object>> Handle(ConfirmDeviceRequest request, CancellationToken cancellationToken)
    {
        //Check if request is from App
        (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();
        User? user;

        request.EmailOrPhone = request.EmailOrPhone.Trim().Normalize();

        if (_commonService.IsValidEmailAddress(request.EmailOrPhone))
        {
            user = await _unitOfWork.UserRepo.GetUserByEmail(request.EmailOrPhone);
        }
        else
        {
            request.EmailOrPhone = _commonService.FormatMsisdn(request.EmailOrPhone);
            user = await _unitOfWork.UserRepo.GetUserByMsisdn(request.EmailOrPhone);
        }

        //User not registered
        if (user == null)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.AccountNotRegistered], CustomStatusCode.AccountNotRegistered);
        }

        //Check user for any type of deactivation


        //Verify Otp
        var otpResponse = await _otpService.VerifyOtp(request.Otp, request.EmailOrPhone + "-" + request.DeviceId, OtpType.Device, null);
        if (otpResponse.Code == (int) CustomStatusCode.InvalidOtp)
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.InvalidOtp], CustomStatusCode.InvalidOtp);
        }

        //Mark current device as confirmed
        await _unitOfWork.DeviceRepo.MarkDeviceAsConfirmed(request.DeviceId, user.Id);

        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}