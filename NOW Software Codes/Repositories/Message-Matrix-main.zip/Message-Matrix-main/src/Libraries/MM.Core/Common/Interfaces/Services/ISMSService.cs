using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MM.Core.Common.DTOs;

namespace MM.Core.Common.Interfaces.Services;
public interface ISMSService
{
    Task<bool> SendTwilioSms(SmsRequestDTO twilioSmsRequest);
    Task<bool> SendMarketingSms(SmsRequestDTO smsRequest);
}
