using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.InternationalBundle;

public sealed class InternationalBundleRequest : IRequest<Result<List<BundleInfo>>>
{
    public string? Msisdn { get; set; } = null;
    public string? CountryCode { get; set; } = null;
}
