﻿namespace Application.Common.Models;

public static class CurrencySymbol
{
    public const string GBP = "£";
}