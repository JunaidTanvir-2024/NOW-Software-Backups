﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;

namespace TalkhomeAPI.Services.Interfaces
{
    public interface ICommonService
    {
        Task<GenericApiResponse<GetAddressByPostCodeResponseModel>> GetAddressByPostCode(
           GetAddressByPostCodeRequestModel model);
    }
}
