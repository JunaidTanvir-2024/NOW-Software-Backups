using Hangfire;
using Infrastructure;
using PhoneNumbers;
using Serilog;
using Infrastructure.BLL.Interfaces;
using Microsoft.Extensions.Localization;
using Microsoft.AspNetCore.Localization;
using System.Globalization;
using Hangfire.MemoryStorage;
using THA.Daemon.Utilities;
using THAApi.Resources;

var builder = WebApplication.CreateBuilder(args);

string environment = builder.Configuration["AppEnvironment"]!;
string port = builder.Configuration["AppUrl"]!;

Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", environment);
//set custom port from appsettings
builder.WebHost.UseUrls($"http://*:{port}");

// Add Hangfire services.
builder.Services.AddHangfire(configuration => configuration
	.SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
	.UseSimpleAssemblyNameTypeSerializer()
	.UseRecommendedSerializerSettings()
	.UseMemoryStorage()
	);

// Add the processing server as IHostedService
builder.Services.AddHangfireServer();

//Setup Serilog File logging and Sentry logging
builder.Services.AddSingleton((Serilog.ILogger)new LoggerConfiguration()
						.MinimumLevel.Debug()
						.WriteTo.RollingFile(Path.Combine(builder.Configuration.GetSection("Serilog")["FilePath"], "THAAPI-log-{Date}.txt"))
						.WriteTo.Sentry(options => builder.Configuration.Bind("Sentry", options))
						.CreateLogger());

builder.Services.AddLocalization();
//I have registered this service so that we can use global level localization
builder.Services.AddScoped<IStringLocalizer, StringLocalizer<Language>>();

builder.Services.AddHttpContextAccessor();
builder.Services.RegisterAppSettingsConfig(builder.Configuration);
builder.Services.AddSingleton(PhoneNumberUtil.GetInstance());
builder.Services.RegisterBLServices(builder.Configuration);
builder.Services.RegisterDLServices();

// Add framework services.
builder.Services.AddMvc();

var app = builder.Build();
var DelaysInSeconds = new int[] { 900, 1800, 3600, 7200 };//900 seconds=15 minutes, 1800 seconds=30 minutes 3600=1 hour,7200=2 hours

GlobalJobFilters.Filters.Add(new AutomaticRetryAttribute { Attempts = 4, DelaysInSeconds = DelaysInSeconds });

app.UseHangfireDashboard();// This will enable the dashboard to view the stats of job (url:/hangfire)

RecurringJob.AddOrUpdate<IUserAccount_BL>("DeleteAccountsJob", x =>
	x.DeleteAccountsRequestsAsync(),
	Cron.Daily());

var supportedCultures = new List<CultureInfo>()
			{
			   new CultureInfo("el"),
			   new CultureInfo("nl"),
			   new CultureInfo("de"),
			   new CultureInfo("fr"),
			   new CultureInfo("en"),
			   new CultureInfo("es"),
			   new CultureInfo("sv"),
			   new CultureInfo("it"),
			   new CultureInfo("nb"),
			   new CultureInfo("pt"),
			   new CultureInfo("tr"),
			   new CultureInfo("fil"),
			   new CultureInfo("vi")
			};
app.UseRequestLocalization(new RequestLocalizationOptions
{
	DefaultRequestCulture = new RequestCulture("en"),
	// Formatting numbers, dates, etc.
	SupportedCultures = supportedCultures,
	// UI strings that we have localized.
	SupportedUICultures = supportedCultures
});

app.UseRouting();
app.UseEndpoints(endpoints =>
{
	_ = endpoints.MapHangfireDashboard();
});

app.Run();
