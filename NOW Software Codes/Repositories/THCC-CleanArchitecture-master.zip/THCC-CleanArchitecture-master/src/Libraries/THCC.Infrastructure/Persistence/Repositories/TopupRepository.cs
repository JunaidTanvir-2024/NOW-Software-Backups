﻿using System.Data;
using Dapper;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

using Serilog;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Settings;
using THCC.Domain.Constants;
using THCC.Domain.Entities;
using THCC.Infrastructure.Persistence.DapperConfigurations;

using static THCC.Domain.Constants.ThccConstants;
using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Persistence.Repositories
{
    internal sealed class TopupRepository : ITopupRepository
    {
        #region Fields
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;
        private readonly AutoTopupServiceSettings _autoTopupServiceSettings;


        #endregion

        #region Ctor
        public TopupRepository(IConfiguration configuration,
            ILogger logger,
            IOptions<AutoTopupServiceSettings> autoTopupServiceSettings)
        {
            _configuration = configuration;
            _logger = logger;
            _autoTopupServiceSettings = autoTopupServiceSettings.Value;
        }

        #endregion

        #region Methods

        public async Task DisableAutoTopup(string account)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@account", account.Trim());

            await DapperWrapper.ExecuteAsync(
                StoredProcedures.DisableAutoTopup, parameters, CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.BackHome));
        }

        public async Task<AutoTopup> GetAutoTopup(string accountNumber, string userEmail)
        {
            DynamicParameters param = new();
            param.Add("@account", accountNumber);
            param.Add("@Email", userEmail);
            param.Add("@ProductCode", nameof(ProductCode.THCC));
            return await DapperWrapper.QueryFirstOrDefaultAsync<AutoTopup>(StoredProcedures.GetAutoTopup, param, CommandType.StoredProcedure, _configuration.GetConnectionString(ThccConstants.ConnectionStrings.BackHome));
        }

        public async Task SetAutoTopup(bool isAutoTopup, string accountNumber, string userEmail, decimal topupAmount, string topupCurrency, decimal topupTheresholdAmount, string paymentMethod = default!, string cardMaskedPan = default!, string cardInitialTransactionId = default!)
        {
            if (string.IsNullOrEmpty(topupCurrency))
            {
                topupCurrency = nameof(Currency.GBP);
            }
            var parameters = new DynamicParameters();
            parameters.Add("@threshold", topupTheresholdAmount);
            parameters.Add("@account", accountNumber);
            parameters.Add("@TopupAmount", topupAmount);
            parameters.Add("@TopupCurrency", topupCurrency);
            parameters.Add("@Email", userEmail);
            parameters.Add("@ProductCode", nameof(ProductCode.THCC));
            parameters.Add("@IsAutoTopup", isAutoTopup);
            parameters.Add("@PaymentMethod", paymentMethod);
            parameters.Add("@MaskedPan", cardMaskedPan);
            parameters.Add("@InitialTransactionId", cardInitialTransactionId);
            await DapperWrapper.ExecuteAsync(StoredProcedures.UpdateAutoTopupStatus, parameters, CommandType.StoredProcedure, _configuration.GetConnectionString(ThccConstants.ConnectionStrings.BackHome));
        }


        #region AutoTopup Daemon

        public async Task<IEnumerable<AutoTopUpTransactions>> GetAutoTopupTransactions()
        {
            return await DapperWrapper.QueryAsync<AutoTopUpTransactions>
                (_autoTopupServiceSettings.AutoTopupSimulationMode ? StoredProcedures.GetTHRCCAutoTopupTransactionsSimulation : StoredProcedures.GetTHRCCAutoTopupTransactions,
                param: null,
                CommandType.StoredProcedure,
                _configuration.GetConnectionString(ThccConstants.ConnectionStrings.BackHome));
        }

        public async Task<decimal> GetCurrentMonthAutoTopupAmount(string productItemCode, string cardNumber, string cardPin)
        {
            string loggingParameters = $"productItemCode={productItemCode} cardNumber={cardNumber}";
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@ProductItemCode", productItemCode);
                parameters.Add("@CardNumber", cardNumber);
                parameters.Add("@PinNumber", cardPin);

                return await DapperWrapper.QueryFirstAsync<decimal>(
                 StoredProcedures.CurrentMonthAutoTopupAmount,
                 param: parameters,
                 CommandType.StoredProcedure,
                 _configuration.GetConnectionString(ConnectionStrings.CentralizedPayment));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TopupRepository, Method: GetCurrentMonthAutoTopupAmount, Parameters => {loggingParameters}, ErrorMessage: {ex.Message}");
                return 0;
            }
        }

        public async Task AddAutoTopupTransaction(
            int customerId,
            string customerMerchantRef,
            string pay360TransactionId,
            float transactionAmount,
            string transactionCurrency,
            DateTime? transactionDate,
            bool isTransactionSuccess,
            string transactionErrorMessage,
            bool isFullfilmentSuccess,
            string fullfilmentErrorMessage,
            DateTime? fullfilmentDate,
            string fullfilmentRef,
            bool isSmsSent,
            DateTime? smsSentDate,
            bool isEmailSent,
            DateTime? emailSentDate)
        {
            string loggingParameters = $" customerId: {customerId}, customerMerchantRef: {customerMerchantRef}, pay360TransactionId: {pay360TransactionId}, transactionAmount: {transactionAmount}, transactionCurrency: {transactionCurrency}, transactionDate: {transactionDate}, isTransactionSuccess: {isTransactionSuccess}, transactionErrorMessage: {transactionErrorMessage}, isFullfilmentSuccess: {isFullfilmentSuccess}, fullfilmentErrorMessage: {fullfilmentErrorMessage}, fullfilmentDate: {fullfilmentDate}, fullfilmentRef: {fullfilmentRef}, isSmsSent: {isSmsSent}, smsSentDate: {smsSentDate}, isEmailSent: {isEmailSent}, emailSentDate: {emailSentDate} ";
            try
            {

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Customer_Id", customerId);
                parameters.Add("@CustomerMerchantRef", customerMerchantRef);
                parameters.Add("@Pay360TransactionId", pay360TransactionId);
                parameters.Add("@TransactionAmount", transactionAmount);
                parameters.Add("@TransactionCurrency", transactionCurrency);
                parameters.Add("@TransactionDate", transactionDate);
                parameters.Add("@IsTransactionSuccess", isTransactionSuccess);
                parameters.Add("@TransactionErrorMessage", transactionErrorMessage);
                parameters.Add("@IsFullfilmentSuccess", isFullfilmentSuccess);
                parameters.Add("@FullfilmentErrorMessage", fullfilmentErrorMessage);
                parameters.Add("@FullfilmentDate", fullfilmentDate);
                parameters.Add("@FullfilmentRef", fullfilmentRef);
                parameters.Add("@IsSmsSent ", isSmsSent);
                parameters.Add("@SmsSentDate", smsSentDate);
                parameters.Add("@IsEmailSent", isEmailSent);
                parameters.Add("@EmailSentDate", emailSentDate);

                await DapperWrapper.ExecuteAsync(StoredProcedures.AddAutoTopupTransaction, parameters, CommandType.StoredProcedure,
                    _configuration.GetConnectionString(ThccConstants.ConnectionStrings.CentralizedPayment));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: {typeof(TopupRepository)}, Method: AddAutoTopupTransaction, Parameters => {loggingParameters}, ErrorMessage: {ex.Message}");
            }
        }

        public async Task<int> UpdateTHRCCAutoTopupTransaction(bool isSuccess,
            string errorMessage,
            DateTime lastExecutionTime,
            string msisdn,
            int errorCode,
            int reExecuteCount,
            string email,
            string productCode,
            string account)
        {
            // TODD : remove the msisdn param for function it has no use - plx

            string loggingParameters = $" isSuccess: {isSuccess}, errorMessage: {errorMessage}, lastExecutionTime: {lastExecutionTime}, msisdn: {msisdn}, errorCode: {errorCode}, reExecuteCount: {reExecuteCount}, email:{email}, productCode: {productCode} ";
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@IsSuccess", isSuccess);
                parameters.Add("@ErrorMessage", errorMessage);
                parameters.Add("@LastExecutionDate", lastExecutionTime);
                parameters.Add("@account", account);
                parameters.Add("@ErrorCode", errorCode);
                parameters.Add("@ReExecuteCount", reExecuteCount);
                parameters.Add("@Email", email);
                parameters.Add("@ProductCode", productCode);


                var result = await DapperWrapper.ExecuteReturnAsync(StoredProcedures.UpdateAutoTopupTransaction, parameters, CommandType.StoredProcedure,
                    _configuration.GetConnectionString(ThccConstants.ConnectionStrings.BackHome));
                if (result < 1)  // Un-Successfull
                {
                    _logger.Error($"Class: {typeof(TopupRepository)}, Method: UpdateTHRCCAutoTopupTransaction, Parameters => {loggingParameters}, ErrorMessage: Error in Transaction updation");
                }
                return result;

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: {typeof(TopupRepository)}, Method: UpdateTHRCCAutoTopupTransaction, Parameters => {loggingParameters}, ErrorMessage: {ex.Message}");
                return 0;
            }

        }

        #endregion

        #endregion

    }
}
