using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class Otp : IBaseEntity<long>
{
    public long Id { get; set; }
    public string Code { get; set; } = null!;
    public ushort Type { get; set; }
    public ushort UsageCount { get; set; }
    public bool IsAlreadyUsed { get; set; }
    public bool IsRetryLimitExceeded { get; set; }
    public bool IsBlocked { get; set; }
    public DateTime ExpiryTime { get; set; }
    public DateTime? BlockTime { get; set; }
    public long UserId { get; set; }
    public User User { get; set; } = null!;
}
