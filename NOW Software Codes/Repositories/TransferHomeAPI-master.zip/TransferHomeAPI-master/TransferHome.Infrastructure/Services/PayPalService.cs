﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using TransferHome.Models.Contracts.Service.PaypalApiContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TrasnferHome.Models.Configurations;
using TransferHome.Infrastructure.Services.Interfaces;
using System.Diagnostics;

namespace TransferHome.Infrastructure.Services
{
    public class PayPalService : IPayPalService
    {
        private readonly string PayPalApiEndpoint;

        public PayPalService(IOptions<PayPalConfig> payPalConfig)
        {
            PayPalApiEndpoint = payPalConfig.Value.PayPalApiEndpoint;
        }

        public string GetResumeUrl(string path, string baseUrl)
        {
            string Domain = "";
            Uri result = null;

            if (Debugger.IsAttached)
            {
                if (Uri.TryCreate(new Uri(baseUrl), path, out result))
                {
                    Domain = result.AbsoluteUri;
                }
                else
                {
                    Domain = baseUrl + "/" + path;
                }
            }
            else
            {
                if (Uri.TryCreate(new Uri(baseUrl), path, out result))
                {
                    Domain = result.AbsoluteUri.Replace("http", "https");
                }
                else
                {
                    Domain = new Uri(baseUrl).ToString();
                    Domain = Domain.Replace("http", "https");
                    Domain = Domain + path;
                }
                
            }

            return Domain;

        }

        public async Task<GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>> PayPalCreateSalePayment(PayPalCreateSalePaymentRequest request)
        {
            GenericPayPalApiResponse<PayPalCreateSalePaymentResponse> ret = new GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";
            endpoint = PayPalApiEndpoint + "Paypal/CreateSalePayment";
            Json = JsonConvert.SerializeObject(request);
            Result = await Post(endpoint, Json);
            if (Result == null)
            {
                return null;
            }
            ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>>(Result);
            return ret;

        }

        public async Task<GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>> PayPalExecuteSalePayment(PayPalExecuteSalePaymentRequest request)
        {
            GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse> ret = new GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";
            endpoint = PayPalApiEndpoint + "Paypal/ExecuteSalePayment";
            Json = JsonConvert.SerializeObject(request);
            Result = await Post(endpoint, Json);
            if (Result == null)
            {
                return null;
            }
            ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>>(Result);
            return ret;

        }

        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address), Timeout = TimeSpan.FromSeconds(60) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                    {
                        throw new WebException();
                    }

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (System.Exception e)
            {
                return null;
            }
        }
    }
}
