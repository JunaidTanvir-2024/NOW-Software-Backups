﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class GetSpecificSimOrderDetailsRequestModel
    {
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Please provide valid OrderId")]
        public int OrderId { get; set; }
    }
}
