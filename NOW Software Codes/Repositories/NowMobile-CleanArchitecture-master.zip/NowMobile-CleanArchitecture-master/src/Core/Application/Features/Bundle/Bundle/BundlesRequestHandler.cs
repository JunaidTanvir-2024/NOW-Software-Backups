using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.Bundle;

public sealed class BundlesRequestHandler : IRequestHandler<BundlesRequest, Result<List<BundleInfo>>>
{
    #region Fields

    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<BundlesRequestHandler> _localizer;
    private readonly ICommonService _commonService;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;
    private readonly IUserService _userService;

    public BundlesRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<BundlesRequestHandler> localizer,
        ICommonService commonService,
        IMapper mapper,
        ICurrentUser currentUser,
        IUserService userService)
    {
        _uow = uow;
        _localizer = localizer;
        _commonService = commonService;
        _mapper = mapper;
        _currentUser = currentUser;
        _userService = userService;
    }

    #endregion

    #region Methods
    public async Task<Result<List<BundleInfo>>> Handle(BundlesRequest request, CancellationToken cancellationToken)
    {
        var bundles = new List<BundleInfo>();
        (bool IsMobileRequest, DeviceType? DeviceType, int MediumType) = _commonService.IsAppRequest();

        if (!string.IsNullOrEmpty(request.Msisdn))
        {
            request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        }

        if (_currentUser.IsAuthenticated() && !string.IsNullOrEmpty(request.Msisdn))
        {
            request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
            if (!await _userService.IsUserMsisdn(request.Msisdn))
            {
                return Result<List<BundleInfo>>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            }
        }
        //national and data bundles sorting by price
        var nationalBundles = _mapper.Map<List<BundleInfo>>(await _uow.BundleRepo.GetBundles(request))
         .OrderBy(x => x.TotalPrice).Where(x => x.Category !=(int) BundleCategory.International).ToList();

        // international bundles sorting by name
        var internationalBundles = _mapper.Map<List<BundleInfo>>(await _uow.BundleRepo.GetBundles(request))
            .Where(x => x.Category == (int) BundleCategory.International).ToList();

        //concat both lists
        bundles = nationalBundles.Concat(internationalBundles).ToList();

        if (bundles.Any() && string.IsNullOrEmpty(request.Msisdn) && IsMobileRequest)
        {
            bundles.ForEach(x => x.IsAvailable = false);
        }
        return Result<List<BundleInfo>>.Success(bundles, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}