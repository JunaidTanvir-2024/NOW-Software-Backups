﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Requests
{
    public class GetPromotionTierByIdRequest
    {
        public string PromotionTierId { get; set; } = null!;
    }
}
