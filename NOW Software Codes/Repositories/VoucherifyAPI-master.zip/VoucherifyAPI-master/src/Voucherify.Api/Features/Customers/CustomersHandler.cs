using RW;

using Voucherify.Api.Features.Campaigns.Responses;

using Voucherify.Api.Features.Customers.Requests;
using Voucherify.Api.Features.Customers.Responses;
using Voucherify.Core.Domain.Definitions;
using Voucherify.Core.Services.VoucherifyApi;
using Voucherify.Core.Services.VoucherifyApi.Definations;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;

namespace Voucherify.Api.Features.Customers;

public interface ICustomersHandler
{
    Task<IResultWrapper<CustomerResponse>> CreateCustomer(AddCustomerRequest request);
    Task<IResultWrapper<CustomerResponse>> DeleteCustomer(DeleteCustomerRequest request);
    Task<IResultWrapper<CustomerResponse>> GetCustomer(GetCustomerRequest request);
    Task<IResultWrapper<List<CustomerResponse>>> GetCustomers(GetCustomersRequest request);
    Task<IResultWrapper<CustomerResponse>> UpdateCustomer(UpdateCustomerRequest request);
    Task<IResultWrapper<ReferralCodeResponse>> GetInvitationCode(GetReferralCodeRequest request);
    Task<IResultWrapper<List<CampaignResponse>>> GetCampaignsAgainstCustomer(GetCustomerCampaignsRequest request);
    Task<IResultWrapper<CustomerLoyaltyCardResponse>> GetCustomerLoyaltyCard(GetCustomerLoyaltyCardRequest request);
}

public class CustomersHandler : ICustomersHandler
{
    private const string Customer = "Customer";
    private const string CustomerCampaigns = "Customer";
    private const string ReferralCode = "ReferralCode";
    private const string Customers = "Customers";

    private readonly IVoucherifyImplementation _voucherifyImplementation;

    public CustomersHandler(IVoucherifyImplementation voucherifyImplementation)
    {
        _voucherifyImplementation = voucherifyImplementation;
    }
    public async Task<IResultWrapper<List<CustomerResponse>>> GetCustomers(GetCustomersRequest request)
    {

        List<Customer>? customers = await _voucherifyImplementation.GetCustomers(request.PageNumber, request.PageSize);
        if (customers != null)
        {
            List<CustomerResponse>? result = customers?.Select(customer => new CustomerResponse()
            {
                SourceId = customer?.SourceId,
                Name = customer?.Name,
                Phone = customer?.Phone,
                Email = customer?.Email,
                Description = customer?.Description,
                Metadata = customer?.Metadata,
                City = customer?.Address?.City,
                Country = customer?.Address?.Country,
                AddressLine1 = customer?.Address?.Line1,
                AddressLine2 = customer?.Address?.Line2,
                PostalCode = customer?.Address?.PostalCode,
                State = customer?.Address?.PostalCode,
                Points = (customer?.Loyalty?.Points) ?? 0,
                RedeemedPoints = (customer?.Summary?.Redemptions?.LoyaltyCard?.RedeemedPoints) ?? 0,
                ReferredCustomers = (customer?.Loyalty?.ReferredCustomers) ?? 0,
                LoyaltyCampaigns = customer?.Loyalty?.Campaigns
            }).ToList();

            return ResultWrapper.Success(result);
        }
        return ResultWrapper.Failure<List<CustomerResponse>>(AppConstants.StatusMessages.CustomerNotFound, AppConstants.StatusCodes.CustomerNotFound);
    }
    public async Task<IResultWrapper<CustomerLoyaltyCardResponse>> GetCustomerLoyaltyCard(GetCustomerLoyaltyCardRequest request)
    {
        var loyaltyCards = await _voucherifyImplementation.GetLoyaltyCards(customerSourceId: request.CustomerSourceId, campaignId: request.LoyaltyCampaignId);
        return loyaltyCards != null && loyaltyCards.Count > 0 ?
            ResultWrapper.Success(new CustomerLoyaltyCardResponse()
            {
                LoyaltyCard = loyaltyCards?.Select(voucher => voucher.Code).First(),
                CustomerId = loyaltyCards?.Select(voucher => voucher.HolderId).First()
            }) :
            ResultWrapper.Success(new CustomerLoyaltyCardResponse() { LoyaltyCard = null, CustomerId = request.CustomerSourceId });
    }
    public async Task<IResultWrapper<CustomerResponse>> GetCustomer(GetCustomerRequest request)
    {
        var customer = await _voucherifyImplementation.GetCustomer(request.CustomerSourceId);

        var loyaltyCards = await GetCustomerLoyaltyCard(new GetCustomerLoyaltyCardRequest() { CustomerSourceId = request.CustomerSourceId, LoyaltyCampaignId = request.LoyaltyCampaignId });

        return customer != null ?
            ResultWrapper.Success(new CustomerResponse()
            {
                Id = customer?.Id,
                SourceId = customer?.SourceId,
                Name = customer?.Name,
                Phone = customer?.Phone,
                Email = customer?.Email,
                Description = customer?.Description,
                Metadata = customer?.Metadata,
                City = customer?.Address?.City,
                Country = customer?.Address?.Country,
                AddressLine1 = customer?.Address?.Line1,
                AddressLine2 = customer?.Address?.Line2,
                PostalCode = customer?.Address?.PostalCode,
                State = customer?.Address?.PostalCode,
                Points = (customer?.Loyalty?.Points) ?? 0,
                RedeemedPoints = (customer?.Summary?.Redemptions?.LoyaltyCard?.RedeemedPoints) ?? 0,
                ReferredCustomers = (customer?.Loyalty?.ReferredCustomers) ?? 0,
                LoyaltyCampaigns = customer?.Loyalty?.Campaigns,
                LoyaltyCard = loyaltyCards?.Payload == null ? null : loyaltyCards.Payload.LoyaltyCard
            }) :
            ResultWrapper.Failure<CustomerResponse>(AppConstants.StatusMessages.CustomerNotFound, AppConstants.StatusCodes.CustomerNotFound);
    }
    public async Task<IResultWrapper<CustomerResponse>> CreateCustomer(AddCustomerRequest request)
    {
        // Request mapping
        var addNewCustomer = new CustomerCreate()
        {
            SourceId = request.SourceId,
            Address = new Address()
            {
                City = request.City,
                Country = request.Country,
                Line1 = request.AddressLine1,
                Line2 = request.AddressLine2,
                PostalCode = request.PostalCode,
                State = request.State
            },
            Description = request.Description,
            Email = request.Email,
            Name = request.Name,
            Phone = request.Phone,
            Metadata = request.Metadata,
        };

        var customer = await _voucherifyImplementation.CreateCustomer(addNewCustomer);

        // Response mapping
        return customer != null ?
            ResultWrapper.Success(new CustomerResponse()
            {
                Id = customer?.Id,
                SourceId = customer?.SourceId,
                Name = customer?.Name,
                Phone = customer?.Phone,
                Email = customer?.Email,
                Description = customer?.Description,
                Metadata = customer?.Metadata,
                City = customer?.Address?.City,
                Country = customer?.Address?.Country,
                AddressLine1 = customer?.Address?.Line1,
                AddressLine2 = customer?.Address?.Line2,
                PostalCode = customer?.Address?.PostalCode,
                State = customer?.Address?.PostalCode,
                Points = (customer?.Loyalty?.Points) ?? 0,
                ReferredCustomers = (customer?.Loyalty?.ReferredCustomers) ?? 0
            }) :
            ResultWrapper.Failure<CustomerResponse>(AppConstants.StatusMessages.CustomerNotCreated, AppConstants.StatusCodes.CustomerNotCreated);
    }
    public async Task<IResultWrapper<CustomerResponse>> UpdateCustomer(UpdateCustomerRequest request)
    {
        // Request mapping
        var updateCustomer = new CustomerUpdate()
        {
            //Address = request.Address,
            //Description = request.Description,
            //Email = request.Email,
            //Name = request.Name,
            //Phone = request.Phone,
            Metadata = request.Metadata
        };

        var customer = await _voucherifyImplementation.UpdateCustomer(request.SourceId, updateCustomer);
        return customer != null ?
            ResultWrapper.Success(new CustomerResponse()
            {
                SourceId = customer?.SourceId,
                Name = customer?.Name,
                Phone = customer?.Phone,
                Email = customer?.Email,
                Description = customer?.Description,
                Metadata = customer?.Metadata,
                City = customer?.Address?.City,
                Country = customer?.Address?.Country,
                AddressLine1 = customer?.Address?.Line1,
                AddressLine2 = customer?.Address?.Line2,
                PostalCode = customer?.Address?.PostalCode,
                State = customer?.Address?.PostalCode,
                Points = (customer?.Loyalty?.Points) ?? 0,
                ReferredCustomers = (customer?.Loyalty?.ReferredCustomers) ?? 0
            }) :
            ResultWrapper.Failure<CustomerResponse>(AppConstants.StatusMessages.CustomerNotUpdated, AppConstants.StatusCodes.CustomerNotUpdated);
    }
    public async Task<IResultWrapper<CustomerResponse>> DeleteCustomer(DeleteCustomerRequest request)
    {
        var result = await _voucherifyImplementation.DeleteCustomer(request.CustomerSourceId);
        return result ?
            ResultWrapper.Success<CustomerResponse>() :
            ResultWrapper.Failure<CustomerResponse>(AppConstants.StatusMessages.CustomerNotDeleted, AppConstants.StatusCodes.CustomerNotDeleted);
    }
    public async Task<IResultWrapper<ReferralCodeResponse>> GetInvitationCode(GetReferralCodeRequest request)
    {
        var referralCodePublicationResult = await _voucherifyImplementation.CreatePublication(request.CampaignNameOrId, request.CustomerSourceId);

        return referralCodePublicationResult!.Result!.Equals(nameof(VoucherifyEnums.RedemptionResult.Success), StringComparison.OrdinalIgnoreCase) ?

            ResultWrapper.Success(new ReferralCodeResponse()
            {
                ReferralCode = referralCodePublicationResult.Voucher?.Code,
                ReferrerId = referralCodePublicationResult.Voucher?.ReferrerId
            }) :
            ResultWrapper.Failure<ReferralCodeResponse>(AppConstants.StatusMessages.ReferralCodeNotCreated, AppConstants.StatusCodes.ReferralCodeNotCreated);
    }
    public async Task<IResultWrapper<List<CampaignResponse>>> GetCampaignsAgainstCustomer(GetCustomerCampaignsRequest request)
    {
        var customerData = new Customer()
        {
            SourceId = request.SourceId,
            Metadata = request.Metadata,
        };
        var campaigns = await _voucherifyImplementation.GetCampaignsAgainstCustomer(customerData);

        if (campaigns != null)
        {
            var result = campaigns?.Select(campaign => new CampaignResponse()
            {
                Name = campaign.Name,
                Description = campaign.Description,
                Id = campaign.Id,
                PromotionTiers = campaign.Promotion?.Tiers?.ConvertAll(promotion => new Promotions.Responses.PromotionTierResponse()
                {
                    PromotionId = promotion.Id,
                    Name = promotion.Name,
                    Banner = promotion.Banner,
                    Metadata = promotion.Metadata,
                    Category = promotion.Category,
                    CategoryId = promotion.CategoryId,
                    CampaignId = promotion.Campaign?.Id,
                    CampaignStartDate = promotion.Campaign?.StartDate,
                    IsCampaignActive = promotion.Campaign?.Active,
                    CampaignExpirationDate = promotion.Campaign?.ExpirationDate,
                    AmountOff = promotion.Action?.Discount?.AmountOff,
                    PercentOff = promotion.Action?.Discount?.PercentOff,
                    UnitOff = promotion.Action?.Discount?.UnitOff,
                    UnitType = promotion.Action?.Discount?.UnitType,
                    AmountLimit = promotion.Action?.Discount?.AmountLimit,
                    DiscountType = Convert.ToString(promotion.Action?.Discount?.Type),
                    DiscountEffect = Convert.ToString(promotion.Action?.Discount?.Effect)
                }),
                Active = campaign.Active,
                ExpirationDate = campaign.ExpirationDate,
                Metadata = campaign.Metadata,
                StartDate = campaign.StartDate,
                CampaignType = Convert.ToString(campaign.CampaignType)
            }).ToList();

            return ResultWrapper.Success(result);
        }
        return ResultWrapper.Failure<List<CampaignResponse>>(AppConstants.StatusMessages.CampaignNotFound, AppConstants.StatusCodes.CampaignNotFound);
    }
}
