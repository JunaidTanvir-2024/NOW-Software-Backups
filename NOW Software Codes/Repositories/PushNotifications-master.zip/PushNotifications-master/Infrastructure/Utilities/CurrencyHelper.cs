﻿namespace Infrastructure.Utilities
{
    public static class CurrencyHelper
    {
        public static string GetRawSymbol(string currency)
        {
            string symbol = "";
            switch (currency)
            {
                case "EUR":
                    symbol = "€";
                    break;
                case "USD":
                    symbol = "$";
                    break;
                case "GBP":
                    symbol = "£";
                    break;
                default:
                    symbol = "£";
                    break;
            }
            return symbol;
        }
    }
}
