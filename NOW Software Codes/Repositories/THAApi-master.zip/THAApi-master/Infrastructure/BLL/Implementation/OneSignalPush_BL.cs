﻿using Infrastructure.BLL.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Infrastructure.BLL.Implementation;
using Models.Contracts.Request;
using System.Linq;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.BLL.Interfaces.Languages;

namespace Infrastructure.BLL.Implementation
{

	public class OneSignalPush_BL : IOneSignalPush_BL
    {
        private const string AppId = "cc84e2f6-4ad9-47c9-a225-cb7d36a237c4";
        private const string Username = "authorization";
        private const string Password = "Basic MmNlN2U0ODQtZDExYS00ZjA0LWIzMWUtODRkNWFlYzc2YmFh";
        private const string NotificationsUrl = "https://onesignal.com/api/v1/notifications";
        private readonly IHttpService httpService;
        private readonly IEnumerable<IMessageService> messageServices;

        public OneSignalPush_BL(IHttpService httpService, IEnumerable<IMessageService> messageServices)
        {
            this.httpService = httpService;
            this.messageServices = messageServices;
        }
        public Task<bool> NotifyUser(string msisdn, Func<IMessageService, string> messageFunc, string data = null)
        {
            return NotifyUsers(new[] { msisdn }, messageFunc, data);
        }
        public Task<bool> NotifyUsers(string[] msisdns, Func<IMessageService, string> messageFunc)
        {
            return NotifyUsers(msisdns, messageFunc, null);
        }
        private async Task<bool> NotifyUsers(string[] msisdns, Func<IMessageService, string> messageFunc, string data)
        {
            var recipients = GenerateRecipients(msisdns);
            var content = GetContent(messageFunc);
            var result = await SendAsync(recipients, content, data);

            if (result.Recipients == msisdns.Length && result.Errors.Length == 0)
            {
                return true;
            }
            return false;
        }
        private async Task<PushNotificationResult> SendAsync(List<Tag> recipients, IDictionary<string, string> contents, string data)
        {
            var pushNotification = new PushNotification
            {
                AppId = AppId,
                Tags = recipients,
                Contents = contents,
                Data = data != null ? new Data { Balance = data } : null
            };

            var requestBody = JsonConvert.SerializeObject(pushNotification);
            var result = await httpService.PostAsync(NotificationsUrl, requestBody, Username, Password);
            if (result == null)
                result = "";

            return JsonConvert.DeserializeObject<PushNotificationResult>(result);
        }
        private IDictionary<string, string> GetContent(Func<IMessageService, string> messageFunc)
        {
            return messageServices.Aggregate(new Dictionary<string, string>(), (dict, messageService) =>
            {
                var message = messageFunc(messageService);
                foreach (var language in messageService.Languages)
                {
                    dict[language] = message;
                }
                return dict;
            });
        }
        private List<Tag> GenerateRecipients(string[] msisdns)
        {
            var results = new List<Tag>();
            for (int i = 0; i < msisdns.Length; i++)
            {
                //Only add an OR operator after the first recipient
                if (msisdns.Length > 1 && i != 0)
                {
                    //This is how it handles multiple recipients
                    results.Add(GenerateOrOperator());
                }
                results.Add(GenerateRecipient(msisdns[i]));
            }
            return results;
        }
        private Tag GenerateRecipient(string msisdn)
        {
            return new Tag
            {
                Key = "msisdn",
                Relation = "=",
                Value = msisdn,
            };
        }
        private Tag GenerateOrOperator()
        {
            return new Tag
            {
                Operator = "OR"
            };
        }
        private string UTFEncode(string message)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(message);
            return Encoding.UTF8.GetString(bytes);
        }
    }
}
