﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetAddressResponseModel
    {
        public string Latitude { get; set; }

        public string Longitude { get; set; }

        public IList<string> Addresses { get; set; }

        public string Message { get; set; }
    }
}
