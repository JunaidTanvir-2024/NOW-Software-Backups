using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Traveler;

public abstract class GetTraveler
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public long Id { get; set; }
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.Id).NotNull();
		}
	}
	#endregion

	#region Response
	public sealed record Response
	{
		public required TripInfo Trip { get; set; }
		public sealed record TripInfo
		{
			public long Id { get; set; }
			public string? Name { get; set; }
			public DateTime StartingDate { get; set; }
			public long CreatorId { get; set; }
			public required TravelerInfo Traveler { get; set; }
		}
		public sealed record TravelerInfo
		{
			public required long Id { get; set; }
			public string? FullName { get; set; }
			public string? Email { get; set; }
		}
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{
			var traveler = await _unitOfWork.TravelerRepository.GetTraveler(x => x.UserId.Equals(query.Id));

			if (traveler is not null)
			{
				return ResultWrapper.Success(new Response()
				{
					Trip = new Response.TripInfo()
					{
						Id = traveler.TripId,
						Name = traveler.Trip?.Name,
						StartingDate = traveler?.Trip?.StartingDate ?? default,
						CreatorId = traveler?.Trip?.CreatorId ?? default,
						Traveler = new Response.TravelerInfo()
						{
							Id = traveler?.User?.Id ?? default,
							Email = traveler?.User?.Email,
							FullName = traveler?.User?.UserDetail?.FullName,
						}
					},
				});
			}
			return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
		}
	}
	#endregion
}
