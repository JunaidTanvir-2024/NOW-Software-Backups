$(function () {
  var swiper = new Swiper('.hero-slider', {
    loop: true,
    effect: 'fade',
    followFinger: false,
    autoplay: {
      delay: 3500,
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    pagination: {
      el: '.swiper-pagination',
      clickable: true
    }
  });
})


$(function () {


  $(function () {
    // on scroll navbar fixed and bg chnage for desktop only
    $(window).scroll(function () {
      var scroll = $(window).scrollTop();

      if ($(this).width() > 991) {
        if (scroll >= 100) {
          $('nav.navbar').addClass('navbar-scroll');
        } else {
          $('nav.navbar').removeClass('navbar-scroll');
        }
      }
    });

    if ($(window).width() > 991 && $(window).scrollTop() >= 50) {
      $('nav.navbar').addClass('navbar-scroll');
    }
  });

  //show and hide password
    $('.pwd-hs-btn').click(function () {
    $(this).toggleClass('text-danger')
    var next = $(this).next();
    if ('password' == next.attr('type')) {
      this.textContent = "Hide";
      next.prop('type', 'text');
    } else {
      this.textContent = "Show";
      next.prop('type', 'password');
    }

  });

  // Tippy popover
  tippy.setDefaults({
    animation: 'scale',
    arrow: true,
    maxWidth: 320,
    touch: false,
    touchHold: true,
    delay: [200, 20],
    trigger: 'mouseenter',
  });


  // Select2
  $('.CO_Select_Country').select2({
    placeholder: "Select Country"
  });

  $('.CO_Expiry_Month').select2({
    placeholder: "Expiry Month"
  });

  $('.CO_Expiry_Year').select2({
    placeholder: "Expiry Year"
  });

  $('.SISU_Add_Credit').select2({
    placeholder: "Add Credit"
  });

  $('.CO_Post_Address').select2({});

  $('.Recharge_Card').select2({
    placeholder: "Select Top-up Amount"
  });

  $('.Redeem_Points').select2({});

  $('.THCC_Rates').select2({
    placeholder: "Select Country"
  });

});