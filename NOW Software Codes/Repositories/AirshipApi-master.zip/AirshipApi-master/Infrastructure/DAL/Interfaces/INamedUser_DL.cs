﻿using Models.Contracts;
using Models.Contracts.Request;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface INamedUser_DL
    {
        Task<GenericResult<bool>> NUserChannelAssociation(NUserChannelAssocRequest request);
        Task<GenericResult<bool>> AddNUserTags(AddNUserTagsRequest request);
    }
}
