﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using THCCWEB.Attributes;
using THCCWEB.Models.ApiContracts.Response;
using THCCWEB.Utilities;
using static THCCWEB.Utilities.Enum;

namespace THCCWEB.Models.ViewModels.CheckOutView
{
    public class CheckoutViewModel
    {
        public CardViewModel UserCard { get; set; }
        public Pay360CardsData UserCards { get; set; }
        public CountriesResponseModel ListOfCountries { get; set; }
        public BillingAddress BillingAddress { get; set; }
        public string CardPrice { get; set; }
        public string PageType { get; set; }
        public string CallingCardNumber { get; set; }
        [Required(ErrorMessage = "Enter post code"), StringLength(maximumLength: 9, ErrorMessage = "Maximum length exceeded")]
        [RegularExpression("^[^\\s]+[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid Post Code")]
        public string PostCode { get; set; }
        [Required(ErrorMessage = "Enter email address")]
        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address")]
        public string EmailAddress { get; set; }
        public int CallingCardProductId { get; set; }
        [Required(ErrorMessage = "Enter card price")]
        [CollectionValidation(values: new int[] { 5, 10, 20 })]
        public int CallingCardPrice { get; set; }
        public Pay360PaymentType Pay360PaymentType { get; set; }
        public string ipAddress { get; set; }
        public ProductType ProductItemCode { get; set; }
        [Required(ErrorMessage ="Please Enter PIN")]
        public string RechargePIN { get; set; }

        [Required(ErrorMessage = "Enter security code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [Range(0, int.MaxValue, ErrorMessage = "Only numbers allowed.")]
        public string SecurityCode { get; set; }
        public bool IsAutoToupEnabled { get; set; }
        public bool IsEmailExist { get; set; }
        public bool ShouldSave { get; set; }
        public bool IsCardAutoConnected { get; set; }
        public string UniqueRef { get; set; }
        public bool IsAuthenticated { get; set; }

        public bool Iscollonical_checkout { get; set; }


    }


    public class BillingAddress 
    {
        [Required(ErrorMessage = "Select country")]
        public string CountryCode { get; set; }
        [Required(ErrorMessage = "Enter address"), StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        [RegularExpression("^[^\\s]+[a-zA-Z0-9 .&-]*$", ErrorMessage = "Please enter a valid Address")]
        public string AddressL1 { get; set; }
        public string AddressL2 { get; set; }
        public string AddressL3 { get; set; }
        public string AddressL4 { get; set; }
        public string City { get; set; }
        public string Region { get; set; }
    }

    public class Pay360CardsData
    {
        public List<PaymentMethodData> paymentMethodResponses { get; set; }
    }
    public class PaymentMethodData
    {
        public bool registered { get; set; }
        public bool isPrimary { get; set; }
        public CardData card { get; set; }
        public string paymentClass { get; set; }
    }
    public class CardData
    {
        public string cardFingerprint { get; set; }
        public string cardToken { get; set; }
        public string cardType { get; set; }

        [JsonProperty(PropertyName = "new")]
        public bool newCard { get; set; }
        public string cardUsageType { get; set; }
        public string cardScheme { get; set; }
        public string maskedPan { get; set; }
        public string expiryDate { get; set; }
        public string issuer { get; set; }
        public string issuerCountry { get; set; }
        public string cardHolderName { get; set; }

    }
}