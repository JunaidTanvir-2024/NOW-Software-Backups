﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Response
{
    public class InternationalRatesResponseModel
    {
        public IEnumerable<InternationalRateResponseModel> internationalRatesList { get; set; }
    }
}
