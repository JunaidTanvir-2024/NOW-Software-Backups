﻿namespace CallingCode.Mvc.Middlewares;

public class TrailingSlashAndLowerCaseUrlMiddleware
{
    private readonly RequestDelegate _next;

    public TrailingSlashAndLowerCaseUrlMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext httpContext)
    {
        string currentPath = httpContext.Request.Path;

        if (currentPath != "/" && httpContext.Request.Method == "GET")
        {
            bool isAjaxCall = httpContext.Request.Headers["x-requested-with"] == "XMLHttpRequest";

            string ext = System.IO.Path.GetExtension(currentPath);

            bool NeedRedirection = false;

            var currentQueryString = httpContext.Request.QueryString;

            if (!isAjaxCall && string.IsNullOrEmpty(ext))
            {
                if (currentPath.EndsWith("/"))
                {
                    currentPath = currentPath.Remove(currentPath.Length - 1, 1);
                    NeedRedirection = true;
                }
                if (currentPath.Any(char.IsUpper))
                {
                    currentPath = currentPath.ToLower();
                    NeedRedirection = true;
                }

                if (currentQueryString.HasValue)
                {
                    currentPath += currentQueryString.Value;
                }
            }

            if (NeedRedirection)
            {
                httpContext.Response.Redirect(currentPath, true);
                return;
            }
        }

        await _next(httpContext);
    }
}

// Extension method used to add the middleware to the HTTP request pipeline.
public static class TrailingSlashAndLowerCaseUrlMiddlewareExtensions
{
    public static IApplicationBuilder UseTrailingSlashAndLowerCaseUrlMiddleware(this IApplicationBuilder builder)
    {
        return builder.UseMiddleware<TrailingSlashAndLowerCaseUrlMiddleware>();
    }
}