﻿using Application.Common.Models.ResponseWrappers;

namespace Application.Features.Identity.ForgotPassword.ForgotPasswod;

public class ForgotPasswordRequest : IRequest<Result<object>>
{
    public string EmailAddress { get; set; } = default!;

    [JsonIgnore]
    public string? IpAddress { get; set; } = null;
}
