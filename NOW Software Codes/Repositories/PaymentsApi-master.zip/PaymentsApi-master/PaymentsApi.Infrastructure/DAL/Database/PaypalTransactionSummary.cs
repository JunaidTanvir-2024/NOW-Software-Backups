﻿using PaymentsApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public class PaypalTransactionSummary
    {
        public long Id { get; set; }
        public string CustomerMsisdn { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerName { get; set; }        
        public double? TransactionAmount { get; set; }
        public string TransactionCurrency { get; set; }
        public string Pay360TransactionId { get; set; }
        public string TransactionMerchantRef { get; set; }
        public string CustomerMerchantRef { get; set; }
        public int Customer_Id { get; set; }
        public Pay360SummaryTransactionStatuses TransactionStatus_Id { get; set; }              
        public string PaypalCheckoutToken { get; set; }
        public long? SinglePayment_Transaction_Id { get; set; }
        public DateTime? SinglePayment_Transaction_DateTime { get; set; }
        public long? Resume_Transaction_Id { get; set; }
        public DateTime? Resume_Transaction_DateTime { get; set; }       
        public long? Refund_Transaction_Id { get; set; }
        public DateTime? Refund_Transaction_Datetime { get; set; }
        public DateTime? Fulfilment_DateTime { get; set; }
        public DateTime? cr_date { get; set; }
        public bool IsDirectFullfilment { get; set; }
        public string ApiInstallationIdCashierApi { get; set; }
    }
}
