using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces;

public interface ITokenService : IServicesType.ITransientService
{
    Task<TokenResponse> GetTokenAsync(User user, string ipAddress, CancellationToken cancellationToken);

    Task<TokenResponse> RefreshTokenAsync(RefreshTokenRequest request, string ipAddress);
}