﻿
using Models.Contracts;
using Models.Database;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL
{
    public interface IAuth_DL
    {
        Task<bool> VerifyPreAuth(string enc_tx, string product_code, string product_item_code);
        Task<Auth> GetPreAuth(string enc_tx, string product_code, string product_item_code);
        Task<int> AddPreAuth(PreAuthRequest request, string enc_g, string enc_k, string enc_tx, int enc_a, string enc_d, int enc_ty, string remoteIp);

    }
}
