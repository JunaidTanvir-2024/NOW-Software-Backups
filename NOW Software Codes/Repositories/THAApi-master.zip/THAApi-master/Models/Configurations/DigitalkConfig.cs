﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
   public class DigitalkConfig
    {
        public string ApiUrl { get; set; }
    }
}
