﻿using System;
using System.Collections.Generic;
using System.Text;

namespace THM.Models.Configurations
{
    public class ConnectionStrings
    {
        public string DigiTalkNowMobileConnection { get; set; }
        public string THWEbConnection { get; set; }
        public string THMGeneral { get; set; }
    }
}
