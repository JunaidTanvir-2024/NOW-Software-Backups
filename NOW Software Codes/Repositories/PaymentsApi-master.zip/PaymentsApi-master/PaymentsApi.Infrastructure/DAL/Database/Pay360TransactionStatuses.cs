﻿using PaymentsApi.Infrastructure.DAL.EnumToLookup;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public class Pay360TransactionStatus : LookupTableBase
    {
        public Pay360TransactionStatus()
        {
            Pay360Transactions = new HashSet<Pay360Transaction>();
        }

        public ICollection<Pay360Transaction> Pay360Transactions { get; set; }
    }
}
