﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Contracts.Request.Api
{
    public class PoppayoutRequest
    {
        public string from { get; set; }
        public string[] to { get; set; }
        public string textMessage { get; set; }
        public string SmsJobPriority { get; set; }
        public int SmsJobId { get; set; }
    }
}
