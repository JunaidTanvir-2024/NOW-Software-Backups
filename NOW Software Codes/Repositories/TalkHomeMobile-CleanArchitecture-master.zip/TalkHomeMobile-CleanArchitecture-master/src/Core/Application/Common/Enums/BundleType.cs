namespace Application.Common.Enums;

public enum BundleType
{
    PAYG = 1,
    Rolling,
    TestDrive,
    SpecialOffer,
    Welcome,
    BoltOn,
    AddOn,
    FirstMonthOffer,
    PennyPro,
    Annual
}
public enum BundleCategory
{
    National = 1,
    International,
    DataOnly,
    ActivationOffer,
    Affiliate,
    TwelveMonthsContract
}