﻿
namespace THCC.Application.Features.Topup.DisableAutoTopup;

public class DisableAutoTopupRequest:IRequest<object>
{
}
