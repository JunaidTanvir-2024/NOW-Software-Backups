﻿using Microsoft.AspNetCore.Http;
using SC.Core.Vendors.Notification;
using SC.Core.Features.Email.Response;
using SC.Core.Features.Email.Request;

namespace SC.Core.Features.Email
{

    //public sealed class SendEmailHandler : IRequestHandler<SendEmailRequest, SendEmailResponse>
    //{
    //    private readonly IMessageMatrixService _messageMatrixService;
    //    public SendEmailHandler(IMessageMatrixService messageMatrixService, IHttpContextAccessor httpContextAccessor)
    //    {
    //        _messageMatrixService = messageMatrixService;

    //    }
    //    //public async Task<SendEmailResponse> Handle(SendEmailRequest request, CancellationToken cancellationToken)
    //    //{
            
    //    //    return  new SendEmailResponse();
    //    //}
    //}


}
