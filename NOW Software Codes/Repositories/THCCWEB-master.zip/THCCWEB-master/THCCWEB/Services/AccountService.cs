﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using THCCWEB.Services.Interface;

namespace THCCWEB.Services
{
    public class AccountService : IAccountService
    {

    }
}
