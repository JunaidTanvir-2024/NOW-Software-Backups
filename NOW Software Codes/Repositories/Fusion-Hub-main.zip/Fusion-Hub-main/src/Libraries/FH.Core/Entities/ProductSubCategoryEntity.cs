namespace FH.Core.Entities;
public sealed record ProductSubCategoryEntity : BaseEntity<long>
{
    public string? Name { get; set; }
    public string? Description { get; set; }
    public long ProductCategoryId { get; set; }
}
