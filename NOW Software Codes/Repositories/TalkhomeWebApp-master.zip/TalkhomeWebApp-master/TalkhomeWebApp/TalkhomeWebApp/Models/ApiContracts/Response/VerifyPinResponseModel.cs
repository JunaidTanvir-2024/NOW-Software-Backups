﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class VerifyPinResponseModel
    {
        public UserInfo User { get; set; }
        public string Token { get; set; }
        public DateTime ValidTo { get; set; }
    }

    public class UserInfo
    {
        public string Msisdn { get; set; }
        public string Currency { get; set; }
        public string AccountID { get; set; }
        public string Email { get; set; }
        public bool IsEmailVerified { get; set; }
        public bool? IsMailSubscription { get; set; }
        public string Na_Service_Id { get; set; }
        public string ISO_Two_CountryCode { get; set; }
    }
}
