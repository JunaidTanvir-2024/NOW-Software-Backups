﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{
    public class DingConfig
    {
        public string AuthApiEndPoint { get; set; }
        public bool SimulationMode { get; set; }
        public string ApiEndPoint { get; set; }
        public bool JsonResponseLogging { get; set; }
        public string EUR_client_id { get; set; }
        public string EUR_client_secret { get; set; }
        public string GBP_client_id { get; set; }
        public string GBP_client_secret { get; set; }
        public string grant_type { get; set; }
        public bool SendSmsToSender { get; set; }
        public string smsTemplate { get; set; }
        public int ProductCount { get; set; }

    }
}
