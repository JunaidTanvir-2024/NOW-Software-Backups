﻿using Application.Features.Account.History.Models;

namespace Application.Features.Payment.Invoice.Models;
public class InvoiceResponse
{
    public Domain.Entities.Bundle BundleInfo { get; set; } = new Domain.Entities.Bundle();
    public IEnumerable<PaymentHistoryInfo> OrderHistoryInfo { get; set; } = new List<PaymentHistoryInfo>();
}