﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class SimOrderViewModel : BaseViewModel
    {
        [Required(ErrorMessage = "Enter First Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Only alphabets allowed")]
        [StringLength(maximumLength: 50, ErrorMessage = "Only 50 characters allowed.")]
        public string UserFirstName { get; set; }

        [Required(ErrorMessage = "Enter Last Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Only alphabets allowed")]
        [StringLength(maximumLength: 50, ErrorMessage = "Only 50 characters allowed.")]
        public string UserLastName { get; set; }

        [Required(ErrorMessage = "Enter Email"), DataType(DataType.EmailAddress, ErrorMessage = "Invalid Email")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        [StringLength(maximumLength: 50, ErrorMessage = "Only 50 characters allowed.")]
        public string UserEmail { get; set; }

        [Required(ErrorMessage = "Enter Address"), StringLength(maximumLength: 1000, ErrorMessage = "Maximum Length Exceeded")]
        public string AddressL1 { get; set; }

        [StringLength(maximumLength: 1000, ErrorMessage = "Maximum Length Exceeded")]
        public string AddressL2 { get; set; }

        [Required(ErrorMessage = "Enter City"), StringLength(maximumLength: 200, ErrorMessage = "Maximum Length Exceeded")]
        public string City { get; set; }

        [StringLength(maximumLength: 200, ErrorMessage = "Maximum Length Exceeded")]
        public string County { get; set; }

        [Required(ErrorMessage = "Enter Post Code"), StringLength(maximumLength: 100, ErrorMessage = "Maximum Length Exceeded")]
        public string PostCode { get; set; }

        public int CountryId { get; set; }

        [Required(ErrorMessage = "Enter Password"), MinLength(8, ErrorMessage = "The Password must be at least 8 characters long"), MaxLength(150, ErrorMessage = "Maximum Length Exceeded")]
        public string UserPassword { get; set; }

        [Required(ErrorMessage = "Enter Confirm Password"), Compare("UserPassword", ErrorMessage = "Password doesn't match"), MinLength(8, ErrorMessage = "The Password must be at least 8 characters long"), MaxLength(150, ErrorMessage = "Maximum Length Exceeded")]
        public string UserConfirmPassword { get; set; }

        public bool IsReplace { get; set; }

        public bool IsPortIn { get; set; }

        public bool IsUserExist { get; set; }

        [Required(ErrorMessage = "Enter Port Msisdn"), MaxLength(length: 12, ErrorMessage = "Maximum 12 characters allowed"), MinLength(length: 10, ErrorMessage = "Minimum 10 characters allowed")]
        public string PortMsisdn { get; set; }
        [Required(ErrorMessage = "Enter PAC Code"), StringLength(maximumLength: 10, ErrorMessage = "Maximum Length Exceeds")]
        public string Code { get; set; }

        public bool MailSubscription { get; set; }

        public string isuserverified { get; set; }

        public string otp { get; set; }

    }
}
