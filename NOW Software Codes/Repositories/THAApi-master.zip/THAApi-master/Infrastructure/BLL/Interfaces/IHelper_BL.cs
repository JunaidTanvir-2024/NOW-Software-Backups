﻿namespace Infrastructure.BLL.Interfaces
{
    public interface IHelper_BL
    {
        string GetCountryName(string msisdn);

        string GetISOCurrencyCode(string msisdn);

        string GetAccountCurrency(string msisdn);

        string StripLeadingZeros(string msisdn);

        string GetSipUserName(string msisdn);

        string FormatMsisdn(string msisdn);

        string ToMonetaryUnit(decimal amount, string currency);

        string ToMonetaryUnit(string amount, string currency);

        string ToCurrencySymbol(string currency);
        string ToCurrencyName(string currencySymbol);

        string FormatAccountBalance(decimal amount, string currency);

        string ToSmsCharge(decimal amount, string currency);

        string ToCallCharge(decimal amount, string currency);

        string ToCallType(string zone);

        string ToCallDuration(int totalSeconds);

        string ToPaymentHistoryAmount(decimal amount, string currency);

        string GetPaymentHistoryReference(string method, string reason);

        string GetCountryCode(string msisdn);

        string GetCountryNamebyCoutryISCode(string iso);

        string GetCountryNamebyCoutryISCode(string iso, string remarks);
        string GetCountryIso(string msisdn);
    }
}
