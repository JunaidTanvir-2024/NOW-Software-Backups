﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THM.Models.AirShip
{
    public class NamedUserTagsRequest
    {
        [JsonProperty("NamedUser")]
        public string NamedUser { get; set; }

        [JsonProperty("ProductCode")]
        public string ProductCode { get; set; }

        [JsonProperty("TagGroup")]
        public string TagGroup { get; set; }

        [JsonProperty("Tags")]
        public List<string> Tags { get; set; }
    }
}
