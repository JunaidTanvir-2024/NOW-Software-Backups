﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
	public class AccountBalance
    {
        public float new_balance { get; set; }

        public int audit_id { get; set; }

    }
}
