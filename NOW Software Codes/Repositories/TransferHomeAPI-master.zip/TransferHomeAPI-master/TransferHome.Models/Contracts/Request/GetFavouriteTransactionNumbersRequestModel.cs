﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class GetFavouriteTransactionNumbersRequestModel
    {
        public int UserId { get; set; }
    }
}
