﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Configurations
{
    public class SmtpConfig
    {
        public string server { get; set; }
        public string from { get; set; }
        public string fromForCustomer { get; set; }
        public string fromForTHMCustomer { get; set; }
        public string fromForTHACustomer { get; set; }
        public string fromForTHCCCustomer { get; set; }
        public string fromForNowPayGCustomer { get; set; }
        public string fromForWtccCustomer { get; set; }
        public string fromForStccCustomer { get; set; }
        public string fromForBtccCustomer { get; set; }
        public string fromForMtccCustomer { get; set; }
        public string fromForTdccCustomer { get; set; }        
        public string userName { get; set; }
        public string password { get; set; }
        public string[] to { get; set; }
        public string[] cc { get; set; }
        public string[] bcc { get; set; }
        public string subject { get; set; }
        public string subjectForCustomer { get; set; }
        public string subjectForTHCCNCustomer { get; set; }
        public string subjectForTHRCCCustomer { get; set; }
        public string subjectForTHRCCNewCustomer { get; set; }
        public bool sendEmailToCustomer { get; set; }
        public bool sendEmailToTHCCCustomer { get; set; }
        public bool sendEmailToTHRCCCustomer { get; set; }
        public bool sendTemplateEmailToCustomer { get; set; }
        public string subjectForWtccCustomer { get; set; }
        public string subjectForStccCustomer { get; set; }
        public string subjectForBtccCustomer { get; set; }
        public string subjectForMtccCustomer { get; set; }
        public string subjectForTdccCustomer { get; set; }        
        public string subjectForNowPayGCustomer { get; set; }
        public string DisplayNameForTHCC { get; set; }

    }
}
