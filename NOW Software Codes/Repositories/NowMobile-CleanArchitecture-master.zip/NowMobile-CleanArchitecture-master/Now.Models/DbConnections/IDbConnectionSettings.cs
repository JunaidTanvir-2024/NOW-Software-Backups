﻿using System.Data;

namespace Now.Models.DbConnections;

public interface IDbConnectionSettings
{
    IDbConnection SqlConnection { get; }
}
