﻿using System;
using System.Collections.Generic;

namespace ATT.Models.Contracts.Ding.Response
{
    public class DingErrorResponse
    {
        public int ResultCode { get; set; }
        public List<ErrorCodes> ErrorCodes { get; set; }
    }
    public class ErrorCodes
    {
        public string Code { get; set; }
        public string Context { get; set; }
    }
}
