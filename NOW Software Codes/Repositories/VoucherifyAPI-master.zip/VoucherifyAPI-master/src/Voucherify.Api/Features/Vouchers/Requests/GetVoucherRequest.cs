using FluentValidation;

namespace Voucherify.Api.Features.Vouchers.Requests;

public class GetVoucherRequest
{
    public string VoucherCodeOrId { get; set; } = null!;
}
internal class GetVoucherByIdRequestValidator : AbstractValidator<GetVoucherRequest>
{
    public GetVoucherByIdRequestValidator()
    {
        RuleFor(p => p.VoucherCodeOrId).NotNull().NotEmpty();
    }
}