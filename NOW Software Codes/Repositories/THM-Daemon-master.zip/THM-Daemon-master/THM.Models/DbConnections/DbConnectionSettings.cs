﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace THM.Models.DbConnections
{

    public class DbConnectionSettings : IDbConnectionSettings
    {
        public IDbConnection SqlConnection { get; }

        public DbConnectionSettings(IDbConnection connection)
        {
            SqlConnection = connection;
        }
    }
}
