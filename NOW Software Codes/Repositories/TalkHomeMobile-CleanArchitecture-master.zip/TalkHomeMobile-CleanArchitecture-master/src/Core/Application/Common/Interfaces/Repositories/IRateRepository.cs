using Application.Common.Extensions.DependencyResolver;
using Application.Features.Rate.Model;

namespace Application.Common.Interfaces.Repositories;

public interface IRateRepository : IServicesType.IScopedService
{
    Task<List<InternationalRate>> GetInternationalRates();
   // Task<List<RoamingRate>> GetRoamingRates();
    Task<RoamingRate> GetRoamingRates(int fromCountry, int toFrom);
    Task<List<UkRate>> GetUKRates();
}