﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Models.Contracts.Request;
using Models.Contracts.Request.CountryDestination;
using Models.Contracts.Response;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Linq;
using System.Threading.Tasks;
using THAApi.Utilities;

namespace THAApi.Controllers
{
    [ApiController]
    [ApiVersion("2.0")]
    [Route("v{v:apiVersion}")]
    public class DestinationV2Controller : Controller
    {
        private readonly IBundle_BL BundleBL;
        private readonly IUserAccount_BL _userAccount_BL;
        private readonly ILogger Logger;
        private readonly IStringLocalizer Localizer;

        public DestinationV2Controller(
            IBundle_BL bundleBL,
            IUserAccount_BL userAccount_BL,
            ILogger logger,
            IStringLocalizer localizer)
        {
            BundleBL = bundleBL;
            _userAccount_BL = userAccount_BL;
            Logger = logger;
            Localizer = localizer;
        }

        [HttpPost]
        [Route("bundleswithtop")]
        public async Task<IActionResult> GetCountryWithBundlesAndTopBundlesV2([FromBody] SuggestedBundleRequest request)
        {
            var userMsisdn = User.Msisdn();
            var userAccount = await _userAccount_BL.GetUserAccountBalance(userMsisdn);

            string welcomeBundleDescription = await this.RenderViewAsync(Pages.WelcomeBundle, userAccount, false);
            string paygBundleDescription = await this.RenderViewAsync(Pages.PaygBundle, userAccount, false);

            return Ok(await BundleBL.GetCountryWithBundlesAndTopBundlesV2(userMsisdn, request.CountryCodes, welcomeBundleDescription, paygBundleDescription));
        }
        [HttpPost]
        [Route("bundles")]
        public async Task<IActionResult> GetBundleDetailsV2(BundleIsoRequest request)
        {
            var userMsisdn = User.Msisdn();
            try
            {
                var userAccount = await _userAccount_BL.GetUserAccountBalance(userMsisdn);
                string welcomeBundleDescription = await this.RenderViewAsync(Pages.WelcomeBundle, userAccount, false);
                string paygBundleDescription = await this.RenderViewAsync(Pages.PaygBundle, userAccount, false);
                string globalCreditDescription = await this.RenderViewAsync(Pages.GlobalCredit, userAccount, false);
                return Ok(await BundleBL.GetBundleDetailsV2(request.isoCode, userMsisdn, User.Currency(), welcomeBundleDescription, paygBundleDescription, globalCreditDescription));

            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"Controller: DestinationV2Controller, " +
                    $"Method: GetBundleDetailsV2 , " +
                    $"Msisdn: {userMsisdn} {request.isoCode}, " +
                    $"ErrorMessage: {ex.Message}, " +
                    $"StackTrace: {ex.StackTrace}");
                var resp = GenericApiResponse<object>.Failure(
                    null, Localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);
                return Ok(resp);
            }
        }
    }
}