﻿
using Newtonsoft.Json;

namespace Application.Features.Payment.Card.Models;
public class RefundPaymentResponse
{

    [JsonProperty("customer")]
    public CustomerResponseModel Customer { get; set; }

    [JsonProperty("outcome")]
    public OutcomeModel Outcome { get; set; }

    [JsonProperty("transaction")]
    public TransactionResponseModel Transaction { get; set; }
}


public class TransactionResponseModel
{
    [JsonProperty("transactionId")]
    public string TransactionId { get; set; }
    [JsonProperty("merchantDescription")]
    public string TransactionDescription { get; set; }
    [JsonProperty("status")]
    public string Status { get; set; }
    [JsonProperty("type")]
    public string Type { get; set; }
    [JsonProperty("amount")]
    public double Amount { get; set; }
    [JsonProperty("currency")]
    public string Currency { get; set; }
    [JsonProperty("transactionTime")]
    public string TransactionTime { get; set; }
    [JsonProperty("receivedTime")]
    public string ReceivedTime { get; set; }
    [JsonProperty("channel")]
    public string Channel { get; set; }
    [JsonProperty("merchantRef")]
    public string MerchantRef { get; set; }
    [JsonProperty("recurring")]
    public bool Recurring { get; set; }
    [JsonProperty("commerceType")]
    public string CommerceType { get; set; }
    [JsonProperty("relatedTransaction")]
    public RelatedTransaction RelatedTransaction { get; set; }
}



[JsonObject("outcome")]
public class OutcomeModel
{
    [JsonProperty("status")]
    public string Status { get; set; }

    [JsonProperty("reasonCode")]
    public string ReasonCode { get; set; }

    [JsonProperty("reasonMessage")]
    public string ReasonMessage { get; set; }
}





public class RelatedTransaction
{
    [JsonProperty("transactionId")]
    public string TransactionId { get; set; }
    [JsonProperty("merchantRef")]
    public string MerchantRef { get; set; }
}





public class CustomerResponseModel
{
    [JsonProperty("id")]
    public long Id { get; set; }

    [JsonProperty("merchantRef")]
    public string MerchantRef { get; set; }

    [JsonProperty("email")]
    public string Email { get; set; }
}

