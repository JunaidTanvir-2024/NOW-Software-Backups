﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class GetAccountDetailsResponseModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public bool IsEmailVerified { get; set; }
        public bool EmailSubscription { get; set; }
        public decimal Balance { get; set; }
        public int? DayOfBirth { get; set; }
        public int? MonthOfBirth { get; set; }
        public string Pin { get; set; }
    }
}
