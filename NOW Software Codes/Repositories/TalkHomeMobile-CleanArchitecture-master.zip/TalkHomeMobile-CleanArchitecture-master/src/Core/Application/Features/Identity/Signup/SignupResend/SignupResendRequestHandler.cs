﻿using Application.Common.Interfaces.Infrastructure.Identity;
using Application.Common.Mailing;

namespace Application.Features.Identity.Signup.SignupResend;
internal class SignupResendRequestHandler : IRequestHandler<SignupResendRequest, Result<object>>
{
    private readonly IOtpService _otpService;
    private readonly IStringLocalizer<SignupResendRequestHandler> _localizer;
    private readonly ISmsService _smsService;
    private readonly IMailService _mailService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;

    public SignupResendRequestHandler(
        IOtpService otpService,
        IStringLocalizer<SignupResendRequestHandler> localizer,
        ISmsService smsService,
        IMailService mailService,
        IUnitOfWork unitOfWork,
        ICommonService commonService
       )
    {
        _otpService = otpService;
        _localizer = localizer;
        _smsService = smsService;
        _mailService = mailService;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
    }

    public async Task<Result<object>> Handle(SignupResendRequest request, CancellationToken cancellationToken)
    {
        //Validate user for any type deactivation


        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        //Check if email already attached
        User? user = await _unitOfWork.UserRepo.GetUserByEmail(request.EmailAddress);
        if (user != null)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.EmailAlreadyRegistered],
                CustomStatusCode.EmailAlreadyRegistered);
        }

        //Is valid msisdn
        var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdnDetails == null)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Check if msisdn already attached
        if (await _unitOfWork.UserRepo.IsProductAlreadyAttached(request.Msisdn))
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.MsisdnAlreadyRegistered], CustomStatusCode.MsisdnAlreadyRegistered);
        }

        //Craet Email Otp
        var (EmailOtp, EmailOtpModel) = await _otpService.CreateOtp(request.EmailAddress, OtpType.SignUp, true);
        if (EmailOtpModel.StatusCode != CustomStatusCode.OtpIsNotCreated)
        {
            await _mailService.SendSignupEmailOtpAsync(request.EmailAddress, EmailOtp);
        }
        //Crete Msisdn Otp
        var (MsisdnOtp, MsisdnOtpModel) = await _otpService.CreateOtp(request.Msisdn, OtpType.SignUp, false);
        if (MsisdnOtpModel.StatusCode != CustomStatusCode.OtpIsNotCreated)
        {
            await _smsService.SendOtpMessage(request.Msisdn, MsisdnOtp.ToString());
        }
        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }
}