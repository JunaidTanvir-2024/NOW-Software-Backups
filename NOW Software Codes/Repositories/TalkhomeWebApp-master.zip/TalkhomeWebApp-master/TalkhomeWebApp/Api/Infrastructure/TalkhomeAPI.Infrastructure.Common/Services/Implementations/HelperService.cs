﻿using Newtonsoft.Json;
using PhoneNumbers;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using TalkhomeAPI.Infrastructure.Common.Models;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class HelperService : IHelperService
    {
        public string ToMonetaryUnit(decimal amount, string currency)
        {
            return DetermineMonetaryUnit(amount, currency);
        }
        public string ToMonetaryUnit(string amount, string currency)
        {
            var decimalAmount = Convert.ToDecimal(amount, CultureInfo.InvariantCulture);

            return DetermineMonetaryUnit(decimalAmount, currency);
        }
        public IList<Country> GetCountries()
        {
            var completePath = Path.GetFullPath(Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot/CountriesName.json"));

            var json = System.IO.File.ReadAllText(completePath);

            var _countries = JsonConvert.DeserializeObject<CountriesData>(json);

            return _countries.countries;
        }
        private string DetermineMonetaryUnit(decimal amount, string currency)
        {
            if (amount >= 1)
            {
                var monetaryAmount = amount.ToString("F",CultureInfo.InvariantCulture);
                var currencyUnit = GetMajorCurrencyUnit(currency);
                if (currencyUnit == string.Empty)
                    return FormattableString.Invariant($"{monetaryAmount} {currency}");
                else
                    return FormattableString.Invariant($"{currencyUnit}{monetaryAmount}");
            }
            else
            {

                var monetaryAmount = Math.Round((amount * 100), 1);
                //var monetaryAmount = (amount * 100);
                var currencyUnit = GetMinorCurrencyUnit(currency);
                return FormattableString.Invariant($"{monetaryAmount}{currencyUnit}");
            }
        }
        private string GetMajorCurrencyUnit(string currency)
        {
            switch (currency)
            {
                case "GBP":
                    return "£";
                case "EUR":
                    return "€";
                case "USD":
                    return "$";
            }
            return string.Empty;
        }
        private string GetMinorCurrencyUnit(string currency)
        {
            switch (currency)
            {
                case "GBP":
                    return "p";
                case "EUR":
                    return "c";
                case "USD":
                    return "c";
            }
            return string.Empty;
        }
    }
}
