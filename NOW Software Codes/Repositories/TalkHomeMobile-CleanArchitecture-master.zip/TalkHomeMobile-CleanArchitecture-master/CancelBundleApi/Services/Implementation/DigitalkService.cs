﻿using CancelBundleApi.Constants.Enums;
using CancelBundleApi.Helpers.HttpService;
using CancelBundleApi.Models.RequestModels;
using CancelBundleApi.Models.ResponseModels;
using CancelBundleApi.Services.Interfaces;
using CancelBundleApi.Settings.Database;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Net;

namespace CancelBundleApi.Services.Implementation;

internal class DigitalkService : IDigitalkService
{
    private readonly IHttpService _httpService;
    private readonly DigitalkSettings _digiTalkSettings;
    private readonly ILogger<DigitalkService> _logger;
    public DigitalkService(IHttpService httpService, IOptions<DigitalkSettings> digiTalkSettings, ILogger<DigitalkService> logger)
    {
        _httpService = httpService;
        _digiTalkSettings = digiTalkSettings.Value;
        _httpService.WithBasicAuth(_digiTalkSettings.UserName, _digiTalkSettings.Password).EnableLogging();
        _logger = logger;
    }
    public async Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> DeleteSubscribedBundles(UnSubscribeBundlesRequest request, Item bundleItem)
    {
        try
        {
            string endPoint = _digiTalkSettings.ApiEndPoint + $"/subscribers/{request.SubscriberId}/subscriptions/2/bundles/{bundleItem?.Type}";

            var removeBundleResponse = await _httpService.DeleteAsync(endPoint, request, bundleItem.ServiceCorrelationGuid);
            return (removeBundleResponse.IsSuccessStatusCode, removeBundleResponse.ResponseBody, removeBundleResponse.StatusCode);
        }
        catch (Exception ex)
        {
            _logger.LogError($"Message: {ex.Message}, " +
              $"Class: DigitalkService, " +
         $"Method: DeleteSubscribedBundles, " +
         $"Exception: {ex.StackTrace}");
            return (false, string.Empty, (int) HttpStatusCode.InternalServerError);
        }
    }

    public async Task<(List<Item> Items, bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> GetSubscribedBundles(UnSubscribeBundlesRequest request, string correlationGuid)
    {
        try
        {

            string endPoint = _digiTalkSettings.ApiEndPoint + $"/subscribers/{request.SubscriberId}/subscriptions/2/bundles?type=1";

            var bundlesResponse = await _httpService.GetAsync(endPoint, request, correlationGuid);
            if (!bundlesResponse.IsSuccessStatusCode)
            {
                return (new List<Item>(), false, string.Empty, bundlesResponse.StatusCode);
            }
            var bundlesList = JsonConvert.DeserializeObject<BundleItems>(bundlesResponse.ResponseBody);
            if (bundlesList.Items != null && bundlesList.Items.Count == 0)
            {
                await NoDataFound(string.Empty, CustomStatusKey.NoSubscriptionBundlesFound, request, correlationGuid);
            }
            return (bundlesList.Items.ToList(), bundlesResponse.IsSuccessStatusCode, bundlesResponse.ResponseBody, bundlesResponse.StatusCode);
        }
        catch (Exception ex)
        {
            _logger.LogError($"Message: {ex.Message}, " +
             $"Class: DigitalkService, " +
        $"Method: GetSubscribedBundles, " +
        $"Exception: {ex.StackTrace}");
            return (new List<Item>(), false, string.Empty, (int) HttpStatusCode.InternalServerError);
        }
    }
    public async Task NoDataFound(string endPoint, string noDataFound, UnSubscribeBundlesRequest request, string correlationGuid)
    {
        await _httpService.NoRequestDataFound(endPoint, noDataFound, request, correlationGuid);
    }
}
