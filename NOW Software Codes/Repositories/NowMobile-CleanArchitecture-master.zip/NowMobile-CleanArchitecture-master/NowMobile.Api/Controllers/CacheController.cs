﻿

namespace NowMobile.Api.Controllers;
public class CacheController : VersionedApiController
{

    //[HttpGet("clear") , OpenApiOperation("clear cache.", "")]
    //public async Task<IActionResult> CacheClear([FromRoute] string postcode)
    //{
    //    return Ok(await Mediator.Send(new CacheClearRequest()));
    //
    //}

}