﻿using System;
using System.Collections.Generic;

namespace TalkhomeWebApp.Models
{
    public class Referrals
    {
        public List<ReferralOut> referrals { get; set; }
    }

    public class DingPromoResponse
    {
        public DingPayload payload = new DingPayload();
    }

    public class DingPayload
    {
        public List<Item> item = new List<Item>();
        public List<string> dingCountries = new List<string>();
    }
    public class Item
    {
        public string title { get; set; }
        public string description { get; set; }
        public DateTime dateFrom { get; set; }
        public DateTime dateTo { get; set; }
        public string pubDate { get; set; }
        public string operatorName { get; set; }
        public string operatorId { get; set; }
        public string subOperatorId { get; set; }
        public string countryId { get; set; }
        public string countryName { get; set; }
        public string title2 { get; set; }
        public string denomination { get; set; }
        public string denominationLocal { get; set; }
        public string promotionstatus { get; set; }
        public string countryCode { get; set; }
        public string operatorImageUrl { get; set; }
    }

    public class Channel
    {
        public string title { get; set; }
        public string description { get; set; }
        public string link { get; set; }
        public string pubDate { get; set; }
        public string lastBuildDate { get; set; }
        public string ttl { get; set; }
        public List<Item> item { get; set; }
    }

    public class RSS
    {
        public List<PromotionCountry> country { get; set; }
        public Channel channel { get; set; }
        public PromotionCountry defaultCountry { get; set; }

    }

    /***
     * msisdn varchar(50) not null,
	email varchar(100) not null,
	canBeContacted bit not null default(0) **/

    public class useremailRegistration
    {
        public string email { get; set; }
        public string msisdn { get; set; }
        public bool canBeContacted { get; set; }
    }

    public class PromotionCountry
    {
        public string countryId { get; set; }
        public string countryName { get; set; }
        public bool status { get; set; }
    }

    public class Promotion
    {
        public string countryId { get; set; }
        public string countryName { get; set; }
        public bool status { get; set; }

    }
    public class Referral
    {

        public string msisdn { get; set; }

        public decimal amount { get; set; }

        public string Date { get; set; }


    }

    public class ReferralOut
    {

        public string msisdn { get; set; }

        public string amount { get; set; }

        public string date { get; set; }

    }
}
