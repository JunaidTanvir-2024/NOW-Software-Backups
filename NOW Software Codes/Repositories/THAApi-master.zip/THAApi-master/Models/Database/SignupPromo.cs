﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
   
    public class SignupPromo
    {
        public bool is_unit_Promo { get; set; }
        public bool is_bundle_Promo { get; set; }
        public decimal amount { get; set; }
    }
}
