namespace Infrastructure.BLL.Services.Voucherify.Models.EarningRules.Requests
{
    public class GetEarningRulesRequest
    {
        public string CampaignId { get; set; } = null!;

        public int PageNumber { get; set; }

        public int PageSize { get; set; }
    }
}

