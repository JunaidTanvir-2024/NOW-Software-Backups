namespace Effortless.Api.Features.Auth.Signup.Response;

public record SignupResponse(string? PhoneNumber);
