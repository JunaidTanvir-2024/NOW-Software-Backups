using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Customers;
using Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class Publication
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("object")]
    public string? Object { get; set; }

    [JsonPropertyName("created_at")]
    public DateTimeOffset CreatedAt { get; set; }

    [JsonPropertyName("customer_id")]
    public string? CustomerId { get; set; }

    [JsonPropertyName("tracking_id")]
    public string? TrackingId { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    [JsonPropertyName("channel")]
    public string? Channel { get; set; }

    [JsonPropertyName("source_id")]
    public object? SourceId { get; set; }

    [JsonPropertyName("result")]
    public string? Result { get; set; }

    [JsonPropertyName("customer")]
    public Customer? Customer { get; set; }

    [JsonPropertyName("voucher")]
    public Voucher? Voucher { get; set; }

    [JsonPropertyName("vouchers_id")]
    public string[]? VouchersId { get; set; }
}
