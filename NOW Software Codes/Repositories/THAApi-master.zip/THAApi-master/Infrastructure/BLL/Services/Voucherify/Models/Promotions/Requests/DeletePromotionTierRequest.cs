﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Requests
{
    public class DeletePromotionTierRequest
    {
        public string PromotionTierId { get; set; } = null!;
    }
}
