﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum CEventChannelIdentifier
    {
        named_user_id = 1,
        ios_channel = 2,
        android_channel = 3,
        web_channel = 4,
        amazon_channel = 5,
        channel = 6        
    }
}
