﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Enums;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class PaymentHistory
    {
        public decimal Amount { get; set; }
        public decimal Balance { get; set; }
        public string Method { get; set; }
        public string Reason { get; set; }
        public string Reference { get; set; }
        public string NowtelTransactionReference { get; set; }
        public DateTime PaymentDate { get; set; }
        public string Msisdn { get; set; }
        public string Type { get; set; }
        public bool IsSuccess { get; set; }
        public string BundleName { get; set; }
        public string BundleId { get; set; }
        public string Db { get; set; }
        public string OperatorLogoUrl { get; set; }
        public string OperatorName { get; set; }
        public string Currency { get; set; }
    }
    public class DBBundles
    {
        public Guid ID { get; set; }
        public string BrandedName { get; set; }
        public string Description { get; set; }
        public string PackageType { get; set; }
        public string PackageCategory { get; set; }
        public int TotalCostPence { get; set; }
        public int ChargePeriodDays { get; set; }
        public int Texts { get; set; }
        public int Seconds { get; set; }
        public int Minutes { get; set; }
        public string Remarks { get; set; }
        public string RemainingMinutes { get; set; }
        public DateTime Expiry { get; set; }
        public bool IsTrial { get; set; }
        public Guid? TrialId { get; set; }
        public BundleCategory BundleCategory { get; set; }
        public BundleType BundleType { get; set; }
        public int OffPercentage { get; set; }
        public bool IsTrialMinutesExpired { get; set; }
        public bool IsRenew { get; set; }
        public PaymentMethods PaymentMethod { get; set; }
        public string CardMaskedPAN { get; set; }
        public bool IsLastRenewalFailed { get; set; }
    }
}
