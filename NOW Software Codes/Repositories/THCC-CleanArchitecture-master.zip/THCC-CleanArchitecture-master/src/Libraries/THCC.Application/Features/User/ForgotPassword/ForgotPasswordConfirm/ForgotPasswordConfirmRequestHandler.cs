﻿using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.ForgotPassword.ForgotPasswordConfirm;

public class ForgotPasswordConfirmRequestHandler : IRequestHandler<ForgotPasswordConfirmRequest, object>
{
    private readonly IOtpService _otpService;
    private readonly IUserRepository _userRepository;

    public ForgotPasswordConfirmRequestHandler(
        IOtpService otpService,
        IUserRepository userRepository)
    {
        _otpService = otpService;
        _userRepository = userRepository;
    }

    public async Task<object> Handle(ForgotPasswordConfirmRequest request, CancellationToken cancellationToken)
    {
        request.Email = request.Email.Trim();
        request.Otp = request.Otp.Trim();

        var user = await _userRepository.GetUserByEmailAsync(request.Email);
        if (user == null)
        {
            return ErrorResult.Failure(
                CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
        }

        var emailToken = await _otpService.GetTokenAgainstOtp(
                    request.Email, request.Otp!, OtpType.ForgotPassword);
        
        if (string.IsNullOrEmpty(emailToken))
        {
            return ErrorResult.Failure(
                CustomStatusKey.InvalidOtp, CustomStatusCode.BadRequest);
        }

        if (!(await _userRepository.IsValidToken(user, emailToken, OtpType.ForgotPassword)))
        {
            return ErrorResult.Failure(
                CustomStatusKey.InvalidOtp, CustomStatusCode.BadRequest);
        }

        return Unit.Value;
    }
}