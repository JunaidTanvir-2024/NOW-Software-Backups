﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Campaigns.Requests
{
    public class DeleteCampaignRequest
    {
        public string CampaignName { get; set; } = null!;
    }
}
