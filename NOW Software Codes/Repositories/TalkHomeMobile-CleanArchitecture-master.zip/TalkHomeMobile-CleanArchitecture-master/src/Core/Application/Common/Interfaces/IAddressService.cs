﻿using Application.Common.Extensions.DependencyResolver;
using Application.Features.Address;

namespace Application.Common.Interfaces;
public interface IAddressService : IServicesType.ITransientService
{
    Task<AddressResponseModel> GetAddresses(string postcode);
}
