﻿
using System.Text.Json.Serialization;


namespace SC.Core.Features.Countries.Requests;
public sealed class GetCountyAndOperatorInfoRequest : IRequest<IResultWrapper>
{

    [JsonPropertyName("msisdn")]
    public string Msisdn { get; set; } = default!;
    [JsonPropertyName("vendor")]
    public int Vendor { get; set; } = default!;

}
public sealed class GetCountyAndOperatorInfoRequestValidator : AbstractValidator<GetCountyAndOperatorInfoRequest>
{

}

