﻿using System.Collections.Generic;

namespace Models.Contracts.Request.Digitalk
{
	public class BundleAllowanceItems
	{
		public BundleAllowanceItems()
		{
			Items = new List<DigitalkBundleAllowance>();
		}

		public List<DigitalkBundleAllowance> Items { get; set; }
	}
}
