﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmsOutReachCallBackUrlApi.Contracts.Xeebi.Request
{

    public class XeebiSmsCallBackUrlRequest
    {
        public string message_id { get; set; }
        public string from { get; set; }
        public string to { get; set; }
        public string submit_status { get; set; }
        public int sms_count { get; set; }
        public DateTime? created_date { get; set; }
        public DateTime? sent_date { get; set; }
        public DateTime? delivered_date { get; set; }
        public string delivery_status { get; set; }
        public string cost { get; set; }
    }

}
