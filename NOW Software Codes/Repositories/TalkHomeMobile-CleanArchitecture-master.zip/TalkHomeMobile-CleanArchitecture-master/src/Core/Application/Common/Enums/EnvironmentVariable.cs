﻿
namespace Application.Common.Enums;
public enum EnvironmentVariable
{
    Production,
    Staging,
    Development
}
