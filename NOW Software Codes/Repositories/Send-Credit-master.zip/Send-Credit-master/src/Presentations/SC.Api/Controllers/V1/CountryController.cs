﻿using Microsoft.AspNetCore.Authorization;

using SC.Api.Model.Country;
using SC.Core.Features.Countries.Requests;

using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Controllers.V1;

[ApiVersion(1.0)]
public sealed class CountryController : BaseApiController
{
    //  [Authorize]
    [AllowAnonymous]
    [HttpPost]
    public async Task<ActionResult> GetCountries(GetCountriesRequest request)
    {
        var result = await Mediator.Send(request);

        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }

    // [Authorize]
    [AllowAnonymous]
    [HttpGet("GetCountryAndOperatorInfo")]
    public async Task<ActionResult> GetCountryAndOperatorInfo(string? Msisdn, int Vendor = 1)
    {
        var result = await Mediator.Send(new GetCountyAndOperatorInfoRequest() { Msisdn = Msisdn, Vendor = Vendor });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}