using Application.Common.Interfaces.HttpService;
using Infrastructure.Services.Models;
using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Text.Json;

namespace Infrastructure.Services.HttpService;

public sealed partial class HttpService : IHttpService
{
    private readonly IHttpClientFactory _httpClientFactory;
   // private readonly ILoggerRepository _loggerRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private string? _bearerToken;
    private string? _basicAuthUsername;
    private string? _basicAuthPassword;
    private bool _isLoggingEnabled;
    private readonly List<HttpServiceKeyValues> _headers;

    public HttpService(
        IHttpClientFactory httpClientFactory,
        //ILoggerRepository loggerRepository,
        IHttpContextAccessor httpContextAccessor)
    {
        _httpClientFactory = httpClientFactory;
        //_loggerRepository = loggerRepository;
        _httpContextAccessor = httpContextAccessor;
        _headers = new List<HttpServiceKeyValues>();
    }

    public IHttpService WithBearerAuth(string token)
    {
        _bearerToken = token;
        return this;
    }

    public IHttpService WithBasicAuth(string username, string password)
    {
        _basicAuthUsername = username;
        _basicAuthPassword = password;
        return this;
    }

    public IHttpService WithHeaders(IEnumerable<HttpServiceKeyValues> headers)
    {
        _headers.AddRange(headers);
        return this;
    }

    public IHttpService EnableLogging()
    {
        //_isLoggingEnabled = true;
        _isLoggingEnabled = false;
        return this;
    }

    #region HTTP Requests
    public async Task<(bool IsSuccessStatusCode, string ResponseBody,int StatusCode)> GetAsync(string requestUri)
    {
        return await SendRequestAsync(HttpMethod.Get, requestUri);
    }

    public async Task<(bool IsSuccessStatusCode, string ResponseBody,int StatusCode)> PostAsync(string requestUri, object? data = default)
    {
        var content = CreateJsonContent(data ?? string.Empty);
        return await SendRequestAsync(HttpMethod.Post, requestUri, content);
    }

    public async Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> PutAsync(string requestUri, object? data = default)
    {
        var content = CreateJsonContent(data ?? string.Empty);
        return await SendRequestAsync(HttpMethod.Put, requestUri, content);
    }

    public async Task<(bool IsSuccessStatusCode, string ResponseBody,int StatusCode)> DeleteAsync(string requestUri)
    {
        return await SendRequestAsync(HttpMethod.Delete, requestUri);
    }
#endregion

    private async Task<(bool IsSuccessStatusCode, string ResponseBody,int StatusCode)> SendRequestAsync(HttpMethod method, string requestUri, HttpContent? content = null)
    {
        var stopwatch = Stopwatch.StartNew();
        var client = _httpClientFactory.CreateClient();

        var request = new HttpRequestMessage(method, requestUri);

        if (_bearerToken != null)
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _bearerToken);
        }
        else if (_basicAuthUsername != null && _basicAuthPassword != null)
        {
            var authValue = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_basicAuthUsername}:{_basicAuthPassword}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authValue);
        }

        foreach (var header in _headers)
        {
            client.DefaultRequestHeaders.Add(header.Key, header.Value);
        }

        if (content != null)
        {
            request.Content = content;
        }

        var requestBody = request?.Content != null ? await request.Content.ReadAsStringAsync() : string.Empty;
        return await SendRequestAndSaveLog(stopwatch, client, request, requestBody);
    }

    private async Task<(bool IsSuccessStatusCode, string ResponseBody,int HttpStatusCode)> SendRequestAndSaveLog(Stopwatch stopwatch, HttpClient client, HttpRequestMessage? request, string requestBody,int statusCode = 0)
    {
        // Save log entry to the database
        try
        {
            var result = await client.SendAsync(request!);

            var responseBody = await result.Content.ReadAsStringAsync();
            var isSuccess = result.IsSuccessStatusCode;

            // Calculating response size
            var responseSize = Encoding.UTF8.GetByteCount(responseBody);

            if (_isLoggingEnabled)
            {
                InsertLogs(stopwatch, request, (int)result.StatusCode, responseBody, requestBody, responseSize, string.Empty);
            }
            return (isSuccess, responseBody, (int)result.StatusCode);
        }
        catch (Exception ex)
        {
            // Set the error message in the log entry
            if (_isLoggingEnabled)
            {               
                // Response body and size will be zero as there is no response in case of error 
                InsertLogs(stopwatch, request, (int)HttpStatusCode.InternalServerError, string.Empty, requestBody, 0, ex.StackTrace?.ToString());
            }
            return (false, string.Empty, (int)HttpStatusCode.InternalServerError);
        }
    }

    private void InsertLogs(Stopwatch stopwatch, HttpRequestMessage? request, int statusCode, string? responseBody, string? reqeustBody, int responseSize, string? stackTraceError)
    {
        var logEntry = new HttpResponseLogEntry
        {
            Timestamp = DateTime.UtcNow,
            RequestPath = request?.RequestUri?.ToString(),
            RequestMethod = request?.Method.ToString(),
            RequestBody = reqeustBody,
            ResponseBody = responseBody,
            StatusCode = statusCode,
            Duration = stopwatch.ElapsedMilliseconds,
            ClientIP = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
            UserAgent = _httpContextAccessor.HttpContext?.Request.Headers["User-Agent"],
            ResponseSize = responseSize,
            ErrorMessage = stackTraceError,
            CorrelationId = _httpContextAccessor.HttpContext?.Items["CorrelationIdKey"]?.ToString()!,
            Headers = JsonSerializer.Serialize(request?.Headers),
            QueryString = request?.RequestUri?.Query
        };
        //_loggerRepository.InsertVoucherifyLogEntry(logEntry);
    }

    private static HttpContent CreateJsonContent(object data)
    {
        var json = JsonSerializer.Serialize(data);
        return new StringContent(json, Encoding.UTF8, "application/json");
    }

}
