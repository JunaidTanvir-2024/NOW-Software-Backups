﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class FcmPushResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public FcmPushPayload payload { get; set; }
    }

    public class FcmPushPayload
    {
        public string multicast_id { get; set; }
        public int success { get; set; }
        public int failure { get; set; }        
        public string canonical_ids { get; set; }
        public List<FcmResult> results { get; set; }
    }

    public class FcmResult
    {
        public string message_id { get; set; }
        public string registration_id { get; set; }
        public string error { get; set; }
    }

}
