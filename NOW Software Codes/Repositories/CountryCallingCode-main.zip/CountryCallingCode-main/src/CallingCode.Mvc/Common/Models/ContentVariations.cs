﻿using System.Text.Json.Serialization;

namespace CallingCode.Mvc.Common.Models;


public class ContentVariations
{
    [JsonPropertyName("Variations")]
    public Variation[] Variations { get; set; } = new Variation[0];
}

public class Variation
{
    [JsonPropertyName("CountryCodeStartsWith")]
    public string CountryCodeStartsWith { get; set; } = default!;

    [JsonPropertyName("MainSection")]
    public MainSection MainSection { get; set; } = default!;

    [JsonPropertyName("HowToCall")]
    public DialingInstructions HowToCall { get; set; } = default!;

    [JsonPropertyName("DialingInstructions")]
    public DialingInstructions DialingInstructions { get; set; } = default!;

    [JsonPropertyName("AreaPhoneCodes")]
    public AreaPhoneCodes AreaPhoneCodes { get; set; } = default!;

    [JsonPropertyName("TalkHomeApp")]
    public CallingCards TalkHomeApp { get; set; } = default!;

    [JsonPropertyName("CallingCards")]
    public CallingCards CallingCards { get; set; } = default!;
    
    [JsonPropertyName("TalkHomeAppTopup")]
    public CallingCards TalkHomeAppTopup { get; set; } = default!;

    [JsonPropertyName("TalkHomeSim")]
    public CallingCards TalkHomeSim { get; set; } = default!;
}

public class AreaPhoneCodes
{
    [JsonPropertyName("Title")]
    public string Title { get; set; } = default!;

    [JsonPropertyName("Paragraph")]
    public string Paragraph { get; set; } = default!;
}

public class CallingCards
{
    [JsonPropertyName("Title")]
    public string Title { get; set; } = default!;

    [JsonPropertyName("Paragraph")]
    public string[] Paragraph { get; set; } = default!;

    [JsonPropertyName("Link")]
    public string Link { get; set; } = default!;

    [JsonPropertyName("Link2")]
    public string Link2 { get; set; } = default!;
}

public class DialingInstructions
{
    [JsonPropertyName("Title")]
    public string Title { get; set; } = default!;

    [JsonPropertyName("Paragraph")]
    public string Paragraph { get; set; } = default!;

    [JsonPropertyName("Bullets")]
    public string[] Bullets { get; set; } = default!;
}

public class MainSection
{
    [JsonPropertyName("Title")]
    public string Title { get; set; } = default!;

    [JsonPropertyName("Paragraph")]
    public string[] Paragraph { get; set; } = default!;
}
