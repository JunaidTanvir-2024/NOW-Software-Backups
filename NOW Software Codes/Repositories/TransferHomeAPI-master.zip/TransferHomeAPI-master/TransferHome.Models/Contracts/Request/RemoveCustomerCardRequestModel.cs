﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class RemoveCustomerCardRequestModel
    {
        [Required]
        public string CardToken { get; set; }
    }
}
