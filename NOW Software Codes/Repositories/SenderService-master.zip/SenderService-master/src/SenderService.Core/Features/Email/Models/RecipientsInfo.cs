﻿using System.ComponentModel.DataAnnotations;

namespace SenderService.Core.Features.Email.Models;

public class RecipientsInfo
{
    public byte RecipientType { get; set; }
    [EmailAddress]
    public string EmailAddress { get; set; } = null!;
    public string? RecipientName { get; set; }
}
