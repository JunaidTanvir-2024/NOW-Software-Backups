﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class VoucherTopupRequest
    {
        public string Msisdn { get; set; }

        public string Pin { get; set; }

        public string VoucherCode { get; set; }
        public string advertiserID { get; set; }

        //public AppsFlyerInfo AppsFlyerInfo { get; set; }
        public string AppsFlyerId { get; set; }
        public int DeviceType { get; set; }
    }
}
