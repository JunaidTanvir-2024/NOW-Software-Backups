﻿using MapsterMapper;
using RW.Models;
using SC.Core.Vendors.FusionHub;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SC.Core.Features.Lookups;
public sealed class MsisdnLookup
{
    public sealed record Query : IRequest<IResultWrapper>
    {
        public required string Msisdn { get; set; }
        public int Vendor { get; set; }
    }

    // Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Msisdn).NotNull().NotEmpty();
        }
    }

    // Response
    public sealed record Response
    {
        [JsonPropertyName("operator")]
        public OperatorInfo Operator { get; set; } = null!;
        [JsonPropertyName("country")]
        public CountryInfo Country { get; set; } = null!;

        public sealed record OperatorInfo
        {
            [JsonPropertyName("id")]
            public long Id { get; set; }
            [JsonPropertyName("name")]
            public string? Name { get; set; }
        }
        public sealed record CountryInfo
        {
            [JsonPropertyName("id")]
            public long Id { get; set; }
            [JsonPropertyName("name")]
            public string? Name { get; set; }
            [JsonPropertyName("isoCode")]
            public string? IsoCode { get; set; }
        }
    }

    // Handler
    internal sealed class Handler : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IFusionHubService _fusionHubService;
        private readonly IMapper _mapper;

        public Handler(IFusionHubService fusionHubService, IMapper mapper)
        {
            _fusionHubService = fusionHubService;
            _mapper = mapper;
        }
        public async Task<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var response = await _fusionHubService.GetMsisdnLookupAsync(request);
            if (response?.Payload == null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
            }
            return ResultWrapper.Success(response.Payload);
        }
    }
}

