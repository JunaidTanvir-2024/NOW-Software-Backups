using Application.Common.Extensions.DependencyResolver;
//using Application.Features.Account.History.Models;
//using Application.Features.Bundle.Model;

namespace Application.Common.Interfaces.Repositories;

public interface IUserRepository : IServicesType.IScopedService
{
  
    /// <summary>
    /// get msisdn detail
    /// </summary>
    /// <param name="msisdn"></param>
    /// <returns></returns>
    Task<MsisdnDetails> GetMsisdnDetail(string msisdn);
}