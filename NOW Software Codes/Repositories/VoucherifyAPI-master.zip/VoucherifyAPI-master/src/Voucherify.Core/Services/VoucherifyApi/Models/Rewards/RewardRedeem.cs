using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Rewards;

public class RewardRedeem
{
    [JsonPropertyName("reward")]
    public Reward? Reward { get; set; }
    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}
