﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests
{
    public class DeleteVoucherifyCustomerRequest
    {
        public string SourceId { get; set; }
    }
}
