﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NowPayG.Models.Porting
{
    public enum CodeTypes
    {
        PAC = 1,
        STAC = 2
    }
}
