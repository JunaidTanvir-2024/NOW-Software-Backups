using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Country;

public abstract class UpdateTrip
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long Id { get; set; }
        public string? Name { get; set; }
        public DateTime? StartingDate { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public required string Name { get; set; }
        public DateTime StartingDate { get; set; }
        // public required string CurrencyUnit { get; set; }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {

            var trip = await _unitOfWork.TripRepository.GetTrip(x => x.Id.Equals(query.Id));

            if (trip is null)
            {
                return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
            }

            trip!.Name = query.Name ?? trip.Name;
            trip.StartingDate = query.StartingDate ?? trip.StartingDate;
            _unitOfWork.TripRepository.UpdateTrip(trip);
            _unitOfWork.SaveChanges();


            return ResultWrapper.Success(new Response()
            {
                Id = trip.Id,
                Name = trip.Name,
                StartingDate = trip.StartingDate,
                // CurrencyUnit = trip?.CurrencyUnit ?? default!,
            });
        }
    }
    #endregion
}
