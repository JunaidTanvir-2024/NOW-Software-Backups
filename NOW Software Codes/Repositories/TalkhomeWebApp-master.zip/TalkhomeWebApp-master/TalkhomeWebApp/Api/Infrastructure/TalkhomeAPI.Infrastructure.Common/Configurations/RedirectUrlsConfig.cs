﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class RedirectUrlsConfig
    {
        public string VerifyEmailRedirectUrl { get; set; }
    }
}
