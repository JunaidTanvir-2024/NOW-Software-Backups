using System.Text.Json.Serialization;

using Voucherify.Core.Commons.Converters;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class Discount
{
    [JsonPropertyName("type")]
    [JsonConverter(typeof(EnumConverter<DiscountType>))]
    public DiscountType? Type { get; set; }

    [JsonPropertyName("effect")]
    [JsonConverter(typeof(EnumConverter<DiscountEffect>))]
    public DiscountEffect? Effect { get; set; }

    [JsonPropertyName("amount_off")]
    public long? AmountOff { get; set; }

    [JsonPropertyName("percent_off")]
    public double? PercentOff { get; set; }

    [JsonPropertyName("unit_off")]
    public double? UnitOff { get; set; }

    [JsonPropertyName("unit_type")]
    public string? UnitType { get; set; }

    [JsonPropertyName("amount_limit")]
    public long? AmountLimit { get; set; }
}
