using Voucherify.Api.Features.StackableDiscounts.Common;

namespace Voucherify.Api.Features.StackableDiscounts.Responses;

public class StackableDiscountRedemptionResponse
{
    public string? RedemptionId { get; set; }
    public string? CampaignName { get; set; }
    public ReferrerInfo? Referrer { get; set; }
    public ApplicableOrder? Order { get; set; }

    public class ReferrerInfo
    {
        public string? Id { get; set; }

        public string? Name { get; set; }

        public string? Email { get; set; }

        public string? SourceId { get; set; }
    }
}
