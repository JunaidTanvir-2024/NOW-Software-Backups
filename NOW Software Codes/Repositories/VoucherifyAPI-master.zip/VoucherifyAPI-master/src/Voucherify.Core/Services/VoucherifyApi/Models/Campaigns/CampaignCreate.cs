using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Campaigns;

public class CampaignCreate
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("type")]
    public CampaignExtensionType? Type { get; set; }

    [JsonPropertyName("campaign_type")]
    public CampaignType? CampaignType { get; set; }

    [JsonPropertyName("start_date")]
    public DateTime? StartDate { get; set; }

    [JsonPropertyName("expiration_date")]
    public DateTime? ExpirationDate { get; set; }

    [JsonPropertyName("vouchers_count")]
    public int? VouchersCount { get; set; }

    [JsonPropertyName("voucher")]
    public CampaignVoucherCreate? Voucher { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}
