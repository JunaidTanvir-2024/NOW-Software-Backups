﻿using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Web;
using TalkhomeWebApp.Models;
using TalkhomeWebApp.Models.Configurations;
using TalkhomeWebApp.Utilities;
using TalkhomeWebApp.Utilities.Extension;

namespace TalkhomeWebApp.Services
{
    public class BundleService : IBundleService
    {
        private readonly ILogger _logger;
        private readonly IWebHostEnvironment _hostEnvironment;
		private readonly ApiClient _apiClient;
		private readonly IDataProtector _dataProtector;
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly EndPoints _endpoints;
        public BundleService(ILogger logger,
            IOptions<BasicAuthConfig> basicAuthConfig,
            IOptions<EndPoints> Endpoints,
            IDataProtectionProvider provider,
            IWebHostEnvironment hostEnvironment,
            ApiClient apiClient)
        {
            _logger = logger;
            _hostEnvironment = hostEnvironment;
			this._apiClient = apiClient;
			_dataProtector = provider.CreateProtector("THA-WEB-101");
            _basicAuthConfig = basicAuthConfig.Value;
            _endpoints = Endpoints.Value;
        }
        public async Task<List<Bundles>> GetBundleByCountry(string NaServiceId, string FromCoutry,string account, IPrincipal User)
        {
            List<Bundles> Bundles = new List<Bundles>();
            string token = Convert.ToBase64String(System.Text.Encoding.
                    GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

            var response = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint + "Bundles/GetBundleByCountry", User,
				ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "ServiceId=" + NaServiceId + "&account=" + account }, basicauthtoken: token);

            if (response != null && response.IsSuccessStatusCode)
            {
                var BundleResponse = await response.Content.ReadAsStringAsync();
                Bundles = JsonConvert.DeserializeObject<IEnumerable<Bundles>>(BundleResponse).ToList();

                if (Bundles.Count > 0)
                {
                    var _countries = JsonConvert.DeserializeObject<CountriesModel>(System.IO.File.ReadAllText(
                                                         _hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json"));

                    foreach (var item in Bundles)
                    {
                        item.Description = item.Description.Replace(",", "");
                        item.BundleTypeName = item.BundleType.ToString();
                        item.BundleCategoryName = item.BundleCategory.ToString();
                        item.bundleInfo = HttpUtility.UrlEncode(_dataProtector.Protect(FromCoutry + "--" + NaServiceId + "--" + item.ID));
                        item.CountryName = _countries.countries.Where(x => x.IsoTwoCharacterCode.Equals(item.Description)).Select(x => x.Name).FirstOrDefault();
                    }
                }
            }
            return Bundles;
        }
        public async Task<List<Bundles>> GetBundleByDestinationCountry(string NaServiceId, string FromCoutry,string toCountryCode,string account, IPrincipal User)
        {
            List<Bundles> Bundles = new List<Bundles>();
            string token = Convert.ToBase64String(System.Text.Encoding.
                    GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

            var response = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint + "Bundles/GetBundleByDestinationCountry", User,
				ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "ServiceId=" + NaServiceId + "&toCountryCode="+ toCountryCode + "&account=" + account }, basicauthtoken: token);

            if (response != null && response.IsSuccessStatusCode)
            {
                var BundleResponse = await response.Content.ReadAsStringAsync();
                Bundles = JsonConvert.DeserializeObject<IEnumerable<Bundles>>(BundleResponse).ToList();

                if (Bundles.Count > 0)
                {
                    var _countries = JsonConvert.DeserializeObject<CountriesModel>(System.IO.File.ReadAllText(
                                                         _hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json"));

                    foreach (var item in Bundles)
                    {
                        item.Description = item.Description.Replace(",", "");
                        item.BundleTypeName = item.BundleType.ToString();
                        item.BundleCategoryName = item.BundleCategory.ToString();
                        item.bundleInfo = HttpUtility.UrlEncode(_dataProtector.Protect(FromCoutry + "--" + NaServiceId + "--" + item.ID));
                        item.CountryName = _countries.countries.Where(x => x.IsoTwoCharacterCode.Equals(item.Description)).Select(x => x.Name).FirstOrDefault();
                    }
                }
            }
            return Bundles;
        }

        public async Task<List<BundlesCountries>> GetBundlesCountries(IPrincipal User)
        {
            List<BundlesCountries> BundlesCountries = new List<BundlesCountries>();
            string token = Convert.ToBase64String(System.Text.Encoding.
                               GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

            var response = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint + "Bundles/GetCountriesByBundle", User,
															 ApiCallType.BasicAuth, GetRequest: true, basicauthtoken: token);

            if (response != null && response.IsSuccessStatusCode)
            {
                var CountriesResponse = await response.Content.ReadAsStringAsync();
                BundlesCountries = JsonConvert.DeserializeObject<List<BundlesCountries>>(CountriesResponse);

                foreach (var item in BundlesCountries)
                {
                    item.CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(item.Currency);
                }

            }
            return BundlesCountries;
        }
    }
}
