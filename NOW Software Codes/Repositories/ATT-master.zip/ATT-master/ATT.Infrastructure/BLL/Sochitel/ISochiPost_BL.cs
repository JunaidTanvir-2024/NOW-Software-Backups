﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Sochitel.Response;

namespace ATT.Infrastructure.BLL.Sochitel
{
    public interface ISochiPost_BL
    {
        Task<GenericApiResponse<Balance>> getBalance(string Currency);

        Task<GenericApiResponse<Dictionary<string, Operator>>> GetOperators(string strCountry, int intlocal, int productType, string currency);

        Task<GenericApiResponse<OperatorProducts>> getOperatorProductsMSISDN(string msisdn, string currency);

        Task<GenericApiResponse<OperatorProducts>> getOperatorProductsOperatorID(string operatorID, string currency);

        Task<GenericApiResponse<ProductDetails>> GetProduct(int productId, string currency);

        Task<GenericApiResponse<ExecTransaction>> execTransaction(string fromMsisdn, string toMsisdn, string amount, string currency, string operatorid, string success_sms_quote, string transactionReference);

        Task<GenericApiResponse<SMSTransaction>> sendSMS(string MSISDN, string SMSContent, string currency);

        Task<GenericApiResponse<GetTransactionResponse>> getTransaction(string userReference, string userCurrency);

        Task<GenericApiResponse<ParseMSISDNResponse>> parseMSISDN(string msisdn, string currency);
    }
}
