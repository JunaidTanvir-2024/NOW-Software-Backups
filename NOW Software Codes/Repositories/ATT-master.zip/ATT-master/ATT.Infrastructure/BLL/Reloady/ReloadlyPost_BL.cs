﻿using ATT.Infrastructure.BLL.Common;
using ATT.Infrastructure.BLL.Reloadly;
using ATT.Infrastructure.DAL;
using ATT.Models.Configurations;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Common;
using ATT.Models.Contracts.Reloadly;
using ATT.Models.Contracts.Reloadly.Request;
using ATT.Models.Contracts.Reloadly.Response;
using ATT.Models.Database;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PhoneNumbers;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using ServiceProvider = ATT.Models.Contracts.Common.ServiceProvider;

namespace ATT.Infrastructure.BLL.Reloady
{
    public class ReloadlyPost_BL : IReloadlyPost_BL
    {
        private ILogger _logger;
        private ReloadlyConfig _reloadlyConf;
        private IReloadlyAuth_BL _reloadlyAuth_BL;
        private ICommon_BL _common_BL;
        private IAttDb_DL _appDB;
        private readonly TwilioConfig TwilioConfig;
        private readonly SmtpConfig SmtpConfig;
        private readonly HttpConfig httpConfig;
        public DateTime? tokenRequestEndTime = null;
        public DateTime? tokenRequestStartTime = null;
        public DateTime? GetPRoductStartTime = null;
        public DateTime? GetPRoductEndTime = null;
        public ReloadlyPost_BL(IAttDb_DL _db, ILogger appLoggers, IOptions<ReloadlyConfig> reloadlyConf, ICommon_BL common_BL, IReloadlyAuth_BL reloadlyAuth_BL, IOptions<TwilioConfig> twilioConfig, IOptions<SmtpConfig> smpt, IOptions<HttpConfig> http)
        {
            _appDB = _db;
            _logger = appLoggers;
            _reloadlyConf = reloadlyConf.Value;
            _reloadlyAuth_BL = reloadlyAuth_BL;
            TwilioConfig = twilioConfig.Value;
            SmtpConfig = smpt.Value;
            _common_BL = common_BL;
            httpConfig = http.Value;
        }


        public async Task<JsonOperatorProductResponse> ReloadlyFreeSwitchGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, string productCode, string productItemCode)
        {

            string iso = string.Empty;
            PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
            try
            {
                string phone = ToMsisdn;
                if (!phone.StartsWith("+"))
                    phone = "+" + phone;
                // phone must begin with '+'
                PhoneNumber numberProto = phoneUtil.Parse(phone, "");
                int countryCode = numberProto.CountryCode;
                iso = phoneUtil.GetRegionCodeForCountryCode(countryCode);
            }
            catch (NumberParseException e)
            {
                _logger.Debug($"  ReloadlyFreeSwitchGetPhoneOperator-PhoneNumberUtil unable to fetch iso code against " + ToMsisdn + " error " + e.ToString());
            }

            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 4;
            int suggesstionCount = 7;
            try
            {
                var subUrl = $"operators/auto-detect/phone/{ToMsisdn}/countries/{iso}?suggestedAmountsMap=true&suggestedAmounts=true";
                tokenRequestStartTime = DateTime.Now;
                var authResponse = await _reloadlyAuth_BL.getAuthToken();
                tokenRequestEndTime = DateTime.Now;
                var baseAddress = new Uri(_reloadlyConf.SimulationMode ? _reloadlyConf.simulation_audience : _reloadlyConf.prod_audience);
                HttpClient reloadlyHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/com.reloadly.topups-v1+json");
                reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");
                string returnData = "";
                GetPRoductStartTime = DateTime.Now;
                var httpResponse = await reloadlyHttpClient.GetAsync(subUrl);
                GetPRoductEndTime = DateTime.Now;
                var productJson = "{}";
                var requestJson = "";
                var responseJson = "";
                var serviceProviderId = result.servcieproviderid;
                if (httpResponse.StatusCode == HttpStatusCode.OK)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                    requestJson = subUrl; responseJson = returnData;
                    if (_reloadlyConf.JsonResponseLogging)
                    {
                        _logger.Information($"Reloadly ReloadlyFreeSwitchGetPhoneOperator Request {subUrl} Response {returnData}");
                    }
                    var operatorResponse = JsonConvert.DeserializeObject<ReloadlyOperatorResponse>(returnData);

                    PayLoad payload = new PayLoad();
                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();

                    operatorDetails.id = operatorResponse.operatorId.ToString();
                    operatorDetails.name = operatorResponse.name;
                    operatorDetails.country = operatorResponse.country.name;
                    operatorDetails.nowtelTransactionReference = Guid.NewGuid().ToString();
                    operatorDetails.ProductItemCode = productItemCode;
                    operatorDetails.iconUri = operatorResponse.logoUrls != null && operatorResponse.logoUrls.Length > 0 ? operatorResponse.logoUrls[0] : "";

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.insertTransactionGUID_Tha(operatorDetails.nowtelTransactionReference, account.ToUpper(), ToMsisdn, productJson, requestJson, responseJson, serviceProviderId, fromMSISDN, productItemCode, operatorResponse.country.isoName, operatorResponse.operatorId.ToString(), productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country, GetTokenApiTime: (tokenRequestEndTime.Value - tokenRequestStartTime.Value).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime.Value - GetPRoductStartTime.Value).TotalMilliseconds);
                    if (dbResult.DBStatus == 0)
                    {
                        _logger.Debug($"  ReloadlyFreeSwitchGetPhoneOperator  Failed  Source:Reloadly API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:Reloadly API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        CustomerChargeValueForReplacement custChargeValue = await _appDB.GetCustomerChargeValueForReplacement(ToMsisdn, productItemCode);
                        //// IF suggested amounts has value either denomination type is range or fixed
                        var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(operatorResponse.suggestedAmountsMap.ToString());
                        if (dict.Count > 0)
                        {
                            bool productFound = false;
                            if ((operatorResponse.denominationType.ToLower().Equals("range")
                                && Convert.ToDecimal(custChargeValue.OrignalChargeValue) >= Convert.ToDecimal(operatorResponse.minAmount)
                                && Convert.ToDecimal(custChargeValue.OrignalChargeValue) <= Convert.ToDecimal(operatorResponse.maxAmount))
                                ||
                                (operatorResponse.denominationType.ToLower().Equals("fixed")
                                && dict.ContainsKey(Convert.ToDecimal(custChargeValue.OrignalChargeValue).ToString()))
                                )
                            {

                                //foreach (var kv in dict.Take(suggesstionCount))
                                //{
                                AttProduct product = new AttProduct();
                                if (!_reloadlyConf.CalculateVIAFx
                                && (_reloadlyConf.SuggestedAmountOperatorCodes.Trim().Equals("*") || _reloadlyConf.SuggestedAmountOperatorCodes.Split(",").ToList().Contains(operatorResponse.operatorId.ToString())))
                                {
                                    if (operatorResponse.denominationType.ToLower().Equals("range"))
                                    {
                                        if (dict.Count > 1)
                                            product.product = ((int)Math.Floor((Convert.ToDecimal(dict.ElementAt(1).Value) / Convert.ToDecimal(dict.ElementAt(1).Key)) * Convert.ToDecimal(custChargeValue.OrignalChargeValue))).ToString();
                                        else
                                            product.product = ((int)Math.Floor((Convert.ToDecimal(dict.First().Value) / Convert.ToDecimal(dict.First().Key)) * Convert.ToDecimal(custChargeValue.OrignalChargeValue))).ToString();

                                        productFound = true;

                                    }
                                    else
                                     if (dict.ContainsKey(custChargeValue.OrignalChargeValue.ToString()))
                                    {
                                        product.product = dict[custChargeValue.OrignalChargeValue.ToString()];
                                        productFound = true;
                                    }
                                }
                                else
                                {
                                    product.product = ((int)Math.Floor(operatorResponse.fx.rate * Convert.ToDecimal(custChargeValue.OrignalChargeValue))).ToString();
                                    productFound = true;
                                }

                                if (productFound)
                                {
                                    product.receiverccy = operatorResponse.destinationCurrencyCode;
                                    product.clientccy = operatorResponse.senderCurrencyCode;
                                    product.itemPriceClientccy = custChargeValue.NewChargeValue;
                                    product.transactionfeeClientccy = 0.ToString();
                                    product.totalPriceClientccy = custChargeValue.NewChargeValue;
                                    products.Add(product);

                                    await _appDB.insertaccessDetails(dbResult.InsertId,
                            account,
                            product.receiverccy,
                            product.product,
                           custChargeValue.OrignalChargeValue,
                            custChargeValue.OrignalChargeValue,
                            custChargeValue.NewChargeValue,
                            //endrate.CustomerChargeValue.ToString(),
                            //endrate.CustomerChargeValue.ToString(),
                            0,
                            null,
                            null
                            );
                                }
                                //}
                            }
                            if (!productFound)
                            {
                                if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                                {
                                    await _common_BL.SendEmail(new EmailTransactionModel()
                                    {
                                        ErrorMessage = $"ProductNotMatched: \n\r ConfiguredRates: {JsonConvert.SerializeObject(custChargeValue)} \n\r ProviderResponse: {JsonConvert.SerializeObject(dict)}",
                                        Status = "Failure",
                                        FromMsisdn = fromMSISDN,
                                        ToMsisdn = ToMsisdn,
                                        ProductCode = productCode,
                                        ProductItemCode = productItemCode,
                                        ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                                        TransationType = TransationType.Get
                                    });
                                }
                                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "ProductNotMatched", DbConfiguredValues: JsonConvert.SerializeObject(custChargeValue), OperatorResponse: JsonConvert.SerializeObject(dict));
                            }
                        }
                        else if (operatorResponse.denominationType.ToLower().Equals("range"))
                        {
                            var reloadlyProduct = operatorResponse.suggestedAmounts.FirstOrDefault(s => Convert.ToDecimal(s) == Convert.ToDecimal(custChargeValue.OrignalChargeValue));
                            //foreach (var amount in operatorResponse.suggestedAmounts.Take(suggesstionCount))
                            //{
                            AttProduct product = new AttProduct();
                            product.product = custChargeValue.NewChargeValue;
                            product.receiverccy = operatorResponse.destinationCurrencyCode;
                            product.clientccy = operatorResponse.senderCurrencyCode;
                            product.itemPriceClientccy = custChargeValue.NewChargeValue;
                            product.transactionfeeClientccy = 0.ToString();
                            product.totalPriceClientccy = custChargeValue.NewChargeValue;
                            products.Add(product);

                            await _appDB.insertaccessDetails(dbResult.InsertId,
              account,
              product.receiverccy,
              product.product,
              custChargeValue.OrignalChargeValue,
              custChargeValue.OrignalChargeValue,
              custChargeValue.NewChargeValue,
              //endrate.CustomerChargeValue.ToString(),
              //endrate.CustomerChargeValue.ToString(),
              0,
              null,
              null
              );
                            //}
                        }
                        else // Fixed denomination
                        {
                            if (operatorResponse.senderCurrencyCode == operatorResponse.destinationCurrencyCode)
                            {
                                //foreach (var amount in operatorResponse.fixedAmounts.Take(suggesstionCount))
                                //{

                                var reloadlyProduct = operatorResponse.fixedAmounts.FirstOrDefault(s => Convert.ToDecimal(s) == Convert.ToDecimal(custChargeValue.OrignalChargeValue));
                                AttProduct product = new AttProduct();
                                product.product = custChargeValue.NewChargeValue;
                                product.receiverccy = operatorResponse.destinationCurrencyCode;
                                product.clientccy = operatorResponse.senderCurrencyCode;
                                product.itemPriceClientccy = custChargeValue.NewChargeValue;
                                product.transactionfeeClientccy = 0.ToString();
                                product.totalPriceClientccy = custChargeValue.NewChargeValue;
                                products.Add(product);

                                await _appDB.insertaccessDetails(dbResult.InsertId,
                account,
          product.receiverccy,
          product.product,
          custChargeValue.OrignalChargeValue,
          custChargeValue.OrignalChargeValue,
          custChargeValue.NewChargeValue,
          //endrate.CustomerChargeValue.ToString(),
          //endrate.CustomerChargeValue.ToString(),
          0,
          null,
          null
              );
                                //}
                            }
                        }

                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _logger.Information($"  ReloadlyFreeSwitchGetPhoneOperator  Success      Parameters-msisdn:{ToMsisdn} currency:{account}");

                        return result;
                    }
                }
                else
                {

                    returnData = await httpResponse.Content.ReadAsStringAsync();
                    var errorResponse = JsonConvert.DeserializeObject<ReloadlyErrorResponse>(returnData);

                    result.message = errorResponse.message;
                    result.status = "Failure";
                    result.errorCode = 2;

                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                    {
                        await _common_BL.SendEmail(new EmailTransactionModel()
                        {
                            ErrorMessage = errorResponse.message,
                            Status = "Failure",
                            FromMsisdn = fromMSISDN,
                            ToMsisdn = ToMsisdn,
                            ProductCode = productCode,
                            ProductItemCode = productItemCode,
                            ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                            TransationType = TransationType.Get
                        });
                    }
                    await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message, GetTokenApiTime: (tokenRequestEndTime.Value - tokenRequestStartTime.Value).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime.Value - GetPRoductStartTime.Value).TotalMilliseconds);
                    _logger.Debug($"  ReloadlyFreeSwitchGetPhoneOperator  Failed  Source:Relaodly API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.message}");

                    return result;
                }

            }
            catch (Exception ex)
            {
                var date = DateTime.Now;
                if (!tokenRequestStartTime.HasValue)
                {
                    tokenRequestStartTime = date;
                }
                if (!tokenRequestEndTime.HasValue)
                {
                    tokenRequestEndTime = date;
                }
                if (!GetPRoductStartTime.HasValue)
                {
                    GetPRoductStartTime = date;
                }
                if (!GetPRoductEndTime.HasValue)
                {
                    GetPRoductEndTime = date;
                }
                _logger.Debug($"  ReloadlyFreeSwitchGetPhoneOperator  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";

                if (SmtpConfig.sendErrorGetProductsEmail)
                {
                    await _common_BL.SendEmail(new EmailTransactionModel()
                    {
                        ErrorMessage = ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                        Status = "Failure",
                        FromMsisdn = fromMSISDN,
                        ToMsisdn = ToMsisdn,
                        ProductCode = productCode,
                        ProductItemCode = productItemCode,
                        ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                        TransationType = TransationType.Get
                    });
                }
                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                     GetTokenApiTime: (tokenRequestEndTime.Value - tokenRequestStartTime.Value).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime.Value - GetPRoductStartTime.Value).TotalMilliseconds);
                return result;
            }

        }

        public async Task<object> ReloadlyFreeSwitchTopUp(ExecuteData request)
        {
            try
            {
                string json = "";
                string returnData = "";
                DateTime tokenRequestStartTime = DateTime.Now;
                DateTime tokenRequestEndTime = tokenRequestStartTime;
                DateTime TopUpApiStartTime = tokenRequestStartTime;
                DateTime TopUpApiEndTime = tokenRequestStartTime;

                string nowtelTransactionReference = request.nowtelTransactionReference;
                string product = request.product;
                string messageToRecipient = request.messageToRecipient;
                string fromMSISDN = request.fromMSISDN;

                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(nowtelTransactionReference, product);

                if (guidReferneceRecord == null)
                {
                    _logger.Debug($"   /ReloadlyFreeSwitchTopUp  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return result;
                }
                try
                {


                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn,request.nowtelTransactionReference.Remove(0, 14), request.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"  \"GET /ReloadlyFreeSwitchTopUp\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return result;
                }
                try
                {
                    string recipientIso = string.Empty;
                    string senderIso = string.Empty;
                    PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
                    try
                    {
                        ///Receipent ISO Code
                        string phone = guidReferneceRecord.tomsisdn;
                        if (!phone.StartsWith("+"))
                            phone = "+" + phone;
                        // phone must begin with '+'
                        PhoneNumber numberProto = phoneUtil.Parse(phone, "");
                        int countryCode = numberProto.CountryCode;
                        recipientIso = phoneUtil.GetRegionCodeForCountryCode(countryCode);

                        //Sender ISO Code
                        phone = request.fromMSISDN;
                        if (!phone.StartsWith("+"))
                            phone = "+" + phone;
                        // phone must begin with '+'
                        numberProto = phoneUtil.Parse(phone, "");
                        countryCode = numberProto.CountryCode;
                        senderIso = phoneUtil.GetRegionCodeForCountryCode(countryCode);

                    }
                    catch (NumberParseException e)
                    {
                        _logger.Debug($"  ReloadlyFreeSwitchTopUp-PhoneNumberUtil unable to fetch iso code against ToNumber" + guidReferneceRecord.tomsisdn + ". From Number" + request.fromMSISDN + " error " + e.ToString());
                    }


                    var subUrl = $"topups";
                    ReloadlyTopUpRequest topUpRequest = new ReloadlyTopUpRequest
                    {

                        amount = guidReferneceRecord.fromAmount,
                        customIdentifier = nowtelTransactionReference,
                        operatorId = request.operatorid,
                        recipientPhone = new RelaodlyPhoneDetails
                        {
                            countryCode = recipientIso,
                            number = guidReferneceRecord.tomsisdn
                        },
                        senderPhone = new RelaodlyPhoneDetails
                        {
                            countryCode = senderIso,
                            number = request.fromMSISDN
                        },
                    };
                    json = JsonConvert.SerializeObject(topUpRequest);
                    tokenRequestStartTime = DateTime.Now;
                    var authResponse = await _reloadlyAuth_BL.getAuthToken();
                    tokenRequestEndTime = DateTime.Now;
                    var baseAddress = new Uri(_reloadlyConf.SimulationMode ? _reloadlyConf.simulation_audience : _reloadlyConf.prod_audience);
                    HttpClient reloadlyHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                    reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/com.reloadly.topups-v1+json");
                    reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");

                    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");


                    TopUpApiStartTime = DateTime.Now;
                    var httpResponse = await reloadlyHttpClient.PostAsync(subUrl, httpContent);
                    TopUpApiEndTime = DateTime.Now;

                    if (httpResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        if (_reloadlyConf.JsonResponseLogging)
                        {
                            _logger.Information($"Reloadly ReloadlyFreeSwitchTopUp Request {json} Response {returnData}");
                        }
                        var response = JsonConvert.DeserializeObject<ReloadlyTopUpResponse>(returnData);

                        //Successful transaction
                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh_v3(
                                DateTime.Now.ToString(),
                                 _reloadlyConf.SimulationMode ? _reloadlyConf.simulation_client_id : _reloadlyConf.prod_client_id_eur, // Username
                                guidReferneceRecord.selling_price,        // Customer Charge Value
                                response.requestedAmount - response.discount ?? 0,  // Actual Charge Value
                                Convert.ToDecimal(guidReferneceRecord.product),
                                response.requestedAmountCurrencyCode,
                                response.deliveredAmountCurrencyCode,
                                guidReferneceRecord.destination_country,
                                "Success",
                                "",
                                response.operatorId.ToString(),
                                product,
                                response.operatorName,
                                null,
                                response.transactionId,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                4,
                                messageToRecipient,
                                guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                nowtelTransactionReference,
                                json,
                                returnData,
                                GetTokenApiTime: tokenRequestEndTime < tokenRequestStartTime ? 0 : (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                                TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                );

                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  ReloadlyFreeSwitchTopUp  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }

                        _logger.Information($"  ReloadlyFreeSwitchTopUp   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{response.transactionId}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = response.requestedAmount, // Customer Charge Value
                            currency = response.requestedAmountCurrencyCode,
                            reference = response.transactionId
                        };

                        if (_reloadlyConf.SendSmsToSender)
                        {
                            var smsToSend = _reloadlyConf.smsTemplate
                                .Replace("#currency#", response.deliveredAmountCurrencyCode)
                                .Replace("#amount#", guidReferneceRecord.toAmount)
                                .Replace("#to#", guidReferneceRecord.tomsisdn)
                                .Replace("#TransRef#", response.transactionId);
                            SendTwilioSms(request.fromMSISDN, smsToSend);
                        }
                        return result;
                    }
                    else
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<ReloadlyErrorResponse>(returnData);

                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh_v3(
                           DateTime.Now.ToString(),
                            _reloadlyConf.SimulationMode ? _reloadlyConf.simulation_client_id : _reloadlyConf.prod_client_id_eur, // Username
                           guidReferneceRecord.selling_price,         // Customer Charge Value
                           -1,
                           decimal.Parse(product),
                           guidReferneceRecord.account,
                           guidReferneceRecord.toCurrency,
                           guidReferneceRecord.destination_country,
                           "Failure",
                           "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.message,
                           guidReferneceRecord.operatorCode,
                           product,
                           guidReferneceRecord.operatorName,
                           null,
                           "",
                           fromMSISDN,
                           guidReferneceRecord.tomsisdn,
                           4,
                           messageToRecipient,
                           guidReferneceRecord.productCode,
                           guidReferneceRecord.ProductItemCode,
                           nowtelTransactionReference,
                           json,
                           returnData,
                           GetTokenApiTime: tokenRequestEndTime < tokenRequestStartTime ? 0 : (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                           TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds


                           );

                            if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                            {
                                await _common_BL.SendEmail(new EmailTransactionModel()
                                {
                                    accessGUID = nowtelTransactionReference,
                                    DestinationCountry = guidReferneceRecord.destination_country,
                                    ErrorMessage = "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.message,
                                    Status = "Failure",
                                    FromMsisdn = guidReferneceRecord.frommsisdn,
                                    ToMsisdn = guidReferneceRecord.tomsisdn,
                                    OperatorId = guidReferneceRecord.operatorCode,
                                    OperatorName = guidReferneceRecord.operatorName,
                                    ProductCode = guidReferneceRecord.productCode,
                                    ProductItemCode = guidReferneceRecord.ProductItemCode,
                                    ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                                    TransationType = TransationType.Execute
                                });
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  ReloadlyFreeSwitchTopUp  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        _logger.Debug($"  ReloadlyFreeSwitchTopUp  Failed  Source:Reloadly API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-N/A          Reason={errorResponse.message}");
                        var result = new
                        {
                            errorCode = 2,
                            status = "Failure",
                            message = errorResponse.message
                        };

                        return result;
                    }
                }
                catch (Exception ex)
                {
                    var date = DateTime.Now;

                    if (tokenRequestEndTime < tokenRequestStartTime)
                    {
                        tokenRequestEndTime = date;
                    }

                    if (TopUpApiEndTime < TopUpApiStartTime)
                    {
                        TopUpApiEndTime = date;
                    }


                    try
                    {
                        await _appDB.insertAirTimeTransferTransaction_Trh_v3(
                        DateTime.Now.ToString(),
                         _reloadlyConf.SimulationMode ? _reloadlyConf.simulation_client_id : _reloadlyConf.prod_client_id_eur, // Username
                        guidReferneceRecord.selling_price,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        guidReferneceRecord.toCurrency,
                        guidReferneceRecord.destination_country,
                        "FailureException",
                        ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                         guidReferneceRecord.operatorCode,
                        product,
                        guidReferneceRecord.operatorName,
                        null,
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        4,
                        messageToRecipient,
                        guidReferneceRecord.productCode,
                        guidReferneceRecord.ProductItemCode,
                        nowtelTransactionReference,
                        json,
                                returnData,
                                GetTokenApiTime: tokenRequestEndTime < tokenRequestStartTime ? 0 : (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                                TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                );

                        if (SmtpConfig.sendErrorExecuteTransactionEmail)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                accessGUID = nowtelTransactionReference,
                                DestinationCountry = guidReferneceRecord.destination_country,
                                ErrorMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                                Status = "FailureException",
                                FromMsisdn = guidReferneceRecord.frommsisdn,
                                ToMsisdn = guidReferneceRecord.tomsisdn,
                                OperatorId = guidReferneceRecord.operatorCode,
                                OperatorName = guidReferneceRecord.operatorName,
                                ProductCode = guidReferneceRecord.productCode,
                                ProductItemCode = guidReferneceRecord.ProductItemCode,
                                ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                                TransationType = TransationType.Execute

                            });
                        }

                    }
                    catch (Exception dbException)
                    {
                        _logger.Debug($"  ReloadlyFreeSwitchTopUp  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _logger.Debug($"  ReloadlyFreeSwitchTopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return errorResult;
                }
            }
            catch (Exception ex)
            {
                _logger.Debug($"  ReloadlyFreeSwitchTopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return errorResult;
            }

        }

        public async Task<JsonOperatorProductResponse> ReloadlyTHAGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, bool useDbRates, int? cdsp_config_id, string productCode, string productItemCode)
        {

            string iso = string.Empty;
            PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
            try
            {
                string phone = ToMsisdn;
                if (!phone.StartsWith("+"))
                    phone = "+" + phone;
                // phone must begin with '+'
                PhoneNumber numberProto = phoneUtil.Parse(phone, "");
                int countryCode = numberProto.CountryCode;
                iso = phoneUtil.GetRegionCodeForCountryCode(countryCode);
            }
            catch (NumberParseException e)
            {
                _logger.Debug($"  ReloadlyTHAGetPhoneOperator-PhoneNumberUtil unable to fetch iso code against " + ToMsisdn + " error " + e.ToString());
            }

            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 4;
            int suggesstionCount = 7;
            try
            {

                // Validating fraud customers , at_check_fraud

                try
                {

                    bool isPermitted = await _appDB.CheckFraudUser("", ToMsisdn, fromMSISDN);
                    if (isPermitted == false)
                    {
                        result.errorCode = 3;
                        result.status = "Failure";
                        result.message = "Fraud detected. Access Blocked.";
                        return result;
                    }

                }
                catch (Exception ex)
                {
                    _logger.Error($"  \"GET /ReloadlyTHAGetPhoneOperator\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {ToMsisdn}, destinationMSISDN: {fromMSISDN}, currency:{account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    result.errorCode = 2;
                    result.status = "Failure";
                    result.message = "General API Access Error: " + ex.Message;
                    return result;

                }
                //var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn,fromMSISDN);// Get the discount if any exists in db agains destination

                var subUrl = $"operators/auto-detect/phone/{ToMsisdn}/countries/{iso}?suggestedAmountsMap=true&suggestedAmounts=true";
                tokenRequestStartTime = DateTime.Now;
                var authResponse = await _reloadlyAuth_BL.getAuthToken(account);
                tokenRequestEndTime = DateTime.Now;
                var baseAddress = new Uri(_reloadlyConf.SimulationMode ? _reloadlyConf.simulation_audience : _reloadlyConf.prod_audience);
                HttpClient reloadlyHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/com.reloadly.topups-v1+json");
                reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");
                string returnData = "";
                GetPRoductStartTime = DateTime.Now;
                var httpResponse = await reloadlyHttpClient.GetAsync(subUrl);
                GetPRoductEndTime = DateTime.Now;
                var productJson = "{}";
                var requestJson = "";
                var responseJson = "";
                var serviceProviderId = result.servcieproviderid;
                if (httpResponse.StatusCode == HttpStatusCode.OK)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                    requestJson = subUrl; responseJson = returnData;
                    if (_reloadlyConf.JsonResponseLogging)
                    {
                        _logger.Information($"Reloadly ReloadlyTHAGetPhoneOperator Request {subUrl} Response {returnData}");
                    }
                    var operatorResponse = JsonConvert.DeserializeObject<ReloadlyOperatorResponse>(returnData);

                    PayLoad payload = new PayLoad();
                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();

                    operatorDetails.id = operatorResponse.operatorId.ToString();
                    operatorDetails.name = operatorResponse.name;
                    operatorDetails.country = operatorResponse.country.name;
                    operatorDetails.nowtelTransactionReference = Guid.NewGuid().ToString();
                    operatorDetails.ProductItemCode = productItemCode;
                    operatorDetails.iconUri = operatorResponse.logoUrls != null && operatorResponse.logoUrls.Length > 0 ? operatorResponse.logoUrls[0] : "";

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.insertTransactionGUID_Tha(operatorDetails.nowtelTransactionReference, account.ToUpper(), ToMsisdn, productJson, requestJson, responseJson, serviceProviderId, fromMSISDN, productItemCode, operatorResponse.country.isoName, operatorResponse.operatorId.ToString(), productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country, GetTokenApiTime: (tokenRequestEndTime.Value - tokenRequestStartTime.Value).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime.Value - GetPRoductStartTime.Value).TotalMilliseconds);
                    if (dbResult.DBStatus == 0)
                    {
                        _logger.Debug($"  ReloadlyTHAGetPhoneOperator  Failed  Source:Reloadly API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:Reloadly API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        int from_country_code = 0;
                        phoneUtil = PhoneNumberUtil.GetInstance();
                        try
                        {
                            if (!fromMSISDN.StartsWith("+"))
                                fromMSISDN = "+" + fromMSISDN;
                            PhoneNumber numberProto = phoneUtil.Parse(fromMSISDN, "");
                            from_country_code = numberProto.CountryCode;
                        }
                        catch (NumberParseException e)
                        {

                        }
                        THACustomerChargeValuesForReplacement custChargeValues = new THACustomerChargeValuesForReplacement();
                        if (useDbRates && cdsp_config_id.HasValue)
                            custChargeValues = await _appDB.GetReloadlyTHACustomerChargeValuesForReplacement(cdsp_config_id.Value, operatorDetails.id, result.servcieproviderid, from_country_code, operatorDetails.name);

                        //// IF suggested amounts has value either denomination type is range or fixed
                        var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(operatorResponse.suggestedAmountsMap.ToString());
                        if (dict.Count > 0)
                        {
                            bool productFound = false;
                            foreach (var custChargeValue in custChargeValues.chargeValues)
                            {
                                if ((operatorResponse.denominationType.ToLower().Equals("range")
                                && Convert.ToDecimal(custChargeValue.buying_price) >= Convert.ToDecimal(operatorResponse.minAmount)
                                && Convert.ToDecimal(custChargeValue.buying_price) <= Convert.ToDecimal(operatorResponse.maxAmount))
                                ||
                                (operatorResponse.denominationType.ToLower().Equals("fixed")
                                && dict.ContainsKey(Convert.ToDecimal(custChargeValue.buying_price).ToString()))
                                )
                                {

                                    //foreach (var kv in dict.Take(suggesstionCount))
                                    //{
                                    AttProduct product = new AttProduct();
                                    if (!_reloadlyConf.CalculateVIAFx
                                && (_reloadlyConf.SuggestedAmountOperatorCodes.Trim().Equals("*") || _reloadlyConf.SuggestedAmountOperatorCodes.Split(",").ToList().Contains(operatorResponse.operatorId.ToString())))
                                    {
                                        if (operatorResponse.denominationType.ToLower().Equals("range"))
                                        {
                                            if (dict.Count > 1)
                                                product.product = ((int)Math.Floor((Convert.ToDecimal(dict.ElementAt(1).Value) / Convert.ToDecimal(dict.ElementAt(1).Key)) * Convert.ToDecimal(custChargeValue.buying_price))).ToString();
                                            else
                                                product.product = ((int)Math.Floor((Convert.ToDecimal(dict.First().Value) / Convert.ToDecimal(dict.First().Key)) * Convert.ToDecimal(custChargeValue.buying_price))).ToString();
                                            productFound = true;
                                        }
                                        else
                                          if (dict.ContainsKey(custChargeValue.buying_price.ToString()))
                                        {
                                            product.product = dict[custChargeValue.buying_price.ToString()];
                                            productFound = true;
                                        }
                                        else
                                        {
                                            continue;
                                        }

                                    }
                                    else
                                    {
                                        product.product = ((int)Math.Floor(operatorResponse.fx.rate * Convert.ToDecimal(custChargeValue.buying_price))).ToString();
                                        productFound = true;
                                    }

                                    var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN, custChargeValue.selling_price);// Get the discount if any exists in db agains destination

                                    product.receiverccy = operatorResponse.destinationCurrencyCode;
                                    product.clientccy = operatorResponse.senderCurrencyCode;
                                    product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                    product.transactionfeeClientccy = 0.ToString();
                                    product.totalPriceClientccy = custChargeValue.selling_price.ToString();

                                    product.discountPercentage = discountPercentage;
                                    product.orignalAmount = product.totalPriceClientccy;
                                    product.itemPriceClientccy = Math.Round((Convert.ToDecimal(product.orignalAmount) - (Convert.ToDecimal(product.orignalAmount) * product.discountPercentage / 100)), 2).ToString();
                                    product.totalPriceClientccy = product.itemPriceClientccy;

                                    products.Add(product);

                                    await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                            account,
                            product.receiverccy,
                            product.product,
                           custChargeValue.buying_price.ToString(),
                            custChargeValue.buying_price.ToString(),
                            product.totalPriceClientccy,
                            //endrate.CustomerChargeValue.ToString(),
                            //endrate.CustomerChargeValue.ToString(),
                            0,
                            null,
                            null,
                   discountPercentage: product.discountPercentage,
                   orignalAmount: product.orignalAmount
                            );

                                    //}
                                }
                            }

                            if (!productFound)
                            {
                                if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                                {
                                    await _common_BL.SendEmail(new EmailTransactionModel()
                                    {
                                        ErrorMessage = $"ProductNotMatched: \n\r ConfiguredRates: {JsonConvert.SerializeObject(custChargeValues)} \n\r ProviderResponse: {JsonConvert.SerializeObject(dict)}",
                                        Status = "Failure",
                                        FromMsisdn = fromMSISDN,
                                        ToMsisdn = ToMsisdn,
                                        ProductCode = productCode,
                                        ProductItemCode = productItemCode,
                                        ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                                        TransationType = TransationType.Get
                                    });
                                }
                                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "ProductNotMatched", DbConfiguredValues: JsonConvert.SerializeObject(custChargeValues), OperatorResponse: JsonConvert.SerializeObject(dict));
                            }

                        }
                        else if (operatorResponse.denominationType.ToLower().Equals("range"))
                        {

                            foreach (var custChargeValue in custChargeValues.chargeValues)
                            {

                                var reloadlyProduct = operatorResponse.suggestedAmounts.FirstOrDefault(s => Convert.ToDecimal(s) == Convert.ToDecimal(custChargeValue.buying_price));
                                //foreach (var amount in operatorResponse.suggestedAmounts.Take(suggesstionCount))
                                //{

                                var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN, custChargeValue.selling_price);// Get the discount if any exists in db agains destination

                                AttProduct product = new AttProduct();
                                product.product = ((int)Math.Floor(operatorResponse.fx.rate * Convert.ToDecimal(custChargeValue.buying_price))).ToString();
                                product.receiverccy = operatorResponse.destinationCurrencyCode;
                                product.clientccy = operatorResponse.senderCurrencyCode;
                                product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                product.transactionfeeClientccy = 0.ToString();
                                product.totalPriceClientccy = custChargeValue.selling_price.ToString();

                                product.discountPercentage = discountPercentage;
                                product.orignalAmount = product.totalPriceClientccy;
                                product.itemPriceClientccy = Math.Round((Convert.ToDecimal(product.orignalAmount) - (Convert.ToDecimal(product.orignalAmount) * product.discountPercentage / 100)), 2).ToString();
                                product.totalPriceClientccy = product.itemPriceClientccy;

                                products.Add(product);

                                await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                  account,
                  product.receiverccy,
                  product.product,
                  custChargeValue.buying_price.ToString(),
                  custChargeValue.buying_price.ToString(),
                  product.totalPriceClientccy,
                  //endrate.CustomerChargeValue.ToString(),
                  //endrate.CustomerChargeValue.ToString(),
                  0,
                  null,
                  null,
                   discountPercentage: product.discountPercentage,
                   orignalAmount: product.orignalAmount
                  );
                                //}
                            }
                        }
                        else // Fixed denomination
                        {
                            if (operatorResponse.senderCurrencyCode == operatorResponse.destinationCurrencyCode)
                            {
                                foreach (var custChargeValue in custChargeValues.chargeValues)
                                {
                                    //foreach (var amount in operatorResponse.fixedAmounts.Take(suggesstionCount))
                                    //{

                                    var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN, custChargeValue.selling_price);// Get the discount if any exists in db agains destination

                                    var reloadlyProduct = operatorResponse.fixedAmounts.FirstOrDefault(s => Convert.ToDecimal(s) == Convert.ToDecimal(custChargeValue.buying_price));
                                    AttProduct product = new AttProduct();
                                    product.product = ((int)Math.Floor(operatorResponse.fx.rate * Convert.ToDecimal(custChargeValue.buying_price))).ToString();
                                    product.receiverccy = operatorResponse.destinationCurrencyCode;
                                    product.clientccy = operatorResponse.senderCurrencyCode;
                                    product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                    product.transactionfeeClientccy = 0.ToString();
                                    product.totalPriceClientccy = custChargeValue.selling_price.ToString();


                                    product.discountPercentage = discountPercentage;
                                    product.orignalAmount = product.totalPriceClientccy;
                                    product.itemPriceClientccy = Math.Round((Convert.ToDecimal(product.orignalAmount) - (Convert.ToDecimal(product.orignalAmount) * product.discountPercentage / 100)), 2).ToString();
                                    product.totalPriceClientccy = product.itemPriceClientccy;

                                    products.Add(product);

                                    await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                    account,
              product.receiverccy,
              product.product,
              custChargeValue.buying_price.ToString(),
              custChargeValue.buying_price.ToString(),
             product.totalPriceClientccy,
              //endrate.CustomerChargeValue.ToString(),
              //endrate.CustomerChargeValue.ToString(),
              0,
              null,
              null,
                   discountPercentage: product.discountPercentage,
                   orignalAmount: product.orignalAmount
                  );
                                    //}
                                }
                            }
                        }

                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _logger.Information($"  ReloadlyTHAGetPhoneOperator  Success      Parameters-msisdn:{ToMsisdn} currency:{account}");

                        return result;
                    }
                }
                else
                {

                    returnData = await httpResponse.Content.ReadAsStringAsync();
                    var errorResponse = JsonConvert.DeserializeObject<ReloadlyErrorResponse>(returnData);

                    result.message = errorResponse.message;
                    result.status = "Failure";
                    result.errorCode = 2;

                    _logger.Debug($"  ReloadlyTHAGetPhoneOperator  Failed  Source:Relaodly API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.message}");
                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                    {
                        await _common_BL.SendEmail(new EmailTransactionModel()
                        {
                            ErrorMessage = errorResponse.message,
                            Status = "Failure",
                            FromMsisdn = fromMSISDN,
                            ToMsisdn = ToMsisdn,
                            ProductCode = productCode,
                            ProductItemCode = productItemCode,
                            ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                            TransationType = TransationType.Get
                        });
                    }
                    await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message, GetTokenApiTime: (tokenRequestEndTime.Value - tokenRequestStartTime.Value).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime.Value - GetPRoductStartTime.Value).TotalMilliseconds);

                    return result;
                }

            }
            catch (Exception ex)
            {
                var date = DateTime.Now;
                if (!tokenRequestStartTime.HasValue)
                {
                    tokenRequestStartTime = date;
                }
                if (!tokenRequestEndTime.HasValue)
                {
                    tokenRequestEndTime = date;
                }
                if (!GetPRoductStartTime.HasValue)
                {
                    GetPRoductStartTime = date;
                }
                if (!GetPRoductEndTime.HasValue)
                {
                    GetPRoductEndTime = date;
                }
                _logger.Debug($"  ReloadlyTHAGetPhoneOperator  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";

                if (SmtpConfig.sendErrorGetProductsEmail)
                {
                    await _common_BL.SendEmail(new EmailTransactionModel()
                    {
                        ErrorMessage = ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                        Status = "Failure",
                        FromMsisdn = fromMSISDN,
                        ToMsisdn = ToMsisdn,
                        ProductCode = productCode,
                        ProductItemCode = productItemCode,
                        ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                        TransationType = TransationType.Get
                    });
                }
                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""), GetTokenApiTime: (tokenRequestEndTime.Value - tokenRequestStartTime.Value).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime.Value - GetPRoductStartTime.Value).TotalMilliseconds);
                return result;
            }

        }

        public async Task<JsonOperatorProductResponse> Com_ATT_ReloadlyGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, int? cdsp_config_id, string productCode, string productItemCode, string ProductId, int selectedCarrierNumber)
        {

            string iso = string.Empty;
            PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
            try
            {
                string phone = ToMsisdn;
                if (!phone.StartsWith("+"))
                    phone = "+" + phone;
                // phone must begin with '+'
                PhoneNumber numberProto = phoneUtil.Parse(phone, "");
                int countryCode = numberProto.CountryCode;
                iso = phoneUtil.GetRegionCodeForCountryCode(countryCode);
            }
            catch (NumberParseException e)
            {
                _logger.Debug($"  Com_ATT_ReloadlyGetPhoneOperator-PhoneNumberUtil unable to fetch iso code against " + ToMsisdn + " error " + e.ToString());
            }

            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 4;
            int suggesstionCount = 7;

            // Validating fraud customers , at_check_fraud

            try
            {

                bool isPermitted = await _appDB.CheckFraudUser("", ToMsisdn, fromMSISDN);
                if (isPermitted == false)
                {
                    result.errorCode = 3;
                    result.status = "Failure";
                    result.message = "Fraud detected. Access Blocked.";
                    return result;
                }

            }
            catch (Exception ex)
            {
                _logger.Error($"  \"GET /Com_ATT_ReloadlyGetPhoneOperator\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {ToMsisdn}, destinationMSISDN: {fromMSISDN}, currency:{account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error: " + ex.Message;
                return result;

            }

            try
            {
                var subUrl = $"operators/auto-detect/phone/{ToMsisdn}/countries/{iso}?suggestedAmountsMap=true&suggestedAmounts=true";
                tokenRequestStartTime = DateTime.Now;
                var authResponse = await _reloadlyAuth_BL.CRM_ATT_getAuthToken(account, ProductId);
                tokenRequestEndTime = DateTime.Now;
                var baseAddress = new Uri(_reloadlyConf.SimulationMode ? _reloadlyConf.simulation_audience : _reloadlyConf.prod_audience);
                HttpClient reloadlyHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/com.reloadly.topups-v1+json");
                reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");
                string returnData = "";
                GetPRoductStartTime = DateTime.Now;
                var httpResponse = await reloadlyHttpClient.GetAsync(subUrl);
                GetPRoductEndTime = DateTime.Now;
                var productJson = "{}";
                var requestJson = "";
                var responseJson = "";
                var serviceProviderId = result.servcieproviderid;
                if (httpResponse.StatusCode == HttpStatusCode.OK)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                    requestJson = subUrl; responseJson = returnData;
                    if (_reloadlyConf.JsonResponseLogging)
                    {
                        _logger.Information($"Reloadly Com_ATT_ReloadlyGetPhoneOperator Request {subUrl} Response {returnData}");
                    }
                    var operatorResponse = JsonConvert.DeserializeObject<ReloadlyOperatorResponse>(returnData);

                    PayLoad payload = new PayLoad();
                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();

                    operatorDetails.id = operatorResponse.operatorId.ToString();
                    operatorDetails.name = operatorResponse.name;
                    operatorDetails.country = operatorResponse.country.name;
                    operatorDetails.nowtelTransactionReference = Guid.NewGuid().ToString();
                    operatorDetails.ProductItemCode = productItemCode;
                    operatorDetails.iconUri = operatorResponse.logoUrls != null && operatorResponse.logoUrls.Length > 0 ? operatorResponse.logoUrls[0] : "";

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.Com_ATT_insertTransactionGUID(ProductId, operatorDetails.nowtelTransactionReference, account.ToUpper(), ToMsisdn, productJson, requestJson, responseJson, serviceProviderId, fromMSISDN, productItemCode, operatorResponse.country.isoName, operatorResponse.operatorId.ToString(), productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country, GetTokenApiTime: (tokenRequestEndTime.Value - tokenRequestStartTime.Value).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime.Value - GetPRoductStartTime.Value).TotalMilliseconds);
                    if (dbResult.DBStatus == 0)
                    {
                        _logger.Debug($"  Com_ATT_ReloadlyGetPhoneOperator  Failed  Source:Reloadly API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:Reloadly API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        int from_country_code = 0;
                        phoneUtil = PhoneNumberUtil.GetInstance();
                        try
                        {
                            if (!fromMSISDN.StartsWith("+"))
                                fromMSISDN = "+" + fromMSISDN;
                            PhoneNumber numberProto = phoneUtil.Parse(fromMSISDN, "");
                            from_country_code = numberProto.CountryCode;
                        }
                        catch (NumberParseException e)
                        {

                        }
                        COMM_ATT_CustomerChargeValuesForReplacement custChargeValues = new COMM_ATT_CustomerChargeValuesForReplacement();
                        if (cdsp_config_id.HasValue)
                            custChargeValues = await _appDB.Com_ATT_GetCustomerChargeValuesForReplacement(cdsp_config_id.Value, selectedCarrierNumber);

                        //// IF suggested amounts has value either denomination type is range or fixed
                        var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(operatorResponse.suggestedAmountsMap.ToString());
                        if (dict.Count > 0)
                        {
                            bool productFound = false;
                            foreach (var custChargeValue in custChargeValues.chargeValues)
                            {
                                if ((operatorResponse.denominationType.ToLower().Equals("range")
                                && Convert.ToDecimal(custChargeValue.buying_price) >= Convert.ToDecimal(operatorResponse.minAmount)
                                && Convert.ToDecimal(custChargeValue.buying_price) <= Convert.ToDecimal(operatorResponse.maxAmount))
                                ||
                                (operatorResponse.denominationType.ToLower().Equals("fixed")
                                && dict.ContainsKey(Convert.ToDecimal(custChargeValue.buying_price).ToString()))
                                )
                                {

                                    //foreach (var kv in dict.Take(suggesstionCount))
                                    //{
                                    AttProduct product = new AttProduct();

                                    if (!_reloadlyConf.CalculateVIAFx
                                && (_reloadlyConf.SuggestedAmountOperatorCodes.Trim().Equals("*") || _reloadlyConf.SuggestedAmountOperatorCodes.Split(",").ToList().Contains(operatorResponse.operatorId.ToString())))
                                    {
                                        if (operatorResponse.denominationType.ToLower().Equals("range"))
                                        {
                                            if (dict.Count > 1)
                                                product.product = ((int)Math.Floor((Convert.ToDecimal(dict.ElementAt(1).Value) / Convert.ToDecimal(dict.ElementAt(1).Key)) * Convert.ToDecimal(custChargeValue.buying_price))).ToString();
                                            else
                                                product.product = ((int)Math.Floor((Convert.ToDecimal(dict.First().Value) / Convert.ToDecimal(dict.First().Key)) * Convert.ToDecimal(custChargeValue.buying_price))).ToString();
                                            productFound = true;
                                        }
                                        else
                                        if (dict.ContainsKey(custChargeValue.buying_price.ToString()))
                                        {
                                            product.product = dict[custChargeValue.buying_price.ToString()];
                                            productFound = true;
                                        }
                                        else
                                        {
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        product.product = ((int)Math.Floor(operatorResponse.fx.rate * Convert.ToDecimal(custChargeValue.buying_price))).ToString();
                                        productFound = true;
                                    }

                                    product.receiverccy = operatorResponse.destinationCurrencyCode;
                                    product.clientccy = operatorResponse.senderCurrencyCode;
                                    product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                    product.transactionfeeClientccy = 0.ToString();
                                    product.totalPriceClientccy = custChargeValue.selling_price.ToString();
                                    products.Add(product);

                                    await _appDB.insertaccessDetails(dbResult.InsertId,
                            account,
                            product.receiverccy,
                            product.product,
                           custChargeValue.buying_price.ToString(),
                            custChargeValue.buying_price.ToString(),
                            custChargeValue.selling_price.ToString(),
                            //endrate.CustomerChargeValue.ToString(),
                            //endrate.CustomerChargeValue.ToString(),
                            0,
                            null,
                            null,
                            custChargeValue.received_amount.ToString()
                            );

                                    //}
                                }
                            }

                            if (!productFound)
                            {
                                if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                                {
                                    await _common_BL.SendEmail(new EmailTransactionModel()
                                    {
                                        ErrorMessage = $"ProductNotMatched: \n\r ConfiguredRates: {JsonConvert.SerializeObject(custChargeValues)} \n\r ProviderResponse: {JsonConvert.SerializeObject(dict)}",
                                        Status = "Failure",
                                        FromMsisdn = fromMSISDN,
                                        ToMsisdn = ToMsisdn,
                                        ProductCode = productCode,
                                        ProductItemCode = productItemCode,
                                        ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                                        TransationType = TransationType.Get
                                    });
                                }
                                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "ProductNotMatched", DbConfiguredValues: JsonConvert.SerializeObject(custChargeValues), OperatorResponse: JsonConvert.SerializeObject(dict));
                            }
                        }
                        else if (operatorResponse.denominationType.ToLower().Equals("range"))
                        {

                            foreach (var custChargeValue in custChargeValues.chargeValues)
                            {

                                var reloadlyProduct = operatorResponse.suggestedAmounts.FirstOrDefault(s => Convert.ToDecimal(s) == Convert.ToDecimal(custChargeValue.buying_price));
                                //foreach (var amount in operatorResponse.suggestedAmounts.Take(suggesstionCount))
                                //{
                                AttProduct product = new AttProduct();
                                product.product = ((int)Math.Floor(operatorResponse.fx.rate * Convert.ToDecimal(custChargeValue.buying_price))).ToString();
                                product.receiverccy = operatorResponse.destinationCurrencyCode;
                                product.clientccy = operatorResponse.senderCurrencyCode;
                                product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                product.transactionfeeClientccy = 0.ToString();
                                product.totalPriceClientccy = custChargeValue.selling_price.ToString();
                                products.Add(product);

                                await _appDB.insertaccessDetails(dbResult.InsertId,
                  account,
                  product.receiverccy,
                  product.product,
                  custChargeValue.buying_price.ToString(),
                  custChargeValue.buying_price.ToString(),
                  custChargeValue.selling_price.ToString(),
                  //endrate.CustomerChargeValue.ToString(),
                  //endrate.CustomerChargeValue.ToString(),
                  0,
                  null,
                  null,
                            custChargeValue.received_amount.ToString()
                  );
                                //}
                            }
                        }
                        else // Fixed denomination
                        {
                            if (operatorResponse.senderCurrencyCode == operatorResponse.destinationCurrencyCode)
                            {
                                foreach (var custChargeValue in custChargeValues.chargeValues)
                                {
                                    //foreach (var amount in operatorResponse.fixedAmounts.Take(suggesstionCount))
                                    //{

                                    var reloadlyProduct = operatorResponse.fixedAmounts.FirstOrDefault(s => Convert.ToDecimal(s) == Convert.ToDecimal(custChargeValue.buying_price));
                                    AttProduct product = new AttProduct();
                                    product.product = ((int)Math.Floor(operatorResponse.fx.rate * Convert.ToDecimal(custChargeValue.buying_price))).ToString();
                                    product.receiverccy = operatorResponse.destinationCurrencyCode;
                                    product.clientccy = operatorResponse.senderCurrencyCode;
                                    product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                    product.transactionfeeClientccy = 0.ToString();
                                    product.totalPriceClientccy = custChargeValue.selling_price.ToString();
                                    products.Add(product);

                                    await _appDB.insertaccessDetails(dbResult.InsertId,
                    account,
              product.receiverccy,
              product.product,
              custChargeValue.buying_price.ToString(),
              custChargeValue.buying_price.ToString(),
              custChargeValue.selling_price.ToString(),
              //endrate.CustomerChargeValue.ToString(),
              //endrate.CustomerChargeValue.ToString(),
              0,
              null,
              null,
                            custChargeValue.received_amount.ToString()
                  );
                                    //}
                                }
                            }
                        }

                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _logger.Information($"  Com_ATT_ReloadlyGetPhoneOperator  Success      Parameters-msisdn:{ToMsisdn} currency:{account}");

                        return result;
                    }
                }
                else
                {

                    returnData = await httpResponse.Content.ReadAsStringAsync();
                    var errorResponse = JsonConvert.DeserializeObject<ReloadlyErrorResponse>(returnData);

                    result.message = errorResponse.message;
                    result.status = "Failure";
                    result.errorCode = 2;

                    _logger.Debug($"  Com_ATT_ReloadlyGetPhoneOperator  Failed  Source:Relaodly API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.message}");
                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                    {
                        await _common_BL.SendEmail(new EmailTransactionModel()
                        {
                            ErrorMessage = errorResponse.message,
                            Status = "Failure",
                            FromMsisdn = fromMSISDN,
                            ToMsisdn = ToMsisdn,
                            ProductCode = productCode,
                            ProductItemCode = productItemCode,
                            ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                            TransationType = TransationType.Get
                        });
                    }
                    await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message, GetTokenApiTime: (tokenRequestEndTime.Value - tokenRequestStartTime.Value).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime.Value - GetPRoductStartTime.Value).TotalMilliseconds);
                    return result;
                }

            }
            catch (Exception ex)
            {
                var date = DateTime.Now;
                if (!tokenRequestStartTime.HasValue)
                {
                    tokenRequestStartTime = date;
                }
                if (!tokenRequestEndTime.HasValue)
                {
                    tokenRequestEndTime = date;
                }
                if (!GetPRoductStartTime.HasValue)
                {
                    GetPRoductStartTime = date;
                }
                if (!GetPRoductEndTime.HasValue)
                {
                    GetPRoductEndTime = date;
                }
                _logger.Debug($"  Com_ATT_ReloadlyGetPhoneOperator  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                if (SmtpConfig.sendErrorGetProductsEmail)
                {
                    await _common_BL.SendEmail(new EmailTransactionModel()
                    {
                        ErrorMessage = ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                        Status = "Failure",
                        FromMsisdn = fromMSISDN,
                        ToMsisdn = ToMsisdn,
                        ProductCode = productCode,
                        ProductItemCode = productItemCode,
                        ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                        TransationType = TransationType.Get
                    });
                }
                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""), GetTokenApiTime: (tokenRequestEndTime.Value - tokenRequestStartTime.Value).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime.Value - GetPRoductStartTime.Value).TotalMilliseconds);
                return result;
            }

        }

        public async Task<JsonATTCRMOperatorProductResponse> ReloadlyATTCRMGetPhoneOperator(string account, string ToMsisdn, string productID)
        {

            string iso = string.Empty;
            PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
            int suggesstionCount = 15;
            try
            {
                string phone = ToMsisdn;
                if (!phone.StartsWith("+"))
                    phone = "+" + phone;
                // phone must begin with '+'
                PhoneNumber numberProto = phoneUtil.Parse(phone, "");
                int countryCode = numberProto.CountryCode;
                iso = phoneUtil.GetRegionCodeForCountryCode(countryCode);
            }
            catch (NumberParseException e)
            {
                _logger.Debug($"  ReloadlyATTCRMGetPhoneOperator-PhoneNumberUtil unable to fetch iso code against " + ToMsisdn + " error " + e.ToString());
            }

            JsonATTCRMOperatorProductResponse result = new JsonATTCRMOperatorProductResponse();
            try
            {
                var subUrl = $"operators/auto-detect/phone/{ToMsisdn}/countries/{iso}?suggestedAmountsMap=true&suggestedAmounts=true";
                var authResponse = await _reloadlyAuth_BL.CRM_ATT_getAuthToken(account, productID);
                var baseAddress = new Uri(_reloadlyConf.SimulationMode ? _reloadlyConf.simulation_audience : _reloadlyConf.prod_audience);
                HttpClient reloadlyHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/com.reloadly.topups-v1+json");
                reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");
                string returnData = "";
                var httpResponse = await reloadlyHttpClient.GetAsync(subUrl);
                var productJson = "{}";
                var requestJson = "";
                var responseJson = "";
                var serviceProviderId = 4;
                if (httpResponse.StatusCode == HttpStatusCode.OK)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                    requestJson = subUrl; responseJson = returnData;
                    if (_reloadlyConf.JsonResponseLogging)
                    {
                        _logger.Information($"Reloadly ReloadlyATTCRMGetPhoneOperator Request {subUrl} Response {returnData}");
                    }
                    var operatorResponse = JsonConvert.DeserializeObject<ReloadlyOperatorResponse>(returnData);

                    ATTCRMPayLoad payload = new ATTCRMPayLoad();
                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttCRMOperator> operators = new List<AttCRMOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttCRMOperator operatorDetails = new AttCRMOperator();

                    operatorDetails.name = operatorResponse.name;
                    operatorDetails.country = operatorResponse.country.name;

                    //// IF suggested amounts has value either denomination type is range or fixed
                    var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(operatorResponse.suggestedAmountsMap.ToString());
                    if (operatorResponse.denominationType.ToLower().Equals("range"))
                    {
                        result.isRange = true;

                        //Min
                        AttProduct product = new AttProduct();
                        if (!_reloadlyConf.CalculateVIAFx
                                && (_reloadlyConf.SuggestedAmountOperatorCodes.Trim().Equals("*") || _reloadlyConf.SuggestedAmountOperatorCodes.Split(",").ToList().Contains(operatorResponse.operatorId.ToString())))
                        {
                            //if (dict.Count > 1)
                            //    product.product = ((Convert.ToDecimal(dict.ElementAt(1).Value) / Convert.ToDecimal(dict.ElementAt(1).Key)) * Convert.ToDecimal(operatorResponse.minAmount)).ToString();
                            //else
                            //    product.product = ((Convert.ToDecimal(dict.First().Value) / Convert.ToDecimal(dict.First().Key)) * Convert.ToDecimal(operatorResponse.minAmount)).ToString();
                            product.product = operatorResponse.localMinAmount.ToString();
                        }
                        else
                        {
                            product.product = (operatorResponse.minAmount * operatorResponse.fx.rate).ToString();
                        }

                        product.receiverccy = operatorResponse.destinationCurrencyCode;
                        product.clientccy = operatorResponse.senderCurrencyCode;
                        product.itemPriceClientccy = operatorResponse.minAmount.ToString();
                        product.transactionfeeClientccy = 0.ToString();
                        product.totalPriceClientccy = operatorResponse.minAmount.ToString();
                        products.Add(product);


                        //Max
                        product = new AttProduct();
                        if (!_reloadlyConf.CalculateVIAFx
                                && (_reloadlyConf.SuggestedAmountOperatorCodes.Trim().Equals("*") || _reloadlyConf.SuggestedAmountOperatorCodes.Split(",").ToList().Contains(operatorResponse.operatorId.ToString())))
                        {
                            //if (dict.Count > 1)
                            //    product.product = ((Convert.ToDecimal(dict.ElementAt(1).Value) / Convert.ToDecimal(dict.ElementAt(1).Key)) * Convert.ToDecimal(operatorResponse.maxAmount)).ToString();
                            //else
                            //    product.product = ((Convert.ToDecimal(dict.First().Value) / Convert.ToDecimal(dict.First().Key)) * Convert.ToDecimal(operatorResponse.maxAmount)).ToString();
                            product.product = operatorResponse.localMaxAmount.ToString();
                        }
                        else
                        {
                            product.product = (operatorResponse.maxAmount * operatorResponse.fx.rate).ToString();
                        }
                        product.receiverccy = operatorResponse.destinationCurrencyCode;
                        product.clientccy = operatorResponse.senderCurrencyCode;
                        product.itemPriceClientccy = operatorResponse.maxAmount.ToString();
                        product.transactionfeeClientccy = 0.ToString();
                        product.totalPriceClientccy = operatorResponse.maxAmount.ToString();
                        products.Add(product);

                    }
                    else
                    {
                        if (dict.Count > 0)
                        {
                            foreach (var kv in dict.Take(suggesstionCount))
                            {
                                AttProduct product = new AttProduct();

                                if (!_reloadlyConf.CalculateVIAFx
                                    && (_reloadlyConf.SuggestedAmountOperatorCodes.Trim().Equals("*") || _reloadlyConf.SuggestedAmountOperatorCodes.Split(",").ToList().Contains(operatorResponse.operatorId.ToString())))
                                {
                                    //if (dict.Count > 1)
                                    //    product.product = ((Convert.ToDecimal(dict.ElementAt(1).Value) / Convert.ToDecimal(dict.ElementAt(1).Key)) * Convert.ToDecimal(kv.Key)).ToString();
                                    //else
                                    //    product.product = ((Convert.ToDecimal(dict.First().Value) / Convert.ToDecimal(dict.First().Key)) * Convert.ToDecimal(kv.Key)).ToString();
                                    product.product = kv.Value;
                                }
                                else
                                {
                                    product.product = (operatorResponse.fx.rate * Convert.ToDecimal(kv.Key)).ToString();
                                }

                                product.receiverccy = operatorResponse.destinationCurrencyCode;
                                product.clientccy = operatorResponse.senderCurrencyCode;
                                product.itemPriceClientccy = kv.Key.ToString();
                                product.transactionfeeClientccy = 0.ToString();
                                product.totalPriceClientccy = kv.Key.ToString();
                                products.Add(product);

                            }
                        }
                        else if (_reloadlyConf.CalculateVIAFx && operatorResponse.fixedAmounts.Count() > 0)
                        {
                            foreach (var kv in operatorResponse.fixedAmounts.Take(suggesstionCount))
                            {
                                AttProduct product = new AttProduct();
                                product.product = (operatorResponse.fx.rate * Convert.ToDecimal(kv)).ToString();
                                product.receiverccy = operatorResponse.destinationCurrencyCode;
                                product.clientccy = operatorResponse.senderCurrencyCode;
                                product.itemPriceClientccy = kv.ToString();
                                product.transactionfeeClientccy = 0.ToString();
                                product.totalPriceClientccy = kv.ToString();
                                products.Add(product);
                            }
                        }

                    }
                    operatorDetails.products = products;
                    operators.Add(operatorDetails);
                    payload.operators = operators;
                    result.ATTCRMpayload = payload;
                    _logger.Information($"  ReloadlyATTCRMGetPhoneOperator  Success      Parameters-msisdn:{ToMsisdn} currency:{account}");

                    return result;
                }
                else
                {

                    returnData = await httpResponse.Content.ReadAsStringAsync();
                    var errorResponse = JsonConvert.DeserializeObject<ReloadlyErrorResponse>(returnData);

                    result.message = errorResponse.message;
                    result.status = "Failure";
                    result.errorCode = 2;

                    _logger.Debug($"  ReloadlyATTCRMGetPhoneOperator  Failed  Source:Relaodly API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.message}");

                    return result;
                }

            }
            catch (Exception ex)
            {
                _logger.Debug($"  ReloadlyATTCRMGetPhoneOperator  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                return result;
            }

        }


        public async Task<object> ReloadlyTHATopUp(ExecuteData request)
        {
            try
            {
                string json = "";
                string returnData = "";
                DateTime tokenRequestStartTime = DateTime.Now;
                DateTime tokenRequestEndTime = tokenRequestStartTime;
                DateTime TopUpApiStartTime = tokenRequestStartTime;
                DateTime TopUpApiEndTime = tokenRequestStartTime;

                string nowtelTransactionReference = request.nowtelTransactionReference;
                string product = request.product;
                string messageToRecipient = request.messageToRecipient;
                string fromMSISDN = request.fromMSISDN;

                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(nowtelTransactionReference, product);

                guidReferneceRecord.tomsisdn = guidReferneceRecord.tomsisdn.Replace("+", "");
                guidReferneceRecord.tomsisdn = guidReferneceRecord.tomsisdn.StartsWith("00") == true ? guidReferneceRecord.tomsisdn.Remove(0, 2) : guidReferneceRecord.tomsisdn;


                if (guidReferneceRecord == null)
                {
                    _logger.Debug($"   /ReloadlyTHATopUp  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return result;
                }
                try
                {


                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn,request.nowtelTransactionReference.Remove(0, 14), request.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"  \"GET /ReloadlyTHATopUp\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return result;
                }
                string clientId = (guidReferneceRecord.account.ToUpper() == "GBP" ? _reloadlyConf.prod_client_id_gbp : _reloadlyConf.prod_client_id_eur);

                try
                {
                    string recipientIso = string.Empty;
                    string senderIso = string.Empty;
                    PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
                    try
                    {
                        ///Receipent ISO Code
                        string phone = guidReferneceRecord.tomsisdn;
                        if (!phone.StartsWith("+"))
                            phone = "+" + phone;
                        // phone must begin with '+'
                        PhoneNumber numberProto = phoneUtil.Parse(phone, "");
                        int countryCode = numberProto.CountryCode;
                        recipientIso = phoneUtil.GetRegionCodeForCountryCode(countryCode);

                        //Sender ISO Code
                        phone = request.fromMSISDN;
                        if (!phone.StartsWith("+"))
                            phone = "+" + phone;
                        // phone must begin with '+'
                        numberProto = phoneUtil.Parse(phone, "");
                        countryCode = numberProto.CountryCode;
                        senderIso = phoneUtil.GetRegionCodeForCountryCode(countryCode);

                    }
                    catch (NumberParseException e)
                    {
                        _logger.Debug($"  ReloadlyTHATopUp-PhoneNumberUtil unable to fetch iso code against ToNumber" + guidReferneceRecord.tomsisdn + ". From Number" + request.fromMSISDN + " error " + e.ToString());
                    }


                    var subUrl = $"topups";
                    ReloadlyTopUpRequest topUpRequest = new ReloadlyTopUpRequest
                    {

                        amount = guidReferneceRecord.fromAmount,
                        customIdentifier = nowtelTransactionReference,
                        operatorId = guidReferneceRecord.operatorCode,
                        recipientPhone = new RelaodlyPhoneDetails
                        {
                            countryCode = recipientIso,
                            number = guidReferneceRecord.tomsisdn
                        },
                        senderPhone = new RelaodlyPhoneDetails
                        {
                            countryCode = senderIso,
                            number = request.fromMSISDN
                        },
                    };
                    json = JsonConvert.SerializeObject(topUpRequest);
                    tokenRequestStartTime = DateTime.Now;
                    var authResponse = await _reloadlyAuth_BL.getAuthToken(guidReferneceRecord.account);
                    tokenRequestEndTime = DateTime.Now;
                    var baseAddress = new Uri(_reloadlyConf.SimulationMode ? _reloadlyConf.simulation_audience : _reloadlyConf.prod_audience);
                    HttpClient reloadlyHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                    reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/com.reloadly.topups-v1+json");
                    reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");

                    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");


                    TopUpApiStartTime = DateTime.Now;
                    var httpResponse = await reloadlyHttpClient.PostAsync(subUrl, httpContent);
                    TopUpApiEndTime = DateTime.Now;

                    if (httpResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        if (_reloadlyConf.JsonResponseLogging)
                        {
                            _logger.Information($"Reloadly ReloadlyTHATopUp Request {json} Response {returnData}");
                        }
                        var response = JsonConvert.DeserializeObject<ReloadlyTopUpResponse>(returnData);

                        //Successful transaction
                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh_v4(
                                DateTime.Now.ToString(),
                                _reloadlyConf.SimulationMode ? _reloadlyConf.simulation_client_id : clientId, // Username
                                guidReferneceRecord.selling_price,        // Customer Charge Value
                                response.requestedAmount - response.discount ?? 0,  // Actual Charge Value
                                Convert.ToDecimal(guidReferneceRecord.product),
                                response.requestedAmountCurrencyCode,
                                response.deliveredAmountCurrencyCode,
                                guidReferneceRecord.destination_country,
                                "Success",
                                "",
                                response.operatorId.ToString(),
                                product,
                                response.operatorName,
                                null,
                                response.transactionId,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                4,
                                messageToRecipient,
                                guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                nowtelTransactionReference,
                                json,
                                returnData,
                                 guidReferneceRecord.discountPercentage.ToString(),
                                guidReferneceRecord.orignalAmount,
                                GetTokenApiTime: tokenRequestEndTime < tokenRequestStartTime ? 0 : (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                                TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                );

                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  ReloadlyTHATopUp  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }

                        _logger.Information($"  ReloadlyTHATopUp   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{response.transactionId}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = response.requestedAmount, // Customer Charge Value
                            currency = response.requestedAmountCurrencyCode,
                            reference = response.transactionId
                        };

                        if (_reloadlyConf.SendSmsToSender)
                        {
                            var smsToSend = _reloadlyConf.smsTemplate
                                .Replace("#currency#", response.deliveredAmountCurrencyCode)
                                .Replace("#amount#", guidReferneceRecord.toAmount)
                                .Replace("#to#", guidReferneceRecord.tomsisdn)
                                .Replace("#TransRef#", response.transactionId);
                            SendTwilioSms(request.fromMSISDN, smsToSend, guidReferneceRecord.productCode);

                            // Option Message Sms to Destination Msisdn
                            var smsBody = request.messageToRecipient;
                            SendTwilioSms(guidReferneceRecord.tomsisdn, smsBody, guidReferneceRecord.productCode, true);

                        }
                        return result;
                    }
                    else
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<ReloadlyErrorResponse>(returnData);

                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh_v4(
                           DateTime.Now.ToString(),
                            _reloadlyConf.SimulationMode ? _reloadlyConf.simulation_client_id : clientId, // Username
                           guidReferneceRecord.selling_price,         // Customer Charge Value
                           -1,
                           decimal.Parse(product),
                           guidReferneceRecord.account,
                           guidReferneceRecord.toCurrency,
                           guidReferneceRecord.destination_country,
                           "Failure",
                           "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.message,
                           guidReferneceRecord.operatorCode,
                           product,
                           guidReferneceRecord.operatorName,
                           null,
                           "",
                           fromMSISDN,
                           guidReferneceRecord.tomsisdn,
                           4,
                           messageToRecipient,
                           guidReferneceRecord.productCode,
                           guidReferneceRecord.ProductItemCode,
                           nowtelTransactionReference,
                           json,
                                returnData,
                                 guidReferneceRecord.discountPercentage.ToString(),
                                guidReferneceRecord.orignalAmount,
                                GetTokenApiTime: tokenRequestEndTime < tokenRequestStartTime ? 0 : (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                                TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                );

                            if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                            {
                                await _common_BL.SendEmail(new EmailTransactionModel()
                                {
                                    accessGUID = nowtelTransactionReference,
                                    DestinationCountry = guidReferneceRecord.destination_country,
                                    ErrorMessage = "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.message,
                                    Status = "Failure",
                                    FromMsisdn = guidReferneceRecord.frommsisdn,
                                    ToMsisdn = guidReferneceRecord.tomsisdn,
                                    OperatorId = guidReferneceRecord.operatorCode,
                                    OperatorName = guidReferneceRecord.operatorName,
                                    ProductCode = guidReferneceRecord.productCode,
                                    ProductItemCode = guidReferneceRecord.ProductItemCode,
                                    ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                                    TransationType = TransationType.Execute

                                });
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  ReloadlyTHATopUp  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        _logger.Debug($"  ReloadlyTHATopUp  Failed  Source:Reloadly API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-N/A          Reason={errorResponse.message}");
                        var result = new
                        {
                            errorCode = 2,
                            status = "Failure",
                            message = errorResponse.message
                        };

                        return result;
                    }
                }
                catch (Exception ex)
                {
                    var date = DateTime.Now;

                    if (tokenRequestEndTime < tokenRequestStartTime)
                    {
                        tokenRequestEndTime = date;
                    }

                    if (TopUpApiEndTime < TopUpApiStartTime)
                    {
                        TopUpApiEndTime = date;
                    }

                    try
                    {
                        await _appDB.insertAirTimeTransferTransaction_Trh_v4(
                        DateTime.Now.ToString(),
                         _reloadlyConf.SimulationMode ? _reloadlyConf.simulation_client_id : clientId, // Username
                        guidReferneceRecord.selling_price,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        guidReferneceRecord.toCurrency,
                        guidReferneceRecord.destination_country,
                        "FailureException",
                        ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                        guidReferneceRecord.operatorCode,
                        product,
                        guidReferneceRecord.operatorName,
                        null,
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        4,
                        messageToRecipient,
                        guidReferneceRecord.productCode,
                        guidReferneceRecord.ProductItemCode,
                        nowtelTransactionReference,
                         json,
                                returnData,
                                 guidReferneceRecord.discountPercentage.ToString(),
                                guidReferneceRecord.orignalAmount,
                               GetTokenApiTime: tokenRequestEndTime < tokenRequestStartTime ? 0 : (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                                TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                        );

                        if (SmtpConfig.sendErrorExecuteTransactionEmail)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                accessGUID = nowtelTransactionReference,
                                DestinationCountry = guidReferneceRecord.destination_country,
                                ErrorMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                                Status = "FailureException",
                                FromMsisdn = guidReferneceRecord.frommsisdn,
                                ToMsisdn = guidReferneceRecord.tomsisdn,
                                OperatorId = guidReferneceRecord.operatorCode,
                                OperatorName = guidReferneceRecord.operatorName,
                                ProductCode = guidReferneceRecord.productCode,
                                ProductItemCode = guidReferneceRecord.ProductItemCode,
                                ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                                TransationType = TransationType.Execute

                            });
                        }
                    }
                    catch (Exception dbException)
                    {
                        _logger.Debug($"  ReloadlyTHATopUp  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _logger.Debug($"  ReloadlyTHATopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return errorResult;
                }
            }
            catch (Exception ex)
            {
                _logger.Debug($"  ReloadlyTHATopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return errorResult;
            }

        }

        public async Task<object> CRM_ATT_ReloadlyTopUp(ExecuteData request, CRM_ATT_APIAccessGUID guidReferneceRecord)
        {
            try
            {
                string json = "";
                string returnData = "";
                DateTime tokenRequestStartTime = DateTime.Now;
                DateTime tokenRequestEndTime = tokenRequestStartTime;
                DateTime TopUpApiStartTime = tokenRequestStartTime;
                DateTime TopUpApiEndTime = tokenRequestStartTime;

                string nowtelTransactionReference = request.nowtelTransactionReference;
                string product = request.product;
                string messageToRecipient = request.messageToRecipient;
                string fromMSISDN = request.fromMSISDN;


                guidReferneceRecord.tomsisdn = guidReferneceRecord.tomsisdn.Replace("+", "");
                guidReferneceRecord.tomsisdn = guidReferneceRecord.tomsisdn.StartsWith("00") == true ? guidReferneceRecord.tomsisdn.Remove(0, 2) : guidReferneceRecord.tomsisdn;


                if (guidReferneceRecord == null)
                {
                    _logger.Debug($"   /CRM_ATT_ReloadlyTopUp  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return result;
                }
                try
                {


                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn, request.nowtelTransactionReference.Remove(0, 14), request.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"  \"GET /CRM_ATT_ReloadlyTopUp\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return result;
                }
                string clientId = (guidReferneceRecord.account.ToUpper() == "GBP" ? _reloadlyConf.prod_client_id_gbp : _reloadlyConf.prod_client_id_eur);

                try
                {
                    string recipientIso = string.Empty;
                    string senderIso = string.Empty;
                    PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
                    try
                    {
                        ///Receipent ISO Code
                        string phone = guidReferneceRecord.tomsisdn;
                        if (!phone.StartsWith("+"))
                            phone = "+" + phone;
                        // phone must begin with '+'
                        PhoneNumber numberProto = phoneUtil.Parse(phone, "");
                        int countryCode = numberProto.CountryCode;
                        recipientIso = phoneUtil.GetRegionCodeForCountryCode(countryCode);

                        //Sender ISO Code
                        phone = request.fromMSISDN;
                        if (!phone.StartsWith("+"))
                            phone = "+" + phone;
                        // phone must begin with '+'
                        numberProto = phoneUtil.Parse(phone, "");
                        countryCode = numberProto.CountryCode;
                        senderIso = phoneUtil.GetRegionCodeForCountryCode(countryCode);

                    }
                    catch (NumberParseException e)
                    {
                        _logger.Debug($"  CRM_ATT_ReloadlyTopUp-PhoneNumberUtil unable to fetch iso code against ToNumber" + guidReferneceRecord.tomsisdn + ". From Number" + request.fromMSISDN + " error " + e.ToString());
                    }


                    var subUrl = $"topups";
                    ReloadlyTopUpRequest topUpRequest = new ReloadlyTopUpRequest
                    {

                        amount = guidReferneceRecord.fromAmount,
                        customIdentifier = nowtelTransactionReference,
                        operatorId = guidReferneceRecord.operatorCode,
                        recipientPhone = new RelaodlyPhoneDetails
                        {
                            countryCode = recipientIso,
                            number = guidReferneceRecord.tomsisdn
                        },
                        senderPhone = new RelaodlyPhoneDetails
                        {
                            countryCode = senderIso,
                            number = request.fromMSISDN
                        },
                    };
                    json = JsonConvert.SerializeObject(topUpRequest);
                    tokenRequestStartTime = DateTime.Now;
                    var authResponse = await _reloadlyAuth_BL.CRM_ATT_getAuthToken(guidReferneceRecord.account, guidReferneceRecord.ProductId);
                    tokenRequestEndTime = DateTime.Now;
                    var baseAddress = new Uri(_reloadlyConf.SimulationMode ? _reloadlyConf.simulation_audience : _reloadlyConf.prod_audience);
                    HttpClient reloadlyHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                    reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/com.reloadly.topups-v1+json");
                    reloadlyHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");

                    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");



                    TopUpApiStartTime = DateTime.Now;
                    var httpResponse = await reloadlyHttpClient.PostAsync(subUrl, httpContent);
                    TopUpApiEndTime = DateTime.Now;

                    if (httpResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        if (_reloadlyConf.JsonResponseLogging)
                        {
                            _logger.Information($"Reloadly CRM_ATT_ReloadlyTopUp Request {json} Response {returnData}");
                        }
                        var response = JsonConvert.DeserializeObject<ReloadlyTopUpResponse>(returnData);

                        //Successful transaction
                        try
                        {

                            await _appDB.CRM_ATT_insertAirTimeTransferTransaction(
                              guidReferneceRecord.ProductId,
                              DateTime.Now.ToString(),
                                _reloadlyConf.SimulationMode ? _reloadlyConf.simulation_client_id : clientId, // Username
                                guidReferneceRecord.selling_price,        // Customer Charge Value
                                response.requestedAmount - response.discount ?? 0,  // Actual Charge Value
                                Convert.ToDecimal(guidReferneceRecord.product),
                                response.requestedAmountCurrencyCode,
                                response.deliveredAmountCurrencyCode,
                                guidReferneceRecord.destination_country,
                                "Success",
                                "",
                                response.operatorId.ToString(),
                                product,
                                response.operatorName,
                                null,
                                response.transactionId,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                4,
                                messageToRecipient,
                                guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                nowtelTransactionReference,
                                json,
                                returnData,
                                GetTokenApiTime: tokenRequestEndTime < tokenRequestStartTime ? 0 : (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                                TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds,
                                crmamount: guidReferneceRecord.crmAmount
                                );

                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  CRM_ATT_ReloadlyTopUp  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }

                        _logger.Information($"  CRM_ATT_ReloadlyTopUp   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{response.transactionId}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = response.requestedAmount, // Customer Charge Value
                            currency = response.requestedAmountCurrencyCode,
                            reference = response.transactionId
                        };

                        if (_reloadlyConf.SendSmsToSender)
                        {
                            var smsToSend = _reloadlyConf.smsTemplate
                                .Replace("#currency#", response.deliveredAmountCurrencyCode)
                                .Replace("#amount#", guidReferneceRecord.toAmount)
                                .Replace("#to#", guidReferneceRecord.tomsisdn)
                                .Replace("#TransRef#", response.transactionId);
                            SendTwilioSms(request.fromMSISDN, smsToSend, guidReferneceRecord.productCode);

                            // Option Message Sms to Destination Msisdn
                            //var smsBody = request.messageToRecipient;
                            //await SendTwilioSms(guidReferneceRecord.tomsisdn, smsBody, guidReferneceRecord.productCode, true);
                        }
                        return result;
                    }
                    else
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<ReloadlyErrorResponse>(returnData);

                        try
                        {

                            await _appDB.CRM_ATT_insertAirTimeTransferTransaction(
                              guidReferneceRecord.ProductId,
                         DateTime.Now.ToString(),
                            _reloadlyConf.SimulationMode ? _reloadlyConf.simulation_client_id : clientId, // Username
                           guidReferneceRecord.selling_price,        // Customer Charge Value
                           -1,
                           decimal.Parse(product),
                           guidReferneceRecord.account,
                           guidReferneceRecord.toCurrency,
                           guidReferneceRecord.destination_country,
                           "Failure",
                           "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.message,
                           guidReferneceRecord.operatorCode,
                           product,
                           guidReferneceRecord.operatorName,
                           null,
                           "",
                           fromMSISDN,
                           guidReferneceRecord.tomsisdn,
                           4,
                           messageToRecipient,
                           guidReferneceRecord.productCode,
                           guidReferneceRecord.ProductItemCode,
                           nowtelTransactionReference,
                           json,
                                returnData,
                                GetTokenApiTime: tokenRequestEndTime < tokenRequestStartTime ? 0 : (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                                TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds,
                                crmamount: guidReferneceRecord.crmAmount);


                            if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                            {
                                await _common_BL.SendEmail(new EmailTransactionModel()
                                {
                                    accessGUID = nowtelTransactionReference,
                                    DestinationCountry = guidReferneceRecord.destination_country,
                                    ErrorMessage = "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.message,
                                    Status = "Failure",
                                    FromMsisdn = guidReferneceRecord.frommsisdn,
                                    ToMsisdn = guidReferneceRecord.tomsisdn,
                                    OperatorId = guidReferneceRecord.operatorCode,
                                    OperatorName = guidReferneceRecord.operatorName,
                                    ProductCode = guidReferneceRecord.productCode,
                                    ProductItemCode = guidReferneceRecord.ProductItemCode,
                                    ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                                    TransationType = TransationType.Execute

                                });
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  CRM_ATT_ReloadlyTopUp  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        _logger.Debug($"  CRM_ATT_ReloadlyTopUp  Failed  Source:Reloadly API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-N/A          Reason={errorResponse.message}");
                        var result = new
                        {
                            errorCode = 2,
                            status = "Failure",
                            message = errorResponse.message
                        };

                        return result;
                    }
                }
                catch (Exception ex)
                {
                    var date = DateTime.Now;

                    if (tokenRequestEndTime < tokenRequestStartTime)
                    {
                        tokenRequestEndTime = date;
                    }

                    if (TopUpApiEndTime < TopUpApiStartTime)
                    {
                        TopUpApiEndTime = date;
                    }

                    try
                    {
                        await _appDB.CRM_ATT_insertAirTimeTransferTransaction(
                              guidReferneceRecord.ProductId,
                      DateTime.Now.ToString(),
                         _reloadlyConf.SimulationMode ? _reloadlyConf.simulation_client_id : clientId, // Username
                        guidReferneceRecord.selling_price,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        guidReferneceRecord.toCurrency,
                        guidReferneceRecord.destination_country,
                        "FailureException",
                        ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                         guidReferneceRecord.operatorCode,
                        product,
                        guidReferneceRecord.operatorName,
                        null,
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        4,
                        messageToRecipient,
                        guidReferneceRecord.productCode,
                        guidReferneceRecord.ProductItemCode,
                        nowtelTransactionReference,
                        json,
                                returnData,
                                GetTokenApiTime: tokenRequestEndTime < tokenRequestStartTime ? 0 : (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                                TopUpApiTime: TopUpApiEndTime < TopUpApiStartTime ? 0 : (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds,
                                crmamount: guidReferneceRecord.crmAmount);

                        if (SmtpConfig.sendErrorExecuteTransactionEmail)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                accessGUID = nowtelTransactionReference,
                                DestinationCountry = guidReferneceRecord.destination_country,
                                ErrorMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                                Status = "FailureException",
                                FromMsisdn = guidReferneceRecord.frommsisdn,
                                ToMsisdn = guidReferneceRecord.tomsisdn,
                                OperatorId = guidReferneceRecord.operatorCode,
                                OperatorName = guidReferneceRecord.operatorName,
                                ProductCode = guidReferneceRecord.productCode,
                                ProductItemCode = guidReferneceRecord.ProductItemCode,
                                ServiceProviderName = ServiceProvider.Reloadly.ToString(),
                                TransationType = TransationType.Execute

                            });
                        }
                    }
                    catch (Exception dbException)
                    {
                        _logger.Debug($"  CRM_ATT_ReloadlyTopUp  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _logger.Debug($"  CRM_ATT_ReloadlyTopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return errorResult;
                }
            }
            catch (Exception ex)
            {
                _logger.Debug($"  CRM_ATT_ReloadlyTopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return errorResult;
            }

        }


        private async Task SendTwilioSms(string to, string textMessage, string productCode = null, bool isOptionMessage = false)
        {
            bool isRestrictedCountry = false;
            Twilio.Types.PhoneNumber from = "888 8";

            to = to.Replace("+", "");
            to = to.StartsWith("00") == true ? to.Remove(0, 2) : to;

            foreach (var item in TwilioConfig.TwilioFromNumberCountries)
            {
                if (to.StartsWith(item))
                {
                    isRestrictedCountry = true;
                    from = new Twilio.Types.PhoneNumber(TwilioConfig.TwilioNumber);
                    break;
                }
            }

            if (!to.StartsWith("+"))
            {
                to = "+" + to;
            }

            string fromText = "TransHome";

            if (!string.IsNullOrWhiteSpace(productCode))
            {
                fromText = productCode == "TRH" ? "TransHome" : "TalkHome";
                if (isOptionMessage == false)
                {
                    textMessage = productCode == "TRH" ? textMessage : textMessage.Replace("TransferHome", "Talk Home");
                }

            }

            string requestParameters = $"from : {(isRestrictedCountry ? from.ToString() : fromText)}, to: {to}, textMessage: {textMessage}";

            try
            {
                TwilioClient.Init(TwilioConfig.Sid, TwilioConfig.AuthToken);
                var message = await MessageResource.CreateAsync(body: textMessage, from: isRestrictedCountry ? from : fromText, to: new Twilio.Types.PhoneNumber(to));
                return;
            }
            catch (Exception ex)
            {
                _logger.Error($"DingPost_BL - Method: SendTwilioSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
                return;
            }
        }

        //private async Task SendTwilioSms(string to, string textMessage, string productCode = null, bool isOptionMessage = false)
        //{
        //    bool isRestrictedCountry = false;
        //    Twilio.Types.PhoneNumber from = "888 8";

        //    foreach (var item in TwilioConfig.TwilioFromNumberCountries)
        //    {
        //        if (to.StartsWith(item))
        //        {
        //            isRestrictedCountry = true;
        //            from = new Twilio.Types.PhoneNumber(TwilioConfig.TwilioNumber);
        //            break;
        //        }
        //    }

        //    if (!to.StartsWith("+"))
        //    {
        //        to = "+" + to;
        //    }           

        //    string fromText = "TransHome";

        //    if (!string.IsNullOrWhiteSpace(productCode))
        //    {
        //        fromText = productCode == "TRH" ? "TransHome" : "TalkHome";
        //        if(isOptionMessage == false)
        //        {
        //            textMessage = productCode == "TRH" ? textMessage : textMessage.Replace("TransferHome", "Talk Home");
        //        }

        //    }

        //    string requestParameters = $"from : {(isRestrictedCountry ? from.ToString() : fromText)}, to: {to}, textMessage: {textMessage}";

        //    try
        //    {
        //        TwilioClient.Init(TwilioConfig.Sid, TwilioConfig.AuthToken);
        //        var message = await MessageResource.CreateAsync(body: textMessage, from: isRestrictedCountry ? from : fromText, to: new Twilio.Types.PhoneNumber(to));
        //        return;
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Error($"ReloadlyPost - Method: SendTwilioSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
        //        return;
        //    }
        //}

    }
}
