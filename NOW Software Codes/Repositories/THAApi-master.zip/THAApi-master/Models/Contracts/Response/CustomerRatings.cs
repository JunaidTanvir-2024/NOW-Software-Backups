﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class CustomerRatings
    {
        public string RatingEvent { get; set; }
        public bool IsRatingRecordRequired { get; set; }
    }
}
