﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class TransferByNewCustomerRequestModel
    {
        [Required]
        [MaxLength(200)]
        public string nowtelRef { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int product { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int operatorId { get; set; }

        public PaymentCardModel cardData { get; set; }
        public BillingAddressModel billingAddressData { get; set; }
        
        [Required]
        public string ipAddress { get; set; }
    }

    public class PaymentCardModel
    {
        [Required(ErrorMessage = "Enter name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid Name")]
        public string NameOnCard { get; set; }

        [Required(ErrorMessage = "Enter card number")]
        [StringLength(maximumLength: 19, ErrorMessage = "Length must be between (16-19)", MinimumLength = 16)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string CardNumber { get; set; }

        [Required(ErrorMessage = "Select month")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string ExpiryMonth { get; set; }

        [Required(ErrorMessage = "Select year")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string ExpiryYear { get; set; }

        [Required(ErrorMessage = "Enter security code"), StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
        public string SecurityCode { get; set; }

        public bool ShouldSaveCard { get; set; }
    }

    public class BillingAddressModel
    {
        [Required(ErrorMessage = "Select country")]
        public string CountryCode { get; set; }

        [Required(ErrorMessage = "Enter address"), StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL1 { get; set; }

        [StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL2 { get; set; }

        [StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL3 { get; set; }

        [StringLength(maximumLength: 1000, ErrorMessage = "Maximum length exceeded")]
        public string AddressL4 { get; set; }

        [StringLength(maximumLength: 200, ErrorMessage = "Maximum length exceeded")]
        public string City { get; set; }

        [StringLength(maximumLength: 200, ErrorMessage = "Maximum length exceeded")]
        public string Region { get; set; }

        public string PostCode { get; set; }
    }
}
