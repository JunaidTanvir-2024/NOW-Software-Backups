﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models.ApiRequest.Users
{
    public class GetUserByIDRequetModel
    {
        public int UserID { get; set; }
    }
}