﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class MisdnVerificationRequest
    {
        public string PhoneNumber { get; set; }
    }
}
