﻿namespace Now.Models.Database;

    public class OrderData
    {
        public bool IsAppRequest { get; set; }
        public int CheckoutType { get; set; }
        public AutoTopupInfo? AutoTopupInfo { get; set; }
        public OrderBundleInfo? BundleInfo { get; set; }
        public long CreditSimOrderId { get; set; }
        public string? CardMaskedPan { get; set; }
        public string? CardScheme { get; set; }
        public string? Alias { get; set; }
    }
    public class OrderBundleInfo
    {
        public int BundleId { get; set; }
        public string? GoodyBagColorCode { get; set; }
        public bool IsRenewable { get; set; }
    }
    public class AutoTopupInfo
    {
        public float ThresHoldAmount { get; set; }
        public float TopupAmount { get; set; }
        public string CurrencySymbol { get; set; } = "£";
        public bool Status { get; set; }
        public string? PaymentMethod { get; set; }
    }


