﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class LocalAccessNumber
    {
        public string Number { get; set; }

        public string Description { get; set; }
    }

    public class AirtimeConfig
    {
        public bool isTopup { get; set; }

        public bool isDatabundle { get; set; }

        public int timeOut { get { return 90; } }
    }
}
