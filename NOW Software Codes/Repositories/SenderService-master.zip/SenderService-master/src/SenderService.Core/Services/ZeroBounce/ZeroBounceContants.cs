﻿namespace SenderService.Core.Services.ZeroBounce;

internal class ZeroBounceStatus
{
    public const string Valid = "valid";
    public const string Invalid = "invalid";
    public const string CatchAll = "catch-all";
    public const string Unknown = "unknown";
    public const string SpamTrap = "spamtrap";
    public const string Abuse = "abuse";
    public const string DoNotMail = "do_not_mail";
}
internal class ZeroBounceSubStatus
{
    public const string AliasAddress = "alias_address";
    public const string AntispamSystem = "antispam_system";
    public const string Greylisted = "greylisted";
    public const string MailServerTemporaryError = "mail_server_temporary_error";
    public const string ForcibleDisconnect = "forcible_disconnect";
    public const string MailServerDidNotRespond = "mail_server_did_not_respond";
    public const string TimeoutExceeded = "timeout_exceeded";
    public const string FailedSmtpConnection = "failed_smtp_connection";
    public const string MailboxQuotaExceeded = "mailbox_quota_exceeded";
    public const string ExceptionOccurred = "exception_occurred";
    public const string PossibleTrap = "possible_trap";
    public const string RoleBased = "role_based";
    public const string GlobalSuppression = "global_suppression";
    public const string MailboxNotFound = "mailbox_not_found";
    public const string NoDnsEntries = "no_dns_entries";
    public const string FailedSyntaxCheck = "failed_syntax_check";
    public const string PossibleTypo = "possible_typo";
    public const string UnroutableIpAddress = "unroutable_ip_address";
    public const string LeadingPeriodRemoved = "leading_period_removed";
    public const string DoesNotAcceptMail = "does_not_accept_mail";
    public const string RoleBasedCatchAll = "role_based_catch_all";
    public const string Disposable = "disposable";
    public const string Toxic = "toxic";
    public const string Alternate = "alternate";
}
