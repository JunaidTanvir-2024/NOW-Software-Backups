using FluentValidation;

using MM.Core.Common.Interfaces.Database;
using MM.Infrastructure.Common.Middlewares;
using MM.Infrastructure.Services.Email;
using MM.Infrastructure.Services.OpenApi;
using MM.Infrastructure.Services.SMS;

namespace MM.Infrastructure;

public static class ConfigureDependencies
{
    public static IServiceCollection AddInfrastructureDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.RegisterJsonSettings(configuration);
        services.RegisterBuiltInServices();
        services.RegisterCustomServices();
        services.AddApiVersioningConfiguration();
        services.AddOpenApiConfiguration();
        services.RegisterRepositories();
        return services;
    }
    private static IServiceCollection RegisterBuiltInServices(this IServiceCollection services)
    {
        services.AddHttpClient();
        services.AddHttpContextAccessor();
        return services;
    }
    private static IServiceCollection RegisterCustomServices(this IServiceCollection services)
    {
        services.AddScoped<ITimeWarpService, TimeWarpService>();
        services.AddScoped<IHttpService, HttpService>();
        services.AddScoped<ISMSService, SMSService>();


        return services;
    }
    private static IServiceCollection RegisterRepositories(this IServiceCollection services)
    {
        services.AddTransient<ILoggerRepository, LoggerRepository>();
        services.AddScoped<ISmsLogRepository, MessageLogRepository>();
        services.AddScoped<IEmailService, EmailService>();

        return services;
    }
    private static IServiceCollection RegisterJsonSettings(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<OpenApiSetting>(configuration.GetSection(OpenApiSetting.SectionName));
        services.Configure<SecurityHeaderSetting>(configuration.GetSection(SecurityHeaderSetting.SectionName));
        services.Configure<DTOneSetting>(configuration.GetSection(DTOneSetting.SectionName));
        services.Configure<SMSServiceSetting>(configuration.GetSection(SMSServiceSetting.SectionName));
        services.Configure<PhishingSetting>(configuration.GetSection(PhishingSetting.SectionName));
        services.Configure<MailSettings>(configuration.GetSection(MailSettings.SectionName));
        services.Configure<SmsMarketing>(configuration.GetSection(SmsMarketing.SectionName)); 

        return services;
    }
    public static IApplicationBuilder UseInfrastructureMiddlewares(this IApplicationBuilder app)
    {
        app.UseAppExceptionMiddleware();
        app.UseOpenApiConfiguration();
        app.UseSecurityHeadersMiddleware();
        app.UseAppLoggingMiddleware();
        return app;
    }
}
