using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Orders;

namespace Voucherify.Core.Services.VoucherifyApi.Models.StackableDiscounts;

public class StackableDiscountRollback
{
    [JsonPropertyName("rollbacks")]
    public Rollback[]? Rollbacks { get; set; }

    [JsonPropertyName("order")]
    public Order? Order { get; set; }
}