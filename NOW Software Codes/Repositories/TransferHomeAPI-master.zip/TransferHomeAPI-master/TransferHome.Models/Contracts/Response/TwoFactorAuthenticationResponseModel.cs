﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class TwoFactorAuthenticationResponseModel
    {
        public int TokenTypeId { get; set; }
    }
}
