﻿namespace Models.Configurations
{
    public class AccountDeleteSettings
    {
        public int SignUpAllowedAfterDays { get; set; }
        public int AccountDeletePeriodInDays { get; set; }
    }
}
