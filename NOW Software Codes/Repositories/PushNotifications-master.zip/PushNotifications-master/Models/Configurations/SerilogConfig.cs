﻿namespace Models.Configurations
{

    public class SerilogConfig
    {
        public string FilePath { get; set; }
    }
}
