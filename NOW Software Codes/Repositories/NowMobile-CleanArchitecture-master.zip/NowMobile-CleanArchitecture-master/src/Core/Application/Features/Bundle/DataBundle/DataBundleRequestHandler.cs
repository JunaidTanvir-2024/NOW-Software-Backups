using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.DataBundle;

public sealed class DataBundleRequestHandler : IRequestHandler<DataBundleRequest, Result<List<BundleInfo>>>
{
    #region Fields

    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<DataBundleRequestHandler> _localizer;
    private readonly ICommonService _commonService;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;
    private readonly IUserService _userService;

    public DataBundleRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<DataBundleRequestHandler> localizer,
        ICommonService commonService,
        IMapper mapper,
        ICurrentUser currentUser,
        IUserService userService)
    {
        _uow = uow;
        _localizer = localizer;
        _commonService = commonService;
        _mapper = mapper;
        _currentUser = currentUser;
        _userService = userService;
    }
    #endregion

    #region Methods
    public async Task<Result<List<BundleInfo>>> Handle(DataBundleRequest request, CancellationToken cancellationToken)
    {
        if (!string.IsNullOrEmpty(request.Msisdn))
        {
            request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        }

        if (_currentUser.IsAuthenticated() && !string.IsNullOrEmpty(request.Msisdn))
        {
            request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
            if (!await _userService.IsUserMsisdn(request.Msisdn))
            {
                return Result<List<BundleInfo>>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
            }
        }

        var bundles = _mapper.Map<List<BundleInfo>>(await _uow.BundleRepo.GetDataBundles(request));
        return Result<List<BundleInfo>>.Success(bundles, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}