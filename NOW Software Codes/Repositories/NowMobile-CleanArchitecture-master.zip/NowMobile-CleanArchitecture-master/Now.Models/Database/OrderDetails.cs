﻿using System;

namespace Now.Models.Database;

public class OrderDetails
{
    public int Id { get; set; }
    public string TransactionId { get; set; } = default!;
    public string Email { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
    public long UserId { get; set; }
    public int TransactionType { get; set; }
    public int PaymentMethodType { get; set; }
    public float Amount { get; set; }
    public float Discount { get; set; }
    public float TotalAmount { get; set; }
    public DateTime CreateDateTime { get; set; }
    public string? Firstname { get; set; }
    public string? Lastname { get; set; }
    public string? CustomerName { get; set; }
    public string? OrderData { get; set; }
}
