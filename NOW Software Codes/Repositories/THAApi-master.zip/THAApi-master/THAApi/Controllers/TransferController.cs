﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using Models.Contracts.Response;
using System;
using Serilog;
using System.Linq;
using System.Threading.Tasks;
using THAApi.Utilities;
using THAApi.ViewModels;
using Models.Enums;
using Infrastructure.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Localization;
using Newtonsoft.Json;
using Models.Contracts.Response.Voucherify;
using Infrastructure.BLL.Implementation;
using Models.Contracts.Request.Voucherify;

namespace THAApi.Controllers
{
    [ApiController]
    [Route("transfer")]
    public class TransferController : Controller
    {
        private readonly ILogger _logger;
        private readonly IATT_BL _attBl;
        private readonly IPayment_BL _paymentBl;
        private readonly IStringLocalizer _localizer;
        private readonly IHelper_BL _helper_BL;
        private readonly IUserAccount_BL _userAccount_BL;

        public TransferController(
            ILogger logger,
            IATT_BL aTT_BL,
            IPayment_BL paymentService,
            IStringLocalizer localizer,
            IHelper_BL helper_BL,
            IUserAccount_BL userAccount_BL)
        {
            _logger = logger;
            _attBl = aTT_BL;
            _paymentBl = paymentService;
            _localizer = localizer;
            _helper_BL = helper_BL;
            _userAccount_BL = userAccount_BL;
        }

        [HttpPost]
        [Route("Airtime/BeginTransaction")]
        public async Task<IActionResult> ATTBeginTransaction([FromBody] TransFerToTransactionNumbers request)
        {
            var destinationNumber = request.recipientNumber.StartsWith("00") ? request.recipientNumber.Substring(2) :
                request.recipientNumber.StartsWith("+") ? request.recipientNumber.Substring(1) :
                request.recipientNumber;

            var userMsisdn = User.Msisdn();
            var userAccount = await _userAccount_BL.GetUserAccountBalance(userMsisdn);

            string sendTopupDescription = await this.RenderViewAsync(Pages.SendTopup, userAccount, false);

            var products = await _attBl.GetProductsNew(userAccount, destinationNumber, userMsisdn, sendTopupDescription);
            return Ok(products);
        }

        [HttpPost]
        [Route("Airtime/DoTransfer")]
        public async Task<IActionResult> ATTDoTransfer([FromBody] TransFerTotransferConfirm request)
        {
            request.advertiserID = HttpContext.GetAdvertiserID();
            var executeRes = await _attBl.ExecuteTransactionByBalance(request, User.Msisdn());
            return Ok(executeRes);
        }

        [HttpPost]
        [Route("Airtime/TransactionList")]
        public async Task<IActionResult> TransactionsList([FromBody] TransferToTransactionsListRequest request)
        {
            var response = await _attBl.GetAttHistoryAsync(request, User.Account());
            return Ok(response);
        }

        [Route("TransferByPaypal")]
        [HttpPost]
        public async Task<IActionResult> TransferByPaypal([FromBody] TransferByPayPalRequestModel request)
        {
            string advertiserID = HttpContext.GetAdvertiserID();
            var response = await _paymentBl.TransferByPayPalAsync(
                request,
                User.Currency(),
                HttpContext.GetRemoteIPAddress(),
                User.Msisdn(),
                advertiserID);
            return Ok(response);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        [Route("TransferByPaypalReturnV2")]
        public async Task<IActionResult> TransferByPaypalReturn([FromQuery] TransferByPaypalCallBackRequestModel request)
        {
            try
            {
                HttpContext.Request.Headers["Msisdn"] = request.msisdn;
                var response = await _paymentBl.TransferByPayPalCallbackAsync(request);
                var productDetails = await _attBl.GetProductByNowtelTransactionReference(request.nowtelRef, request.product);
                if (response.ErrorCode > 0)
                {
                    return View(Pages.ErrorPage,
                            new ErrorViewModel()
                            {
                                PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal,
                                Type = CheckOutTypes.Transfer,
                                Origination = _helper_BL.GetCountryCode(request.msisdn),
                                Message = response.Message,
                                ThemeMode = request.ThemeMode,
                            });
                }
                var model = new SuccessViewModel()
                {
                    Type = SuccessViewModel.CheckoutType.InternationalTopup,
                    ThemeMode = request.ThemeMode,
                    Origination = _helper_BL.GetCountryCode(request.msisdn),
                    InternationalTopupInfo =
                            new SuccessViewModel.InternationalTopup
                            {
                                Amount = response.Payload.TopupAmount,
                                PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal,
                                Currency = response.Payload.Currency,
                                Destination = _helper_BL.GetCountryCode(productDetails.tomsisdn),
                                IsTransferRequest = request.IsTransferRequest
                            },

                };
                return View(Pages.SuccessPage, model);
            }
            catch (Exception ex)
            {
                _logger.Error(
                    $"Controller: ATTController, " +
                    $"Method: TransferByPaypalReturnV2 , " +
                    $"Request: {JsonConvert.SerializeObject(request)} , " +
                    $"ErrorMessage: {ex.Message}, " +
                    $"StackTrace: {ex.StackTrace}");

                return View(Pages.ErrorPage,
                    new ErrorViewModel()
                    {
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal,
                        Type = CheckOutTypes.Transfer,
                        Origination = _helper_BL.GetCountryCode(request.msisdn),
                        Message = _localizer["SomethingWentWrong"],
                        ThemeMode = request.ThemeMode,
                    });
            }
        }

        [AllowAnonymous]
        [Route("TransferByPaypalCancelV2"), HttpGet]
        public IActionResult TransferByPaypalCancelV2([FromQuery] ThemeMode themeMode)
        {
            return View(Pages.ErrorPage, new ErrorViewModel()
            {
                Message = _localizer["PaymentError"],
                ThemeMode = themeMode,
                Type = CheckOutTypes.Transfer,
                PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal
            });
        }

        [Route("TransferByNewCustomer")]
        [HttpPost]
        public async Task<IActionResult> TransferByNewCustomer([FromBody] TransferByNewCustomerRequestModel request)
        {
            try
            {
                string advertiserID = HttpContext.GetAdvertiserID();
                var response = await _paymentBl.TransferByNewCardAsync(
                    request,
                    User.Currency(),
                    HttpContext.GetRemoteIPAddress(),
                    User.Msisdn(),
                    User.Email(),
                    advertiserID);

                if (response.ErrorCode == 0)
                {
                    var successModel = new SuccessViewModel()
                    {
                        Type = SuccessViewModel.CheckoutType.InternationalTopup,
                        ThemeMode = HttpContext.ThemeMode(),
                        Origination = _helper_BL.GetCountryCode(User.Msisdn()),
                        CustomerMsisdn = User.Msisdn(),
                        InternationalTopupInfo = new SuccessViewModel.InternationalTopup
                        {
                            PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                            Amount = response.Payload.intTopupInfo.TopupAmount,
                            Currency = response.Payload.intTopupInfo.Currency,
                            Destination = _helper_BL.GetCountryCode(response.Payload.transferData?.toMsisdn),
                            IsTransferRequest = request.IsTransferRequest
                        },
                    };
                    var successView = await this.RenderViewAsync(Pages.SuccessPage, successModel);
                    return Ok(GenericApiResponse<object>.Success(new { html = successView }, response.Message));
                }

                if (response.ErrorCode == (int)ApiStatusCodes.Pending3dSecure)
                {
                    if (response.Payload.threeDSecureData.type.Contains("V2", StringComparison.InvariantCultureIgnoreCase))
                    {
                        var model = new Resume3DV2ViewModel()
                        {
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                            ThreeDSServerTransId = response.Payload.threeDSecureData.threeDSServerTransId,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                        };
                        model.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        model.ReturnUrl += $"&advertiserID={advertiserID}";
                        var Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV2Page, model);
                        return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, "success"));
                    }
                    else
                    {
                        var model = new Resume3DV1ViewModel();

                        model.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        model.ReturnUrl += $"&advertiserID={advertiserID}";
                        var Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV1Page, model);
                        return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, "success"));
                    }
                }
                else
                {
                    return Ok(GenericApiResponse<object>.Failure(response.Message, ApiStatusCodes.PaymentServiceError));
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: ATTController, " +
                              $"Method: TransferByNewCustomer, " +
                              $"Request:{JsonConvert.SerializeObject(request)}, " +
                              $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}," +
                              $"StackTrace: {ex.StackTrace}");

                var resp = GenericApiResponse<object>.Failure(
                    null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

                return Ok(resp);
            }
        }

        [Route("TransferByExistingCustomer")]
        [HttpPost]
        public async Task<IActionResult> TransferByExistingCustomer([FromBody] TransferByExistingCustomerRequestModel request)
        {
            try
            {
                string advertiserID = HttpContext.GetAdvertiserID();
                var response = await _paymentBl.TransferByExistingCardAsync(
                    request,
                    User.Currency(),
                    HttpContext.GetRemoteIPAddress(),
                    User.Msisdn(),
                    User.Email(),
                    advertiserID);

                if (response.ErrorCode == 0)
                {
                    var successModel = new SuccessViewModel()
                    {
                        Type = SuccessViewModel.CheckoutType.InternationalTopup,
                        ThemeMode = HttpContext.ThemeMode(),
                        Origination = _helper_BL.GetCountryCode(User.Msisdn()),
                        CustomerMsisdn = User.Msisdn(),
                        InternationalTopupInfo = new SuccessViewModel.InternationalTopup
                        {
                            PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                            Amount = response.Payload.intTopupInfo.TopupAmount,
                            Currency = response.Payload.intTopupInfo.Currency,
                            Destination = _helper_BL.GetCountryCode(response.Payload.transferData?.toMsisdn),
                            IsTransferRequest = request.IsTransferRequest
                        },
                    };
                    var successView = await this.RenderViewAsync(Pages.SuccessPage, successModel);
                    return Ok(GenericApiResponse<object>.Success(new { html = successView }, response.Message));
                }

                if (response.ErrorCode == (int)ApiStatusCodes.Pending3dSecure)
                {
                    if (response.Payload.threeDSecureData.type.Contains("V2", StringComparison.InvariantCultureIgnoreCase))
                    {
                        var model = new Resume3DV2ViewModel()
                        {
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                            ThreeDSServerTransId = response.Payload.threeDSecureData.threeDSServerTransId,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                        };
                        model.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        model.ReturnUrl += $"&advertiserID={advertiserID}";
                        var Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV2Page, model);
                        return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, "success"));
                    }
                    else
                    {
                        var model = new Resume3DV1ViewModel()
                        {
                            Pareq = response.Payload.threeDSecureData.pareq,
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                        };
                        model.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        model.ReturnUrl += $"&advertiserID={advertiserID}";
                        var Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV1Page, model);
                        return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, "success"));
                    }
                }
                else
                {
                    return Ok(GenericApiResponse<object>.Failure(response.Message, ApiStatusCodes.Pay360Error));
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: ATTController, " +
                              $"Method: TransferByExistingCustomer, " +
                              $"Request:{JsonConvert.SerializeObject(request)}, " +
                              $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}," +
                              $"StackTrace: {ex.StackTrace}");

                var resp = GenericApiResponse<object>.Failure(
                    null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

                return Ok(resp);
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        [Route("Resume3DTransaction")]
        public async Task<IActionResult> Resume3DTransaction([FromForm] Resume3DPaymentRequest request,
                                                             [FromQuery] TransferByPay360Resume3DData data)
        {
            try
            {
                HttpContext.Request.Headers["AirshipEventsDisable"] = data.AirshipEventsDisable?"1":"0";
                HttpContext.Request.Headers["Msisdn"] = data.msisdn;

                var response = await _paymentBl.TransferByCardResume3DTransactionCallbackAsync(data, request);
                if (response.ErrorCode == 0)
                {
                    var product = await _attBl.GetProductByNowtelTransactionReference(data.nowtelRef, data.product);
                    return View(Pages.SuccessPage, new SuccessViewModel()
                    {
                        ThemeMode = data.ThemeMode,
                        Origination = _helper_BL.GetCountryCode(data.msisdn),
                        Type = SuccessViewModel.CheckoutType.InternationalTopup,
                        CustomerMsisdn = data.msisdn,
                        InternationalTopupInfo = new SuccessViewModel.InternationalTopup
                        {
                            PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                            Amount = response.Payload.TopupAmount,
                            Currency = response.Payload.Currency,
                            Destination = _helper_BL.GetCountryCode(product.tomsisdn),
                            IsTransferRequest = data.IsTransferRequest
                        },
                    });
                }
                else
                {
                    return View(Pages.ErrorPage, new ErrorViewModel()
                    {
                        Message = response.Message,
                        ThemeMode = data.ThemeMode,
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                        Type = CheckOutTypes.Transfer,
                        Origination = _helper_BL.GetCountryCode(data.msisdn),
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: ATTController, " +
                              $"Method: Resume3DTransaction, " +
                              $"Request:{JsonConvert.SerializeObject(request)}, " +
                              $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}," +
                              $"StackTrace: {ex.StackTrace}");

                return View(Pages.ErrorPage,
                    new ErrorViewModel()
                    {
                        Message = _localizer["SomethingWentWrong"],
                        ThemeMode = data.ThemeMode,
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                        Type = CheckOutTypes.TopUp,
                        Origination = _helper_BL.GetCountryCode(data.msisdn)
                    });
            }
        }
    }
}
