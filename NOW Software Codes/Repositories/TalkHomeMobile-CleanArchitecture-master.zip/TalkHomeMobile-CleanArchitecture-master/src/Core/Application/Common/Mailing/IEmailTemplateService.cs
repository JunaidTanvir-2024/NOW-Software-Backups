﻿using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Mailing;

public interface IEmailTemplateService : IServicesType.ITransientService
{
    string GenerateEmailTemplate<T>(string templateName, T mailTemplateModel);
}
