using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MM.Core.Common.Definitions.Enums;

namespace MM.Core.Common.DTOs;
public class SendEmailRequestDTO
{
    public string? To { get; set; }
    public string? EmailBody { get; set; }
    public string? ProductCode { get; set; }
    public string? Subject { get; set; }
}
