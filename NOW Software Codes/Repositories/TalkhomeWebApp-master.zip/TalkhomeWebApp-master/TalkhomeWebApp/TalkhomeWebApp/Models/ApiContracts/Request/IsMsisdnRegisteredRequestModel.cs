﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class IsMsisdnRegisteredRequestModel
    {
        public string Msisdn { get; set; }
    }
}
