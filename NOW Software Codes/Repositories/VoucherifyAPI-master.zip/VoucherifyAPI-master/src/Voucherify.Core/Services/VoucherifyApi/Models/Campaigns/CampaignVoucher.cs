using System.Text.Json.Serialization;

using Voucherify.Core.Commons.Converters;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Redemptions;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Campaigns;

public class CampaignVoucher
{
    [JsonPropertyName("code_config")]
    public CodeConfig? CodeConfig { get; set; }

    [JsonPropertyName("type")]
    [JsonConverter(typeof(EnumConverter<VoucherType>))]
    public VoucherType? Type { get; set; }

    [JsonPropertyName("category")]
    public string? Category { get; set; }

    [JsonPropertyName("discount")]
    public Discount? Discount { get; set; }

    [JsonPropertyName("gift")]
    public Gift? Gift { get; set; }

    [JsonPropertyName("redemption")]
    public RedemptionQuantity? Redemption { get; set; }
}
