﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    
    public class Sms
    {
        public long Id { get; set; }

        public Provider Provider { get; set; }

        public string ProviderId { get; set; }

        public Status Status { get; set; }

        public string Sender { get; set; }

        public string To { get; set; }

        public string ProviderError { get; set; }

        public DateTime Sent { get; set; }
    }

    public class QueuedSms
    {
        public long Id { get; set; }

        public string From { get; set; }

        public string Destination { get; set; }

        public string Message { get; set; }
        public bool Paid { get; set; }
    }

    public class SmsResult
    {
        public SmsResult() { }

        public bool Success { get; private set; }

        public string Contact { get; private set; }

        public SmsErrorCode ErrorCode { get; private set; }

        public string ErrorMessage { get; private set; }

        public static SmsResult Ok(string contact)
        {
            return new SmsResult
            {
                Success = true,
                Contact = contact
            };
        }

        public static SmsResult Error(string contact, SmsErrorCode errorCode)
        {
            return new SmsResult
            {
                Success = false,
                ErrorCode = errorCode,
                Contact = contact
            };
        }

        public static SmsResult Error(string contact, SmsErrorCode errorCode, string errorMessage)
        {
            return new SmsResult
            {
                Success = false,
                ErrorCode = errorCode,
                ErrorMessage = errorMessage,
                Contact = contact
            };
        }
    }
    public enum SmsErrorCode
    {
        Unknown,
        InsufficentBalance,
        UnableToCharge,
        ProviderError,
        ProviderFailure,
        MessageTooLong,
        Exception
    }
    public enum Provider
    {
        FortyTwo,
        ClxNetWorks,
        Twilio,
        MGage,
        Xeebi,
        SAP,
        Hsl
    }
    public enum Status
    {
        Delivered,
        Failed,
        Pending,
        Error
    }
}
