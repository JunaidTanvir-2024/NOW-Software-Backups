﻿//$("#addproductform").validate({
//    rules: {
//        cardnumber: {
//            required: true
//        },
//        pinnumber: {
//            required: true
//        }
//    },
//    messages: {
//        cardnumber: {
//            required: "Please provide Talk Home rechargeable calling card number"
//        },
//        pinnumber: {
//            required: "Please provide pind sent to you"
//        },
//    },
//});


$("#addproduct").on("click", function (event) {
    //event.preventDefault();
    if (!$("#addproductform").valid()) {
        return false;
    }

    var model = {};
    model.cardnumber = $("#cardnumber").val();
    model.pinnumber = $("#pinnumber").val();
    $.ajax({
        beforeSend: function () {
            loader.btnloadershow(event)
        },
        type: "POST",
        url: "/addproduct",
        data: model,
        success: function (json) {
            if (json && json.errorCode != 0 && json.errorCode != 976 && json.errorCode != 977) {
                $("#ErrorDiv").text(json.key)
            }
            else if (json.errorCode == 976) {
                $("#ErrorDiv").text("Invalid card Number or Pin")
            }
            else if (json.errorCode == 977) {
                $("#ErrorDiv").text("Product addition failed! Product is already attached")
            }

            else if (json && json.errorCode == 0) {
                THCC_AirShip.AddTag(
                    THCC_AirShip.Tags.names.thrcc_card_connected,
                    THCC_AirShip.Tags.types.customer,
                    true,
                    () => {
                        window.location.href = "/account/myaccount";
                    });
                    
                }

            
        },
        error: function (xhr, status, error) {
            $("#ErrorDiv").text("Invalid cardnumber or pin ");
        },
        complete: function () {
            loader.btnloaderhide(event)
        }
    });
});