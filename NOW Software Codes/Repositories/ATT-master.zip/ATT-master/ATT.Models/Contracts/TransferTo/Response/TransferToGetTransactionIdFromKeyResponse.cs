﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransferToGetTransactionIdFromKeyResponse
    {
        public string authentication_key { get; set; }
        public string error_code { get; set; }
        public string error_txt { get; set; }        
        public string id { get; set; }
    }
}
