﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TH.Models.Database
{
    public class User
    {
        public int Id { get; set; }
        public int company_id { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }
}
