﻿
namespace Application.Common.Models;
public class SocialLogin
{
    public string AccessToken { get; set; } = default!;
    public SocialLoginType SocialLoginType { get; set; }
}
