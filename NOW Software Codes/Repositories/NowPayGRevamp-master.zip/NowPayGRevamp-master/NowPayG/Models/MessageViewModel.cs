using NowPayG.Models.ViewModels;
using System;

namespace NowPayG.Models
{
    public class MessageViewModel : BaseViewModel
    {
        public string Heading { get; set; }
        public string Message { get; set; }
    }
}