using Microsoft.AspNetCore.Builder;

namespace JM.Infrastructure.Common.Middlewares;
public static class MiddlewareExtensions
{
    public static IApplicationBuilder UseAppLoggingMiddleware(this IApplicationBuilder app)
    {
        return app.UseMiddleware<ConfigureAppLogging.Middleware>();
    }
    public static IApplicationBuilder UseAppExceptionMiddleware(this IApplicationBuilder app)
    {
        return app.UseMiddleware<ConfigureGlobalException.Middleware>();
    }
    public static IApplicationBuilder UseSecurityHeadersMiddleware(this IApplicationBuilder app)
    {
        return app.UseMiddleware<ConfigureSecurityHeader.Middleware>();
    }
}
