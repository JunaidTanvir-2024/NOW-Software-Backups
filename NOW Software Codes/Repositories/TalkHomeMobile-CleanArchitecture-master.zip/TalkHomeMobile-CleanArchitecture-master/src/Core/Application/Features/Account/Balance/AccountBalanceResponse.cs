namespace Application.Features.Account.Balance;

public class AccountBalanceResponse
{
    public int Id { get; set; }
    public string? Msisdn { get; set; }
    public float Balance { get; set; }
    public string CurrencySymbol { get; set; } = Common.Models.CurrencySymbol.GBP;
}