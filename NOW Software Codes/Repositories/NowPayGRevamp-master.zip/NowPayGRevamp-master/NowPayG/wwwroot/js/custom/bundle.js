﻿function ShowIPCountryWise_Bundle(CountryDropdown) {

    var CountryID = $(CountryDropdown).val();

    if (CountryID != undefined && CountryID != "") {
        $('.sec_InternationalPlans').hide();
        $('.sec_InternationalPlans_' + CountryID).show();
    }
    else {
        $('.sec_InternationalPlans').show();
    }

}

function BuyPlan_home(current) {

    $('#SelectedPlan_Id').val(current.dataset.id);
    $('#BundleBuyForm').submit();

}



