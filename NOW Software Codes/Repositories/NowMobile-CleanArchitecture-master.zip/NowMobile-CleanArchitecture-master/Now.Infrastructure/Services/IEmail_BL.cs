﻿using Now.Models.Enums;

namespace Now.Infrastructure.Services;

    public interface IEmail_BL : ISerivcesType.ITransientService
{
        Task<bool> SendFullfillmentEmail(string customerEmail, string Message, bool IsHtmlBody, string subject = null);
        Task<bool> SendWhyAndBenefitsEmail(string customerEmail, SimOrderType simOrderType);
        Task<bool> SendNotActivatedSimEmail(string customerEmail, SimOrderType simOrderType);
        Task<bool> SendOtherServicesEmail(string customerEmail, SimOrderType simOrderType);
        Task<bool> SendSocialMediaEmails(string customerEmail, SimOrderType simOrderType);
        Task<bool> SendNotToppedUpEmail(string customerEmail, SimOrderType simOrderType);
    }

