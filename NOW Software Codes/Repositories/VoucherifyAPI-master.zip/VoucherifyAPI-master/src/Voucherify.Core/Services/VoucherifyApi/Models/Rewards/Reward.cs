using System.Text.Json.Serialization;

using Voucherify.Core.Commons.Converters;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Rewards;

public class Reward : BaseObject
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("type")]
    [JsonConverter(typeof(EnumConverter<RewardType>))]
    public RewardType? Type { get; set; }

    [JsonPropertyName("parameters")]
    public RewardParameters? Parameters { get; set; }

    [JsonPropertyName("stock")]
    public string? Stock { get; set; }

    [JsonPropertyName("redeemed")]
    public string? Redeemed { get; set; }

    [JsonPropertyName("attributes")]
    public Metadata? Attributes { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}
