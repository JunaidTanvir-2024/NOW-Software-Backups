﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.AppsFlyer
{
    public class SetCustomerIdRequestModel
    {
        public string customerUserId { get; set; }
        public string afUserId { get; set; }
        public string productCode { get; set; } = "THA-WEB-API";
    }
}
