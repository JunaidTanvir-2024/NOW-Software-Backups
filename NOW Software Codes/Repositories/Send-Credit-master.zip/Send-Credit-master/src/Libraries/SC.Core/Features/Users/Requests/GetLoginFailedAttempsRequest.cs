﻿namespace SC.Core.Features.Users.Requests;
public class GetLoginFailedAttempsRequest : IRequest<IResultWrapper>
{
    public string UserID { get; set; } = default!;
    public DateTime ConsecutivePeriod { get; set; } = default!;
}
public class GetLoginFailedAttempsRequestValidator : AbstractValidator<GetLoginFailedAttempsRequest>
{
    public GetLoginFailedAttempsRequestValidator()
    {
        RuleFor(x => x.UserID).NotNull();
        RuleFor(x => x.ConsecutivePeriod).NotNull();
    }
}

