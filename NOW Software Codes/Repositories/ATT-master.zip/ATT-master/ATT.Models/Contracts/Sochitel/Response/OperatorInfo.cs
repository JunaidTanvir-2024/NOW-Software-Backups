﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Response
{
    public class OperatorInfo
    {
        public int id { get; set; }             //Operator ID
        public string name { get; set; }        //Operator Name
        public string reference { get; set; }   //Operator’s transaction reference (available only if the remote operator is assigning a reference ID to the transaction)
    }
}
