﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NowPayG.Configurations;
using NowPayG.Models;
using NowPayG.Models.ApiContracts.Response;
using NowPayG.Models.ViewModels;
using NowPayG.Resources;
using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using NowPayG.Models.ApiContracts.Request;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Serilog;
using Newtonsoft.Json;
using NowPayG.Models.Porting;
using NowPayG.Services.Interfaces;
using PhoneNumbers;
using NowPayG.Models.Pay360ApiContracts;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace NowPayG.Controllers
{
    public class HomeController : Controller
    {
        private readonly string NowPayGApiEndPoint;
        private readonly ILogger Logger;
        private readonly IPortService PortService;
        private readonly IPay360Service Pay360Service;

        public HomeController(IOptions<EndPoints> endPoints, ILogger logger, IPortService portService, IPay360Service pay360Service)
        {
            NowPayGApiEndPoint = endPoints.Value.NowPaygApiEndPoint;
            Logger = logger;
            PortService = portService;
            Pay360Service = pay360Service;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            try
            {
                HomeViewModel model = new HomeViewModel();
                await model.SetSharedDataAsync(User);

                var Plan = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);
                if (Plan != null)
                {
                    if (Plan is Error)
                    {
                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        PlansResponseModel Plans = Plan.GetValue("payload").ToObject<PlansResponseModel>();
                        model.Plans = Plans;
                    }
                }

                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: Index, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllCountries()
        {
            try
            {
                var response = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetCountries", User, null, true);

                if (response != null)
                {
                    if (response is Error)
                    {
                        if ((response as Error).ErrorCode == (int)ApiStatusCodes.NoCountryFound)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.NoCountryFound, status = false, message = MessagesResource.ResourceManager.GetString(Messages.NoCountryFound.ToString()) });
                        }
                        else
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                        }
                    }
                    else
                    {
                        var CountrieslList = response.GetValue("payload").ToObject<CountriesResponseModel>();
                        return Json(new { errorCode = 0, status = true, message = string.Empty, Data = CountrieslList });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: GetAllCountries, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetInternationalRates()
        {
            try
            {
                var response = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllInternationalRates", User, null, true);

                if (response != null)
                {
                    if (response is Error)
                    {
                        if ((response as Error).ErrorCode == (int)ApiStatusCodes.NoInternationalRatesFound)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.NoInternationalRatesFound, status = false, message = MessagesResource.ResourceManager.GetString(Messages.NoInternationalRatesFound.ToString()) });
                        }
                        else
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                        }
                    }
                    else
                    {
                        var InternationalRatesList = response.GetValue("payload").ToObject<InternationalRatesResponseModel>();
                        return Json(new { errorCode = 0, status = true, message = string.Empty, Data = InternationalRatesList });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: GetInternationalRates, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllUKRates()
        {
            try
            {
                var response = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllUKRates", User, null, true);

                if (response != null)
                {
                    if (response is Error)
                    {
                        if ((response as Error).ErrorCode == (int)ApiStatusCodes.NoUKRatesFound)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.NoUKRatesFound, status = false, message = MessagesResource.ResourceManager.GetString(Messages.NoUKRatesFound.ToString()) });
                        }
                        else
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                        }
                    }
                    else
                    {
                        var UkRatesList = response.GetValue("payload").ToObject<UKRatesResponseModel>();
                        return Json(new { errorCode = 0, status = true, message = string.Empty, Data = UkRatesList });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: GetAllUKRates, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetRoamingRates(int FromCountryId, int ToCountryId)
        {
            try
            {
                if (FromCountryId > 0 && ToCountryId > 0)
                {
                    var response = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetRoamingRates", User, null, true, parameters: new string[] { "FromCountryId=" + FromCountryId + "", "ToCountryId=" + ToCountryId });

                    if (response != null)
                    {
                        if (response is Error)
                        {
                            if ((response as Error).ErrorCode == (int)ApiStatusCodes.DBError)
                            {
                                return Json(new { errorCode = (int)ApiStatusCodes.DBError, status = false, message = MessagesResource.ResourceManager.GetString(Messages.NoRoamingRatesFound.ToString()) });
                            }
                            else
                            {
                                return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                            }
                        }
                        else
                        {
                            var RoamingRates = response.GetValue("payload").ToObject<RoamingRatesResponseModel>();
                            return Json(new { errorCode = 0, status = true, message = string.Empty, Data = RoamingRates });
                        }
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server");
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest, "Invalid Parameters");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: GetAllRoamingRates, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllPlans()
        {
            try
            {
                var response = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);

                if (response != null)
                {
                    if (response is Error)
                    {
                        if ((response as Error).ErrorCode == (int)ApiStatusCodes.NoPlanFound)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.NoPlanFound, status = false, message = MessagesResource.ResourceManager.GetString(Messages.NoPlanFound.ToString()) });
                        }
                        else
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                        }
                    }
                    else
                    {
                        var PlansList = response.GetValue("payload").ToObject<PlansResponseModel>();
                        return Json(new { errorCode = 0, status = true, message = string.Empty, Data = PlansList });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: GetAllPlans, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> SimOrder(SimOrderViewModel model)
        {
            try
            {
                if (model.IsUserExist)
                {
                    ModelState.Remove("model.UserPassword");
                    ModelState.Remove("model.UserConfirmPassword");
                }

                if (!model.IsPortIn)
                {
                    ModelState.Remove("model.PortMsisdn");
                    ModelState.Remove("model.Code");
                }

                ModelState.Remove("model.PostCode");

                if (ModelState.IsValid)
                {

                    if( model.otp != null)
                    {
                        ////ReCheck Sim Order Validations 
                        
                        VerifyUserSimOrderRequestModel VerifyUserSimOrdermodel = new VerifyUserSimOrderRequestModel();
                        VerifyUserSimOrdermodel.Address = model.AddressL1;
                        VerifyUserSimOrdermodel.PostCode = model.PostCode;
                        VerifyUserSimOrdermodel.Email = model.UserEmail;

                        
                        int EmailValidationresponsecode = await ValidateuserEmail(VerifyUserSimOrdermodel);

                        if (EmailValidationresponsecode == 0)
                        {
                            //verify otp
                            VerifyotpRequestModel otpmodel = new VerifyotpRequestModel();
                            otpmodel.Email = model.UserEmail;
                            otpmodel.Otpcode = model.otp;

                            var obj = await Api.CallApi(NowPayGApiEndPoint + "Admin/Verifyotp", User, otpmodel);
                            var result = obj.GetValue("payload").ToObject<int>();

                            if (obj != null)
                            {
                                if (obj is Error)
                                { return StatusCode((int)HttpStatusCode.InternalServerError, (obj as Error).ErrorMessage); }
                                else
                                {
                                    if (result != 1)
                                    {
                                        return Json(new { otpValidation = false });
                                    }
                                }
                            }
                            else
                            {
                                return StatusCode((int)HttpStatusCode.InternalServerError, (obj as Error).ErrorMessage);
                            }
                        }
                        else
                        {
                            if (EmailValidationresponsecode == 4 || EmailValidationresponsecode == 5)
                            {
                                return Json(new { isValid = false, errorcode = EmailValidationresponsecode, errormessage = MessagesResource.MonthlySimOrderValidation });
                            }
                            if (EmailValidationresponsecode == 1 || EmailValidationresponsecode == 2 || EmailValidationresponsecode == 3)
                            {
                                return Json(new { isValid = false, errorcode = EmailValidationresponsecode, errormessage = MessagesResource.AccountSimOrderValidation });
                            }
                        }
                    }



                    if (model.otp == null)
                    {

                        VerifyUserSimOrderRequestModel VerifyUserSimOrdermodel = new VerifyUserSimOrderRequestModel();
                        VerifyUserSimOrdermodel.Address = model.AddressL1;
                        VerifyUserSimOrdermodel.PostCode = model.PostCode;
                        VerifyUserSimOrdermodel.Email = model.UserEmail;

                        ////Check Sim Order Validations 
                        int x = await ValidateuserEmail(VerifyUserSimOrdermodel);

                        if ( x == 4 || x == 5)
                        {
                            return Json(new { isValid = false, errorcode = x, errormessage = MessagesResource.MonthlySimOrderValidation });
                        }
                        if (x == 1 || x == 2 || x == 3)
                        {
                            return Json(new { isValid = false, errorcode = x, errormessage = MessagesResource.AccountSimOrderValidation });
                        }


                      
                        int otp = GenerateRandomNo();
                        InsertotpRequestModel otpmodel = new InsertotpRequestModel();
                        otpmodel.Email = model.UserEmail;
                        otpmodel.otpcode = otp;

                        ///Check is user exists
                        IsUserExistRequestModel IsUserExistmodel = new IsUserExistRequestModel()
                        {
                            Email = model.UserEmail,
                        };

                        var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/IsUserExist", User, IsUserExistmodel);

                        var objIsUserVerified = await Api.CallApi(NowPayGApiEndPoint + "Admin/IsverifiedUser", User, IsUserExistmodel);
                        var resultIsUserVerified = objIsUserVerified.GetValue("payload").ToObject<int>();
                        bool isuserexist = true;

                        if (objUser is Error)
                        {
                            if ((objUser as Error).ErrorCode != (int)ApiStatusCodes.UserNotFound)
                            {
                                return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                            }
                            if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.UserNotFound)
                            {
                                isuserexist = false;
                            }
                        }
                        if (isuserexist == false && resultIsUserVerified == 2)
                        {
                            var insertotp_response = await Api.CallApi(NowPayGApiEndPoint + "Admin/Insertotp", User, otpmodel);

                            if (insertotp_response is Error)
                            {
                                return StatusCode((int)HttpStatusCode.InternalServerError, (insertotp_response as Error).ErrorMessage);
                            }
                            else
                            {
                                return Json(new { isValid = true, regsitered = false, confirmed = false });
                            }

                        }
                        if (isuserexist == true && resultIsUserVerified == 2)
                        {
                            var insertotp_response = await Api.CallApi(NowPayGApiEndPoint + "Admin/Insertotp", User, otpmodel);

                            if (insertotp_response is Error)
                            {
                                return StatusCode((int)HttpStatusCode.InternalServerError, (insertotp_response as Error).ErrorMessage);
                            }
                            else
                            {
                                return Json(new { isValid = true, regsitered = true, confirmed = false });
                            }

                        }

                        //Create Sim Order
                        //return Json(new { isValid = true, regsitered = true, confirmed = true });
                    }
                    var request = new SaveUserSimOrderRequestModel() { };

                    request.UserAddressInfo = new UserAddressRequestModel()
                    {
                        AddressLine1 = model.AddressL1,
                        AddressLine2 = model.AddressL2,
                        AddressType = AddressTypes.simOrder,
                        City = model.City,
                        County = model.County,
                        CountryId = model.CountryId,
                        PostCode = model.PostCode
                    };

                    request.UserSimInfo = new UserSIMOrderRequestModel()
                    {
                        Product = ProductType.NowPayG,
                        IsReplacement = model.IsReplace
                    };

                    request.UserInfo = new RegisterUserRequestModel()
                    {
                        CountryId = model.CountryId,
                        Email = model.UserEmail,
                        FirstName = model.UserFirstName,
                        LastName = model.UserLastName,
                        Password = model.UserPassword,
                        MailSubscription = model.MailSubscription
                    };

                    var response = await Api.CallApi(NowPayGApiEndPoint + "User/FreeSimOrder", User, request);
                    if (response != null)
                    {
                        if (response is Error)
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                        }
                        else
                        {
                            var payload = response.GetValue("payload").ToObject<int>();

                            if (payload > 0)
                            {
                                if (model.IsPortIn)
                                {
                                    var phoneNumberUtil = PhoneNumbers.PhoneNumberUtil.GetInstance();
                                    model.PortMsisdn = phoneNumberUtil.Format(phoneNumberUtil.Parse(model.PortMsisdn, "GB"), PhoneNumberFormat.E164).Replace("+", "").Trim();

                                    PortInRequestModel port = new PortInRequestModel
                                    {
                                        Email = model.UserEmail,
                                        Code = model.Code,
                                        PortMsisdn = model.PortMsisdn,
                                        OrderRefId = payload
                                    };

                                    var portInResponse = await PortService.PortIn(port, PortTypes.PortInNew);

                                    if (portInResponse != null && portInResponse.errorCode == 0)
                                    {
                                        return Json(new { errorCode = 0, status = true, message = string.Empty, Data = payload });
                                    }
                                    else
                                    {
                                        return Json(new { errorCode = 0, status = true, message = "Sim Order placed successfully but Port-In request failed.", Data = 0 });
                                    }
                                }
                                return Json(new { errorCode = 0, status = true, message = string.Empty, Data = payload });
                            }
                            else
                            {
                                return Json(new { errorCode = 0, status = true, message = "Sim Order placed successfully.", Data = payload });
                            }
                        }
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: OrderSim, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        public async Task<int> ValidateuserEmail(VerifyUserSimOrderRequestModel model)
        {
            //Check Sim Order Validations            
            var SimOrderValidations = await Api.CallApi(NowPayGApiEndPoint + "Admin/VerifyUserSimOrder", User, model);
            if (SimOrderValidations != null)
            {
                if (SimOrderValidations is Error)
                {
                    return 6;
                }
                else
                {
                    var result = SimOrderValidations.GetValue("payload").ToObject<int>();
                    return result;                    
                }
            }
            else
            {
                return 6;
            }
        }


       [HttpGet]
        [AllowAnonymous]
        [Route("successful-SimOrder/{id}")]
        public async Task<IActionResult> SuccessfulSimOrder(int id)
        {
            await Global.BaseModel.SetSharedDataAsync(User);

            if (id > 0)
            {
                ViewBag.HeadMsg = "Your order has been successful!";
                ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.ExistingUserSimOrder.ToString());
            }
            else
            {
                ViewBag.HeadMsg = "SIM Order & Registration have been successful!";
                ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.NewUserSimOrder.ToString());
            }

            return View(@"~/Views/Account/SuccessfulRegister.cshtml", Global.BaseModel);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ValidateOrderSimEmail(string Email)
        {
            try
            {
                var userresponse = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetNumberOfSimOrdersByEmail", User, null, true, false, null, new string[1] { "Email=" + Email });
                if (userresponse != null)
                {
                    if (userresponse is Error)
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError, (userresponse as Error).ErrorMessage);
                    }
                    else
                    {
                        var NumberSimOrderResponse = userresponse.GetValue("payload").ToObject<GetSimOrdersNoByEmailResponseModel>();
                        return Json(new { errorCode = 0, status = true, message = string.Empty, Data = NumberSimOrderResponse });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: ValidateOrderSimEmail, Parameters=> model: {JsonConvert.SerializeObject(Email)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAddresses(string postCode)
        {
            try
            {
                var response = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAddressesByPostCode", User, null, true, false, null, new string[1] { "postCode=" + postCode });
                if (response != null)
                {
                    if (response is Error)
                    {
                        if ((response as Error).ErrorCode == (int)ApiStatusCodes.NoAddressFound)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.NoAddressFound, status = false, message = MessagesResource.ResourceManager.GetString(Messages.NoAddressFound.ToString()) });
                        }
                        else
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                        }
                    }
                    else
                    {
                        var addresseslist = response.GetValue("payload").ToObject<GetAddressResponseModel>();
                        return Json(new { errorCode = 0, status = true, message = string.Empty, Data = addresseslist });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: ValidateOrderSimEmail, Parameters=> model: {JsonConvert.SerializeObject(postCode)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [Route("about-us")]
        [AllowAnonymous]
        public async Task<IActionResult> About()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: About, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("contact-us")]
        [AllowAnonymous]
        public async Task<IActionResult> Contact()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: Contact, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("privacy-policy")]
        [AllowAnonymous]
        public async Task<IActionResult> Privacy()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: PrivacyPolicy, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("terms-conditions")]
        [AllowAnonymous]
        public async Task<IActionResult> TermsConditions()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: TermsConditions, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("acceptable-use-policy")]
        [AllowAnonymous]
        public async Task<IActionResult> AcceptableUsePolicy()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: AcceptableUsePolicy, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("help-center")]
        [AllowAnonymous]
        public async Task<IActionResult> Help()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: Help, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("order-sim")]
        [AllowAnonymous]
        public async Task<IActionResult> OrderSim()
        {
            try
            {
                var model = new SimOrderViewModel();
                await model.SetSharedDataAsync(User);

                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: OrderFree4GSim, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpPost]
        [Route("order-sim")]
        [AllowAnonymous]
        public async Task<IActionResult> OrderSim(SimOrderViewModel model)
        {
            try
            {
                await model.SetSharedDataAsync(User);
                ModelState.Clear();
                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: OrderFree4GSim, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }

        }

        [HttpGet]
        [Route("offers")]
        [AllowAnonymous]
        public async Task<IActionResult> Offers()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: Offers, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }

        }

        [HttpGet]
        [Route("offerDetails")]
        [AllowAnonymous]
        public async Task<IActionResult> OfferDetails()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: OfferDetails, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("offers/portInYourNumber")]
        [AllowAnonymous]
        public async Task<IActionResult> PortInYourNumber()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: PortInYourNumber, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("offers/referAFriend")]
        [AllowAnonymous]
        public async Task<IActionResult> ReferAFriend()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: ReferAFriend, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("offers/autoTopUp")]
        [AllowAnonymous]
        public async Task<IActionResult> AutoTopUp()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: AutoTopUp, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("offers/free4GSIM")]
        [AllowAnonymous]
        public async Task<IActionResult> Free4GSIM()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: Free4GSIM, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("offers/freeNOWtoNOWCalls")]
        [AllowAnonymous]
        public async Task<IActionResult> FreeNOWtoNOWCalls()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: FreeNOWtoNOWCalls, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("offers/freeData")]
        [AllowAnonymous]
        public async Task<IActionResult> FreeData()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: FreeData, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("rates")]
        [Route("rates/{type}")]
        [AllowAnonymous]
        public async Task<IActionResult> Rates(string type)
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                if (type != null)
                {
                    ViewBag.SelectedRateOption = type;
                }


                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: Rates, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("topUp")]
        [AllowAnonymous]
        public async Task<IActionResult> TopUp()
        {
            try
            {
                CheckOutViewModel model = new CheckOutViewModel();
                var respons = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetCountries", User, null, true);
                if (respons != null)
                {
                    var CountrieslList = respons.GetValue("payload").ToObject<CountriesResponseModel>();
                    string json = JsonConvert.SerializeObject(CountrieslList);
                    model.ListOfCountries = CountrieslList;
                }
                model.CheckoutType = CheckOutTypes.TopUp;

                await model.SetSharedDataAsync(User);

                if (User.Identity.IsAuthenticated)
                {
                    //Check User Products
                    var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                    if (!string.IsNullOrEmpty(products))
                    {
                        model.UserProducts = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Select(item => new SelectListItem()
                        {
                            Text = item.ProductRef,
                            Value = item.ProductRef,
                            Selected = item.ProductRef.Equals(model.Msisdn) ? true : false
                        });
                    }
                    else
                    {
                        return RedirectToAction("AddProduct", "Account");
                    }

                    if (model.CheckoutType == CheckOutTypes.TopUp)
                    {
                        var topupResponse = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).FirstOrDefault();
                        if (topupResponse != null)
                        {
                            var settingResponse = await Pay360Service.GetAutoTopUp(new Pay360GetAutoTopUpRequest() { Msisdn = topupResponse.ProductRef, Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value, ProductCode = ProductCode.NOWPAYG.ToString() });
                            if (settingResponse != null && settingResponse.errorCode == 0 && settingResponse.payload != null)
                            {
                                model.IsAutoToupEnabled = settingResponse.payload.Status;
                            }
                        }
                    }

                    //Get User Pay360 Cards
                    var response = await Pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
                    {
                        customerUniqueRef = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value,
                        productCode = ProductCode.NOWPAYG.ToString(),

                    });

                    if (response != null)
                    {
                        if (response.errorCode > 0)
                        {
                            if (response.errorCode == (int)Pay360StatusCodes.CustomerNotExist) //Customer not Exist
                            {

                            }
                            else
                            {
                                return RedirectToAction("Error", "Error");
                            }
                        }
                        else
                        {
                            if (response.payload != null)
                            {
                                model.UserPay360Cards = response.payload;
                            }
                            else
                            {
                                return RedirectToAction("Error", "Error");
                            }
                        }
                    }
                    else
                    {
                        return RedirectToAction("Error", "Error");
                    }
                }
                return View(@"~/Views/Account/Checkout.cshtml", model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: TopUp,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("why-nowmobile")]
        [AllowAnonymous]
        public async Task<IActionResult> whynowmobile()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: whynowmobile, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("plans")]
        [Route("plans/{type}")]
        [Route("plans/{type}/{plan}")]
        [Route("plans/{type}/{plan}/{filter}")]
        [AllowAnonymous]
        public async Task<IActionResult> Plans(string type, string plan, string filter)
        {
            try
            {
                PlansViewModel model = new PlansViewModel();
                if (type != null)
                {
                    ViewBag.SelectedPlanType = type;
                }

                var Plan = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);
                var Countries = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllCountriesWithPlans", User, null, true);

                if (Plan != null && Countries != null)
                {
                    if (Plan is Error || Countries is Error)
                    {
                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        if (plan == "filter")
                        {
                            model = Plan.GetValue("payload").ToObject<PlansViewModel>();
                            model.Plans = model.Plans.Where(c => c.CountryName == type).ToList();
                            model.Filter = true;
                        }
                        else if(filter == "filter")
                        {
                            model = Plan.GetValue("payload").ToObject<PlansViewModel>();
                            model.Plans = model.Plans.Where(c => c.CountryName == type && c.SubByTextCode==plan).ToList();
                            model.Filter = true;
                        }
                        else
                        {
                            model = Plan.GetValue("payload").ToObject<PlansViewModel>();
                            model.PlansCountries = Countries.GetValue("payload").ToObject<GetAllCountriesWithPlansResponseModel>();
                        }
                    }
                }

                await model.SetSharedDataAsync(User);
                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: plans, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("bundles")]
        [Route("bundles/{type}")]
        [AllowAnonymous]
        public IActionResult Bundles(string type)
        {
            try
            {
                if (type != null)
                {
                    return RedirectToActionPermanent("plans", new { type = type });
                }
                else
                {
                    return RedirectToActionPermanent("plans");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: bundles, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [Route("sitemap.xml")]
        public ActionResult SitemapAsync()
        {
            string baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

            // get last modified date of the home page
            var siteMapBuilder = new SitemapBuilder();

            // add the home page to the sitemap
            siteMapBuilder.AddUrl(baseUrl, changeFrequency: SitemapBuilder.ChangeFrequency.Monthly, priority: 1.0);

            var urls = new List<string>()
            {
                new string(baseUrl+"/plans"),
                new string(baseUrl+"/why-nowmobile"),
                new string(baseUrl+"/about-us"),
                new string(baseUrl+"/contact-us"),
                new string(baseUrl+"/privacy-policy"),
                new string(baseUrl+"/terms-conditions"),
                new string(baseUrl+"/acceptable-use-policy"),
                new string(baseUrl+"/help-center"),
                new string(baseUrl+"/order-sim"),
                new string(baseUrl+"/offers"),
                new string(baseUrl+"/offerDetails"),
                new string(baseUrl+"/offers/portInYourNumber"),
                new string(baseUrl+"/offers/referAFriend"),
                new string(baseUrl+"/offers/autoTopUp"),
                new string(baseUrl+"/offers/free4GSIM"),
                new string(baseUrl+"/offers/freeNOWtoNOWCalls"),
                new string(baseUrl+"/offers/freeData"),
                new string(baseUrl+"/rates"),
                new string(baseUrl+"/topUp"),
            };

            // add the blog posts to the sitemap
            foreach (var url in urls)
            {
                siteMapBuilder.AddUrl(url);
            }

            // generate the sitemap xml
            string xml = siteMapBuilder.ToString();

            return Content(xml, "text/xml");
        }

        [HttpGet]
        [Route("2for1offer")]
        public async Task<IActionResult> TwoForOneOffer()
        {
            try
            {
                TwoForOneViewModel model = new TwoForOneViewModel();
                await model.SetSharedDataAsync(User);

                var Plan = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);
                if (Plan != null)
                {
                    if (Plan is Error)
                    {
                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        PlansResponseModel Plans = Plan.GetValue("payload").ToObject<PlansResponseModel>();
                        model.Plans = Plans;
                    }
                }

                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: TwoForOneOffer, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("2for1promo")]
        public async Task<IActionResult> TwoForOnePromo()
        {
            try
            {
                TwoForOneViewModel model = new TwoForOneViewModel();
                await model.SetSharedDataAsync(User);

                var Plan = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetAllActivePlans", User, null, true);
                if (Plan != null)
                {
                    if (Plan is Error)
                    {
                        return RedirectToAction("Error", "Error");
                    }
                    else
                    {
                        PlansResponseModel Plans = Plan.GetValue("payload").ToObject<PlansResponseModel>();
                        model.Plans = Plans;
                    }
                }

                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: TwoForOnePromo, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("cookies-policy")]
        public async Task<IActionResult> CookiesPolicy()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: HomeController, Method: CookiesPolicy, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpPost]
        [Route("Verifyusersimorder")]
        public async Task<ActionResult> SimOrderRequestValidation(VerifyUserSimOrderRequestModel model)
        {

            //Check Sim Order Validations            
            var SimOrderValidations =  await Api.CallApi(NowPayGApiEndPoint + "Admin/VerifyUserSimOrder", User, model);
            if (SimOrderValidations != null)
            {
                if (SimOrderValidations is Error)
                {return StatusCode((int)HttpStatusCode.InternalServerError, (SimOrderValidations as Error).ErrorMessage);}

                else
                {
                    var result = SimOrderValidations.GetValue("payload").ToObject<int>();
                    if (result > 0)
                    {
                        return Json(new { isValid = false, errorcode = result });
                    }                   
                }
            }
            else
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, (SimOrderValidations as Error).ErrorMessage);
            }

            int otp = GenerateRandomNo();
            InsertotpRequestModel otpmodel = new InsertotpRequestModel();
            otpmodel.Email = model.Email;
            otpmodel.otpcode = otp;

            ///Check is user exists
            IsUserExistRequestModel IsUserExistmodel = new IsUserExistRequestModel()
            {
                Email = model.Email,
            };

            var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/IsUserExist", User, IsUserExistmodel);

            var objIsUserVerified = await Api.CallApi(NowPayGApiEndPoint + "Admin/IsverifiedUser", User, IsUserExistmodel);
            var resultIsUserVerified = objIsUserVerified.GetValue("payload").ToObject<int>();
            bool isuserexist = true;

            if (objUser is Error)
            {
                if ((objUser as Error).ErrorCode != (int)ApiStatusCodes.UserNotFound)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                }
                if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.UserNotFound)
                {
                    isuserexist = false;
                }
            }
            if (isuserexist==false && resultIsUserVerified==2)
            {
                    var insertotp_response = await Api.CallApi(NowPayGApiEndPoint + "Admin/Insertotp", User, otpmodel);

                    if (insertotp_response is Error)
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError, (insertotp_response as Error).ErrorMessage);
                    }
                    else
                    {                       
                        return Json(new { isValid = true, regsitered = false, confirmed = false });
                    }
                
            }
            if (isuserexist == true && resultIsUserVerified == 2)
            {
                var insertotp_response = await Api.CallApi(NowPayGApiEndPoint + "Admin/Insertotp", User, otpmodel);

                if (insertotp_response is Error)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, (insertotp_response as Error).ErrorMessage);
                }
                else
                {
                    return Json(new { isValid = true, regsitered = true, confirmed = false });
                }

            }

            //Create Sim Order
            return Json(new { isValid = true, regsitered = true, confirmed = true });
        }


        [HttpPost]
        [Route("Verifyuserotp")]
        public async Task<ActionResult> Verifyuserotp(string EmailAddress, string otp)
        {
            VerifyotpRequestModel model = new VerifyotpRequestModel();
            model.Email = EmailAddress;
            model.Otpcode = otp;


            var obj = await Api.CallApi(NowPayGApiEndPoint + "Admin/Verifyotp", User, model);
            var result = obj.GetValue("payload").ToObject<int>();

            if (obj != null)
            {
                if (obj is Error)
                { return StatusCode((int)HttpStatusCode.InternalServerError, (obj as Error).ErrorMessage); }
                else
                {
                    if (result == 1)
                    {
                        return Json(new { response = true });
                    }
                    else
                    {
                        return Json(new { response = false });
                    }
                }
            }
            else
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, (obj as Error).ErrorMessage);
            }

        }

        [HttpPost]
        [Route("Send_otp_to_user")]
        public async Task<ActionResult> Send_otp_to_user(string email)
        {
            int otp = GenerateRandomNo();
            InsertotpRequestModel otpmodel = new InsertotpRequestModel();
            otpmodel.Email = email;
            otpmodel.otpcode = otp;


            var insertotp_response = await Api.CallApi(NowPayGApiEndPoint + "Admin/Insertotp", User, otpmodel);

            if (insertotp_response is Error)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, (insertotp_response as Error).ErrorMessage);
            }
            else
            {
                return Json(new { response = true });
            }
        }

        [Route("healthcheck")]
        public async Task<IActionResult> HealthCheck()
        {
            return Ok();
        }

        public int GenerateRandomNo()
        {
            int _min = 1000;
            int _max = 9999;
            Random _rdm = new Random();
            return _rdm.Next(_min, _max);
        }
    }
}
