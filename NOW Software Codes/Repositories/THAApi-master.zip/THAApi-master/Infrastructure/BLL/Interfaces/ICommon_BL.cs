﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface ICommon_BL
    {
        Task<GenericApiResponse<List<CarouselContent>>> GetAndroidCarousel(string msisdn, string version);
        Task<GenericApiResponse<List<CarouselContent>>> GetIosCarousel(string msisdn, string version, string itVersion);
        Task<GenericApiResponse<AppConfigData>> GetAppConfig(string msisdn, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null);
    }
}
