﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace PaypalApi.Models.DbConnections
{
    public interface IDbConnectionSettings
    {
        IDbConnection SqlConnection { get; }
    }
}
