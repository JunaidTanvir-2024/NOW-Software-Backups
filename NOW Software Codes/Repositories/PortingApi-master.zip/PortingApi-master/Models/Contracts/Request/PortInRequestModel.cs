﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class PortInRequestModel
    {
        [Required]
        public string Email { get; set; }
        [Required]
        public string NTMsisdn { get; set; }
        [Required]
        public DateTime? UserPortingDate { get; set; }
        [Required]
        public string PortMsisdn { get; set; }
        [Required]
        public string Code { get; set; }
        [Required]
        public Products Product { get; set; }
        [Required]
        public MediumTypes Medium { get; set; }
    }

    public class PortInNewRequestModel
    {
        [Required]
        public string Email { get; set; }
        [Required]
        public string PortMsisdn { get; set; }
        [Required]
        public int OrderReferenceId { get; set; }
        [Required]
        public string Code { get; set; }
        [Required]
        public Products Product { get; set; }
        [Required]
        public MediumTypes Medium { get; set; }
    }
}
