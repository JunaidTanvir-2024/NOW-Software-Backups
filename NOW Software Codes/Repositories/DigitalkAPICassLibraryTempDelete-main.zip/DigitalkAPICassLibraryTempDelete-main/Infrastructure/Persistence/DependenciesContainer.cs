﻿using Application.Common.Interfaces.HttpService;
using Infrastructure.Services;
using Infrastructure.Services.HttpService;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Infrastructure.Persistence;

internal static class DependenciesContainer
{
    private static readonly Serilog.ILogger _logger = Log.ForContext(typeof(DependenciesContainer));

    internal static IServiceCollection AddPersistenceServices(this IServiceCollection services, IConfiguration config)
    {
        services.AddScoped<IBundleService, BundleService>();
        services.AddScoped<IHttpService, HttpService>();
        return services
            .Configure<DatabaseSettings>(config.GetSection(nameof(DatabaseSettings)))
            .AddRepositories();
    }

    private static IServiceCollection AddRepositories(this IServiceCollection services)
    {
        services.AddScoped<IUserRepository, UserRepository>();       
        return services;
    }
}
