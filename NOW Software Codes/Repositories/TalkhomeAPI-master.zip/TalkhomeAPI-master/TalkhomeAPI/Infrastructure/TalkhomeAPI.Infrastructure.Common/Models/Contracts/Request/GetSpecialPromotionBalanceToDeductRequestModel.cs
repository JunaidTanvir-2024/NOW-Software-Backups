﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class GetSpecialPromotionBalanceToDeductRequestModel
    {
        public decimal Amount { get; set; }
    }
}
