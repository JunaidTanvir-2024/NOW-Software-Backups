﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request
{
    public class RedeemPointsrequestModel
    {
        public string cardno { get; set; }
        public double points { get; set; }
        public string subscriberid { get; set; }
        public string EmailAddress { get; set; }
    }
}
