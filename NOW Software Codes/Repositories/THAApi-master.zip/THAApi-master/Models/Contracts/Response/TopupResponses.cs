﻿using Models.Contracts.Request;
using Models.Contracts.Request.Voucherify;
using Models.Database;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{

    public class TopUpPaymentHistoryResponseModel
    {
        public IEnumerable<TopupPaymentHistory> TopUpHistory { get; set; }
    }
    public class UserAccountPaymentHistoryResponseModel
    {
        public List<UserAccountPaymentHistory> PaymentHistory { get; set; }
    }

    public class PaymentTopupHistory
    {
        public DateTime TransDate { get; set; }
        public decimal Amount { get; set; }
        public string Method { get; set; }
        public string Type { get; set; }
        public string Reference { get; set; }
        public bool Successfull { get; set; }
    }
    public class PaymentVoucherHistory
    {
        public DateTime TransDate { get; set; }
        public decimal Amount { get; set; }
        public decimal Discount { get; set; }
        public decimal TotalAmount { get; set; }
        public string DiscountCode { get; set; }
        public DiscountCodeType? DiscountCodeType { get; set; }
        public string Method { get; set; }
        public string Type { get; set; }
        public bool Successfull { get; set; }
        public string Reference { get; set; }
		public int RewardPoints { get; set; }
	}
    public class PaymentInAppTransferHistory
    {
        public DateTime TransDate { get; set; }
        public decimal Amount { get; set; }
        public string Method { get; set; }
        public string Type { get; set; }
        public string Reference { get; set; }
        public bool Successfull { get; set; }
        public string Msisdn { get; set; }
        public int RewardPoints { get; set; }
    }
    public class PaymentInAppTransferHistoryV2
    {
        public DateTime TransDate { get; set; }
        public decimal Amount { get; set; }
        public decimal Discount { get; set; }
        public decimal TotalAmount { get; set; }
        public string DiscountCode { get; set; }
        public DiscountCodeType? DiscountCodeType { get; set; }
        public string Method { get; set; }
        public string Type { get; set; }
        public string Reference { get; set; }
        public bool Successfull { get; set; }
        public string Msisdn { get; set; }
        public decimal TotalServiceFee { get; set; }
        public decimal ServiceFee { get; set; }
        public decimal ServiceFeeDiscount { get; set; }
        public int RewardPoints { get; set; }
    }
    public class PaymentBundleHistory
    {
        public DateTime TransDate { get; set; }
        public decimal Amount { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal Discount { get; set; }
        public string DiscountCode { get; set; }
        public DiscountCodeType? DiscountCodeType { get; set; }
        public string Method { get; set; }
        public string Type { get; set; }
        public string Reference { get; set; }
        public bool Successfull { get; set; }
        public string BundleName { get; set; }
        public string BundleId { get; set; }
        public int BundleType { get; set; }
        public string BundleTypeName { get; set; }
        public int BundleCategory { get; set; }
		public string BundleDestination { get; set; }
		public string BundleCategoryName { get; set; }
        public int RewardPoints { get; set; }
    }
}
