﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models
{
    public class OrderResponseModel
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string productName { get; set; }
        public int IsDispatched { get; set; }
        public string AddressL1 { get; set; }
        public string AddressL2 { get; set; }
        public DateTime OrderDateTime { get; set; }
        public DateTime DispatchDateTime { get; set; }
        public bool IsReplacement { get; set; }

    }
}