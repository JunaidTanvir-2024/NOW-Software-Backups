using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using THM.Infrastructure.BLL;
using THM.Infrastructure.DAL;
using THM.Infrastructure.Services;
using THM.Models.Configurations;

namespace THM.Daemon
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureServices((hostContext, services) =>
                {
                    IConfiguration configuration = hostContext.Configuration;

                    services.AddHostedService<CreditSimFullfillmentWorker>();
                    services.AddHostedService<SimOrderEmailsWorker>();
                    services.AddHostedService<AirshipWorker>();
                    services.AddHostedService<SimStatusWorker>();

                    services.AddSingleton((ILogger)new LoggerConfiguration()
                       .MinimumLevel.Debug()
                       .WriteTo.RollingFile(Path.Combine(
                           configuration.GetSection("Serilog")["FilePath"], "THM-Daemon-log-{Date}.txt"))
                       .CreateLogger());

                    services.Configure<ConnectionStrings>(options => configuration.GetSection("ConnectionStrings").Bind(options));
                    services.Configure<SmtpConfig>(options => configuration.GetSection("SmtpConfig").Bind(options));
                    services.Configure<AirShipConfig>(options => configuration.GetSection("AirShipConfig").Bind(options));

                    services.AddTransient(typeof(ICreditSimFulfillment_BL), typeof(CreditSimFulfillment_BL));
                    services.AddTransient(typeof(ICreditSimFulfillment_DL), typeof(CreditSimFulfillment_DL));

                    services.AddTransient(typeof(ISimOrderEmails_BL), typeof(SimOrderEmails_BL));
                    services.AddTransient(typeof(ISimOrderEmails_DL), typeof(SimOrderEmails_DL));

                    services.AddTransient(typeof(IAirship_BL), typeof(Airship_BL));
                    services.AddTransient(typeof(IAirship_DL), typeof(Airship_DL));

                    services.AddTransient(typeof(IEmail_BL), typeof(Email_BL));

                    services.AddHttpClient<IAirshipService, AirshipService>();
                });
    }
}
