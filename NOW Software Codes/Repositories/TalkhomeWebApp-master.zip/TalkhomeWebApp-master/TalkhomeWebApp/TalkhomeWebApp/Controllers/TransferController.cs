﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.TagHelpers;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using TalkhomeWebApp.Models;
using TalkhomeWebApp.Models.ApiContracts.Request;
using TalkhomeWebApp.Models.ApiContracts.Response;
using TalkhomeWebApp.Models.Configurations;
using TalkhomeWebApp.Models.ViewModels;
using TalkhomeWebApp.Models.AirShip;
using TalkhomeWebApp.Services;
using TalkhomeWebApp.Utilities;
using TalkhomeWebApp.Utilities.Extension;
using System.Globalization;

namespace TalkhomeWebApp.Controllers
{
    public class TransferController : BaseController
    {
        private readonly ILogger _logger;
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly IAirshipService _airshipService;
        private readonly IGeoService _geoService;
        private readonly IHelperService _helperService;
		private readonly ApiClient _apiClient;
		private readonly EndPoints _endpoints;
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly TestNumbersByCurrencyConfig _testNumbersByCurrencyConfig;

        public TransferController(ILogger logger,
            IOptions<EndPoints> Endpoints,
            IOptions<BasicAuthConfig> basicAuthConfig,
            IWebHostEnvironment hostEnvironment,
            IAirshipService airshipService,
            IGeoService geoService,
            IOptions<TestNumbersByCurrencyConfig> testNumbersByCurrencyConfig,
            IHelperService helperService,
            ApiClient apiClient) : base(logger, helperService)
        {
            _logger = logger;
            _hostEnvironment = hostEnvironment;
            _endpoints = Endpoints.Value;
            _basicAuthConfig = basicAuthConfig.Value;
            _airshipService = airshipService;
            _geoService = geoService;
            _helperService = helperService;
			this._apiClient = apiClient;
			_testNumbersByCurrencyConfig = testNumbersByCurrencyConfig.Value;
        }


        private string GetTestNumberByCurrency(Currency currency)
        {
            switch (currency)
            {
                case Currency.USD:
                    return _testNumbersByCurrencyConfig.USD;
                case Currency.EUR:
                    return _testNumbersByCurrencyConfig.EUR;
                case Currency.GBP:
                    return _testNumbersByCurrencyConfig.GBP;
                default:
                    return _testNumbersByCurrencyConfig.GBP;
            }
        }
        [HttpGet]
        [Route("getproducts")]
        public async Task<IActionResult> GetProducts(string toMsisdn, string country, string fromMsisdn, string currency)
        {
            try
            {
                if (string.IsNullOrEmpty(toMsisdn)) return BadRequest();
                String encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                            _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                if (User.Identity.IsAuthenticated)
                {
                    //Set for authenticated users later
                    if (string.IsNullOrEmpty(currency))
                    {
                        currency = User.Currency();
                    }
                    if (string.IsNullOrEmpty(fromMsisdn))
                    {
                        fromMsisdn = User.PhoneNumber();
                    }
                }
                else
                {
                    var geoInfo = await _geoService.GetGeoInfo(HttpContext);
                    var json = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountryCurrency.json");
                    var _countriesCurrency = JsonConvert.DeserializeObject<AllCurrenciesModel>(json);

                    if (!string.IsNullOrEmpty(geoInfo?.CountryCode))
                    {
                        var currentCountry = _countriesCurrency.Currencies.Where(x => x.ContainsKey(geoInfo.CountryCode)).FirstOrDefault();
                        if (currentCountry != null)
                        {
                            currency = CommonExtentionMethods.GetCurrencyUnit(currentCountry[geoInfo.CountryCode]);
                        }
                        else
                        {
                            currency = "GBP";
                        }
                    }
                    else
                    {
                        currency = "GBP";
                    }
                    if (string.IsNullOrEmpty(fromMsisdn))
                    {
                        fromMsisdn = GetTestNumberByCurrency(Enum.TryParse<Currency>(currency, true, out var currencyEnum) ? currencyEnum : Currency.GBP);
                    }
                }

                var response = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint + "Transfer/GetProducts", User, ApiCallType.BasicAuth, basicauthtoken: encoded, GetRequest: true,
                    parameters: new string[] { "ToMsisdn=" + toMsisdn.Trim(), "FromMsisdn=" + fromMsisdn.Trim(), "Currency=" + currency });

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    if (errorCode == 0)
                    {
                        var model = responseJson.GetValue("payload").ToObject<GetProductsResponseModel>();

                        foreach (var item in model.Products)
                        {
                            item.ClientCurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(item.ClientCurrecny);
                        }

                        return PartialView("~/Views/Partials/_ChooseAmount_Transfer.cshtml", model);
                    }
                    else
                    {
                        return Json(new { errorCode, message = responseJson.GetValue("message").ToObject<string>() });
                    }
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferController, Method: GetProducts, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [HttpGet]
        [Route("transfer-summary")]
        public async Task<IActionResult> SendCreditSummary(string toMsisdn, string fromMsisdn, string currency)
        {
            try
            {
                var viewModel = new TransferSummaryResponseModel();
                try
                {
                    if (string.IsNullOrEmpty(toMsisdn)) return BadRequest();
                    String encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                                _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));


                    if (User.Identity.IsAuthenticated)
                    {
                        //Set for authenticated users later
                        if (string.IsNullOrEmpty(currency))
                        {
                            currency = User.Currency();
                        }
                        if (string.IsNullOrEmpty(fromMsisdn))
                        {
                            fromMsisdn = User.PhoneNumber();
                        }
                    }
                    else
                    {
                        var geoInfo = await _geoService.GetGeoInfo(HttpContext);
                        var json = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountryCurrency.json");
                        var _countriesCurrency = JsonConvert.DeserializeObject<AllCurrenciesModel>(json);

                        if (!string.IsNullOrEmpty(geoInfo?.CountryCode))
                        {
                            var currentCountry = _countriesCurrency.Currencies.Where(x => x.ContainsKey(geoInfo.CountryCode)).FirstOrDefault();
                            if (currentCountry != null)
                            {
                                currency = currentCountry[geoInfo.CountryCode];
                            }
                            else
                            {
                                currency = "GBP";
                            }
                        }
                        else
                        {
                            currency = "GBP";
                        }
                        if (string.IsNullOrEmpty(fromMsisdn))
                        {
                            fromMsisdn = GetTestNumberByCurrency(Enum.TryParse<Currency>(currency, true, out var currencyEnum) ? currencyEnum : Currency.GBP);
                        }
                    }
                    var response = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint + "Transfer/GetProducts", User, ApiCallType.BasicAuth, basicauthtoken: encoded, GetRequest: true,
                        parameters: new string[] { "ToMsisdn=" + toMsisdn.Trim(), "FromMsisdn=" + fromMsisdn.Trim(), "Currency=" + currency });

                    if (response.IsSuccessStatusCode)
                    {
                        var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                        int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                        if (errorCode == 0)
                        {
                            var model = responseJson.GetValue("payload").ToObject<GetProductsResponseModel>();

                            foreach (var item in model.Products)
                            {
                                item.ClientCurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(item.ClientCurrecny);
                            }
                            viewModel.Operator = model.Operator;
                            return PartialView("~/Views/Partials/_Summary_Transfer.cshtml", viewModel);
                        }
                        else
                        {
                            return Json(new { errorCode, message = responseJson.GetValue("message").ToObject<string>() });
                        }
                    }
                    else
                    {
                        return StatusCode((int)response.StatusCode);
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: TransferController, Method: GetProducts, ErrorMessage:" +
                                    $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                    $"StackTrace: {ex.StackTrace}");
                    return StatusCode(500);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferController, Method: GetPaymentMethods, ErrorMessage:" +
                               $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                               $"StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [HttpGet]
        [Route("getpaymentmethods")]
        [Authorize]
        public async Task<IActionResult> GetPaymentMethods(decimal AmountToCharge,string nowtelRef=null,string product = null)
        {
            try
            {
                //Get promo Details
                var promoResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                                "Transfer/GetSpecialPromotionBalanceToDeduct", User, ApiCallType.Bearer, GetRequest: true, parameters: new string[] { "Amount=" + AmountToCharge + "", "nowtelRef="+ nowtelRef, "product=" + product });

                if (promoResponse.IsSuccessStatusCode)
                {
                    var promoResponseJson = JObject.Parse(promoResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = promoResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        AmountToCharge = promoResponseJson.GetValue("payload").
                            ToObject<GetSpecialPromotionBalanceToDeductResponseModel>().retAmount;
                    }
                    else
                    {
                        _logger.Error($"Class: TransferController, Method: GetPaymentMethods - Transfer/GetSpecialPromotionBalanceToDeduct, Response:" + promoResponseJson);

                        return StatusCode(500);
                    }
                }
                else
                {
                    return StatusCode((int)promoResponse.StatusCode);
                }

                var paymentViewModel = new TransferPaymentMethodViewModels()
                {
                    AmountToCharge = AmountToCharge
                };

                //Get Account Details
                var accountResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                                "Account/GetAccountDetails", User, ApiCallType.Bearer, GetRequest: true);

                if (accountResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        paymentViewModel.AccountBalance = accountResponseJson.GetValue("payload").
                            ToObject<GetAccountDetailsResponseModel>().Balance;
                    }
                    else
                    {
                        _logger.Error($"Class: TransferController, Method: GetPaymentMethods - Account/GetAccountDetails, Response:" + accountResponseJson);

                        return StatusCode(500);
                    }
                }
                else
                {
                    return StatusCode((int)accountResponse.StatusCode);
                }


                //Get Customer Cards
                var cardsResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                    "Payment/GetCustomerCards", User, ApiCallType.Bearer, GetRequest: true);

                if (cardsResponse.IsSuccessStatusCode)
                {
                    var cardsResponseJson = JObject.Parse(cardsResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = cardsResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        paymentViewModel.Cards = cardsResponseJson.GetValue("payload").ToObject<Pay360CardsResponseModel>().paymentMethodResponses;

                        if (paymentViewModel.Cards != null && paymentViewModel.Cards.Count > 0)
                        {
                            paymentViewModel.Cards = paymentViewModel.Cards.OrderByDescending(x => x.isPrimary).ToList();
                        }
                    }
                }
                else
                {
                    return StatusCode((int)cardsResponse.StatusCode);
                }

                //Get Countries
                var _countries = JsonConvert.DeserializeObject<CountriesModel>(System.IO.File.ReadAllText(
                                                _hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json"));

                paymentViewModel.Countries = _countries.countries;


                return PartialView("~/Views/Partials/_ChoosePayment_Transfer.cshtml", paymentViewModel);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferController, Method: GetPaymentMethods, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("startaccountbalancepayment")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> StartAccountBalancePayment(StartAccountBalancePaymentRequest model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); };

                var transferResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                    "Transfer/TransferByAccountBalance", User, ApiCallType.Bearer, new TransferByAccountBalanceRequestModel()
                    {
                        nowtelRef = model.nowtelRef,
                        product = model.product,
                        operatorId = model.operatorId,
                        IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext)
                    });

                if (transferResponse.IsSuccessStatusCode)
                {
                    var transferResponseJson = JObject.Parse(transferResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = transferResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var transferData = transferResponseJson.GetValue("payload").ToObject<TransferByAccountBalanceResponseModel>();
                        transferData.UserCurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(transferData.TransferData.fromCurrency);
                        transferData.TransferData.PaymentMethod = PaymentMethodTypes.AccountBalance;
                        TempData.Put("AB-Transfer-Data", transferData);
                        return RedirectToAction("SuccessMessage", "Home", new { key = "TransferSuccessful" });
                    }
                    else
                    {
                        //Need to handle error code values
                        return HandleErrorResponse<StartAccountBalancePaymentRequest>(model, errorCode,
                                                            transferResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (transferResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferController, Method: StartAccountBalancePayment, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("startpaypalpayment")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> StartPaypalPayment(StartPaypalPaymentRequest model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); };

                var payPalResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                    "Transfer/TransferByPayPal", User, ApiCallType.Bearer, new TransferByPayPalRequestModel()
                    {
                        nowtelRef = model.nowtelRef,
                        product = model.product,
                        operatorId = model.operatorId,
                        ipAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext)
                    });

                if (payPalResponse.IsSuccessStatusCode)
                {
                    var payPalResponseJson = JObject.Parse(payPalResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = payPalResponseJson.GetValue("errorCode").ToObject<int>();
                    var payPalData = payPalResponseJson.GetValue("payload").ToObject<TransferByPayPalResponseModel>();

                    if (errorCode == 0)
                    {
                        return Redirect(payPalData.clientRedirectUrl);
                    }
                    else
                    {
                        //Need to handle error code values
                        return HandleErrorResponse<TransferByPayPalResponseModel>(payPalData, errorCode, payPalResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (payPalResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferController, Method: StartPaypalPayment, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("transferpaypalpaymentreturnv1")] //Direct Paypal
        [Authorize]
        public async Task<IActionResult> PayPalPaymentReturnV1(PayPalPaymentReturnV1RequestModel model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); };

                var payPalResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
					"Transfer/TransferByPayPalCallBackV1", User, ApiCallType.Bearer, new TransferByPayPalCallBackV1RequestModel()
                    {
                        NowtelRef = model.nowtelRef,
                        Product = model.product,
                        OperatorId = model.operatorId,
                        PayerID = model.PayerID,
                        PaymentId = model.PaymentId,
                        IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext)
                    });

                if (payPalResponse.IsSuccessStatusCode)
                {
                    var payPalResponseJson = JObject.Parse(payPalResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = payPalResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payPalData = payPalResponseJson.GetValue("payload").ToObject<TransferByPayPalCallBackResponseModel>();
                        payPalData.TransferData.PaymentMethod = PaymentMethodTypes.Paypal;
                        TempData.Put("PP-Transfer-Data", payPalData.TransferData);
                        return RedirectToAction("SuccessMessage", "Home", new { key = "TransferSuccessful" });
                    }
                    else
                    {
                        return HandleErrorResponse<PayPalPaymentReturnV1RequestModel>(model, errorCode,
                                payPalResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (payPalResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferController, Method: TransferPayPalPaymentReturnV1, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("transferpaypalpaymentreturnv2")] //PayPal Via Pay360
        [Authorize]
        public async Task<IActionResult> PayPalPaymentReturnV2(PayPalPaymentReturnV2RequestModel model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); };

                var payPalResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                    "Transfer/TransferByPayPalCallBackV2", User, ApiCallType.Bearer, new TransferByPayPalCallBackV2RequestModel()
                    {
                        NowtelRef = model.nowtelRef,
                        Product = model.product,
                        OperatorId = model.operatorId,
                        Token = model.token,
                        IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext)
                    });

                if (payPalResponse.IsSuccessStatusCode)
                {
                    var payPalResponseJson = JObject.Parse(payPalResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = payPalResponseJson.GetValue("errorCode").ToObject<int>();
                    var payPalData = payPalResponseJson.GetValue("payload").ToObject<TransferByPayPalCallBackResponseModel>();
                    if (errorCode == 0)
                    {
                        payPalData.TransferData.PaymentMethod = PaymentMethodTypes.Paypal;
                        TempData.Put("PP-Transfer-Data", payPalData.TransferData);
                        return RedirectToAction("SuccessMessage", "Home", new { key = "TransferSuccessful" });
                    }
                    else
                    {
                        return HandleErrorResponse<TransferByPayPalCallBackResponseModel>(payPalData, errorCode, payPalResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (payPalResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferController, Method: PayPalPaymentReturnV2, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("transferpaypalpaymentcancel")]
        [Authorize]
        public IActionResult PayPalPaymentCancel(string destination, string network, string amount, string id)
        {
            //return RedirectToAction("ErrorMessage", "Home", new { key = "PayPalPaymentCancelled" });
            TempData.Put("Key", "PayPalPaymentCancelled");
            return RedirectToAction("MobileTopupError", "Home", new MobileTopupTransactionModel
            {
                Payment = "Paypal",
                From = User.PhoneNumber(),
                To = destination,
                Network = network,
                Amount = amount,
                Origin = _helperService.GetCountryCode(User.PhoneNumber()),
                Destination = !string.IsNullOrEmpty(destination)? _helperService.GetCountryCode(destination):null,
                Id = id
            });
        }

        [HttpGet]
        [Route("getaddressbypostcode")]
        public async Task<IActionResult> GetAddressByPostCode(string postCode)
        {
            try
            {
                String encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                            _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                //Get address by postCode
                var addressResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                                                 "Common/GetAddressByPostCode", User, ApiCallType.BasicAuth, basicauthtoken: encoded,
                                                  GetRequest: true, parameters: new string[] { "PostCode=" + postCode });

                if (addressResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(addressResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = accountResponseJson.GetValue("payload").
                                         ToObject<GetAddressByPostCodeResponseModel>().AddressData;
                        return Json(new { errorCode = 0, payload });
                    }
                    else if (errorCode == (int)ApiStatusCodes.NoAddressFound)
                    {
                        return Json(new { errorCode = 1, message = "No Address found against given Post Code. Please enter manually" });
                    }
                    else
                    {
                        return Json(new { errorCode, message = "Something went wrong on server" });
                    }
                }
                else
                {
                    return StatusCode((int)addressResponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferController, Method: GetAddressByPostCode, ErrorMessage:" +
                                    $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                    $"StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("startexistingcardpayment")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> StartExistingCardPayment(StartExistingCardPaymentRequest model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); };

                var paymentResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                    "Transfer/TransferByExistingCard", User, ApiCallType.Bearer, new TransferByExistingCardRequestModel()
                    {
                        nowtelRef = model.nowtelRef,
                        product = model.product,
                        operatorId = model.operatorId,
                        cardToken = model.cardToken,
                        SecurityCode = model.SecurityCode,
                        ipAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext)
                    });

                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var transferData = paymentResponseJson.GetValue("payload").ToObject<TransferByCardResponseModel>();
                        transferData.transferData.PaymentMethod = PaymentMethodTypes.Card;
                        TempData.Put("Card-Transfer-Data", transferData.transferData);
                        return RedirectToAction("SuccessMessage", "Home", new { key = "TransferSuccessful" });
                    }
                    else
                    {
                        var payload = paymentResponseJson.GetValue("payload").ToObject<TransferByCardResponseModel>();
                        if (errorCode == (int)ApiStatusCodes.Pending3dSecure)
                        {

                            if (!payload.threeDSecureData.clientRedirectType.Contains("V2", StringComparison.CurrentCultureIgnoreCase))
                            {
                                var transactionViewModel = new Pay360TransactionViewModel
                                {
                                    url = payload.threeDSecureData.redirectUrl,
                                    pareq = payload.threeDSecureData.pareq,
                                    TransactionId = payload.threeDSecureData.transactionId,
                                    returnUrl = payload.threeDSecureData.returnUrl
                                };
                                return View("~/Views/shared/TransferView3DSecure.cshtml", transactionViewModel);
                            }
                            else
                            {
                                var transactionViewModel = new Pay360TransactionViewModel
                                {
                                    url = payload.threeDSecureData.redirectUrl,
                                    pareq = payload.threeDSecureData.pareq,
                                    TransactionId = payload.threeDSecureData.transactionId,
                                    returnUrl = payload.threeDSecureData.returnUrl,
                                    threeDSServerTransId = payload.threeDSecureData.threeDSServerTransId
                                };
                                return View("~/Views/shared/TransferView3DSecureV2.cshtml", transactionViewModel);
                            }

                        }

                        //Need to handle error code values
                        return HandleErrorResponse<TransferByCardResponseModel>(payload, errorCode,
                                                            paymentResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (paymentResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: TransferController, Method: StartExistingCardPayment, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("startnewcardpayment")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> StartNewCardPayment(StartNewCardPaymentRequest model)
        {
            try
            {
                ModelState.Remove("BillingAddress.PostCode");

                if (!ModelState.IsValid) { return BadRequest(); };

                var paymentResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                   "Transfer/TransferByNewCard", User, ApiCallType.Bearer, new TransferByNewCardRequestModel()
                   {
                       billingAddressData = new BillingAddressModel()
                       {
                           AddressL1 = model.BillingAddress.AddressL1,
                           AddressL2 = model.BillingAddress.AddressL2,
                           AddressL3 = model.BillingAddress.AddressL3,
                           AddressL4 = model.BillingAddress.AddressL4,
                           City = model.BillingAddress.City,
                           PostCode = model.BillingAddress.PostCode,
                           Region = model.BillingAddress.Region,
                           CountryCode = model.BillingAddress.CountryCode
                       },
                       cardData = new PaymentCardModel()
                       {
                           CardNumber = model.NewCard.CardNumber,                        
                           ExpiryMonth = model.NewCard.ExpiryDate.Split('/')[0],
                           ExpiryYear = model.NewCard.ExpiryDate.Split('/')[1],
                           NameOnCard = model.NewCard.NameOnCard,
                           SecurityCode = model.NewCard.SecurityCode,
                           ShouldSaveCard = model.NewCard.ShouldSaveCard
                       },
                       nowtelRef = model.nowtelRef,
                       operatorId = model.operatorId,
                       product = model.product,
                       ipAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext)
                   });

                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var transferData = paymentResponseJson.GetValue("payload").ToObject<TransferByCardResponseModel>();
                        transferData.transferData.PaymentMethod = PaymentMethodTypes.Card;
                        TempData.Put("Card-Transfer-Data", transferData.transferData);
                        return RedirectToAction("SuccessMessage", "Home", new { key = "TransferSuccessful" });
                    }
                    else
                    {
                        var data = paymentResponseJson.GetValue("payload").ToObject<TransferByCardResponseModel>();
                        if (errorCode == (int)ApiStatusCodes.Pending3dSecure)
                        {
                            var payload = data.threeDSecureData;

                            if (!payload.clientRedirectType.Contains("V2", StringComparison.CurrentCultureIgnoreCase))
                            {
                                var transactionViewModel = new Pay360TransactionViewModel
                                {
                                    url = payload.redirectUrl,
                                    pareq = payload.pareq,
                                    TransactionId = payload.transactionId,
                                    returnUrl = payload.returnUrl + "&shouldSave=" + model.NewCard.ShouldSaveCard
                                };
                                return View("~/Views/shared/TransferView3DSecure.cshtml", transactionViewModel);
                            }
                            else
                            {
                                var transactionViewModel = new Pay360TransactionViewModel
                                {
                                    url = payload.redirectUrl,
                                    pareq = payload.pareq,
                                    TransactionId = payload.transactionId,
                                    returnUrl = payload.returnUrl + "&shouldSave=" + model.NewCard.ShouldSaveCard,
                                    threeDSServerTransId = payload.threeDSServerTransId
                                };
                                return View("~/Views/shared/TransferView3DSecureV2.cshtml", transactionViewModel);
                            }

                            //var transactionViewModel = new Pay360TransactionViewModel
                            //{
                            //    url = payload.redirectUrl,
                            //    pareq = payload.pareq,
                            //    TransactionId = payload.transactionId,
                            //    returnUrl = payload.returnUrl + "&shouldSave=" + model.NewCard.ShouldSaveCard
                            //};

                            //return View("~/Views/shared/TransferView3DSecure.cshtml", transactionViewModel);
                        }

                        //Need to handle error code values
                        return HandleErrorResponse<TransferByCardResponseModel>(data, errorCode,
                                        paymentResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (paymentResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: TransferController, Method: StartNewCardPayment, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("startnewcustomerpayment")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> StartNewCustomerPayment(StartNewCustomerPaymentRequest model)
        {
            try
            {
                ModelState.Remove("BillingAddress.PostCode");

                if (!ModelState.IsValid) { return BadRequest(); };

                var paymentResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                    "Transfer/TransferByNewCustomer", User, ApiCallType.Bearer, new TransferByNewCustomerRequestModel()
                    {
                        billingAddressData = new BillingAddressModel()
                        {
                            AddressL1 = model.BillingAddress.AddressL1,
                            AddressL2 = model.BillingAddress.AddressL2,
                            AddressL3 = model.BillingAddress.AddressL3,
                            AddressL4 = model.BillingAddress.AddressL4,
                            City = model.BillingAddress.City,
                            PostCode = model.BillingAddress.PostCode,
                            Region = model.BillingAddress.Region,
                            CountryCode = model.BillingAddress.CountryCode
                        },
                        cardData = new PaymentCardModel()
                        {
                            CardNumber = model.NewCard.CardNumber,
                            ExpiryMonth = model.NewCard.ExpiryDate.Split('/')[0],
                            ExpiryYear = model.NewCard.ExpiryDate.Split('/')[1],
                            NameOnCard = model.NewCard.NameOnCard,
                            SecurityCode = model.NewCard.SecurityCode,
                            ShouldSaveCard = model.NewCard.ShouldSaveCard
                        },
                        nowtelRef = model.nowtelRef,
                        operatorId = model.operatorId,
                        product = model.product,
                        ipAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext)
                    });

                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var transferData = paymentResponseJson.GetValue("payload").ToObject<TransferByCardResponseModel>();
                        transferData.transferData.PaymentMethod = PaymentMethodTypes.Card;
                        TempData.Put("Card-Transfer-Data", transferData.transferData);
                        return RedirectToAction("SuccessMessage", "Home", new { key = "TransferSuccessful" });
                    }
                    else
                    {
                        var data = paymentResponseJson.GetValue("payload").ToObject<TransferByCardResponseModel>();
                        if (errorCode == (int)ApiStatusCodes.Pending3dSecure)
                        {
                            var payload = data.threeDSecureData;

                            if (!payload.clientRedirectType.Contains("V2", StringComparison.CurrentCultureIgnoreCase))
                            {
                                var transactionViewModel = new Pay360TransactionViewModel
                                {
                                    url = payload.redirectUrl,
                                    pareq = payload.pareq,
                                    TransactionId = payload.transactionId,
                                    returnUrl = payload.returnUrl + "&shouldSave=" + model.NewCard.ShouldSaveCard
                                };
                                return View("~/Views/shared/TransferView3DSecure.cshtml", transactionViewModel);
                            }
                            else
                            {
                                var transactionViewModel = new Pay360TransactionViewModel
                                {
                                    url = payload.redirectUrl,
                                    pareq = payload.pareq,
                                    TransactionId = payload.transactionId,
                                    returnUrl = payload.returnUrl + "&shouldSave=" + model.NewCard.ShouldSaveCard,
                                    threeDSServerTransId = payload.threeDSServerTransId
                                };
                                return View("~/Views/shared/TransferView3DSecureV2.cshtml", transactionViewModel);
                            }

                            //var transactionViewModel = new Pay360TransactionViewModel
                            //{
                            //    url = payload.redirectUrl,
                            //    pareq = payload.pareq,
                            //    TransactionId = payload.transactionId,
                            //    returnUrl = payload.returnUrl
                            //};

                            //return View("~/Views/shared/TransferView3DSecure.cshtml", transactionViewModel);
                        }

                        //Need to handle error code values
                        return HandleErrorResponse<TransferByCardResponseModel>(data, errorCode, paymentResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (paymentResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: TransferController, Method: StartNewCustomerPayment, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [Route("securereturntransfer")]
        public async Task<IActionResult> SecureReturnTransfer(SecureReturnTransferRequest model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); };

                String encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var paymentResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                    "Transfer/TransferByCard3dSecureCallBack", User, ApiCallType.BasicAuth,
                     new TransferByCardCallBackRequestModel()
                     {
                         MD = model.MD,
                         nowtelRef = model.nowtelRef,
                         operatorId = model.operatorId,
                         PaRes = model.PaRes,
                         clientRedirectType = model.clientRedirectType,
                         product = model.product,
                         customerEmail = model.customerEmail,
                         IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext)
                     }, basicauthtoken: encoded);

                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();

                    var response = paymentResponseJson.GetValue("payload").ToObject<TransferByCardResponseModel>();

                    if (errorCode == 0)
                    {
                        var transferData = response;
                        transferData.transferData.shouldSave = model.shouldSave;
                        transferData.transferData.PaymentMethod = PaymentMethodTypes.Card;
                        ViewBag.SuccessModelData = JsonConvert.SerializeObject(new TransferSuccessObjectViewModel { transferData = transferData.transferData });
                        return PartialView("~/Views/Home/SuccesRedirection.cshtml");
                    }
                    else
                    {
                        //Need to handle error code values
                        return HandleErrorResponse<TransferByCardResponseModel>(response, errorCode, paymentResponseJson.GetValue("message").ToObject<string>(), true);
                    }
                }

                ViewBag.ErrorModelData = JsonConvert.SerializeObject(new ErrorObjectViewModel { StatusCode = paymentResponse.StatusCode });
                return PartialView("~/Views/Home/ErrorRedirection.cshtml");
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: TransferController, Method: SecureReturnTransfer, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                ViewBag.ErrorModelData = JsonConvert.SerializeObject(new ErrorObjectViewModel { Key = "InternalServerError" });
                return PartialView("~/Views/Home/ErrorRedirection.cshtml");
            }
        }

        [HttpPost]
        [Route("TransferPaymentSuccess")]
        [ValidateAntiForgeryToken]
        public IActionResult TransferPaymentSuccess(string data)
        {
            var model = JsonConvert.DeserializeObject<TransferByCardResponseModel>(data);
            TempData.Put("Card-Transfer-Data", model.transferData);
            return RedirectToAction("SuccessMessage", "Home", new { key = "TransferSuccessful" });

        }

        [HttpPost]
        [Route("TransferPaymentError")]
        [ValidateAntiForgeryToken]
        public IActionResult TransferPaymentError(string data)
        {
            var Model = JsonConvert.DeserializeObject<ErrorObjectViewModel>(data);

            if (Model.StatusCode > 0)
            {
                if (Model.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                return RedirectToAction("ErrorMessage", "Home", new { key = HttpStatusCode.InternalServerError });
            }
            else
            {
                TempData.Put("Key", Model.Key);
                if (Model.Key == "paymentserviceerror")
                    TempData.Put("Payment-Service-Error", Model.ErrorMessage);

                return RedirectToAction("MobileTopupError", "Home", Model.MobileTopupInfo);
            }
        }
    }
}