using Application.Features.AutoTopup.Card.Existing;
using Application.Features.AutoTopup.Card.New;
using Application.Features.Payment.Models;
using Mapster;

namespace Application.Common.MappingProfiles;

public class AutoTopupNewCardPaymentProfile : IRegister
{
    // New Card
    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<SetAutoTopupNewCardRequest, PaymentTopupInfo>
       .NewConfig()
       .Map(paymentTopupInfo => paymentTopupInfo.AutoTopupInfo!.ThresHoldAmount, source => source.ThresHoldAmount)
       .Map(paymentTopupInfo => paymentTopupInfo.AutoTopupInfo!.TopupAmount, source => source.TopupAmount)
       .Map(paymentTopupInfo => paymentTopupInfo.AutoTopupInfo!.Status, source => source.Status);
    }
}
public class AutoTopupExistingCardPaymentProfile : IRegister
{
    // New Card
    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<SetAutoTopupExistingCardRequest, PaymentTopupInfo>
       .NewConfig()
       .Map(paymentTopupInfo => paymentTopupInfo.AutoTopupInfo!.ThresHoldAmount, source => source.ThresHoldAmount)
       .Map(paymentTopupInfo => paymentTopupInfo.AutoTopupInfo!.TopupAmount, source => source.TopupAmount)
       .Map(paymentTopupInfo => paymentTopupInfo.AutoTopupInfo!.Status, source => source.Status);
    }
}