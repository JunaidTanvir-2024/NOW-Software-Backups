﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Configurations
{
    public class Pay360Config
    {
        public string Pay360ApiEndpoint { get; set; }
        public bool IsAuthorization { get; set; }
        public bool Do3DSecure { get; set; }
        public bool IsDirectFullfilment { get; set; }
        public bool IsCustomerAddressCopy { get; set; }
    }
}
