﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog.Core;
using System.IO;
using SmsOutReachCallBackUrlApi.Contracts.Xeebi.Request;
using SmsOutReachCallBackUrlApi.Infrastructure.Xeebi;
using Serilog;
using System.Text;
using Newtonsoft.Json;
using System.Net;
using SmsOutReachCallBackUrlApi.Models;

namespace SmsOutReachCallBackUrlApi.Controllers
{
    
    public class XeebiController : Controller
    {

        private readonly ILogger Logger;
        private IXeebiPost XeebiPost;

        public XeebiController(ILogger logger, IXeebiPost xeebiPost)
        {
            Logger = logger;
            XeebiPost = xeebiPost;
        }

        
        [HttpPost]
        async public Task<IActionResult> SmsCallBackUrl()
        {

            Logger.Information($"Processing - Post: Xeebi/smsreport ");
            string requestJsonData = "";
            try
            {

                using (StreamReader reader = new StreamReader(Request.Body, Encoding.UTF8))
                {
                    requestJsonData = await reader.ReadToEndAsync();
                }
                List<XeebiSmsCallBackUrlRequest> deliveryReport;
                if (requestJsonData.Contains("["))
                {
                    deliveryReport = JsonConvert.DeserializeObject<List<XeebiSmsCallBackUrlRequest>>(requestJsonData);
                }
                else
                {
                    deliveryReport = new List<XeebiSmsCallBackUrlRequest>();
                    XeebiSmsCallBackUrlRequest req = JsonConvert.DeserializeObject<XeebiSmsCallBackUrlRequest>(requestJsonData);
                    deliveryReport.Add(req);

                }
                DbResult result = await XeebiPost.InsertUpdateSmsCallBackUrlData(deliveryReport);
                if (result.DBStatus == 1)
                {
                    return Ok("Success");
                }
                else
                {
                    Logger.Error($"Exception - Post: Xeebi/smsreport, Parameters --> SmsCallBackUrlJson: {requestJsonData}, ExceptionMessage: {result.DBErrorMessage}");
                    return StatusCode((int)HttpStatusCode.InternalServerError, result.DBErrorMessage);

                    //return Json(result.DBErrorMessage);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Exception - Post: Xeebi/smsreport, Parameters --> SmsCallBackUrlJson: {requestJsonData}, ExceptionMessage: {ex.Message}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
                //return Json(ex.Message);
            }

        }

    }
}