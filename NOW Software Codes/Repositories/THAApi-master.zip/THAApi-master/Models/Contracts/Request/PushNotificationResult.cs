﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    
    public class PushNotificationResult
    {
        public PushNotificationResult()
        {
            this.Errors = new string[] { };
        }

        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("recipients")]
        public int Recipients { get; set; }

        [JsonProperty("errors")]
        public string[] Errors { get; set; }
    }

    public class PushNotification
    {
        public PushNotification()
        {
            this.Tags = new List<Tag>();
        }

        [JsonProperty("app_id")]
        public string AppId { get; set; }

        [JsonProperty("tags")]
        public List<Tag> Tags { get; set; }

        [JsonProperty("contents")]
        public IDictionary<string, string> Contents { get; set; }

        [JsonProperty("data")]
        public Data Data { get; set; }

        [JsonProperty("url")]
        public string Url { get; set; }
    }

    public class Tag
    {
        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("relation")]
        public string Relation { get; set; }

        [JsonProperty("value")]
        public string Value { get; set; }

        [JsonProperty("operator")]
        public string @Operator { get; set; }
    }

    public class Data
    {
        [JsonProperty("balance")]
        public string Balance { get; set; }
    }
}
