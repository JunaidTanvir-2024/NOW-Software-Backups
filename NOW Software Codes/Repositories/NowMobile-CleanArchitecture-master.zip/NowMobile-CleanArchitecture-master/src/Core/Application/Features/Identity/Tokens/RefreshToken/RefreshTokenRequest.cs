namespace Application.Features.Identity.Tokens.RefreshToken;

public class RefreshTokenRequest : IRequest<Result<TokenResponse>>
{
    public string Token { get; set; } = default!;
    public string RefreshToken { get; set; } = default!;

    [JsonIgnore]
    public string? IpAddress { get; set; } = null;
}