﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using ThaPromotionsApi.Infrastructure.BLL;
using ThaPromotionsApi.Models.Contracts.Response;

namespace ThaPromotionsApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class TransferToPromotionsController : ControllerBase
    {

        private readonly ILogger Logger;
        private IPromotions_BL PromotionsBL;

        public TransferToPromotionsController(ILogger logger, IPromotions_BL promotionsBL)
        {
            Logger = logger;
            PromotionsBL = promotionsBL;
        }


        [HttpGet]
        [Route("/api/TransferToPromotions")]
        public async Task<ActionResult> GetTransferToPromotions()
        {

            GenericApiResponse<RSS> response = null;
            try
            {
               
                response = await PromotionsBL.GetTransferToPromotions();

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<RSS>()
                {
                    errorCode = 2,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: TransferToPromotionsController, Method: GetTransferToPromotions, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

    }
}