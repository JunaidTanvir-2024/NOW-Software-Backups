﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Services.Models.ATTApiContracts;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface IATTService
    {
        Task<GetProductResponse> GetProducts(string fromMsisdn, string toMsisdn, string currencyAccount);
        Task<ExecuteDataResponse> Execute(ExecuteDataRequest request);
        Task<TransferCountriesResponse> GetDTOneCountriesAsync(string currency);
        Task<TransferOperatorsByCountryResponse> GetDTOneOperatorsByCountryAsync(string currency, string countryName);
        //Task<TransferOperatorDetailsResponse> GetDTOneOperatorDetailsAsync(string currency, string operatorId);
        Task<TransferOperatorDetailsResponse> GetTransferToOperatorDetailsAsync(string countryName, string operatorName);
    }
}
