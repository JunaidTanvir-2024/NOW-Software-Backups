﻿namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
	public class InternationalTopupTransactionLog
	{
		public string TransactionIdentifier { get; set; }
		public string ProductIdentifier { get; set; }
		public string CustomerIdentifier { get; set; }
		public string ToMsisdn { get; set; }
		public string Currency { get; set; }
		public decimal ProductPrice { get; set; }
		public decimal SalePrice { get; set; }
		public decimal DiscountApplied { get; set; }
		public decimal ServiceFee { get; set; }
		public decimal DiscountOnServiceFee { get; set; }
		public decimal TotalPrice { get; set; }
		public int CheckoutStatus { get; set; }
		public string Message { get; set; }
	}
}
