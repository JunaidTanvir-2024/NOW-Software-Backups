﻿namespace CancelBundleApi.Models.DbModels;

public class MsisdnDetails
{
    public string? Msisdn { get; set; }
    public string? AccountId { get; set; }
    public string? SubscriberId { set; get; }
}