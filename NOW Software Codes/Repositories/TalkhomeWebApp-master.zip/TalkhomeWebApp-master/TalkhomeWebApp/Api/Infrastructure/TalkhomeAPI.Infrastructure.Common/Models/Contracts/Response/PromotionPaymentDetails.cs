﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class PromotionPaymentDetails
    {
        public float ChargeAmount { get; set; }
        public float FullfilmentAmount { get; set; }
    }
}
