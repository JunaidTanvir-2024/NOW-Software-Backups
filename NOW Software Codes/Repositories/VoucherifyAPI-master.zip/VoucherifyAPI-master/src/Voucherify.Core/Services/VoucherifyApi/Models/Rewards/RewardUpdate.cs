using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Rewards;

public class RewardUpdate
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("parameters")]
    public RewardParameters? Parameters { get; set; }

    [JsonPropertyName("stock")]
    public string? Stock { get; set; }

    [JsonPropertyName("attributes")]
    public Metadata? Attributes { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}
