﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.DAL
{
	internal static class StoredProcedures
	{
		public static class AutoTopup
		{
			public const string Get = "THA_Api_GetCustomerAutoTopup";
			public const string Set = "THA_Api_UpdateCustomerAutoTopup";
		}
		public static class AutoRenewal
		{
			public const string Set = "tha_update_user_package_renewal_status_v2";
		}
	}
}
