﻿using Application.Common.Caching;
using Application.Common.Interfaces.Infrastructure;
using Application.Common.Models.Airship;
using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.Account.Profile.UpdateProfileImage;
public class UpdateProfileImageRequestHandler : IRequestHandler<UpdateProfileImageRequest, Result<UserInfo>>
{
    #region Fields

    private readonly IStringLocalizer<UpdateProfileImageRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;
    private readonly ICurrentUser _currentUser;
    private readonly IFileService _fileService;
    private readonly IMapper _mapper;
    private readonly CallBackSettings _callBackSettings;
    private readonly ProfileSettings _profileSettings;
    private readonly ICommonService _commonService;
    private readonly IAirshipService _airshipService;


    #endregion

    #region Ctor

    public UpdateProfileImageRequestHandler(
        IStringLocalizer<UpdateProfileImageRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService,
        ICurrentUser currentUser,
        IFileService fileService,
        ICommonService commonService,
        IAirshipService airshipService,
        IOptions<ProfileSettings> profileSettings,
        IOptions<CallBackSettings> callBackSettings,
        IMapper mapper)
    {

        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _cacheService = cacheService;
        _cacheKeyService = cacheKeyService;
        _currentUser = currentUser;
        _fileService = fileService;
        _mapper = mapper;
        _callBackSettings = callBackSettings.Value;
        _profileSettings = profileSettings.Value;
        _airshipService = airshipService;
        _commonService = commonService;
    }

    #endregion

    public async Task<Result<UserInfo>> Handle(UpdateProfileImageRequest request, CancellationToken cancellationToken)
    {
        var userId = _currentUser.GetUserId();

        //Upload profile image
        string? imageName = null;

        if (request.Image != null)
        {
            var virtualDirectories = _fileService.GetVirtualDirectoriesBySite(_profileSettings.SiteName!);
            // Upload photos on real path - This will upload file on all paths if you have multiple physical paths
            foreach (var domainPath in virtualDirectories.DomainPath)
            {
                // Add condition to upload file at only one place if you have multiple paths
                if (domainPath.VirtualPath!.Equals(_profileSettings.VirtualDirectoryName, StringComparison.InvariantCultureIgnoreCase))
                {
                    var (fileName, isSuccess, errorMessage) = await _fileService.FileUploaderAsync(request.Image, $"{domainPath.PhysicalPath}/{userId}");
                    if (isSuccess)
                    {
                        imageName = fileName;
                    }
                    else
                    {
                        return Result<UserInfo>.Failure(null!, errorMessage, CustomStatusCode.FileUploadedError);
                    }
                }
            }
        }

        (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();
        if (!IsAppRequest)
        {
            await _airshipService.HandleGenericTagsAndEvents(new GenericEventData
            {
                EventName = $"picture_user_dash",
                Value = 0,
                Email = _currentUser.GetUserEmail()!,
                InteractionType = "Dahboard-ProfilePicture",
                TagGroupName = "account"
            });
        }
        //Update profile info
        await _unitOfWork.UserRepo.UpdateProfileImage(userId, imageName!);

        //Clear cahe beacuse user password updated
        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, _currentUser.GetUserEmail()!), cancellationToken);
        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, userId.ToString()), cancellationToken);
        var userProducts = await _unitOfWork.UserRepo.GetUserProducts(userId);
        if (userProducts?.Any() == true)
        {
            foreach (var item in userProducts)
            {
                await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, item.Msisdn!), cancellationToken);
            }
        }

        var user = await _unitOfWork.UserRepo.GetUserByIdAsync(_currentUser.GetUserId());
        var userInfo = _mapper.Map<UserInfo>(user!);
        if (!string.IsNullOrEmpty(user!.Image))
        {
            userInfo.Image = $"{_callBackSettings.WebBaseUrl}{_profileSettings.VirtualDirectoryName}/{user.Id}/{user.Image}";
        }

        return Result<UserInfo>.Success(userInfo, _localizer[CustomStatusKey.Success]);
    }
}