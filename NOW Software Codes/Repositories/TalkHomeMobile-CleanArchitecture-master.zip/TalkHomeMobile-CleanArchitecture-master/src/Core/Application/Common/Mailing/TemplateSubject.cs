﻿
namespace Application.Common.Mailing;
public static class TemplateSubject
{
    public const string ForgetPassword = "Forget Password";
    public const string SignUp = "user SignUp";
    public const string SendFreeSimOrderEmail = "Sim Order Sucess";
    public const string Topup = "Your £{amount} top up was successful";
    public const string Bundle = "Your plan purchase was successful";
    public const string CreditSim = "SIM Order Confirmed: Talk Home Mobile";
    public const string FullfilmentFailed = "Fullfillment Failed";
}
