﻿
namespace Application.Common.Settings;
public class RatingSettings
{
    public const string SectionName = "RatingSettings";
    public static RatingSettings Bind = new RatingSettings();
    public string? ApiUrl { get; set; }
}
