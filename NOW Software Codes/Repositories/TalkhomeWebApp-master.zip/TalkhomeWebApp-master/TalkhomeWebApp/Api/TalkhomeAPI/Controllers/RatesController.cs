﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Services.Interfaces;
using ThmApi.Filters;

namespace TalkhomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RatesController : ControllerBase
    {
        private readonly IRatesService _ratesService;
        private readonly ILogger _logger;

        public RatesController(IRatesService ratesService, ILogger logger)
        {
            _ratesService = ratesService;
            _logger = logger;
        }
        [HttpGet]
        [Route("GetRates")]
        [BasicAuth]
        public async Task<IActionResult> GetRates(string IsoCode)
        {
            try
            {
                return Ok(await _ratesService.GetRates(IsoCode));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: RatesController, Method: GetRates, " +
                              $"Parameters=> model: " + $"{IsoCode}, " +
                              $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
            
        }
    }
}