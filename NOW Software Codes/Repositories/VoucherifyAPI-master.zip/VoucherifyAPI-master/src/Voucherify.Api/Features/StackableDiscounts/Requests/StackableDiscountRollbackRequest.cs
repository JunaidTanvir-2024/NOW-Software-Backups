using FluentValidation;

namespace Voucherify.Api.Features.StackableDiscounts.Requests;

public class StackableDiscountRollbackRequest
{
    public string? RedemptionId { get; set; }
}

internal class StackableDiscountRollbackRequestValidator : AbstractValidator<StackableDiscountRollbackRequest>
{
    public StackableDiscountRollbackRequestValidator()
    {
        RuleFor(p => p.RedemptionId).NotNull().NotEmpty();
    }
}
