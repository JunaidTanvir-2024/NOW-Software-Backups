﻿using Dapper;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.DbConnections;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Repositories
{
    public class BundleRepository : IBundleRepository
    {
        private readonly IDbConnectionSettings TH_Db;
        private readonly IDbConnectionSettings DGT_Db;
        
        public BundleRepository(IOptions<ConnectionString> connectionString)
        {
            TH_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppDbConnection));
            DGT_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigitalkDbConnection));
        }

        public async Task<IEnumerable<BundlesCountries>> GetCountriesByBundle()
        {
            return await TH_Db.SqlConnection.QueryAsync<BundlesCountries>("tha_web_get_bundles_home_country", commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<Bundles>> GetBundleByCountry(string ServiceId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@na_service_id", ServiceId);
            
            return await DGT_Db.SqlConnection.QueryAsync<Bundles>("tha_web_get_compatible_bundles", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<Bundles> GetBundleById(string Id)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@calling_package_id", Id);

            return await DGT_Db.SqlConnection.QueryFirstOrDefaultAsync<Bundles>("tha_web_get_compatible_bundles_by_id", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> BundlePurchaseViaAccountBalance(string accountId, string bundleId)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@account", accountId);
            parameters.Add("@bundle_id", bundleId);
            parameters.Add("@error_code", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 250);

            await DGT_Db.SqlConnection.ExecuteAsync("tha_add_accounts_bundle", parameters, commandType: CommandType.StoredProcedure);

            return parameters.Get<int>("error_code");
        }
    }
}
