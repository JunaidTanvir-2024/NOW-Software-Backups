﻿using Models.Contracts.Request.Rating;
using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface ICustomerRatingService
    {
        public Task<GenericApiResponse<IEnumerable<RatingEvents>>> GetRatingEvents();
        public Task<GenericApiResponse<object>> AddCustomerRating(AddCustomerRatingRequest request);
        public Task<GenericApiResponse<IEnumerable<CustomerRatings>>> GetCustomerRatings(GetCustomerRatingsRequest request);
    }
}
