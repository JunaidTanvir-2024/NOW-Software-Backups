﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBDataHistory
    {
        public string Date { get; set; }
        public string subscriber_charge { get; set; }
        public string MB { get; set; }
    }
}
