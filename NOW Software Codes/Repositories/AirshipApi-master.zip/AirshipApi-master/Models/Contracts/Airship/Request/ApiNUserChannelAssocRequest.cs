﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Request
{
    public class ApiNUserChannelAssocRequest
    {
        [JsonProperty("channel_id")]
        public string ChannelId { get; set; }

        [JsonProperty("named_user_id")]
        public string NamedUserId { get; set; }

        [JsonProperty("device_type")]
        public string DeviceType { get; set; }

        public bool ShouldSerializeDeviceType()
        {
            // don't serialize the DeviceType property if not (ios, android or amazon)
            if (DeviceType == "ios" || DeviceType == "android" || DeviceType == "amazon")
            {
                return true;
            }
            else
            {
                return false;
            }
        }


    }
}
