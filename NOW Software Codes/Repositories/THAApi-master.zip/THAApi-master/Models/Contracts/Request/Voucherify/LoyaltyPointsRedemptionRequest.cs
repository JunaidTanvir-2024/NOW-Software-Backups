﻿namespace Models.Contracts.Request.Voucherify
{
    public class LoyaltyPointsRedemptionRequest
    {
        public string SkuId { get; set; }
    }
}
