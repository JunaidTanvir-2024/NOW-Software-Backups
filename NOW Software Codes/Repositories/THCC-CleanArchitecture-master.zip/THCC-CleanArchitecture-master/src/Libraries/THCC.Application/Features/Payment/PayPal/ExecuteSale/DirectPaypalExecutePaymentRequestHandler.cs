﻿using Newtonsoft.Json;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.PayPal.ExecuteSale
{
    public class DirectPaypalExecutePaymentRequestHandler : IRequestHandler<DirectPaypalExecutePaymentRequest, object>
    {
        private readonly IPaymentService _paymentService;
        private readonly IPaymentRepository _paymentRepository;
        private readonly ILogger _logger;
        private readonly IUserRepository _userRepository;

        public DirectPaypalExecutePaymentRequestHandler(
            IPaymentService paymentService,
            IPaymentRepository paymentRepository,
            ILogger logger,
            IUserRepository userRepository)
        {
            _paymentService = paymentService;
            _paymentRepository = paymentRepository;
            _logger = logger;
            _userRepository = userRepository;
        }

        public async Task<object> Handle(DirectPaypalExecutePaymentRequest request, CancellationToken cancellationToken)
        {
            var orderDetails = await _paymentRepository.GetOrderDetails(null!, request.PaymentId.Trim());
            if (orderDetails?.TransactionId!.Equals(request.PaymentId, StringComparison.InvariantCultureIgnoreCase) != true
                || orderDetails.OrderStatus != OrderStatus.Created)
            {
                _logger.Debug("DirectPaypalExecutePaymentRequestHandler: Invalid resume data: " + JsonConvert.SerializeObject(request));
                return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
            }
            var user = await _userRepository.GetUserByIdAsync(orderDetails.PaymentUserId!);
            return await _paymentService.HandleDirectPaypalExecuteRequest(
                request.PayerId!,
                request.PaymentId!,
                user!.Email!,
                orderDetails.Id);
        }
    }
}
