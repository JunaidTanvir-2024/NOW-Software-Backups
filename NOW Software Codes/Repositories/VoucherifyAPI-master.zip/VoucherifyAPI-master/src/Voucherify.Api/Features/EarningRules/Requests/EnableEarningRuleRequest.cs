using FluentValidation;

namespace Voucherify.Api.Features.EarningRules.Requests;

public class EnableEarningRuleRequest
{
    public string CampaignId { get; set; } = null!;
    public string EarningRuleId { get; set; } = null!;
}
internal class EnableEarningRuleRequestValidator : AbstractValidator<EnableEarningRuleRequest>
{
    public EnableEarningRuleRequestValidator()
    {
        RuleFor(p => p.CampaignId).NotNull().NotEmpty();
        RuleFor(p => p.EarningRuleId).NotNull().NotEmpty();
    }
}