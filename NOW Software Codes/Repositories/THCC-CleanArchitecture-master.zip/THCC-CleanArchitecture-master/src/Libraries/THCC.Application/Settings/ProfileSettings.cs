﻿namespace THCC.Application.Settings;
public sealed class ProfileSettings
{
    public const string SectionName = "ProfileSettings";
    public static ProfileSettings Bind = new ProfileSettings();
    public string? SiteName { get; set; }
    public string? VirtualDirectoryName { get; set; }
}
