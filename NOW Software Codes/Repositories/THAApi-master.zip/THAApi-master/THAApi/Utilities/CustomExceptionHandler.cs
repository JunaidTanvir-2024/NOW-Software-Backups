﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Localization;
using Models.Contracts.Response;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace THAApi.Utilities
{
    public class CustomExceptionHandler
    {
        private readonly RequestDelegate _next;

        public CustomExceptionHandler(RequestDelegate next)
        {
            _next = next;
        }
        public async Task InvokeAsync(HttpContext context, ILogger _logger)
        {
            try
            {
                // Call the next delegate/middleware in the pipeline.
                    context.Request.EnableBuffering();

                await _next(context);
            }
            catch (Exception ex)
            {
                var _localizer = context.RequestServices.GetRequiredService<IStringLocalizer>();
                var controllerName = context.Request.RouteValues["controller"].ToString();
                var actionName = context.Request.RouteValues["action"].ToString();
                // Handle unhandled exceptions
                var serilaizerSetting = new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                    PreserveReferencesHandling = PreserveReferencesHandling.None
                };
                //Need to get the body data also, but make sure no payment sensitive data is lost.
                var bodyContent = string.Empty;
                if (controllerName.Equals("UserAccount", StringComparison.InvariantCultureIgnoreCase) && actionName.Equals("Login", StringComparison.InvariantCultureIgnoreCase))
                {
                    try
                    {
                        context.Request.Body.Position = 0;
                        using (StreamReader reader
                          = new StreamReader(context.Request.Body, Encoding.UTF8, true, 1024, true))
                        {
                            bodyContent = await reader.ReadToEndAsync();
                        }
                    }
                    catch (Exception)
                    {
                        context.Request.Body.Position = 0;
                    }
                }
                var excepMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message;
                var message = $"Controller: {controllerName}, " +
                              $"Method: {actionName}, " +
                              $"Parameters => {JsonConvert.SerializeObject(context.Request.Query, serilaizerSetting)}, " +
                              $"Body => {bodyContent}"+
                              $"StackTrace => {ex.StackTrace}, " +
                              $"ErrorMessage: {excepMessage}";
                _logger.Error(message);
                var response = GenericApiResponse<bool>.Failure(_localizer["SomethingWentWrong"], ApiStatusCodes.CodeException);
                context.Response.StatusCode = 200;
                await context.Response.WriteAsJsonAsync<GenericApiResponse<bool>>(response);
            }
        }
    }
}
