﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Model.EventNotification;
public class FacebookEventData
{
    public string EventName { get; set; } = default!;
    public string ExternalId { get; set; } = default!;
    public string Currency { get; set; } = default!;
    public decimal Value { get; set; } = default!;
    public string PhoneNumber { get; set; } = default!;
    public string Email { get; set; } = default!;
    public string UserAgent { get; set; } = default!;
    public string IpAddress { get; set; } = default!;
}

