namespace MM.Api;

public static class ConfigureMiddlewares
{
    public static WebApplication AddApiMiddlewares(this WebApplication app)
    {
        app.UseSentryTracing();
        app.UseAuthentication();
        app.UseAuthorization();
        app.UseInfrastructureMiddlewares();
        app.MapControllers();
        return app;
    }
}
