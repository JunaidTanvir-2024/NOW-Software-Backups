﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface ISMS_BL
    {
        Task<GenericApiResponse<SMSResponse>> ReSendSMS(String attempt, string msisdn);
        Task<GenericApiResponse<string>> SendReferralCode(Msisdn msisdn, string referrer);
    }
}
