﻿using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using System.Threading.Tasks;

namespace PaymentsApi.Infrastructure.BLL.Interfaces.Pay360
{
    public interface BL_IPay360CommonServices
    {
        Task<GenericApiResponse<ApiPaymentResponse>> RefundFullPayment(UserRequestRefundFullPayment userRequest);
        Task<GenericApiResponse<ApiPaymentResponse>> RefundPartialPayment(UserRequestRefundPartialPayment userRequest);
        Task<GenericApiResponse<UserPaymentMethodsResponse>> GetCustomerPaymentMethodsByCustomerUniqueRef(UserRequestGetCustomerPaymentMethodsByCustomerUniqueRef userRequest);
        Task<GenericApiResponse<UserPaymentMethodsResponse>> GetCustomerPaymentMethodsByCustomerID(string customerID);
        Task<GenericApiResponse<UserPaymentMethodResponse>> SetCustomerDefaultCard(UserRequestUpdateCard userRequest);
        //GenericApiResponse<UserCustomerResponseModels> GetCustomerByMsisdn(string msisdn);
        Task<GenericApiResponse<UserCustomerResponseModels>> GetCustomerByCustomerUniqueRef(UserRequestGetCustomerByCustomerUniqueRef userRequest);
        Task<GenericApiResponse<string>> RemoveCustomerCard(UserRequestRemoveCard userRequest);
        Task<GenericApiResponse<UserTransactionsResponseModel>> GetTransactionsByMerchantRef(string MerchantRef);
        Task<GenericApiResponse<UserTransactionResponseModel>> GetTransactionsByTransactionId(string transactionId);
        Task<GenericApiResponse<ApiPaymentResponse>> CaptureTransaction(UserRequestCaptureOrCancelTransaction userRequest);
        Task<GenericApiResponse<ApiPaymentResponse>> CancelTransaction(UserRequestCaptureOrCancelTransaction userRequest);
        Task<GenericApiResponse<string>> SetAutoTopup_old(UserRequestSetAutoTopup userRequest);
        Task<GenericApiResponse<string>> SetAutoTopup(UserRequestSetAutoTopup userRequest);
        Task<GenericApiResponse<UserResponseGetAutoTopup>> GetAutoTopup_old(UserRequestGetAutoTopup userRequest);        
        Task<object> GetAutoTopup(UserRequestGetAutoTopup userRequest);


    }
}
