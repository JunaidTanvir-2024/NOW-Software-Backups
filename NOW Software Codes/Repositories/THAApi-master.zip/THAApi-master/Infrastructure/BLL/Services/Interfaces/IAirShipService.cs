﻿using Infrastructure.BLL.Services;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Enums;
using Models.Services.Airship;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface IAirShipService
    {
        Task AddNamedUserTags(NamedUserTagsRequest request);
        Task RemoveNamedUserTags(NamedUserTagsRequest request);
        Task AddCustomEvent(CustomEventsRequest request);
        Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress);
        Task AddEmailChannel(string emailAddress);
        Task DisassociateEmailChannelFromNamedUser(string namedUserId, string emailAddress);
        Task AddEmailChannelCommercial(string emailAddress);
        Task RemoveEmailChannelCommercial(string emailAddress);
        Task HandleTopupTagsAndEvents(TopupInfoAirship info);
        Task HandleBundleTagsAndEvents(BundleInfoAirShip info);
        Task HandleIntTopupTagsAndEvents(IntTopupInfoAirShip info);
        Task HandleAutoTopup(string msisdn, bool IsActive);
        Task HandleAutoRenew(string msisdn, bool isActive, string destination, BundleType bundleType);
        Task ReferralRedeemedAirshipEvent(string msisdn, int points);
        Task VoucherifyPointsEarnAirshipEvent(string msisdn, int points);
    }
}
