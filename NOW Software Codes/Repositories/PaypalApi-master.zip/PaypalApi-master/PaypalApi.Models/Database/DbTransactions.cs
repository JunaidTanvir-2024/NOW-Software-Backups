﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Database
{
    public class DbTransactions
    {
        public int Id { get; set; }
        public string Customer_Id { get; set; }
        public string PaypalTransactionId { get; set; }
        public string Currency { get; set; }
        public float Amount { get; set; }
    }
}
