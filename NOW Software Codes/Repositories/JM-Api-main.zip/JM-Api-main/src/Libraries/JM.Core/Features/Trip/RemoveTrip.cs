using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;
namespace JM.Core.Features.Trip;

public abstract class RemoveTrip
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long Id { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Id).NotNull();
        }
    }
    #endregion

    #region Response
    public sealed record Response { }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var trip = await _unitOfWork.TripRepository.GetTrip(x => x.Id.Equals(query.Id));

            if (trip is not null)
            {
                trip.IsDeleted = true;
                trip.IsActive = false;
                _unitOfWork.SaveChanges();

                return ResultWrapper.Success(AppConstant.StatusKey.Success, AppConstant.StatusCode.Success);
            }

            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
    }
    #endregion
}
