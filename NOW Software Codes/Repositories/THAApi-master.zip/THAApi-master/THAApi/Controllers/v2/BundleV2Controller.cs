﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using Models.Enums;
using System.Threading.Tasks;
using THAApi.Utilities;

namespace THAApi.Controllers
{
    [ApiController]
	[ApiVersion("2.0")]
	[Route("v{v:apiVersion}")]
	public class BundleV2Controller : Controller
    {
        private readonly IBundle_BL Bundle_BL;
        public BundleV2Controller(IBundle_BL bundle_BL)
        {
            Bundle_BL = bundle_BL;
        }

        [HttpPost]  
        [Route("bundles/setautorenewal")]
        public async Task<IActionResult> SetBundleAutoRenewalV2([FromBody] SetBundleAutoRenewalRequestModel request)
        {
            return Ok(await Bundle_BL.SetBundleAutoRenewalV2(request.AutoRenewal, User.Msisdn(), request.BundleId, User.Email()));
        }

		[HttpPost]
		[Route("bundles/purchase/{id}")]
		public async Task<IActionResult> PurchaseBundle(string id, [FromBody] PurchaseBundleRequest request)
		{
			string advertiserID = HttpContext.GetAdvertiserID();
			DeviceType deviceType = (DeviceType)request.DeviceType;
			return Ok(await Bundle_BL.PurchaseBundleV2(request.AppsFlyerId, deviceType, advertiserID, User.Msisdn(), id, request.IsBundleAutoRenew, User.Email()));
		}
    }
}
