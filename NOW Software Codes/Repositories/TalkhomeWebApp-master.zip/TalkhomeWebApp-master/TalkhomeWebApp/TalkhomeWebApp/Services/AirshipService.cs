﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.AirShip;
using TalkhomeWebApp.Models.Configurations;

namespace TalkhomeWebApp.Services
{
    public interface IAirshipService
    {
        bool IsActive { get; }
        string PaymentTagGroupName { get; }
        string CustomerTagGroupName { get; }
        string ActivityTagGroupName { get; }
        string TransactionTagGroupName { get; }
        string ServiceTagGroupName { get; }
        Task AssociateNamedUserWeb(string channelId, string msisdn);
        Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress);
        Task AddEmailChannel(string emailAddress);
        Task AddNamedUserTags(NamedUserTagsRequest data);
        Task RemoveNamedUserTags(NamedUserTagsRequest request);
        Task AddCustomEvent(CustomEventsRequest data);
        Task AddEmailChannelCommercial(string emailAddress);
        Task RemoveEmailChannelCommercial(string emailAddress);
        Task DisassociationNamedUserFromWebChannel(string namedUserId, string channelId);
    }

    public class AirshipService : IAirshipService
    {
        private readonly AirshipConfig _airShipConfig;
        public bool IsActive { get; }
        public string PaymentTagGroupName { get; }
        public string CustomerTagGroupName { get; }
        public string ActivityTagGroupName { get; }
        public string TransactionTagGroupName { get; }
        public string ServiceTagGroupName { get; }

        public AirshipService(IOptions<AirshipConfig> airShipConfig)
        {
            _airShipConfig = airShipConfig.Value;
            IsActive = airShipConfig.Value.IsActive;
            PaymentTagGroupName = airShipConfig.Value.PaymentTagGroupName;
            CustomerTagGroupName = airShipConfig.Value.CustomerTagGroupName;
            ActivityTagGroupName = airShipConfig.Value.ActivityTagGroupName;
            TransactionTagGroupName = airShipConfig.Value.TransactionTagGroupName;
            ServiceTagGroupName = airShipConfig.Value.ServiceTagGroupName;
        }

        public async Task AssociateNamedUserWeb(string channelId, string msisdn)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "NamedUser/Channel/WebAssociation")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        ChannelId = channelId,
                        NamedUserId = msisdn,
                        ProductCode = "THA"
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "NamedUser/EmailAssociationWithNamedUser")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        EmailAddress = emailAddress,
                        NamedUserId = namedUserId,
                        ProductCode = "THA"
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task AddEmailChannel(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THA"
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task AddEmailChannelCommercial(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THA",
                        commercialOptedIn = DateTime.UtcNow
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task RemoveEmailChannelCommercial(string emailAddress)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = "THA",
                        commercialOptedOut = DateTime.UtcNow
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DisassociationNamedUserFromWebChannel(string namedUserId, string channelId)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "NamedUser/Channel/Disassociation")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        ChannelId = channelId,
                        NamedUserId = namedUserId,
                        DeviceType = 4,
                        ProductCode = "THA"
                    }), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task AddNamedUserTags(NamedUserTagsRequest data)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "NamedUser/AddNuserTags")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task RemoveNamedUserTags(NamedUserTagsRequest data)
        {
            if (!_airShipConfig.IsActive)
                return;

            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "NamedUser/RemoveNuserTags")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        public async Task AddCustomEvent(CustomEventsRequest data)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _airShipConfig.ApiEndpoint + "CustomEvent/AddCustomEvent")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json")
                };

                using var client = new HttpClient();

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
