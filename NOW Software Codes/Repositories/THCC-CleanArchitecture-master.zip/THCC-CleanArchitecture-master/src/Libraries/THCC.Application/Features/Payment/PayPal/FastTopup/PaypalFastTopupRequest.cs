﻿using THCC.Application.Interfaces.Services;
using THCC.Application.Settings;

namespace THCC.Application.Features.Payment.PayPal.FastTopup
{
    public class PaypalFastTopupRequest : IRequest<object>
    {
        public string? EmailAddress { get; set; }
        public decimal Amount { get; set; }
        public string CardNumber { get; set; } = default!;
    }

    public class FastTopupRequestValidator : AbstractValidator<PaypalFastTopupRequest>
    {
        public FastTopupRequestValidator(
            IOptions<TopupSettings> topupSettings,
            ICommonService commonService)
        {
            RuleFor(p => p.Amount).Cascade(CascadeMode.Stop)
              .NotEmpty()
              .NotNull()
              .Must(x => topupSettings.Value.Amounts.Any(a => a.Amount == x))
              .WithMessage("Please only use: " + string.Join(",", values: topupSettings.Value.Amounts.Select(a => a.Amount)));

            RuleFor(p => p.CardNumber)
                 .NotEmpty()
                 .NotNull()
                 .MaximumLength(20);

            RuleFor(p => p.EmailAddress)
                .NotNull()
                .NotEmpty()
                .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
                .Must(p => commonService.IsValidEmailAddress(p)).WithMessage("Invalid Email Address")
                .When(p => p.EmailAddress != null);
        }
    }
}
