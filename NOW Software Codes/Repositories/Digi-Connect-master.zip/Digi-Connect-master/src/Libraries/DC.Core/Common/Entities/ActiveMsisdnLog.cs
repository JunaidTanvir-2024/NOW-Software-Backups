
namespace DC.Core.Common.Entities;

public sealed record ActiveMsisdnLog
{
    public string SimState { get; set; }
    public DateTime SimStateUpdated { get; set; }
    public string Msisdn { get; set; }
    public string Account { get; set; }
    public DateTime CreatedOn { get; set; }
    public string CreatedBy { get; set; }
    public string Cadence { get; set; }
    public string SmsStatus { get; set; }
    public string Product { get; set; }

}
