namespace Application.Features.Rate.Model;

public class InternationalRate
{
    public int CountryId { get; set; }
    public string? IsoCode { get; set; }
    public string? Destination { get; set; }
    public string? Landline { get; set; }
    public string? Mobile { get; set; }
    public string? Sms { get; set; }
    public string? LandlineStandard { get; set; }
    public string? MobileStandard { get; set; }
    public string? SmsStandard { get; set; }
    public string? CountryCode { get; set; }
    public string? PhoneCode { get; set; }
    public bool? IsBundleExist { get; set; }
}