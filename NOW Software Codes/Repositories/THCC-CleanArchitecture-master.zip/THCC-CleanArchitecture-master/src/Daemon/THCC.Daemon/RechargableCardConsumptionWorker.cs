﻿

using THCC.Application.Interfaces.Services.Tracking;

namespace THCC.Daemon
{
    public class RechargableCardConsumptionWorker : BackgroundService
    {
        private readonly ILogger<RechargableCardConsumptionWorker> _logger;
        private readonly IServiceScopeFactory _serviceProvider;

        public RechargableCardConsumptionWorker(
            ILogger<RechargableCardConsumptionWorker> logger,
            IServiceScopeFactory serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using var scope = _serviceProvider.CreateScope();
                    var callingCardService = scope.ServiceProvider.GetRequiredService<ICallingCardConsumptionService>();
                    await callingCardService.RechargeableCardConsumptionAndCallJob();
                }
                catch (Exception ex)
                {
                    _logger.LogError("RechargableCardConsumptionWorker, " +
                                     "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                     "StackTrace: " + ex.StackTrace);
                }
                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
        }
    }
}