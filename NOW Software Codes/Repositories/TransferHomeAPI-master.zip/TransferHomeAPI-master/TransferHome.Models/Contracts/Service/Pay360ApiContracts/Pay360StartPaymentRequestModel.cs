﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.Service.Pay360ApiContracts
{
    public class Pay360StartPaymentRequestModel
    {
        public CardRequestModel UserCard { get; set; }
        [Required]
        public Pay360PaymentType Pay360PaymentType { get; set; }
        [Required]
        public CheckOutTypes CheckoutPaymentType { get; set; }
        public int UserId { get; set; }
        [Required]
        public decimal Amount { get; set; }
        [Required]
        public string Currency { get; set; }
        public string CustomerPhoneNumber { get; set; }
        public string CustomerEmail { get; set; }
        public bool AutoTopUp { get; set; }
        [Required]
        public string IPAddress { get; set; }
        [Required]
        public ExecuteDataRequest TransferTransaction { get; set; }
    }

    public class CardRequestModel
    {
        [Required]
        public string NameOnCard { get; set; }
        [Required]
        public string CardNumber { get; set; }
        [Required]
        public string ExpiryMonth { get; set; }
        [Required]
        public string ExpiryYear { get; set; }
        [Required]
        public string SecurityCode { get; set; }
        [Required]
        public string Token { get; set; }
    }
}
