﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using Models.Enums;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using THAApi.Utilities;

namespace THAApi.Controllers
{
    [ApiController]
    public class BundleController : Controller
    {
        private readonly IBundle_BL Bundle_BL;
        public BundleController(IBundle_BL bundle_BL)
        {
            Bundle_BL = bundle_BL;
        }

        [HttpPost]
        [Route("databundle/product")]
        public async Task<IActionResult> GetDataBundleProduct(DataBundle request)
        {
            return Ok(await Bundle_BL.GetDataBundlesProducts(User.Msisdn(), request.recipientNumber));
        }

        [HttpGet]
        [Route("TopBundles")]
        public async Task<IActionResult> TopBundles()
        {
            return Ok(await Bundle_BL.GetuserTopBundles(User.Msisdn()));
        }


        [HttpPost]
        [Route("bundles/setautorenewal")]
        public async Task<IActionResult> SetBundleAutoRenewal([FromBody] SetBundleAutoRenewalRequestModel request)
        {
            return Ok(await Bundle_BL.SetBundleAutoRenewal(request.AutoRenewal, User.Msisdn(), request.BundleId, User.Email()));
        }
        
        [HttpPost]
        [Route("bundles/purchase/{id}")]
        public async Task<IActionResult> PurchaseBundle(string id, [FromBody] PurchaseBundleRequest request)
        {
            string advertiserID = HttpContext.GetAdvertiserID();
            DeviceType deviceType = (DeviceType)request.DeviceType;
            return Ok(await Bundle_BL.PurchaseBundle(request.AppsFlyerId,deviceType, advertiserID, User.Msisdn(), id, request.IsBundleAutoRenew, User.Email()));
        }

        [HttpGet]
        [Route("bundles/{id}")]
        public async Task<IActionResult> Get(string id)
        {
            return Ok(await Bundle_BL.Get(User.Msisdn(), id));
        }

        [HttpPost]
        [Route("bundles/validate")]
        public async Task<IActionResult> ValidateBundle([FromQuery] ValidateBundleRequest request)
        {
            return Ok(await Bundle_BL.ValidateBundle(User.Account(), request.BundleId.ToString(CultureInfo.InvariantCulture)));
        }
    }
}
