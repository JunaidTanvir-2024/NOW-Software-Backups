﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class GetFavouriteTransactionNumbersResponseModel
    {
        public IEnumerable<FavouriteTransactionNumber> Numbers { get; set; }
    }
    public class FavouriteTransactionNumber
    {
        public string Msisdn { get; set; }
        public bool IsFrequent { get; set; }
        public bool isfrequent { get; set; }
    }
}
