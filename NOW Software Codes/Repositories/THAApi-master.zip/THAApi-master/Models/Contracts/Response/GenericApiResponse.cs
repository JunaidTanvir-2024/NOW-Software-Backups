﻿using Models.Contracts.Response;
using Models.Enums;

namespace Models.Contracts.Response
{
    public class GenericApiResponse<T>
    {
        public string Message { get; set; }
        public string Status { get; set; }
        public int ErrorCode { get; set; }
        public T Payload { get; set; }
        public static GenericApiResponse<T> Success(T payload, string message, string status = "Success")
        {
            return new GenericApiResponse<T>
            {
                ErrorCode = 0,
                Status = status,
                Message = message,
                Payload = payload
            };
        }
        public static GenericApiResponse<T> Success(string message, string status = "Success", int errorCode = 0)
        {
            return new GenericApiResponse<T>
            {
                ErrorCode = errorCode,
                Status = status,
                Message = message
            };
        }
        public static GenericApiResponse<T> Failure(string message, ApiStatusCodes errorCode, string status = "Failure")
        {
            return new GenericApiResponse<T>
            {
                ErrorCode = (int)errorCode,
                Status = status,
                Message = message
            };
        }

        public static GenericApiResponse<T> Failure(T payload, string message, ApiStatusCodes errorCode, string status = "Failure")
        {
            return new GenericApiResponse<T>
            {
                ErrorCode = (int)errorCode,
                Status = status,
                Message = message,
                Payload = payload
            };
        }


        //public void GenerateToken(IConfiguration configuration)
        //{
        //    throw new NotImplementedException();
        //}

        //public static GenericApiResponse<LoginResponseModel> Failure(string v)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
