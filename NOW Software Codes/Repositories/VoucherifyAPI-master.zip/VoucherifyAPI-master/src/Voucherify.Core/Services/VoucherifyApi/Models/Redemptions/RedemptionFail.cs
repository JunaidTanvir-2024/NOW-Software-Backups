﻿namespace Voucherify.Core.Services.VoucherifyApi.Models.Redemptions;

public class RedemptionFail
{

}
