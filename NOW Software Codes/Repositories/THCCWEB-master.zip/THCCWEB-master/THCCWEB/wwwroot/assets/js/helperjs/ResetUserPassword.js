﻿
$("#resetForm").validate({
    rules: {

        NewPassword: {
            required: true,
            minlength: 8
        },
        ConfirmPassword: {
            required: true,
            equalTo: "#NewPassword",
            minlength: 8
        },
        Email: {
            required: true
        }
       
    },
    messages: {
        NewPassword: {
            required: "Enter New password",
            minlength: "Must be between 8 and 50 characters"
        },
        ConfirmPassword: {
            required: "Enter Confirm New password",
            minlength: "Must be between 8 and 50 characters",
            equalTo: "Confirm Password doesn't match, Type again !"
        },
        Email: {
            required: "Please provide an Email"
        }
    },
});
$("#resetForm").on("submit", function () {
    if ($("#resetForm").valid() !== true) {
        return;
    }
    else {
        var model = {};
        model.NewPassword = $("#NewPassword").val();
        model.Email = $("#Email").val();
        $.ajax({
            type: "POST",
            url: "/UpdateUserPassword",
            data: model,
            async: false,
            success: function (json) {
                if (json && json.errorCode > 0 ) {
                    $("#emailErrorDiv").text(json.key)
                } else if (json && json.errorCode == 0) {
                    window.location.href = "/success/" + json.key
                }
            },
            error: function (error) {
                var a = error;
                alert("Error: " + a.responseText);
            }
        });
    }
    return false;
});