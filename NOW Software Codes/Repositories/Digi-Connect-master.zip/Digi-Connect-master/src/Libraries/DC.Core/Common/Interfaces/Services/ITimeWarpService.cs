using DC.Core.Common.DependencyResolver;

namespace DC.Core.Common.Interfaces.Services;

public interface ITimeWarpService : ServiceType.IScoped
{
    DateTime UtcNow { get; }
}
