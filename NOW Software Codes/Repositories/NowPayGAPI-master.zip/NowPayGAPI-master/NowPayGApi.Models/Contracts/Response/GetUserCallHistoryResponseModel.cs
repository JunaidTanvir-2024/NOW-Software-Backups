﻿using NowPayGApi.Models.DAOs.Digitalk;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetUserCallHistoryResponseModel
    {
        public IEnumerable<DbCallingHistory> CallingHistory { get; set; }
        public int CallingHisotryTotalRecords { get; set; }
    }
}
