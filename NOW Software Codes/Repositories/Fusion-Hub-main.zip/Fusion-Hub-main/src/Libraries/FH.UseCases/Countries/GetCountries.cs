using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;
using RW.Models;


namespace FH.UseCases.Countries;
public sealed class GetCountries
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public int Page { get; set; }
		public int RecordsPerPage { get; set; }
		public CountryFilter? CountryFilters { get; set; }
		public sealed record CountryFilter
		{
			public string? CountryName { get; set; }
			public string? CountryCallingCode { get; set; }
			public string? IsoCode2 { get; set; }
			public string? IsoCode3 { get; set; }
		}
	}

	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.Page).GreaterThan(0);
			RuleFor(x => x.RecordsPerPage).LessThan(101);
		}
	}
	#endregion

	#region Response
	public sealed record Response
	{
		public long CountryId { get; set; }
		public string? IsoCode2 { get; set; }
		public string? IsoCode3 { get; set; }
		public int CallingCode { get; set; }
		public string? CountryName { get; set; }
		public int IsoNumericCode { get; set; }
		public string? Continent { get; set; }
		public string? CountryLogo { get; set; }
	}

	#endregion

	#region Handler
	public sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IMapper _mapper = mapper;
		private readonly IUnitOfWork _unitOfWork = unitOfWork;

		public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
		{
			var getCountryRequest = _mapper.Map<CountryDto.Request>(request);

			// Assigning Default Values
			getCountryRequest.IsActive = true;
			getCountryRequest.IsDeleted = false;

			(IEnumerable<CountryDto.Response> countries, DatabasePaginationDto pagination) = await _unitOfWork.CountryRepository.GetCountries(getCountryRequest);

			if (countries is null)
			{
				ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
			}

			var getCountriesResponse = _mapper.Map<List<Response>>(countries!);

			return ResultWrapper.Success(getCountriesResponse, new Pagination(TotalCount: pagination.TotalRecords, PageCount: pagination.TotalPages, CurrentPage: request.Page, PageSize: request.RecordsPerPage));
		}
	}
	#endregion
}
