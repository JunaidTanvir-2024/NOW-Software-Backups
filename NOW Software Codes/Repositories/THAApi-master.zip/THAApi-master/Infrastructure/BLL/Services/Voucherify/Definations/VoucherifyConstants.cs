namespace Infrastructure.BLL.Services.Voucherify.Definations
{
    public sealed class VoucherifyConstants
    {
        private VoucherifyConstants() { }

        public static class Endpoints
        {
            public const string Customers = "/api/customers/";
            
            public const string CustomerInvitationCode = "/api/customers/invitationCode";
            
            public const string CustomersLoyaltyCard = "/api/customers/loyaltyCard";
            
            public const string Campaigns = "/api/campaigns/";
            public const string Vouchers = "/api/vouchers/";

            public const string Promotions = "/api/promotions/";
            public const string ValidatePromotion = "/api/promotions/validate";

            public const string Loyalties = "/api/loyalties/";
            public const string LoyaltyRewards = "/api/loyalties/rewards";

            public const string RedeemStackableDiscounts = "/api/discounts/redeem";
            public const string ValidateStackableDiscounts = "/api/discounts/validate";
            public const string RollbackStackableDiscounts = "/api/discounts/rollback";

            public const string Products = "/api/products/";
            public const string ProductSKUs = "/api/products/skus/";

            public const string EarningRules = "/api/earningRules/";

            public const string VoucherifyEvents = "/api/events/";
        }
    }
}
