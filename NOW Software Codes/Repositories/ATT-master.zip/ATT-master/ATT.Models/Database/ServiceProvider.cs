﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Database
{
    public class ServiceProvider
    {

        public int DefaultServiceProviderID { get; set; }
        public int DefaultServiceProviderDataBundles { get; set; }
        public int OriginDestinationId { get; set; }

    }
}
