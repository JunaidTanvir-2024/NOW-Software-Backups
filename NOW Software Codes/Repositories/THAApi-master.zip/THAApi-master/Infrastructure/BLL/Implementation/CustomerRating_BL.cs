﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Models.Contracts.Request;
using Models.Contracts.Request.Rating;
using Models.Contracts.Response;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class CustomerRating_BL: ICustomerRating_BL
    {
        private readonly ICustomerRatingService _ratingService;
        public CustomerRating_BL(ICustomerRatingService ratingService)
        {
            _ratingService = ratingService;
        }

        public async Task<IEnumerable<RatingEvents>> GetRatingEvents()
        {
            var response=await _ratingService.GetRatingEvents();
            if(response.ErrorCode==0)
            {
                return response.Payload;
            }
            else
            {
                return null;
            }
        }

        public async Task<GenericApiResponse<object>> AddCustomerRating(Models.Contracts.Request.AddCustomerRatingRequest request,string msisdn, string email=null)
        {
            var APIRequest = new Models.Contracts.Request.Rating.AddCustomerRatingRequest()
            {
                CustomerRating = request.CustomerRating,
                RatingEvent = request.RatingEvent,
                TotalRating = request.TotalRating,
                RatingSource=Models.Enums.RatingSources.APP,
                Email = email,
                MSISDN = msisdn
            };
            var response = await _ratingService.AddCustomerRating(APIRequest);
            return response;
        }
        public async Task<GenericApiResponse<IEnumerable<CustomerRatings>>> GetCustomerRatings(string msisdn, string productCode, string email = null)
        {
            var APIRequest = new GetCustomerRatingsRequest()
            {
                Email = email,
                MSISDN = msisdn,
                productCode = productCode
            };

            var response= await _ratingService.GetCustomerRatings(APIRequest);
            return response;

            //return GenericApiResponse<IEnumerable<CustomerRatings>>.Success(new List<CustomerRatings>(),"");
        }
    }
}
