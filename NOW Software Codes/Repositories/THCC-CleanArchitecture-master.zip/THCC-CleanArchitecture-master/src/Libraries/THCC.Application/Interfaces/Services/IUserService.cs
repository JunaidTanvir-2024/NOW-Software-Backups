using Microsoft.AspNetCore.Identity;

using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Services;

public interface IUserService : ServiceType.IScoped
{
    Task<LoginInfoDto> LoginAsync(User user, string password, bool lockoutOnFailure);
    Task<SignUpInfoDto> SignUpAsync(string firstname, string lastname, string email, string password, string role, bool isConfirmedUser);
    Task<LoginInfoDto> SocialLoginAsync(User user, string providerKey, SocialLoginType loginprovider);
    Task<SignUpInfoDto> SocialSignUpAsync(
            string? userId,
            string? firstname,
            string? lastname,
            string email,
            SocialLoginType type);
    Task<bool> VerifyPasswordAsync(User user, string password);
    Task<IdentityResult?> ChangePasswordAsync(User appUser, string newPassword, string oldpassword);
    Task<SignUpInfoDto> UpdateUserAsync(User user, string firstname, string lastname, string password, bool isConfirmedUser);
    Task<SignUpInfoDto> SendGuestUserOtp(string userId);
    Task<IdentityResult?> AddPasswordAsync(User appUser, string password);
}
