﻿using System;


namespace ATT.Models.Contracts.Sochitel.Response
{
    public class GetTransactionResponse
    {
        public int id { get; set; }                    //ARTX transaction ID
        public IDName productType { get; set; }        // Product type contains product id and  product name
        public string userReference { get; set; }     //User reference ID (only if set by the user in the request)
        public OperatorInfo @operator { get; set; }     //Object containing operator’s details
        public Status status { get; set; }              //Object containing transaction status
        public DateTime date { get; set; }              // Date of the transaction
        public OperatorUserString amount { get; set; }        // object containing amount
        public OperatorUserString currency { get; set; }        // object containing currency
        public Channel channel { get; set; }                   // // object containing channel detail
        public IDName country { get; set; }        // object containing country id and name
        public string note { get; set; }           // Transaction’s note (if set in the request)

        // Extra Parameters ---- Depending on the transaction productType , variable extra parameters can be set in the response.

        public string msisdn { get; set; }           // Phone number ----- Extra parameters for Mobile Top Up and Mobile Data products
        public Pin pin { get; set; }             //Only for Mobile PIN products. Object containing PIN’s details
        public string accountid { get; set; }   // Account ID ---Extra parameters for Bill Payment products:
    }

    public class Status
    {
        public int id { get; set; }              // Status ID
        public string name { get; set; }         // Status description
        public int type { get; set; }            // Status Type id
        public string typeName { get; set; }     // Status type name
    }
    public class Channel
    {       
        public string channel { get; set; }         // Channel’s name
        public int reference { get; set; }            // Channel’s reference ID        
    }
}
