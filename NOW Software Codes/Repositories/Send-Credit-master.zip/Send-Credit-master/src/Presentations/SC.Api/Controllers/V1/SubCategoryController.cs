﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SC.Core.Features.Products;
using SC.Core.Features.Products.Requests;

namespace SC.Api.Controllers.V1;

public class SubCategoryController : BaseApiController
{
    [AllowAnonymous]
    [HttpPost]
    public async Task<ActionResult> GetSubCategories(GetSubCategory Model)
    {
        var result = await Mediator.Send(new GetSubCategoriesRequest()
        {
            CategoryAliasName = Model.CategoryAliasName,

        });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}

