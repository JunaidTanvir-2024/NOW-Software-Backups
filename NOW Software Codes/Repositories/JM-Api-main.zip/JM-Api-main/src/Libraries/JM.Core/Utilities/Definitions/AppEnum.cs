using System.ComponentModel.DataAnnotations;

namespace JM.Core.Utilities.Definitions;

public static class AppEnum
{
    public enum VendorType
    {
        Google = 1,
        Apple = 2
    }
    public enum OtpType
    {
        Signup = 1,
        Forget = 2
    }
    public enum LoginProvider
    {
        Google = 1,
        Apple = 2
    }

    public enum OrderByDirection
    {
        Ascending = 1,
        Descending = 2
    }
    public enum TripType
    {
        All = 1,
        Personal = 2,
        Shared = 3
    }
    public enum SubscriptionType
    {
        CloudStorage = 1,
        AdsFree = 2
    }

    public enum SubscriptionUnitType
    {
        GigaBytes = 1,
        Advertisement = 2
    }

    public enum AdsFreeExperience
    {
        Partial = 1,
        Full = 2
    }
    public enum CurrencyUnit
    {
        [Display(Name = "$")]
        Dollar = 1
    }
    public enum MediaType
    {
        Picture = 1,
        Videos = 2
    }
    public enum FriendshipStatus
    {
        Pending = 1,
        Accepted = 2,
        Rejected = 3,
        Blocked = 4
    }
}
