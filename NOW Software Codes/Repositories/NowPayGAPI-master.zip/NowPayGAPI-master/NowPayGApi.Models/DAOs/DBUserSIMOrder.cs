﻿using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBUserSIMOrder
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int UserAddessId { get; set; }
        public ProductType Product { get; set; }
        public bool IsReplacement { get; set; }
        public DateTime OrderDateTime { get; set; }
        public bool IsDispatched { get; set; }
        public DateTime? DispatchDateTime { get; set; }
        public string DispatchedByName { get; set; }

        //UserInfo
        public string FirstName { get; set; }
        public string LastName { get; set; }

        //AddressInfo
        public string City { get; set; }
      
    }
}
