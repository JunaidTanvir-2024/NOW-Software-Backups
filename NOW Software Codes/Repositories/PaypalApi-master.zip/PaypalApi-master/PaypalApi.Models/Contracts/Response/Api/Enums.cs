﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Contracts.Response.Api
{

    public enum TransactionStates
    {
        Created = 1,
        Approved = 2,
        Completed = 3
    }

    public enum TransactionIntent
    {
        Sale = 1,
        Authorize = 2        
    }

    
}
