﻿using Newtonsoft.Json;
namespace THCC.Infrastructure.Services.Tracking.AirShip.Models
{
    public class AirShipEmailChannelModel
    {
        public AirShipChannel Channel { get; set; } = new AirShipChannel();
    }

    public class AirShipChannel
    {
        [JsonProperty("opt_in")]
        public bool OptIn { get; set; }
    }
}
