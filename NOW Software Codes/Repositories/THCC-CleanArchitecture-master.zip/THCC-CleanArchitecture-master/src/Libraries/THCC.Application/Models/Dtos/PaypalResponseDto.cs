﻿namespace THCC.Application.Models.Dtos
{
    public class PaypalResponseDto
    {
        public PaymentResponse? PaymentResponse { get; set; }
    }
}
