﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    
    public enum PushAudienceType
    {
        All = 1,
        NamedUser = 2,
        Channel = 3,
        Tag = 4,
        TagGroup = 5
    }
}
