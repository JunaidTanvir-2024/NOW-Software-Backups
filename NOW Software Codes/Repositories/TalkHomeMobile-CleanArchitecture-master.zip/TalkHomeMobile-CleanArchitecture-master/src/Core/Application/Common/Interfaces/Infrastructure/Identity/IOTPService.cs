﻿using Application.Common.Extensions.DependencyResolver;
using Application.Common.Models;
using Application.Common.Models.ResponseWrappers;

namespace Application.Common.Interfaces.Infrastructure.Identity;

public interface IOtpService : IServicesType.ITransientService
{
    Task<(int Otp, OTPModel result)> CreateOtp(string uniqueIdentifier, OtpType type, bool? isEmail);
    Task<DbResult> IsValidOtp(string uniqueIdentifier, int otp, OtpType type);
    Task<DbResult> VerifyOtp(int otp, string uniqueRef, OtpType type, bool? isEmail);
}