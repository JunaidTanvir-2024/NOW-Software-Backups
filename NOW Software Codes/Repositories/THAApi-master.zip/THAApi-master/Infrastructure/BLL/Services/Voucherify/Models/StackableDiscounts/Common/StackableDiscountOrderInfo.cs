﻿using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common
{
    public class StackableDiscountOrderInfo
    {
        public long? Amount { get; set; }
        public string SkuId { get; set; }
        public int? Quantity { get; set; }
        public Metadata Metadata { get; set; }
        
    }
}
