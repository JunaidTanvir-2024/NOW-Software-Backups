﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Serilog;
using System;
using System.Globalization;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class SMS_BL : ISMS_BL
    {
        private readonly IStringLocalizer Localizer;
        private readonly ISMS_DL SMS_DL;
        private readonly IUserAccount_DL UserAccount_DL;
        private readonly ISapSmsService SapSmsService_BL;
        private readonly IConfiguration Config;
        private const string TalkHomeSMSFrom = "TALK HOME";
        public SMS_BL(
            ISapSmsService sapSmsService_BL, 
            IConfiguration config, 
            IUserAccount_DL userAccount_DL, 
            IStringLocalizer localizer,
            ISMS_DL sms_DL)
        {
            Localizer = localizer;
            SMS_DL = sms_DL;
            SapSmsService_BL = sapSmsService_BL;
            UserAccount_DL = userAccount_DL;
            Config = config;
        }
        public async Task<GenericApiResponse<SMSResponse>> ReSendSMS(String attempt, string msisdn)
        {

            GenericApiResponse<SMSResponse> response = new GenericApiResponse<SMSResponse>();
            SMSResponse pload = new SMSResponse();

            try
            {
                var count = await SMS_DL.CountSMSResend(msisdn);
                if (count >= 2)
                {
                    pload.responseCode = false;
                    pload.Message = Localizer["YouexceededthemessageCount"];
                    pload.statuscode = 4;
                    response.Payload = pload;
                    response.Status = "failed";
                    response.Message = Localizer["YouexceededthemessageCount"];
                    return response;
                }

                var userAccountPin = await UserAccount_DL.GetUserAccountPin(msisdn);


                if (string.IsNullOrEmpty(userAccountPin))
                {
                    pload.responseCode = false;
                    pload.Message = Localizer["InvalidAccount"];
                    pload.statuscode = 3;
                    response.Payload = pload;
                    response.Status = "success";
                    response.Message = Localizer["SuccessfullysentthePIN"];
                    return response;

                }

                var outgoingMessage = Localizer["SignUpMessage", userAccountPin];
                //var smsRespone=await smsService1.Send(TalkHomeSMSFrom, msisdn.Trim(), outgoingMessage, false);
                var smsRespone = await SapSmsService_BL.Send(TalkHomeSMSFrom, msisdn.Trim(), outgoingMessage, false);
                pload.responseCode = smsRespone.Success;

                if (smsRespone.Success)
                {
                    await SMS_DL.UpdateSMSResend(msisdn);

                    pload.Message = Localizer["SuccessfullySent"];
                    pload.statuscode = 1;
                    response.Payload = pload;
                    response.Status = "success";
                    response.Message = Localizer["SuccessfullysentthePIN"];
                }
                else
                {
                    pload.Message = Localizer["SMSsentfailed"];
                    pload.statuscode = 2;
                    response.Payload = pload;
                    response.Status = "failed";
                    response.Message = Localizer["FailedtosendPIN"];
                }
                return response;
            }
            catch (Exception)
            {
                response.Status = "failed";
                response.Message = Localizer["FailedtosendPIN"];
                return response;
            }
        }
        
        public async Task<GenericApiResponse<string>> SendReferralCode(Msisdn msisdn, string referrer)
        {
            //get the refferal code
            GenericApiResponse<string> response = new GenericApiResponse<string>();

            var refferalcode = await UserAccount_DL.GetReferralCode(referrer);

            if (string.IsNullOrEmpty(refferalcode))
            {
                response.Payload = "Referral Code! , Not Found";
                response.Status = "Failure";
                response.Message = "Failure";

                return response;
            }

            string message = response.Message = Localizer["GetReferralContent",refferalcode];

            string validityPeriod = Config["sms_referral_validity"].ToString(CultureInfo.InvariantCulture);
            string op = Config["sms_referral_operator"].ToString(CultureInfo.InvariantCulture);
            int max_sms_count = int.Parse(Config["sms_referral_maxsmscount"].ToString(CultureInfo.InvariantCulture));


            foreach (string MobileNo in msisdn.msisdns)
            {
                int sms_count = await UserAccount_DL.SaveReferralSMSs(referrer, MobileNo, message);

                if (sms_count <= max_sms_count)
                {
                    var smsRespone = await SapSmsService_BL.Send(TalkHomeSMSFrom, MobileNo, message, false);
                    //await LocalSMSService.Send(referrer, MobileNo, message, validityPeriod, op);
                }


            }
            response.Payload = "Referral Code!! Sucessfully Sent";
            response.Status = "Success";
            response.Message = "Success";

            return response;


        }

    }
}
