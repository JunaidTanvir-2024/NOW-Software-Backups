﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ViewModels.Account
{
    public class UpdateUserInfoViewModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool? IsSubscribedToNewsletter { get; set; }
        public string AccountNumber { get; set; }
    }
}
