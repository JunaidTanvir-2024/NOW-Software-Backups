﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Request;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Status = Models.Enums.Status;

namespace Infrastructure.DAL.Implementation
{
    public class Push_DL : IPush_DL
    {
        private ILogger _logger;
        private readonly ConnectionStrings _dbConnections;

        public Push_DL(
            IOptions<ConnectionStrings> dbConnections,
            ILogger logger)
        {
            _dbConnections = dbConnections.Value;
            _logger = logger;
        }

        /// <summary>
        /// Get Push Registration
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<PushRegistration> GetPushRegistration(string msisdn)
        {
            try
            {
                var start = DateTime.Now;

                IEnumerable<PushRegistration> reg = new List<PushRegistration>();

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    reg = await dbConnection.QueryAsync<PushRegistration>(@"
                        select msisdn, gcm, apns, pushKit, sandbox, version, language from tha_push_registrations(nolock) where msisdn = @msisdn",
                    new { msisdn = msisdn });
                }

                return reg.Count() == 1 ? reg.First() : null;
            }
            catch (Exception ex)
            {
                _logger.Error("GetPushRegistration Failed:" + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Set Push Registration
        /// </summary>
        /// <param name="registration"></param>
        /// <returns></returns>
        public async Task<bool> SetPushRegistration(PushRegistration registration)
        {
            try
            {
                var start = DateTime.Now;
                //await connection.OpenAsync();

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    var result = await dbConnection.ExecuteAsync(@"
                    delete from tha_push_registrations where msisdn = @msisdn;
                    insert into tha_push_registrations (msisdn, gcm, apns, pushKit, sandbox, version, language)
                        values (@msisdn, @gcm, @apns, @pushKit, @sandbox, @version, @language)",
                        registration);

                    return result > 0;
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Push_DL, Method: SetPushRegistration, Parameters=> {JsonConvert.SerializeObject(registration)}, ErrorMessage: {errorMessage}");
                return false;
            }
        }

        /// <summary>
        /// Get FCM Token
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericResult<string>> GetFCMToken(string msisdn)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                string result = string.Empty;

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    result = await dbConnection.QueryFirstOrDefaultAsync<string>("tha_fcm_api_getToken", parameters, commandType: CommandType.StoredProcedure);
                }

                if (result == null)
                {
                    return new GenericResult<string>() { Data = null, Status = Status.Failure, ErrorCode = 1, ErrorMessage = "Data Not Available" };
                }
                else
                {
                    return new GenericResult<string>() { Data = result, Status = Status.Success, ErrorCode = 0, ErrorMessage = "" };
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Push_DL, Method: GetFCMToken, Parameters=> msisdn: {msisdn}, ErrorMessage: {errorMessage}");
                return new GenericResult<string> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }
        }

        /// <summary>
        /// Get APNS Token
        /// </summary>
        /// <param name="msisdn"></param>
        /// <returns></returns>
        public async Task<GenericResult<APNSToken>> GetAPNSToken(string msisdn)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);

                APNSToken result = new APNSToken();

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppsAccountsDb))
                {
                    result = await dbConnection.QueryFirstOrDefaultAsync<APNSToken>("tha_apns_api_getToken", parameters, commandType: CommandType.StoredProcedure);
                }

                if (result == null)
                {
                    return new GenericResult<APNSToken>() { Data = null, Status = Status.Failure, ErrorCode = 1, ErrorMessage = "Data Not Available" };
                }
                else
                {
                    return new GenericResult<APNSToken>() { Data = result, Status = Status.Success, ErrorCode = 0, ErrorMessage = "" };
                }
            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Push_DL, Method: GetFCMToken, Parameters=> msisdn: {msisdn}, ErrorMessage: {errorMessage}");
                return new GenericResult<APNSToken> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }
        }

    }
}
