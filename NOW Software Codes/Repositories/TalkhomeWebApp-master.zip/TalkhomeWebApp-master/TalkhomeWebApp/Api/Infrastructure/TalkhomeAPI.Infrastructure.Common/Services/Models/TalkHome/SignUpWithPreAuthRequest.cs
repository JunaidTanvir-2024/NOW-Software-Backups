﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome
{
    public class SignUpWithPreAuthRequest
    {
        public string msisdn { get; set; }
        public AppInfo appInfo { get; set; }
        public string productCode { get; set; } = "THA";
        public string productItemCode { get; set; } = "THAWeb";
    }
}
