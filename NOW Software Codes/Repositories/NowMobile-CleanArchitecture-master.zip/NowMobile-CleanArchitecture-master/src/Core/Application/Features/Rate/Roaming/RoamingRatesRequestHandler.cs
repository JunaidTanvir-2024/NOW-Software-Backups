﻿using Application.Common.Interfaces;
using Application.Features.Rate.Model;


namespace Application.Features.Rate.Roaming;
public class RoamingRatesRequestHandler : IRequestHandler<RoamingRatesRequest, Result<RoamingRate>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<RoamingRatesRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;

    public RoamingRatesRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<RoamingRatesRequestHandler> localizer,
        IMapper mapper, ICommonService commonService)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
        _commonService = commonService;
    }

    public async Task<Result<RoamingRate>> Handle(RoamingRatesRequest request, CancellationToken cancellationToken)
    {
        var rates = await _uow.RateRepo.GetRoamingRates(request.FromCountryCode,request.ToCountryCode);
        if (rates!=null)
        {
        rates.IsEU= _commonService.IsEUCountry(rates.IsoCode);

        }
        return Result<RoamingRate>.Success(rates!, _localizer[CustomStatusKey.Success]);
    }
}
