﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using TalkhomeWebApp.Utilities;
using Microsoft.Extensions.Options;
using TalkhomeWebApp.Models.Configurations;
using Newtonsoft.Json.Linq;
using TalkhomeWebApp.Models;
using TalkhomeWebApp.Models.ApiContracts.Request;
using TalkhomeWebApp.Utilities.Extension;
using TalkhomeWebApp.Models.ApiContracts.Response;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using System.Linq;
using System.Text;
using TalkhomeWebApp.Services;

namespace TalkhomeWebApp.Controllers
{
    public class PayPalController : BaseController
    {
        private readonly ILogger _logger;
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly EndPoints _endpoints;
        private readonly IAirshipService _airshipService;
		private readonly ApiClient _apiClient;

		public PayPalController(ILogger logger,
            IOptions<EndPoints> Endpoints,
            IAirshipService airshipService,
            IOptions<BasicAuthConfig> basicAuthConfig,
            IHelperService helperService,
            ApiClient apiClient) : base(logger, helperService)
        {
            _logger = logger;
            _basicAuthConfig = basicAuthConfig.Value;
            _endpoints = Endpoints.Value;
            _airshipService = airshipService;
			this._apiClient = apiClient;
		}

        [Route("paypalstartpayment")]
        [ValidateAntiForgeryToken]
        [HttpPost]
        public async Task<IActionResult> PayPalStartPayment(PayPalStartPaymentRequest model)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    if (string.IsNullOrEmpty(model.Msisdn))
                    {
                        ModelState.Remove("Msisdn");
                        model.Msisdn = User.Claims.First(i => i.Type == "phone_number").Value;
                    }
                }

                if (model.CheckoutPaymentType == CheckOutTypes.FastTopup)
                {
                    model.CheckoutPaymentType = CheckOutTypes.TopUp;
                }

                if (!ModelState.IsValid) { return BadRequest(); };

                String encodedToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var payPalResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                                                "Payment/PaypalPayment", User, ApiCallType.BasicAuth, new PaypalPaymentRequestModel()
                                                {
                                                    EmailAddress = model.EmailAddress,
                                                    ipAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext),
                                                    TopUpAmount = model.Amount,
                                                    BundleId = model.BundleId,
                                                    CheckoutType = model.CheckoutPaymentType,
                                                    BundleType = model.BundleType,
                                                    FromBundleISO2 = model.FromBundleISO2,
                                                    ToBundleISO2 = model.ToBundleISO2,
                                                    Msisdn = model.Msisdn
                                                }, basicauthtoken: encodedToken);

                if (payPalResponse.IsSuccessStatusCode)
                {
                    var payPalResponseJson = JObject.Parse(payPalResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = payPalResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payPalData = payPalResponseJson.GetValue("payload").ToObject<PaypalPaymentResponseModel>();

                        return Redirect(payPalData.clientRedirectUrl);
                    }
                    else
                    {
                        //Need to handle error code values
                        return HandleErrorResponse<PayPalStartPaymentRequest>(model, errorCode,
                            payPalResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (payPalResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PayPalController, Method: StartPaypalPayment, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("paypalpaymentcallback")] //Direct Paypal
        public async Task<IActionResult> PayPalPaymentCallBack(PaypalPaymentCallBackRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid) { return BadRequest(); };

                model.IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext);

                String encodedToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var payPalResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                                    "Payment/PaypalPaymentCallBack", User, ApiCallType.BasicAuth, model, basicauthtoken: encodedToken);
                TempData.Put("PaymentMethod", "Paypal");

                if (payPalResponse.IsSuccessStatusCode)
                {
                    var payPalResponseJson = JObject.Parse(payPalResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = payPalResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var purchaseInfo = payPalResponseJson.GetValue("payload").ToObject<PaypalPaymentCallBackResponseModel>();

                        if (model.type == CheckOutTypes.Bundle)
                        {
                            TempData.Put("BundlePurchaseInfo", purchaseInfo.bundlePurchaseInfo);

                            return RedirectToAction("SuccessMessage", "Home", new { key = "BundlePurchaseSuccessful" });
                        }
                        else
                        {
                            TempData.Put("TopupInfo", purchaseInfo.topupInfo);

                            return RedirectToAction("SuccessMessage", "Home", new { key = "TopupSuccessful" });
                        }
                    }
                    else
                    {
                        return HandleErrorResponse<PaypalPaymentCallBackRequestModel>(model, errorCode,
                                payPalResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (payPalResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PayPalController, Method: PayPalPaymentCallBack, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("paypalbypay360paymentcallback")] //Paypal By Pay360
        public async Task<object> PaypalByPay360PaymentCallBack(PaypalByPay360PaymentCallBackRequestModel model)
        {
            try
            {
                ModelState.Remove("BundleType");
                if (!ModelState.IsValid) { return BadRequest(); };

                model.IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext);

                String encodedToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var payPalResponse = await _apiClient.CallApi(_endpoints.TalkHomeAPIEndPoint +
                                    "Payment/PaypalByPay360PaymentCallBack", User, ApiCallType.BasicAuth, model, basicauthtoken: encodedToken);

                if (payPalResponse.IsSuccessStatusCode)
                {
                    var payPalResponseJson = JObject.Parse(payPalResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = payPalResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var purchaseInfo = payPalResponseJson.GetValue("payload").ToObject<PaypalByPay360PaymentCallBackResponseModel>();

                        if (model.type == CheckOutTypes.Bundle)
                        {
                            purchaseInfo.bundlePurchaseInfo.BundleType = model.BundleType;
                            TempData.Put("BundlePurchaseInfo", purchaseInfo.bundlePurchaseInfo);
                            return RedirectToAction("SuccessMessage", "Home", new { key = "BundlePurchaseSuccessful" });
                        }
                        else
                        {
                            TempData.Put("TopupInfo", purchaseInfo.topupInfo);

                            return RedirectToAction("SuccessMessage", "Home", new { key = "TopupSuccessful" });
                        }
                    }
                    else
                    {
                        return HandleErrorResponse<PaypalByPay360PaymentCallBackRequestModel>(model, errorCode,
                                payPalResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (payPalResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PayPalController, Method: PaypalByPay360PaymentCallBack, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("paypalpaymentcancel")]
        public IActionResult PayPalPaymentCancel(PaypalPaymentRequestModel model)
        {
            return HandleErrorResponse<PaypalPaymentRequestModel>(model, (int)ApiStatusCodes.PaymentCreationFailed_PayPal);
        }
    }
}