﻿using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Orders;

namespace Voucherify.Core.Services.VoucherifyApi.Models.StackableDiscounts;

public class Redeemable
{
    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("object")]
    public string? Object { get; set; }

    [JsonPropertyName("order")]
    public Order? Order { get; set; }

    [JsonPropertyName("applicable_to")]
    public ApplicableTo? ApplicableTo { get; set; }

    [JsonPropertyName("inapplicable_to")]
    public ApplicableTo? InapplicableTo { get; set; }

    [JsonPropertyName("result")]
    public ResultInfo? Result { get; set; }

    public class ResultInfo
    {
        [JsonPropertyName("loyalty_card")]
        public LoyaltyCard? LoyaltyCard { get; set; }
        [JsonPropertyName("discount")]
        public Discount? DiscountInfo { get; set; }
        [JsonPropertyName("error")]
        public VoucherifyError? VoucherifyError { get; set; }
    }
}


