using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Rewards;

public class RewardParameters
{
    [JsonPropertyName("product")]
    public MaterialReward? Product { get; set; }

    [JsonPropertyName("campaign")]
    public CampaignReward? Campaign { get; set; }

    [JsonPropertyName("coin")]
    public CoinReward? Coin { get; set; }
}

public class MaterialReward
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }
    [JsonPropertyName("balance")]
    public string? Balance { get; set; }
}
public class CampaignReward
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }
    [JsonPropertyName("sku_id")]
    public string? SkuId { get; set; }
}
public class CoinReward
{
    [JsonPropertyName("exchange_ratio")]
    public double ExchangeRatio { get; set; }

    [JsonPropertyName("points_ratio")]
    public long PointsRatio { get; set; }
}