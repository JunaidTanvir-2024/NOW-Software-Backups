namespace Voucherify.Api.Features.StackableDiscounts.Common;

public class ApplicableOrder
{
    public long? Amount { get; set; }
    public long? DiscountAmount { get; set; }
    public long? AmountOff { get; set; }
    public double? PercentOff { get; set; }
    public double? UnitOff { get; set; }
    public string? UnitType { get; set; }
    public string? DiscountEffect { get; set; }
    public string? DiscountType { get; set; }
    public long? AmountLimit { get; set; }
    public IEnumerable<ApplicableOrderItems>? Items { get; set; }
    public class ApplicableOrderItems
    {
        public string? ProductId { get; set; }
        public string? SkuId { get; set; }
        public long? SkuPrice { get; set; }
    }
}