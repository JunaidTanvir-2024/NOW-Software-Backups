﻿using BasketWebPanel.Areas.Dashboard.Models.ApiResponse;
using BasketWebPanel.Areas.Dashboard.Models.ApiResponse.Admin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using BasketWebPanel.ViewModels;
using BasketWebPanel.Areas.Dashboard.Models;
using BasketWebPanel.Areas.Dashboard.ViewModels;
using BasketWebPanel.Areas.Dashboard.Models.ApiRequest.Plans;
using BasketWebPanel.Areas.Dashboard.Models.ApiRequest;

namespace BasketWebPanel.Areas.Dashboard.Controllers
{
    public class SimOrderController : Controller
    {
        // GET: Dashboard/SimOrder
        public ActionResult ManageOrder()
        {
            try
            {
                var claimIdentity = ((ClaimsIdentity)User.Identity);
                GetALlOrderResponseModel GetOrder = new GetALlOrderResponseModel();
                GetOrder.SetSharedData(User);
                // return Json(AddPlan.Plans);
                //return View(GetPlans);
                return View(GetOrder);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<ActionResult> GetOrders()
        {
            try
            {
                GetALlOrderResponseModel GetAllOrders = new GetALlOrderResponseModel();

                var OrderResponse = await ApiCall.CallApi("api/CommonServices/GetOrders", User, null, true);
               var Orders = OrderResponse.GetValue("payload").ToObject<GetALlOrderResponseModel>();
                GetAllOrders.orderList = Orders.orderList;
                return Json(GetAllOrders, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<int> DispatchOrder(int Id)
        {
            IdModel model = new IdModel()
            {
                Id = Id,

            };
            try
            {
                GetALlOrderResponseModel GetAllOrders = new GetALlOrderResponseModel();

                var OrderResponse = await ApiCall.CallApi("api/Admin/DispatchOrder", User, model, false);
                var Orders = OrderResponse.GetValue("payload").ToObject<bool>();
                if (Orders == true)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<ActionResult> ViewOrder(int Id)
        {
            IdModel model = new IdModel()
            {
                Id = Id,

            };
            try
            {
                GetALlOrderResponseModel GetAllOrders = new GetALlOrderResponseModel();

                var OrderResponse = await ApiCall.CallApi("api/Admin/ViewOrder", User, model, false);
                var Orders = OrderResponse.GetValue("payload").ToObject<GetALlOrderResponseModel>();
                GetAllOrders.orderList = Orders.orderList;
                return Json(GetAllOrders, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}