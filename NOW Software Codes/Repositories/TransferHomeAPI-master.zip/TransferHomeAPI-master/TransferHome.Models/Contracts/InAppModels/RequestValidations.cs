﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Text;

namespace TransferHome.Models.Contracts.InAppModels
{
    public class RequestValidations
    {
        /// <summary>
        /// Gets the list of countries based on ISO 3166-1
        /// </summary>
        /// <returns>Returns the list of countries.</returns>
        private static List<RegionInfo> GetListOfCountries()
        {
            List<RegionInfo> countries = new List<RegionInfo>();
            foreach (CultureInfo culture in CultureInfo.GetCultures(CultureTypes.SpecificCultures))
            {
                RegionInfo country = new RegionInfo(culture.LCID);
                if (countries.Where(p => p.Name == country.Name).Count() == 0)
                    countries.Add(country);
            }
            return countries.OrderBy(p => p.EnglishName).ToList();
        }

        /// <summary>
        /// Validates Address Line 1
        /// </summary>
        /// <param name="addressLine1">The input string</param>
        /// <returns>The validation result</returns>
        public static ValidationResult AddressLine1(string addressLine1)
        {
            if (string.IsNullOrWhiteSpace(addressLine1))
                return new ValidationResult("");
            else
                return ValidationResult.Success;
        }

        /// <summary>
        /// Validates City
        /// </summary>
        /// <param name="addressLine1">The input string</param>
        /// <returns>The validation result</returns>
        public static ValidationResult City(string city)
        {
            if (string.IsNullOrWhiteSpace(city))
                return new ValidationResult(("Please Enter A City").ToString());
            else
                return ValidationResult.Success;
        }

        /// <summary>
        /// Validates Country code
        /// </summary>
        /// <param name="countryCode">The input string</param>
        /// <returns>The validation result</returns>
        public static ValidationResult CountryCode(string countryCode)
        {
            var Countries = GetListOfCountries();

            if (string.IsNullOrWhiteSpace(countryCode))
                return new ValidationResult(("").ToString());

            foreach (var country in Countries)
                if (countryCode.Equals(country.TwoLetterISORegionName))
                    return ValidationResult.Success; // Better to return a success early, as soon as a country code match is found

            return new ValidationResult(("").ToString());
        }

        /// <summary>
        /// Validates Post code
        /// </summary>
        /// <param name="postCode">The input string</param>
        /// <returns>The validation result</returns>
        public static ValidationResult PostCode(string postCode)
        {
            if (string.IsNullOrWhiteSpace(postCode))
                return new ValidationResult(("").ToString());
            else
                return ValidationResult.Success;
        }

        /// <summary>
        /// Validates Email address
        /// </summary>
        /// <param name="email">The input string</param>
        /// <returns>The validation result</returns>
        public static ValidationResult Email(string email)
        {
            if (string.IsNullOrEmpty(email))
                return new ValidationResult(("").ToString());
            else
                return ValidationResult.Success;
        }

        /// <summary>
        /// Validates Salutation
        /// </summary>
        /// <param name="salutation">The input string</param>
        /// <returns>The validation result</returns>
        public static ValidationResult Salutation(string salutation)
        {
            if (string.IsNullOrEmpty(salutation))
                return new ValidationResult(("").ToString());
            else
                return ValidationResult.Success;
        }


    }
}
