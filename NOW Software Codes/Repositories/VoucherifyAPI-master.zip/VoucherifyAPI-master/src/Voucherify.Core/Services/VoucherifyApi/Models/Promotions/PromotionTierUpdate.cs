using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Promotions;

public class PromotionTierUpdate
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("banner")]
    public string? Banner { get; set; }

    [JsonPropertyName("action")]
    public PromotionTierAction? Action { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}
