﻿using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Requests
{
    public class UpdatePromotionRequest
    {
        public string PromotionId { get; set; }

        public string Name { get; set; }

        public string Banner { get; set; }

        public long? AmountOff { get; private set; }

        public double? PercentOff { get; private set; }

        public double? UnitOff { get; private set; }

        public string UnitType { get; private set; }

        public string Category { get; set; }

        public string CategoryId { get; set; }

        public Metadata Metadata { get; set; }
    }
}
