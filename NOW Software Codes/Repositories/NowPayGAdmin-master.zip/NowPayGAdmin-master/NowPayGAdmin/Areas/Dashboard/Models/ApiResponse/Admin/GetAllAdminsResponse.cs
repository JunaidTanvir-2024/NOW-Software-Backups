﻿using BasketWebPanel.Areas.Dashboard.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models.ApiResponse.Admin
{
    public class GetAllAdminsResponse
    {
        public IEnumerable<BasketWebPanel.Areas.Dashboard.Models.Admin> AdminsList { get; set; }
    }
}