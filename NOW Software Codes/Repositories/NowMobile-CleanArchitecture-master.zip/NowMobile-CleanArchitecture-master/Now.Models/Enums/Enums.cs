﻿

namespace  Now.Models.Enums;

public enum DbStatus
{
    Success = 1,
    Failure = 2
}
public enum ProductCode
{
    NOWPAYG
}
public enum PaymentType
{
    Card = 1,
    Paypal = 2,
    Balance,
    Voucher
}

public enum CreditSimType
{
    Topup = 1,
    Bundle = 2,
    TopupBundle = 3
}

public enum EmailsType
{
    WhyAndBenefits = 1,
    NotActivatedSim = 2,
    NotToppedUp = 3,
    OtherServicesEmail = 4,
    SocialMediaEmails = 5
}

public enum SimOrderType
{
    FreeSim = 1,
    CreditSim
}

public enum SimStauts
{
    Unprovisioned = 1,
    Dormant = 2,
    FirstUseActive = 3,
    Active = 4,
    Restricted = 5,
    Suspended = 6,
    Expired = 7,
    Disconnected = 8
}
public enum MediumType
{
    Web = 1,
    Android = 2,
    IOS = 3
}