﻿namespace THCC.Domain.Entities
{
    public class OrderHistory
    {
        public long Id { get; set; }
        public long OrderId { get; set; }
        public string? Description { get; set; }
        public DateTime DateTime { get; set; }
    }
}