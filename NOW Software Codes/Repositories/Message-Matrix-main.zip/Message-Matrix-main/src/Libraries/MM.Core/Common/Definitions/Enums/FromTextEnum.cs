using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MM.Core.Common.Definitions.Enums;
public enum FromTextEnum
{
    TransHome = 1,
    TRH = 2,
    TalkHome
}
