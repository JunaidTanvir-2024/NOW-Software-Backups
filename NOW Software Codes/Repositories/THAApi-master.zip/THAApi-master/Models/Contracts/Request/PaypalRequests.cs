﻿using Models.Contracts.Request.Voucherify;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
	public class RefundFullPaymentRequestModel
	{
		public string transactionId { get; set; }
	}
	public class PaypalPaymentRequestModel
    {
        public decimal TopUpAmount { get; set; }
        public string BundleId { get; set; }
        //public AppsFlyerInfo AppsFlyerInfo { get; set; }
        public UtmParamsInfo UtmParamsInfo { get; set; }
        public Enums.CheckOutTypes CheckoutType { get; set; }
        public string AppsFlyerId { get; set; }
        public bool AirshipEventsDisable { get; set; }
        public int DeviceType { get; set; }
    }
    public class PaypalPaymentRequestModelV2: PaypalPaymentRequestModel
    {
        public string DiscountCode { get; set; }
        public DiscountCodeType DiscountCodeType { get; set; }
    }


	public class PaypalByPay360PaymentCallBackRequestModel
    {
        public string Token { get; set; }

        public Enums.CheckOutTypes CheckoutType { get; set; }
        public ThemeMode ThemeMode { get; set; }

        public string BundleId { get; set; }
        public decimal TopupAmount  { get; set; }

        public string Msisdn { get; set; }
        public string Email { get; set; }
        public int PTId { get; set; }
        public string IpAddress { get; set; }

        //Apps Flyer
        public int DeviceType { get; set; }
        public string AppsFlyerId { get; set; }

        //Utm Params
        public string UtmCampaign { get; set; }
        public string UtmMedium { get; set; }
        public string UtmSource { get; set; }

        // FaceBook
        public string advertiserID { get; set; }
        public bool AirshipEventsDisable { get; set; }
    }
    public class PaypalByPay360PaymentCallBackRequestModelV2: PaypalByPay360PaymentCallBackRequestModel
    {
        public string DiscountCode { get; set; }
        public DiscountCodeType DiscountCodeType { get; set; }
    }
}
