using System.Data;

using Dapper;

using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;

using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

using Serilog;

namespace FH.Infrastructure.Persistence.Repositories;

internal sealed class CategoryRepository(IConfiguration configuration, ILogger logger) : ICategoryRepository
{
    private readonly IConfiguration _configuration = configuration;
    private readonly ILogger _logger = logger;

    public async Task<IEnumerable<SubCategoryDto.Response>> GetSubCategoryName(SubCategoryDto.Request request)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var subCategoryParameters = new DynamicParameters();
                subCategoryParameters.Add("is_active", request.IsActive);
                subCategoryParameters.Add("is_deleted", request.IsDeleted);
                subCategoryParameters.Add("category_name_alias", request.CategoryAliasName);
                var subCategories = await connection.QueryAsync<SubCategoryDto.Response>(AppConstants.Database.StoreProcedure.SubCategoryGet, subCategoryParameters, commandType: CommandType.StoredProcedure);
                return (subCategories);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(CategoryRepository), methodName: nameof(GetSubCategoryName));
            return default!;
        }
    }
}
