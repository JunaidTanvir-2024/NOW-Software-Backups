﻿namespace THCC.Application.Models.Dtos;

public class RatesDto
{
    public string? Country { get; set; }
    public string? CountryISOCode { get; set; }
    public double LandlineRatePerMin { get; set; }
    public double MobileRatePerMin { get; set; }
}
