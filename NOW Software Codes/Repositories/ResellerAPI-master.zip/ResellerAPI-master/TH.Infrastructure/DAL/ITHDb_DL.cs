﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TH.Models.Database;

namespace TH.Infrastructure.DAL
{
    public interface ITHDb_DL
    {
        Task<Customer> CustomerDetails(string msisdn);
        Task<DbResult<string>> SetPrimarySIMState(string msisdn, int state, string username);
        Task<PurchaseResult> Purchase(string msisdn, string bundleref, decimal amount, string transactionid);
        Task<List<Plans>> GetPlans();
        Task<List<AccountPlans>> GetAccountPlans(string msisdn);
        Task<DbResult<string>> TopupVoucher(string msisdn, string pin);
        Task<List<TopupHistory>> GetTopupHistory(string msisdn);
        Task<User> Login(string userName, string password);
    }
}
