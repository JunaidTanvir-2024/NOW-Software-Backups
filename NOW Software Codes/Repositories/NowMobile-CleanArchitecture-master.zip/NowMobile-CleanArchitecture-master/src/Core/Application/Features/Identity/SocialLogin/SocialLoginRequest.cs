﻿
using Application.Common.Models;

namespace Application.Features.Identity.SocialLogin;
public class SocialLoginRequest : IRequest<Result<SocialLoginResponse>>
{
    public AppInfo? AppInfo { get; set; }
    public AppleLoginModel? AppleLogin { get; set; }
    public string AccessToken { get; set; } = default!;
    public SocialLoginType? SocialLoginType { get; set; }
    [JsonIgnore]
    public string? IpAddress { get; set; }
}
