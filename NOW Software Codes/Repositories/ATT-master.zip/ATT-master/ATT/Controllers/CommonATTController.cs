﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ATT.Infrastructure.BLL.Common;
using ATT.Infrastructure.BLL.Ding;
using ATT.Infrastructure.BLL.Reloady;
using ATT.Infrastructure.BLL.Sochitel;
using ATT.Infrastructure.BLL.TransferTo;
using ATT.Infrastructure.DAL;
using ATT.Models.Configurations;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Common;
using ATT.Models.Contracts.TransferTo.Response;
using ATT.Models.Database;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using ServiceProvider = ATT.Models.Contracts.Common.ServiceProvider;

namespace ATT.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CommonATTController : ControllerBase
    {
        private ITransfertoPost_BL _TransferToPost;
        private ILogger _loggerAPIAccess;
        private IAttDb_DL _appDB;
        private ISochitelAutomation_BL _SochiTelAutomation;
        private ITransfertoAutomation_BL _TransfertoAutomation;
        private IReloadlyPost_BL _reloadlyPost_BL;
        private IDingPost_BL _dingPost_BL;
        private ITransfertoAuth_BL TransferToAuth;
        private TransferToConfig TransferToConf;
        private readonly SmtpConfig SmtpConfig;
        private ICommon_BL _common_BL;

        public CommonATTController(ITransfertoPost_BL post, ILogger appLoggers, IAttDb_DL appDB, ICommon_BL common_BL, ITransfertoAutomation_BL transfertoAutomation, ISochitelAutomation_BL sochiTelAutomation, IReloadlyPost_BL reloadlyPost_BL, IDingPost_BL dingPost_BL, ITransfertoAuth_BL transferToAuth, IOptions<TransferToConfig> transferToConf, IOptions<SmtpConfig> smpt)
        {
            _TransferToPost = post;
            _loggerAPIAccess = appLoggers;
            _appDB = appDB;
            _TransfertoAutomation = transfertoAutomation;
            _SochiTelAutomation = sochiTelAutomation;
            _reloadlyPost_BL = reloadlyPost_BL;
            TransferToAuth = transferToAuth;
            _dingPost_BL = dingPost_BL;
            TransferToConf = transferToConf.Value;
            SmtpConfig = smpt.Value;
            _common_BL = common_BL;
        }

        [HttpGet]
        [Route("GetATTCRMOperatorRates")]
        public async Task<IActionResult> GetATTCRMOperatorRates(int serviceproviderid, string destinationMSISDN, string account, string productID)
        {
            /// transfer to have too implement gereric
            try
            {
                string toNumber = destinationMSISDN.Replace("+", "");
                toNumber = toNumber.StartsWith("00") == true ? toNumber.Remove(0, 2) : toNumber;
                if (serviceproviderid == 3) //Ding
                {
                    var result = await _dingPost_BL.DingATTCRMGetPhoneOperator(account, destinationMSISDN);
                    //  result.ATTCRMpayload.operators.ForEach(x => x.id = "-1");
                    return Ok(result);
                }
                else if (serviceproviderid == 4) //Reloadly
                {
                    var result = await _reloadlyPost_BL.ReloadlyATTCRMGetPhoneOperator(account, toNumber, productID);
                    //result.payload?.operators.ForEach(x => x.id = "-1");
                    //return Ok(result);
                    return Ok(result);
                }
                else  // Use TransferTo
                // Isrange right now is false for transferTo
                {
                    if (productID.ToLower().Equals("trhivr"))
                    {
                        var result = await _TransfertoAutomation.transferToATTCRMFreeSwitchGetOperatorProductsMSISDN(destinationMSISDN, account);
                        return Ok(result);
                    }
                    // Have to implement for THA and others later
                    else
                    {
                        // in case of 30 account is different so have to pass from msisdn later will implement 
                        var result = await _TransfertoAutomation.transferToATTCRMDirectGetOperatorProductsMSISDN(null, destinationMSISDN, account, productID);
                        return Ok(result);
                    }
                }
            }
            catch (Exception ex)
            {

                _loggerAPIAccess.Debug($" ATTController, \"GET /GetATTCRMOperatorRates\"  Failed  Source:General  Parameters-serviceproviderid {serviceproviderid}  destinationMSISDN {destinationMSISDN} currency:{account}    Message:{ex.ToString()}");
                var errorResult = new { errorCode = 2, status = "Failure", message = ex.Message };
                JsonOperatorProductResponse respone = new JsonOperatorProductResponse();
                respone.status = errorResult.status;
                respone.message = errorResult.message;
                respone.errorCode = errorResult.errorCode;
                return Ok(respone);

            }
        }

        [HttpGet]
        [Route("GetOperatorProducts")]
        public async Task<IActionResult> GetOperatorProducts(string destinationMSISDN, string account, string fromMSISDN, string productCode, string productItemCode, string ProductId, int serviceProviderNumber = 1)
        {
            try
            {
                string toNumber = destinationMSISDN.Replace("+", "");
                toNumber = toNumber.StartsWith("00") == true ? toNumber.Remove(0, 2) : toNumber;

                Comm_ATT_DestinationServiceProvider serviceProviderRecord = await _appDB.Com_ATT_GetServiceProvider(fromMSISDN, toNumber, ProductId);
                if (serviceProviderRecord != null)
                {

                    RoutingInfo routingInfo = GetRoutingInfo(serviceProviderRecord, serviceProviderNumber);

                    if (routingInfo.ServiceProviderId == 2) //transferto
                    {
                        var result = await _TransfertoAutomation.CRM_ATT_transferToDirectGetOperatorProductsMSISDN(fromMSISDN, account, toNumber, serviceProviderRecord.Id, productCode, productItemCode, ProductId, routingInfo.CarrierNumber);
                        if (result.errorCode > 0 && routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.CRM_ATT_UpdateServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else if (routingInfo.ServiceProviderId == 3) //Ding
                    {
                        var result = await _dingPost_BL.Com_ATT_DingGetPhoneOperator(fromMSISDN, account, toNumber, serviceProviderRecord.Id, productCode, productItemCode, ProductId, routingInfo.CarrierNumber);
                        if (result.payload != null)
                        {
                            foreach (var _operator in result.payload.operators)
                            {
                                _operator.routingType = (int)serviceProviderRecord.TypeOfRouting;
                                _operator.routingTypeName = ((RoutingType)serviceProviderRecord.TypeOfRouting).ToString();
                            }
                        }
                        if (result.errorCode > 0 && routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.CRM_ATT_UpdateServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else if (routingInfo.ServiceProviderId == 4) //Reloadly
                    {
                        var result = await _reloadlyPost_BL.Com_ATT_ReloadlyGetPhoneOperator(fromMSISDN, account, toNumber, serviceProviderRecord.Id, productCode, productItemCode, ProductId, routingInfo.CarrierNumber);
                        if (result.payload != null)
                        {
                            foreach (var _operator in result.payload.operators)
                            {
                                _operator.routingType = (int)serviceProviderRecord.TypeOfRouting;
                                _operator.routingTypeName = ((RoutingType)serviceProviderRecord.TypeOfRouting).ToString();
                            }
                        }
                        if (result.errorCode > 0 && routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.CRM_ATT_UpdateServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else  // Use TransferTo
                    {
                        var result = await _TransfertoAutomation.CRM_ATT_transferToDirectGetOperatorProductsMSISDN(fromMSISDN, account, toNumber,null, productCode, productItemCode, ProductId, -1);
                        return Ok(result);
                    }
                }
                else // Use TransferTo
                {
                    var result = await _TransfertoAutomation.CRM_ATT_transferToDirectGetOperatorProductsMSISDN(fromMSISDN, account, toNumber, null, productCode, productItemCode, ProductId, -1);
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {

                _loggerAPIAccess.Debug($" CommonATTController, \"GET /GetOperatorProducts\"  Failed  Source:General  Parameters => destinationMSISDN: {destinationMSISDN},  currency:{account}, fromMSISDN: {fromMSISDN}, productCode: {productCode}, productItemCode: {productItemCode}, serviceProviderNumber: {serviceProviderNumber} ProductId {ProductId},  Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = ex.Message };
                JsonOperatorProductResponse respone = new JsonOperatorProductResponse();
                respone.status = errorResult.status;
                respone.message = errorResult.message;
                respone.errorCode = errorResult.errorCode;
                respone.payload = new PayLoad();
                respone.payload.operators = new List<AttOperator>();

                try
                {

                    string toNumber = destinationMSISDN.Replace("+", "");
                    toNumber = toNumber.StartsWith("00") == true ? toNumber.Remove(0, 2) : toNumber;
                    Comm_ATT_DestinationServiceProvider serviceProviderRecord = await _appDB.Com_ATT_GetServiceProvider(fromMSISDN, toNumber, ProductId);
                    AttOperator attOperator = new AttOperator()
                    {
                        routingType = (int)serviceProviderRecord.TypeOfRouting,
                        routingTypeName = ((RoutingType)serviceProviderRecord.TypeOfRouting).ToString()
                    };
                }
                catch (Exception exx)
                {
                    respone.errorCode = -1;
                    respone.message = "Internal server error";
                    _loggerAPIAccess.Debug($" CommonATTController, \"GET /GetOperatorProducts\"  Failed  Source:General  Parameters => destinationMSISDN: {destinationMSISDN},  currency:{account}, fromMSISDN: {fromMSISDN}, productCode: {productCode}, productItemCode: {productItemCode}, serviceProviderNumber: {serviceProviderNumber} ProductId {ProductId},  Message:{exx.Message}");
                }

                return Ok(respone);
            }

        }

        [HttpPost]
        [Route("Execute")]
        public async Task<IActionResult> Execute(ExecuteData data)
        {
            try
            {
                CRM_ATT_APIAccessGUID guidReferneceRecord = await _appDB.CRM_ATT_getTransactionGUIDRecord(data.nowtelTransactionReference, data.product);
                Comm_ATT_DestinationServiceProvider serviceProviderRecord = await _appDB.Com_ATT_GetServiceProvider(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn, guidReferneceRecord.ProductId);
                if (serviceProviderRecord != null)
                {
                    RoutingInfo routingInfo = GetRoutingInfo(serviceProviderRecord, data.serviceProviderNumber);

                    if (routingInfo.ServiceProviderId == 2) //transferto
                    {
                        var result = await CRM_ATT_transfertoExecuteTransaction(data, guidReferneceRecord);
                        if (routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.CRM_ATT_UpdateServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else if (routingInfo.ServiceProviderId == 3) //Ding
                    {
                        var result = await _dingPost_BL.Com_ATT_DingTopUp(data, guidReferneceRecord);
                        if (routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.CRM_ATT_UpdateServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else if (routingInfo.ServiceProviderId == 4) //Reloadly
                    {
                        var result = await _reloadlyPost_BL.CRM_ATT_ReloadlyTopUp(data, guidReferneceRecord);
                        if (routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.CRM_ATT_UpdateServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else  // Use TransferTo
                    {
                        var result = await CRM_ATT_transfertoExecuteTransaction(data, guidReferneceRecord);
                        return Ok(result);
                    }
                }
                else // Use TransferTo
                {
                    var result = await CRM_ATT_transfertoExecuteTransaction(data, guidReferneceRecord);
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($" CommonATTController, \"POST /Execute\"  Failed  Source:General  Parameters-  RequestJson:{JsonConvert.SerializeObject(data)},  ErrorMessage:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = ex.Message };
                JsonOperatorProductResponse respone = new JsonOperatorProductResponse();
                respone.status = errorResult.status;
                respone.message = errorResult.message;
                respone.errorCode = errorResult.errorCode;
                respone.payload = new PayLoad();
                respone.payload.operators = new List<AttOperator>();

                try
                {
                    CRM_ATT_APIAccessGUID guidReferneceRecord = await _appDB.CRM_ATT_getTransactionGUIDRecord(data.nowtelTransactionReference, data.product);
                    string toNumber = guidReferneceRecord.tomsisdn.Replace("+", "");
                    toNumber = toNumber.StartsWith("00") == true ? toNumber.Remove(0, 2) : toNumber;
                    Comm_ATT_DestinationServiceProvider serviceProviderRecord = await _appDB.Com_ATT_GetServiceProvider(guidReferneceRecord.frommsisdn, toNumber, guidReferneceRecord.ProductId);
                    AttOperator attOperator = new AttOperator()
                    {
                        routingType = (int)serviceProviderRecord.TypeOfRouting,
                        routingTypeName = ((RoutingType)serviceProviderRecord.TypeOfRouting).ToString()
                    };
                }
                catch (Exception exx)
                {
                    respone.errorCode = -1;
                    respone.message = "Internal server error";
                    _loggerAPIAccess.Debug($" CommonATTController, \"POST /Execute\"  Failed  Source:General  Parameters-  RequestJson:{JsonConvert.SerializeObject(data)},  ErrorMessage:{exx.Message}");
                }

                return Ok(respone);
            }

        }


        private async Task<IActionResult> CRM_ATT_transfertoExecuteTransaction(ExecuteData data, CRM_ATT_APIAccessGUID guidReferneceRecord)
        {
            try
            {
                string nowtelTransactionReference = data.nowtelTransactionReference;
                string operatorid = data.operatorid;
                string product = data.product;
                string messageToRecipient = data.messageToRecipient;
                string fromMSISDN = data.fromMSISDN;


                if (guidReferneceRecord == null)
                {
                    _loggerAPIAccess.Debug($"  \"GET /CRM_ATT_transfertoExecuteTransaction\"  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return Ok(result);
                }

                long RequestKey = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
                ;

                try
                {
                    var TopUpApiStartTime = DateTime.Now;
                    GenericApiResponse<transfertoExecuteTransaction> execTransactionResponse = new GenericApiResponse<transfertoExecuteTransaction>();
                    if (guidReferneceRecord.ProductId.ToLower().Equals("trhivr"))
                    {
                        execTransactionResponse = await _TransferToPost.transfertoExecuteTransactionFreeSwitch(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, RequestKey);
                    }
                    else
                    {
                        execTransactionResponse = await _TransferToPost.transfertoTransaction(fromMSISDN, guidReferneceRecord.tomsisdn, product, guidReferneceRecord.account, operatorid, messageToRecipient, RequestKey);
                    }

                    var TopUpApiEndTime = DateTime.Now;



                    if (execTransactionResponse.Status == 0)
                    {
                        //Successful transaction
                        try
                        {
                            await _appDB.CRM_ATT_insertAirTimeTransferTransaction(
                                guidReferneceRecord.ProductId,
                                DateTime.Now.ToString(),
                                (guidReferneceRecord.ProductId.ToLower().Equals("trhivr") ? TransferToConf.AttFreeSwitchUsernameEUR : TransferToAuth.GetAttCredentials(guidReferneceRecord.account, long.Parse(data.fromMSISDN))[0]), // Username
                                guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                                execTransactionResponse.Result.wholesale_price,  // Actual Charge Value
                                decimal.Parse(execTransactionResponse.Result.product_requested),
                                execTransactionResponse.Result.originating_currency,
                                execTransactionResponse.Result.destination_currency,
                                execTransactionResponse.Result.country,
                                "Success",
                                "",
                                execTransactionResponse.Result.operatorid,
                                execTransactionResponse.Result.product_requested,
                                execTransactionResponse.Result.@operator,
                                RequestKey.ToString(),
                                execTransactionResponse.Result.transactionid,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                2,
                                messageToRecipient,
                                 guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                nowtelTransactionReference,
                                 $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}, RequestKey:{RequestKey}",
                                JsonConvert.SerializeObject(execTransactionResponse.Result),
                                TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds,
                                crmamount: guidReferneceRecord.crmAmount
                                );
                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /CRM_ATT_transfertoExecuteTransaction\"  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }


                        _loggerAPIAccess.Information($"  \"POST /CRM_ATT_transfertoExecuteTransaction\"   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                            currency = execTransactionResponse.Result.originating_currency,
                            reference = execTransactionResponse.Result.transactionid
                        };
                        return Ok(result);
                    }
                    else
                    {
                        try
                        {
                            await _appDB.CRM_ATT_insertAirTimeTransferTransaction(
                                  guidReferneceRecord.ProductId,
                            DateTime.Now.ToString(),
                            (guidReferneceRecord.ProductId.ToLower().Equals("trhivr") ? TransferToConf.AttFreeSwitchUsernameEUR : TransferToAuth.GetAttCredentials(guidReferneceRecord.account, long.Parse(data.fromMSISDN))[0]), // Username
                            guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                            -1,
                            decimal.Parse(product),
                            guidReferneceRecord.account,
                            "",
                            "",
                            "Failure",
                            execTransactionResponse.Message,
                            operatorid,
                            product,
                            "",
                            RequestKey.ToString(),
                            "",
                            fromMSISDN,
                            guidReferneceRecord.tomsisdn,
                            2,
                            messageToRecipient,
                            guidReferneceRecord.productCode,
                           guidReferneceRecord.ProductItemCode,
                           nowtelTransactionReference,
                                       $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}, RequestKey:{RequestKey}",
                                       JsonConvert.SerializeObject(execTransactionResponse)
                           );

                            if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                            {
                                await _common_BL.SendEmail(new EmailTransactionModel()
                                {
                                    accessGUID = nowtelTransactionReference,
                                    DestinationCountry = guidReferneceRecord.destination_country,
                                    ErrorMessage = execTransactionResponse.Message,
                                    Status = "Failure",
                                    FromMsisdn = guidReferneceRecord.frommsisdn,
                                    ToMsisdn = guidReferneceRecord.tomsisdn,
                                    OperatorId = guidReferneceRecord.operatorCode,
                                    OperatorName = guidReferneceRecord.operatorName,
                                    ProductCode = guidReferneceRecord.productCode,
                                    ProductItemCode = guidReferneceRecord.ProductItemCode,
                                    ServiceProviderName = ServiceProvider.TransferTo.ToString(),
                                    TransationType = TransationType.Execute
                                });
                            }

                        }
                        catch (Exception ex)
                        {
                            _loggerAPIAccess.Debug($"  \"POST /CRM_ATT_transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        //Sochitel API Fatal Exception is already been logged in SochiPost. Here just log the API access
                        _loggerAPIAccess.Debug($"  \"POST /CRM_ATT_transfertoExecuteTransaction\"  Failed  Source:Sochitel API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{execTransactionResponse.ATTTransactionReference}          Reason={execTransactionResponse.Message}");
                        var result = new { errorCode = 2, status = "Failure", message = execTransactionResponse.Message };
                        return Ok(result);
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        await _appDB.CRM_ATT_insertAirTimeTransferTransaction(
                            guidReferneceRecord.ProductId,
                        DateTime.Now.ToString(),
                        (guidReferneceRecord.ProductId.ToLower().Equals("trhivr") ? TransferToConf.AttFreeSwitchUsernameEUR : TransferToAuth.GetAttCredentials(guidReferneceRecord.account, long.Parse(data.fromMSISDN))[0]), // Username
                        guidReferneceRecord.CustomerChargeValue,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        "",
                        "",
                        "FailureException",
                        ex.Message,
                        operatorid,
                        product,
                        "",
                        RequestKey.ToString(),
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        2,
                        messageToRecipient,
                                guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                nowtelTransactionReference,
                                            $"fromMSISDN:{fromMSISDN}, ToMsisdn:{guidReferneceRecord.tomsisdn}, product:{product}, account:{guidReferneceRecord.account}, operatorid:{operatorid}, messageToRecipient:{messageToRecipient}, RequestKey:{RequestKey}",
                                            ""
                        );

                        if (SmtpConfig.sendErrorExecuteTransactionEmail)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                accessGUID = nowtelTransactionReference,
                                DestinationCountry = guidReferneceRecord.destination_country,
                                ErrorMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                                Status = "FailureException",
                                FromMsisdn = guidReferneceRecord.frommsisdn,
                                ToMsisdn = guidReferneceRecord.tomsisdn,
                                OperatorId = guidReferneceRecord.operatorCode,
                                OperatorName = guidReferneceRecord.operatorName,
                                ProductCode = guidReferneceRecord.productCode,
                                ProductItemCode = guidReferneceRecord.ProductItemCode,
                                ServiceProviderName = ServiceProvider.Ding.ToString(),
                                TransationType = TransationType.Execute

                            });
                        }

                    }
                    catch (Exception dbException)
                    {
                        _loggerAPIAccess.Debug($"  \"POST /CRM_ATT_transfertoExecuteTransaction\"  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _loggerAPIAccess.Debug($"  \"GET /CRM_ATT_transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return Ok(errorResult);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /CRM_ATT_transfertoExecuteTransaction\"  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return Ok(errorResult);
            }
        }

        [NonAction]
        private RoutingInfo GetRoutingInfo(Comm_ATT_DestinationServiceProvider serviceProviderRecord, int serviceProviderNumber)
        {
            #region Routing

            int serviceProviderId;
            int CarrierNumber = 1;
            bool updateCount;
            int NewServiceProviderTranCount_Current = 0;
            int NewSecondServiceProviderTranCount_Current = 0;

            #region PercentageRouting

            if (serviceProviderRecord.TypeOfRouting == RoutingType.Percentage)
            {
                updateCount = true;
                int serviceProviderRoutingCount = int.Parse(serviceProviderRecord.PercentageRoutingRatio.Split(':')[0]);
                int serviceProvider1RoutingCount = int.Parse(serviceProviderRecord.PercentageRoutingRatio.Split(':')[1]);


                if (serviceProviderRecord.service_provider_current_count >= serviceProviderRoutingCount)
                {
                    if (serviceProviderRecord.service_provider_1_current_count >= (serviceProvider1RoutingCount - 1))
                    {
                        NewServiceProviderTranCount_Current = 0;
                        NewSecondServiceProviderTranCount_Current = 0;
                        serviceProviderId = serviceProviderRecord.service_provider_id_1;
                        CarrierNumber = 2;
                    }
                    else
                    {
                        NewServiceProviderTranCount_Current = serviceProviderRecord.service_provider_current_count;
                        NewSecondServiceProviderTranCount_Current = serviceProviderRecord.service_provider_1_current_count + 1;
                        serviceProviderId = serviceProviderRecord.service_provider_id_1;
                        CarrierNumber = 2;
                    }
                }
                else
                {
                    NewServiceProviderTranCount_Current = serviceProviderRecord.service_provider_current_count + 1;
                    NewSecondServiceProviderTranCount_Current = 0;
                    serviceProviderId = serviceProviderRecord.service_provider_id;
                    CarrierNumber = 1;
                }

            }

            #endregion PercentageRouting

            #region FailoverRouting

            else // Failover Routing
            {
                updateCount = false;

                if (serviceProviderNumber == 2) // Second Service Provider
                {
                    serviceProviderId = serviceProviderRecord.service_provider_id_1;
                    CarrierNumber = 2;
                }
                else // Service Provider
                {
                    serviceProviderId = serviceProviderRecord.service_provider_id;
                    CarrierNumber = 1;
                }
            }

            RoutingInfo routingInfo = new RoutingInfo();
            routingInfo.ServiceProviderId = serviceProviderId;
            routingInfo.CarrierNumber = CarrierNumber;
            routingInfo.UpdateCount = updateCount;
            routingInfo.NewServiceProviderTranCount_Current = NewServiceProviderTranCount_Current;
            routingInfo.NewSecondServiceProviderTranCount_Current = NewSecondServiceProviderTranCount_Current;

            return routingInfo;

            #endregion FailoverRouting

            #endregion Routing

        }


    }
}
