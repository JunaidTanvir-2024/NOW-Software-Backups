﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using NowPayG.Models;
using System;
using System.Security.Claims;
using System.Linq;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.Net;

namespace NowPayG.Utility
{
    public static class ExtensionMethods
    {
        public static ClaimsIdentity SetClaims(this BaseViewModel model, LoginTypes logintType, out AuthenticationProperties authProperties,bool RememberMe)
        {
            try
            {
                ClaimsIdentity claimsIdentity;
                //claimsIdentity = new ClaimsIdentity(DefaultAuthenticationTypes.ApplicationCookie);
                claimsIdentity = new ClaimsIdentity(CookieAuthenticationDefaults.AuthenticationScheme);
                claimsIdentity.AddClaim(new Claim("Id", model.Id.ToString()));
                claimsIdentity.AddClaim(new Claim("FirstName", model.FirstName));
                claimsIdentity.AddClaim(new Claim("LastName", model.LastName));
                claimsIdentity.AddClaim(new Claim("FullName", model.FullName));
                claimsIdentity.AddClaim(new Claim("Email", model.Email));
                claimsIdentity.AddClaim(new Claim("Token", model.Token));
                claimsIdentity.AddClaim(new Claim("access_token", model.Token));
                claimsIdentity.AddClaim(new Claim("token_type", "Bearer"));
                claimsIdentity.AddClaim(new Claim("IsSignedIn", Convert.ToString(true)));
                claimsIdentity.AddClaim(new Claim("LoginType", ((int)logintType).ToString()));
                claimsIdentity.AddClaim(new Claim("Products", ((model.ProductList != null && model.ProductList.Count() > 0) ? JsonConvert.SerializeObject(model.ProductList.Select(x => new { AccountId = x.AccountId, ProductRef = x.ProductRef })) : "")));

                authProperties = new AuthenticationProperties
                {
                    //AllowRefresh = <bool>,
                    // Refreshing the authentication session should be allowed.

                    ExpiresUtc = DateTimeOffset.UtcNow.AddDays(1).AddMinutes(-1),
                    // The time at which the authentication ticket expires. A 
                    // value set here overrides the ExpireTimeSpan option of 
                    // CookieAuthenticationOptions set with AddCookie.

                    IsPersistent = RememberMe,
                    // Whether the authentication session is persisted across 
                    // multiple requests. When used with cookies, controls
                    // whether the cookie's lifetime is absolute (matching the
                    // lifetime of the authentication ticket) or session-based.

                    //IssuedUtc = <DateTimeOffset>,
                    // The time at which the authentication ticket was issued.

                    //RedirectUri = <string>
                    // The full path or absolute URI to be used as an http 
                    // redirect response value.
                };

                return claimsIdentity;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static string GetRemoteIPAddress(this HttpContext context, bool allowForwarded = true)
        {
            if (allowForwarded)
            {
                string header = (context.Request.Headers["CF-Connecting-IP"].FirstOrDefault() ?? context.Request.Headers["X-Forwarded-For"].FirstOrDefault());
                if (IPAddress.TryParse(header, out IPAddress ip))
                {
                    return ip.MapToIPv4().ToString();
                }
            }
            return context.Connection.RemoteIpAddress.MapToIPv4().ToString();
        }
    }
}
