﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Models.Payments
{
    public class Pay360CustomerModel
    {

        public string displayName { get; set; }
        public string merchantRef { get; set; }
        public string pay360CustId { get; set; }
        public string email { get; set; }
        public string defaultCurrency { get; set; }
        public string dob { get; set; }
        public string addressLine1 { get; set; }
        public string addressLine2 { get; set; }
        public string addressLine3 { get; set; }
        public string addressLine4 { get; set; }
        public string city { get; set; }
        public string region { get; set; }
        public string postCode { get; set; }
        public string country { get; set; }
        public string countryCode { get; set; }
        public string telephone { get; set; }
        public List<paymentMethodResponse> PaymentMethods { get; set; }
    }

    public class paymentMethodResponse
    {
        public bool registered { get; set; }
        public bool isPrimary { get; set; }
        public card card { get; set; }
        public string paymentClass { get; set; }
    }

    public class card
    {
        public string cardFingerprint { get; set; }
        public string cardToken { get; set; }
        public string cardType { get; set; }
        [JsonProperty(PropertyName = "new")]
        public bool newCard { get; set; }
        public string cardUsageType { get; set; }
        public string cardScheme { get; set; }
        public string maskedPan { get; set; }
        public string expiryDate { get; set; }
        public string issuer { get; set; }
        public string issuerCountry { get; set; }
        public string cardHolderName { get; set; }

    }
}
