namespace Application.Features.Bundle.SimBundle;

public sealed class SimBundleRequestValidator : AbstractValidator<SimBundleRequest> { }
