namespace DC.Core.Common.Definitions;

public static class AppEnums
{
    public enum ClientInformation
    {
        ProductCode,
        ProductItemCode,
        UniqueReference
    }
    public enum Vendor
    {
        MessageMatrix = 1,
    }
    public enum SimState
    {
        Active
    }

    public enum SmsType
    {
        Activation ,
        Topup 
    }
    public enum SmsSubCategory
    {
        OnlineSim = 1,
        RetailSim = 2,
        NoThmApp =3,
        All =4,
        ActivationWithoutPlan =5,
        ActivationWithoutPlanAndTopup=6,
        AllTopUps=7,
        FirstTopUpNoPlan=8
    }
    public enum Cadence
    {
        Immediate,
        T12hours,
        T24hours,
        T48hours,
        T72hours,
        T96hours,
        T120hours

    }
}
