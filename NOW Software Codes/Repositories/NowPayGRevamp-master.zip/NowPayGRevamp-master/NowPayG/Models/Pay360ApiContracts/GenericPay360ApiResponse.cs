﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.Pay360ApiContracts
{
    public class GenericPay360ApiResponse<T>
    {
        public string status { get; set; }

        public string message { get; set; }

        public T payload { get; set; }

        public int errorCode { get; set; }
        public string pay360ApiCode { get; set; }
    }
}
