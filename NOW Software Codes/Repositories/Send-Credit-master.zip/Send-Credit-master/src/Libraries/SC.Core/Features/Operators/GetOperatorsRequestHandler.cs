﻿using Microsoft.AspNetCore.Http;
using RW.Models;
using SC.Core.Vendors.FusionHub;

namespace SC.Core.Features.Operators;
internal sealed class GetOperatorsRequestHandler : IRequestHandler<GetOperatorsRequest, IResultWrapper>
{
    private readonly IFusionHubService _fusionHubService;
    public GetOperatorsRequestHandler(IFusionHubService fusionHubService, IHttpContextAccessor httpContextAccessor)
    {
        _fusionHubService = fusionHubService;
        
    }

    public async Task<IResultWrapper> Handle(GetOperatorsRequest request, CancellationToken cancellationToken)
    {
     
        var response = await _fusionHubService.GetOperatorsAsync(request);
        if (response?.Payload == null)
        {
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
        }
        return ResultWrapper.Success(response.Payload, new Pagination(response.PaginationInfo.TotalCount, response.PaginationInfo.PageCount, response.PaginationInfo.CurrentPage, response.PaginationInfo.PageSize));
    }
}

