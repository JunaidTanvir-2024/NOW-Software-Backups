﻿$(document).ready(function () {
    var selectcard;
    selectcard = $("#cardoption").val();
    if (selectcard && !selectcard.trim()) {
        $("#cardoption").val(10);
        selectcard = 10;
    } 
    ChangeCallingCard(selectcard);
       
    if (selectcard == 5) { $("#th-cc-5").prop("checked", true); }
    else if (selectcard == 10) { $("#th-cc-10").prop("checked", true); }
    else if (selectcard == 20) {$("#th-cc-20").prop("checked", true); }
var paymentMethod = "PayCard";
$("#newCard").click();
});

// Model Pop up selected ammout updation
function ChangeCallingCard(cardValue, event) {
    selectedCardAmmount = cardValue;
    $(".cardAmount").text(cardValue);
}
function ChangePaymentMethods(pMethod) {
    paymentMethod = pMethod;
    if (paymentMethod == "PayCard") {
        $("#paybyCard").show();
    } else {
        $("#paybyCard").hide();
    }
}

//$("#payBtn").click(function () {
//    if (!$('#CheckoutForm').valid()) {
//        return false;
//    }
//    $("#TermsError").hide();
//    if (paymentMethod == "PayPal") {
//        if (validatePaypalRequest()) {
//            $("#checkOutPay").modal();
//        }
//    } else {

//    }
    
//})

//$("#sendPaymentRequestBTN").click(function () {
//    sendPaymentUsingPaypal();
//});

function sendPaymentUsingPaypal() {
    var model = {};
    model.Ammount = selectedCardAmmount;
    model.Email = $('#emailAddress').val();
    model.ProductCode = "THCC";
    $.ajax({
        type: "POST",
        url: "/Paypal/SendPaypalRequest",
        data: model,
        async: false,
        success: function (json) {
            if (json.errorCode == 0) {
                window.location.href = json.redirectLink;
            }
        },
        error: function (error) {
            var a = error;
            alert("Error: " + a.responseText);
        }
    });
}

function validatePaypalRequest() {
    //$('#emailValidError').hide();
    $('#termnCondition').is(":checked") ? $("#TermsError").hide() : $("#TermsError").show();
    //$('#emailAddress').val() ? $("#emailError").hide() : $("#emailError").show();
   

    if (!$('#termnCondition').is(":checked")) {
        return false;
    }
    //if (!$('#emailAddress').val()) {
    //    return false;
    //} 
    //if (!isEmail($('#emailAddress').val())) {
    //    $('#emailValidError').show();
    //    return false;
    //}    
    return true; 
}