using System.ComponentModel.DataAnnotations;

namespace JM.Core.Utilities.Extensions;

public static class EnumExtensions
{
    public static string? GetDisplayName(this Enum value)
    {
        var displayAttribute = value.GetType()?
                                    .GetField(value.ToString())?
                                    .GetCustomAttributes(typeof(DisplayAttribute), false)
                                    as DisplayAttribute[];

        return displayAttribute?.Length > 0 ? displayAttribute[0].Name : value.ToString();
    }
}

