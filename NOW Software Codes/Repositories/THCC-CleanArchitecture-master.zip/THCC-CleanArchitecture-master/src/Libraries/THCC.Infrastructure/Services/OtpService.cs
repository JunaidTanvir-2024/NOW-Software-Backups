﻿using Microsoft.Extensions.Hosting;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;

using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Services;
public class OtpService : IOtpService

{
    #region Fields

    private readonly IOtpRepository _otprepository;
    private readonly IHostEnvironment _hostingEnvironment;

    #endregion

    #region Ctor

    public OtpService(
        IOtpRepository otprepository,
        IHostEnvironment hostingEnvironment)
    {
        _otprepository = otprepository;
        _hostingEnvironment = hostingEnvironment;
    }

    #endregion

    #region Methods

    public async Task<string> SaveToken(string email, string token, OtpType Type)
    {
        string otp = _hostingEnvironment.EnvironmentName == Environments.Production ? GenerateOTP() : 1234.ToString();
        await _otprepository.SaveToken(otp, email, token, Type);
        return otp;
    }

    public async Task<string> GetTokenAgainstOtp(string email, string otp, OtpType type)
    {
        return await _otprepository.GetToken(otp, email, type);
    }

    #endregion

    #region Utilities

    private static string GenerateOTP()
    {
        const int _min = 1000;
        const int _max = 9999;
        Random _rdm = new Random();
        return _rdm.Next(_min, _max).ToString();
    }

    #endregion
}