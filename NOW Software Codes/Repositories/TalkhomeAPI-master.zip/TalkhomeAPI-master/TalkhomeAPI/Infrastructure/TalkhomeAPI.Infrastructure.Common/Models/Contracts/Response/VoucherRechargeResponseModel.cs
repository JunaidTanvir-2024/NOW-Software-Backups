﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class VoucherRechargeResponseModel
    {
        public decimal? card_credit { get; set; }
        public int? voucher_id { get; set; }
        public string voucher_currency { get; set; }
    }
}
