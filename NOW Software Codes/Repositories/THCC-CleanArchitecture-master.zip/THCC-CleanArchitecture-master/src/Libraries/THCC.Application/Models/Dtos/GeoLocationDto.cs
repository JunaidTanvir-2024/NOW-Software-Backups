﻿namespace THCC.Application.Models.Dtos
{
    public class GeoLocationDto
    {
        public string? IpAddress { get; set; }
        public string? Device { get; set; }
        public string? CountryName { get; set; }
        public string? CityName { get; set; }
    }
}
