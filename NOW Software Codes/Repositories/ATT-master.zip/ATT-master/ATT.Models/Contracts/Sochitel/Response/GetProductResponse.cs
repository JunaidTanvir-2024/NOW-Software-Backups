﻿

namespace ATT.Models.Contracts.Sochitel.Response
{
    public class ProductDetails
    {
        public Product product { get; set; }
        public IDName @operator { get; set; }
        public OperatorUserString currency { get; set; }
    }
}
