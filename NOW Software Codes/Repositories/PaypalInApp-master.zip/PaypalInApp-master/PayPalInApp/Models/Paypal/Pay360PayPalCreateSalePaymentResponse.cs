﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Models.Paypal
{
    public class Pay360PayPalCreateSalePaymentResponse
    {
        public string customerId { get; set; }
        public string transactionId { get; set; }
        public string transactionAmount { get; set; }
        public outcome outcome { get; set; }
        public string clientRedirectUrl { get; set; }
        public string checkoutToken { get; set; }
    }
    public class outcome
    {
        public string status { get; set; }
        public string reasonCode { get; set; }
        public string reasonMessage { get; set; }
    }
}
