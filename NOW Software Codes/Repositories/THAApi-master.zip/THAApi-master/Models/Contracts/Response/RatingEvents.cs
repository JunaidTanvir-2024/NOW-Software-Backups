﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class RatingEvents
    {
        public int id { get; set; }
        public string RatingEvent { get; set; }
        public string Description { get; set; }
        public string EventProduct { get; set; }
    }
}
