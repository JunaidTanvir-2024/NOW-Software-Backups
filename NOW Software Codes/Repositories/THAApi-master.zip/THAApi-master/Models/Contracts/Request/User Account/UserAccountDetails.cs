﻿namespace Models.Contracts.Request
{
    public class UserAccountDetails
    {
        public string Title { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string TelephoneOne { get; set; }

        public string TelephoneTwo { get; set; }

        public string EmailAddress { get; set; }

        public string DeliveryAddressOne { get; set; }

        public string DeliveryAddressTwo { get; set; }

        public string DeliveryAddressThree { get; set; }

        public string DeliveryPostCode { get; set; }

        public string DeliveryCountry { get; set; }

        public string AddressOne { get; set; }

        public string AddressTwo { get; set; }

        public string AddressThree { get; set; }

        public string AddressFour { get; set; }

        public string PostCode { get; set; }

        public string Country { get; set; }

        public string referralCode { get; set; }

        public int Na_Service_Id { get; set; }
    }

    public class UserSubscriberDetails
    {
        public UserAccountDetails UseSubscriberDetails { get; set; }

        public UserAccountBalance UserAccountBalance { get; set; }

        public int SubscriberID { get; set; }

    }


    public class Subscriber_Details
    {
        public string Title { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string TelephoneOne { get; set; }

        public string TelephoneTwo { get; set; }

        public string EmailAddress { get; set; }

        public string DeliveryAddressOne { get; set; }

        public string DeliveryAddressTwo { get; set; }

        public string DeliveryAddressThree { get; set; }

        public string DeliveryPostCode { get; set; }

        public string DeliveryCountry { get; set; }

        public string AddressOne { get; set; }

        public string AddressTwo { get; set; }

        public string AddressThree { get; set; }

        public string AddressFour { get; set; }

        public string PostCode { get; set; }

        public string Country { get; set; }

        public string referralCode { get; set; }

        public int Na_Service_Id { get; set; }

        public string Currency { get; set; }

        public string Balance { get; set; }

        public string CurrencySymbol { get; set; }

        public int SubscriberID { get; set; }

    }
}
