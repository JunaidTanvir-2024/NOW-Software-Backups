using System.Data;
using System.Data.SqlClient;

using Dapper;

using Microsoft.Extensions.Configuration;

using THCC.Domain.Constants;

namespace THCC.Infrastructure.Persistence.DapperConfigurations;
public static class DapperWrapper
{
    private static IConfiguration? _configuration;

    public static void SetConfiguration(IConfiguration configuration)
    {
        _configuration = configuration;
    }
    public static IEnumerable<T> Query<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        IEnumerable<T>? result = connection.Query<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }

    public async static Task<IEnumerable<T>> QueryAsync<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        IEnumerable<T>? result = await connection.QueryAsync<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    public static T QuerySingle<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        T? result = connection.QuerySingle<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    public async static Task<T> QuerySingleAsync<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        T? result = await connection.QuerySingleAsync<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }

    public static T QuerySingleOrDefault<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        T? result = connection.QuerySingleOrDefault<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    public async static Task<T> QuerySingleOrDefaultAsync<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        T? result = await connection.QuerySingleOrDefaultAsync<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    public static T QueryFirst<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        var result = connection.QueryFirst<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    public async static Task<T> QueryFirstAsync<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        T? result = await connection.QueryFirstAsync<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    public static T QueryFirstOrDefault<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        var result = connection.QueryFirstOrDefault<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    public async static Task<T> QueryFirstOrDefaultAsync<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        var result = await connection.QueryFirstOrDefaultAsync<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    public static void Execute(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        connection.Execute(sql, param, commandType: commandType);
        connection.Close();
    }
    public async static Task ExecuteAsync(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        await connection.ExecuteAsync(sql, param, commandType: commandType);
        connection.Close();
    }
    public async static Task<int> ExecuteReturnAsync(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        var result =await connection.ExecuteAsync(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    public static T ExecuteScalar<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        T? result = connection.ExecuteScalar<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    public async static Task<T> ExecuteScalarAsync<T>(string sql, object? param = null, CommandType? commandType = null, string? connectionString = null)
    {
        using var connection = new SqlConnection(connectionString ?? GetDefaultConnectionString());
        connection.Open();
        var result = await connection.ExecuteScalarAsync<T>(sql, param, commandType: commandType);
        connection.Close();
        return result;
    }
    private static string? GetDefaultConnectionString()
    {
        return _configuration?.GetConnectionString(ThccConstants.ConnectionStrings.DefaultConnection);
    }
}