namespace Application.Features.Bundle.Model;

#region Old BundleInfo Model
// public sealed class BundleInfo
// {
//     public int Id { get; set; }
//     public string? Name { get; set; }
//     public string? DisplayName { get; set; }
//     // public string? Description { get; set; }
//     public string? UuId { get; set; }
//     public int Category { get; set; }
//     public double Type { get; set; }
//     public double Price { get; set; }
//     public double DiscountPrice { get; set; }
//     public double DiscountPercentage { get; set; }
//     // public double DiscountSaving { get; set; }
//     public string? LocalMinutes { get; set; }
//     public string? InternationalMinutes { get; set; }
//     public string? LocalMinutesOrSms { get; set; }
//     public string? Data { get; set; }
//     public string? DataUnit { get; set; }
//     public string? LocalSms { get; set; }
//     public string? InternationalSms { get; set; }
//     public string? InternationalMinutesOrSms { get; set; }
//     public int ValidityDays { get; set; }
//     // public bool IsFollowedBy { get; set; }
//     public string? FollowedByPackageId { get; set; }
//     public int CountryId { get; set; }
//     public string? CountryName { get; set; }
//     public string? CountryCode { get; set; }
//     public string? DisplayDescription { get; set; }
//     public string? CountriesIncluded { get; set; }
//     public string? ColorCode { get; set; }
//     public bool IsTop { get; set; }
//     public bool IsPopular { get; set; }
//     public bool IsAvailable { get; set; }
//     public string? CSSClass { get; set; }
//     public string? InternationalResourcesCountries { get; set; }
// }

#endregion

#region Bundle Info Model
public sealed class BundleInfo
{
    public int Id { get; set; }
    public string UuId { get; set; } = default!;
    public string DisplayName { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? CountryCode { get; set; }
    public int Category { get; set; }
    public int Type { get; set; }
    public decimal Price { get; set; }
    public decimal Discount { get; set; }
    public decimal TotalPrice { get; set; }
    public string? LocalMinutes { get; set; }
    public string? InternationalMinutes { get; set; }
    public bool LocalMinutesOrSms { get; set; }
    public bool InternationalMinutesOrSms { get; set; }
    public string? Data { get; set; }
    public string? DataUnit { get; set; }
    public string? LocalSms { get; set; }
    public string? InternationalSms { get; set; }
    public int ValidityDays { get; set; }
    public bool IsAddOn { get; set; }
    public bool IsSaverPlan { get; set; }
    public string? AddOnData { get; set; }
    public string? AddOnDataUnit { get; set; }
    public string? DisplayDescription { get; set; }
    public bool IsAvailable { get; set; }
    public string? AddonPackageDescription { get; set; }
    public bool ShowBadge { get; set; }
    public string? BadgeDescription { get; set; }
    public bool ShowRenewal { get; set; }
    public bool IsRoaming { get; set; }
}
#endregion