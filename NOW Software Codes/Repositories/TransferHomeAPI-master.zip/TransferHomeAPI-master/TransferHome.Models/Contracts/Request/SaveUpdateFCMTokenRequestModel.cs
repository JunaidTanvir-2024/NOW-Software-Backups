﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.Request
{
    public class SaveUpdateFCMTokenRequestModel
    {
        [Required]
        public string Token { get; set; }
        [Required]
        public string UDID { get; set; }
        [Required]
        public DeviceType DeviceType { get; set; }
    }
}
