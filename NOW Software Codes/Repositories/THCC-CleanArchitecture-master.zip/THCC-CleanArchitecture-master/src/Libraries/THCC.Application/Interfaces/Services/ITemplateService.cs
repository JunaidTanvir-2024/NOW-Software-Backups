﻿using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Services;

public interface ITemplateService : ServiceType.ITransient
{
    string GenerateTemplate<T>(string templateName, T mailTemplateModel);
}
