﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Configurations;
using TalkhomeAPI.Models.Pay360ApiContracts;
using TalkhomeAPI.Models.PaypalApiContracts;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class PayPalService : IPayPalService
    {
        private readonly string PayPalApiEndpoint;
        private readonly string PayPalByPay360ApiEndpoint;

        public PayPalService(IOptions<PayPalConfig> payPalConfig)
        {
            PayPalApiEndpoint = payPalConfig.Value.PayPalApiEndpoint;
            PayPalByPay360ApiEndpoint = payPalConfig.Value.PayPalByP630ApiEndpoint;
        }

        public async Task<GenericPayPalApiResponse<PayPalByPay360CSPaymentResponse>> PayPalByPay360CS(PayPalByPay360CSPaymentRequest request)
        {
            var ret = new GenericPayPalApiResponse<PayPalByPay360CSPaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";
            endpoint = PayPalByPay360ApiEndpoint + "Paypal/Payment";
            Json = JsonConvert.SerializeObject(request);
            Result = await Post(endpoint, Json);
            if (Result == null)
            {
                return null;
            }
            ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<PayPalByPay360CSPaymentResponse>>(Result);
            return ret;
        }

        public async Task<GenericPayPalApiResponse<PayPalByPay360ESPaymentResponse>> PayPalByPay360ES(PayPalByPay360ESPaymentRequest request)
        {
            var ret = new GenericPayPalApiResponse<PayPalByPay360ESPaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";
            endpoint = PayPalByPay360ApiEndpoint + "Paypal/Resume";
            Json = JsonConvert.SerializeObject(request);
            Result = await Post(endpoint, Json);
            if (Result == null)
            {
                return null;
            }
            ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<PayPalByPay360ESPaymentResponse>>(Result);
            return ret;
        }


        public async Task<GenericApiResponse<PayPalCreateSalePaymentResponse>> PayPalCreateSalePayment(PayPalCreateSalePaymentRequest request)
        {
            GenericApiResponse<PayPalCreateSalePaymentResponse> ret = new GenericApiResponse<PayPalCreateSalePaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";
            endpoint = PayPalApiEndpoint + "Paypal/CreateSalePayment";
            Json = JsonConvert.SerializeObject(request);
            Result = await Post(endpoint, Json);
            if (Result == null)
            {
                return null;
            }
            ret = JsonConvert.DeserializeObject<GenericApiResponse<PayPalCreateSalePaymentResponse>>(Result);
            return ret;

        }

        public async Task<GenericApiResponse<PayPalExecuteSalePaymentResponse>> PayPalExecuteSalePayment(PayPalExecuteSalePaymentRequest request)
        {
            GenericApiResponse<PayPalExecuteSalePaymentResponse> ret = new GenericApiResponse<PayPalExecuteSalePaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";
            endpoint = PayPalApiEndpoint + "Paypal/ExecuteSalePayment";
            Json = JsonConvert.SerializeObject(request);
            Result = await Post(endpoint, Json);
            if (Result == null)
            {
                return null;
            }
            ret = JsonConvert.DeserializeObject<GenericApiResponse<PayPalExecuteSalePaymentResponse>>(Result);
            return ret;

        }

        public async Task<GenericPayPalApiResponse<PaypalRefundResponse>> PaypalRefund(RefundFullPaymentRequestModel request)
        {

            string endpoint = PayPalByPay360ApiEndpoint + "Paypal/Refund";

            GenericPayPalApiResponse<PaypalRefundResponse> ret = new GenericPayPalApiResponse<PaypalRefundResponse>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<PaypalRefundResponse>>(Result);

            return ret;

        }

        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                    {
                        throw new WebException();
                    }

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch
            {
                return null;
            }
        }
    }
}


