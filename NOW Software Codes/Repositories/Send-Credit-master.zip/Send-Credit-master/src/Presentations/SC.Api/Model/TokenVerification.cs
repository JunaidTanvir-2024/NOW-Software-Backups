﻿namespace SC.Api.Model;
public class TokenVerification
{
    public string Email { get; set; }
    public string Code { get; set; }
}

