﻿using Infrastructure.BLL.Services.Voucherify.Models.Promotions.Common;
using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Requests
{
    public class GetCustomerSpecificPromotionTiersRequest
    {
        public PromotionTierCustomerInfo Customer { get; set; } = null!;
        public PromotionTierOrderInfo Order { get; set; } = null!;
        public Metadata ValidationMetadata { get; set; } = null!;
    }
}