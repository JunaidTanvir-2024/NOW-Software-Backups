﻿using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Common.Model;
using SC.Core.Models;
using SC.Core.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SC.Core.Common.Definitions.Constants;
using static SC.Core.Models.PurchaseInventoryRequest;
using static SC.Core.Common.Definitions.Constants.AppEnums;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Vendors.Payment.Responses;
using MapsterMapper;
using System.Linq.Expressions;
using System.Linq.Dynamic.Core;
using SC.Core.Common.DTOs.Configurations;
using System.Diagnostics.Eventing.Reader;


namespace SC.Infrastructure.Services.CustomerOrder;
internal sealed class CustomerOrderService : ICustomerOrderService
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly ICommonService _commonService;
    private readonly IFusionHubService _fusionHubService;
    private readonly IMapper _mapper;
    public CustomerOrderService(ICustomerCartRespository CustomerCartRespository, ICommonService commonService, IFusionHubService fusionHubService, IMapper mapper)
    {
        _customerCartRespository = CustomerCartRespository;
        _commonService = commonService;
        _fusionHubService = fusionHubService;
        _mapper = mapper;
    }
    public async Task<decimal> CalculateCustomerOrderPrice(string UserID)
    {

        var orderDetail = await _customerCartRespository.GetCustomerOrderDetail(UserID, AppEnums.OrderStatusEnum.Init.Getkey());

        decimal OrderPrice = 0;
        decimal serviceFee = 0;
        if (orderDetail != null && orderDetail.CartDetail.Count() > 0)
            foreach (var product in orderDetail.CartDetail)
            {
                OrderPrice += Math.Round((product.ProductPrice * product.Quantity) + product.ServiceFeeAmount, 3);
                serviceFee += product.ServiceFeeAmount;
            }


        if (orderDetail != null)
        {
            var order = new OrderCreationDto()
            {
                CustomerOrderID = orderDetail.CustomerOrderID,
                PromoCode = orderDetail.PromoCode,
                DiscountTypeId = orderDetail.DiscountTypeId,
                DiscountInclusiveAmount = orderDetail.DiscountInclusiveAmount,
                DiscountAmount = orderDetail.DiscountAmount,
                ServiceFee = serviceFee,
                TaxAmount = orderDetail.TaxAmount,
                TaxInclusiveAmount = orderDetail.TaxInclusiveAmount,
                TaxExclusiveAmount = orderDetail.TaxExclusiveAmount,
                TotalOrderAmount = Math.Round(OrderPrice, 3),// update new price
                Currency = orderDetail.Currency,
                OrderStatus = orderDetail.OrderStatus,
                UserID = UserID
            };
            var orderID = await _customerCartRespository.OrderCreationAsync(order);
            return orderID > 0 ? OrderPrice : 0;
        }
        return OrderPrice;
    }

    public async Task<ApiResult<PurchaseInventoryResponse>> PurchaseInventory(CustomerOrderDetailDto orderDetail)
    {
        ProductPurchaseType productPurchaseType;
        bool IsValid = true;
        string OrderIncompletionError = string.Empty;
        string WrongProductTypeError = string.Empty;
        string SenderName = string.Empty;
        if (string.IsNullOrEmpty(orderDetail.Firstname + orderDetail.Lastname))
            SenderName = "SendCredit_";
        else
            SenderName = orderDetail.Firstname + "_" + orderDetail.Lastname;

        List<PurchaseItem> purchaseItems = new List<PurchaseItem>();
        foreach (var item in orderDetail.CartDetail)
        {
            if (string.IsNullOrEmpty(item.ReceiverMobile) || string.IsNullOrEmpty(item.SenderMobile) || string.IsNullOrEmpty(item.ProductType) || string.IsNullOrEmpty(item.ProductVendorCode))
            {
                IsValid = false;
                OrderIncompletionError = AppConstants.StatusKeys.IncompleteOrder;
                break;
            }
            string productType = item.ProductType.ToUpper();
            switch (productType)
            {
                case AppConstants.ProductPurchaseType.Topup:
                    productPurchaseType = ProductPurchaseType.Topup; break;
                case AppConstants.ProductPurchaseType.Bundle:
                    productPurchaseType = ProductPurchaseType.Bundle; break;
                case AppConstants.ProductPurchaseType.InternetData:
                    productPurchaseType = ProductPurchaseType.InternetData; break;
                case AppConstants.ProductPurchaseType.GiftCard:
                    productPurchaseType = ProductPurchaseType.GiftCard; break;
                default:
                    {
                        productPurchaseType = ProductPurchaseType.Topup;
                        IsValid = false;
                        WrongProductTypeError = AppConstants.StatusKeys.wrongProductType;
                        break;
                    }

            }
            purchaseItems.Add(new PurchaseItem
            {
                ProductId = item.ProductId,
                ProductVendorCode = item.ProductVendorCode,
                RecipientMsisdn = item.ReceiverMobile,
                SenderMsisdn = item.SenderMobile,
                ProductType = productPurchaseType,
                Quantity = 1,
                CartReference = item.CustomerCartID.ToString(),
                SenderName = SenderName
            });
        }

        var purchaseInventoryRequest = new PurchaseInventoryRequest
        {
            TransactionReference = _commonService.GetRequestID() + "_OrderID_" + orderDetail.CustomerOrderID.ToString(),
            PurchaseItems = purchaseItems
        };

        var inventryresponse = await _fusionHubService.PurchaseInventory(purchaseInventoryRequest);
        if (inventryresponse.Payload == null)
            return inventryresponse;
        var purchaseInventroyResponce = _mapper.Map<PurchaseInventoryResponse>(inventryresponse.Payload);
        if (purchaseInventroyResponce.PurchasedItems != null && purchaseInventroyResponce.PurchasedItems.Count > 0)
        {
            var udpateItems = new List<CartStatusUpdateDto>();
            foreach (var item in purchaseInventroyResponce.PurchasedItems)
            {
                var crt = new CartStatusUpdateDto();
                crt.STATUS = item.Status;
                crt.ID = long.Parse(item.CartReference);
                udpateItems.Add(crt);
            }
            var updateCartResponse = await _customerCartRespository.CartUpdateAsync(udpateItems);

            var finalStatusProducts = purchaseInventroyResponce.PurchasedItems
                                               .Where(x => x.Status.ToUpper() == nameof(TransactionStatus.Completed).ToUpper() ||
                                                   x.Status.ToUpper() == nameof(TransactionStatus.Confirmed).ToUpper()).ToList();

            if (finalStatusProducts.Count > 0)
            {
                var cart = new List<CartStatusUpdateDto>();
                foreach (var item in finalStatusProducts)
                {
                    var crt = new CartStatusUpdateDto();
                    crt.STATUS = item.Status;
                    crt.ID = long.Parse(item.CartReference);
                    cart.Add(crt);
                }
                var updateditems = await _customerCartRespository.UpdateCartFinalStatusAsync(cart);

            }


        }
        return inventryresponse;
    }

    public async Task CreateOrderPaymentHistory(long OrderID, decimal orderAmount, string? transactionID, string action, bool? isFailure, bool? require3dSecure = false)
    {
        await _customerCartRespository.OrderPaymentCreationAsync(new OrderPaymentDto
        {
            OrderPaymentId = 0,
            CustomerOrderId = OrderID,
            CustomerId = _commonService.GetUserID(),
            TransactionId = transactionID,
            OrderAmount = orderAmount,
            IsPaymentSuccess = isFailure,
            CreatedBy = _commonService.GetUserID(),
            UpdatedBy = _commonService.GetUserID(),
            RequestId = _commonService.GetRequestID(),
            Action = action,
            Require3dSecure = (bool)require3dSecure!
        });
    }
    public async Task<bool> UpdateOrder(CustomerOrderDetailDto orderDetail)
    {
        var order = new OrderCreationDto()
        {
            CustomerOrderID = orderDetail.CustomerOrderID,
            PromoCode = orderDetail.PromoCode,
            DiscountTypeId = orderDetail.DiscountTypeId,
            DiscountInclusiveAmount = orderDetail.DiscountInclusiveAmount,
            DiscountAmount = orderDetail.DiscountAmount,
            ServiceFee = orderDetail.ServiceFee,
            TaxAmount = orderDetail.TaxAmount,
            TaxInclusiveAmount = orderDetail.TaxInclusiveAmount,
            TaxExclusiveAmount = orderDetail.TaxExclusiveAmount,
            TotalOrderAmount = orderDetail.TotalOrderAmount,
            Currency = orderDetail.Currency,
            OrderStatus = OrderStatusEnum.Checkout.Getkey(),
            UserID = _commonService.GetUserID(),
            PaymentMethod = orderDetail.PaymentMethod

        };
        var orderID = await _customerCartRespository.OrderCreationAsync(order);
        return orderID > 0 ? true : false;
    }

    public async Task<decimal> CalculateServiceFeeAmount(string productType, decimal? productSellingPrice)
    {
        decimal ServiceFeeAmount = 0;        

        var serviceFeeConfiguration = await _customerCartRespository.GetServiceFeeConfiguration();
        bool isBusinessConditionMatch = false;
        bool isPercentage = false;
        decimal PercentageValue = 0;
        decimal FlatValue = 0;
        if (serviceFeeConfiguration != null && serviceFeeConfiguration.Count > 0)
        {
            foreach (var item in serviceFeeConfiguration)
            {
                var condition = string.Empty;
                //condition = item.LowerValue.ToString() + " "
                //            + item.LeftBusinessCondition.ToString() + " "
                //            + productSellingPrice.ToString() + " "
                //            + "&&" + " "
                //            + productSellingPrice.ToString() + " "
                //            + item.RightBusinessCondition.ToString() + " "
                //            + item.UpperValue.ToString();


                if (item.LeftBusinessCondition == "<=" && item.RightBusinessCondition == "<")
                {
                    if (item.LowerValue <= productSellingPrice && productSellingPrice < item.UpperValue)
                    {
                        isBusinessConditionMatch = true;
                        PercentageValue = item.AppliedValue;
                        FlatValue = item.AppliedValue;
                        if (item.BusinessCriteria == "%")
                            isPercentage = true;
                        break;
                    }
                }
            }

            if (isBusinessConditionMatch && isPercentage)
            {
                ServiceFeeAmount = ((decimal)((PercentageValue / 100) * productSellingPrice)!);
            }
            else if (isBusinessConditionMatch)
                ServiceFeeAmount = FlatValue;
        }       

        return ServiceFeeAmount;
    }







}

