﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrasnferHome.Models.Configurations
{
    public class SerilogConfig
    {
        public string FilePath { get; set; }
    }
}
