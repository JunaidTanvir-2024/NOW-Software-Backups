﻿using FluentValidation;

using System.ComponentModel;

namespace Voucherify.Api.Features.Promotions.Requests;

public class GetPromotionTiersRequest
{
    [DefaultValue(1)]
    public int PageNumber { get; set; }
    [DefaultValue(10)]
    public int PageSize { get; set; }
}
internal class GetPromotionsRequestValidator : AbstractValidator<GetPromotionTiersRequest>
{
    public GetPromotionsRequestValidator()
    {
        RuleFor(p => p.PageNumber).GreaterThan(0);
        RuleFor(p => p.PageSize).GreaterThan(0);
    }
}