namespace Infrastructure.Persistence.Repositories;

internal sealed class UnitOfWork : IUnitOfWork
{
    public UnitOfWork(
        /*IDbHelpers dbHelpers,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService,
        IOptions<CacheSettings> cacheSettings,*/

        IOptions<DatabaseSettings> databaseSettings)
    {
        UserRepo = new UserRepository(databaseSettings/*, dbHelpers, cacheSettings, cacheService, cacheKeyService*/);

    }

    public IUserRepository UserRepo { get; }

}