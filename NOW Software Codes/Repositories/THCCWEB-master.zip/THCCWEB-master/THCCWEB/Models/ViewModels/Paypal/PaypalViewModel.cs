﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using THCCWEB.Attributes;

namespace THCCWEB.Models.ViewModels.Paypal
{
    public class PaypalViewModel
    {
        public string EmailAddress { get; set; }
        [CollectionValidation(values: new int[] { 5, 10, 20})]
        public int CallingCardPrice { get; set; }
        public string ProductCode { get; set; }
        public string ProductItemCode { get; set; }
        public string RechargePIN { get; set; }
    }

}
