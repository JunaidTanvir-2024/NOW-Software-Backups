﻿using System.ComponentModel;

using FluentValidation;

namespace Voucherify.Api.Features.Loyalties.Requests;

public class GetLoyaltiesRequest
{
    [DefaultValue(1)]
    public int PageNumber { get; set; }
    [DefaultValue(10)]
    public int PageSize { get; set; }
}

internal class GetLoyaltiesRequestValidator : AbstractValidator<GetLoyaltiesRequest>
{
    public GetLoyaltiesRequestValidator()
    {
        RuleFor(p => p.PageNumber).GreaterThan(0);
        RuleFor(p => p.PageSize).GreaterThan(0);
    }
}