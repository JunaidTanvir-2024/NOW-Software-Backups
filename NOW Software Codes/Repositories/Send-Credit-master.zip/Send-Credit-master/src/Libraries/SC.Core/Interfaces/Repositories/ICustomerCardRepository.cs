﻿using SC.Core.Models.Dtos.CustomerCard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Interfaces.Repositories;
public interface ICustomerCardRepository
{
    Task<long> AddCustomerCardAsync(CustomerCardDto order);
    Task<List<CustomerCardDto>> GetCustomerCardsAsync(string userID);
    Task<bool?> RemoveCardAsync(long CardId);
    Task<bool?> MarkCardAsDefaultAsync(long CardId, string UserID);
}

