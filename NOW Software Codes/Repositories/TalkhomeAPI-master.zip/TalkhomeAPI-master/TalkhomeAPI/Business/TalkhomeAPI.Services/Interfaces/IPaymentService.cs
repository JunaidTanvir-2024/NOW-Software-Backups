﻿using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Pay360ApiContracts;
using TalkhomeAPI.Models.PaypalApiContracts;

namespace TalkhomeAPI.Services.Interfaces
{
    public interface IPaymentService
    {
        Task<GenericApiResponse<VoucherRechargeResponseModel>> VoucherRecharge(VoucherRequestModel model);
        Task<GenericApiResponse<Pay360CardsResponse>> Pay360GetCards(string msisdn);
        Task<GenericApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(string msisdn);
        Task<GenericApiResponse<bool>> SetAutoTopUp(SetAutoTopUpRequestModel model, string msisdn, string currency);
        Task<GenericApiResponse<bool>> SetCustomerDefaultCard(SetCustomerDefaultCardRequestModel model, string msisdn);
        Task<GenericApiResponse<bool>> RemoveCard(RemoveCardRequestModel model, string msisdn);
        Task<GenericApiResponse<Pay360CustomerModel>> GetCustomer(Pay360CustomerRequestModel model);
        Task<GenericApiResponse<Pay360Resume3DResponseModel>> Resume3DTransaction(Pay360Resume3DRequestModel request);

        Task<GenericApiResponse<NewCustomerPaymentResponseModel>> NewCustomerPayment(NewCustomerPaymentRequestModel model);
        Task<GenericApiResponse<BundlePurchaseViaABResponseModel>> BundlePurchaseViaAccountBalance(
                                        BundlePurchaseViaABRequestModel model, string accountId, string msisdn, string currency);
        Task<GenericApiResponse<NewCardPaymentResponseModel>> NewCardPayment(NewCardPaymentRequestModel model);
        Task<GenericApiResponse<ExistingCardPaymentResponseModel>> ExistingCardPayment(ExistingCardPaymentRequestModel model);
        Task<GenericApiResponse<PaypalPaymentResponseModel>> PaypalPayment(PaypalPaymentRequestModel model);
        Task<GenericApiResponse<PaypalPaymentCallBackResponseModel>> PaypalPaymentCallBack(PaypalPaymentCallBackRequestModel model);
        Task<GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>> PaypalByPay360PaymentCallBack(
                                        PaypalByPay360PaymentCallBackRequestModel model);
    }
}
