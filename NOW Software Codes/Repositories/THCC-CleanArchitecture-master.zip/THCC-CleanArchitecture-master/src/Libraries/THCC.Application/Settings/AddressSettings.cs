﻿namespace THCC.Application.Settings
{
    public class AddressSettings
    {
        public const string SectionName = "AddressSettings";
        public static AddressSettings Bind = new AddressSettings();
        public string? ApiKey { get; set; }
        public string? ApiEndpoint { get; set; }
    }
}
