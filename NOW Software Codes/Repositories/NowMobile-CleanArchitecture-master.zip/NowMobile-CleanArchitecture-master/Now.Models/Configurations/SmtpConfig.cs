﻿


namespace Now.Models.Configurations;

    public class SmtpConfig
    {
        public string? Server { get; set; }
        public string? From { get; set; }
        public string? FromForCustomer { get; set; }
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public string[] To { get; set; }
        public string[] CC { get; set; }
        public string[] Bcc { get; set; }
        public string? Subject { get; set; }
        public bool SendEmailToCustomer { get; set; }
    }

