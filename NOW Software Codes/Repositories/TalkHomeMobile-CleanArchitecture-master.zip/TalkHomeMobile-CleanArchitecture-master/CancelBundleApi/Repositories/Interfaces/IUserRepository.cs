using CancelBundleApi.Models.DbModels;

namespace CancelBundleApi.Repositories.Interfaces;

public interface IUserRepository //: IServicesType.IScopedService
{

    /// <summary>
    /// get msisdn detail
    /// </summary>
    /// <param name="msisdn"></param>
    /// <returns></returns>
    Task<MsisdnDetails> GetMsisdnDetail(string msisdn);
}