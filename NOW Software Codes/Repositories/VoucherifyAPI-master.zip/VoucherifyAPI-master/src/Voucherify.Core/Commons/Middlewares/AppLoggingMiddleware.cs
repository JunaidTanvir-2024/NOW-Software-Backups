using System.Diagnostics;
using System.Text;
using System.Text.Json;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;

using Sentry;

using Serilog;

using Voucherify.Core.Services.Loggers;

namespace Voucherify.Core.Commons.Middlewares;

public class AppLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger _logger;
    private readonly ILoggerRepository _loggerRepository;

    public AppLoggingMiddleware(RequestDelegate next, ILogger logger, ILoggerRepository loggerRepository)
    {
        _next = next;
        _logger = logger;
        _loggerRepository = loggerRepository;
    }

    public async Task Invoke(HttpContext context)
    {
        var stopwatch = Stopwatch.StartNew();

        var originalRequestBody = context.Request.Body;
        var originalResponseBody = context.Response.Body;

        // Read the request body
        var requestBody = await ReadRequestBody(context.Request);
        var responseStream = new MemoryStream();

        var responseBody = string.Empty;

        var correlationId = Guid.NewGuid(); // Generate a new correlation ID
        context.Items["CorrelationIdKey"] = correlationId.ToString();
        try
        {
            // Log the request
            _logger.Information($"[Request] {context.Request.Method} {context.Request.Path}{context.Request.QueryString} {requestBody}");

            // Replace the request body with a new memory stream
            using var requestBodyStream = new MemoryStream(Encoding.UTF8.GetBytes(requestBody));
            context.Request.Body = requestBodyStream;

            // Capture the response
            context.Response.Body = responseStream;

            // Continue processing the request
            await _next(context);

            // Log the response
            responseStream.Seek(0, SeekOrigin.Begin);
            responseBody = await ReadResponseBody(context, responseBody, originalResponseBody, responseStream);
            _logger.Information($"[Response] {context.Response.StatusCode} {responseBody}");

            //Calculating Response Size
            var responseSize = Encoding.UTF8.GetByteCount(responseBody);

            // Save log entry to the database
            UpsertAppLogs(context, stopwatch, context.Response.StatusCode, requestBody, responseBody, responseSize, string.Empty);
        }
        catch (Exception ex)
        {
            _logger.Error(ex,$"Message: {ex.Message}, StackTrace: {ex.StackTrace?.ToString()}");

            // Set the error message in the log entry
            UpsertAppLogs(context, stopwatch, StatusCodes.Status500InternalServerError, requestBody, responseBody, 0, ex.StackTrace?.ToString());

            // Re-throw the exception to allow proper error handling by Exception middleware
            throw;
        }
        finally
        {
            // Reset the request body stream
            await ResetRequestBodyStream(context, originalRequestBody, originalResponseBody, responseStream);
        }
    }


    private void UpsertAppLogs(HttpContext context, Stopwatch stopwatch, int statusCode, string requestBody, string? responseBody, int responseSize, string? errorStackTrace)
    {
        (string serializedHeaders, string uniqueReference, string productCode, string productItemCode) = SerializeHeaders(context!.Request.Headers);

        if (string.IsNullOrEmpty(uniqueReference))
        {
            _logger.Debug($"Unique Reference is not found against this request {requestBody}");
        }

        var logEntry = new AppLogEntry
        {
            Timestamp = DateTime.UtcNow,
            RequestPath = context.Request.GetDisplayUrl(),
            RequestMethod = context.Request.Method,
            RequestBody = requestBody,
            ResponseBody = responseBody,
            StatusCode = statusCode,
            Duration = stopwatch.ElapsedMilliseconds,
            ClientIP = context?.Connection.RemoteIpAddress?.ToString(),
            UserAgent = context?.Request.Headers["User-Agent"],
            ResponseSize = responseSize,
            ErrorMessage = errorStackTrace,
            CorrelationId = context?.Items["CorrelationIdKey"]!.ToString(),
            Headers = serializedHeaders,
            QueryString = context?.Request.QueryString.ToString(),
            UniqueReference = uniqueReference,
            ProductCode = productCode,
            ProductItemCode = productItemCode,
        };

        // Save log entry to the database using your preferred data access method (e.g., Dapper, Entity Framework, etc.)
        _loggerRepository.UpsertAppLogEntry(logEntry);
    }
    private static async Task<string> ReadRequestBody(HttpRequest request)
    {
        request.EnableBuffering();

        var body = request.Body;

        using (var memoryStream = new MemoryStream())
        {
            await body.CopyToAsync(memoryStream);
            memoryStream.Seek(0, SeekOrigin.Begin);

            using (var reader = new StreamReader(memoryStream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true, bufferSize: 4096, leaveOpen: true))
            {
                var requestBody = await reader.ReadToEndAsync();
                request.Body.Seek(0, SeekOrigin.Begin);
                return requestBody;
            }
        }
    }

    private static async Task<string> ReadResponseBody(HttpContext context, string responseBody, Stream originalResponseBody, MemoryStream responseStream)
    {
        responseBody = await new StreamReader(responseStream).ReadToEndAsync();
        responseStream.Seek(0, SeekOrigin.Begin);
        context.Response.Body = originalResponseBody;
        return responseBody;
    }

    private static async Task ResetRequestBodyStream(HttpContext context, Stream originalRequestBody, Stream originalResponseBody, MemoryStream responseStream)
    {
        context.Request.Body = originalRequestBody;
        context.Response.Body = originalResponseBody;
        responseStream.Seek(0, SeekOrigin.Begin);
        await responseStream.CopyToAsync(originalResponseBody);
    }
    private static (string serializedHeaders, string uniqueReference, string productCode, string productItemCode) SerializeHeaders(IHeaderDictionary headers)
    {
        var serializedHeaders = new Dictionary<string, string>();

        foreach (var header in headers)
        {
            serializedHeaders[header.Key] = header.Value.ToString();
        }

        string uniqueReference = serializedHeaders.TryGetValue("UniqueReference", out var uniqueReferenceValue)
            ? uniqueReferenceValue
            : "";

        string productCode = serializedHeaders.TryGetValue("ProductCode", out var productCodeValue)
            ? productCodeValue
            : "";

        string productItemCode = serializedHeaders.TryGetValue("ProductItemCode", out var productItemCodeValue)
            ? productItemCodeValue
            : "";


        return (JsonSerializer.Serialize(serializedHeaders), uniqueReference, productCode, productItemCode);
    }
}
