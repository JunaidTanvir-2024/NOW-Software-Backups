﻿namespace THCC.Application.Models.Dtos;

public class AccountSummaryDto
{
    public AccountSummaryDto()
    {
        RedeemablePoints = new List<KeyValuePair<int, string>>();
    }

    public UserDto UserInfo { get; set; } = default!;
    public ProductDto ProductInfo { get; set; } = default!;
    public AutoTopupResponseDto AutoTopupInfo { get; set; } = default!;
    public int Points { get; set; }
    public int MinimumRedeemablePoints { get; set; }
    public List<KeyValuePair<int, string>> RedeemablePoints { get; set; }
}

public class ProductDto
{
    public string CardNumber { get; set; } = default!;
    public string PinNumber { get; set; } = default!;
    public string Credit { get; set; } = default!;
    public LastTopupDto LastTopup { get; set; } = default!;
}

public class LastTopupDto
{
    public string Amount { get; set; } = default!;
    public string Date { get; set; } = default!;
}