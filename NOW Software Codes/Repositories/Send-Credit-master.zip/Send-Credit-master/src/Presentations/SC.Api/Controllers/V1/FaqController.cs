﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using SC.Core.Features.Countries.Requests;
using SC.Core.Features.FAQs.Requests;

namespace SC.Api.Controllers.V1
{
    [ApiVersion(1.0)]
    public sealed class FaqController : BaseApiController
    {
        //  [Authorize]
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult> GetFaqByOperator(GetFaqByOperatorRequest request)
        {
            var result = await Mediator.Send(request);

            if (result.IsSuccess)
            {
                return Ok(result);
            }
            return NotFound(result);
        }

    }
}