﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SC.Api.Model.Country;
using SC.Api.Model.CustomerOrder;
using SC.Core.Features.Countries.Requests;
using SC.Core.Features.CustomerOrder.Requests;

namespace SC.Api.Controllers.V1;
[ApiVersion(1.0)]
public sealed class ProcessOrderController : BaseApiController
{
    [Authorize]
    [HttpPost]
    public async Task<ActionResult> ProcessOrder(ProcessOrderPaymentModel paymentCard)
    {
        var cardModel = new ProcessOrderRequest();
        cardModel.Card = paymentCard.Card;
        cardModel.PromoCode = paymentCard.PromoCode;
        cardModel.paymentMethod = paymentCard.paymentMethod;
        var result = await Mediator.Send(cardModel);

        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }

    [Authorize]
    [HttpPost("ResumePayment")]
    public async Task<ActionResult> ResumePayment(ResumePaymentModel model)
    {

        var result = await Mediator.Send(new ResumePaymentRequest() { TransactionId = model.TransactionId });

        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}

