﻿using System;
using System.Collections.Generic;
using System.Text;

namespace THM.Models.Configurations
{
    public class AirShipConfig
    {
        public bool IsActive { get; set; }
        public string AccountTagGroupName { get; set; }
        public string CartTagGroupName { get; set; }
        public string UserTagGroupName { get; set; }
        public string PurchaseTagGroupName { get; set; }
        public string ActivityTagGroupName { get; set; }
        public string ApiEndpoint { get; set; }
    }
}
