﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace TalkhomeAPI.Utilities
{
    public static class UserExtensions
    {
        public static string AccountId(this ClaimsPrincipal user)
        {
            return user.Claims.First(i => i.Type == "accountId").Value;
        }
        public static string Msisdn(this ClaimsPrincipal user)
        {
            return user.Claims.First(i => i.Type == "msisdn").Value;
        }
        public static string Currency(this ClaimsPrincipal user)
        {
            return user.Claims.First(i => i.Type == "currency").Value;
        }

    }
}
