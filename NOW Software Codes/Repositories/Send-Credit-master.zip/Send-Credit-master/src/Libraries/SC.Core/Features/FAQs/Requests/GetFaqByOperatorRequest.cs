﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SC.Core.Features.FAQs.Requests
{


    public sealed class GetFaqByOperatorRequest : IRequest<IResultWrapper>
    {
        [JsonPropertyName("page")]
        public int Page { get; set; } = default!;

        [JsonPropertyName("recordsPerPage")]
        public int RecordsPerPage { get; set; } = default!;

        [JsonPropertyName("operatorShortCode")]
        public string? OperatorShortCode { get; set; }

    
    }

    public sealed class GetFaqByOperatorShortCodeRequestValidator : AbstractValidator<GetFaqByOperatorRequest>
    {
        public GetFaqByOperatorShortCodeRequestValidator()
        { 
             
        
        
        }
    }
}
