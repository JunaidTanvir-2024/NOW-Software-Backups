﻿var ProgressClass_sum = "";
var TextClass_sum = "";

var userCallHistoryTable_sum = null;
var userSmsHistoryTable_sum = null;
var userDataHistoryTable_sum = null;
var userPaymentHistoryTable_sum = null;

$(document).ready(function () {

    ShowUserSummary_sum($("#dplUserProducts").val());
    GetUserCallHistory_sum($("#dplUserProducts").val());

    $("#dplUserProducts").change(function () {
        ShowUserSummary_sum($("#dplUserProducts").val());
        Show_Hide_History_Sections($('#dpl_NowMobileHisotry_sum').val());
        $('#TopUp_Msisdn_AccountSummary').val($("#dplUserProducts").val());
    });

    $('#dpl_NowMobileHisotry_sum').change(function () {
        Show_Hide_History_Sections($('#dpl_NowMobileHisotry_sum').val());
    });

});

function ShowUserSummary_sum(ID) {
    $.ajax({
        url: "/Account/GetUserSummary",
        type: "POST",
        data: { ProductRef: ID },
        beforeSend: function (xhr) {
            $('#UserSummaryFailureAlert').slideUp();
            $('.loading-bar').show();
        },
        success: function (response) {
            if (response != null) {
                if (response.status == true && response.data != null) {

                    ResetSummaryData_sum();

                    if (response.data.mobileAccount != null) {
                        $('#txtPhoneNumber').text(response.data.mobileAccount.msisdn == null ? "N/A" : response.data.mobileAccount.msisdn);
                        $('#txtRemainingCredit').text(response.data.mobileAccount.credit == null ? "N/A" : "£" + parseFloat(response.data.mobileAccount.credit).toFixed(2));
                        $('#txtActiveSince').text(response.data.mobileAccount.firstDate == null ? "N/A" : response.data.mobileAccount.firstDate.split(' ')[0]);
                    }
                    else {
                        $('#txtPhoneNumber').text("N/A");
                        $('#txtRemainingCredit').text("N/A");
                        $('#txtActiveSince').text("N/A");
                    }
                    if (response.data.lastTopUp != null) {
                        $('#txttopupAmount').text(response.data.lastTopUp.amount == null ? "N/A" : "£" + parseFloat(parseFloat(response.data.lastTopUp.amount)).toFixed(0));
                        $('#txttopupDate').text(response.data.lastTopUp.date == null ? "N/A" : response.data.lastTopUp.date.split(' ')[0]);
                    }
                    else {
                        $('#txttopupAmount').text("N/A");
                        $('#txttopupDate').text("N/A");
                    }

                    if (response.data.bundleList != null && response.data.bundleList.length > 0) {

                        var html = '';

                        $.each(response.data.bundleList, function (key, val) {

                            if (val.expiry != null) {

                                var percentageMinute = parseFloat(100 - parseFloat((((parseInt(val.minutes) - parseInt(val.remainingMinutes)) * 100) / parseInt(val.minutes)))).toFixed(0);
                                var percentageText = parseFloat(100 - parseFloat((((parseInt(val.texts) - parseInt(val.remainingTexts)) * 100) / parseInt(val.texts)))).toFixed(0);
                                var percentageData = parseFloat(100 - parseFloat((((parseInt(val.data) - parseInt(val.remainingData)) * 100) / parseInt(val.data)))).toFixed(0);


                                if (new Date() < new Date(val.expiry)) {

                                    html += "<div class=\"block\" style=\"padding-bottom:30px;\">";

                                    html += "<div class=\"clearfix\">" +
                                        "<div class=\"plan-name  float-none float-md-left\"><b>" + val.brandedName + "</b></div>";

                                    html += "<div class=\"plan-name float-none float-md-right red\">Expires in " + ((new Date(val.expiry) - new Date()) / 86400000).toFixed(0) + " day(s)</div>" +
                                        "</div>";
                                    if (val.minutes != 0 || val.texts != 0 || val.data != 0) {
                                        html += "<hr/>";
                                    }

                                    html += "<div class=\"row AllCardsRow\">";

                                    if (val.minutes != 0) {
                                        AddProgressClass_sum(percentageMinute);
                                        html += NotExpiredCards_sum(val.minutes, val.remainingMinutes, percentageMinute, "Minutes");
                                    }
                                    if (val.texts != 0) {
                                        AddProgressClass_sum(percentageText);
                                        html += NotExpiredCards_sum(val.texts, val.remainingTexts, percentageText, "Texts");
                                    }
                                    if (val.data != 0) {
                                        AddProgressClass_sum(percentageData);
                                        html += NotExpiredCards_sum(val.data, val.remainingData, percentageData, "Data");
                                    }
                                    html += "</div>" + CommonCardsHtml_sum(val) + "</div></div>";

                                }
                                else {

                                    html += "<div class=\"block red-bg expired\">";

                                    html += "<div class=\"clearfix\">" +
                                        "<div class=\"float-none float-md-left\"><b>" + val.brandedName + "</b></div><div class=\"float-none float-md-right\">Expired</div>" +
                                        "</div>";

                                    if (val.minutes != 0 || val.texts != 0 || val.data != 0) {
                                        html += "<hr/>";
                                    }

                                    html += "<div class=\"row\">";

                                    if (val.minutes != 0) {
                                        AddProgressClass_sum(percentageMinute);
                                        html += ExpiredCards(val.minutes, val.remainingMinutes, percentageMinute, "Minutes");
                                    }
                                    if (val.texts != 0) {
                                        AddProgressClass_sum(percentageText);
                                        html += ExpiredCards(val.texts, val.remainingTexts, percentageText, "Texts");
                                    }
                                    if (val.data != 0) {
                                        AddProgressClass_sum(percentageData);
                                        html += ExpiredCards(val.data, val.remainingData, percentageData, "Data");
                                    }

                                    html += "</div>" + CommonCardsHtml_sum(val) + "</div></div>";
                                }
                            }


                            html += "  <div class=\"form-row\">" +
                                "<div class=\"col-12 mt-2 mb-2 SavSettingsFailureAlert_autoRenew\" data-Uuid=" + val.uuid + "  style=\"display: none\" >" +
                                "   <div class=\"alert alert-danger\">" +
                                "      <span class=\"SavSettingsFailureMessage_autoRenew\" data-Uuid=" + val.uuid + "></span>" +
                                " </div>" +
                                "</div >" +

                                " <div class=\"col-12 mt-2 SavSettingsSuccessAlert_autoRenew\" data-Uuid=" + val.uuid + "  style=\"display: none\">" +
                                "    <div class=\"alert alert-success\">" +
                                "       <span class=\"SavSettingsSuccessMessage_autoRenew\" data-Uuid=" + val.uuid + "></span>" +
                                "  </div>" +
                                "</div>" +
                                " </div >";

                        });

                        $('#PlansContent_Summary').html('');
                        $('#PlansContent_Summary').css('padding', "20px");
                        $('#PlansContent_Summary').html(html);

                        AddColumnClass_sum();
                    }
                    else {
                        $('#PlansContent_Summary').css('padding', "20px").css('padding-left', "70px");
                        $('#PlansContent_Summary').html('No Records were found.');
                    }
                }
                else {

                    $('#UserSummaryFailureAlert').slideDown().delay(4000).slideUp();
                }
            }
            else {

                $('#UserSummaryFailureAlert').slideDown().delay(4000).slideUp();
            }
        },
        complete: function (xhr, status) {
            $('.loading-bar').hide();
        },
        error: function (xhr, status, error) {

            $('#UserSummaryFailureAlert').slideDown().delay(4000).slideUp();
        }
    });
}

function ResetSummaryData_sum() {

    $('#txtPhoneNumber').text('N/A');
    $('#txtRemainingCredit').text('N/A');
    $('#txtActiveSince').text('N/A');

    $('#txttopupAmount').text("N/A");
    $('#txttopupDate').text("N/A");

    $('#PlansContent_Summary').css('padding', "20px").css('padding-left', "70px");
    $('#PlansContent_Summary').html('No Records were found.');
}

function AddProgressClass_sum(percentage) {

    if (percentage >= 0 && percentage <= 50) {
        ProgressClass_sum = "bg-danger";
        TextClass_sum = "text-danger";
    }
    else if (percentage >= 50 && percentage <= 75) {
        ProgressClass_sum = "bg-warning";
        TextClass_sum = "text-warning";
    }
    else {
        ProgressClass_sum = "bg-success";
        TextClass_sum = "text-success";
    }

}

function NotExpiredCards_sum(Total, Remaining, percentage, Text) {

    if (Text == "Data") {
        Text = Text + " MB";
    }

    return "<div class=\"col-lg-4\"><h6>" + Text + " (" + Remaining + " of " + Total + ")</h6>" +
        "<div class=\"pt-1\">" +
        "<div class=\"progress\">" +
        "<div class=\"progress-bar progress-bar-striped " + ProgressClass_sum + "\" role=\"progressbar\" style=\"width:" + percentage + "%\" aria-valuenow=" + percentage + " aria-valuemin=\"0\" aria-valuemax=\"100\">" + percentage + "%</div>" +
        "</div>" +
        "</div></div>";
}

function ExpiredCards(Total, Remaining, percentage, Text) {

    if (Text == "Data") {
        Text = Text + " MB";
    }

    return "<div class=\"col-lg-4\"><h6>" + Text + " (" + Remaining + " of " + Total + ")</h6>" +
        "<div class=\"pt-1\">" +
        "<div class=\"progress\">" +
        "<div class=\"progress-bar progress-bar-striped " + ProgressClass_sum + "\" role=\"progressbar\" style=\"width:" + percentage + "%\" aria-valuenow=" + percentage + " aria-valuemin=\"0\" aria-valuemax=\"100\">" + percentage + "%</div>" +
        "</div>" +
        "</div></div>";

}

function CommonCardsHtml_sum(val) {

    if (val.packageCategory != 8) {
        var isRenew = val.isRenew == true ? '  Checked' : '';

        //return "<button type=\"button\" class=\"btn btn-primary btn-primary-2\" onclick=\"BuyPlanAgain_AccSum(this)\" data-id=" + val.id + " >Buy again £" + val.totalCostPence + "</button>" +
        //    "<div class=\"float-none float-md-right\">" +
        //    "<label class=\"switch float-left\">" +
        //    "   <input type=\"checkbox\" class=\"isAutoRenew\" value=\"true\" name=\"isAutoRenew\" data-Uuid=" + val.uuid + "   " + isRenew + "   data-totalCostPence=" + val.totalCostPence + ">" +
        //    "      <span class=\"slider round\"></span>" +
        //    "     <input type=\"hidden\" value=\"false\" name=\"isAutoRenew\">" +
        //    "</label>" +
        //    "<div class=\"package-price autoRenewSwitchText float-left\">Auto Renew</div>" +
        //    "<div class=\"help pl-2  float-left autorenewText\">" +
        //    "<a class=\"popup-with-move-anim\" href=\"#auto-renew\" >" +
        //    "<i class=\"fas fa-info-circle\"></i>" +
        //    "</a >" +
        //    "</div>" +
        //    "</div>";


        var planSec = ""
        planSec = "<hr><div class=\"row\"><div class=\"col-sm-8\">";
        if (isRenew) {
            planSec += '<label for="AutopToupToggle_topup_checkout" class="pr-2 pt-2">Auto Renew Plan is Enabled</label></div>';
        }
        else {
            planSec += '<label for="AutopToupToggle_topup_checkout" class="pr-2 pt-2">Auto Renew Plan is Disabled</label></div>';
        }
        planSec += "<div class=\"col-sm-4\">" +
            "<button type=\"button\" class=\"btn btn-primary btn-primary-2\" onclick=\"BuyPlanAgain_AccSum(this)\" data-id=" + val.id + " >Buy</button>" +
            "</div>" +
            "</div>";
        return planSec;
    }
    else {
        return "";
    }
}

function AddColumnClass_sum() {

    for (var i = 0; i < $('.AllCardsRow').length; i++) {

        var childrenlength = $(".AllCardsRow")[i].children.length;
        if (childrenlength > 0) {

            if (childrenlength == 1) {
                $(".AllCardsRow")[i].children[0].className = 'col-lg-12'
            }
            else if (childrenlength == 2) {
                $(".AllCardsRow")[i].children[0].className = 'col-lg-6';
                $(".AllCardsRow")[i].children[1].className = 'col-lg-6';

            }
            else if (childrenlength == 3) {
                $(".AllCardsRow")[i].children[0].className = 'col-lg-4';
                $(".AllCardsRow")[i].children[1].className = 'col-lg-4';
                $(".AllCardsRow")[i].children[2].className = 'col-lg-4';
            }
        }
        else {
            continue;
        }
    }
}

function BuyPlanAgain_AccSum(current) {
    $('#SelectedPlanId_AccSum').val(current.dataset.id);
    $('#BundleBuyForm_AccSum').submit();
}

function Show_Hide_History_Sections(val) {

    $('#UserSmsHistoryTable,#UserCallingHistoryTable,#UserDataHistoryTable,#UserPaymentHistoryTable').hide();
    $('#UserSmsHistoryTable_wrapper,#UserCallingHistoryTable_wrapper,#UserDataHistoryTable_wrapper,#UserPaymentHistoryTable_wrapper').hide();

    if (val == 1) {
        GetUserCallHistory_sum($("#dplUserProducts").val());
        $('#UserCallingHistoryTable_wrapper').show();
        $('#UserCallingHistoryTable').show();
    }
    else if (val == 2) {
        GetUserSmsHistory_sum($("#dplUserProducts").val());
        $('#UserSmsHistoryTable_wrapper').show();
        $('#UserSmsHistoryTable').show();
    }
    else if (val == 3) {
        GetUserDataHistory_sum($("#dplUserProducts").val());
        $('#UserDataHistoryTable_wrapper').show();
        $('#UserDataHistoryTable').show();
    }
    else if (val == 4) {
        GetUserPaymentHistory_sum($("#dplUserProducts").val());
        $('#UserPaymentHistoryTable_wrapper').show();
        $('#UserPaymentHistoryTable').show();
    }
}

function GetUserSmsHistory_sum(currentProduct) {
    if (userSmsHistoryTable_sum != null) {
        userSmsHistoryTable_sum.destroy();
    }

    userSmsHistoryTable_sum = $("#UserSmsHistoryTable").DataTable({
        "orderMulti": false,
        "order": [],
        "lengthChange": false,
        "searching": false,
        "processing": true,
        "responsive": true,
        "pagingType": "simple",
        "language": {
            "emptyTable": "Sms history not found"
        },
        "ajax": {
            "url": "/Account/GetUserSmsHistory",
            "type": "GET",
            "data": function (d) {
                d.ProductRef = currentProduct;
            },
            "error": function () {
                $('.dataTables_empty').text('Failed to load sms history.');
            }
        },
        "columns": [
            { "data": "called_party_number", "autoWidth": true },
            { "data": "date", "autoWidth": true },
            { "data": "number_of_sms", "autoWidth": true },
            {
                "data": "subscriber_charge", "autoWidth": true,
                "render": function (data) {
                    if (data != null) {
                        return "£" + parseFloat(data).toFixed(2);
                    }
                }
            }
        ]
    });
}

function GetUserCallHistory_sum(currentProduct) {

    if (userCallHistoryTable_sum != null) {
        userCallHistoryTable_sum.destroy();
    }

    userCallHistoryTable_sum = $("#UserCallingHistoryTable").DataTable({
        "orderMulti": false,
        "order": [],
        "lengthChange": false,
        "searching": false,
        "processing": true,
        "responsive": true,
        "pagingType": "simple",
        "language": {
            "emptyTable": "Call history not found"
        },
        "ajax": {
            "url": "/Account/GetUserCallHistory",
            "type": "GET",
            "data": function (d) {
                d.ProductRef = currentProduct;
            },
            "error": function () {
                $('.dataTables_empty').text('Failed to load call history.');
            }
        },
        "columns": [
            { "data": "called_party_number", "autoWidth": true },
            { "data": "start_time", "autoWidth": true },
            {
                "data": "duration", "autoWidth": true,
                "render": function (data) {
                    if (data != null && data != "") {
                        return ConvertTime_sum(parseInt(data));
                    }
                }
            },
            {
                "data": "subscriber_charge", "autoWidth": true,
                "render": function (data) {
                    if (data != null) {
                        return "£" + parseFloat(data).toFixed(2);
                    }
                }
            }
        ]
    });

}

function GetUserDataHistory_sum(currentProduct) {

    if (userDataHistoryTable_sum != null) {
        userDataHistoryTable_sum.destroy();
    }

    userDataHistoryTable_sum = $("#UserDataHistoryTable").DataTable({
        "orderMulti": false,
        "order": [],
        "lengthChange": false,
        "searching": false,
        "processing": true,
        "responsive": true,
        "pagingType": "simple",
        "language": {
            "emptyTable": "Data history not found"
        },
        "ajax": {
            "url": "/Account/GetUserDataHistory",
            "type": "GET",
            "data": function (d) {
                d.ProductRef = currentProduct;
            },
            "error": function () {
                $('.dataTables_empty').text('Failed to load data history.');
            }
        },
        "columns": [
            { "data": "date", "autoWidth": true },
            { "data": "mb", "autoWidth": true },
            {
                "data": "subscriber_charge", "autoWidth": true,
                "render": function (data) {
                    if (data != null) {
                        return "£" + parseFloat(data).toFixed(2);
                    }
                }
            }
        ]
    });
}

function GetUserPaymentHistory_sum(currentProduct) {

    if (userPaymentHistoryTable_sum != null) {
        userPaymentHistoryTable_sum.destroy();
    }

    userPaymentHistoryTable_sum = $("#UserPaymentHistoryTable").DataTable({
        "orderMulti": false,
        "order": [],
        "lengthChange": false,
        "searching": false,
        "processing": true,
        "responsive": true,
        "pagingType": "simple",
        "language": {
            "emptyTable": "Payment history not found"
        },
        "ajax": {
            "url": "/Account/GetUserPaymentHistory",
            "type": "GET",
            "data": function (d) {
                d.ProductRef = currentProduct;
            },
            "error": function () {
                $('.dataTables_empty').text('Failed to load payment history.');
            }
        },
        "columns": [
            { "data": "paymentDate", "autoWidth": true },
            {
                "data": "reason", "autoWidth": true,
                "render": function (data) {
                    if (data != null && $.trim(data) == 'NowPayg Online Topup') {
                        return 'Online TopUp';
                    } else {
                        return data;
                    }
                }
            },
            {
                "data": "amount", "autoWidth": true,
                "render": function (data) {
                    if (data != null) {
                        return "£" + parseFloat(data).toFixed(2);
                    }
                }
            }
        ]
    });

}

function ConvertTime_sum(seconds) {

    //a day contains 60 * 60 * 24 = 86400 seconds
    //an hour contains 60 * 60 = 3600 seconds
    //a minut contains 60 seconds
    //the amount of seconds we have left
    var leftover = seconds;

    //how many full hours fits in the amount of leftover seconds
    var hours = Math.floor(leftover / 3600);

    //how many seconds are left
    leftover = leftover - (hours * 3600);

    //how many minutes fits in the amount of leftover seconds
    var minutes = Math.floor(leftover / 60);

    //how many seconds are left
    leftover = leftover - (minutes * 60);

    if (hours == 0) {
        hours = '00';
    }
    else if (hours < 10) {
        hours = '0' + hours;
    }

    if (minutes == 0) {
        minutes = '00';
    }
    else if (minutes < 10) {
        minutes = '0' + minutes;
    }


    if (leftover == 0) {
        leftover = '00';
    }
    else if (leftover < 10) {
        leftover = '0' + leftover;
    }


    return hours + ":" + minutes + ':' + leftover;
}
$(document).on('change', ".isAutoRenew", function () {
    var Uuid = $(this).attr('data-Uuid');
    var sameBundles = $(".isAutoRenew[data-Uuid=" + Uuid + "]");

    $(sameBundles).prop("checked", $(this).is(':checked'));

    SetBundleAutoRenewal(Uuid);
});

$(document).on('click', '.autorenewText', function () {
    var theGoodStuff = $("#auto-renew-model");
    $.magnificPopup.open({
        items: {
            src: theGoodStuff
        },
        type: 'inline',
        preloader: false,
        focus: '#username',
        modal: true,
        fixedContentPos: false
    });

});
function SetBundleAutoRenewal(bundle_id) {
    var Uuid = bundle_id;
    var isAutoRenew = $(".isAutoRenew[data-Uuid=" + Uuid + "]:first-child").is(':checked');
    var totalCostPence = $(".isAutoRenew[data-Uuid=" + Uuid + "]:first-child").attr('data-totalCostPence');

    $.ajax({
        url: "/Account/SetBundleAutoRenewal",
        type: "POST",
        data: {
            Msisdn: $('#dplUserProducts').val(),
            Uuid: Uuid,
            isAutoRenew: isAutoRenew,
            BundleAmount: totalCostPence

        },
        beforeSend: function (xhr) {
            $('.SavSettingsFailureAlert_autoRenew, .SavSettingsSuccessAlert_autoRenew').hide();
            $('.BtnSavSettings_autoRenew[data-Uuid=' + Uuid + ']').attr('disabled', true);
            $('.Spinner_SavSettings_autoRenew[data-Uuid=' + Uuid + ']').fadeIn();
        },
        success: function (response) {

            if (response != null) {

                if (response.status == true) {
                    $('.SavSettingsSuccessMessage_autoRenew[data-Uuid=' + Uuid + ']').text(response.message);
                    $('.SavSettingsSuccessAlert_autoRenew[data-Uuid=' + Uuid + ']').slideDown().delay(3000).slideUp();
                }
                else {
                    $('.SavSettingsFailureMessage_autoRenew[data-Uuid=' + Uuid + ']').text(response.message);
                    $('.SavSettingsFailureAlert_autoRenew[data-Uuid=' + Uuid + ']').slideDown().delay(5000).slideUp();
                }

            }
            else {
                $('.SavSettingsFailureMessage_autoRenew[data-Uuid=' + Uuid + ']').text('Something went wrong on server.');
                $('.SavSettingsFailureAlert_autoRenew[data-Uuid=' + Uuid + ']').slideDown().delay(3000).slideUp();
            }
        },
        complete: function (xhr, status) {

            $('.BtnSavSettings_autoRenew[data-Uuid=' + Uuid + ']').attr('disabled', false);
            $('.Spinner_SavSettings_autoRenew[data-Uuid=' + Uuid + ']').hide();
        },
        error: function (xhr, status, error) {
            $('.SavSettingsFailureMessage_autoRenew[data-Uuid=' + Uuid + ']').text('Something went wrong on server.');
            $('.SavSettingsFailureAlert_autoRenew[data-Uuid=' + Uuid + ']').slideDown().delay(3000).slideUp();
        }
    });
}