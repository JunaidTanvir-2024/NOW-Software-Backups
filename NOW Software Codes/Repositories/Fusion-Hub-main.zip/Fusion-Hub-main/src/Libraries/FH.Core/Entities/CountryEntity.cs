namespace FH.Core.Entities;
public sealed record CountryEntity : BaseEntity<long>
{
    public string? IsoCode2 { get; set; }
    public string? IsoCode3 { get; set; }
    public short? CallingCode { get; set; }
    public string? CountryName { get; set; }
    public string? IsoNumericCode { get; set; }
    public string? Continent { get; set; }

    // Pagination DTOs
    public int Page { get; set; }
    public int RecordsPerPage { get; set; }
    public bool IsActive { get; set; }
    public bool IsDeleted { get; set; }
}
