﻿//import { transcode } from "buffer";

var IsSignedIn = $('#hdnIsSignedIn').val();
var hdnUrl = $('#hdnUrl');
var logoutUrl = hdnUrl.data('logouturl');
var googleLoginUrl = hdnUrl.data('urlgooglelogin');
var facebookLoginUrl = hdnUrl.data('urlfacebooklogin');
var loginTypeFB = hdnUrl.data('logintypefb');
var loginTypeGoogle = hdnUrl.data('logintypegoogle');


function onSuccess(googleUser) {
    console.log('Logged in as: ' + googleUser.getBasicProfile().getName());
}
function onFailure(error) {
    console.log(error);
}

function onLoad() {
    gapi.load('auth2', function () {
        gapi.auth2.init({
            //Lab
            client_id: '371579881204-2k43g3nsn7tp7i9jtsud0aan9acrrtj7.apps.googleusercontent.com',
            //local
            //client_id: '643200762837-3lovi78j6f0q3ie7dj89vcfbkctpgg77.apps.googleusercontent.com',
            scope: 'profile email'
        });
    });
}

function onSignIn(googleUser) {

    if (IsSignedIn === 'True') {
        return;
    }

    var access_token = googleUser.getAuthResponse().access_token;

    var url = googleLoginUrl;
    url = url.replace("__AT__", access_token);
    $.getJSON(url, function (responseData) {
        if (responseData.status === "Success") {
            try {
                if (!(RedirectURL == null || RedirectURL == "" || RedirectURL == undefined)) {
                    window.location = RedirectURL;
                }
                else {
                    CheckUrlForRedirection();
                }
            } catch (e) {
                CheckUrlForRedirection();
            }
        }
        else {
            CheckUrlForRedirection();
        }
    });
}

function CheckUrlForRedirection() {
    if (document.URL.indexOf("verify-email?token") != -1) {
        window.location = "/home";
    }
    else if (document.URL.indexOf("login") != -1) {
        window.location = "/home";
    }
    else {
        window.location.reload();
    }
}

function onLogout() {
    var loginType = $('#hdnLoginType').val();
    if (loginType === loginTypeFB) {
        FB.getLoginStatus(function (response) {
            if (response.status === "unknown") {
                window.location.href = logoutUrl;
            }
            else {
                FB.logout(function (response) {
                    // user is now logged out
                    window.location.href = logoutUrl;
                });
            }
        }, true);

    }
    else if (loginType === loginTypeGoogle) {
        var auth2 = gapi.auth2.getAuthInstance();
        auth2.signOut().then(function () {
            window.location.href = logoutUrl;
        });
    }
    else {
        window.location.href = logoutUrl;
    }
}

//Facebook Social Login
window.fbAsyncInit = function () {
    FB.init({
        //local
        //appId: '339899880216983',
          //Lab
        appId: '477130233097924',
        cookie: true,
        xfbml: true,
        version: 'v3.3'
    });

    FB.AppEvents.logPageView();

    FB.getLoginStatus(function (response) {
        statusChangeCallback(response);
    });

};

function checkLoginState() {
    FB.getLoginStatus(function (response) {
        statusChangeCallback(response);
    });
}

function statusChangeCallback(response) {
    if (IsSignedIn === 'True') {
        return;
    }

    if (response.status === "connected") {
        var url = facebookLoginUrl;
        url = url.replace("__AT__", response.authResponse.accessToken);
        url = url.replace("__UI__", response.authResponse.userID);
        url = url.replace("&amp;", "&");
        $.getJSON(url, function (responseData) {
            if (responseData.status === "Success") {
                try {
                    if (!(RedirectURL == null || RedirectURL == "" || RedirectURL == undefined)) {
                        window.location = RedirectURL;
                    }
                    else {
                        CheckUrlForRedirection();
                    }
                } catch (e) {
                    CheckUrlForRedirection();
                }
            }
            else {
                CheckUrlForRedirection();
            }
        }).error(function (jqXHR, textStatus, errorThrown) {
            if (jqXHR.status == 400) {
                $('#SocailLoginFailureMessage').text(jqXHR.responseText);
                $('#SocailLoginFailureAlert').slideDown().delay(3000).slideUp();
            }
        })
    }
}

(function (d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) { return; }
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

