namespace DC.Core.Common.DTOs;
public record ClaimDto();
