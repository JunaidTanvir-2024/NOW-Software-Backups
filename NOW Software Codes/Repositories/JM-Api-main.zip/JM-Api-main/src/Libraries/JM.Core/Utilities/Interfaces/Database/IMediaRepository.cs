using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;

public interface IMediaRepository : ResolveAs.IScoped
{
    Task<Media> AddMedia(Media media);
    void UpdateMedia(Media media);
    Task<Media?> GetMedia(Expression<Func<Media, bool>> expression);
    Task<IEnumerable<Media>> GetMediaList(Expression<Func<Media, bool>> expression = default!);
}
