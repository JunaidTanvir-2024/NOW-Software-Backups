using Application.Common.Extensions.DependencyResolver;
using Application.Features.Bundle.Bundle;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Bundle.DataBundle;
using Application.Features.Bundle.InternationalBundle;
using Application.Features.Bundle.Model;
using Application.Features.Bundle.NationalBundle;
using Application.Features.Bundle.NationalPayAsYouGoBundle;
using Application.Features.Bundle.NationalRollingBundle;
using Application.Features.Bundle.RoamingBundle;
using Application.Features.Bundle.SimBundle;
using Application.Features.Bundle.SuggestedBundle;
using Application.Features.Bundle.TwelveMonthBundle;

namespace Application.Common.Interfaces.Repositories;
public interface IBundleRepository : IServicesType.IScopedService
{
    Task<Bundle> GetBundleById(BundleByIdRequest bundleByIdRequest);
    Task<IEnumerable<Bundle>> GetBundles(BundlesRequest bundlesRequest);
    Task<IEnumerable<Bundle>> GetSuggestedBundles(SuggestedBundleRequest suggestedBundleRequest);
    Task<IEnumerable<Bundle>> GetDataBundles(DataBundleRequest dataBundleRequest);
    Task<IEnumerable<Bundle>> GetInternationalBundlesByCountryCode(InternationalBundleRequest internationalBundleByCountryCodeRequest);
    Task<IEnumerable<Bundle>> GetNationalBundles(NationalBundleRequest nationalBundleRequest);
    Task<IEnumerable<Bundle>> GetNationalPayAsYouGoBundles(NationalPayAsYouGoBundleRequest nationalPayAsYouGoBundleRequest);
    Task<IEnumerable<Bundle>> GetNationalRollingBundles(NationalRollingBundleRequest nationalRollingBundleRequest);
    Task<List<Bundle>> GetSimBundles(SimBundleRequest simBundleRequest);
    Task SetBundleAutoRenewal(bool isRenew, string msisdn, string accountId, string bundleUuid, string userEmail, PaymentMethod paymentMethod, string cardPanMasked = null, string cardInitialTransactionId = null,bool isActive=true, bool AlreadyExists = false);
    //Task SetBundleAutoRenewal(bool isRenew, string msisdn, string accountId, string bundleUuid, string userEmail, PaymentMethod paymentMethod, long? subscriberBundleId = null, string cardPanMasked = null, string cardInitialTransactionId = null);
    Task SetBundleAutoRenewal(bool isRenew, string msisdn, string accountId, string bundleUuid, string userEmail, PaymentMethod paymentMethod, string cardPanMasked, string cardInitialTransactionId, int grantedCount);
    Task ShiftBundleAutoRenewal(string msisdn, string accountId, string bundleUuid, string followedByBundleUuid, int followedByBundleGrantedCount, string userEmail, PaymentMethod paymentMethod, string cardPanMasked, string cardInitialTransactionId);
    Task UpdateBundleAutoRenewalExecutionDetails(bool isAutoRenew, string Msisdn, string account, string bundleId, bool isSuccess, int errorCode, string errorMsg, int reExecuteCount, DateTime lastExecutionDate);
    Task UpdateBundleAutoRenewalExecutionDetailsByInitialTransactionId(bool isAutoRenew, string initialTransactionId, string bundleId, bool isSuccess, int errorCode, string errorMsg, int reExecuteCount, DateTime lastExecutionDate);
    Task<bool> DisableBundleAutoRenewal(string msisdn, string transactionId);
    Task ReActivateBundleAutoRenewal(string msisdn, string accountId, string bundleUuid);
    Task<GetBundleAutoRenewalStatus> GetBundleAutoRenewal(string msisdn, string accountId, string bundleId);
    Task<(int errorCode, string errorMessage)> BundlePurchaseValidation(string accountId, string bundleUuId);
    Task<(int errorCode, string errorMessage, int? AuditId)> AddBundleViaSp(string accountId, string msisdn, string email, string bundleUuid);
    Task<Bundle> GetBundleById(string bundleId);
    Task<IEnumerable<Bundle>> GetRoamingBundles(RoamingBundleRequest request);
    Task<IEnumerable<Bundle>> GetTwelveMonthBundles(TwelveMonthBundleRequest twelveMonthBundleRequest);
    Task ChangePlanAutoRenewal(bool isRenew, string msisdn, string accountId, string bundleUuid, string userEmail, PaymentMethod paymentMethod, string cardPanMasked = null, string cardInitialTransactionId = null);

    Task<SubscribedBundle> GetChangePlanBundleByMsisdn(string msisdn);
    Task<IEnumerable<GetBundleAutoRenewalStatus>> GetContractBundleAutoRenewal(string msisdn);
    Task<Guid?> GetNewBundleForRenewal(Guid bundleId);
}