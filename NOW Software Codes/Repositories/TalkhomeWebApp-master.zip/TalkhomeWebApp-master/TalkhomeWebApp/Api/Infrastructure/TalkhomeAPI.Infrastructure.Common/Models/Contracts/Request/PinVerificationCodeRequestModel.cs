﻿using System.ComponentModel.DataAnnotations;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class PinVerificationCodeRequestModel
    {
        public string PinCode { get; set; }

        [Required(ErrorMessage = "phone number is required")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "country code is required")]
        public string PhoneNumberCountryCode { get; set; }

    }
}