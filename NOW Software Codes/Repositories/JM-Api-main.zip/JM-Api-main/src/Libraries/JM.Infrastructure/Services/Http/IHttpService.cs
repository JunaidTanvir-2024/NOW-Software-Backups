using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Infrastructure.Services.Http;

public interface IHttpService : ResolveAs.IScoped
{
    Task<(bool isFailure, string json)> DeleteAsync(string requestUri, Dictionary<string, List<string>>? queryHeaders = null);
    Task<(bool isFailure, string json)> GetAsync(string requestUri, object? queryParams = default, Dictionary<string, List<string>>? queryHeaders = null);
    Task<(bool isFailure, string json)> PostAsync(string requestUri, object? data = default, bool isAccessTokenRequest = false, Dictionary<string, List<string>>? queryHeaders = null);
    Task<(bool isFailure, string json)> PutAsync(string requestUri, object? data = default, Dictionary<string, List<string>>? queryHeaders = null);
    IHttpService EnableLogging();
    IHttpService WithBasicAuth(string? username, string? password);
    IHttpService WithBearerAuth(string cachedTokenKey, string tokenProperty, string tokenExpiry);
    IHttpService WithDefaultHeaders(Dictionary<string, string> headers);
    IHttpService SetVendor(AppEnum.VendorType vendor);
    IHttpService WithApiKey(string? apiKey, string? apiKeyHeaderName);
}
