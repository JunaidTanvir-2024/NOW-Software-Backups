﻿using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;

namespace Application.Features.Payment.Card.ExistingCardPaymentV2;

public class ExistingCardPaymentRequestV2 : IRequest<Result<CardResponse>>
{
    public string? Msisdn { get; set; }

    public PaymentExistingCardInfo PaymentCardInfo { get; set; } = default!;

    public SetPaymentTopupInfo? TopupInfo { get; set; }

    public PaymentBundleInfo? BundleInfo { get; set; }

    public PaymentCreditSimInfo? CreditSimInfo { get; set; }

    [JsonIgnore]
    public string? Email { get; set; }

    [JsonIgnore]
    public string? IpAddress { get; set; }
    public string? ConversionID { get; set; }
    public ConversionPlatForm ConversionPlatFormID { get; set; }
    public bool IsRetry { get; set; } = false;
}