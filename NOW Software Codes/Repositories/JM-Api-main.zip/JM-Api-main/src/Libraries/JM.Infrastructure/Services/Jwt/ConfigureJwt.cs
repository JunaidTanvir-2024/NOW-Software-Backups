using System.Security.Claims;
using System.Text.Json;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Services;

using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

using RW;

namespace JM.Infrastructure.Services.Jwt;

internal static class JwtConfiguration
{
    #region Jwt Dependency Extension
    internal static IServiceCollection AddJwtConfiguration(this IServiceCollection services, IConfiguration configuration)
    {
        return services
                    .Configure<JwtSetting>(configuration.GetSection(JwtSetting.SectionName))
                    .AddJwtMiddleware();
    }
    #endregion

    #region Jwt Setting
    public sealed class JwtSetting
    {
        public const string SectionName = nameof(JwtSetting);
        public required string Issuer { get; set; }
        public required string Audience { get; set; }
        public int ExpirationTimeInMinutes { get; set; }
        public bool IsExactTimeExpiry { get; set; }
        public int RefreshTokenExpirationInDays { get; set; }
        public required AsymmetricFilesInfo AsymmetricFiles { get; set; }
        public sealed class AsymmetricFilesInfo
        {
            public const string SectionName = nameof(AsymmetricFiles);
            public required string SecretKeyFile { get; set; }
            public required string PublicKeyFile { get; set; }
        }
    }
    #endregion
    internal static IServiceCollection AddJwtMiddleware(this IServiceCollection services)
    {
        // Get IJwtTokenService
        var jwtService = services.BuildServiceProvider().GetRequiredService<IJwtService>();

        // Bind jwt settings
        var jwtSettings = services.BuildServiceProvider().GetRequiredService<IOptions<JwtSetting>>().Value;

        string publicKeyPath = string.Empty;

        // Get Secret Key Path;
        if (jwtSettings.AsymmetricFiles.SecretKeyFile is not null)
        {
            publicKeyPath = Path.Combine(Directory.GetCurrentDirectory(), jwtSettings.AsymmetricFiles.SecretKeyFile);
        }

        // Authentication scheme
        services.AddAuthentication(authentication =>
        {
            authentication.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            authentication.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        // Jwt Bearer with events
        .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, bearer =>
        {
            bearer.IncludeErrorDetails = true; // => true for easy debugging else remove it
            bearer.TokenValidationParameters = new TokenValidationParameters
            {
                IssuerSigningKey = new ECDsaSecurityKey(jwtService.GetSecurityKeyViaFile(publicKeyPath)),
                ValidAudience = jwtSettings.Audience,
                ValidIssuer = jwtSettings.Issuer,
                RequireSignedTokens = true,
                RequireExpirationTime = true,
                ValidateLifetime = true,
                ValidateAudience = true,
                ValidateIssuer = true,
                RoleClaimType = ClaimTypes.Role,
                ClockSkew = TimeSpan.Zero // Add zero tolerance on token expiration date/time
            };
            bearer.Events = new JwtBearerEvents
            {
                OnAuthenticationFailed = context => HandleAuthenticationFailed(context),
                OnChallenge = context => HandleChallenge(context),
                OnForbidden = context => HandleForbidden(context)
            };
        });
        services.AddAuthorization(options =>
        {
            options.DefaultPolicy = new AuthorizationPolicyBuilder()
            .RequireAuthenticatedUser()
            .AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme)
            .Build();
        });
        return services;
    }
    private static Task HandleAuthenticationFailed(AuthenticationFailedContext context)
    {
        if (context.Exception is SecurityTokenExpiredException)
        {
            return WriteJsonResponseAsync(context.Response, AppConstant.StatusCode.Unauthorized, AppConstant.StatusKey.JwtTokenExpired);
        }
        if (context.Exception is SecurityTokenValidationException)
        {
            return WriteJsonResponseAsync(context.Response, AppConstant.StatusCode.Unauthorized, AppConstant.StatusKey.JwtTokenInvalid);
        }
        return Task.CompletedTask;
    }

    private static Task HandleChallenge(JwtBearerChallengeContext context)
    {
        context.HandleResponse();

        if (!context.Request.Headers.ContainsKey("Authorization"))
        {
            return WriteJsonResponseAsync(context.Response, AppConstant.StatusCode.Unauthorized, AppConstant.StatusKey.JwtTokenMissing);
        }
        if (!context.Response.HasStarted)
        {
            return WriteJsonResponseAsync(context.Response, AppConstant.StatusCode.Unauthorized, AppConstant.StatusKey.JwtTokenInvalid);
        }

        return Task.CompletedTask;
    }

    private static Task HandleForbidden(ForbiddenContext context)
    {
        return WriteJsonResponseAsync(context.Response, AppConstant.StatusCode.Forbidden, AppConstant.StatusKey.Forbidden);
    }

    private static Task WriteJsonResponseAsync(HttpResponse response, int statusCode, string errorMessage)
    {
        response.ContentType = AppConstant.ContentType.ApplicationJson;
        response.StatusCode = statusCode;

        var jsonResponse = JsonSerializer.Serialize(ResultWrapper.Failure(errorMessage, statusCode));

        return response.WriteAsync(jsonResponse);
    }
}
