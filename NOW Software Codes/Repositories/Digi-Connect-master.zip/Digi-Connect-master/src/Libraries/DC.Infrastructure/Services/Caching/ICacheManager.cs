using DC.Core.Common.DependencyResolver;

namespace DC.Infrastructure.Services.Caching;

public interface ICacheManager : ServiceType.ISingleton
{
    Task StoreInCache(string? cacheKey, string? cacheValue, string? expiryInMinutes);
    Task<string?> RetrieveFromCache(string? cacheKey);
}
