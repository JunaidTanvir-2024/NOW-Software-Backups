﻿using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.CancelBundle;
public class CancelBundleDetailRequest : IRequest<Result<CancelBundleDetails>>
{
    public int SubscriberBundleId { get; set; }
    public string BundleId { set; get; } = default!;
    public string Msisdn { set; get; } = default!;
}
