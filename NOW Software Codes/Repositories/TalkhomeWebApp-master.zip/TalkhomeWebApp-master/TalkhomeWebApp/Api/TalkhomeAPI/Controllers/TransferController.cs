﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.ATTApiContracts;
using TalkhomeAPI.Services.Interfaces;
using TalkhomeAPI.Utilities;
using ThmApi.Filters;

namespace TalkhomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransferController : ControllerBase
    {
        private readonly ILogger Logger;
        private readonly ITransferService _transferService;
        private readonly IATTService _attService;

        public TransferController(ILogger logger, ITransferService transferService,
            IATTService attService)
        {
            Logger = logger;
            _transferService = transferService;
            this._attService = attService;
        }

        [Route("GetProducts")]
        [HttpGet]
        [BasicAuth]
        //[ActiveUser]
        public async Task<IActionResult> GetProducts([FromQuery] GetProductsRequestModel model)
        {
            try
            {
                var result = await _transferService.GetProducts(
                        model.ToMsisdn,
                        model.FromMsisdn,
                        model.Currency);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: GetProducts, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        //[Route("TransferSummary")]
        //[HttpGet]
        //[BasicAuth]
        //[ActiveUser]
        //public async Task<IActionResult> GetSummary([FromQuery] GetTransferSummaryRequestModel model)
        //{
        //    try
        //    {
        //        return Ok();
        //    }
        //    catch(Exception ex)
        //    {
        //        Logger.Error($"Class: TransferController, Method: GetSummary, Parameters=> model: " +
        // $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
        //        return StatusCode(500);
        //    }
        //}
        [Route("TransferByAccountBalance")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByAccountBalance([FromBody] TransferByAccountBalanceRequestModel model)
        {
            try
            {
                return Ok(await _transferService.TransferByAccountBalance(model,
                                                User.Msisdn(),
                                                User.Currency()));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByAccountBalance, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("GetSpecialPromotionBalanceToDeduct")]
        [HttpGet]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetSpecialPromotionBalanceToDeduct([FromQuery] GetSpecialPromotionBalanceToDeductRequestModel model)
        {
            try
            {
                return Ok(await _transferService.GetSpecialPromotionBalanceToDeduct(
                                                User.Msisdn(),
                                                model.Amount,model.nowtelRef,model.product));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: GetSpecialPromotionBalanceToDeduct, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("TransferByPayPal")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByPayPal([FromBody] TransferByPayPalRequestModel model)
        {
            try
            {
                HttpContext.Request.Headers["Msisdn"] = User.Msisdn();
                return Ok(await _transferService.TransferByPayPal(model,
                                                User.Msisdn(),
                                                User.Currency(),
                                                User.AccountId()));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByPayPal, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        //Direct Paypal
        [Route("TransferByPayPalCallBackV1")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByPayPalCallBackV1([FromBody] TransferByPayPalCallBackV1RequestModel model)
        {
            try
            {
                return Ok(await _transferService.TransferByPayPalCallBackV1(model,
                                                User.Claims.First(i => i.Type == "msisdn").Value,
                                                User.Claims.First(i => i.Type == "currency").Value));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByPayPalCallBackV1, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        //PayPal Via Pay360
        [Route("TransferByPayPalCallBackV2")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByPayPalCallBackV2([FromBody] TransferByPayPalCallBackV2RequestModel model)
        {
            try
            {
                HttpContext.Request.Headers["Msisdn"] = User.Msisdn();
                return Ok(await _transferService.TransferByPayPalCallBackV2(model,
                                                User.Msisdn(),
                                                User.Currency()));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByPayPalCallBackV2, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("TransferByExistingCard")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByExistingCard([FromBody] TransferByExistingCardRequestModel model)
        {
            try
            {
                HttpContext.Request.Headers["Msisdn"] = User.Msisdn();
                return Ok(await _transferService.TransferByExistingCard(model,
                                                    User.Msisdn(),
                                                    User.Currency(),
                                                    User.AccountId()));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByExistingCard, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("TransferByNewCustomer")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByNewCustomer([FromBody] TransferByNewCustomerRequestModel model)
        {
            try
            {
                HttpContext.Request.Headers["Msisdn"] = User.Msisdn();
                return Ok(await _transferService.TransferByNewCustomer(model,
                                                    User.Msisdn(),
                                                    User.Currency(),
                                                    User.AccountId()));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByNewCustomer, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("TransferByNewCard")]
        [HttpPost]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> TransferByNewCard([FromBody] TransferByNewCardRequestModel model)
        {
            try
            {
                HttpContext.Request.Headers["Msisdn"] = User.Msisdn();
                return Ok(await _transferService.TransferByNewCard(model,
                                                    User.Msisdn(),
                                                    User.Currency(),
                                                    User.AccountId()));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByNewCardRequestModel, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [Route("TransferByCard3dSecureCallBack")]
        [HttpPost]
        [BasicAuth]
        public async Task<IActionResult> TransferByCard3dSecureCallBack([FromBody] TransferByCardCallBackRequestModel model)
        {
            try
            {
                HttpContext.Request.Headers["Msisdn"] = model.customerMsisdn;
                return Ok(await _transferService.TransferByCard3dSecureCallBack(model));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferByCard3dSecureCallBack, Parameters=> model: " +
                         $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [Route("TransferCountries")]
        public async Task<IActionResult> TransferCountries(string continent)
        {
            try
            {
                var response = await _attService.GetDTOneCountriesAsync(continent);
                return Ok(GenericApiResponse<TransferCountriesResponse>.Success(response, "Countries loaded successfully"));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferCountries, Method: TransferCountries, Parameters=> model: " +
                         $"{continent}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [Route("TransferOperators")]
        public async Task<IActionResult> TransferOperators(string currency, string countryName)
        {
            try
            {
                var response = await _attService.GetDTOneOperatorsByCountryAsync(currency, countryName);
                if (response != null)
                {
                    return Ok(GenericApiResponse<TransferOperatorsByCountryResponse>.Success(response, "Operators loaded successfully"));
                }
                else
                {
                    return Ok(GenericApiResponse<TransferOperatorsByCountryResponse>.Failure("Country not found", Enums.ApiStatusCodes.RecordNotFound));
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferOperators, Method: TransferByCard3dSecureCallBack, Parameters=> model: " +
                         $"{currency}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [Route("TransferOperatorDetails")]
        public async Task<IActionResult> TransferOperatorDetails(string countryName, string operatorName)
        {
            try
            {
                var response = await _attService.GetTransferToOperatorDetailsAsync(countryName, operatorName);
                if(response!=null)
                return Ok(GenericApiResponse<TransferOperatorDetailsResponse>.Success(response, "Operator details loaded successfully"));
                else
                {
                    return Ok(GenericApiResponse<TransferOperatorsByCountryResponse>.Failure("Operator not found", Enums.ApiStatusCodes.RecordNotFound));
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferOperatorDetails, Method: TransferByCard3dSecureCallBack, Parameters=> model: " +
                         $"{countryName}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
    }
}