﻿namespace Application.Common.Enums;
public enum SignUpTypeId : byte
{
    UsernameAndPassword = 1,
    Google = 2,
    Facebook = 3,
    Twitter = 4
}