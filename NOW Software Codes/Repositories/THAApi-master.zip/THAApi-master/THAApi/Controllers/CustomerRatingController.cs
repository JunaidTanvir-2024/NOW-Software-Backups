﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using Models.Contracts.Response;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using THAApi.Utilities;

namespace THAApi.Controllers
{
    [ApiController]
    public class CustomerRatingController : Controller
    {
        ICustomerRating_BL _customerRating_BL;

        public CustomerRatingController(ICustomerRating_BL customerRating_BL)
        {
            _customerRating_BL = customerRating_BL;
        }

        [HttpGet]
        [Route("Rating/GetRatingEvents")]
        public async Task<GenericApiResponse<IEnumerable<RatingEvents>>> GetRatingEvents()
        {
            var response = await _customerRating_BL.GetRatingEvents();
            return GenericApiResponse<IEnumerable<RatingEvents>>.Success(response, "Success");
        }

        [HttpPost]
        [Route("Rating/AddCustomerRating")]
        public async Task<GenericApiResponse<object>> AddCustomerRating([FromBody] AddCustomerRatingRequest model)
        {
            var response = await _customerRating_BL.AddCustomerRating(model,User.Msisdn(), User.Email());
            return response;
        }

        [HttpGet]
        [Route("Rating/GetCustomerRatings")]
        public async Task<GenericApiResponse<IEnumerable<CustomerRatings>>> GetCustomerRatings()
        {
            var response = await _customerRating_BL.GetCustomerRatings(User.Msisdn(), "THA", User.Email());
            return response;
        }


    }
}
