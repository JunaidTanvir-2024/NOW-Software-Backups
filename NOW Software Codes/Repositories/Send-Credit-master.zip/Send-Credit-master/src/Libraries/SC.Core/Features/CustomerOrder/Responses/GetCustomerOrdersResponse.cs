﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder.Responses;
public record GetCustomerOrdersResponse
{
    public long CustomerOrderID { get; set; } = default!;
    public string CustomerID { get; set; } = default!;
    public string PromoCode { get; set; } = default!;
    public string DiscountType { get; set; } = default!;
    public decimal DiscountAmount { get; set; } = decimal.Zero;
    public decimal ServiceFee { get; set; } = decimal.Zero;
    public decimal TaxAmount { get; set; } = decimal.Zero;
    public decimal TaxInclusiveAmount { get; set; } = decimal.Zero;
    public decimal TaxExclusiveAmount { get; set; } = decimal.Zero;
    public decimal TotalOrderAmount { get; set; } = decimal.Zero;
    public string Currency { get; set; } = default!;
    public string OrderStatus { get; set; } = default!;
    public long CustomerAddressId { get; set; } = default!;
}

