﻿using System.Text.Json.Serialization;

namespace SenderService.Core.Services.ZeroBounce;
public class ZeroBounceSettings
{
    public const string SectionName = nameof(ZeroBounceSettings);
    public static ZeroBounceSettings Bind { get; set; } = new ZeroBounceSettings();
    public string ApiKey { get; set; } = default!;
    public ZeroBounceEndpoints Endpoints { get; set; } = new ZeroBounceEndpoints();
}

public class ZeroBounceEndpoints
{
    public string Base { get; set; } = default!;
    public string Validate { get; set; } = default!;
    public string EmailValidate { get => $"{Base}{Validate}"; }
}