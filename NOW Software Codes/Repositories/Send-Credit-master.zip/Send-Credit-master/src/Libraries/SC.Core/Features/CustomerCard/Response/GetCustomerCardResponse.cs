﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerCard.Response;
public record GetCustomerCardResponse
{

    public long CustomerCardId { get; set; } = default!;
    public string Pan { get; set; } = default!;
    public string NameOnCard { get; set; } = default!;
    public string CardType { get; set; } = default!;
    public string Expiry { get; set; } = default!;
    public bool IsDefault { get; set; } = default!;
}

