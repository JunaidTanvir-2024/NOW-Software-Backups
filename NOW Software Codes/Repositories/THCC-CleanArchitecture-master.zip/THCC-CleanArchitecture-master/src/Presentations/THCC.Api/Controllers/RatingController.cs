﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using THCC.Api.Controllers.Common;
using THCC.Application.Features.TrustPilot;
using THCC.Application.Settings;

namespace THCC.Api.Controllers
{
    public class RatingController : BaseApiController
    {
        [AllowAnonymous]
        [HttpGet("trustpilot")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TrustPilotSettings))]
        public async Task<IActionResult> GetTopupDenominations(CancellationToken cancellationToken)
        {
            return HandleResponse(await Mediator.Send(new RatingRequest(), cancellationToken));
        }
    }
}
