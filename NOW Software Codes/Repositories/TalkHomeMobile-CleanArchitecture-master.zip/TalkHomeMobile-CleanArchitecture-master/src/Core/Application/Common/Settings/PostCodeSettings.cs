﻿namespace Application.Common.Settings;

public class PostCodeSettings
{
    public const string SectionName = "PostCodeSettings";
    public static PostCodeSettings Bind = new PostCodeSettings();

    public int PostCodeRequestLimitPerToken { get; set; }
    public bool RequirePostCodeCookieValidation { get; set; }
    public bool RequirePostCodeDBValidation { get; set; }
}
