﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel;

namespace Models.Common
{
    public class Metadata : Dictionary<string, object>
    {
        [JsonConstructor]
        public Metadata() { }
        public Metadata(Dictionary<string, object> dictionary) : base(dictionary ?? new Dictionary<string, object>()) { }
	}
}