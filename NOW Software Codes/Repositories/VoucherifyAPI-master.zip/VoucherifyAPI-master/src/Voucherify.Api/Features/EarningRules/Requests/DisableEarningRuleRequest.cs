using FluentValidation;

namespace Voucherify.Api.Features.EarningRules.Requests;

public class DisableEarningRuleRequest
{
    public string CampaignId { get; set; } = null!;
    public string EarningRuleId { get; set; } = null!;
}
internal class DisableEarningRuleRequestValidator : AbstractValidator<DisableEarningRuleRequest>
{
    public DisableEarningRuleRequestValidator()
    {
        RuleFor(p => p.CampaignId).NotNull().NotEmpty();
        RuleFor(p => p.EarningRuleId).NotNull().NotEmpty();
    }
}