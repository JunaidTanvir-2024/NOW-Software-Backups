﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models
{
    public class BundlesCountries
    {
        public string ISO_Code { get; set; }
        public string Country { get; set; }
        public string Na_Service_Id { get; set; }
        public string Currency { get; set; }
        public string CurrencySymbol { get; set; }
        public string SelectedCountry { get; set; }
    }
}
