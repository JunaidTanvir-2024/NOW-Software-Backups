﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Response
{
    public class GetUserPaymentHistoryResponseModel
    {
        public IEnumerable<DBPaymentHistory> PaymentHistory { get; set; }
        public int PaymentHisotryTotalRecords { get; set; }
    }

    public class DBPaymentHistory
    {
        public string PaymentDate { get; set; }
        public string Amount { get; set; }
        public string Reason { get; set; }
    }
}