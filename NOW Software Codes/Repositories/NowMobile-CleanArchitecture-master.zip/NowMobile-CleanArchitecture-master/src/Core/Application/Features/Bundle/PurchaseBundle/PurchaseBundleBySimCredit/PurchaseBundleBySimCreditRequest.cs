﻿namespace Application.Features.Bundle.PurchaseBundle.PurchaseBundleBySimCredit;

public class PurchaseBundleBySimCreditRequest : IRequest<Result<PurchaseBundleResponse>>
{
    public int BundleId { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
    public bool IsAutoRenew { get; set; }
}
