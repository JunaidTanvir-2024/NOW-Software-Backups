﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BasketWebPanel.Areas.Dashboard.Controllers
{
    public class ErrorController : Controller
    {
        // GET: Dashboard/Error
        public ActionResult Index()
        {
            //if (Request.IsAjaxRequest())
            //{
                
            //        Response.Clear();
            //        Response.StatusCode = 404;
                
            //}
            
                Global.sharedDataModel.SetSharedData(User);
                return View("~/Areas/Dashboard/Views/Shared/Forbidden.cshtml", Global.sharedDataModel);
            
          
            
           
        }
    }
}