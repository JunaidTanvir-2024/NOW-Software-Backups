﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Models.Paypal
{
    public class Pay360PayPalCreateSalePaymentRequest
    {
        [JsonProperty("customerName")]
        [Required]
        public string CustomerName { get; set; }

        [JsonProperty("customerUniqueRef")]
        [Required]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("customerMsisdn")]
        public string CustomerMsisdn { get; set; }

        [JsonProperty("CustomerEmail")]
        public string CustomerEmail { get; set; }

        [JsonProperty("transactionCurrency")]
        public string transactionCurrency { get; set; }

        [JsonProperty("transactionAmount")]
        public float transactionAmount { get; set; }

        [JsonProperty("isDirectFullfilment")]
        public bool isDirectFullfilment { get; set; }

        [JsonProperty("ipAddress")]
        public string ipAddress { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }

        [Required]
        public paymentMethod paymentMethod { get; set; }

        [JsonProperty("basket")]
        [Required]
        public List<ProductBasket> Basket { get; set; }
        public customField customFields { get; set; }

    }

    public class paymentMethod
    {
        public paypal paypal { get; set; }
    }

    public class paypal
    {
        [Required]
        public string returnUrl { get; set; }

        [Required]
        public string cancelUrl { get; set; }
    }
    public class customField
    {
        public List<fieldstate> fieldState { get; set; }
    }

    public class fieldstate
    {
        public string name { get; set; }
        public string value { get; set; }
        public bool transient { get; set; } = false;
    }
}
