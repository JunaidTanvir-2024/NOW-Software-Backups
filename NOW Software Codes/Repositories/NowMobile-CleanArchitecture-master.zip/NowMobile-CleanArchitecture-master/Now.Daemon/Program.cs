﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Now.Daemon;
using Now.Infrastructure.BLL;
using Now.Infrastructure.DAL;
using Now.Infrastructure.Services;
using Now.Models.Configurations;
using NowDaemon.DependencyResolver;
using Org.BouncyCastle.Crypto;
using Serilog;
using System.Reflection;

public class Program
{
    public static void Main(string[] args)
    {
        CreateHostBuilder(args).Build().Run();
    }

    public static IHostBuilder CreateHostBuilder(string[] args)
    {
        return Host.CreateDefaultBuilder(args)
            .ConfigureServices(ConfigureServices)
            .UseSerilog((_, config) => config.WriteTo.Console());
    }
    public static void ConfigureServices(HostBuilderContext hostContext,IServiceCollection services)
    {
        IConfiguration configuration = hostContext.Configuration;
        services.AddHostedService<CreditSimFullfillmentWorker>();
        services.Configure<ConnectionStrings>(configuration.GetSection("ConnectionStrings"));
        services.Configure<SmtpConfig>(configuration.GetSection("SmtpConfig"));

        services.AddTransient(typeof(ICreditSimFulfillment_BL), typeof(CreditSimFulfillment_BL));
        services.AddTransient(typeof(ICreditSimFulfillment_DL), typeof(CreditSimFulfillment_DL));
        services.AddTransient(typeof(IEmail_BL), typeof(Email_BL));
        services.AddHttpClient<IAirshipService, AirshipService>();

    }
}
