﻿$(document).ready(function () {

    $('#BtnSaveProduct').click(function () {

        if (!$('#AddProductForm').valid()) {
            return;
        }

        var model = {
            MobileNumber: $('#MobileNumber').val().trim(),
            PUKCode: $('#PUKCode').val().trim()
        }

        $.ajax({
            url: "/Account/SaveUserProduct",
            type: "POST",
            data: model,
            beforeSend: function (xhr) {
                $('#lblSaveProduct').hide();
                $('#BtnSaveProduct').attr('disabled', true);
                $('#BtnSaveProductSpinner').fadeIn();

                $("#UserProductSuccessAlert").hide();
                $("#UserProductFailureAlert").hide();
            },
            success: function (response) {
                if (response != null) {
                    if (response.status && response.errorCode == 0) {
                        $('#AddProductForm')[0].reset();
                        window.location.href = "/AccountSummary?Msisdn=" + response.mobileNumber;
                    }
                    else {
                        $('#UserProductFailureAlertmsg').html(response.message);
                        $("#UserProductFailureAlert").slideDown().delay(3000).slideUp();
                    }
                }
                else {
                    $('#UserProductFailureAlertmsg').html('Some Error Occured. Please contact Customer Services');
                    $("#UserProductFailureAlert").slideDown().delay(3000).slideUp();
                }
            },
            complete: function (xhr, status) {
                $('#BtnSaveProductSpinner').hide();
                $('#lblSaveProduct').fadeIn();
                $('#BtnSaveProduct').attr('disabled', false);
            },
            error: function (xhr, status, error) {
                $('#UserProductFailureAlertmsg').html('Some Error Occured. Please contact Customer Services');
                $("#UserProductFailureAlert").slideDown().delay(3000).slideUp();
            }
        });

    });

})

function NumberValidation_addPro(evt, length) {

    var TotalLength = $("#" + evt.currentTarget.id).val().length;

    var theEvent = evt || window.event;

    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }
    var regex = /[0-9]/;
    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }
    if (TotalLength >= parseInt(length)) {
        theEvent.returnValue = false;
        theEvent.preventDefault();
    }
}
