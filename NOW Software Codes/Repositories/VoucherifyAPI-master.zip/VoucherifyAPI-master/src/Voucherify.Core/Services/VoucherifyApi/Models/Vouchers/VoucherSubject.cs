using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

public class VoucherSubject
{
    [JsonPropertyName("object")]
    public string? Object { get; set; }

    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("source_id")]
    public string? SourceId { get; set; }

    [JsonPropertyName("price")]
    public long? Price { get; set; }
}
