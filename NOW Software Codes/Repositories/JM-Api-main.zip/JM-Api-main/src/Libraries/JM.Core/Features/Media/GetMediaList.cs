
using System.Linq.Expressions;

using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;
namespace JM.Core.Features.Media;

public abstract class GetMediaList
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public QueryFilter Filters { get; set; } = new QueryFilter();
		public sealed record QueryFilter
		{
			public long? TripId { get; set; }
			public AppEnum.MediaType? MediaType { get; set; }
		}
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			// RuleFor(x => x.Id).GreaterThan(0);
		}
	}
	#endregion

	#region Response
	public sealed record Response
	{
		public long Id { get; set; }
		public required string Type { get; set; }
		public required string Url { get; set; }
		public required TravelerInfo Traveler { get; set; }
		public sealed record TravelerInfo
		{
			public required long Id { get; set; }
			public string? FullName { get; set; }
			public string? Email { get; set; }
		}
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{
			var mediaList = query.Filters is null ?
			 await _unitOfWork.MediaRepository.GetMediaList() :
			 await _unitOfWork.MediaRepository.GetMediaList(GetFilters(query.Filters));

			if (mediaList is not null)
			{
				return ResultWrapper.Success(mediaList.Select(media => new Response()
				{
					Id = media.Id,
					Type = media.Type,
					Url = media.Url,
					Traveler = new Response.TravelerInfo()
					{
						Id = media?.Traveler?.User?.Id ?? default,
						Email = media?.Traveler?.User?.Email,
						FullName = media?.Traveler?.User?.UserDetail?.FullName
					}
				}));
			}

			return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
		}
		private static Expression<Func<Entities.Media, bool>> GetFilters(Query.QueryFilter filters)
		{
			Expression<Func<Entities.Media, bool>> filterExpression = x =>
				x.IsActive &&
				(filters.TripId == null || x.TripId.Equals(filters.TripId)) &&
				(filters.MediaType == null || x.Type.Equals(Enum.GetName(typeof(AppEnum.MediaType), filters.MediaType)));

			return filterExpression;
		}
	}
	#endregion
}
