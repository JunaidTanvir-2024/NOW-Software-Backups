﻿using ATT.Models.Configurations;
using ATT.Models.Contracts.Common;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using System.Net.Mail;
using ATT.Infrastructure.DAL;
using System.Security.Cryptography;
using System.IO;

namespace ATT.Infrastructure.BLL.Common
{
    public class Common_BL : ICommon_BL
    {
        private ILogger _logger;
        private readonly SmtpConfig SmtpConfig;
        private readonly TwilioConfig TwilioConfig;
        private IAttDb_DL _appDB;
        public Common_BL(IAttDb_DL _db, ILogger appLoggers, IOptions<SmtpConfig> smpt, IOptions<TwilioConfig> twilioConfig)
        {
            _appDB = _db;
            _logger = appLoggers;
            SmtpConfig = smpt.Value;
            TwilioConfig = twilioConfig.Value;
        }
        public async Task<bool> SendEmail(EmailTransactionModel transactionModel)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                //SmtpClient client = new SmtpClient("172.24.0.224");

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }



                //client.DeliveryMethod = SmtpDeliveryMethod.Network;
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SmtpConfig.from);
                foreach (var to in SmtpConfig.to)
                {
                    mailMessage.To.Add(to);
                }
                foreach (var cc in SmtpConfig.cc)
                {
                    if (cc != "" && cc != null)
                    {
                        mailMessage.CC.Add(cc);
                    }
                }
                foreach (var bcc in SmtpConfig.bcc)
                {
                    if (bcc != "" && bcc != null)
                    {
                        mailMessage.Bcc.Add(bcc);
                    }
                }
                mailMessage.Body = string.Empty;
                mailMessage.Body = !string.IsNullOrEmpty(transactionModel.ProductCode) ? "ProductCode:   " + transactionModel.ProductCode + Environment.NewLine : "";
                mailMessage.Body += !string.IsNullOrEmpty(transactionModel.ProductItemCode) ? "ProductItemCode: " + transactionModel.ProductItemCode + Environment.NewLine : "";
                mailMessage.Body += !string.IsNullOrEmpty(transactionModel.accessGUID) ? "Access GUID: " + transactionModel.accessGUID + Environment.NewLine : "";
                mailMessage.Body += !string.IsNullOrEmpty(transactionModel.FromMsisdn) ? "From MSISDN: " + transactionModel.FromMsisdn + Environment.NewLine : "";
                mailMessage.Body += !string.IsNullOrEmpty(transactionModel.ToMsisdn) ? "To MSISDN: " + transactionModel.ToMsisdn + Environment.NewLine : "";
                mailMessage.Body += !string.IsNullOrEmpty(transactionModel.DestinationCountry) ? "Destination Country: " + transactionModel.DestinationCountry + Environment.NewLine : "";
                mailMessage.Body += !string.IsNullOrEmpty(transactionModel.OperatorId) ? "Operator Id: " + transactionModel.OperatorId + Environment.NewLine : "";
                mailMessage.Body += !string.IsNullOrEmpty(transactionModel.OperatorName) ? "Operator Name: " + transactionModel.OperatorName + Environment.NewLine : "";
                mailMessage.Body += !string.IsNullOrEmpty(transactionModel.Status) ? "Status: " + transactionModel.Status + Environment.NewLine : "";
                mailMessage.Body += !string.IsNullOrEmpty(transactionModel.ErrorMessage) ? "Error Message: " + transactionModel.ErrorMessage + Environment.NewLine : "";
                mailMessage.Subject = !string.IsNullOrEmpty(transactionModel.TransationType.ToString()) ? transactionModel.TransationType == TransationType.Get ?
                      SmtpConfig.GetProductssubject.Replace("#productcode#", transactionModel.ProductCode.ToString()).Replace("#productitemcode#", transactionModel.ProductItemCode).Replace("#serviceprovicer#", transactionModel.ServiceProviderName) :
                      SmtpConfig.ExecuteTransactionsubject.Replace("#productcode#", transactionModel.ProductCode.ToString()).Replace("#productitemcode#", transactionModel.ProductItemCode).Replace("#serviceprovicer#", transactionModel.ServiceProviderName) : "";
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Common_BL, Method: SendEmail, Parameters=> transactionModel: {JsonConvert.SerializeObject(transactionModel)}, ErrorMessage: {ex.Message}");
                return false;
            }

        }
        public async Task SendTwilioSms(string to, string textMessage, string productCode = null, bool isOptionMessage = false)
        {
            bool isRestrictedCountry = false;
            Twilio.Types.PhoneNumber from = "888 8";

            to = to.Replace("+", "");
            to = to.StartsWith("00") == true ? to.Remove(0, 2) : to;

            foreach (var item in TwilioConfig.TwilioFromNumberCountries)
            {
                if (to.StartsWith(item))
                {
                    isRestrictedCountry = true;
                    from = new Twilio.Types.PhoneNumber(TwilioConfig.TwilioNumber);
                    break;
                }
            }

            if (!to.StartsWith("+"))
            {
                to = "+" + to;
            }

            string fromText = "TransHome";

            if (!string.IsNullOrWhiteSpace(productCode))
            {
                fromText = productCode == "TRH" ? "TransHome" : "TalkHome";
                if (isOptionMessage == false)
                {
                    textMessage = productCode == "TRH" ? textMessage : textMessage.Replace("TransferHome", "Talk Home");
                }

            }

            string requestParameters = $"from : {(isRestrictedCountry ? from.ToString() : fromText)}, to: {to}, textMessage: {textMessage}";

            try
            {
                TwilioClient.Init(TwilioConfig.Sid, TwilioConfig.AuthToken);
                var message = await MessageResource.CreateAsync(body: textMessage, from: isRestrictedCountry ? from : fromText, to: new Twilio.Types.PhoneNumber(to));
                return;
            }
            catch (Exception ex)
            {
                _logger.Error($"DingPost_BL - Method: SendTwilioSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
                return;
            }
        }

        public async Task<decimal> GetDiscountSettings(string productCode, string productItemCode, string toMsisdn, string fromMsisdn, decimal amount)
        {
            decimal DiscountPercentage = await _appDB.GetDiscountSettings(productCode, productItemCode, toMsisdn, fromMsisdn, amount);
            return DiscountPercentage;

        }

        public string AesEncrypt(string text)
        {
            string EncryptionKey = "2110115610683097";
            byte[] clearBytes = Encoding.Unicode.GetBytes(text);
            string encryptedText = "";
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(16);
                encryptor.IV = pdb.GetBytes(16);
                encryptor.Mode = CipherMode.ECB;
                encryptor.BlockSize = 128;

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    encryptedText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return encryptedText;
        }

        public string AesDecrypt(string encryptedText)
        {
            string EncryptionKey = "2110115610683097";
            byte[] cipherBytes = Convert.FromBase64String(encryptedText);
            string decryptedText = "";
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(16);
                encryptor.IV = pdb.GetBytes(16);
                encryptor.Mode = CipherMode.ECB;
                encryptor.BlockSize = 128;

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    decryptedText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return decryptedText;
        }
        public async Task<MessageResource> SendTwilioSmsWithCallback(string to, string textMessage, string productCode = null, bool isOptionMessage = false)
        {
            bool isRestrictedCountry = false;
            Twilio.Types.PhoneNumber from = "888 8";

            to = to.Replace("+", "");
            to = to.StartsWith("00") == true ? to.Remove(0, 2) : to;

            foreach (var item in TwilioConfig.TwilioFromNumberCountries)
            {
                if (to.StartsWith(item))
                {
                    isRestrictedCountry = true;
                    from = new Twilio.Types.PhoneNumber(TwilioConfig.TwilioNumber);
                    break;
                }
            }

            if (!to.StartsWith("+"))
            {
                to = "+" + to;
            }

            string fromText = "TransHome";

            if (!string.IsNullOrWhiteSpace(productCode))
            {
                fromText = productCode == "TRH" ? "TransHome" : "TalkHome";
                if (isOptionMessage == false)
                {
                    textMessage = productCode == "TRH" ? textMessage : textMessage.Replace("TransferHome", "Talk Home");
                }

            }

            string requestParameters = $"from : {(isRestrictedCountry ? from.ToString() : fromText)}, to: {to}, textMessage: {textMessage}";

            try
            {
                TwilioClient.Init(TwilioConfig.Sid, TwilioConfig.AuthToken);
                var message = await MessageResource.CreateAsync(
                    body: textMessage,
                    from: isRestrictedCountry ? from : fromText,
                    to: new Twilio.Types.PhoneNumber(to),
                    statusCallback: new Uri(TwilioConfig.SmsStatuCallbackUrl)
);
                return message;
            }
            catch (Exception ex)
            {
                _logger.Error($"DingPost_BL - Method: SendTwilioSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
                return null;
            }
        }     
    }
}
