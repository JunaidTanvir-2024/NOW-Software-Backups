﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Configurations
{
    public class SAPConfig
    {
        public string ApiEndPoint { get; set; }
        public bool IsActive { get; set; }
        public string[] CountryCodes { get; set; }
    }
}
