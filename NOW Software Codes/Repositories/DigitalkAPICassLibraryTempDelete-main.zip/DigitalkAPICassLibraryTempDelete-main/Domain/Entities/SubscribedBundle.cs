﻿using System.Text.Json.Serialization;

namespace Domain.Entities;

public class SubscribedBundle
{
    public string Price { get; set; } = default!;
    public string BrandedName { get; set; } = default!;
    public string PlanName { get; set; } = default!;
    public string GprsDataBytesConverted { get; set; } = default!;
    public string GprsDataUnit { get; set; } = default!;
    public string RemainingTexts { get; set; } = default!;
    public string RemainingMinutes { get; set; } = default!;
    public string RemainingGprsDataBytesConverted { get; set; } = default!;
    [JsonIgnore]
    public string RemainingGprsDataBytesConvertedWithoutUnit { get; set; } = default!;
    public int Bundleid { get; set; }
    public int Minutes { get; set; }
    public int Texts { get; set; }
    public int NoOfRenewals { get; set; }
    public int GrantedCount { get; set; }
    public int NoOfDays { get; set; }
    public int Type { get; set; }
    public int Category { get; set; }
    public long GprsDataBytes { get; set; }
    public long RemainingGprsDataBytes { get; set; }
    public bool InternationalMinutesOrSms { get; set; }
    public bool MinutesOrSms { get; set; }
    public bool IsAutoRenew { get; set; }
    public string AutoRenewPaymentMethod { get; set; } = default!;
    public string AutoRenewCardPanMasked { get; set; } = default!;
    public bool IsAllowancewbundle { get; set; }
    public bool IsNew { get; set; }
    public DateTime Expiry { get; set; }
    public bool IsRetry { get; set; }
    public Guid Id { get; set; }
}
