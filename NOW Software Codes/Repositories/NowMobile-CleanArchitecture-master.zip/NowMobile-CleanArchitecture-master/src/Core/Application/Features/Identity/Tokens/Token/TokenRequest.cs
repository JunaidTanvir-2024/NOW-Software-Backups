﻿namespace Application.Features.Identity.Tokens.Token;

public class TokenRequest : IRequest<Result<TokenResponse>>
{
    public TokenRequest()
    {
        UserInfo = new UserInfo();
        AppInfo = new AppInfo();
    }

    public UserInfo UserInfo { get; set; } = new UserInfo();

    public AppInfo AppInfo { get; set; } =new AppInfo();

    [JsonIgnore]
    public string? IpAddress { get; set; }
}

public sealed class UserInfo
{
    public string EmailOrPhone { get; set; } = default!;

    public string Password { get; set; } = default!;
}