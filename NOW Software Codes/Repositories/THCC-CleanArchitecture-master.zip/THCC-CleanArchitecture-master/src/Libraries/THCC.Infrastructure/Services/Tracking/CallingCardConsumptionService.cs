﻿using Microsoft.VisualBasic;

using Newtonsoft.Json.Linq;

using Serilog;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Airship;

using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Services.Tracking;

public class CallingCardConsumptionService : ICallingCardConsumptionService
{
    #region Fields

    private readonly ILogger _logger;
    private readonly ICallingCardRepository _callingCardRepo;
    private readonly IAirshipService _airshipService;
    private readonly IPhoneNumberService _phoneNumberService;

    #endregion

    #region Ctors

    public CallingCardConsumptionService(
        ILogger logger,
        ICallingCardRepository callingCardRepo,
        IAirshipService airshipService,
        IPhoneNumberService phoneNumberService)
    {
        _logger = logger;
        _callingCardRepo = callingCardRepo;
        _airshipService = airshipService;
        _phoneNumberService = phoneNumberService;
    }

    #endregion

    #region Methods

    public async Task ClassicCardConsumptionJob()
    {
        var history = await _callingCardRepo.GetClassicCardConsumptionHistory();
        if (history?.Count > 0)
        {
            foreach (var item in history)
            {
                try
                {
                    string email = item.Email != null ? item.Email.Trim() : string.Empty;
                    if (!string.IsNullOrEmpty(email) && (await CreateAirshipEmailChannel(item.Id, email)))
                    {
                        var eventRequest = new CustomEventsRequest
                        {
                            ProductCode = nameof(ProductCode.THCC),
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = email,
                            InteractionType = "THCC-Backend-Service",
                            InteractionId = $"Disposable Card Limit - {item.Percentage}% Consumed",
                            CustomEventName = $"classic_consumed_{item.Percentage}_dash"
                        };
                        if (!await _airshipService.AddCustomEvents(eventRequest))
                        {
                            _logger.Error($"Class: CallingCardConsumptionService,  ErrorMessage: custom event not fired. , Request: {item.Email} - classic_consumed_{item.Percentage}_dash");
                        }

                        var isTagSuccess = await _airshipService.AddCustomUserTags(
                            new CustomUserTagsRequest()
                            {
                                NamedUser = email,
                                TagGroup = "activitynew",
                                Tags = new List<string> { eventRequest.CustomEventName }
                            });
                        if (!isTagSuccess)
                        {
                            _logger.Error($"Class: CallingCardConsumptionService,  ErrorMessage: custom tag not fired. , Request: {item.Email} - classic_consumed_{item.Percentage}_dash");
                        }
                    }
                    await _callingCardRepo.UpdateClassicCardConsumptionItems(item.Id, item.Percentage);
                }
                catch (Exception ex)
                {
                    _logger.Error("Class: CallingCardConsumptionService, Method: ClassicCardConsumptionJob, " +
                                            $"ErrorMessage: {ex.Message} , Request: {item.Email} - {item.Percentage}");
                }
            }
        }
    }
    public async Task RechargeableCardConsumptionAndCallJob()
    {
        var history = await _callingCardRepo.GetTHRCCCDRHistory();
        if (history?.Count > 0)
        {
            foreach (var item in history)
            {
                try
                {
                    string email = item.Email != null ? item.Email.Trim() : string.Empty;
                    if (!string.IsNullOrEmpty(email) &&
                       !string.IsNullOrEmpty(item.Destination) &&
                       await CreateAirshipEmailChannel(item.Id, email))
                    {
                        var destinationCountry = await _phoneNumberService.GetCountry(item.Destination.Replace("#", "")!);
                        if (destinationCountry != null)
                        {
                            var duration = Math.Round(Convert.ToDouble(item.Duration) / 60, 2);

                            var balance = item.OpeningBalance - item.ClosingBalance;
                            balance = (float)Math.Round((balance / 100), 2);
                            double percentage = Math.Round((balance / (item.OpeningBalance / 100)) * 100, 2);

                            var resquest = new CustomEventsRequest
                            {
                                ProductCode = nameof(ProductCode.THCC),
                                ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                ChannelIdentifierValue = email,
                                InteractionType = "THCC-Backend-Service",
                            };


                            //Fire consumption tags and events
                            if (percentage != 0 && percentage % 5 == 0)
                            {
                                resquest.InteractionId = $"Rechargeable Card Limit  - {percentage}% Consumed";
                                resquest.CustomEventName = $"rechargeable_consumed_{percentage}_dash";
                                if (!await _airshipService.AddCustomEvents(resquest))
                                {
                                    _logger.Error($"Class: CallingCardConsumptionService,  ErrorMessage: custom event not fired. , Request: {item.Email} - Event: {resquest.CustomEventName}");
                                }

                                var consumptionTagRequest = new CustomUserTagsRequest()
                                {
                                    NamedUser = email,
                                    TagGroup = "activitynew",
                                    Tags = new List<string> { resquest.CustomEventName }
                                };
                                if (!await _airshipService.AddCustomUserTags(consumptionTagRequest))
                                {
                                    _logger.Error($"Class: CallingCardConsumptionService,  ErrorMessage: custom tag not fired. , Request: {item.Email} - Event: {resquest.CustomEventName}");
                                }
                            }


                            //Fire call data tags and events
                            var eventProperties = new Dictionary<string, string>()
                            {
                                { "duration", Convert.ToString(duration) },
                                { "amount ", Convert.ToString(balance) }
                            };
                            resquest.CustomEventName = $"call_dest_{destinationCountry.IsoTwoCharacterCode!.ToLower()}_rechargeable";
                            resquest.Value = Convert.ToDouble(balance);
                            resquest.InteractionId = $"Any call to {destinationCountry.Name!.ToLower()} from Rechargeable card";
                            resquest.Properties = eventProperties;
                            if (!await _airshipService.AddCustomEvents(resquest))
                            {
                                _logger.Error($"Class: CallingCardConsumptionService,  ErrorMessage: custom event not fired. , Request: {item.Email} - call_dest_{destinationCountry.IsoTwoCharacterCode}_classic");
                            }

                            var callTagRequest = new CustomUserTagsRequest()
                            {
                                NamedUser = email,
                                TagGroup = "activitynew",
                                Tags = new List<string> { resquest.CustomEventName }
                            };
                            if (!await _airshipService.AddCustomUserTags(callTagRequest))
                            {
                                _logger.Error($"Class: CallingCardConsumptionService,  ErrorMessage: custom tag not fired. , Request: {item.Email} - call_dest_{destinationCountry.IsoTwoCharacterCode}_classic");
                            }
                        }
                    }
                    await _callingCardRepo.UpdateTHRCCCDRItem(item.Id);
                }
                catch (Exception ex)
                {
                    _logger.Error("Class: CallingCardConsumptionService, Method: RechargeableCardConsumptionJob, " +
                                            $"ErrorMessage: {ex.Message} , Request: {item.Email} - RecordId: {item.Id}  ");
                }
            }
        }
    }
    public async Task ClassicCardCallingJob()
    {
        var history = await _callingCardRepo.GetClassicCardCDRHistory();
        if (history?.Count > 0)
        {
            foreach (var item in history)
            {
                try
                {
                    //  item.Email = "muh.usman237@gmail.com";
                    string email = item.Email != null ? item.Email.Trim() : string.Empty;
                    if (!string.IsNullOrEmpty(email) &&
                        !string.IsNullOrEmpty(item.Destination) &&
                        await CreateAirshipEmailChannel(item.Id, email))
                    {
                        var destinationCountry = await _phoneNumberService.GetCountry(item.Destination);
                        if (destinationCountry != null && !string.IsNullOrEmpty(destinationCountry.Name))
                        {
                            var balance = item.OpeningBalance - item.ClosingBalance;
                            balance = (float)Math.Round((balance / 100), 2);

                            var duration = Math.Round(Convert.ToDouble(item.Duration / 60), 2);

                            var eventProperties = new Dictionary<string, string>()
                            {
                                { "duration", Convert.ToString(duration) },
                                { "amount ", Convert.ToString(balance) }
                            };
                            var eventRequest = new CustomEventsRequest
                            {
                                ProductCode = nameof(ProductCode.THCC),
                                ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                ChannelIdentifierValue = email,
                                InteractionType = "THCC-Backend-Service",
                                CustomEventName = $"call_dest_{destinationCountry.IsoTwoCharacterCode!.ToLower()}_classic",
                                Value = Convert.ToDouble(balance),
                                InteractionId = $"Any call to {destinationCountry.IsoTwoCharacterCode!.ToLower()} from Classic card",
                                Properties = eventProperties
                            };
                            if (!await _airshipService.AddCustomEvents(eventRequest))
                            {
                                _logger.Error($"Class: CallingCardConsumptionService,  ErrorMessage: custom event not fired. , Request: {item.Email} - call_dest_{destinationCountry.IsoTwoCharacterCode}_classic");
                            }

                            var callTagRequest = new CustomUserTagsRequest()
                            {
                                NamedUser = email,
                                TagGroup = "activitynew",
                                Tags = new List<string> { eventRequest.CustomEventName }
                            };
                            if (!await _airshipService.AddCustomUserTags(callTagRequest))
                            {
                                _logger.Error($"Class: CallingCardConsumptionService,  ErrorMessage: custom event not fired. , Request: {item.Email} - call_dest_{destinationCountry.IsoTwoCharacterCode}_classic");
                            }
                        }
                    }
                    await _callingCardRepo.UpdateClassicCardCDRItem(item.Id);
                }
                catch (Exception ex)
                {
                    _logger.Error("Class: CallingCardConsumptionService, Method: ClassicCardCallingJob, " +
                        $"ErrorMessage: {ex.Message} , Request:{item.Id} - {item.Email} - {item.Destination}");
                }
            }
        }
    }

    #endregion

    #region Private Methods
    
    private async Task<bool> CreateAirshipEmailChannel(long id, string email)
    {
        var isExists = await _airshipService.IsEmailChannelAlreadyExists(email);
        if (isExists != null && isExists == false)
        {
            var (isSuccess, errorMessage) = await _airshipService.CreateEmailChannelCommercial(email);
            if (!isSuccess)
            {
                _logger.Debug($"Class: CallingCardConsumptionService, Method: CreateEmailChannel, ErrorMessage: {errorMessage} , Email: {email}, RecordId: {id}");
                return false;
            }

            (isSuccess, errorMessage) = await _airshipService.EmailAssociationWithNamedUser(email, email);
            if (!isSuccess)
            {
                _logger.Debug($"Class: CallingCardConsumptionService, Method: EmailAssociationWithNamedUser, ErrorMessage: {errorMessage} , Email: {email}, RecordId: {id}");
                return false;
            }
        }
        return true;
    }

    #endregion
}
