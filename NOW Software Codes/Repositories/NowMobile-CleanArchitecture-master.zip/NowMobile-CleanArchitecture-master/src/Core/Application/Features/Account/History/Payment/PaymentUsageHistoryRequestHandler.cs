using Application.Common.Settings;
using Application.Features.Account.History.Models;
using Application.Features.Payment.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Application.Features.Account.History.Payment;
public class PaymentUsageHistoryRequestHandler : IRequestHandler<PaymentUsageHistoryRequest, Result<PaymentHistoryResponse>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<PaymentUsageHistoryRequestHandler> _localizer;
    private readonly ICommonService _commonService;
    private readonly CallBackSettings _callbackSettings;
    private readonly IUserService _userService;
    private readonly IMapper _mapper;

    public PaymentUsageHistoryRequestHandler(
        IUnitOfWork uow,
        IMapper mapper,
        IStringLocalizer<PaymentUsageHistoryRequestHandler> localizer,
        ICommonService commonService,
        IOptions<CallBackSettings> callbackSettings,
        IUserService userService)
    {
        _uow = uow;
        _localizer = localizer;
        _commonService = commonService;
        _userService = userService;
        _mapper = mapper;
        _callbackSettings = callbackSettings.Value;
    }

    public async Task<Result<PaymentHistoryResponse>> Handle(PaymentUsageHistoryRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();
        if (IsAppRequest)
        {
            request.StartDate = DateTime.UtcNow.Date;
            request.EndDate = DateTime.UtcNow.Date.AddDays(7);
            request.PageNo = 1;
            request.PageSize = 20;
        }
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<PaymentHistoryResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var paymentHistory = await _uow.UserRepo.PaymentHistory(request.Msisdn, request.StartDate, request.EndDate, request.PageNo, request.PageSize);
        List<PaymentHistoryInfo> paymentHistoryInfo = new List<PaymentHistoryInfo>();
        foreach (var item in paymentHistory)
        {
            string CardMaskedPan = "", ImageURL = "", GoodyBagColorCode = "";
            if (!String.IsNullOrEmpty(item.OrderData))
            {
                var orderData = JsonConvert.DeserializeObject<OrderData>(item.OrderData!)!;
                if (orderData != null)
                {
                    if (item.PaymentMethodType == (int) PaymentMethod.Card)
                    {
                        CardMaskedPan = string.IsNullOrEmpty(orderData.CardMaskedPan)
                        ? "Card Payment" : orderData.CardMaskedPan;
                        ImageURL = (IsAppRequest ? _callbackSettings.AppBaseUrl! : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(orderData.CardScheme!);
                    }
                    if (orderData.BundleInfo != null)
                    {
                        GoodyBagColorCode = !String.IsNullOrEmpty(orderData!.BundleInfo!.GoodyBagColorCode) ? orderData!.BundleInfo!.GoodyBagColorCode : "basic"!;
                    }
                }
            }
            else
            {
                CardMaskedPan = "Card Payment";
                ImageURL = (IsAppRequest ? _callbackSettings.AppBaseUrl! : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(null!);
                if (!string.IsNullOrEmpty(item.BundleId))
                {
                    GoodyBagColorCode = "basic";
                }
            }
            PaymentHistoryInfo vm = new PaymentHistoryInfo
            {
                Amount = item.Amount,
                BundleCountryCode = item.BundleCountryCode,
                BundleName = item.BundleName,
                Discount = item.Discount,
                Msisdn = item.Msisdn,
                OrderID = item.OrderID,
                PaymentMethodType = item.PaymentMethodType,
                TotalAmount = item.TotalAmount,
                TotalCount = item.TotalCount,
                TransactionDate = item.TransactionDate,
                TransactionId = item.TransactionId,
                TransactionItemType = item.TransactionItemType,
                TransactionType = item.TransactionType,
                CardMaskedPan = CardMaskedPan,
                ImageURL = ImageURL,
                GoodyBagColorCode = GoodyBagColorCode,
            };
            paymentHistoryInfo.Add(vm);
        }
        //paymentHistoryInfo = _mapper.Map<List<PaymentHistoryInfo>>(paymentHistory);
        var paymentHistoryResponse = new PaymentHistoryResponse()
        {
            History = paymentHistoryInfo,
            TotalCount = paymentHistory.Select(x => x.TotalCount).FirstOrDefault(),
            PageNo = request.PageNo,
            RecordsFiltered = paymentHistory.Count()
        };
        return Result<PaymentHistoryResponse>.Success(paymentHistoryResponse, _localizer[CustomStatusKey.Success]);
    }
}