﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Configurations
{
    
    public class ConnectionString
    {
        public string DefaultConnection { get; set; }
        public string DigiTalkConnection { get; set; }
        public string ThmConnection { get; set; }
        public string ThrccConnection { get; set; }
        public string ThccConnection { get; set; }
        public string ItsaConnection { get; set; }
        public string TalkHomePaymentsConnection { get; set; }
        public string ThaConnection { get; set; }
        
    }
}
