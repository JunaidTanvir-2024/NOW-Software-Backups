﻿using Dapper;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace PushNotification
{
    public class THMService
    {
        //private string DigitalkMobileString = ConfigurationManager.ConnectionStrings["DigitalkMobileDb"].ConnectionString.ToString();
        private string TalkHomePaymentCcString = ConfigurationManager.ConnectionStrings["TalkHomePaymentDb"].ConnectionString.ToString();
        private string DigitalkCcString = ConfigurationManager.ConnectionStrings["DigitalkTHCCDb"].ConnectionString.ToString();
        private string TalkHomeWebString = ConfigurationManager.ConnectionStrings["TalkHomeWebDb"].ConnectionString.ToString();
        private string TalkHomeAppString = ConfigurationManager.ConnectionStrings["TalkHomeAppsDb"].ConnectionString.ToString();
   
        IDbConnection TalkHomeAppConnection, TalkHomePaymentConnection, DigitalkCallingCardConnection, TalkHomeWebConnection;

        public THMService()
        {
            //DigitalkMobileConnection = new SqlConnection(DigitalkMobileString);
            TalkHomePaymentConnection = new SqlConnection(TalkHomePaymentCcString);
            DigitalkCallingCardConnection = new SqlConnection(DigitalkCcString);
            TalkHomeWebConnection = new SqlConnection(TalkHomeWebString);
            TalkHomeAppConnection = new SqlConnection(TalkHomeAppString);
        }

        public async Task<string> GetAndroidAccount(string msisdn)
        {

           
            try
            {
                if (TalkHomeAppConnection.State != ConnectionState.Open)
                {
                    TalkHomeAppConnection.Open();
                }

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                var result = await TalkHomeAppConnection.QueryFirstOrDefaultAsync<string>("tha_fcm_api_getToken", parameters, commandType: CommandType.StoredProcedure);
                return result;

                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
            }
            finally
            {
                TalkHomeAppConnection.Close();
            }

            return null;
        }

        public async Task GetThccPoints()
        {
            IEnumerable<AccountPoints> result=null;

            if (DigitalkCallingCardConnection.State != ConnectionState.Open)
            {
                DigitalkCallingCardConnection.Open();
            }

            try
            {
                var parameter = new DynamicParameters();
                //parameter.Add("@account", account);

                result = await DigitalkCallingCardConnection.QueryAsync<AccountPoints>("th_get_account_points",
                    parameter, commandType: CommandType.StoredProcedure);
            }
            catch ( Exception ex)
            {
                Console.WriteLine("Exception Occured" + ex.ToString());
            } finally
            {
                DigitalkCallingCardConnection.Close();
            }



           



            foreach (AccountPoints ap in result)
            {
                if(ap.account==null || ap.amount==null || ap.audid==0)
                {
                    Console.WriteLine("Invalid Point Reference , account or amount or audid ");
                    break;
                }

                
                await this.UpdatePoint(ap.account, decimal.Parse(ap.amount), ap.audid.ToString());


                await this.UpdatePointStatus(ap.account, decimal.Parse(ap.amount), ap.audid.ToString());

            }
            


            //th_get_account_points




        }





        public async Task GetThccUserAccount()
        {

            try
            {
                if (DigitalkCallingCardConnection.State != ConnectionState.Open)
                {
                    DigitalkCallingCardConnection.Open();
                }

                var parameter = new DynamicParameters();
                //parameter.Add("@account", account);

                var result = await DigitalkCallingCardConnection.QueryAsync<CC>("thcc_import_users",
                    parameter, commandType: CommandType.StoredProcedure);

                if (result != null && result.Count() > 0)
                {
                    var cca = result.FirstOrDefault<CC>();

                    var isExits = await isExists(cca.account, cca.email);
                    int errorcode = isExits.errorcode;
                    if (isExits.errorcode==0)
                    {
                        Console.WriteLine("Adding product and account " + cca.account);
                        var userres= await addUser(cca.email,
                            cca.password,
                             cca.title,
                            cca.firstname,
                            cca.lastname
                           );

                        if(userres!=null 
                            && userres.errorCode==0 
                            && userres.payload !=null 
                            && userres.payload.signUp !=null
                            && userres.payload.signUp.token !=null)
                        {
                            var confirm = await ConfirmUserAccount(cca.email);

                            if (confirm == 0)
                            {
                                var signres = await Signin(cca.email, cca.password);

                                if (signres != null
                                    && signres.errorCode == 0
                                    && signres.payload != null
                                    && signres.payload.authentication != null
                                    && signres.payload.authentication.token != null)
                                {
                                    var addProductRes = await AddProduct(signres.payload.authentication.token, cca.account.Trim(), cca.pin.Trim());

                                    if (addProductRes.errorCode == 0)
                                    {
                                        await UpdateAccount(cca.account.Trim(), errorcode);
                                    }
                                    else
                                    {

                                        await UpdateAccount(cca.account.Trim(), errorcode);
                                    }
                                }
                                else
                                {

                                    await UpdateAccount(cca.account.Trim(), errorcode);
                                }
                            }


                        }
                        else
                        {

                            await UpdateAccount(cca.account.Trim(), errorcode);
                        }

                    }
                    else if (isExits.errorcode == 1)
                    {
                        Console.WriteLine("Adding product for the account " + cca.account);
                        var signres = await Signin(cca.email, cca.password);

                        if(signres!=null
                            && signres.errorCode==0
                            && signres.payload!=null 
                            && signres.payload.authentication!=null
                            && signres.payload.authentication.token != null)
                        {
                            var confirm = await ConfirmUserAccount(cca.email);

                            if(confirm==0)
                            {
                                var addProductRes=await AddProduct(signres.payload.authentication.token, cca.account.Trim(), cca.pin);

                                if (addProductRes.errorCode == 0)
                                {
                                    await UpdateAccount(cca.account.Trim(), errorcode);
                                }
                                else
                                {

                                    await UpdateAccount(cca.account.Trim(), errorcode);
                                }
                            }
                        } else
                        {
                            await UpdateAccount(cca.account.Trim(), errorcode);
                        }


                        //product already added with different email
                    }
                    else if (isExits.errorcode == 2)
                    {
                        Console.WriteLine("Product Already added with different email " + cca.account);
                        //product already added with same email
                        await UpdateAccount(cca.account.Trim(), errorcode);
                    }
                    else if (isExits.errorcode == 3)
                    {
                        //await addUser(cca.email,
                        //    cca.password,
                        //     cca.title,
                        //    cca.firstname,
                        //    cca.lastname
                        //   );

                        Console.WriteLine("Account already existed " + cca.account);

                        await UpdateAccount(cca.account.Trim(), errorcode);

                    } else
                    {
                        //await addUser(cca.email,
                        //    cca.password,
                        //     cca.title,
                        //    cca.firstname,
                        //    cca.lastname
                        //   );
                        Console.WriteLine("Account already existed " + cca.account);
                        await UpdateAccount(cca.account.Trim(), errorcode);

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured" + ex.ToString());
            }
            finally
            {
                DigitalkCallingCardConnection.Close();
            }

        }



        private async Task<AccExists> isExists(string account, string email)
        {

            AccExists ace = null;
            try
            {
                if (TalkHomeWebConnection.State != ConnectionState.Open)
                {
                    TalkHomeWebConnection.Open();
                }

                var parameter = new DynamicParameters();
                parameter.Add("@account", account.Trim());
                parameter.Add("@email", email.Trim());

                var result = await TalkHomeWebConnection.QueryAsync<AccExists>("th_get_user_name",
                    parameter, commandType: CommandType.StoredProcedure);

                if (result != null && result.Count() > 0)
                {
                    ace = result.FirstOrDefault<AccExists>();





                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("");
            }
            finally
            {
                TalkHomeWebConnection.Close();
            }

            return ace;
        }

        private async Task<int> UpdateAccount(string account,int errorcode)
        {


            try
            {
                if (DigitalkCallingCardConnection.State != ConnectionState.Open)
                {
                    DigitalkCallingCardConnection.Open();
                }

                var parameter = new DynamicParameters();
                parameter.Add("@account", account);
                parameter.Add("@errorcode", errorcode);

                var result = await DigitalkCallingCardConnection.ExecuteAsync("thcc_import_users_create_log",
                    parameter, commandType: CommandType.StoredProcedure);

                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured" + ex.ToString());
            }
            finally
            {
                DigitalkCallingCardConnection.Close();
            }

            return 1;
        }

        private async Task<int> ConfirmUserAccount(string email)
        {


            try
            {
                if (TalkHomeWebConnection.State != ConnectionState.Open)
                {
                    TalkHomeWebConnection.Open();
                }

                var parameter = new DynamicParameters();
                parameter.Add("@email", email.Trim());

                var result = await TalkHomeWebConnection.ExecuteAsync("th_confirm_user_v2",
                    parameter, commandType: CommandType.StoredProcedure);

                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured" + ex.ToString());
            }
            finally
            {
                TalkHomeWebConnection.Close();
            }

            return 1;
        }

        private async Task<int> UpdatePointStatus(string account, decimal amount, string reference)
        {


            if (DigitalkCallingCardConnection.State != ConnectionState.Open)
            {
                DigitalkCallingCardConnection.Open();
            }

            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@auditId", int.Parse(reference));
                parameter.Add("@account", account);
                parameter.Add("@amount", amount);

                var result = await DigitalkCallingCardConnection.ExecuteAsync("thc_create_points_update_log",
                    parameter, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured" + ex.ToString());
            }
            finally
            {
                DigitalkCallingCardConnection.Close();
            }

            return 1;
        }


        private async Task<int> UpdatePoint(string account,decimal amount,string reference)
        {

            
            try
            {
                if (TalkHomePaymentConnection.State != ConnectionState.Open)
                {
                    TalkHomePaymentConnection.Open();
                }

                var parameter = new DynamicParameters();
                parameter.Add("@basket_customer_reference", account);
                parameter.Add("@amount", amount);
                parameter.Add("@reference", reference);

                var result = await TalkHomePaymentConnection.ExecuteAsync("thc_add_points_daemon",
                    parameter, commandType: CommandType.StoredProcedure);

                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured"+ex.ToString());
            }
            finally
            {
                TalkHomePaymentConnection.Close();
            }

            return 1;
        }



        private async Task<AddProductRes> AddProduct(string Token,
            string Account,
            string Pin
            )

        {

            AddProductRes pcr = null;

            HttpClient client = new HttpClient
            {
                BaseAddress = new Uri("https://api.talkhome.co.uk/"),
            };

            client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
            client.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");
            client.DefaultRequestHeaders.TryAddWithoutValidation("Token", Token);
            client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue(
                        "Basic",
                        Convert.ToBase64String(Encoding.ASCII.GetBytes("betatest:j6vbV7EcnxCwheyM")));


            var body = JsonConvert.SerializeObject(new
            {
                Number = Account,
                Code = Pin
            }, new JsonSerializerSettings
            {
                ContractResolver = new DefaultContractResolver()
            });



            try
            {
                var requestMessage = new HttpRequestMessage(HttpMethod.Post,
                    $"talkhome/product/thcc/add")
                {
                    Content = new StringContent(body, Encoding.UTF8, "application/json")
                };

                var result = await client.SendAsync(requestMessage);

                if (!result.IsSuccessStatusCode)
                {
                    pcr = null;
                }

                if (result.Content != null)
                {
                    pcr = JsonConvert.DeserializeObject<AddProductRes>(await result.Content.ReadAsStringAsync());
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured : " + ex.ToString());
            }

            return pcr;

        }


        /*
        * 
        * 
        * 
        * 
        * "Title": "Mrs",
 "FirstName": "TalkHome",
 "LastName": "Mobile",
 "DateOfBirth": "",
 "ContactNo": "",
 "MobileNo": "",
 "IsSubscribedToNewsletter": false */
        private async Task<LoginRes> Signin(string Email,
            string Password
            )

        {

            LoginRes pcr = null;

            HttpClient client = new HttpClient
            {
                BaseAddress = new Uri("https://api.talkhome.co.uk/"),
            };

            client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
            client.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");
            client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue(
                        "Basic",
                        Convert.ToBase64String(Encoding.ASCII.GetBytes("betatest:j6vbV7EcnxCwheyM")));


            var body = JsonConvert.SerializeObject(new
            {
                Email = Email,
                Password = Password,
                IPAddress = "192.168.0.1"
            }, new JsonSerializerSettings
            {
                ContractResolver = new DefaultContractResolver()
            });



            try
            {
                var requestMessage = new HttpRequestMessage(HttpMethod.Post,
                    $"talkhome/useraccount/login")
                {
                    Content = new StringContent(body, Encoding.UTF8, "application/json")
                };

                var result = await client.SendAsync(requestMessage);

                if (!result.IsSuccessStatusCode)
                {
                    pcr = null;
                }

                if (result.Content != null)
                {
                    pcr = JsonConvert.DeserializeObject<LoginRes>(await result.Content.ReadAsStringAsync());
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured : " + ex.ToString());
            }

            return pcr;

        }






        /*
         * 
         * 
         * 
         * 
         * "Title": "Mrs",
  "FirstName": "TalkHome",
  "LastName": "Mobile",
  "DateOfBirth": "",
  "ContactNo": "",
  "MobileNo": "",
  "IsSubscribedToNewsletter": false */
        private async Task<AddUserRes> addUser(string Email,
            string Password, 
            string Title,
            string FirstName,
            string LastName
            )
        
            {
                if (string.IsNullOrEmpty(Title) || string.IsNullOrWhiteSpace(Title))
                    Title = "Mr";

                if (string.IsNullOrEmpty(FirstName) || string.IsNullOrWhiteSpace(FirstName))
                    FirstName = "Firstname";

                if (string.IsNullOrEmpty(LastName) || string.IsNullOrWhiteSpace(LastName))
                    LastName = "LastName";



                AddUserRes pcr = null;

                HttpClient client = new HttpClient
                {
                    BaseAddress = new Uri("https://api.talkhome.co.uk/"),
                };

                client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
                client.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");
                client.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue(
                            "Basic",
                            Convert.ToBase64String(Encoding.ASCII.GetBytes("betatest:j6vbV7EcnxCwheyM")));


                var body = JsonConvert.SerializeObject(new { Email = Email,
                    Password = Password,
                    Title = Title,
                    FirstName = FirstName,
                    LastName = LastName,
                    DateOfBirth = "",
                    ContactNo = "",
                    MobileNo="",
                    IsSubscribedToNewsletter=false
                }, new JsonSerializerSettings
                {
                    ContractResolver = new DefaultContractResolver()
                });



                try
                {
                    var requestMessage = new HttpRequestMessage(HttpMethod.Post,
                        $"talkhome/useraccount/signup")
                    {
                        Content = new StringContent(body, Encoding.UTF8, "application/json")
                    };

                    var result = await client.SendAsync(requestMessage);

                    if (!result.IsSuccessStatusCode)
                    {
                        pcr = null;
                    }

                    if (result.Content != null)
                    {
                        pcr = JsonConvert.DeserializeObject<AddUserRes>(await result.Content.ReadAsStringAsync());
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception Occured : " + ex.ToString());
                }

                return pcr;
                
            }


        private async Task<ConfirmRes> confirmUser(string token
            )

        {




            ConfirmRes pcr = null;

            HttpClient client = new HttpClient
            {
                BaseAddress = new Uri("https://api.talkhome.co.uk/"),
            };

            client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
            client.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");
            client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue(
                        "Basic",
                        Convert.ToBase64String(Encoding.ASCII.GetBytes("betatest:j6vbV7EcnxCwheyM")));


            



            try
            {
                var requestMessage = new HttpRequestMessage(HttpMethod.Get,
                    $"talkhome/confirm/{token}");

                var result = await client.SendAsync(requestMessage);

                if (!result.IsSuccessStatusCode)
                {
                    pcr = null;
                }

                if (result.Content != null)
                {
                    pcr = JsonConvert.DeserializeObject<ConfirmRes>(await result.Content.ReadAsStringAsync());
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured : " + ex.ToString());
            }

            return pcr;

        }











    }

    public class AddProductRes
    {
        public int status { get; set; }
        public string message { get; set; }
        public int errorCode { get; set; }
    }

    public class Authentication
    {
        public string fullName { get; set; }
        public string firstName { get; set; }
        public string token { get; set; }
        public DateTime expiryDate { get; set; }
        public List<string> productCodes { get; set; }
    }

    public class LoginPayload
    {
        public Authentication authentication { get; set; }
    }

    public class LoginRes
    {
        public int status { get; set; }
        public string message { get; set; }
        public LoginPayload payload { get; set; }
        public int errorCode { get; set; }
    }



    public class Confirm
    {
        public bool isConfirmed { get; set; }
    }

    public class ConfirmRes
    {
        public int status { get; set; }
        public string message { get; set; }
        public Confirm confirm { get; set; }
        public int errorCode { get; set; }
    }



    public class SignUp
    {
        public bool isRegistered { get; set; }
        public string token { get; set; }
    }

    public class Payload
    {
        public SignUp signUp { get; set; }
    }

    public class AddUserRes
    {
        public int status { get; set; }
        public string message { get; set; }
        public Payload payload { get; set; }
        public int errorCode { get; set; }
    }



    /**
     * account,password,email,state
     * 
     * 
     * 
     **/

    public class AccExists
    {
        public int errorcode { get; set; }
    }

    public class CC
    {
        public string account { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public string state { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string title { get; set; }
        public string pin { get; set; }
    }

    public class AccountPoints
    {
        public string account { get; set; }
        public string amount { get; set; }
        public string reason { get; set; }
        public string method { get; set; }
        public string reference { get; set; }
        public int audid { get; set; }


    }



}

