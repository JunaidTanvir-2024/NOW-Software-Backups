﻿namespace SenderService.Core.Services.Mailing;

public interface ISmtpMailService
{
    Task<bool> SendAsync(MailRequest request, CancellationToken cancellationToken = default);
}