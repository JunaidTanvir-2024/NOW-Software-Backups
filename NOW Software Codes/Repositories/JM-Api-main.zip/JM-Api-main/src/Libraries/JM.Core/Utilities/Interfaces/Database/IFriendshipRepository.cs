using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;

public interface IFriendshipRepository : ResolveAs.IScoped
{
    Task<Friendship> AddFriendship(Friendship friendship);
    void UpdateFriendship(Friendship friendship);
    Task<Friendship?> GetFriendship(Expression<Func<Friendship, bool>> expression);
    Task<IEnumerable<Friendship>> GetFriendshipList(Expression<Func<Friendship, bool>> expression = default!);
}
