﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SC.Api.Model.CustomerOrder;
using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Features.CustomerOrder;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.CustomerOrder.Responses;
using SC.Core.Features.Operators;

namespace SC.Api.Controllers.V1;

[ApiVersion(1.0)]
public sealed class CustomerOrderController : BaseApiController
{

    //[Authorize]
    [AllowAnonymous]
    [HttpPost("AddProductToCart")]
    public async Task<ActionResult> AddProductToCart(CartCreationModel model)
    {
        var result = await Mediator.Send(new CartCreationRequest()
        {
            CustomerCartID = model.CustomerCartID,
            ProductID = model.ProductID,
            Currency = model.Currency,
            IsGuestUser = model.IsGuestUser,
            UserID = model.UserID,
            ProductPrice = model.ProductPrice,
        });


        if (result.IsSuccess)
        {
            var typedResponse = result.TypedPayload<CartCreationResponse>();
            var customerCart = await Mediator.Send(new GetCustomerCartRequest() { IsGuestUser = model.IsGuestUser, UserID = typedResponse?.UserID });
            if (customerCart.IsSuccess)
            {
                return Ok(customerCart);
            }
            return BadRequest(customerCart);
        }
        return BadRequest(result);

    }
    [Authorize]
    [HttpPost("AddCartItemDetail")]
    public async Task<ActionResult> AddCartItemDetail(CartItemCreationModel model)
    {
        var result = await Mediator.Send(new CartItemCreationRequest()
        {
            receiverEmail = model.receiverEmail,
            receiverMobile = model.receiverMobile,
            receiverPin = model.receiverPin,
            customMessage = model.customMessage,
            isRenewal = model.isRenewal,
            senderId = model.senderId,
            senderName = model.senderName,
            senderEmail = model.senderEmail,
            senderMobile = model.senderMobile,
            productId = model.productId,
            customerCartId = model.customerCartId,
            isActive = model.isDeleted,
            isDeleted = model.isActive
        });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);

    }
    //[Authorize]
    [AllowAnonymous]
    [HttpPost("RemoveProductFromCart")]
    public async Task<ActionResult> RemoveProductFromCart(RemoveCartModel model)
    {
        var result = await Mediator.Send(new RemoveProductFromCartRequest()
        {
            ProductID = model.productID,
            CustomerCartID = model.CustomerCartID,
            IsGuestUser = model.IsGuestUser,
            UserID = model.UserID,
        });
        if (result.IsSuccess)
        {
            var customerCart = await Mediator.Send(new GetCustomerCartRequest() { IsGuestUser = model.IsGuestUser, UserID = model.UserID });
            if (customerCart.IsSuccess)
            {
                return Ok(customerCart);
            }
            return BadRequest(customerCart);
        }
        return BadRequest(result);

    }

    //[Authorize]
    [AllowAnonymous]
    [HttpPost("GetCustomerCart")]
    public async Task<ActionResult> GetCustomerCart(GetCustomerCartModel model)
    {
        var result = await Mediator.Send(new GetCustomerCartRequest() { IsGuestUser = model.IsGuestUser, UserID = model.UserID });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);

    }

    [Authorize]
    [HttpPost("AddCustomerAddress")]
    public async Task<ActionResult> AddCustomerAddress(AddCustomerAddressModel model)
    {
        var result = await Mediator.Send(new AddCustomerAddressRequest()
        {
            AddressType = model.AddressType,
            StreetAddress1 = model.StreetAddress1,
            StreetAddress2 = model.StreetAddress2,
            City = model.City,
            State = model.State,
            PostalCode = model.PostalCode,
            Country = model.Country,
            Email = model.Email,
            Phone = model.Phone,
            Region = model.Region,
            CountryCode = model.CountryCode,
        });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);

    }

    [Authorize]
    [HttpGet("GetCustomerOrders")]
    public async Task<ActionResult> GetCustomerOrders()
    {
        var result = await Mediator.Send(new GetCustomerOrdersRequest());
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);

    }

    [Authorize]
    [HttpGet("GetCustomerOrderDetail")]
    public async Task<ActionResult> GetCustomerOrderDetail(long orderID)
    {
        var result = await Mediator.Send(new CustomerOrder.Request() { OrderID= orderID });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return BadRequest(result);

    }


}

