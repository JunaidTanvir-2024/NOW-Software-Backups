using DC.Api;
InitializeLogger();
var assemblyName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;

Log.Information($"{assemblyName} Booting Up..");
try
{
	var builder = WebApplication.CreateBuilder(args);
	{
        builder.Host.UseSerilog((hostingContext, config) => config.ReadFrom.Configuration(hostingContext.Configuration).WriteTo.Sentry());
        builder.WebHost.UseSentry();
        // Configure Services
		builder.Services.AddApiDependencies(builder.Configuration);

        var port = builder.Configuration.GetValue<string>("Kestrel:Endpoints:Http:Url");

        Log.Information($"{port} Booting Up..");
    }
	WebApplication? app = builder.Build();

	{
        app.AddApiMiddlewares();
        app.Run();
	}
}
catch (Exception ex) when (!ex.GetType().Name.Equals("StopTheHostException", StringComparison.Ordinal))
{
	InitializeLogger();
	Log.Error($"{assemblyName} Shutting down...");
	Log.Fatal(ex, "Unhandled exception");
	throw;
}
finally
{
	InitializeLogger();
	Log.Error($"{assemblyName} Shutting down...");
	Log.CloseAndFlush();
}

/// <summary>
/// Static console logger
/// </summary>
static void InitializeLogger()
{
	if (Log.Logger is not Serilog.Core.Logger)
	{
		Log.Logger = new LoggerConfiguration().WriteTo.Console().WriteTo.Sentry().CreateLogger();
	}
}
