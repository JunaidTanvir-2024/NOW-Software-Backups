﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class TransferByCardCallBackRequestModel
    {
        public string nowtelRef { get; set; }
        public string product { get; set; }
        public string operatorId { get; set; }
        public string MD { get; set; }
        public string PaRes { get; set; }
        public string customerEmail { get; set; }
        public string IpAddress { get; set; }
        public string clientRedirectType { get; set; }
    }
}
