using SenderService.Core;
using SenderService.Core.Common.Settings;
using SenderService.Core.Persistence;
using SenderService.Worker;

var builder = Host.CreateDefaultBuilder(args);
{

    builder.ConfigureServices((hostingContext, services) =>
    {
        // Add the email sender worker
        services.AddLogging();
        services.AddCoreLayerServices(hostingContext.Configuration);
        services.AddHostedService<EmailDispatchWorker>();
        services.AddOptions<EmailDispatcherSettings>()
           .Bind(hostingContext.Configuration.GetSection(EmailDispatcherSettings.SectionName));
    });
}

var host = builder.Build();
{
    host.Run();
}