﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class CallingCodesLandingPageViewMOdel
    {
        public CallingCodesCountryContent LandingPageContent { get; set; }      
        public List<Bundles> Bundles { get; set; }
        public string CurrencySymbol { get; set; }
    }

    public class CallingCodesCountryContent
    {
        public string BannerMainHeadline { get; set; }
        public string BannerMainHeadlineDescription { get; set; }
        public string Bannercontent { get; set; }       
        public string Bannerimagesource { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public string MainHeadline { get; set; }
        public string MainHeadlinesDescription { get; set; }
        public List<CountrySpecificQuestions> PageContent { get; set; }
        public string RecomendedBundlesHeading { get; set; }
        public string RecomendedBundlesDescription { get; set; }
        public List<RecomendedBundles> RecomendedBundlesNames { get; set; }

        public string SendInternationalTopupHeading { get; set; }

        public string SendInternationalTopupDescription { get; set; }
        public string AreaCodeHeading { get; set; }
        public string AreaCodeDescription { get; set; }
        public List<Codelist> AreaCodesList1 { get; set; }
        public List<Codelist> AreaCodesList2 { get; set; }
        public List<Codelist> AreaCodesList3 { get; set; }
        public List<Codelist> AreaCodesList4 { get; set; }


    }

    public class AreaCode
    {
        public string AreaCodeHeading { get; set; }
        public string AreaCodeDescription { get; set; }
        public List<Codelist> AreaCodesList { get; set; }
    }
    public class CountrySpecificQuestions
    {
        public string Heading { get; set; }
        public string Description { get; set; }
    }
    public class Codelist 
    { 
        public string AreaName { get; set; }
        public int AreaCode { get; set; }
    }

    public class RecomendedBundles
    {       
        public string Bundlename { get; set; }
    }

}
