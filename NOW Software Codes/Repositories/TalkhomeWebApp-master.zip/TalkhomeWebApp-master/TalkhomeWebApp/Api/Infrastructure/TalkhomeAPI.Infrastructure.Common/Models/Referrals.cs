﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models
{
    public class Referrals
    {
        public List<ReferralOut> referrals { get; set; }
    }

    public class DingPromoResponse
    {
        public DingPayload payload = new DingPayload();
    }

    public class DingPayload
    {
        public List<PromotionItem> item = new List<PromotionItem>();
        public List<string> dingCountries = new List<string>();
    }
    public class PromotionItem
    {
        public string title { get; set; }
        public string description { get; set; }
        public string dateFrom { get; set; }
        public string dateTo { get; set; }
        public string pubDate { get; set; }
        public string operatorName { get; set; }
        public string operatorId { get; set; }
        public string subOperatorId { get; set; }
        public string countryId { get; set; }
        public string countryName { get; set; }
        public string title2 { get; set; }
        public string denomination { get; set; }
        public string denominationLocal { get; set; }
        public string promotionstatus { get; set; }
        public string operatorImageUrl { get; set; }
    }

    public class Channel
    {
        public string title { get; set; }
        public string description { get; set; }
        public string link { get; set; }
        public string pubDate { get; set; }
        public string lastBuildDate { get; set; }
        public string ttl { get; set; }
        public List<PromotionItem> item { get; set; }
    }

    public class RSS
    {
        public List<PromotionCountry> country { get; set; }
        public Channel channel { get; set; }
        public PromotionCountry defaultCountry { get; set; }

    }
    public class RSSResult
    {
        public string message { get; set; }
        public int status { get; set; }
        public RSS result { get; set; }
    }


    /***
     * msisdn varchar(50) not null,
	email varchar(100) not null,
	canBeContacted bit not null default(0) **/

    public class useremailRegistration
    {
        public string email { get; set; }
        public string msisdn { get; set; }
        public bool canBeContacted { get; set; }
    }

    public class PromotionCountry
    {
        public string countryId { get; set; }
        public string countryName { get; set; }
        public bool status { get; set; }
    }

    public class Promotion
    {
        public string countryId { get; set; }
        public string countryName { get; set; }
        public bool status { get; set; }

    }
    public class Referral
    {

        public string msisdn { get; set; }

        public decimal amount { get; set; }

        public string Date { get; set; }


    }

    public class ReferralOut
    {

        public string msisdn { get; set; }

        public string amount { get; set; }

        public string date { get; set; }

    }
}
