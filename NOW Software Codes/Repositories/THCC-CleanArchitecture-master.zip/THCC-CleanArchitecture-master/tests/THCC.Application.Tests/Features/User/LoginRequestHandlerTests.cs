﻿using FakeItEasy;

using FluentAssertions;

using MapsterMapper;

using Microsoft.Extensions.Options;

using Serilog;

using THCC.Application.Extensions.Security;
using THCC.Application.Features.User.ForgotPassword.ForgotPasswod;
using THCC.Application.Features.User.Login;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;
using THCC.Domain.Entities;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Application.Tests.Features.User
{
    public class LoginRequestHandlerTests
    {
        private readonly IUserRepository _userRepo;
        private readonly ILegacyRepository _legacyRepo;
        private readonly ILogger _logger;
        private readonly ICommonService _commonService;
        private readonly IOptions<ProfileSettings> _profileSetting;
        private readonly IUserService _userService;
        private readonly IMapper _mapper;
        private readonly ILegacySecurityService _legacySecurityService;
        private readonly IAirshipService _airshipService;

        private readonly LoginRequestHandler _loginRequestHandler;

        public LoginRequestHandlerTests()
        {
            _mapper = A.Fake<IMapper>();
            _userRepo = A.Fake<IUserRepository>();
            _legacyRepo = A.Fake<ILegacyRepository>();
            _logger = A.Fake<ILogger>();
            _commonService = A.Fake<ICommonService>();
            _profileSetting = A.Fake<IOptions<ProfileSettings>>();
            _userService = A.Fake<IUserService>();
            _legacySecurityService = A.Fake<ILegacySecurityService>();
            _airshipService = A.Fake<IAirshipService>();
            _loginRequestHandler = new LoginRequestHandler(
                _mapper, _userRepo, _legacyRepo, _logger, _profileSetting, _commonService, _userService, _legacySecurityService, _airshipService);
        }

        [Fact]
        public async Task LoginRequestHandler_UserNotRegistered()
        {
            //Arrange
            var request = new LoginRequest()
            {
                Email = "usman@yahoo.com",
                Password = "password"
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.AccountNotRegistered
                    }
                }
            };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns((Domain.Entities.User?)null!);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns((LegacyUser)null!);

            //Act
            var result = await _loginRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task LoginRequestHandler_LegacyUserNotConfirmed()
        {
            //Arrange
            var request = new LoginRequest()
            {
                Email = "usman@yahoo.com",
                Password = "password"
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.AccountNotRegistered
                    }
                }
            };
            var legacyUser = new LegacyUser() { IsConfirmedUser = false };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns((Domain.Entities.User?)null!);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns(legacyUser);

            //Act
            var result = await _loginRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task LoginRequestHandler_LegacyUserInvalidPassword()
        {
            //Arrange
            var request = new LoginRequest()
            {
                Email = "usman@yahoo.com",
                Password = "password"
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.InvalidCredentials
                    }
                }
            };
            var legacyUser = new LegacyUser() { IsConfirmedUser = true };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns((Domain.Entities.User?)null!);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns(legacyUser);
            A.CallTo(() => _legacySecurityService.CheckPassword(request.Password, legacyUser)).Returns(false);

            //Act
            var result = await _loginRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task LoginRequestHandler_LegacytoNewDbUserRegistrationFailed()
        {
            //Arrange
            var request = new LoginRequest()
            {
                Email = "usman@yahoo.com",
                Password = "password"
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.InternalServerError,
                        Message =  CustomStatusKey.InternalServerError
                    }
                }
            };
            var signUpResponse = new SignUpInfoDto()
            {
                IsSuccess = false
            };
            var legacyUser = new LegacyUser() { IsConfirmedUser = true, FirstName = "first", LastName = "last" };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns((Domain.Entities.User?)null!);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns(legacyUser);
            A.CallTo(() => _legacySecurityService.CheckPassword(request.Password, legacyUser)).Returns(true);
            A.CallTo(() => _userService.SignUpAsync(null!, null!, "asdads", "asd", "asdasd", true)).Returns(signUpResponse);

            //Act
            var result = await _loginRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task LoginRequestHandler_LegacytoNewDbProductRegistration_CardNumberAlreadyRegister()
        {
            //Arrange
            var request = new LoginRequest()
            {
                Email = "usman@yahoo.com",
                Password = "password"
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.CardNumberAlreadyRegistered
                    }
                }
            };
            var signUpResponse = new SignUpInfoDto()
            {
                IsSuccess = true,
                Errors = null,
                Id = "123123"
            };
            var legacyUserProduct = new LegacyProduct()
            {
                IsActive = true,
                DateCreated = DateTime.UtcNow,
                Id = 12312,
                ProductRef = "123123"
            };
            var legacyUser = new LegacyUser() { IsConfirmedUser = true, FirstName = "first-1", LastName = "last-1" };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).ReturnsNextFromSequence((Domain.Entities.User?)null!);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns(legacyUser);
            A.CallTo(() => _legacySecurityService.CheckPassword(request.Password, legacyUser)).Returns(true);
            A.CallTo(() => _userService.SignUpAsync(legacyUser.FirstName, legacyUser.LastName, request.Email, request.Password, UserRole.Customer, true)).Returns(signUpResponse);
            A.CallTo(() => _legacyRepo.GetUserProducts(legacyUser.Id)).Returns(legacyUserProduct);
            A.CallTo(() => _userRepo.CreateProduct(legacyUserProduct.ProductRef, signUpResponse.Id, legacyUserProduct.DateCreated)).Returns((false, 1, "null"));

            //Act
            var result = await _loginRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task LoginRequestHandler_InvalidlegacyPasswordForWithoutPasswordUser()
        {
            //Arrange
            var request = new LoginRequest()
            {
                Email = "usman@yahoo.com",
                Password = "password"
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.InvalidCredentials
                    }
                }
            };
            var user = new Domain.Entities.User() { EmailConfirmed=true};
            var legancyUser = new LegacyUser() { IsConfirmedUser=true };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns(user);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns(legancyUser);
            A.CallTo(() => _legacySecurityService.CheckPassword(request.Password, legancyUser)).Returns(false);

            //Act
            var result = await _loginRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task LoginRequestHandler_GuestUserwithoutPassword()
        {
            //Arrange
            var request = new LoginRequest()
            {
                Email = "usman@yahoo.com",
                Password = "password"
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.InvalidCredentials
                    }
                }
            };
            var user = new Domain.Entities.User() { Email = "usman@yahoo.com" };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns(user);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns((LegacyUser)null!);
            A.CallTo(() => _userRepo.IsSocialLoginUser(user)).Returns(true);

            //Act
            var result = await _loginRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task LoginRequestHandler_UserNotConfirmed()
        {
            //Arrange
            var request = new LoginRequest()
            {
                Email = "usman@yahoo.com",
                Password = "password"
            };
            var response = new ErrorResult()
            {
                Errors = new List<ErrorDto>()
                {
                    new ErrorDto()
                    {
                        Code =CustomStatusCode.BadRequest,
                        Message =  CustomStatusKey.AccountNotRegistered
                    }
                }
            };
            var user = new Domain.Entities.User() { EmailConfirmed = false };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns(user);

            //Act
            var result = await _loginRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task LoginRequestHandler_LoginwithAddlegacyPassword()
        {
            //Arrange
            var request = new LoginRequest()
            {
                Email = "usman@yahoo.com",
                Password = "password"
            };
            var response = new LoginResponse()
            {
                User = new UserDto(),
                Token = "ffefefef78774877rfryf7y7yer7fy"
            };
            var user = new Domain.Entities.User() { EmailConfirmed = true };
            var legancyUser = new LegacyUser() { IsConfirmedUser = true };
            var loginResponse = new LoginInfoDto()
            {
                IsSuccess = true,
                Token = "ffefefef78774877rfryf7y7yer7fy"
            };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).Returns(user);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns(legancyUser);
            A.CallTo(() => _legacySecurityService.CheckPassword(request.Password, legancyUser)).Returns(true);
            A.CallTo(() => _userService.LoginAsync(user, request.Password, true)).Returns(loginResponse);

            //Act
            var result = await _loginRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<ErrorResult>()
                .Which.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task LoginRequestHandler_LegacytoNewDbProductRegistration_CardNumberAlreadyRegister_SuccessfulLogin()
        {
            //Arrange
            var request = new LoginRequest()
            {
                Email = "usman@yahoo.com",
                Password = "password"
            };
            var loginResponse = new LoginInfoDto()
            {
                IsSuccess = true,
                ErrorCode = 0,
                ErrorMessage = null,
                RefreshToken = "ffefefef78774877rfryf7y7yer7fy",
                Token = "ffefefef78774877rfryf7y7yer7fy"
            };
            var response = new LoginResponse()
            {
                User = new UserDto(),
                RefreshToken = loginResponse.RefreshToken,
                Token = "ffefefef78774877rfryf7y7yer7fy"
            };
            var signUpResponse = new SignUpInfoDto()
            {
                IsSuccess = true,
                Errors = null,
                Id = "123123"
            };
            var legacyUserProduct = new LegacyProduct()
            {
                IsActive = true,
                DateCreated = DateTime.UtcNow,
                Id = 12312,
                ProductRef = "123123"
            };
            var legacyUser = new LegacyUser() { IsConfirmedUser = true, FirstName = "first-1", LastName = "last-1" };

            var user = new Domain.Entities.User()
            {
                FirstName = legacyUser.FirstName,
                LastName = legacyUser.LastName,
                Email = request.Email,
                PasswordHash = "ufheurhgurhgurgh"
            };
            A.CallTo(() => _userRepo.GetUserByEmailAsync(request.Email)).
                ReturnsNextFromSequence(null!, user);
            A.CallTo(() => _legacyRepo.GetUserByEmail(request.Email)).Returns(legacyUser);
            A.CallTo(() => _legacySecurityService.CheckPassword(request.Password, legacyUser)).Returns(true);
            A.CallTo(() => _userService.SignUpAsync(legacyUser.FirstName, legacyUser.LastName, request.Email, request.Password, UserRole.Customer, true)).Returns(signUpResponse);
            A.CallTo(() => _legacyRepo.GetUserProducts(legacyUser.Id)).Returns(legacyUserProduct);
            A.CallTo(() => _userRepo.CreateProduct(legacyUserProduct.ProductRef, signUpResponse.Id, legacyUserProduct.DateCreated)).Returns((true, 0, "null"));
            A.CallTo(() => _userService.LoginAsync(user, request.Password, true)).Returns(loginResponse);

            //Act
            var result = await _loginRequestHandler.Handle(request, CancellationToken.None);

            //Assert
            result.Should().BeEquivalentTo(response);
        }

    }
}
