﻿namespace Models.Contracts.Response.Voucherify
{
    public class ReferralCodeEligibilityResponse
    {
        public bool IsEligibile { get; set; }
    }
}
