global using FluentValidation;
global using MediatR;
global using static THCC.Domain.Constants.ThccConstants;
global using static THCC.Domain.Constants.ThccEnums;
global using System.Text.Json.Serialization;
global using THCC.Application.Interfaces.Services;
global using THCC.Domain.Entities;
global using THCC.Application.Interfaces.Repositories;
global using Microsoft.AspNetCore.Http;
global using Microsoft.Extensions.Options;
global using THCC.Application.Extensions.FluentValidation;
global using Mapster;
global using MapsterMapper;
global using Microsoft.Extensions.DependencyInjection;
global using System.Reflection;
global using THCC.Application.Extensions.DependencyResolver;
global using System.Security.Cryptography;
global using Serilog;

