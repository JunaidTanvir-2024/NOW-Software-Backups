using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;

public interface ISubscriptionRepository : ResolveAs.IScoped
{
    Task<Subscription> AddSubscription(Subscription subscription);
    Task AddSubscriptionBenefits(IEnumerable<SubscriptionBenefit> subscriptionBenefits);
    void UpdateSubscription(Subscription subscription);
    Task<Subscription?> GetSubscription(Expression<Func<Subscription, bool>> expression);
    Task<IEnumerable<Subscription>> GetSubscriptionList();
}
