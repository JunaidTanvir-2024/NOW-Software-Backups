﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class GetChannelByEmailRequest
    {
        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("email_channel_id")]
        [Required]
        public string email_channel_id { get; set; }

    }
}
