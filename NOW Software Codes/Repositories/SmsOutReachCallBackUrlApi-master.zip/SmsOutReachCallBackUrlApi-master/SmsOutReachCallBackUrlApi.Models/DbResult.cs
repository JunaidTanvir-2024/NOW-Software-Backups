﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmsOutReachCallBackUrlApi.Models
{
    public class DbResult
    {
        public int DBStatus { get; set; }
        public string DBErrorMessage { get; set; }
    }
}
