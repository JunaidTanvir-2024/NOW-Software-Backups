﻿using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerCard.Request;
public sealed class GetCustomerCardRequest : IRequest<IResultWrapper>
{
    public string UserId { get; set; } = default!;
   
}
public sealed class GetCustomerCardRequestValidator : AbstractValidator<GetCustomerCardRequest>
{
    public GetCustomerCardRequestValidator()
    {
       
       
    }
    
}
