﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using THCCWEB.Attributes;

namespace THCCWEB.Models.ViewModels
{
    public class OrderRechargeablecardViewModel
    {

        [Required(ErrorMessage = "Enter first name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-z]+([\s][a-zA-Z]+)*$", ErrorMessage = "Invalid first name")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Enter last name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-z]+([\s][a-zA-Z]+)*$", ErrorMessage = "Invalid last name")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Enter Email")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }
        [CompareStrings("Email", ErrorMessage = "Email address does not match", IgnoreCase = true)]
        [Required(ErrorMessage = "Enter Confirm Email")]
        [EmailAddress(ErrorMessage = "Invalid confirm Email Address")]
        public string ConfirmEmail { get; set; }

        [Required(ErrorMessage = "Enter Password")]
        [StringLength(50, ErrorMessage = "Must be between 8 and 50 characters", MinimumLength = 8)]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Enter Confirm Password ")]
        [StringLength(50, ErrorMessage = "Must be between 8 and 50 characters", MinimumLength = 8)]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Confirm Password doesn't match, Type again !")]
        public string ConfirmPassword { get; set; }


        [Required(ErrorMessage = "Please select a Credit")]
        public Nullable<int> Credit { get; set; }
    }
}
