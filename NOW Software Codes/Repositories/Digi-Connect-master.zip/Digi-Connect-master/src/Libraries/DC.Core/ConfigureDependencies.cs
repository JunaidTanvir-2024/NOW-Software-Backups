using DC.Core.Common.DependencyResolver;
using DC.Core.Common.Setting;

namespace DC.Core;

public static class ConfigureDependencies
{
    public static IServiceCollection AddCoreDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.AutoResolve();
        services.RegisterJsonSettings(configuration);
        services.RegisterCoreServices();
        return services;
    }

    private static IServiceCollection RegisterCoreServices(this IServiceCollection services)
    {
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
        services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
        return services;
    }
    private static IServiceCollection RegisterJsonSettings(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<SMSMarketingSetting>(configuration.GetSection(SMSMarketingSetting.SectionName));
      
        return services;
    }
}
