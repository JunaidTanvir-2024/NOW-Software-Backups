﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Serilog;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Database;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class Transaction_DL : ITransaction_DL
    {
        private readonly ConnectionStrings _dbConnections;
        private readonly ILogger _logger;
        public Transaction_DL(
            IOptions<ConnectionStrings> dbConnections,
            ILogger logger)
        {
            _dbConnections = dbConnections.Value;
            _logger = logger;
        }

        /// <summary>
        /// Save Transaction
        /// </summary>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task SaveTransactionAsync(DBTransferTransaction transaction)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@AccountId", transaction.AccountId);
                parameters.Add("@PaymentTypeId", (int)transaction.PaymentTypeId); //app
                parameters.Add("@PaymentRef", transaction.PaymentRef);
                parameters.Add("@StatusId", transaction.StatusId);
                parameters.Add("@NowtelRef", transaction.NowtelRef);
                parameters.Add("@ClientCurrency", transaction.ClientCurrecny);
                parameters.Add("@ReceiverCurrency", transaction.ReceiverCurrecny);
                parameters.Add("@Product", transaction.Product);
                parameters.Add("@ItemPrice", transaction.ItemPrice);
                parameters.Add("@TotalPrice", transaction.TotalPrice);
                parameters.Add("@FromMsisdn", transaction.FromMsisdn);
                parameters.Add("@ToMsisdn", transaction.ToMsisdn);
                parameters.Add("@OperatorCountryName", transaction.OperatorCountryName);
                parameters.Add("@CountryCode", transaction.CountryCode);
                parameters.Add("@OperatorName", transaction.OperatorName);
                parameters.Add("@OperatorLogoUrl", transaction.OperatorLogoUrl);
                parameters.Add("@TransferRef", transaction.TransferRef);
                parameters.Add("@PaymentErrorMsg", transaction.PaymentErrorMsg);
                parameters.Add("@TransferErrorMsg", transaction.TransferErrorMsg);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    await dbConnection.ExecuteAsync("tha_app_save_itopup_transactions",
                    parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Transaction_DL, Method: SaveTransactionAsync, " + ex);
            }
        }
    }
}
