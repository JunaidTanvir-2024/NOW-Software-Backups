using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class UserDetail : IBaseEntity<long>
{
    public long Id { get; set; }
    public string? FullName { get; set; }
    public string? ProfilePhoto { get; set; }
    public long UserId { get; set; }
    public User User { get; set; } = null!;
    public long CountryId { get; set; }
    public Country Country { get; set; } = null!;
}
