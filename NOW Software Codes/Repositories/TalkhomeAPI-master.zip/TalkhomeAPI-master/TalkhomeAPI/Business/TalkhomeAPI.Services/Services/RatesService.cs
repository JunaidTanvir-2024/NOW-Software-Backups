﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Services.Interfaces;

namespace TalkhomeAPI.Services.Services
{
    public class RatesService : IRatesService
    {
        private readonly IRatesRepository _ratesRepository;
        private readonly RatesConfig _ratesConfig;

        public RatesService(IRatesRepository ratesRepository, IOptions<RatesConfig> ratesConfig)
        {
            _ratesRepository = ratesRepository;
            _ratesConfig = ratesConfig.Value;
        }
        public async Task<GenericApiResponse<IList<Rates>>> GetRates(string IsoCode)
        {
            var RatesResponse = await _ratesRepository.GetRates(IsoCode);
            if (RatesResponse != null)
            {
                var rates = RatesResponse.ToList();

                foreach (var item in rates)
                {
                    if (!string.IsNullOrEmpty(item.ISO2Code))
                    {
                        if (_ratesConfig.UpdatedCountryCodes.Any(x => x.Key.Equals(item.ISO2Code.ToUpper())))
                        {
                            item.ISO2Code = _ratesConfig.UpdatedCountryCodes.Where(
                                                x => x.Key.Equals(item.ISO2Code.ToUpper())).FirstOrDefault().Value;
                        }

                        item.Landline = item.Landline * 100;
                        item.Mobile = item.Mobile * 100;
                        item.SMS = item.SMS * 100;
                    }
                }

                return GenericApiResponse<IList<Rates>>.Success(rates, "Rates get successfully");
            }
            else
            {
                return GenericApiResponse<IList<Rates>>.Failure(null,
                                    "Payment service is not responding", ApiStatusCodes.RatesNotFound);
            }
        }
    }
}
