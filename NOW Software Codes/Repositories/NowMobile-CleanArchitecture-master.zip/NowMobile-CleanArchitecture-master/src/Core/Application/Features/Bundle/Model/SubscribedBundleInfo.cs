﻿namespace Application.Features.Bundle.Model;

public class SubscribedBundleInfo
{
    public decimal Price { get; set; }

    public string BrandedName { get; set; } = default!;
    public string PlanName { get; set; } = default!;

    public long GprsDataBytes { get; set; }
    public string GprsDataBytesConverted { get; set; } = default!;
    public long RemainingGprsDataBytes { get; set; }
    public string RemainingGprsDataBytesConverted { get; set; } = default!;
    [JsonIgnore]
    public string RemainingGprsDataBytesConvertedWithoutUnit { get; set; } = default!;
    public string GprsDataUnit { get; set; } = default!;

    public string Minutes { get; set; } = default!;
    public string RemainingMinutes { get; set; } = default!;

    public string Texts { get; set; } = default!;
    public string RemainingTexts { get; set; } = default!;

    public bool InternationalMinutesOrSms { get; set; }
    public bool MinutesOrSms { get; set; }

    public int Bundleid { get; set; }
    public int NoOfDays { get; set; }
    public BundleType Type { get; set; }
    public BundleCategory Category { get; set; }

    public bool IsAutoRenew { get; set; } = false;
    public string AutoRenewPaymentMethod { get; set; } = default!;
    public string AutoRenewCardMask { get; set; }
    public bool ShowAutoRenew { get; set; }

    public bool IsAllowancewbundle { get; set; }

    public DateTime Expiry { get; set; }

    public Guid Id { get; set; }
    //public string GoodyBagColorCode { get; set; } = default!;
}
