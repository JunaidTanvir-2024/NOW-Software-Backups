using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;
namespace JM.Core.Features.User;

public abstract class GetUser
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public string Email { get; set; } = string.Empty;
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Email).NotEmpty().NotEmpty();
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public required long Id { get; set; }
        public required string Email { get; set; }
        public required string Username { get; set; }
        public string? FullName { get; set; }
        public string? ProfilePhoto { get; set; }
        public CountryInfo? Country { get; set; }
        public record CountryInfo
        {
            public long? Id { get; set; }
            public string? Name { get; set; }
            public string? IsoCode3 { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var user = await _unitOfWork.UserRepository.GetUser(x => x.NormalizedEmail!.Equals(query.Email.ToUpperInvariant()));

            if (user is not null)
            {
                return ResultWrapper.Success(new Response()
                {
                    Id = user!.Id,
                    Email = user.Email!,
                    Username = user?.UserName!,
                    FullName = user?.UserDetail?.FullName,
                    ProfilePhoto = user?.UserDetail?.ProfilePhoto,
                    Country = new Response.CountryInfo()
                    {
                        Id = user?.UserDetail?.Country?.Id,
                        IsoCode3 = user?.UserDetail?.Country?.IsoCode3,
                        Name = user?.UserDetail?.Country?.Name
                    },
                });
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
        }
    }
    #endregion
}
