namespace FH.Core.Entities;

public sealed record OperatorEntity : BaseEntity<long>
{
    public string? Name { get; set; }
    public string? Logo { get; set; }
    public string? Description { get; set; }
    public long CountryId { get; set; }
}
