﻿using CancelBundleApi.Repositories.Implementations;
using CancelBundleApi.Repositories.Interfaces;
using CancelBundleApi.Settings.Database;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CancelBundleApi.Extensions.DependencyContainers.ServicesContainers;

internal static class DbRespositoryServiceContainer
{
    internal static IServiceCollection RegisterRepositoryServices(this IServiceCollection services, IConfiguration config)
    {
        return services
            .Configure<DatabaseSettings>(config.GetSection(nameof(DatabaseSettings)))
            .AddRepositories();
    }

    private static IServiceCollection AddRepositories(this IServiceCollection services)
    {
        services.AddScoped<IServiceLoggerRepository, ServiceLoggerRepository>();
        services.AddScoped<IUnitOfWork, UnitOfWork>();
        services.AddScoped<IUserRepository, UserRepository>();
        return services;
    }
}
