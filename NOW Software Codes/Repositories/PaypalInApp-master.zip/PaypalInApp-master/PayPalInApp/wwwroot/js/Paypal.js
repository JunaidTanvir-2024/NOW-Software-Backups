/**
 * Manages all scripts for in-app Paypal top up page.
 * 
 * @author micheled
 * Created on 06 June 2017 at 11:22
 *
 */
var Paypal = (function () {
    'use strict';

    /*******************
     * Private methods *
     *******************/
    /**
     * Shows the loading spinner <div>
     * 
     */
    function showSpinner() {
        $('.loader').show();
    }

    /*************
     * UI events *
     *************/
    // Checkout form is submitted, show loading spinner to mimic Android behaviour
    $('#amountForm').submit(function () {
        showSpinner();
    });



})();
