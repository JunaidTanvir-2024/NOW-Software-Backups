﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.JwtHelpers;
using TalkhomeAPI.Services.Interfaces;
using ThmApi.Filters;

namespace TalkhomeAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountController : Controller
    {
        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;
        private readonly IAccountService _accountService;

        public AccountController(IAccountService accountService, ILogger logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
            _accountService = accountService;
        }

        [HttpPost]
        [Route("Login")]
        [BasicAuth]
        [IpAddress]
        public async Task<IActionResult> Login([FromBody]LoginRequestModel model)
        {
            try
            {
                return Ok(await _accountService.Login(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: Login, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("VerifyPin")]
        [BasicAuth]
        [IpAddress]
        public async Task<IActionResult> VerifyPin([FromBody]VerifyPinRequestModel model)
        {
            try
            {
                var response = await _accountService.VerifyPin(model);
                if (response.errorCode == 0 ||
                    response.errorCode == (int)ApiStatusCodes.MissingPersonDetails)
                {
                    response.payload.GenerateToken(_configuration);
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyPin, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("VerifyEmail")]
        [BasicAuth]
        public async Task<IActionResult> VerifyEmail([FromBody]VerifyEmailRequestModel model)
        {
            try
            {
                return Ok(await _accountService.VerifyEmail(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyEmail, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("ReSendEmailVerificationLink")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> ReSendEmailVerificationLink()
        {
            try
            {
                return Ok(await _accountService.ReSendEmailVerificationLink(User.Claims.First(i => i.Type == "msisdn").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: ReSendEmailVerificationLink, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("SignUp")]
        [BasicAuth]
        [IpAddress]
        public async Task<IActionResult> SignUp([FromBody]SignUpRequestModel model)
        {
            try
            {
                return Ok(await _accountService.SignUp(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SignUp, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("IsEmailAlreadyExists")]
        [BasicAuth]
        public async Task<IActionResult> IsEmailAlreadyExists([FromQuery]IsEmailAlreadyExistsRequestModel model)
        {
            try
            {
                return Ok(await _accountService.IsEmailAlreadyExists(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: IsEmailAlreadyExists, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("ReSendPin")]
        [BasicAuth]
        [IpAddress]
        public async Task<IActionResult> ReSendPin([FromBody]ReSendPinRequestModel model)
        {
            try
            {
                return Ok(await _accountService.ReSendPin(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: ReSendPin, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetAccountDetails")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetAccountDetails()
        {
            try
            {
                return Ok(await _accountService.GetAccountDetails(User.Claims.First(i => i.Type == "msisdn").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetAccountDetails, " +
                    $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("UpdateMissingDetails")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> UpdateMissingDetails([FromBody]UpdateMissingDetailsRequestModel model)
        {
            try
            {
                return Ok(await _accountService.UpdateMissingDetails(model, User.Claims.First(i => i.Type == "msisdn").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: UpdateMissingDetails, " +
                    $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("UpdateAccountDetails")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> UpdateAccountDetails([FromBody]UpdateAccountDetailsRequestModel model)
        {
            try
            {
                return Ok(await _accountService.UpdateAccountDetails(model, User.Claims.First(i => i.Type == "msisdn").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: UpdateAccountDetails, " +
                    $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetCallingHistory")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetCallingHistory()
        {
            try
            {
                return Ok(await _accountService.GetCallingHistory(
                                        User.Claims.First(i => i.Type == "accountId").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetCallingHistory, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetTopUpPaymentHistory")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetTopUpPaymentHistory()
        {
            try
            {
                return Ok(await _accountService.GetTopUpPaymentHistory(
                                        User.Claims.First(i => i.Type == "accountId").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetTopUpPaymentHistory, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetInternationalTopUpHistory")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetInternationalTopUpHistory()
        {
            try
            {
                return Ok(await _accountService.GetInternationalTopUpHistory(
                                        User.Claims.First(i => i.Type == "accountId").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetInternationalTopUpHistory, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetBundlesHistory")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetBundlesHistory()
        {
            try
            {
                return Ok(await _accountService.GetBundlesHistory(
                                        User.Claims.First(i => i.Type == "accountId").Value));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetBundlesHistory, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("IsMsisdnRegistered")]
        [BasicAuth]
        public async Task<IActionResult> IsMsisdnRegistered([FromQuery]IsMsisdnRegisteredRequestModel request)
        {
            try
            {
                return Ok(await _accountService.IsMsisdnRegistered(request));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: IsMsisdnRegistered, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetAccountDetailsByMsisdn")]
        [BasicAuth]
        public async Task<IActionResult> GetAccountDetailsByMsisdn([FromQuery]GetAccountDetailsByMsisdnRequestModel request)
        {
            try
            {
                return Ok(await _accountService.GetAccountDetailsByMsisdn(request));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetAccountDetailsByMsisdn, " +
                    $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
    }
}
