﻿using Infrastructure.BLL.Services.Voucherify.Models.Events.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.MetadataModels;
using Infrastructure.BLL.Services.Voucherify.Models.Promotions.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common;
using Infrastructure.DAL.Implementation;
using Models.Contracts.Request.Voucherify;
using Models.Contracts.Response;
using Models.Contracts.Response.Voucherify;
using Models.Enums;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IVoucherify_BL
    {
        Task<GenericApiResponse<VoucherifyLoyaltiesResponse>> GetLoyaltiesInfo(string customerMsisdn, string customerEmail, string description);
        Task<GenericApiResponse<GetCustomerSpecificPromotionsResult>> GetCustomerSpecificPromotionsTiers(GetCustomerSpecificPromotionsRequest request, string customerMsisdn, string userAccount,string currency);
        Task<GenericApiResponse<GetCustomerSpecificPromotionsResult>> GetCustomerSpecificPromotionsTiersV3(GetCustomerSpecificPromotionRequestV3 request, string customerMsisdn, string userAccount,string currency);
        Task<GenericApiResponse<ReferralCodeResponse>> GetReferralCode(string customerMsisdn);
        Task<GenericApiResponse<StackableDiscountResponse>> RedeemDiscount(StackableDiscountRequest request, string msisdnn, string userAccount, CustomerMetadata customerMetadata = null);
        Task<GenericApiResponse<LoyaltyPointsRedemptionResponse>> RedeemLoyaltyPoints(string userMsisdn, LoyaltyPointsRedemptionRequest request);
        Task<GenericApiResponse<ValidateDiscountResponse>> ValidateDiscount(StackableDiscountRequest request, string msisdn, string userAccount, CustomerMetadata customerMetadata = null);
        Task<GenericApiResponse<ValidateDiscountResponse>> ValidateDiscountV3(StackableDiscountRequestV3 request, string msisdn, string userAccount, CustomerMetadata customerMetadata = null);
        Task<InvokedVoucherifyEventResponse> PurchaseEvent(string msisdn, string eventName, VoucherifyEventsMetadata eventMetadata);
        Task<InvokedVoucherifyEventResponse> InvokeEvent(string msisdn, string eventName, VoucherifyEventsMetadata eventMetadata);
        Task<GenericApiResponse<ReferralCodeEligibilityResponse>> IsUserEligibleToGenerateInvitationCode(string customerMsisdn);
        Task<GenericApiResponse<ValidateReferralCodeResponse>> ValidateReferralCode(ReferralCodeValidationRequest request, string customerMsisdn, string userAccount);
        Task<bool> CreateVoucherifyNewUser(string userMsisdn);
    }
}