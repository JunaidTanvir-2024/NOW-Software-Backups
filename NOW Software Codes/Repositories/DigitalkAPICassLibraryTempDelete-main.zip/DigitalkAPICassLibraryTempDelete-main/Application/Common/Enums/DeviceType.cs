﻿namespace Application.Common.Enums;
public enum DeviceType : byte
{
    Android = 1,
    IOS = 2
}
public enum MediumType : byte
{
    Web=1,
    Android = 2,
    IOS = 3,

}