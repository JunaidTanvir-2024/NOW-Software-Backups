﻿using Application.Features.Account.History.All;
using Application.Features.Account.History.Call;
using Application.Features.Account.History.Data;
using Application.Features.Account.History.Payment;
using Application.Features.Account.History.Sms;

namespace NowMobile.Api.Controllers;

public class HistoryController : VersionedApiController
{
    [HttpGet]
    [OpenApiOperation("Get all history", "")]
    public async Task<IActionResult> AllHistory([FromQuery] AllHistoryRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpGet("Payment")]
    [OpenApiOperation("Get payment history", "")]
    public async Task<IActionResult> PaymentHistory([FromQuery] PaymentUsageHistoryRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpGet("Call")]
    [OpenApiOperation("Get calls history.", "")]
    public async Task<IActionResult> CallHistory([FromQuery] CallUsageHistoryRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpGet("Data")]
    [OpenApiOperation("Get data history.", "")]
    public async Task<IActionResult> DataHistory([FromQuery] DataUsageHistoryRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpGet("Sms")]
    [OpenApiOperation("Get sms history.", "")]
    public async Task<IActionResult> SmsHistory([FromQuery] SmsUsageHistoryRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
}