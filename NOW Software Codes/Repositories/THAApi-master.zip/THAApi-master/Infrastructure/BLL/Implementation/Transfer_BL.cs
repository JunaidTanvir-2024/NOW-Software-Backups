﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.DAL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using MimeKit;
using Models.Contracts.Request;
using Models.Contracts.Request.AppsFlyer;
using Models.Contracts.Request.FaceBook;
using Models.Contracts.Response;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
	public class Transfer_BL : ITransfer_BL
	{
		private readonly IHelper_BL helperService;
		private readonly IUserAccount_BL UserAccount_BL;
		private readonly IUserAccount_DL UserAccount_DL;
		private readonly IConfiguration Config;
		private readonly IEmailService _emailService;
		private readonly IHttpContextAccessor _httpContextAccessor;
		private const string Endpoint = "http://finance.yahoo.com/d/quotes.csv?e=.csv&f=sl1d1t1&s=";
		private const string FreeServiceSuffix = "&compact=ultra";
		//private string FreeServiceEndpoint = Config["currency_converter"].ToString(CultureInfo.InvariantCulture);        
		private readonly HashSet<string> supportedCurrencies = new HashSet<string> { "USD", "EUR", "GBP" };
		private readonly IOneSignalPush_BL PushNotificationService;
		private readonly IStringLocalizer _localizer;
		private readonly IAirShipService _airShipService;
		private readonly IAppsFlyerService _appFlyerService;
		private readonly IFaceBookService _faceBookService;
		public Transfer_BL(
			IOneSignalPush_BL pushNotificationService,
			IStringLocalizer localizer,
			IConfiguration config,
			IUserAccount_DL userAccount_DL,
			IHelper_BL helperService,
			IUserAccount_BL userAccount_BL,
			IAirShipService airShipService,
			IAppsFlyerService appflyerService,
			IFaceBookService faceBookService,
			IEmailService emailService,
			IHttpContextAccessor httpContextAccessor)
		{
			this.helperService = helperService;
			UserAccount_BL = userAccount_BL;
			UserAccount_DL = userAccount_DL;
			Config = config;
			PushNotificationService = pushNotificationService;
			_localizer = localizer;
			_airShipService = airShipService;
			_appFlyerService = appflyerService;
			_faceBookService = faceBookService;
			_emailService = emailService;
			this._httpContextAccessor = httpContextAccessor;
		}
		public async Task<GenericApiResponse<UserAccountBalance>> ExecuteBalanceTransfer(TransferBalanceTransaction transaction)
		{
			var response = new GenericApiResponse<UserAccountBalance>();
			var sourceUserAccount = await UserAccount_BL.GetUserAccountWithoutCaching(transaction.Source.Msisdn);

			DeviceType deviceType = (DeviceType)transaction.DeviceType;

			if (!SourceAccountHasEnoughCredit(sourceUserAccount, transaction.Source.Amount))
			{
				response.Message = _localizer["InsufficientBalance"];
				response.Status = "Failure";
				return response;
			}
			var destinationUserAccount = await UserAccount_BL.GetUserAccountWithoutCaching(transaction.Destination.Msisdn);

			if (!IsSourceNaServiceIDAllowed(sourceUserAccount.UserAccountDetails.Na_Service_Id))
			{
				response.Message = _localizer["BalanceTransferFailed"];
				response.Status = "Failure";
				return response;
			}

			if (!IsDestinationNaServiceIDAllowed(destinationUserAccount.UserAccountDetails.Na_Service_Id))
			{
				response.Message = _localizer["BalanceTransferFailed"];
				response.Status = "Failure";
				return response;
			}

			if (!await UserAccount_DL.ValidateTransfer(transaction.Source.Amount, sourceUserAccount.Msisdn, sourceUserAccount.AccountID, transaction.Source.Amount, destinationUserAccount.Msisdn, destinationUserAccount.AccountID))
			{
				response.Message = _localizer["BalanceTransferFailed"];
				response.Status = "Failure";
				return response;
			}

			var success = await ProcessBalanceTransfer(transaction, sourceUserAccount, destinationUserAccount);

			response.Payload = await UserAccount_DL.GetUserAccountBalanceAsync(transaction.Source.Msisdn);

			//Now store balance transfer transactions in a new table, for tracking over time.

			if (success)
			{
				var userProfile = UserAccount_BL.GetUserProfile(transaction.Source.Msisdn);
				try
				{
					if (userProfile.Result?.Payload?.email != null)
					{
						var builder = new BodyBuilder();
						using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\inapp-transfer-reciept.html").Replace("~\\", ""))))
						{
							builder.HtmlBody = SourceReader.ReadToEnd();
						}


						string messageBody = builder.HtmlBody
							.Replace("%TIMESTAMP%", DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"))
							.Replace("%TRANSFERTO%", transaction.Destination.Msisdn)
							.Replace("%FIRST_NAME%", transaction.Destination.Name)
							.Replace("%TRANSFERTOAMOUNT%", helperService.ToMonetaryUnit(transaction.Source.Amount, transaction.Source.Currency))
							.Replace("%REMACCBAL%", helperService.ToMonetaryUnit(response.Payload.Balance, response.Payload.Currency))
							.Replace("%EMAIL%", userProfile.Result?.Payload.email);

						await _emailService.SendEmail(userProfile.Result?.Payload?.email, messageBody, true, "In App Transfer Reciept");
					}
				}
				catch (Exception)
				{

				}
				#region Airship
				if (!_httpContextAccessor.HttpContext.AirshipEventsDisable())
				{
					await _airShipService.AddCustomEvent(
					new CustomEventsRequest()
					{
						ChannelIdentifier = CEventChannelIdentifier.named_user_id,
						ChannelIdentifierValue = sourceUserAccount.Msisdn,
						CustomEventName = "inapp_transfer"
					});

					await _airShipService.AddCustomEvent(
						new CustomEventsRequest()
						{
							ChannelIdentifier = CEventChannelIdentifier.named_user_id,
							ChannelIdentifierValue = sourceUserAccount.Msisdn,
							Value = Convert.ToDouble(transaction.Source.Amount, CultureInfo.InvariantCulture),
							CustomEventName = "inapp_transfer_app"
						});
				}
				await _airShipService.AddCustomEvent(
					new CustomEventsRequest()
					{
						ChannelIdentifier = CEventChannelIdentifier.named_user_id,
						ChannelIdentifierValue = destinationUserAccount.Msisdn,
						Value = Convert.ToDouble(transaction.Source.Amount, CultureInfo.InvariantCulture),
						CustomEventName = "inapp_transfer_received"
					});
				#endregion


				#region AppsFlyer
				await _appFlyerService.CreateCustomEvent(
					new List<CreateEventRequestModel>
					{
						new CreateEventRequestModel
						{
							appsflyer_id= transaction.AppsFlyerId,
							deviceType= deviceType,
							eventName= "inapp_transfer_app",
							eventRevenue= Convert.ToDecimal(transaction.Source.Amount, CultureInfo.InvariantCulture),
							ip= ""
						}
					});

				//await _appFlyerService.CreateCustomEvent(
				//    new List<CreateEventRequestModel>
				//    {
				//        new CreateEventRequestModel
				//        {
				//            appsflyer_id= transaction.AppsFlyerId,
				//            deviceType= transaction.DeviceType,
				//            eventName= "inapp_transfer_received",
				//            eventRevenue= Convert.ToDecimal(transaction.Source.Amount, CultureInfo.InvariantCulture),
				//            ip= ""
				//        }
				//    });
				#endregion

				#region FaceBook

				//await _faceBookService.CreateCustomEvent(transaction.advertiserID,
				//    new List<EventDetailsModel>()
				//    {
				//        new EventDetailsModel
				//        {
				//            _eventName = "total_purchase_app",
				//            fb_currency = "",
				//            _valueToSum = Convert.ToDecimal(transaction.Source.Amount, CultureInfo.InvariantCulture),
				//        }
				//    });

				await _faceBookService.CreateCustomEvent(transaction.advertiserID,
					new List<EventDetailsModel>()
					{
						new EventDetailsModel
						{
							_eventName = "inapp_transfer_app",
							fb_currency = "",
							_valueToSum = Convert.ToDecimal(transaction.Source.Amount, CultureInfo.InvariantCulture),
						}
					});


				#endregion

				response.Message = _localizer["BalanceTransferSuccessful"];
				response.Status = "Success";
			}
			else
			{
				response.Message = _localizer["BalanceTransferFailed"];
				response.Status = "Failure";
			}

			return response;
		}
		private async Task<bool> ProcessBalanceTransfer(TransferBalanceTransaction transaction, UserAccount sourceUserAccount, UserAccount destinationAccount)
		{

			var Transfer = await UserAccount_DL.AddRemoveCreditToBalanceTransfer(transaction, sourceUserAccount, destinationAccount);

			bool isTransfer = Transfer.Payload;

			if (isTransfer)
			{
				await NotifyReceiverOfTransfer(transaction);

				return true;
			}
			return false;
		}
		private async Task NotifyReceiverOfTransfer(TransferBalanceTransaction transaction)
		{
			var creditAmount = helperService.ToMonetaryUnit(
						transaction.Destination.Amount,
						transaction.Destination.Currency);

			var recipientNewBalance = await UserAccount_DL.GetUserAccountBalanceAsync(transaction.Destination.Msisdn);
			try
			{
				var success = await PushNotificationService.NotifyUser(
					transaction.Destination.Msisdn,
					i => _localizer["BalanceTransferReceived", transaction.Source.Msisdn, creditAmount],
					recipientNewBalance.Balance);
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.ToString());

			}
		}

		private bool IsSourceNaServiceIDAllowed(int na_service_id)
		{
			string deny_na_service_ids = Config["Deny_Balance_Transfer_Na_Service_Id_From"];
			if (deny_na_service_ids.Contains(na_service_id.ToString(CultureInfo.InvariantCulture)))
				return false;
			return true;
		}
		private bool IsDestinationNaServiceIDAllowed(int na_service_id)
		{
			string deny_na_service_ids = Config["Deny_Balance_Transfer_Na_Service_Id_To"];
			if (deny_na_service_ids.Contains(na_service_id.ToString(CultureInfo.InvariantCulture)))
				return false;
			return true;
		}
		public async Task<GenericApiResponse<TransferBalanceTransaction>> SummariseBalanceTransfer(TransferBalanceRequest request)
		{
			var response = new GenericApiResponse<TransferBalanceTransaction>();
			try
			{
				if (request.SourceMsisdn.Equals(request.DestinationMsisdn, StringComparison.InvariantCulture))
				{
					response.Message = "In-AppTransfer on own number is not allowed.";
					response.Status = "Failure";
					return response;
				}
				//Check if destination user have loged deleted request and still in pending
				var destinationMsisdnDeleteRequest = await UserAccount_DL.GetDeleteAccountLogRequest(request.DestinationMsisdn);
				if (destinationMsisdnDeleteRequest != null && destinationMsisdnDeleteRequest.AccountDeleteStatus != AccountDeleteStatus.Deleted && destinationMsisdnDeleteRequest.AccountDeleteStatus != AccountDeleteStatus.Cancelled)
				{
					response.Message = _localizer["BothAccountsMustBeTalkHomeUsers"];
					response.ErrorCode = (int)ApiStatusCodes.BothAccountsMustBeTalkHomeUsers;
					response.Status = "Failure";
					return response;
				}

				var sourceUserAccount = await UserAccount_BL.GetUserAccountWithoutCaching(request.SourceMsisdn);
				var destinationUserAccount = await UserAccount_BL.GetUserAccountWithoutCaching(request.DestinationMsisdn);
				//if (!decimal.TryParse(request.TransferAmount, out var _transferAmount) || _transferAmount > 100)
				//{
				//    response.Message = "Maximum transfer amount limit exeeds.";
				//    response.Status = "Failure";
				//    return response;
				//}

				if (sourceUserAccount != null && destinationUserAccount != null &&
					sourceUserAccount.Msisdn == request.SourceMsisdn &&
					destinationUserAccount.Msisdn == request.DestinationMsisdn)
				{
					if (MeetsMinimumSpendCriteria(request.TransferAmount) || MeetsMinimumSpendCriteria(request.TransferAmount, request.SourceMsisdn, request.DestinationMsisdn))
					{
						if (SourceAccountHasEnoughCredit(sourceUserAccount, request.TransferAmount))
						{
							var sourceCurrency = sourceUserAccount.UserAccountBalance.Currency;

							var destinationCurrency = destinationUserAccount.UserAccountBalance.Currency;

							var transaction = new TransferBalanceTransaction
							{
								Id = Guid.NewGuid().ToString(),
								Source = new TransferBalanceParty
								{
									AccountId = sourceUserAccount.AccountID,
									Msisdn = sourceUserAccount.Msisdn,
									Amount = request.TransferAmount,
									Currency = sourceCurrency,
								},
								Destination = new TransferBalanceParty
								{
									AccountId = destinationUserAccount.AccountID,
									Msisdn = destinationUserAccount.Msisdn,
									Currency = destinationCurrency,
									Name = request.DestinationName
								}
							};

							transaction = await DetermineDestinationAmountAndRate(transaction);

							var debitAmount = helperService.ToMonetaryUnit(
								transaction.Source.Amount,
								transaction.Source.Currency);

							string summaryMessage = string.Empty;

							if (decimal.Parse(transaction.Destination.Amount, CultureInfo.InvariantCulture) == 0.0m)
							{
								response.Message = _localizer["BalanceTransferFailed"];
								response.Status = "Failure";
								return response;
							}


							if (decimal.Parse(transaction.FxRate, CultureInfo.InvariantCulture) == 1.0m)
							{
								summaryMessage = _localizer["BalanceTransferSummary",
									debitAmount,
									transaction.Destination.Name ?? $"+{transaction.Destination.Msisdn}"];
							}
							else
							{
								var creditAmount = helperService.ToMonetaryUnit(
								transaction.Destination.Amount,
								transaction.Destination.Currency);

								summaryMessage = _localizer["BalanceTransferSummaryWithFxRate",
									debitAmount, creditAmount,
									transaction.Destination.Name ?? $"+{transaction.Destination.Msisdn}",
									transaction.FxRate];
							}

							response.Status = "Success";
							response.Message = summaryMessage;
							response.Payload = transaction;
						}
						else
						{
							response.Message = _localizer["NotEnoughCredit"];
							response.Status = "Failure";
						}

					}
					else
					{
						var currencySymbol = helperService.ToCurrencySymbol(sourceUserAccount.UserAccountBalance.Currency);
						response.Message = _localizer["MinimumSpendNotMet", FormattableString.Invariant($"{currencySymbol}5.00")];
						response.Status = "Failure";
					}
				}
				else
				{
					response.Message = _localizer["BothAccountsMustBeTalkHomeUsers"];
					response.ErrorCode = (int)ApiStatusCodes.BothAccountsMustBeTalkHomeUsers;
					response.Status = "Failure";
				}
			}
			catch (Exception)
			{
				response.Message = _localizer["SomethingWentWrong"];
				response.Status = "Failure";
				response.ErrorCode = (int)ApiStatusCodes.CodeException;
			}

			return response;
		}
		public bool MeetsMinimumSpendCriteria(string sourceTransferAmount)
		{
			return decimal.Parse(sourceTransferAmount, CultureInfo.InvariantCulture) >= 5.00m;
		}
		public bool MeetsMinimumSpendCriteria(string sourceTransferAmount, string sourceMSISDN, string destinationMSISDN)
		{
			return (decimal.Parse(sourceTransferAmount, CultureInfo.InvariantCulture) >= 1.00m && sourceMSISDN.StartsWith("30") && destinationMSISDN.StartsWith("30"));
		}
		private bool SourceAccountHasEnoughCredit(UserAccount sourceUserAccount, string sourceTransferAmount)
		{
			return decimal.Parse(sourceUserAccount.UserAccountBalance.Balance, CultureInfo.InvariantCulture) >= decimal.Parse(sourceTransferAmount, CultureInfo.InvariantCulture);
		}
		private async Task<TransferBalanceTransaction> DetermineDestinationAmountAndRate(TransferBalanceTransaction transaction)
		{
			decimal fxRate = 1.0m;

			var sourceTransferAmount = Convert.ToDecimal(transaction.Source.Amount, CultureInfo.InvariantCulture);

			decimal destinationTransferAmount = sourceTransferAmount;

			if (transaction.Source.Currency != transaction.Destination.Currency)
			{
				fxRate = await GetFxRate(transaction.Source.Currency, transaction.Destination.Currency);

				if (fxRate != 0)
				{
					destinationTransferAmount = sourceTransferAmount * fxRate;
					destinationTransferAmount = Math.Round(destinationTransferAmount, 2);
				}
				else
				{
					destinationTransferAmount = Math.Round(0.0m, 2);
				}
			}

			transaction.FxRate = fxRate.ToString(CultureInfo.InvariantCulture);
			transaction.Destination.Amount = destinationTransferAmount.ToString("F", CultureInfo.InvariantCulture);

			return transaction;
		}
		public async Task<decimal> GetFxRate(string fromCurrency, string toCurrency)
		{
			try
			{
				if (!supportedCurrencies.Contains(fromCurrency))
				{
					throw new ArgumentOutOfRangeException(nameof(fromCurrency),
						$"Supported currencies are: {string.Join(", ", supportedCurrencies)}");
				}

				if (!supportedCurrencies.Contains(toCurrency))
				{
					throw new ArgumentOutOfRangeException(nameof(toCurrency),
						$"Supported currencies are: {string.Join(", ", supportedCurrencies)}");
				}
				try
				{
					if (Config["currency_converter_api_on"] == "1")
					{
						var response = await DownloadFreeFxRate(fromCurrency, toCurrency);

						response = response.Replace("\"", "");
						response = response.Replace("{", "");
						response = response.Replace("}", "");

						var result = response.Split(':');
						var fxRate = Convert.ToDecimal(result[1], CultureInfo.InvariantCulture);
						return fxRate;
					}
					else
					{
						var fxRate = await UserAccount_DL.GetFxRateFromDB(fromCurrency, toCurrency);
						return Convert.ToDecimal(fxRate, CultureInfo.InvariantCulture);
					}

				}
				catch (Exception)
				{

					try
					{
						var fxRate = await UserAccount_DL.GetFxRateFromDB(fromCurrency, toCurrency);
						return Convert.ToDecimal(fxRate, CultureInfo.InvariantCulture);
					}
					catch (Exception)
					{
						return getFxRateFromConfig(fromCurrency, toCurrency);
					}

				}


			}
			catch (Exception)
			{
				return 0;

			}
		}
		private decimal getFxRateFromConfig(string fromCurrency, string toCurrency)
		{

			if (fromCurrency == "EUR" && toCurrency == "GBP")
			{
				var fxRate = Convert.ToDecimal("0.8937", CultureInfo.InvariantCulture);
				return fxRate;
			}

			if (fromCurrency == "GBP" && toCurrency == "EUR")
			{
				var fxRate = Convert.ToDecimal("1.11661", CultureInfo.InvariantCulture);
				return fxRate;
			}

			if (fromCurrency == "USD" && toCurrency == "EUR")
			{
				var fxRate = Convert.ToDecimal("0.8376", CultureInfo.InvariantCulture);
				return fxRate;
			}

			if (fromCurrency == "EUR" && toCurrency == "USD")
			{
				var fxRate = Convert.ToDecimal("1.19264", CultureInfo.InvariantCulture);
				return fxRate;
			}

			if (fromCurrency == "GBP" && toCurrency == "USD")
			{
				var fxRate = Convert.ToDecimal("1.33276", CultureInfo.InvariantCulture);
				return fxRate;
			}

			if (fromCurrency == "USD" && toCurrency == "GBP")
			{
				var fxRate = Convert.ToDecimal("0.74927", CultureInfo.InvariantCulture);
				return fxRate;
			}
			return 0;
		}

		private async Task<string> DownloadFreeFxRate(string fromCurrency, string toCurrency)
		{

			string FreeServiceEndpoint = Config["currency_converter"].ToString(CultureInfo.InvariantCulture);
			var request = WebRequest.Create($"{FreeServiceEndpoint}{fromCurrency}_{toCurrency}{FreeServiceSuffix}") as HttpWebRequest;

			if (request == null) throw new ArgumentNullException(nameof(request));

			using (var response = await request.GetResponseAsync() as HttpWebResponse)
			{
				if (response == null) return null;

				using (var stream = response.GetResponseStream())
				{
					if (stream == null) return null;

					using (var sr = new StreamReader(stream))
					{
						return await sr.ReadToEndAsync();
					}
				}
			}
		}
	}
}
