﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SMSOutReach.Web.Models
{
    public class SMSJobViewModel
    {
        
        public string Id { get; set; }

        public string UserName { get; set; }
       
        [Required]
        public string Message { get; set; }

        [Required]
        [Display(Name = "Campaign Reference")]
        public string Campaign { get; set; }

        [Required]
        public string MSISDN { get; set; }

        public string datetimepicker { get; set; }

        public bool JobIndexUpdate { get; set; }

        public List<SelectListItem> SenderProducts { get; set; }
        public List<SelectListItem> SMSCarriers { get; set; }

        [Required]
        [Display(Name = "Send From")]
        public string ProductId { get; set; }

        [Required]
        [Display(Name = "SMS Provider")]
        public string CarrierId { get; set; }

    }
}
