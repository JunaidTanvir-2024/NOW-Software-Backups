﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.ViewModels;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class Pay360GetAutoTopUpData
    {
        public string Msisdn { get; set; }
        public float ThresHold { get; set; }
        public float Topup { get; set; }
        public string Currency { get; set; }
        public bool Status { get; set; }
        public Pay360CardsData UserPay360Cards { get; set; }
    }
}
