﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Request;
using Models.DbConnections;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class NamedUser_DL : INamedUser_DL
    {

        private IDbConnectionSettings DefaultConnection;      
        private ILogger Logger;

        public NamedUser_DL(IOptions<ConnectionStrings> connectionConfig, ILogger logger)
        {

            DefaultConnection = new DbConnectionSettings(new SqlConnection(connectionConfig.Value.DefaultConnection));            
            Logger = logger;
        }

        public async Task<GenericResult<bool>> NUserChannelAssociation(NUserChannelAssocRequest request)
        {

            string logParameters = $" {JsonConvert.SerializeObject(request)} ";
            try
            {

                var parameter = new DynamicParameters();
                parameter.Add("@channel_id", request.ChannelId);
                parameter.Add("@device_type_id", (int)request.DeviceType);
                parameter.Add("@product_code", request.ProductCode);
                parameter.Add("@named_user", request.NamedUserId);
                
                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_NUserChannelAssociation", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUser_DL, Method: NUserChannelAssociation, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }

        public async Task<GenericResult<bool>> AddNUserTags(AddNUserTagsRequest request)
        {

            string logParameters = $" {JsonConvert.SerializeObject(request)} ";
            try
            {
                DataTable tblTags = new DataTable();
                tblTags.Columns.Add("tag_name", typeof(string));
                for (int i = 0; i < request.Tags.Count; i++)
                {
                    DataRow row = tblTags.NewRow();
                    row["tag_name"] = request.Tags[i];
                    tblTags.Rows.Add(row);
                }

                var parameter = new DynamicParameters();
                parameter.Add("@named_user_tag_group", request.TagGroup);
                parameter.Add("@named_user_tags", tblTags.AsTableValuedParameter("dbo.NUserTagsType"));
                parameter.Add("@product_code", request.ProductCode);
                parameter.Add("@named_user", request.NamedUser);               

                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_AddNUserTags", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUser_DL, Method: AddNUserTags, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }


    }

}

