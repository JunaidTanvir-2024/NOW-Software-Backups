﻿namespace CancelBundleApi.Common
{
    internal static class TimeConverter
    {
        public static long GetUnixTimeStamp()
        {
            // Get the current UTC time
            DateTime currentTime = DateTime.UtcNow;

            // Calculate the Unix timestamp
            long unixTimestamp = (long) (currentTime - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
            return unixTimestamp;
        }
    }
}
