namespace Application.Features.Payment.Invoice;
public class InvoiceRequest : IRequest<Result<InvoiceResponse>>
{
    public int OrderId { get; set; } = default!;
}