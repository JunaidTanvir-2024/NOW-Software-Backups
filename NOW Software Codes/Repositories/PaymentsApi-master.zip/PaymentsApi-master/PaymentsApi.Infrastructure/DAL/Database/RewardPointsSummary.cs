﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public class RewardPointsSummary
    {
        public string account { get; set; }
        public int auditId { get; set; }
        public int points { get; set; }
        public int tpoints { get; set; }
        public int pointsgiven { get; set; }
        public int amount { get; set; }
    }
}
