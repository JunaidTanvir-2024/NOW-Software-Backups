﻿
using GeoTimeZone;
using System.Collections.ObjectModel;

namespace CallingCode.Mvc.Common.Extensions;

public static class DateTimeHelpers
{
    public static DateTimeOffset GetCurrentTimeByOffset(string offset)
    {
        // Parse the offset string to get the hours and minutes
        int hoursOffset = int.Parse(offset.Substring(4, 2));
        int minutesOffset = int.Parse(offset.Substring(7, 2));

        // Create a new time span for the offset
        TimeSpan utcOffset = new TimeSpan(hours: hoursOffset, minutes: minutesOffset, seconds: 0);

        // Create a new DateTimeOffset object with the current UTC time and the specified offset
        return DateTimeOffset.UtcNow.ToOffset(utcOffset);
    }

    public static DateTime GetCurrentTimeByLatAndLong(double latitude, double longitude)
    {
        string tzid = TimeZoneLookup.GetTimeZone(latitude, longitude).Result;

        /// Get the timezone info based on the timezone ID
        TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(tzid);

        //Get the current datetime in the specified timezone
        DateTime currentDateTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, timeZoneInfo);

        return currentDateTime;
    }
    public static string FormateDate(string inputDate)
    {
        // Parse input date string to DateTime object
        DateTime date = DateTime.ParseExact(inputDate, "MM/dd/yyyy", null);

        // Format the desired date string
        return date.ToString("MMMM d, yyyy");
    }
    public static string GetTimeByTimeZone(string timeZone)
    {
        // Get the timezone info for the specified time zone
        TimeZoneInfo targetTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);

        // Get the current time in the target time zone
        DateTimeOffset targetTime = TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow, targetTimeZone);

        // Return the time in the target time zone as a string in 24-hour format
        return targetTime.ToString("h:mm:ss tt");
    }
    public static string? GetTimeZoneId(double latitude, double longitude)
    {
        // Get the UTC offset for the specified latitude and longitude
        TimeSpan utcOffset = TimeZoneInfo.Local.GetUtcOffset(DateTime.UtcNow);

        // Get the timezone ID for the given UTC offset and latitude/longitude coordinates
        ReadOnlyCollection<TimeZoneInfo> timeZones = TimeZoneInfo.GetSystemTimeZones();
        foreach (TimeZoneInfo timeZone in timeZones)
        {
            if (timeZone.GetUtcOffset(DateTime.UtcNow).Equals(utcOffset) && timeZone.IsDaylightSavingTime(DateTime.UtcNow) == TimeZoneInfo.Local.IsDaylightSavingTime(DateTime.UtcNow))
            {
                TimeZoneInfo.AdjustmentRule[] adjustmentRules = timeZone.GetAdjustmentRules();
                if (adjustmentRules.Length == 0)
                {
                    return timeZone.Id;
                }

                DateTime dateTime = DateTime.UtcNow;
                DateTime utcDateTime = dateTime.ToUniversalTime();
                DateTime convertedDateTime = TimeZoneInfo.ConvertTimeFromUtc(utcDateTime, timeZone);

                if (timeZone.IsDaylightSavingTime(convertedDateTime) == TimeZoneInfo.Local.IsDaylightSavingTime(dateTime))
                {
                    return timeZone.Id;
                }
            }
        }

        return null;
    }
    public static string GetUtcOffset(DateTime dateTime, string countryName)
    {
        // Get the time zone for the given country name
        var timeZone = TimeZoneInfo.GetSystemTimeZones()
            .FirstOrDefault(tz => tz.DisplayName.Contains(countryName));

        if (timeZone == null)
        {
            throw new ArgumentException($"No time zone found for country: {countryName}");
        }

        // Calculate the UTC/GMT offset for the given date and time in hours and minutes
        var utcOffset = timeZone.GetUtcOffset(dateTime);
        var hours = Math.Abs(utcOffset.Hours);
        var minutes = Math.Abs(utcOffset.Minutes);

        // Format the UTC/GMT offset string
        var sign = utcOffset < TimeSpan.Zero ? "-" : "+";
        var utcOffsetString = $"UTC/GMT {sign}{hours:00}:{minutes:00}";

        return utcOffsetString;
    }
}