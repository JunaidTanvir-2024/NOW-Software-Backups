﻿using MapsterMapper;
using RW.Models;
using SC.Core.Features.Products.Requests;
using SC.Core.Features.Products.Responses;
using SC.Core.Vendors.FusionHub;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SC.Core.Features.Products.Responses.GetProductResponseRapper;

namespace SC.Core.Features.Products;
internal sealed class GetSubCategoriesHandler : IRequestHandler<GetSubCategoriesRequest, IResultWrapper>
{
    private readonly IFusionHubService _fusionHubService;
    private readonly IMapper _mapper;
    public GetSubCategoriesHandler(IFusionHubService fusionHubService, IMapper mapper)
    {
        _fusionHubService = fusionHubService;
        _mapper = mapper;
    }

    public async Task<IResultWrapper> Handle(GetSubCategoriesRequest request, CancellationToken cancellationToken)
    {
        var response = await _fusionHubService.GetSubCategoriesAsync(request);
        if (response?.Payload == null)
        {
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
        }
        return ResultWrapper.Success(response);
    }
}

