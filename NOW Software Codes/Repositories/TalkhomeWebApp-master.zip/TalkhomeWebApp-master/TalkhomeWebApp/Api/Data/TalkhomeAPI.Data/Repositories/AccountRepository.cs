﻿using Dapper;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeAPI.Data.DbConnections;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Constants;
using TalkhomeAPI.Infrastructure.Common.Models;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Repositories
{

	public class AutoTopupRepository : IAutoTopupRepository
	{
		private readonly ILogger<AutoTopupRepository> _logger;
		private string _connectionString;
		public AutoTopupRepository(IOptions<ConnectionString> connectionString,
			ILogger<AutoTopupRepository> logger)
		{
			_connectionString = connectionString.Value.DigitalkDbConnection;
			this._logger = logger;
		}
		public async Task<AutoTopupDetail> Get(string msisdn)
		{
			try
			{
				DynamicParameters parameters = new DynamicParameters();
				parameters.Add("@Msisdn", msisdn);

				using var dbConnection = new SqlConnection(_connectionString);
				var result = await dbConnection.QueryFirstOrDefaultAsync<AutoTopupDetail>("THA_Api_GetCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);
				return result;
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Class: AutoTopupRepository, Method: GetCustomerAutoTopup_THA, Parameters=>  msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
				throw;
			}
		}

		public async Task<int> Set(AutoTopupDetail entity)
		{
			try
			{
				DynamicParameters parameters = new DynamicParameters();
				parameters.Add("@AutoTopupTheresholdAmount", entity.ThresHold);
				parameters.Add("@IsAutoTopup", entity.Status);
				parameters.Add("@Msisdn", entity.Msisdn);
				parameters.Add("@TopupAmount", entity.Topup);
				parameters.Add("@TopupCurrency", entity.Currency);
				parameters.Add("@PaymentMethod", entity.PaymentMethod);
				parameters.Add("@CardMaskedPAN", entity.CardMaskedPAN);
				parameters.Add("@CardInitialTransactionId", entity.CardInitialTransactionId);
				parameters.Add("@PaypalSubscriptionId", entity.PaypalSubscriptionId);
				using var dbConnection = new SqlConnection(_connectionString);
				var result = await dbConnection.ExecuteAsync("THA_Api_UpdateCustomerAutoTopup", parameters, commandType: CommandType.StoredProcedure);
				return result;
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Class: AutoTopupRepository, Method: UpdateCustomerAutoTopup_THA, Parameters=> autoTopupTheresholdAmount: {entity.ThresHold}, isAutoTopup: {entity.Status}, msisdn: {entity.Msisdn}, topupAmount: {entity.Topup}, topupCurrency: {entity.Currency}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
				throw;
			}
		}
	}
	public class AccountRepository : IAccountRepository
	{
		private readonly IDbConnectionSettings DGT_Db;
		private readonly IDbConnectionSettings THA_Db;
		private readonly IDbConnectionSettings THA_Accounts_Db;
		private readonly IDbConnectionSettings SmsServiceDbConnection;
		private readonly IDbConnectionSettings CentralisedPaymentConnection;
		private readonly ILogger<AccountRepository> _logger;
		public AccountRepository(IOptions<ConnectionString> connectionString, ILogger<AccountRepository> logger)
		{
			DGT_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigitalkDbConnection));
			THA_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppDbConnection));
			THA_Accounts_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppsAccountsDbConnection));
			SmsServiceDbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.SmsServiceDbConnection));
			CentralisedPaymentConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.CentralisedPaymentConnection));
			_logger = logger;
		}

		public async Task<bool> IsUserExist(string SipUserName)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@sipuserName", SipUserName);
			parameters.Add("@isExists", dbType: DbType.Boolean, direction: ParameterDirection.Output);
			await DGT_Db.SqlConnection.ExecuteAsync("tha_web_user_exists", parameters, commandType: CommandType.StoredProcedure);

			return parameters.Get<bool>("@isExists");
		}
		public async Task<string> GetSipUserName(string account)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@account", account);
			return await DGT_Db.SqlConnection.ExecuteScalarAsync<string>("tha_get_sipusername",parameters,commandType: CommandType.StoredProcedure);
		}
		public async Task<bool> IsNewUser(string account)
		{
			
			var parameters = new DynamicParameters();

			parameters.Add("@account", account);
			parameters.Add("@isNewUser", dbType: DbType.Boolean, direction: ParameterDirection.Output);

			await DGT_Db.SqlConnection.ExecuteAsync("thaIsNewUserByAccount", parameters, commandType: CommandType.StoredProcedure);

			var isNewUser = parameters.Get<bool>("@isNewUser");
			//If user was delete before then it will never be a new user
			return !await IsAccountDeleted(account) && isNewUser;
		}
		/// <summary>
		/// This method will check if the account is deleted
		/// </summary>
		/// <param name="msisdn"></param>
		/// <returns></returns>
		public async Task<bool> IsAccountDeleted(string account)
		{
			try
			{
				var sipUserName = await GetSipUserName(account);
				var msisdn = sipUserName.Substring(3);

				var parameters = new DynamicParameters();
				parameters.Add("@msisdn", msisdn);
				parameters.Add("@isDeleted", dbType: DbType.Boolean, direction: ParameterDirection.Output);
				await THA_Db.SqlConnection.ExecuteAsync("tha_is_account_deleted", parameters, commandType: CommandType.StoredProcedure);
				return parameters.Get<bool>("@isDeleted");
			}
			catch (Exception ex)
			{
				_logger.LogError(ex,"Class:AccountRepository, Method:IsAccountDelete");
				return false;
			}
		}
		public async Task<DBAccountInfo> GetAccountDetails(string Username, string pin)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@sipuserName", Username);
			parameters.Add("@pin", pin);

			return await DGT_Db.SqlConnection.QueryFirstOrDefaultAsync<DBAccountInfo>("tha_web_get_account_details", parameters, commandType: CommandType.StoredProcedure);
		}

		public async Task<bool> VerifyPin(string UserName, string Pin)
		{
			var parameters = new DynamicParameters();
			parameters.Add("sipuserName", UserName);
			parameters.Add("pin", Pin);
			parameters.Add("isValid", dbType: DbType.Boolean, direction: ParameterDirection.Output);

			await DGT_Db.SqlConnection.ExecuteAsync("tha_web_validate_pin", parameters, commandType: CommandType.StoredProcedure);

			return parameters.Get<bool>("isValid");
		}

		public async Task<DBResultValidateMsisdn> ValidateMsisdn(string msisdn)
		{
			var garb = new DBResultValidateMsisdn();
			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", msisdn, dbType: DbType.String);
			parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
			parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

			var result = await DGT_Db.SqlConnection.QueryAsync("tha_validate_msisdn", parameters, commandType: CommandType.StoredProcedure);
			int errorCode = parameters.Get<int>("@errorcode");
			string errorMsg = parameters.Get<string>("@errormsg");
			if (errorCode == 0) // Success
			{
				garb.error_code = errorCode;
				garb.error_msg = "Success";
			}
			else // Failure
			{
				garb.error_msg = "Bundle addition failed. " + errorMsg;
				garb.error_code = errorCode;
			}
			return garb;
		}
		public async Task<int> UpdateUser(DBUser user)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", user.msisdn);
			parameters.Add("@firstname", user.firstname);
			parameters.Add("@lastname", user.lastname);
			parameters.Add("@email", user.email);
			parameters.Add("@email_subscribed", user.email_subscribed);

			return await THA_Db.SqlConnection.ExecuteAsync("tha_web_update_user_registration", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<bool> IsFirstTopUp(string msisdn)
		{
			try
			{
				var parameter = new DynamicParameters();
				parameter.Add("@msisdn", msisdn);
				var result = await DGT_Db.SqlConnection.ExecuteScalarAsync<DateTime?>("tha_first_topup", parameter, commandType: CommandType.StoredProcedure);

				if (result == null)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			catch
			{
				return false;
			}
		}
		public async Task<int> IsBundleExists(string msisdn)
		{
			var parameters = new DynamicParameters();

			parameters.Add("@productref", msisdn);
			parameters.Add("@isExits", dbType: DbType.Int32, direction: ParameterDirection.Output);

			await DGT_Db.SqlConnection.ExecuteAsync("tha_bundle_exists ", parameters, commandType: CommandType.StoredProcedure);

			return parameters.Get<int>("@isExits");
		}
		public async Task<DBUser> GetUserByPhoneNumber(string phoneNumber)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", phoneNumber);

			return await THA_Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("tha_web_select_user_registration", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<DateTime> GetUserRegistrationDate(string accountNumber)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@account", accountNumber);

			return await THA_Accounts_Db.SqlConnection.QueryFirstOrDefaultAsync<DateTime>("tha_web_get_registration_date", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<string> GetPinByPhoneNumber(string sipUsername)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@sipuserName", sipUsername);

			return await DGT_Db.SqlConnection.QueryFirstOrDefaultAsync<string>("tha_web_get_pin_v1", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task InsertEmailVerificationToken(string phoneNumber, string token)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", phoneNumber);
			parameters.Add("@token", token);

			await THA_Db.SqlConnection.ExecuteAsync("tha_web_user_set_email_token", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<int> VerifyEmail(string token)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@token", token);
			parameters.Add("@errorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);

			await THA_Db.SqlConnection.QueryFirstOrDefaultAsync<int>("tha_web_verifyEmail", parameters, commandType: CommandType.StoredProcedure);
			return parameters.Get<int>("errorCode");
		}
		public async Task<DBUser> GetUserInfoByEmailToken(string token)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@token", token);

			return await THA_Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("tha_web_getUserInfoByEmailToken", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<DBAccountInfo> GetAccountDetailsBySipUsername(string sipUsername)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@sipuserName", sipUsername);

			return await DGT_Db.SqlConnection.QueryFirstOrDefaultAsync<DBAccountInfo>("tha_web_get_account_details_by_sipUsername", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<DBResultValidateMsisdn> VoucherRecharge(string pin, string account)
		{
			var garb = new DBResultValidateMsisdn();
			var parameters = new DynamicParameters();
			parameters.Add("@pin ", pin);
			parameters.Add("@account", account);
			parameters.Add("@card_credit", dbType: DbType.Decimal, direction: ParameterDirection.Output);
			parameters.Add("@voucher_id", dbType: DbType.Int32, direction: ParameterDirection.Output);
			parameters.Add("@voucher_currency", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
			parameters.Add("@result_status", dbType: DbType.Int32, direction: ParameterDirection.Output);
			parameters.Add("@result_message", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);
			await DGT_Db.SqlConnection.ExecuteAsync("tha_web_vchApplyVoucher", parameters, commandType: CommandType.StoredProcedure);
			int errorCode = parameters.Get<int>("@result_status");
			string errorMsg = parameters.Get<string>("@result_message");
			if (errorCode == 0) // Success
			{
				garb.card_credit = parameters.Get<decimal?>("@card_credit");
				garb.voucher_id = parameters.Get<int?>("@voucher_id");
				garb.voucher_currency = parameters.Get<string>("@voucher_currency");

				garb.error_code = errorCode;
				garb.error_msg = "Success";
			}
			else // Failure
			{
				garb.error_msg = errorMsg;
				garb.error_code = errorCode;
			}
			return garb;
		}
		public async Task<IEnumerable<DBCallHistory>> GetCallingHistory(string accountNumber)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@account", accountNumber, dbType: DbType.String);

			return await DGT_Db.SqlConnection.QueryAsync<DBCallHistory>("tha_web_call_history", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<IEnumerable<DBTopUpPaymentHistory>> GetTopUpPaymentHistory(string accountNumber)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@account", accountNumber, dbType: DbType.String);

			return await DGT_Db.SqlConnection.QueryAsync<DBTopUpPaymentHistory>("tha_web_payment_history", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<IEnumerable<DBITopUpHistory>> GetInternationalTopUpHistory(string accountNumber)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@accountid", accountNumber, dbType: DbType.String);

			return await THA_Db.SqlConnection.QueryAsync<DBITopUpHistory>("tha_web_get_itopup_transactions", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<bool> IsEmailAlreadyExists(string email)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@Email", email);
			parameters.Add("@IsValid", dbType: DbType.Boolean, direction: ParameterDirection.Output);

			await DGT_Db.SqlConnection.ExecuteAsync("tha_web_email_alreadyExists", parameters, commandType: CommandType.StoredProcedure);

			return parameters.Get<bool>("@IsValid");
		}
		public async Task<int> UpdateAccountDetails(DBUser user)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", user.msisdn);
			parameters.Add("@firstname", user.firstname);
			parameters.Add("@lastname", user.lastname);
			parameters.Add("@email", user.email);
			parameters.Add("@email_subscribed", user.email_subscribed);
			parameters.Add("@day_of_birth", user.dayOfBirth);
			parameters.Add("@month_of_birth", user.monthOfBirth);

			return await THA_Db.SqlConnection.ExecuteAsync("tha_web_update_user_account", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<string> ValidateUser(string msisdn)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", msisdn);

			return await THA_Db.SqlConnection.QueryFirstOrDefaultAsync<string>("tha_web_validate_blocked_user", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<IEnumerable<DBBundles>> GetBundlesHistory(string accountNumber)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@account", accountNumber);

			return await DGT_Db.SqlConnection.QueryAsync<DBBundles>("tha_web_get_account_bundles_v2", parameters, commandType: CommandType.StoredProcedure);
		}
		public async Task<List<PaymentHistory>> GetEntirePaymentHistory(string msisdn, string account)
		{
			//Get InApp Tranfer + Voucher Recharge 
			var accountParm = new DynamicParameters();
			accountParm.Add("@account", account, dbType: System.Data.DbType.String);
			var accountHistoryTask = DGT_Db.SqlConnection.QueryAsync<PaymentHistory>(
				"tha_get_entire_payment_history_v2", accountParm, commandType: System.Data.CommandType.StoredProcedure);
			//Get (Bundle + Topup via Card & Paypal) + International Topup Via (via Card & Paypal & Accout Balance) 

			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", msisdn, dbType: System.Data.DbType.String);
			parameters.Add("@account", account, dbType: System.Data.DbType.String);
			var topupBundleItopupHistoryTask = THA_Db.SqlConnection.QueryMultipleAsync("tha_topup_bundle_itopup_history", parameters, commandType: CommandType.StoredProcedure);
			//Execute both calls parallel
			await Task.WhenAll(accountHistoryTask, topupBundleItopupHistoryTask);
			var accountHistory = accountHistoryTask.Result.ToList();
			accountHistory.ForEach(x => { x.Db = "account"; });

			var airTimeHistory = topupBundleItopupHistoryTask.Result.Read<PaymentHistory>().ToList();
			var bundleTopupHisotry = topupBundleItopupHistoryTask.Result.Read<PaymentHistory>().ToList();
			var bundleAccountHisotry = topupBundleItopupHistoryTask.Result.Read<PaymentHistory>().ToList();

			airTimeHistory.ForEach(x => { x.Db = "payment"; });
			bundleTopupHisotry.ForEach(x => { x.Db = "payment"; });
			bundleAccountHisotry.ForEach(x => { x.Db = "payment"; });
			accountHistory.AddRange(bundleAccountHisotry.OrderByDescending(e => e.PaymentDate));
			accountHistory.AddRange(airTimeHistory.OrderByDescending(e => e.PaymentDate));
			accountHistory.AddRange(bundleTopupHisotry.OrderByDescending(e => e.PaymentDate));

			if (accountHistory.Count > 0)
				accountHistory = accountHistory.OrderByDescending(x => x.PaymentDate).ToList();

			return accountHistory;
		}
		public async Task<bool> IsValidIpAddress(string ipAddress, string path, int requestsLimit, int requestsLimitMinutes, string requestJson)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@requestsLimit", requestsLimit);
			parameters.Add("@requestsLimitMinutes", requestsLimitMinutes);
			parameters.Add("@ipAddress", ipAddress);
			parameters.Add("@path", path);
			parameters.Add("@requestJson", requestJson);
			parameters.Add("@return", dbType: DbType.Boolean, direction: ParameterDirection.Output);

			await THA_Db.SqlConnection.ExecuteAsync("tha_web_isValidIpAddress", parameters, commandType: CommandType.StoredProcedure);

			return parameters.Get<bool>("@return");
		}
		public async Task<bool> ValidateSmsRequest(string PhoneNumber, string IpAddress, int smsLimit, SmsTypeId smsTypeId)
		{
			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", PhoneNumber);
			parameters.Add("@ipAddress", IpAddress);
			parameters.Add("@smsTypeId", (Int16)smsTypeId);
			parameters.Add("@smsLimit", (Int16)smsLimit);
			parameters.Add("@response", dbType: DbType.Boolean, direction: ParameterDirection.Output);

			await THA_Db.SqlConnection.ExecuteAsync("tha_web_check_sms_validation", parameters, commandType: CommandType.StoredProcedure);

			return parameters.Get<bool>("@response");
		}
		public async Task<int> GetSMSCount(string msisdn, string remoteIp)
		{
			var storedProcedure = "tha_sms_get_sms_count_v1";

			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", msisdn);
			parameters.Add("@ip", remoteIp);
			parameters.Add("@count", dbType: DbType.Int32, direction: ParameterDirection.Output);

			await SmsServiceDbConnection.SqlConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

			int count = parameters.Get<int>("@count");

			return count;
		}
		public async Task<string> GetEmailVerificationToken(string msisdn)
		{
			var parameters = new DynamicParameters();

			parameters.Add("@msisdn", msisdn);

			return await THA_Db.SqlConnection.ExecuteScalarAsync<string>("tha_web_get_email_verification_token", parameters, commandType: CommandType.StoredProcedure);
		}

		public async Task<GenericApiResponse<List<PromotionCountry>>> GetPromotionAlerts(string msisdn)
		{
			var storedProcedure = "tha_get_transfer_alert";
			var gr = new GenericApiResponse<List<PromotionCountry>>();
			var parameters = new DynamicParameters();
			try
			{
				parameters.Add("@msisdn", msisdn);

				var colCountry = await THA_Db.SqlConnection.QueryAsync<PromotionCountry>(storedProcedure, parameters,
						 commandType: CommandType.StoredProcedure);

				gr.status = "Success";
				gr.message = "Success";
				gr.payload = colCountry.ToList<PromotionCountry>();

				return gr;
			}
			catch (Exception)
			{
				gr.status = "Failure";
				gr.message = "Failure";
			}

			return gr;
		}
		public async Task<GenericApiResponse<bool>> SetPromotions(string msisdn, Promotion promotion)
		{
			var storedProcedure = "tha_update_transfer_alert";
			var gr = new GenericApiResponse<bool>();
			var parameters = new DynamicParameters();
			try
			{
				var country_code = string.IsNullOrEmpty(promotion.countryId.Trim()) ? 0 : int.Parse(promotion.countryId);
				parameters.Add("@msisdn", msisdn);
				parameters.Add("@country_name", promotion.countryName);
				parameters.Add("@country_code", country_code);
				parameters.Add("@altert_status", promotion.status);

				int status = await THA_Db.SqlConnection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);

				gr.status = "Success";
				gr.message = "Success";
				gr.payload = true;

				return gr;
			}
			catch (Exception)
			{
				gr.status = "Failure";
				gr.message = "Failure";
			}

			return gr;
		}
		/// <summary>
		/// This method will return the list of delete account reasons
		/// </summary>
		/// <param name="languageName"></param>
		/// <returns></returns>
		public async Task<DeleteAccountLogRequest> GetDeleteAccountLogRequest(string msisdn)
		{
			var storedProcedure = "tha_get_delete_account_request";

			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", msisdn);

			return await THA_Db.SqlConnection.QueryFirstOrDefaultAsync<DeleteAccountLogRequest>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
		}
		/// <summary>
		/// This method will return the list of delete account reasons
		/// </summary>
		/// <param name="languageName"></param>
		/// <returns></returns>
		public async Task<List<DeleteAccountReasonResponseModel>> GetDeleteAccountReasons()
		{
			string languageColName = "english_en";

			var parameters = new DynamicParameters();
			parameters.Add("@languageName", languageColName);

			var result = await THA_Db.SqlConnection.QueryAsync<DeleteAccountReasonResponseModel>("tha_get_delete_account_reasons", parameters, commandType: CommandType.StoredProcedure);
			return result.ToList();
		}
		/// <summary>
		/// Insert Delete Account Logs
		/// </summary>
		/// <param name="account"></param>
		/// <param name="msisdn"></param>
		/// <param name="message"></param>
		/// <returns></returns>
		public async Task<int> CreateDeleteAccountRequest(DeleteAccountLogRequest deleteAccountRequest)
		{

			var sp = "tha_insert_delete_account_logs_v2";
			var parameters = new DynamicParameters();
			parameters.Add("@msisdn", deleteAccountRequest.Msisdn);
			parameters.Add("@account", deleteAccountRequest.AccountId);
			parameters.Add("@message", AccountDeleteMessages.DeleteRequestMessage);

			parameters.Add("@accountActivationDate", deleteAccountRequest.AccountActivationDate);
			parameters.Add("@accountDeleteStatus", AccountDeleteStatus.Requested);
			parameters.Add("@comments", deleteAccountRequest.Comments);
			parameters.Add("@reason", deleteAccountRequest.DeleteAccountReason);
			parameters.Add("@allowedSignUpDate", deleteAccountRequest.AllowedSignUpDate);

			return await THA_Db.SqlConnection.ExecuteAsync(sp, parameters, commandType: CommandType.StoredProcedure);

		}
	}
}
