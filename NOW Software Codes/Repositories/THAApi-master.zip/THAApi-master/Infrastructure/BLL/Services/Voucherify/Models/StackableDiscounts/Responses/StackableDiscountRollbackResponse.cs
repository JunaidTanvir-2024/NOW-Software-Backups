﻿using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Responses
{
    public class StackableDiscountRollbackResponse
    {
        [JsonPropertyName("isRollback")]
        public bool IsRollback { get; set; }
    }
}
