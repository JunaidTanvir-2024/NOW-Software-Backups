﻿using System.Collections.Generic;
using TalkhomeAPI.Infrastructure.Common.Models;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public interface IHelperService
    {
        string ToMonetaryUnit(decimal amount, string currency);
        string ToMonetaryUnit(string amount, string currency);
        IList<Country> GetCountries();
    }
}