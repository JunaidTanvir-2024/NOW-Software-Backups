namespace Application.Common.Settings;

public class PortingSettings
{
    public const string SectionName = "PortingSettings";
    public static PortingSettings Bind = new PortingSettings();
    public string ApiEndPoint { get; set; } = default!;
}