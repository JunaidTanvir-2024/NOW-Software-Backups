using FluentValidation;

namespace FH.Core.Extensions;
public static class FluentValidationExtensions
{
    public static IRuleBuilderOptions<T, string> AlphabetsOnly<T, TElement>(this IRuleBuilder<T, string> ruleBuilder)
    {
        return ruleBuilder.Must((rootObject, propertyValue, context) =>
        {
            if (propertyValue == null)
            {
                return false; // Null strings are considered valid (you can change this behavior if needed).
            }

            return propertyValue.All(char.IsLetter);
        }).WithMessage("The field must contain only alphabets.");
    }



}
