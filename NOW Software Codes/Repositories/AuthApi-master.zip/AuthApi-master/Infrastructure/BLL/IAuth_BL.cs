﻿using Microsoft.AspNetCore.Http;
using Models.Contracts;
using Models.Database;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL
{
    public interface IAuth_BL
    {
        Task<GenericApiResponse<bool>> VerifyPreAuth(VerifyPreAuthRequest request);
        Task<GenericApiResponse<PreAuthResponse>> PreAuth(PreAuthRequest request, string remoteIp);
        Task<string> GetRemoteIPAddress(HttpContext context, bool allowForwarded = true);

    }
}
