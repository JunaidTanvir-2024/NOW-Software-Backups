﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Configurations
{
    public class PushConfig
    {
        public string ApiEndPoint { get; set; }
        public string ApiUserName { get; set; }
        public string ApiPassword { get; set; }
    }
}
