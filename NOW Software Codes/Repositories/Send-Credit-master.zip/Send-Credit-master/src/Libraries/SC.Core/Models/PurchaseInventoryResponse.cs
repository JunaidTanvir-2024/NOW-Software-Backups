﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SC.Core.Models;
public class PurchaseInventoryResponse
{
    [JsonPropertyName("transactionReference")]
    public required string TransactionReference { get; set; }
    [JsonPropertyName("purchasedItems")]
    public List<PurchasedItem> PurchasedItems { get; set; } = new List<PurchasedItem>();
    public sealed record PurchasedItem
    {
        [JsonPropertyName("productVendorCode")]
        public string ProductVendorCode { get; set; } = null!;
        [JsonPropertyName("productId")]
        public long ProductId { get; set; }
        [JsonPropertyName("cartReference")]
        public string CartReference { get; set; }
        [JsonPropertyName("status")]
        public string Status { get; set; }
    }
}

