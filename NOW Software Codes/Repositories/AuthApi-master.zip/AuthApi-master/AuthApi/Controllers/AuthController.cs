﻿using Infrastructure.BLL;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;
using Models.Contracts;
using Newtonsoft.Json;
using System.Net;

namespace AuthApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController : ControllerBase
    {
       
        private IAuth_BL AuthBl;
        private readonly ILogger Logger;

        public AuthController(ILogger logger, IAuth_BL authBl)
        {
            AuthBl = authBl;
            Logger = logger;
        }

        [Route("PreAuth")]
        [HttpPost]
        public async Task<IActionResult> PreAuth([FromBody] PreAuthRequest request)
        {

            string remoteIp = "";
            try
            {

                remoteIp = await AuthBl.GetRemoteIPAddress(HttpContext);                
                var response = await AuthBl.PreAuth(request, remoteIp);
                return Ok(response);
               
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: AuthController, Method: PreAuth, Parameters => remoteIp: {remoteIp}, {JsonConvert.SerializeObject(request)}, ErrorMessage: {ex.Message}");
                GenericApiResponse<PreAuthResponse> response = new GenericApiResponse<PreAuthResponse>();
                response.errorCode = 2;
                response.message = "Failure:Excep";
                response.status = "Failure";
                response.payload = new PreAuthResponse() { token_tx = "" };
                return Ok(response);
            }
        }

        [Route("VerifyPreAuth")]
        [HttpPost]
        public async Task<IActionResult> VerifyPreAuth([FromBody] VerifyPreAuthRequest request)
        {

            
            try
            {
                
                var response = await AuthBl.VerifyPreAuth(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: AuthController, Method: VerifyPreAuth, Parameters => {JsonConvert.SerializeObject(request)}, ErrorMessage: {ex.Message}");
                GenericApiResponse<bool> response = new GenericApiResponse<bool>();
                response.errorCode = 2;
                response.message = "Failure:Excep";
                response.status = "Failure";
                response.payload = false;
                return Ok(response);
            }
        }

        [HttpGet]
        [Route("/healthCheck")]
        public async Task<IActionResult> healthCheck()
        {
            return Ok();
        }

    }
}
