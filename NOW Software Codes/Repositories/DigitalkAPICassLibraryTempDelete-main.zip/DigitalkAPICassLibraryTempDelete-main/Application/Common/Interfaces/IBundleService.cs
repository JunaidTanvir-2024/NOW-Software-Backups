﻿namespace Application.Common.Interfaces;
public interface IBundleService
{
    Task<bool> UnSubscribeBundle(string subscriber_id, string packageId);
}
