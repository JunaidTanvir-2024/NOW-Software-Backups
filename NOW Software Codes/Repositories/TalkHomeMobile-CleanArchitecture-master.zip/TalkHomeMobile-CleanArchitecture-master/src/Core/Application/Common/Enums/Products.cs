namespace Application.Common.Enums;

public enum Products
{
    TalkHome = 1,
    NowPayg = 2
}
