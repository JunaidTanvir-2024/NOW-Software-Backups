﻿using ATT.Models.Contracts;
using ATT.Models.Contracts.Ding.Response;
using ATT.Models.Database;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.Ding
{
    public interface IDingPost_BL
    {
        Task<JsonOperatorProductResponse> DingFreeSwitchGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, string productCode, string productItemCode);
        Task<JsonOperatorProductResponse> DingTHAGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, bool useDbRates, int? cdsp_config_id, string productCode, string productItemCode);
        Task<JsonATTCRMOperatorProductResponse> DingATTCRMGetPhoneOperator(string account, string ToMsisdn);
        Task<object> DingFreeSwitchTopUp(ExecuteData request);
        Task<object> DingTHATopUp(ExecuteData request);
        Task<object> Com_ATT_DingTopUp(ExecuteData request, CRM_ATT_APIAccessGUID guidReferneceRecord);        
        Task<JsonPromoResponse> DingGetPromotions(string fromMSISDN);
        Task<JsonOperatorProductResponse> Com_ATT_DingGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, int? cdsp_config_id, string productCode, string productItemCode,string ProductId, int selectedCarrierNumber);
    }
}
