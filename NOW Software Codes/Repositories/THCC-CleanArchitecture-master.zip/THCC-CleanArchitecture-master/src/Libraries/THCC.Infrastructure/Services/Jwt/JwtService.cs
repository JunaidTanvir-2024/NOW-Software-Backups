using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;

using MapsterMapper;

using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

using Serilog;

using THCC.Application.Features.User.Login;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Domain.Entities;
using THCC.Infrastructure.Services.Identity;

namespace THCC.Infrastructure.Services.Jwt;

internal sealed class JwtService : IJwtService
{
    private readonly ILogger _logger;
    private readonly IUserRepository _userRepository;
    private readonly IMapper _mapper;
    private readonly JwtSettings _jwtSettings;

    public JwtService(
        IOptions<JwtSettings> jwtSettings,
        ILogger logger,
        IUserRepository userRepository,
        IMapper mapper)
    {
        _logger = logger;
        _userRepository = userRepository;
        _mapper = mapper;
        _jwtSettings = jwtSettings.Value;
    }

    #region Public

    public async Task<TokenInfoDto> GetToken(User user, string? ipAddress)
    {
        return await GenerateTokensAndUpdateUser(user);
    }

    public async Task<LoginResponse?> RefreshTokenAsync(string token, string refreshToken)
    {
        string? email = null;

        try
        {
            var userPrincipal = GetPrincipalFromExpiredToken(token);
            email = userPrincipal?.GetEmail();
        }
        catch (Exception ex)
        {
            _logger.Error(ex, ex.Message);
        }

        if (email is null)
        {
            _logger.Debug(
                "Class: JwtService, " +
                " Method: RefreshTokenAsync, " +
                " Error: Email not found from claims principal " +
                $" token: {token}"+
                $" request refresh token: {refreshToken}" );
               

            return null;
        }
        var user = await _userRepository.GetUserByEmailAsync(email);

        if (user?.RefreshToken != refreshToken)
        {
            _logger.Debug(
               "Class: JwtService, " +
               "Method: RefreshTokenAsync, " +
               " Error: Refresh token not matched " +
               $" token: {token}" +
               $" request refresh token: {refreshToken}" +
               $" user refresh token: {user?.RefreshToken}");

            return null;
        }
        if (user.RefreshTokenExpiryTime <= DateTime.UtcNow)
        {
            _logger.Debug(
               "Class: JwtService, " +
               "Method: RefreshTokenAsync, " +
               " Error: Refresh token expiry time is greater than current time. " +
               $" token: {token}" +
               $" request refresh token: {refreshToken}" +
               $" user refresh token: {user?.RefreshToken}");

            return null;
        }
        var tokenInfo = await GenerateTokensAndUpdateUser(user);
        return tokenInfo != null
            ? new LoginResponse()
            {
                User = _mapper.Map<UserDto>(user!),
                RefreshToken = tokenInfo!.RefreshToken!,
                Token = tokenInfo.Token!
            }
            : null;
    }

    public ECDsa GetSecurityKeyViaFile(string? filePath)
    {
        var eccPem = File.ReadAllText(filePath!);
        var key = ECDsa.Create();
        key.ImportFromPem(eccPem);
        return key;
    }


    #endregion

    #region Private

    private async Task<TokenInfoDto> GenerateTokensAndUpdateUser(User? appUser)
    {
        var jwtToken = GenerateJwtToken(appUser);
        var (refreshToken, refreshTokenExpiryTime) = GenerateRefreshToken();

        //Need to update referesh token with user
        await _userRepository.UpdateRefreshTokenAsync(appUser!.Email!, refreshToken, refreshTokenExpiryTime!);

        return new TokenInfoDto(jwtToken!, refreshToken);
    }
    private string? GenerateJwtToken(User? appUser)
    {
        var userClaims = GetClaims(appUser!);
        var signingKey = GetSecurityKeyViaFile(_jwtSettings.AsymmetricFiles.SecretKeyFile!);
        var securityToken = new JwtSecurityToken(
        issuer: _jwtSettings.Issuer,
        audience: _jwtSettings.Audience,
        expires: DateTime.UtcNow.AddMinutes(_jwtSettings.ExpirationTimeInMinutes),
        signingCredentials: new SigningCredentials(new ECDsaSecurityKey(signingKey), SecurityAlgorithms.EcdsaSha512),
        claims: userClaims);
        return new JwtSecurityTokenHandler().WriteToken(securityToken);
    }
    private static IEnumerable<Claim> GetClaims(User user) =>
      new List<Claim>
      {
           new(ClaimTypes.NameIdentifier, user.Id.ToString()),
           new(ClaimTypes.Email, user.Email!),
           //new(ClaimTypes.Fullname, $"{user.FirstName} {user.LastName}"),
           new(ClaimTypes.Name, user.FirstName ?? string.Empty),
           new(ClaimTypes.Surname, user.LastName ?? string.Empty)
      };
    private (string RefreshToken, DateTime RefreshTokenExpiryTime) GenerateRefreshToken()
    {
        var refreshTokenExpiryTime = DateTime.UtcNow.AddDays(_jwtSettings.RefreshTokenExpirationInDays);
        byte[] randomNumber = new byte[64];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomNumber);
        var refreshToken = Convert.ToBase64String(randomNumber);
        return (refreshToken, refreshTokenExpiryTime);
    }
    private ClaimsPrincipal GetPrincipalFromExpiredToken(string? token)
    {
        try
        {
            var tokenValidationParameters = GetTokenValidationParameters();
            var handler = new JwtSecurityTokenHandler();
            var principal = handler.ValidateToken(token!, tokenValidationParameters!, out var securityToken);

            if (securityToken is not JwtSecurityToken jwtSecurityToken || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.EcdsaSha512, StringComparison.InvariantCultureIgnoreCase))
            {
                _logger.Debug("JwtService: GetPrincipalFromExpiredToken ==> Security Algorithms not matched. ");
                throw new SecurityTokenException("Invalid token");
            }

            var signingKey = GetSecurityKeyViaFile(_jwtSettings.AsymmetricFiles.SecretKeyFile!);

            if (signingKey is not ECDsa signingECDsa)
            {
                _logger.Debug("JwtService: GetPrincipalFromExpiredToken ==> Error while obtaining signing key ");
                throw new Exception("Error while obtaining signing key");
            }

            if (!handler.CanReadToken(token))
            {
                _logger.Debug("JwtService: GetPrincipalFromExpiredToken ==> Invalid token format ");
                throw new SecurityTokenException("Invalid token format");
            }

            return principal!;
        }
        catch (Exception)
        {
            return new ClaimsPrincipal();
        }
    }
    private TokenValidationParameters GetTokenValidationParameters()
    {
        return new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = false,
            ValidateIssuerSigningKey = true,
            ValidIssuer = _jwtSettings.Issuer,
            ValidAudience = _jwtSettings.Audience,
            IssuerSigningKey = new ECDsaSecurityKey(GetSecurityKeyViaFile(_jwtSettings.AsymmetricFiles.SecretKeyFile!))
        };
    }

    #endregion
}