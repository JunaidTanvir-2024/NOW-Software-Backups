﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    
    public class UpdateUserProfileResponse
    {
        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("dobDay")]
        public int DobDay { get; set; }

        [JsonProperty("dobMonth")]
        public int DobMonth { get; set; }

        [JsonProperty("dobYear")]
        public int DobYear { get; set; }

        //[JsonProperty("canEmail")]
        //public bool CanEmail { get; set; } = true;

        //[JsonProperty("canSms")]
        //public bool CanSms { get; set; } = true;

        //[JsonProperty("canPush")]
        //public bool CanPush { get; set; } = true;

        [JsonProperty("image")]
        public string Image { get; set; }
    }
}
