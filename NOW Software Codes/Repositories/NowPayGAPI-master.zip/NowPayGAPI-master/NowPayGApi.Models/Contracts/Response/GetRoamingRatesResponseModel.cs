﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetRoamingRatesResponseModel
    {
        public RoamingRatesResponseModel RoamingRates { get; set; }
    }

    public class RoamingRatesResponseModel
    {
        public decimal VoiceRate { get; set; }
        public decimal SmsRate { get; set; }
        public decimal DataRate { get; set; }
    }


}
