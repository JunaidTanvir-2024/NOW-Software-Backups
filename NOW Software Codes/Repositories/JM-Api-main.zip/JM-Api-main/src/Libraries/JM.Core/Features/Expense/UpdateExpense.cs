using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;


namespace JM.Core.Features.Auth.Expense;

public abstract class UpdateExpense
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long Id { get; set; }
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public AppEnum.CurrencyUnit CurrencyUnit { get; set; } = AppEnum.CurrencyUnit.Dollar;
        public long CategoryId { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Id).GreaterThan(0);
            RuleFor(x => x.Amount).GreaterThan(0);
            RuleFor(x => x.CategoryId).GreaterThan(0);
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            _unitOfWork.ExpenseRepository.UpdateExpense(new Entities.Expense()
            {
                Id = query.Id,
                Description = query.Description,
                Amount = query.Amount,
                CategoryId = query.CategoryId,
            });
            _unitOfWork.SaveChanges();

            return await ValueTask.FromResult(ResultWrapper.Success(AppConstant.StatusKey.Success, AppConstant.StatusCode.Success));
        }
    }
    #endregion
}
