﻿
namespace Application.Features.Identity.SocialLogin;
public class SocialLoginResponse
{
    public string Token { get; set; } = default!;
    public string RefreshToken { get; set; } = default!;
    public long Id { get; set; }
    public string Name { get; set; } = default!;
    public string Email { get; set; } = default!;
}
