﻿
namespace THCC.Application.Features.Payment.Card.MakeCardDefault;

public class MakeCardDefaultRequest : IRequest<object>
{
    public string SecurityCode { get; set; } = default!;
    public string CardToken { get; set; } = default!;
}
public class MakeCardDefaultRequestValidator : AbstractValidator<MakeCardDefaultRequest>
{
    public MakeCardDefaultRequestValidator()
    {
        RuleFor(p => p.CardToken)
                .NotEmpty()
                .NotNull()
                .MaximumLength(100);

        RuleFor(p => p.SecurityCode)
            .NotEmpty()
            .NotNull()
            .MinimumLength(3)
            .MaximumLength(4);
    }
}
