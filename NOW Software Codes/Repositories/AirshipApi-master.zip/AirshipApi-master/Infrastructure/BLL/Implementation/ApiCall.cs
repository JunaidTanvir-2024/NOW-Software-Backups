﻿
using Infrastructure.BLL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Enums;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class ApiCall : IApiCall
    {
        private HttpClient client;
        private AirshipConfig AirshipConf;

        public ApiCall(IOptions<AirshipConfig> airshipConf)
        {            
            AirshipConf = airshipConf.Value;            
        }

        public GenericResult<Credentials> GetCredentials(string productCode)
        {
            
            try
            {

                if(productCode.ToLower() == "tha")
                {
                    Credentials creds = new Credentials() { 
                        ApiEndPoint = AirshipConf.ApiEndPoint, 
                        AppKey = AirshipConf.THA_AppKey, 
                        AppSecret = AirshipConf.THA_AppSecret, 
                        AuthType = AirshipConf.THA_AuthType, 
                        BearerToken = AirshipConf.THA_BearerToken, 
                        MasterSecret = AirshipConf.THA_MasterSecret 
                    };
                    return new GenericResult<Credentials>() { ErrorCode = 0, Status = Status.Success, Data = creds };
                }
                else if (productCode.ToLower() == "trh")
                {
                    Credentials creds = new Credentials()
                    {
                        ApiEndPoint = AirshipConf.ApiEndPoint,
                        AppKey = AirshipConf.TRH_AppKey,
                        AppSecret = AirshipConf.TRH_AppSecret,
                        AuthType = AirshipConf.TRH_AuthType,
                        BearerToken = AirshipConf.TRH_BearerToken,
                        MasterSecret = AirshipConf.TRH_MasterSecret
                    };
                    return new GenericResult<Credentials>() { ErrorCode = 0, Status = Status.Success, Data = creds };
                }
                else if (productCode.ToLower() == "thcc")
                {
                    Credentials creds = new Credentials()
                    {
                        ApiEndPoint = AirshipConf.ApiEndPoint,
                        AppKey = AirshipConf.THCC_AppKey,
                        AppSecret = AirshipConf.THCC_AppSecret,
                        AuthType = AirshipConf.THCC_AuthType,
                        BearerToken = AirshipConf.THCC_BearerToken,
                        MasterSecret = AirshipConf.THCC_MasterSecret
                    };
                    return new GenericResult<Credentials>() { ErrorCode = 0, Status = Status.Success, Data = creds };
                }
                else if (productCode.ToLower() == "thm")
                {
                    Credentials creds = new Credentials()
                    {
                        ApiEndPoint = AirshipConf.ApiEndPoint,
                        AppKey = AirshipConf.THM_AppKey,
                        AppSecret = AirshipConf.THM_AppSecret,
                        AuthType = AirshipConf.THM_AuthType,
                        BearerToken = AirshipConf.THM_BearerToken,
                        MasterSecret = AirshipConf.THM_MasterSecret
                    };
                    return new GenericResult<Credentials>() { ErrorCode = 0, Status = Status.Success, Data = creds };
                }
                else
                {
                    return new GenericResult<Credentials>() { Status = Status.Failure, ErrorMessage = $"Credentials not found for ProductCode: {productCode}", ErrorCode = 1 };
                }

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);                
                return new GenericResult<Credentials>() { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }
       

        public async Task<IRestResponse> Get(string Uri, AuthType authType, string authHeader, string contentType = "application/json", string acceptHeader = "application/vnd.urbanairship+json;version=3;", Dictionary<string, string> otherHeaders = null)
        {
           
            try
            {

                var client = new RestClient(Uri);
                //client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("Content-Type", contentType);
                request.AddHeader("Accept", acceptHeader);
                request.AddHeader("Authorization", $"{authType} {authHeader}");
                //if (!string.IsNullOrWhiteSpace(contentEncoding))
                //{
                //    request.AddHeader("Content-Transfer-Encoding", contentEncoding);
                //}      
                if (otherHeaders != null && otherHeaders.Count > 0)
                {
                    for (int i = 0; i < otherHeaders.Count; i++)
                    {
                        request.AddHeader(otherHeaders.ElementAt(i).Key, otherHeaders.ElementAt(i).Value);
                    }
                }
                IRestResponse response = await client.ExecuteAsync(request);
                return response;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
                
        public async Task<IRestResponse> Post(string Uri, string requestJson, AuthType authType, string authHeader, string contentType = "application/json", string acceptHeader = "application/vnd.urbanairship+json;version=3", Dictionary<string,string> otherHeaders = null)
        {
            try
     
            {

                var client = new RestClient(Uri);                
                //client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                request.AddHeader("Content-Type", contentType);
                request.AddHeader("Accept", acceptHeader);
                request.AddHeader("Authorization", $"{authType} {authHeader}");
                //if (!string.IsNullOrWhiteSpace(contentEncoding))
                //{
                //    request.AddHeader("Content-Transfer-Encoding", contentEncoding);
                //}
                if(otherHeaders != null && otherHeaders.Count > 0)
                {
                    for (int i = 0; i < otherHeaders.Count; i++)
                    {
                        request.AddHeader(otherHeaders.ElementAt(i).Key, otherHeaders.ElementAt(i).Value);
                    }
                }
                request.AddParameter(contentType, requestJson , ParameterType.RequestBody);
                IRestResponse response = await client.ExecuteAsync(request);                
                return response;
               
                //using (client = new HttpClient())
                //{
                //    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                //     //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authType.ToString(), authHeader);
                //    // HttpRequestMessage req = new HttpRequestMessage();
                //    // req.Headers.Add("Content-Type", contentType);
                //    //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vnd.urbanairship+json;version=3"));//ACCEPT header
                //    //// client.DefaultRequestHeaders.cont.Add("Content-Type", contentType);
                //    // //client.DefaultRequestHeaders.Add("Accept", acceptHeader);
                //    Encoding encoding = Encoding.Unicode;
                //    if (!string.IsNullOrWhiteSpace(contentEncoding))
                //    {
                //        //client.DefaultRequestHeaders.Add("Content-Transfer-Encoding", contentEncoding);
                //        encoding = Encoding.GetEncoding("gzip, deflate, br");
                //    }
                //    //encoding = Encoding.GetEncoding("gzip");
                //    var client = new HttpClient();
                //    var httpRequestMessage = new HttpRequestMessage
                //    {
                //        Method = HttpMethod.Post,
                //        RequestUri = new Uri(Uri),
                //        Headers = {
                //        { HttpRequestHeader.Authorization.ToString(), $"{authType.ToString()} {authHeader}" },
                //        //{ HttpRequestHeader.Accept.ToString(), acceptHeader }
                //        { "Accept", "application/vnd.urbanairship+json;version=3" },
                //        { HttpRequestHeader.ContentType.ToString(), "application/json" }


                //    },
                //        Content = new StringContent(requestJson, encoding, "application/json")
                //    };

                //    var response = client.SendAsync(httpRequestMessage).Result;

                //    //var stringContent = new StringContent(requestJson, encoding, contentType);
                //    //HttpResponseMessage response = await client.PostAsync(Uri, stringContent);
                //    return response;
                //}
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<IRestResponse> Put(string Uri, string requestJson, AuthType authType, string authHeader, string contentType = "application/json", string acceptHeader = "application/vnd.urbanairship+json;version=3;", Dictionary<string, string> otherHeaders = null)
        {
            try
            {
                var client = new RestClient(Uri);
                //client.Timeout = -1;
                var request = new RestRequest(Method.PUT);
                request.AddHeader("Content-Type", contentType);
                request.AddHeader("Accept", acceptHeader);
                request.AddHeader("Authorization", $"{authType} {authHeader}");
                //if (!string.IsNullOrWhiteSpace(contentEncoding))
                //{
                //    request.AddHeader("Content-Transfer-Encoding", contentEncoding);
                //}
                if (otherHeaders != null && otherHeaders.Count > 0)
                {
                    for (int i = 0; i < otherHeaders.Count; i++)
                    {
                        request.AddHeader(otherHeaders.ElementAt(i).Key, otherHeaders.ElementAt(i).Value);
                    }
                }
                request.AddParameter(contentType, requestJson, ParameterType.RequestBody);
                IRestResponse response = await client.ExecuteAsync(request);
                return response;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<HttpResponseMessage> PostUrlEncoded(string Uri, AuthType authTokenType, string authToken, List<KeyValuePair<string, string>> postDataModel)
        {
            try
            {
                using (client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                    //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", UtilityFunctions.CreateBasicHeader(pay360Config.ApiUserName, pay360Config.ApiPassword));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);
                    HttpContent content = new FormUrlEncodedContent(postDataModel);
                    content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
                    content.Headers.ContentType.CharSet = "UTF-8";
                    HttpResponseMessage resposne = await client.PostAsync(Uri, content);
                    return resposne;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}
