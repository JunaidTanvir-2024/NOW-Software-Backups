﻿namespace CancelBundleApi.Constants.Enums;
public static class JsonFiles
{
    public const string FolderName = "JsonConfigurationFiles";
    public const string AppSettings = "appsettings";
    public const string Logger = "logger";
    public const string Database = "database";
    public const string Common = "common";

}