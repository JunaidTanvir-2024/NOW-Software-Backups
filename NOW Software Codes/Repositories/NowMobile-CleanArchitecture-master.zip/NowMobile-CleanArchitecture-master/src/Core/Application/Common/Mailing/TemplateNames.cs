﻿namespace Application.Common.Mailing;

public static class TemplateNames
{
    public const string EmailConfirmation = "EmailVerificationV2";
    public const string ForgetPassword = "ForgotPasswordV2";
    public const string SignUpEmail = "EmailVerificationV2";
    public const string Topup = "TopupV2";
    public const string Bundle = "BundleV2";
    public const string SendFreeSimOrderEmail = "Order_Sim_FreeV2";
    public const string SendCreditSimOrderEmail = "Order_Sim_CreditV2";
}
