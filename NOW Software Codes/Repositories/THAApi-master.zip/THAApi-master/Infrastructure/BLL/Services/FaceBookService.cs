﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Request.AppsFlyer;
using Models.Contracts.Request.FaceBook;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;


namespace Infrastructure.BLL.Services
{
    public class FaceBookService : IFaceBookService
    {
        private readonly FaceBookConfig _faceBookConfig;
        private readonly ILogger Logger;
        private readonly IApiCall _apiCall;
        public FaceBookService(
                        IOptions<FaceBookConfig> faceBookConfig,
                        ILogger logger,
                        IApiCall apiCall)
        {
            _faceBookConfig = faceBookConfig.Value;
            Logger = logger;
            this._apiCall = apiCall;
        }

        public async Task CreateCustomEvent(string advertiserID, List<EventDetailsModel> eventDetails)
        {
            try
            {
                var requestModel = new FaceBookCreateEventRequestModel()
                {
                    _event = "CUSTOM_APP_EVENTS",
                    advertiser_tracking_enabled = 1,
                    application_tracking_enabled = 1,
                    custom_events = eventDetails,
                    advertiser_id = advertiserID,
                    accesstoken = _faceBookConfig.APPAccessToken
                };

                string URL = _faceBookConfig.ApiEndpoint + _faceBookConfig.APPID + "/activities";
                string aaa = "";
                string jsonRequest = JsonConvert.SerializeObject(requestModel);
                HttpResponseMessage httpResponse = await _apiCall.PostAsync(URL, jsonRequest);
                if (httpResponse == null)
                {
                    aaa = "httpResponse is null";

                }
                else
                {
                    if (httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        aaa = "OK";
                    }
                    else if (httpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        aaa = "BadRequest";
                    }
                    else
                    {
                        aaa = "cadcascsacsa";
                    }
                }

                string acs = aaa;

            }
            catch
            {
            }
        }

        public async Task HandleTopupEvents(string advertiserID, bool IsSuccess, bool? IsCard, decimal Amount, string currency, string origination)
        {
            try
            {
                if (!_faceBookConfig.IsActive)
                    return;
                if (String.IsNullOrEmpty(advertiserID))
                    return;

                var transactionevents = new List<EventDetailsModel>();
                string paymentMethod = GetPaymentMethod(IsCard, "Topup");
                string eventRevenenuCurrency = "";
                if (!String.IsNullOrEmpty(currency))
                {
                    eventRevenenuCurrency = currency;
                }

                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();



                if (IsSuccess)
                {
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new EventDetailsModel
                        {
                            _eventName = "total_purchase_app",
                            fb_currency = eventRevenenuCurrency,
                            _valueToSum = Amount
                        });
                    }
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = "topup_any_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = "total_transaction_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_any_{paymentMethod}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_any_{origination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_any_{origination}_{paymentMethod}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_{Amount}_{origination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_{Amount}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_{origination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                }
                else
                {
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"payfail_any_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"payfail_any_{origination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"payfail_{paymentMethod}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                }
                await this.CreateCustomEvent(advertiserID, transactionevents);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: FaceBookService, Method: HandleTopupEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleBundlePurchaseEvents(string advertiserID, string origination, string destination, BundleType BundleType, bool IsSuccess, bool? IsCard, decimal Amount, string currency)
        {
            try
            {
                if (!_faceBookConfig.IsActive)
                    return;
                if (String.IsNullOrEmpty(advertiserID))
                    return;

                var transactionevents = new List<EventDetailsModel>();
                string bundleType = GetBundleType(BundleType);
                string paymentMethod = GetPaymentMethod(IsCard);
                string eventRevenenuCurrency = "";
                if (!String.IsNullOrEmpty(currency))
                {
                    eventRevenenuCurrency = currency;
                }


                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();

                if (!string.IsNullOrEmpty(destination))
                    destination = destination.ToLower().Trim();
                if (IsSuccess)
                {
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new EventDetailsModel
                        {
                            _eventName = $"total_purchase_app",
                            fb_currency = eventRevenenuCurrency,
                            _valueToSum = Amount
                        });
                    }

                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_any_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"total_transaction_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_{paymentMethod}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_{bundleType}_any_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_dest_{destination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_orig_{origination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_dest_{bundleType}_{destination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_orig_{bundleType}_{origination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_any_{origination}_{destination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_{bundleType}_{origination}_{destination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_{bundleType}_{paymentMethod}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_{bundleType}_{origination}_{destination}_{paymentMethod}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                }
                else
                {
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"payfail_bun_any_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"payfail_bun_{paymentMethod}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                }

                await this.CreateCustomEvent(advertiserID, transactionevents);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: FaceBookService, Method: HandleBundlePurchaseEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }

        public async Task HandleIntTopupEvents(string advertiserID, string origination, string destination, bool IsSuccess, bool? IsCard, decimal Amount,bool isTransferRequest)
        {
            try
            {
                if (!_faceBookConfig.IsActive)
                    return;

                if (String.IsNullOrEmpty(advertiserID))
                    return;

                var transactionevents = new List<EventDetailsModel>();

                string paymentMethod = GetPaymentMethod(IsCard);
                string eventRevenenuCurrency = "";

                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();

                if (!string.IsNullOrEmpty(destination))
                    destination = destination.ToLower().Trim();
                if (IsSuccess)
                {
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new EventDetailsModel
                        {
                            _eventName = $"total_purchase_app",
                            fb_currency = eventRevenenuCurrency,
                            _valueToSum = Amount
                        });
                    }

                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_any_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = "total_transaction_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_{paymentMethod}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_dest_{destination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_orig_{origination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_any_{origination}_to_{destination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    if (isTransferRequest)
                    {
                        transactionevents.Add(new EventDetailsModel
                        {
                            _eventName = $"req_inttop_sent_app",
                            fb_currency = eventRevenenuCurrency,
                            _valueToSum = Amount
                        });
                    }
                }
                else
                {
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_failure_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttopfail_{paymentMethod}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttopfail_any_{origination}_app",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                }
                await this.CreateCustomEvent(advertiserID, transactionevents);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: FaceBookService, Method: HandleIntTopupEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }

        private string GetBundleType(BundleType bundleType)
        {
            if (bundleType == BundleType.Welcome)
            {
                return "welcome";
            }
            else if (bundleType == BundleType.PAYG)
            {
                return "payg";
            }
            else if (bundleType == BundleType.Monthly)
            {
                return "roll";
            }
            else
            {
                return "trial";
            }
        }
        private string GetPaymentMethod(bool? IsCard, string type = null)
        {
            if (IsCard.HasValue)
            {
                if (IsCard.Value)
                {
                    return "card";
                }
                else
                {
                    return "paypal";
                }
            }
            else
            {
                if (type == "Topup")
                {
                    return "voucher";
                }
                else
                {
                    return "balance";
                }
            }
        }
    }
}
