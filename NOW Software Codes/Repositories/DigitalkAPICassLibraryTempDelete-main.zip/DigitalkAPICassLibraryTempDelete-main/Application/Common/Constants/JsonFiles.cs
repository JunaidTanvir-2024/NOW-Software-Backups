﻿namespace Application.Common.Constants;
public static class JsonFiles
{
    public const string FolderName = "Configurations";
    public const string AppSettings = "appsettings";
    public const string Logger = "logger";
    public const string Cache = "cache";
    public const string Database = "database";   
    public const string Middleware = "middleware";
    public const string Common = "common";
   
}