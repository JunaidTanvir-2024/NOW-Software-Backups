﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class GetRoamingRatesRequestModel
    {
        [Required]
        public int FromCountryId { get; set; }
        [Required]
        public int ToCountryId { get; set; }
    }
}
