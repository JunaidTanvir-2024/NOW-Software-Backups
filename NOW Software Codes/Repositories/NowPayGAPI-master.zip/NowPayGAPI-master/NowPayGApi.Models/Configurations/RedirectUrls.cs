﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Configurations
{
    public class RedirectUrls
    {
        public string VerifyEmailRedirectUrl { get; set; }
        public string ForgotPasswordRedirectUrl { get; set; }
    }
}
