﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Models.Configurations;
using TrasnferHome.Models.Configurations;

namespace TransferHomeAPI.Helpers
{
    public class BasicAuthRequirement : IAuthorizationRequirement
    {

    }

    public class BasicAuthHandler : AuthorizationHandler<BasicAuthRequirement>
    {
        private readonly BasicAuthConfig BasicAuthConfig;

        public BasicAuthHandler(IOptions<BasicAuthConfig> basicAuthConfig)
        {
            BasicAuthConfig = basicAuthConfig.Value;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, BasicAuthRequirement requirement)
        {
            try
            {
                var authFilterCtx = (Microsoft.AspNetCore.Mvc.Filters.AuthorizationFilterContext)context.Resource;
                var httpContext = authFilterCtx.HttpContext;

                if (!httpContext.Request.Headers.ContainsKey("Authorization"))
                {
                    context.Fail();
                    return Task.FromResult(0);
                }
                else
                {
                    var basicAuthToken = httpContext.Request.Headers["Authorization"].ToString();
                    var authHeader = AuthenticationHeaderValue.Parse(basicAuthToken);
                    var credentialBytes = Convert.FromBase64String(authHeader.Parameter);
                    var credentials = Encoding.UTF8.GetString(credentialBytes).Split(':');
                    var username = credentials[0];
                    var password = credentials[1];
                    if (username == BasicAuthConfig.Username && password == BasicAuthConfig.Password)
                    {
                        context.Succeed(requirement);
                        return Task.FromResult(0);
                    }
                    else
                    {
                        context.Fail();
                        return Task.FromResult(0);
                    }
                }
            }
            catch (Exception)
            {
                context.Fail();
                return Task.FromResult(0);
            }
        }
    }
}
