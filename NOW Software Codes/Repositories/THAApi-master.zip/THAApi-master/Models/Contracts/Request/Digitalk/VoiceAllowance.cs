﻿namespace Models.Contracts.Request.Digitalk
{
	public class VoiceAllowance
	{
		public string Spend { get; set; }
		public int SpendMode { get; set; }
		public string SpendText { get; set; }
		public int Calls { get; set; }
		public int CallsMode { get; set; }
		public string CallsText { get; set; }
		public int Seconds { get; set; }
		public int SecondsMode { get; set; }
		public string SecondsText { get; set; }
	}
}