﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class NewCustomerPaymentResponseModel
    {
        public ThreeDSecureData threeDSecureData { get; set; }
        public BundlePurchaseInfo bundlePurchaseInfo { get; set; }
        public TopupInfo topupInfo { get; set; }
    }

    public class BundlePurchaseInfo
    {
        public string TransactionId { get; set; }
        public string BundleName { get; set; }
        public string BundleAmount { get; set; }
        public string Msisdn { get; set; }
        public BundleType BundleType { get; set; }
        public string Currency { get; set; }
        public bool shouldSave { get; set; }
        public string origination { get; set; }
        public string destination { get; set; }
        public bool AutoRenew { get; set; }
        public PaymentMethodTypes PaymentMethod { get; set; }
    }
    public class DefaultCardPaymentResponseModel
    {
        public BundlePurchaseInfo bundlePurchaseInfo { get; set; }
    }
}
