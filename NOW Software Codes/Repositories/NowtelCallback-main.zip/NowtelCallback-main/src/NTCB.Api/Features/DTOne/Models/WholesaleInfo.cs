﻿using System.Text.Json.Serialization;
namespace NTCB.Api.Features.DTOne.Models;

public class WholesaleInfo
{
    [JsonPropertyName("amount")]
    public float Amount { get; set; }

    [JsonPropertyName("fee")]
    public int Fee { get; set; }

    [JsonPropertyName("unit")]
    public string? Unit { get; set; }

    [JsonPropertyName("unit_type")]
    public string? UnitType { get; set; }
}
