﻿using Dapper;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using TH.Models.Configurations;
using TH.Models.Database;
using TH.Models.DbConnections;

namespace TH.Infrastructure.DAL
{
    public class THDb_DL : ITHDb_DL
    {

        private readonly ILogger Logger;
        private IDbConnectionSettings DigiTalkRepDbConnection;
        private IDbConnectionSettings DigiTalkDbConnection;
        private IDbConnectionSettings ThmConnection;
        private IDbConnectionSettings ThrccConnection;
        private IDbConnectionSettings ThccConnection;
        private CompanyConfig CompanyConf;

        public THDb_DL(ILogger logger, IOptions<ConnectionString> connectionString, IOptions<CompanyConfig> companyConfig)
        {
            Logger = logger;
            DigiTalkRepDbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigiTalkRepConnection));
            DigiTalkDbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigiTalkConnection));
            ThmConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThmConnection));
            ThrccConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThrccConnection));
            ThccConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.ThccConnection));
            CompanyConf = companyConfig.Value;
        }

        public async Task<Customer> CustomerDetails(string msisdn)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@company_id", CompanyConf.CompanyId);
                parameters.Add("@msisdn", msisdn);              
                var result = await DigiTalkDbConnection.SqlConnection.QueryFirstOrDefaultAsync<Customer>("now_res_customer_details", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: THDb_DL, Method: CustomerDetails, Parameters=> msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null;
            }
        }

        public async Task<List<Plans>> GetPlans()
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@company_id", CompanyConf.CompanyId);                
                var result = await DigiTalkDbConnection.SqlConnection.QueryAsync<Plans>("now_res_calling_packages_list", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: THDb_DL, Method: GetPlans, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null;
            }
        }

        public async Task<DbResult<string>> SetPrimarySIMState(string msisdn, int state , string username)
        {

            DbResult<string> response = new DbResult<string>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@company_id", CompanyConf.CompanyId);
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@username", username);
                parameters.Add("@state", state);               
                parameters.Add("@errorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorMsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

                var result = await DigiTalkDbConnection.SqlConnection.QueryAsync("now_res_set_primary_sim_state", parameters, commandType: CommandType.StoredProcedure);
                response.ErrorCode = parameters.Get<int>("@errorCode");
                response.ErrorMsg = parameters.Get<string>("@errorMsg");

            }
            catch (Exception ex)
            {
                response.ErrorCode = 1;
                response.ErrorMsg = "Code Exception: " + ex.Message;
                Logger.Error($"Class: THDb_DL, Method: SetPrimarySIMState, Parameters => msisdn: {msisdn}, state: {state}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<DbResult<string>> TopupVoucher(string msisdn, string pin)
        {

            DbResult<string> response = new DbResult<string>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@company_id", CompanyConf.CompanyId);
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@pin", pin);
                parameters.Add("@errorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorMsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

                var result = await DigiTalkDbConnection.SqlConnection.QueryAsync("now_res_topup_vocher", parameters, commandType: CommandType.StoredProcedure);
                response.ErrorCode = parameters.Get<int>("@errorCode");
                response.ErrorMsg = parameters.Get<string>("@errorMsg");

            }
            catch (Exception ex)
            {
                response.ErrorCode = 10;
                response.ErrorMsg = "Failed";
                Logger.Error($"Class: THDb_DL, Method: TopupVoucher, Parameters => msisdn: {msisdn}, pin: {pin}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<PurchaseResult> Purchase(string msisdn, string bundleref, decimal amount, string transactionid)
        {

            PurchaseResult response = new PurchaseResult();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@company_id", CompanyConf.CompanyId);
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@bundleref", bundleref);
                parameters.Add("@amount", amount);
                parameters.Add("@transactionid", transactionid);
                parameters.Add("@new_balance", dbType: DbType.Decimal, direction: ParameterDirection.Output);
                parameters.Add("@audit_id", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorMsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 500);

                var result = await DigiTalkDbConnection.SqlConnection.QueryAsync("now_res_purchase", parameters, commandType: CommandType.StoredProcedure);
                response.new_balance = parameters.Get<decimal>("@new_balance");
                response.audit_id = parameters.Get<int>("@audit_id");
                response.ErrorCode = parameters.Get<int>("@errorCode");
                response.ErrorMsg = parameters.Get<string>("@errorMsg");

            }
            catch (Exception ex)
            {
                response.ErrorCode = 1;
                response.ErrorMsg = "Code Exception: " + ex.Message;
                Logger.Error($"Class: THDb_DL, Method: Purchase, Parameters => msisdn: {msisdn}, bundleref: {bundleref}, amount: {amount}, transactionid: {transactionid}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        public async Task<List<AccountPlans>> GetAccountPlans(string msisdn)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@company_id", CompanyConf.CompanyId);
                parameters.Add("@msisdn", msisdn);
                var result = await DigiTalkDbConnection.SqlConnection.QueryAsync<AccountPlans>("now_res_calling_packages_msisdn", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: THDb_DL, Method: GetAccountPlans, Parameters=> msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null;
            }
        }

        public async Task<List<TopupHistory>> GetTopupHistory(string msisdn)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@company_id", CompanyConf.CompanyId);
                parameters.Add("@msisdn", msisdn);
                var result = await DigiTalkDbConnection.SqlConnection.QueryAsync<TopupHistory>("now_res_topup_history", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: THDb_DL, Method: GetTopupHistory, Parameters=> msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null;
            }
        }

        public async Task<User> Login(string userName, string password)
        {
            User response = null;
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserName", userName);
                parameters.Add("@Password", password);
                parameters.Add("@company_id", CompanyConf.CompanyId);
                response = await DigiTalkDbConnection.SqlConnection.QueryFirstOrDefaultAsync<User>("now_res_user_login", parameters, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: THDb_DL, Method: Login, Parameters--> UserName: {userName}, Password: {password},  ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

    }
}
