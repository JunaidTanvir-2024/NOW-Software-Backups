﻿using Dapper;
using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class Common_BL : ICommon_BL
    {
        private readonly IUserAccount_DL UserAccountDL;
        private readonly IAppConfig_DL AppConfig_DL;
        private readonly IConfiguration Config;
        private readonly IStringLocalizer Localizer;

        public Common_BL(
            IStringLocalizer localizer,
            IAppConfig_DL appConfig_DL,
            IConfiguration config,
            IUserAccount_DL userAccount_DL)
        {
            UserAccountDL = userAccount_DL;
            Config = config;
            AppConfig_DL = appConfig_DL;
            Localizer = localizer;
        }

        public async Task<GenericApiResponse<List<CarouselContent>>> GetAndroidCarousel(string msisdn, string version)
        {
            var response = new GenericApiResponse<List<CarouselContent>>();

            var locale = Localizer["Locale"].ToString();

            if (string.IsNullOrEmpty(locale))
                locale = "en";

            List<CarouselContent> lstCarousel = new List<CarouselContent>();

            List<CarouselContent> lstCarouselRes = new List<CarouselContent>();

            response.Message = "Failure";
            response.Status = "Failure";

            try
            {
                var thaUsername = "THA" + msisdn;

                var userAccountInformation = await UserAccountDL.GetUserAccountInfo(thaUsername);

                int na_service_id = int.Parse(userAccountInformation.Na_Service_Id);
                List<CarouselMenu> lstCarouselMenu = null;

                int relversion = int.Parse(version);

                lstCarouselMenu = await AppConfig_DL.GetCarouselMenuV1(msisdn, na_service_id, relversion);

                if (lstCarouselMenu.Count == 0)
                {

                    lstCarouselMenu = await AppConfig_DL.GetCarouselMenu(msisdn, 1);
                }


                lstCarousel = await AppConfig_DL.GetCarouselDynamic(msisdn, na_service_id, locale);

                if (lstCarousel.Count == 0)
                {

                    lstCarousel = await AppConfig_DL.GetCarouselDynamic(msisdn, 1, "en");
                }

                AirtimeConfig ac = null;

                var airTime = await AppConfig_DL.GetAirtimeConfig(msisdn);

                if (airTime != null && airTime.Count() > 0)
                {
                    ac = airTime?.FirstOrDefault<AirtimeConfig>();

                }


                var leftOuterQuery =
             from menu in lstCarouselMenu
             join content in lstCarousel on menu.service equals content.service
             select new CarouselContent { content = content.content, service = content.service, title = content.title };

                foreach (var str in leftOuterQuery)
                {
                    CarouselContent cRes = new CarouselContent();
                    var content = str;
                    cRes.content = content.content;
                    cRes.service = content.service;
                    cRes.title = content.title;
                    if (relversion < 2)
                        lstCarouselRes.Add(cRes);
                    else if (!(content.service.ToLower() == "transfer" && (ac == null || (ac != null && !ac.isDatabundle && !ac.isTopup))))
                        lstCarouselRes.Add(cRes);
                    //lstCarouselRes.Add(cRes);
                }


                response.Payload = lstCarouselRes;

                response.Status = "Success";
                response.Message = "Success";
            }
            catch (Exception)
            {

            }

            return response;
        }
        public async Task<GenericApiResponse<List<CarouselContent>>> GetIosCarousel(string msisdn, string version, string itVersion)
        {
            var response = new GenericApiResponse<List<CarouselContent>>();

            var locale = Localizer["Locale"].ToString();

            if (string.IsNullOrEmpty(locale))
                locale = "en";

            List<CarouselContent> lstCarousel = new List<CarouselContent>();

            List<CarouselContent> lstCarouselRes = new List<CarouselContent>();

            response.Message = "Failure";
            response.Status = "Failure";

            try
            {
                var thaUsername = "THA" + msisdn;

                var userAccountInformation = await UserAccountDL.GetUserAccountInfo(thaUsername);

                int na_service_id = int.Parse(userAccountInformation.Na_Service_Id);
                List<CarouselMenu> lstCarouselMenu = null;
                int relversion = int.Parse(version);

                lstCarouselMenu = await AppConfig_DL.GetCarouselMenuV1(msisdn, na_service_id, relversion, itVersion);


                if (lstCarouselMenu.Count == 0)
                {

                    lstCarouselMenu = await AppConfig_DL.GetCarouselMenu(msisdn, 1);
                }


                lstCarousel = await AppConfig_DL.GetCarouselDynamic(msisdn, na_service_id, locale);

                if (lstCarousel.Count == 0)
                {

                    lstCarousel = await AppConfig_DL.GetCarouselDynamic(msisdn, 1, "en");
                }

                AirtimeConfig ac = null;

                var airTime = await AppConfig_DL.GetAirtimeConfig(msisdn);

                if (airTime != null && airTime.Count() > 0)
                {
                    ac = airTime?.FirstOrDefault<AirtimeConfig>();

                }

                var leftOuterQuery =
           from menu in lstCarouselMenu
           join content in lstCarousel on menu.service equals content.service
           select new CarouselContent { content = content.content, service = content.service, title = content.title };
                //select menuGroup.DefaultIfEmpty(new CarouselContent() { content = "", service = menu.service, title = menu.title });
                //leftOuterQuery.AsList();

                foreach (var str in leftOuterQuery)
                {
                    CarouselContent cRes = new CarouselContent();
                    var content = str;

                    if (Config["ApiConfig:payment_itunes_only_version"] == itVersion &&
                        content.service.ToLower() == "topup")
                    {

                        cRes.content = "Top Up your app here";
                        cRes.service = content.service;
                        cRes.title = "TOP UP";

                    }
                    else
                    {

                        cRes.content = content.content;
                        cRes.service = content.service;
                        cRes.title = content.title;

                    }

                    if (relversion < 2)
                        lstCarouselRes.Add(cRes);
                    else if (!(content.service.ToLower() == "transfer" && (ac == null || (ac != null && !ac.isDatabundle && !ac.isTopup))))
                        lstCarouselRes.Add(cRes);
                }


                response.Payload = lstCarouselRes;

                response.Status = "Success";
                response.Message = "Success";
            }
            catch (Exception)
            {

            }

            return response;
        }
        public async Task<GenericApiResponse<AppConfigData>> GetAppConfig(string msisdn, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null)
        {
            var response = new GenericApiResponse<AppConfigData>();
            AppConfigData appConfigData = new AppConfigData();
            GenericApiResponse<IEnumerable<LocalAccessNumber2>> generalLA = null;
            response.Message = "Failure";
            response.Status = "Failure";
            AirtimeConfig ac = new AirtimeConfig();
            try
            {
                var lsMsg = await AppConfig_DL.getReferralMsgs(msisdn);

                if (lsMsg != null && lsMsg.Count == 2)
                {
                    appConfigData.referralMessage1 = lsMsg[0];
                    appConfigData.referralMessage2 = lsMsg[1];
                }


                generalLA = await UserAccountDL.Get2(msisdn, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);
                var airTime = await AppConfig_DL.GetAirtimeConfig(msisdn);

                if (airTime != null && airTime.Count() > 0)
                {
                    ac = airTime?.FirstOrDefault<AirtimeConfig>();

                }

                appConfigData.airtimeconfig = ac;
                appConfigData.bundlesms = await AppConfig_DL.getBundleSMS(msisdn);
                appConfigData.localaccess = generalLA.Payload;
                response.Payload = appConfigData;

                appConfigData.multiStepFO = false;
                if (int.Parse(Config["ApiConfig:multiStepFO_complete_enable"]) == 1)
                {
                    appConfigData.multiStepFO = true;
                }
                else
                {

                    IList<string> enableList = Config["ApiConfig:multiStepFO_enabled_country_codes"].Split(',').ToList<string>();

                    var result = from s in enableList
                                 where msisdn.StartsWith(s)
                                 select s;

                    if (result.Count() > 0)
                    {
                        appConfigData.multiStepFO = true;
                    }

                }

                appConfigData.canShowApp2APP = false;

                if (int.Parse(Config["ApiConfig:app_app_call_complete_enable"]) == 1)
                {
                    appConfigData.canShowApp2APP = true;
                }
                else
                {
                    IList<string> enableList = Config["ApiConfig:app_app_call_enabled_country_codes"].Split(',').ToList<string>();

                    var resultEn = from s in enableList
                                   where msisdn.StartsWith(s)
                                   select s;

                    if (resultEn.Count() > 0)
                    {
                        appConfigData.canShowApp2APP = true;
                    }

                }


                appConfigData.refreshconfig = new Refreshconfig { startupoptions = int.Parse(Config["startup_appconfig_options"]), topupbuttons = int.Parse(Config["Payment_appconfig_topupbuttons"]), scdisable = Config["ApiConfig:payment_itunes_only_version"] };
                appConfigData.isSIPCallLockedIPV6 = false;
                appConfigData.isIPV6MsgDisplay = false;
                appConfigData.A2ACallSettings = new a2aCallSettings { isTLS = true, port = "5061", url = Config["ApiConfig:app_app_call_url"] };
                var sipSettings = await UserAccountDL.GetSipConfigurations(msisdn, IsIOS, IsAndroid, IOSAllowedVersion, AndroidAllowedVersion);
                appConfigData.PaidCallSettings = new PaidCallSettings { transport = sipSettings.transport, is_somme_user = sipSettings.is_somme_user, isTLS = sipSettings.is_tls, port = sipSettings?.Port, realmIPV4 = sipSettings?.realm_ipv4, realmIPV6 = sipSettings?.realm_ipv6 };
                if (!(ac == null || (ac != null && !ac.isDatabundle && !ac.isTopup)))
                {
                    appConfigData.defaultShortcuts = new Shortcut[] {
                    new Shortcut {index=4,service="call" } ,
                    new Shortcut {index=3,service="topup" } ,
                    new Shortcut {index=2,service="transfer"} ,
                    new Shortcut {index=1,service="bundles"}
                    };
                }
                else
                {
                    appConfigData.defaultShortcuts = new Shortcut[] {
                    new Shortcut {index=4,service="call" } ,
                    new Shortcut {index=3,service="topup" } ,
                    new Shortcut {index=2,service="rates"} ,
                    new Shortcut {index=1,service="bundles"}
                    };
                }

                appConfigData.exclusionShortcuts = new string[] { "message" };
                response.Message = generalLA.Message;


                ForceUpdateMessage forceUpdate = new ForceUpdateMessage();
                IList<string> forceUpdateList = Config["ApiConfig:force_update_country_codes"].Split(',').ToList<string>();

                var forceUpdateEn = from s in forceUpdateList
                                    where msisdn.StartsWith(s)
                                    select s;

                if (forceUpdateEn.Count() > 0)
                {
                    forceUpdate.disabledMessage = new Message
                    {
                        el = "Κατεβάστε νεα έκδοση του Talk Home app.\n\nΠαρακαλώ πατήστε τον παρακάτω σύνδεσμο να αναβαθμιστεί και συνεχίσετε να χρησιμοποιείτε το app.",
                        en = "Download the new version of the Talk Home app.\n\nPlease tap the button below to upgrade and continue using the app.",
                        fr = "Download the new version of the Talk Home app.\n\nPlease tap the button below to upgrade and continue using the app.",
                        it = "Télécharger la nouvelle version de l'app Talk Home.\n\nS'il vous plait, cliqueer sur le lien pour mettre à jour et continuer à utiliser l'app."
                    };
                    forceUpdate.disabledVersionsAndroid = new string[] { "1.5.7", "1.5.8", "1.5.9", "1.5.10", "1.6.0", "1.6.1", "1.7.0", "1.7.1", "1.7.2" };
                    forceUpdate.disabledVersionsIos = new string[] { "1.5.7", "1.5.8", "1.5.9", "1.5.10", "1.6.0", "1.6.1", "1.7.0", "1.7.1", "1.7.2" };
                    appConfigData.forceUpdateMessage = forceUpdate;
                }

                response.Status = "Success";

            }
            catch (Exception)
            {

            }
            return response;
        }
    }
}
