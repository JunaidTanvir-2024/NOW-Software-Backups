using JM.Core.Utilities.DependencyResolver;

namespace JM.Infrastructure.Services.Caching;

public interface ICacheService : ResolveAs.ISingleton
{
    Task StoreInCache(string? cacheKey, string? cacheValue, string? expiryInMinutes);
    Task<string?> RetrieveFromCache(string? cacheKey);
}
