﻿using ATT.Models.Contracts;
using ATT.Models.Contracts.Common;
using ATT.Models.Contracts.Ding.Response;
using ATT.Models.Contracts.TransferTo.Response;
using ATT.Models.Database;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceProvider = ATT.Models.Database.ServiceProvider;

namespace ATT.Infrastructure.DAL
{

    public interface IAttDb_DL
    {
        Task<IEnumerable<DBOperators>> GetTransferToOperatorsByCountryId(string transferToCountryId);
        Task<IEnumerable<DBOperators>> GetTransferToOperators(string countryName);
        Task UpdateTransferToOperators(int transferToCountryID, List<OperatorsByCountry> operators);
        Task<IEnumerable<DBCountriesWithOperatorNames>> GetTransferToCountriesWithOperatorNames(string continent = null);
        Task<DBOperators> GetTransferToOperatorDetails(string countryName, string operatorName);
        Task insertAirTimeTransferTransaction(
            string Date, string SochiTelAccountID,
            decimal Amount,
            decimal BuyAmount,
            decimal OperatorAmount,
            string Currency,
            string OperatorCurrency,
            string DestinationCountry,
            string Status,
            string ErrorMessage,
            string OperaterID,
            string ProductID,
            string OperatorName,
            string NowtelTranscationRefrence,
            string TransactionRefrence, string frommsisdn, string tomsisdn, int ServiceProviderID, string message_to_recipient
        );
        Task insertAirTimeTransferTransaction(
            string Date, string SochiTelAccountID,
            decimal Amount,
            decimal BuyAmount,
            decimal OperatorAmount,
            string Currency,
            string OperatorCurrency,
            string DestinationCountry,
            string Status,
            string ErrorMessage,
            string OperaterID,
            string ProductID,
            string OperatorName,
            string TranscationRefrence,
            string TransactionRefrence,
            string frommsisdn,
            string tomsisdn,
            int ServiceProviderID,
            string message_to_recipient,
            string accessRef,
            string json_request,
            string json_response,
            string productCode,
            string productItemCode,
            string discountPercentage,
            string orignalAmount,
            double? TopUpApiTime = null
        );
        Task insertAirTimeTransferTransaction_Trh(
         string Date,
         string CurrencyAccountID,
         decimal Amount,
         decimal BuyAmount,
         decimal OperatorAmount,
         string Currency,
         string OperatorCurrency,
         string DestinationCountry,
         string Status,
         string ErrorMessage,
         string OperaterID,
         string ProductID,
         string OperatorName,
         string NowtelTranscationRefrence,
         string TransactionRefrence,
         string frommsisdn,
         string tomsisdn,
         int ServiceProviderID,
         string message_to_recipient,
         string productCode,
         string productItemCode,
         string accessRef,
                     string json_request,
            string json_response,
            double? TopUpApiTime = null
         );

        Task insertAirTimeTransferTransaction_Trh_v3(
        string Date,
        string CurrencyAccountID,
        decimal Amount,
        decimal BuyAmount,
        decimal OperatorAmount,
        string Currency,
        string OperatorCurrency,
        string DestinationCountry,
        string Status,
        string ErrorMessage,
        string OperaterID,
        string ProductID,
        string OperatorName,
        string NowtelTranscationRefrence,
        string TransactionRefrence,
        string frommsisdn,
        string tomsisdn,
        int ServiceProviderID,
        string message_to_recipient,
        string productCode,
        string productItemCode,
        string accessRef,
         string json_request,
        string json_response,
        double? GetTokenApiTime = null, double? TopUpApiTime = null
        );

        Task insertAirTimeTransferTransaction_Trh_v4(
        string Date,
        string CurrencyAccountID,
        decimal Amount,
        decimal BuyAmount,
        decimal OperatorAmount,
        string Currency,
        string OperatorCurrency,
        string DestinationCountry,
        string Status,
        string ErrorMessage,
        string OperaterID,
        string ProductID,
        string OperatorName,
        string NowtelTranscationRefrence,
        string TransactionRefrence,
        string frommsisdn,
        string tomsisdn,
        int ServiceProviderID,
        string message_to_recipient,
        string productCode,
        string productItemCode,
        string accessRef,
         string json_request,
        string json_response,
        string discountPercentage,
            string orignalAmount
        , double? GetTokenApiTime = null, double? TopUpApiTime = null
        );

        Task CRM_ATT_insertAirTimeTransferTransaction(
            string ProductId_rates,
    string Date,
    string CurrencyAccountID,
    decimal Amount,
    decimal BuyAmount,
    decimal OperatorAmount,
    string Currency,
    string OperatorCurrency,
    string DestinationCountry,
    string Status,
    string ErrorMessage,
    string OperaterID,
    string ProductID,
    string OperatorName,
    string NowtelTranscationRefrence,
    string TransactionRefrence,
    string frommsisdn,
    string tomsisdn,
    int ServiceProviderID,
    string message_to_recipient,
    string productCode,
    string productItemCode,
    string accessRef,
     string json_request,
    string json_response
    , double? GetTokenApiTime = null, double? TopUpApiTime = null, string crmamount = null
    );
        Task<DBResponse> insertTransactionGUID2(string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId,
            string sourceMSisdn, string countryCode = "", string operatorCode = "", string product = "");

        Task<DBResponse> insertTransactionGUID(string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId, string countryCode = "", string operatorCode = "");

        Task<DBResponse> insertTransactionGUID1(string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId, string sourceMSISDN, string countryCode = "", string operatorCode = "", double? GetProductApiTime = null, string productItemCode = null);


        Task<APIAccessGUID> getTransactionGUIDRecord(string guid, string product);
        Task<APIAccessGUID> getTransactionGUIDRecord_v2(string guid, string product);

        Task<IList<SochitelCustomerRate>> GetEndRates(int serviceProviderOperaorId, string account, int serviceProviderId, int originDestinationId);

        Task<int> insertaccessDetails(int accessid,
            string clientccy,
            string receiverccy,
            string product,
            string itemPriceClientccy,
            string totalPriceClientccy,
            int productId, string skuCode = null, string uatNumber = null);

        Task<int> insertaccessDetails(int accessid,
           string clientccy,
           string receiverccy,
           string product,
           string itemPriceClientccy,
           string totalPriceClientccy,
           string totalSellingPriceClientccy,
           int productId, string skuCode = null, string uatNumber = null, string crmamount = null);

        Task<int> insertaccessDetailsWithDiscount(int accessid,
           string clientccy,
           string receiverccy,
           string product,
           string itemPriceClientccy,
           string totalPriceClientccy,
           string totalSellingPriceClientccy,
           int productId, string skuCode = null, string uatNumber = null, string crmamount = null, decimal? discountPercentage = null, string orignalAmount = null);


        DingProduct GetDingProduct(string account, string receiverccy, string productExcludingTax, string product, string itemPriceClientccy, string totalPriceClientccy, string dingSkuCode);

        AttProduct GetProduct(string account, string receiverccy, string product, string itemPriceClientccy, string totalPriceClientccy);

        Task updateProductsJSONOfGUID(string GUID, string productsJSON);

        Task<OperatorMasterOperator> getOperatorMasterOperatorRecord(int ServiceProviderOperatorID);

        Task<OperatorMasterOperator> getMasterServiceProviderRecord(int ServiceProviderID, int MasterOperatorID);

        Task<ServiceProvider> getServiceProviderRecord(int NS_id, string destination_msisdn);

        Task<int> GetTransferToCountryIdByCallingCode(int callingCode);

        Task<int> AddTransferToQueue(TransferToQueue data);

        Task<DBResponse> insertTransactionGUID_Trh(string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId,
     string sourceMSisdn, string productItemCode, string countryCode = "", string operatorCode = "", string product = "", string operatorName = "", string operatorLogoUrl = "", string operatorCountryName = "", double? GetTokenApiTime = null, double? GetProviderApiTime = null, double? GetProductApiTime = null);
        Task<DBResponse> insertTransactionGUID_Tha(string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId,
    string sourceMSisdn, string productItemCode, string countryCode = "", string operatorCode = "", string product = "", string operatorName = "", string operatorLogoUrl = "", string operatorCountryName = "", double? GetTokenApiTime = null, double? GetProviderApiTime = null, double? GetProductApiTime = null);

        Task<APIAccessGUID_Trh> getTransactionGUIDRecord_Trh(string guid, string product);
        Task<CRM_ATT_APIAccessGUID> CRM_ATT_getTransactionGUIDRecord(string guid, string product);

        Task insertAirTimeTransferTransaction_Trh(string Date,
         string CurrencyAccountID,
         decimal Amount,
         decimal BuyAmount,
         decimal OperatorAmount,
         string Currency,
         string OperatorCurrency,
         string DestinationCountry,
         string Status,
         string ErrorMessage,
         string OperaterID,
         string ProductID,
         string OperatorName,
         string NowtelTranscationRefrence,
         string TransactionRefrence,
         string frommsisdn,
         string tomsisdn,
         int ServiceProviderID,
         string message_to_recipient,
         string productCode,
          string productItemCode);

        Task<bool> CheckFraudUser(string productCode, string toMsisdn, string fromMsisdn);
        Task<ATT_ValidateCustomer> ValidateNowtelCustomer(
           string frommsisdn, string tomsisdn, string nowtelreference, string product, decimal amount, string product_code, string product_item_code);
        Task<DestinationServiceProvider> GetFreeSwitchServiceProvider(string destination_msisdn);
        Task<THADestinationServiceProvider> GetTHAServiceProvider(string destination_msisdn, string source_msisdn, string productCode, string productItemCode);

        Task<CustomerChargeValueForReplacement> GetCustomerChargeValueForReplacement(string destinationMsisdn, string productItemCode);
        Task<THACustomerChargeValuesForReplacement> GetTHAMobiquityCustomerChargeValuesForReplacement(int cdsp_config_id, int servcieproviderid, int from_country_code, string operator_name);
        Task<THACustomerChargeValuesForReplacement> GetTHACustomerChargeValuesForReplacement(int cdsp_config_id, string operator_code, int servcieproviderid, int from_country_code);
        Task<List<THADestinationDingProvider>> THAGetDingDestinationsOperators(string source_msisdn);
        Task<int> UpdateFreeSwitchServiceProvider(int Id, int ServiceProviderTranCount_Current, int SecondServiceProviderTranCount_Current);
        Task<int> CRM_ATT_UpdateServiceProvider(int Id, int ServiceProviderTranCount_Current, int SecondServiceProviderTranCount_Current);
        Task<THACustomerChargeValuesForReplacement> GetReloadlyTHACustomerChargeValuesForReplacement(int cdsp_config_id, string reloadly_operator_id, int servcieproviderid, int from_country_code, string reloadly_operator_name);

        #region
        Task<Comm_ATT_DestinationServiceProvider> Com_ATT_GetServiceProvider(string fromMSISDN, string destinationMSISDN, string ProductId);
        Task<DBResponse> Com_ATT_insertTransactionGUID(string ProductId, string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId,
   string sourceMSisdn, string productItemCode, string countryCode = "", string operatorCode = "", string product = "", string operatorName = "", string operatorLogoUrl = "", string operatorCountryName = "", double? GetTokenApiTime = null, double? GetProviderApiTime = null, double? GetProductApiTime = null);

        Task<DBResponse> insertGetProductsAccessErrors(string account, string toMsisdn, int serviceProviderId,
   string sourceMSisdn, string ProductCode, string productItemCode, string ErrorMessage, double? GetTokenApiTime = null, double? GetProductApiTime = null, string DbConfiguredValues = null, string OperatorResponse = null);
        Task<COMM_ATT_CustomerChargeValuesForReplacement> Com_ATT_GetCustomerChargeValuesForReplacement(int cdsp_config_id, int selectedCarrierNumber);
        Task<ServicePRoviderThreshhold> Com_ATT_GetServiceProvidersThreshhold(int servcieproviderid);
        #endregion

        #region Discount
        Task<decimal> GetDiscountSettings(string productCode, string productItemCode, string toMsisdn, string fromMsisdn, decimal amount);
        #endregion
    }
}
