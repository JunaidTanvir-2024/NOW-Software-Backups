namespace FH.Core.Entities;
public abstract record BaseEntity<T>
{
    public T Id { get; set; } = default!;
}
