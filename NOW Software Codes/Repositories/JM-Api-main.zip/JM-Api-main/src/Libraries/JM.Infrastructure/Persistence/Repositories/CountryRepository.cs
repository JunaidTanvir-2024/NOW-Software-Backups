using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.EntityFrameworkCore;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;

internal sealed class CountryRepository(AppDbContext context, ILogger logger) : ICountryRepository
{
	private readonly AppDbContext _context = context;
	private readonly ILogger _logger = logger;

	public async Task<IEnumerable<Country>> GetCountries()
	{
		try
		{
			return await _context.Set<Country>()
			  .Select(x => new Country()
			  {
				  Id = x.Id,
				  CallingCode = x.CallingCode,
				  IsoCode2 = x.IsoCode2,
				  IsoCode3 = x.IsoCode3,
				  NumericCode = x.NumericCode,
				  Name = x.Name
			  })
			   .ToListAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(CountryRepository), nameof(GetCountries));
			return default!;
		}
	}
	public async Task AddCountryList(IEnumerable<Country> countries)
	{
		try
		{
			await _context.Set<Country>().AddRangeAsync(countries);
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(CountryRepository), nameof(GetCountries));
		}
	}
	public async Task<Country?> GetCountry(Expression<Func<Country, bool>> expression)
	{
		try
		{
			return await _context.Set<Country>()
			   .Where(expression)
			   .Select(x => new Country()
			   {
				   Id = x.Id,
				   CallingCode = x.CallingCode,
				   IsoCode2 = x.IsoCode2,
				   IsoCode3 = x.IsoCode3,
				   NumericCode = x.NumericCode,
				   Name = x.Name
			   }).FirstOrDefaultAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(CountryRepository), nameof(GetCountries));
			return default!;
		}
	}
}
