﻿using System.Text.Json.Serialization;

namespace CallingCode.Mvc.Common.Models;

public class CountryTimeZone
{
    [JsonPropertyName("year")]
    public long Year { get; set; }

    [JsonPropertyName("month")]
    public long Month { get; set; }

    [JsonPropertyName("day")]
    public long Day { get; set; }

    [JsonPropertyName("hour")]
    public long Hour { get; set; }

    [JsonPropertyName("minute")]
    public long Minute { get; set; }

    [JsonPropertyName("seconds")]
    public long Seconds { get; set; }

    [JsonPropertyName("milliSeconds")]
    public long MilliSeconds { get; set; }

    [JsonPropertyName("dateTime")]
    public DateTimeOffset DateTime { get; set; }

    [JsonPropertyName("date")]
    public string? Date { get; set; }

    [JsonPropertyName("time")]
    public string? Time { get; set; }

    [JsonPropertyName("timeZone")]
    public string? TimeZone { get; set; }

    [JsonPropertyName("dayOfWeek")]
    public string? DayOfWeek { get; set; }

    [JsonPropertyName("dstActive")]
    public bool DstActive { get; set; }
    public string? InDst { get; set; }

    public string? TimeDifferenceMessage { get; set; }
}
