﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using THCCWEB.Models.ViewModels.CheckOutView;
using THCCWEB.Utilities;

namespace THCCWEB.Extension
{
    public static class ExtendedClasses
    {
        public static void DynamicModelValidation(this CheckoutViewModel model,ModelStateDictionary state, RequestModelTypes type)
        {
            switch (type)
            {
                case RequestModelTypes.FastTopUp:
                    {

                        state.Remove("UserCard.CardNumber");
                        state.Remove("UserCard.NameOnCard");
                        state.Remove("UserCard.ExpiryYear");
                        state.Remove("UserCard.ExpiryMonth");
                        state.Remove("UserCard.SecurityCode");
                        state.Remove("BillingAddress.AddressL1");
                        state.Remove("BillingAddress.CountryCode");
                        state.Remove("PostCode");
                        state.Remove("SecurityCode");
                        state.Remove("EmailAddress");
                        state.Remove("PostCode");
                        break;
                    }
                default: break;
            }
        }
    }
}
