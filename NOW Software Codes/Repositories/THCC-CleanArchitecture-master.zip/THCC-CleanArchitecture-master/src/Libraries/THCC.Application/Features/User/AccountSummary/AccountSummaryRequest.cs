﻿namespace THCC.Application.Features.User.AccountSummary;

public class AccountSummaryRequest : IRequest<object> { }