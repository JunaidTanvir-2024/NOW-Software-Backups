﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Serilog;
using Swashbuckle.AspNetCore.Swagger;
using TH.Infrastructure.BLL;
using TH.Infrastructure.DAL;
using TH.Middleware;
using TH.Models.Configurations;

namespace TH
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton((Serilog.ILogger)new LoggerConfiguration()
             .MinimumLevel.Warning()
             .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "THApi-log-{Date}.txt"))
             .CreateLogger());

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            services.Configure<ConnectionString>(Configuration.GetSection("ConnectionStrings"));
            services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));
            services.Configure<CompanyConfig>(Configuration.GetSection("Company"));
            services.AddTransient<ITH_BL, TH_BL>();
            services.AddTransient<ITHDb_DL, THDb_DL>();

            services.AddLogging(
            builder =>
            {
                builder.AddFilter("Microsoft", LogLevel.Warning)
                       .AddFilter("System", LogLevel.Warning)
                       .AddFilter("NToastNotify", LogLevel.Warning)
                       .AddConsole();
            });

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "NowMobile API",
                    Description = "NowMobile API",
                    TermsOfService = "None",
                    Contact = new Contact() { Name = "Nowtel", Email = "hello@nowtel.co.uk", Url = "https://nowtel.com/" }
                });
            });


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {

            app.UseMiddleware<DogStatsDMiddleware>();
            
            // user Authentication middleware 
            app.UseMiddleware<AuthenticationMiddleware>();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseMvc();
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "NowMobile API");
                });
            }
            else
            {
                app.UseHsts();
                app.UseMvc();
            }

            //app.UseMvc();
            //app.UseSwagger();
            //app.UseSwaggerUI(c =>
            //{
            //    c.SwaggerEndpoint("/swagger/v1/swagger.json", "NowMobile API");
            //});
        }
    }
}
