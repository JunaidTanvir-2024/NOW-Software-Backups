﻿using Newtonsoft.Json;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using System.Collections.Generic;

namespace PaymentsApi.Models.Contracts.Pay360.Response.Api
{
    public class ApiPaymentResponse
    {
        [JsonProperty("processing")]
        public ProcessingModel Processing { get; set; }

        [JsonProperty("paymentMethod")]
        public PaymentMethodResponseModel PaymentMethod { get; set; }

        [JsonProperty("customer")]
        public CustomerResponseModel Customer { get; set; }

        [JsonProperty("outcome")]
        public OutcomeModel Outcome { get; set; }

        [JsonProperty("transaction")]
        public TransactionResponseModel Transaction { get; set; }

        [JsonProperty("financialServices")]
        public FinancialServicesResponseModel FinancialServices { get; set; }

        [JsonProperty("history")]
        public List<HistoryModel> History { get; set; }

        [JsonProperty("clientRedirect")]
        public ClientRedirectModel ClientRedirect { get; set; }

        [JsonProperty("fraudGuard")]
        public FraudGuardModel FraudGuard { get; set; }
        [JsonProperty("threeDSecure")]
        public ThreeDSecureModel ThreeDSecure {get;set;}

        [JsonProperty("basketResponse")]
        public List<BasketItemsResponse> BasketResponse { get; set; }

    }

    [JsonObject("threeDSecure")]
    public class ThreeDSecureModel
    {
        [JsonProperty("Scheme")]
        public string Scheme { get; set; }
        [JsonProperty("Status")]
        public string Status { get; set; }
        [JsonProperty("EnrolmentIndicator")]
        public string EnrolmentIndicator { get; set; }
        [JsonProperty("EnrolmentStatus")]
        public string EnrolmentStatus { get; set; }
        [JsonProperty("EnrolmentDateTime")]
        public string EnrolmentDateTime { get; set; }
        [JsonProperty("Xid")]
        public string Xid { get; set; }
        [JsonProperty("Eci")]
        public string Eci { get; set; }
        [JsonProperty("authenticationIndicator")]
        public string AuthenticationIndicator { get; set; }
        [JsonProperty("authenticationStatus")]
        public string AuthenticationStatus { get; set; }
        [JsonProperty("avv")]
        public string Avv { get; set; }

        [JsonProperty("version")]
        public string Version { get; set; }

        [JsonProperty("protocolVersion")]
        public string ProtocolVersion { get; set; }

        [JsonProperty("threeDSServerTransId")]
        public string ThreeDSServerTransId { get; set; }

        [JsonProperty("challengeRequest")]
        public string ChallengeRequest { get; set; }

        [JsonProperty("versionsAttempted")]
        public List<VersionAttempted> VersionsAttempted { get; set; }
    }

    public class VersionAttempted
    {
        [JsonProperty("version")]
        public string Version { get; set; }

        [JsonProperty("availability")]
        public string Availability { get; set; }
    }



    [JsonObject("clientRedirect")]
    public class ClientRedirectModel
    {

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("pareq")]
        public string Pareq { get; set; }

        [JsonProperty("url")]
        public string Url { get; set; }

        [JsonProperty("threeDSServerTransId")]
        public string ThreeDSServerTransId { get; set; }

    }

    [JsonObject("threeDSecureResponse")]
    public class ThreeDSecureResponse
    {
        [JsonProperty("pares")]
        public string Pares { get; set; }

    }

    [JsonObject("fraudGuard")]
    public class FraudGuardModel
    {
        [JsonProperty("score")]
        public float Score { get; set; }

        [JsonProperty("geoLocation")]
        public GeoLocationModel GeoLocation { get; set; }

        [JsonProperty("channelRisk")]
        public ChannelRiskModel ChannelRisk { get; set; }

        [JsonProperty("recentActivity")]
        public RecentActivityModel RecentActivity { get; set; }

        [JsonProperty("identityMorphing")]
        public IdentityMorphingModel IdentityMorphing { get; set; }

        

    }

    [JsonObject("geoLocation")]
    public class GeoLocationModel
    {

        [JsonProperty("ipCountry")]
        public IpCountryModel IpCountryModel { get; set; }

        [JsonProperty("ipCity")]
        public string IpCity { get; set; }

        [JsonProperty("ipRegion")]
        public string IpRegion { get; set; }

        [JsonProperty("distanceFromIpToBilling")]
        public int DistanceFromIpToBilling { get; set; }
    }

    [JsonObject("channelRisk")]
    public class ChannelRiskModel
    {
        [JsonProperty("freeEmailProvider")]
        public bool FreeEmailProvider { get; set; }

        
        [JsonProperty("openProxyRisk")]
        public float OpenProxyRisk { get; set; }

    }

    [JsonObject("recentActivity")]
    public class RecentActivityModel
    {
        [JsonProperty("last24Hours")]
        public Last24HoursModel Last24HoursModel { get; set; }
    }

    [JsonObject("last24Hours")]
    public class Last24HoursModel
    {
        [JsonProperty("attemptsViaIp")]
        public int AttemptsViaIp { get; set; }

        [JsonProperty("attemptsOnCard")]
        public int AttemptsOnCard { get; set; }
    }

    [JsonObject("identityMorphing")]
    public class IdentityMorphingModel
    {
        [JsonProperty("againstAddress")]
        public int AgainstAddress { get; set; }

        [JsonProperty("againstEmail")]
        public int AgainstEmail { get; set; }

        [JsonProperty("againstCard")]
        public int AgainstCard { get; set; }

        [JsonProperty("againstIp")]
        public int AgainstIp { get; set; }
    }


    [JsonObject("ipCountry")]
    public class IpCountryModel
    {

        [JsonProperty("country")]
        public string IpCity { get; set; }

        [JsonProperty("ipValues")]
        public string IpRegion { get; set; }

    }


    



    [JsonObject("outcome")]
    public class OutcomeModel
    {
        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("reasonCode")]
        public string ReasonCode { get; set; }

        [JsonProperty("reasonMessage")]
        public string ReasonMessage { get; set; }
    }

    [JsonObject("paymentMethod")]
    public class PaymentMethodResponseModel
    {
        [JsonProperty("registered")]
        public bool Registered { get; set; }

        [JsonProperty("isPrimary")]
        public bool isPrimary { get; set; }

        [JsonProperty("card")]
        public CardModel Card { get; set; }

        [JsonProperty("paymentClass")]
        public string PaymentClass { get; set; }
    }


    public class UpdatePaymentMethodResponseModel
    {

        public string paymentClass { get; set; }
        public bool isPrimary { get; set; }

        [JsonProperty("card")]
        public CardModel card { get; set; }
     
    }


    [JsonObject("processing")]
    public class ProcessingModel
    {
        public AuthResponseModel AuthResponse { get; set; }

        [JsonProperty("route")]
        public string Route { get; set; }
    }

    public class TransactionResponseModel
    {
        [JsonProperty("transactionId")]
        public string TransactionId { get; set; }
        [JsonProperty("merchantDescription")]
        public string TransactionDescription { get; set; }
        [JsonProperty("status")]
        public string Status { get; set; }
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("amount")]
        public double Amount { get; set; }
        [JsonProperty("currency")]
        public string Currency { get; set; }
        [JsonProperty("transactionTime")]
        public string TransactionTime { get; set; }
        [JsonProperty("receivedTime")]
        public string ReceivedTime { get; set; }
        [JsonProperty("channel")]
        public string Channel { get; set; }
        [JsonProperty("merchantRef")]
        public string MerchantRef { get; set; }
        [JsonProperty("recurring")]
        public bool Recurring { get; set; }
        [JsonProperty("commerceType")]
        public string CommerceType { get; set; }
        [JsonProperty("relatedTransaction")]
        public RelatedTransaction RelatedTransaction { get; set; }
    }

    public class RelatedTransaction
    {
        [JsonProperty("transactionId")]
        public string TransactionId  { get; set; }
        [JsonProperty("merchantRef")]
        public string MerchantRef { get; set; }
    }

    [JsonObject("authResponse")]
    public class AuthResponseModel
    {
        [JsonProperty("statusCode")]
        public string StatusCode { get; set; }

        [JsonProperty("acquirerName")]
        public string AcquirerName { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("gatewayReference")]
        public string GatewayReference { get; set; }

        [JsonProperty("gatewayMessage")]
        public string GatewayMessage { get; set; }

        [JsonProperty("avsAddressCheck")]
        public string AvsAddressCheck { get; set; }

        [JsonProperty("cv2Check")]
        public string Cv2Check { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("authCode")]
        public string AuthCode { get; set; }

        [JsonProperty("gatewaySettlement")]
        public string GatewaySettlement { get; set; }

        [JsonProperty("gatewayCode")]
        public string GatewayCode { get; set; }

        [JsonProperty("avsPostcodeCheck")]
        public string AvsPostCodeCheck { get; set; }
    }

    [JsonObject("card")]
    public class CardModel
    {
        [JsonProperty("cardFingerprint")]
        public string CardFingerPrint { get; set; }

        [JsonProperty("cardToken")]
        public string CardToken { get; set; }

        [JsonProperty("cardType")]
        public string CardType { get; set; }

        [JsonProperty("new")]
        public bool New { get; set; }

        [JsonProperty("cardUsageType")]
        public string CardUsageType { get; set; }

        [JsonProperty("cardScheme")]
        public string CardScheme { get; set; }

        [JsonProperty("maskedPan")]
        public string MaskedPan { get; set; }

        [JsonProperty("expiryDate")]
        public string ExpiryDate { get; set; }

        [JsonProperty("issuer")]
        public string Issuer { get; set; }

        [JsonProperty("issuerCountry")]
        public string IssuerCountry { get; set; }

        [JsonProperty("cardHolderName")]
        public string CardHolderName { get; set; }
    }

    public class CustomerResponseModel
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("merchantRef")]
        public string MerchantRef { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }
    }

    public class FinancialServicesResponseModel
    {
        [JsonProperty("dateOfBirth")]
        public string DateOfBirth { get; set; }
        [JsonProperty("surname")]
        public string Surname { get; set; }
        [JsonProperty("accountNumber")]
        public string AccountNumber { get; set; }
        [JsonProperty("postCode")]
        public string PostCode { get; set; }
    }

    public class HistoryModel
    {
        [JsonProperty("transactionStatus")]
        public string TransactionStatus { get; set; }

        [JsonProperty("reasonCode")]
        public string ReasonCode { get; set; }

        [JsonProperty("reasonMessage")]
        public string ReasonMessage { get; set; }

        [JsonProperty("timeStamp")]
        public string TimeStamp { get; set; }
    }
    //[JsonObject("threeDSecure")]
    //public class ThreeDSecureModel
    //{
    //    [JsonProperty("Scheme")]
    //    public string Scheme { get; set; }
    //    [JsonProperty("Status")]
    //    public string Status { get; set; }
    //    [JsonProperty("EnrolmentIndicator")]
    //    public string EnrolmentIndicator { get; set; }
    //    [JsonProperty("EnrolmentStatus")]
    //    public string EnrolmentStatus { get; set; }
    //    [JsonProperty("EnrolmentDateTime")]
    //    public string EnrolmentDateTime { get; set; }
    //    [JsonProperty("Xid")]
    //    public string Xid { get; set; }
    //    [JsonProperty("Eci")]
    //    public string Eci { get; set; }
    //    [JsonProperty("authenticationIndicator")]
    //    public string AuthenticationIndicator { get; set; }
    //    [JsonProperty("authenticationStatus")]
    //    public string AuthenticationStatus { get; set; }
    //    [JsonProperty("avv")]
    //    public string Avv { get; set; }
    //}

}
