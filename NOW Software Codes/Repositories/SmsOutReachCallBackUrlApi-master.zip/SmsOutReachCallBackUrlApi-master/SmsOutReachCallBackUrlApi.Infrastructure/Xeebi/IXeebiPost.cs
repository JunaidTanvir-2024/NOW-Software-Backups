﻿using SmsOutReachCallBackUrlApi.Contracts.Xeebi.Request;
using SmsOutReachCallBackUrlApi.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SmsOutReachCallBackUrlApi.Infrastructure.Xeebi
{
    public interface IXeebiPost
    {
       
        Task<DbResult> InsertUpdateSmsCallBackUrlData(List<XeebiSmsCallBackUrlRequest> deliveryReport);        

    }
}
