﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using PaymentsApi.Models.Configurations;
using Serilog;
using Serilog.Core;
using System;
using System.Diagnostics;
using System.Net;
using System.Threading.Tasks;

namespace PaymentsApi.Middleware
{

    public class RequestLogging
    {
        private readonly RequestDelegate Next;
        private static string SerilogFilePath;
        private readonly ILogger Logger;

        public RequestLogging(RequestDelegate next, IOptions<SerilogConfig> serilogConfig,ILogger logger)
        {
            Next = next;
            Logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            // Call the next delegate/middleware in the pipeline
            await this.Next(context);

            stopwatch.Stop();

            var date = DateTime.UtcNow.ToString("s", System.Globalization.CultureInfo.InvariantCulture);
            var client = context.Request.Headers["X-Forwarded-For"].ToString() ?? context.Connection.RemoteIpAddress.ToString();
            var method = context.Request.Method;
            var path = context.Request.Path.ToString();
            var responseTime = stopwatch.ElapsedMilliseconds;
            var StatusCode = context.Response.StatusCode;
            var StatusDescription = ((HttpStatusCode)StatusCode).ToString();

            var message = $"{date} {client} \"{method} {path}\" Status: {StatusCode} {StatusDescription} ResponseTime: {responseTime}ms";

#if !RELEASE
            Console.WriteLine(message);
#endif
            Logger.Information(message);

            // Call the next delegate/middleware in the pipeline
            //return this.Next(context);
        }


    }

}
