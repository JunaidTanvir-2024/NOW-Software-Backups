﻿namespace Application.Features.Address;
public class AddressRequest : IRequest<Result<AddressResponseModel>>
{
    public string PostCode { get; set; } = default!;
}