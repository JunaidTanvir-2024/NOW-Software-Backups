﻿namespace Models.Contracts.Request
{
    public class UserAccountBundles
    {
        public string Name { get; set; }
    }
}
