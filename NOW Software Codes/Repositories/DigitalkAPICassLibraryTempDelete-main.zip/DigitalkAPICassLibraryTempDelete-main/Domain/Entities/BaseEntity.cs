﻿namespace Domain.Entities
{
    public abstract class BaseEntity
    {
        protected long Id { get; set; }
    }
}
