﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaymentsApi.Models.Configurations;

namespace PaymentsApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Pay360HostedApiController : ControllerBase
    {
       // private AppConfiguration _appConfiguration;

        public Pay360HostedApiController()
        {
            
        }

        
    }
}