﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Configurations
{
    public class CommonSettings
    {
        public SmsGateway SmsGateway { get; set; }
    }
}
