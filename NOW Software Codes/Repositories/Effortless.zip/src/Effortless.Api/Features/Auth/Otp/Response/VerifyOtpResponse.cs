namespace Effortless.Api.Features.Auth.Otp.Response;
public class VerifyOtpResponse
{
    public bool IsValid { get; set; }
}
