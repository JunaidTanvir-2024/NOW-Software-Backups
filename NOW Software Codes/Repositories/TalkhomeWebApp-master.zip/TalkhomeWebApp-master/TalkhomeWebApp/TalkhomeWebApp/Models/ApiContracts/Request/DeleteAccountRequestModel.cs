﻿using System;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class DeleteAccountRequestModel
    {               
    

        public string AccountId { get; set; }
        public string Msisdn { get; set; }
       
        public string DeleteAccountReason { set; get; }
        public string Comments { set; get; }
        public string Message { set; get; }
    }
}
