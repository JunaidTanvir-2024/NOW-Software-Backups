﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.DTOs.CustomerOrder;
public record OrderPaymentDto
{
    public long OrderPaymentId { get; set; } = default!;
    public string CustomerId { get; set; } = default!;
    public long CustomerOrderId { get; set; } = default!;
    public string? TransactionId { get; set; } = default!;
    public decimal OrderAmount { get; set; } = default!;
    public bool? IsPaymentSuccess { get; set; } = default!;
    public string CreatedBy { get; set; } = default!;
    public string UpdatedBy { get; set; } = default!;
    public string RequestId { get; set; } = default!;
    public string Action { get; set; } = default!;
    public bool Require3dSecure { get; set; } = default!;
}

