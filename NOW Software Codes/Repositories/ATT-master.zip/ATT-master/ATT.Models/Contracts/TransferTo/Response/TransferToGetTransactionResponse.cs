﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransferToGetTransactionResponse
    {
        public string transactionid { get; set; }
        public string msisdn { get; set; }
        public string destination_msisdn { get; set; }
        public string transaction_authentication_key { get; set; }        
        public int transaction_error_code { get; set; }
        public string transaction_error_txt { get; set; }
        public string country { get; set; }
        public int countryid { get; set; }
        public string @operator { get; set; }
        public int operatorid { get; set; }
        public string reference_operator { get; set; }
        public string product_requested { get; set; }
        public string actual_product_sent { get; set; }
        public decimal wholesale_price { get; set; }
        public decimal retail_price { get; set; }
        public string sms { get; set; }
        public string originating_currency { get; set; }
        public string destination_currency { get; set; }
        public string authentication_key { get; set; }              
        
    }
}
