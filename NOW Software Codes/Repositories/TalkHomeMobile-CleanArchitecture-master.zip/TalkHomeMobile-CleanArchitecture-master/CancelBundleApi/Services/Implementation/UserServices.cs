﻿using CancelBundleApi.Models.DbModels;
using CancelBundleApi.Repositories.Interfaces;
using CancelBundleApi.Services.Interfaces;

namespace CancelBundleApi.Services.Implementation;

internal sealed class UserServices : IUserServices
{
    private readonly IUnitOfWork _uow;

    public UserServices(IUnitOfWork uow)
    {
        _uow = uow;
    }

    public async Task<MsisdnDetails> GetMsisdnDetail(string msisdn)
    {

        var msisdnDetails = await _uow.UserRepo.GetMsisdnDetail(msisdn);

        return msisdnDetails;
    }
}
