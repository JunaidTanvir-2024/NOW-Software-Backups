﻿using SC.Core.Common.Definitions.Utilities;
using System.ComponentModel.DataAnnotations;
using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Model.Account;
public record AccountDetailModel
{
    public string Avatar { get; set; } = default!;
    public string DateOfBirth { get; set; } = default!;
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public string FrontName { get; set; } = default!;
    [Required(ErrorMessage = "The {0} field is required.")]
    [EnumValidation(typeof(AppEnums.GenderEnum), ErrorMessage = "The {0} field is required and must be a valid GenderEnum value.")]
    public GenderEnum Gender { get; set; } = default!;
}

