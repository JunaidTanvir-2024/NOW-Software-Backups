﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace THCC.Application.Models.Dtos
{
    public class THRCCAuditDto
    {
        public decimal new_balance { get; set; }
        public int audit_id { get; set; }
    }
}
