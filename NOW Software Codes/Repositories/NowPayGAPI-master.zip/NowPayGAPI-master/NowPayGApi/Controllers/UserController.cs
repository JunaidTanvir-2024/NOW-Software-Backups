﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NowPayGApi.Infrastructure.BLL.Interfaces;
using NowPayGApi.JwtHelpers;
using NowPayGApi.Models.Contracts;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using NowPayGApi.Models.DAOs;
using NowPayGApi.Models.Utility;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NowPayGApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : Controller
    {
        private IConfiguration _configuration { get; }
        private readonly IBL_User Bl;
        private readonly ILogger Logger;

        public UserController(IConfiguration configuration, IBL_User bl, ILogger logger)
        {
            _configuration = configuration;
            Bl = bl;
            Logger = logger;
        }

        [HttpPost]
        [Route("Login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody]LoginRequestModel model)
        {
            try
            {
                GenericApiResponse<LoginResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.Login(model);
                if (response != null)
                {
                    if (response.payload != null)
                    {
                        response.payload.GenerateToken(_configuration);
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: Login, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

        }

        [HttpPost]
        [Route("Register")]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody]RegisterUserRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.RegisterUser(model);
                if (response != null)
                {
                    return Ok(response);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: Register, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

        }

        [HttpPost]
        [Route("ExternalLogin")]
        [AllowAnonymous]
        public async Task<ActionResult> ExternalLogin([FromBody]ExternalLoginRequestModel model)
        {
            try
            {
                GenericApiResponse<LoginResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.RegisterSocialMediaUser(model);
                if (response != null)
                {
                    if (response.payload != null)
                    {
                        response.payload.GenerateToken(_configuration);
                        return Ok(response);
                    }
                    else
                    {
                        return Ok(response);
                    }
                }
                else
                {
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: ExternalLogin, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("GetUserByEmail")]
        [AllowAnonymous]
        public async Task<IActionResult> GetUserByEmail([FromBody]GetUserByEmailRequestModel model)
        {
            try
            {
                GenericApiResponse<GetUserByEmailResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.GetUserByEmail(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetUserByEmail, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

        }

        [HttpPost]
        [Route("VerifyEmail")]
        [AllowAnonymous]
        public async Task<IActionResult> VerifyEmail([FromBody]VerifyEmailRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.VerifyEmailbyToken(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: VerifyEmail, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("ForgotPassword")]
        [AllowAnonymous]
        public async Task<IActionResult> ForgotPassword([FromBody]ForgotPasswordRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.ForgotPassword(model);
                if (response != null)
                {
                    return Ok(response);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: Register, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

        }

        [HttpPost]
        [Route("UpdateUserPassword")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateUserPassword([FromBody]UpdateUserPasswordRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.UpdatePassword(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: VerifyEmail, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

        }

        [HttpPost]
        [Route("ReSendToken")]
        [AllowAnonymous]
        public async Task<IActionResult> ReSendToken([FromBody]ReSendTokenRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.ResendVerificationEmail(model);
                if (response != null)
                {
                    return Ok(response);
                }
                return BadRequest();

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: VerifyEmail, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

        }

        [HttpPost]
        [Route("IsUserExist")]
        [AllowAnonymous]
        public async Task<IActionResult> IsUserExist([FromBody]IsUserExistRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.IsUserExist(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: IsUserExist, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

        }

        [HttpPost]
        [Route("ValidateMsisdn")]
        [AllowAnonymous]
        public async Task<IActionResult> ValidateMsisdn([FromBody]ValidateMsisdnRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.ValidateMsisdn(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: ValidateMsisdn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

        }

        [HttpPost]
        [Route("FreeSimOrder")]
        [AllowAnonymous]
        public async Task<IActionResult> UserFreeSimOrder([FromBody]SaveUserSimOrderRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.SaveUserSimOrder(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: UserFreeSimOrder, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("SaveUserProduct")]
        [Authorize]
        public async Task<IActionResult> SaveUserProduct([FromBody]SaveUserProductRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                model.UserId = Convert.ToInt32((HttpContext.User.Identity as ClaimsIdentity).FindFirst("Id").Value);
                var response = await Bl.SaveUserProduct(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: SaveUserProduct, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("GetAllProductsByUserID")]
        [Authorize]
        public async Task<IActionResult> GetAllProductsByUserID([FromBody]GetAllProductsByUserIDRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.GetAllProductsByUserID(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetAllProductsByUserID, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("UserSummary")]
        [Authorize]
        public async Task<IActionResult> GetUserSummary([FromBody]GetUserSummaryRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.GetUserSummary(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetUserSummary, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("GetUserCallHistory")]
        [Authorize]
        public async Task<IActionResult> GetUserCallHistory([FromBody]GetUserCallHistoryRequestModel model)
        {
            try
            {
                return Ok(await Bl.GetUserCallHistory(model));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetUserCallHistory, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("GetUserSmsHistory")]
        [Authorize]
        public async Task<IActionResult> GetUserSmsHistory([FromBody]GetUserSmsHistoryRequestModel model)
        {
            try
            {
                return Ok(await Bl.GetUserSmsHistory(model));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetUserSmsHistory, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("GetUserDataHistory")]
        [Authorize]
        public async Task<IActionResult> GetUserDataHistory([FromBody]GetUserDataHistoryRequestModel model)
        {
            try
            {
                return Ok(await Bl.GetUserDataHistory(model));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetUserDataHistory, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("GetUserPaymentHistory")]
        [Authorize]
        public async Task<IActionResult> GetUserPaymentHistory([FromBody]GetUserPaymentHistoryRequestModel model)
        {
            try
            {
                return Ok(await Bl.GetUserPaymentHistory(model));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetUserPaymentHistory, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("UpdateMailSubscription")]
        [Authorize]
        public async Task<IActionResult> UpdateMailSubscription([FromBody]UpdateMailSubscriptionRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.UpdateMailSubscription(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: UpdateMailSubscription, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("ChangeAccountPasword")]
        [Authorize]
        public async Task<IActionResult> ChangeAccountPasword([FromBody]ChangePasswordRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.ChangeAccountPassword(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: ChangeAccountPasword, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("AddBundleViaSimCredit")]
        [Authorize]
        public async Task<IActionResult> AddBundleViaSimCredit([FromBody]AddBundleViaSimCreditRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.AddBundleViaSimCredit(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: AddBundleViaSimCredit, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("SetBundleAutoRenewal")]
        [AllowAnonymous]
        public async Task<IActionResult> SetBundleAutoRenewal([FromBody]BundleAutoRenewalRequestModel model)
        {
            try
            {
             
               var response=  await Bl.SetBundleAutoRenewal(model);
                return Ok(response);

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: SetBundleAutoRenewal, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }
    }
}
