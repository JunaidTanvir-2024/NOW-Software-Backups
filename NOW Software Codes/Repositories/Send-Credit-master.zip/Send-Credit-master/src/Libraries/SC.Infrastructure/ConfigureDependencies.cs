﻿using Microsoft.EntityFrameworkCore;
using SC.Core.Interfaces.Services;
using SC.Core.Vendors.Notification;
using SC.Core.Vendors.Payment;
using SC.Infrastructure.Services;
using SC.Infrastructure.Services.Common;
using SC.Infrastructure.Services.CustomerOrder;
using SC.Infrastructure.Services.MessageBroker;
using SC.Infrastructure.Vendors.EventTracking;
using SC.Infrastructure.Vendors.EventTracking.Common;
using SC.Infrastructure.Vendors.FusionHub;
using SC.Infrastructure.Vendors.FusionHub.Common;
using SC.Infrastructure.Vendors.Notification;
using SC.Infrastructure.Vendors.Notification.Common;
using SC.Infrastructure.Vendors.Payment;
using SC.Infrastructure.Vendors.Payment.Common;

namespace SC.Infrastructure;

public static class ConfigureDependencies
{
    public static IServiceCollection AddInfrastructureDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.RegisterJsonSettings(configuration);
        services.AddRegisterMessageBrokerConfigurations(configuration);
        services.RegisterBuiltInServices();
        services.RegisterCustomServices();
        services.RegisterVendors();
        services.AddApiVersioningConfiguration();
        services.AddOpenApiConfiguration();
        services.AddJwtConfiguration();
        services.RegisterRepositories();
        return services;
    }

    private static IServiceCollection RegisterBuiltInServices(this IServiceCollection services)
    {
        services.AddHttpClient();
        services.AddHttpContextAccessor();
        return services;
    }

    private static IServiceCollection RegisterCustomServices(this IServiceCollection services)
    {
        services.AddScoped<ITimeWarpService, TimeWarpService>();
        services.AddScoped<IJwtService, JwtService>();
        services.AddTransient<IHttpService, HttpService>();
        services.AddScoped<IFusionHubService, FusionHubService>();
        services.AddScoped<ICommonService, CommonService>();
        services.AddScoped<ICustomerOrderService, CustomerOrderService>();
        services.AddScoped<IPaymentIntegration, PaymentIntegration>();
        services.AddScoped<IDiscountRepository, DiscountRepository>();
        services.AddScoped<IHelperService, HelperService>();
        services.AddScoped<IMessageMatrixService, MessageMatrixService>();
        services.AddScoped<IEventTrackingService, EventTrackingService>();
        services.AddScoped<IEventTrackingIntegration, EventTrackingIntegration>();
        services.AddScoped<IMessagePublisher, MessagePublisher>();

        return services;
    }

    private static IServiceCollection RegisterRepositories(this IServiceCollection services)
    {
        services.AddTransient<ILoggerRepository, LoggerRepository>();
        services.AddTransient<IUserRepository, UserRepository>();
        services.AddTransient<ICustomerCartRespository, CustomerCartRespository>();
        services.AddTransient<IContactPersonRepository, ContactPersonRepository>();
        services.AddTransient<ICustomerCardRepository, CustomerCardRepository>();
        services.AddTransient<ISystemConfigurationRepository, SystemConfigurationRepository>();
        services.AddTransient<IFaqRepository, FaqRepository>();
        return services;
    }

    private static IServiceCollection RegisterVendors(this IServiceCollection services)
    {
        //services.AddScoped<IDTOneIntegration, DTOneIntegration>();
        return services;
    }

    private static IServiceCollection RegisterJsonSettings(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<OpenApiSetting>(configuration.GetSection(OpenApiSetting.SectionName));
        services.Configure<JwtSetting>(configuration.GetSection(JwtSetting.SectionName));
        services.Configure<DefaultRegionSetting>(configuration.GetSection(DefaultRegionSetting.SectionName));
        services.Configure<SecurityHeaderSetting>(configuration.GetSection(SecurityHeaderSetting.SectionName));
        services.Configure<PaymentHubSetting>(configuration.GetSection(PaymentHubSetting.SectionName));
        services.Configure<MessageMatrixSetting>(configuration.GetSection(MessageMatrixSetting.SectionName));
        services.Configure<EventTrackingSetting>(configuration.GetSection(EventTrackingSetting.SectionName));

        return services;
    }

    public static IApplicationBuilder UseInfrastructureMiddlewares(this IApplicationBuilder app)
    {
        //app.MessageBrokerDbInitializer();
        app.UseAppExceptionMiddleware();
        app.UseAppLoggingMiddleware();
        app.UseOpenApiConfiguration();
        app.UseSecurityHeadersMiddleware();
        return app;
    }
    private static void MessageBrokerDbInitializer(this IApplicationBuilder app)
    {
        using (var scope = app.ApplicationServices.CreateScope())
        {
            scope.ServiceProvider.GetService<MessageBrokerDbContext>()?.Database.Migrate();
        }
    }
}