﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Services;

public interface IAddressService : ServiceType.ITransient
{
    Task<AddressDto> GetAddresses(string postcode);
}
