﻿using Application.Features.Carousel;

namespace Application.Common.Interfaces.Repositories;
public interface IPromotionRepository
{
    Task<IEnumerable<CarouselResponse>> GetPromotionCarousel(long userid, string msisdn, bool? isNewUserOnly);
}