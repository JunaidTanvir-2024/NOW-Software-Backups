﻿using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    
    public class ProductsForTransactionOutputArray
    {
        public List<ProductsForTransactionOutput> Operators { get; set; }
        public ProductsForTransactionOutputArray()
        {
            Operators = new List<ProductsForTransactionOutput>();
        }
        public PopupInfo SendTopupPopup { get; set; }
    }

    public class ProductsForTransactionOutput

    {
        //public ProductsForTransactionRow[] products = new ProductsForTransactionRow[1000];

        public int Id { get; set; }
        public string Name { get; set; }
        public string Country { get; set; }
        public string NowtelTransactionReference { get; set; }
        public string IconUri { get; set; }
        public List<ProductsForTransactionRow> Products { get; set; }

        public static implicit operator ProductsForTransactionOutput(ProductsForTransactionOutputArray v)
        {
            throw new NotImplementedException();
        }
    }

    public class ProductsForTransactionRow
    {
        public string Clientccy { get; set; }
        public string Receiverccy { get; set; }
        public string TransactionfeeClientccy { get; set; }
        public string Product { get; set; }
        //public string ServiceFeeClientccy { get; set; }
        public string ItemPriceClientccy { get; set; }
        public string TotalPriceClientccy { get; set; }

    }
}
