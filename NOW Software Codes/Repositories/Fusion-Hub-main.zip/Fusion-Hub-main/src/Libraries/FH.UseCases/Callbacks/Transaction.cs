using FH.Core.DTOs.Database;
using FluentValidation;
using Mediator;
using FH.Core.Helpers;
using FH.Core.Interfaces.Database;
using FH.Core.Interfaces.Vendors;
using FH.Core.Interfaces.Services;
using MessageBrokerModel;
using static MessageBrokerModel.TransactionMessageDto;


namespace FH.UseCases.Callbacks;
public sealed class Transaction
{
    #region Query
    public sealed record Query : IRequest
    {
        public required string Hash { get; set; }
        public required object Data { get; set; }
    }

    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Hash).NotNull().NotEmpty();
            RuleFor(x => x.Data).NotNull().NotEmpty();
        }
    }

    #endregion

    #region Response
    public sealed record Response { }

    #endregion

    #region Handler
    internal sealed class Handler(ISecurityHelpers securityHelpers, IUnitOfWork unitOfWork, IDTOneService dTOneService, IMessagePublisher messagePublisher) : IRequestHandler<Query>
    {
        private const string FUSION_HUB = "FusionHub";
        private readonly ISecurityHelpers _securityHelpers = securityHelpers;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IDTOneService _dTOneService = dTOneService;
        private readonly IMessagePublisher _messagePublisher = messagePublisher;

        async ValueTask<Unit> IRequestHandler<Query, Unit>.Handle(Query request, CancellationToken cancellationToken)
        {
            var isValidCallData = _securityHelpers.VerifyHashedData(request.Data, request.Hash);

            if (isValidCallData)
            {
                var result = _dTOneService.MapTransactionData(request.Data);

                var transactionStatus = await _unitOfWork.TransactionRepository.TransactionUpdate(new ProductTransactionUpdateDto.Request()
                {
                    Status = result.Status,
                    VendorTransactionId = result.VendorTransactionId
                });

                if (transactionStatus is not null)
                {
                    await _messagePublisher.PublishMessage(new TransactionMessageDto()
                    {
                        Publisher = FUSION_HUB,
                        TransactionReference = transactionStatus.TransactionReference,
                        TransactionItems = new TransactionItem()
                        {
                            CartReference = transactionStatus.CartReference,
                            ProductId = transactionStatus.ProductId,
                            ProductVendorCode = transactionStatus.ProductVendorCode,
                            Status = transactionStatus.TransactionStatus
                        },
                    });
                }
                return Unit.Value;
            }
            return Unit.Value;
        }
    }
    #endregion
}
