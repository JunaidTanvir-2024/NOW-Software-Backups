﻿using ATT.Models.Contracts.TransferTo.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.TransferTo
{
    public interface ITransfertoAuth_BL
    {
        TransfertoBaseRequest getAuthJSONObject(string currency, string product, bool isLCR);

        TransfertoBaseRequest getAuthJSONObject(string currency, long? sourceMSISDN = null);

        HttpRequestMessage HttpRequestMessage(string currency, string url, HttpMethod method = null, HttpContent content = null);

        TransfertoBaseRequest getAuthJSONObject(string currency, long key, long? sourceMSISDN = null);

        TransfertoBaseRequest getFreeSwitchAuthJSONObject();

        TransfertoBaseRequest getFreeSwitchAuthJSONObject(long key);

        string[] GetAttCredentials(string currency, long? sourceMSISDN = null);

        string[] GetDataBundlesCredentials(string currency);
        string[] GetAttCredentials_TRH(string currency, string product);
        TransfertoBaseRequest getAuthJSONObject_TRH(string currency, string product);
        TransfertoBaseRequest getAuthJSONObject_TRH(string currency, long key, string productCode);
    }
}
