﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface IEmailService
    {
        Task SendUserRegistrationEmail(string email, string name, string token);
        Task<bool> SendEmail(string customerEmail, string Message, bool IsHtmlBody, string subject = null);
    }
}
