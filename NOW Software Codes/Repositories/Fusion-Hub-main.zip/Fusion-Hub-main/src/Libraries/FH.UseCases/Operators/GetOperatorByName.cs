using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Interfaces.Database;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;

namespace FH.UseCases.Operators;
public sealed class GetOperatorByName
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public string? OperatorName { get; set; }
		public string? IsoCode { get; set; }
		//public OperatorRequestType RequestType { get; set; }
	}

	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query> { }

	#endregion

	#region Response
	public sealed record Response
	{
		public OperatorInfo Operator { get; set; } = new OperatorInfo();
		public sealed record OperatorInfo
		{
			public long Id { get; set; }
			public string? Name { get; set; }
			public string? Description { get; set; }
			public OperatorCountryInfo Country { get; set; } = new OperatorCountryInfo();
		}
		public sealed record OperatorCountryInfo
		{
			public string? Name { get; set; }
			public string? IsoCode { get; set; }
		}
	}

	#endregion

	#region Handler
	internal sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IMapper _mapper = mapper;
		private readonly IUnitOfWork _unitOfWork = unitOfWork;

		public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
		{
			var getOperatorsRequest = _mapper.Map<OperatorByNameDto.Request>(request);

			getOperatorsRequest.IsActive = true;
			getOperatorsRequest.IsDeleted = false;

			var OperatorRecords = await _unitOfWork.OperatorRepository.GetOperatorByName(getOperatorsRequest);

			if (OperatorRecords is null)
			{
				return ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
			}
			var getOperatorsResponse = _mapper.Map<List<Response>>(OperatorRecords);
			return ResultWrapper.Success(getOperatorsResponse);
		}
	}
	#endregion
}
