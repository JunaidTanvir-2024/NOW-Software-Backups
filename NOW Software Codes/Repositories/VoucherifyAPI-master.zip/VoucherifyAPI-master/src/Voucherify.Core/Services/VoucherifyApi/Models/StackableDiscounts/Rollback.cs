using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Orders;

namespace Voucherify.Core.Services.VoucherifyApi.Models.StackableDiscounts;

public class Rollback
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("source_id")]
    public object? SourceId { get; set; }

    [JsonPropertyName("created_at")]
    public DateTimeOffset CreatedAt { get; set; }

    [JsonPropertyName("updated_at")]
    public DateTimeOffset UpdatedAt { get; set; }

    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("result")]
    public string? Result { get; set; }

    [JsonPropertyName("amount")]
    public long Amount { get; set; }

    [JsonPropertyName("total_amount")]
    public long TotalAmount { get; set; }

    [JsonPropertyName("items")]
    public OrderItem[]? Items { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    [JsonPropertyName("customer_id")]
    public string? CustomerId { get; set; }

    [JsonPropertyName("referrer_id")]
    public object? ReferrerId { get; set; }

    [JsonPropertyName("object")]
    public string? Object { get; set; }
}
