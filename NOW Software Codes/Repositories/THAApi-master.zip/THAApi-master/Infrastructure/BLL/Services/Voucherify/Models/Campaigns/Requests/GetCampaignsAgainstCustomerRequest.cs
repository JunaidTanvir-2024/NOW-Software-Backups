using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.Campaigns.Requests
{
    public class GetCampaignsAgainstCustomerRequest
    {
        public string SourceId { get; set; } = null!;
        public Metadata Metadata { get; set; }
    }
}
