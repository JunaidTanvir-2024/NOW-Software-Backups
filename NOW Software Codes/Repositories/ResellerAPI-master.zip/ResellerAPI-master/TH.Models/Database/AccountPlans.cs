﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TH.Models.Database
{
    public class AccountPlans
    {
        public string calling_package_id { get; set; }
        public string branded_name { get; set; }
        public int allowance_remaining_voice_seconds { get; set; }
        public int allowance_remaining_sms_messages { get; set; }
        public int allowance_remaining_gprs { get; set; }
    }
       
}
