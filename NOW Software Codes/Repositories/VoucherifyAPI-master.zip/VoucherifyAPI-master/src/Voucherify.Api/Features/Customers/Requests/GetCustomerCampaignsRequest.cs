using FluentValidation;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Customers.Requests;

public class GetCustomerCampaignsRequest
{
    public string SourceId { get; set; } = null!;
    public Metadata? Metadata { get; set; }
}
internal class GetCustomerCampaignsRequestValidator : AbstractValidator<GetCustomerCampaignsRequest>
{
    public GetCustomerCampaignsRequestValidator()
    {
        RuleFor(p => p.SourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.SourceId = phoneNumber);
    }
}
