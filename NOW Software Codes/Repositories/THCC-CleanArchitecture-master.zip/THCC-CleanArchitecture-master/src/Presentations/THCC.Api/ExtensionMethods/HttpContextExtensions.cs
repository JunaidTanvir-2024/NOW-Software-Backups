﻿using System.Net;

public static class HttpContextExtensions
{
    public static string? GetClientIpAddress(this HttpContext httpContext)
    {
        // First try to get the IP address from the request headers
        if (httpContext.Request.Headers.TryGetValue("X-Forwarded-For", out var values))
        {
            var ip = values.FirstOrDefault()?.Split(new char[] { ',' }).FirstOrDefault()?.Trim();
            if (!string.IsNullOrEmpty(ip) && IPAddress.TryParse(ip, out var result))
            {
                return result.ToString();
            }
        }

        // If X-Forwarded-For header is not present or contains an invalid IP address,
        // fall back to using the remote IP address of the client
        return httpContext.Connection.RemoteIpAddress?.ToString();
    }
}