﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
   
    public class IMUserAccount
    {
        public string IMUsername { get; set; }

        public string IMPassword { get; set; }
    }
}
