﻿using PhoneNumbers;
using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    /// <summary>
    /// Gets the full and validated phone number 
    /// </summary>
    public class PhoneNumberService : IPhoneNumberService
    {
        private readonly PhoneNumberUtil phoneNumberUtil;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="phoneNumberUtil">Instance of PhoneNumberUtil</param>
        public PhoneNumberService(PhoneNumberUtil phoneNumberUtil)
        {
            this.phoneNumberUtil = phoneNumberUtil;
        }

        /// <summary>
        /// Gets the region from a phone number
        /// </summary>
        /// <param name="originator">Phone number, this must be in E164 format</param>
        /// <returns>Country Code</returns>
        public string GetCountryCode(string phoneNumber)
        {
            try
            {
                phoneNumber = phoneNumber.Trim();

                if (!phoneNumber.StartsWith("+"))
                {
                    phoneNumber = $"+{phoneNumber}";
                }

                if (phoneNumber.StartsWith("+1"))
                {
                    string countryCode = null;
                    string[] countries = { "US", "CA" };

                    foreach (var c in countries)
                    {
                        bool isValid = phoneNumberUtil.IsPossibleNumber(phoneNumber, c);
                        if (isValid)
                        {
                            try
                            {
                                var number = phoneNumberUtil.Parse(phoneNumber, c);
                                isValid = phoneNumberUtil.IsValidNumberForRegion(number, c);
                                if (isValid)
                                {
                                    countryCode = c;
                                }
                            }
                            catch
                            {
                                countryCode = null;
                            }
                        }
                    }
                    return countryCode;
                }
                else
                {
                    var number = phoneNumberUtil.Parse(phoneNumber, "");
                    return phoneNumberUtil.GetRegionCodeForCountryCode(number.CountryCode);
                }
            }
            catch (NumberParseException)
            {
                return null;
            }
        }
    }
}
