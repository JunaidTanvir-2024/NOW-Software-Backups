﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class TransferByPayPalCallBackV1RequestModel
    {
        [Required]
        public string PaymentId { get; set; }
        [Required]
        public string PayerID { get; set; }

        public string IpAddress { get; set; }

        //Transfer Related Data
        [Required]
        [MaxLength(200)]
        public string NowtelRef { get; set; }
        [Required]
        [Range(1, int.MaxValue)]
        public int Product { get; set; }
        [Required]
        [Range(1, int.MaxValue)]
        public int OperatorId { get; set; }
    }
}
