﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class PortOutBySmsResponseModel
    {
        public readonly string group = "sms-service";
        public string keyword { get; set; }
        public string text { get; set; }
    }
}
