﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{
    public class TwilioConfig
    {
        public string Sid { get; set; }
        public string AuthToken { get; set; }
        public string[] TwilioFromNumberCountries { get; set; }
        public string TwilioNumber { get; set; }
        public string SmsStatuCallbackUrl { set; get; }
    }
}
