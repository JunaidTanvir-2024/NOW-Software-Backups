﻿using NowPayG.Models.Pay360ApiContracts;
using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class Pay360ViewModel
    {
        public CardViewModel UserCard { get; set; }

        [Required(ErrorMessage = "Select Amount")]
        public float Amount { get; set; }

        [Required(ErrorMessage = "Select/Enter Msisdn")]
        public string Msisdn { get; set; }

        [Required(ErrorMessage = "Enter Security Code")]
        public string SecurityCode { get; set; }

        public Pay360PaymentType Pay360PaymentType { get; set; }

        public CheckOutTypes CheckoutPaymentType { get; set; }

        public string UUID { get; set; }
        public string BundleName { get; set; }

        public string CustomerEmail { get; set; }

        public bool AutoTopUp { get; set; }
        public string AccountId { get; set; }
        public bool isAutoRenew { get; set; }
        public string EmailAddress { get; set; }
        public string AddressL1 { get; set; }
        public string AddressL2 { get; set; }
        public string AddressL3 { get; set; } = "AddressL3";
        public string AddressL4 { get; set; } = "AddressL4";
        public string City { get; set; }
        public string County { get; set; }
        public string PostCode { get; set; }
        public string Region { get; set; }
    }
}
