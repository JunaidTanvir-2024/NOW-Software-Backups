using FH.Api.Filter;
using FH.Infrastructure;

using Hangfire;

namespace FH.Api;

public static class ConfigureMiddlewares
{
    public static WebApplication AddApiMiddlewares(this WebApplication app)
    {
        app.UseStaticFiles();
        app.UseAuthentication();
        app.UseAuthorization();
        app.UseSentryTracing();
        app.UseHttpsRedirection();
        //   app.UseHangfireDashboard("/hangfire");
        app.UseHangfireDashboard("/hangfire", new DashboardOptions
        {
            DashboardTitle = "Fusion Hub Dashboard",
            Authorization = new[]
               {
                new  HangfireAuthorizationFilter("admin")
            }
        });
        app.UseInfrastructureMiddlewares();
        app.MapControllers();
        return app;
    }
}
