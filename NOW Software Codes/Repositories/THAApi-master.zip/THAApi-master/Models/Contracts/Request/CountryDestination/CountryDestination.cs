﻿using Models.Contracts.Response;
using System.Collections.Generic;

namespace Models.Contracts.Request.CountryDestination
{
    public class CountryDestination
	{
		public CountryDestination() { }

		public CountryDestination(string id, string name)
		{
			Id = id;
			Name = name;
		}

		public CountryDestination(string id, string name, string flagImageUrl)
		{
			Id = id;
			Name = name;
			FlagImageUrl = flagImageUrl;
		}

		public CountryDestination(string id, string name, string flagImageUrl, bool hasBundles)
		{
			Id = id;
			Name = name;
			FlagImageUrl = flagImageUrl;
			HasBundles = hasBundles;
		}

		public CountryDestination(string id, string name, string flagImageUrl, bool hasBundles, bool hasOffers)
		{
			Id = id;
			Name = name;
			FlagImageUrl = flagImageUrl;
			HasBundles = hasBundles;
			HasOffers = hasOffers;
		}

		public CountryDestination(string id,
		  string name,
		  string flagImageUrl,
		  bool hasBundles,
		  string ISOCode
		  )
		{
			Id = id;
			Name = name;
			FlagImageUrl = flagImageUrl;
			HasBundles = hasBundles;

			this.ISOCode = ISOCode;
		}

		public CountryDestination(string id,
			string name,
			string flagImageUrl,
			bool hasBundles,
			bool hasOffers,
			bool showOffpeak,
			string Landline,
			string Mobile,
			string SMS,
			string OffPeakLandline,
			string OffPeakMobile,
			string OffPeakSMS,
			string LandlineName,
			string MobileName,
			string SMSName,
			string ISOCode
			)
		{
			Id = id;
			Name = name;
			FlagImageUrl = flagImageUrl;
			HasBundles = hasBundles;
			HasOffers = hasOffers;
			if (Rates == null) Rates = new List<CountryDestinationRateDetails>();

			if (showOffpeak)
			{

				this.OffPeakLandline = string.IsNullOrEmpty(OffPeakLandline) ? Landline : OffPeakLandline;
				this.OffPeakMobile = string.IsNullOrEmpty(OffPeakMobile) ? Mobile : OffPeakMobile;
				this.OffPeakSMS = string.IsNullOrEmpty(OffPeakSMS) ? SMS : OffPeakSMS;

				Rates.Add(new CountryDestinationRateDetails
				{
					Name = LandlineName,
					Price = Landline,
					offpeakPrice = this.OffPeakLandline
				});

				Rates.Add(new CountryDestinationRateDetails
				{
					Name = MobileName,
					Price = Mobile,
					offpeakPrice = this.OffPeakMobile
				});

				Rates.Add(new CountryDestinationRateDetails
				{
					Name = SMSName,
					Price = SMS,
					offpeakPrice = this.OffPeakSMS
				});

			}
			else
			{

				Rates.Add(new CountryDestinationRateDetails
				{ Name = LandlineName, Price = Landline });

				Rates.Add(new CountryDestinationRateDetails
				{ Name = MobileName, Price = Mobile });

				Rates.Add(new CountryDestinationRateDetails
				{ Name = SMSName, Price = SMS });

			}




			this.showOffpeak = showOffpeak;
			this.ISOCode = ISOCode;
			this.Landline = Landline;
			this.Mobile = Mobile;
			this.SMS = SMS;
		}

		public string Id { get; set; }
		public string Name { get; set; }
		public string FlagImageUrl { get; set; }
		public bool HasBundles { get; set; }
		public bool HasOffers { get; set; }
		public string bundleid { get; set; }
		public string dest_country_name { get; set; }
		public string dest_iso_code { get; set; }
		public string ISOCode { get; set; }
		public string bundle_name { get; set; }
		public string bundle_price { get; set; }
		public string bundle_minutes { get; set; }
		public string bundle_days { get; set; }
		public bool showOffpeak { get; set; }

		private string Landline;
		private string Mobile;
		private string SMS;
		private string OffPeakLandline;
		private string OffPeakMobile;
		private string OffPeakSMS;

		public List<CountryDestinationRateDetails> Rates { get; set; }
	}


	public class RatesView
	{
		public IEnumerable<CountryDestination> countryDestinations { get; set; }

		public IEnumerable<CountryDestination> topCountryDestinations { get; set; }

		public IEnumerable<TopDestinationBundleDetails> topBundleDestinations { get; set; }

	}
	public class BundlesWithTopDestinations
	{
		public IEnumerable<CountryDestination> countryDestinations { get; set; }
		public IEnumerable<CountryDestination> topCountryDestinations { get; set; }
		public IEnumerable<TopDestinationBundleDetails> topBundleDestinations { get; set; }
		public IEnumerable<CountryDestinationWelcomeBundle> topWelcomeBundleDestinations { get; set; }
        public PopupInfo WelcomeBundlePopup { get; set; }
        public PopupInfo PaygBundlePopup { get; set; }
    }
}
