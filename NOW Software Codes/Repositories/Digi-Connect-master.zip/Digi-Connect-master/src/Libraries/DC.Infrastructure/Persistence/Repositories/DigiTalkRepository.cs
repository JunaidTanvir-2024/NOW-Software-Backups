using DC.Core.Common.Definitions;
using DC.Core.Common.Entities;
using DC.Core.Common.Extensions;
using DC.Core.Common.Interfaces.Database;
using DC.Core.Features.Notifications.Requests;

namespace DC.Infrastructure.Persistence.Repositories;

internal sealed class DigiTalkRepository(IConfiguration configuration, ILogger logger) : IDigiTalkRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private readonly ILogger _logger = logger;


    public async Task<List<ActiveMsisdnEntity>> GetNewRegisteredMsisdn(DateTime time, string state)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.DigiConnect)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@sim_state", state);
                parameters.Add("@sim_activation_datetime_utc", time);

                return (await connection.QueryAsync<ActiveMsisdnEntity>(AppConstants.Database.StoreProcedure.GetActiveMsisdn, parameters, commandType: CommandType.StoredProcedure)).ToList();
                
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(DigiTalkRepository), nameof(GetNewRegisteredMsisdn));
            return default;
        }
    }

   

}
