// 86acbd31cd7c09cf30acb66d2fbedc91daa48b86:1608718168.7825837
importScripts('https://aswpsdkeu.com/notify/v1/ua-sdk.min.js')
uaSetup.worker(self, {
  defaultIcon: 'https://dl.asnapieu.com/binary/public/ZGdRQ10lSRemMwRaE5o2vg/c3ee51e3\u002D2885\u002D4073\u002Dbc8c\u002De2bea41a36b2',
  defaultTitle: 'TalkHome Calling Cards',
  defaultActionURL: 'https://lab.talk\u002Dhome.co.uk',
  appKey: 'ZGdRQ10lSRemMwRaE5o2vg',
  token: 'MTpaR2RSUTEwbFNSZW1Nd1JhRTVvMnZnOjZKeFlnVjF2M3ZfejRfMktYcGpwS2hueEc1NThtODRwM2FKdDhvNWp1aWc',
  vapidPublicKey: 'BJDaXVZ_IPc8BYczwu-56ZfjfJwP1M-kvftT6DfTDCMknbN7qFsJ2TvKuH81Ys1h32KFeZT7EgO3lMspSgtdHD4='
})
