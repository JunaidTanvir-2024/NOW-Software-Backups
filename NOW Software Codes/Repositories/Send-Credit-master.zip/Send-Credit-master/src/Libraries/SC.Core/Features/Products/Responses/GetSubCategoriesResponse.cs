﻿using System.Text.Json.Serialization;
namespace SC.Core.Features.Products;
public sealed class GetSubCategoriesResponse
{
    [JsonPropertyName("categoryAliasName")]
    public string? CategoryAliasName { get; set; } = default!;
    [JsonPropertyName("subCategoryObj")]
    public SubCategory SubCategoryObj { get; set; } = default!;

    public sealed record SubCategory
    {
        [JsonPropertyName("subCategoryId")]
        public long SubCategoryId { get; set; } = default!;
        [JsonPropertyName("subCategoryName")]
        public string? SubCategoryName { get; set; } = default!;
        [JsonPropertyName("subCategoryShortCode")]
        public string? SubCategoryShortCode { get; set; } = default!;
        [JsonPropertyName("subCategoryDescription")]
        public string? SubCategoryDescription { get; set; } = default!;
    }

}

