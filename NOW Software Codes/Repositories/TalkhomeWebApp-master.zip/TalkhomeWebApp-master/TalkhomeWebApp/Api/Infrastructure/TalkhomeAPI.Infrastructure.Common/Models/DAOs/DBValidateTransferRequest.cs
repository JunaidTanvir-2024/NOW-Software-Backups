﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBValidateTransferRequest
    {
        public string FromCountryCode { get; set; }
        public string ToCountryCode { get; set; }
        public string UserCurrency { get; set; }
        public string AccountId { get; set; }
        public decimal TotalAmount { get; set; }
        public string FromMsisdn { get; set; }
    }
}
