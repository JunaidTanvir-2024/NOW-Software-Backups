﻿using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerCard.Request;
public sealed class AddCustomerCardRequest : IRequest<IResultWrapper>
{
    public string UserId { get; set; } = default!;
    public string Pan { get; set; } = default!;
    public string NameOnCard { get; set; } = default!;
    public string CardType { get; set; } = default!;
    public string Expiry { get; set; } = default!;
    public bool IsDefault { get; set; } = default!;
}
public sealed class AddCustomerCardRequestValidator : AbstractValidator<AddCustomerCardRequest>
{
    public AddCustomerCardRequestValidator(IHelperService helperService)
    {
        RuleFor(x => x.Expiry)
         .NotNull()
         .NotEmpty()
         .Must(helperService.BeValidCardExpiryDate)
         .WithMessage("Invalid card expiry date format. Use MMYY format.");

    }
    
}
