﻿using Microsoft.Extensions.Configuration;
using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Models.Dtos.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Infrastructure.Persistence.Repositories;
internal sealed class SystemConfigurationRepository : ISystemConfigurationRepository
{
    private readonly IConfiguration _configuration;
    private readonly ILogger _logger;

    public SystemConfigurationRepository(IConfiguration configuration, ILogger logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<OrderLimitConfigurationDto> GetOrderLimitConfigurationAsync(string? currency)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@p_currency", currency);


                return await connection.QueryFirstOrDefaultAsync<OrderLimitConfigurationDto>(AppConstants.StoreProcedures.GetOrderLimitConfiguration, parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.Error("GetOrderLimitConfigurationAsync, " +
                                "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                "StackTrace: " + ex.StackTrace);
                return default;
            }
        }
    }
}

