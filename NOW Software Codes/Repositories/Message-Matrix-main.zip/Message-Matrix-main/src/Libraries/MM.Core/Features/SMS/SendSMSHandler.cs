using MM.Core.Common.Definitions.Constants;

using Microsoft.AspNetCore.Http;

using MM.Core.Common.Interfaces.Services;
using MM.Core.Features.SMS.Request;
using MM.Core.Common.Interfaces.Database;
using Microsoft.Extensions.Configuration;
using MM.Core.Common.Definitions.Enums;
namespace MM.Core.Features.SMS;


public class SendSMSHandler : IRequestHandler<SendSMSRequest, IResultWrapper>
{
    private readonly ISMSService _sMSService;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ISmsLogRepository _smsLogRepository;
    private readonly IConfiguration? _configuration;
    public SendSMSHandler(ISMSService sMSService, IHttpContextAccessor httpContextAccessor,
        ISmsLogRepository smsLogRepository, IConfiguration configuration)
    {
        _sMSService = sMSService;
        _httpContextAccessor = httpContextAccessor;
        _smsLogRepository = smsLogRepository;
        _configuration = configuration;
    }

    public async Task<IResultWrapper> Handle(SendSMSRequest request, CancellationToken cancellationToken)
    {
        if (request == null)
        {
            return await HandleError("Invalid Request");
        }
        if (string.IsNullOrEmpty(request.To) == true)
        {
            return await HandleError("Receiver is Required");
        }
        if (string.IsNullOrEmpty(request.message) == true)
        {
            return await HandleError("Message is Required");
        }
        string? enumVal = Enum.GetName(typeof(RequestType), request.RequestType);

        if (enumVal != "MarketingSms" && enumVal != "TwilioSms")
        {
            return await HandleError("Invalid request type");
        }
        if (enumVal == "MarketingSms")
        {
            return await HandleMarketingSms(request, cancellationToken);
        }

        return await HandleTwilioSms(request, cancellationToken);
    }
    private async Task<IResultWrapper> HandleTwilioSms(SendSMSRequest request, CancellationToken cancellationToken)
    {
        var result = await _sMSService.SendTwilioSms(new SmsRequestDTO { To = request.To, TextMessage = request.message, ProductCode = request.ProductCode, Requestid = request.RequestID });
        return result ? ResultWrapper.Success("Message send successfully", AppConstants.StatusCodes.Success) : ResultWrapper.Failure("Message not Send");
    }
    private async Task<IResultWrapper> HandleMarketingSms(SendSMSRequest request, CancellationToken cancellationToken)
    {
        request.To = request.To.Replace("+44", "0");
        var requestedDate = DateTime.UtcNow.AddHours(-24);
        var allowedSMSPerUser = Convert.ToInt16(_configuration?.GetSection("AllowedMarketingSMS").Value);
        var sentMessageCount = await _smsLogRepository.GetMessageCount(request.To, request.message, requestedDate);
        if (sentMessageCount >= allowedSMSPerUser)
        {
            return await HandleError("Limit Reached");
        }
        var result = await _sMSService.SendMarketingSms(new SmsRequestDTO { To = request.To, TextMessage = request.message, ProductCode = request.ProductCode, Requestid = request.RequestID });
        return result ? ResultWrapper.Success("Message send successfully", AppConstants.StatusCodes.Success) : ResultWrapper.Failure("Message not Send");
    }
    private async Task<IResultWrapper> HandleError(string errorMsg)
    {
        return ResultWrapper.Failure(errorMsg);
    }
}

