﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransfertoDataBundleProductList
    {
        public List<object> fixed_value_vouchers { get; set; }
        public List<FixedValueRecharge> fixed_value_recharges { get; set; }
        public List<object> variable_value_payments { get; set; }
        public List<object> fixed_value_payments { get; set; }
        public List<object> variable_value_vouchers { get; set; }
        public List<object> variable_value_recharges { get; set; }
    }

    public class FixedValueRecharge
    {
        public int product_id { get; set; }
        public string product_name { get; set; }
        public string product_short_desc { get; set; }
        public int operator_id { get; set; }
        public string @operator { get; set; }
        public int country_id { get; set; }
        public string country { get; set; }
        public int service_id { get; set; }
        public string service { get; set; }
        public string account_currency { get; set; }
        public double wholesale_price { get; set; }
        public double retail_price { get; set; }
        public int fee { get; set; }
        public string product_currency { get; set; }
        public int product_value { get; set; }
        public string local_currency { get; set; }
        public int local_value { get; set; }
    }

   
}
