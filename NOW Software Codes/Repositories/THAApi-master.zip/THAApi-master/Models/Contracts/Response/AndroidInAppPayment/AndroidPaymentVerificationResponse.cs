﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response.AndroidInAppPayment
{
	public class AndroidPaymentVerificationResponse
	{

	}
}
