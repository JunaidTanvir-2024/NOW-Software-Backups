﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class GetProductsResponseModel
    {
        public ATTOperator Operator { get; set; }
        public IEnumerable<ATTProduct> Products { get; set; }
    }

    public class ATTOperator
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Country { get; set; }
        public string NowtelTransactionReference { get; set; }
        public string IconUri { get; set; }
        public int Accessid { get; set; }
    }

    public class ATTProduct
    {
        public string ClientCurrecny { get; set; }
        public string ReceiverCurrecny { get; set; }
        public string Product { get; set; }
        public string ItemPriceClientCurrency { get; set; }
        public string TransactionFeeClientCurrency { get; set; }
        public string TotalPriceClientCurrency { get; set; }
    }
}
