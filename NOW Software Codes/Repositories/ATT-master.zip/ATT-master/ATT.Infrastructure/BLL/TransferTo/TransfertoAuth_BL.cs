﻿using ATT.Models.Configurations;
using ATT.Models.Contracts.TransferTo.Request;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.TransferTo
{
    public class TransfertoAuth_BL : ITransfertoAuth_BL
    {

        private TransferToConfig TransferToConf;

        public TransfertoAuth_BL(IOptions<TransferToConfig> transferToConf)
        {
            TransferToConf = transferToConf.Value;
        }

        public string[] GetDataBundlesCredentials(string currency)
        {
            string[] Credentials = new string[] { "", "" };
            if (currency.ToUpper() == "GBP")
            {
                Credentials[0] = TransferToConf.DataBundlesApiKeyGBP;
                Credentials[1] = TransferToConf.DataBundlesApiSecretGBP;
            }
            else if (currency.ToUpper() == "EUR")
            {
                Credentials[0] = TransferToConf.DataBundlesApiKeyEUR;
                Credentials[1] = TransferToConf.DataBundlesApiSecretEUR;
            }
            else if (currency.ToUpper() == "USD") // USD
            {
                Credentials[0] = TransferToConf.DataBundlesApiKeyUSD;
                Credentials[1] = TransferToConf.DataBundlesApiSecretUSD;
            }
            return Credentials;
        }

        public string[] GetAttCredentials_TRH(string currency, string product)
        {
            string[] Credentials = new string[] { "", "" };
            if (product.ToUpper() == "TRH")
            {
                if (currency.ToUpper() == "GBP")
                {
                    Credentials[0] = TransferToConf.TRHUsernameGBP;
                    Credentials[1] = TransferToConf.TRHAppTokenGBP;
                }
                else if (currency.ToUpper() == "EUR")
                {
                    Credentials[0] = TransferToConf.TRHUsernameEUR;
                    Credentials[1] = TransferToConf.TRHAppTokenEUR;
                }
                else if (currency.ToUpper() == "USD")  // USD
                {
                    Credentials[0] = TransferToConf.TRHUsernameUSD;
                    Credentials[1] = TransferToConf.TRHAppTokenUSD;
                }
            }
            else
            {
                if (currency.ToUpper() == "GBP")
                {
                    Credentials[0] = TransferToConf.AttUsernameGBP;
                    Credentials[1] = TransferToConf.AttAppTokenGBP;
                }
                else if (currency.ToUpper() == "EUR")
                {
                    Credentials[0] = TransferToConf.AttUsernameEUR;
                    Credentials[1] = TransferToConf.AttAppTokenEUR;
                }
                else if (currency.ToUpper() == "USD")  // USD
                {
                    Credentials[0] = TransferToConf.AttUsernameUSD;
                    Credentials[1] = TransferToConf.AttAppTokenUSD;
                }
            }
            return Credentials;
        }

        public string[] GetAttCredentials(string currency, string product)
        {
            string[] Credentials = new string[] { "", "" };

            if (currency.ToUpper() == "GBP")
            {
                Credentials[0] = TransferToConf.AttUsernameGBP;
                Credentials[1] = TransferToConf.AttAppTokenGBP;
            }
            else if (currency.ToUpper() == "EUR")
            {
                Credentials[0] = TransferToConf.AttUsernameEUR;
                Credentials[1] = TransferToConf.AttAppTokenEUR;
            }
            else if (currency.ToUpper() == "USD")  // USD
            {
                Credentials[0] = TransferToConf.AttUsernameUSD;
                Credentials[1] = TransferToConf.AttAppTokenUSD;
            }

            return Credentials;
        }

        public string[] GetAttCredentials(string currency, long? sourceMSISDN = null)
        {
            string[] Credentials = new string[] { "", "" };
            if (currency.ToUpper() == "GBP")
            {
                Credentials[0] = TransferToConf.AttUsernameGBP;
                Credentials[1] = TransferToConf.AttAppTokenGBP;
            }
            else if (currency.ToUpper() == "EUR")
            {
                if (sourceMSISDN != null && sourceMSISDN.ToString().StartsWith("30"))
                {
                    Credentials[0] = TransferToConf.AttUsernameEUR_GR;
                    Credentials[1] = TransferToConf.AttAppTokenEUR_GR;
                }
                else
                {
                    Credentials[0] = TransferToConf.AttUsernameEUR;
                    Credentials[1] = TransferToConf.AttAppTokenEUR;
                }

            }
            else if (currency.ToUpper() == "USD")  // USD
            {
                Credentials[0] = TransferToConf.AttUsernameUSD;
                Credentials[1] = TransferToConf.AttAppTokenUSD;
            }
            return Credentials;
        }

        public TransfertoBaseRequest getAuthJSONObject_TRH(string currency, string product)
        {
            TransfertoBaseRequest auth = new TransfertoBaseRequest();
            string[] Credentials = GetAttCredentials_TRH(currency, product);
            auth.login = Credentials[0];
            auth.key = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
            auth.md5 = getMD5Text(auth.login + Credentials[1] + auth.key.ToString());
            return auth;
        }

        public TransfertoBaseRequest getAuthJSONObject(string currency, string product, bool isLCR)
        {
            TransfertoBaseRequest auth = new TransfertoBaseRequest();
            string[] Credentials = GetAttCredentials(currency, product);
            auth.login = Credentials[0];
            auth.key = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
            auth.md5 = getMD5Text(auth.login + Credentials[1] + auth.key.ToString());
            return auth;
        }

        public TransfertoBaseRequest getAuthJSONObject(string currency, long? sourceMSISDN = null)
        {
            TransfertoBaseRequest auth = new TransfertoBaseRequest();
            string[] Credentials = GetAttCredentials(currency, sourceMSISDN);
            auth.login = Credentials[0];
            auth.key = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
            auth.md5 = getMD5Text(auth.login + Credentials[1] + auth.key.ToString());
            return auth;
        }

        public TransfertoBaseRequest getAuthJSONObject(string currency, long key, long? sourceMSISDN = null)
        {
            TransfertoBaseRequest auth = new TransfertoBaseRequest();
            string[] Credentials = GetAttCredentials(currency, sourceMSISDN);
            auth.login = Credentials[0];
            auth.key = key;
            auth.md5 = getMD5Text(auth.login + Credentials[1] + auth.key.ToString());
            return auth;
        }
        public TransfertoBaseRequest getAuthJSONObject_TRH(string currency, long key, string productCode)
        {
            TransfertoBaseRequest auth = new TransfertoBaseRequest();

            string[] Credentials = GetAttCredentials_TRH(currency, productCode);
            auth.login = Credentials[0];
            auth.key = key;
            auth.md5 = getMD5Text(auth.login + Credentials[1] + auth.key.ToString());
            return auth;
        }
        // For FreeSwitch Daemon
        public TransfertoBaseRequest getFreeSwitchAuthJSONObject()
        {
            TransfertoBaseRequest auth = new TransfertoBaseRequest();
            auth.login = TransferToConf.AttFreeSwitchUsernameEUR;
            auth.key = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
            auth.md5 = getMD5Text(auth.login + TransferToConf.AttFreeSwitchAppTokenEUR + auth.key.ToString());
            return auth;
        }

        // For FreeSwitch Daemon
        public TransfertoBaseRequest getFreeSwitchAuthJSONObject(long key)
        {
            TransfertoBaseRequest auth = new TransfertoBaseRequest();
            auth.login = TransferToConf.AttFreeSwitchUsernameEUR;
            auth.key = key;
            auth.md5 = getMD5Text(auth.login + TransferToConf.AttFreeSwitchAppTokenEUR + auth.key.ToString());
            return auth;
        }




        private string getMD5Text(string str)
        {
            StringBuilder hash = new StringBuilder();
            MD5CryptoServiceProvider md5provider = new MD5CryptoServiceProvider();
            byte[] bytes = md5provider.ComputeHash(new UTF8Encoding().GetBytes(str));

            for (int i = 0; i < bytes.Length; i++)
            {
                hash.Append(bytes[i].ToString("x2"));
            }
            return hash.ToString();
        }

        // Good and Servcies Api Request Message

        public HttpRequestMessage HttpRequestMessage(string currency, string url, HttpMethod method = null, HttpContent content = null)
        {
            string[] Credentials = GetDataBundlesCredentials(currency);
            string api_key = Credentials[0]; //"e97dfe52-17e4-491b-8c68-b4a68a8d5e7b";
            string api_secret = Credentials[1]; //"3a066b0e-0bff-446d-be01-67c5cdf9add8";

            int epoch = (int)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds;
            string nonce = epoch.ToString();
            string message = api_key + nonce;

            System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
            byte[] keyByte = encoding.GetBytes(api_secret);
            HMACSHA256 hmac = new HMACSHA256(keyByte);
            byte[] messageBytes = encoding.GetBytes(message);
            byte[] hashmessage = hmac.ComputeHash(messageBytes);

            string hmac_base64 = Convert.ToBase64String(hashmessage);
            //Console.WriteLine("Hash Base64 code is " + hmac_base64);
            if (method == null)
                method = HttpMethod.Get;
            HttpRequestMessage request = new HttpRequestMessage(method, url);
            request.Headers.Add("X-TransferTo-apikey", api_key);
            request.Headers.Add("X-TransferTo-nonce", nonce);
            request.Headers.Add("X-TransferTo-hmac", hmac_base64);
            if (content != null)
            {
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                request.Content = content;
            }

            return request;
        }





    }
}
