﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.DbConnections;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class Channel_DL : IChannel_DL
    {

        private IDbConnectionSettings DefaultConnection;
        private ILogger Logger;

        public Channel_DL(IOptions<ConnectionStrings> connectionConfig, ILogger logger)
        {

            DefaultConnection = new DbConnectionSettings(new SqlConnection(connectionConfig.Value.DefaultConnection));
            Logger = logger;
        }

        public async Task<GenericResult<bool>> AddChannel(Channel channel, string productCode)
        {

            string logParameters = $" productCode: {productCode}, {JsonConvert.SerializeObject(channel)} ";
            try
            {

                var parameter = new DynamicParameters();
                parameter.Add("@channel_id", channel.channel_id);
                parameter.Add("@device_type_id", (int)channel.device_type);
                parameter.Add("@product_code", productCode);
                parameter.Add("@installed", channel.installed);
                parameter.Add("@last_registration", channel.last_registration);
                parameter.Add("@opt_in", channel.opt_in);
                parameter.Add("@commercial_opted_in", channel.commercial_opted_in);
                parameter.Add("@push_address", channel.push_address);
                string deviceOs = (channel.device_attributes == null ? null : channel.device_attributes.ua_device_os);
                parameter.Add("@device_os", deviceOs);
                string device_country = (channel.device_attributes == null ? null : channel.device_attributes.ua_country);
                parameter.Add("@device_country", device_country);
                string device_model = (channel.device_attributes == null ? null : channel.device_attributes.ua_device_model);
                parameter.Add("@device_model", device_model);
                string device_local_timezone = (channel.device_attributes == null ? null : channel.device_attributes.ua_local_tz);
                parameter.Add("@device_local_timezone", device_local_timezone);
                string device_app_version = (channel.device_attributes == null ? null : channel.device_attributes.ua_app_version);
                parameter.Add("@device_app_version", device_app_version);
                string device_language = (channel.device_attributes == null ? null : channel.device_attributes.ua_language);
                parameter.Add("@device_language", device_language);
                string device_sdk_version = (channel.device_attributes == null ? null : channel.device_attributes.ua_sdk_version);
                parameter.Add("@device_sdk_version", device_sdk_version);
                string device_carrier = (channel.device_attributes == null ? null : channel.device_attributes.ua_carrier);
                parameter.Add("@device_carrier", device_carrier);

                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_AddChannel", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Channel_DL, Method: AddChannel, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }

        public async Task<GenericResult<bool>> AddChannelTags(AddChannelTagsRequest request)
        {

            string logParameters = $" {JsonConvert.SerializeObject(request)} ";
            try
            {
                DataTable tblTags = new DataTable();
                tblTags.Columns.Add("tag_name", typeof(string));
                for (int i = 0; i < request.Tags.Count; i++)
                {
                    DataRow row = tblTags.NewRow();
                    row["tag_name"] = request.Tags[i];
                    tblTags.Rows.Add(row);
                }
                var parameter = new DynamicParameters();
                parameter.Add("@channel_tag_group", request.TagGroup);
                parameter.Add("@channel_tags", tblTags.AsTableValuedParameter("dbo.ChannelTagsType"));
                parameter.Add("@product_code", request.ProductCode);
                parameter.Add("@channel_id", request.ChannelId);
                parameter.Add("@device_type_id", (int)request.DeviceType);             

                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_AddChannelTags", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Channel_DL, Method: AddChannelTags, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }

    }
}
