﻿using MapsterMapper;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.CustomerOrder.Responses;
using SC.Core.Features.Products;
using SC.Core.Features.Products.Requests;
using SC.Core.Features.Products.Responses;
using SC.Core.Vendors.FusionHub;
using Sentry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder;
internal sealed class GetCustomerCartHandler : IRequestHandler<GetCustomerCartRequest, IResultWrapper>
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly IFusionHubService _fusionHubService;
    private readonly ICustomerOrderService _customerOrderService;
    public GetCustomerCartHandler(ICustomerCartRespository customerCartRespository, IMapper mapper, ICommonService commonService, IFusionHubService fusionHubService, ICustomerOrderService customerOrderService)
    {
        _customerCartRespository = customerCartRespository;
        _mapper = mapper;
        _commonService = commonService;
        _fusionHubService = fusionHubService;
        _customerOrderService = customerOrderService;
    }
    public async Task<IResultWrapper> Handle(GetCustomerCartRequest request, CancellationToken cancellationToken)
    {
        string Order_userID = string.Empty;
        if (request.IsGuestUser)
            Order_userID = request.UserID!;
        else
            Order_userID = _commonService.GetUserID();

        if (string.IsNullOrEmpty(Order_userID))
            return ResultWrapper.Failure(AppConstants.StatusKeys.UserNotProvided, 404);

        var response = await _customerCartRespository.GetCustomerCart(Order_userID);
        var productresult = _mapper.Map<List<GetCustomerCartResponse>>(response);
        var productStatus = string.Empty;
        var productstatusRequest = new GetProductStatusRequest() { ProductIds = new List<long>() };
        foreach (var product in productresult)
        {

            if (!productstatusRequest.ProductIds.Contains(product.ProductId))
                productstatusRequest.ProductIds.Add(product.ProductId);
        }
        var productresponse = await _fusionHubService.GetProductsStatusAsync(productstatusRequest);
        if (productresponse?.Payload == null)
        {
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
        }
        var productResult = _mapper.Map<List<GetProductStatusResponse>>(productresponse.Payload);

        foreach (var product in productresult)
        {

            var systemproduct = productResult.FirstOrDefault(x => x.Product.Id == product.ProductId);
            if (systemproduct != null)
            {
                product.ProductStatus = (systemproduct?.IsActive != null && systemproduct.IsActive.ToUpper() == true.ToString().ToUpper()) ? AppEnums.CartItemState.Cart.Getkey() : AppEnums.CartItemState.NoLongerExist.Getkey();

            }
            else
                product.ProductStatus = AppEnums.CartItemState.NoLongerExist.Getkey();
        }
        GetCustomerCartResponseRapper cartResponse = new GetCustomerCartResponseRapper();
        cartResponse.CustomerCart = productresult;
        cartResponse.UserID = productresult?.FirstOrDefault()?.UserID!;
        cartResponse.TotalOrderPrice = productresult?.FirstOrDefault()?.TotalOrderPrice ?? 0;
        cartResponse.TotalServiceFeeAmount = productresult?.Sum(t=>t.ServiceFeeAmount) ?? 0;
        return ResultWrapper.Success(cartResponse);

    }
}

