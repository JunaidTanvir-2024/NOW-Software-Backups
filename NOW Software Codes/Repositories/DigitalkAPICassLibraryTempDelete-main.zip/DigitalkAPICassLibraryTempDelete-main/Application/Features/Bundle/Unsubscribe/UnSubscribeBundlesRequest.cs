
namespace Application.Features.Bundle.Bundle;

public sealed class UnSubscribeBundlesRequest : IRequest<Result<bool>>
{
    public string Msisdn { get; set; }
    public string PackageId { set; get; }
}