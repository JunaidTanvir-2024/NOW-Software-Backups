﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder.Responses;
public sealed class AddCustomerAddressResponse
{
    public long CustomerAddressID { get; set; } = default!;
}

