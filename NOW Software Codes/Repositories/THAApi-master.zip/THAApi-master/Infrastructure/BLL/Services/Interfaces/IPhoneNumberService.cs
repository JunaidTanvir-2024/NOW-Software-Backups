﻿namespace Infrastructure.BLL.Services.Interfaces
{
    public interface IPhoneNumberService
    {
        string GetFullNumber(string originator, string contact);

        string GetCountry(string originator);
        string GetCountryIsoCode(string msisdn);
    }
}