using DC.Core.Common.Definitions;
using DC.Core.Common.Entities;
using DC.Core.Common.Extensions;
using DC.Core.Common.Interfaces.Database;
using DC.Core.Features.Notifications.Requests;

namespace DC.Infrastructure.Persistence.Repositories;

internal sealed class DigiConnectRepository(IConfiguration configuration, ILogger logger) : IDigiConnectRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private readonly ILogger _logger = logger;

    public async Task <List<ActiveMsisdnEntity>> GetNewRegisteredMsisdn()
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.DigiConnect)))
            {
                var parameters = new DynamicParameters(); 
                var resp = await connection.QueryAsync<ActiveMsisdnEntity>(AppConstants.Database.StoreProcedure.GetActiveMsisdn, parameters, commandType: CommandType.StoredProcedure);
                var response = resp.ToList();
                return response;
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(DigiConnectRepository), nameof(GetNewRegisteredMsisdn));
            return default;
        }
    }

    public async Task UpsertNewRegisteredMsisdn(ActiveMsisdnEntity request)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.DigiConnect)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@sim_state", request.SimState);
                parameters.Add("@sim_activation_datetime_utc", request.SimStateUpdated);
                parameters.Add("@msisdn", request.Msisdn);
                parameters.Add("@is_active", request.IsActive);
                parameters.Add("@is_fulfilled", request.IsFulfilled);
                parameters.Add("@account", request.AccountId);
                parameters.Add("@activation_Date", request.ActiveDate);
                parameters.Add("@created_on", request.CreatedOn);
                parameters.Add("@created_by", request.CreatedBy);
                parameters.Add("@modified_on", request.ModifiedOn);
                parameters.Add("@modified_by", request.ModifiedBy);
                parameters.Add("@product_type", request.Product);

                await connection.ExecuteAsync(AppConstants.Database.StoreProcedure.InsertActiveMsisdn, parameters, commandType: CommandType.StoredProcedure);
            }
        }
         catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(DigiConnectRepository), nameof(UpsertNewRegisteredMsisdn));
        }
    }

    public async Task<List<SmsDetails>> GetMessageContent(string type)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.DigiConnect)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@category",type);

                return (await connection.QueryAsync<SmsDetails>(AppConstants.Database.StoreProcedure.GetSmsContent, parameters, commandType: CommandType.StoredProcedure)).ToList();

            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(DigiConnectRepository), nameof(GetMessageContent));
            return default;
        }
    }

    public async Task<List<ActiveMsisdnLog>> GetActiveMsisdnLog(DateTime created, string cadence)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.DigiConnect)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@created_on", created);
                parameters.Add("@cadence", cadence);

                return (await connection.QueryAsync<ActiveMsisdnLog>(AppConstants.Database.StoreProcedure.GetActiveMsisdnLog, parameters, commandType: CommandType.StoredProcedure)).ToList();

            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(DigiConnectRepository), nameof(GetActiveMsisdnLog));
            return default;
        }
    }

    public async Task AddSendSMSLog(SendSMSLog request)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.DigiConnect)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@parm_sms_category_id", request.SmsCategoryId);
                parameters.Add("@param_sms_request", request.SmsRequest);
                parameters.Add("@param_sms_sent_status", request.SMSSentStatus);
                parameters.Add("@param_created_on", request.CreatedOn);
                parameters.Add("@param_created_by", request.CreatedBy);
                parameters.Add("@param_msisdn", request.Msisdn);
                parameters.Add("@param_cadence", request.Cadence);
                await connection.ExecuteAsync(AppConstants.Database.StoreProcedure.AddSendSMSLog, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(DigiConnectRepository), nameof(GetNewRegisteredMsisdn));
        }
    }

    public async Task<List<GetNewTopUp>> GetNewTopUp(DateTime created, string cadence)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.DigiConnect)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@created_on", created);
              

                return (await connection.QueryAsync<GetNewTopUp>(AppConstants.Database.StoreProcedure.GetNewTopUp, parameters, commandTimeout: 180, commandType: CommandType.StoredProcedure)).ToList();

            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(DigiConnectRepository), nameof(GetNewTopUp));
            return default;
        }
    }

    public async Task<List<GetMsisdnWithNoPlan>> GetMsisdnWithNoPlan(DateTime created, string cadence)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.DigiConnect)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@created_on", created);
                return (await connection.QueryAsync<GetMsisdnWithNoPlan>(AppConstants.Database.StoreProcedure.GetMsisdnWithNoPlan, parameters,commandTimeout:180, commandType: CommandType.StoredProcedure)).ToList();

            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(DigiConnectRepository), nameof(GetMsisdnWithNoPlan));
            return default;
        }
    }
}
