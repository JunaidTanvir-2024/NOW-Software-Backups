﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Serilog;
using Models.Contracts.Response;
using Models.Enums;
using Models.Contracts.Request;
using THAApi.ViewModels;
using THAApi.Utilities;
using Infrastructure.Utilities;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;
using Microsoft.Extensions.Localization;
using Infrastructure.BLL.Interfaces;
using Microsoft.CodeAnalysis.Options;
using Models.Configurations;
using Microsoft.Extensions.Options;
using ICSharpCode.Decompiler.IL;
using Infrastructure.BLL;
using Models.Contracts.Request.Voucherify;
using Models.Services.Airship;

namespace THAApi.Controllers.v2
{
    [ApiController]
    [ApiVersion("2.0")]
    [Route("v{v:apiVersion}")]
    public class Pay360v2Controller : Controller
    {
        private readonly ILogger _logger;
        private readonly IPayment_BL _paymentBL;
        private readonly IStringLocalizer _localizer;
        private readonly IHelper_BL _helper_BL;
        private readonly IUserAccount_BL _userAccount_BL;
        private readonly VoucherifyConfig _voucherifyConfig;

        public Pay360v2Controller(
            ILogger logger,
            IPayment_BL paymentBL,
            IStringLocalizer localizer,
            IHelper_BL helper_BL,
            IUserAccount_BL userAccount_BL,
            IOptions<VoucherifyConfig> option)
        {
            _logger = logger;
            _paymentBL = paymentBL;
            _localizer = localizer;
            _helper_BL = helper_BL;
            _userAccount_BL = userAccount_BL;
            _voucherifyConfig = option.Value;
        }

        [HttpPost]
        [Route("Pay360/NewCustomerPayment")]
        public async Task<IActionResult> NewCustomerPayment([FromBody] NewCustomerPaymentRequestModelV2 model)
        {
            try
            {
                if (string.IsNullOrEmpty(model.DiscountCode))
                {
                    model.DiscountCode = null;
                    model.DiscountCodeType = DiscountCodeType.None;
                }

                if (model.CheckoutType != CheckOutTypes.Bundle && model.CheckoutType != CheckOutTypes.TopUp)
                {
                    return Ok(GenericApiResponse<object>.Failure("This endpoint is only for topup and bundle", ApiStatusCodes.BadRequest));
                }

                string advertiserID = HttpContext.GetAdvertiserID();
                var response = await _paymentBL.NewCustomerPaymentV2Async(
                    model,
                    User.Msisdn(),
                    User.Currency(),
                    HttpContext.GetRemoteIPAddress(),
                    User.Email(),
                    advertiserID);

                if (response.ErrorCode == 0)
                {
                    string paymentMethodViewData = await PrepareSuccessHtml(response.Payload, model.UtmParamsInfo, HttpContext.ThemeMode(), model.DiscountCodeType);
                    return Ok(GenericApiResponse<object>.Success(new { html = paymentMethodViewData }, ""));
                }

                if (response.ErrorCode == (int)ApiStatusCodes.Pending3dSecure)
                {
                    string Secure3dResponseView = "";

                    if (response.Payload.threeDSecureData.type.Equals("v1", StringComparison.InvariantCultureIgnoreCase))
                    {
                        var resume3dViewModel = new Resume3DV1ViewModel()
                        {
                            Pareq = response.Payload.threeDSecureData.pareq,
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                        };
                        resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
                        Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV1Page, resume3dViewModel, false);
                    }
                    else
                    {
                        var resume3dViewModel = new Resume3DV2ViewModel()
                        {
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                            ThreeDSServerTransId = response.Payload.threeDSecureData.threeDSServerTransId
                        };
                        resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
                        Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV2Page, resume3dViewModel, false);
                    }
                    return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, ""));
                }

                var resp = GenericApiResponse<object>.Failure(null, response.Message, ApiStatusCodes.UnSuccessful);

                return Ok(resp);
            }
            catch (Exception ex)
            {
                if (model.CardInfo != null)
                {
                    model.CardInfo.NameOnCard = "";
                    model.CardInfo.CardNumber = "";
                    model.CardInfo.SecurityCode = "";
                    model.CardInfo.ExpiryDate = "";
                }

                _logger.Error($"Class: Pay360Controller, " +
                              $"Method: NewCustomerPayment, " +
                              $"Request:{JsonConvert.SerializeObject(model)}, " +
                              $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
                              $"StackTrace: {ex.StackTrace}");

                var resp = GenericApiResponse<object>.Failure(
                    null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

                return Ok(resp);
            }
        }

        [HttpPost]
        [Route("Pay360/ExistingCardPayment")]
        public async Task<IActionResult> ExistingCardPayment([FromBody] ExistingCardPaymentRequestModelV2 model)
        {
            try
            {
                if (model.CheckoutType != CheckOutTypes.Bundle && model.CheckoutType != CheckOutTypes.TopUp)
                {
                    return Ok(GenericApiResponse<object>.Failure("This endpoint is only for topup and bundle", ApiStatusCodes.BadRequest));
                }
                if (string.IsNullOrEmpty(model.DiscountCode))
                {
                    model.DiscountCode = null;
                    model.DiscountCodeType = DiscountCodeType.None;
                }
                string advertiserID = HttpContext.GetAdvertiserID();
                var response = await _paymentBL.ExistingCardPaymentV2Async(
                    model,
                    User.Msisdn(),
                    User.Currency(),
                    HttpContext.GetRemoteIPAddress(),
                    User.Email(),
                    advertiserID);

                if (response.ErrorCode == 0)
                {
                    string paymentMethodViewData = await PrepareSuccessHtml(response.Payload, model.UtmParamsInfo, HttpContext.ThemeMode(), model.DiscountCodeType);
                    return Ok(GenericApiResponse<object>.Success(new { html = paymentMethodViewData }, ""));
                }

                if (response.ErrorCode == (int)ApiStatusCodes.Pending3dSecure)
                {
                    string Secure3dResponseView = "";

                    if (response.Payload.threeDSecureData.type.Equals("v1", StringComparison.InvariantCultureIgnoreCase))
                    {
                        var resume3dViewModel = new Resume3DV1ViewModel()
                        {
                            Pareq = response.Payload.threeDSecureData.pareq,
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                        };
                        resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
                        Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV1Page, resume3dViewModel, false);
                    }
                    else
                    {
                        var resume3dViewModel = new Resume3DV2ViewModel()
                        {
                            ReturnUrl = response.Payload.threeDSecureData.returnUrl,
                            Url = response.Payload.threeDSecureData.redirectUrl,
                            TransactionId = response.Payload.threeDSecureData.transactionId,
                            ThreeDSServerTransId = response.Payload.threeDSecureData.threeDSServerTransId
                        };
                        resume3dViewModel.ReturnUrl += $"&ThemeMode={HttpContext.ThemeMode()}";
                        resume3dViewModel.ReturnUrl += $"&advertiserID={HttpContext.GetAdvertiserID()}";
                        Secure3dResponseView = await this.RenderViewAsync(Pages.Resume3DV2Page, resume3dViewModel, false);
                    }
                    return Ok(GenericApiResponse<object>.Success(new { html = Secure3dResponseView }, ""));
                }

                var resp = GenericApiResponse<object>.Failure(null, response.Message, ApiStatusCodes.UnSuccessful);

                return Ok(resp);
            }
            catch (Exception ex)
            {
                model.SecurityCode = "";

                _logger.Error($"Class: Pay360Controller, " +
                              $"Method: ExistingCardPayment, " +
                              $"Request:{JsonConvert.SerializeObject(model)}, " +
                              $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
                              $"StackTrace: {ex.StackTrace}");

                var resp = GenericApiResponse<object>.Failure(
                    null, _localizer["SomethingWentWrong"], ApiStatusCodes.InternalServerError);

                return Ok(resp);
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        [Route("Pay360/Resume3DTransaction"), HttpPost]
        public async Task<IActionResult> Resume3DTransaction([FromQuery] Resume3DPaymentDataRequestV2 data,
                                                             [FromForm] Resume3DPaymentRequest request)
        {
            try
            {
                HttpContext.Request.Headers["AirshipEventsDisable"] = data.airshipEventsDisable ? "1" : "0";
                if (string.IsNullOrEmpty(data.DiscountCode))
                {
                    data.DiscountCode = null;
                    data.DiscountCodeType = DiscountCodeType.None;
                }
                var response = await _paymentBL.Resume3DTransactionV2Async(request, data);
                if (response.ErrorCode > 0)
                    return View(Pages.ErrorPageV2, new ErrorViewModel()
                    {
                        Message = response.Message,
                        ThemeMode = data.ThemeMode,
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                        Type = data.CheckoutType,
                        BundlePurchaseInfo = response.Payload?.bundlePurchaseInfo,
                        Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn)
                    });

                if (response.Payload.topupInfo != null)
                {
                    var successviewModel = new SuccessViewModel()
                    {
                        Type = SuccessViewModel.CheckoutType.Topup,
                        ThemeMode = data.ThemeMode,
                        Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn),
                        UtmParamsInfo = new UtmParamsInfo()
                        {
                            utm_campaign = data.UtmCampaign,
                            utm_medium = data.UtmMedium,
                            utm_source = data.UtmSource
                        },
                        CustomerMsisdn = data.CustomerMsisdn,
                        TransactionId = request.MD,
                        TopupInfo = new SuccessViewModel.Topup()
                        {
                            Amount = response.Payload.topupInfo.TopupAmount,
                            Currency = response.Payload.topupInfo.Currency,
                            PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                            UpdatedBalance = response.Payload.topupInfo.NewBalance
                        },

                        // Done
                        VoucherifyInfo = Utility.GetVoucherifyInfo(response.Payload.CampaignName, CheckOutTypes.TopUp, data.DiscountCodeType, isFirstTopup: response.Payload.topupInfo.IsFirstTopup, topupPoints: response.Payload.topupInfo.RewardPoints, isRedeemedSuccess: response.Payload.IsRedeemedSuccess),
                    };

                    return View(Pages.SuccessPage, successviewModel);
                }
                else
                {
                    var successviewModel = new SuccessViewModel()
                    {
                        Type = SuccessViewModel.CheckoutType.Bundle,
                        ThemeMode = data.ThemeMode,
                        Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn),
                        UtmParamsInfo = new UtmParamsInfo()
                        {
                            utm_campaign = data.UtmCampaign,
                            utm_medium = data.UtmMedium,
                            utm_source = data.UtmSource
                        },
                        CustomerMsisdn = data.CustomerMsisdn,
                        TransactionId = request.TransactionId,
                        BundleInfo = new SuccessViewModel.Bundle()
                        {
                            Amount = response.Payload.bundlePurchaseInfo.BundleAmount,
                            Currency = response.Payload.bundlePurchaseInfo.Currency,
                            PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                            Name = response.Payload.bundlePurchaseInfo.BundleName,
                            Type = response.Payload.bundlePurchaseInfo.Type,
                            Destination = response.Payload.bundlePurchaseInfo.Destination,
                        },

                        // Done
                        VoucherifyInfo = Utility.GetVoucherifyInfo(response.Payload.CampaignName, CheckOutTypes.Bundle, data.DiscountCodeType, isWelcomeBundle: response.Payload.bundlePurchaseInfo.Type == BundleType.Welcome, bundlePoints: response.Payload.bundlePurchaseInfo.RewardPoints, isRedeemedSuccess: response.Payload.IsRedeemedSuccess),
                    };

                    return View(Pages.SuccessPage, successviewModel);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Pay360Controller, " +
                              $"Method: Resume3DTransaction, " +
                              $"Request-request: {JsonConvert.SerializeObject(data)}, " +
                              $"Request-Data: {JsonConvert.SerializeObject(data)}, " +
                              $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
                              $"StackTrace: {ex.StackTrace}");

                return View(Pages.ErrorPageV2,
                    new ErrorViewModel()
                    {
                        Message = _localizer["SomethingWentWrong"],
                        ThemeMode = data.ThemeMode,
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                        Origination = _helper_BL.GetCountryCode(data.CustomerMsisdn),
                        Type = data.CheckoutType,
                    });
            }
        }
        [HttpGet]
        [Route("pay360/getPaymentAmounts")]
        public async Task<IActionResult> GetPaymentAmounts()
        {
            var userMsisdn = User.Msisdn();
            var userAccount = await _userAccount_BL.GetUserAccountBalance(userMsisdn);

            string accountTopupDescription = await this.RenderViewAsync(Pages.AccountTopup, userAccount, false);

            return Ok(await _paymentBL.GetPaymentAmountsV2(User.Currency(), userMsisdn, User.Email(), accountTopupDescription));
        }

        [HttpPost]
        [Route("SetAutoTopup")]
        public async Task<IActionResult> SetAutoTopup([FromBody] SetAutoTopUpRequestModel model)
        {
            return Ok(await _paymentBL.SetAutoTopUpV2(model, User.Msisdn(), User.Currency(), User.Email()));
        }

        private async Task<string> PrepareSuccessHtml(CardPaymentResponseModel response, UtmParamsInfo utmParams, ThemeMode themeMode, DiscountCodeType discountCodeType)
        {
            var successResponse = new SuccessViewModel();
            if (response.topupInfo != null)
            {
                //Topup
                successResponse.Origination = _helper_BL.GetCountryCode(response.customerMsisdn);
                successResponse.UtmParamsInfo = new UtmParamsInfo()
                {
                    utm_campaign = utmParams?.utm_campaign,
                    utm_medium = utmParams?.utm_medium,
                    utm_source = utmParams?.utm_source
                };
                successResponse.CustomerMsisdn = response.customerMsisdn;
                successResponse.TransactionId = response.transactionId;
                successResponse.ThemeMode = themeMode;
                successResponse.Type = SuccessViewModel.CheckoutType.Topup;
                successResponse.TopupInfo = new SuccessViewModel.Topup()
                {
                    Amount = response.topupInfo.TopupAmount,
                    Currency = response.topupInfo.Currency,
                    PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                    UpdatedBalance = response.topupInfo.NewBalance
                };
                successResponse.VoucherifyInfo = Utility.GetVoucherifyInfo(response.CampaignName, CheckOutTypes.TopUp, discountCodeType, topupPoints: response?.topupInfo?.RewardPoints, isRedeemedSuccess: response?.IsRedeemedSuccess);
            }
            else
            {
                //Bundle
                successResponse.Origination = _helper_BL.GetCountryCode(response.customerMsisdn);
                successResponse.UtmParamsInfo = new UtmParamsInfo()
                {
                    utm_campaign = utmParams?.utm_campaign,
                    utm_medium = utmParams?.utm_medium,
                    utm_source = utmParams?.utm_source
                };
                successResponse.CustomerMsisdn = response.customerMsisdn;
                successResponse.TransactionId = response.transactionId;
                successResponse.ThemeMode = themeMode;
                successResponse.Type = SuccessViewModel.CheckoutType.Bundle;
                successResponse.BundleInfo = new SuccessViewModel.Bundle()
                {
                    Amount = response.bundlePurchaseInfo.BundleAmount,
                    Currency = response.bundlePurchaseInfo.Currency,
                    PaymentMethod = SuccessViewModel.PaymentMehtods.Card,
                    Name = response.bundlePurchaseInfo.BundleName,
                    Type = response.bundlePurchaseInfo.Type,
                    Destination = response.bundlePurchaseInfo.Destination,
                };

                successResponse.VoucherifyInfo = Utility.GetVoucherifyInfo(response.CampaignName, CheckOutTypes.Bundle, discountCodeType, isWelcomeBundle: response?.bundlePurchaseInfo?.Type == BundleType.Welcome, bundlePoints: response?.bundlePurchaseInfo?.RewardPoints, isRedeemedSuccess: response?.IsRedeemedSuccess);
            }

            var paymentMethodViewData = await this.RenderViewAsync(Pages.SuccessPage, successResponse, false);
            return paymentMethodViewData;
        }
    }
}
