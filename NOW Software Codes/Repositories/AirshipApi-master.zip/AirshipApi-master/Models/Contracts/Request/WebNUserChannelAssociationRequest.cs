﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class WebNUserChannelAssociationRequest
    {
        [JsonProperty("ChannelId")]
        [Required]
        public string ChannelId { get; set; }

        [JsonProperty("NamedUserId")]
        [Required]
        [StringLength(maximumLength: 128, MinimumLength = 1)]
        public string NamedUserId { get; set; }

        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; }
    }
}
