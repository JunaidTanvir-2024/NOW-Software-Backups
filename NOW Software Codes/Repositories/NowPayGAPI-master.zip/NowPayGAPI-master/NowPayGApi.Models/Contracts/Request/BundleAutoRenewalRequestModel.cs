﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
   public class BundleAutoRenewalRequestModel
    {
        public string AccountId { get; set; }
        public string Uuid { get; set; }
        public string Msisdn { get; set; }
        public bool isAutoRenew { get; set; }
        public string ProductCode { get; set; }
        public string Email { get; set; }
        public int BundleAmount { get; set; }
    }
}
