namespace Application.Features.Account.Balance;

public class AccountBalanceRequestValidator : AbstractValidator<AccountBalanceRequest>
{
    public AccountBalanceRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");
    }
}
