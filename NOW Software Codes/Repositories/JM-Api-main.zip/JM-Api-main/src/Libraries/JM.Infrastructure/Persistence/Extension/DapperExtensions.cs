using System.Data;

using Dapper;

namespace JM.Infrastructure.Persistence.Extension;

public static class DapperExtensions
{
    public static (string sql, object param) BuildQueryAndParams(DynamicParameters parameters, string functionName)
    {
        var paramNames = parameters.ParameterNames.ToList();
        var param = parameters.ParameterNames.ToDictionary(name => name, name => parameters.Get<object>(name));
        string sql = $"SELECT * FROM {functionName}(";
        if (paramNames.Any())
        {
            sql += string.Join(", ", paramNames.Select(p => $"@{p}"));
        }
        sql += ")";
        return (sql, param);
    }
}
