namespace MM.Infrastructure.Services.Versioning;
public static class ConfigureApiVersioning
{
    public static IServiceCollection AddApiVersioningConfiguration(this IServiceCollection services)
    {
        services.AddApiVersioning(config =>
        {
            config.ApiVersionReader = new UrlSegmentApiVersionReader();
            config.DefaultApiVersion = new ApiVersion(1.0);
            config.AssumeDefaultVersionWhenUnspecified = true;
            config.ReportApiVersions = true;
        }).AddApiExplorer(option =>
        {
            option.GroupNameFormat = "'v'VV";
            option.FormatGroupName = (group, version) => $"{group} | {version}";
            option.SubstituteApiVersionInUrl = true;
        });

        return services;
    }
}
