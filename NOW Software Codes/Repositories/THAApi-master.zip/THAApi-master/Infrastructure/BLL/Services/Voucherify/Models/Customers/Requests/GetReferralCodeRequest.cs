﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests
{
    public class GetReferralCodeRequest
    {
        public string CampaignNameOrId { get; set; }
        public string CustomerSourceId { get; set; }
    }
}
