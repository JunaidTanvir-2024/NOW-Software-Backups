using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.SimBundle;

public sealed class SimBundleRequestHandler : IRequestHandler<SimBundleRequest, Result<List<BundleInfo>>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<SimBundleRequestHandler> _localizer;
    private readonly IMapper _mapper;

    public SimBundleRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<SimBundleRequestHandler> localizer,
        IMapper mapper)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
    }

    public async Task<Result<List<BundleInfo>>> Handle(SimBundleRequest request, CancellationToken cancellationToken)
    {
        var bundles = (await _uow.BundleRepo.GetSimBundles(request)).Where(i => i.Category != (int) BundleCategory.Affiliate).ToList();
        return Result<List<BundleInfo>>.Success(_mapper.Map<List<BundleInfo>>(bundles), _localizer[CustomStatusKey.Success]);
    }
}
