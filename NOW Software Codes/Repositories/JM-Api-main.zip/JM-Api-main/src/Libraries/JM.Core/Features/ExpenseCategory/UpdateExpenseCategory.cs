using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;
namespace JM.Core.Features.ExpenseCategory;
public abstract class UpdateExpenseCategory
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long Id { get; set; }
        public string Name { get; set; } = string.Empty;
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Name).NotEmpty().NotNull();
            RuleFor(x => x.Id).GreaterThan(0);
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            _unitOfWork.ExpenseRepository.UpdateExpenseCategory(new Entities.ExpenseCategory()
            {
                Id = query.Id,
                Name = query.Name
            });
            _unitOfWork.SaveChanges();

            return await ValueTask.FromResult(ResultWrapper.Success(AppConstant.StatusKey.Success, AppConstant.StatusCode.Success));
        }
    }
    #endregion
}
