﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace SenderService.Core.Persistence;

public static class DatabaseInitialization
{
    public static void InitializeDatabase(IServiceProvider serviceProvider)
    {
        using (var scope = serviceProvider.CreateScope())
        {
            var context = scope.ServiceProvider.GetService<SenderServiceContext>();

            context?.Database.Migrate();
        }
    }
}
