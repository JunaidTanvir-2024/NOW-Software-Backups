﻿using Models.Enums;

namespace Models.Contracts.Request.Voucherify
{
    public class ValidateReferralCodeResponse
    {
        public bool IsValid { get; set; }
        public decimal Value { get; set; }
        public string DiscountCode { get; set; }
        public DiscountType DiscountType { get; set; }
    }
}
