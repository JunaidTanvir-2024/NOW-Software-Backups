﻿
using Microsoft.AspNetCore.Http;
using SC.Infrastructure.Persistence.Repositories.DTOs;

namespace SC.Infrastructure.Persistence.Repositories;

public interface ILoggerRepository
{
    Task AppLogUpsertAsync(AppLogDto logDto);
    Task VendorLogInsertAsync(VendorLogDto vendorLogDto);
}

internal sealed class LoggerRepository : ILoggerRepository
{
    private LoggerRepository() { }

    private readonly IConfiguration? _configuration;

    public LoggerRepository(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public async Task AppLogUpsertAsync(AppLogDto appLogDto)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@request_timestamp", appLogDto.Timestamp);
                parameters.Add("@request_path", appLogDto.RequestPath);
                parameters.Add("@request_method", appLogDto.RequestMethod);
                parameters.Add("@request_body", appLogDto.RequestBody);
                parameters.Add("@response_body", appLogDto.ResponseBody);
                parameters.Add("@status_code", appLogDto.StatusCode);
                parameters.Add("@duration", appLogDto.Duration);
                parameters.Add("@client_ip", appLogDto.ClientIP);
                parameters.Add("@user_agent", appLogDto.UserAgent);
                parameters.Add("@response_size", appLogDto.ResponseSize);
                parameters.Add("@error_reason", appLogDto.ErrorReason);
                parameters.Add("@correlation_id", appLogDto.CorrelationId);
                parameters.Add("@headers", appLogDto.Headers);
                parameters.Add("@query_string", appLogDto.QueryString);
                parameters.Add("@unique_reference", appLogDto.UniqueReference);
                parameters.Add("@product_code", appLogDto.ProductCode);
                parameters.Add("@product_item_code", appLogDto.ProductItemCode);
                parameters.Add("@request_id", appLogDto.RequestID);

                await connection.ExecuteAsync(AppConstants.StoreProcedures.AppLogUpsert, parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
    public async Task VendorLogInsertAsync(VendorLogDto vendorLogDto)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
        {
            var parameters = new DynamicParameters();
            parameters.Add("@request_timestamp", vendorLogDto.Timestamp);
            parameters.Add("@request_path", vendorLogDto.RequestPath);
            parameters.Add("@request_method", vendorLogDto.RequestMethod);
            parameters.Add("@request_body", vendorLogDto.RequestBody);
            parameters.Add("@response_body", vendorLogDto.ResponseBody);
            parameters.Add("@status_code", vendorLogDto.StatusCode);
            parameters.Add("@duration", vendorLogDto.Duration);
            parameters.Add("@response_size", vendorLogDto.ResponseSize);
            parameters.Add("@error_reason", vendorLogDto.ErrorReason);
            parameters.Add("@correlation_id", vendorLogDto.CorrelationId);
            parameters.Add("@headers", vendorLogDto.Headers);
            parameters.Add("@query_string", vendorLogDto.QueryString);
            parameters.Add("@vendor_id", vendorLogDto.VendorId);
            parameters.Add("@request_id", vendorLogDto.RequestID);

            await connection.ExecuteAsync(AppConstants.StoreProcedures.VendorLogInsert, parameters, commandType: CommandType.StoredProcedure);
        }
    }
}
