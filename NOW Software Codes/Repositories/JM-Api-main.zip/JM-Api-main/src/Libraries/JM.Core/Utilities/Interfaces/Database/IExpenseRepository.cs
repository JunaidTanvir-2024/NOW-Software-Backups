using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;

public interface IExpenseRepository : ResolveAs.IScoped
{
    Task<Expense> AddExpense(Expense expense);
    void UpdateExpense(Expense expense);
    Task<Expense?> GetExpense(Expression<Func<Expense, bool>> expression);
    Task<IEnumerable<Expense>> GetExpenseList(Expression<Func<Expense, bool>> expression = default!);
    Task<ExpenseCategory> AddExpenseCategory(ExpenseCategory expense);
    void UpdateExpenseCategory(ExpenseCategory expense);
    Task<ExpenseCategory?> GetExpenseCategory(Expression<Func<ExpenseCategory, bool>> expression);
    Task<IEnumerable<ExpenseCategory>> GetExpenseCategoryList();
    ExpenseCategory RemoveExpenseCategory(ExpenseCategory expenseCategory);
}
