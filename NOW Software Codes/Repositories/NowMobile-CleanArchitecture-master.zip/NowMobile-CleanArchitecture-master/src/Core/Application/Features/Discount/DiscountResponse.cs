namespace Application.Features.Discount;

public class DiscountResponse
{
    public float Discount { get; set; }
}
