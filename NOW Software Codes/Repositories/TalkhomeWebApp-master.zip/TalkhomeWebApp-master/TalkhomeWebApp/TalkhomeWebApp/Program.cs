using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;

namespace TalkhomeWebApp
{
    public class Program
    {
        public static IConfiguration Configuration { get; set; }
        public static void Main(string[] args)
        {

            var builder = new ConfigurationBuilder()
                                .SetBasePath(Directory.GetCurrentDirectory())
                                .AddJsonFile("appsettings.json");

            Configuration = builder.Build();

            string port;
            if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == Environments.Development)
            {
                port = Configuration["HostPortDebug"];
            }
            else
            {
                port = Configuration["HostPortProduction"];
            }

            WebHost.CreateDefaultBuilder(args)
               .UseStartup<Startup>()
               .UseUrls($"http://*:{port}")
               .UseSerilog((hostingContext, config) =>
               {
                   config.ReadFrom.Configuration(hostingContext.Configuration)
                         .WriteTo.Sentry();
               })
               .UseSentry()
               .Build()
               .Run();
        }
    }
}
