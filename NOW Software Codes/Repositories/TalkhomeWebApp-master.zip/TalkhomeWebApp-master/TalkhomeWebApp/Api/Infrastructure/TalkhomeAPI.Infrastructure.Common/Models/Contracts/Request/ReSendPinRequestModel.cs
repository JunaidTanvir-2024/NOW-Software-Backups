﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class ReSendPinRequestModel
    {
        [Required(ErrorMessage = "Enter your phone-number")]
        [MaxLength(length: 50, ErrorMessage = "Maximum length exceeded")]
        public string PhoneNumber { get; set; }
        
        [Required]
        [MaxLength(length: 5, ErrorMessage = "Maximum length exceeded")]
        public string PhoneNumberCountryCode { get; set; }

        [Required]
        [MaxLength(50)]
        public string IpAddress { get; set; }
    }
}
