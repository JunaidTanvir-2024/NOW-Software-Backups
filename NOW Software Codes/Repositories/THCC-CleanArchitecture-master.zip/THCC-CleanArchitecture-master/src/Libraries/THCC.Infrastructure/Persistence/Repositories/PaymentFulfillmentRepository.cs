﻿using System.Data;

using Dapper;

using Microsoft.Extensions.Configuration;

using Serilog;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.Dtos;
using THCC.Domain.Aggregates;
using THCC.Infrastructure.Persistence.DapperConfigurations;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Infrastructure.Persistence.Repositories
{
    public class PaymentFulfillmentRepository : IPaymentFulfillmentRepository
    {
        #region Fields

        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;

        #endregion

        #region Ctors
        public PaymentFulfillmentRepository(
            ILogger logger,
            IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        #endregion

        #region Card Fulfillment Methods

        public async Task<THCCPinDto> Pay360ThccCardFullfilment(
            string transactionId,
            string amount,
            string email,
            string firstname)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", int.Parse(amount.Split('.')[0]));
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                return await DapperWrapper.QueryFirstOrDefaultAsync<THCCPinDto>(
                      StoredProcedures.Pay360ThccCardFullfilment,
                      parameters,
                      commandType: CommandType.StoredProcedure,
                      _configuration.GetConnectionString(ConnectionStrings.TalkHomeRechargeableCard));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentFullfillment.cs, Method: ThccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null!;
            }
        }

        public async Task<FullfilmentDto> Pay360ThrccCardFullfilment(
            string email,
            string firstName,
            string transactionId,
            string amount,
            string cardNumber)
        {
            var response = new FullfilmentDto();

            try
            {
                if (string.IsNullOrEmpty(cardNumber))
                {
                    var pinResponse = await GetNextRCCPin(email, firstName, transactionId);
                    if (pinResponse == null)
                    {
                        response.ErrorMessage = "Failed to get rechargable card number";
                        response.ErrorCode = -1;
                        return response;
                    }
                    cardNumber = pinResponse!.Account!.Trim();
                }

                DynamicParameters parameters = new();
                parameters.Add("@amount", amount);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@productref", cardNumber);
                parameters.Add("@thccpin", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 150);
                parameters.Add("@errorcode", null, dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 200);
                parameters.Add("@account", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 50);
                var result = await DapperWrapper.QueryFirstOrDefaultAsync<THRCCAuditDto>(
                    StoredProcedures.Pay360ThrccCardFullfilment, parameters, commandType: CommandType.StoredProcedure,
                    _configuration.GetConnectionString(ConnectionStrings.BackHome));
                if (result != null)
                {
                    var errorCode = parameters.Get<int>("@errorcode");
                    var errorMessage = parameters.Get<string>("@errormsg");
                    if (errorCode > 0)
                    {
                        response.ErrorMessage = errorMessage;
                        response.ErrorCode = errorCode;
                    }
                    else
                    {
                        response.AuditId = result.audit_id.ToString();
                        if (result?.new_balance > 0)
                        {
                            var newBalance = Math.Round(Convert.ToDecimal(result?.new_balance / 100), 2);
                            response.NewBalance = newBalance.ToString();
                        }
                        response.CardNumber = parameters.Get<string>("@account").Trim();
                        response.PinNumber = parameters.Get<string>("@thccpin").Trim();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentFullfillment, Method: Pay360ThrccCardFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, cardNumber: {cardNumber}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                response.ErrorMessage = ex.Message;
                response.ErrorCode = -1;
            }

            return response;
        }



        public async Task<FullfilmentDto> ThrccCustomerFullfilment(string transactionId, string amount, string productRef)
        {

            FullfilmentDto response = new();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@amount", amount);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@productref", productRef);
                parameters.Add("@thccpin", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 150);
                parameters.Add("@errorcode", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 30);
                parameters.Add("@errormsg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 200);

                var result = await DapperWrapper.QueryFirstOrDefaultAsync<THRCCAuditDto>(
                    StoredProcedures.ThrccCustomerFullfilment, parameters, commandType: CommandType.StoredProcedure,
                    _configuration.GetConnectionString(ConnectionStrings.BackHome));
                if (result != null && result.audit_id != 0)
                {
                    response.ErrorMessage = parameters.Get<string>("@errormsg");
                    response.ErrorCode = Convert.ToInt32(parameters.Get<string>("@errorcode"));
                    response.PinNumber = parameters.Get<string>("@thccpin");
                    response.CardNumber = productRef;
                    response.AuditId = result.audit_id.ToString();
                    if (result?.new_balance > 0)
                    {
                        var newBalance = Math.Round(Convert.ToDecimal(result?.new_balance / 100), 2);
                        response.NewBalance = newBalance.ToString();
                    }
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "Execution failed!";
                    response.PinNumber = "";
                }
            }
            catch (Exception ex)
            {
                response.ErrorCode = 1;
                response.ErrorMessage = "Code Exception: " + ex.Message;
                _logger.Error($"Class: PaymentFullfillment, Method: ThrccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, productRef: {productRef}, ErrorMessage: {ex.Message}");
            }
            return response;
        }

        #endregion

        #region Paypal

        public async Task<THCCPinDto> PaypalThccCardFullfilment(
          string transactionId,
          string amount,
          string email,
          string firstname)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@denomination", int.Parse(amount.Split('.')[0]));
                parameters.Add("@email", email);
                parameters.Add("@th_transaction_reference", transactionId);
                parameters.Add("@firstName", firstname);

                return await DapperWrapper.QueryFirstOrDefaultAsync<THCCPinDto>(
                      StoredProcedures.PaypalThccCardFullfilment,
                      parameters,
                      commandType: CommandType.StoredProcedure,
                      _configuration.GetConnectionString(ConnectionStrings.TalkHomeRechargeableCard));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentFullfillment.cs, Method: ThccCustomerFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, email: {email}, firstname: {firstname}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null!;
            }
        }

        public async Task<FullfilmentDto> PaypalThrccCardFullfilment(
            string email,
            string firstName,
            string transactionId,
            string amount,
            string cardNumber)
        {
            var response = new FullfilmentDto();

            try
            {
                if (string.IsNullOrEmpty(cardNumber))
                {
                    var pinResponse = await GetNextRCCPin(email, firstName, transactionId);
                    if (pinResponse == null)
                    {
                        response.ErrorMessage = "Failed to get rechargable card number";
                        response.ErrorCode = -1;
                        return response;
                    }
                    cardNumber = pinResponse.Account!.Trim();
                }

                DynamicParameters parameters = new();
                parameters.Add("@amount", amount);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@productref", cardNumber);
                parameters.Add("@thccpin", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 150);
                parameters.Add("@errorcode", null, dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 200);
                parameters.Add("@account", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 50);
                var result = await DapperWrapper.QueryFirstOrDefaultAsync<THRCCAuditDto>(
                    StoredProcedures.PaypalThrccCardFullfilment, parameters, commandType: CommandType.StoredProcedure,
                    _configuration.GetConnectionString(ConnectionStrings.BackHome));
                if (result != null)
                {
                    var errorCode = parameters.Get<int>("@errorcode");
                    var errorMessage = parameters.Get<string>("@errormsg");
                    if (errorCode > 0)
                    {
                        response.ErrorMessage = errorMessage;
                        response.ErrorCode = errorCode;
                    }
                    else
                    {
                        response.AuditId = result.audit_id.ToString();
                        response.NewBalance = result.new_balance.ToString();
                        response.CardNumber = parameters.Get<string>("@account").Trim();
                        response.PinNumber = parameters.Get<string>("@thccpin").Trim();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaymentFullfillment, Method: PaypalThrccCardFullfilment, Parameters => transactionId: {transactionId}, amount: {amount}, cardNumber: {cardNumber}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                response.ErrorMessage = ex.Message;
                response.ErrorCode = -1;
            }

            return response;
        }


        #endregion

        private async Task<PinDetail> GetNextRCCPin(string email, string firstName, string th_transaction_reference)
        {
            PinDetail trccPin = new();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@email", email);
                parameters.Add("@firstName", firstName);
                parameters.Add("@th_transaction_reference", th_transaction_reference);
                parameters.Add("@pin", null, DbType.String, direction: ParameterDirection.Output, size: 20);
                parameters.Add("@pan", null, DbType.String, direction: ParameterDirection.Output, size: 38);

                await DapperWrapper.QueryFirstOrDefaultAsync<PinDetail>(
                 StoredProcedures.THRCCPin, parameters, commandType: CommandType.StoredProcedure,
                 _configuration.GetConnectionString(ConnectionStrings.TalkHomeRechargeableCard));

                trccPin.Pin = Convert.ToString(parameters.Get<dynamic>("@pin")).Trim();
                trccPin.Account = Convert.ToString(parameters.Get<dynamic>("@pan"));

                return trccPin;
            }
            catch (Exception ex)
            {
                _logger.Error($"GetNextRCCPin: Exception occured while getting the Recharageble card for email:{email}"
                                                + th_transaction_reference + " \n" + ex.ToString());
            }
            return null!;
        }

        public async Task UpdateFulfillmentItems(
            long orderItemId,
            string errorMsg,
            string? cardnumber,
            string? cardpin,
            string orderHistoryDescription)
        {
            cardnumber = cardnumber != null ? cardnumber.Trim() : cardnumber;
            cardpin = cardpin != null ? cardpin.Trim() : cardpin;

            var parameters = new DynamicParameters();
            parameters.Add("@orderItemId", orderItemId);
            parameters.Add("@errorMsg", errorMsg);
            parameters.Add("@cardnumber", cardnumber);
            parameters.Add("@cardpin", cardpin);
            parameters.Add("@OrderHistoryDescription", orderHistoryDescription);
            await DapperWrapper.ExecuteAsync(StoredProcedures.UpdateFulfillmentItems, parameters, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
        }
    }
}
