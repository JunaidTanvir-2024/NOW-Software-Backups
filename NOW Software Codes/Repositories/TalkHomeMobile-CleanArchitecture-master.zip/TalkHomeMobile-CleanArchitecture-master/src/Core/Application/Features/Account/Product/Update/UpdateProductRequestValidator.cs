﻿namespace Application.Features.Account.Product.Update;
public class UpdateProductRequestValidator : AbstractValidator<UpdateProductRequest>
{
    public UpdateProductRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");

        RuleFor(p => p.ProductId).Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .Must(x => x > 0)
            .WithMessage("Invalid Product Ref");
    }
}
