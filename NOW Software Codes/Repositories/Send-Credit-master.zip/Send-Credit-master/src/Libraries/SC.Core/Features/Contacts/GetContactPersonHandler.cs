﻿using MapsterMapper;

using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.Contacts.Requests;
using SC.Core.Features.Contacts.Response;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Contacts
{
    internal class GetContactPersonHandler : IRequestHandler<GetContactPersonRequest, IResultWrapper>
    {
        private readonly IContactPersonRepository _contactPersonRepository;
        private readonly ICommonService _commonService;
        private readonly IMapper _mapper;

        public GetContactPersonHandler(IContactPersonRepository contactPersonRepository, ICommonService commonService, IMapper mapper)
        {
            this._contactPersonRepository = contactPersonRepository;
            this._commonService = commonService;
            this._mapper = mapper;
        }

        public async Task<IResultWrapper> Handle(GetContactPersonRequest request, CancellationToken cancellationToken)
        {
            var personRequest = _mapper.Map<GetContactPersonDto.Request>(request);
            personRequest.UserId = _commonService.GetUserID();
            var contactpersons = await _contactPersonRepository.GetContactPersons(personRequest);

            var response = contactpersons.Select(x => new GetContactPersonResponse()
            {
                Id = CipherHelper.Encrypt( x.Id.ToString()),
                FirstName = x.FirstName,
                LastName = x.LastName,
                Email = x.Email,
                MobileNo = x.MobileNo
            });
 
            return ResultWrapper.Success(response);
        }
    }
}