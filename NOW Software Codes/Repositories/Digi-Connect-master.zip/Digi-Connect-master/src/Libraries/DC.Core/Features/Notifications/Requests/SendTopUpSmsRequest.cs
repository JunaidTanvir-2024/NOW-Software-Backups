using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DC.Core.Features.Notifications.Requests;

public record SendTopUpSmsRequest() : IRequest<IResultWrapper>
{

}
public class SendTopUpSmsRequestValidator : AbstractValidator<SendTopUpSmsRequest>
{
    public SendTopUpSmsRequestValidator()
    {

    }
}

