﻿using Models.Contracts.Request.Voucherify;
using Models.Enums;
using System.ComponentModel.DataAnnotations;

namespace Models.Contracts.Request
{
    public class TransferByPayPalResponseModel
    {
        public string clientRedirectUrl { get; set; }
    }
    public class TransferByPaypalCallBackRequestModel
    {
        public string nowtelRef { get; set; }
        public string payerId { get; set; }
        public string product { get; set; }
        public int operatorId { get; set; }
        public string msisdn { get; set; }
        public string token { get; set; }
        public string AppsFlyerId { get; set; }
        public int DeviceType { get; set; }
        public ThemeMode ThemeMode { get; set; }
        public string IpAddress { get; set; }
        public string advertiserID { get; set; }
        public bool IsTransferRequest { get; set; } = false;
    }
    public class TransferByPaypalCallBackRequestModelV2: TransferByPaypalCallBackRequestModel
    {
        public string DiscountCode { get; set; }
        public DiscountCodeType DiscountCodeType { get; set; }
    }

	public class TransferByPayPalRequestModel
    {
        [Required]
        public string nowtelRef { get; set; }

        [Required]
        public string product { get; set; }

        [Required]
        public string operatorId { get; set; }
        public string messageToRecipient { get; set; }
        //public AppsFlyerInfo AppsFlyerInfo { get; set; }
        public string AppsFlyerId { get; set; }
        public int DeviceType { get; set; }
        public bool IsTransferRequest { get; set; } = false;
    }
    public class TransferByPayPalRequestModelV2: TransferByPayPalRequestModel
    {
        public string DiscountCode { get; set; }
        public DiscountCodeType DiscountCodeType { get; set; }
    }
}
