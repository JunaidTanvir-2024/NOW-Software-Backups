﻿using Application.Common.Caching;

namespace Application.Features.CacheClear;
public class CacheClearRequestHandler : IRequestHandler<CacheClearRequest, Result<object>>
{
    #region Fields

    private readonly IStringLocalizer<CacheClearRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;
    private readonly ICurrentUser _currentUser;


    #endregion

    #region Ctor

    public CacheClearRequestHandler(

        IStringLocalizer<CacheClearRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService,
        ICurrentUser currentUser

       )
    {

        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _cacheService = cacheService;
        _cacheKeyService = cacheKeyService;
        _currentUser = currentUser;

    }

    #endregion

    #region Method
    public async Task<Result<object>> Handle(CacheClearRequest request, CancellationToken cancellationToken)
    {
        //Clear cahe

        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, _currentUser.GetUserEmail()!), cancellationToken);
        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, _currentUser.GetUserId().ToString()), cancellationToken);
        var userProducts = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        if (userProducts?.Any() == true)
        {
            foreach (var item in userProducts)
            {
                await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, item.Msisdn!), cancellationToken);
            }
        }
        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
