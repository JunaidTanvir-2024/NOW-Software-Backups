﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TH.Models.Configurations
{
    public class CompanyConfig
    {
        public int CompanyId { get; set; }
    }
}
