﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Database
{
    public class DestinationServiceProvider
    {
        public int Id { get; set; }
        public string Country { get; set; }
        public string InitialCallingCode { get; set; }
        public int ServiceProviderId { get; set; }
        public bool IsEnabled { get; set; }
        public int SecondServiceProviderId { get; set; }
        public bool SecondServiceProviderEnabled { get; set; }
        public int SecondServiceProviderTranCount_Current { get; set; }
        public int ServiceProviderTranCount_Current { get; set; }
        public int SecondServiceProviderTranCount { get; set; }
        public int ServiceProviderTranCount { get; set; }
        public RoutingType TypeofRouting { get; set; }
    }

    public class Comm_ATT_DestinationServiceProvider
    {
        public int Id { get; set; }
        public string operator_code { get; set; }
        public int service_provider_id { get; set; }
        public int service_provider_id_1 { get; set; }
        public int service_provider_current_count { get; set; }
        public int service_provider_1_current_count { get; set; }
        public string PercentageRoutingRatio { get; set; }
        public RoutingType TypeOfRouting { get; set; }
    }


    public enum RoutingType
    {
        Failover = 1,
        Percentage = 2
    }

    public class RoutingInfo
    {
        public int ServiceProviderId { get; set; }
        public int CarrierNumber { get; set; }
        public bool UpdateCount { get; set; }
        public int NewServiceProviderTranCount_Current { get; set; }
        public int NewSecondServiceProviderTranCount_Current { get; set; }
    }

}
