﻿using System.Text.Json.Serialization;

namespace NTCB.Api.Features.DTOne.Models;

public class PricesInfo
{
    [JsonPropertyName("retail")]
    public object? Retail { get; set; }
    [JsonPropertyName("wholesale")]
    public WholesaleInfo? Wholesale { get; set; }
}
