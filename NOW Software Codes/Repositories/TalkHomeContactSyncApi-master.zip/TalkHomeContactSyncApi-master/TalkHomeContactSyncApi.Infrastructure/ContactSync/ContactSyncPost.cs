﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Serilog;
using System.Threading.Tasks;
using TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Request;
using TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Response;
using System.Data;
using TalkHomeContactSyncApi.Contracts;
using System.Diagnostics;

namespace TalkHomeContactSyncApi.Infrastructure.ContactSync
{
    public class ContactSyncPost: IContactSyncPost
    {
        private readonly ILogger Logger;
        private readonly IContactSyncDB DB;
        public ContactSyncPost(IContactSyncDB dB, ILogger logger)
        {
            this.Logger = logger;
            this.DB = dB;
        }

        //Convert the contact request into data table and pass to data layer for filtering either talkhome user or not.
        async public Task<GenericApiResponse<IList<ContactSyncResponse>>> GetFilteredTalkHomeContacts(ContactSyncRequest contacts)
        {
            GenericApiResponse<IList<ContactSyncResponse>> responseResult;
            IList<ContactSyncResponse> response = new List<ContactSyncResponse>();
            try
            {
                //Check weather the request has single contact or not.
                if (contacts.Contacts != null)
                {
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();
                    DataTable dt = new DataTable();
                    dt.Columns.Add("Contact", typeof(string));

                    //var query = from contact in contacts.Contacts
                    //            select dt.Rows.Add(dt.NewRow()["Contact"] = contact);
                    //Convert the contacts request into datatable.

                    for (int i = 0; i < contacts.Contacts.Count; i++)
                    {
                        //adding contacts as row to datatable.
                        DataRow row = dt.NewRow();
                        row["Contact"] = contacts.Contacts[i];
                        dt.Rows.Add(row);
                    }
                    stopwatch.Stop();
                    Console.WriteLine($"Generating Datatable took {stopwatch.ElapsedMilliseconds} ms");
                    //passing the contact datatable to data layer for comparison and filtering talkhome contacts.

                    response = await DB.GetFilteredTalkHomeContacts(dt);
                    if(response!=null)
                    {
                        responseResult= GenericApiResponse<IList<ContactSyncResponse>>.Success(response, "Request executed successfully.");
                    }
                    else
                    {
                        responseResult = GenericApiResponse<IList<ContactSyncResponse>>.Success(null, "Request executed returned null.");
                    }
                }
                else
                {
                    responseResult = GenericApiResponse<IList<ContactSyncResponse>>.Pending(null, "Bad request");
                }
            }
            catch(Exception ex)
            {
                responseResult = GenericApiResponse<IList<ContactSyncResponse>>.Failure("Unsuccesfull");
                Logger.Error($"ContactSyncPost->GetFilteredTalkHomeContacts ErrorMessage: +{ex.Message}");
                Console.WriteLine("ContactSyncPost->GetFilteredTalkHomeContacts ErrorMessage: check Logs for details");
            }
            return responseResult;
            
        }
    }
}
