﻿using THCC.Application.Models.Dtos;
using THCC.Application.Settings;

namespace THCC.Application.Features.Payment.Card.AutoTopup.ExistingCard;

public class AutoTopupExistingCardPaymentRequest : IRequest<object>
{
    public PaymentExistingCardDto PaymentCardInfo { get; set; } = default!;
    public decimal Amount { get; set; }
}

public class AutoTopupExistingCardPaymentRequestValidator : AbstractValidator<AutoTopupExistingCardPaymentRequest>
{
    public AutoTopupExistingCardPaymentRequestValidator(
            IOptions<TopupSettings> topupSettings)
    {
        RuleFor(p => p.Amount).Cascade(CascadeMode.Stop)
          .NotEmpty()
          .NotNull()
          .Must(x => topupSettings.Value.Amounts.Any(a => a.Amount == x))
          .WithMessage("Please only use: " + string.Join(",", values: topupSettings.Value.Amounts.Select(a => a.Amount)));

        RuleFor(p => p.PaymentCardInfo.CardToken)
            .NotEmpty()
            .NotNull()
            .MaximumLength(100)
            .When(x => x.PaymentCardInfo != null);

        RuleFor(p => p.PaymentCardInfo.SecurityCode)
            .NotEmpty()
            .NotNull()
            .MinimumLength(3)
            .MaximumLength(4)
            .When(x => x.PaymentCardInfo != null);
    }
}
