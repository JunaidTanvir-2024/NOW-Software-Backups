﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.Card.Topup.FastTopup.NewCard
{
    public class FastTopupNewCardPaymentRequestHandler : IRequestHandler<FastTopupNewCardPaymentRequest, object>
    {
        #region Fields

        private readonly IPaymentService _paymentService;
        private readonly IUserRepository _userRepository;
        private readonly IUserService _userService;
        private readonly ILogger _logger;
        private readonly IAirshipService _airshipService;
        private readonly ICurrentUser _currentUser;

        #endregion

        #region Ctors

        public FastTopupNewCardPaymentRequestHandler(
            IPaymentService paymentService,
            IUserRepository userRepository,
            IUserService userService,
            ILogger logger,
            IAirshipService airshipService,
            ICurrentUser currentUser)
        {
            _paymentService = paymentService;
            _userRepository = userRepository;
            _userService = userService;
            _logger = logger;
            _airshipService = airshipService;
            _currentUser = currentUser;
        }

        #endregion

        #region Methods

        public async Task<object> Handle(FastTopupNewCardPaymentRequest request, CancellationToken cancellationToken)
        {
            //Trim all the request properties
            request.CardNumber = request.CardNumber.Trim();
            request.EmailAddress = request.EmailAddress != null ? request.EmailAddress!.Trim() : null;
            request.PaymentCardInfo.NameOnCard = request.PaymentCardInfo.NameOnCard.Trim();
            request.PaymentCardInfo.CardNumber = request.PaymentCardInfo.CardNumber.Trim();
            request.PaymentCardInfo.SecurityCode = request.PaymentCardInfo.SecurityCode.Trim();
            request.PaymentCardInfo.ExpiryMonth = request.PaymentCardInfo.ExpiryMonth.Trim();
            request.PaymentCardInfo.ExpiryYear = request.PaymentCardInfo.ExpiryYear.Trim();
            request.PaymentAddressInfo.AddressL1 = request.PaymentAddressInfo.AddressL1!.Trim();
            request.PaymentAddressInfo.City = request.PaymentAddressInfo.City!.Trim();
            request.PaymentAddressInfo.PostCode = request.PaymentAddressInfo.PostCode!.Trim();
            request.PaymentAddressInfo.CountryCode = request.PaymentAddressInfo.CountryCode!.Trim();

            var userData = new UserDto();
            var productUser = await _userRepository.GetUserByProduct(request.CardNumber);
            if (_currentUser.IsAuthenticated())
            {
                if (productUser != null)
                {
                    //Check if the card number is logged-in user card number
                    if (productUser.Id.Equals(_currentUser.GetUserId(),
                                    StringComparison.InvariantCultureIgnoreCase))
                    {
                        userData.Email = _currentUser.GetUserEmail();
                        userData.Id = _currentUser.GetUserId();
                    }
                    else
                    {
                        userData.Email = productUser.Email!;
                        userData.Id = productUser.Id;
                    }
                }
                else
                {
                    //User must have to provide email address when card number is not registered
                    if (string.IsNullOrEmpty(request.EmailAddress))
                    {
                        _logger.Error("FastTopupNewCardPaymentRequestHandler => card number not registerd and email not provided: " + request.CardNumber);
                        return ErrorResult.Failure(
                                CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
                    }

                    //Check user is registered
                    var dbUser = await _userRepository.GetUserByEmailAsync(request.EmailAddress);
                    if (dbUser != null)
                    {
                        userData.Id = dbUser.Id;
                        userData.Email = dbUser.Email!;
                    }
                    else
                    {
                        var signupResponse = await _userService.SignUpAsync(
                             null!,
                             null!,
                             request!.EmailAddress,
                             null!,
                             UserRole.Guest,
                             false);

                        if (!signupResponse.IsSuccess)
                        {
                            return ErrorResult.Failure(CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
                        }

                        userData.Id = signupResponse!.Id!;
                        userData.Email = request!.EmailAddress;
                    }
                }
            }
            else
            {
                if (productUser != null)
                {
                    userData.Email = productUser.Email!;
                    userData.Id = productUser.Id;
                }
                else
                {
                    //User must have to provide email address when card number is not registered
                    if (string.IsNullOrEmpty(request.EmailAddress))
                    {
                        _logger.Error("FastTopupNewCardPaymentRequestHandler => card number not registerd and email not provided: " + request.CardNumber);
                        return ErrorResult.Failure(
                                CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
                    }

                    //Check user is registered
                    var dbUser = await _userRepository.GetUserByEmailAsync(request.EmailAddress);
                    if (dbUser != null)
                    {
                        userData.Id = dbUser.Id;
                        userData.Email = dbUser.Email!;
                    }
                    else
                    {
                        var signupResponse = await _userService.SignUpAsync(
                             null!,
                             null!,
                             request!.EmailAddress,
                             null!,
                             UserRole.Guest,
                             false);

                        if (!signupResponse.IsSuccess)
                        {
                            return ErrorResult.Failure(CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
                        }

                        userData.Id = signupResponse!.Id!;
                        userData.Email = request!.EmailAddress;
                    }
                }
            }

            //Make sure card is not save when the user is not logged-in
            if (!_currentUser.IsAuthenticated())
            {
                request!.PaymentCardInfo.SaveCard = false;
                request!.PaymentCardInfo.MakeDefault = false;
            }
            #region Airship

            await _airshipService.CreateEmailChannelAndAssociation(userData.Email!);

            #endregion
            return await _paymentService.HandleCardPaymentRequest(
                paymentNewCardInfo: request!.PaymentCardInfo,
                paymentAddressInfo: request.PaymentAddressInfo,
                paymentExistingCardInfo: null!,
                autoTopupInfo: null!,
                userInfo: userData,
                productType: ProductType.FastTopup,
                amount: request.Amount,
                cardNumber: request.CardNumber);
        }

        #endregion
    }
}