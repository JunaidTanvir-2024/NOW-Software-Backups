﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.Porting
{
    public class GetPortingDetailsRequestModel
    {
        public string Msisdn { get; set; }
        public string Email { get; set; }
    }
}
