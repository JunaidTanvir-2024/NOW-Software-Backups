namespace MM.Core.Common.Definitions.Constants;

public static partial class AppConstants
{
    public static class ContentTypes
    {
        public const string ApplicationJson = "application/json";
        public const string ApplicationOctetStream = "application/octet-stream";
        public const string ApplicationXml = "application/xml";
    }
}
