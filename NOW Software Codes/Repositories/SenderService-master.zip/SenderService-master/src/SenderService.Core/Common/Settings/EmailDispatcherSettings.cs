﻿namespace SenderService.Core.Common.Settings;
public class EmailDispatcherSettings
{
    public const string SectionName = nameof(EmailDispatcherSettings);
    public static EmailDispatcherSettings Bind { get; set; } = new EmailDispatcherSettings();
    public int EmailRetryLimit { get; set; } = default!;
    public int MaxConcurrentTasks { get; set; } = default!;
    public int EmailBatchSize { get; set; } = default!;
    public int SendDelayInSeconds { get; set; } = default!;
}
