﻿using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Vouchers.Responses;

public class VoucherResponse
{
    public string? Code { get; set; }

    public string? VoucherType { get; set; }

    public string? Campaign { get; set; }

    public string? CampaignId { get; set; }

    public string? Category { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? ExpirationDate { get; set; }

    public bool Active { get; set; }

    public Metadata? Metadata { get; set; }

    public bool IsReferralCode { get; set; }
}
