using System;
namespace TalkhomeWebApp.Models.ViewModels
{
    public class MessageViewModel
    {
        public string Heading { get; set; }
        public string Message { get; set; }
    }
}