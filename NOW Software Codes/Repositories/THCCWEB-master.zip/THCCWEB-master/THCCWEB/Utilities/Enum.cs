﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Utilities
{
    public class Enum
    {
        public enum ApiCallType
        {
            BasicAuth,
            Bearer,
            NoHeader
        }
        public enum ProductType
        {
            THCC = 1,
            THRCC = 2,
            THRCCNC = 3,//new recharable card
            TopUp=4 //Top Up
        }
    }
    public enum Pay360PaymentType
    {
        New,
        Default,
        Token,
        ExistingNew
    }
    public enum CheckOutTypes
    {
        RechargeTopUp = 1,
        Purchase = 2
    }
    public enum RequestModelTypes
    {
        FastTopUp = 1
    }

}
