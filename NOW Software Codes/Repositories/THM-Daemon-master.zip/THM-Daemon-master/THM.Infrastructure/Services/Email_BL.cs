﻿using Microsoft.Extensions.Options;
using MimeKit;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using THM.Models.Configurations;
using THM.Models.Enums;

namespace THM.Infrastructure.Services
{
    public class Email_BL : IEmail_BL
    {

        private readonly SmtpConfig SmtpConfig;
        private readonly ILogger Logger;


        public Email_BL(ILogger logger, IOptions<SmtpConfig> smpt)
        {
            Logger = logger;
            SmtpConfig = smpt.Value;
        }

        public async Task<bool> SendFullfillmentEmail(
            string customerEmail, string Message, bool IsHtmlBody, string subject = null)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }

                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SmtpConfig.from);
                mailMessage.To.Add(customerEmail);
                if (IsHtmlBody)
                {
                    mailMessage.IsBodyHtml = IsHtmlBody;
                }
                mailMessage.Body = Message;
                mailMessage.Subject = subject;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Email_BL, Method: SendFullfillmentEmail, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> SendWhyAndBenefitsEmail(
           string customerEmail, SimOrderType simOrderType)
        {
            try
            {
                var builder = new BodyBuilder();

                string emailPath;

                if (simOrderType == SimOrderType.CreditSim)
                {
                    emailPath = @"~\wwwroot\Templates\Credit-Sim\2 days. Pre-Paid. About Talk Home – Why and Benefits.html";
                }
                else
                {
                    emailPath = @"~\wwwroot\Templates\Free-Sim\2 days. Free Sim. About Talk Home – Why and Benefits.html";
                }

                using (StreamReader SourceReader = File.OpenText(string.Format(
                                Path.GetFullPath(emailPath).Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();

                    return await SendEmail(customerEmail, builder.HtmlBody, true, "Welcome to Talk Home Mobile");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Email_BL, Method: SendWhyAndBenefitsEmail, Parameters=> customerEmail: {customerEmail}, SimOrderType: {(int)simOrderType}, ErrorMessage: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> SendNotActivatedSimEmail(
            string customerEmail, SimOrderType simOrderType)
        {
            try
            {
                var builder = new BodyBuilder();

                string emailPath;

                if (simOrderType == SimOrderType.CreditSim)
                {
                    emailPath = @"~\wwwroot\Templates\Credit-Sim\4 Days (not activated. Pre-Paid. Received your Sim_ Activate_.html";
                }
                else
                {
                    emailPath = @"~\wwwroot\Templates\Free-Sim\4 days (not activated). Free Sim. Received your Sim_ Activate_.html";
                }

                using (StreamReader SourceReader = File.OpenText(string.Format(
                                Path.GetFullPath(emailPath).Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();

                    return await SendEmail(customerEmail, builder.HtmlBody, true, "Have you activated your Talk Home Mobile Sim?");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Email_BL, Method: SendNotActivatedSimEmail, Parameters=> customerEmail: {customerEmail}, SimOrderType: {(int)simOrderType}, ErrorMessage: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> SendOtherServicesEmail(
            string customerEmail, SimOrderType simOrderType)
        {
            try
            {
                var builder = new BodyBuilder();

                string emailPath;

                if (simOrderType == SimOrderType.CreditSim)
                {
                    emailPath = @"~\wwwroot\Templates\Credit-Sim\3 Days. Pre-Paid. Our Other Services_.html";
                }
                else
                {
                    emailPath = @"~\wwwroot\Templates\Free-Sim\3 days. Free Sim. Our Other Services_.html";
                }

                using (StreamReader SourceReader = File.OpenText(string.Format(
                                Path.GetFullPath(emailPath).Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();

                    return await SendEmail(customerEmail, builder.HtmlBody, true, "How to get the best out of Talk Home Mobile");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Email_BL, Method: SendOtherServicesEmail, Parameters=> customerEmail: {customerEmail}, SimOrderType: {(int)simOrderType}, ErrorMessage: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> SendSocialMediaEmails(
            string customerEmail, SimOrderType simOrderType)
        {
            try
            {
                var builder = new BodyBuilder();

                string emailPath;

                if (simOrderType == SimOrderType.CreditSim)
                {
                    emailPath = @"~\wwwroot\Templates\Credit-Sim\2 days. Pre-Paid. Social Media _ Useful Guides and Articles.html";
                }
                else
                {
                    emailPath = @"~\wwwroot\Templates\Free-Sim\2 days. Free Sim. Social Media _ Useful Guides and Articles.html";
                }

                using (StreamReader SourceReader = File.OpenText(string.Format(
                                Path.GetFullPath(emailPath).Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();

                    return await SendEmail(customerEmail, builder.HtmlBody, true, "Get more Talk Home offers, updates and news?");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Email_BL, Method: SendSocialMediaEmails, Parameters=> customerEmail: {customerEmail}, SimOrderType: {(int)simOrderType}, ErrorMessage: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> SendNotToppedUpEmail(
                string customerEmail, SimOrderType simOrderType)
        {
            try
            {
                var builder = new BodyBuilder();

                string emailPath;

                emailPath = @"~\wwwroot\Templates\Free-Sim\2 days (not topped up). Free Sim. Top Up_.html";

                using (StreamReader SourceReader = File.OpenText(string.Format(
                                Path.GetFullPath(emailPath).Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();

                    return await SendEmail(customerEmail, builder.HtmlBody, true, "Activate and top up your SIM in three simple steps");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Email_BL, Method: SendNotToppedUpEmail, Parameters=> customerEmail: {customerEmail}, SimOrderType: {(int)simOrderType}, ErrorMessage: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> SendEmail(
            string customerEmail, string Message, bool IsHtmlBody, string subject = null)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }

                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SmtpConfig.from);
                mailMessage.To.Add(customerEmail);

                if (IsHtmlBody)
                {
                    mailMessage.IsBodyHtml = IsHtmlBody;
                }

                mailMessage.Body = Message;
                mailMessage.Subject = subject;

                await client.SendMailAsync(mailMessage);

                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Email_BL, Method: SendEmail, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }
        }
    }
}
