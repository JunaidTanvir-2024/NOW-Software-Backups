﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NowPayGApi.Infrastructure.BLL.Interfaces;
using NowPayGApi.Models.Contracts;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using Serilog;

namespace NowPayGApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommonServicesController : Controller
    {
        public IBL_CommonServices Bl;
        public ILogger Logger;

        public CommonServicesController(IBL_CommonServices bl, ILogger logger)
        {
            Bl = bl;
            Logger = logger;
        }

        [HttpGet]
        [Route("GetAllActivePlans")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllActivePlans()
        {
            try
            {
                GenericApiResponse<GetPlansResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.GetAllActivePlans();
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetAllActivePlans, Parameters=> No Parameters, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetAllPlans")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllPlans()
        {
            try
            {
                GenericApiResponse<GetPlansResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.GetAllPlans();
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetAllPlans, Parameters=> No Parameters, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetCountries")]
        [AllowAnonymous]
        public async Task<IActionResult> GetCountries()
        {
            try
            {
                GenericApiResponse<GetCountriesResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.GetCountries();
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetCountries, Parameters=> No Parameters, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetPlanCategories")]
        [Authorize]
        public async Task<IActionResult> GetPlanCategories()
        {
            try
            {
                GenericApiResponse<GetPlanCategoriesResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.GetPlanCategories();
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetPlanCategories, Parameters=> No Parameters, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetProduct")]
        [Authorize]
        public async Task<IActionResult> GetProduct()
        {
            try
            {
                GenericApiResponse<GetProductResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.GetProduct();
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetProduct, Parameters=> No Parameters, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetCurrency")]
        [Authorize]
        public async Task<IActionResult> GetCurrency()
        {
            try
            {
                GenericApiResponse<GetCurrencyResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.GetCurrency();
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetCurrency, Parameters=> No Parameters, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("GetPlanById")]
        [AllowAnonymous]
        public async Task<IActionResult> GetPlanById(IdRequestModel model)
        {
            try
            {
                GenericApiResponse<GetPlanResponseModel> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.GetPlanById(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetPlanById, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetAllInternationalRates")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllInternationalRates()
        {
            try
            {
                var response = await Bl.GetAllInternationalRates();
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetAllInternationalRates, Parameters=> No Parameters, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetRoamingRates")]
        [AllowAnonymous]
        public async Task<IActionResult> GetRoamingRates([FromQuery]GetRoamingRatesRequestModel model)
        {
            try
            {
                var response = await Bl.GetRoamingRates(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetRoamingRates, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetAllUKRates")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllUKRates()
        {
            try
            {
                var response = await Bl.GetAllUKRates();
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetAllUKRates, Parameters=> No Parameters, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetAllCountriesWithPlans")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllCountriesWithPlans()
        {
            try
            {
                var response = await Bl.GetAllCountriesWithPlans();
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetAllCountriesWithPlans, Parameters=> No Parameters, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetAddressesByPostCode")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAddressesByPostCode([FromQuery]GetAddressesRequestModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var response = await Bl.GetAddresses(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetAddressesByPostCode, Parameters => model: { JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetNumberOfSimOrdersByEmail")]
        [AllowAnonymous]
        public async Task<IActionResult> GetSimOrdersNoByEmail([FromQuery] GetSimOrdersNoByEmailRequestModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var response = await Bl.GetSimOrdersNoByEmail(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetSimOrdersNoByEmail, Parameters => model: { JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetFirstUseDate")]
        [AllowAnonymous]
        public async Task<IActionResult> GetFirstUseDate(string msisdn)
        {
           
            try
            {
                var response = await Bl.GetFirstUseDate(msisdn);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonServicesController, Method: GetFirstUseDate, Parameters => model: , ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }
    }
}