﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.Product.Product;

public class GetProductRequestHandler : IRequestHandler<GetProductRequest, object>
{
    #region Fields 

    private readonly IUserRepository _userRepo;
    private readonly ICurrentUser _currentUser;

    #endregion

    #region Ctors
    public GetProductRequestHandler(
        IUserRepository userRepo,
        ICurrentUser currentUser
       )
    {
        _userRepo = userRepo;
        _currentUser = currentUser;
    }

    #endregion

    public async Task<object> Handle(GetProductRequest request, CancellationToken cancellationToken)
    {
        var userProduct = await _userRepo.GetUserProducts(_currentUser.GetUserId());
        return userProduct == null
            ? (object)ErrorResult.Failure(CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest)
            : new ProductDto()
        {
            CardNumber = userProduct.Product
        };
    }
}
