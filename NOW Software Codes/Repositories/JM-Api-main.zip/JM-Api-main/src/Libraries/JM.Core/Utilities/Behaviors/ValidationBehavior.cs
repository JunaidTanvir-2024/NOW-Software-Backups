using FluentValidation;

using Mediator;

using RW;
using RW.Models;

namespace JM.Core.Utilities.Behaviors;

public class ValidationBehavior<TRequest, TResponse>(IEnumerable<IValidator<TRequest>> validators) : IPipelineBehavior<TRequest, IResultWrapper>
    where TRequest : IRequest<IResultWrapper>
{
    public async ValueTask<IResultWrapper> Handle(TRequest message, CancellationToken cancellationToken, MessageHandlerDelegate<TRequest, IResultWrapper> next)
    {
        var context = new ValidationContext<TRequest>(message);

        var validationResults = await Task.WhenAll(validators
            .Select((validator) => validator.ValidateAsync(context)));

        var validationFailures = validationResults.SelectMany(result => result.Errors.DistinctBy(x => x.PropertyName));

        if (validationFailures.Any())
        {
            var errors = validationFailures.Select(x => new ValidationErrorDto() { ErrorMessage = x.ErrorMessage, PropertyName = x.PropertyName });
            return ResultWrapper.Failure(errors);
        }

        return await next(message, cancellationToken);
    }
}
