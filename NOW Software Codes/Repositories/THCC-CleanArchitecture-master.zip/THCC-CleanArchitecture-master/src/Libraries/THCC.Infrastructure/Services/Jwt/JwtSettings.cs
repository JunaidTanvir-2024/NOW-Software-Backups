namespace THCC.Infrastructure.Services.Jwt;
public class JwtSettings
{
    public const string SectionName = nameof(JwtSettings);
    public static JwtSettings Bind { get; } = new JwtSettings();
    public string? Issuer { get; set; }
    public string? Audience { get; set; }
    public int ExpirationTimeInMinutes { get; set; }
    public bool AsymmetricEnryption { get; set; }
    public int RefreshTokenExpirationInDays { get; set; }
    public AsymmetricFiles AsymmetricFiles { get; set; } = new AsymmetricFiles();
}
public class AsymmetricFiles
{
    public const string SectionName = nameof(AsymmetricFiles);
    public static AsymmetricFiles Bind { get; } = new AsymmetricFiles();
    public string? SecretKeyFile { get; set; }
    public string? PublicKeyFile { get; set; }
}

public class SymmetricEnryption
{
    public const string SectionName = nameof(SymmetricEnryption);
    public static SymmetricEnryption Bind { get; } = new SymmetricEnryption();
    public string? SecretKey { get; set; }
}