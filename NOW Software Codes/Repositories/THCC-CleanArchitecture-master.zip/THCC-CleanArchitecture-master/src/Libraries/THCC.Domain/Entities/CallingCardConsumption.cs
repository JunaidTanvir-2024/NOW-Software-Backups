﻿namespace THCC.Domain.Entities
{
    public class CallingCardConsumption
    {
        public long Id { get; set; }
        public string? Email { get; set; }
        public float Percentage { get; set; }
    }
    public class CallingCardCDRHistory
    {
        public long Id { get; set; }
        public string? Email { get; set; }
        public float OpeningBalance { get; set; }
        public float ClosingBalance { get; set; }
        public int Duration { get; set; }
        public string? Destination { get; set; }
    }
}
