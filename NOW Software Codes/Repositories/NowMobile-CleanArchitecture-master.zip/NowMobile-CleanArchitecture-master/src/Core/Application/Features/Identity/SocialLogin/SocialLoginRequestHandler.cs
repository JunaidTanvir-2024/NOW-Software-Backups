﻿using Application.Common.Enums;
using Application.Common.Interfaces;
using Application.Common.Interfaces.Infrastructure.Identity;
using Application.Common.Models;
using Application.Common.Settings;
using Application.Features.Identity.Tokens.Token;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Identity.SocialLogin;
public class SocialLoginRequestHandler : IRequestHandler<SocialLoginRequest, Result<SocialLoginResponse>>
{
    #region Fields

    private readonly ITokenService _tokenService;
    private readonly IStringLocalizer<RefreshTokenRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly IOtpService _otpService;
    private readonly ISmsService _smsService;
    private readonly IMapper _mapper;
    private readonly ISocialLoginService _socialLoginService;
    private readonly LoginSettings _loginSettings;

    #endregion

    #region Ctor

    public SocialLoginRequestHandler(
        ITokenService tokenService,
        IStringLocalizer<RefreshTokenRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService,
        IOtpService otpService,
        ISmsService smsService,
        IOptions<LoginSettings> loginSettings,
        IMapper mapper,
        ISocialLoginService socialLoginService)
    {
        _tokenService = tokenService;
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _otpService = otpService;
        _smsService = smsService;
        _mapper = mapper;
        _socialLoginService = socialLoginService;
        _loginSettings = loginSettings.Value;
    }
    #endregion


    public async Task<Result<SocialLoginResponse>> Handle(SocialLoginRequest request, CancellationToken cancellationToken)
    {
        var responseModel = new SocialUserViewModel();
        LoginType loginType;
        //Check if request is from App
        (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();


        #region Google

        if (request.SocialLoginType == SocialLoginType.Google)
        {
            var googleLoginResponse = await _socialLoginService.GetUserFromGoogle(request.AccessToken);
            if (googleLoginResponse == null)
            {
                return Result<SocialLoginResponse>.Failure(_localizer[CustomStatusKey.SocialLoginFailed], CustomStatusCode.SocialLoginFailed);
            }
            if(string.IsNullOrEmpty(googleLoginResponse.Email))
            {
                return Result<SocialLoginResponse>.Failure(_localizer[CustomStatusKey.SocialEmailMissing], CustomStatusCode.SocialEmailMissing);
            }
            responseModel = new SocialUserViewModel
            {
                Id = googleLoginResponse.Id,
                Email = googleLoginResponse.Email,
                Name = googleLoginResponse.Name,
                Picture = googleLoginResponse.Picture,
                Type = SocialLoginType.Google
            };
        }

        #endregion

        #region FaceBook

        else if (request.SocialLoginType == SocialLoginType.Facebook)
        {
            var googleLoginResponse = await _socialLoginService.GetUserFromFacebook(request.AccessToken);
            if (googleLoginResponse == null)
            {
                return Result<SocialLoginResponse>.Failure(_localizer[CustomStatusKey.SocialLoginFailed], CustomStatusCode.SocialLoginFailed);
            }

            if (string.IsNullOrEmpty(googleLoginResponse.Email))
            {
                return Result<SocialLoginResponse>.Failure(_localizer[CustomStatusKey.SocialEmailMissing], CustomStatusCode.SocialEmailMissing);
            }
            responseModel = new SocialUserViewModel { Id = googleLoginResponse.Id, Email = googleLoginResponse.Email, Name = googleLoginResponse.Name, Picture = googleLoginResponse.Picture.Data.Url, Type = SocialLoginType.Facebook };

        }

        #endregion

        #region Apple

        else if (request.AppleLogin != null && !string.IsNullOrEmpty(request.AppleLogin.User.Email))
        {
            var validateAppleToken =await _socialLoginService.ValidateAppleToken(request.AppleLogin.Code, request.AppleLogin.User.Email);
            if (!validateAppleToken)
            {
                return Result<SocialLoginResponse>.Failure(_localizer[CustomStatusKey.SocialLoginFailed], CustomStatusCode.SocialLoginFailed);
            }
            responseModel.Name = request.AppleLogin.User.Name.FirstName + " " + request.AppleLogin.User.Name.LastName;
            responseModel.Email = request.AppleLogin.User.Email;
            request.SocialLoginType = SocialLoginType.Apple;


        }

        #endregion

        var user = await _unitOfWork.UserRepo.GetUserByEmail(responseModel?.Email);

        #region Existing User
        var names = responseModel.Name.Split(' ');
        
        if (user != null)
        {

            var updateExistingUser = await _unitOfWork.UserRepo.UpdateExistingUser(new User
            {
                Email = responseModel.Email,
                SocialSignUpType = (int) request.SocialLoginType
            });

            var tokenInfo = await _tokenService.GetTokenAsync(user, request.IpAddress!, cancellationToken);
            var response = new SocialLoginResponse()
            {
                Id = user.Id,
                Email = user.Email,
                Name = user.FirstName,
                Token = tokenInfo.Token,
                RefreshToken = tokenInfo.RefreshToken
            };
            return Result<SocialLoginResponse>.Success(response, _localizer[CustomStatusKey.Success]);
        }

        #endregion

        #region New User
        var registerUser = await _unitOfWork.UserRepo.RegisterSocialUser(new User
        {
            FirstName = names[0],
            LastName = names[1],
            Email = responseModel.Email,
            SocialSignUpType = (int) request.SocialLoginType
        });
        user = await _unitOfWork.UserRepo.GetUserByEmail(responseModel?.Email);
        if (user != null)
        {
            var tokenInfo = await _tokenService.GetTokenAsync(user, request.IpAddress!, cancellationToken);
            var response = new SocialLoginResponse()
            {
                Id = user.Id,
                Email = user.Email,
                Name = user.FirstName,
                Token = tokenInfo.Token,
                RefreshToken = tokenInfo.RefreshToken
            };
            return Result<SocialLoginResponse>.Success(response, _localizer[CustomStatusKey.Success]);
        }
        #endregion

        return Result<SocialLoginResponse>.Failure(_localizer[CustomStatusKey.InvalidCredentials], CustomStatusCode.InvalidCredentials);
    }
}
