﻿using System;
using System.Xml.Serialization;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.ATTApiContracts
{
    [XmlRoot(ElementName = "TransferTo")]
    public class DTOneOperatorDetails
    {

        [XmlElement(ElementName = "country")]
        public string Country { get; set; }

        [XmlElement(ElementName = "countryid")]
        public int Countryid { get; set; }

        [XmlElement(ElementName = "operator")]
        public string Operator { get; set; }

        [XmlElement(ElementName = "operatorid")]
        public int Operatorid { get; set; }

        [XmlElement(ElementName = "destination_currency")]
        public string DestinationCurrency { get; set; }

        [XmlElement(ElementName = "product_list")]
        public string ProductList { get; set; }

        [XmlElement(ElementName = "retail_price_list")]
        public string RetailPriceList { get; set; }

        [XmlElement(ElementName = "wholesale_price_list")]
        public string WholesalePriceList { get; set; }

        [XmlElement(ElementName = "authentication_key")]
        public double AuthenticationKey { get; set; }

        [XmlElement(ElementName = "error_code")]
        public int ErrorCode { get; set; }

        [XmlElement(ElementName = "error_txt")]
        public string ErrorTxt { get; set; }
    }


}
