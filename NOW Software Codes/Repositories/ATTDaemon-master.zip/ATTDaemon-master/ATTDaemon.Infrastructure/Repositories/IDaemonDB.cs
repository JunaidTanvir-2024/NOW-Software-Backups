﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ATTDaemon.Models;
using ATTDaemon.Models.DB;

namespace ATTDaemon.Infrastructure.Repositories
{
    public interface IDaemonDB
    {
        List<countries> getCountries();

        void insertOperator(int ServiceProviderOperatorID, int serviceProviderID, string currency, string Name, int CountryID, string iconUri, bool isFixed);

        void insertOperatorProductRate(int OperatorID, float transactionfeeClientccy, float itemPriceClientccy,
                   float totalPriceClientccy, string clientccy, string receiverccy, string product);

        at_Operators getOperatorRecord(int serviceProviderOperatorID, int serviceProviderID, string currency);

        void deleteOperatorRatesRecords(int operatorRecordID);
    }
}
