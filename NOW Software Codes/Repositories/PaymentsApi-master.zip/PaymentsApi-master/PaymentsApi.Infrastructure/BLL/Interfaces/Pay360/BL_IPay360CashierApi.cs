﻿using PaymentsApi.Infrastructure.DAL.Database;
using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using System.Threading.Tasks;

namespace PaymentsApi.Infrastructure.BLL.Interfaces.Pay360
{
    public interface BL_IPay360CashierApi
    {
        Task<GenericApiResponse<UserResponseModels>> NewCustomerPayment(UserPaymentRequestNewCustomer userRequest);
        Task<GenericApiResponse<UserResponseModels>> ExistingCustomerPaymentDefaultCard(UserPaymentRequestExistingCustomerDefaultCard userRequest);
        Task<GenericApiResponse<UserResponseModels>> ExistingCustomerPaymentNewCard(UserPaymentRequestExistingCustomerNewCard userRequest);
        Task<GenericApiResponse<UserResponseModels>> Resume3DSecureTransaction(UserRequestResume3DSecureTransaction userRequest);
        Task<GenericApiResponse<UserResponseModels>> ExistingCustomerPaymentCardToken(UserPaymentRequestCardToken userRequest);
        Task<GenericApiResponse<UserResponseModels>> RepeatTransaction(UserRequestRepeatTransaction userRequest);
        Task<GenericApiResponse<TAmount>> Validate(Validate userRequest);
        Task<GenericApiResponse<UpdatePaymentMethodResponseModel>> UpdateCustomerCard(UpdateCustomerCardRequest updateCustomerCardRequest);
        Task<GenericApiResponse<UserResponseModels>> Fullfilment(UserResponseModels userResponse, string pay360TransactionId, string transactionId, string currency, string customerMerchantReference, string customerEmail, string msisdn = "");

        Task<GenericApiResponse<UserResponseModels>> Validations(string customerMsisdn, string productCode, float transactionAmount, ProductBasket[] productBasket);
        Task<bool> SendEmail(EmailTransactionModel transactionModel);
        Task<bool> SendEmailToCustomer(string customerEmail, string Message, bool IsHtmlBody = false);
        Task<bool> SendEmailToCustomer(string customerEmail, string Message, string productCode);
        Task<bool> SendHtmlEmailToCustomer(string customerEmail, string htmlMessage, string productCode, string EmailSubject = null);

        Task<GenericApiResponse<UserResponseModels>> Resume3DsV2(UserRequestResume3DsV2 userRequest);
    }
}
