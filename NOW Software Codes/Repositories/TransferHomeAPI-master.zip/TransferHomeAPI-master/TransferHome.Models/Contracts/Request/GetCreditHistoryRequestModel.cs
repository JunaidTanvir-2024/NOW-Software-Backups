﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class GetCreditHistoryRequestModel
    {
        [Required]
        public int UserId { get; set; }
    }
}
