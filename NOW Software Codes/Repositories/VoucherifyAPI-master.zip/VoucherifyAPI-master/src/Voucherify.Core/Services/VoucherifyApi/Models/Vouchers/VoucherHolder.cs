using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

public class VoucherHolder
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("email")]
    public string? Email { get; set; }

    [JsonPropertyName("source_id")]
    public string? SourceId { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    [JsonPropertyName("object")]
    public string? Object { get; set; }
}
