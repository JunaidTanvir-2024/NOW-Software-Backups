﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class GetPromotionsResponseModel
    {
        public PromotionsDetails PromotionsDetails { get; set; }
    }

    public class PromotionsDetails
    {
        public PromotionsDetails()
        {
            Promotions = new List<Promotions>();
            PromotionPaymentMethods = new List<PromotionPaymentMethods>();
        }
        public IEnumerable<Promotions> Promotions { get; set; }
        public IEnumerable<PromotionPaymentMethods> PromotionPaymentMethods { get; set; }

    }

    public class Promotions
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Priority { get; set; }
        public bool IsAllowedMultiplePromotions { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public PromotionType Type { get; set; }
        public AudienceType Audience { get; set; }
        public PromotionDependentTypes PromotionDependentType { get; set; }
        public OfferUnitTypes OfferUnit { get; set; }
        public decimal OfferValue { get; set; }
    }

    public class PromotionPaymentMethods
    {
        public int PromotionId { get; set; }
        public PaymentMethodTypes PaymentMethodId { get; set; }
    }
}
