namespace Application.Features.Identity.Signup.Signup;

public class SignupRequestValidator : AbstractValidator<SignupRequest>
{
    public SignupRequestValidator(ICommonService commonService)
    {
        #region User Info Validation

        RuleFor(p => p.UserInfo.FirstName).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.UserInfo.LastName).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.UserInfo.Email).Cascade(CascadeMode.Stop).NotNull().NotEmpty().Must(p => commonService.IsValidEmailAddress(p)).WithMessage("Invalid Email Address");
        RuleFor(p => p.UserInfo.Password).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.UserInfo.ConfirmPassword).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.UserInfo.Msisdn).Cascade(CascadeMode.Stop).NotNull().NotEmpty().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
        //.WithMessage("Your password cannot be empty")
        //.MinimumLength(8).WithMessage("Your password length must be at least 8.")
        //.MaximumLength(20).WithMessage("Your password length must not exceed 16.")
        //.Matches(@"[A-Z]+").WithMessage("Your password must contain at least one uppercase letter.")
        //.Matches(@"[a-z]+").WithMessage("Your password must contain at least one lowercase letter.")
        //.Matches(@"[0-9]+").WithMessage("Your password must contain at least one number.")
        //.Matches(@"[\!\?\*\.]+").WithMessage("Your password must contain at least one (!? *.).");
        RuleFor(x => x).Custom((x, context) =>
        {
            if (x.UserInfo.Password != x.UserInfo.ConfirmPassword)
            {
                context.AddFailure(nameof(x.UserInfo.Password), "Passwords should match");
            }
        });

        #endregion

        //#region App Info Validation
        //RuleFor(p => p.AppInfo.CpuArchitecture).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.ActionExecuted).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DeviceOS).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DeviceOSVersion).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DeviceMake).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DeviceModel).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DeviceLanguage).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.DevicePersistentID).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.AppVersion).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //RuleFor(p => p.AppInfo.AppLanguage).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        //#endregion
    }
}