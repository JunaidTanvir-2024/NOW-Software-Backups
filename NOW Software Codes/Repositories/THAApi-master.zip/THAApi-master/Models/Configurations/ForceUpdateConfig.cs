﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class ForceUpdateConfig
    {
        public DisabledMessages disabledMessage { get; set; }
        public List<string> disabledVersionsAndroid { get; set; }
        public List<string> disabledVersionsIos { get; set; }
    }

    public class DisabledMessages
    {
        public string el { get; set; }
        public string en { get; set; }
        public string it { get; set; }
        public string fr { get; set; }

    }
}
