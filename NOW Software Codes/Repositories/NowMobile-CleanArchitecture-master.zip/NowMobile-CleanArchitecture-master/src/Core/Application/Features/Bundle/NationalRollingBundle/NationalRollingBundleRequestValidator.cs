namespace Application.Features.Bundle.NationalRollingBundle;

public sealed class NationalRollingBundleRequestValidator : AbstractValidator<NationalRollingBundleRequest>
{
    public NationalRollingBundleRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
    }
}
