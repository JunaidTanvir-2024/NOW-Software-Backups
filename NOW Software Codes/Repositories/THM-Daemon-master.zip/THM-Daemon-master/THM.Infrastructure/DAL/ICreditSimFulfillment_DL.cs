﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using THM.Models.Contracts;
using THM.Models.Database;
using THM.Models.Enums;

namespace THM.Infrastructure.DAL
{
    public interface ICreditSimFulfillment_DL
    {
        Task<IEnumerable<DbSimOrderPool>> GetActiveNumbersFromPool();
        Task<DbResult<List<DbCreditSimOrderDetail>>> GetCreditSimOrderDetail(string msisdn);
        Task<DbResult<string>> UpdateCreditSimFullfilment(long id, bool isFullfilled, string fulfillment_error_message, string fulfillment_ref);
        Task<DbResult<DbAddBundleOrTopupResult>> AddBundleOrTopup(
            string transactionId, string bundleRef, string amount, string msisdn, PaymentType paymentType,string email);
        Task UpdateCreditSimFullfilmentInSimPool(int id, bool isFullfiled, string errorMessage);
    }
}
