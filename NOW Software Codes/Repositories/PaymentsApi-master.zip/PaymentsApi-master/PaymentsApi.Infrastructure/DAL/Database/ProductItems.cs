﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public class ProductItems
    {
        public float AmountLimit { get; set; }
        public string ProductItemCode { get; set; }
        public string ProductItemName { get; set; }
        public string ProductCode { get; set; }       
    }

    public class ValidateRes
    {
        public float Errorcode { get; set; }
        public string Errormsg { get; set; }
        public Int32 Tamount { get; set; }
    }

    public class TAmount
    {
        public Int32 Tamount { get; set; }
    }
}
