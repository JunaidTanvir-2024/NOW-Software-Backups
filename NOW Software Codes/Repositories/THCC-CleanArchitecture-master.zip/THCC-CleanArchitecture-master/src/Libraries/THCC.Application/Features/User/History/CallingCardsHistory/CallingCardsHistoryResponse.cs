﻿
namespace THCC.Application.Features.User.History.CallingCardsHistory
{
    public class CallingCardsHistoryResponse
    {
        public string? Card { get; set; }
        public string? Pin { get; set; }
    }
}
