﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBBundles
    {
        public Guid ID { get; set; }
        public string BrandedName { get; set; }
        public string Description { get; set; }
        public string PackageType { get; set; }
        public string PackageCategory { get; set; }
        public int TotalCostPence { get; set; }
        public int ChargePeriodDays { get; set; }
        public int Texts { get; set; }
        public int Seconds { get; set; }
        public int Minutes { get; set; }
        public string Remarks { get; set; }
        public string RemainingMinutes { get; set; }
        public DateTime Expiry { get; set; }
    }
}
