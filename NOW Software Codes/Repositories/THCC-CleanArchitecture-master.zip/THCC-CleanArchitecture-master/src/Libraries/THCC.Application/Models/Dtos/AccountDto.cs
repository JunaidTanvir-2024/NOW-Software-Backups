﻿namespace THCC.Application.Models.Dtos
{
    public class AccountDto
    {
        public string? CardNumber { get; set; }
        public string? PinNumber { get; set; }
        public string? Credit { get; set; }
        public string? SubscriberId { get; set; }
        public int SubscriberState { get; set; }
        public int AccountState { get; set; }
    }
}
