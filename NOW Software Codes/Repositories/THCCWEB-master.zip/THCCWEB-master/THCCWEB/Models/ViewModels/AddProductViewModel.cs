﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ViewModels
{
    public class AddProductViewModel
    {
        [Required(ErrorMessage = "Card number is required")]
        public string cardnumber { get; set; }

        [Required(ErrorMessage = "Pin number is required")]
        public string pinnumber { get; set; }
    }
}
