using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class Subscription : IBaseEntity<long>
{
    public long Id { get; set; }
    public decimal Price { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsDeleted { get; set; } = false;
    public DateTime StartDate { get; set; }
    public DateTime ExpiryDate { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public DateTime? DeletedAt { get; set; }
    public ICollection<SubscriptionBenefit> Benefits { get; set; } = null!;
    public ICollection<UserSubscription> UserSubscriptions { get; set; } = null!;
}
