﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum Status
    {
        Success = 1,
        Failure = 2
    }
}
