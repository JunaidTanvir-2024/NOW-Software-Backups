﻿using PaymentsApi.Models.Utility;
using System;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public class Pay360TransactionSummary
    {
        public long Id { get; set; }
        public double? TransactionAmount { get; set; }
        public string TransactionCurrency { get; set; }
        public string Pay360TransactionId { get; set; }
        public string TransactionMerchantRef { get; set; }
        public string CustomerMerchantRef { get; set; }
        public Pay360SummaryTransactionStatuses TransactionStatus_Id { get; set; }
        public Pay360SummaryTransactionTypes TransactionType_Id { get; set; }
        public int Customer_Id { get; set; }
        public long? Preauth_Transaction_Id { get; set; }
        public long? Capture_Transaction_Id { get; set; }
        public long? Single_Payment_Transaction_Id { get; set; }
        public DateTime? Transaction_PreAuth_DateTime { get; set; }
        public DateTime? Transaction_Capture_DateTime { get; set; }
        public DateTime? Transaction_SinglePayment_DateTime { get; set; }
        public DateTime? Transaction_Fulfilment_DateTime { get; set; }
        public DateTime? Transaction_SmsSent_DateTime { get; set; }
        public DateTime? Transaction_EmailSent_DateTime { get; set; }
        public string Fullfilment_Ref { get; set; }
        public bool IsProcessedByDaemon { get; set; }
        public bool ThreeDSecureCompleted { get; set; }
        public bool Is3DSecure { get; set; }
        public bool IsSmsSent { get; set; }
        public bool IsEmailSent { get; set; }
        public bool IsDirectFullfilment { get; set; }
    }
}
