﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SenderService.Core.Features.EmailValidation.Response;
using SenderService.Core.Persistence.Entities;
using System.Data;

namespace SenderService.Core.Persistence.Repository;

public interface IEmailValidationRepository
{
    Task AddEmailValidationAsync(EmailValidation emailValidation);
    Task DeleteEmailValidationAsync(long id);
    Task<List<EmailValidation>> GetEmailValidationsAsync();
    Task<EmailValidation?> GetEmailValidationByIdAsync(long id);
    Task UpdateEmailValidationAsync(EmailValidation emailValidation);
    Task<bool> IsEmailVerifiedAsync(string email);
    EmailStatus? CheckEmailStatus(string domain, string email);
    Task AddEmailValidation(string email, string status, string domain, string subStatus, string productCode, string requestBody, string responseBody, string ipAddress);
}

internal sealed class EmailValidationRepository : IEmailValidationRepository
{
    private readonly SenderServiceContext _dbContext;
    private readonly IConfiguration _configuration;

    public EmailValidationRepository(SenderServiceContext dbContext, IConfiguration configuration)
    {
        _dbContext = dbContext;
        _configuration = configuration;
    }

    public async Task<EmailValidation?> GetEmailValidationByIdAsync(long id)
    {
        return await _dbContext.Set<EmailValidation>().FirstOrDefaultAsync(x => x.Id == id);
    }

    public async Task<List<EmailValidation>> GetEmailValidationsAsync()
    {
        return await _dbContext.Set<EmailValidation>().ToListAsync();
    }

    public async Task AddEmailValidationAsync(EmailValidation emailValidation)
    {
        emailValidation.ProcessDate = DateTime.UtcNow;
        _dbContext.Set<EmailValidation>().Add(emailValidation);
        await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateEmailValidationAsync(EmailValidation emailValidation)
    {
        emailValidation.ProcessDate = DateTime.UtcNow;
        _dbContext.Set<EmailValidation>().Update(emailValidation);
        await _dbContext.SaveChangesAsync();
    }

    public async Task DeleteEmailValidationAsync(long id)
    {
        var emailValidation = await GetEmailValidationByIdAsync(id);
        if (emailValidation != null)
        {
            _dbContext.Set<EmailValidation>().Remove(emailValidation);
            await _dbContext.SaveChangesAsync();
        }
    }
    public async Task<bool> IsEmailVerifiedAsync(string email)
    {
        var emailValidation = await _dbContext.Set<EmailValidation>().FirstOrDefaultAsync(x => x.Email == email);
        return emailValidation != null && emailValidation.IsVerified;
    }
    public EmailStatus? CheckEmailStatus(string domain, string email)
    {
        var results = _dbContext.Set<EmailStatus>().FromSqlInterpolated($"EXECUTE SP_VerifyEmailAddress @Email = {email}, @Domain = {domain}").AsEnumerable();
        return results.FirstOrDefault();
    }
    public async Task AddEmailValidation(string email, string status, string domain, string subStatus, string productCode, string requestBody, string responseBody, string ipAddress)
    {
        await _dbContext.Database.ExecuteSqlInterpolatedAsync($"EXECUTE SP_AddEmailValidation @Email={email}, @Status={status}, @Domain={domain}, @SubStatus={subStatus}, @ProductCode={productCode}, @RequestBody={requestBody}, @ResponseBody={responseBody}, @IpAddress={ipAddress}");
    }
}
