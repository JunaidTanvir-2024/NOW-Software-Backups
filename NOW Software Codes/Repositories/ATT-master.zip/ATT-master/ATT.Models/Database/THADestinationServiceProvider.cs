﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Database
{
    public class THADestinationServiceProvider
    {
        public string destaination_country_code { get; set; }
        public string destination_operator_name { get; set; }
        public string destination_country_name { get; set; }
        public string service_provider { get; set; }
        public int? service_provider_id { get; set; }
        public int csdp_config_id { get; set; }
        public bool use_db_rates { get; set; }
    }
}
