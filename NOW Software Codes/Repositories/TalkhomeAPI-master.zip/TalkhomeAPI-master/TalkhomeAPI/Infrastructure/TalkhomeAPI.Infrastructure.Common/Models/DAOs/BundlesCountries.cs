﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class BundlesCountries
    {
        public string ISO_Code { get; set; }
        public string Country { get; set; }
        public string Na_Service_Id { get; set; }
        public string Currency { get; set; }
    }
}
