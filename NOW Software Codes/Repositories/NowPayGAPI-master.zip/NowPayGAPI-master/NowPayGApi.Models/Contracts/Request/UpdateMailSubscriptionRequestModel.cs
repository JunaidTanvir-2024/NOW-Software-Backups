﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class UpdateMailSubscriptionRequestModel
    {
        public int UserID { get; set; }
        public bool MailSubscription { get; set; }
    }
}
