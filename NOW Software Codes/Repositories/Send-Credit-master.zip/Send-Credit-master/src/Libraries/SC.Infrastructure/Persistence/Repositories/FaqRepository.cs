﻿using RW.Models;

using SC.Core.Models.Dtos;
using SC.Core.Models.Entities;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Infrastructure.Persistence.Repositories
{
    public class FaqRepository : IFaqRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;

        public FaqRepository(IConfiguration configuration, ILogger logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<(IEnumerable<GetFaqsbyOperatorDto.Response> operatorFaqs, DatabasePaginationDto pagination)> GetFaqsbyOperator(GetFaqsbyOperatorDto.Request request)
        {
            try
            {
                using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
                {

                    var faqParameters = new DynamicParameters();
                    faqParameters.Add("operator_shortcode", request?.OperatorShortCode);
                    faqParameters.Add("is_active", request?.IsActive);
                    faqParameters.Add("is_deleted", request?.IsDeleted);
                    faqParameters.Add("page", request?.Page);
                    faqParameters.Add("records_per_page", request?.RecordsPerPage);

                    faqParameters.Add("total_pages", 0, direction: ParameterDirection.Output);
                    faqParameters.Add("total_records", 0, direction: ParameterDirection.Output);


                    var responseFaqs = await connection.QueryAsync<GetFaqsbyOperatorDto.Response>(AppConstants.StoreProcedures.GetFaqByOperator, param: faqParameters, commandType: CommandType.StoredProcedure);


                    // Read the output parameters
                    var totalRecords = faqParameters.Get<int>("total_records");
                    var totalPages = faqParameters.Get<int>("total_pages");
                    return (responseFaqs, new DatabasePaginationDto() { TotalPages = totalPages, TotalRecords = totalRecords });

                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, nameof(FaqRepository), nameof(GetFaqsbyOperator));
                return default!;
            }
        }
    }
}
