using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Loyalties;

public class Loyalty
{
    [JsonPropertyName("points")]
    public int Points { get; set; }

    [JsonPropertyName("type")]
    public string? Type { get; set; }

    [JsonPropertyName("custom_event")]
    public Metadata? PointsInfo { get; set; }
}
