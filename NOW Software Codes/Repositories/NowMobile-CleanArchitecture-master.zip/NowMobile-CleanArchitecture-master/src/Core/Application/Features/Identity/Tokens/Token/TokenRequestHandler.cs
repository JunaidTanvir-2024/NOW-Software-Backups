﻿using Application.Common.Enums;
using Application.Common.Interfaces.Infrastructure.Identity;
using Application.Common.Mailing;
using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.Identity.Tokens.Token;

public class TokenRequestHandler : IRequestHandler<TokenRequest, Result<TokenResponse>>
{
    #region Fields

    private readonly ITokenService _tokenService;
    private readonly IStringLocalizer<RefreshTokenRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly IOtpService _otpService;
    private readonly IMapper _mapper;
    private readonly IMailService _mailService;
    private readonly ISmsService _smsService;
    private readonly IAirshipService _airshipService;
    private readonly LoginSettings _loginSettings;

    #endregion

    #region Ctor

    public TokenRequestHandler(
        ITokenService tokenService,
        IStringLocalizer<RefreshTokenRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService,
        IOptions<LoginSettings> loginSettings,
        IOtpService otpService,
        IMapper mapper,
        IMailService mailService,
        ISmsService smsService,
        IAirshipService airshipService)
    {
        _tokenService = tokenService;
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _otpService = otpService;
        _mapper = mapper;
        _mailService = mailService;
        _smsService = smsService;
        _airshipService = airshipService;
        _loginSettings = loginSettings.Value;
    }

    #endregion

    #region Methods

    public async Task<Result<TokenResponse>> Handle(TokenRequest request, CancellationToken cancellationToken)
    {
        //Check if request is from App
          (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();
        User? user;
        LoginType loginType;
        request.UserInfo.EmailOrPhone = request.UserInfo.EmailOrPhone.Trim().Normalize();

        if (_commonService.IsValidEmailAddress(request.UserInfo.EmailOrPhone))
        {
            loginType = LoginType.Email;
            user = await _unitOfWork.UserRepo.GetUserByEmail(request.UserInfo.EmailOrPhone);
        }
        else
        {
            request.UserInfo.EmailOrPhone = _commonService.FormatMsisdn(request.UserInfo.EmailOrPhone);
            loginType = LoginType.PhoneNumber;
            user = await _unitOfWork.UserRepo.GetUserByMsisdn(request.UserInfo.EmailOrPhone);
        }

        //User not registered
        if (user == null)
        {
            return Result<TokenResponse>.Failure(_localizer[CustomStatusKey.InvalidCredentials], CustomStatusCode.InvalidCredentials);
        }
        //For Existing Users who had social signup and had no password 
        if (user.Password == null)
        {
            return Result<TokenResponse>.Failure(_localizer[CustomStatusKey.InvalidCredentials], CustomStatusCode.InvalidCredentials);
        }

        //Validate user for any type of de-activation

        //Validate Password
        if (!user.Password.Equals(CryptoHelper.Hash(request.UserInfo.Password), StringComparison.CurrentCultureIgnoreCase))
        {
            if (_loginSettings.InvalidLogin.IsActive)
            {
                await _unitOfWork.UserRepo.SaveInvalidLoginAttempt(user.Id, request.IpAddress);
            }
            return Result<TokenResponse>.Failure(_localizer[CustomStatusKey.InvalidCredentials],
                CustomStatusCode.InvalidCredentials);
        }
         await _unitOfWork.UserRepo.LoginLogs(user.Id, (int)loginType);

        //Save device logs and mark current device as active for user
        if (IsAppRequest)
        {
            //Check if user device used for first time
            if (await _unitOfWork.DeviceRepo.IsNewDevice(request.AppInfo.DevicePersistentID, user.Id))
            {
                //Save device logs as login action
                var userDeviceLog = _mapper.Map<UserDeviceLog>((request, user));
                await _unitOfWork.DeviceRepo.SaveDeviceLog(userDeviceLog);
               

                //Save user device as un-confirmed and in-active
                await _unitOfWork.DeviceRepo.SaveUserDeviceAsInActive(
                    request.AppInfo.DevicePersistentID, (DeviceType) deviceType!, user.Id);

                //Send otp message
                var (Otp, otpModel) = await _otpService.CreateOtp(request.UserInfo.EmailOrPhone + "-" + request.AppInfo.DevicePersistentID, OtpType.Device, null);
                if (otpModel.StatusCode != CustomStatusCode.OtpIsNotCreated)
                {
                    if (loginType == LoginType.Email)
                    {
                        await _mailService.SendSignupEmailOtpAsync(request.UserInfo.EmailOrPhone, Otp, null);
                    }
                    else
                    {
                        await _smsService.SendOtpMessage(request.UserInfo.EmailOrPhone, Otp.ToString()!);
                    }
                }
                return Result<TokenResponse>.Failure(_localizer[CustomStatusKey.DeviceNotVerified], CustomStatusCode.DeviceNotVerified);
            }
            else
            {
                //Save device logs as login action
                var userDeviceLog = _mapper.Map<UserDeviceLog>((request, user));
                await _unitOfWork.DeviceRepo.SaveDeviceLog(userDeviceLog);


                //Mark current device as active for user
                await _unitOfWork.DeviceRepo.MarkDeviceAsActive(
                    request.AppInfo.DevicePersistentID, (DeviceType) deviceType!, user.Id);
            }
            await _airshipService!.AddEmailChannelCommercial(user?.Email);

            //Associate email with named user
            _airshipService.EmailAssociationWithNamedUser(user?.Email, user?.Email);
        }

        //Get user auth token
        var tokenInfo = await _tokenService.GetTokenAsync(user, request.IpAddress!, cancellationToken);

        return Result<TokenResponse>.Success(tokenInfo, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}