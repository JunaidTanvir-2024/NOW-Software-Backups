﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PayPalInApp.Configurations;
using PayPalInApp.Interfaces;
using PayPalInApp.Models;
using PayPalInApp.Models.AirShip;
using Serilog;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace PayPalInApp.Services
{
    public class AirShipService : IAirShipService
    {

        private readonly string AirShipApiEndpoint;
        private readonly ILogger Logger;
        public AirShipService(ILogger logger, IOptions<AppConfig> appConfig)
        {
            Logger = logger;
            AirShipApiEndpoint = appConfig.Value.AirShipApiEndpoint;
        }

        public async Task<GenericAirShipApiResponse<string>> AddNamedUserTags(NamedUserTagsRequest request)
        {
            string endpoint = AirShipApiEndpoint + "NamedUser/AddNuserTags";

            GenericAirShipApiResponse<string> ret = new GenericAirShipApiResponse<string>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                Logger.Error($"Controller: AirShipService, Method: AddNamedUserTags, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:null ");
                return null; 
            }

            //LoggerService.Debug(GetType(), Result);
            ret = JsonConvert.DeserializeObject<GenericAirShipApiResponse<string>>(Result);
            if (ret.errorCode != 0)
            {
                Logger.Error($"Controller: AirShipService, Method: AddNamedUserTags, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:{Result} ");
            }
            return ret;
        }

        public async Task<GenericAirShipApiResponse<string>> AddCustomEvent(CustomEventsRequest request)
        {
            string endpoint = AirShipApiEndpoint + "CustomEvent/AddCustomEvent";

            GenericAirShipApiResponse<string> ret = new GenericAirShipApiResponse<string>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                Logger.Error($"Controller: AirShipService, Method: AddCustomEvent, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:null ");
                return null;
            }

            //LoggerService.Debug(GetType(), Result);
            ret = JsonConvert.DeserializeObject<GenericAirShipApiResponse<string>>(Result);
            if (ret.errorCode != 0)
            {
                Logger.Error($"Controller: AirShipService, Method: AddCustomEvent, Parameters=> NamedUserTagsRequest: {JsonConvert.SerializeObject(request)}, ErrorMessage:Response:{Result} ");
            }
            return ret;
        }

        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address), Timeout = TimeSpan.FromSeconds(60) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                        throw new WebException();

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (System.Exception e)
            {

                return null;
            }
        }
    }
}
