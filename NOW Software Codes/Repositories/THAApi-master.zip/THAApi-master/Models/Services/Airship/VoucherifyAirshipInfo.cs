﻿namespace Models.Services.Airship
{
    public class VoucherifyAirshipInfo
    {
        public CouponInfo Coupon { get; set; }
        public ReferralInfo Referral { get; set; }
        public DirectPromotionInfo DirectPromotion { get; set; }
        public BundleInfo Bundle { get; set; }
        public TopupInfo Topup { get; set; }
        public InternationalTopupInfo InternationalTopup { get; set; }

        public class CouponInfo
        {
            public string CampaignName { get; set; }
            public bool Status { get; set; }
        }
        public class ReferralInfo
        {
            public bool IsReferredUser { get; set; }
        }
        public class DirectPromotionInfo
        {
            public bool Status { get; set; }
        }
        public class BundleInfo
        {
            public bool IsWelcome { get; set; }
            public int? Points { get; set; }
        }
        public class TopupInfo
        {
            public bool IsFirst { get; set; }
            public int? Points { get; set; }
        }
        public class InternationalTopupInfo
        {
            public bool IsFirst { get; set; }
            public int? Points { get; set; }
        }
    }
}
