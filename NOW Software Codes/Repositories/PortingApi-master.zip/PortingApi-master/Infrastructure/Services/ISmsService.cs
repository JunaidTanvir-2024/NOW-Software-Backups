﻿using Models.Contracts.Response.SmsApiResponse;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public interface ISmsService
    {
        Task<XeebiSendSmsResponse> SendXeebiSms(string to, string textMessage);
    }
}