﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{
    public class ReloadlyConfig
    {
        public string AuthApiEndPoint { get; set; }
        public bool SimulationMode { get; set; }
        public bool JsonResponseLogging { get; set; }
        public string simulation_client_id { get; set; }
        public string simulation_client_secret { get; set; }
        public string simulation_audience { get; set; }
        public string prod_client_id_eur { get; set; }
        public string prod_client_secret_eur { get; set; }
        public string prod_client_id_gbp { get; set; }
        public string prod_client_secret_gbp { get; set; }
        public string prod_client_id_usd { get; set; }
        public string prod_client_secret_usd { get; set; }
        public string prod_audience { get; set; }
        public string grant_type { get; set; }
        public bool SendSmsToSender { get; set; }
        public string smsTemplate { get; set; }
        public bool CalculateVIAFx { get; set; }
        public string SuggestedAmountOperatorCodes { get; set; }
    }
}
