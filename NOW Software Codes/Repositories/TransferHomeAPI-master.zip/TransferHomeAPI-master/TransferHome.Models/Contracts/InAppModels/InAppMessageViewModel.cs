﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.InAppModels
{
    public class InAppMessageViewModel
    {
        public InAppMessageViewModel()
        {
            FirebaseTopUpEvent = new FirebaseUserTopUpEventModel();
            FirebaseTransferEvent = new FirebaseUserTransferEventModel();
        }
        public string Heading { get; set; }
        public string Message { get; set; }

        /// <summary>
        /// Model to be sent to firebase on successful topup
        /// </summary>
        public FirebaseUserTopUpEventModel FirebaseTopUpEvent { get; set; }
        /// <summary>
        /// Model to be sent to firebase on successful transfer
        /// </summary>
        public FirebaseUserTransferEventModel FirebaseTransferEvent { get; set; }
    }

    public class FirebaseUserTopUpEventModel
    {
        public string Msisdn { get; set; }
        public string TopUpAmount { get; set; }
        public string Currency { get; set; }
        public string TopUpDateTime { get; set; }
        public bool IsFirstTimeTopUp { get; set; }
        public string TopUpBy { get; set; }
    }

    public class FirebaseUserTransferEventModel
    {
        public string Msisdn { get; set; }
        public string DestinationNumber { get; set; }
        public string DestinationCountry { get; set; }
        public string OperatorName { get; set; }
        public string TransferAmount { get; set; }
        public string TransferAmountCurrency { get; set; }
        public string TransferDateTime { get; set; }
        public string TransferFrom { get; set; }

    }
}
