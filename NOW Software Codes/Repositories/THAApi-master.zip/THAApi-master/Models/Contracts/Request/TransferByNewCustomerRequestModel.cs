﻿using Models.Contracts.Request.Voucherify;
using Models.Contracts.Response;
using Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;

namespace Models.Contracts.Request
{
	public class TransferByCardResponseModel
	{
		public TransferData transferData { get; set; }
		public ThreeDSecureData threeDSecureData { get; set; }
		public string ipAddress { get; set; }
		public InternationalTopupInfo intTopupInfo { get; set; }
        public string CampaignName { get; set; }
        public bool IsRedeemedSuccess { get; set; }
        public bool IsFirstInternationalTopup { get; set; }
        public decimal FromAmount { get; set; }
    }
	public class Pay360Resume3DResponseModel
	{
		public TopupInfo topupInfo { get; set; }
	}
	public class TransferByPay360Resume3DData
	{
		public string nowtelRef { get; set; }
		public string product { get; set; }
		public string operatorId { get; set; }
		public string customerEmail { get; set; }
		public string threeDsV { get; set; }
		public string msisdn { get; set; }
		public string currency { get; set; }
		public string account { get; set; }
		public ThemeMode ThemeMode { get; set; }
		public string AppsFlyerId { get; set; }
		public DeviceType DeviceType { get; set; }
		public string IpAddress { get; set; }
		public string advertiserID { get; set; }
		public bool IsTransferRequest { get; set; } = false;
		public bool AirshipEventsDisable { get; set; }
	}
	public class TransferByPay360Resume3DDataV2: TransferByPay360Resume3DData
	{
        public string DiscountCode { get; set; }
        public DiscountCodeType DiscountCodeType { get; set; }
    }
	public class TransferData
	{
		public string TransactionId { get; set; }
		public string fromMsisdn { get; set; }
		public string fromAmount { get; set; }
		public string fromCurrency { get; set; }

		public string toMsisdn { get; set; }
		public string toAmount { get; set; }
		public string toCurrency { get; set; }

		public string fromCountry { get; set; }
		public string toCountry { get; set; }
	}
	public class TransferByNewCustomerRequestModel
	{
		[Required]
		[MaxLength(200)]
		public string nowtelRef { get; set; }

		[Required]
		public string product { get; set; }

		[Required]
		public int operatorId { get; set; }
		public string messageToRecipient { get; set; }

		public PaymentCardModel cardData { get; set; }
		//public AppsFlyerInfo AppsFlyerInfo { get; set; }
		public BillingAddressModel billingAddressData { get; set; }
		public string AppsFlyerId { get; set; }
		public int DeviceType { get; set; }
		public bool IsTransferRequest { get; set; } = false;
	}
	public class TransferByNewCustomerRequestModelV2 : TransferByNewCustomerRequestModel
	{
        public string DiscountCode { get; set; }
        public DiscountCodeType DiscountCodeType { get; set; }
    }
	public class TransferByExistingCustomerRequestModel
	{
		[Required]
		[MaxLength(300)]
		public string CardToken { get; set; }

		[Required(ErrorMessage = "Enter Security Code"),
			StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
		[RegularExpression("([0-9]+)", ErrorMessage = "Please enter valid Number")]
		public string SecurityCode { get; set; }
		public bool IsDefaultCard { get; set; }

		[Required]
		[MaxLength(200)]
		public string nowtelRef { get; set; }

		[Required]
		public string product { get; set; }

		[Required]
		public int operatorId { get; set; }

		public string messageToRecipient { get; set; }

		//public AppsFlyerInfo AppsFlyerInfo { get; set; }
		public string AppsFlyerId { get; set; }
		public int DeviceType { get; set; }
		public bool IsTransferRequest { get; set; } = false;
	}
	public class TransferByExistingCustomerRequestModelV2: TransferByExistingCustomerRequestModel
	{
        public string DiscountCode { get; set; }
        public DiscountCodeType DiscountCodeType { get; set; }
    }
}
