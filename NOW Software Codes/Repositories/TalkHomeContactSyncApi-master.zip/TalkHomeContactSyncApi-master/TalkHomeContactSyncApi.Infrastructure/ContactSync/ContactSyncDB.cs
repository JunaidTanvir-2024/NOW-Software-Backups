﻿using Dapper;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Request;
using TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Response;
using TalkHomeContactSyncApi.Models.Configuration;
using TalkHomeContactSyncApi.Models.Database;

namespace TalkHomeContactSyncApi.Infrastructure.ContactSync
{
    public class ContactSyncDB :IContactSyncDB
    {
        private string Connectionstring;
        private IDbConnection DbConnection { get { return new SqlConnection(Connectionstring); } }
        private readonly ILogger logger;

        public ContactSyncDB(IOptions<ConnectionStrings> connectionStrings, ILogger logger)
        {
            this.Connectionstring = connectionStrings.Value.DefaultConnectionString;
            this.logger = logger;
        }
        
        //Compare the contact and respond which is talkhome user or not.
        async public Task<IList<ContactSyncResponse>> GetFilteredTalkHomeContacts(DataTable dataTable)
        {
            IList<ContactSyncResponse> FilteredContacts = new List<ContactSyncResponse>();
            try
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                var result =await DbConnection.QueryAsync<ContactSyncResponse>("tha_check_contacts", new { Contacts = dataTable.AsTableValuedParameter("[dbo].[Tha_Contacts]") }, commandType: CommandType.StoredProcedure);
                stopwatch.Stop();
                Console.WriteLine($"Querying DB took {stopwatch.ElapsedMilliseconds} ms");
                if (result != null)
                {
                    FilteredContacts = result.AsList();
                }
            }
            catch (Exception ex)
            {
                logger.Error($"ContactSyncDB-> GetFilteredTalkHomeContacts-> Sp_TalkHomeContactSyncApi_GetTalkHomeContactOrNot ErrorMessage: +{ex.Message}");
                Console.WriteLine("ContactSyncDB-> GetFilteredTalkHomeContacts-> Sp_TalkHomeContactSyncApi_GetTalkHomeContactOrNot ErrorMessage: check Logs for details");
            }
            return FilteredContacts;
        }

        public async Task<User> Login(string userName, string password)
        {
            User response = null;
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserName", userName);
                parameters.Add("@Password", password);
                response = await DbConnection.QueryFirstOrDefaultAsync<User>("tha_Api_Login", parameters, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                logger.Error($"Class: ContactSyncDB, Method: Login, StoredProcedure: tha_Api_Login, Parameters--> UserName: {userName}, Password: {password},  ErrorMessage: {ex.Message}");
            }
            return response;
        }
    }
}
