﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request
{
    public class VerifyEmailRequestModel
    {
        [Required]
        public string Token { get; set; }

        public int TokenTypeId { get; set; }

    }
}
