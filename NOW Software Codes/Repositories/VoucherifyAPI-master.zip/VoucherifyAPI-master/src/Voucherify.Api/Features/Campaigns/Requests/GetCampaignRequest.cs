﻿using FluentValidation;

namespace Voucherify.Api.Features.Campaigns.Requests;

public class GetCampaignRequest
{
    public string CampaignNameOrId { get; set; } = null!;
}
internal class GetCampaignByIdOrNameRequestValidator : AbstractValidator<GetCampaignRequest>
{
    public GetCampaignByIdOrNameRequestValidator()
    {
        RuleFor(p => p.CampaignNameOrId).NotNull().NotEmpty();
    }
}