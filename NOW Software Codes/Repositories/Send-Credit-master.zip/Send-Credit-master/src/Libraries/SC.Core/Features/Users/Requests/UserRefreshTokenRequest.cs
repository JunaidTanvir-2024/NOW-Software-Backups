﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Users.Requests;
public sealed class UserRefreshTokenRequest : IRequest<IResultWrapper>
{
    public string Token { get; set; } = default!;
    public string RefreshToken { get; set; } = default!;
}
public sealed class UserRefreshTokenRequestValidator : AbstractValidator<UserRefreshTokenRequest>
{
    public UserRefreshTokenRequestValidator()
    {
        RuleFor(x => x.Token).NotNull();
        RuleFor(x => x.RefreshToken).NotNull();
    }
}

