using System.Data;

using Dapper;

using FH.Core.Definitions;
using FH.Core.Entities;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;

using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

using Serilog;

namespace FH.Infrastructure.Persistence.Repositories;

internal sealed class VendorRepository(IConfiguration configuration, ILogger logger) : IVendorRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private readonly ILogger _logger = logger;

    public async Task<long> VendorInsert(VendorEntity vendorDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("batch_hash", vendorDto.BatchHash);
                parameters.Add("api_type", vendorDto.ApiType);
                parameters.Add("api_page", vendorDto.ApiPage);
                parameters.Add("vendor_id", vendorDto.VendorId);
                var id = await connection.QueryFirstOrDefaultAsync<long>(AppConstants.Database.StoreProcedure.VendorDataHashInsert, parameters, commandType: CommandType.StoredProcedure);
                return id;
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(VendorRepository), nameof(VendorInsert));
            return default!;
        }
    }
    public async Task<string?> GetVendorHash(VendorEntity vendorDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("api_type", vendorDto.ApiType);
                parameters.Add("api_page", vendorDto.ApiPage);
                parameters.Add("vendor_id", vendorDto.VendorId);

                var vendorDataHash = await connection.QueryFirstOrDefaultAsync<string>(AppConstants.Database.StoreProcedure.VendorDataHashGet, parameters, commandType: CommandType.StoredProcedure);
                return vendorDataHash;
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(VendorRepository), nameof(GetVendorHash));
            return default!;
        }
    }
}
