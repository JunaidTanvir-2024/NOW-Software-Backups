﻿

using System.Data.SqlTypes;
using System.Text.Json.Serialization;


namespace SC.Core.Features.CustomerOrder.Requests;
public sealed class OrderCreationRequest : IRequest<IResultWrapper>
{
    public long CustomerOrderID { get; set; } = default!;
    public string CustomerID { get; set; } = default!;
    public string PromoCode { get; set; } = default!;
    public int? DiscountTypeId { get; set; } = default!;
    public decimal DiscountAmount { get; set; } = decimal.Zero;
    public decimal ServiceFee { get; set; } = decimal.Zero;
    public decimal TaxAmount { get; set; } = decimal.Zero;
    public decimal TaxInclusiveAmount { get; set; } = decimal.Zero;
    public decimal TaxExclusiveAmount { get; set; } = decimal.Zero;
    public decimal TotalOrderAmount { get; set; } = decimal.Zero;
    public string Currency { get; set; } = default!;
    public OrderStatusEnum OrderStatus { get; set; } = default!;
    public bool IsActive { get; set; } = true;
    public bool IsDeleted { get; set; } = false;
}
public sealed class OrderCreationRequestValidator : AbstractValidator<OrderCreationRequest>
{
    public OrderCreationRequestValidator()
    {
        RuleFor(x => x.OrderStatus).IsInEnum();
    }
}

