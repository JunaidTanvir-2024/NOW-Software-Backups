﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SMSOutReach.Model.Connections
{
    
    public interface IDbConnectionSettings
    {
        IDbConnection SqlConnection { get; }
    }
}
