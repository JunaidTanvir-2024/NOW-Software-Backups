﻿using CancelBundleApi.Helpers.HttpService;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CancelBundleApi.Extensions.DependencyContainers.ServicesContainers;

internal static class HttpServiceContainer
{
    public static IServiceCollection RegisterHttpServices(this IServiceCollection services, IConfiguration config)
    {
        //services.AddHttpClient();
        services.AddScoped<IHttpService, HttpService>();
        return services;
    }
}
