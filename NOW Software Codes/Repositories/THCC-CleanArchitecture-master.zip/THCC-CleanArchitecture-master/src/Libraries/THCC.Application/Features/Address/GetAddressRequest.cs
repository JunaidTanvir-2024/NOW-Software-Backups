﻿namespace THCC.Application.Features.Address;
public class GetAddressRequest : IRequest<object>
{
    public string PostCode { get; set; } = default!;
}
public class AddressRequestValidator : AbstractValidator<GetAddressRequest>
{
    public AddressRequestValidator()
    {
        RuleFor(p => p.PostCode)
            .NotNull()
            .NotEmpty()
            .WithMessage("Please provide valid postal code");
    }
}