﻿using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Repositories
{
    public interface ILegacyRepository : ServiceType.IScoped
    {
        Task<LegacyUser> GetUserByEmail(string emailAddress);
        Task<LegacyProduct> GetUserProducts(long userId);
    }
}
