﻿

namespace SC.Core.Common.Definitions.Constants;
public static partial class AppEnums
{
    public enum OperatorRequestType
    {
        AllCountries = 1,
        CountryByIsoCode = 2
    }
    public enum ProductRequestType
    {
        AllProducts = 1,
        ProductByName = 2

    }
}
