﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IHistory_BL
    {
        Task<IEnumerable<UserAccountPaymentHistory>> GetPaymentHistory(string msisdn);
        Task<GenericApiResponse<object>> GetEntirePaymentHistory(string msisdn, string account);
        Task<GenericApiResponse<object>> GetEntirePaymentHistoryV2(string msisdn, string account);
    }
}
