﻿using Application.Common.Caching;
using Application.Common.Interfaces.Payment;

namespace Application.Features.Account.DeleteAccount;
public class DeleteAccountRequestHandler : IRequestHandler<DeleteAccountRequest, Result<object>>
{
    #region Fields

    private readonly IStringLocalizer<DeleteAccountRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;
    private readonly ICurrentUser _currentUser;
    private readonly ICardService _cardService;

    #endregion

    #region Ctor

    public DeleteAccountRequestHandler(

        IStringLocalizer<DeleteAccountRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService,
        ICurrentUser currentUser,
          ICardService cardService

       )
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _cacheService = cacheService;
        _cacheKeyService = cacheKeyService;
        _currentUser = currentUser;
        _cardService = cardService;
    }

    #endregion

    #region Method
    public async Task<Result<object>> Handle(DeleteAccountRequest request, CancellationToken cancellationToken)
    {
        User? user;
        user = await _unitOfWork.UserRepo.GetUserByEmail(request.Email);
        //User not registered
        if (user == null)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidCredentials], CustomStatusCode.InvalidCredentials);
        }
        //Validate Password
        bool isAuthenticated = SecurityHelper.CheckPassword(request.Password, user);
        if (_currentUser.GetUserEmail() == request.Email && isAuthenticated)
        {
            var response = await _unitOfWork.UserRepo.DeleteAccount(_currentUser.GetUserId(), _currentUser.GetUserEmail()!);
            if (response?.Code > 0)
            {
                return Result<object>.Failure(null!, _localizer[response.Message!], response.Code);
            }

            // Remove Card
            var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
            if (cards?.Count() > 0)
            {
                foreach (var item in cards)
                {
                    await _cardService.RemoveCard(item.CardToken, _currentUser.GetUserEmail()!);
                }
            }

            //Clear cahe because user deleted

            await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, _currentUser.GetUserEmail()!), cancellationToken);
            await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, _currentUser.GetUserId().ToString()), cancellationToken);
            var userProducts = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
            if (userProducts?.Any() == true)
            {
                foreach (var item in userProducts)
                {
                    await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.User, item.Msisdn!), cancellationToken);
                }
            }
            return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
        }
        else
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidCredentials], CustomStatusCode.InvalidCredentials);
        }
    }
    #endregion
}
