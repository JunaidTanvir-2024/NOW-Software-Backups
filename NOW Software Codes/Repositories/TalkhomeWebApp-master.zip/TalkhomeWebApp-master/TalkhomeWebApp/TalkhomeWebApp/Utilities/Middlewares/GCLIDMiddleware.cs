﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Utilities.Middlewares
{
    public class GCLIDMiddleware
    {
        private readonly RequestDelegate _next;

        public GCLIDMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext httpContext)
        {
            var cookieOptions = new CookieOptions()
            {
                IsEssential = false,
                HttpOnly = true,
                Secure = false,
                SameSite = SameSiteMode.Strict
            };

            if (httpContext.Request.Query["utm_source"].Count > 0)
            {
                httpContext.Response.Cookies.Append("tha_utm_source", 
                    httpContext.Request.Query["utm_source"].ToString(), cookieOptions);
            }

            if (httpContext.Request.Query["utm_medium"].Count > 0)
            {
                httpContext.Response.Cookies.Append("tha_utm_medium", 
                    httpContext.Request.Query["utm_medium"].ToString(), cookieOptions);
            }

            if (httpContext.Request.Query["utm_campaign"].Count > 0)
            {
                httpContext.Response.Cookies.Append("tha_utm_campaign", 
                    httpContext.Request.Query["utm_campaign"].ToString(), cookieOptions);
            }

            if (httpContext.Request.Query["utm_term"].Count > 0)
            {
                httpContext.Response.Cookies.Append("tha_utm_term",
                    httpContext.Request.Query["utm_term"].ToString(), cookieOptions);
            }

            if (httpContext.Request.Query["utm_content"].Count > 0)
            {
                httpContext.Response.Cookies.Append("tha_utm_content",
                    httpContext.Request.Query["utm_content"].ToString(), cookieOptions);
            }

            return _next(httpContext);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class MyMiddlewareExtensions
    {
        public static IApplicationBuilder UseGCLIDMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<GCLIDMiddleware>();
        }
    }
}
