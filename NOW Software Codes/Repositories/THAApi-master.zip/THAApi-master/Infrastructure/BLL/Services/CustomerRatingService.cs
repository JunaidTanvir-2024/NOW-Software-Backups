﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request.Rating;
using Models.Contracts.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services
{
    public class CustomerRatingService: ICustomerRatingService
    {
        private readonly IApiCall _apiCall;

        private readonly CustomerRatingConfig _customerRatingConfig;

        public CustomerRatingService(
            IApiCall apiCall,
            IOptions<CustomerRatingConfig> customerRatingConfig)
        {
            _apiCall = apiCall;
            _customerRatingConfig = customerRatingConfig.Value;
        }

        public async Task<GenericApiResponse<IEnumerable<RatingEvents>>> GetRatingEvents()
        {
            HttpResponseMessage response = await _apiCall.GetAsync($"{_customerRatingConfig.ApiURL}/api/Rating/GetRatingEvents?productCode=THA");
            return JsonConvert.DeserializeObject<GenericApiResponse<IEnumerable<RatingEvents>>>(await response.Content.ReadAsStringAsync());
        }

        public async Task<GenericApiResponse<object>> AddCustomerRating(AddCustomerRatingRequest request)
        {
            HttpResponseMessage response = await _apiCall.PostAsync($"{_customerRatingConfig.ApiURL}/api/Rating/AddCustomerRating",JsonConvert.SerializeObject(request));
            return JsonConvert.DeserializeObject<GenericApiResponse<object>>(await response.Content.ReadAsStringAsync());
        }

        public async Task<GenericApiResponse<IEnumerable<CustomerRatings>>> GetCustomerRatings(GetCustomerRatingsRequest request)
        {
            HttpResponseMessage response = await _apiCall.PostAsync($"{_customerRatingConfig.ApiURL}/api/Rating/GetCustomerRatings", JsonConvert.SerializeObject(request));
            return JsonConvert.DeserializeObject<GenericApiResponse<IEnumerable<CustomerRatings>>>(await response.Content.ReadAsStringAsync());
        }
    }
}
