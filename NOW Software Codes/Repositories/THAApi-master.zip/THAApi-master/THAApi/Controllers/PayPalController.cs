﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Serilog;
using Models.Contracts.Request;
using THAApi.Utilities;
using THAApi.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;
using Microsoft.Extensions.Localization;
using Models.Enums;
using Infrastructure.Utilities;
using Infrastructure.BLL.Interfaces;

namespace THAApi.Controllers
{
    [ApiController]
    public class PayPalController : Controller
    {
        private readonly ILogger _logger;
        private readonly IPayment_BL _paymentBl;
        private readonly IStringLocalizer _localizer;
        private readonly IHelper_BL _helper_BL;

        public PayPalController(
            ILogger logger,
            IPayment_BL paymentBl,
            IStringLocalizer stringLocalizer,
            IHelper_BL helper_BL)
        {
            _logger = logger;
            _paymentBl = paymentBl;
            _localizer = stringLocalizer;
            this._helper_BL = helper_BL;
        }

        [HttpPost]
        [Route("PaypalPayment")]
        public async Task<IActionResult> PaypalPayment([FromBody] PaypalPaymentRequestModel request)
        {
            string advertiserID = HttpContext.GetAdvertiserID();
            var response = await _paymentBl.PaypalPaymentAsync(
                request,
                User.Msisdn(),
                User.Currency(),
                HttpContext.GetRemoteIPAddress(),
                advertiserID);
            return Ok(response);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        [Route("PaypalByPay360CallBack")]
        public async Task<IActionResult> PaypalByPay360CallBack([FromQuery] PaypalByPay360PaymentCallBackRequestModel request)
        {
            try
            {
                HttpContext.Request.Headers["AirshipEventsDisable"] = request.AirshipEventsDisable ? "1" : "0";
                HttpContext.Request.Headers["Msisdn"] = request.Msisdn;
                var response = await _paymentBl.PaypalByPay360PaymentCallBackAsync(request);

                if (response.ErrorCode > 0)
                {
                    return View(Pages.ErrorPage, new ErrorViewModel()
                    {
                        Message = response.Message,
                        ThemeMode = request.ThemeMode,
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal,
                        Type = request.CheckoutType,
                        BundlePurchaseInfo = response.Payload?.bundlePurchaseInfo,
                        Origination = _helper_BL.GetCountryCode(request.Msisdn),
                    });
                }

                var viewModel = new SuccessViewModel();

                if (response.Payload.topupInfo != null)
                {
                    //Topup
                    viewModel.Type = SuccessViewModel.CheckoutType.Topup;
                    viewModel.Origination = _helper_BL.GetCountryCode(request.Msisdn);
                    viewModel.UtmParamsInfo = new UtmParamsInfo()
                    {
                        utm_campaign = request.UtmCampaign,
                        utm_medium = request.UtmMedium,
                        utm_source = request.UtmSource
                    };
                    viewModel.CustomerMsisdn = response.Payload.topupInfo.Msisdn;
                    viewModel.TransactionId = response.Payload.topupInfo.TransactionId;
                    viewModel.TopupInfo = new SuccessViewModel.Topup()
                    {
                        Amount = response.Payload.topupInfo.TopupAmount,
                        Currency = response.Payload.topupInfo.Currency,
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal,
                        UpdatedBalance = response.Payload.topupInfo.NewBalance
                    };


                    viewModel.ThemeMode = request.ThemeMode;
                    return View(Pages.SuccessPage, viewModel);
                }
                else
                {
                    //Bundle
                    viewModel.Type = SuccessViewModel.CheckoutType.Bundle;
                    viewModel.Origination = _helper_BL.GetCountryCode(request.Msisdn);
                    viewModel.UtmParamsInfo = new UtmParamsInfo()
                    {
                        utm_campaign = request.UtmCampaign,
                        utm_medium = request.UtmMedium,
                        utm_source = request.UtmSource
                    };
                    viewModel.CustomerMsisdn = response.Payload.bundlePurchaseInfo.Msisdn;
                    viewModel.TransactionId = response.Payload.bundlePurchaseInfo.TransactionId;
                    viewModel.BundleInfo = new SuccessViewModel.Bundle()
                    {
                        Amount = response.Payload.bundlePurchaseInfo.BundleAmount,
                        Currency = response.Payload.bundlePurchaseInfo.Currency,
                        Name = response.Payload.bundlePurchaseInfo.BundleName,
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal,
                        Type = response.Payload.bundlePurchaseInfo.Type,
                        Destination = response.Payload.bundlePurchaseInfo.Destination,
                    };

                    viewModel.ThemeMode = request.ThemeMode;
                    return View(Pages.SuccessPage, viewModel);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PayPalController, " +
                              $"Method: PaypalByPay360CallBack, " +
                              $"Request:{JsonConvert.SerializeObject(request)}, " +
                              $"ErrorMessage: {(ex.InnerException != null ? ex.InnerException.Message + "-" + ex.Message : ex.Message)}, " +
                              $"StackTrace: {ex.StackTrace}");

                return View(Pages.ErrorPage,
                    new ErrorViewModel()
                    {
                        Message = _localizer["SomethingWentWrong"],
                        ThemeMode = request.ThemeMode,
                        Type = request.CheckoutType,
                        PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal
                    });
            }
        }

        [AllowAnonymous]
        [Route("PaypalPaymentCancel"), HttpGet]
        public IActionResult PaypalPaymentCancel([FromQuery] ThemeMode themeMode)
        {
            return View(Pages.ErrorPage, new ErrorViewModel()
            {
                Message = _localizer["PaymentError"],
                ThemeMode = themeMode,
                PaymentMethod = SuccessViewModel.PaymentMehtods.Paypal,
                Type = CheckOutTypes.Bundle,
            });
        }
    }
}