﻿using System;
using System.Collections.Generic;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class TransferCountriesResponse
    {
        public List<TransferCountry> Countries { get; set; }
        public class TransferCountry
        {
            public string CountryId { get; set; }
            public string Code { get; set; }
            public string Name { get; set; }
            public string Continent { get; set; }
            public int OperatorsCount { get; set; }
            public string OperatorsName { get; set; }
        }
    }
    public class TransferOperatorsResponse
    {
        public List<Operator> Operators { get; set; }
        public List<Item> Promotions { get; set; }
        public class Operator
        {
            public string Continent { get; set; }
            public string TransferToOperatorId { get; set; }
            public string operatorId { get; set; }
            public string operatorName { get; set; }
            public string countryName { get; set; }
            public string countryCode { get; set; }
            public string operatorImageUrl { get; set; }
        }
    }
    public class TransferOperatorDetailsResponse
    {
        public string Country { get; set; }

        public int Countryid { get; set; }

        public string Operator { get; set; }

        public int Operatorid { get; set; }

        public string DestinationCurrency { get; set; }

        public string ProductList { get; set; }

        public string RetailPriceList { get; set; }

        public string WholesalePriceList { get; set; }

        public double AuthenticationKey { get; set; }

        public int ErrorCode { get; set; }

        public string ErrorTxt { get; set; }
    }
}
