﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransfertoDataBundlesProductsJsonResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public int servcieproviderid { get; set; }
        public DataBundlesOperatorProductsPayLoad payload { get; set; }
    }



    public class DataBundlesOperatorProductsPayLoad
    {
        public List<DataBundlesOperator> operators { get; set; }
    }

    public class DataBundlesOperator
    {
        public string id { get; set; }
        public string name { get; set; }
       
       
        public int country_id { get; set; }
        public string country { get; set; }

        //public int operator_id { get; set; }
        //public string @operator { get; set; }

        //public int service_id { get; set; }
        //public string service { get; set; }


        public string nowtelTransactionReference { get; set; }
        public string iconUri { get; set; }

        public string ProductApiType { get; set; } //GS - ATT transfertoo // ATT

        public List<DataBundleProductList> products { get; set; }
      //  public int accessid { get; set; }
    }

    public class DataBundleProductList
    {
        public int ProductId { get; set; }
        public string Product { get; set; }
        public string ProductDesc { get; set; }

        public string AccountCurrency { get; set; }
        public string ProductCurrency { get; set; }

        public string ProductDisplay { get; set; }

        public double WholeSalePrice { get; set; }

        public double CalculatedRetailPrice { get; set; }
        public double TransactionFee { get; set; }
        public double CustomerChargePrice { get; set; }

        public string BundleVolume { get; set; }

        public string ExpiryDays { get; set; }
        public string Extra { get; set; }
        public string LocalMinutes { get; set; }
        public string InternationalMinutes { get; set; }
        public string LocalSms { get; set; }
        public string InternationalSms { get; set; }
        public string FacebookData { get; set; }
        public string TwitterData { get; set; }
        public string InstragramData { get; set; }

    }

   

    public class EndRateDataBundleProductList
    {
        public string ProductType { get; set; }

        public int Id { get; set; }
        public int OperatorId { get; set; }
        public int OriginDestinationId { get; set; }
        
        public double WholeSalePrice { get; set; }
        public double Margin { get; set; }
        public double RetailPrice { get; set; }
      
        public double CalculatedRetailPrice { get; set; }
        public double TransactionFee { get; set; }
        public double CustomerChargePrice { get; set; }

        public string ClientCurrency { get; set; }
        public string ReceiverCurrency { get; set; }

        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductDesc { get; set; }
        public string ProductDisplay { get; set; }
        public string FacebookData { get; set; }
        public string TwitterData { get; set; }
        public string InstragramData { get; set; }
        public string ProductValue { get; set; }
        public string PriceId { get; set; }

        public string BundleVolume { get; set; }

        public string ExpiryDays { get; set; }
        public string Extra { get; set; }
        public string LocalMinutes { get; set; }
        public string InternationalMinutes { get; set; }
        public string LocalSms { get; set; }
        public string InternationalSms { get; set; }

        public bool isEnabled { get; set; }
        public bool isRecordUpdated { get; set; }

        //public int product_id { get; set; }
        //public string product_name { get; set; }
        //public string product_short_desc { get; set; }

        //public string account_currency { get; set; }
        //public double wholesale_price { get; set; }
        //public double retail_price { get; set; }
        //public int fee { get; set; }
        //public string product_currency { get; set; }
        //public int product_value { get; set; }
        //public string local_currency { get; set; }
        //public int local_value { get; set; }
    }


    //public class ATTRateDataBundleProductList
    //{
    //    public int Id { get; set; }
    //    public int OperatorId { get; set; }
    //    public int OriginDestinationId { get; set; }

    //    public double WholeSalePrice { get; set; }
    //    public double Margin { get; set; }
               
    //    public double CalculatedRetailPrice { get; set; }
    //    public double TransactionFee { get; set; }
    //    public double CustomerChargePrice { get; set; }

    //    public double ClientCurrency { get; set; }
    //    public double ReceiverCurrency { get; set; }

       
    //    public string ProductValue { get; set; }
    //    public string PriceId { get; set; }
      
      
     
    //    public string BundleMbGb { get; set; }

    //    public string ExpiryDays { get; set; }
    //    public string Extra { get; set; }
    //    public string LocalMinutes { get; set; }
    //    public string InternationalMinutes { get; set; }
    //    public string LocalSms { get; set; }
    //    public string InternationalSms { get; set; }

    //    public bool isEnabled { get; set; }
    //}
}
