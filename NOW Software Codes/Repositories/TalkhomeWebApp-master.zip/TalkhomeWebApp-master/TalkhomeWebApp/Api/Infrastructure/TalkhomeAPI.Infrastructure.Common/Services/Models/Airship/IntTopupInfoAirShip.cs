﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.Airship
{
    public class IntTopupInfoAirShip
    {
        public string Msisdn { get; set; }
        public string Origination { get; set; }
        public string Destination { get; set; }
        public bool IsSuccess { get; set; }
        public bool? IsCard { get; set; }
        public bool SaveCard { get; set; }
        public decimal RemainingBalance { get; set; }
    }
}
