using FH.Core.DependencyResolver;
using FH.Core.DTOs.Database;
using FH.Core.Entities;

namespace FH.Core.Interfaces.Database;

public interface IOperatorRepository : ServiceType.IScoped
{
	Task<IEnumerable<OperatorEntity>> OperatorBulkUpsert(IEnumerable<OperatorEntity> operatorDto);
	Task<IEnumerable<VendorOperatorEntity>> VendorOperatorBulkUpsert(IEnumerable<VendorOperatorEntity> operatorDto);
	Task<IEnumerable<OperatorDto.Response>> GetOperatorByName(OperatorByNameDto.Request operatorDto);
	Task<(IEnumerable<OperatorDto.Response> operators, DatabasePaginationDto pagination)> GetOperators(OperatorDto.Request getOperatorsRequest);
	Task<OperatorByVendorCodeDto.Response?> GetOperatorByVendorCode(OperatorByVendorCodeDto.Request request);
	Task UpdateOperatorsAliases(IEnumerable<OperatorAliasDto.Request> operatorAliasDto);
    Task<(IEnumerable<OperatorByProductCategoryDto.Response> operators, DatabasePaginationDto pagination)> GetOperatorByProductCategory(OperatorByProductCategoryDto.Request operatorDto);
    Task<IEnumerable<OperatorBySubCategoryDto.Response>> GetOperatorBySubCategory(OperatorBySubCategoryDto.Request request);
}
