﻿using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.SubscribedBundle.V3;
public class SubscribedBundleRequestV3: IRequest<Result<List<SubscribedBundleInfo>>>
{
    public string Msisdn { get; set; } = default!;
}
