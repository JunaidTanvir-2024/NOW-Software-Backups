﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.IO;
using System.Net;

namespace NowPayG
{
    //public class Program
    //{
    //    public static void Main(string[] args)
    //    {
    //        CreateWebHostBuilder(args).Build().Run();
    //    }

    //    public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
    //        WebHost.CreateDefaultBuilder(args)
    //            .UseStartup<Startup>();
    //}

    public class Program
    {
        public static IConfiguration Configuration { get; set; }

        public static void Main(string[] args)
        {

            var builder = new ConfigurationBuilder()
                                .SetBasePath(Directory.GetCurrentDirectory())
                                .AddJsonFile("appsettings.json");

            Configuration = builder.Build();
            string url = "";
            if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == EnvironmentName.Development)
            {
                url = $"https://*:{Configuration["HostPortDebug"]}";
            }
            else
            {
                url = $"http://*:{Configuration["HostPortProduction"]}";
            }

            WebHost.CreateDefaultBuilder(args)
               //.UseKestrel(options =>
               //{
               //    options.Listen(IPAddress.Loopback, Convert.ToInt32(port));
               //})
               .UseStartup<Startup>()
               .UseUrls(url)
               .UseSerilog()
               .Build()
               .Run();
        }
    }
}
