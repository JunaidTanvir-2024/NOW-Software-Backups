﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.Configurations
{
    public class BasicAuthConfig
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
    public class TopUpConfig
    {
        public decimal[] TopUpAmounts { get; set; }
    }
    public class TestNumbersByCurrencyConfig
    {
        public string EUR { get; set; }
        public string USD { get; set; }
        public string GBP { get; set; }
    }
}
