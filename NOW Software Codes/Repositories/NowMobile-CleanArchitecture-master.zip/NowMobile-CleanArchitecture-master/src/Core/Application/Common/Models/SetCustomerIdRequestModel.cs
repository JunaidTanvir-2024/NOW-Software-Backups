﻿
namespace Application.Common.Models;
public class SetCustomerIdRequestModel
{
    public string? CustomerUserId { get; set; }
    public string? AfUserId { get; set; }
    public string ProductCode { get; set; } = "NOWPAYG";
    public string BaseProductCode { get; set; } = "NOW";
}
