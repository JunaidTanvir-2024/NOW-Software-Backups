﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class Credentials
    {
        public string ApiEndPoint { get; set; }
        public string AppKey { get; set; }
        public string AppSecret { get; set; }
        public string MasterSecret { get; set; }
        public string BearerToken { get; set; }
        public AuthType AuthType { get; set; }
    }
}
