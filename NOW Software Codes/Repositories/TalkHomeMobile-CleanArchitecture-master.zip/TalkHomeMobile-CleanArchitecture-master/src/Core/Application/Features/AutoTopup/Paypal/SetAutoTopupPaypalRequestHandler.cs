﻿using Application.Common.Enums;
using Application.Common.Interfaces.Payment;
using Application.Common.Settings;
using Application.Features.AutoTopup.GetAutoTopup;
using Application.Features.Bundle.Model;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.CreateSale;
using Application.Features.Payment.Paypal.Models;
using Domain.Entities;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Security.AccessControl;

namespace Application.Features.AutoTopup.Paypal;

public class SetAutoTopupPaypalRequestHandler : IRequestHandler<SetAutoTopupPaypalRequest, Result<SetAutoTopupPaypalResponse>>
{
    private readonly IStringLocalizer<SetAutoTopupPaypalRequestHandler> _localizer;
    private readonly ICurrentUser _currentUser;
    private readonly IUserService _userService;
    private readonly IPayPalService _payPalService;
    private readonly ICommonService _commonService;
    private readonly IPaymentService _paymentService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly TopupSettings _topupSettings;

    public SetAutoTopupPaypalRequestHandler(
        IStringLocalizer<SetAutoTopupPaypalRequestHandler> localizer,
        ICurrentUser currentUser,
        IUserService userService,
        IPayPalService payPalService,
        ICommonService commonService,
        IPaymentService paymentService,
        IUnitOfWork unitOfWork,
        IOptions<TopupSettings> topupSettings)
    {
        _localizer = localizer;
        _currentUser = currentUser;
        _userService = userService;
        _payPalService = payPalService;
        _commonService = commonService;
        _paymentService = paymentService;
        _unitOfWork = unitOfWork;
        _topupSettings = topupSettings.Value;
    }

    public async Task<Result<SetAutoTopupPaypalResponse>> Handle(SetAutoTopupPaypalRequest request, CancellationToken cancellationToken)
    {
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<SetAutoTopupPaypalResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var responseMessage = _localizer[CustomStatusKey.SetAutoTopupSuccess].ToString();

        //var autoTopupStatus = await _unitOfWork.TopupRepo.GetAutoTopup(request.Msisdn, _currentUser.GetUserEmail()!);
        //if (autoTopupStatus?.Status == true && autoTopupStatus?.PaymentMethod?.Equals("Paypal", StringComparison.InvariantCultureIgnoreCase) == true)
        //{
        //    //Suspend paypal existing subscription and create new one
        //    var subscriptionSuspendRequest = new PaypalSuspendSubscriptionRequest
        //    {
        //        SubscriptionId = autoTopupStatus.InitialTransactionId!
        //    };
        //    await _payPalService.PayPalCancelSubscription(subscriptionSuspendRequest);

        //}

        var isAppRequest = _commonService.IsAppRequest();
        var topupInfo = new AutoTopupInfo()
        {
            ThresHoldAmount = _topupSettings.ThresholdAmount,
            Status = request.Status,
            TopupAmount = request.TopupAmount,
            PaymentMethod = PaymentMethod.Paypal.ToString()
        };
        var paymentResponse = await _paymentService.HandlePaypalPaymentRequest(
            topupInfo: new PaymentTopupInfo() { TopupAmount = request.TopupAmount, AutoTopupInfo = topupInfo },
            bundleInfo: null!,
            creditSimInfo: null!,
            msisdn: request.Msisdn,
            _currentUser.GetUserEmail()!
            , request.IpAddress!,
            isSubscriptionRequest: true,
            subscriptionWithInitialSale: false);
        if (paymentResponse != null && paymentResponse.ErrorCode == 0 && !string.IsNullOrEmpty(paymentResponse.Data?.RedirectUrl))
        {
            //Redirect to paypal
            var responseModel = new SetAutoTopupPaypalResponse
            {
                RedirectUrl = paymentResponse.Data.RedirectUrl
            };
            return Result<SetAutoTopupPaypalResponse>.Success(responseModel, responseMessage.Replace("{status}", request.Status ? "enabled" : "disabled"));
        }
        else
        {
            return Result<SetAutoTopupPaypalResponse>.Failure(
            _localizer[CustomStatusKey.SetAutoTopupFailure], CustomStatusCode.InternalServerError);
        }
    }
}