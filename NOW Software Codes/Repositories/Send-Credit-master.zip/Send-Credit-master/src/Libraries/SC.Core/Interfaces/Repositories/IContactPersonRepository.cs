﻿using SC.Core.Models.Dtos;

namespace SC.Core.Interfaces.Repositories
{
    public interface IContactPersonRepository
    {
        Task<int> AddContactPerson(ContactPersonDto contactPersonDto);

        Task<int> DeleteContactPerson(int id);

        Task<List<ContactPersonDto>> GetContactPersons(GetContactPersonDto.Request request);

        Task<int> UpdateContactPerson(ContactPersonDto contactPersonDto);
    }
}