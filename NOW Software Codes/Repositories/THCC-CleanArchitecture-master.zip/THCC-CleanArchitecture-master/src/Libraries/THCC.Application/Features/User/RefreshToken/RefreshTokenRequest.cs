namespace THCC.Application.Features.User.RefreshToken;

public class RefreshTokenRequest : IRequest<object>
{
    public string Token { get; set; } = default!;
    public string RefreshToken { get; set; } = default!;
}
public class RefreshTokenRequestValidator : AbstractValidator<RefreshTokenRequest>
{
    public RefreshTokenRequestValidator()
    {
        RuleFor(p => p.RefreshToken)
            .NotEmpty()
            .NotNull();

        RuleFor(p => p.Token)
            .NotEmpty()
            .NotNull();
    }
}
