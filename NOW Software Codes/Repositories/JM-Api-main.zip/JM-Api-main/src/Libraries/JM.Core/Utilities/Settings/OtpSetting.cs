namespace JM.Core.Utilities.Settings;

public sealed class OtpSetting
{
    public const string SectionName = nameof(OtpSetting);
    public long MinValue { get; set; }
    public long MaxValue { get; set; }
    public int BlockTimeInMinutes { get; set; }
    public int ExpiryTimeInMinutes { get; set; }
    public int CreationLimit { get; set; }
    public int RetryLimit { get; set; }
    public string DefaultCode { get; set; } = null!;
}
