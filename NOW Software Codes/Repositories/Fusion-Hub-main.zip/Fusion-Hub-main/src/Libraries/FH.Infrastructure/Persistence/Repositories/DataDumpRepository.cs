using System.Data;

using Dapper;

using FH.Core.Definitions;
using FH.Core.Entities;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;

using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

using Serilog;

namespace FH.Infrastructure.Persistence.Repositories;

internal sealed class DataDumpRepository(IConfiguration configuration, ILogger logger) : IDataDumpRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private readonly ILogger _logger = logger;

    public async Task<IEnumerable<long>> GetVendorDataHash(VendorDataHashEntity vendorDataHashDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("api_page", vendorDataHashDto.ApiPage);
                parameters.Add("api_type", vendorDataHashDto.ApiType);

                return await connection.QueryAsync<long>(AppConstants.Database.StoreProcedure.VendorDataHashGet, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(DataDumpRepository), nameof(GetVendorDataHash));
            return default!;
        }
    }
    public async Task<IEnumerable<long>> DataDumpBulkUpsert(VendorDataHashEntity vendorDataHashDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("api_page", vendorDataHashDto.ApiPage);
                parameters.Add("api_type", vendorDataHashDto.ApiType);
                parameters.Add("batch_hash", vendorDataHashDto.BatchHash);

                return await connection.QueryAsync<long>(AppConstants.Database.StoreProcedure.VendorDataHashInsert, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(DataDumpRepository), nameof(DataDumpBulkUpsert));
            return default!;
        }
    }
}
