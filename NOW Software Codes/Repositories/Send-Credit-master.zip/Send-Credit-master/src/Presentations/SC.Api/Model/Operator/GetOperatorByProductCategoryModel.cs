﻿using SC.Core.Features.Operators.OperatorByProductCategory;
using SC.Core.Features.ProductByOperator;

namespace SC.Api.Model;

public class GetOperatorByProductCategoryModel
{
    public int Page { get; set; }
    public int RecordsPerPage { get; set; }
    public OperatorsByProductCategory.Query.OperatorsByProductCategoryFilter? OperatorFilters { get; set; }
    public OperatorsByProductCategory.Query map()
    {
        return new OperatorsByProductCategory.Query
        {
            Page = Page,
            RecordsPerPage = RecordsPerPage,
            OperatorFilters = OperatorFilters
        };
    }
}

