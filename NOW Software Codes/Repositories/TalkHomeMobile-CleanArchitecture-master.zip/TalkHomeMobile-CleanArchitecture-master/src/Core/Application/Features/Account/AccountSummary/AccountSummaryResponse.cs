﻿namespace Application.Features.Account.AccountSummary;

public class AccountSummaryResponse
{
    public IEnumerable<UserProductInfo>? ProductInfo { get; set; }
    public UserInfo UserInfo { get; set; } = new UserInfo();
    public string DisablePaymentVersion { get; set; } = string.Empty;
}
