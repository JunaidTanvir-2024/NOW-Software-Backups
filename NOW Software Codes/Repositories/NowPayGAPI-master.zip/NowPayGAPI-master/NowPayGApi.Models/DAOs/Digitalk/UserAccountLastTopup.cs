﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs.Digitalk
{
    public class UserAccountLastTopup
    {
        public string amount { get; set; }
        public string date { get; set; }
    }
}
