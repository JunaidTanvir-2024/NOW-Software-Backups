using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.StackableDiscounts;

public class RedeemableDiscounts
{
    [JsonPropertyName("redeemables")]
    public List<StackableDiscount>? Redeemable { get; set; }
}