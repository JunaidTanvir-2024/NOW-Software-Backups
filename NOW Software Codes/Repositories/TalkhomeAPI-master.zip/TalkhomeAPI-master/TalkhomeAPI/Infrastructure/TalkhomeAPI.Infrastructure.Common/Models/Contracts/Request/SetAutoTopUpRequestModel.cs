﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Linq;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class SetAutoTopUpRequestModel
    {
        [Required(ErrorMessage = "Select Threshold Amount")]
        [CollectionValidation(values: new int[] { 1, 3, 5 })]
        public int thresholdBalanceAmount { get; set; }

        [Required(ErrorMessage = "Select TopUp Amount")]
        [CollectionValidation(values: new int[] { 5, 10, 15, 20, 25 })]
        public int amount { get; set; }

        public bool isActive { get; set; }
    }

    public class CollectionValidationAttribute : ValidationAttribute
    {
        private readonly int[] values;

        public CollectionValidationAttribute(int[] values)
        {
            this.values = values;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (!values.Contains((int)value))
                return new ValidationResult("Invalid amount");

            return ValidationResult.Success;
        }
    }
}
