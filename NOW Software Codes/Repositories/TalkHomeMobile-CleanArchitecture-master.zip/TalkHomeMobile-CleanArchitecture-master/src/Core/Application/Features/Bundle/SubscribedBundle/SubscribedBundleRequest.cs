﻿
using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.SubscribedBundle;
public class SubscribedBundleRequest : IRequest<Result<List<SubscribedBundleInfo>>>
{
    public string Msisdn { get; set; } = default!;
}
