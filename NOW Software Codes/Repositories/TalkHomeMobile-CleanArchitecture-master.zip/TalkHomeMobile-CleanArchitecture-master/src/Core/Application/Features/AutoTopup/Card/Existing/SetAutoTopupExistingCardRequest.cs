using Application.Features.Payment.Card.Models;

namespace Application.Features.AutoTopup.Card.Existing;

public class SetAutoTopupExistingCardRequest : IRequest<Result<CardResponse>>
{
    public string Msisdn { get; set; } = default!;
    public float TopupAmount { get; set; } = default!;
    [JsonIgnore]
    public bool Status { get; set; }
    [JsonIgnore]
    public string IpAddress { get; set; } = string.Empty;
    public PaymentExistingCardInfo PaymentCardInfo { get; set; } = new PaymentExistingCardInfo();
}