﻿//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using SenderService.Core.Persistence.Entities;

//namespace SenderService.Core.Persistence.Configurations;
//internal class EmailValidationConfiguration : IEntityTypeConfiguration<EmailValidation>
//{
//    public void Configure(EntityTypeBuilder<EmailValidation> entity)
//    {
//        entity.HasIndex(e => e.Email, "IX_EmailValidations_Email");

//        entity.Property(e => e.Email).HasMaxLength(510);
//        entity.Property(e => e.InvalidReason).HasMaxLength(50);

//        entity.HasOne(d => d.ProductCode).WithMany(p => p.EmailValidations).HasForeignKey(d => d.ProductCodeId);
//    }
//}
