﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Response
{
    public class ApiGetUserByIdResponse
    {
        public bool ok { get; set; }
        public NamedUser named_user { get; set; }

    }
    public class NamedUser
    {
        public string named_user_id { get; set; }
        public Dictionary<string, List<string>> tags { get; set; }
        public DateTime? created { get; set; }
        public DateTime? last_modified { get; set; }
        public List<Channel> channels { get; set; }
    }
}
