﻿using Dapper;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using TalkhomeAPI.Data.DbConnections;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Pay360ApiContracts;

namespace TalkhomeAPI.Data.Repositories
{
    public class AccountRepository : IAccountRepository
    {
        private readonly IDbConnectionSettings DGT_Db;
        private readonly IDbConnectionSettings THA_Db;
        private readonly IDbConnectionSettings THA_Accounts_Db;
        private readonly IDbConnectionSettings DefaultConnection;

        public AccountRepository(IOptions<ConnectionString> connectionString)
        {
            DGT_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.DigitalkDbConnection));
            THA_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppDbConnection));
            THA_Accounts_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppsAccountsDbConnection));
            DefaultConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
        }

        public async Task<bool> IsUserExist(string UserName)
        {
            var parameters = new DynamicParameters();
            parameters.Add("sipuserName", UserName);
            parameters.Add("@isExists", dbType: DbType.Boolean, direction: ParameterDirection.Output);
            await DGT_Db.SqlConnection.ExecuteAsync("tha_web_user_exists", parameters, commandType: CommandType.StoredProcedure);

            return parameters.Get<bool>("@isExists");
        }
        public async Task<DBAccountInfo> GetAccountDetails(string Username, string pin)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@sipuserName", Username);
            parameters.Add("@pin", pin);

            return await DGT_Db.SqlConnection.QueryFirstOrDefaultAsync<DBAccountInfo>("tha_web_get_account_details", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<bool> VerifyPin(string UserName, string Pin)
        {
            var parameters = new DynamicParameters();
            parameters.Add("sipuserName", UserName);
            parameters.Add("pin", Pin);
            parameters.Add("isValid", dbType: DbType.Boolean, direction: ParameterDirection.Output);

            await DGT_Db.SqlConnection.ExecuteAsync("tha_web_validate_pin", parameters, commandType: CommandType.StoredProcedure);

            return parameters.Get<bool>("isValid");
        }
        public async Task<DBResultValidateMsisdn> ValidateMsisdn(string msisdn)
        {
            var garb = new DBResultValidateMsisdn();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn, dbType: DbType.String);
                parameters.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                var result = await DGT_Db.SqlConnection.QueryAsync("tha_validate_msisdn", parameters, commandType: CommandType.StoredProcedure);
                int errorCode = parameters.Get<int>("@errorcode");
                string errorMsg = parameters.Get<string>("@errormsg");
                if (errorCode == 0) // Success
                {
                    garb.error_code = errorCode;
                    garb.error_msg = "Success";
                }
                else // Failure
                {
                    garb.error_msg = "Bundle addition failed. " + errorMsg;
                    garb.error_code = errorCode;
                }
            }
            catch (Exception)
            {

                throw;
            }
            return garb;
        }
        public async Task<int> UpdateUser(DBUser user)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", user.msisdn);
            parameters.Add("@firstname", user.firstname);
            parameters.Add("@lastname", user.lastname);
            parameters.Add("@email", user.email);
            parameters.Add("@email_subscribed", user.email_subscribed);

            return await THA_Db.SqlConnection.ExecuteAsync("tha_web_update_user_registration", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<bool> IsFirstTopUp(string msisdn)
        {
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@msisdn", msisdn);
                var result = await DGT_Db.SqlConnection.ExecuteScalarAsync<DateTime?>("tha_first_topup", parameter, commandType: CommandType.StoredProcedure);

                if (result == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
        public async Task<int> IsBundleExists(string msisdn)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@productref", msisdn);
            parameters.Add("@isExits", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await DGT_Db.SqlConnection.ExecuteAsync("tha_bundle_exists ", parameters, commandType: CommandType.StoredProcedure);

            return parameters.Get<int>("@isExits");
        }
        public async Task<DBUser> GetUserByPhoneNumber(string phoneNumber)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", phoneNumber);

            return await THA_Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("tha_web_select_user_registration", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<DateTime> GetUserRegistrationDate(string accountNumber)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@account", accountNumber);

            return await THA_Accounts_Db.SqlConnection.QueryFirstOrDefaultAsync<DateTime>("tha_web_get_registration_date", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<string> GetPinByPhoneNumber(string sipUsername)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@sipuserName", sipUsername);

            return await DGT_Db.SqlConnection.QueryFirstOrDefaultAsync<string>("tha_web_get_pin", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task InsertEmailVerificationToken(string phoneNumber, string token)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", phoneNumber);
            parameters.Add("@token", token);

            await THA_Db.SqlConnection.ExecuteAsync("tha_web_user_set_email_token", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<int> VerifyEmail(string token)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@token", token);
            parameters.Add("@errorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await THA_Db.SqlConnection.QueryFirstOrDefaultAsync<int>("tha_web_verifyEmail", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("errorCode");
        }
        public async Task<DBUser> GetUserInfoByEmailToken(string token)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@token", token);

            return await THA_Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("tha_web_getUserInfoByEmailToken", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<DBAccountInfo> GetAccountDetailsBySipUsername(string sipUsername)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@sipuserName", sipUsername);

            return await DGT_Db.SqlConnection.QueryFirstOrDefaultAsync<DBAccountInfo>("tha_web_get_account_details_by_sipUsername", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<DBResultValidateMsisdn> VoucherRecharge(string pin, string account)
        {
            var garb = new DBResultValidateMsisdn();
            var parameters = new DynamicParameters();
            parameters.Add("@pin ", pin);
            parameters.Add("@account", account);
            parameters.Add("@card_credit", dbType: DbType.Decimal, direction: ParameterDirection.Output);
            parameters.Add("@voucher_id", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@voucher_currency", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
            parameters.Add("@result_status", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@result_message", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);
            await DGT_Db.SqlConnection.ExecuteAsync("tha_web_vchApplyVoucher", parameters, commandType: CommandType.StoredProcedure);
            int errorCode = parameters.Get<int>("@result_status");
            string errorMsg = parameters.Get<string>("@result_message");
            if (errorCode == 0) // Success
            {
                garb.card_credit = parameters.Get<decimal?>("@card_credit");
                garb.voucher_id = parameters.Get<int?>("@voucher_id");
                garb.voucher_currency = parameters.Get<string>("@voucher_currency");

                garb.error_code = errorCode;
                garb.error_msg = "Success";
            }
            else // Failure
            {
                garb.error_msg = errorMsg;
                garb.error_code = errorCode;
            }
            return garb;
        }
        public async Task<IEnumerable<DBCallHistory>> GetCallingHistory(string accountNumber)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@account", accountNumber, dbType: DbType.String);

            return await DGT_Db.SqlConnection.QueryAsync<DBCallHistory>("tha_web_call_history", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<IEnumerable<DBTopUpPaymentHistory>> GetTopUpPaymentHistory(string accountNumber)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@account", accountNumber, dbType: DbType.String);

            return await DGT_Db.SqlConnection.QueryAsync<DBTopUpPaymentHistory>("tha_web_payment_history", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<IEnumerable<DBITopUpHistory>> GetInternationalTopUpHistory(string accountNumber)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@accountid", accountNumber, dbType: DbType.String);

            return await THA_Db.SqlConnection.QueryAsync<DBITopUpHistory>("tha_web_get_itopup_transactions", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<bool> IsEmailAlreadyExists(string email)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Email", email);
            parameters.Add("@IsValid", dbType: DbType.Boolean, direction: ParameterDirection.Output);

            await DGT_Db.SqlConnection.ExecuteAsync("tha_web_email_alreadyExists", parameters, commandType: CommandType.StoredProcedure);

            return parameters.Get<bool>("@IsValid");
        }
        public async Task<int> UpdateAccountDetails(DBUser user)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", user.msisdn);
            parameters.Add("@firstname", user.firstname);
            parameters.Add("@lastname", user.lastname);
            parameters.Add("@email", user.email);
            parameters.Add("@email_subscribed", user.email_subscribed);
            parameters.Add("@day_of_birth", user.dayOfBirth);
            parameters.Add("@month_of_birth", user.monthOfBirth);

            return await THA_Db.SqlConnection.ExecuteAsync("tha_web_update_user_account", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<string> ValidateUser(string msisdn)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", msisdn);

            return await THA_Db.SqlConnection.QueryFirstOrDefaultAsync<string>("tha_web_validate_blocked_user", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<IEnumerable<DBBundles>> GetBundlesHistory(string accountNumber)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@account", accountNumber);

            return await DGT_Db.SqlConnection.QueryAsync<DBBundles>("tha_web_get_account_bundles", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<bool> IsValidIpAddress(string ipAddress, string path, int requestsLimit, int requestsLimitMinutes, string requestJson)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@requestsLimit", requestsLimit);
            parameters.Add("@requestsLimitMinutes", requestsLimitMinutes);
            parameters.Add("@ipAddress", ipAddress);
            parameters.Add("@path", path);
            parameters.Add("@requestJson", requestJson);
            parameters.Add("@return", dbType: DbType.Boolean, direction: ParameterDirection.Output);

            await THA_Db.SqlConnection.ExecuteAsync("tha_web_isValidIpAddress", parameters, commandType: CommandType.StoredProcedure);

            return parameters.Get<bool>("@return");
        }
        public async Task<bool> ValidateSmsRequest(string PhoneNumber, string IpAddress, int smsLimit, SmsTypeId smsTypeId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@msisdn", PhoneNumber);
            parameters.Add("@ipAddress", IpAddress);
            parameters.Add("@smsTypeId", (Int16)smsTypeId);
            parameters.Add("@smsLimit", (Int16)smsLimit);
            parameters.Add("@response", dbType: DbType.Boolean, direction: ParameterDirection.Output);

            await THA_Db.SqlConnection.ExecuteAsync("tha_web_check_sms_validation", parameters, commandType: CommandType.StoredProcedure);

            return parameters.Get<bool>("@response");
        }
        public async Task<string> GetEmailVerificationToken(string msisdn)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@msisdn", msisdn);

            return await THA_Db.SqlConnection.ExecuteScalarAsync<string>("tha_web_get_email_verification_token", parameters, commandType: CommandType.StoredProcedure);
        }
       
    }
}
