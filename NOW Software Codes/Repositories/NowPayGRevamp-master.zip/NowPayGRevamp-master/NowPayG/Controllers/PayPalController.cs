﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NowPayG.Configurations;
using NowPayG.Models;
using NowPayG.Models.Pay360ApiContracts;
using NowPayG.Models.PaypalApiContracts;
using NowPayG.Models.ViewModels;
using NowPayG.Resources;
using NowPayG.Services.Interfaces;
using NowPayG.Utility;
using PhoneNumbers;
using Serilog;

namespace NowPayG.Controllers
{
    public class PayPalController : Controller
    {
        private readonly IPayPalService PayPalService;
        private readonly ILogger Logger;
        private readonly EndPoints _endPointsSettings;
        public PayPalController(IPayPalService payPalService, ILogger logger, IOptions<EndPoints> endPointsSettings)
        {
            PayPalService = payPalService;
            Logger = logger;
            _endPointsSettings = endPointsSettings.Value;
        }

        [Route("PayPal/Payment")]
        [ValidateAntiForgeryToken]
        [HttpPost]
        public async Task<IActionResult> PayPalStartPayment(PayPalViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                model.Msisdn = phoneNumberUtil.Format(phoneNumberUtil.Parse(model.Msisdn, "GB"), PhoneNumberFormat.E164).Replace("+", "").Trim();
                var response = await PayPalService.PayPalCreateSalePayment(await CreatePayPalPaymentRequest(model));

                if (response == null)
                {
                    TempData["Heading"] = "Payment Failed";
                    TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";

                    return RedirectToAction("Error", "Error");
                }
                if (response.errorCode > 0)
                {
                    TempData["Heading"] = "Payment Failed";

                    var ErrorCodes = new int[] { 5, 11, 21, 22, 27 };

                    if (ErrorCodes.Contains(response.errorCode))
                    {
                        TempData["Message"] = PaymentAPIMessagesResource.ResourceManager.GetString(Enum.GetName(typeof(Pay360StatusCodes), response.errorCode));
                    }
                    else
                    {
                        Logger.Error($"Class: PayPalController, Method: PayPalStartPayment, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorCode: { response.errorCode}, ErrorMessage: { response.message}");

                        TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";
                    }

                    return RedirectToAction("Error", "Error");
                }
                return Redirect(response.payload.RedirectUrl);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PayPalController, Method: PayPalStartPayment, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [ActionName("purchaseSuccessReturn")]
        public async Task<IActionResult> PurchaseSuccessReturn(SuccessReturnPayPalViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                PayPalExecuteSalePaymentRequest PaymentRequest = new PayPalExecuteSalePaymentRequest
                {
                    PayerId = model.PayerID,
                    PaymentId = model.paymentId,
                    CustomerUniqueRef = model.uRef,
                    ProductCode = ProductCode.NOWPAYG.ToString()
                };

                MessageViewModel ViewModel = new MessageViewModel();
                await ViewModel.SetSharedDataAsync(User);

                var response = await PayPalService.PayPalExecuteSalePayment(PaymentRequest);

                if (response == null)
                {
                    TempData["Heading"] = "Payment Failed";
                    TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";

                    return RedirectToAction("Error", "Error");
                }
                else if (response.errorCode > 0)
                {
                    TempData["Heading"] = "Payment Failed";

                    var ErrorCodes = new int[] { 5, 11, 21, 22, 27 };

                    if (ErrorCodes.Contains(response.errorCode))
                    {
                        TempData["Message"] = PaymentAPIMessagesResource.ResourceManager.GetString(Enum.GetName(typeof(Pay360StatusCodes), response.errorCode));
                    }
                    else if (response.errorCode == 12)
                    {
                        TempData["Message"] = response.message;
                    }
                    else
                    {
                        TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";
                    }

                    Logger.Error($"Class: PayPalController, Method: purchaseSuccessReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorCode: { response.errorCode}, ErrorMessage: { response.message}");
                    return RedirectToAction("Error", "Error");
                }
                else
                {
                    TempData["Heading"] = "Payment";
                    TempData["Message"] = "Plan of £" + model.Amount + " is purchased successfully.";

                    Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                    bundleDetail.Add("Id", model.Msisdn);
                    bundleDetail.Add("name", model.bundleName);
                    bundleDetail.Add("amount", model.Amount.ToString());
                    bundleDetail.Add("category", CheckOutTypes.Bundle.ToString());
                    TempData["BundleDetail"] = bundleDetail;

                    return RedirectToAction("SuccessfulPayment");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PayPalController, Method: PurchaseSuccessReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [ActionName("topUpSuccessReturn")]
        public async Task<IActionResult> TopUpSuccessReturn(SuccessReturnPayPalViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                PayPalExecuteSalePaymentRequest PaymentRequest = new PayPalExecuteSalePaymentRequest
                {
                    PayerId = model.PayerID,
                    PaymentId = model.paymentId,
                    CustomerUniqueRef = model.uRef,
                    ProductCode = ProductCode.NOWPAYG.ToString()
                };

                var response = await PayPalService.PayPalExecuteSalePayment(PaymentRequest);

                MessageViewModel ViewModel = new MessageViewModel();
                await ViewModel.SetSharedDataAsync(User);

                if (response == null)
                {
                    TempData["Heading"] = "Payment Failed";
                    TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";

                    return RedirectToAction("Error", "Error");
                }
                else if (response.errorCode > 0)
                {
                    TempData["Heading"] = "Payment Failed";

                    var ErrorCodes = new int[] { 5, 11, 21, 22, 27 };

                    if (ErrorCodes.Contains(response.errorCode))
                    {
                        TempData["Message"] = PaymentAPIMessagesResource.ResourceManager.GetString(Enum.GetName(typeof(Pay360StatusCodes), response.errorCode));
                    }
                    else if (response.errorCode == 12)
                    {
                        TempData["Message"] = response.message;
                    }
                    else
                    {
                        TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";
                    }

                    Logger.Error($"Class: PayPalController, Method: topUpSuccessReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorCode: { response.errorCode}, ErrorMessage: { response.message}");
                    return RedirectToAction("Error", "Error");
                }
                else
                {
                    TempData["Heading"] = "Payment";
                    TempData["Message"] = "Topup of £" + model.Amount + " is done successfully.";


                    Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                    bundleDetail.Add("Id", model.Msisdn);
                    bundleDetail.Add("name", "£" + model.Amount);
                    bundleDetail.Add("amount", model.Amount.ToString());
                    bundleDetail.Add("category", model.CheckOutType.ToString());
                    TempData["BundleDetail"] = bundleDetail;


                    return RedirectToAction("SuccessfulPayment");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PayPalController, Method: TopUpSuccessReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [ActionName("cancelReturn")]
        public IActionResult CancelReturn(CancelReturnPayPalViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                TempData["Heading"] = "Payment Failed";
                TempData["Message"] = "Your Payment is cancelled by Paypal";

                return RedirectToAction("Error", "Error");
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PayPalController, Method: CancelReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        private async Task<PayPalCreateSalePaymentRequest> CreatePayPalPaymentRequest(PayPalViewModel model)
        {
            try
            {
                string uRef = User.Identity.IsAuthenticated ? User.Claims.Where(e => e.Type == "Email").FirstOrDefault().Value : model.EmailAddress;
                string customerName = User.Identity.IsAuthenticated ? User.Claims.Where(e => e.Type == "FullName").FirstOrDefault().Value : "Guest";

                string purchaseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}/payPal/purchaseSuccessReturn?uRef=" + uRef + "&bundleId=" + model.UUID + "&bundleName=" + model.BundleName + "&Amount=" + model.Amount + "&Msisdn=" + model.Msisdn; 
                
                //string purchaseUrl = $"http://172.24.1.197:11021/payPal/purchaseSuccessReturn?uRef=" + uRef + "&bundleId=" + model.UUID + "&bundleName=" + model.BundleName + "&Amount=" + model.Amount + "&Msisdn=" + model.Msisdn;

                purchaseUrl = new Uri(purchaseUrl).AbsoluteUri.ToString();

                string topUpUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}/payPal/topUpSuccessReturn?uRef=" + uRef + "&Amount=" + model.Amount + "&Msisdn=" + model.Msisdn + "&CheckOutType=" + model.CheckoutPaymentType; 
                
                //string topUpUrl = $"http://172.24.1.197:11021/payPal/topUpSuccessReturn?uRef=" + uRef + "&Amount=" + model.Amount + "&Msisdn=" + model.Msisdn + "&CheckOutType=" + model.CheckoutPaymentType;

                topUpUrl = new Uri(topUpUrl).AbsoluteUri.ToString();
                string returnUrl = "";

                List<ProductBasket> baskets = new List<ProductBasket>();
                if (model.CheckoutPaymentType == CheckOutTypes.Bundle)
                {
                    ProductBasket basket = new ProductBasket()
                    {
                        Amount = model.Amount,
                        BundleRef = model.UUID,
                        ProductItemCode = ProductItemCode.NOWPG.ToString(),
                        ProductRef = model.Msisdn
                    };

                    baskets.Add(basket);
                }
                else
                {
                    ProductBasket basket = new ProductBasket()
                    {
                        Amount = model.Amount,
                        BundleRef = "",
                        ProductItemCode = ProductItemCode.NOWPG.ToString(),
                        ProductRef = model.Msisdn
                    };

                    baskets.Add(basket);
                }

                if (model.CheckoutPaymentType == CheckOutTypes.TopUp || model.CheckoutPaymentType == CheckOutTypes.FastTopUp)
                {
                    returnUrl = topUpUrl;
                }
                else
                {
                    returnUrl = purchaseUrl;
                }

                PayPalCreateSalePaymentRequest request = new PayPalCreateSalePaymentRequest
                {
                    CustomerName = customerName,
                    CustomerEmail = uRef,
                    //CustomerName = customerName,
                    //CustomerEmail = User.Identity.IsAuthenticated ? User.Claims.Where(e => e.Type == "Email").FirstOrDefault().Value : null,
                    CustomerMsisdn = model.Msisdn,
                    CustomerUniqueRef = uRef,
                    ProductCode = ProductCode.NOWPAYG.ToString(),
                    Transaction = new Transactions()
                    {
                        Amount = new Amounts()
                        {
                            Total = model.Amount,
                            Currency = Currency.GBP.ToString()
                        },
                        Description = "PayPal Transaction for Customer Unique Reference: " + uRef
                    },
                    RedirectUrl = new RedirectUrls
                    {
                        ReturnUrl = returnUrl,
                        CancelUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}/payPal/cancelReturn"
                    },
                    Basket = baskets
                };

                return request;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PayPalController, Method: CreatePayPalPaymentRequest, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("SuccessfulPayment")]
        [ActionName("SuccessfulPayment")]
        public async Task<IActionResult> Success()
        {
            var model = new MessageViewModel()
            {
                Heading = (string)TempData["Heading"],
                Message = (string)TempData["Message"]
            };

            //Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
            //bundleDetail.Add("Id", "1234");
            //bundleDetail.Add("name", "10");
            //bundleDetail.Add("amount", "10");
            //bundleDetail.Add("category", CheckOutTypes.TopUp.ToString());
            //TempData["BundleDetail"] = bundleDetail;

            ViewBag.BundleDetail = (TempData["BundleDetail"] != null) ? TempData["BundleDetail"] : new Dictionary<string, string>();
            TempData.Keep();
            await model.SetSharedDataAsync(User);
            return View("~/Views/Shared/Success.cshtml", model);
        }


        [Route("PayPal/Pay360Payment")]
        [ValidateAntiForgeryToken]
        [HttpPost]
        public async Task<ActionResult> Pay360PayPalStartPayment(Pay360PaypalPaymentPostModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                model.Msisdn= phoneNumberUtil.Format(phoneNumberUtil.Parse(model.Msisdn, "GB"), PhoneNumberFormat.E164).Replace("+", "").Trim();
                var response = await PayPalService.Pay360PayPalCreateSalePayment(await CreatePay360PayPalPaymentRequest(model));

                if (response == null)
                {
                    TempData["Heading"] = "Payment Failed";
                    TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";

                    return RedirectToAction("Error", "Error");
                }
                if (response.errorCode > 0)
                {
                    TempData["Heading"] = "Payment Failed";

                    var ErrorCodes = new int[] { 5, 11, 21, 22, 27 };

                    if (ErrorCodes.Contains(response.errorCode))
                    {
                        TempData["Message"] = PaymentAPIMessagesResource.ResourceManager.GetString(Enum.GetName(typeof(Pay360StatusCodes), response.errorCode));
                    }
                    else
                    {
                        Logger.Error($"Class: PayPalController, Method: PayPalStartPayment, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorCode: { response.errorCode}, ErrorMessage: { response.message}");

                        TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";
                    }

                    return RedirectToAction("Error", "Error");
                }
                return Redirect(response.payload.clientRedirectUrl);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PayPalController, Method: Pay360PayPalStartPayment, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }

        }
   
        [HttpGet]
        [ActionName("pay360purchaseSuccessReturn")]
        public async Task<IActionResult> Pay360PurchaseSuccessReturn(SuccessReturnPayPalViewModel model)
        {
            try
            {
                if (!ModelState.IsValid) { return RedirectToAction("ErrorMessage", "Home", new { key = "InvalidForm" }); }

                Pay360PayPalResumePaymentRequest request = new Pay360PayPalResumePaymentRequest
                {
                    PaypalCheckoutToken = model.token
                };


                var response = await PayPalService.Pay360ResumePayment(request);

                if (response == null)
                {
                    TempData["Heading"] = "Payment Failed";
                    TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";

                    return RedirectToAction("Error", "Error");
                }
                else if (response.errorCode > 0)
                {
                    TempData["Heading"] = "Payment Failed";

                    var ErrorCodes = new int[] { 5, 11, 21, 22, 27 };

                    if (ErrorCodes.Contains(response.errorCode))
                    {
                        TempData["Message"] = PaymentAPIMessagesResource.ResourceManager.GetString(Enum.GetName(typeof(Pay360StatusCodes), response.errorCode));
                    }
                    else if (response.errorCode == 12)
                    {
                        TempData["Message"] = response.message;
                    }
                    else
                    {
                        TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";
                    }

                    Logger.Error($"Class: PayPalController, Method: pay360purchaseSuccessReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorCode: { response.errorCode}, ErrorMessage: { response.message}");
                    return RedirectToAction("Error", "Error");
                }
                else
                {
                    TempData["Heading"] = "Payment";
                    TempData["Message"] = "Plan of £" + model.Amount + " is purchased successfully.";

                    Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                    bundleDetail.Add("Id", model.Msisdn);
                    bundleDetail.Add("name", model.bundleName);
                    bundleDetail.Add("amount", model.Amount.ToString());
                    bundleDetail.Add("category", CheckOutTypes.Bundle.ToString());
                    TempData["BundleDetail"] = bundleDetail;

                    return RedirectToAction("SuccessfulPayment");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PayPalController, Method: pay360purchaseSuccessReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }

        }

        [HttpGet]
        [ActionName("pay360topUpSuccessReturn")]
        public async Task<IActionResult> Pay360TopUpSuccessReturn(SuccessReturnPayPalViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                Pay360PayPalResumePaymentRequest request = new Pay360PayPalResumePaymentRequest
                {
                    PaypalCheckoutToken = model.token
                };

                var response = await PayPalService.Pay360ResumePayment(request);

                MessageViewModel ViewModel = new MessageViewModel();
                await ViewModel.SetSharedDataAsync(User);

                if (response == null)
                {
                    TempData["Heading"] = "Payment Failed";
                    TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";

                    return RedirectToAction("Error", "Error");
                }
                else if (response.errorCode > 0)
                {
                    TempData["Heading"] = "Payment Failed";

                    var ErrorCodes = new int[] { 5, 11, 21, 22, 27 };

                    if (ErrorCodes.Contains(response.errorCode))
                    {
                        TempData["Message"] = PaymentAPIMessagesResource.ResourceManager.GetString(Enum.GetName(typeof(Pay360StatusCodes), response.errorCode));
                    }
                    else if (response.errorCode == 12)
                    {
                        TempData["Message"] = response.message;
                    }
                    else
                    {
                        TempData["Message"] = "Payment Service is not responding at the moment. Please try again later";
                    }

                    Logger.Error($"Class: PayPalController, Method: pay360topUpSuccessReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorCode: { response.errorCode}, ErrorMessage: { response.message}");
                    return RedirectToAction("Error", "Error");
                }
                else
                {
                    TempData["Heading"] = "Payment";
                    TempData["Message"] = "Topup of £" + model.Amount + " is done successfully.";


                    Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                    bundleDetail.Add("Id", model.Msisdn);
                    bundleDetail.Add("name", "£" + model.Amount);
                    bundleDetail.Add("amount", model.Amount.ToString());
                    bundleDetail.Add("category", model.CheckOutType.ToString());
                    TempData["BundleDetail"] = bundleDetail;
                    return RedirectToAction("SuccessfulPayment");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PayPalController, Method: pay360topUpSuccessReturn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        private async Task<Pay360PayPalCreateSalePaymentRequest> CreatePay360PayPalPaymentRequest(Pay360PaypalPaymentPostModel model)
        {
            try
            {
                Pay360PayPalCreateSalePaymentRequest request = new Pay360PayPalCreateSalePaymentRequest();

                string uRef = User.Identity.IsAuthenticated ? User.Claims.Where(e => e.Type == "Email").FirstOrDefault().Value : model.EmailAddress;
                string customerName = User.Identity.IsAuthenticated ? User.Claims.Where(e => e.Type == "FullName").FirstOrDefault().Value : "Guest";

                string purchaseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}/payPal/pay360purchaseSuccessReturn?uRef=" + uRef + "&bundleId=" + model.UUID + "&bundleName=" + model.BundleName + "&Amount=" + model.Amount + "&Msisdn=" + model.Msisdn;

                //string purchaseUrl = $"http://172.24.1.197:11021/payPal/pay360purchaseSuccessReturn?uRef=" + uRef + "&bundleId=" + model.UUID + "&bundleName=" + model.BundleName + "&Amount=" + model.Amount + "&Msisdn=" + model.Msisdn;

                purchaseUrl = new Uri(purchaseUrl).AbsoluteUri.ToString();

                string topUpUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}/payPal/pay360topUpSuccessReturn?uRef=" + uRef + "&Amount=" + model.Amount + "&Msisdn=" + model.Msisdn + "&CheckOutType=" + model.CheckoutPaymentType;

                //string topUpUrl = $"http://172.24.1.197:11021/payPal/pay360topUpSuccessReturn?uRef=" + uRef + "&Amount=" + model.Amount + "&Msisdn=" + model.Msisdn + "&CheckOutType=" + model.CheckoutPaymentType;

                topUpUrl = new Uri(topUpUrl).AbsoluteUri.ToString();
                string returnUrl = "";

                List<ProductBasket> baskets = new List<ProductBasket>();
                if (model.CheckoutPaymentType == CheckOutTypes.Bundle)
                {
                    ProductBasket basket = new ProductBasket()
                    {
                        Amount = model.Amount,
                        BundleRef = model.UUID,
                        ProductItemCode = ProductItemCode.NOWPG.ToString(),
                        ProductRef = model.Msisdn
                    };

                    baskets.Add(basket);
                }
                else
                {
                    ProductBasket basket = new ProductBasket()
                    {
                        Amount = model.Amount,
                        BundleRef = "",
                        ProductItemCode = ProductItemCode.NOWPG.ToString(),
                        ProductRef = model.Msisdn
                    };

                    baskets.Add(basket);
                }

                if (model.CheckoutPaymentType == CheckOutTypes.TopUp || model.CheckoutPaymentType == CheckOutTypes.FastTopUp)
                {
                    returnUrl = topUpUrl;
                }
                else
                {
                    returnUrl = purchaseUrl;
                }

              

                customField customFields = new customField();

                string FirstRegistrationDate;
                try
                {
                    var response = await Api.CallApi(_endPointsSettings.NowPaygApiEndPoint + "CommonServices/GetFirstUseDate", User, GetRequest: true, parameters: "Msisdn=" + model.Msisdn);
                    if (response is Error)
                    {
                        FirstRegistrationDate = "";
                    }
                    else
                    {
                        FirstRegistrationDate = Convert.ToDateTime(response.GetValue("payload").ToObject<string>()).ToString("yyyy-MM-dd");
                    }
                }
                catch
                {
                    FirstRegistrationDate = "";
                }


                request.Basket = baskets;

                List<fieldstate> _fieldState = new List<fieldstate>()
                {
                    new fieldstate() { name = "ProductCode", value = "NOWPAYG", transient = false },
                    new fieldstate() { name = "ProductItemCode", value = "NOWPG", transient = false },
                    new fieldstate() { name = "FirstUseDate", value = FirstRegistrationDate, transient = false },
                };
                customFields.fieldState = _fieldState;
                request.customFields = customFields;

                request.ipAddress = ExtensionMethods.GetRemoteIPAddress(HttpContext);


                request.CustomerMsisdn = model.Msisdn;
                request.CustomerUniqueRef = uRef;
                request.CustomerEmail = uRef;

                request.ProductCode = ProductCode.NOWPAYG.ToString();

                request.transactionCurrency = Currency.GBP.ToString();
                request.transactionAmount = model.Amount;

                paymentMethod paymentMethod = new paymentMethod();


                paymentMethod.paypal = new paypal
                {
                    returnUrl = returnUrl,
                    cancelUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}/payPal/cancelReturn"
                };
                request.paymentMethod = paymentMethod;
                request.isDirectFullfilment = true;
                request.CustomerName = customerName;
                return request;

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PayPalController, Method: CreatePayPalPaymentRequest, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }
    }
}