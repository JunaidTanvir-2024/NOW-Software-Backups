using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Loyalties.Responses
{
    public class AddLoyaltyPointsResponse
    {
        [JsonPropertyName("eventName")]
        public string EventName { get; set; }

        [JsonPropertyName("customerId")]
        public string CustomerId { get; set; }
    }
}