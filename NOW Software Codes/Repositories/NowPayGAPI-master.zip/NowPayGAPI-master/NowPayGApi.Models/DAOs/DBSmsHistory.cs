﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBSmsHistory
    {
        public string Date { get; set; }
        public string calling_party_number { get; set; }
        public string called_party_number { get; set; }
        public string subscriber_charge { get; set; }
        public string Number_of_sms { get; set; }
    }
}
