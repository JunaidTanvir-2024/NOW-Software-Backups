﻿namespace ATT.Models.Contracts.Common
{
    public class TopupSmsDetailsModel
    {
        public string FromMsisdn { set; get; }
        public string ToMsisdn { set; get; }
        public string ReceiptText { set; get; }
        public string TransactionId { set; get; }
        public string PinCode { set; get; }
        public string SmsToSend { set; get; }
        public string AmountTransfered { set; get; }
    }
}
