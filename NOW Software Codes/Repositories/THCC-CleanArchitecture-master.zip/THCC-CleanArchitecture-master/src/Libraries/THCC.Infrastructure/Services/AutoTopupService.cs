﻿using System.Net.Sockets;
using System.Net;
using System.Security.Cryptography;
using System.Text;

using Microsoft.CodeAnalysis;
using Microsoft.Extensions.Options;

using Newtonsoft.Json;

using Serilog;

using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;
using THCC.Application.Settings;
using THCC.Domain.Entities;

using static THCC.Domain.Constants.ThccConstants;
using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Services
{
    public class AutoTopupService : IAutoTopupService
    {
        private readonly ITopupRepository _topupRepository;
        private readonly IPaymentRepository _paymentRepository;
        private readonly IPaymentFulfillmentRepository _fulfillmentRepository;
        private readonly IUserRepository _userRepository;
        private readonly IPointsRepository _pointsRepository;
        private readonly ICommonService _commonService;
        private readonly ICardService _cardService;
        private readonly ILogger _logger;
        private readonly ILegacyRepository _legacyRepository;
        private readonly IUserService _userService;
        private readonly ICallingCardRepository _callingCardRepository;
        private readonly TopupSettings _topupSettings;
        private readonly AutoTopupServiceSettings _autoTopupServiceSettings;

        public AutoTopupService(
            ITopupRepository topupRepository,
            IPaymentRepository paymentRepository,
            IPaymentFulfillmentRepository fulfillmentRepository,
            IUserRepository userRepository,
            IPointsRepository pointsRepository,
            ICommonService commonService,
            ICardService cardService,
            ILogger logger,
            ILegacyRepository legacyRepository,
            IUserService userService,
            ICallingCardRepository callingCardRepository,
            IOptions<TopupSettings> topupSettings,
            IOptions<AutoTopupServiceSettings> autoTopupServiceSettings)
        {
            _topupRepository = topupRepository;
            _paymentRepository = paymentRepository;
            _fulfillmentRepository = fulfillmentRepository;
            _userRepository = userRepository;
            _pointsRepository = pointsRepository;
            _commonService = commonService;
            _cardService = cardService;
            _logger = logger;
            _legacyRepository = legacyRepository;
            _userService = userService;
            _callingCardRepository = callingCardRepository;
            _topupSettings = topupSettings.Value;
            _autoTopupServiceSettings = autoTopupServiceSettings.Value;
        }

        public async Task StartPay360THRCCAutoTopupJob()
        {
            string customerAccount = string.Empty;
            string customerEmail = string.Empty;
            string productCode = string.Empty;
            var autoTopupTransactions = await _topupRepository.GetAutoTopupTransactions();
            if (autoTopupTransactions?.Count() > 0)
            {
                foreach (var transacton in autoTopupTransactions)
                {
                    try
                    {
                        _logger.Information($"AutoTopupService: Executing the transation : {transacton.Email} {transacton.Account}");

                        //Get Card Details
                        var cardDetails = await _callingCardRepository.GetCardInfo(transacton.Account);
                        if (cardDetails == null || string.IsNullOrEmpty(cardDetails.Pin))
                        {
                            _logger.Error($"No calling card details found: {transacton.Email} {transacton.Account}");
                            continue;
                        }

                        var autoTopupCurrentMonthAmount = await _topupRepository.GetCurrentMonthAutoTopupAmount(nameof(ProductItemCode.THRCC), transacton.Account, cardDetails.Pin.Trim());
                        if (autoTopupCurrentMonthAmount + transacton.TopupAmount >= _autoTopupServiceSettings.AutoTopupMonthlyMaxLimit)
                        {
                            _logger.Information($"AutoTopupService: Customer reached the monthly limit: {transacton.Email} {transacton.Account}");
                            continue;
                        }

                        var currentDate = DateTime.UtcNow;
                        if (transacton?.IsSuccess == false && transacton.ErrorCode == 3 && transacton.ReExecuteCount < 3)
                        {
                            DateTime lastDay = currentDate.AddDays(-1);
                            if (transacton.LastExecutionDate > lastDay)
                            {
                                continue;
                            }
                        }
                        else if (transacton?.IsSuccess == false && transacton.ErrorCode == 3 && transacton.ReExecuteCount == 3)
                        {
                            DateTime lastWeek = currentDate.AddDays(-7);
                            if (transacton.LastExecutionDate > lastWeek)
                            {
                                continue;
                            }
                        }
                        else if (transacton?.IsSuccess == false && transacton.ErrorCode == 3 && transacton.ReExecuteCount > 3)
                        {
                            continue;
                        }

                        customerAccount = transacton!.Account.Trim();
                        customerEmail = transacton.Email.Trim();
                        productCode = transacton.ProductCode.Trim();
                        DateTime transactionTime = DateTime.UtcNow;

                        //Get user from new THCC db
                        var userInfo = await _userRepository.GetUserByEmailAsync(customerEmail);
                        if (userInfo == null)
                        {
                            //Check if user exists in legacy THCC db
                            var legacyUser = await _legacyRepository.GetUserByEmail(customerEmail);
                            if (legacyUser != null)
                            {
                                //Register this user in new db 
                                var signupResponse = await _userService.SignUpAsync(
                                        legacyUser.FirstName.Trim(),
                                        legacyUser.LastName.Trim(),
                                        customerEmail,
                                        null!,
                                        UserRole.Customer,
                                        true);

                                if (signupResponse.IsSuccess)
                                {
                                    //Get legacy user product
                                    var legacyUserProduct = await _legacyRepository.GetUserProducts(legacyUser.Id);

                                    //Register products in new db
                                    if (legacyUserProduct != null)
                                    {
                                        (bool isProductSuccess, int errorCode, string errorMessage) = await _userRepository.CreateProduct(
                                                legacyUserProduct.ProductRef!,
                                                signupResponse.Id!,
                                                legacyUserProduct.DateCreated);
                                        if (!isProductSuccess && errorCode > 0)
                                        {
                                            _logger.Error(
                                                $"Daemon - Failed {legacyUser.Email} product registration to new DB with errorCode: " +
                                                $"{errorCode} {errorMessage}");
                                        }
                                    }
                                }
                                userInfo = await _userRepository.GetUserByEmailAsync(customerEmail);
                            }
                        }

                        //Create order request 
                        var topupAmount = Convert.ToDecimal(transacton!.TopupAmount!);
                        var order = new Order
                        {
                            UserId = userInfo!.Id!,
                            Discount = 0,
                            TotalAmount = topupAmount,
                            Amount = topupAmount,
                            Description = null,
                            IpAddress = null,
                            OrderStatus = OrderStatus.Created,
                            Device = null,
                            DeviceLocation = null
                        };
                        var orderItem = new OrderItem
                        {
                            Discount = 0,
                            TotalAmount = topupAmount,
                            Amount = topupAmount,
                            CardNumber = customerAccount,
                            ProductType = ProductType.AutoTopupTransaction
                        };
                        var orderPayment = new OrderPayment()
                        {
                            PaymentMethodId = PaymentMethod.Card,
                            Stauts = PaymentStatus.Pending,
                            PaymentUserId = userInfo.Id
                        };
                        var orderCardPayment = new OrderCardPayment()
                        {
                            CardNumber = string.IsNullOrEmpty(transacton.InitialTransactionId) ? "Default Card" : transacton.MaskedPan,
                            CardExpiry = null!,
                            CardType = null!,
                            SaveCard = false,
                            MakeDefault = false,
                            IsAutoPayment = false,
                            AutoPaymentAmount = 0,
                            AutoPaymentThreshold = 0
                        };

                        var accountDetail = await _userRepository.GetAccountDetails(orderItem.CardNumber!);
                        int points = await _pointsRepository.GetPoints(orderItem.CardNumber!);

                        var orderPoint = new OrderPoint
                        {
                            OpeningBalance = decimal.Parse(accountDetail.Credit!),
                            ClosingBalance = decimal.Parse(accountDetail.Credit!) + order.Amount,
                            OpeningPoints = points,
                            PointsReceived = _topupSettings.Amounts.Find(x => x.Amount == order.Amount)!.Points
                        };
                        orderPoint.ClosingPoints = points + orderPoint.PointsReceived;

                        var orderHistory = new OrderHistory()
                        {
                            Description = "Auto Payment - Order Created"
                        };

                        //Save order data
                        long orderId = await _paymentRepository.SaveOrderDetails(
                            order,
                            orderItem,
                            orderPayment,
                            orderCardPayment,
                            null!,
                            orderPoint,
                            orderHistory);

                        if (orderId == 0)
                        {
                            await _topupRepository.UpdateTHRCCAutoTopupTransaction(
                               isSuccess: false,
                               errorMessage: "Unable to save order history",
                               lastExecutionTime: DateTime.UtcNow,
                               msisdn: transacton.Account,
                               errorCode: 3,
                               reExecuteCount: transacton!.ReExecuteCount + 1,
                               email: transacton.Email,
                               productCode: transacton.ProductCode,
                               account: customerAccount);

                            continue;
                        }

                        var customerDetails = await _paymentRepository.GetCustomerByMerchantRef(
                                                $"{transacton.ProductCode.ToUpper()}_{transacton.Email}");
                        if (customerDetails == null)
                        {
                            await _topupRepository.UpdateTHRCCAutoTopupTransaction(
                               isSuccess: false,
                               errorMessage: "Customer does not exists in Pay360 database",
                               lastExecutionTime: DateTime.UtcNow,
                               msisdn: transacton.Account,
                               errorCode: 2,
                               reExecuteCount: 0,
                               email: transacton.Email,
                               productCode: transacton.ProductCode,
                               account: customerAccount);
                            _logger.Error($"Class: AutoTopupService, Method: StartPay360THRCCAutoTopupJob, " +
                                $"ErrorMessage: Customer does not exists in database, MerchantReference: {customerDetails?.MerchantRef}");

                            continue;
                        }

                        CardPaymentRequestDto cardPaymentRequest = null!;
                        CardPaymentResponseDto cardPaymentResponse = null!;
                        if (string.IsNullOrEmpty(transacton.InitialTransactionId))
                        {
                            //Default Card payment
                            cardPaymentRequest = new CardPaymentRequestDto()
                            {
                                PaymentDefaultCardInfo = new PaymentDefaultCardDto
                                {
                                    CardCv2 = Decrypt(customerDetails.DefaultCardCV2!, customerDetails.EncryptionKey!)
                                },
                                IpAddress = Dns.GetHostAddresses(Dns.GetHostName()).First(address => address.AddressFamily == AddressFamily.InterNetwork).ToString(),
                                CardNumber = transacton.Account,
                                Amount = order.TotalAmount,
                                TransactionType = ProductType.AutoTopupTransaction,
                                IsRecurring = false,
                                Email = transacton.Email!
                            };
                            cardPaymentResponse = await _cardService.CardPayment(cardPaymentRequest);
                        }
                        else
                        {
                            cardPaymentResponse = await _cardService.RecurringPayment(
                                new RecurringPaymentDto
                                {
                                    Amount = order.TotalAmount,
                                    TransactionId = transacton.InitialTransactionId
                                });
                        }
                        if (cardPaymentResponse?.IsSuccess == false)
                        {
                            _logger.Error($"Class: AutoTopupService, Method: StartPay360THRCCAutoTopupJob, Type: Pay360 Payments Api Call, " +
                                $"RequestJson => {JsonConvert.SerializeObject(cardPaymentRequest)}, ErrorMessage: {cardPaymentResponse.ErrorMessage} ");

                            await _topupRepository.AddAutoTopupTransaction(
                               customerId: customerDetails.Id,
                               customerMerchantRef: customerDetails.MerchantRef!,
                               pay360TransactionId: string.Empty,
                               transactionAmount: transacton.TopupAmount,
                               transactionCurrency: nameof(Currency.GBP),
                               transactionDate: transactionTime,
                               isTransactionSuccess: false,
                               transactionErrorMessage: cardPaymentResponse?.ErrorMessage!,
                               isFullfilmentSuccess: false,
                               fullfilmentErrorMessage: null!,
                               fullfilmentDate: null!,
                               fullfilmentRef: null!,
                               isSmsSent: false,
                               smsSentDate: null,
                               isEmailSent: false,
                               emailSentDate: null);

                            int errorCode = 0;
                            int reExecuteCount = cardPaymentResponse?.IsSuccess == true ? 0 : transacton!.ReExecuteCount + 1;
                            if (cardPaymentResponse!.ErrorMessage!.Contains("Declined by upstream processor"))
                            {
                                errorCode = 1;  // Dead End
                            }
                            else if (cardPaymentResponse.ErrorMessage.Contains("Customer does not exists"))
                            {
                                errorCode = 2; // Customer does not exists 
                                reExecuteCount = 0;
                            }
                            else
                            {
                                errorCode = 3;  // Other Error but Not Dead End
                            }

                            //Update auto-topup transaction status
                            await _topupRepository.UpdateTHRCCAutoTopupTransaction(
                               isSuccess: false,
                               errorMessage: cardPaymentResponse.ErrorMessage,
                               lastExecutionTime: transactionTime,
                               msisdn: transacton.Account,
                               errorCode: errorCode,
                               reExecuteCount: reExecuteCount,
                               email: transacton.Email,
                               productCode: transacton.ProductCode,
                               account: customerAccount);

                            //Update order history
                            await _paymentRepository.UpdateOrderHistoryStatus(
                                orderId,
                                cardPaymentResponse.TransactionId!,
                                OrderStatus.Failure,
                                PaymentStatus.Failure,
                                cardPaymentResponse!.ErrorMessage! + "-" + cardPaymentResponse!.ErrorCode!.ToString(),
                                OrderHistoryConstants.PaymentFailed);

                            continue;
                        }

                        #region Fullfillment

                        var amount = transacton.TopupAmount;
                        amount *= 100;
                        var result = await _fulfillmentRepository.ThrccCustomerFullfilment(cardPaymentResponse!?.TransactionId!, amount.ToString(), transacton.Account);
                        if (result?.ErrorCode == 0)
                        {
                            const int errorCode = 0;   //  Success
                            const int reExecuteCount = 0;

                            //update auto topup transaction status
                            await _topupRepository.UpdateTHRCCAutoTopupTransaction(
                                isSuccess: true,
                                errorMessage: string.Empty,
                                lastExecutionTime: DateTime.UtcNow,
                                msisdn: transacton.Account,
                                errorCode: errorCode,
                                reExecuteCount: reExecuteCount,
                                email: transacton.Email,
                                productCode: transacton.ProductCode,
                                account: customerAccount);

                            //update order history
                            await _paymentRepository.UpdateOrderHistoryStatus(
                                orderId,
                                cardPaymentResponse!.TransactionId!,
                                OrderStatus.Success,
                                PaymentStatus.Success,
                                null!,
                                OrderHistoryConstants.PaymentSuccess);

                            var orderDetails = await _paymentRepository.GetOrderDetails(orderId);
                            await _fulfillmentRepository.UpdateFulfillmentItems(
                                  orderItemId: orderDetails.OrderItemId,
                                  errorMsg: null!,
                                  cardnumber: result?.CardNumber!,
                                  cardpin: result?.PinNumber!,
                                  orderHistoryDescription: OrderHistoryConstants.FulfillmentSuccess);

                            await _topupRepository.AddAutoTopupTransaction(
                                      customerId: customerDetails.Id,
                                      customerMerchantRef: customerDetails.MerchantRef!,
                                      pay360TransactionId: cardPaymentResponse!.TransactionId!,
                                      transactionAmount: transacton.TopupAmount,
                                      transactionCurrency: nameof(Currency.GBP),
                                      transactionDate: transactionTime,
                                      isTransactionSuccess: true,
                                      transactionErrorMessage: null!,
                                      isFullfilmentSuccess: true,
                                      fullfilmentErrorMessage: null!,
                                      fullfilmentDate: DateTime.UtcNow,
                                      fullfilmentRef: result?.AuditId!,
                                      isSmsSent: false,
                                      smsSentDate: null,
                                      isEmailSent: false,
                                      emailSentDate: null);
                        }
                        else
                        {
                            // Fullfilment Un-Successfull
                            const int errorCode = 2;

                            //update auto topup transaction status
                            await _topupRepository.UpdateTHRCCAutoTopupTransaction(
                                isSuccess: false,
                                errorMessage: "Error in Customer Fullfilment",
                                lastExecutionTime: DateTime.UtcNow,
                                msisdn: transacton.Account,
                                errorCode: errorCode,
                                reExecuteCount: transacton!.ReExecuteCount + 1,
                                email: transacton.Email,
                                productCode: transacton.ProductCode,
                                account: customerAccount);
                            _logger.Error($"Class: AutoTopupService, Method: StartPay360THRCCAutoTopupJob, Error in Customer Fullfilment, Msisdn: {transacton.Account} ");

                            // update order with failure
                            await _paymentRepository.UpdateOrderHistoryStatus(
                                orderId,
                                cardPaymentResponse?.TransactionId!,
                                OrderStatus.Failure,
                                PaymentStatus.Success,
                                null!,
                                null!);

                            //update order fullfilment with failure
                            var orderDetails = await _paymentRepository.GetOrderDetails(orderId);
                            await _fulfillmentRepository.UpdateFulfillmentItems(
                                  orderItemId: orderDetails.OrderItemId,
                                  errorMsg: result?.ErrorMessage!,
                                  cardnumber: null!,
                                  cardpin: null!,
                                  orderHistoryDescription: OrderHistoryConstants.FulfillmentFailed);

                        }

                        #endregion

                    }
                    catch (Exception ex)
                    {
                        if (!string.IsNullOrWhiteSpace(customerAccount) && !string.IsNullOrWhiteSpace(customerEmail) && !string.IsNullOrWhiteSpace(productCode))
                        {
                            const int errorCode = 3;  // Other Error but Not Dead End0
                            await _topupRepository.UpdateTHRCCAutoTopupTransaction(
                                isSuccess: false,
                                errorMessage: "THRCC Daemon Exception: " + ex.Message,
                                lastExecutionTime: DateTime.UtcNow,
                                msisdn: customerAccount,
                                errorCode: errorCode,
                                reExecuteCount: transacton!.ReExecuteCount + 1,
                                email: customerEmail,
                                productCode: productCode,
                                account: customerAccount);
                        }
                        _logger.Error($"Class: AutoTopupService, Method: StartPay360THRCCAutoTopupJob, ErrorMessage: {ex.Message} ");
                    }
                }
            }
        }

        #region Private

        private const int Keysize = 128;

        // This constant determines the number of iterations for the password bytes generation function.
        private const int DerivationIterations = 1000;

        private string Encrypt(string plainText, string key)
        {
            // Salt and IV is randomly generated each time, but is preprended to encrypted cipher text
            // so that the same Salt and IV values can be used when decrypting.  
            var saltStringBytes = Generate128BitsOfRandomEntropy();
            var ivStringBytes = Generate128BitsOfRandomEntropy();
            var plainTextBytes = Encoding.UTF8.GetBytes(plainText);
#pragma warning disable SYSLIB0041 // Type or member is obsolete
            using var password = new Rfc2898DeriveBytes(key, saltStringBytes, DerivationIterations);
            var keyBytes = password.GetBytes(Keysize / 8);
#pragma warning disable SYSLIB0022 // Type or member is obsolete
            using var symmetricKey = new RijndaelManaged();
#pragma warning restore SYSLIB0022 // Type or member is obsolete
            symmetricKey.BlockSize = 128;
            symmetricKey.Mode = CipherMode.CBC;
            symmetricKey.Padding = PaddingMode.PKCS7;
            using var encryptor = symmetricKey.CreateEncryptor(keyBytes, ivStringBytes);
            using var memoryStream = new MemoryStream();
            using var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            // Create the final bytes as a concatenation of the random salt bytes, the random iv bytes and the cipher bytes.
            var cipherTextBytes = saltStringBytes;
            cipherTextBytes = cipherTextBytes.Concat(ivStringBytes).ToArray();
            cipherTextBytes = cipherTextBytes.Concat(memoryStream.ToArray()).ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
#pragma warning restore SYSLIB0041 // Type or member is obsolete
        }

        private string Decrypt(string cipherText, string key)
        {
            // Get the complete stream of bytes that represent:
            // [32 bytes of Salt] + [32 bytes of IV] + [n bytes of CipherText]
            var cipherTextBytesWithSaltAndIv = Convert.FromBase64String(cipherText);
            // Get the saltbytes by extracting the first 32 bytes from the supplied cipherText bytes.
            var saltStringBytes = cipherTextBytesWithSaltAndIv.Take(Keysize / 8).ToArray();
            // Get the IV bytes by extracting the next 32 bytes from the supplied cipherText bytes.
            var ivStringBytes = cipherTextBytesWithSaltAndIv.Skip(Keysize / 8).Take(Keysize / 8).ToArray();
            // Get the actual cipher text bytes by removing the first 64 bytes from the cipherText string.
            var cipherTextBytes = cipherTextBytesWithSaltAndIv.Skip(Keysize / 8 * 2).Take(cipherTextBytesWithSaltAndIv.Length - Keysize / 8 * 2).ToArray();

#pragma warning disable SYSLIB0041 // Type or member is obsolete
            using var password = new Rfc2898DeriveBytes(key, saltStringBytes, DerivationIterations);
            var keyBytes = password.GetBytes(Keysize / 8);
#pragma warning disable SYSLIB0022 // Type or member is obsolete
            using var symmetricKey = new RijndaelManaged();
#pragma warning restore SYSLIB0022 // Type or member is obsolete
            symmetricKey.BlockSize = 128;
            symmetricKey.Mode = CipherMode.CBC;
            symmetricKey.Padding = PaddingMode.PKCS7;
            using var decryptor = symmetricKey.CreateDecryptor(keyBytes, ivStringBytes);
            using var memoryStream = new MemoryStream(cipherTextBytes);
            using var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            var plainTextBytes = new byte[cipherTextBytes.Length];
            var decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
            return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
#pragma warning restore SYSLIB0041 // Type or member is obsolete
        }

        private byte[] Generate128BitsOfRandomEntropy()
        {
            var randomBytes = new byte[16]; // 16 Bytes will give us 128 bits.
#pragma warning disable SYSLIB0023 // Type or member is obsolete
            using (var rngCsp = new RNGCryptoServiceProvider())
            {
                // Fill the array with cryptographically secure random bytes.
                rngCsp.GetBytes(randomBytes);
            }
#pragma warning restore SYSLIB0023 // Type or member is obsolete
            return randomBytes;
        }

        #endregion
    }
}