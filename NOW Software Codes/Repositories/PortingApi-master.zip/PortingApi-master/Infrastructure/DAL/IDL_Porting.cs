﻿using Models.DAO;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL
{
    public interface IDL_Porting
    {
        Task<int> InsertPortRequest(Port port);
        Task<IEnumerable<Port>> GetPortingRequests(Port port);
        Task<int> UpdateUserPortingDate(Port port);
        Task<string> GetSubscriberId(string msisdn);
        Task<int> ValidatePortingRequest(Port port);
        Task<PortingCodeInfo> ValidatePortingBySMSRequest(Port port);
        Task<int> CancelPortingRequest(Port port);
        Task<GetTempMsisdnDbResponse> GetTempMsisdn(int orderReferenceId, Products product);
        Task<int> InsertApiPortingRequest(Port port);
        Task<Product> GetProduct(string Msisdn);
        Task<Port> GetPortingRequestsbyID(int id);
    }
}
