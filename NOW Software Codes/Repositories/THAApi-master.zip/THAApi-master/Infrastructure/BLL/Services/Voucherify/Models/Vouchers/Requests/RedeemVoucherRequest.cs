﻿using Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests;

namespace Infrastructure.BLL.Services.Voucherify.Models.Vouchers.Requests
{
    public class RedeemVoucherRequest
    {
        public string VoucherCode { get; set; }
        public CreateVoucherifyCustomerRequest Customer { get; set; }
    }
}
