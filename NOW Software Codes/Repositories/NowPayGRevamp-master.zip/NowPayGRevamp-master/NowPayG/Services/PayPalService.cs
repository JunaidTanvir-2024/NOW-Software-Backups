﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NowPayG.Configurations;
using NowPayG.Models.PaypalApiContracts;
using NowPayG.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace NowPayG.Services
{
    public class PayPalService :IPayPalService
    {
        private readonly string PayPalApiEndpoint;
        private readonly string Pay360PayPalApiEndpoint;
        public PayPalService(IOptions<PayPalConfig> payPalConfig)
        {
            PayPalApiEndpoint = payPalConfig.Value.PayPalApiEndpoint;
            Pay360PayPalApiEndpoint = payPalConfig.Value.Pay360PayPalApiEndpoint;
        }

        public async Task<GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>> PayPalCreateSalePayment(PayPalCreateSalePaymentRequest request)
        {
            GenericPayPalApiResponse<PayPalCreateSalePaymentResponse> ret = new GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";
            endpoint = PayPalApiEndpoint + "Paypal/CreateSalePayment";
            Json = JsonConvert.SerializeObject(request);
            Result = await Post(endpoint, Json);
            if (Result == null)
            {
                return null;
            }
            ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>>(Result);
            return ret;

        }

        public async Task<GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>> PayPalExecuteSalePayment(PayPalExecuteSalePaymentRequest request)
        {
            GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse> ret = new GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";
            endpoint = PayPalApiEndpoint + "Paypal/ExecuteSalePayment";
            Json = JsonConvert.SerializeObject(request);
            Result = await Post(endpoint, Json);
            if (Result == null)
            {
                return null;
            }
            ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>>(Result);
            return ret;

        }



        public async Task<GenericPayPalApiResponse<Pay360PayPalCreateSalePaymentResponse>> Pay360PayPalCreateSalePayment(Pay360PayPalCreateSalePaymentRequest request)
        {
            GenericPayPalApiResponse<Pay360PayPalCreateSalePaymentResponse> ret = new GenericPayPalApiResponse<Pay360PayPalCreateSalePaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";
            endpoint = Pay360PayPalApiEndpoint + "Paypal/Payment";
            Json = JsonConvert.SerializeObject(request);
            Result = await Post(endpoint, Json);
            if (Result == null)
            {
                return null;
            }
            ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<Pay360PayPalCreateSalePaymentResponse>>(Result);
            return ret;

        }    
        
        public async Task<GenericPayPalApiResponse<Pay360PayPalCreateResumePaymentResponse>> Pay360ResumePayment(Pay360PayPalResumePaymentRequest request)
        {
            GenericPayPalApiResponse<Pay360PayPalCreateResumePaymentResponse> ret = new GenericPayPalApiResponse<Pay360PayPalCreateResumePaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";
            endpoint = Pay360PayPalApiEndpoint + "Paypal/Resume";
            Json = JsonConvert.SerializeObject(request);
            Result = await Post(endpoint, Json);
            if (Result == null)
            {
                return null;
            }
            ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<Pay360PayPalCreateResumePaymentResponse>>(Result);
            return ret;

        }




        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address), Timeout = TimeSpan.FromSeconds(60) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                    {
                        throw new WebException();
                    }

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch
            {
                return null;
            }
        }
    }
}
