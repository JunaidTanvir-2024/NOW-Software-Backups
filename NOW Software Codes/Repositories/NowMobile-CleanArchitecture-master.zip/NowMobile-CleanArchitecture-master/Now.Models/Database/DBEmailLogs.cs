﻿using Now.Models.Enums;

namespace Now.Models.Database;

public class DbEmailLogs
{
    public int Id { get; set; }
    public int SimOrderId { get; set; }
    public SimOrderType SimOrderTypeId { get; set; }
    public EmailsType EmailTypeId { get; set; }
    public bool? IsEmailSent { get; set; }
}
