﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class TransactionbaketitemsResponseModel
    {
        public int id { get; set; }
        public float amount { get; set; }
        public string bundleref { get; set; }
        public string Transactioncurrency { get; set; }
        public string ProductItemCode { get; set; }
        public string Email { get; set; }

    }    }
