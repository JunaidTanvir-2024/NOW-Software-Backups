﻿using Application.Common.Enums;
using Application.Features.AutoTopup.Card;
using Application.Features.AutoTopup.Card.Existing;
using Application.Features.Payment.Card.CustomerCards;
using Application.Features.Payment.Card.ExistingCardPayment;
using Application.Features.Payment.Card.MakeCardDefault;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Card.NewCardPayment;
using Application.Features.Payment.Card.RemoveCard;
using Application.Features.Payment.Card.Resume3d;
using Application.Features.Payment.InAppReceipt;
using Application.Features.Payment.Invoice;
using Application.Features.Payment.Paypal.CreateSale;
using Application.Features.Payment.Paypal.Direct.ExecuteSale;
using Application.Features.Payment.Paypal.Direct.ExecuteSubscription;
using Microsoft.Extensions.Localization;
using NowMobile.Api.Models;

namespace NowMobile.Api.Controllers;

public class PaymentController : VersionedApiController
{
    #region Fields

    private readonly IStringLocalizer<PaymentController> _localizer;

    #endregion

    #region Ctor

    public PaymentController(IStringLocalizer<PaymentController> localizer)
    {
        _localizer = localizer;
    }

    #endregion

    #region Methods

    #region Card Payment

    #region Customer Card Management

    [HttpGet("card"), OpenApiOperation("Get customer payment methods", "")]
    public async Task<IActionResult> GetCustomerCards()
    {
        return Ok(await Mediator.Send(new CustomerCardsRequest()));
    }

    [HttpPost("card/default"), OpenApiOperation("Make customer card as default", "")]
    public async Task<IActionResult> MakeCardDefault([FromBody] MakeCardDefaultRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("card/remove"), OpenApiOperation("Remove customer card", "")]
    public async Task<IActionResult> RemoveCustomerCard([FromBody] RemoveCardRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("card/new"), AllowAnonymous, OpenApiOperation("New card payment", "")]
    public async Task<IActionResult> NewCardPayment([FromBody] NewCardPaymentRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("card/existing"), OpenApiOperation("Existing card payment", "")]
    public async Task<IActionResult> ExistingCardPayment([FromBody] ExistingCardPaymentRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpPost("card/Resume"), AllowAnonymous, OpenApiOperation("Resume3d for card payment", "")]
    public async Task<IActionResult> Resume3d([FromForm] string MD, [FromQuery] int orderId)
    {
        #region Validations

        if (string.IsNullOrEmpty(MD))
        {
            return BadRequest();
        }

        if (orderId < 0)
        {
            return BadRequest();
        }

        #endregion

        var response = await Mediator.Send(new Resume3dRequest() { MD = MD, OrderId = orderId });

        if (response.ErrorCode == 0)
        {
            return View("~/Views/PaymentResponse.cshtml", new PaymentResponseModel()
            {
                IsSuccess = true,
                OrderId = response.Data!.OrderId
            });
        }
        else
        {
            return View("~/Views/PaymentResponse.cshtml", new PaymentResponseModel()
            {
                IsSuccess = false,
                ErrorCode = response.ErrorCode,
                ErrorMessage = response.Message,
                OrderId = orderId
            });
        }
    }

    #endregion

    #endregion

    #region Paypal Payment

    [HttpPost("paypal"), AllowAnonymous, OpenApiOperation("Paypal payment", "")]
    public async Task<IActionResult> PaypalCreateSale([FromBody] PaypalCreateSalePaymentRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpGet("paypal/sale"), AllowAnonymous, OpenApiOperation("Paypal payment execute sale", "")]
    public async Task<IActionResult> PaypalExecuteSale([FromQuery] DirectPaypalExecutePaymentRequest request)
    {
        var response = await Mediator.Send(request);

        if (response.ErrorCode == 0)
        {
            return View("~/Views/PaymentResponse.cshtml", new PaymentResponseModel()
            {
                IsSuccess = true,
                OrderId = response.Data!.OrderId
            });
        }
        else
        {
            return View("~/Views/PaymentResponse.cshtml", new PaymentResponseModel()
            {
                IsSuccess = false,
                ErrorCode = response.ErrorCode,
                ErrorMessage = response.Message
            });
        }
    }

    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpGet("paypal/subscription"), AllowAnonymous, OpenApiOperation("Paypal payment execute sale", "")]
    public async Task<IActionResult> PaypalExecuteSubscription()
    {
        var response = await Mediator.Send(new DirectPaypalExecuteSubscriptionRequest());

        if (response.ErrorCode == 0)
        {
            return View("~/Views/PaymentResponse.cshtml", new PaymentResponseModel()
            {
                IsSuccess = true,
                OrderId = response.Data!.OrderId
            });
        }
        else
        {
            return View("~/Views/PaymentResponse.cshtml", new PaymentResponseModel()
            {
                IsSuccess = false,
                ErrorCode = response.ErrorCode,
                ErrorMessage = response.Message
            });
        }
    }

    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpGet("paypal/cancel"), AllowAnonymous, OpenApiOperation("Paypal payment cancel", "")]
    public IActionResult PaypalCancelSale()
    {
        return View("~/Views/PaymentResponse.cshtml", new PaymentResponseModel()
        {
            IsSuccess = false,
            ErrorCode = CustomStatusCode.PaypalPaymentCancelled,
            ErrorMessage = _localizer[CustomStatusKey.PaypalPaymentCancelled]
        });
    }

    #endregion

    #region Invoice

    [HttpGet("invoice"), AllowAnonymous, OpenApiOperation("Get order details for invoice.", "")]
    public async Task<IActionResult> GetOrderDetails([FromQuery] InvoiceRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    #endregion

    #region InAppPurchase

    [HttpPost("verifyreceipt"), OpenApiOperation("Verify Receipt", "")]
    public async Task<IActionResult> VerifyInAppPurchaseReceipt([FromBody] InAppReceiptRequest request)
    {
        return Ok(await Mediator.Send(request));
    }

    #endregion
    private string? GetIpAddress() =>
    Request.Headers.ContainsKey("X-Forwarded-For")
        ? Request.Headers["X-Forwarded-For"]
        : HttpContext.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "N/A";

   

    #endregion
}