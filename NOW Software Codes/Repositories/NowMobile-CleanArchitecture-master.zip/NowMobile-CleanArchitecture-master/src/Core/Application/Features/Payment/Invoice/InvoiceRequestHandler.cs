using Application.Common.Interfaces.Repositories;
using Application.Common.Settings;
using Application.Features.Payment.Models;
using Domain.Aggregate;
using MapsterMapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Application.Features.Payment.Invoice;

public class InvoiceRequestHandler : IRequestHandler<InvoiceRequest, Result<InvoiceResponse>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<InvoiceRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly CallBackSettings _callbackSettings;

    public InvoiceRequestHandler(
        IUnitOfWork uow,
        IMapper mapper,
        ICommonService commonService,
        IOptions<CallBackSettings> callbackSettings,
        IStringLocalizer<InvoiceRequestHandler> localizer)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
        _commonService = commonService;
        _callbackSettings = callbackSettings.Value;
    }

    public async Task<Result<InvoiceResponse>> Handle(InvoiceRequest request, CancellationToken cancellationToken)
    {
        InvoiceResponse invoiceResponse = new InvoiceResponse();
        var (isSuccess, orderDetails, orderItemDetails) = await _uow.PaymentRepo.GetOrderDetails(request.OrderId);
        if (isSuccess)
        {
              (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();
            invoiceResponse.InvoiceDetails = _mapper.Map<InvoiceDetails>(orderDetails);
            invoiceResponse.InvoiceDetails.PaymentMethodTypeName = _commonService.GetPaymentMethodName(orderDetails.PaymentMethodType);
            invoiceResponse.InvoiceDetails.TransactionTypeName = _commonService.GetTransactionTypeName(orderDetails.TransactionType);

            InvoiceBundleInfo invoiceBundleInfo = new InvoiceBundleInfo();
            InvoiceTopupInfo invoiceTopupInfo = new InvoiceTopupInfo();
            InvoiceSIMInfo invoiceSIMInfo = new InvoiceSIMInfo();
            InvoiceCardInfo invoiceCardInfo = new InvoiceCardInfo();
            foreach (var item in orderItemDetails)
            {
                if (item.BundleId != Guid.Empty && item.BundleId != null)
                {
                    Domain.Entities.Bundle bundleInfo = new Domain.Entities.Bundle();
                    bundleInfo = await _uow.BundleRepo.GetBundleById(Convert.ToString(item.BundleId)!);
                    invoiceBundleInfo.BundleInfo = bundleInfo;
                    invoiceBundleInfo.Amount = item.Amount;
                    invoiceBundleInfo.Discount = item.Discount;
                    invoiceBundleInfo.TotalAmount = item.TotalAmount;
                    invoiceResponse.InvoiceBundleInfo = invoiceBundleInfo;
                }
                if (item.BundleId == null)
                {
                    invoiceTopupInfo.Amount = item.Amount;
                    invoiceTopupInfo.Discount = item.Discount;
                    invoiceTopupInfo.TotalAmount = item.TotalAmount;
                    invoiceResponse.InvoiceTopupInfo = invoiceTopupInfo;
                }
            }
            if (invoiceResponse.InvoiceDetails.TransactionType == (int) TransactionType.SIMWithPlan
                || invoiceResponse.InvoiceDetails.TransactionType == (int) TransactionType.SIMWithCreditandPlan
                || invoiceResponse.InvoiceDetails.TransactionType == (int) TransactionType.SIMWithCredit)
            {
                invoiceSIMInfo.Description = "Free 5G SIM";
                invoiceResponse.InvoiceSIMInfo = invoiceSIMInfo;
            }
            if (!String.IsNullOrEmpty(orderDetails.OrderData))
            {
                var orderData = JsonConvert.DeserializeObject<OrderData>(orderDetails.OrderData!)!;
                if (orderData != null)
                {
                    if (orderDetails.PaymentMethodType == (int) PaymentMethod.Card)
                    {
                        invoiceCardInfo.CardMaskedPan = String.IsNullOrEmpty(orderData.CardMaskedPan)
                            ? "Card Payment" : orderData.CardMaskedPan;
                        invoiceCardInfo.ImageURL = (IsAppRequest ? _callbackSettings.AppBaseUrl!
               : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(orderData.CardScheme!);
                        invoiceResponse.InvoiceCardInfo = invoiceCardInfo;
                    }
                    if (orderData.AutoTopupInfo != null)
                    {
                        if (IsAppRequest)
                        {
                            if (orderData.AutoTopupInfo.Status)
                            {
                                invoiceResponse.InvoiceAutoTopupInfo = new InvoiceAutoTopupInfo
                                {
                                    Amount = orderData.AutoTopupInfo.TopupAmount
                                };
                            }
                        }
                        else
                        {
                            invoiceResponse.InvoiceAutoTopupInfo = new InvoiceAutoTopupInfo
                            {
                                Amount = orderData.AutoTopupInfo.TopupAmount
                            };
                        }

                    }
                }
            }
            else
            {
                if (orderDetails.PaymentMethodType == (int) PaymentMethod.Card)
                {
                    invoiceCardInfo.ImageURL = (IsAppRequest ? _callbackSettings.AppBaseUrl!
               : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(null!);
                    invoiceCardInfo.CardMaskedPan = "Card Payment";
                    invoiceResponse.InvoiceCardInfo = invoiceCardInfo;
                }
            }
        }

        return Result<InvoiceResponse>.Success(invoiceResponse!, _localizer[CustomStatusKey.Success]);
    }
}