﻿using SC.Core.Models.Dtos.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Interfaces.Repositories;
public interface ISystemConfigurationRepository
{
    Task<OrderLimitConfigurationDto> GetOrderLimitConfigurationAsync(string? currency);
}

