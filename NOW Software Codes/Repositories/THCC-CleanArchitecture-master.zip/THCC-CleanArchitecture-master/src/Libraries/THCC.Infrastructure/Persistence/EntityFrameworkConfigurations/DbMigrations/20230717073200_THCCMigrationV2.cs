﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace THCC.Infrastructure.Persistence.EntityFrameworkConfigurations.DbMigrations
{
    /// <inheritdoc />
    public partial class THCCMigrationV2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedDateTime",
                table: "Users",
                type: "datetime",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreatedDateTime",
                table: "Users");
        }
    }
}
