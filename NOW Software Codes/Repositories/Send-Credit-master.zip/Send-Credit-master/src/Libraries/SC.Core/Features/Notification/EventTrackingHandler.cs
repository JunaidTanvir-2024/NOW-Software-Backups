﻿using Microsoft.AspNetCore.Http;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.Notification.Request;
using SC.Core.Vendors.Notification;
using System.Text.Json;
using Microsoft.Extensions.Options;
using System;
using System.Net;
using SC.Infrastructure.Vendors.EventTracking;
using System.Threading.Tasks;

namespace SC.Core.Features.Notification;
internal sealed class EventTrackingHandler : IRequestHandler<EventTrackingRequest, bool>
{
    private readonly IEventTrackingService _eventTrackingService;
    private readonly ICommonService _commonService;
    public EventTrackingHandler(IEventTrackingService eventTrackingService, IHttpContextAccessor httpContextAccessor, ICommonService commonService)
    {
        _eventTrackingService = eventTrackingService;
        _commonService = commonService;

    }
    public async Task<bool> Handle(EventTrackingRequest request, CancellationToken cancellationToken)
    {
        bool result = false;

        request.ClientIp = _commonService.GetIpAddress();
        request.UserAgent = _commonService.GetUserAgent();

        if (request.PlatForm == "GA4")
        {
            await HandleGA4(request);
        }
        if (request.PlatForm == "FB")
        {
            await HandleFB(request);
        }
        if (request.PlatForm == "AirShip")
        {
            await HandleAirShip(request);
        }
        if (request.PlatForm == "All")
        {
            await HandleAll(request);
        }

        return result;
    }
    private async Task HandleGA4(EventTrackingRequest request)
    {
        request.EventDetail = CreateGA4EventRequest(request);
        var response = await _eventTrackingService.TrackGA4Event(request);

    }
    private async Task HandleFB(EventTrackingRequest request)
    {
        request.EventDetail = CreateFacebookEventRequest(request);
        var response = await _eventTrackingService.TrackFBEvent(request);
    }
    private async Task HandleAirShip(EventTrackingRequest request)
    {
        request.EventDetail = CreateAirShipEventRequest(request);
        var response = await _eventTrackingService.TrackAirShipEvent(request);

    }
    private async Task HandleAll(EventTrackingRequest request)
    {
        var tasks = new Task[]
        {
            HandleGA4(request),
            HandleFB(request),
            HandleAirShip(request)
        };
        Task.WaitAll(tasks);
    }
    private string CreateFacebookEventRequest(EventTrackingRequest request)
    {
        var payload = new
        {
            data = new[]
            {
                new
                {
                    event_name =request.EventName,
                    event_time = DateTimeOffset.Now.ToUnixTimeSeconds(),
                    user_data = new
                    {
                        client_ip_address = request.ClientIp,
                       client_user_agent=request.UserAgent,
                       external_id=request.ClientId
                    },
                    custom_data = new
                    {
                        currency = request.EventCurrency,
                        value = request.EventValue
                    }
                }
            }
        };
        return JsonSerializer.Serialize(payload);
    }
    private string CreateGA4EventRequest(EventTrackingRequest request)
    {
        var payloadRequest = new
        {
            client_id = request.ClientId,
            events = new[]
            {
                new
                {
                    name = request.EventName,
                    @params = new
                    {
                        value = request.EventValue,
                        currency = request.EventCurrency
                    }
                }
            }
        };
        return JsonSerializer.Serialize(payloadRequest);
    }
    private string CreateAirShipEventRequest(EventTrackingRequest request)
    {
        return default;
    }


}

