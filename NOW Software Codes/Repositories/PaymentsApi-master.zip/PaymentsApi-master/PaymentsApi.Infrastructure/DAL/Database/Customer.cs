﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public partial class Customer
    {
        public Customer()
        {
            Pay360Transaction = new HashSet<Pay360Transaction>();
        }

        public int Id { get; set; }
        public string DisplayName { get; set; }
        public string MerchantRef { get; set; }
        public string ProductCode { get; set; }
        public long Pay360CustId { get; set; }
        public string Email { get; set; }
        public string Msisdn { get; set; }
        public string DefaultCurrency { get; set; }
        public DateTime? Dob { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string AddressLine4 { get; set; }
        public string City { get; set; }
        public string Region { get; set; }
        public string PostCode { get; set; }
        public string Country { get; set; }
        public string CountryCode { get; set; }
        public string Telephone { get; set; }
        public string DefaultCardCV2 { get; set; }
        public string EncryptionKey { get; set; }
        public double ThresholdBalanceAmount { get; set; }
        public bool IsAutoTopup { get; set; }

        public ICollection<Pay360Transaction> Pay360Transaction { get; set; }
    }
}
