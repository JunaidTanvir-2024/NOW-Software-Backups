using NTCB.Api.Commons.Wrappers.Db;
using NTCB.Api.Features.DTOne;

using PConnect.Core.Commons.Helpers.Logger;

using Serilog;


StaticLoggerHelper.EnsureInitialized();
Log.Information($"Servicely Server Booting Up...");
try
{
    var builder = WebApplication.CreateBuilder(args);
    {
        //// Serilog Configurations
        builder.Host.UseSerilog((hostingContext, config) => config.ReadFrom.Configuration(hostingContext.Configuration));
        ConfigureServices(builder);
    }

    var app = builder.Build();
    {
        ConfigureMiddlewares(app);
        app.Run();
    }

    #region Configure Services
    static void ConfigureServices(WebApplicationBuilder builder)
    {
        builder.Services.AddControllers();
        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();
        builder.Services.AddScoped<IDTOneService, DTOneService>();
        builder.Services.AddScoped<IDTOneRepository, DTOneRepository>();
        DapperWrapper.SetConfiguration(builder.Configuration, builder.Environment.IsProduction());
    }
    #endregion


    #region Configure Middlewares
    static void ConfigureMiddlewares(WebApplication app)
    {
        // Configure the HTTP request pipeline.
        //if (app.Environment.IsDevelopment())
        //{
        app.UseSwagger();
        app.UseSwaggerUI();
        //}

        //app.UseHttpsRedirection();

        //app.UseAuthorization();

        app.MapControllers();
    }
    #endregion
}
catch (Exception ex) when (!ex.GetType().Name.Equals("StopTheHostException", StringComparison.Ordinal))
{
    StaticLoggerHelper.EnsureInitialized();
    Log.Error(ex, "Servicely Server Shutting down...");
    Log.Fatal(ex, "Unhandled exception");
    throw;
}
finally
{
    StaticLoggerHelper.EnsureInitialized();
    Log.Error("Servicely Server Shutting down...");
    Log.CloseAndFlush();
}