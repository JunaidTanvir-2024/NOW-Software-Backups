﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Configurations
{
    public class SmsConfig
    {
        public string PoppayoutsApiEndPoint { get; set; }
        public string XeebiApiEndPoint { get; set; }
        public bool UsePoppayout { get; set; }
        public bool UseXeebi { get; set; }
    }
}
