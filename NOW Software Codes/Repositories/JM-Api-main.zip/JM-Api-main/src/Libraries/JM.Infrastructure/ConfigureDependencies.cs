using System.Reflection;

using FluentMigrator.Runner;

using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using JM.Infrastructure.Services.Versioning;
using JM.Infrastructure.Services.OpenApi;
using JM.Core.Utilities.Definitions;
using JM.Infrastructure.Common.Middlewares;
using JM.Infrastructure.Persistence;
using JM.Infrastructure.Services.Identity;
using JM.Infrastructure.Persistence.Migrations;
using JM.Infrastructure.Services.Jwt;
using JM.Infrastructure.Services.Mailing;
using JM.Infrastructure.Services.Otp;
using JM.Infrastructure.Vendors.Google.Common;

namespace JM.Infrastructure;

public static class ConfigureDependencies
{
	public static IServiceCollection AddInfrastructureDependencies(this IServiceCollection services, IConfiguration configuration)
	{
		services.AddOtpConfiguration(configuration);
		services.AddSmtpConfiguration(configuration);
		services.RegisterJsonSettings(configuration);
		services.AddDistributedMemoryCache();
		services.RegisterBuiltInServices();
		services.AddAppContextConfigurations(configuration);
		services.AddFluentMigrator(configuration);
		services.AddApiVersioningConfiguration();
		services.AddOpenApiConfiguration(configuration);
		services.AddJwtConfiguration(configuration);
		services.AddGoogleConfiguration(configuration);
		return services;
	}

	private static IServiceCollection AddFluentMigrator(this IServiceCollection services, IConfiguration configuration)
	{
		return services.AddFluentMigratorCore()
					 .ConfigureRunner(c => c.AddPostgres()
					 .WithGlobalConnectionString(configuration.GetConnectionString(AppConstant.Database.JourneyMingle))
					 .ScanIn(Assembly.GetExecutingAssembly()));
	}

	private static IServiceCollection RegisterBuiltInServices(this IServiceCollection services)
	{
		services.AddHttpClient();
		services.AddHttpContextAccessor();
		return services;
	}

	private static IServiceCollection RegisterJsonSettings(this IServiceCollection services, IConfiguration configuration)
	{
		services.Configure<IdentitySetting>(configuration.GetSection(IdentitySetting.SectionName));
		return services;
	}

	public static IApplicationBuilder UseInfrastructureMiddlewares(this IApplicationBuilder app, IConfiguration configuration)
	{
		DatabaseSchema.Migrate(app.ApplicationServices, configuration);
		app.UseAppExceptionMiddleware();
		app.UseOpenApiConfiguration();
		app.UseSecurityHeadersMiddleware();
		app.UseAppLoggingMiddleware();
		return app;
	}
}
