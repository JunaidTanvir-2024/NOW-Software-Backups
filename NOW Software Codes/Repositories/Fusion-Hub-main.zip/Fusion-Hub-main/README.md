# FusionHub

FusionHub is an innovative project designed to seamlessly integrate a variety of third-party services into a unified platform, simplifying access and enabling effortless distribution through a single, user-friendly API interface

## Table of Contents

- [FusionHub](#fusionhub)
  - [Table of Contents](#table-of-contents)
  - [Tech Stack Info](#tech-stack-info)
  - [Architecture](#architecture)
  - [Libraries \& Packages](#libraries--packages)
  - [Generating Encryption Keys](#generating-encryption-keys)
  - [Setup and Configuration](#setup-and-configuration)
  - [Coding Practices for Fusion-Hub Code Quality](#coding-practices-for-fusion-hub-code-quality)
          - [Last Updated: (02-10-2023)](#last-updated-02-10-2023)
  - [Naming Conventions](#naming-conventions)
  - [Emoji Usage Guide](#emoji-usage-guide)


## Tech Stack Info

- **Framework**: ASP.NET Core
- **Version**: .NET 8.0.100-rc.1

## Architecture

FusionHub adheres to the clean architecture pattern, employing a feature-based approach to implementation.

## Libraries & Packages

FusionHub utilizes the following libraries.

- **Fluent Validation** ([Nuget](https://www.nuget.org/packages/FluentValidation))
- **Serilog** ([Nuget](https://www.nuget.org/packages/Serilog))
- **JwtBearer** ([Nuget](https://www.nuget.org/packages/Microsoft.AspNetCore.Authentication.JwtBearer))
- **OpenApi** ([Nuget](https://www.nuget.org/packages/Microsoft.AspNetCore.OpenApi))
- **ResultWrapper** ([Nuget](https://www.nuget.org/packages/RW))

## Generating Encryption Keys
Install OpenSSL to your system, and then use these commands to generate public and private keys. I am using ECDSA algorthim.

`openssl ecparam -name prime256v1 -genkey -noout -out ec-private-key.pem`
`openssl ec -in ec-private-key.pem -pubout -out ec-public-key.pem`
`cat ec-private-key.pem`
`cat ec-public-key.pem`

## Setup and Configuration

Setting up and configuring FusionHub is a breeze! Just follow these simple steps:

1. Clone the repository from Nowtel GitHub Repo: `git clone https://github.com/nowtel/FusionHub.git`.
2. Ensure you have the .NET 8.0.100-rc.1 SDK installed. If not, no worries! You can easily obtain it by visiting [Download .NET 8 SDK](https://dotnet.microsoft.com/download).
3. Open the project in your preferred Integrated Development Environment (IDE) such as Visual Studio or Visual Studio Code.
4. Build the project with a single command: `dotnet build`.
5. Run the project using the command: `dotnet run`. 
6. Congratulations! FusionHub is now up and running, accessible at the specified URL.


## Coding Practices for Fusion-Hub Code Quality 
###### Last Updated: (02-10-2023)

Here are coding practices for maintaining code quality in Fusion-Hub:

1. **Remove Unused Code and namspaces**
   - Always clean up your codebase by removing unused using statements and unnecessary code.

2. **Null Checking**
   - Perform null checks where applicable to prevent Null Reference Exceptions during runtime.

3. **Follow Naming Conventions**
   - Adhere to naming conventions consistently throughout your codebase.
   - Follow these naming conventions [Naming Conventions](#naming-conventions)

1. **Code Reusability**
   - Extract reusable methods and create generic functions to avoid code duplication.

2. **Code Consistency**
   - Use var instead of explict type to maintain consistency.

3. **Code Readability**
   - Write code that is easy for other developers to understand.

4. **Dispose of Unmanaged Resources**
   - Properly manage unmanaged resources, such as file I/O and network resources, using using blocks.

5. **Exception Handling and Logging**
   - Implement robust exception handling using try/catch/finally blocks and log exceptions for debugging purposes.

6.  **Method Length**
    - Keep methods concise, generally not exceeding 30-40 lines of code.

7.  **Avoid Nesting**
    - Minimize nested loops and conditional statements to improve code readability.


11. **Unit Testing**
    - Write developer test cases and perform unit testing to catch basic issues before QA testing.

12. **Access Specifiers**
    - Choose access specifiers (e.g., private, public, internal) according to the required scope.

13. **Interfaces**
    - Implement interfaces and depedency injection to decouple components and promote low coupling.

14. **Class Modifiers**
    - Mark classes as sealed, static, or abstract based on their intended usage.
    - By default every class should be sealed

15. **Stringbuilder Usage**
    - Use StringBuilder for efficient string concatenation to reduce memory overhead.

16. **Remove Unreachable Code**
    - Identify and eliminate unreachable code segments.

17. **Method Comments**
    - Add comments to describe the purpose, input types, and return types of methods.

18. **Performance Monitoring**
    - Utilize tools like Fiddler to analyze HTTP/network traffic and measure web application and service performance.

19. **Constants and Readonly**
    - Use constants and readonly keywords for values that should not change.

20. **Minimize Type Casting**
    - Avoid unnecessary type casting and conversions to improve performance.

21. **Memory Leak Detection**
    - Regularly check for memory leaks in your code and fix any identified issues.

22. **Security**
    - Implement security measures to prevent cross-scripting attacks, SQL injection, and other vulnerabilities.

23. **Avoid Default Keyword**
    - Refrain from using the 'default' keyword for known types (e.g., int, decimal) unless dealing with generic types.

24. **Avoid 'out' and 'ref' Keywords**
    - Minimize the use of 'out' and 'ref' keywords, following Microsoft's guidelines for code analysis.

## Naming Conventions
- **Solution Name**: Pascal Case
- **Project Name**: Pascal Case
- **Folder Name**: Pascal Case
- **Namespace Name**: Pascal Case
- **Class Name**: Pascal Case(use PascalCasing for abbreviations 3 characters or more, use Noun or Noun Phrase for name, e.g., Employee, BusinessLocation)
- **Property Name**: Pascal Case
- **Private Class Variable Injectable**: `_camelCase`
- **Function Name**: Pascal Case
- **Method Arguments**: Camel Case
- **Use of Enums in the right way**
- **Avoid direct string comparison; use enum for that**
- **Do not use underscore in identifiers**
    -**Correct**: `DateTime clientAppointment;`
    -**Avoid**: `DateTime client_Appointment;`

- **Local Variables**: Camel Case
    -**Correct**: `int counter;`
    -**Avoid**: `int iCounter;`

- **Use implicit type `var` for local variable declarations**
    - **Example**: 
```csharp
				var stream = File.Create(path);
				var customers = new Dictionary();
```
- **Use the letter "I" for interface name prefix**
```csharp
		public interface IShape{}
```
- **Organize namespaces with a clearly defined structure**
    -- Use filescoped namespace instead of blocked namespace.
	  -**Correct**: `namespace Company.Product.Module.SubModule;`
    -**Avoid**: `namespace Company.Product.Module.SubModule {}`
		
- **Code should be properly indented**
- 
## Emoji Usage Guide

To add a touch of visual representation and enhance communication, we encourage the use of Unicode emojis in commit messages. Here are some suggested emojis for different scenarios:

- New Application Release:
  - 🎉 Party Popper: Celebrates the release of a new version.
  - 🚀 Rocket: Signifies the launch of a new application.

- New Feature Added to the Application:
  - ✨ Sparkles: Represents newly added feature.
  - 🆕 New: Indicates something new and exciting.
  - 💡 Light Bulb: Symbolizes a bright new idea or innovation.

- Bug Fix:
  - 🐛 Bug: Represents fixing a software bug.
  - 🛠️ Hammer and Wrench: Symbolizes making repairs and improvements.
  - ✅ Checkmark: Indicates that an issue has been resolved.

- Item of Newly Added Features:
  - ➕ Plus Sign: Represents the addition of a new feature.
  - 📋 Memo: Symbolizes a summary, note or documentation about a new feature.
  - 👉 Point Right: Indicates list item.

- Notification:
  - 🔔 Bell: Represents a notification or alert.
  - 📢 Loudspeaker: Symbolizes broadcasting or notifying important information.
  - 💬 Speech Bubble: Indicates a message or announcement.

- Appreciating a New Collaborator:
  - 👏 Clapping Hands: Represents appreciation and applause.
  - 🤝 Handshake: Symbolizes collaboration and partnership.
  - 🌟 Star: Indicates recognition and appreciation for a new collaborator.

Feel free to use these emojis in your commit messages, README, and other communication to add a touch of fun and clarity to your project.
