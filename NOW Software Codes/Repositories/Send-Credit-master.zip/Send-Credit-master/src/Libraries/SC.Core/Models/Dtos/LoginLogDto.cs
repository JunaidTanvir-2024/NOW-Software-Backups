﻿namespace SC.Core.Models.Dtos;
public record LoginLogDto
{
    public string UserID { get; init; }
    public DateTimeOffset LoginTime { get; init; }
    public DateTimeOffset LoginOutTime { get; init; }
    public string? DeviceInfo { get; init; }
    public string? Refresh_Token { get; init; } = default!;
    public DateTime? Refresh_Token_Expiry { get; init; } = default!;
    public bool IsSuccessLogin { get; set; } = default!;
}
