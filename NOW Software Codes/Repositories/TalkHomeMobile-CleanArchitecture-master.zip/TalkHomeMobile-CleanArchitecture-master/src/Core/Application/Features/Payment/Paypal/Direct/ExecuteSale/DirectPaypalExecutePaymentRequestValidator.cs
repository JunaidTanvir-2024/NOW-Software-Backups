﻿namespace Application.Features.Payment.Paypal.Direct.ExecuteSale;
public class DirectPaypalExecutePaymentRequestValidator : AbstractValidator<DirectPaypalExecutePaymentRequest>
{
    public DirectPaypalExecutePaymentRequestValidator()
    {
        RuleFor(p => p.CustomerUniqueRef).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.OrderId).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.PayerId).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.PaymentId).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
    }
}
