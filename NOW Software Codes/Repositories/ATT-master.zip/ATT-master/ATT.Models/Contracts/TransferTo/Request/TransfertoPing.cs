﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Request
{
    public class TransfertoPing : TransfertoBaseRequest
    {
        public string action = "ping";

        public string toXML()
        {
            return "<TransferTo>" + base.toXML() + $"<action>{action}</action></TransferTo>";
        }
    }
}
