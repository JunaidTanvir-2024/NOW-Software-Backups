﻿using Models.Contracts.Request;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface IATTService
    {
        Task<AirtimeTransferExecute> TransferBalance(TransFerTotransferConfirm request, string fromMsisdn);
        Task<AirtimeTransferProducts> GetProductsAsync(string account, string destination, string clientMSISDN);
    }
}