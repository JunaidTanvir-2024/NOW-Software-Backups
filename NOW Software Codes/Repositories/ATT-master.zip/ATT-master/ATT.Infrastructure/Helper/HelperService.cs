﻿using PhoneNumbers;

namespace ATT.Infrastructure.Helper
{
    public static class HelperService
    {    
        public static string GetCountryISOCode(string msisdn)
        {
            var phoneUtil = PhoneNumberUtil.GetInstance();
            
            if (!msisdn.StartsWith("+"))
                msisdn = "+" + msisdn;
            // phone must begin with '+'
            PhoneNumber numberProto = phoneUtil.Parse(msisdn, "");
            int countryCode = numberProto.CountryCode;
            string recipientIso = phoneUtil.GetRegionCodeForCountryCode(countryCode);
            return recipientIso;
        }
    }
}
