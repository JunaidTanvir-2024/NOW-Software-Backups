using FluentValidation;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Customers.Requests;

public class UpdateCustomerRequest
{
    public string SourceId { get; set; } = null!;

    //public string? Name { get; set; }

    //public string? Email { get; set; }

    //public string? Description { get; set; }

    //public string? Phone { get; set; }

    //public Address? Address { get; set; }

    public Metadata? Metadata { get; set; }
}
internal class UpdateCustomerRequestValidator : AbstractValidator<UpdateCustomerRequest>
{
    public UpdateCustomerRequestValidator()
    {
        RuleFor(p => p.SourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.SourceId = phoneNumber);
    }
}
