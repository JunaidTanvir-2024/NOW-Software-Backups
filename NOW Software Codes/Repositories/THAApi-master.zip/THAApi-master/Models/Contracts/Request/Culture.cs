﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class Culture
    {
        public string Name { get; set; }
        public string EnglishName { get; set; }
        public string DisplayName { get; set; }
        public string NativeName { get; set; }
        public string TwoLetterISORegionName { get; set; }
        public string ThreeLetterISORegionName { get; set; }
        public string ThreeLetterWindowsRegionName { get; set; }
        public string IsMetric { get; set; }
        public string GeoId { get; set; }
        public string CurrencyEnglishName { get; set; }
        public string CurrencyNativeName { get; set; }
        public string CurrencySymbol { get; set; }
        public string ISOCurrencySymbol { get; set; }
    }
}
