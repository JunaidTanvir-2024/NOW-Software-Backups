﻿using CallingCode.Mvc.Common.Enums;
using CallingCode.Mvc.Common.Extensions;
using CallingCode.Mvc.Common.Models;
using System;
using System.Text.Json;

namespace CallingCode.Mvc.Common.Services.OpenMeteo;

public interface IOpenMeteoImplementation
{
    Task<CountryBundleInfoModel?> GetBundleDetails(string formCountryCode, string toCountryCode);
    Task<CountryTimeZone?> GetCountryTimeDetail(double capitalLatitude, double capitalLongitude);
    Task<DateTimeOffset> GetVisitorTime(string visitorIp);
    Task<WeatherForecastModel?> GetWeatherDetail(double latitude, double longitude, bool currentWeather = true, string hourly = "temperature_2m,relativehumidity_2m,windspeed_10m");
}

public class OpenMeteoImplementation : IOpenMeteoImplementation
{
    private readonly string _weatherApiUrl = "https://api.open-meteo.com/v1/forecast";
    private readonly string _timeApi = "https://www.timeapi.io/api";
    private readonly string _talkHomeApi = "https://app.talkhome.co.uk";
    private readonly IHttpClientFactory _httpClientFactory;

    public OpenMeteoImplementation(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
    }

    public async Task<WeatherForecastModel?> GetWeatherDetail(double latitude, double longitude, bool currentWeather = true, string hourly = "temperature_2m,relativehumidity_2m,windspeed_10m")
    {

        var httpClient = _httpClientFactory.CreateClient();

        try
        {
            var endpointWithQueryParams = $"{_weatherApiUrl}?latitude={latitude}&longitude={longitude}&current_weather={currentWeather}&hourly={hourly}&timezone=auto";
            var response = await httpClient.GetAsync(endpointWithQueryParams);
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var result = await response.Content.ReadFromJsonAsync<WeatherForecastModel>();
            if (result?.CurrentWeather != null)
            {
                result.CurrentWeather.CurrentCondition = WmoCodes.WeatherCodeMap[result.CurrentWeather.Weathercode];
            }

            return result;
        }
        catch
        {
            return null;
        }
    }

    public async Task<CountryTimeZone?> GetCountryTimeDetail(double capitalLatitude, double capitalLongitude)
    {

        var httpClient = _httpClientFactory.CreateClient();

        try
        {
            var endpointWithQueryParams = $"{_timeApi}/Time/current/coordinate?latitude={capitalLatitude}&longitude={capitalLongitude}";
            var response = await httpClient.GetAsync(endpointWithQueryParams);
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var result = await response.Content.ReadFromJsonAsync<CountryTimeZone>();
            if (result != null)
            {
                result.Date = DateTimeHelpers.FormateDate(result.Date);
                result.Time = result.DateTime.ToString("h:mm:ss tt");
                result.InDst = await CheckCountryInDstOrNot(result.TimeZone);
            }
            return result;
        }
        catch
        {
            return null;
        }
    }


    public async Task<string> CheckCountryInDstOrNot(string? timezone)
    {
        if (string.IsNullOrEmpty(timezone))
        {
            return "Not In DST";
        }

        var httpClient = _httpClientFactory.CreateClient();

        try
        {
            var endpointWithQueryParams = $"{_timeApi}/TimeZone/zone?timeZone={timezone}";
            var response = await httpClient.GetAsync(endpointWithQueryParams);
            if (!response.IsSuccessStatusCode)
            {
                return "Not In DST";
            }

            var result = await response.Content.ReadFromJsonAsync<DSTCountry>();
            if (result?.HasDayLightSaving == true && result.IsDayLightSavingActive == true)
            {
                return "In DST";
            }
            else
            {
                return "Not In DST";
            }
        }
        catch
        {
            return "Not In DST";
        }
    }


    public async Task<CountryBundleInfoModel?> GetBundleDetails(string formCountryCode, string toCountryCode)
    {
        var httpClient = _httpClientFactory.CreateClient();
        var endpointWithQueryParams = $"{_talkHomeApi}/getcountrybundleinfo?fromcountryCode={formCountryCode}&toCountryCode={toCountryCode}";
        try
        {
            var result = await httpClient.GetFromJsonAsync<CountryBundleInfoModel>(endpointWithQueryParams);
            return result;
        }
        catch (Exception)
        {
            return null;
        }
    }
    public async Task<DateTimeOffset> GetVisitorTime(string visitorIp)
    {
        var httpClient = _httpClientFactory.CreateClient();
        var endpointWithQueryParams = $"{_timeApi}/Time/current/ip?ipAddress={visitorIp}";
        var response = await httpClient.GetAsync(endpointWithQueryParams);
        if (!response.IsSuccessStatusCode)
        {
            return DateTime.UtcNow;
        }

        var result = await response.Content.ReadFromJsonAsync<CountryTimeZone>();
        return result.DateTime;
    }
}
