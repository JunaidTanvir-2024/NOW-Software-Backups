﻿namespace SC.Infrastructure.Common.Settings;
public sealed class DefaultRegionSetting
{
    public const string SectionName = nameof(DefaultRegionSetting);
    public static DefaultRegionSetting Instance { get; } = new DefaultRegionSetting();
    public string RegionName { get; set; } = default!;
    public string Country { get; set; } = default!;
    public string Currency { get; set; } = default!;
    public string[] ValidCurrencies { get; set; } = default!;

}

