﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ViewModels
{
    public class RatesViewModel
    {
        public int Id { get; set; }
        public string Destination { get; set; }
        public double Landline_rate { get; set; }
        public double Mobile_rate { get; set; }
        public double Landline_TotalMins5GBP { get; set; }
        public double Mobile_TotalMins5GBP { get; set; }
        public double Landline_TotalMins10GBP { get; set; }
        public double Mobile_TotalMins10GBP { get; set; }
        public double Landline_TotalMins20GBP { get; set; }
        public double Mobile_TotalMins20GBP { get; set; }
    }
}
