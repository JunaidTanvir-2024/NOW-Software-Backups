﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.OpenApi.Models;

using Swashbuckle.AspNetCore.SwaggerGen;

namespace THCC.Api.Filters
{
    public class SwaggerGlobalAuthFilter : IOperationFilter
    {
        private readonly string _name;

        public SwaggerGlobalAuthFilter()
            : this(JwtBearerDefaults.AuthenticationScheme)
        {
        }

        public SwaggerGlobalAuthFilter(string name)
        {
            _name = name;
        }

        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (HasAllowAnonymousAttribute(context))
            {
                return;
            }

            if (operation.Security == null)
            {
                operation.Security = new List<OpenApiSecurityRequirement>();
            }

            var securityScheme = new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = _name
                }
            };

            var securityRequirement = new OpenApiSecurityRequirement
            {
                [securityScheme] = Array.Empty<string>()
            };

            operation.Security.Add(securityRequirement);
        }

        private static bool HasAllowAnonymousAttribute(OperationFilterContext context)
        {
            var actionDescriptor = context.ApiDescription.ActionDescriptor;
            return actionDescriptor?.EndpointMetadata.Any(em => em is AllowAnonymousAttribute) == true;
        }
    }
}
