using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.BundleDetail;

public sealed class BundleByIdRequest : IRequest<Result<BundleInfo>>
{
    public string Id { get; set; } = default!;
}