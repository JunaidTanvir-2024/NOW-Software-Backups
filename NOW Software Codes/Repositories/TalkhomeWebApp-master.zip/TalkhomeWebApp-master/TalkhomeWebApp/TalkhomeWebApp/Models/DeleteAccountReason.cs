﻿namespace TalkhomeWebApp.Models
{
    public class DeleteAccountReason
    {
        public int Id { get; set; } 
        public string Reason { get; set;}
    }
}
