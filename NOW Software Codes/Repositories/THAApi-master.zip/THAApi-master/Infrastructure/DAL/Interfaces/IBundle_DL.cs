﻿using Models.Contracts.Request;
using System.Collections.Generic;
using System.Threading.Tasks;
using Models.Contracts.Response;
using Models.Contracts.Request.Rate;
using Models.Database;
using System;
using Models.Contracts.Request.Digitalk;
using Models.Contracts.Request.Bundle;
using Models.Contracts.Request.CountryDestination;
using Models.Enums;

namespace Infrastructure.DAL.Interfaces
{
	public interface IBundle_DL
    {
        Task<IEnumerable<OfferBundleDetails>> GetOfferBundlesInfo(List<string> ids);
        Task<Bundles> GetBundleById(string Id, string account);
        Task<bool> IsOfferBundle(string id);
        Task<ValidateResponse> SetBundleAutoRenewal(bool isAutoRenew, string Msisdn, string account, string bundleId, bool isTrial = false);
        Task<ValidateResponse> SetBundleAutoRenewalV2(bool isAutoRenew, string Msisdn, string account, string bundleId, bool isTrial, PaymentMethods paymentMethod, string cardMaskedPAN, string cardInitialTransactionId, string paypalSubscriptionId);
		Task<(int, string)> OfferBundleValidation(string accountId, string bundleId);
        Task<IEnumerable<BundleDetailsDB>> GetBundleDetailsByIds(List<string> ids);
        Task<DataBundleRecord> GetDataBundleRecord(string nowtelReference, int productId);
        Task<IEnumerable<Bundle>> GetCompatibleBundlesViaSQL(int na_service_id, string account);
        Task<IEnumerable<Bundle>> GetCompatibleBundlesViaSQLV2(int na_service_id, string account);
        Task<IEnumerable<RateRev>> GetCountryRates(int na_service_id, int id);
        Task<IEnumerable<Bundle>> GetAccountDigitalkBundlesViaSQL(string account);
        Task<StandardResponse> AddDigitalkBundlesViaSQL(string account, string bundleid);
        Task<IEnumerable<DigitalkBundle>> GetAccountDigitalkBundles(string msisdn);
        Task<IEnumerable<TopDestinationBundleDetails>> GetuserTopBundles(int na_service_id, string msisdn);
        Task<bool> GetDispayOffPeak(string msisdn, int na_service);
        Task<IEnumerable<RateRev>> GetCountryRatesWithBudle(int na_service_id);
        Task<bool> AnyActiveAutoBundleRenwal(string account);
        Task<IEnumerable<RateRev>> GetCountryRatesWithBudle(int na_service_id, string msisdn);
        Task SaveBundlePurchaseData(bool isSuccess, string bundleName, string bundleRef, float bundleAmount, string accountId, string errorMessage);
        Task<bool> IsBundlePurchasedPreviously(string account, string bundleId);
        Task<bool> MonthlyBundleValidationAfterTrialExpire(string account, string msisdn, string bundleId, string trialBundleId);
    }
}
