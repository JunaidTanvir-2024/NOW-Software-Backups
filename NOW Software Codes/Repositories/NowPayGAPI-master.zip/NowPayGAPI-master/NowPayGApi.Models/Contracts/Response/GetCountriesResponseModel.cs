﻿using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetCountriesResponseModel
    {
        public IEnumerable<DBCountry> Countries { get; set; }
    }
}
