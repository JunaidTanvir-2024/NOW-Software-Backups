using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MM.Infrastructure.Common.Settings;
public sealed class MailSettings
{
    public const string SectionName = "MailSettings";
    public static MailSettings Bind = new MailSettings();
    public bool IsActive { get; set; }
    public string? Host { get; set; }
    public string? UserName { get; set; }
    public string? Password { get; set; }
    //public string? From { get; set; }
    public bool EnableSSL { get; set; }
    public int Port { get; set; }
    public bool IsMailFromBackgroundService { get; set; }
    public string? AlternateHost { get; set; }
    public string? AlternateHostUserName { get; set; }
    public string? DisplayName { get; set; }
    public string? AlternateHostPassword { get; set; }
    public int AlternatePort { get; set; }
    public string[]? AlternateHostDomains { get; set; }
    public MailFrom MailFrom { get; set; }
}
public sealed class MailFrom
{
    public string THM { get; set; }
    public string SC { get; set; }
    public string THA { get; set; }
}
