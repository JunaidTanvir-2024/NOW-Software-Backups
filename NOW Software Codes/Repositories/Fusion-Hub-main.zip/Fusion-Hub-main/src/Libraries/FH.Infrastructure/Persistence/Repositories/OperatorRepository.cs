using System.Data;

using Dapper;

using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Entities;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;

using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

using Serilog;
namespace FH.Infrastructure.Persistence.Repositories;
internal sealed class OperatorRepository(IConfiguration configuration, ILogger logger) : IOperatorRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private readonly ILogger _logger = logger;

    public async Task<IEnumerable<VendorOperatorEntity>> VendorOperatorBulkUpsert(IEnumerable<VendorOperatorEntity> operatorDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("name", typeof(string));
                table.Columns.Add("logo", typeof(string));
                table.Columns.Add("operator_id", typeof(long));
                table.Columns.Add("vendor_operator_code", typeof(string));
                table.Columns.Add("country_id", typeof(long));
                foreach (var op in operatorDto)
                {
                    table.Rows.Add(op.Name, op.Logo, op.OperatorId, op.VendorOperatorCode, op.CountryId);
                }
                var parameters = new DynamicParameters();
                parameters.Add("operator_data", table.AsTableValuedParameter(AppConstants.Database.TableType.VendorOperator));
                return await connection.QueryAsync<VendorOperatorEntity>(AppConstants.Database.StoreProcedure.VendorOperatorBulkInsert, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OperatorRepository), nameof(VendorOperatorBulkUpsert));
            return default!;
        }
    }
    public async Task<IEnumerable<OperatorEntity>> OperatorBulkUpsert(IEnumerable<OperatorEntity> operatorDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("name", typeof(string));
                table.Columns.Add("logo", typeof(string));
                table.Columns.Add("description", typeof(string));
                table.Columns.Add("country_id", typeof(long));
                foreach (var op in operatorDto)
                {
                    table.Rows.Add(op.Name, op.Logo, op.Description, op.CountryId);
                }
                var parameters = new DynamicParameters();
                parameters.Add("operator_data", table.AsTableValuedParameter(AppConstants.Database.TableType.Operator));
                return await connection.QueryAsync<OperatorEntity>(AppConstants.Database.StoreProcedure.OperatorsBulkInsert, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OperatorRepository), nameof(OperatorBulkUpsert));
            return default!;
        }
    }
    public async Task<(IEnumerable<OperatorDto.Response> operators, DatabasePaginationDto pagination)> GetOperators(OperatorDto.Request operatorsRequest)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("operator_name", typeof(string));
                table.Columns.Add("country_iso_code", typeof(string));
                table.Rows.Add(operatorsRequest?.OperatorFilters?.OperatorName, operatorsRequest?.OperatorFilters?.CountryIsoCode);

                var OperatorParameters = new DynamicParameters();

                OperatorParameters.Add("OperatorFilters", value: table.AsTableValuedParameter(AppConstants.Database.TableType.OperatorFilter));
                OperatorParameters.Add("is_active", operatorsRequest?.IsActive);
                OperatorParameters.Add("is_deleted", operatorsRequest?.IsDeleted);
                OperatorParameters.Add("page", operatorsRequest?.Page);
                OperatorParameters.Add("records_per_page", operatorsRequest?.RecordsPerPage);
                OperatorParameters.Add("total_records", 0, direction: ParameterDirection.Output);
                OperatorParameters.Add("total_pages", 0, direction: ParameterDirection.Output);
                var operators = await connection.QueryAsync<OperatorDto.Response>(AppConstants.Database.StoreProcedure.OperatorsGet, OperatorParameters, commandType: CommandType.StoredProcedure);

                // Read the output parameters
                var totalRecords = OperatorParameters.Get<int>("total_records");
                var totalPages = OperatorParameters.Get<int>("total_pages");
                return (operators, new DatabasePaginationDto() { TotalPages = totalPages, TotalRecords = totalRecords });
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OperatorRepository), methodName: nameof(GetOperators));
            return default!;
        }
    }
    public async Task<IEnumerable<OperatorDto.Response>> GetOperatorByName(OperatorByNameDto.Request operatorDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var OperatorParameters = new DynamicParameters();
                OperatorParameters.Add("is_active", operatorDto.IsActive);
                OperatorParameters.Add("is_deleted", operatorDto.IsDeleted);
                OperatorParameters.Add("operator_name", operatorDto.OperatorName);
                var operatorRecord = await connection.QueryAsync<OperatorDto.Response>(AppConstants.Database.StoreProcedure.OperatorByNameGet, OperatorParameters, commandType: CommandType.StoredProcedure);
                return (operatorRecord);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OperatorRepository), methodName: nameof(GetOperatorByName));
            return default!;
        }
    }
    public async Task<OperatorByVendorCodeDto.Response?> GetOperatorByVendorCode(OperatorByVendorCodeDto.Request request)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var OperatorParameters = new DynamicParameters();
                OperatorParameters.Add("vendor_code", request.VendorCode);

                var operatorRecord = await connection.QueryFirstOrDefaultAsync<OperatorByVendorCodeDto.Response>(AppConstants.Database.StoreProcedure.OperatorByVendorCodeGet, OperatorParameters, commandType: CommandType.StoredProcedure);

                return (operatorRecord);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OperatorRepository), methodName: nameof(GetOperatorByName));
            return default!;
        }
    }

    public async Task UpdateOperatorsAliases(IEnumerable<OperatorAliasDto.Request> operatorAliasDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("operator_id", typeof(long));
                table.Columns.Add("name_alias", typeof(string));
                table.Columns.Add("description", typeof(string));


                foreach (var item in operatorAliasDto)
                {
                    table.Rows.Add(item.OperatorId, item.OperatorNameAlias, item.OperatorDescription);
                }

                var operatorParameters = new DynamicParameters();
                operatorParameters.Add("operators", table.AsTableValuedParameter(AppConstants.Database.TableType.OperatorAliasType));

                await connection.ExecuteAsync(AppConstants.Database.StoreProcedure.OperatorAliasesUpdate, operatorParameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(ProductRepository), nameof(UpdateOperatorsAliases));
        }
    }

    public async Task<(IEnumerable<OperatorByProductCategoryDto.Response> operators, DatabasePaginationDto pagination)> GetOperatorByProductCategory(OperatorByProductCategoryDto.Request operatorDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var OperatorParameters = new DynamicParameters();
                OperatorParameters.Add("is_active", operatorDto.IsActive);
                OperatorParameters.Add("is_deleted", operatorDto.IsDeleted);
                OperatorParameters.Add("countryIsoCode2", operatorDto.OperatorFilters?.CountryIsoCode);
                OperatorParameters.Add("currencyCode", operatorDto.OperatorFilters?.CurrencyCode);
                OperatorParameters.Add("category_alias_name", operatorDto.OperatorFilters?.CategoryAliasName);

                OperatorParameters.Add("page", operatorDto.Page);
                OperatorParameters.Add("records_per_page", operatorDto.RecordsPerPage);

                OperatorParameters.Add("total_pages", 0, direction: ParameterDirection.Output);
                OperatorParameters.Add("total_records", 0, direction: ParameterDirection.Output);
                var response = await connection.QueryAsync<OperatorByProductCategoryDto.Response>(AppConstants.Database.StoreProcedure.OperatoryByProductCategoryGet, OperatorParameters, commandType: CommandType.StoredProcedure);

                // Read the output parameters
                var totalRecords = OperatorParameters.Get<int>("total_records");
                var totalPages = OperatorParameters.Get<int>("total_pages");
                return (response, new DatabasePaginationDto() { TotalPages = totalPages, TotalRecords = totalRecords });

            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OperatorRepository), methodName: nameof(GetOperatorByName));
            return default!;
        }
    }

    public async Task<IEnumerable<OperatorBySubCategoryDto.Response>> GetOperatorBySubCategory(OperatorBySubCategoryDto.Request request)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {

                var OperatorParameters = new DynamicParameters();

                OperatorParameters.Add("is_active", request?.IsActive);
                OperatorParameters.Add("is_deleted", request?.IsDeleted);
                OperatorParameters.Add("countryIsoCode2", request?.CountryIsoCode);
                OperatorParameters.Add("currencyCode", request?.CurrencyCode);
                OperatorParameters.Add("product_category_alias_name", request?.ProductCategoryAliasName);
                OperatorParameters.Add("product_sub_category_alias_name", request?.ProductSubCategoryAliasName);
                OperatorParameters.Add("limit", request?.Limit);
           
                var operators = await connection.QueryAsync<OperatorBySubCategoryDto.Response>(AppConstants.Database.StoreProcedure.OperatoryBySubCategoryGet, OperatorParameters, commandType: CommandType.StoredProcedure);
                return operators;
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(OperatorRepository), methodName: nameof(GetOperatorBySubCategory));
            return default!;
        }
    }

}
