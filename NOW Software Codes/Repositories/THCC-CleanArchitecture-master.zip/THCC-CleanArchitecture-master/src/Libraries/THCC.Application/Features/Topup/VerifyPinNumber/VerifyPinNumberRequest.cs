﻿namespace THCC.Application.Features.Topup.VerifyPinNumber
{
    public class VerifyPinNumberRequest : IRequest<object>
    {
        public string Pin { get; set; } = default!;
    }
    public class VerifyPinRequestValidator : AbstractValidator<VerifyPinNumberRequest>
    {
        public VerifyPinRequestValidator()
        {
            RuleFor(data => data.Pin)
                .NotNull()
                .NotEmpty()
                .MaximumLength(20).WithMessage("Your pin length must not exceed 20.")
                .WithMessage("Invalid pin");
        }
    }
}
