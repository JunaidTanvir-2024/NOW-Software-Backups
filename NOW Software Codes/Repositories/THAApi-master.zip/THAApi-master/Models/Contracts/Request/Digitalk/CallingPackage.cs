﻿namespace Models.Contracts.Request.Digitalk
{
	public class CallingPackage
	{
		public string AllowancePeriodLength { get; set; }
		public string AllowancePeriodType { get; set; }
		public string AllowanceRecurrence { get; set; }
		public string BrandedName { get; set; }
		public bool ChargeAtEndOfPeriod { get; set; }
		public string ChargePeriodLength { get; set; }
		public string ChargePeriodType { get; set; }
		public string ChargeRecurrence { get; set; }
		public CommonAllowance CommonAllowance { get; set; }
		public string Description { get; set; }
		public string FullType { get; set; }
		public GPRSAllowance GPRSAllowance { get; set; }
		public string InitialCharge { get; set; }
		public MMSAllowance MMSAllowance { get; set; }
		public object PIC { get; set; }
		public string PackageCategory { get; set; }
		public string PackageId { get; set; }
		public string PackageName { get; set; }
		public string PackageType { get; set; }
		public string RecurringCharge { get; set; }
		public SMSAllowance SMSAllowance { get; set; }
		public string ServiceType { get; set; }
		public string SubscriptionCharge { get; set; }
		public VoiceAllowance VoiceAllowance { get; set; }
	}
}