﻿using FluentValidation;

namespace Voucherify.Api.Features.Vouchers.Requests;

public class UdpateVoucherRequest
{
}
internal class UdpateVoucherRequestValidator : AbstractValidator<UdpateVoucherRequest>
{
    public UdpateVoucherRequestValidator()
    {
    }
}