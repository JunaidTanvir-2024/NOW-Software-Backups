﻿namespace THCC.Domain.Entities
{
    public class UserProduct
    {
        public long Id { get; set; }
        public string UserId { get; set; } = default!;
        public string Product { get; set; } = default!;
        public DateTime CreatedDateTime { get; set; }
        public bool IsActive { get; set; }
    }
}
