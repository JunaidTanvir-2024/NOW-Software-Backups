﻿using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.AutoTopup.GetAutoTopup;

public class GetAutoTopupRequestHandler : IRequestHandler<GetAutoTopupRequest, Result<AutoTopupResponse>>
{
    private readonly IStringLocalizer<GetAutoTopupRequestHandler> _localizer;
    private readonly ITopupRepository _topupRepo;
    private readonly ICurrentUser _currentUser;
    private readonly IUserService _userService;
    private readonly TopupSettings _topupSettings;

    public GetAutoTopupRequestHandler(
        IStringLocalizer<GetAutoTopupRequestHandler> localizer,
        ITopupRepository topupRepo,
        ICurrentUser currentUser,
        IUserService userService,
        IOptions<TopupSettings> topupSettings)
    {
        _localizer = localizer;
        _topupRepo = topupRepo;
        _currentUser = currentUser;
        _userService = userService;
        _topupSettings = topupSettings.Value;
    }

    public async Task<Result<AutoTopupResponse>> Handle(GetAutoTopupRequest request, CancellationToken cancellationToken)
    {
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<AutoTopupResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var autoTopup = await _topupRepo.GetAutoTopup(request.Msisdn, _currentUser.GetUserEmail()!);
        if (autoTopup == null)
        {
            return Result<AutoTopupResponse>.Failure(null!, _localizer[CustomStatusKey.GetAutoTopupFailure], CustomStatusCode.InternalServerError);
        }
        var response = new AutoTopupResponse();
        if (autoTopup == null)
        {
            response = new AutoTopupResponse()
            {
                AutoTopup = new AutoTopupInfo
                {
                    Status = false,
                    ThresHoldAmount = 1,
                    TopupAmount = 5,
                },
                AutoTopupThresholdAmounts = _topupSettings.AutoTopupThresholdAmounts,
                TopUpAmounts = _topupSettings.TopUpAmounts
            };
           
        }
        else
        {

            response = new AutoTopupResponse()
            {
                AutoTopup = new AutoTopupInfo
                {
                    Status = autoTopup.Status,
                    ThresHoldAmount = autoTopup.ThresHold,
                    PaymentMethod = autoTopup.PaymentMethod,
                    TopupAmount = autoTopup.Topup,
                    CardPanMasked = autoTopup.MaskedPan,
                },
                AutoTopupThresholdAmounts = _topupSettings.AutoTopupThresholdAmounts,
                TopUpAmounts = _topupSettings.TopUpAmounts
            };
        }
       
        return Result<AutoTopupResponse>.Success(response, _localizer[CustomStatusKey.Success]);
    }
}