﻿using Microsoft.AspNetCore.Mvc;
using SenderService.API.Controllers.Common;
using SenderService.Core.Common;
using System.Net;
using SenderService.Core.Features.Domain;
using SenderService.Core.Features.Domain.Request;
using SenderService.Core.Features.Domain.Response;

namespace SenderService.API.Controllers;

public class DomainController : BaseApiController
{
    private readonly IBlockedDomainService _blockedDomainService;

    public DomainController(IBlockedDomainService blockedDomainService)
    {
        _blockedDomainService = blockedDomainService;
    }

    [HttpPost]
    public async Task<ActionResult> AddBlockedDomain(AddBlockedDomainRequest request)
    {
        var blockedDomainAdded = await _blockedDomainService.AddBlockedDomainAsync(request);
        if (blockedDomainAdded > 0)
        {
            return CreatedAtAction(nameof(GetBlockedDomainByName), routeValues: blockedDomainAdded, value: ApiResult<long>.Success(successCode: (int) HttpStatusCode.Created, data: blockedDomainAdded));
        }
        else
        {
            return BadRequest(ApiResult<BlockedDomainResponse>.Failure());
        }
    }
    [HttpGet]
    public async Task<ActionResult> GetBlockedDomains()
    {
        var blockedDomains = await _blockedDomainService.GetBlockedDomainsAsync();
        if (blockedDomains.Any())
        {
            return Ok(ApiResult<IEnumerable<BlockedDomainResponse>>.Success(data: blockedDomains));
        }
        else
        {
            return NotFound(ApiResult<IEnumerable<BlockedDomainResponse>>.Failure(message: "There is no blocked domain found",errorCode: (int) HttpStatusCode.NotFound));
        }
    }
    [HttpGet("Name")]
    public async Task<ActionResult> GetBlockedDomainByName([FromQuery] GetDomainByNameRequest request)
    {
        var blockedDomain = await _blockedDomainService.GetBlockedDomainByNameAsync(request);
        if (blockedDomain != null)
        {
            return Ok(ApiResult<BlockedDomainResponse>.Success(data: blockedDomain));
        }
        else
        {
            return NotFound(ApiResult<BlockedDomainResponse>.Failure("No record found for this domain", errorCode: (int) HttpStatusCode.NotFound));
        }
    }
}
