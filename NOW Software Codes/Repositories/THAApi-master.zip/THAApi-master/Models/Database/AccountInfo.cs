﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    public class AccountInfo
    {
        public string pin { get; set; }
        //public string na_service_id { get; set; }
        public string currency { get; set; }
        //public string account { get; set; }
        
    }
}
