using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DC.Core.Common.Definitions;
using DC.Core.Common.Extensions;
using DC.Core.Common.Interfaces.Database;
using DC.Core.Features.HangFire;
using DC.Core.Features.Notifications.Requests;

using Hangfire;

using Microsoft.AspNetCore.Http;

using Serilog;

namespace DC.Core.Features.HangFire;

public class InitiateHangFireJobHandler : IRequestHandler<InitiateHangFireJobRequest, IResultWrapper>
{
    private readonly IRecurringJobManager _recurringJobManager;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IConfiguration? _configuration;
    private readonly IMediator _mediator;
    private readonly ILogger _logger;
    public InitiateHangFireJobHandler(IRecurringJobManager recurringJobManager, IMediator mediator, IHttpContextAccessor httpContextAccessor, IConfiguration configuration, ILogger logger)
    {
        _recurringJobManager = recurringJobManager;
        _httpContextAccessor = httpContextAccessor;
        _configuration = configuration;
        _mediator = mediator;
        _logger = logger;

    }

    public async Task<IResultWrapper> Handle(InitiateHangFireJobRequest request, CancellationToken cancellationToken)
    {
        try
        {
            if (request == null)
            {
                return await HandleError("Invalid Request");
            }

            _recurringJobManager.AddOrUpdate("Get New Registered SMS", () => GetNewMSISDN(), "*/5 * * * *");
            _recurringJobManager.AddOrUpdate("SendActivationMSISDN", () => SendActivationMsisdn(), "3/5 * * * *");
            _recurringJobManager.AddOrUpdate("SendTopUpMessage", () => SendTopUpMessage(), "4/5 * * * *");
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(InitiateHangFireJobHandler), nameof(InitiateHangFireJobHandler));
        }
        return default;
    }
    public async Task GetNewMSISDN()
    {
        try
        {
            var requestM = new NewRegisteredMsisdnRequest();
            await _mediator.Send(requestM);
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(InitiateHangFireJobHandler), nameof(InitiateHangFireJobHandler));
        }
    }
    public async Task SendActivationMsisdn()
    {
        try
        {
            var requestM = new SendActivationSmsRequest();
            await _mediator.Send(requestM);
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(InitiateHangFireJobHandler), nameof(InitiateHangFireJobHandler));
        }
    }
    public async Task SendTopUpMessage()
    {
        try
        {
            var requestM = new SendTopUpSmsRequest();
            await _mediator.Send(requestM);
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(InitiateHangFireJobHandler), nameof(InitiateHangFireJobHandler));
        }
    }
    private async Task<IResultWrapper> HandleError(string errorMsg)
    {
        return ResultWrapper.Failure(errorMsg);
    }
}


