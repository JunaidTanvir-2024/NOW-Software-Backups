namespace THCC.Application.Settings;

public sealed class MailSettings
{
    public const string SectionName = nameof(MailSettings);
    public static MailSettings Bind = new MailSettings();
    public bool IsActive { get; set; }

    public string EmailServiceBaseUrl { get; set; } = default!;
    public bool SendMailFromExternalService { get; set; } = default!;
    public bool RequireEmailValidation { get; set; } = default!;

    public string? Host { get; set; }
    public string? UserName { get; set; }
    public string? Password { get; set; }
    public int Port { get; set; }

    public string? AlternateHost { get; set; }
    public string? AlternateHostUserName { get; set; }
    public string? AlternateHostPassword { get; set; }
    public int AlternatePort { get; set; }
    public string[]? AlternateHostDomains { get; set; }

    public MailSettingsData ForgotPassword { get; set; } = default!;
    public MailSettingsData SignUpSuccess { get; set; } = default!;
    public MailSettingsData Redeem { get; set; } = default!;
    public MailSettingsData ContactUs { get; set; } = default!;
    public MailSettingsData ChangePasswordSuccess { get; set; } = default!;
    public MailSettingsData VerifyEmail { get; set; } = default!;
    public MailSettingsData THRCCPurchase { get; set; } = default!;
    public MailSettingsData THRCCRecharge { get; set; } = default!;
    public MailSettingsData THRCCFastRecharge { get; set; } = default!;
    public MailSettingsData THCCPurchase { get; set; } = default!;
    public MailSettingsData RedeemPoints { get; set; } = default!;
}

public sealed class MailSettingsData
{
    public const string SectionName = nameof(MailSettingsData);
    public static MailSettingsData Bind = new MailSettingsData();
    public string? From { get; set; }
    public string? DisplayName { get; set; }
    public string? Subject { get; set; }
    public bool SendEmail { get; set; }
}