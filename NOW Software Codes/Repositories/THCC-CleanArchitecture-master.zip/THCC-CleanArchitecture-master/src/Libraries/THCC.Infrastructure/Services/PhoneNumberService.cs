﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;

using PhoneNumbers;

using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;

using static System.Runtime.InteropServices.JavaScript.JSType;

namespace THCC.Infrastructure.Services
{
    /// <summary>
    /// Gets the full and validated phone number 
    /// </summary>
    public class PhoneNumberService : IPhoneNumberService
    {
        private readonly PhoneNumberUtil _phoneNumberUtil;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="phoneNumberUtil">Instance of PhoneNumberUtil</param>
        public PhoneNumberService(PhoneNumberUtil phoneNumberUtil)
        {
            _phoneNumberUtil = phoneNumberUtil;
        }

        /// <summary>
        /// Gets the region from a phone number
        /// </summary>
        /// <param name="originator">Phone number, this must be in E164 format</param>
        /// <returns>Country Code</returns>
        public async Task<CountryDto?> GetCountry(string msisdn)
        {
            string configurationsDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Configurations");
            var countriesList = JsonConvert.DeserializeObject<List<CountryDetailsDto>>(
                await File.ReadAllTextAsync(configurationsDirectory + "/countries.json"));
            try
            {
                msisdn = msisdn.Trim();

                msisdn = msisdn.Replace("+", "");
                msisdn = msisdn.StartsWith("00") ? msisdn.Remove(0, 2) : msisdn;

                if (!msisdn.StartsWith("+"))
                {
                    msisdn = $"+{msisdn}";
                }

                if (msisdn.StartsWith("+1"))
                {
                    string? countryCode = null;
                    string[] countries = { "US", "CA" };
                    System.String phoneNumber = msisdn;
                    foreach (var c in countries)
                    {
                        bool isValid = _phoneNumberUtil.IsPossibleNumber(phoneNumber, c);
                        if (isValid)
                        {
                            try
                            {
                                var number = _phoneNumberUtil.Parse(phoneNumber, c);
                                isValid = _phoneNumberUtil.IsValidNumberForRegion(number, c);
                                if (isValid)
                                {
                                    countryCode = c;
                                }
                            }
                            catch (Exception)
                            {
                                countryCode = null;
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(countryCode))
                    {
                        return new CountryDto()
                        {
                            Name = countriesList!.Find(
                            x => x.IsoTwoCharacterCode!.Equals(countryCode))?.Name,
                            IsoTwoCharacterCode = countryCode
                        };
                    }
                    else
                    {
                        var number = _phoneNumberUtil.Parse(msisdn, "");
                        countryCode = _phoneNumberUtil.GetRegionCodeForCountryCode(number.CountryCode);
                        return new CountryDto()
                        {
                            Name = countriesList!.Find(
                            x => x.IsoTwoCharacterCode!.Equals(countryCode))?.Name,
                            IsoTwoCharacterCode = countryCode
                        };
                    }
                }
                else
                {
                    var number = _phoneNumberUtil.Parse(msisdn, "");
                    var countryCode = _phoneNumberUtil.GetRegionCodeForCountryCode(number.CountryCode);
                    return new CountryDto()
                    {
                        Name = countriesList!.Find(
                        x => x.IsoTwoCharacterCode!.Equals(countryCode))?.Name,
                        IsoTwoCharacterCode = countryCode
                    };
                }
            }
            catch (NumberParseException)
            {
                return null;
            }
        }
    }
}