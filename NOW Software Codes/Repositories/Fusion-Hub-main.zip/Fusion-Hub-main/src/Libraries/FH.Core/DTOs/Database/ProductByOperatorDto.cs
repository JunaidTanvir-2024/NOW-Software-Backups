namespace FH.Core.DTOs.Database;

public sealed record ProductByOperatorDto
{
    public sealed record Request
    {
        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public bool IsActive { get; set; } = true;
        public bool IsDeleted { get; set; } = false;
        public decimal? Price { get; set; }
        public string? CountryIsoCode { get; set; }
        public string? CurrencyCode { get; set; }
        public string? Category { get; set; }
        public string? SubCategory { get; set; }
        public string? Operator { get; set; }

    }

    public sealed record Response
    {
        public long ProductId { get; set; }
        public string? ProductName { get; set; }
        public string? ProductAliasName { get; set; }
        public string? Description { get; set; }
        public bool? ProductType { get; set; }

        // ProductOperatorInfo
        public string? OperatorName { get; set; }
        public string? OperatorAliasName { get; set; }
        public string? OperatorShortCode { get; set; }
        public string? OperatorDescription { get; set; }

        // ProductCountryInfo
        public string? CountryName { get; set; }
        public string? CountryIsoCode2 { get; set; }
        public string? CountryIsoCode3 { get; set; }
        public string? Continent { get; set; }
        public string? CallingCode { get; set; }

        //ProductVendorInfo
        public string? VendorProductCode { get; set; }
        public string? VendorOperatorCode { get; set; }
        public string? Logo { get; set; }

        //ProductPriceInfo
        public decimal? Price { get; set; }
        public decimal? range_min_price { get; set; }

    }
}
