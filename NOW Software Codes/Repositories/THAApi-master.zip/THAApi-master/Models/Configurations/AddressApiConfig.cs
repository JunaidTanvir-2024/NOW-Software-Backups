﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    
    public class AddressApiConfig
    {
        public string ApiEndpoint { get; set; }
        public string ApiKey { get; set; }
    }
}
