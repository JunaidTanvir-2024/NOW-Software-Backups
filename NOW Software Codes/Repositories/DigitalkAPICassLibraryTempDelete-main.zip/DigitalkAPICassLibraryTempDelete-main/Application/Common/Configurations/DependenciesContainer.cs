﻿using Application.Common.Constants;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

namespace Application.Common.Configurations;

public static class DependenciesContainer
{
    public static IHostBuilder AddJsonFilesConfigurations(this IHostBuilder host)
    {
        host.ConfigureAppConfiguration((context, config) =>
        {
            var env = context.HostingEnvironment;
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string configurationsDirectory = Path.Combine(baseDirectory, JsonFiles.FolderName);

            config.AddJsonFile($"{JsonFiles.AppSettings}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{JsonFiles.AppSettings}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                 .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Logger}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Logger}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Database}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Database}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
               .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Common}.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"{configurationsDirectory}/{JsonFiles.Common}.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                 .AddEnvironmentVariables();
        });
        return host;
    }
}