﻿using System.Collections.Generic;

namespace Models.Configurations
{
	public class HslSmsConfig
	{
		public const string SectionName = "SmsApi";
		public string sms_sap_local_uri { get; set; }
		public Dictionary<string,string> CountryBaseSenders { get; set; }
	}
}
