﻿

using SC.Core.Features.Countries.Requests;
using SC.Core.Vendors.FusionHub;

namespace SC.Core.Features.Countries;
internal sealed class GetCountyAndOperatorInfoHandler : IRequestHandler<GetCountyAndOperatorInfoRequest, IResultWrapper>
{
    private readonly IFusionHubService _fusionHubService;
    public GetCountyAndOperatorInfoHandler(IFusionHubService fusionHubService)
    {
        _fusionHubService = fusionHubService;
    }

    public async Task<IResultWrapper> Handle(GetCountyAndOperatorInfoRequest request, CancellationToken cancellationToken)
    {
        var response = await _fusionHubService.GetCountryAndOperatorInfoAsync(request);
        if (response.Payload == null)
        {
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
        }
        return ResultWrapper.Success(response);
    }
}

