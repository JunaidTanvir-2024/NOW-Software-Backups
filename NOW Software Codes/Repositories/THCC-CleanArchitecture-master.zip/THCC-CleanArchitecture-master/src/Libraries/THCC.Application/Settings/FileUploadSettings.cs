namespace THCC.Application.Settings;

public class FileUploadSettings
{
    public const string SectionName = "FileUploadSettings";
    public static FileUploadSettings Bind = new FileUploadSettings();
    public List<string> SupportedExtensions { get; set; } = new List<string>();
    public long FileSizeInBytes { get; set; }
}