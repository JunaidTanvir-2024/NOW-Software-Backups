
using JM.Api.Controllers.Common;
using JM.Core.Features.Country;
using JM.Core.Utilities.Definitions;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using RW.Common;
using RW.Failures;
using RW.Models;
using RW.Successes;

namespace JM.Api.Controllers.V1;

public sealed class CountryController : V1ApiController
{
    [HttpGet]
    [AllowAnonymous]
    [ProducesResponseType<SuccessPayload<IEnumerable<CountryList.Response>>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    public async Task<ActionResult> Country()
    {
        var result = await Mediator.Send(new CountryList.Query(), HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpGet("id")]
    [ProducesResponseType<SuccessPayload<GetCountry.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    [AllowAnonymous]
    public async Task<ActionResult> GetCountry([FromQuery] GetCountry.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
}
