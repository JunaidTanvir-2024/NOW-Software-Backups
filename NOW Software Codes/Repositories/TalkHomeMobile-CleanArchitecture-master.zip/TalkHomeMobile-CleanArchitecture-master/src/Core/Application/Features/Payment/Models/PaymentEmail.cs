﻿
using Application.Features.AutoTopup;
using Application.Features.Bundle.Model;

namespace Application.Features.Payment.Models;

public class PaymentEmail
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? CustomerEmail { get; set; }
    public string? CustomerMsisdn { get; set; }
    public string TimeStamp { get; set; } = default!;
    public PaymentMethod PaymentMethod { get; set; }
    public float Discount { get; set; }
    public float TotalAmount { get; set; }
}

public class TopupPaymentEmail : PaymentEmail
{
    public float CustomerBalance { get; set; }
    public TransactionType TransactionType { get; set; }
}

public class BundlePaymentEmail : PaymentEmail
{
    public string BundleName { get; set; } = default!;
    public string Data { get; set; } = default!;
    public string Min { get; set; } = default!;
    public string Sms { get; set; } = default!;
}

public class CreditSimPaymentEmail : PaymentEmail
{
    public string? TransactionId { get; set; }
    public float TopupAmount { get; set; }
    public AutoTopupInfo? AutoTopupOrderInfo { get; set; }

    public OrderBundleInfo? OrderBundleInfo { get; set; }
    public BundleInfo? BundleInfo { get; set; }
}