﻿using Application.Features.AutoTopup;

namespace Application.Common.Interfaces;

public interface IAutoTopupService : ISerivcesType.ITransientService
{
    Task<AutoTopupInfo> GetAutoTopUp(string msisdn, string email);
    Task<bool> SetAutoTopUp(string msisdn, string email, float thresholdAmount, float topupAmount, bool isActive);
}
