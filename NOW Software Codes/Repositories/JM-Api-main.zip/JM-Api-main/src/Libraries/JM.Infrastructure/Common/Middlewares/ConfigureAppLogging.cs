using System.Diagnostics;
using System.Text;
using System.Text.Json;

using JM.Core.Entities;
using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Helpers;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;

namespace JM.Infrastructure.Common.Middlewares;

internal sealed class ConfigureAppLogging
{
    internal sealed class Middleware(RequestDelegate next, IGlobalHelper globalHelper)
    {
        private const int BUFFER_SIZE = 4096;
        private readonly IGlobalHelper _globalHelper = globalHelper;

        public async Task Invoke(HttpContext context, IUnitOfWork unitOfWork)
        {
            var stopwatch = Stopwatch.StartNew();
            ModifyRequest(context);
            var responseBody = string.Empty;
            var originalRequestBody = context.Request.Body;
            var originalResponseBody = context.Response.Body;
            var requestBody = await ReadRequestBody(context.Request);
            var responseStream = new MemoryStream();
            context.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(requestBody));
            context.Response.Body = responseStream;
            try
            {
                await next(context); // Continue Request Processing
                responseStream.Seek(0, SeekOrigin.Begin);
                responseBody = await ReadResponseBody(context, originalResponseBody, responseStream);
                await UpsertAppLogs(context, stopwatch, requestBody, responseBody, unitOfWork);
                await ResetRequestBodyStream(context, originalRequestBody, originalResponseBody, responseStream);
            }
            catch (Exception ex)
            {
                await UpsertAppLogs(context, stopwatch, requestBody, responseBody, unitOfWork, ex.StackTrace?.ToString());
                throw; // Re-throw the exception to allow proper error handling by Global Exception middleware
            }
        }

        private void ModifyRequest(HttpContext context)
        {
            var requestReference = _globalHelper.GetRequestReference();
            var productReference = _globalHelper.GetProductReference();
            context.Request.Headers.Append(AppConstant.Headers.ProductReference, productReference);
            context.Items[AppConstant.Headers.ProductReference] = productReference;
            context.Items[AppConstant.Headers.RequestReference] = requestReference;
        }

        private async Task UpsertAppLogs(HttpContext context, Stopwatch stopwatch, string requestBody, string? responseBody, IUnitOfWork unitOfWork, string? errorReason = default!)
        {
            var logEntry = new AppLog()
            {
                RequestPath = context.Request.GetDisplayUrl(),
                RequestMethod = context.Request.Method,
                RequestBody = ClientRequest(context, requestBody),
                ResponseBody = responseBody ?? null!,
                StatusCode = IsStartupRequest(context!) ? 200 : context.Response.StatusCode,
                ProcessDuration = stopwatch.ElapsedMilliseconds,
                ClientIp = context?.Connection.RemoteIpAddress?.ToString()!,
                UserAgent = context?.Request.Headers.UserAgent!,
                ErrorReason = errorReason,
                RequestHeaders = SerializeHeaders(context?.Request.Headers),
                RequestReference = IsStartupRequest(context!) ? "x-startup-request" : _globalHelper.GetRequestReference()!,
                ProductReference = IsStartupRequest(context!) ? "x-startup-code" : _globalHelper.GetProductReference()!,
                RequestTimestamp = DateTime.UtcNow,
            };

            await unitOfWork.LoggerRepository.AppLogUpsert(logEntry);
            unitOfWork.SaveChanges();
        }

        private static string ClientRequest(HttpContext context, string requestBody)
        {
            return JsonSerializer.Serialize(new { Body = requestBody ?? null, Query = Convert.ToString(context.Request.QueryString) ?? null });
        }

        private static async Task<string> ReadRequestBody(HttpRequest request)
        {
            request.EnableBuffering();
            var body = request.Body;
            using var memoryStream = new MemoryStream();
            await body.CopyToAsync(memoryStream);
            memoryStream.Seek(0, SeekOrigin.Begin);

            using var reader = new StreamReader(memoryStream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true, bufferSize: BUFFER_SIZE, leaveOpen: true);
            var requestBody = await reader.ReadToEndAsync();
            request.Body.Seek(0, SeekOrigin.Begin);
            return requestBody;
        }

        private static async Task<string> ReadResponseBody(HttpContext context, Stream originalResponseBody, MemoryStream responseStream)
        {
            string responseBody = await new StreamReader(responseStream).ReadToEndAsync();
            responseStream.Seek(0, SeekOrigin.Begin);
            context.Response.Body = originalResponseBody;
            return responseBody;
        }

        private static async Task ResetRequestBodyStream(HttpContext context, Stream originalRequestBody, Stream originalResponseBody, MemoryStream responseStream)
        {
            context.Request.Body = originalRequestBody;
            context.Response.Body = originalResponseBody;
            responseStream.Seek(0, SeekOrigin.Begin);
            await responseStream.CopyToAsync(originalResponseBody);
        }

        private static string SerializeHeaders(IHeaderDictionary? headers)
        {
            if (headers is null)
            {
                return string.Empty;
            }
            var serializedHeaders = new Dictionary<string, string>();
            foreach (var header in headers)
            {
                serializedHeaders[header.Key] = header.Value.ToString();
            }
            return JsonSerializer.Serialize(serializedHeaders);
        }
    }
    private static bool IsStartupRequest(HttpContext context)
    {
        return !context.Request.Path.StartsWithSegments("/api") && context.Request.Method != "POST";
    }
}
