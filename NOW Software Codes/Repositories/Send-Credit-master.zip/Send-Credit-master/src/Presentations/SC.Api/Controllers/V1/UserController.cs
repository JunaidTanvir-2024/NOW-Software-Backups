﻿using MassTransit.Internals.GraphValidation;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;

using SC.Api.Model.Account;
using SC.Core.Common.DTOs;
using SC.Core.Common.Helpers;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.MigrateGuestProfile;
using SC.Core.Features.Notification.Request;
using SC.Core.Features.Products;
using SC.Core.Features.Users.Responses;
using SC.Core.Interfaces.Repositories;
using SC.Core.Vendors.Notification.Response;

using Sentry;

using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

namespace SC.Api.Controllers.V1;

[ApiVersion(1.0, Deprecated = true)]
public class UserController : BaseApiController
{
    private readonly UserManager<IdentityUser> _userManager;
    private readonly SignInManager<IdentityUser> _signInManager;
    private readonly IUserRepository _userRepository;
    private readonly Serilog.ILogger _logger;
    private readonly ICommonService _commonService;
    private readonly IConfiguration _configuration;

    public UserController(Serilog.ILogger logger, UserManager<IdentityUser> userManager,
                                      SignInManager<IdentityUser> signInManager,
                                      IUserRepository userRepository,
                                      ICommonService commonService,
                                      IConfiguration configuration)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        this._userRepository = userRepository;
        _logger = logger;
        _commonService = commonService;
        _configuration = configuration;
    }

    [HttpPost("SignUp"), AllowAnonymous]
    public async Task<IActionResult> SignUp(SignUpModel Request)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            Request.Email = Request.Email.Trim();
            Request.Password = Request.Password.Trim();
            string EmailCode = string.Empty;
            if (!AppHelpers.IsValidEmail(Request.Email))
                return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Conflict, AppConstants.StatusKeys.InvalidEmailFormat));
            var newuser = new IdentityUser
            {
                PhoneNumber = Request.PhoneNumber,
                Email = Request.Email,
                UserName = Request.Email,
                AccessFailedCount = 0,
                TwoFactorEnabled = true,
            };
            string _tokenpurpose = "EmailConfirmation" + DateTime.Now.ToString();
            var userStatus = AppEnums.UserStatusEnum.AccountCreated.Getkey();

            IdentityResult? result = await _userManager.CreateAsync(newuser, Request.Password);
            if (result.Succeeded)
            {
                var usercreated = await _userManager.FindByEmailAsync(Request.Email);
                if (usercreated != null)
                {
                    EmailCode = await _userManager.GenerateUserTokenAsync(usercreated, TokenOptions.DefaultPhoneProvider, _tokenpurpose);
                    var paramsTemplate = new Dictionary<string, string>()
                    {
                        { "{123456}" , EmailCode  },
                        { "{F_NAME}" , Request.Email  },
                    };
                    await SendNotification(Request.Email, AppConstants.StatusKeys.EmailSubject, AppConstants.EmailTemplates.SignUpOtp, paramsTemplate);

                    await Mediator.Send(new UpdateUserRequest() { UserID = usercreated.Id, UserStatus = userStatus, UserToken = EmailCode, TokenPurpose = _tokenpurpose, UserType = Request.UserType });// user status updated
                }
                return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Success, $"Your Send Credit verification code  sent on email {usercreated.Email}"));
            }
            else
            {
                // In case Email already exist in system but Email code not verified, then send new code
                var ExistingUser = await _userManager.FindByEmailAsync(Request.Email);
                if (ExistingUser != null && ExistingUser.EmailConfirmed == false)
                {
                    EmailCode = await _userManager.GenerateUserTokenAsync(ExistingUser, TokenOptions.DefaultPhoneProvider, _tokenpurpose);

                    var paramsTemplate = new Dictionary<string, string>()
                    {
                        { "{123456}" , EmailCode  },
                        { "{F_NAME}" , Request.Email  },
                    };

                    await SendNotification(Request.Email, AppConstants.StatusKeys.EmailSubject, AppConstants.EmailTemplates.SignUpOtp, paramsTemplate);

                    await Mediator.Send(new UpdateUserRequest() { UserID = ExistingUser.Id, UserStatus = userStatus, UserToken = EmailCode, TokenPurpose = _tokenpurpose });// user status updated

                    return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Success, $"Your Send Credit verification code  sent on email {ExistingUser.Email}"));
                }
                else return HandleResponse(ProcessError(result));
            }
        }
        catch (Exception ex)
        {
            _logger.Error("User SignUp, " +
                                 "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                 "StackTrace: " + ex.StackTrace);
            return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.InternalServerError, AppConstants.StatusKeys.InternalServerError));
        }
    }

    [AllowAnonymous]
    [HttpPost("SignIn")]
    public async Task<IActionResult> LoginUser(SignInModel User)
    {
        try
        {
            var result = await _signInManager.PasswordSignInAsync(User.Email, User.Password, isPersistent: false, lockoutOnFailure: false);
            if (result.Succeeded)
            {
                var identityUser = await _userManager.FindByEmailAsync(User.Email);
                if (identityUser != null && identityUser.EmailConfirmed == true && (identityUser.LockoutEnabled == false
                                            || identityUser.LockoutEnd < DateTime.Now.AddMinutes(AppConstants.UserIdentityConfiguration.UserLockedOutTimeSpanMinutes)))
                {
                    if (User.IsGuestUser)
                    {
                        var GuestMigrationResponse = await Mediator.Send(new MigrateGuestData.Query() { IsGuestUser = User.IsGuestUser, UserID = User.UserID, SignInUserID = identityUser.Id });
                        if (!GuestMigrationResponse.IsSuccess)
                            return BadRequest(GuestMigrationResponse);
                    }

                    GetTokenRequest tokenRequest = new GetTokenRequest();
                    tokenRequest.UserInfo = new ClaimDto()
                    {
                        Id = identityUser.Id,
                        UserName = identityUser.UserName ?? string.Empty,
                        Email = identityUser.Email ?? string.Empty,
                        RequestID = _commonService.GenerateRequestID(),
                    };
                    var tokenresponse = (await Mediator.Send(tokenRequest)).TypedPayload<TokensDto>();
                    await CreateUserLoginLog(identityUser, true,
                                            tokenresponse != null ? tokenresponse.RefreshToken : string.Empty, tokenresponse?.RefreshTokenExpiry);

                    identityUser.LockoutEnabled = false;
                    identityUser.LockoutEnd = null;
                    identityUser.AccessFailedCount = 0;
                    await _userManager.UpdateAsync(identityUser);

                    var response = HandleResponse(tokenresponse);
                    foreach (var key in HttpContext.Response.Headers.Keys.ToList())// remove properties from header
                    {
                        HttpContext.Response.Headers.Remove(key);
                    }
                    return response;
                }
                else
                {
                    if (identityUser != null && identityUser.TwoFactorEnabled)
                    {
                        return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Conflict, AppConstants.StatusKeys.EmailVerificationRequired));
                    }
                    else if (identityUser != null && identityUser.LockoutEnabled)
                    {
                        return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Conflict, AppConstants.StatusKeys.UserLocked));
                    }
                    else
                    {
                        return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.NotFound, AppConstants.StatusKeys.EmailOrPasswordInvalid));
                    }
                }
            }
            else
            {
                var response = await ManageUserLockout(User);
                return HandleResponse(response);
            }
        }
        catch (Exception ex)
        {
            _logger.Error("Login, " + "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," + "StackTrace: " + ex.StackTrace);
            return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.InternalServerError, AppConstants.StatusKeys.InternalServerError));
        }
    }

    [AllowAnonymous]
    [HttpPost("VerifyToken")]
    public async Task<IActionResult> VerifyToken(TokenVerification user)
    {
        try
        {
            var identityUser = await _userManager.FindByEmailAsync(user.Email);
            if (identityUser != null)
            {
                var UserDetailresponse = (await Mediator.Send(
                                                    new GetUserDetailRequest() { UserID = identityUser.Id }))
                                                    .TypedPayload<GetUserDetailResponse>();// Get User Detail for double checking latest User Token
                var result = await _userManager.VerifyUserTokenAsync(identityUser, TokenOptions.DefaultPhoneProvider, UserDetailresponse?.TokenPurpose, user.Code);

                if (result && UserDetailresponse?.UserToken == user.Code)
                {
                    var userStatus = AppEnums.UserStatusEnum.Active.Getkey();
                    await Mediator.Send(new UpdateUserRequest() { UserID = identityUser.Id, UserStatus = userStatus });// user status updated

                    var userName = await _userManager.GetUserNameAsync(identityUser);

                    var paramsTemplate = new Dictionary<string, string>()
                    {
                        { "{F_NAME}" ,userName  },
                    };
                    await SendNotification(user.Email, AppConstants.EmailSubjects.WelcomeEmail, AppConstants.EmailTemplates.WelcomeEmail, paramsTemplate);

                    identityUser.LockoutEnabled = false;
                    identityUser.EmailConfirmed = true;
                    identityUser.TwoFactorEnabled = false;
                    await _userManager.UpdateAsync(identityUser);
                    return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Success, AppConstants.StatusKeys.SuccessTokenVerification));
                }
                else
                {
                    return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Forbidden, AppConstants.StatusKeys.InvalidToken));
                }
            }
            else
            {
                return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Conflict, AppConstants.StatusKeys.EmailExist));
            }
        }
        catch (Exception ex)
        {
            _logger.Error("Token Verification, " + "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," + "StackTrace: " + ex.StackTrace);
            return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.InternalServerError, AppConstants.StatusKeys.InternalServerError));
        }
    }

    [HttpPost("ForgotPassword"), AllowAnonymous]
    public async Task<IActionResult> ForgotPassword(ForgotPasswordModel request)
    {
        try
        {
            request.Email = request.Email.Trim();
            var ExistingUser = await _userManager.FindByEmailAsync(request.Email);
            if (ExistingUser != null)
            {
                var otpCode = await _userManager.GenerateUserTokenAsync(ExistingUser, TokenOptions.DefaultPhoneProvider, "ResetPasswordPurpose");
                //await SendNotification(ExistingUser!.Email!, token);

                //var userName = await _userManager.GetUserNameAsync(ExistingUser);
                var userDetailsDto = await _userRepository.GetUserDetailByUserID(ExistingUser.Id);
                var firstName = userDetailsDto?.FirstName;
                var lastName = userDetailsDto?.LastName;

                var userName = $"{firstName} {lastName}";

                var paramsTemplate = new Dictionary<string, string>()
                    {
                        { "{F_NAME}" ,userName  },
                        { "{123456}" ,otpCode  },
                    };
                //var x  = _configuration?.GetValue("EmailTemplatePath").ToString();
                await SendNotification(request.Email, AppConstants.EmailSubjects.ResetPasswordOtp, AppConstants.EmailTemplates.ResetPasswordOtp, paramsTemplate);

                return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Success, $"Your Password Reset code  sent on email {ExistingUser.Email}"));
            }
            else
            {
                return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.NotFound, AppConstants.StatusKeys.EmailNotFound));
            }
        }
        catch (Exception ex)
        {
            _logger.Error("PasswordReset, " +
                                 "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                 "StackTrace: " + ex.StackTrace);
            return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.InternalServerError, AppConstants.StatusKeys.InternalServerError));
        }
    }

    [HttpPost("ResetPassword"), AllowAnonymous]
    public async Task<IActionResult> ResetPassword(ResetPasswordModel request)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            request.Email = request.Email.Trim();
            var user = await _userManager.FindByEmailAsync(request.Email);
            if (user == null)
                return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.NotFound, AppConstants.StatusKeys.EmailNotFound));

            var tokenVerified = await _userManager.VerifyUserTokenAsync(user, TokenOptions.DefaultPhoneProvider, "ResetPasswordPurpose", request.Token);
            if (!tokenVerified)
                return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Forbidden, AppConstants.StatusKeys.InvalidToken));
            var token = await _userManager.GeneratePasswordResetTokenAsync(user);//new token for reseting password
            var result = await _userManager.ResetPasswordAsync(user, token, request.Password);
            if (!result.Succeeded)
                return HandleResponse(ProcessError(result));
            user.PasswordHash = _userManager.PasswordHasher.HashPassword(user, request.Password);

            var userDetailsDto = await _userRepository.GetUserDetailByUserID(user.Id);
            var firstName = userDetailsDto?.FirstName;
            var lastName = userDetailsDto?.LastName;

            var userName = $"{firstName} {lastName}";

            var paramsTemplate = new Dictionary<string, string>()
                                                    {
                                                        { "{F_NAME}" ,userName  },
                                                    };
            await SendNotification(request.Email, AppConstants.EmailSubjects.ResetPasswordSuccess, AppConstants.EmailTemplates.ResetPasswordSuccess, paramsTemplate);

            return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Success, AppConstants.StatusKeys.SuccessPasswordReset));
        }
        catch (Exception ex)
        {
            _logger.Error("PasswordReset, " +
                                 "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                 "StackTrace: " + ex.StackTrace);
            return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.InternalServerError, AppConstants.StatusKeys.InternalServerError));
        }
    }

    [HttpPost("ResendOTP"), AllowAnonymous]
    public async Task<IActionResult> ResendOTP(ResendOPTModel Request)
    {
        try
        {
            Request.Email = Request.Email.Trim();
            string EmailCode = string.Empty;
            var newuser = new IdentityUser
            {
                Email = Request.Email,
                UserName = Request.Email,
                AccessFailedCount = 0,
                TwoFactorEnabled = true
            };
            var ExistingUser = await _userManager.FindByEmailAsync(Request.Email);
            if (ExistingUser != null && ExistingUser.EmailConfirmed == false)
            {
                string _purpose = "EmailConfirmation" + DateTime.Now;
                var UserDetailresponse = (await Mediator.Send(new GetUserDetailRequest() { UserID = ExistingUser.Id })).TypedPayload<GetUserDetailResponse>();

                EmailCode = await _userManager.GenerateUserTokenAsync(ExistingUser, TokenOptions.DefaultPhoneProvider, _purpose);
                await Mediator.Send(new UpdateUserRequest()
                {
                    UserID = ExistingUser.Id,
                    UserStatus = UserDetailresponse.UserStatus,
                    UserToken = EmailCode,
                    TokenPurpose = _purpose
                });// Latest Token Persisted

                var paramsTemplate = new Dictionary<string, string>()
                    {
                        { "{123456}" , EmailCode  },
                        { "{F_NAME}" , ExistingUser!.Email!  },
                    };
                await SendNotification(Request.Email, AppConstants.StatusKeys.EmailSubject, AppConstants.EmailTemplates.SignUpOtp, paramsTemplate);

                return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.Success, $"Your Send Credit verification code sent on email {ExistingUser.Email}"));
            }
            else
                return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.NotFound, AppConstants.StatusKeys.EmailNotFound));
        }
        catch (Exception ex)
        {
            _logger.Error("ResendOTP, " +
                                 "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                 "StackTrace: " + ex.StackTrace);
            return HandleResponse(ProcessGeneral(AppConstants.StatusCodes.InternalServerError, AppConstants.StatusKeys.InternalServerError));
        }
    }

    [HttpPost("EditAccountDetail")]
    [Authorize]
    public async Task<IActionResult> EditAccountDetail(AccountDetailModel model)
    {
        var result = await Mediator.Send(new ÚpdateAccountDetailRequest()
        {
            FirstName = model.FirstName,
            LastName = model.LastName,
            FrontName = model.FrontName,
            DateOfBirth = model.DateOfBirth,
            Gender = model.Gender,
            Avatar = model.Avatar
        });
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }

    [HttpGet("GetAccountDetail")]
    [Authorize]
    public async Task<IActionResult> GetAccountDetail()
    {
        var result = await Mediator.Send(new GetAccountDetailRequest());
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }

    // Private Methods
    private async Task SendNotification(string email, string subject, string templateName, Dictionary<string, string> paramsTemplate)
    {

        var emailTemplatePath = _configuration.GetSection("EmailTemplatePath").Value;

        var user = await _userManager.FindByEmailAsync(email);
        var body = EmailHelper.GenerateEmailContent(templateName, paramsTemplate, emailTemplatePath!);

        var notificationResponse = await Mediator.Send(new SendNotificationRequest()
        {
            To = email,
            EmailBody = body,
            ProductCode = "SC",
            Subject = subject,
            EmailType = 1
        });
    }

    private async Task CreateUserLoginLog(IdentityUser user, bool IsSuccessLogin, string refreshToken, DateTime? refreshTokenExpiry = null)
    {
        UserLoginLogRequest logrequest = new UserLoginLogRequest()
        {
            UserID = user.Id,
            LoginTime = DateTime.UtcNow,
            Refresh_Token = refreshToken,
            Refresh_Token_Expiry = refreshTokenExpiry,
            IsSuccessLogin = IsSuccessLogin
        };
        await Mediator.Send(logrequest);
    }

    private async Task<ApiGenericResponse> ManageUserLockout(SignInModel user)
    {
        ApiGenericResponse? response = new ApiGenericResponse();
        var identityUser = await _userManager.FindByEmailAsync(user.Email);
        if (identityUser != null)
        {
            await CreateUserLoginLog(identityUser, false, string.Empty); // Create Login Log
            if (identityUser.LockoutEnabled == false)
            {
                GetLoginFailedAttempsRequest FailedAttempsCountRequest = new GetLoginFailedAttempsRequest();
                FailedAttempsCountRequest.UserID = identityUser.Id;
                FailedAttempsCountRequest.ConsecutivePeriod = DateTime.Now.AddMinutes(-AppConstants.UserIdentityConfiguration.ConsectiveFailedAttemptsWithMinutees);

                var FailedAttempsCountResponse = (await Mediator.Send(FailedAttempsCountRequest)).TypedPayload<int>();

                if (FailedAttempsCountResponse == AppConstants.UserIdentityConfiguration.MaxFailedAttempts)
                {
                    identityUser.LockoutEnabled = true;
                    identityUser.LockoutEnd = DateTime.Now.AddMinutes(AppConstants.UserIdentityConfiguration.UserLockedOutTimeSpanMinutes);
                    IdentityResult? result = await _userManager.UpdateAsync(identityUser);
                    if (result.Succeeded)
                    {
                        response.Code = AppConstants.StatusCodes.Conflict;
                        response.Message = AppConstants.StatusKeys.UserLocked;
                    }
                }
                else
                {
                    response.Code = AppConstants.StatusCodes.NotFound;
                    response.Message = AppConstants.StatusKeys.EmailOrPasswordInvalid;
                }
            }
            else
            {
                response.Code = AppConstants.StatusCodes.Conflict;
                response.Message = AppConstants.StatusKeys.UserLocked;
            }
        }
        else
        {
            response.Code = AppConstants.StatusCodes.NotFound;
            response.Message = AppConstants.StatusKeys.EmailOrPasswordInvalid;
        }
        return response;
    }

    private ErrorResult ProcessError(IdentityResult result)
    {
        ErrorResult? errorResponse = new ErrorResult()
        {
            Errors = new List<ErrorDto>()
        };
        if (result?.Errors != null)
            foreach (var error in result.Errors)
            {
                errorResponse.Errors.Add(new ErrorDto()
                {
                    Code = AppConstants.StatusCodes.BadRequest,
                    Message = error.Description
                });
            }
        return errorResponse;
    }

    private ApiGenericResponse ProcessGeneral(int code, string message)
    {
        ApiGenericResponse? response = new ApiGenericResponse
        {
            Code = code,
            Message = message
        };
        return response;
    }
}