﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts
{
    public class PaypalRefundResponse
    {
        public string CustomerId { get; set; }
        public string TransactionId { get; set; }
        public string RelatedTransactionId { get; set; }
        public string TransactionAmount { get; set; }
        public OutcomeModel OutcomeModel { get; set; }
    }
    public class OutcomeModel
    {
        public string Status { get; set; }
        public string ReasonCode { get; set; }
        public string ReasonMessage { get; set; }
    }
}
