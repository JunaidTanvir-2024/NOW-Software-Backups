﻿namespace THCC.Domain.Entities
{
    public class LegacyProduct
    {
        public int Id { get; set; }
        public string? ProductRef { get; set; }
        public DateTime DateCreated { get; set; }
        public bool IsActive { get; set; }
    }
}
