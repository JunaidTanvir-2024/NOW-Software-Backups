
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using static SC.Core.Common.Definitions.Constants.AppConstants;

InitializeLogger();
var assemblyName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;

Log.Information($"{assemblyName} Booting Up..");
try
{
    var builder = WebApplication.CreateBuilder(args);
    {
        builder.Host.UseSerilog((hostingContext, config) => config.ReadFrom
        .Configuration(hostingContext.Configuration));
        builder.WebHost.UseSentry();

        var allowedOrigins = builder.Configuration.GetValue<string>("AllowedOrigins");
        var origins = allowedOrigins?.Split(";");
        // Configure Services
        builder.Services.AddApiDependencies(builder.Configuration);
        builder.Services.AddCors(options =>
        {
            options.AddDefaultPolicy( builder =>
            {
                builder.AllowAnyOrigin()
                .AllowAnyHeader()
                .AllowAnyMethod();
            });

            //options.AddPolicy("EnableCORS", builder =>
            //{
            //    builder.WithOrigins(origins)
            //    .AllowAnyHeader()
            //    .AllowAnyMethod();
            //});
        });
    }
    builder.Services.Configure<DataProtectionTokenProviderOptions>(opt =>
   opt.TokenLifespan = TimeSpan.FromMinutes(AppConstants.UserIdentityConfiguration.TokenValidityMinutees));
    builder.Services.AddIdentity<IdentityUser, ExtendedIdentityRole>(options =>
    {
        options.Password.RequireDigit = true;
        options.Password.RequireLowercase = true;
        options.Password.RequireNonAlphanumeric = true;
        options.Password.RequireUppercase = true;
        options.Password.RequiredLength = 8;
        options.Password.RequiredUniqueChars = 1;

    }).AddDapperStores(options =>
    {
        options.AddRolesTable<ExtendedRolesTable, ExtendedIdentityRole>();
    }).AddDefaultTokenProviders();


    builder.Services.Configure<ConnectionStrings>(builder.Configuration.GetSection(nameof(ConnectionStrings)));
    //builder.Services.AddMassTransitHostedService();
    var app = builder.Build();
    {
        app.AddApiMiddlewares();
        app.Run();
    }
}
catch (Exception ex) when (!ex.GetType().Name.Equals("StopTheHostException", StringComparison.Ordinal))
{
    InitializeLogger();
    Log.Error($"{assemblyName} Shutting down...");
    Log.Fatal(ex, "Unhandled exception");
    throw;
}
finally
{
    InitializeLogger();
    Log.Error($"{assemblyName} Shutting down...");
    Log.CloseAndFlush();
}

/// <summary>
/// Static console logger
/// </summary>
static void InitializeLogger()
{
    if (Log.Logger is not Serilog.Core.Logger)
    {
        Log.Logger = new LoggerConfiguration().WriteTo.Console().WriteTo.Sentry().CreateLogger();
    }
}
