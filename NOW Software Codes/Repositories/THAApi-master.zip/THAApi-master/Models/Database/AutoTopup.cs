﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
	public class AutoTopupDetail
	{
		public string Msisdn { get; set; }
		public float ThresHold { get; set; }
		public float Topup { get; set; }
		public string Currency { get; set; }
		public bool Status { get; set; }
		public PaymentMethods PaymentMethod { get; set; }
        public string CardMaskedPAN { get; set; }
        public string CardInitialTransactionId { get; set; }
        public string PaypalSubscriptionId { get; set; }
        public bool LastAutoTopupFailed { get; set; }
    }
}
