﻿using System.Text.Json.Serialization;

namespace CallingCode.Mvc.Common.Models;

public class GeoInfo
{
    [JsonPropertyName("country")]
    public string CountryCode { get; set; }

    //[JsonPropertyName("country_name")]
    //public string CountryName { get; set; }

    //[JsonPropertyName("region_code")]
    //public string RegionCode { get; set; }

    [JsonPropertyName("region")]
    public string? RegionName { get; set; }

    [JsonPropertyName("city")]
    public string? City { get; set; }
}
