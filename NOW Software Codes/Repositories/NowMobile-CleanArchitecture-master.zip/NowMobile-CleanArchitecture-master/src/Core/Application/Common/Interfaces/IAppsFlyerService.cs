﻿using Application.Common.Models;

namespace Application.Common.Interfaces;
public interface IAppsFlyerService : ISerivcesType.ITransientService
{
    Task SetCustomerId(string customerUserId, string afUserId);
    Task CreateCustomEvent(List<CreateEventRequestModel> request);
}
