﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.SmsApiRequest
{
    public class GenericSmsApiResponse<T>
    {

        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public T payload { get; set; }

        public static GenericSmsApiResponse<T> Success(T payload, string message)
        {
            return new GenericSmsApiResponse<T>
            {
                errorCode = 0,
                status = "Success",
                message = message,
                payload = payload
            };
        }

        public static GenericSmsApiResponse<T> Pending(T payload, string message)
        {
            return new GenericSmsApiResponse<T>
            {
                errorCode = 1,
                status = "Pending",
                message = message,
                payload = payload
            };
        }

        public static GenericSmsApiResponse<T> Failure(string message)
        {
            return new GenericSmsApiResponse<T>
            {
                errorCode = 2,
                status = "Failure",
                message = message

            };
        }

    }
}
