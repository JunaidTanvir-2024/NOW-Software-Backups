﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts
{
    public class PreAuthResponse
    {
        public string token_tx { get; set; }
    }
}
