using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

using Microsoft.AspNetCore.Http;

using Voucherify.Core.Services.Loggers;

namespace Voucherify.Core.Services.Http;

public sealed class HttpService : IHttpService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILoggerRepository _loggerRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private string? _bearerToken;
    private string? _basicAuthUsername;
    private string? _basicAuthPassword;
    private bool _isLoggingEnabled;
    private readonly List<HttpServiceKeyValues> _headers;

    public HttpService(
        IHttpClientFactory httpClientFactory,
        ILoggerRepository loggerRepository,
        IHttpContextAccessor httpContextAccessor)
    {
        _httpClientFactory = httpClientFactory;
        _loggerRepository = loggerRepository;
        _httpContextAccessor = httpContextAccessor;
        _headers = new List<HttpServiceKeyValues>();
    }

    public HttpService WithBearerAuth(string token)
    {
        _bearerToken = token;
        return this;
    }

    public HttpService WithBasicAuth(string username, string password)
    {
        _basicAuthUsername = username;
        _basicAuthPassword = password;
        return this;
    }

    public HttpService WithHeaders(IEnumerable<HttpServiceKeyValues> headers)
    {
        _headers.AddRange(headers);
        return this;
    }

    public HttpService EnableLogging()
    {
        _isLoggingEnabled = true;
        return this;
    }

    public async Task<(bool StatusCode, string ResponseBody)> GetAsync(string requestUri)
    {
        return await SendRequestAsync(HttpMethod.Get, requestUri);
    }

    public async Task<(bool StatusCode, string ResponseBody)> PostAsync(string requestUri, object? data = default)
    {
        var content = CreateJsonContent(data ?? string.Empty);
        return await SendRequestAsync(HttpMethod.Post, requestUri, content);
    }

    public async Task<(bool StatusCode, string ResponseBody)> PutAsync(string requestUri, object? data = default)
    {
        var content = CreateJsonContent(data ?? string.Empty);
        return await SendRequestAsync(HttpMethod.Put, requestUri, content);
    }

    public async Task<(bool StatusCode, string ResponseBody)> DeleteAsync(string requestUri)
    {
        return await SendRequestAsync(HttpMethod.Delete, requestUri);
    }

    private async Task<(bool StatusCode, string ResponseBody)> SendRequestAsync(HttpMethod method, string requestUri, HttpContent? content = null)
    {
        var stopwatch = Stopwatch.StartNew();
        var client = _httpClientFactory.CreateClient();

        var request = new HttpRequestMessage(method, requestUri);

        if (_bearerToken != null)
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _bearerToken);
        }
        else if (_basicAuthUsername != null && _basicAuthPassword != null)
        {
            var authValue = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_basicAuthUsername}:{_basicAuthPassword}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authValue);
        }

        foreach (var header in _headers)
        {
            client.DefaultRequestHeaders.Add(header.Key, header.Value);
        }

        if (content != null)
        {
            request.Content = content;
        }

        var requestBody = request?.Content != null ? await request.Content.ReadAsStringAsync() : string.Empty;
        return await SendRequestAndSaveLog(stopwatch, client, request, requestBody);
    }

    private async Task<(bool StatusCode, string ResponseBody)> SendRequestAndSaveLog(Stopwatch stopwatch, HttpClient client, HttpRequestMessage? request, string requestBody)
    {
        // Save log entry to the database
        try
        {
            var result = await client.SendAsync(request!);

            var responseBody = await result.Content.ReadAsStringAsync();
            var isSuccess = result.IsSuccessStatusCode;

            // Calculating response size
            var responseSize = Encoding.UTF8.GetByteCount(responseBody);

            if (_isLoggingEnabled)
            {
                InsertVoucherifyLogs(stopwatch, request, (int)result.StatusCode, responseBody, requestBody, responseSize, string.Empty);
            }
            return (isSuccess, responseBody);
        }
        catch (Exception ex)
        {
            // Set the error message in the log entry
            if (_isLoggingEnabled)
            {
                // Response body and size will be zero as there is no response in case of error 
                InsertVoucherifyLogs(stopwatch, request, StatusCodes.Status500InternalServerError, string.Empty, requestBody, 0, ex.StackTrace?.ToString());
            }
            return (false, string.Empty);
        }
    }

    private void InsertVoucherifyLogs(Stopwatch stopwatch, HttpRequestMessage? request, int statusCode, string? responseBody, string? reqeustBody, int responseSize, string? stackTraceError)
    {
        var logEntry = new VoucherifyLogEntry
        {
            Timestamp = DateTime.UtcNow,
            RequestPath = request?.RequestUri?.ToString(),
            RequestMethod = request?.Method.ToString(),
            RequestBody = reqeustBody,
            ResponseBody = responseBody,
            StatusCode = statusCode,
            Duration = stopwatch.ElapsedMilliseconds,
            ClientIP = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
            UserAgent = _httpContextAccessor.HttpContext?.Request.Headers["User-Agent"],
            ResponseSize = responseSize,
            ErrorMessage = stackTraceError,
            CorrelationId = _httpContextAccessor.HttpContext?.Items["CorrelationIdKey"]?.ToString()!,
            Headers = JsonSerializer.Serialize(request?.Headers),
            QueryString = request?.RequestUri?.Query
        };
        _loggerRepository.InsertVoucherifyLogEntry(logEntry);
    }

    private static HttpContent CreateJsonContent(object data)
    {
        var json = JsonSerializer.Serialize(data);
        return new StringContent(json, Encoding.UTF8, "application/json");
    }

    public sealed class HttpServiceKeyValues
    {
        public string Key { get; set; } = null!;
        public string Value { get; set; } = null!;
    }
}
