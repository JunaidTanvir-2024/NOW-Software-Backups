﻿namespace THCC.Domain.Entities
{
    public class LegacyUser
    {
        public long Id { get; set; }
        public string FirstName { get; set; } = default!;
        public string LastName { get; set; } = default!;
        public string Email { get; set; } = default!;
        public bool NewsLetter { get; set; }
        public byte[] Password { get; set; } = default!;
        public byte[] PasswordPrefix { get; set; } = default!;
        public byte[] PasswordSuffix { get; set; } = default!;
        public byte[] Key { get; set; } = default!;
        public byte[] IV { get; set; } = default!;
        public bool IsConfirmedUser { get; set; }
    }
}
