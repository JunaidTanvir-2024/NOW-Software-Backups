﻿namespace SenderService.Core.Common.Enums;
public enum ProcessingState
{
    Pending = 0,
    Complete = 1,
    Failed = 2
}