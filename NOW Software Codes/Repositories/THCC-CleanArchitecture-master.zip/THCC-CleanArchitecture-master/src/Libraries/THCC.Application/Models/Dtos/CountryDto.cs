﻿namespace THCC.Application.Models.Dtos
{
    public class CountryDetailsDto
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? PhoneCode { get; set; }
        public string? IsoTwoCharacterCode { get; set; }
        public string? IsoThreeCharacterCode { get; set; }
        public string? IsoNumericCode { get; set; }
        public bool IsNational { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class CountryDto
    {
        public string? Name { get; set; }
        public string? IsoTwoCharacterCode { get; set; }
    }
}
