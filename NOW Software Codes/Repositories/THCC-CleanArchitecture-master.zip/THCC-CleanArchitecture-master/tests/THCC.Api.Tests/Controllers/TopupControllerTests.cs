﻿using FakeItEasy;

using FluentAssertions;

using FluentValidation.Results;

using MediatR;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;

using THCC.Api.Controllers;
using THCC.Application.Features.Topup.Denominations;
using THCC.Application.Features.Topup.VerifyCardNumber;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

using static THCC.Domain.Constants.ThccConstants;

namespace THCC.Api.Tests.Controllers
{
    public class TopupControllerTests
    {
        private readonly TopupController _topupController;
        private readonly ISender _sender;

        private readonly VerifyCardNumberValidator _verifyCardNumberValidator;

        public TopupControllerTests()
        {
            //SUT
            _sender = A.Fake<ISender>();
            _topupController = new TopupController
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext()
                }
            };
            _topupController.ControllerContext.HttpContext.RequestServices = new ServiceCollection().AddSingleton(_sender).BuildServiceProvider();

            //Dependencies
            _verifyCardNumberValidator = new VerifyCardNumberValidator();
        }

        #region Topup Denominations

        [Fact]
        public async void TopupController_GetTopupDenominations_Success()
        {
            //Arrange
            var topupSettings = new TopupSettings();
            var cancellationToken = CancellationToken.None;
            A.CallTo(() => _sender.Send(new TopupDenominationRequest(), cancellationToken)).Returns(topupSettings);

            //Act
            var result = await _topupController.GetTopupDenominations(CancellationToken.None);

            //Assert
            result.Should().BeOfType<OkObjectResult>()
                .Which.Value.Should().BeOfType<TopupSettings>();
        }

        #endregion

        #region Verify Card Number

        [Fact]
        public async void TopupController_VerifyCardNumber_CardNumber_IsValidAndRegister()
        {
            //Arrange
            var cancellationToken = CancellationToken.None;
            var request = new VerifyCardNumberRequest() { CardNumber = "1231231231231231" };
            A.CallTo(() => _sender.Send(request, cancellationToken)).Returns(
                new VerifyCardNumberResponse()
                {
                    IsRegistered = true
                });

            //Act
            var result = await _topupController.VerifyCardNumberNumber(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<OkObjectResult>()
                .Which.Value.Should().BeOfType<VerifyCardNumberResponse>()
                .Which.IsRegistered.Should().BeTrue();
        }

        [Fact]
        public async void TopupController_VerifyCardNumber_CardNumber_IsValidAndNotRegister()
        {
            //Arrange
            var cancellationToken = CancellationToken.None;
            var request = new VerifyCardNumberRequest() { CardNumber = "1231231231231231" };
            A.CallTo(() => _sender.Send(request, cancellationToken)).Returns(
                new VerifyCardNumberResponse()
                {
                    IsRegistered = false
                });

            //Act
            var result = await _topupController.VerifyCardNumberNumber(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<OkObjectResult>()
                .Which.Value.Should().BeOfType<VerifyCardNumberResponse>()
                .Which.IsRegistered.Should().BeFalse();
        }

        [Fact]
        public async void TopupController_VerifyCardNumber_CardNumber_IsNotValid()
        {
            //Arrange
            var cancellationToken = CancellationToken.None;
            var errorResponse = new ErrorResult()
            {
                Errors = new List<ErrorDto>() {
                    new ErrorDto() {
                        Code = CustomStatusCode.BadRequest,
                        Message = CustomStatusKey.InvalidCardNumnber }
                }
            };
            var request = new VerifyCardNumberRequest() { CardNumber = "1231231231231231" };
            A.CallTo(() => _sender.Send(request, cancellationToken)).Returns(errorResponse);

            //Act
            var result = await _topupController.VerifyCardNumberNumber(request, CancellationToken.None);

            //Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeOfType<ErrorResult>()
                .Which.Errors.Count.Should().Be(1);
        }

        [Fact]
        public async void TopupController_VerifyCardNumber_CardNumber_ShouldNotBeNull()
        {
            // Arrange
            var request = new VerifyCardNumberRequest
            {
                CardNumber = null!
            };
            //Act
            var result = await _verifyCardNumberValidator.ValidateAsync(request);
            //Assert
            result.Should().BeOfType<ValidationResult>().Which.IsValid.Should().BeFalse();
        }

        [Fact]
        public async void TopupController_VerifyCardNumber_CardNumber_ShouldNotBeEmpty()
        {
            // Arrange
            var request = new VerifyCardNumberRequest
            {
                CardNumber = string.Empty
            };
            //Act
            var result = await _verifyCardNumberValidator.ValidateAsync(request);
            //Assert
            result.Should().BeOfType<ValidationResult>().Which.IsValid.Should().BeFalse();
        }

        [Theory]
        [InlineData("123456789012345678901")] // Length exceeds maximum length of 20
        [InlineData("12345678901234567890")] // Length is within the maximum length
        public async void TopupController_VerifyCardNumber_CardNumber_ShouldNotExceedMaximumLength(string cardNumber)
        {
            // Arrange
            var request = new VerifyCardNumberRequest
            {
                CardNumber = cardNumber// Length exceeds maximum length of 20
            };

            // Act
            var result = await _verifyCardNumberValidator.ValidateAsync(request);

            if (cardNumber.Length > 20)
            {
                //Assert
                result.Should().BeOfType<ValidationResult>().Which.IsValid.Should().BeFalse();
            }
            else
            {
                //Assert
                result.Should().BeOfType<ValidationResult>().Which.IsValid.Should().BeTrue();
            }
        }
      
        [Fact]
        public async void TopupController_VerifyCardNumber_CardNumber_ShouldPassValidation()
        {
            // Arrange
            var request = new VerifyCardNumberRequest
            {
                CardNumber = "123456"
            };

            // Act
            var result = await _verifyCardNumberValidator.ValidateAsync(request);

            //Assert
            result.Should().BeOfType<ValidationResult>().Which.IsValid.Should().BeTrue();
        }

        #endregion
    }
}