using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

using THCC.Application.Settings;


namespace THCC.Application;

public static class ConfigureApplication
{
    public static IHostBuilder AddJsonFilesConfigurations(this IHostBuilder host)
    {
        host.ConfigureAppConfiguration((context, config) =>
        {
            if (context is null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            var environment = config.AddJsonFile("appsettings.json").Build().GetSection("Environment").Value;
            Environment.SetEnvironmentVariable("DOTNET_ENVIRONMENT", environment);
            Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", environment);
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string configurationsDirectory = Path.Combine(baseDirectory, "Configurations");

            config.AddJsonFile(Path.Combine(baseDirectory, "appsettings.json"), optional: false, reloadOnChange: true)
                  .AddJsonFile(Path.Combine(configurationsDirectory, $"appsettings.{environment}.json"), optional: true, reloadOnChange: true)
                  .AddEnvironmentVariables();
        });
        return host;
    }

    public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
    {
        //Configure settings
        services.Configure<AddressSettings>(configuration.GetSection(AddressSettings.SectionName));
        services.Configure<AutoTopupServiceSettings>(configuration.GetSection(AutoTopupServiceSettings.SectionName));
        services.Configure<CommerceTypeSettings>(configuration.GetSection(CommerceTypeSettings.SectionName));
        services.Configure<DiscountSettings>(configuration.GetSection(DiscountSettings.SectionName));
        services.Configure<FileUploadSettings>(configuration.GetSection(FileUploadSettings.SectionName));
        services.Configure<GeoLocationSettings>(configuration.GetSection(GeoLocationSettings.SectionName));
        services.Configure<MailSettings>(configuration.GetSection(MailSettings.SectionName));
        services.Configure<Pay360Setting>(configuration.GetSection(Pay360Setting.SectionName));
        services.Configure<PayPalSetting>(configuration.GetSection(PayPalSetting.SectionName));
        services.Configure<ProfileSettings>(configuration.GetSection(ProfileSettings.SectionName));
        services.Configure<TopupSettings>(configuration.GetSection(TopupSettings.SectionName));
        services.Configure<TrustPilotSettings>(configuration.GetSection(TrustPilotSettings.SectionName));
        services.Configure<AirShipSettings>(configuration.GetSection(AirShipSettings.SectionName));
        services.Configure<RateLimitingSettings>(configuration.GetSection(RateLimitingSettings.SectionName));
        services.Configure<CallingCardSettings>(configuration.GetSection(CallingCardSettings.SectionName));


        // Dependencies Resolver registration
        services.AutoResolve();
        services.AddHttpClient();
        services.AddMediatR(Assembly.GetExecutingAssembly());

        // Register mapster object mapping configuration
        services.AddMapsterConfiguration();

        // Register fluent validation and all request validators 
        services.AddFluentValidatorsConfiguration();

        services.AddHttpContextAccessor();
        return services;
    }

    private static IServiceCollection AddMapsterConfiguration(this IServiceCollection services)
    {
        #region Mapster Configurations

        var mapperConfiguration = TypeAdapterConfig.GlobalSettings;
        mapperConfiguration.Scan(Assembly.GetExecutingAssembly());
        services.AddSingleton(mapperConfiguration);
        services.AddScoped<IMapper, ServiceMapper>();

        return services;
        #endregion
    }

    private static IServiceCollection AddFluentValidatorsConfiguration(this IServiceCollection services)
    {
        // Getting Current Executing Assembly and adding fluent validation validators
        var executingAssembly = Assembly.GetExecutingAssembly();
        services.AddValidatorsFromAssembly(executingAssembly);
        return services;
    }
}
