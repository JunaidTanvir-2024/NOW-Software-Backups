﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Models.Contracts;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace THAAPI.Controllers
{

    [ApiController]
    public class PushController : ControllerBase
    {

        private readonly ILogger Logger;
        private IPush_BL PushBl;
        private IPush_DL PushDl;
        
        public PushController(ILogger logger, IPush_BL pushBl, IPush_DL pushDl)
        {
            Logger = logger;
            PushBl = pushBl;
            PushDl = pushDl;
        }

        [HttpPost]
        [Route("~/push/notification/{recipient}")]
        public async Task<IActionResult> Send(string recipient, PushPayload payload)
        {
            Logger.Information($"{Request.Method} {Request.Path} {JsonConvert.SerializeObject(payload)}");

            try
            {
                payload.PopulateFlags();
                var success = await PushBl.SendNotification(recipient, payload);
                return success ? Ok(GenericApiResponse<bool>.Success(true, "Success")) : Ok(GenericApiResponse<bool>.Failure("Failure", ApiStatusCodes.UnSuccessful));
            }
            catch (Exception ex)
            {
                Logger.Error($"{ex}");
                return StatusCode(500, GenericApiResponse<PushRegistration>.Failure($"Failure: {ex.Message}", ApiStatusCodes.InternalServerError));
            }
        }
        //This endpoit is not consuming
        [HttpPut]
        [Route("~/push/registration/{msisdn}")]
        public async Task<IActionResult> RegisterDevice(string msisdn, PushRegistration registration)
        {
            Logger.Information($"{Request.Method} {Request.Path} {JsonConvert.SerializeObject(registration)}");

            try
            {
                registration.msisdn = msisdn;
                var success = await PushDl.SetPushRegistration(registration);
                return success ? Ok(GenericApiResponse<PushRegistration>.Success(registration, "Success")) : Ok(GenericApiResponse<PushRegistration>.Failure("Failure", ApiStatusCodes.UnSuccessful));
            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: PushController, Method: RegisterDevice, Parameters=> requestJson: {JsonConvert.SerializeObject(registration)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return StatusCode(500, GenericApiResponse<PushRegistration>.Failure("Failure", ApiStatusCodes.InternalServerError));
            }
        }
        //This endpoit is not consuming
        [HttpPost]
        [Route("push/sendPush/{recipient}")]
        public async Task<IActionResult> SendPush(string recipient, PushRequest request)
        {
            FCMPushRequest fCMPushRequest = new FCMPushRequest();
            APNSPushRequest apnsPushRequest = new APNSPushRequest();
            try
            {

                string msisdn = recipient;
                var jsonBody = string.Empty;
                GenericApiResponse<FcmPushPayload> fcmPushResponse = null;
                GenericApiResponse<ApnsPayload> apnsPushResponse = null;
                //List<Claim> userClaims = this.User.Claims.ToList();
                //msisdn = userClaims.Find(c => c.Type == "msisdn").Value;

                ///Send FCM
                var fcmResponse = await PushBl.GetFCMToken(msisdn);
                if (fcmResponse.ErrorCode == 0)
                {
                    //For testing

                    request.DeviceToken = fcmResponse.Payload;

                     fCMPushRequest = new FCMPushRequest()
                    {
                        MessageTitle = request.MessageTitle,
                        MessageBody = request.MessageBody,
                        DeviceToken = request.DeviceToken,
                        NotificationType = request.NotificationType == NotificationTypes.Notification ? FCMNotificationTypes.FCMNotificationMessage : request.NotificationType==NotificationTypes.Silent? FCMNotificationTypes.FCMDataMessage:FCMNotificationTypes.FCMXMPPNotificationMessage,
                        sip_calling = request.sip_calling,
                        call_uuid = request.call_uuid,
                        xmpp_message=request.xmpp_message,
                        
                     };

                    fcmPushResponse = await PushBl.SendFCMPush(fCMPushRequest);
                }


                /////////////Send APNS
                var apnsResponse = await PushBl.GetAPNSToken(msisdn);
                if (apnsResponse.ErrorCode == 0)
                {
                    if (apnsResponse.Payload.sandBox)
                    {
                        request.server = ApnServerType.Development;
                    }
                    else
                    {
                        request.server = ApnServerType.Production;
                    }
                    if (request.NotificationType == NotificationTypes.Notification|| request.NotificationType == NotificationTypes.XMPP)
                    {
                        request.DeviceToken = apnsResponse.Payload.APNS;
                    }
                    else if (request.NotificationType == NotificationTypes.Silent)
                    {

                        request.DeviceToken = apnsResponse.Payload.Pushkit;
                    }
                    apnsPushRequest = new APNSPushRequest()
                    {
                        MessageTitle = request.MessageTitle,
                        MessageBody = request.MessageBody,
                        DeviceToken = request.DeviceToken,
                        NotificationType = request.NotificationType == NotificationTypes.Notification ? APNSNotificationTypes.APNSRemotePushNotification :request.NotificationType==NotificationTypes.Silent? APNSNotificationTypes.APNSVoipPushNotification:APNSNotificationTypes.APNSXMPPRemotePushNotification,
                        sip_calling = request.sip_calling,
                        call_uuid = request.call_uuid,
                        xmpp_message = request.xmpp_message,
                        server = request.server
                    };
                    apnsPushResponse = await PushBl.SendAPNSPush(apnsPushRequest);
                }

                if (fcmPushResponse != null && apnsPushResponse != null)
                {
                    if (fcmPushResponse.ErrorCode == 0 || apnsPushResponse.ErrorCode == 0)
                    {
                        var res = new
                        {
                            message = "Success",
                            status = "Success",
                            errorCode = 0,
                            payload = new
                            {
                                reason = ""
                            }
                        };
                        return Ok(res);
                    }
                    else
                    {
                        var reason = fcmPushResponse.Payload.results[0].error == null ? "" : fcmPushResponse.Payload.results[0].error + "|" + apnsPushResponse.Payload.Reason;
                        var res = new
                        {
                            message = "Failure",
                            status = "Failure",
                            errorCode = fcmPushResponse.ErrorCode + "|" + apnsPushResponse.ErrorCode,
                            payload = new
                            {
                                reason = reason
                            }
                        };
                        return Ok(res);
                    }

                }
                else if (fcmPushResponse != null && apnsPushResponse == null)
                {
                    var res = new
                    {
                        message = fcmPushResponse.Message,
                        status = fcmResponse.Status,
                        errorCode = fcmPushResponse.ErrorCode,
                        payload = new
                        {
                            reason = fcmPushResponse.Payload.results[0].error == null ? "" : fcmPushResponse.Payload.results[0].error
                        }
                    };

                    if (res.errorCode != 0)
                    {
                        Logger.Information($"Class: PushController, Method: SendAPNSPush Error, Parameters=> requestJson: {JsonConvert.SerializeObject(fCMPushRequest)} responseJSon {res}");
                    }

                    return Ok(res);
                }
                else if (fcmPushResponse == null && apnsPushResponse != null)
                {
                    var res = new
                    {
                        message = apnsPushResponse.Message,
                        status = apnsPushResponse.Status,
                        errorCode = apnsPushResponse.ErrorCode,
                        payload = new
                        {
                            reason = apnsPushResponse.Payload.Reason
                        }
                    };
                    if (res.errorCode != 0)
                    {
                        Logger.Information($"Class: PushController, Method: SendAPNSPush Error, Parameters=> requestJson: {JsonConvert.SerializeObject(apnsPushRequest)} responseJSon {res}");
                    }

                    return Ok(res);
                }
                else
                {
                    var res = new
                    {
                        message = "Failure",
                        status = "Failure",
                        errorCode = ApiStatusCodes.TokenNotFound,
                        payload = new
                        {
                            reason = "Token Not Found"
                        }
                    };
                    return Ok(res);
                }


            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: PushController, Method: SendPush, Parameters=> requestJson: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }


        //[HttpPost]
        //[Route("push/sendFCMPush/{recipient}")]
        //public async Task<IActionResult> SendFCMPush(string recipient, FCMPushRequest request)
        //{
        //    try
        //    {

        //        string msisdn = recipient;
        //        var jsonBody = string.Empty;

        //        //List<Claim> userClaims = this.User.Claims.ToList();
        //        //msisdn = userClaims.Find(c => c.Type == "msisdn").Value;

        //        var fcmResponse = await PushBl.GetFCMToken(msisdn);
        //        if (fcmResponse.errorCode == 0)
        //        {
        //            //For testing
        //            //if (request.sip_calling == null)
        //            //    request.sip_calling = "923340111395";
        //            request.DeviceToken = fcmResponse.payload;
        //        }
        //        var response = await PushBl.SendFCMPush(request);
        //        return Ok(response);
        //    }
        //    catch (Exception ex)
        //    {
        //        string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
        //        Logger.Error($"Class: PushController, Method: SendFCMPush, Parameters=> requestJson: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
        //        return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
        //    }
        //}

        //[HttpPost]
        //[Route("push/sendAPNSPush/{recipient}")]
        //public async Task<IActionResult> SendAPNSPush(string recipient, APNSPushRequest request)
        //{
        //    try
        //    {
        //        string msisdn = recipient;
        //        var jsonBody = string.Empty;

        //        //List<Claim> userClaims = this.User.Claims.ToList();
        //        //msisdn = userClaims.Find(c => c.Type == "msisdn").Value;

        //        var apnsResponse = await PushBl.GetAPNSToken(msisdn);
        //        if (apnsResponse.errorCode == 0)
        //        {
        //            if (apnsResponse.payload.sandBox)
        //            {
        //                request.server = ApnServerType.Development;
        //            }
        //            else
        //            {
        //                request.server = ApnServerType.Production;
        //            }
        //            if (request.NotificationType == APNSNotificationTypes.APNSRemotePushNotification)
        //            {
        //                request.DeviceToken = apnsResponse.payload.APNS;
        //            }
        //            else if (request.NotificationType == APNSNotificationTypes.APNSVoipPushNotification)
        //            {
        //                //For testing
        //                //if (request.sip_calling == null)
        //                //    request.sip_calling = "923340111395";
        //                request.DeviceToken = apnsResponse.payload.Pushkit;
        //            }

        //        }
        //        var response = await PushBl.SendAPNSPush(request);
        //        return Ok(response);

        //    }
        //    catch (Exception ex)
        //    {
        //        string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
        //        Logger.Error($"Class: PushController, Method: SendAPNSPush, Parameters=> requestJson: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
        //        return Ok(GenericApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException));
        //    }
        //}

    }
}