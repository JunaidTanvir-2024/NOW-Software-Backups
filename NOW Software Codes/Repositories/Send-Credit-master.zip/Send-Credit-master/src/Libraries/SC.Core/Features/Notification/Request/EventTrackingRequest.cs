﻿using SC.Core.Common.Model.EventNotification;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Notification.Request;
public class EventTrackingRequest : IRequest<bool>
{
    public string EventDetail { get; set; } = default!;
    public string EventName { get; set; } = default!;
    public string EventValue { get; set; } = default!;
    public string EventCurrency { get; set; } = default!;
    public string Email { get; set; } = default!;
    public string PhoneNumber { get; set; } = default!;
    public string ClientId { get; set; } = default!;
    public string PlatForm { get; set; } = default!;
    public string Uri { get; set; } = default!;
    public string ProductCode { get; set; } = default!;
    public string UserAgent { get; set; } = default!;
    public string ClientIp { get; set; } = default!;
    public DateTime RequestDateTime { get; set; } = default!;

   
}
public sealed class EventTrackingRequestValidator : AbstractValidator<EventTrackingRequest>
{
    public EventTrackingRequestValidator()
    {
        
    }
}



