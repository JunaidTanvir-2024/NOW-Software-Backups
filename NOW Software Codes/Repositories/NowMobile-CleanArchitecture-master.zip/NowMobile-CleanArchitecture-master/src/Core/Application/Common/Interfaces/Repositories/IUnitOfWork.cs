namespace Application.Common.Interfaces.Repositories;

public interface IUnitOfWork : ISerivcesType.IScopedService
{
    IUserRepository UserRepo { get; }
    IDeviceRepository DeviceRepo { get; }
    IBundleRepository BundleRepo { get; }
    ISimRepository SimRepo { get; }
   IPromotionRepository PromotionRepo { get; }
    IRateRepository RateRepo { get; }
    IPaymentRepository PaymentRepo { get; }
    ITopupRepository TopupRepo { get; }
}