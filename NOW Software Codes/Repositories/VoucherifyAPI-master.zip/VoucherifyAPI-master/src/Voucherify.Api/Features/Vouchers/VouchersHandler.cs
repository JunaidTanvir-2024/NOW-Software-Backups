using RW;

using Voucherify.Api.Features.Vouchers.Requests;
using Voucherify.Api.Features.Vouchers.Responses;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Domain.Definitions;
using Voucherify.Core.Services.VoucherifyApi;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Api.Features.Vouchers;

public interface IVouchersHandler
{
    Task<IResultWrapper<bool>> DeleteVoucher(DeleteVoucherRequest request);
    Task<IResultWrapper<List<VoucherResponse>>> GetVouchersList(GetVouchersRequest request);
    Task<IResultWrapper<VoucherResponse>> GetSpecificVoucher(GetVoucherRequest request);
    Task<IResultWrapper<VoucherRedemptionResponse>> VoucherRedemption(RedeemVoucherRequest request);
    Task<IResultWrapper<VoucherValidationResponse>> VoucherValidation(ValidateVoucherRequest request);
}

public class VouchersHandler : IVouchersHandler
{
    private const string VoucherCode = "Voucher Code";
    private readonly IVoucherifyImplementation _voucherifyImplementation;

    public VouchersHandler(IVoucherifyImplementation voucherifyImplementation)
    {
        _voucherifyImplementation = voucherifyImplementation;
    }

    public async Task<IResultWrapper<List<VoucherResponse>>> GetVouchersList(GetVouchersRequest request)
    {
        var vouchers = await _voucherifyImplementation.GetVouchers(request.PageNumber, request.PageSize);
        if (vouchers != null)
        {
            var result = vouchers?.Select(voucher => new VoucherResponse()
            {
                Active = voucher.Active,
                Campaign = voucher.Campaign,
                CampaignId = voucher.CampaignId,
                Category = voucher.Category,
                Code = voucher.Code,
                ExpirationDate = voucher.ExpirationDate,
                IsReferralCode = voucher.IsReferralCode,
                Metadata = voucher.Metadata,
                StartDate = voucher.StartDate,
                VoucherType = voucher.Type.ToString()
            }).ToList();

            return ResultWrapper.Success(result).IncludePagination(request.PageNumber, request.PageSize, result?.Count);
        };

        return ResultWrapper.Failure<List<VoucherResponse>>(AppConstants.StatusMessages.NotFound, AppConstants.StatusCodes.NotFound);
    }

    public async Task<IResultWrapper<VoucherResponse>> GetSpecificVoucher(GetVoucherRequest request)
    {
        var voucher = await _voucherifyImplementation.GetVoucher(request.VoucherCodeOrId);

        return voucher != null ?
            ResultWrapper.Success(new VoucherResponse()
            {
                Active = voucher.Active,
                Campaign = voucher.Campaign,
                CampaignId = voucher.CampaignId,
                Category = voucher.Category,
                Code = voucher.Code,
                ExpirationDate = voucher.ExpirationDate,
                IsReferralCode = voucher.IsReferralCode,
                Metadata = voucher.Metadata,
                StartDate = voucher.StartDate,
                VoucherType = voucher.Type.ToString()
            }) :

            ResultWrapper.Failure<VoucherResponse>(AppConstants.StatusMessages.NotFound, AppConstants.StatusCodes.NotFound);
    }
    public async Task<IResultWrapper<bool>> DeleteVoucher(DeleteVoucherRequest request)
    {
        var result = await _voucherifyImplementation.DeleteVoucher(request.VoucherCodeOrId);
        return result ? ResultWrapper.Success(result) :
            ResultWrapper.Failure<bool>(AppConstants.StatusMessages.BadRequest, AppConstants.StatusCodes.BadRequest);
    }
    public async Task<IResultWrapper<VoucherValidationResponse>> VoucherValidation(ValidateVoucherRequest request)
    {
        var customerData = new Customer()
        {
            SourceId = request.CustomerSourceId,
            Metadata = request.CustomerMetadata,
        };
        var result = await _voucherifyImplementation.ValidateVoucher(request.VoucherCode, customerData);

        return result != null ?
            ResultWrapper.Success(new VoucherValidationResponse()
            {
                IsValid = result!.Valid,
                VoucherCode = result.Code,
            }) :
            ResultWrapper.Failure<VoucherValidationResponse>(AppConstants.StatusMessages.VoucherCodeInvalid, AppConstants.StatusCodes.VoucherCodeInvalid);
    }
    public async Task<IResultWrapper<VoucherRedemptionResponse>> VoucherRedemption(RedeemVoucherRequest request)
    {
        var customerData = new CustomerCreate()
        {
            SourceId = request.Customer.SourceId,
            Address = new Address()
            {
                City = request.Customer.City,
                Country = request.Customer.Country,
                Line1 = request.Customer.AddressLine1,
                Line2 = request.Customer.AddressLine2,
                PostalCode = request.Customer.PostalCode,
                State = request.Customer.State
            }
        };
        var result = await _voucherifyImplementation.RedeemVoucher(request.VoucherCode, customerData);

        return result != null ?
            ResultWrapper.Success(new VoucherRedemptionResponse()
            {
                CustomerId = result?.Customer?.Id,
                CustomerMetadata = result?.Customer?.Metadata,
                Id = result?.Id,
                RedemptionDate = result?.Date,
                RedemptionStatus = result?.Result == RedemptionResult.Success,
                SourceId = result?.Customer?.SourceId,
                Voucher = result?.Voucher
            }) :
            ResultWrapper.Failure<VoucherRedemptionResponse>(AppConstants.StatusMessages.VoucherCodeInvalid, AppConstants.StatusCodes.VoucherCodeInvalid);
    }
}
