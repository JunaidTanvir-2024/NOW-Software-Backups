﻿using FluentValidation;

namespace Voucherify.Api.Features.Loyalties.Requests;

public class GetLoyaltyByCampaignNameRequest
{
    public string CampaignIdOrName { get; set; } = null!;
}
internal class GetLoyaltyByCampaignNameRequestValidator : AbstractValidator<GetLoyaltyByCampaignNameRequest>
{
    public GetLoyaltyByCampaignNameRequestValidator()
    {
        RuleFor(p => p.CampaignIdOrName).NotNull().NotEmpty();
    }
}
