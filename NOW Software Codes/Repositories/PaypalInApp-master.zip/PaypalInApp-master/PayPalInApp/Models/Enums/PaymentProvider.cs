﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Models.Enums
{
    public enum PaymentProvider
    {
        MIPay,
        Pay360
    }
}
