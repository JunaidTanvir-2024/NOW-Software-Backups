﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using SmsOutReachCallBackUrlApi.Contracts.Xeebi.Request;
using SmsOutReachCallBackUrlApi.Models;
using SmsOutReachCallBackUrlApi.Models.Configurations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace SmsOutReachCallBackUrlApi.Infrastructure.Xeebi
{
    public class XeebiPost : IXeebiPost
    {

        private readonly ILogger Logger;       
        private IXeebiDb Db;

        public XeebiPost(ILogger logger, IOptions<ConnectionString> connectionConfig)
        {
            Logger = logger;            
            string connectionString = connectionConfig.Value.DefaultConnection;
            Db = new XeebiDb(connectionString);
        }

        async public Task<DbResult> InsertUpdateSmsCallBackUrlData(List<XeebiSmsCallBackUrlRequest> deliveryReport)
        {

            DbResult result = null;
            try
            {

                if (deliveryReport.Count > 0)
                {
                    DataTable tbl = new DataTable();
                    tbl.Columns.Add("ApiUserName", typeof(string));
                    tbl.Columns.Add("MessageId", typeof(string));
                    tbl.Columns.Add("From", typeof(string));
                    tbl.Columns.Add("To", typeof(string));
                    tbl.Columns.Add("SubmitStatus", typeof(string));
                    tbl.Columns.Add("DeliveryStatus", typeof(string));
                    tbl.Columns.Add("SmsCount", typeof(int));
                    tbl.Columns.Add("CreatedDate", typeof(DateTime));
                    tbl.Columns.Add("SentDate", typeof(DateTime));
                    tbl.Columns.Add("DeliveredDate", typeof(DateTime));
                    tbl.Columns.Add("Cost", typeof(decimal));

                    for (int i = 0; i < deliveryReport.Count; i++)
                    {
                        DataRow row = tbl.NewRow();
                        row["ApiUserName"] = Convert.DBNull;
                        row["MessageId"] = (string.IsNullOrEmpty(deliveryReport[i].message_id)? Convert.DBNull: deliveryReport[i].message_id);
                        row["From"] = (string.IsNullOrEmpty(deliveryReport[i].from) ? Convert.DBNull : deliveryReport[i].from);
                        row["To"] = (string.IsNullOrEmpty(deliveryReport[i].to) ? Convert.DBNull : deliveryReport[i].to);
                        row["SubmitStatus"] = (string.IsNullOrEmpty(deliveryReport[i].submit_status) ? Convert.DBNull : deliveryReport[i].submit_status);
                        row["DeliveryStatus"] = (string.IsNullOrEmpty(deliveryReport[i].delivery_status) ? Convert.DBNull : deliveryReport[i].delivery_status);
                        row["SmsCount"] = deliveryReport[i].sms_count; 
                        row["CreatedDate"] = (deliveryReport[i].created_date == null ? Convert.DBNull : deliveryReport[i].created_date);
                        row["SentDate"] = (deliveryReport[i].sent_date == null ? Convert.DBNull : deliveryReport[i].sent_date);
                        row["DeliveredDate"] =  (deliveryReport[i].delivered_date == null ? Convert.DBNull : deliveryReport[i].delivered_date);
                        row["Cost"] = (string.IsNullOrEmpty(deliveryReport[i].cost) ? Convert.DBNull : deliveryReport[i].cost);
                        tbl.Rows.Add(row);
                    }


                    result = await Db.InsertUpdateSmsCallBackUrlData(tbl);

                }
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Database Insertion Error: - Class: XeebiPost, Method: InsertUpdateSmsCallBackUrlData, Parameters --> SmsCallBackUrlJson: {JsonConvert.SerializeObject(deliveryReport)}, Exception: {ex.Message}");
                result = new DbResult();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                return result;
            }
        }

    }
}
