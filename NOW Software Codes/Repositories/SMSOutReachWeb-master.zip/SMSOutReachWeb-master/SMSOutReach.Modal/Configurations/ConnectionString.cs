﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSOutReach.Model.Configurations
{
    
    public class ConnectionString
    {
        public string DefaultConnection { get; set; }
    }
}
