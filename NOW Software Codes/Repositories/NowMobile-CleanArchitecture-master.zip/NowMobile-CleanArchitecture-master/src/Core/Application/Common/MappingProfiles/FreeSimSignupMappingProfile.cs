﻿using Application.Features.Sim.FreeSim.Confirm;
using Mapster;

namespace Application.Common.MappingProfiles;

internal sealed class FreeSimSignupMappingProfile : IRegister
{
    public UserCredentials UserCredentials { get; private set; } = default!;

    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<FreeSimConfirmRequest, User>
        .NewConfig()
        
        .Map(user => user.FirstName, signupRequest => $"{signupRequest.UserInfo.FirstName}")
        .Map(user => user.LastName, signupRequest => $"{signupRequest.UserInfo.LastName}")
        .Map(user => user.Email, signupRequest => $"{signupRequest.UserInfo.Email}")
        .Map(user => user.MailSubscription, signupRequest => $"{signupRequest.UserInfo.NewsLetter}");
        
    }

    
}