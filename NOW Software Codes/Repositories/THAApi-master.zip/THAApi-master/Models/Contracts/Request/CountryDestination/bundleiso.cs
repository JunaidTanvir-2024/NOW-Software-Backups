﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request.CountryDestination
{
	public class BundleIsoRequest
	{
		public string isoCode { get; set; }
	}
}
