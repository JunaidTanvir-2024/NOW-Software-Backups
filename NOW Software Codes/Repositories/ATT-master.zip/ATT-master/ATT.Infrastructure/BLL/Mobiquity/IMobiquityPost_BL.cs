﻿using ATT.Models.Contracts;
using ATT.Models.Contracts.Mobiquity.Response;
using ATT.Models.Database;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.Mobiquity
{
    public interface IMobiquityPost_BL
    {
        Task<JsonOperatorProductResponse> MobiquityTHAGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, bool useDbRates, int? cdsp_config_id, string productCode, string productItemCode);
        Task<object> MobiquityTHATopUp(ExecuteData request);
        Task<JsonMobiquityBalanceResponse> MobiquityGetBalance();
    }
}
