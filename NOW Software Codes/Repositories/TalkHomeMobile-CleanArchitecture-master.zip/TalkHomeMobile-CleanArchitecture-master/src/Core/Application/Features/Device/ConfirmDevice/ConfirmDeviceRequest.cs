﻿namespace Application.Features.Device.ConfirmDevice;
public class ConfirmDeviceRequest : IRequest<Result<object>>
{
    public string EmailOrPhone { get; set; } = default!;
    public string DeviceId { get; set; } = default!;
    public int Otp { get; set; } = default!;
}
