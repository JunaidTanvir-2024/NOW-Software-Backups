﻿using SC.Core.Common.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Users.Requests;
public class ÚpdateAccountDetailRequest : IRequest<IResultWrapper>
{
    public string Avatar { get; set; } = default!;
    public string DateOfBirth { get; set; } = default!;
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public string FrontName { get; set; } = default!;
    public GenderEnum Gender { get; set; } = default!;

}

public class ÚpdateAccountDetailRequestValidator : AbstractValidator<ÚpdateAccountDetailRequest>
{
    public ÚpdateAccountDetailRequestValidator(IHelperService helperService)
    {
        RuleFor(x => x.DateOfBirth)
        .NotNull()
        .NotEmpty()
        .Must(helperService.BeValidDOBFormat)
        .WithMessage("Invalid date of birth date format. Use " + AppConstants.CommonAppConfig.DateFormat + " format.");
    }
}
