﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Response
{
    public class Product
    {
        public string id { get; set; }
        public IDName productType { get; set; }
        public string priceType { get; set; }
        public string name { get; set; }
        public OperatorMinMaxPrice price { get; set; }
    }
}
