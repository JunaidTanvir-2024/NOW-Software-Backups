﻿using Newtonsoft.Json;

namespace THCC.Application.Models.Dtos
{
    public class FacebookUserDto
    {
        [JsonProperty("id")]
        public string? Id { get; set; }

        [JsonProperty("first_name")]
        public string? FirstName { get; set; }

        [JsonProperty("last_name")]
        public string? LastName { get; set; }

        [JsonProperty("email")]
        public string? Email { get; set; }

        [JsonProperty("picture")]
        public FacebookPictureDto? Picture { get; set; }
    }

    public class FacebookPictureDto
    {
        [JsonProperty("data")]
        public FacebookPictureDataDto? Data { get; set; }
    }

    public class FacebookPictureDataDto
    {
        [JsonProperty("url")]
        public string? Url { get; set; }
    }
}
