﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Rewards.Requests
{
    public class GetRewards
    {
    }

}