﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransfertoOperatorListByServices
    {
        public List<Operator> operators { get; set; }
    }

    public class Operator
    {
        public int operator_id { get; set; }
        public string @operator { get; set; }
        public int country_id { get; set; }
        public string country { get; set; }
    }

   
}
