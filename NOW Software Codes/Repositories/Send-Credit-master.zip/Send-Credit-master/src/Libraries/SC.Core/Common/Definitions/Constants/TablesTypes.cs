﻿namespace SC.Core.Common.Definitions.Constants;

public static partial class AppConstants
{
    public static class TablesTypes
    {
        public const string DiscountFilterType = "dbo.discount_filter_type";
        public const string ContactPersonFilterType = "dbo.contact_person_get_filter_type";
    }
}