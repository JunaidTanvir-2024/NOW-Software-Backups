using DC.Core.Common.DependencyResolver;


namespace DC.Core.Common.Interfaces.Database;

public interface IUnitOfWork : IDisposable, ServiceType.ITransient
{
    IAppLoggerRepository AppLoggerRepository { get; }

    void BeginTransaction();

    void Commit();

    void Rollback();
}
