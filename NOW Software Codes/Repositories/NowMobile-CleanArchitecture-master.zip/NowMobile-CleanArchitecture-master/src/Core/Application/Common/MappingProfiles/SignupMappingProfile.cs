using Application.Common.Helpers;
using Application.Features.Identity.Signup.SignupConfirm;
using Application.Features.Sim.FreeSim.Confirm;
using Mapster;

namespace Application.Common.MappingProfiles;

internal sealed class SignupMappingProfile : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<SignupConfirmRequest, User>
        .NewConfig()
        .Map(user => user.FirstName, signupRequest => $"{signupRequest.UserInfo.FirstName}")
        .Map(user => user.LastName, signupRequest => $"{signupRequest.UserInfo.LastName}")
        .Map(user => user.Email, signupRequest => $"{signupRequest.UserInfo.Email}")
        .Map(user => user.MailSubscription, signupRequest => $"{signupRequest.UserInfo.NewsLetter}")
        .Map(user => user.Password, signupRequest => CryptoHelper.Hash(signupRequest.UserInfo.Password));
    }
   
}