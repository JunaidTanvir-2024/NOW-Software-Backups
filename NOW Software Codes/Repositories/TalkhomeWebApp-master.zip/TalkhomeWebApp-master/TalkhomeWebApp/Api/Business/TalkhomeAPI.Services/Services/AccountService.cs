﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MimeKit;
using Newtonsoft.Json;
using PhoneNumbers;
using Serilog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.ExtensionMethods;
using TalkhomeAPI.Infrastructure.Common.Models;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.DTOs;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Implementations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Airship;
using TalkhomeAPI.Infrastructure.Common.Services.Models.AppsFlyer;
using TalkhomeAPI.Infrastructure.Common.Services.Models.FaceBook;
using TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome;
using TalkhomeAPI.Services.Interfaces;

namespace TalkhomeAPI.Services.Services
{
	public class AccountService : IAccountService
	{
		private readonly IAccountRepository _accountRepository;
		private readonly ISmsService _smsService;
		private readonly ITalkHomeService _talkHomeService;
		private readonly IEmailService _emailService;
		private readonly ILogger _logger;
		private readonly IAirShipService _airShipService;
		private readonly IAppsFlyerService _appsFlyerService;
		private readonly IFaceBookService _facebookService;
		private readonly IConfiguration Config;
		private readonly IBundleRepository _bundleRepository;
		private readonly TalkHomeConfig _talkHomeConfig;
		private readonly SMSConfig _smsConfig;
		private readonly AccountDeleteSettings _accountDeleteSettings;

		//Types
		private const string Topup = "Topup";
		private const string BundlePurchase = "BundlePurchase";
		private const string AirTimeTransfer = "AirTimeTransfer";
		private const string InAppTransfer = "InAppTransfer";

		public AccountService(
			IAccountRepository accountRepository,
			ISmsService smsService,
			ITalkHomeService talkHomeService,
			IConfiguration config,
			IEmailService emailService,
			ILogger logger,
			IAirShipService airShipService,
			IAppsFlyerService appsFlyerService,
			IFaceBookService faceBookService,
			IOptions<SMSConfig> smsConfig,
			IOptions<TalkHomeConfig> talkHomeConfig,
			IBundleRepository bundleRepository,
			IOptions<AccountDeleteSettings> accountDeleteSettings)
		{
			_accountRepository = accountRepository;
			_smsService = smsService;
			_talkHomeService = talkHomeService;
			_emailService = emailService;
			_logger = logger;
			_airShipService = airShipService;
			_appsFlyerService = appsFlyerService;
			_facebookService = faceBookService;
			this._bundleRepository = bundleRepository;
			Config = config;
			_talkHomeConfig = talkHomeConfig.Value;
			_smsConfig = smsConfig.Value;
			_accountDeleteSettings = accountDeleteSettings.Value;
		}

		public Task<DBAccountInfo> GetAccountDetails(string Username, string pin)
		{
			return _accountRepository.GetAccountDetails(Username, pin);
		}
		public Task<bool> IsUserExist(string UserName)
		{
			return _accountRepository.IsUserExist(UserName);
		}
		public async Task<GenericApiResponse<string>> ValidateMsisdn(string msisdn)
		{
			var result = await _accountRepository.ValidateMsisdn(msisdn);
			if (result != null)
			{
				if (result.error_code == 0)
				{
					return GenericApiResponse<string>.Success(result.error_msg, result.error_msg);
				}
				else
				{
					return GenericApiResponse<string>.Failure("Your provided number is Invalid", ApiStatusCodes.InvalidNumber);
				}
			}
			return GenericApiResponse<string>.Failure("Something went wrong on server.", ApiStatusCodes.InternalServerError);
		}
		public async Task<string> ValidateUser(string msisdn)
		{
			return await _accountRepository.ValidateUser(msisdn);
		}
		public async Task<GenericApiResponse<SignUpResponseModel>> SignUp(SignUpRequestModel model)
		{
			//Check number validity
			var phoneNumberUtil = PhoneNumberUtil.GetInstance();
			PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

			bool IsValidNumber;
			try
			{
				IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

				if (IsValidNumber)
				{
					model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
						.Replace("+", "").Trim();
				}
			}
			catch
			{
				IsValidNumber = false;
			}

			if (!IsValidNumber)
			{
				return GenericApiResponse<SignUpResponseModel>.Failure(null,
										"Number is invalid", ApiStatusCodes.InvalidNumber);
			}

			//Check if user already registered
			var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
			if (accountResponse != null)
			{

				return GenericApiResponse<SignUpResponseModel>.Failure(null,
										"User is already registered", ApiStatusCodes.UserAlreadyRegistered);
			}


			model.Email = model.Email.Trim();

			GenericApiResponse<SignUpResponse> signUpResponse;

			if (_talkHomeConfig.SignUpType == SignUpType.New)
			{
				//Pre-Auth User
				var preAuthRequest = new PreAuthRequestModel()
				{
					email = model.Email,
					msisdn = model.PhoneNumber
				};

				var preAuthResponse = await _talkHomeService.PreAuth(preAuthRequest);

				if (preAuthResponse == null)
				{
					return GenericApiResponse<SignUpResponseModel>.Failure(null,
							"Something went wrong on server", ApiStatusCodes.InternalServerError);
				}

				if (preAuthResponse.errorCode > 0)
				{

					_logger.Error($"Class: AccountService, Method: PreAuth, Parameters=> " +
									$"Request: {JsonConvert.SerializeObject(preAuthRequest)}, " +
									$"Response: ${JsonConvert.SerializeObject(preAuthResponse)}");

					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Unable to register user", ApiStatusCodes.SignUpFailed);
				}

				var preAuthTokenData = preAuthResponse.payload.token_tx.Split("-");

				var eType = (EType)(Convert.ToInt32(preAuthTokenData[2]));

				string eTypeValue;
				if (eType == EType.DeviceUUID)
				{
					eTypeValue = preAuthRequest.deviceUuid;
				}
				else if (eType == EType.Email)
				{
					eTypeValue = preAuthRequest.email;
				}
				else
				{
					eTypeValue = preAuthRequest.msisdn;
				}

				string input = preAuthTokenData[0] + preAuthTokenData[1] + eTypeValue;

				string newPreAuthToken = "";

				var algo = (Algo)(Convert.ToInt32(preAuthTokenData[3]));
				if (algo == Algo.HMACSHA256)
				{
					newPreAuthToken = CommonExtentionMethods.HMACSHA256Encode(input, preAuthTokenData[4]);
				}

				//Sign-Up User
				var signUpRequest = new SignUpWithPreAuthRequest()
				{
					msisdn = model.PhoneNumber,
					appInfo = new AppInfo() { DevicePersistentID = model.IpAddress + "-" + model.PhoneNumber }
				};

				signUpResponse = await _talkHomeService.SignUpWithPreAuth(signUpRequest, newPreAuthToken);

				if (signUpResponse == null)
				{
					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Something went wrong on server", ApiStatusCodes.InternalServerError);
				}
				if (signUpResponse.errorCode > 0)
				{
					_logger.Error($"Class: AccountService, Method: SignUpWithPreAuth, Parameters=> model: " +
								$"Request: {JsonConvert.SerializeObject(signUpRequest)}, " +
								$"Response: {JsonConvert.SerializeObject(signUpResponse)}, " +
								$"ErrorMessage: Unable to register");

					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Unable to register user", ApiStatusCodes.SignUpFailed);
				}
				else if (signUpResponse.payload == null)
				{
					_logger.Error($"Class: AccountService, Method: SignUpWithPreAuth, Parameters=> model: " +
								$"Request: {JsonConvert.SerializeObject(signUpRequest)}, " +
								$"Response: {JsonConvert.SerializeObject(signUpResponse)}, " +
								$"ErrorMessage: Unable to register");

					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Unable to register user", ApiStatusCodes.SignUpFailed);
				}
				else if (!signUpResponse.payload.isPreAuthVerified)
				{
					_logger.Error($"Class: AccountService, Method: SignUpWithPreAuth, Parameters=> model: " +
								$"Request: {JsonConvert.SerializeObject(signUpRequest)}, " +
								$"Response: {JsonConvert.SerializeObject(signUpResponse)}, " +
								$"ErrorMessage: Unable to register");

					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Unable to register user", ApiStatusCodes.SignUpFailed);
				}
			}
			else
			{
				var signUpRequest = new SignUpRequest()
				{
					msisdn = model.PhoneNumber,
					appInfo = new AppInfo() { DevicePersistentID = model.IpAddress + "-" + model.PhoneNumber }
				};

				//Sign-Up User
				signUpResponse = await _talkHomeService.SignUp(signUpRequest);

				if (signUpResponse == null)
				{
					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Something went wrong on server", ApiStatusCodes.InternalServerError);
				}
				else if (signUpResponse.payload == null)
				{
					_logger.Error($"Class: AccountService, Method: SignUp, Parameters=> model: " +
													$"Request: {JsonConvert.SerializeObject(signUpRequest)}, " +
													$"Response: {JsonConvert.SerializeObject(signUpResponse)}, " +
													$"ErrorMessage: Unable to register");

					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Unable to register user", ApiStatusCodes.SignUpFailed);
				}
			}

			await _airShipService.HandleSignUpTagsAndEvents(model.PhoneNumber, model.MailSubscription);

			//Update user
			await _accountRepository.UpdateUser(new DBUser()
			{
				firstname = model.FirstName,
				lastname = model.LastName,
				email = model.Email,
				email_subscribed = model.MailSubscription,
				msisdn = model.PhoneNumber
			});

			//Generate token & Save to DB
			var token = Guid.NewGuid();
			await _accountRepository.InsertEmailVerificationToken(model.PhoneNumber, token.ToString());

			//Send email to user
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
			_emailService.SendUserRegistrationEmail(model.Email,
								model.FirstName + " " + model.LastName, token.ToString());
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed


			return GenericApiResponse<SignUpResponseModel>.Success(null, "Pin sent successfully");
		}
		public async Task<GenericApiResponse<SignUpResponseModel>> SignUpV2(SignUpRequestModel model)
		{
			//Check number validity
			var phoneNumberUtil = PhoneNumberUtil.GetInstance();
			PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

			bool IsValidNumber;
			try
			{
				IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

				if (IsValidNumber)
				{
					model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
						.Replace("+", "").Trim();
				}
			}
			catch
			{
				IsValidNumber = false;
			}

			if (!IsValidNumber)
			{
				return GenericApiResponse<SignUpResponseModel>.Failure(null,
										"Number is invalid", ApiStatusCodes.InvalidNumber);
			}


			var existingUserDeletedAccountRequest = await _accountRepository.GetDeleteAccountLogRequest(model.PhoneNumber);
			//check if user try to sign up during the deleted request submitted
			if (existingUserDeletedAccountRequest != null && existingUserDeletedAccountRequest.AccountDeleteStatus != AccountDeleteStatus.Deleted && existingUserDeletedAccountRequest.AccountDeleteStatus != AccountDeleteStatus.Cancelled && existingUserDeletedAccountRequest.AccountDeleteRequestDate != null)
			{
				return GenericApiResponse<SignUpResponseModel>.Failure("Account deletion for this number is still in progress. For more information, please contact support.", ApiStatusCodes.RecordNotFound);
			}

			//check if user try to sign up with in the cool down period of 30 days after account deleted
			if (existingUserDeletedAccountRequest != null &&
				existingUserDeletedAccountRequest.AccountDeleteStatus == AccountDeleteStatus.Deleted &&
				DateTime.UtcNow < existingUserDeletedAccountRequest?.AllowedSignUpDate)
			{
				return GenericApiResponse<SignUpResponseModel>.Failure("An account with this number was recently deleted. To continue please contact support.", ApiStatusCodes.RecordNotFound);
			}

			//Check if user already registered
			var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
			if (accountResponse != null)
			{
				return GenericApiResponse<SignUpResponseModel>.Failure(null,
										"User is already registered", ApiStatusCodes.UserAlreadyRegistered);
			}


			model.Email = model.Email.Trim();

			GenericApiResponse<SignUpResponse> signUpResponse;

			if (_talkHomeConfig.SignUpType == SignUpType.New)
			{
				//Pre-Auth User
				var preAuthUserInfoRequest = new PreAuthRequestModel()
				{
					email = model.Email,
					msisdn = model.PhoneNumber
				};

				var preAuthResponse = await _talkHomeService.PreAuth(preAuthUserInfoRequest);

				if (preAuthResponse == null)
				{
					return GenericApiResponse<SignUpResponseModel>.Failure(null,
							"Something went wrong on server", ApiStatusCodes.InternalServerError);
				}

				if (preAuthResponse.errorCode > 0)
				{

					_logger.Error($"Class: AccountService, Method: PreAuth, Parameters=> " +
									$"Request: {JsonConvert.SerializeObject(preAuthUserInfoRequest)}, " +
									$"Response: ${JsonConvert.SerializeObject(preAuthResponse)}");

					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Unable to register user", ApiStatusCodes.SignUpFailed);
				}

				var preAuthTokenData = preAuthResponse.payload.token_tx.Split("-");

				var eType = (EType)(Convert.ToInt32(preAuthTokenData[2]));

				string eTypeValue;
				if (eType == EType.DeviceUUID)
				{
					eTypeValue = preAuthUserInfoRequest.deviceUuid;
				}
				else if (eType == EType.Email)
				{
					eTypeValue = preAuthUserInfoRequest.email;
				}
				else
				{
					eTypeValue = preAuthUserInfoRequest.msisdn;
				}

				string input = preAuthTokenData[0] + preAuthTokenData[1] + eTypeValue;

				string newPreAuthToken = "";

				var algo = (Algo)(Convert.ToInt32(preAuthTokenData[3]));
				if (algo == Algo.HMACSHA256)
				{
					newPreAuthToken = CommonExtentionMethods.HMACSHA256Encode(input, preAuthTokenData[4]);
				}

				//Sign-Up User
				var signUpRequest = new SignupWithPreAuthRequestV2()
				{
					Msisdn = model.PhoneNumber,
					appInf = new AppInf(),
					AuthTx = newPreAuthToken,
					deviceInf = new DeviceInf
					{
						DevicePersistentID = model.IpAddress + "-" + model.PhoneNumber
					}
				};

				signUpResponse = await _talkHomeService.SignUpOrSignInWithPreAuth(signUpRequest, model.IpAddress);

				if (signUpResponse == null)
				{
					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Something went wrong on server", ApiStatusCodes.InternalServerError);
				}
				if (signUpResponse.errorCode > 0)
				{
					_logger.Error($"Class: AccountService, Method: SignUpWithPreAuth, Parameters=> model: " +
								$"Request: {JsonConvert.SerializeObject(signUpRequest)}, " +
								$"Response: {JsonConvert.SerializeObject(signUpResponse)}, " +
								$"ErrorMessage: Unable to register");

					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											signUpResponse.message, ApiStatusCodes.SignUpFailed);
				}
				else if (signUpResponse.payload == null)
				{
					_logger.Error($"Class: AccountService, Method: SignUpWithPreAuth, Parameters=> model: " +
								$"Request: {JsonConvert.SerializeObject(signUpRequest)}, " +
								$"Response: {JsonConvert.SerializeObject(signUpResponse)}, " +
								$"ErrorMessage: Unable to register");

					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Unable to register user", ApiStatusCodes.SignUpFailed);
				}
				else if (!signUpResponse.payload.isPreAuthVerified)
				{
					_logger.Error($"Class: AccountService, Method: SignUpWithPreAuth, Parameters=> model: " +
								$"Request: {JsonConvert.SerializeObject(signUpRequest)}, " +
								$"Response: {JsonConvert.SerializeObject(signUpResponse)}, " +
								$"ErrorMessage: Unable to register");

					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Unable to register user", ApiStatusCodes.SignUpFailed);
				}
			}
			else
			{
				var signUpRequest = new SignUpRequest()
				{
					msisdn = model.PhoneNumber,
					appInfo = new AppInfo() { DevicePersistentID = model.IpAddress + "-" + model.PhoneNumber }
				};

				//Sign-Up User
				signUpResponse = await _talkHomeService.SignUp(signUpRequest);

				if (signUpResponse == null)
				{
					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Something went wrong on server", ApiStatusCodes.InternalServerError);
				}
				else if (signUpResponse.payload == null)
				{
					_logger.Error($"Class: AccountService, Method: SignUp, Parameters=> model: " +
													$"Request: {JsonConvert.SerializeObject(signUpRequest)}, " +
													$"Response: {JsonConvert.SerializeObject(signUpResponse)}, " +
													$"ErrorMessage: Unable to register");

					return GenericApiResponse<SignUpResponseModel>.Failure(null,
											"Unable to register user", ApiStatusCodes.SignUpFailed);
				}
			}

			await _airShipService.HandleSignUpTagsAndEvents(model.PhoneNumber, model.MailSubscription);

			return GenericApiResponse<SignUpResponseModel>.Success(new SignUpResponseModel { }, "Pin sent successfully");
		}
		public async Task<GenericApiResponse<LoginResponseModel>> Login(LoginRequestModel model)
		{
			//Check number validity
			var phoneNumberUtil = PhoneNumberUtil.GetInstance();
			PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

			bool IsValidNumber;
			try
			{
				IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

				if (IsValidNumber)
				{
					model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
						.Replace("+", "").Trim();
				}
			}
			catch
			{
				IsValidNumber = false;
			}

			if (!IsValidNumber)
			{
				return GenericApiResponse<LoginResponseModel>.Failure(null,
													"Number is invalid", ApiStatusCodes.InvalidNumber);
			}


			//Get User Info
			var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
			if (accountResponse == null)
			{
				return GenericApiResponse<LoginResponseModel>.Failure(null,
												"User not registered", ApiStatusCodes.UserNotRegistered);
			}

			//Check User is active or not
			var validationResponse = await _accountRepository.ValidateUser(model.PhoneNumber);
			if (validationResponse != null)
			{
				return GenericApiResponse<LoginResponseModel>.Failure(null,
												"User not authorized", ApiStatusCodes.UserNotAuthorized);
			}

			//Get User Pin
			var pinResponse = await _accountRepository.GetPinByPhoneNumber("THA" + model.PhoneNumber);
			if (string.IsNullOrEmpty(pinResponse))
			{
				return GenericApiResponse<LoginResponseModel>.Failure(null,
												"User not authorized", ApiStatusCodes.UserNotAuthorized);
			}

			try
			{
				var smsCount = await _accountRepository.GetSMSCount(model.PhoneNumber, model.IpAddress);
				if (smsCount <= 2)
				{
					await _smsService.SendSms(Number.CountryCode, model.PhoneNumber,
												$"Welcome to TALK HOME App! Your PIN is {pinResponse.Trim()}. To manage your account online, or to top up credit, visit https://www.talkhomeapp.com");
				}
			}
			catch (Exception ex)
			{
				_logger.Error($"Class: AccountService, Method: IsValidSmsRequest-Login, Parameters=> model: " +
													 $"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}");
			}

			return GenericApiResponse<LoginResponseModel>.Success(null, "Pin sent successfully");
		}
		public async Task<GenericApiResponse<LoginResponseModel>> LoginV2(LoginRequestModel model)
		{
			//Check number validity
			var phoneNumberUtil = PhoneNumberUtil.GetInstance();
			PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

			bool IsValidNumber;
			try
			{
				IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

				if (IsValidNumber)
				{
					model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
						.Replace("+", "").Trim();
				}
			}
			catch
			{
				IsValidNumber = false;
			}

			if (!IsValidNumber)
			{
				return GenericApiResponse<LoginResponseModel>.Failure(null,
													"Number is invalid", ApiStatusCodes.InvalidNumber);
			}
			//check if user try to login in after the account deleted and with in the cool down period
			var existingUserDeletedAccountRequest = await _accountRepository.GetDeleteAccountLogRequest(model.PhoneNumber);
			if (existingUserDeletedAccountRequest != null &&
				existingUserDeletedAccountRequest.AccountDeleteStatus == AccountDeleteStatus.Deleted &&
				DateTime.UtcNow < existingUserDeletedAccountRequest?.AllowedSignUpDate)
			{
				return GenericApiResponse<LoginResponseModel>.Failure("An account with this number was recently deleted. To continue please contact support.", ApiStatusCodes.RecordNotFound);
			}

			//Check if user already registered
			var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
			if (accountResponse == null)
			{

				return GenericApiResponse<LoginResponseModel>.Failure(null,
										"User not found", ApiStatusCodes.RecordNotFound);
			}

			//Only allow existing users to login
			var isUserExist = await _accountRepository.IsUserExist($"THA{model.PhoneNumber}");
			if (!isUserExist)
			{
				return GenericApiResponse<LoginResponseModel>.Failure(null,
										"User not registered", ApiStatusCodes.UserNotRegistered);
			}
			//TODO:Pre-auth
			var userResponse = await _accountRepository.GetUserByPhoneNumber(model.PhoneNumber);
			//Pre-Auth User
			var preAuthUserInfoRequest = new PreAuthRequestModel()
			{
				email = userResponse?.email,
				msisdn = model.PhoneNumber
			};

			var preAuthResponse = await _talkHomeService.PreAuth(preAuthUserInfoRequest);

			if (preAuthResponse == null)
			{
				return GenericApiResponse<LoginResponseModel>.Failure(null,
						"Something went wrong on server", ApiStatusCodes.InternalServerError);
			}

			if (preAuthResponse.errorCode > 0)
			{

				_logger.Error($"Class: AccountService, Method: LoginV2, Parameters=> " +
								$"Request: {JsonConvert.SerializeObject(preAuthUserInfoRequest)}, " +
								$"Response: ${JsonConvert.SerializeObject(preAuthResponse)}");

				return GenericApiResponse<LoginResponseModel>.Failure(null,
										"Unable to login user", ApiStatusCodes.UnableToLogin);
			}

			var preAuthTokenData = preAuthResponse.payload.token_tx.Split("-");

			var eType = (EType)(Convert.ToInt32(preAuthTokenData[2]));

			string eTypeValue;
			if (eType == EType.DeviceUUID)
			{
				eTypeValue = preAuthUserInfoRequest.deviceUuid;
			}
			else if (eType == EType.Email)
			{
				eTypeValue = preAuthUserInfoRequest.email;
			}
			else
			{
				eTypeValue = preAuthUserInfoRequest.msisdn;
			}

			string input = preAuthTokenData[0] + preAuthTokenData[1] + eTypeValue;

			string newPreAuthToken = "";

			var algo = (Algo)(Convert.ToInt32(preAuthTokenData[3]));
			if (algo == Algo.HMACSHA256)
			{
				newPreAuthToken = CommonExtentionMethods.HMACSHA256Encode(input, preAuthTokenData[4]);
			}
			//TODO:Call preauth api
			var signupWithPreauthRequestV2 = new SignupWithPreAuthRequestV2()
			{
				Msisdn = model.PhoneNumber,
				deviceInf = new DeviceInf() { DevicePersistentID = model.IpAddress + "-" + model.PhoneNumber },
				appInf = new AppInf(),
				AuthTx = newPreAuthToken,
			};
			var signinPreAuthResponse = await _talkHomeService.SignUpOrSignInWithPreAuth(signupWithPreauthRequestV2, model.IpAddress);
			if (signinPreAuthResponse == null || signinPreAuthResponse.errorCode > 0)
			{
				return GenericApiResponse<LoginResponseModel>.Failure(null,
						signinPreAuthResponse.message, ApiStatusCodes.UnableToLogin);
			}

			return GenericApiResponse<LoginResponseModel>.Success(
				new LoginResponseModel
				{
					Msisdn = model.PhoneNumber,
					email = userResponse?.email,
					Firstname = userResponse?.firstname,
					Lastname = userResponse?.firstname
				}, "Pin sent successfully");
		}
		public async Task<GenericApiResponse<VerifyPinResponseModel>> VerifyPin(VerifyPinRequestModel model)
		{
			//Check number validity
			var phoneNumberUtil = PhoneNumberUtil.GetInstance();
			PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

			bool IsValidNumber;
			try
			{
				IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

				if (IsValidNumber)
				{
					model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
						.Replace("+", "").Trim();
				}
			}
			catch
			{
				IsValidNumber = false;
			}

			if (!IsValidNumber)
			{
				return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
										"Number is invalid", ApiStatusCodes.InvalidNumber);
			}



			//TODO:useraccoutn/login api hit




			//Get User Info
			var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
			if (accountResponse == null)
			{
				return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
												"User not registered", ApiStatusCodes.UserNotRegistered);
			}

			//Check User is active or not
			var validationResponse = await _accountRepository.ValidateUser(model.PhoneNumber);
			if (validationResponse != null)
			{
				return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
											   "User not authorized", ApiStatusCodes.UserNotAuthorized);
			}

			//Get user pin
			var pinResponse = await _accountRepository.GetPinByPhoneNumber("THA" + model.PhoneNumber);
			if (string.IsNullOrEmpty(pinResponse))
			{
				return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
												"User not authorized", ApiStatusCodes.UserNotAuthorized);
			}

			//Verify pin
			if (!model.PinNumber.Equals(pinResponse.Trim()))
			{
				return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
												"Pin is invalid", ApiStatusCodes.InvalidPinNumber);
			}

			var userResponse = await _accountRepository.GetUserByPhoneNumber(model.PhoneNumber);

			if (userResponse == null)
			{
				return GenericApiResponse<VerifyPinResponseModel>.Failure(new VerifyPinResponseModel()
				{
					User = new UserInfo()
					{
						Msisdn = model.PhoneNumber,
						Currency = accountResponse.Currency,
						AccountID = accountResponse.AccountID,
						Na_Service_Id = accountResponse.Na_Service_Id,
						ISO_Two_CountryCode = model.PhoneNumberCountryCode
					}
				}, "User details are missing", ApiStatusCodes.MissingPersonDetails);
			}

			if (string.IsNullOrEmpty(userResponse.firstname)
				|| string.IsNullOrEmpty(userResponse.lastname)
				|| string.IsNullOrEmpty(userResponse.email))
			{

				return GenericApiResponse<VerifyPinResponseModel>.Failure(new VerifyPinResponseModel()
				{
					User = new UserInfo()
					{
						Msisdn = model.PhoneNumber,
						Currency = accountResponse.Currency,
						AccountID = accountResponse.AccountID,
						Email = userResponse.email,
						IsEmailVerified = userResponse.email_verified,
						Na_Service_Id = accountResponse.Na_Service_Id,
						ISO_Two_CountryCode = model.PhoneNumberCountryCode,
						IsMailSubscription = userResponse.email_subscribed
					}
				}, "User details are missing", ApiStatusCodes.MissingPersonDetails);

			}

			return GenericApiResponse<VerifyPinResponseModel>.Success(new VerifyPinResponseModel()
			{
				User = new UserInfo()
				{
					Msisdn = userResponse.msisdn,
					Currency = accountResponse.Currency,
					AccountID = accountResponse.AccountID,
					Email = userResponse.email,
					IsEmailVerified = userResponse.email_verified,
					Na_Service_Id = accountResponse.Na_Service_Id,
					ISO_Two_CountryCode = model.PhoneNumberCountryCode,
					IsMailSubscription = userResponse.email_subscribed
				}
			}, "logged-in successfully");
		}
		public async Task<GenericApiResponse<VerifyPinResponseModel>> VerifyPinV2(VerifyPinRequestModel model)
		{
			//Check number validity
			var phoneNumberUtil = PhoneNumberUtil.GetInstance();
			PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

			bool IsValidNumber;
			try
			{
				IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

				if (IsValidNumber)
				{
					model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
						.Replace("+", "").Trim();
				}
			}
			catch
			{
				IsValidNumber = false;
			}

			if (!IsValidNumber)
			{
				return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
										"Number is invalid", ApiStatusCodes.InvalidNumber);
			}

			//TODO:useraccoutn/login api hit
			var loginRequest = new LoginRequest
			{
				AppInfo = new AppInfo
				{
					DevicePersistentID = model.IpAddress + "-" + model.PhoneNumber
				}
			};
			var response = await _talkHomeService.VerifyPin(loginRequest, model.PhoneNumber, model.PinNumber, model.IpAddress);
			if (response == null || response.errorCode > 0)
			{
				_logger.Information($"Class:AccountService, Method:VerifyPinV2, Msisdn:{model.PhoneNumber}, Response:{JsonConvert.SerializeObject(response)}");
				return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
						"Pin is invalid", ApiStatusCodes.InvalidPinNumber);
			}
			//
			//Get User Info
			var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
			if (accountResponse == null)
			{
				return GenericApiResponse<VerifyPinResponseModel>.Failure(null,
												"User not registered", ApiStatusCodes.UserNotRegistered);
			}
			if (model.SignupRequest != null)
			{
				//Update user
				await _accountRepository.UpdateUser(new DBUser()
				{
					firstname = model.SignupRequest.FirstName,
					lastname = model.SignupRequest.LastName,
					email = model.SignupRequest.Email,
					email_subscribed = model.SignupRequest.MailSubscription,
					msisdn = model.PhoneNumber
				});
				//Generate token & Save to DB
				var token = Guid.NewGuid();
				await _accountRepository.InsertEmailVerificationToken(model.PhoneNumber, token.ToString());

				//Send email to user
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
				_emailService.SendUserRegistrationEmail(model.SignupRequest.Email,
									model.SignupRequest.FirstName + " " + model.SignupRequest.LastName, token.ToString());
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed


			}

			var userResponse = await _accountRepository.GetUserByPhoneNumber(model.PhoneNumber);

			if (userResponse == null)
			{
				return GenericApiResponse<VerifyPinResponseModel>.Failure(new VerifyPinResponseModel()
				{
					User = new UserInfo()
					{
						Msisdn = model.PhoneNumber,
						Currency = accountResponse.Currency,
						AccountID = accountResponse.AccountID,
						Na_Service_Id = accountResponse.Na_Service_Id,
						ISO_Two_CountryCode = model.PhoneNumberCountryCode
					}
				}, "User details are missing", ApiStatusCodes.MissingPersonDetails);
			}

			if (string.IsNullOrEmpty(userResponse.firstname)
				|| string.IsNullOrEmpty(userResponse.lastname)
				|| string.IsNullOrEmpty(userResponse.email))
			{

				return GenericApiResponse<VerifyPinResponseModel>.Failure(new VerifyPinResponseModel()
				{
					User = new UserInfo()
					{
						Msisdn = model.PhoneNumber,
						Currency = accountResponse.Currency,
						AccountID = accountResponse.AccountID,
						Email = userResponse.email,
						IsEmailVerified = userResponse.email_verified,
						Na_Service_Id = accountResponse.Na_Service_Id,
						ISO_Two_CountryCode = model.PhoneNumberCountryCode,
						IsMailSubscription = userResponse.email_subscribed
					}
				}, "User details are missing", ApiStatusCodes.MissingPersonDetails);

			}
			//
			return GenericApiResponse<VerifyPinResponseModel>.Success(new VerifyPinResponseModel()
			{
				User = new UserInfo()
				{
					Msisdn = response.payload.Msisdn,
					Currency = accountResponse.Currency,
					AccountID = response.payload.AccountID,
					Email = userResponse.email,
					IsEmailVerified = userResponse.email_verified,
					Na_Service_Id = accountResponse.Na_Service_Id,
					ISO_Two_CountryCode = model.PhoneNumberCountryCode,
					IsMailSubscription = userResponse.email_subscribed
				}
			}, "logged-in successfully");
		}
		public async Task<GenericApiResponse<ReSendPinResponseModel>> ReSendPin(ReSendPinRequestModel model)
		{
			//Check number validity
			var phoneNumberUtil = PhoneNumberUtil.GetInstance();
			PhoneNumber Number = phoneNumberUtil.Parse(model.PhoneNumber, model.PhoneNumberCountryCode);

			bool IsValidNumber;
			try
			{
				IsValidNumber = phoneNumberUtil.IsValidNumber(Number);

				if (IsValidNumber)
				{
					model.PhoneNumber = phoneNumberUtil.Format(Number, PhoneNumberFormat.E164)
						.Replace("+", "").Trim();
				}
			}
			catch
			{
				IsValidNumber = false;
			}

			if (!IsValidNumber)
			{
				return GenericApiResponse<ReSendPinResponseModel>.Failure(null,
					"Number is invalid", ApiStatusCodes.InvalidNumber);
			}

			//Get user details
			//var userResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + model.PhoneNumber);
			//if (userResponse == null)
			//{
			//	return GenericApiResponse<ReSendPinResponseModel>.Failure(null,
			//				"User is not registerd", ApiStatusCodes.UserNotRegistered);
			//}

			//Send pin
			var pinResponse = await _accountRepository.GetPinByPhoneNumber("THA" + model.PhoneNumber);
			if (string.IsNullOrEmpty(pinResponse))
			{
				return GenericApiResponse<ReSendPinResponseModel>.Failure(null,
													"User not authorized", ApiStatusCodes.UserNotAuthorized);
			}

			try
			{
				var smsCount = await _accountRepository.GetSMSCount(model.PhoneNumber, model.IpAddress);
				if (smsCount <= 2)
				{
					await _smsService.SendSms(Number.CountryCode, model.PhoneNumber,
							   $"Welcome to TALK HOME App! Your PIN is {pinResponse.Trim()}. To manage your account online, or to top up credit, visit https://www.talkhomeapp.com"); ;
				}
			}
			catch (Exception ex)
			{
				_logger.Error($"Class: AccountService, Method: ReSendPin, Parameters=> model: " +
											$"{JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}");
			}

			return GenericApiResponse<ReSendPinResponseModel>.Success(null, "Pin sent successfully");


		}
		public async Task<GenericApiResponse<VerifyEmailResponseModel>> VerifyEmail(VerifyEmailRequestModel model)
		{
			var verificationResponse = await _accountRepository.VerifyEmail(model.Token);
			if (verificationResponse == 0)
			{
				var userResponse = await _accountRepository.GetUserInfoByEmailToken(model.Token);

				var builder = new BodyBuilder();
				using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\email-successful-verification.html").Replace("~\\", ""))))
				{
					builder.HtmlBody = SourceReader.ReadToEnd();
				}

				string messageBody = builder.HtmlBody
					.Replace("%FIRST_NAME%", userResponse.firstname);

				await _emailService.SendEmail(userResponse.email, messageBody, true, "Email Verification Successful");

				try
				{
					#region Airship

					if (_airShipService.IsActive)
					{
						await _airShipService.AddEmailChannelCommercial(userResponse.email);

						//Associate email with named user
						await _airShipService.EmailAssociationWithNamedUser(userResponse.msisdn, userResponse.email);

						await _airShipService.AddCustomEvent(new CustomEventsRequest()
						{
							ProductCode = "THA",
							ChannelIdentifier = CEventChannelIdentifier.named_user_id,
							ChannelIdentifierValue = userResponse.msisdn,
							CustomEventName = $"email_verified_web"
						});
					}

					#endregion

					#region Facebook Events

					await _facebookService.CreateCustomEvent(userResponse.msisdn, new List<EventDetailsModel>
					{
						new EventDetailsModel
						{
						_eventName = $"email_verified_web"
						}
					});

					#endregion

					#region appflyer

					await _appsFlyerService.CreateCustomEvent(new List<CreateEventRequestModel> {
					new CreateEventRequestModel
					{
						customerUserId=userResponse.msisdn,
						eventName="email_verified_web"
					}
					});

					await _appsFlyerService.CreateCustomEvent(
						   new List<CreateEventRequestModel>
						   {
								new CreateEventRequestModel
								{
									customerUserId = userResponse.msisdn,
									eventName = $"email_verified_web",
								}
						   });

					#endregion

				}
				catch (Exception ex)
				{
					_logger.Error($"Class: AccountService, Method: VerifyEmail-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
				}

				return GenericApiResponse<VerifyEmailResponseModel>.Success(null,
					"Email verified successfully");
			}
			else
			{
				return GenericApiResponse<VerifyEmailResponseModel>.Failure(null,
					"Token is invalid", ApiStatusCodes.InvalidToken);
			}
		}
		public async Task<GenericApiResponse<ReSendEmailVerificationResponse>> ReSendEmailVerificationLink(string msisdn)
		{
			//Check if user already registered
			var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);
			if (userResponse == null)
			{

				return GenericApiResponse<ReSendEmailVerificationResponse>.Failure(null,
										"User is not registered", ApiStatusCodes.UserNotRegistered);
			}

			if (userResponse.email_verified)
			{
				return GenericApiResponse<ReSendEmailVerificationResponse>.Failure(null,
										"Email is already verified", ApiStatusCodes.EmailAlreadyVerified);
			}


			string token;

			//Get token if exists 
			var tokenInfo = await _accountRepository.GetEmailVerificationToken(msisdn);
			if (!string.IsNullOrEmpty(tokenInfo))
			{
				token = tokenInfo;
			}
			else
			{
				//Generate token & Save to DB
				var newToken = Guid.NewGuid();
				token = newToken.ToString();

				await _accountRepository.InsertEmailVerificationToken(msisdn, token);
			}

			//Send email to user
			if (!string.IsNullOrEmpty(userResponse.firstname))
			{
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
				_emailService.SendUserRegistrationEmail(userResponse.email,
							userResponse.firstname + " " + userResponse.lastname, token);
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
			}
			else
			{
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
				_emailService.SendUserRegistrationEmail(userResponse.email, msisdn, token);
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
			}

			return GenericApiResponse<ReSendEmailVerificationResponse>.Success(null, "Token generated successfully");
		}
		public async Task<GenericApiResponse<GetAccountDetailsResponseModel>> GetAccountDetails(string msisdn)
		{
			var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
			var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);
			var pinResponse = await _accountRepository.GetPinByPhoneNumber("THA" + msisdn);


			var response = new GetAccountDetailsResponseModel()
			{
				Balance = accountResponse.Balance,
				Pin = CommonExtentionMethods.EncryptString("b14ca5898a4e4133bbce2ea2315a1916", pinResponse.Trim())
			};

			if (userResponse != null)
			{
				response.FirstName = userResponse.firstname;
				response.LastName = userResponse.lastname;
				response.Email = userResponse.email;
				response.IsEmailVerified = userResponse.email_verified;
				response.EmailSubscription = userResponse.email_subscribed;
				response.DayOfBirth = userResponse.dayOfBirth;
				response.MonthOfBirth = userResponse.monthOfBirth;
			}

			return GenericApiResponse<GetAccountDetailsResponseModel>.Success(response, "User details found successfully");
		}
		public async Task<GenericApiResponse<UpdateMissingDetailsResponseModel>> UpdateMissingDetails(
			UpdateMissingDetailsRequestModel model,
			string msisdn)
		{
			//Update data
			await _accountRepository.UpdateUser(new DBUser()
			{
				firstname = model.FirstName,
				lastname = model.LastName,
				email = model.Email,
				email_subscribed = model.EmailSubscription,
				msisdn = msisdn
			});

			var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);

			if (!userResponse.email_verified)
			{
				string token;

				//Get token if exists 
				var tokenInfo = await _accountRepository.GetEmailVerificationToken(msisdn);
				if (!string.IsNullOrEmpty(tokenInfo))
				{
					token = tokenInfo;
				}
				else
				{
					//Generate token & Save to DB
					var newToken = Guid.NewGuid();
					token = newToken.ToString();

					await _accountRepository.InsertEmailVerificationToken(userResponse.msisdn, token);
				}

				//Send email to user
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
				_emailService.SendUserRegistrationEmail(model.Email,
									model.FirstName + " " + model.LastName, token.ToString());
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
			}

			await _airShipService.HandleMailTagsAndEvents(msisdn, model.EmailSubscription);

			return GenericApiResponse<UpdateMissingDetailsResponseModel>.Success(null,
															"User details updated successfully");
		}
		public async Task<GenericApiResponse<UpdateAccountDetailsResponseModel>> UpdateAccountDetails(
			UpdateAccountDetailsRequestModel model,
			string msisdn)
		{
			var userOldDataResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);

			var response = await _accountRepository.UpdateAccountDetails(new DBUser()
			{
				msisdn = msisdn,
				dayOfBirth = model.DayOfBirth,
				monthOfBirth = model.MonthOfBirth,
				firstname = model.FirstName,
				lastname = model.LastName,
				email = model.Email,
				email_subscribed = model.EmailSubscription
			});

			if (response > 0)
			{
				var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);

				if (!userResponse.email_verified)
				{
					string token;

					//Get token if exists 
					var tokenInfo = await _accountRepository.GetEmailVerificationToken(msisdn);
					if (!string.IsNullOrEmpty(tokenInfo))
					{
						token = tokenInfo;
					}
					else
					{
						//Generate token & Save to DB
						var newToken = Guid.NewGuid();
						token = newToken.ToString();

						await _accountRepository.InsertEmailVerificationToken(userResponse.msisdn, token);
					}

					//Send email to user
#pragma warning disable CS4014
					_emailService.SendUserRegistrationEmail(userResponse.email,
														userResponse.firstname + " " + userResponse.lastname, token.ToString());
#pragma warning restore CS4014
				}

				#region Airship
				try
				{
					if (_airShipService.IsActive)
					{
#pragma warning disable CS4014

						//remove previous email channel from current user (beacuse user email is changed)
						if (!userOldDataResponse.email.Equals(userResponse.email))
						{
							_airShipService.RemoveEmailChannelCommercial(userResponse.email);
							_airShipService.DisassociateEmailChannelFromNamedUser(userOldDataResponse.msisdn, userOldDataResponse.email);
						}

						// Register + Removal of commercial emails
						if (userResponse.email_verified && userResponse.email_subscribed)
						{
							_airShipService.AddEmailChannelCommercial(userResponse.email);
						}
						else if (userResponse.email_verified && !userResponse.email_subscribed)
						{
							_airShipService.RemoveEmailChannelCommercial(userResponse.email);
						}

						_airShipService.AddNamedUserTags(new NamedUserTagsRequest()
						{
							NamedUser = userOldDataResponse.msisdn,
							ProductCode = "THA",
							TagGroup = _airShipService.ActivityTagGroupName,
							Tags = new List<string>() { "birthday" }
						});

						await _airShipService.HandleMailTagsAndEvents(msisdn, model.EmailSubscription);
					}
#pragma warning restore CS4014
				}
				catch (Exception ex)
				{
					_logger.Error($"Class: AccountService, Method: UpdateAccountDetails-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
				}
				#endregion

				return GenericApiResponse<UpdateAccountDetailsResponseModel>.Success(new UpdateAccountDetailsResponseModel()
				{
					IsEmailVerified = userResponse.email_verified
				}, "User details updated successfully");
			}
			else
			{
				return GenericApiResponse<UpdateAccountDetailsResponseModel>.Failure(
					null, ApiStatusCodes.RecordNotFound);
			}
		}
		public async Task<GenericApiResponse<CallHistoryResponseModel>> GetCallingHistory(string accountNumber)
		{
			var result = await _accountRepository.GetCallingHistory(accountNumber);

			return GenericApiResponse<CallHistoryResponseModel>.Success(
				new CallHistoryResponseModel()
				{
					CallHistory = result
				}, result.Count() > 0 ? "Found calling history" : "calling history not found");

		}
		public async Task<GenericApiResponse<List<EntirePaymentHistory>>> GetEntirePaymentHistory(string account, string msisdn)
		{
			var payload = new List<EntirePaymentHistory>();

			var paymentHistories = await _accountRepository.GetEntirePaymentHistory(msisdn, account);
			var bundleDetails = await _bundleRepository.GetBundleDetailsByIds(paymentHistories.Where(e => e.Type == BundlePurchase && e.BundleId != null).Select(e => e.BundleId).Distinct().ToList());
			paymentHistories.ForEach(x =>
			{
				if (x.Type == Topup)
				{
					payload.Add(
						new EntirePaymentHistory()
						{
							Amount = x.Db == "account" ? x.Amount / 100 : x.Amount,
							Successfull = x.Db == "account" ? true : x.IsSuccess,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Type = x.Type,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A"
						});
				}
				else if (x.Type == InAppTransfer)
				{
					payload.Add(
						new EntirePaymentHistory()
						{
							Amount = x.Amount / 100,
							Successfull = true,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A",
							Type = x.Type,
							Msisdn = x.Msisdn
						});
				}
				else if (x.Type == AirTimeTransfer)
				{
					payload.Add(
						new EntirePaymentHistory()
						{
							Amount = x.Amount,
							Successfull = x.IsSuccess,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A",
							Type = x.Type,
							Msisdn = x.Msisdn
						});
				}
				else if (x.Type == BundlePurchase)
				{
					var details = bundleDetails.FirstOrDefault(e => e.Id == Guid.Parse(x.BundleId));
					payload.Add(
						new EntirePaymentHistory()
						{
							Amount = x.Amount,
							Successfull = x.IsSuccess,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A",
							Type = x.Type,
							BundleName = !string.IsNullOrEmpty(details?.DisplayName) ? details.DisplayName : "N/A",
							BundleId = x.BundleId,
							BundleCategory = (int)(details?.Category ?? BundleCategory.Platinum),
							BundleCategoryName = (details?.Category ?? BundleCategory.Platinum).ToString(),
							BundleType = (int)(details?.Type ?? BundleType.PAYG),
							BundleTypeName = (details?.Type ?? BundleType.PAYG).ToString()
						});
				}
			});

			return GenericApiResponse<List<EntirePaymentHistory>>.Success(payload, payload.Count > 0 ? "History found successfully" : "History not found");
		}
		public async Task<GenericApiResponse<GetTopUpPaymentHistoryResponseModel>> GetTopUpPaymentHistory(string accountNumber)
		{
			var result = await _accountRepository.GetTopUpPaymentHistory(accountNumber);

			return GenericApiResponse<GetTopUpPaymentHistoryResponseModel>.Success(
						  new GetTopUpPaymentHistoryResponseModel()
						  {
							  TopUpHistory = result
						  }, result.Count() > 0 ? "Found topup history" : "TopUp history not found");

		}
		public async Task<GenericApiResponse<GetInternationalTopUpHistoryResponseModel>> GetInternationalTopUpHistory(string accountNumber)
		{
			var result = await _accountRepository.GetInternationalTopUpHistory(accountNumber);
			return GenericApiResponse<GetInternationalTopUpHistoryResponseModel>.Success(
						  new GetInternationalTopUpHistoryResponseModel()
						  {
							  TopUpHistory = result
						  }, result.Count() > 0 ? "Found topup history" : "TopUp history not found");

		}
		public async Task<GenericApiResponse<bool>> IsEmailAlreadyExists(IsEmailAlreadyExistsRequestModel model)
		{
			return GenericApiResponse<bool>.Success(await _accountRepository.IsEmailAlreadyExists(model.Email), "Sucess");
		}
		public async Task<GenericApiResponse<GetBundlesHistoryResponseModel>> GetBundlesHistory(string accountNumber)
		{
			var result = await _accountRepository.GetBundlesHistory(accountNumber);

			return GenericApiResponse<GetBundlesHistoryResponseModel>.Success(
						  new GetBundlesHistoryResponseModel()
						  {
							  BundlesHistory = result
						  }, result.Count() > 0 ? "Found Bundles history" : "Bundles history not found");
		}
		public async Task<GenericApiResponse<bool>> IsMsisdnRegistered(IsMsisdnRegisteredRequestModel request)
		{

			var msisdn = request.Msisdn.StartsWith("+") ? request.Msisdn.Replace("+", "").Trim() : request.Msisdn;
			msisdn = request.Msisdn.StartsWith("00") ? request.Msisdn.Replace("00", "").Trim() : request.Msisdn;

			bool IsValidNumber;
			try
			{   //Check number validity
				var phoneNumberUtil = PhoneNumberUtil.GetInstance();
				PhoneNumber Number = phoneNumberUtil.Parse("+" + msisdn, "");

				IsValidNumber = phoneNumberUtil.IsValidNumber(Number);
			}
			catch
			{
				IsValidNumber = false;
			}

			if (!IsValidNumber)
			{
				return GenericApiResponse<bool>.Failure(false, "Number is invalid", ApiStatusCodes.InvalidNumber);
			}

			//Check if user already registered
			var validationResponse = await _accountRepository.ValidateMsisdn(msisdn);
			if (validationResponse == null)
				return GenericApiResponse<bool>.Failure(false, "Number is invalid", ApiStatusCodes.InvalidNumber);

			if (validationResponse.error_code != 0)
				return GenericApiResponse<bool>.Failure(false, "Number is invalid", errorCode: ApiStatusCodes.InvalidNumber);

			//Don't allow if user have a delete account request with pending status
			var deletedLogRequest = await _accountRepository.GetDeleteAccountLogRequest(msisdn);
			if (deletedLogRequest != null && deletedLogRequest.AccountDeleteStatus != AccountDeleteStatus.Deleted && deletedLogRequest.AccountDeleteStatus!=AccountDeleteStatus.Cancelled)
			{
				return GenericApiResponse<bool>.Failure(false, "Number is invalid", errorCode: ApiStatusCodes.InvalidNumber);
			}

			return GenericApiResponse<bool>.Success(true, "Number is valid");
		}
		public async Task<GenericApiResponse<GetAccountDetailsByMsisdnResponseModel>> GetAccountDetailsByMsisdn(GetAccountDetailsByMsisdnRequestModel request)
		{
			var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + request.Msisdn);

			if (accountResponse == null)
			{
				return GenericApiResponse<GetAccountDetailsByMsisdnResponseModel>.Failure(null, "Number is invalid", ApiStatusCodes.InvalidNumber);
			}


			var userResponse = await _accountRepository.GetUserByPhoneNumber(request.Msisdn);


			var response = new GetAccountDetailsByMsisdnResponseModel()
			{
				Currency = accountResponse.Currency,
				EmailAddress = userResponse != null && !string.IsNullOrEmpty(userResponse.email) ? userResponse.email.Trim() : null
			};

			return GenericApiResponse<GetAccountDetailsByMsisdnResponseModel>.Success(response, "User details found successfully");
		}
		public async Task<GenericApiResponse<RSS>> GetPromotions(string msisdn)
		{
			GenericApiResponse<RSS> gr = new GenericApiResponse<RSS>();

			try
			{
				var cls = new HttpClient()
				{
					BaseAddress = new Uri(Config["ATTConfig:ApiEndpoint"])
				};
				cls.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
				cls.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");

				var result = await cls.GetAsync("DtOneGetPromotions");

				if (result.IsSuccessStatusCode)
				{

					var rssResult = JsonConvert.DeserializeObject<GenericApiResponse<RSSResult>>(await result.Content.ReadAsStringAsync());
					var rss = rssResult.payload.result;

					var rssResults = await _accountRepository.GetPromotionAlerts(msisdn);

					var rssCountry = rss.country;
					var rssAlerts = rssResults.payload;


					var leftOuterQuery = from country in rssCountry
										 join countryAlerts in rssAlerts on country.countryId equals countryAlerts.countryId into countryGroup
										 select countryGroup.DefaultIfEmpty(new PromotionCountry() { countryId = country.countryId, countryName = country.countryName, status = country.status });


					var x = leftOuterQuery.ToList();

					rss.country = x.SelectMany(d => d).ToList();
					rss.defaultCountry = new PromotionCountry { countryId = "661", countryName = "Afghanistan" };
					//var itm = (from it in rss.channel.item orderby it.countryName ascending select it).ToList();                    
					rss.channel.item = rss.channel.item.OrderBy(itt => itt.countryName).ToList();
					try
					{
						if (Config["ATTConfig:only_dtOne_promotions"] == "0")
						{

							var clientNew = new HttpClient()
							{
								BaseAddress = new Uri(Config["ATTConfig:ApiEndpoint"])
							};
							cls.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
							cls.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");

							var dingResult = await clientNew.GetAsync($"Ding/DingGetPromotions?fromMSISDN={msisdn}");

							if (dingResult.IsSuccessStatusCode)
							{
								var dingPromotions = JsonConvert.DeserializeObject<DingPromoResponse>(await dingResult.Content.ReadAsStringAsync());

								if (dingPromotions.payload != null)
								{
									var dingCountries = dingPromotions.payload.dingCountries;
									rss.channel.item.RemoveAll(r => dingCountries.Contains(r.countryName));

									//Create Country if not exists in countries list
									var existingCountries = rss.country.Select(s => s.countryName).ToList();
									var dingCountriesWithPromoNotInList = dingPromotions.payload.item.Where(s => !existingCountries.Contains(s.countryName)).Select(s => s.countryName).Distinct().ToList();

									var maxCountryId = Int32.Parse(rss.country.Max(s => s.countryId));

									foreach (var dingCountry in dingCountriesWithPromoNotInList)
									{
										maxCountryId++;
										rss.country.Add(new PromotionCountry { countryId = maxCountryId.ToString(CultureInfo.InvariantCulture), countryName = dingCountry });
									}

									rss.country = rss.country.OrderBy(s => s.countryName).ToList();

									dingPromotions.payload.item.ForEach(xx => xx.countryId = (rss.country.FirstOrDefault(s => s.countryName == xx.countryName)?.countryId));
									rss.channel.item.AddRange(dingPromotions.payload.item);

								}
							}

						}
					}
					catch (Exception ex)
					{
						_logger.Error($"Failed to get Promotions from ATT API :" + ex.Message);
					}
					gr.status = "Success";
					gr.message = "Success";
					gr.payload = rss;
				}
				return gr;
			}
			catch (Exception ex)
			{
				gr.status = "Failure";
				gr.message = "Failure";

				_logger.Error($"Failed to get Promotions from ATT API :" + ex.Message);
			}
			return gr;
		}
		public async Task<GenericApiResponse<bool>> SetPromotions(string msisdn, Promotion promotion)
		{
			try
			{
				return await _accountRepository.SetPromotions(msisdn, promotion);
			}
			catch (Exception)
			{
				_logger.Error($"Failed to Set Promotions from ATT API");
				return null;
			}

		}

		/// <summary>
		/// This method will call the talkhome api endpoint to create the delete account request in the database
		/// </summary>
		/// <param name="model"></param>
		/// <returns></returns>
		public async Task<GenericApiResponse<bool>> CreateDeleteAccountRequest(DeleteAccountLogRequest model)
		{
			//getting the user information to extract the registeration date
			var userInfo = await _accountRepository.GetUserByPhoneNumber(model.Msisdn);
			if (userInfo == null)
			{
				return GenericApiResponse<bool>.Failure("Account couldn't be found.", ApiStatusCodes.RecordNotFound);
			}

			model.AccountActivationDate = userInfo.registration_date;

			var signUpAllowedAfterDays = _accountDeleteSettings.SignUpAllowedAfterDays;
			model.AllowedSignUpDate = DateTime.UtcNow.AddDays(signUpAllowedAfterDays);

			var response = await _accountRepository.CreateDeleteAccountRequest(model);
			if (response == 1)
			{
				if (!string.IsNullOrEmpty(userInfo.email))//email will be sent to the user for the account delete request
				{
					await SendDeleteAccountEmail(userInfo);
				}
				return GenericApiResponse<bool>.Success(true, "Account delete request logged successfully!");
			}
			return GenericApiResponse<bool>.Failure(false,
					"Account delete request couldn't be logged. Please contact customer support service.", ApiStatusCodes.AccountDeleteLogRequestFailed);

		}
		public async Task<GenericApiResponse<List<DeleteAccountReasonResponseModel>>> GetDeleteAccountReasons()
		{
			var deleteAccountReasons = await _accountRepository.GetDeleteAccountReasons();
			if (deleteAccountReasons.Any())
			{
				return GenericApiResponse<List<DeleteAccountReasonResponseModel>>.Success(deleteAccountReasons, "Delete account reasons found");
			}
			return GenericApiResponse<List<DeleteAccountReasonResponseModel>>.Failure(new List<DeleteAccountReasonResponseModel>(),
		"Delete account reasons not found", ApiStatusCodes.RecordNotFound);

		}
		private async Task SendDeleteAccountEmail(DBUser userProfile)
		{
			try
			{
				if (!userProfile.email_verified)
					return;
				var builder = new BodyBuilder();
				using (StreamReader SourceReader = System.IO.File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\Delete-Account.html").Replace("~\\", ""))))
				{
					builder.HtmlBody = SourceReader.ReadToEnd();
				}

				string messageBody = builder.HtmlBody
					.Replace("%FIRST_NAME%", userProfile?.firstname);

				await _emailService.SendEmail(userProfile.email, messageBody, true, "Account delete request");
			}
			catch (Exception ex)
			{

				string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);

				_logger.Error($"Class: AccountService, Method: SendDeleteAccountEmail, " +
				   $"Parameters:userProfile: {JsonConvert.SerializeObject(userProfile)}, " +
				   $"ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
			}
		}
		/// <summary>
		/// This method will call the talkhome api to verify the sent code on sms and email
		/// </summary>
		/// <param name="model"></param>
		/// <returns></returns>
		public async Task<GenericApiResponse<bool>> VerifyPinCode(PinVerificationCodeRequestModel model)
		{
			//Send pin
			var pinResponse = await _accountRepository.GetPinByPhoneNumber("THA" + model.PhoneNumber);
			if (string.IsNullOrEmpty(pinResponse))
			{
				return GenericApiResponse<bool>.Failure(false,
													"User not authorized", ApiStatusCodes.UserNotAuthorized);
			}
			if (pinResponse.Trim().Equals(model.PinCode))
			{
				return GenericApiResponse<bool>.Success(true, "Pin is valid");
			}
			return GenericApiResponse<bool>.Failure(false, "Pin is in-valid", ApiStatusCodes.InvalidPinNumber);
		}
		/// <summary>
		/// This method will return true/false if the user has requested for delete account
		/// </summary>
		/// <param name="msisdn"></param>
		/// <returns></returns>
		public async Task<GenericApiResponse<bool>> IsAccountDeleteRequestInProgress(string msisdn)
		{
			var existingUserDeletedAccountRequest = await _accountRepository.GetDeleteAccountLogRequest(msisdn);
			//check if user try to sign up during the deleted request submitted
			if (existingUserDeletedAccountRequest != null && existingUserDeletedAccountRequest.AccountDeleteStatus != AccountDeleteStatus.Deleted && existingUserDeletedAccountRequest.AccountDeleteStatus != AccountDeleteStatus.Cancelled && existingUserDeletedAccountRequest.AccountDeleteRequestDate != null)
			{
				return GenericApiResponse<bool>.Success(true, "Account deletion for this number is still in progress. For more information, please contact support.");
			}
			return GenericApiResponse<bool>.Failure(false, "Request not found", ApiStatusCodes.RecordNotFound);
		}
	}
}
