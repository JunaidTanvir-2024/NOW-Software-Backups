﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using PaymentsApi.Infrastructure.BLL.Interfaces.Pay360;
using PaymentsApi.Infrastructure.Services.Interfaces;
using PaymentsApi.Models.Configurations;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using System.Linq;

namespace PaymentsApi.Infrastructure.BLL.Implementation.Pay360
{
    public class Pay360Auth : IPay360Auth
    {
        private readonly Pay360Config _pay360Config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IPhoneNumberService _phoneNumberService;

        public Pay360Auth(
            IOptions<Pay360Config> options,
            IHttpContextAccessor httpContextAccessor,
            IPhoneNumberService phoneNumberService)
        {
            _pay360Config = options.Value;
            _httpContextAccessor = httpContextAccessor;
            _phoneNumberService = phoneNumberService;
        }


        public Pay360Creds GetApiCredsByProductCodeAndProductRef(string productRef, string productCode, string paymentType)
        {
            if (!string.IsNullOrEmpty(productCode) && _pay360Config.Pay60CountryAccountConfig.Any(
                    x => x.ProductCode.Equals(productCode, System.StringComparison.InvariantCultureIgnoreCase)
                            && x.PaymentType.Equals(paymentType, System.StringComparison.InvariantCultureIgnoreCase)))
            {
                var creds = new Pay360Creds()
                {
                    ApiUserName = _pay360Config.ApiUserName,
                    ApiPassword = _pay360Config.ApiPassword,
                    ApiInstallationIdCashierApi = _pay360Config.ApiInstallationIdCashierApi
                };
                if (!string.IsNullOrEmpty(productRef))
                {
                    var coutryCode = _phoneNumberService.GetCountryISOCode(productRef);
                    if (coutryCode != null)
                    {
                        var accountConfig = _pay360Config.Pay60CountryAccountConfig.Find(x =>
                                x.CountryCode.Equals(coutryCode, System.StringComparison.InvariantCultureIgnoreCase)
                                    && x.ProductCode.Equals(productCode, System.StringComparison.InvariantCultureIgnoreCase)
                                    && x.PaymentType.Equals(paymentType, System.StringComparison.InvariantCultureIgnoreCase));
                        if (accountConfig != null)
                        {
                            creds.ApiUserName = accountConfig.ApiUserName;
                            creds.ApiPassword = accountConfig.ApiPassword;
                            creds.ApiInstallationIdCashierApi = accountConfig.ApiInstallationIdCashierApi;
                        }
                    }
                }
                return creds;
            }
            else
            {
                return new Pay360Creds()
                {
                    ApiUserName = _pay360Config.ApiUserName,
                    ApiPassword = _pay360Config.ApiPassword,
                    ApiInstallationIdCashierApi = _pay360Config.ApiInstallationIdCashierApi
                };
            }
        }


        public Pay360Creds GetApiCredsByInstallationId(string installationId)
        {
            var creds = new Pay360Creds()
            {
                ApiUserName = _pay360Config.ApiUserName,
                ApiPassword = _pay360Config.ApiPassword,
                ApiInstallationIdCashierApi = _pay360Config.ApiInstallationIdCashierApi
            };

            if (string.IsNullOrEmpty(installationId))
            {
                return creds;
            }

            if (_pay360Config.Pay60CountryAccountConfig.Any(
                    x => x.ApiInstallationIdCashierApi.Equals(installationId, System.StringComparison.InvariantCultureIgnoreCase)))
            {
                var accountConfig = _pay360Config.Pay60CountryAccountConfig.Find(
                            x => x.ApiInstallationIdCashierApi.Equals(installationId, System.StringComparison.InvariantCultureIgnoreCase));
                if (accountConfig != null)
                {
                    creds.ApiUserName = accountConfig.ApiUserName;
                    creds.ApiPassword = accountConfig.ApiPassword;
                    creds.ApiInstallationIdCashierApi = accountConfig.ApiInstallationIdCashierApi;
                }
            }

            return creds;
        }

        public class Pay360Creds
        {
            public string ApiUserName { get; set; }
            public string ApiPassword { get; set; }
            public string ApiInstallationIdCashierApi { get; set; }
        }
    }
}
