﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TH.Models.Contracts.Request
{
    public class UserRequestPurchase
    {

        [Required]
        [JsonProperty("msisdn")]
        public string msisdn { get; set; }

        [Required]
        [JsonProperty("bundleref")]
        public string bundleref { get; set; }

        [Required]
        [JsonProperty("amount")]
        public decimal amount { get; set; }

        [Required]
        [JsonProperty("transactionid")]
        public string transactionid { get; set; }

    }
}
