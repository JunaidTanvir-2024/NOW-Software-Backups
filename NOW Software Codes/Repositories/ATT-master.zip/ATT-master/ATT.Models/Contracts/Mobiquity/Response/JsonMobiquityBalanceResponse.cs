﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Mobiquity.Response
{
    public class JsonMobiquityBalanceResponse
    {
        public JsonMobiquityBalanceResponse()
        {
            payload = new payload();
        }
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public payload payload { get; set; }
    }
    
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class WALLET
    {
        public string WALLETTYPEID { get; set; }
        public string FBALANCE { get; set; }
        public string WALLETNAME { get; set; }
        public string BALANCE { get; set; }
    }

    public class OTHERWALLETS
    {
        public WALLET WALLET { get; set; }
    }

    public class COMMAND
    {
        public string WALLETTYPEID { get; set; }
        public string PAYER_MLIMITCUST { get; set; }
        public string PAYER_DLIMITCUST { get; set; }
        public string FICBALANCE { get; set; }
        public string TXNID { get; set; }
        public string WALLETNAME { get; set; }
        public string BALANCE { get; set; }

        [JsonProperty("IVR-RESPONSE")]
        public string IVRRESPONSE { get; set; }
        public string MESSAGE { get; set; }
        public string PAYEE_DLIMITCUST { get; set; }
        public string USERTYPE { get; set; }
        public OTHERWALLETS OTHERWALLETS { get; set; }
        public string FRBALANCE { get; set; }
        public string TYPE { get; set; }
        public string PAYEE_MLIMITCUST { get; set; }
        public string TXNSTATUS { get; set; }
        public string TRID { get; set; }
    }

    public class payload
    {
        public COMMAND COMMAND { get; set; }
    }



}
