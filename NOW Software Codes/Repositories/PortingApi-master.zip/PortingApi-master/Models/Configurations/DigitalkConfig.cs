﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class DigitalkConfig
    {
        public string ApiEndPoint { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
