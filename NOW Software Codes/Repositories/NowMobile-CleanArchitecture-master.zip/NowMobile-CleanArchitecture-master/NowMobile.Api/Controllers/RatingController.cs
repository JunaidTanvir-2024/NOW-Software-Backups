﻿

using Application.Features.Rating.Rating;
using Application.Features.Rating.Status;

namespace NowMobile.Api.Controllers;
public class RatingController : VersionedApiController
{
    [HttpGet("status"), OpenApiOperation("Get customer rating status", "")]
    public async Task<IActionResult> CustomerRating()
    {
        return Ok(await Mediator.Send(new RatingStatusRequest()));
    }

    [HttpPost, OpenApiOperation("Save customer rating.", "")]
    public async Task<IActionResult> CustomerRating([FromBody] RatingRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
}