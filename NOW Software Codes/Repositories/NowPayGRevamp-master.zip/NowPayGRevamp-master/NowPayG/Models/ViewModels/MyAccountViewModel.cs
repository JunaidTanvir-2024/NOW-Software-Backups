﻿using Microsoft.AspNetCore.Mvc.Rendering;
using NowPayG.Models.ApiContracts.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class MyAccountViewModel : BaseViewModel
    {
        public IEnumerable<SelectListItem> UserProductsList { get; set; }
    }
}
