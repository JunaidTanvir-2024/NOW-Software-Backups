﻿using Infrastructure.BLL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Response;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class Push_BL : IPush_BL
    {

        private readonly ILogger Logger;
        private readonly FCMConfig FCMConfig;
        private IApnSender ApnSender;

        public Push_BL(ILogger logger, IOptions<FCMConfig> fcmConf, IApnSender apnSender)
        {
            Logger = logger;
            FCMConfig = fcmConf.Value;
            ApnSender = apnSender;
        }


        public async Task<GenericApiResponse<FCMPushResponse>> SendToFCM(string Json)
        {

            var serverKey = string.Format("key={0}", FCMConfig.ServerKey);
            var senderId = string.Format("id={0}", FCMConfig.SenderId);
            try
            {
                using (var httpRequest = new HttpRequestMessage(HttpMethod.Post, FCMConfig.URL))
                {
                    httpRequest.Headers.TryAddWithoutValidation("Authorization", serverKey);
                    httpRequest.Headers.TryAddWithoutValidation("Sender", senderId);
                    httpRequest.Content = new StringContent(Json, Encoding.UTF8, "application/json");

                    using (var httpClient = new HttpClient())
                    {
                        var response = await httpClient.SendAsync(httpRequest);
                        string jsonResult = await response.Content.ReadAsStringAsync();
                        var apiResponse = JsonConvert.DeserializeObject<FCMPushResponse>(jsonResult);
                        if (response.IsSuccessStatusCode)
                        {

                            if (apiResponse.failure > 0) // Failure
                            {
                                return GenericApiResponse<FCMPushResponse>.Failure(apiResponse, "Failure", ApiStatusCodes.UnSuccessful);
                            }
                            else // Success
                            {
                                return GenericApiResponse<FCMPushResponse>.Success(apiResponse, "Success");
                            }
                        }
                        else // Failure
                        {
                            Logger.Error($"class: Push_BL, Method: SendToFCM, Parameters=> json: {Json}, ErrorMessage: Error Sending Notification, error code: {response.StatusCode}");
                            return GenericApiResponse<FCMPushResponse>.Failure(apiResponse, "Failure", ApiStatusCodes.CodeException);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"class: Push_BL, Method: SendToFCM, Parameters=> json: {Json}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<FCMPushResponse>.Failure("Failure", ApiStatusCodes.UnSuccessful);
            }


        }

        public async Task<GenericApiResponse<ApnsResponse>> SendToIOS(string jsonBody, string deviceToken, APNSNotificationTypes notificationType, ApnServerType apnsserver)
        {

            try
            {
                var res = await ApnSender.SendAsync(jsonBody, deviceToken, notificationType, apnsserver);

                if (!res.IsSuccess) // failure
                {
                    return GenericApiResponse<ApnsResponse>.Failure(new ApnsResponse() { Reason = res.Error.Reason.ToString() }, "Failure", res.Error.Reason);
                }
                else // success
                {

                    return GenericApiResponse<ApnsResponse>.Success(new ApnsResponse() { Reason = "" }, "Success");
                }


            }
            catch (Exception ex)
            {
                Logger.Error($"class: push_bl, method: SendToIOS, parameters=> json: {jsonBody}, errormessage: {ex.Message}, stacktrace: {ex.StackTrace}");
                return GenericApiResponse<ApnsResponse>.Failure("Failure", ApiStatusCodes.CodeException);
            }


        }

        public async Task<GenericApiResponse<List<ApnsResponse>>> SendToIOSBulk(string jsonBody, List<string> DeviceTokens, APNSNotificationTypes notificationType, ApnServerType apnsserver)
        {

            try
            {
                var res = await ApnSender.SendAsyncBulk(jsonBody, DeviceTokens, notificationType, apnsserver);

                if (res.Count>0) // failure
                {
                    return GenericApiResponse<List<ApnsResponse>>.Failure(res.Select(s=>new ApnsResponse() {Reason=s.Error.Reason.ToString(),DeviceToken=s.Error.DeviceToken }).ToList(), "Failure", ApiStatusCodes.BulkAPNSFailure);
                }
                else // success
                {

                    return GenericApiResponse<List<ApnsResponse>>.Success(new List<ApnsResponse>(), "Success");
                }


            }
            catch (Exception ex)
            {
                Logger.Error($"class: push_bl, method: SendToIOS, parameters=> json: {jsonBody}, errormessage: {ex.Message}, stacktrace: {ex.StackTrace}");
                return GenericApiResponse<List<ApnsResponse>>.Failure("Failure", ApiStatusCodes.CodeException);
            }


        }
    }
}
