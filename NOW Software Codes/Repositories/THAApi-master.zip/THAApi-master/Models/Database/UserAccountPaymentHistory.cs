﻿using Models.Contracts.Request.Voucherify;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    //public class UserAccountPaymentHistory
    //{
    //    public string Amount { get; set; }

    //    public string Reference { get; set; }

    //    public DateTime DateTime { get; set; }
    //}

    public class PaymentHistory
    {
        public decimal Amount { get; set; }
        public decimal Discount { get; set; }
        public decimal TotalAmount { get; set; }
        public string DiscountCode { get; set; }
        public DiscountCodeType? DiscountCodeType { get; set; }
        public decimal ServiceFee { get; set; }
        public decimal TotalServiceFee { get; set; }
        public decimal ServiceFeeDiscount { get; set; }
        public decimal Balance { get; set; }
        public string Method { get; set; }
        public string Reason { get; set; }
        public string Reference { get; set; }
        public string NowtelTransactionReference { get; set; }
        public DateTime PaymentDate { get; set; }
        public string Msisdn { get; set; }
        public string Type { get; set; }
        public bool IsSuccess { get; set; }
        public string BundleName { get; set; }
        public string BundleId { get; set; }
        public string Db { get; set; }
        public string OperatorLogoUrl { get; set; }
        public string OperatorName { get; set; }
        public string Currency { get; set; }
    }
}
