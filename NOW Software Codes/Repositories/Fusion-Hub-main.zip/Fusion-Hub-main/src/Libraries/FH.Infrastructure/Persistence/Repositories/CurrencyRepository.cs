using System.Data;

using Dapper;

using FH.Core.Definitions;
using FH.Core.Entities;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;

using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

using Serilog;

namespace FH.Infrastructure.Persistence.Repositories;

internal sealed class CurrencyRepository(IConfiguration configuration, ILogger logger) : ICurrencyRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private readonly ILogger _logger = logger;

    public async Task<IEnumerable<CurrencyUnitEntity>> CurrencyUnitUpsert(IEnumerable<CurrencyUnitEntity> currencyUnitDtos)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("code", typeof(string));
                table.Columns.Add("name", typeof(string));
                table.Columns.Add("is_default", typeof(bool));

                foreach (var cu in currencyUnitDtos)
                {
                    table.Rows.Add(cu.Code, cu.Name, cu.IsDefault);
                }

                var parameters = new DynamicParameters();
                parameters.Add("currency_data", table.AsTableValuedParameter(AppConstants.Database.TableType.CurrencyUnit));

                return await connection.QueryAsync<CurrencyUnitEntity>(AppConstants.Database.StoreProcedure.CurrencyUnitBulkInsert, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(CurrencyRepository), nameof(CurrencyUnitUpsert));
            return default!;
        }
    }
}
