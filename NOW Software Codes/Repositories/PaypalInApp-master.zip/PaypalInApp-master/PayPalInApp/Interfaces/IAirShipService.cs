﻿using PayPalInApp.Models;
using PayPalInApp.Models.AirShip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayPalInApp.Interfaces
{
    public interface IAirShipService
    {
        Task<GenericAirShipApiResponse<string>> AddNamedUserTags(NamedUserTagsRequest request);
        Task<GenericAirShipApiResponse<string>> AddCustomEvent(CustomEventsRequest request);
    }
}
