using Microsoft.AspNetCore.Identity;

namespace JM.Core.Entities;

public sealed class Role : IdentityRole<long> { }
