﻿using Application.Common.Interfaces.Payment;
using Application.Common.Settings;
using Application.Features.Payment.Card.ExistingCardPaymentV2;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;
using Microsoft.Extensions.Options;

namespace Application.Features.Payment.Card.ExistingCardPaymentV3;
public class ExistingCardPaymentRequestHandlerV3 : IRequestHandler<ExistingCardPaymentRequestV3, Result<CardResponse>>
{
    private readonly IStringLocalizer<ExistingCardPaymentRequestHandlerV3> _localizer;
    private readonly IPaymentService _paymentService;
    private readonly ICardService _cardService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly ITopupRepository _topupRepo;
    private readonly IPayPalService _payPalService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly TopupSettings _topupSettings;

    public ExistingCardPaymentRequestHandlerV3(
        IStringLocalizer<ExistingCardPaymentRequestHandlerV3> localizer,
        IPaymentService paymentService,
        ICardService cardService,
        ICurrentUser currentUser,
        IMapper mapper,
        ITopupRepository topupRepo,
        IPayPalService payPalService,
        IUnitOfWork unitOfWork,
        IOptions<TopupSettings> topupSettings)
    {
        _localizer = localizer;
        _paymentService = paymentService;
        _cardService = cardService;
        _currentUser = currentUser;
        _mapper = mapper;
        _topupRepo = topupRepo;
        _payPalService = payPalService;
        _unitOfWork = unitOfWork;
        _topupSettings = topupSettings.Value;
    }

    public async Task<Result<CardResponse>> Handle(ExistingCardPaymentRequestV3 request, CancellationToken cancellationToken)
    {
        string existigCardNumber, cardScheme;

        //Check if card is user own card
        var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
        if (cards == null || cards != null &&
            !cards.Any(x => x.CardToken.Equals(
                request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)))
        {
            return Result<CardResponse>.Failure(
                _localizer[CustomStatusKey.InvalidPaymentCard], CustomStatusCode.InvalidPaymentCard);
        }

        existigCardNumber = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).MaskedPan;

        cardScheme = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).CardScheme;
        var setAutoTopupInfo = _mapper.Map<PaymentTopupInfo>(request.TopupInfo!);

 
        if (setAutoTopupInfo?.AutoTopupInfo != null)
        {
            setAutoTopupInfo.AutoTopupInfo.ThresHoldAmount = _topupSettings.ThresholdAmount;
        }
        return await _paymentService.HandleCardPaymentRequest(
                null!,
                request.PaymentCardInfo,
                null!,
                setAutoTopupInfo!,
                request.BundleInfo!,
                request.CreditSimInfo!,              
                request.Msisdn!,
                request.Email!,
                request.IpAddress!,
                existigCardNumber,
                cardScheme,
                false,
                request.ConversionID,
               (int) (request.ConversionPlatFormID),
               request.IsRetry,
                 request.EarlyTerminationChargesInfo!);
    }
}