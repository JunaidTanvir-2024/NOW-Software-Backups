﻿using Application.Features.AutoTopup.Paypal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.AutoTopup.DisableAutoTopup;
public class DisableAutoTopupRequest : IRequest<Result<object>>
{
    public string Msisdn { get; set; } = default!;
}
