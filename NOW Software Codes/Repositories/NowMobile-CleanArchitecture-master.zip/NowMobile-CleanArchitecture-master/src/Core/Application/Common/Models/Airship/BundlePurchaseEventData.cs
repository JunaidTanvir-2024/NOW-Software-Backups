﻿namespace Application.Common.Models.Airship;

public class BundlePurchaseEventData
{
    public string Email { get; set; } = string.Empty;
    public string BundleName { get; set; } = string.Empty;
    public string Destination { get; set; } = string.Empty;
    public int BundleCategory { get; set; }
    public double BundleType { get; set; }
    public bool? IsCard { get; set; }
    public bool IsSuccess { get; set; }
    public bool AutoRenew { get; set; }
    public bool SaveCard { get; set; } = false;
    public decimal Amount { get; set; }
}
