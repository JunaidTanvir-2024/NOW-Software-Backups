﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.AirShip
{
    public class BundleInfoAirShip
    {
        public string Msisdn { get; set; }
        public string Origination { get; set; }
        public string Destination { get; set; }
        public BundleType BundleType { get; set; }
        public bool IsSuccess { get; set; }
        public bool? IsCard { get; set; }
        public bool SaveCard { get; set; }
        public decimal RemainingBalance { get; set; }
    }
}
