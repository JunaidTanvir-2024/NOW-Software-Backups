using FluentValidation;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Utility.Requests;

public class InvokeEventRequest
{
    public string? EventName { get; set; }
    public string? CustomerSourceId { get; set; }
    public Metadata? Metadata { get; set; }
}

internal class InvokeEventRequestValidator : AbstractValidator<InvokeEventRequest>
{
    public InvokeEventRequestValidator()
    {
        RuleFor(p => p.EventName).NotNull().NotEmpty();
        RuleFor(p => p.CustomerSourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.CustomerSourceId = phoneNumber);
    }
}
