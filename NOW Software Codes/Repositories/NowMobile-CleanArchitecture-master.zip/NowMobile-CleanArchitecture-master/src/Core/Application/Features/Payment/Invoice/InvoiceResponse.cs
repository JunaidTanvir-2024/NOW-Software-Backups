﻿using Application.Features.AutoTopup;
using Application.Features.Bundle.Model;
using Domain.Aggregate;

namespace Application.Features.Payment.Invoice;

public class InvoiceResponse
{
    public InvoiceDetails? InvoiceDetails { get; set; }
    public InvoiceCardInfo? InvoiceCardInfo { get; set; }
    public InvoiceBundleInfo? InvoiceBundleInfo { get; set; }
    public InvoiceTopupInfo? InvoiceTopupInfo { get; set; }
    public InvoiceAutoTopupInfo? InvoiceAutoTopupInfo { get; set; }
    public InvoiceSIMInfo? InvoiceSIMInfo { get; set; }
    //public IEnumerable<InvoiceItemDetails>? InvoiceItemDetails { get; set; }
}
public class InvoiceDetails
{
    public int Id { get; set; }
    public string TransactionId { get; set; } = default!;
    public string Email { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
    public int TransactionType { get; set; }
    public string? TransactionTypeName { get; set; } = string.Empty;
    public string? PaymentMethodTypeName { get; set; } = string.Empty;
    public int PaymentMethodType { get; set; }
    public float Amount { get; set; }
    public float Discount { get; set; }
    public float TotalAmount { get; set; }
    public DateTime CreateDateTime { get; set; }
    public string? CustomerName { get; set; }
    [JsonIgnore]
    public int OrderStatus { get; set; }
    [JsonIgnore]
    public string OrderData { get; set; } = string.Empty;
}
public class InvoiceItemDetails
{
    public int TransactionItemType { get; set; }
    public string? TransactionItem { get; set; } = string.Empty;
    public float Amount { get; set; }
    public float Discount { get; set; }
    public float TotalAmount { get; set; }
    public Domain.Entities.Bundle? BundleInfo { get; set; }
}
public class InvoiceBundleInfo
{
    public float Amount { get; set; }
    public float Discount { get; set; }
    public float TotalAmount { get; set; }
    public Domain.Entities.Bundle? BundleInfo { get; set; }
}
public class InvoiceTopupInfo
{
    public float Amount { get; set; }
    public float Discount { get; set; }
    public float TotalAmount { get; set; }
}
public class InvoiceAutoTopupInfo
{
    public float Amount { get; set; }
}
public class InvoiceSIMInfo
{
    public string? Description { get; set; } = string.Empty;
}
public class InvoiceCardInfo
{
    public string? CardMaskedPan { get; set; } = string.Empty;
    public string? ImageURL { get; set; } = string.Empty;
}