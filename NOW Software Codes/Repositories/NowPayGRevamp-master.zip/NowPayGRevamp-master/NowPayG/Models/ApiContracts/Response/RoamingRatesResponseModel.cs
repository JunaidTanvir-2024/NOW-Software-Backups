﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Response
{
    public class RoamingRatesResponseModel
    {
        public RoamingRateResponseModel RoamingRates { get; set; }
    }
}
