﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransfertoTranscationDataBundleReponse
    {
        public string reference { get; set; }
        public string amount { get; set; }
        public string currency { get; set; }
        
    }
    public class TransfertoTranscationDataBundleGSReponse
    {
        public string transaction_id { get; set; }
        public int simulation { get; set; }
        public string status { get; set; }
        public string status_message { get; set; }
        public string date { get; set; }
        public string account_number { get; set; }
        public string external_id { get; set; }
        public string operator_reference { get; set; }
        public string product_id { get; set; }
        public string product { get; set; }
        public string product_desc { get; set; }
        public string product_currency { get; set; }
        public int product_value { get; set; }
        public string local_currency { get; set; }
        public int local_value { get; set; }
        public string operator_id { get; set; }
        public string @operator { get; set; }
        public string country_id { get; set; }
        public string country { get; set; }
        public string account_currency { get; set; }
        public double wholesale_price { get; set; }
        public double retail_price { get; set; }
        public int fee { get; set; }
        public Sender sender { get; set; }
        public Recipient recipient { get; set; }
        public int sender_sms_notification { get; set; }
        public string sender_sms_text { get; set; }
        public int recipient_sms_notification { get; set; }
        public string recipient_sms_text { get; set; }

        public List<Error> errors { get; set; }

    }

    public class Sender
    {
        public string last_name { get; set; }
        public string middle_name { get; set; }
        public string first_name { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
    }

    public class Recipient
    {
        public string last_name { get; set; }
        public string middle_name { get; set; }
        public string first_name { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
    }

    public class Error
    {
        public int code { get; set; }
        public string message { get; set; }
    }

   
}
