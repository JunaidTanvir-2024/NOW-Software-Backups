using System.Reflection;
using System.Text.Json;
using DinkToPdf.Contracts;
using DinkToPdf;

using MediatR;
using THCC.Api.Filters;
using THCC.Application;
using THCC.Infrastructure;

namespace THCC.Api;

public static class ConfigureDependencies
{
    public static IServiceCollection AddApiDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddApplicationServices(configuration);
     
        services.AddInfrastructureServices(configuration);

        services.AddSingleton(typeof(IConverter), new SynchronizedConverter(new PdfTools()));

        services.AddControllers(options => options.Filters.Add(typeof(ModelStateFilterAttribute))).AddJsonOptions(
            options =>
        {
            options.JsonSerializerOptions.DictionaryKeyPolicy = JsonNamingPolicy.CamelCase;
            options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        });

        services.AddMediatR(Assembly.GetExecutingAssembly());

        return services;
    }
}