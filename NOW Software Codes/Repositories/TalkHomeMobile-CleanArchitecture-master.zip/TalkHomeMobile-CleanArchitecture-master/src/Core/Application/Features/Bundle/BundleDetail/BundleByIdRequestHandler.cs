using Application.Features.Bundle.Model;
using CancelBundleApi.Models.ResponseModels;

namespace Application.Features.Bundle.BundleDetail;

public sealed class BundleByIdRequestHandler : IRequestHandler<BundleByIdRequest, Result<BundleInfo>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<BundleByIdRequestHandler> _localizer;
    private readonly IMapper _mapper;

    public BundleByIdRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<BundleByIdRequestHandler> localizer,
        IMapper mapper)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
    }

    public async Task<Result<BundleInfo>> Handle(BundleByIdRequest request, CancellationToken cancellationToken)
    {
        var bundle = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(request));
        if (bundle == null)
        {
            return Result<BundleInfo>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }
        if (bundle.Category == (int) BundleCategory.Affiliate)
        {
            var IsFollowedByPlan12MonthContract = await _uow.UserRepo.IsFollowedByPlan12MonthContract(bundle.UuId.ToString());
            if (IsFollowedByPlan12MonthContract)
            {
                bundle.Is12MonthAffiliate = true;
            }
        }
        return Result<BundleInfo>.Success(bundle, _localizer[CustomStatusKey.Success]);
    }
}