﻿
using ATT.Models.Contracts;
using ATT.Models.Database;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.Sochitel
{
    public  interface ISochitelAutomation_BL
    {
         Task<JsonOperatorProductResponse> sochitelGetOperatorProductsMSISDN(string destinationMSISDN, string account, int originDestinationId);
         Task<JsonOperatorProductResponse> GetFreeSwitchOperatorProducts(string sourceMSISDN, string destinationMSISDN, string account, string productCode, string productItemCode);
        Task<object> FreeSwitch_Execute(ExecuteData data);
         //Task<JsonOperatorProductResponse> sochitelGetOperatorProductsMSISDN(string destinationMSISDN, string account, int originDestinationId,string sourceMSISDN);
    }
}
