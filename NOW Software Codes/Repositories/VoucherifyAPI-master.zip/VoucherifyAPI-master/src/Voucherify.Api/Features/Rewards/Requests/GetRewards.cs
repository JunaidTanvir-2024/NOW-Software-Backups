﻿namespace Voucherify.Api.Features.Rewards.Requests;

internal class GetRewards
{
}
