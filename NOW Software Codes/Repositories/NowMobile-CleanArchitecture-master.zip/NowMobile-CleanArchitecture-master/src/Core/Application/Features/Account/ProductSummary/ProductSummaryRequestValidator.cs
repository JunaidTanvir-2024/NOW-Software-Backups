﻿namespace Application.Features.Account.ProductSummary;

public class ProductSummaryRequestValidator : AbstractValidator<ProductSummaryRequest>
{
    public ProductSummaryRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");
    }
}
