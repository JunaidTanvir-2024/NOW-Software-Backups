﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Configurations
{
    public class FCMConfig
    {
        public string ServerKey { get; set; }
        public string LegacyServer { get; set; }
        public string SenderId { get; set; }
    }
}
