﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request.FaceBook
{
    public class FaceBookCreateEventRequestModel
    {
        [JsonProperty("event")]
        public string _event { get; set; }
        //public object eventValue { get; set; }
        public int advertiser_tracking_enabled { get; set; } = 1;
        public int application_tracking_enabled { get; set; } = 1;
        public string advertiser_id { get; set; }
        public string productCode { get; set; } = "THA-WEB-API";
        public List<EventDetailsModel> custom_events { get; set; }
        [JsonProperty("app-access-token")]
        public string accesstoken { get; set; }
    }
    public class EventDetailsModel
    {
        public string _eventName { get; set; }
        public decimal _valueToSum { get; set; }
        public string fb_currency { get; set; }
    }
}
