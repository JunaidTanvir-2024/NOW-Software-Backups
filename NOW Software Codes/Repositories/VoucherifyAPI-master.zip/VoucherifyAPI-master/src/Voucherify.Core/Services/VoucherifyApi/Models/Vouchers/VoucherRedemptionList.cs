using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

public class VoucherRedemptionList
{
    [JsonPropertyName("object")]
    public string? Object { get; set; }
    [JsonPropertyName("quantity")]
    public int? Quantity { get; set; }

    [JsonPropertyName("redeemed_quantity")]
    public int? RedeemedQuantity { get; set; }

    [JsonPropertyName("redemption_entries")]
    public List<VoucherRedemption>? RedemptionEntries { get; set; }
}
