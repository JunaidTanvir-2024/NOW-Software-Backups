namespace THCC.Application.Features.Rates;

public class RatesRequest : IRequest<object> { }
