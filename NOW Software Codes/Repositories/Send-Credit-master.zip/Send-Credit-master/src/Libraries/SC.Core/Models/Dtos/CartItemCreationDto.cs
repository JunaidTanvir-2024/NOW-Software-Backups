﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.Dtos;
public record CartItemCreationDto
{
    public long customerCartItemId { get; set; } = default!;
    public string receiverEmail { get; set; } = default!;
    public string receiverMobile { get; set; } = default!;
    public string receiverPin { get; set; } = default!;
    public string customMessage { get; set; } = default!;
    public bool isRenewal { get; set; } = default!;
    public string senderId { get; set; } = default!;
    public string senderName { get; set; } = default!;
    public string senderEmail { get; set; } = default!;
    public string senderMobile { get; set; } = default!;
    public long productId { get; set; } = default!;
    public long customerCartId { get; set; } = default!;
    public bool isActive { get; set; } = default!;
    public bool isDeleted { get; set; } = default!;
    public string customerID { get; set; } = default!;
    public string ProductVendorCode { get; set; } = default!;
    public string? ProductType { get; set; } = default!;

}

