﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.JwtHelpers;
using TalkhomeAPI.Services.Interfaces;
using TalkhomeAPI.Utilities;
using ThmApi.Filters;

namespace TalkhomeAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountController : Controller
    {
        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;
        private readonly IAccountService _accountService;

        public AccountController(IAccountService accountService, ILogger logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
            _accountService = accountService;
        }

        [HttpPost]
        [Route("Login")]
        [BasicAuth]
        [IpAddress]
        public async Task<IActionResult> Login([FromBody] LoginRequestModel model)
        {
            try
            {
                return Ok(await _accountService.LoginV2(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: Login, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("VerifyPin")]
        [BasicAuth]
        [IpAddress]
        public async Task<IActionResult> VerifyPin([FromBody] VerifyPinRequestModel model)
        {
            try
            {
                var response = await _accountService.VerifyPinV2(model);
                if (response.errorCode == 0 ||
                    response.errorCode == (int)ApiStatusCodes.MissingPersonDetails)
                {
                    response.payload.GenerateToken(_configuration);
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyPin, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("VerifyEmail")]
        [BasicAuth]
        public async Task<IActionResult> VerifyEmail([FromBody] VerifyEmailRequestModel model)
        {
            try
            {
                return Ok(await _accountService.VerifyEmail(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyEmail, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("ReSendEmailVerificationLink")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> ReSendEmailVerificationLink()
        {
            try
            {
                return Ok(await _accountService.ReSendEmailVerificationLink(User.Msisdn()));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: ReSendEmailVerificationLink, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("SignUp")]
        [BasicAuth]
        [IpAddress]
        public async Task<IActionResult> SignUp([FromBody] SignUpRequestModel model)
        {
            try
            {
                return Ok(await _accountService.SignUpV2(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SignUp, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("IsEmailAlreadyExists")]
        [BasicAuth]
        public async Task<IActionResult> IsEmailAlreadyExists([FromQuery] IsEmailAlreadyExistsRequestModel model)
        {
            try
            {
                return Ok(await _accountService.IsEmailAlreadyExists(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: IsEmailAlreadyExists, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("ReSendPin")]
        [BasicAuth]
        [IpAddress]
        public async Task<IActionResult> ReSendPin([FromBody] ReSendPinRequestModel model)
        {
            try
            {
                return Ok(await _accountService.ReSendPin(model));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: ReSendPin, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetAccountDetails")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetAccountDetails()
        {
            try
            {
                return Ok(await _accountService.GetAccountDetails(User.Msisdn()));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetAccountDetails, " +
                    $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("UpdateMissingDetails")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> UpdateMissingDetails([FromBody] UpdateMissingDetailsRequestModel model)
        {
            try
            {
                return Ok(await _accountService.UpdateMissingDetails(model, User.Msisdn()));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: UpdateMissingDetails, " +
                    $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("UpdateAccountDetails")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> UpdateAccountDetails([FromBody] UpdateAccountDetailsRequestModel model)
        {
            try
            {
                return Ok(await _accountService.UpdateAccountDetails(model, User.Msisdn()));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: UpdateAccountDetails, " +
                    $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetCallingHistory")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetCallingHistory()
        {
            try
            {
                return Ok(await _accountService.GetCallingHistory(
                                        User.AccountId()));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetCallingHistory, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetTopUpPaymentHistory")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetTopUpPaymentHistory()
        {
            try
            {
                return Ok(await _accountService.GetTopUpPaymentHistory(
                                        User.AccountId()));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetTopUpPaymentHistory, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [HttpGet]
        [Route("GetEntirePaymentHistory")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetEntirePaymentHistory()
        {
            try
            {
				return Ok(await _accountService.GetEntirePaymentHistory(User.AccountId(),User.Msisdn()));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetEntirePaymentHistory, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [HttpGet]
        [Route("GetInternationalTopUpHistory")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetInternationalTopUpHistory()
        {
            try
            {
                return Ok(await _accountService.GetInternationalTopUpHistory(
                                        User.AccountId()));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetInternationalTopUpHistory, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetBundlesHistory")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> GetBundlesHistory()
        {
            try
            {
                return Ok(await _accountService.GetBundlesHistory(
                                        User.AccountId()));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetBundlesHistory, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("IsMsisdnRegistered")]
        [BasicAuth]
        public async Task<IActionResult> IsMsisdnRegistered([FromQuery] IsMsisdnRegisteredRequestModel request)
        {
            try
            {
                return Ok(await _accountService.IsMsisdnRegistered(request));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: IsMsisdnRegistered, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetAccountDetailsByMsisdn")]
        [BasicAuth]
        public async Task<IActionResult> GetAccountDetailsByMsisdn([FromQuery] GetAccountDetailsByMsisdnRequestModel request)
        {
            try
            {
                return Ok(await _accountService.GetAccountDetailsByMsisdn(request));
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetAccountDetailsByMsisdn, " +
                    $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("Promotions")]
        [BasicAuth]
        public async Task<IActionResult> GetPromotions(string msisdn)
        {
            try
            {
                var response = await _accountService.GetPromotions(msisdn);
                return Ok(response);

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetPromotions, " +
                    $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("Promotions")]
        [Authorize]
        public async Task<IActionResult> SetPromotions(Promotion promotion)
        {
            try
            {
                var msisdn = User.Claims.First(i => i.Type == "msisdn").Value;
                var response = await _accountService.SetPromotions(msisdn, promotion);
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: SetPromotions, " +
                    $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }   
        [HttpPost]
        [Route("CreateDeleteAccountRequest")]
        [Authorize]
        [ActiveUser]
        public async Task<IActionResult> CreateDeleteAccountRequest(DeleteAccountLogRequest model)
        {
            try
            {
                return Ok(await _accountService.CreateDeleteAccountRequest(model));

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: CreateDeleteAccountRequest, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(new { Msisdn = User.Msisdn(), Account = User.AccountId() })}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [HttpPost]
        [Route("GetDeleteAccountReasons")]
        [Authorize]       
        public async Task<IActionResult> GetDeleteAccountReasons()
        {
            try
            {
                return Ok(await _accountService.GetDeleteAccountReasons());

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: GetDeleteAccountReasons, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(new { Msisdn = User.Msisdn(), Account = User.AccountId() })}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [HttpPost]
        [Route("VerifyPinCode")]
        [BasicAuth]
        public async Task<IActionResult> VerifyPinCode([FromBody] PinVerificationCodeRequestModel model)
        {
            try
            {
                var response = await _accountService.VerifyPinCode(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: VerifyPinCode, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(model)}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        /// <summary>
        /// This method will check if user has submitted the delete account request
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("IsAccountDeleteRequestInProgress")]
        [Authorize]
        public async Task<IActionResult> IsAccountDeleteRequestInProgress()
        {
            try
            {
                return Ok(await _accountService.IsAccountDeleteRequestInProgress(User.Msisdn()));

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AccountController, Method: IsAccountDeleteRequestInProgress, " +
                             $"Parameters=> model: " + $"{JsonConvert.SerializeObject(new { Msisdn = User.Msisdn(), Account = User.AccountId() })}, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
    }
}
