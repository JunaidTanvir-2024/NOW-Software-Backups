﻿using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Application.Settings;

namespace THCC.Application.Features.Payment.Card.Topup.FastTopup.ExistingCard
{
    public class FastTopupExistingCardPaymentRequest : IRequest<object>
    {
        public PaymentExistingCardDto PaymentCardInfo { get; set; } = default!;
        public decimal Amount { get; set; }
        public string CardNumber { get; set; } = default!;
        public string? EmailAddress { get; set; }
    }

    public class FastTopupExistingCardPaymentRequestValidator : AbstractValidator<FastTopupExistingCardPaymentRequest>
    {
        public FastTopupExistingCardPaymentRequestValidator(
            IOptions<TopupSettings> topupSettings,
            ICommonService commonService)
        {
            RuleFor(p => p.EmailAddress)
                .NotNull()
                .NotEmpty()
                .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
                .Must(p => commonService.IsValidEmailAddress(p)).WithMessage("Invalid Email Address")
                .When(p => p.EmailAddress != null);

            RuleFor(p => p.Amount).Cascade(CascadeMode.Stop)
                .NotEmpty()
                .NotNull()
                .Must(x => topupSettings.Value.Amounts.Any(a => a.Amount == x))
                .WithMessage("Please only use: " + string.Join(",", values: topupSettings.Value.Amounts.Select(a => a.Amount)));

            RuleFor(p => p.PaymentCardInfo.CardToken)
                .NotEmpty()
                .NotNull()
                .MaximumLength(100)
                .When(x => x.PaymentCardInfo != null);

            RuleFor(p => p.PaymentCardInfo.SecurityCode)
                .NotEmpty()
                .NotNull()
                .MinimumLength(3)
                .MaximumLength(4)
                .When(x => x.PaymentCardInfo != null);

            RuleFor(p => p.CardNumber)
                .NotEmpty()
                .NotNull()
                .MaximumLength(20);
        }
    }
}