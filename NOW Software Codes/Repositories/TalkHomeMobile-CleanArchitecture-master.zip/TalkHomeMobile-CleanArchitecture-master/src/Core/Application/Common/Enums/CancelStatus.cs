﻿
namespace Application.Common.Enums;
public enum CancelStatus
{

    Refund = 1,
    EarlyTermination
}
