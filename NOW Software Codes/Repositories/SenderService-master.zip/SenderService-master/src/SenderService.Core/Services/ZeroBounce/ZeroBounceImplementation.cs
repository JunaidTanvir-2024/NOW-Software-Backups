﻿using Microsoft.Extensions.Options;
using SenderService.Core.Common.Extensions.HttpClient;
using Serilog;
using Serilog.Events;

namespace SenderService.Core.Services.ZeroBounce;

public interface IZeroBounceImplementation
{
    Task<(ZeroBounceResponse? Result, string ApiRequest, string ApiResponse)> ValidateEmailAsync(string email);
}

internal class ZeroBounceImplementation : IZeroBounceImplementation
{
    private readonly ZeroBounceSettings _zeroBounceSettings;
    private readonly IHttpClientFactory _httpClientFactory;

    public ZeroBounceImplementation(IOptions<ZeroBounceSettings> options, IHttpClientFactory httpClientFactory)
    {
        _zeroBounceSettings = options.Value;
        _httpClientFactory = httpClientFactory;
    }

    public async Task<(ZeroBounceResponse? Result, string ApiRequest, string ApiResponse)> ValidateEmailAsync(string email)
    {
        try
        {
            var queryParams = new { api_key = _zeroBounceSettings.ApiKey, email };
            var httpRequest = _httpClientFactory.CreateRequest(HttpMethod.Get, _zeroBounceSettings.Endpoints.EmailValidate).WithQueryParams(queryParams);
            var result = await httpRequest.SendAndDeserializeAndCaptureAsync<ZeroBounceResponse>();
            return result;
        }
        catch (Exception ex)
        {
            
            Log.Write(
                LogEventLevel.Error,
                "Zero Bounce Api {ZeroBounceException}", ex.Message);
            
           throw;
        }
    }
}
