﻿using Models.Contracts;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using static Models.Contracts.Airship.Response.ApiGetAllListsResponse;

namespace Infrastructure.DAL.Interfaces
{
    public interface IStaticList_DL
    {
        Task<GenericResult<bool>> AddList(AddListRequest list, string productCode);
    }
}
