﻿
using Application.Features.Discount;

namespace NowMobile.Api.Controllers;
public class DiscountController : VersionedApiController
{
    [HttpGet, AllowAnonymous, OpenApiOperation("Get discount", "")]
    public async Task<IActionResult> GetDiscount([FromQuery] DiscountRequest request)
    {
        return Ok(await Mediator.Send(request));
    }
}