﻿using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.Pay360ApiContracts
{
    public class Secure3DViewModel
    {
        public string MD { get; set; }
        public string PaRes { get; set; }

        public CheckOutTypes Checkout { get; set; }
        public bool IsAutoTopUp { get; set; }
        public float Amount { get; set; }
        public string Msisdn { get; set; }
        public bool IsAutenticated { get; set; }
        public string Email { get; set; }
        public string AccountId { get; set; }
        public string Uuid { get; set; }
        public bool isAutoRenew { get; set; }

        public string bundleName { get; set; }
    }
}
