using Mediator;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.Common;

[ApiController]
[ApiExplorerSettings(GroupName = "FusionHub")]
[Route("api/v{version:apiVersion}/[controller]")]
public abstract class BaseApiController : ControllerBase
{
	private ISender _mediator = null!;
	protected ISender Mediator => _mediator ??= HttpContext.RequestServices.GetRequiredService<ISender>();
}
