﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmsOutReachCallBackUrlApi.Contracts.Sap.Request
{
   
    public class SapSmsCallBackRequest
    {
        public string messageId { get; set; }
        public string message { get; set; }
        public string msisdn { get; set; }
        public string status { get; set; }
       
    }
}
