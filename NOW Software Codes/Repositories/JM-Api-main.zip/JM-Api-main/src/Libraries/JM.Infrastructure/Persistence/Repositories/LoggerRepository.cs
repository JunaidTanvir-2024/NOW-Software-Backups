using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;

internal sealed class LoggerRepository(AppDbContext context, ILogger logger) : ILoggerRepository
{
    private readonly AppDbContext _context = context;
    private readonly ILogger _logger = logger;
    public async Task AppLogUpsert(AppLog appLog)
    {
        try
        {
            await _context.Set<AppLog>().AddAsync(appLog);
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(LoggerRepository), nameof(AppLogUpsert));
        }
    }
    public async Task VendorLogInsert(VendorLog vendorLog)
    {
        try
        {
            await _context.Set<VendorLog>().AddAsync(vendorLog);
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(LoggerRepository), nameof(VendorLogInsert));
        }
    }
}
