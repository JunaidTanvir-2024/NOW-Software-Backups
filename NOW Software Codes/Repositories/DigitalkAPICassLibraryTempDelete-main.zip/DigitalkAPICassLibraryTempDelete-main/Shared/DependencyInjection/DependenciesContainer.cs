﻿using Application.Common.Interfaces.Identity;
using Application.Common.Interfaces.Shared;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace Shared.DependencyInjection;

public static class DependenciesContainer
{
  /*  public static IServiceCollection AddSharedServices(this IServiceCollection services)
    {
        return services.AddCurrentUser();
    }

    public static IApplicationBuilder UseCurrentUser(this IApplicationBuilder app) => app.UseMiddleware<CurrentUserMiddleware>();

    public static IServiceCollection AddCurrentUser(this IServiceCollection services) =>
        services
            .AddScoped<CurrentUserMiddleware>()
            .AddScoped<ICurrentUser, CurrentUser>()
            .AddScoped(sp => (ICurrentUserInitializer) sp.GetRequiredService<ICurrentUser>());*/
}