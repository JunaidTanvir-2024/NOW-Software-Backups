﻿using System.Text.Json.Serialization;

namespace SC.Core.Features.Operators;

public sealed class GetOperatorsRequest : IRequest<IResultWrapper>
{
    [JsonPropertyName("page")]
    public int Page { get; set; } = default!;

    [JsonPropertyName("recordsPerPage")]
    public int RecordsPerPage { get; set; } = default!;

    [JsonPropertyName("requestType")]
    public OperatorRequestType RequestType { get; set; }


    [JsonPropertyName("operatorFilters")]
    public OperatorFilter? OperatorFilters { get; set; }

    public sealed record OperatorFilter
    {
        public long? OperatorId { get; set; }
        public string? OperatorName { get; set; }
        public string? CountryIsoCode { get; set; }
    }
}

public sealed class GetOperatorsRequestValidator : AbstractValidator<GetOperatorsRequest>
{
    public GetOperatorsRequestValidator()
    {
    }
}