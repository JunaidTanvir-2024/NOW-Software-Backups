﻿using System;
using System.Collections.Generic;
using System.Text;

namespace THCCWEB.Utilities.ConnectionEnums
{
    public enum ApiStatusCodes
    {
        UserNotFound = 1,
        EmailNotVerified = 2,
        InvalidEmailPassword = 3,
        UserAlreadyExist = 4,
        DBError = 5,
        ExpiredToken = 6,
        UnableToFetchSocialAppUser = 7,
        NoPlanFound = 8,
        NoCountryFound = 9,
        NoInternationalRatesFound = 10,
        NoRoamingRatesFound = 11,
        NoUKRatesFound = 12,
        UserStatusNotChanged = 13,
        NoAddressFound = 14,
        SimOrderFailed = 15,
        NoSimOrderFound = 16,
        MobileNumberAlreadyAttached = 17,
        InvalidMsisdnOrPUK = 18,
        EmailAlreadyVerified = 19,
        InvalidOldPassword = 20,
        InvalidMsisdn = 21,
        ProductsNotFound = 22,
        AddBundleViaSimCreditFailed = 23,
        InsufficientBalanceInSim = 24,
        BundleAutoRenewalError = 25
    }
}
