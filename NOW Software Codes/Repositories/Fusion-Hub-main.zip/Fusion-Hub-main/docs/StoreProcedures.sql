----------------------------------------------------------------

------------------------TABLE TYPES-----------------------------

----------------------------------------------------------------

-- DROP PROCEDURE [dbo].[fh_app_log_upsert]
-- DROP PROCEDURE [dbo].[fh_currency_unit_bulk_insert]
-- DROP PROCEDURE [dbo].[fh_operator_bulk_insert]
-- DROP PROCEDURE [dbo].[fh_product_benefit_bulk_insert]
-- DROP PROCEDURE [dbo].[fh_product_bulk_insert]
-- DROP PROCEDURE [dbo].[fh_product_category_bulk_insert]
-- DROP PROCEDURE [dbo].[fh_product_price_bulk_insert]
-- DROP PROCEDURE [dbo].[fh_product_subcategory_bulk_insert]
-- DROP PROCEDURE [dbo].[fh_vendor_data_hash_get]
-- DROP PROCEDURE [dbo].[fh_vendor_data_hash_insert]
-- DROP PROCEDURE [dbo].[fh_vendor_operator_bulk_insert]
-- DROP PROCEDURE [dbo].[fh_vendor_log_insert]
-- DROP PROCEDURE [dbo].[fh_countries_getall]
-- DROP PROCEDURE [dbo].[fh_countries_get]
-- DROP PROCEDURE [dbo].[fh_country_by_iso_code_get]
-- DROP PROCEDURE [dbo].[fh_product_get]
-- DROP PROCEDURE [dbo].[fh_product_transaction_status_update]
-- DROP PROCEDURE [dbo].[fh_product_transaction_insert]
-- DROP PROCEDURE [dbo].[fh_product_details_get]
-- DROP PROCEDURE [dbo].[fh_operator_by_name_get]
-- DROP PROCEDURE [dbo].[fh_operator_by_vendor_code_get]
-- DROP PROCEDURE [dbo].[fh_operator_get]
-- DROP PROCEDURE [dbo].[fh_product_status_get]
-- DROP PROCEDURE [dbo].[fh_operator_aliases_update]
-- DROP PROCEDURE [dbo].[fh_product_aliases_update]
-- DROP PROCEDURE [dbo].[fh_sub_category_get]
-- DROP PROCEDURE [dbo].[fh_product_each_subcategory_get]



----------------------------------------------------------------

----------------------Store Proceudres--------------------------

----------------------------------------------------------------
-- 1
GO
CREATE PROCEDURE [dbo].[fh_product_category_bulk_insert]
  @category_data dbo.product_category_type READONLY
AS
BEGIN
  DECLARE @UpsertedRecords TABLE 
  (
    Id INT,
    [Name] [NVARCHAR](50)
  );

  -- Insert new records
  INSERT INTO dbo.product_category
    ([name], [description])
  OUTPUT INSERTED.product_category_id, INSERTED.name INTO @UpsertedRecords
  SELECT [name], [description]
  FROM @category_data cd
  WHERE NOT EXISTS (
    SELECT 1
  FROM dbo.product_category pc
  WHERE pc.name = cd.name
  );

  -- Update existing records
  UPDATE pc
  SET pc.[Name] = cd.[Name], pc.[description] = cd.[description]
  OUTPUT INSERTED.product_category_id, INSERTED.[Name] INTO @UpsertedRecords
  FROM dbo.product_category pc
    INNER JOIN @category_data cd ON pc.name = cd.name;

  -- Select the inserted/updated records to return
  SELECT Id, [Name]
  FROM @UpsertedRecords;
END


-- 2
GO
CREATE PROCEDURE [dbo].[fh_currency_unit_bulk_insert]
  @currency_data dbo.currency_unit_type READONLY
AS
BEGIN
  DECLARE @UpsertedRecords TABLE 
  (
    Id INT,
    Code [NVARCHAR](50),
    Name [NVARCHAR](50)
  );

  -- Insert new records
  INSERT INTO dbo.currency_unit
    ([code], [name], [is_default])
  OUTPUT INSERTED.currency_unit_id, INSERTED.code, INSERTED.name INTO @UpsertedRecords
  SELECT [code], [name], [is_default]
  FROM @currency_data cd
  WHERE NOT EXISTS (
    SELECT 1
  FROM dbo.currency_unit cu
  WHERE cu.code = cd.code
  );

  -- Update existing records
  UPDATE cu
    SET cu.name = cd.name, cu.code = cd.code
    OUTPUT INSERTED.currency_unit_id, INSERTED.code, INSERTED.name INTO @UpsertedRecords
    FROM dbo.currency_unit cu INNER JOIN @currency_data cd ON cu.code = cd.code;

  -- Select the inserted/updated records to return
  SELECT Id, Code, Name
  FROM @UpsertedRecords;
END

-- 3
GO
CREATE PROCEDURE [dbo].[fh_operator_bulk_insert]
  @operator_data dbo.operator_type READONLY
AS
BEGIN
  DECLARE @UpsertedRecords TABLE 
  (
    Id INT,
    [Name] NVARCHAR(50),
    CountryId BIGINT
  );

  -- Insert new records
  INSERT INTO dbo.operator
    (name, logo, description, country_id)
  OUTPUT INSERTED.operator_id, INSERTED.[name], INSERTED.country_id INTO @UpsertedRecords
  SELECT name, logo, description, country_id
  FROM @operator_data od
  WHERE NOT EXISTS (
    SELECT 1
  FROM dbo.operator op
  WHERE op.name = od.name
    AND op.country_id = od.country_id
  );

  -- Update existing records (assuming description can be updated)
  UPDATE op
  SET op.description = od.description, op.name = od.name
  OUTPUT INSERTED.operator_id, INSERTED.[name], INSERTED.country_id INTO @UpsertedRecords
  FROM dbo.operator op
    INNER JOIN @operator_data od ON op.name = od.name AND op.country_id = od.country_id;

  -- Select the inserted/updated records to return
  SELECT Id, [Name], CountryId
  FROM @UpsertedRecords;
END

-- 4
GO
CREATE PROCEDURE [dbo].[fh_product_benefit_bulk_insert]
  @benefit_data dbo.product_benefit_type READONLY
AS
BEGIN
  DECLARE @UpsertedRecords TABLE 
  (
    Id INT,
    BenefitWithTax [DECIMAL](18, 2),
    BenefitWithoutTax [DECIMAL](18, 2),
    RangeMinBenefitWithTax [DECIMAL](18, 2),
    RangeMaxBenefitWithTax [DECIMAL](18, 2),
    RangeMinBenefitWithoutTax [DECIMAL](18, 2),
    RangeMaxBenefitWithoutTax [DECIMAL](18, 2),
    Unit [NVARCHAR](50),
    UnitType [NVARCHAR](50),
    BenefitType [NVARCHAR](50),
    ProductId BIGINT
  );

  -- Perform the bulk insert and capture the inserted IDs
  INSERT INTO dbo.product_benefit
    ([data_dump_reference],[description], [benefit_with_tax], [benefit_without_tax],
    [range_min_benefit_with_tax], [range_max_benefit_with_tax],
    [range_min_benefit_without_tax], [range_max_benefit_without_tax],
    [unit], [unit_type], [benefit_type], [product_id])
  OUTPUT INSERTED.product_benefit_id, INSERTED.benefit_with_tax, INSERTED.benefit_without_tax,
  INSERTED.[range_min_benefit_with_tax], INSERTED.[range_max_benefit_with_tax], INSERTED.[range_min_benefit_without_tax], INSERTED.[range_max_benefit_without_tax],
   INSERTED.unit, INSERTED.unit_type, INSERTED.benefit_type, INSERTED.product_id INTO @UpsertedRecords
  SELECT [data_dump_reference], [description], [benefit_with_tax], [benefit_without_tax],
    [range_min_benefit_with_tax], [range_max_benefit_with_tax],
    [range_min_benefit_without_tax], [range_max_benefit_without_tax],
    [unit], [unit_type], [benefit_type], [product_id]
  FROM @benefit_data bd
  WHERE NOT EXISTS (
    SELECT 1
  FROM dbo.product_benefit pb
  WHERE pb.data_dump_reference = bd.data_dump_reference
  );

  -- Update existing records and capture the updated records
  UPDATE pb
  SET pb.benefit_with_tax = bd.benefit_with_tax,
      pb.benefit_without_tax = bd.benefit_without_tax,
      pb.[range_min_benefit_with_tax] = bd.[range_min_benefit_with_tax],
      pb.[range_max_benefit_with_tax] = bd.[range_max_benefit_with_tax],
      pb.[range_min_benefit_without_tax] =bd.[range_min_benefit_without_tax],
      pb.[range_max_benefit_without_tax] = bd.[range_max_benefit_without_tax],
      pb.unit = bd.unit,
      pb.unit_type = bd.unit_type,
      pb.benefit_type = bd.benefit_type
  OUTPUT INSERTED.product_benefit_id, INSERTED.benefit_with_tax, 
  INSERTED.benefit_without_tax,
  INSERTED.[range_min_benefit_with_tax], INSERTED.[range_max_benefit_with_tax], INSERTED.[range_min_benefit_without_tax], INSERTED.[range_max_benefit_without_tax],
   INSERTED.unit, INSERTED.unit_type, 
  INSERTED.benefit_type, INSERTED.product_id INTO @UpsertedRecords
  FROM dbo.product_benefit pb
    INNER JOIN @benefit_data bd ON pb.data_dump_reference = bd.data_dump_reference;

  -- Select both inserted and updated records to return
  SELECT Id, BenefitWithTax, BenefitWithoutTax, RangeMinBenefitWithTax, RangeMaxBenefitWithTax, RangeMinBenefitWithoutTax, RangeMaxBenefitWithoutTax, Unit, UnitType, BenefitType, ProductId
  FROM @UpsertedRecords
END

-- 5
GO
CREATE PROCEDURE [dbo].[fh_product_bulk_insert]
  @product_data dbo.product_type READONLY
AS
BEGIN
  DECLARE @UpsertedRecords TABLE 
   (
    Id INT,
    [Name] [NVARCHAR](150),
    OperatorId BIGINT,
    ProductPriceId BIGINT,
    CurrencyUnitId BIGINT,
    ProductCategoryId BIGINT,
    ProductSubCategoryId BIGINT,
    ValidityUnit [NVARCHAR](100),
    ValidityValue INT,
    VendorProductCode [NVARCHAR](50),
    VendorOperatorCode [NVARCHAR](50),
    VendorId BIGINT,
    ProductType BIT
   );

  -- Insert new records
  INSERT INTO dbo.product
    ([name], [description], [operator_id], [product_price_id], [currency_unit_id], [product_category_id],[product_subcategory_id],
    [validity_unit], [validity_value], [vendor_product_code], [vendor_operator_code], [vendor_id], [product_type])
  OUTPUT INSERTED.product_id, INSERTED.[name], INSERTED.operator_id, INSERTED.product_price_id, INSERTED.currency_unit_id, INSERTED.product_category_id,INSERTED.product_subcategory_id, INSERTED.validity_unit, INSERTED.validity_value, INSERTED.vendor_product_code, INSERTED.vendor_operator_code, INSERTED.vendor_id, INSERTED.product_type INTO @UpsertedRecords
  SELECT [name], [description], [operator_id], [product_price_id], [currency_unit_id], [product_category_id], [product_subcategory_id],
    [validity_unit], [validity_value], [vendor_product_code], [vendor_operator_code], [vendor_id], [product_type]
  FROM @product_data pd
  WHERE NOT EXISTS (
     SELECT 1
  FROM dbo.product p
  WHERE p.vendor_product_code = pd.vendor_product_code
    AND p.vendor_operator_code = pd.vendor_operator_code
    AND p.vendor_id = pd.vendor_id
   );

  -- Update existing records and capture the updated records
  UPDATE p
   SET p.[Name] = pd.[Name],
       p.operator_id = pd.operator_id,
       p.currency_unit_id = pd.currency_unit_id,
       p.product_category_id = pd.product_category_id,
       p.product_subcategory_id = pd.product_subcategory_id,
       p.validity_unit = pd.validity_unit,
       p.validity_value = pd.validity_value,
       p.product_type = pd.product_type
   OUTPUT INSERTED.product_id, INSERTED.[name], INSERTED.operator_id, INSERTED.product_price_id, INSERTED.currency_unit_id,
   INSERTED.product_category_id,INSERTED.product_subcategory_id, INSERTED.validity_unit, INSERTED.validity_value, 
   INSERTED.vendor_product_code, INSERTED.vendor_operator_code, INSERTED.vendor_id, INSERTED.product_type INTO @UpsertedRecords
   FROM dbo.product p
    INNER JOIN @product_data pd ON p.vendor_product_code = pd.vendor_product_code
      AND p.vendor_operator_code = pd.vendor_operator_code
      AND p.vendor_id = pd.vendor_id;

  -- Select both inserted and updated records to return
  SELECT Id, [Name], OperatorId, ProductPriceId, VendorOperatorCode, VendorProductCode, CurrencyUnitId, ProductCategoryId, ProductSubCategoryId, ValidityUnit, ValidityValue, VendorId, ProductType
  FROM @UpsertedRecords
END

-- 6
GO
CREATE PROCEDURE [dbo].[fh_product_subcategory_bulk_insert]
  @subcategory_data dbo.product_subcategory_type READONLY
AS
BEGIN
  DECLARE @UpsertedRecords TABLE 
    (
    Id INT,
    [Name] [NVARCHAR](50),
    ProductCategoryId BIGINT
    );

  -- Insert new records
  INSERT INTO dbo.product_subcategory
    ([name], [description], [product_category_id])
  OUTPUT INSERTED.product_subcategory_id, INSERTED.[name], INSERTED.[product_category_id] INTO @UpsertedRecords
  SELECT [name], [description], [product_category_id]
  FROM @subcategory_data sd
  WHERE NOT EXISTS (
            SELECT 1
  FROM dbo.product_subcategory psc
  WHERE psc.name = sd.name
    AND psc.product_category_id = sd.product_category_id
        );

  -- Update existing records (for instance, updating description)
  UPDATE psc
    SET psc.[description] = sd.[description]
    OUTPUT INSERTED.product_subcategory_id, INSERTED.[name], INSERTED.[product_category_id] INTO @UpsertedRecords
    FROM dbo.product_subcategory psc
    INNER JOIN @subcategory_data sd ON psc.name = sd.name AND psc.product_category_id = sd.product_category_id;

  -- Select the inserted/updated records to return
  SELECT Id, [Name], ProductCategoryId
  FROM @UpsertedRecords;
END

-- 7
GO
CREATE PROCEDURE [dbo].[fh_vendor_operator_bulk_insert]
  @operator_data vendor_operator_type READONLY
AS
BEGIN
  DECLARE @UpsertedRecords TABLE
    (
    Id INT,
    OperatorId BIGINT,
    VendorOperatorCode NVARCHAR(50),
    CountryId BIGINT
    );

  -- Insert new records
  INSERT INTO vendor_operator
    (name, logo, operator_id, vendor_operator_code, country_id)
  OUTPUT INSERTED.vendor_operator_id, INSERTED.operator_id, INSERTED.vendor_operator_code, INSERTED.country_id INTO @UpsertedRecords
  SELECT vo.name, vo.logo, vo.operator_id, vo.vendor_operator_code, vo.country_id
  FROM @operator_data vo
  WHERE NOT EXISTS (
            SELECT 1
  FROM vendor_operator vo_existing
  WHERE vo_existing.vendor_operator_code = vo.vendor_operator_code
    AND vo_existing.country_id = vo.country_id
        );

  -- Update existing records (assuming the name can be updated)
  UPDATE vo
    SET vo.name = vo_new.name
    OUTPUT INSERTED.vendor_operator_id, INSERTED.operator_id, INSERTED.vendor_operator_code, INSERTED.country_id INTO @UpsertedRecords
    FROM vendor_operator vo
    INNER JOIN @operator_data vo_new ON vo.vendor_operator_code = vo_new.vendor_operator_code AND vo.country_id = vo_new.country_id;

  -- Select the inserted/updated records to return
  SELECT Id, OperatorId, VendorOperatorCode, CountryId
  FROM @UpsertedRecords;
END

-- 8
GO

CREATE PROCEDURE [dbo].[fh_product_price_bulk_insert]
  @price_data dbo.product_price_type READONLY
AS
BEGIN
  DECLARE @UpsertedRecords TABLE   
    (
    Id INT,
    DataDumpReference NVARCHAR(55),
    Price DECIMAL(18, 2),
    Tax DECIMAL(18, 2),
    Fee DECIMAL(18, 2),
    DiscountPercentage DECIMAL(18, 2),
    RangeMinPrice DECIMAL(18, 2),
    RangeMaxPrice DECIMAL(18, 2),
    EffectiveFrom DATETIME2(7),
    EffectiveTo DATETIME2(7)  
    );

  -- Insert new records  
  INSERT INTO dbo.product_price
    ([data_dump_reference], [price], [tax], [fee], [discount_percentage],
    [range_min_price], [range_max_price], [effective_from], [effective_to])
  OUTPUT INSERTED.product_price_id, INSERTED.data_dump_reference, INSERTED.price, INSERTED.tax,   
    INSERTED.fee, INSERTED.discount_percentage, INSERTED.range_min_price, INSERTED.range_max_price, INSERTED.effective_from, INSERTED.effective_to  
    INTO @UpsertedRecords
  SELECT [data_dump_reference], [price], [tax], [fee], [discount_percentage],
    [range_min_price], [range_max_price], [effective_from], [effective_to]
  FROM @price_data pd
  WHERE NOT EXISTS (  
        SELECT 1
  FROM dbo.product_price pp
  WHERE pp.data_dump_reference = pd.data_dump_reference  
    );

  -- Update existing records  
  UPDATE pp  
    SET pp.price = pd.price,  
        pp.tax = pd.tax,  
        pp.fee = pd.fee,  
		pp.discount_percentage = pd.discount_percentage,
        pp.range_min_price = pd.range_min_price,  
        pp.range_max_price = pd.range_max_price,  
        pp.effective_from = pd.effective_from,  
        pp.effective_to = pd.effective_to  
    OUTPUT INSERTED.product_price_id, INSERTED.data_dump_reference, INSERTED.price, INSERTED.tax,   
    INSERTED.fee, INSERTED.discount_percentage, INSERTED.range_min_price, INSERTED.range_max_price, INSERTED.effective_from, INSERTED.effective_to  
    INTO @UpsertedRecords  
    FROM dbo.product_price pp
    INNER JOIN @price_data pd ON pp.data_dump_reference = pd.data_dump_reference;

  -- Select the inserted/updated records to return  
  SELECT Id, DataDumpReference, Price, Tax, Fee, DiscountPercentage, RangeMinPrice, RangeMaxPrice, EffectiveFrom, EffectiveTo
  FROM @UpsertedRecords;
END  

-- 9
GO
CREATE PROCEDURE [dbo].[fh_vendor_log_insert]
  (
  @request_timestamp DATETIME2,
  @request_path NVARCHAR(255),
  @request_method NVARCHAR(10),
  @request_body NVARCHAR(MAX),
  @response_body NVARCHAR(MAX),
  @status_code INT,
  @duration BIGINT,
  @response_size BIGINT,
  @error_reason NVARCHAR(MAX),
  @correlation_id UNIQUEIDENTIFIER,
  @headers NVARCHAR(MAX),
  @query_string NVARCHAR(MAX),
  @vendor_id INT
)
AS
BEGIN
  INSERT INTO vendor_log
    (
    request_timestamp,
    request_path,
    request_method,
    request_body,
    response_body,
    status_code,
    duration,
    response_size,
    error_reason,
    correlation_id,
    headers,
    query_string,
    vendor_id
    )
  VALUES
    (
      @request_timestamp,
      @request_path,
      @request_method,
      @request_body,
      @response_body,
      @status_code,
      @duration,
      @response_size,
      @error_reason,
      @correlation_id,
      @headers,
      @query_string,
      @vendor_id
    );
END;
GO

-- 10
GO
CREATE PROCEDURE [dbo].[fh_countries_getall]
AS
BEGIN
  SET NOCOUNT ON;

  -- Select countries from the "country" table  
  SELECT [country_id] as Id, [iso_code2] AS IsoCode2, [iso_code3] AS IsoCode3, [calling_code] AS CallingCode, [name] AS CountryName, [iso_numeric_code] AS IsoNumericCode, [continent] AS Continent
  FROM [dbo].[country]
  WHERE [is_deleted] = 0;
END

-- 11

GO
CREATE PROCEDURE [dbo].[fh_app_log_upsert]
  @request_timestamp DATETIME2,
  @request_path NVARCHAR(255),
  @request_method NVARCHAR(10),
  @request_body NVARCHAR(MAX),
  @response_body NVARCHAR(MAX),
  @status_code INT,
  @duration BIGINT,
  @client_ip NVARCHAR(50),
  @user_agent NVARCHAR(255),
  @response_size BIGINT,
  @error_reason NVARCHAR(MAX),
  @correlation_id UNIQUEIDENTIFIER,
  @headers NVARCHAR(MAX),
  @query_string NVARCHAR(MAX),
  @unique_reference NVARCHAR(50),
  @product_code NVARCHAR(15),
  @product_item_code NVARCHAR(30)
AS
BEGIN
  IF EXISTS (SELECT 1
  FROM [app_log]
  WHERE correlation_id = @correlation_id)  
    BEGIN
    UPDATE [app_log]  
        SET response_body = @response_body  
        WHERE correlation_id = @correlation_id;
  END  
    ELSE  
    BEGIN
    INSERT INTO [app_log]
      (request_timestamp, request_path, request_method, request_body, response_body, status_code, duration, client_ip, user_agent, response_size, error_reason, correlation_id, headers, query_string, unique_reference, product_code,
      product_item_code)
    VALUES
      (@request_timestamp, @request_path, @request_method, @request_body, @response_body, @status_code, @duration, @client_ip, @user_agent, @response_size, @error_reason, @correlation_id, @headers, @query_string, @unique_reference, @product_code,
        @product_item_code);
  END
END

-- 12
GO
CREATE PROCEDURE [dbo].[fh_vendor_data_hash_insert]
  @batch_hash VARCHAR(500),
  @api_page BIGINT,
  @api_type VARCHAR(60),
  @vendor_id BIGINT
AS
BEGIN
  INSERT INTO [dbo].[vendor_data_hash]
    ([batch_hash], [api_type], [api_page], [vendor_id])
  VALUES
    (@batch_hash, @api_type, @api_page, @vendor_id);
END

-- 13
GO
CREATE PROCEDURE [dbo].[fh_vendor_data_hash_get]
  @api_page BIGINT,
  @api_type VARCHAR(60),
  @vendor_id BIGINT
AS
BEGIN
  SELECT [batch_hash]
  FROM [dbo].[vendor_data_hash]
  WHERE [api_page] = @api_page
    AND [api_type] = @api_type AND [vendor_id] = @vendor_id;
END

-- 14
GO
CREATE PROCEDURE [dbo].[fh_product_transaction_insert]
  @transaction_reference NVARCHAR
(255),
  @unique_reference NVARCHAR
(255),
  @vendor_product_code NVARCHAR
(50),
  @product_id BIGINT,
  @status INT
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @InsertedIDs TABLE (ID INT);
  INSERT INTO [dbo].[product_transaction]
    (
    [transaction_reference],
    [unique_reference],
    [vendor_product_code],
    [status],
    [product_id],
    [created_at],
    [updated_at],
    [row_guid]
    )
  OUTPUT INSERTED.transaction_id INTO @InsertedIDs
  VALUES
    (
      @transaction_reference,
      @unique_reference,
      @vendor_product_code,
      @status,
      @product_id,
      GETUTCDATE(),
      GETUTCDATE(),
      NEWID()  
    );

  SELECT ID
  from @InsertedIDs;
END;

-- 15
GO
CREATE PROCEDURE fh_operator_by_vendor_code_get
  @vendor_code VARCHAR(50)
AS
BEGIN
  SELECT
    o.operator_id as OperatorId,
    o.name AS OperatorName,
    c.country_id as CountryId,
    c.name AS CountryName,
    c.iso_code2 AS CountryIsoCode
  FROM vendor_operator vo  with(nolock)
    INNER JOIN operator o with(nolock) ON o.operator_id = vo.operator_id
    INNER JOIN country c with(nolock) ON o.country_id = c.country_id
  WHERE vendor_operator_code = @vendor_code
END


-- 16
GO
CREATE PROCEDURE [dbo].[fh_countries_get]
  (

  @CountryFilters country_filters_type READONLY,
  @is_active BIT,
  @is_deleted BIT,
  @page AS INT,
  @records_per_page AS INT,
  @total_pages AS FLOAT OUTPUT,
  @total_records AS INT OUTPUT
)
AS
BEGIN

  DECLARE	@getCountryName AS NVARCHAR(50),
		@getCountryCallingCode AS SMALLINT,
		@getCountryIsoCode2 AS NVARCHAR(2),
		@getCountryIsoCode3 AS NVARCHAR(3)

  SET @getCountryName =		  (SELECT [name]
  FROM @CountryFilters)
  SET @getCountryCallingCode =  (SELECT [calling_code]
  FROM @CountryFilters)
  SET @getCountryIsoCode2 =	  (SELECT [iso_code2]
  FROM @CountryFilters)
  SET @getCountryIsoCode3 =     (SELECT [iso_code3]
  FROM @CountryFilters)

  SELECT @total_pages = CEILING(COUNT(1) / (CAST(@records_per_page AS FLOAT))), @total_records =COUNT(1)
  FROM dbo.country c
  WHERE c.is_active = @is_active
    AND c.is_deleted = @is_deleted;

  SELECT
    c.country_id AS [CountryId],
    c.iso_code2 AS [IsoCode2],
    c.iso_code3 AS [IsoCode3],
    c.calling_code AS [CallingCode],
    c.name AS [CountryName],
    c.iso_numeric_code AS [IsoNumericCode],
    c.continent AS [Continent],
    (SELECT TOP 1
      concat ('https://operator-logo.dtone.com/logo-',p.vendor_product_code,'-1.png')
    FROM dbo.product p ) AS CountryLogo
  FROM dbo.country c

  WHERE c.is_active = @is_active
    AND c.is_deleted = @is_deleted
    AND (@getCountryName IS NULL OR c.name = @getCountryName )
    AND (@getCountryCallingCode IS NULL OR c.calling_code = @getCountryCallingCode)
    AND (@getCountryIsoCode2 IS NULL OR c.iso_code2 = @getCountryIsoCode2)
    AND (@getCountryIsoCode3 IS NULL OR c.iso_code3 = @getCountryIsoCode3)


  ORDER BY c.name OFFSET (@page - 1) * @records_per_page ROWS FETCH NEXT @records_per_page ROWS ONLY;
END;


-- 17
GO
CREATE PROCEDURE [dbo].[fh_country_by_iso_code_get]
  (
  @is_active BIT = 1,
  @is_deleted BIT = 0,
  @country_iso_code NVARCHAR(50)
)
AS
BEGIN
  SELECT
    c.country_id AS [CountryId],
    c.iso_code2 AS [IsoCode2],
    c.iso_code3 AS [IsoCode3],
    c.calling_code AS [CallingCode],
    c.name AS [CountryName],
    c.iso_numeric_code AS [IsoNumericCode],
    c.continent AS [Continent]
  FROM dbo.country c with(nolock)

  WHERE c.is_active = @is_active
    AND c.is_deleted = @is_deleted AND c.iso_code2 = @country_iso_code


END;


-- 18
GO
CREATE PROCEDURE dbo.fh_product_get	
  (
  @filters product_filters READONLY,

  @is_active BIT,
  @is_deleted BIT,
  @page AS INT,
  @records_per_page AS INT,
  @total_pages AS INT OUTPUT,
  @total_records AS INT OUTPUT
)

AS
BEGIN

  DECLARE @getCountryIsoCode AS VARCHAR(50),
		 @getCurrencyCode AS VARCHAR(50),
		 @getCallingCode AS SMALLINT,
		 @getProductValidtiy AS NVARCHAR(50),
		 @getOperatorId AS NVARCHAR(50),
		 @getProductid AS BIGINT,
		 @getproductCategoryId AS BIGINT,
		 @getproductAliasName AS [nvarchar] (250),
		 @getproductOperatorName AS [nvarchar] (150),
		 @getProductSubCategoryName AS [nvarchar] (150)


  SET @getCountryIsoCode = (SELECT [country_iso_code]
  FROM @filters)
  SET @getCurrencyCode =  (SELECT [currency_code]
  FROM @filters)
  SET @getCallingCode =  (SELECT [calling_code]
  FROM @filters)
  SET @getProductValidtiy = (SELECT [validity_unit]
  FROM @filters)
  SET @getOperatorId = (SELECT [operator_id]
  FROM @filters)
  SET @getProductid = (SELECT [product_id]
  FROM @filters)
  SET @getproductCategoryId = (SELECT [product_category_id]
  FROM @filters)
  SET @getproductAliasName = (SELECT [product_alias_name]
  FROM @filters)
  SET @getproductOperatorName = (SELECT [operator_name]
  FROM @filters)
  SET @getProductSubCategoryName = (SELECT [product_subcategory_name]
  FROM @filters)

  SELECT @total_pages = CEILING(COUNT(*) / (CAST(@records_per_page AS FLOAT))), @total_records =COUNT(*)
  FROM dbo.product p
  WHERE p.is_active = @is_active
    AND p.is_deleted = @is_deleted;

  SELECT p.product_id AS [ProductId],
    p.name AS [ProductName],
    p.name_alias AS [ProductAliasName],
    p.description AS [Description],

    p.validity_unit AS [ValidityUnit],
    p.validity_value AS [ValidityValue],
    p.vendor_product_code AS [VendorProductCode],
    --  concat('https://operator-logo.dtone.com/logo-',p.vendor_operator_code,'-1.png') AS [VendorProductCode],
    p.vendor_operator_code AS [VendorOperatorCode],
    concat ('https://operator-logo.dtone.com/logo-',p.vendor_operator_code,'-1.png') AS [Logo],
    p.product_type AS [ProductType],

    c.name AS [CountryName],
    c.iso_code2 AS [CountryIsoCode2],
    c.iso_code3 AS [CountryIsoCode3],
    c.continent AS [Continent],
    c.calling_code AS [CallingCode],

    op.name AS [OperatorName],
    op.name_alias AS [OperatorAliasName],
    op.short_code AS [OperatorShortCode],
    op.description AS [OperatorDescription],

    cu.name AS [CurrencyName],
    cu.code AS [CurrencyCode],
    cu.is_default AS [CurrencyIsDefault],

    pc.name AS [CategoryName],
    pc.description AS [CategoryDescription],

    psc.name AS [SubCategoryName],
    psc. description AS [SubCategoryDescription],

    --  v.name AS [VendorName],
    p.name AS [VendorName],
    v.description AS [VendorDescription],

    pp.price AS [SellingPrice],
    pp.tax AS [Tax],
    pp.fee AS [Fee],
    pp.range_min_price AS [MaxPrice],
    pp.range_max_price AS [MinPrice],

    (
        SELECT pb.unit AS [Unit],
      pb.unit_type AS [UnitType],
      pb.benefit_type AS [BenefitType],
      pb.benefit_with_tax AS [BenefitWithTax],
      pb.benefit_without_tax AS [BenefitWithoutTax]
    FROM dbo.product_benefit pb
    WHERE pb.product_id = p.product_id
    FOR JSON PATH
) AS ProductBenefitsJson


  FROM dbo.product p
    INNER JOIN dbo.operator op ON op.operator_id = p.operator_id
    INNER JOIN dbo.country c ON c.country_id = op.country_id
    INNER JOIN dbo.currency_unit cu ON cu.currency_unit_id = p.currency_unit_id
    INNER JOIN dbo.vendor v ON v.vendor_id = p.vendor_id
    LEFT JOIN dbo.product_price pp ON p.product_price_id = pp.product_price_id
    INNER JOIN dbo.product_category pc ON pc.product_category_id = p.product_category_id
    INNER JOIN dbo.product_subcategory psc ON psc.product_subcategory_id = p.product_subcategory_id

  WHERE
			  p.is_active = 1 AND p.is_deleted = 0
    AND ( @getCountryIsoCode IS NULL OR c.iso_code2 = @getCountryIsoCode )
    AND (@getCallingCode IS NULL OR c.calling_code = @getCallingCode )
    AND (@getCurrencyCode IS NULL OR cu.code = @getCurrencyCode)
    AND (@getProductValidtiy IS NULL OR p.validity_unit = @getProductValidtiy )
    AND (@getOperatorId IS NULL OR op.operator_id = @getOperatorId )
    AND (@getProductid IS NULL OR p.product_id = @getProductid )
    AND (@getproductCategoryId IS NULL OR pc.product_category_id = @getproductCategoryId )
    AND (@getproductAliasName IS NULL OR p.name_alias = @getproductAliasName)
    AND (@getproductOperatorName IS NULL OR op.short_code = @getproductOperatorName)
    AND (@getProductSubCategoryName IS NULL OR psc.short_code = @getProductSubCategoryName)
  ORDER BY p.product_id OFFSET (@page - 1) * @records_per_page ROWS FETCH NEXT @records_per_page ROWS ONLY;

END;





-- 19
GO




-- 19
GO
CREATE PROCEDURE [dbo].[fh_product_transaction_status_update]
  @unique_reference NVARCHAR(255),
  @status NVARCHAR(20)
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE [dbo].[product_transaction]
    SET [status] = @status,
        [updated_at] = GETUTCDATE()
    WHERE [unique_reference] = @unique_reference;
END;


-- 20
GO
CREATE PROCEDURE [dbo].[fh_product_details_get]
  @productId BIGINT,
  @product_vendor_code NVARCHAR(50)
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    p.product_id AS ProductId,
    p.vendor_product_code AS ProductVendorCode,
    pp.price AS Price,
    pp.tax AS Tax,
    pp.fee AS Fee,
    pp.range_min_price AS RangeMinPrice,
    pp.range_max_price AS RangeMaxPrice,
    v.name AS VendorName
  FROM
    dbo.product AS p
    INNER JOIN
    dbo.product_price AS pp ON p.product_price_id = pp.product_price_id
    INNER JOIN
    dbo.vendor AS v ON v.vendor_id = p.vendor_id
  WHERE  
        p.product_id = @productId
    AND p.vendor_product_code = @product_vendor_code
    AND p.is_active = 1
    AND p.is_deleted = 0
    AND pp.is_active = 1
    AND pp.is_deleted = 0;

END;


-- 21
GO

CREATE PROCEDURE [dbo].[fh_operator_by_name_get]
  (
  @is_active BIT = 1,
  @is_deleted BIT = 0,
  @operator_name NVARCHAR(50)
)
AS
BEGIN

  SELECT op.operator_id AS OperatorId,
    op.name AS [OperatorName],
    op.description AS [Description],
    op.country_id AS [CountryId],
    c.name AS [CountryName],
    c.iso_code2 AS [CountryIsoCode]
  FROM dbo.operator op  with(nolock)
    INNER JOIN dbo.country c  with(nolock)
    ON c.country_id = op.country_id

  WHERE op.is_active = @is_active
    AND op.is_deleted = @is_deleted
    AND op.name = @operator_name

END;

-- 22
GO

CREATE PROCEDURE [dbo].[fh_operator_get]
  (
  @OperatorFilters operator_filters_type READONLY,

  @is_active BIT,
  @is_deleted BIT,
  @page AS INT,
  @records_per_page AS INT,
  @total_pages AS INT OUTPUT,
  @total_records AS INT OUTPUT

)
AS
BEGIN

  DECLARE	@getOperatorName AS VARCHAR(50),
		@getCountryIsoCode AS VARCHAR(50)


  SET @getOperatorName = (SELECT [operator_name]
  FROM @OperatorFilters)
  SET @getCountryIsoCode =  (SELECT [country_iso_code]
  FROM @OperatorFilters)

  SELECT @total_pages = CEILING(COUNT(1) / (CAST(@records_per_page AS FLOAT))), @total_records = COUNT(1)
  FROM dbo.operator op
  WHERE op.is_active = @is_active
    AND op.is_deleted = @is_deleted;

  SELECT op.operator_id AS OperatorId,
    op.name AS [OperatorName],
    op.description AS [Description],
    --   (select top(1) concat('https://operator-logo.dtone.com/logo-',p.vendor_operator_code,'-1.png')  from product p where op.operator_id=p.operator_id) AS [Description],
    (select top(1)
      concat('https://operator-logo.dtone.com/logo-',p.vendor_operator_code,'-1.png')
    from product p
    where op.operator_id=p.operator_id) AS [OperatorLogo],
    c.country_id AS [CountryId],
    c.name AS [CountryName],
    c.iso_code2 AS [CountryIsoCode]
  FROM dbo.operator op
    INNER JOIN dbo.country c
    ON c.country_id = op.country_id

  WHERE 	
			op.is_active = @is_active
    AND op.is_deleted = @is_deleted

    AND (@getOperatorName IS NULL OR op.name = @getOperatorName )
    AND (@getCountryIsoCode IS NULL OR c.iso_code2 = @getCountryIsoCode )

  ORDER BY op.name OFFSET (@page - 1) * @records_per_page ROWS FETCH NEXT @records_per_page ROWS ONLY
END;


-- 23
GO
CREATE PROCEDURE [dbo].[fh_product_status_get]
  --DECLARE @ProductId dbo.product_status_type;
  --INSERT INTO @ProductId (ProductId) VALUES (1), (2), (3), (4), (5), (6), (7), (8), (9), (10);
  --EXEC [dbo].[fh_product_status_get]  @ProductId
  @product_status product_status_type READONLY
AS
BEGIN
  SELECT
    p.product_id AS [ProductId],
    p.name_alias AS ProductNameAlias,
    p.vendor_product_code AS ProductVendorCode,
    p.operator_id AS OperatorId,
    o.name_alias AS OperatorNameAlias,
    pc.product_category_id AS ProductCategoryId,
    pc.name AS ProductCategory,
    psc.product_subcategory_id AS ProductSubcategoryId,
    psc.name AS ProductSubcategory,
    p.vendor_id AS VendorId,
    p.is_active AS [IsActive]
  FROM dbo.product p INNER JOIN product_subcategory psc ON
  p.product_category_id = psc.product_category_id
    INNER JOIN product_category pc ON pc.product_category_id = psc.product_category_id
    INNER JOIN operator o ON o.operator_id = p.operator_id
  WHERE p.product_id IN (SELECT ps.ProductId
  FROM @product_status ps)
END


-- 24
GO

CREATE PROCEDURE fh_product_aliases_update
  @products dbo.product_alias_type READONLY
AS
BEGIN
  UPDATE p
    SET p.name_alias = pl.name_alias, p.description = pl.description
    FROM [fusion_hub].[dbo].[product] p
    INNER JOIN @products pl ON p.product_id = pl.product_id;
END;

-- 25
GO

CREATE PROCEDURE fh_operator_aliases_update
  @operators dbo.operator_alias_type READONLY
AS
BEGIN
  UPDATE o
    SET o.name_alias = ol.name_alias, o.description = ol.description
    FROM [fusion_hub].[dbo].[operator] o
    INNER JOIN @operators ol ON o.operator_id = ol.operator_id;
END;

-- 26
CREATE PROC dbo.fh_sub_category_get  (
  @is_active BIT = 1,
  @is_deleted BIT = 0,
  @category_name_alias NVARCHAR(150)
)
AS

BEGIN

    SELECT 
      pc.name_alias AS [CategoryAliasName],
      psc.product_category_id AS [SubCategoryId],
      psc.name AS [SubCategoryName],
      psc.short_code AS [SubCategoryShortCode],
      psc.description AS [SubCategoryDescription]
      
    FROM dbo.product_category pc
    INNER JOIN dbo.product_subcategory psc 
    ON psc.product_category_id = pc.product_category_id

    WHERE 		   psc.is_active = 1    
          AND psc.is_deleted = 0
          AND pc.name_alias = @category_name_alias

END 


GO

--27



CREATE	 PROC dbo.fh_product_operator_get
  (
 @price decimal(18,2),
 @country_iso_code varchar(50),
 @currency varchar(50),
 @category varchar(50),
 @sub_category varchar(50),
 @operator varchar(50),

  @is_active BIT,
  @is_deleted BIT,
  @page AS INT,
  @records_per_page AS INT,
  @total_pages AS INT OUTPUT,
  @total_records AS INT OUTPUT
)

AS
BEGIN
  SELECT @total_pages = CEILING(COUNT(*) / (CAST(@records_per_page AS FLOAT))), @total_records =COUNT(*)
  FROM dbo.product p
  WHERE p.is_active = @is_active
    AND p.is_deleted = @is_deleted;

WITH RankedProducts AS (
  SELECT 
    p.product_id AS [ProductId],
    p.name AS [ProductName],
    p.name_alias AS [ProductAliasName],
    p.description AS [Description],
    p.vendor_product_code AS [VendorProductCode],
    p.vendor_operator_code AS [VendorOperatorCode],
    CONCAT ('https://operator-logo.dtone.com/logo-',p.vendor_operator_code,'-1.png') AS [Logo],
    p.product_type AS [ProductType],
    pp.price,
    pp.range_min_price,
    c.name AS [CountryName],
    c.iso_code2 AS [CountryIsoCode2],
    c.iso_code3 AS [CountryIsoCode3],
    c.continent AS [Continent],
    c.calling_code AS [CallingCode],
    op.name AS [OperatorName],
    op.name_alias AS [OperatorAliasName],
    op.short_code AS [OperatorShortCode],
    op.description AS [OperatorDescription],
    ROW_NUMBER() OVER (PARTITION BY op.operator_id ORDER BY p.name) AS RowNum
    FROM dbo.product p
    INNER JOIN dbo.operator op ON op.operator_id = p.operator_id
    INNER JOIN dbo.country c ON c.country_id = op.country_id
    INNER JOIN dbo.currency_unit cu ON cu.currency_unit_id = p.currency_unit_id
    INNER JOIN dbo.vendor v ON v.vendor_id = p.vendor_id
    LEFT JOIN dbo.product_price pp ON p.product_id = pp.product_price_id
    LEFT JOIN dbo.product_category pc ON pc.product_category_id = p.product_category_id
    LEFT JOIN dbo.product_subcategory psc ON psc.product_subcategory_id = p.product_subcategory_id

  WHERE
        p.is_active = 1
    AND p.is_deleted = 0
    AND (@country_iso_code IS NULL OR @country_iso_code ='' OR c.iso_code2 = @country_iso_code)
    AND (@currency IS NULL OR @currency='' OR cu.code = @currency)
    AND (@category IS NULL OR @category='' OR pc.name_alias = @category )
    AND (@operator IS NULL OR @operator='' OR op.short_code = @operator)
    AND (@sub_category IS NULL OR @sub_category='' OR psc.short_code = @sub_category)
    AND (@price is null OR (p.product_type =0 AND pp.price <=@price ) OR (p.product_type =1 AND pp.range_min_price <=@price))
  )
  SELECT
   ProductId,
   [ProductName],
    [ProductAliasName],
   [Description],
   [VendorProductCode],
   [VendorOperatorCode],
 [Logo],
[ProductType],
price,
range_min_price,
[CountryName],
 [CountryIsoCode2],
    [CountryIsoCode3],
  [Continent],
 [CallingCode],
[OperatorName],
   [OperatorAliasName],
 [OperatorShortCode],
 [OperatorDescription]
FROM RankedProducts
WHERE RowNum = 1
ORDER BY ProductId OFFSET (@page - 1) * @records_per_page ROWS FETCH NEXT @records_per_page ROWS ONLY
;
END;
GO


--28



CREATE PROCEDURE fh_product_each_subcategory_get
(
	 @SubCategoryFilters product_subcategory_filters_type READONLY,
	 @is_active BIT,
	 @is_deleted BIT
)
AS
BEGIN

	
DECLARE		@getCountryIsoCode2 AS NVARCHAR(2),
			@getCurrencyCode AS NVARCHAR(50),
			@getCategoryAliasName AS NVARCHAR(50)

		  SET @getCountryIsoCode2 =(SELECT TOP 1 [country_isocode2] FROM @SubCategoryFilters)
		  SET @getCurrencyCode = (SELECT TOP 1 [currency_code] FROM @SubCategoryFilters)
		  SET @getCategoryAliasName =(SELECT TOP 1 [category_name_alias] FROM @SubCategoryFilters);
			

	WITH myProducts AS (
    SELECT
		c.name [CountryName],
		op.short_code [OperatorShortCode],
		 p.product_id [ProductId], p.name_alias [ProductAliasName],
        CASE 
            WHEN p.product_type = 0 THEN 'Fixed'
            WHEN p.product_type = 1 THEN 'Range'
        END  [ProductType],

		 pc.name [CategoryName],
		 psc.name AS [SubCategoryName],
		pp.price [Price], pp.range_min_price [MinPrice], pp.range_max_price [MaxPrice],pp.tax [Tax], 
		cu.code [CurrencyCode],
        ROW_NUMBER() OVER (PARTITION BY psc.product_subcategory_id ORDER BY pp.price) AS RowNum
    FROM
        dbo.product p
		INNER JOIN dbo.product_category pc ON pc.product_category_id = p.product_category_id
    INNER JOIN dbo.product_subcategory psc ON p.product_category_id = psc.product_category_id
    INNER JOIN dbo.product_price pp ON p.product_price_id = pp.product_price_id
	INNER JOIN dbo.operator op ON op.operator_id = p.operator_id
	INNER JOIN dbo.country c ON c.country_id = op.country_id
	INNER JOIN dbo.currency_unit cu ON cu.currency_unit_id = p.currency_unit_id

    WHERE
        p.is_active = @is_active AND p.is_deleted = @is_deleted AND pp.price > 0

		AND (@getCountryIsoCode2 IS NULL OR c.iso_code2 = @getCountryIsoCode2)
		AND (@getCurrencyCode IS NULL OR cu.code = @getCurrencyCode )
		AND (@getCategoryAliasName IS NULL OR pc.name_alias = @getCategoryAliasName)

)
SELECT	
  	myProducts.CountryName,
    myProducts.OperatorShortCode,
	  myProducts.CurrencyCode,
    myProducts.ProductId,
    myProducts.ProductAliasName,
    myProducts.ProductType,
    myProducts.CategoryName,
    myProducts.SubCategoryName,
    myProducts.Price,
    myProducts.MinPrice,
    myProducts.MaxPrice,
    myProducts.Tax

 
FROM
    myProducts
WHERE
    RowNum <= 5 
	

END

GO


--29

CREATE PROC dbo.fh_operator_by_Category_get
(
  @is_active BIT,
  @is_deleted BIT,
  @page AS INT,
  @records_per_page AS INT,
  @countryIsoCode2 AS nvarchar(50),
  @currencyCode AS NVARCHAR(50),
  @category_alias_name AS NVARCHAR(50),
  @total_pages AS INT OUTPUT,
  @total_records AS INT OUTPUT
)
AS
BEGIN


CREATE TABLE #TempResult
  (
    OperatorId INT,
    OperatorName NVARCHAR(MAX),
    Description NVARCHAR(MAX),
	[ShortCode] NVARCHAR(60),
	Logo NVARCHAR(100),

    CategoryName NVARCHAR(MAX),
    CategoryAliasName NVARCHAR(MAX),
    CountryName NVARCHAR(MAX),
    CountryIsoCode2 NVARCHAR(50)
  );



  WITH myOperators AS
  (
    SELECT distinct
      op.operator_id [OperatorId],
      op.name [OperatorName],
      op.description [Description],
	  op.short_code [ShortCode],
	  op.logo [Logo],

      pc.name [CategoryName],
      pc.name_alias [CategoryAliasName],
      
	  c.name [CountryName],
      c.iso_code2 [CountryIsoCode2]
    FROM dbo.operator op
    INNER JOIN dbo.product p ON p.operator_id = op.operator_id
    INNER JOIN dbo.product_category pc ON pc.product_category_id = p.product_category_id
    INNER JOIN dbo.country c ON c.country_id = op.country_id
    INNER JOIN dbo.currency_unit cu ON cu.currency_unit_id = p.currency_unit_id
    WHERE
      op.is_active = @is_active AND op.is_deleted = @is_deleted
      AND (@countryIsoCode2 IS NULL OR c.iso_code2 = @countryIsoCode2)
      AND (@currencyCode IS NULL OR cu.code = @currencyCode)
      AND (@category_alias_name IS NULL OR pc.name_alias = @category_alias_name)
   

   	--	  ORDER BY  OperatorId
		  --OFFSET (@page - 1) * @records_per_page ROWS
    --FETCH NEXT @records_per_page ROWS ONLY

  )
 INSERT INTO #TempResult
  SELECT
    OperatorId,
    OperatorName,
    Description,
	ShortCode,
	Logo,
    CategoryName,
    CategoryAliasName,
    CountryName,
    CountryIsoCode2
  FROM myOperators;


    
  SELECT
    @total_pages = CEILING(COUNT(1) / (CAST(@records_per_page AS FLOAT))),
    @total_records = COUNT(1)
  FROM #TempResult;


  
  SELECT DISTINCT  OperatorId,
         OperatorName,
         Description,
		 ShortCode,
		 Logo,
         CategoryName,
         CategoryAliasName,
         CountryName,
         CountryIsoCode2 FROM #TempResult res
		 ORDER BY res.OperatorId
		 	  OFFSET (@page - 1) * @records_per_page ROWS
    FETCH NEXT @records_per_page ROWS ONLY



    
  DROP TABLE #TempResult;


END;
GO



--30



CREATE PROC fh_operator_by_sub_category_get
(
	@is_active BIT,
	@is_deleted BIT,
	@countryIsoCode2 AS NVARCHAR(2),
	@currencyCode AS NVARCHAR(50),
	@product_category_alias_name AS NVARCHAR(50),
	@product_sub_category_alias_name AS NVARCHAR(50),
	@limit INT = 5

)

AS

BEGIN

		WITH RankedProducts
		AS (SELECT DISTINCT op.name AS OperatorName,
				   op.name_alias AS OperatorAliasName,
				   op.short_code AS OperatorShortCode,
				   op.description AS OperatorDescription,
				   op.logo AS [Logo],

				   c.iso_code2 [CountryIsoCode],
				   cu.code [CurrencyCode],

				   pc.name CategoryName,
				   psc.name SubcategoryName
    
			FROM dbo.product p
				INNER JOIN dbo.operator op ON op.operator_id = p.operator_id 
				INNER JOIN dbo.country c ON c.country_id = op.country_id
				INNER JOIN dbo.currency_unit cu ON cu.currency_unit_id = p.currency_unit_id
				INNER JOIN dbo.vendor v ON v.vendor_id = p.vendor_id
				LEFT JOIN dbo.product_price pp ON p.product_id = pp.product_price_id
				INNER JOIN dbo.product_category pc ON pc.product_category_id = p.product_category_id
				INNER JOIN dbo.product_subcategory psc ON psc.product_subcategory_id = p.product_subcategory_id
			
			WHERE p.is_active = @is_active AND p.is_deleted = @is_deleted
				AND (@countryIsoCode2 IS NULL OR c.iso_code2 = @countryIsoCode2)
				AND (@currencyCode IS NULL OR cu.code = @currencyCode)
				AND (@product_category_alias_name IS NULL OR pc.name_alias = @product_category_alias_name)
				AND (@product_sub_category_alias_name IS NULL OR psc.name_alias = @product_sub_category_alias_name)
				  
		

	), DistinctSubCategory 
		AS
		(
			SELECT ROW_NUMBER() OVER (PARTITION BY SubcategoryName ORDER BY (SELECT NULL) )  AS [RowNumber],
				   OperatorName,
                   OperatorAliasName,
                   OperatorShortCode,
                   OperatorDescription,
                   Logo,
                   CountryIsoCode,
                   CurrencyCode,
                   CategoryName,
                   SubcategoryName
				
				
		FROM RankedProducts
		)

		SELECT 
               DistinctSubCategory.OperatorName,
               DistinctSubCategory.OperatorAliasName,
               DistinctSubCategory.OperatorShortCode,
               DistinctSubCategory.OperatorDescription,
               DistinctSubCategory.Logo,
               DistinctSubCategory.CountryIsoCode,
               DistinctSubCategory.CurrencyCode,
               DistinctSubCategory.CategoryName,
               DistinctSubCategory.SubcategoryName
			   
			   FROM DistinctSubCategory
		WHERE DistinctSubCategory.RowNumber <= @limit

	
END



-- 31


