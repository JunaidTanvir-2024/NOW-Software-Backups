﻿namespace Application.Common.Enums;

public enum LoginType : byte
{
    Email = 1,
    PhoneNumber = 2
}
public enum SocialLoginType
{
    Google = 1,
    Facebook = 2,
    Apple = 3

}