﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class SignUpRequestModel
    {
        [Required(ErrorMessage = "Enter first name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid first name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Enter last name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid last name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Enter email address"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [EmailAddress(ErrorMessage = "Email is invalid")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Enter your phone number")]
        [MaxLength(length: 50, ErrorMessage = "Maximum length exceeded")]
        public string PhoneNumber { get; set; }

        [Required]
        [MaxLength(length: 5, ErrorMessage = "Maximum length exceeded")]
        public string PhoneNumberCountryCode { get; set; }

        public bool MailSubscription { get; set; }

        [Required]
        [MaxLength(50)]
        public string IpAddress { get; set; }
    }
}
