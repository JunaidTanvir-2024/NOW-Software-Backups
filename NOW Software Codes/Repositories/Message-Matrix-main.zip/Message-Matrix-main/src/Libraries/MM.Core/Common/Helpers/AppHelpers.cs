namespace MM.Core.Common.Helpers;
public abstract class AppHelpers
{
    public static string GetCorrelationId()
    {
        return Guid.NewGuid().ToString();
    }

}
