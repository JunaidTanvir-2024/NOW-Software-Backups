using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Validations;

public class VoucherSubjectList
{
    [JsonPropertyName("data")]
    public List<VoucherSubject>? Entries { get; set; }
}
