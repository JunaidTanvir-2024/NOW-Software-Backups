﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ATT.Models.Contracts.TransferTo.Request
{
    public class TransferToGetTransactionRequest : TransfertoBaseRequest
    {

        public string action = "trans_info";
        public string transactionid { get; set; }
        //public string operatorid { get; set; }
        public string toXML()
        {
            //return "<TransferTo>" + base.toXML() + $"<action>{action}</action><destination_msisdn>{destination_msisdn}</destination_msisdn><operatorid>{operatorid}</operatorid></TransferTo>";

            return "<TransferTo>" + base.toXML() + $"<action>{action}</action><transactionid>{transactionid}</transactionid></TransferTo>";
        }

    }
}
