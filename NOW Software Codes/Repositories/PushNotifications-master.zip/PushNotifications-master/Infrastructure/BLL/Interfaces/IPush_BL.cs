﻿using Models.Contracts;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IPush_BL
    {
        Task<GenericApiResponse<FCMPushResponse>> SendToFCM(string Json);
        Task<GenericApiResponse<ApnsResponse>> SendToIOS(string jsonBody, string deviceToken, APNSNotificationTypes notificationType, ApnServerType apnsserver);
        Task<GenericApiResponse<List<ApnsResponse>>> SendToIOSBulk(string jsonBody, List<string> DeviceTokens, APNSNotificationTypes notificationType, ApnServerType apnsserver);
    }
}
