﻿using Application.Common.Extensions.DependencyResolver;
using Application.Common.Models.Airship;

namespace Application.Common.Interfaces;
public interface IAirshipService : IServicesType.IScopedService
{
    bool IsActive { get; }
    Task AssociateNamedUserWeb(string channelId, string msisdn);
    Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress);
    Task AddEmailChannel(string emailAddress);
    Task AddEmailChannelCommercial(string emailAddress);
    Task RemoveEmailChannelCommercial(string emailAddress);
    Task DisassociationNamedUserFromWebChannel(string namedUserId, string channelId);
    Task AddNamedUserTags(NamedUserTagsRequest data);
    Task AddCustomEvent(CustomEventsRequest data);
    Task HandleTopupPurchaseTagsAndEvents(TopupPurchaseEventData data);
    Task HandleFastTopupPurchaseTagsAndEvents(FastTopupPurchaseEventData data);
    Task HandleBundlePurchaseTagsAndEvents(BundlePurchaseEventData data);
    Task HandleCreditSIMPurchaseTagsAndEvents(SimPurchaseEventData data);
    Task HandleGenericTagsAndEvents(GenericEventData data);
}
