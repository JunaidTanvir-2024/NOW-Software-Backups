﻿using Microsoft.EntityFrameworkCore;
using SenderService.Core.Persistence.Entities;

namespace SenderService.Core.Persistence.Repository;

public interface IProductCodeRepository
{
    Task<long> AddProductCodeAsync(ProductCode productCode);
    Task<IEnumerable<ProductCode>> GetProductCodesAsync();
    Task<ProductCode?> GetProductCodeByIdAsync(long id);
    Task RemoveProductCodeAsync(ProductCode productCode);
    Task UpdateProductCodeAsync(ProductCode productCode);
    Task<ProductCode?> GetProductCodeByItemCodeAsync(string productCode);
}

internal sealed class ProductCodeRepository : IProductCodeRepository
{
    private readonly SenderServiceContext _dbContext;

    public ProductCodeRepository(SenderServiceContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IEnumerable<ProductCode>> GetProductCodesAsync()
    {
        return await _dbContext.Set<ProductCode>().ToListAsync();
    }

    public async Task<ProductCode?> GetProductCodeByItemCodeAsync(string productCode)
    {
        return await _dbContext.Set<ProductCode>().FirstOrDefaultAsync(pc => pc.ItemCode == productCode);
    }

    public async Task<ProductCode?> GetProductCodeByIdAsync(long id)
    {
        return await _dbContext.Set<ProductCode>().FirstOrDefaultAsync(pc => pc.Id == id);
    }

    public async Task<long> AddProductCodeAsync(ProductCode productCode)
    {
       var entity = await _dbContext.Set<ProductCode>().AddAsync(productCode);
        await _dbContext.SaveChangesAsync();
        return entity.Entity.Id;
    }

    public async Task UpdateProductCodeAsync(ProductCode productCode)
    {
        _dbContext.Set<ProductCode>().Update(productCode);
        await _dbContext.SaveChangesAsync();
    }

    public async Task RemoveProductCodeAsync(ProductCode productCode)
    {
        _dbContext.Set<ProductCode>().Remove(productCode);
        await _dbContext.SaveChangesAsync();
    }
}
