﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Response
{
    public class JsonGetTransactionResponse
    {
        public int errorCode { get; set; }
        public string status { get; set; }
        public string message { get; set; }
        public GetTransactionResponse payload { get; set; }
    }
}
