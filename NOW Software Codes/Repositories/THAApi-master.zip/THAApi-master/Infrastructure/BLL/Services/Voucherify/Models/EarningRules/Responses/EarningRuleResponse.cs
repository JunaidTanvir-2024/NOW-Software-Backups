using Models.Common;
using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.EarningRules.Responses
{
    public class EarningRuleResponse
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("validationRuleId")]
        public string ValidationRuleId { get; set; }

        [JsonPropertyName("loyaltyPoints")]
        public int LoyaltyPoints { get; set; }

        [JsonPropertyName("loyaltyType")]
        public string LoyaltyType { get; set; }

        [JsonPropertyName("eventType")]
        public string EventType { get; set; }

        [JsonPropertyName("isActive")]
        public bool IsActive { get; set; }

        [JsonPropertyName("banner")]
        public string Banner { get; set; }

        [JsonPropertyName("campaignId")]
        public string CampaignId { get; set; }

        [JsonPropertyName("loyaltyMetadata")]
        public LoyaltyMetadataInfo LoyaltyMetadata { get; set; } = new LoyaltyMetadataInfo();

        [JsonPropertyName("metadata")]
        public Metadata Metadata { get; set; }

        public class LoyaltyMetadataInfo
        {
            [JsonPropertyName("basePoints")]
            public int BasePoints { get; set; }
            [JsonPropertyName("base")]
            public int Base { get; set; }
        }
    }
}