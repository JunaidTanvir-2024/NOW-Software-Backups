namespace FH.Infrastructure.Services.OpenApi;

public sealed class OpenApiSetting
{
    public const string SectionName = nameof(OpenApiSetting);
    public string? Version { get; set; }
    public string? Title { get; set; }
    public string? Description { get; set; }
    public string? TermsOfService { get; set; }
    public string? ContactName { get; set; }
    public string? ContactUrl { get; set; }
    public string? LicenseName { get; set; }
    public string? LicenseUrl { get; set; }
    public string? JwtSecurityDefinitionName { get; set; }
    public string? JwtSecurityDefinitionDescription { get; set; }
    public string? JwtSecurityDefinitionBearerFormat { get; set; }
}
