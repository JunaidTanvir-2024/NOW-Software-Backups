﻿namespace SC.Api.Model;
public class GetSubCategory
{
    public string? CategoryAliasName { get; set; } = default!;
}

