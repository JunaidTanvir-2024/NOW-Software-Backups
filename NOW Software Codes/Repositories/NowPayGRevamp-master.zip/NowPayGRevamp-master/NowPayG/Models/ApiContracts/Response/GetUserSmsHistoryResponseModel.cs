﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Response
{
    public class GetUserSmsHistoryResponseModel
    {
        public IEnumerable<DBSmsHistory> SmsHistory { get; set; }
        public int SmsHisotryTotalRecords { get; set; }
    }

    public class DBSmsHistory
    {
        public string Date { get; set; }
        public string calling_party_number { get; set; }
        public string called_party_number { get; set; }
        public string subscriber_charge { get; set; }
        public string Number_of_sms { get; set; }
    }
}
