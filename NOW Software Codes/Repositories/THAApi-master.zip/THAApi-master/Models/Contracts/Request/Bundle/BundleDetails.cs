﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.Bundle
{
	public class BundleDetails
	{
		public BundleDetails()
		{
			Destinations = new List<string>();

			Details = new List<string>();
		}

		public string Id { get; set; }

		public string Name { get; set; }

		public string Price { get; set; }

		public int PriceValue { get; set; }

		public string ChargePeriod { get; set; }
		public string CountryCode { get; set; }

		public List<string> Details { get; set; }

		public List<string> Destinations { get; set; }
		public bool IsOffer { get; set; }
		public bool IsAutoRenew { get; set; }
		public int DiscountPercentage { get; set; }
		public string BundleCategory { get; set; }
	}
}
