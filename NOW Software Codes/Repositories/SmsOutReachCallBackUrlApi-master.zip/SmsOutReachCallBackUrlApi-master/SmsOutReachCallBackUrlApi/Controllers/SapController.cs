﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SmsOutReachCallBackUrlApi.Infrastructure.Sap;
using Serilog;
using System.IO;
using SmsOutReachCallBackUrlApi.Contracts.Sap.Request;
using System.Text;
using SmsOutReachCallBackUrlApi.Models;
using System.Net;
using Newtonsoft.Json;

namespace SmsOutReachCallBackUrlApi.Controllers
{
       
    public class SapController : Controller
    {
        private readonly ILogger Logger;
        private ISapPost SapPost;

        public SapController(ILogger logger, ISapPost sapPost)
        {
            Logger = logger;
            SapPost = sapPost;
        }


        [HttpPost]
        async public Task<IActionResult> SmsCallBackUrl()
        {

            Logger.Information($"Processing - Post: Sap/SmsCallBackUrl ");
            string requestJsonData = "";
            try
            {

                using (StreamReader reader = new StreamReader(Request.Body, Encoding.UTF8))
                {
                    requestJsonData = await reader.ReadToEndAsync();
                }

                Logger.Information($"Processing - Post: Sap/SmsCallBackUrl, Parameters --> SmsCallBackUrlJson: {requestJsonData}");

                SapSmsCallBackRequest deliveryReport = JsonConvert.DeserializeObject<SapSmsCallBackRequest>(requestJsonData); 
                
                DbResult result = await SapPost.AddSmsCallBackUrlData(deliveryReport);
                if (result.DBStatus == 1)
                {
                    return Ok("Success");
                }
                else
                {
                    Logger.Error($"Exception - Post: Sap/SmsCallBackUrl, Parameters --> SmsCallBackUrlJson: {requestJsonData}, ExceptionMessage: {result.DBErrorMessage}");
                    return StatusCode((int)HttpStatusCode.InternalServerError, result.DBErrorMessage);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Exception - Post: Sap/SmsCallBackUrl, Parameters --> SmsCallBackUrlJson: {requestJsonData}, ExceptionMessage: {ex.Message}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }

        }

    }
}