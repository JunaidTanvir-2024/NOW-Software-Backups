﻿using Application.Common.Extensions;
using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.Account.Profile.UpdateProfileImage;

public class UpdateProfileImageRequestValidator : AbstractValidator<UpdateProfileImageRequest>
{
    public UpdateProfileImageRequestValidator(IOptions<FileUploadSettings> fileSettings)
    {
        RuleFor(p => p.Image!).FileSmallerThan(fileSettings.Value.FileSizeInBytes).FileExtensionAllowed(fileSettings).When(p => p.Image != null);
    }
}