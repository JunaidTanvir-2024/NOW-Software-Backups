﻿using NowPayGApi.Models.Contracts;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace NowPayGApi.Infrastructure.BLL.Interfaces
{
    public interface IBL_Admin
    {
        Task<LoginResponseModel> Login(LoginRequestModel model);
        Task<GenericApiResponse<GetUsersResponseModel>> GetAllUsers(GetUsersRequestModel request);
        Task<GenericApiResponse<GetUserByIDResponseModel>> GetUserByID(GetUserByIDRequestModel request);
        Task<GenericApiResponse<bool>> UpdateUserStatus(UpdateUserStatusModel request);
        Task<GenericApiResponse<bool>> SaveUpdateAdmin(SaveUpdateAdminRequestModel request);
        Task<GenericApiResponse<bool>> UpdatePlanStatus(UpdatePlanStatusModel model);
        Task<GenericApiResponse<bool>> UpdatePlan(AddPlanRequestModel model);
        Task<GenericApiResponse<bool>> AddPlan(AddPlanRequestModel model);
        Task<GenericApiResponse<GetAllAdminsResponse>> GetAllAdmins(GetAllAdminsRequestModel request);
        Task<GenericApiResponse<bool>> UpdateAdminStatus(UpdateAdminStatusRequestModel request);
        Task<GenericApiResponse<bool>> DispatchOrder(DispatchOrderRequestModel model, int userId);
        Task<GenericApiResponse<GetSpecificSimOrderDetailsResponseModel>> GetSpecificSimOrderDetails(GetSpecificSimOrderDetailsRequestModel model);
        Task<GenericApiResponse<GetAllSimOrdersResponseModel>> GetAllSimOrders();
        Task<GenericApiResponse<int>> Insertotp(InsertotpRequestModel model);
        Task<GenericApiResponse<int>> Verifyotp(VerifyotpRequestModel model);
        Task<GenericApiResponse<int>> VerifyUserSimOrder(VerifyUserSimOrderRequestModel model);
        Task<GenericApiResponse<int>> IsverifiedUser(string email);

    }
}
