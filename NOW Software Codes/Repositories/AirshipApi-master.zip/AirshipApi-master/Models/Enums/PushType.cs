﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum PushType
    {
        Notification = 1,
        InAppMessage = 2,
        MessageCenterMessage = 3,
        Email = 4,
        Sms = 5        
    }
}
