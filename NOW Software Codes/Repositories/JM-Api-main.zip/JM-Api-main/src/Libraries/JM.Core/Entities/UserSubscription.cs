using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class UserSubscription : IBaseEntity<long>
{
    public long Id { get; set; }
    public long UserId { get; set; }
    public User User { get; set; } = null!;
    public long SubscriptionId { get; set; }
    public Subscription Subscription { get; set; } = null!;
}
