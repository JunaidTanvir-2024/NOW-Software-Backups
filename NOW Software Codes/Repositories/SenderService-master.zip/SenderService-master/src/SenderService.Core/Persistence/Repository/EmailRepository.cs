﻿using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SenderService.Core.Common.Enums;
using SenderService.Core.Common.Extensions;
using SenderService.Core.Common.Models;
using SenderService.Core.Features.Email.Response;
using SenderService.Core.Persistence.Entities;
using System.Data;

namespace SenderService.Core.Persistence.Repository;

public interface IEmailRepository
{
    Task<long> AddEmailAsync(Email email);
    Task<int> CountAsync();
    Task DeleteAsync(string emailAddress, int recipientType);
    Task<IEnumerable<Email>> GetEmailsAsync(int batchSize);
    Task<IEnumerable<Email>> GetEmailsAsync(int pageNumber, int pageSize, string? email);
    List<EmailData> GetEmailsByStoreProcedureAsync(int batchSize);
    Task<Email?> GetSpecificEmailRecordAsync(string? email);
    Task UpdateEmailAsync(Email email);
    Task UpdateEmailByStoreProcedureAsync(long emailId, bool isSent, DateTime sentDatatime, int attempts, DateTime lastAttemptDateTime, short processingStatus, string? errorMessage);
}

internal sealed class EmailRepository : IEmailRepository
{
    private readonly SenderServiceContext _dbContext;
    private readonly IConfiguration _configuration;

    public EmailRepository(SenderServiceContext dbContext, IConfiguration configuration)
    {
        _dbContext = dbContext;
        _configuration = configuration;
    }
    public async Task<IEnumerable<Email>> GetEmailsAsync(int batchSize)
    {
        // Get the emails that were not sent and also include the ones that were not sent in the previous pages
        var query = _dbContext.Set<Email>().Where(x => !x.IsSent);

        // Add includes for related entities
        query = query.Include(e => e.ProductCode).Include(e => e.EmailRecipients);

        return await query.OrderBy(x => x.Priority).ThenBy(x => x.CreatedOnUtc).Take(batchSize).ToListAsync();
    }
    public List<EmailData> GetEmailsByStoreProcedureAsync(int batchSize)
    {
        try
        {
            var results = _dbContext.Set<EmailData>().FromSqlInterpolated($"EXECUTE SP_GetUnsentEmails @BatchSize = {batchSize}").AsEnumerable();
        return results.ToList();
        }
        catch (Exception ex)
        {

            throw;
        }
        

    }
    //public async Task<List<EmailData>> GetEmailsByStoreProcedureAsync(int batchSize)
    //{
    //    var results = _dbContext.Set<EmailData>().FromSqlInterpolated($"EXECUTE SP_GetUnsentEmails @BatchSize = {batchSize}").AsEnumerable();

    //    using (var connection = new SqlConnection(_configuration.GetConnectionString("SenderServiceConnection")))
    //    {
    //        var parameters = new DynamicParameters();
    //        parameters.Add("@BatchSize", batchSize);
    //        var result = await connection.QueryAsync<EmailData>("SP_GetUnsentEmails", parameters, CommandType.StoredProcedure);
    //    }

    //    return results.ToList();
    //}
    public async Task<IEnumerable<Email>> GetEmailsAsync(int pageNumber, int pageSize, string? email)
    {
        // Get the emails query
        var query = _dbContext.Set<Email>().Where(x => !x.IsSent);

        if (!string.IsNullOrEmpty(email))
        {
            // Filter the email recipient data based on the provided email address
            var emailRecipientQuery = _dbContext.Set<EmailRecipient>().Where(x => x.EmailAddress == email);

            // Include the email recipient data in the email query
            query = query.Include(x => x.EmailRecipients).Where(x => x.EmailRecipients.Any(r => emailRecipientQuery.Any(er => er.Id == r.Id)));
        }
        else
        {
            // If no email address is provided, exclude the email recipient data from the email query
            query = query.Include(x => x.ProductCode);
        }

        // Order the email query by priority and created date
        query = query.OrderBy(x => x.Priority).ThenBy(x => x.CreatedOnUtc);

        // Paginate the email query
        query = query.GetPaginationResult(pageNumber, pageSize);

        // Execute the email query and return the result
        return await query.ToListAsync();
    }


    public async Task<Email?> GetSpecificEmailRecordAsync(string? email)
    {
        return await _dbContext.Set<Email>()
            .Include(e => e.ProductCode)
            .Include(e => e.EmailRecipients.Where(x => x.EmailAddress == email))
            .FirstOrDefaultAsync();
    }

    public async Task<Email?> GetSenderEmailRecordAsync(string? email)
    {
        return await _dbContext.Set<Email>()
            .Include(e => e.ProductCode)
            .Include(e => e.EmailRecipients.Where(x => x.EmailAddress == email))
            .FirstOrDefaultAsync();
    }

    public async Task<long> AddEmailAsync(Email email)
    {
        var entity = await _dbContext.Set<Email>().AddAsync(email);
        await _dbContext.SaveChangesAsync();
        return entity.Entity.Id;
    }

    public async Task UpdateEmailAsync(Email email)
    {
        _dbContext.Set<Email>().Update(email);
        await _dbContext.SaveChangesAsync();
    }
    public async Task UpdateEmailByStoreProcedureAsync(long emailId, bool isSent, DateTime sentDatatimeUtc, int attempts, DateTime lastAttemptDateTimeUtc, short processingStatus, string? errorMessage)
    {
        await _dbContext.Database.ExecuteSqlInterpolatedAsync($"EXECUTE SP_UpdateEmailRecord @Id={emailId}, @IsSent = {isSent}, @Attempts={attempts}, @ProcessingState={processingStatus}, @SentDateTimeUtc = {sentDatatimeUtc}, @LastAttemptDateTimeUtc = {lastAttemptDateTimeUtc}, @ErrorMessage={errorMessage}");
    }

    public async Task DeleteAsync(string emailAddress, int recipientType)
    {
        var emailRecipient = await _dbContext.Set<EmailRecipient>()
            .SingleOrDefaultAsync(x => x.EmailAddress == emailAddress && x.RecipientType == recipientType);

        if (emailRecipient == null)
        {
            throw new ArgumentException("Email recipient not found.");
        }

        _dbContext.Set<EmailRecipient>().Remove(emailRecipient);
        await _dbContext.SaveChangesAsync();
    }



    public async Task<int> CountAsync()
    {
        return await _dbContext.Set<Email>().CountAsync();
    }
}
