﻿
using System.Collections.Generic;

namespace ATT.Models.Contracts.Sochitel.Response
{
    public class OperatorProducts
    {
        public IDName type { get; set; }
        public List<string> productTypes { get; set; }
        public Dictionary<string, Product> products { get; set; }
        public OperatorUserString currency { get; set; }


        //Following are the additional parameters other than what is being receibed in the API call to Sochitel. 
        //These parameters are being set in SochiPost code
        public string CountryName { get; set; }
        public string OperatorID { get; set; }          
        public string OperatorName { get; set; }        
        public string OperatorLogo { get; set; }        
        public string CountryLogo { get; set; }         
    }
}
