﻿using PaymentsApi.Infrastructure.DAL.Database;
using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PaymentsApi.Infrastructure.DAL.Interfaces
{
    public interface DL_IPay360
    {
        Task<DbResult<int>> AddCustomer(Customer customer);
        //Task<DbResult<long>> AddTransaction(Pay360Transaction transaction, ProductBasket[] basket, Pay360SummaryTransactionTypes controllerActionType = Pay360SummaryTransactionTypes.NEWCUSTOMER, bool AddSummaryTransaction = false, string ipAddress = null);
        Task<DbResult<long>> AddTransaction(Pay360Transaction transaction, ProductBasket[] basket, bool isDirectFullfilment, Pay360SummaryTransactionTypes controllerActionType = Pay360SummaryTransactionTypes.NEWCUSTOMER, bool AddSummaryTransaction = false, string ipAddress = null);
        Task<DbResult<long>> AddTransactionWithoutBasket(Pay360Transaction transaction, Pay360SummaryTransactionTypes controllerActionType = Pay360SummaryTransactionTypes.NEWCUSTOMER, bool AddSummaryTransaction = false, string ipAddress = null);
        Task<bool> CustomerExistsByMerchantRefAsync(string merchantRef);
        Task<Customer> GetCustomerByMerchantRef(string merchantRef);
        Task<Customer> GetCustomerByCustomerId(int customerId);
        Task<Customer> GetCustomerByPay360CustomerId(long customerId);
        Task<Pay360Transaction> GetTransactionByPay360TransactionId(string transactionId);
        Task<DbResult<string>> UpdateCustomerDefaultCv2(string merchantRef, string cv2, string encryptionKey);
        Task UpdateCustomerIdAndCV2(string merchantRef, long Pay360CustomerId, bool UpdateDefaultCV2 = false, string cV2 = "", string encryptionKey = "");
        Task<Pay360TransactionSummary> GetTransactionSummaryByPay360TransactionId(string transactionId);
        Task<int> UpdateCustomerAutoTopup_old(float autoTopupTheresholdAmount, bool isAutoTopup, string msisdn, decimal topupAmount, string topupCurrency);
        //Task<int> UpdateTHMCustomerAutoTopup(float autoTopupTheresholdAmount, bool isAutoTopup, string msisdn, decimal topupAmount, string topupCurrency, string email);
        Task<int> UpdateCustomerAutoTopup(float autoTopupTheresholdAmount, bool isAutoTopup, string msisdn, decimal topupAmount, string topupCurrency, string email, string productCode);
        //Task<GenericApiResponse<UserResponseGetAutoTopup>> GetCustomerTHMAutoTopup(string msisdn, string email);
        Task<GenericApiResponse<UserResponseGetAutoTopup>> GetCustomerAutoTopup(string msisdn, string email, string productCode);


        Task<DbResult<int>> UpdateSummaryThreeDSecureCompleted(long Id);
        Task<DbResult<int>> UpdateTransactionSummary(string Pay360TransactionId, long TransactionId, Pay360SummaryTransactionStatuses status, DateTime utcNow, bool isFailed);
        Task<DbResult<int>> UpdateTransactionSummaryStatus(string Pay360TransactionId, long TransactionId, DateTime transactionDatetime, Pay360SummaryTransactionStatuses status);
        Task<DbResult<bool>> ValidateTopUp(string customerMsisdn, float transactionAmount);
        Task<DbResult<string>> UpdateCustomerEmail(string merchantRef, string email);
        Task<GenericApiResponse<UserResponseGetAutoTopup>> GetCustomerAutoTopup_old(string msisdn);
        Task<ProductBasket[]> GetTransactionItems(string transactionId);
        Task<List<ProductItems>> GetProductItems();
        Task<List<ProductItems>> GetProductItems(string msisdn);
        Task<ValidateRes> ThrccProductRefValidation(string productItemCode, string productRef);
        Task<ValidateRes> ThmProductRefValidation(string productItemCode, string productRef);
        Task<DbResult<int>> UpdateSummaryThreeDSecureFailed(long Id);
        Task<ValidateRes> ThmProductRefValidation(string productItemCode, string productRef, string bundleRef);
        //Task<DigitalkValidationResponse> DigiTalkValidation(string msisdn);
        //Task<FullfilmentResponse> ThrccCustomerFullfilment(string transactionId, string amount, string productRef);
        //Task<FullfilmentResponse> ThccCustomerFullfilment(string transactionId, string amount);
        Task<FullfilmentResponse> ThccCustomerFullfilment(string transactionId,
            string amount,
            string email,
            string firstname);
        Task<FullfilmentResponse> ThrccCustomerFullfilment(string transactionId,
            string amount,
            string productRef,
            string email,
            string firstname);
        Task<FullfilmentResponse> ThmStraightCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef, string customerEmail, string productCode);
        Task<int> UpdateTransactionItem(int Id, string FullfillmentError, bool IsSmsSent, bool IsEmailSent, bool IsFullfilled, DateTime? SmsSent_DateTime, DateTime? EmailSent_DateTime, DateTime? FulfilmentDateTime);
        Task<List<TransactionItems>> GetTransactionItemsForFullfilment(string transactionId);
        Task<int> UpdateTransactionSummaryFullfilmentStatus(string Pay360TransactionId, int transactionStatusId, DateTime fulfilmentDate);
        Task<TransactionDetail> GetTransactionDetail(string pay360TransactionId);
        Task<FullfilmentResponse> NowCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef);
        Task<FullfilmentResponse> NowStraightCustomerFullfilment(string transactionId, string bundleRef, string amount, string productRef);
        Task<ValidateRes> ThaProductRefValidation(string productItemCode, string productRef);
        Task<ValidateRes> NowPayGProductRefValidation(string productItemCode, string productRef, string bundleRef);
        Task<int> UpdateCustomerAutoTopup_THRCC(float thresholdBalanceAmount, bool isAutoTopup, string productRef, decimal topupAmount, string topupCurrency, string email, string productCode);
        Task<GenericApiResponse<UserResponseGetAutoTopup_THRCC>> GetCustomerAutoTopup_THRCC(string msisdn, string email, string productCode);
        Task<int> GetPoints(string account);
        Task<int> THRCCAddRewardPoints(int auditId, string account, float amount);
        //Task<DbResult<bool>> ItsaValidateTopUp(string customerMsisdn, float transactionAmount);
        Task<DbResult<bool>> ItsaValidations(string customerMsisdn, float transactionAmount);
        Task<FullfilmentResponse> WtccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<FullfilmentResponse> ThaIvrCustomerFullfilment(string msisdn, string amount, string ccsTransId, string ccAuthCode);
        Task<FullfilmentResponse> StccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<FullfilmentResponse> BtccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<FullfilmentResponse> MtccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<FullfilmentResponse> TdccCustomerFullfilment(string transactionId, string amount, string email, string firstname);
        Task<FullfilmentResponse> ThaCustomerFullfilment(string msisdn, string amount, string ccsTransId, string ccAuthCode, string bundleRef);
        Task<GenericApiResponse<UserResponseGetAutoTopup>> GetCustomerAutoTopup_THA(string msisdn);
        Task<int> UpdateCustomerAutoTopup_THA(float autoTopupTheresholdAmount, bool isAutoTopup, string msisdn, decimal topupAmount, string topupCurrency);
    }
}
