﻿using BasketWebPanel.Areas.Dashboard.Models;
using BasketWebPanel.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.ViewModels
{
    public class AddplansViewModel : BaseViewModel
    {
        //public string Name { get; set; }
        public List<Country> Countries { get; set; }
        public IEnumerable<PlanCategory> PlanCategories { get; set; }
        public IEnumerable<Product> Products { get; set; }
        public IEnumerable<Currencies> Currencies { get; set; }
    }


}