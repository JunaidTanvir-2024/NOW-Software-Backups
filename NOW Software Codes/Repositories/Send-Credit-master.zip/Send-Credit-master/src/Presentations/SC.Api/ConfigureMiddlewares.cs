﻿namespace SC.Api;

public static class ConfigureMiddlewares
{
    public static WebApplication AddApiMiddlewares(this WebApplication app)
    {
        app.UseStaticFiles();
        app.UseSentryTracing();
        //app.UseAuthentication();
        //app.UseAuthorization();
        app.UseCors();
        app.UseInfrastructureMiddlewares();
        app.MapControllers();
        return app;
    }
}
