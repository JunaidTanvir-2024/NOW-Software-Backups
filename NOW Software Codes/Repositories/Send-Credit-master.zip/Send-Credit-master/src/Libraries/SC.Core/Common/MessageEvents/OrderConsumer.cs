﻿using MassTransit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using MessageBrokerModel;
using System.Text.RegularExpressions;
using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Interfaces.Repositories;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace SC.Core.Common.MessageEvents;
public class OrderConsumer(ICustomerCartRespository cartRepository) : IConsumer<TransactionMessageDto>
{
    private readonly ICustomerCartRespository _customerCartRepository = cartRepository;
    public async Task Consume(ConsumeContext<TransactionMessageDto> context)
    {
        var inventoryresponse = context.Message;
        //string input = inventoryresponse.TransactionReference;
        //string pattern = @"OrderID_(\d+)";
        //Match match = Regex.Match(input, pattern);
        //if (match.Success)
        //{
        //    string orderId = match.Groups[1].Value;
        //}

        if (inventoryresponse != null)
        {
            var cart = new List<CartStatusUpdateDto>();
            var crt = new CartStatusUpdateDto();
            crt.STATUS = inventoryresponse.TransactionItems.Status;
            long CartID;
            long.TryParse(inventoryresponse.TransactionItems.CartReference, out CartID);
            crt.ID = CartID;
            cart.Add(crt);
            var updateCartResponse = await _customerCartRepository.UpdateCartFinalStatusAsync(cart);
        }
    }
}

