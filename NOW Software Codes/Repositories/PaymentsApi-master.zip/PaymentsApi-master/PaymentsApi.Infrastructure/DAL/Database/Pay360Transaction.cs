﻿using PaymentsApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public partial class Pay360Transaction
    {
        public long Id { get; set; }
        public string Msisdn { get; set; }
        public string TransactionMerchantRef { get; set; }
        public string Pay360TransactionId { get; set; }
        public string TransactionDescription { get; set; }
        public int TransactionStatus_Id { get; set; }
        public int TransactionType_Id { get; set; }
        public double? TransactionAmount { get; set; }
        public string TransactionCurrency { get; set; }
        public string TransactionCommerceType { get; set; }
        public string TransactionChannel { get; set; }
        public DateTime? TransactionTime { get; set; }
        public DateTime? TransactionReceivedTime { get; set; }
        public DateTime? RequestTime { get; set; }
        public string OutcomeStatus { get; set; }
        public string OutcomeReasonCode { get; set; }
        public string OutcomeReasonMessage { get; set; }
        public string AuthStatusCode { get; set; }
        public string AuthMessage { get; set; }
        public string AuthCode { get; set; }
        public string AuthGatewayReference { get; set; }
        public string AuthGatewaySettlement { get; set; }
        public string AuthGatewayCode { get; set; }
        public string AuthGatewayMessage { get; set; }
        public string AuthAvsAddressCheck { get; set; }
        public string AuthAvsPostCodeCheck { get; set; }
        public string AuthCv2Check { get; set; }
        public string AuthStatus { get; set; }
        public string Route { get; set; }
        public int Customer_Id { get; set; }
        public string CardMaskedPan { get; set; }
        public int PaymentMethod_Id { get; set; }
        public int? PaypalId { get; set; }
        public string FinancialServicesDob { get; set; }
        public string FinancialServicesSurName { get; set; }
        public string FinancialServicesAccountNumber { get; set; }
        public string FinancialServicesPostCode { get; set; }
        public string RelatedTransactionId { get; set; }
        public string RelatedTransactionMerchantRef { get; set; }
        public bool Is3DSecure { get; set; }
        public string ThreeDSecureScheme { get; set; }
        public string ThreeDSecureStatus { get; set; }
        public string ThreeDSecureEnrolmentIndicator { get; set; }
        public string ThreeDSecureEnrolmentStatus { get; set; }
        public string ThreeDSecureEnrolmentDateTime { get; set; }
        public string ThreeDSecureXid { get; set; }
        public string ThreeDSecureEci { get; set; }
        public string ThreeDSecureAvv { get; set; }
        public string ThreeDSecureAuthenticationIndicator { get; set; }
        public string ThreeDSecureAuthenticationStatus { get; set; }
        public string ClientRirectType { get; set; }
        public string ClientRedirectUrl { get; set; }
        public string ClientRedirectPaReq { get; set; }
        public bool IsProcessedByDaemon { get; set; }
        public string DaemonErrorMessage { get; set; }
        public bool IsDaemonError { get; set; }
        public string RequestJsonToPay360 { get; set; }
        public string ResponseJsonFromPay360 { get; set; }
        public string IpAddress { get; set; }
        public string ApiInstallationIdCashierApi { get; set; }

        public Customer Customer { get; set; }
        public PaymentMethod PaymentMethod { get; set; }
        public Pay360TransactionType TransactionType { get; set; }
        public Pay360TransactionStatus TransactionStatus { get; set; }
        public Paypal Paypal { get; set; }
    }
}
