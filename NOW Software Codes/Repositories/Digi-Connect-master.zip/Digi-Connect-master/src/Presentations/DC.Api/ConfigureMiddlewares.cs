using DC.Api.Filter;

using Hangfire;

namespace DC.Api;

public static class ConfigureMiddlewares
{
    public static WebApplication AddApiMiddlewares(this WebApplication app)
    {
        app.UseSentryTracing();
        app.UseAuthentication();
        app.UseAuthorization();
        app.UseHangfireDashboard("/hangfire", new DashboardOptions
        {
            DashboardTitle = "Digi Connect Dashboard",
            Authorization = new[]
               {
                new  HangfireAuthorizationFilter("admin")
            }
        });
        app.UseInfrastructureMiddlewares();
        app.MapControllers();
        return app;
    }
}
