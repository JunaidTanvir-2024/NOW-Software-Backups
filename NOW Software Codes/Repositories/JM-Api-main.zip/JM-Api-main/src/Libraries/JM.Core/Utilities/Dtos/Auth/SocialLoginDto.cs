namespace JM.Core.Utilities.Dtos.Auth;

public abstract class SocialLoginDto
{
    public sealed record Request
    {
        public required long Id { get; set; }
        public required string Email { get; set; }
        public required string Username { get; set; }
        public required string Password { get; set; }
        public bool RememberMe { get; set; }
        public bool LockoutOnFailure { get; set; }
    }
    public sealed record Response
    {
        public required bool IsSuccess { get; set; }
        public required bool IsNotAllowed { get; set; }
        public UserInfo User { get; set; } = default!;
        public TokenInfo Token { get; set; } = default!;

        public sealed record UserInfo
        {
            public required long Id { get; set; }
            public required string Email { get; set; }
            public required string Username { get; set; }
            public required string FullName { get; set; }
            public required string ProfilePhoto { get; set; }
            public required CountryInfo Country { get; set; }
        }
        public sealed record TokenInfo
        {
            public required string JwtToken { get; set; }
            public required string RefreshToken { get; set; }
            public required DateTime JwtTokenExpiry { get; set; }
            public required DateTime RefreshTokenExpiry { get; set; }
        }
        public sealed record CountryInfo
        {
            public required string Name { get; set; }
            public required string IsoCode3 { get; set; }
        }
    }

}
