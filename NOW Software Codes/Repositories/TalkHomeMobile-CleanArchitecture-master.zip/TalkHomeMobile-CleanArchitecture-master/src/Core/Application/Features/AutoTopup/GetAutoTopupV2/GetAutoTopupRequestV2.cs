﻿namespace Application.Features.AutoTopup.GetAutoTopupV2;

public class GetAutoTopupRequestV2 : IRequest<Result<AutoTopupResponseV2>>
{
    public string Msisdn { get; set; } = default!;
}
