﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class ValidateCustomer
    {
            public int errorCode { get; set; }
            public int isAllowed { get; set; }
            public string Message { get; set; }
     
    }
}
