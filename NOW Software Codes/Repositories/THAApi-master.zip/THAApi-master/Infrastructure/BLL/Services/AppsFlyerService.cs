﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Request.AppsFlyer;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services
{
    public class AppsFlyerService : IAppsFlyerService
    {
        private readonly AppsFlyerConfig _appsFlyerConfig;
        private readonly ILogger Logger;
        private readonly HttpClient AppsFlyerClient;
        private readonly IHttpClientFactory _clientFactory;
        public AppsFlyerService(
                        IOptions<AppsFlyerConfig> appsFlyerConfig,
                        ILogger logger,
                        HttpClient httpClient,
                        IHttpClientFactory clientFactory)
        {
            _appsFlyerConfig = appsFlyerConfig.Value;
            Logger = logger;
            AppsFlyerClient = httpClient;
            _clientFactory = clientFactory;
        }

        public async Task CreateCustomEvent(List<CreateEventRequestModel> requestModel)
        {
            try
            {
                //var request = new HttpRequestMessage(HttpMethod.Post, "api/Home/CreateCustomEvent")
                //{
                //    Content = new StringContent(JsonConvert.SerializeObject(requestModel), Encoding.UTF8, "application/json")
                //};
                //await AppsFlyerClient.SendAsync(request);
                string aaa = "";
                var request = new HttpRequestMessage(HttpMethod.Post, _appsFlyerConfig.ApiEndpoint + "api/Home/CreateS2SMobileEvent")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(requestModel), Encoding.UTF8, "application/json")
                };

                var client = _clientFactory.CreateClient();

                //await client.SendAsync(request);
                HttpResponseMessage httpResponse = await client.SendAsync(request);
                if (httpResponse == null)
                {
                    aaa = "httpResponse is null";

                }
                else
                {
                    if (httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        aaa = "OK";
                    }
                    else if (httpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        aaa = "BadRequest";
                    }
                    else
                    {
                        aaa = "cadcascsacsa";
                    }
                }
            }
            catch(Exception)
            {
            }
        }


        public async Task HandleTopupEvents(string AppsFlyerId, DeviceType DeviceType, bool IsSuccess, bool? IsCard, decimal Amount, string currency, string origination, string ipAddress)
        {
            try
            {
                if (AppsFlyerId == null)
                    return;
                if (!_appsFlyerConfig.IsActive)
                    return;

                var transactionevents = new List<CreateEventRequestModel>();
                string paymentMethod = GetPaymentMethod(IsCard, "Topup");
                if (!String.IsNullOrEmpty(currency))
                {
                    ipAddress = currency;
                }

                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();

                

                if (IsSuccess)
                {
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new CreateEventRequestModel
                        {
                            appsflyer_id = AppsFlyerId,
                            deviceType = DeviceType,
                            eventName = "total_purchase_app",
                            eventValue = new
                            {
                                origination = origination,
                                af_revenue = Amount,
                            },
                            ////ip = ipAddress,
                            eventRevenue = Amount
                        });
                    }
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = "topup_any_app",
                        ////ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = "total_transaction_app",
                        ////ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"topup_any_{paymentMethod}_app",
                        ////ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"topup_any_{origination}_{paymentMethod}_app",
                        ////ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"topup_{Amount}_{origination}_app",
                        ////ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"topup_{Amount}_app",
                        ////ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"topup_{origination}_app",
                        ////ip = ipAddress,
                        eventRevenue = Amount
                    });
                }
                else
                {
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"payfail_any_app",
                        ////ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"payfail_any_{origination}_app",
                        ////ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"payfail_{paymentMethod}_app",
                        ////ip = ipAddress,
                        eventRevenue = Amount
                    });
                }
                await CreateCustomEvent(transactionevents);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AppsFlyerService, Method: FireTopupEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleBundlePurchaseEvents(string AppsFlyerId, DeviceType DeviceType, string origination, string destination, BundleType BundleType, bool IsSuccess, bool? IsCard, decimal Amount, string currency, string ipAddress)
        {
            try
            {
                if (AppsFlyerId == null)
                    return;
                if (!_appsFlyerConfig.IsActive)
                    return;

                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();

                if (!string.IsNullOrEmpty(destination))
                    destination = destination.ToLower().Trim();

                var transactionevents = new List<CreateEventRequestModel>();
                string bundleType = GetBundleType(BundleType);
                string paymentMethod = GetPaymentMethod(IsCard);

                

                if (IsSuccess)
                {
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new CreateEventRequestModel
                        {
                            appsflyer_id = AppsFlyerId,
                            deviceType = DeviceType,
                            eventName = $"total_purchase_app",
                            //ip = ipAddress,
                            eventRevenue = Amount,
                            eventValue = new
                            {
                                origination = origination,
                                af_revenue = Amount,
                            },
                        });
                    }
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_any_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"total_transaction_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_{paymentMethod}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_{bundleType}_any_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_dest_{destination}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_orig_{origination}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_dest_{bundleType}_{destination}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_orig_{bundleType}_{origination}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_any_{origination}_{destination}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_{bundleType}_{origination}_{destination}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_{bundleType}_{paymentMethod}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"bun_{bundleType}_{origination}_{destination}_{paymentMethod}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                }
                else
                {
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"payfail_bun_any_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"payfail_bun_{paymentMethod}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                }

                await this.CreateCustomEvent(transactionevents);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AppsFlyerService, Method: FireBundlePurchaseEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleIntTopupEvents(string AppsFlyerId, DeviceType DeviceType, string origination, string destination, bool IsSuccess, bool? IsCard, decimal Amount, string ipAddress,bool isTransferRequest)
        {
            try
            {
                if (AppsFlyerId == null)
                    return;
                if (!_appsFlyerConfig.IsActive)
                    return;

                var transactionevents = new List<CreateEventRequestModel>();

                string paymentMethod = GetPaymentMethod(IsCard);

                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();

                if (!string.IsNullOrEmpty(destination))
                    destination = destination.ToLower().Trim();

                

                if (IsSuccess)
                {
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new CreateEventRequestModel
                        {
                            appsflyer_id = AppsFlyerId,
                            deviceType = DeviceType,
                            eventName = $"total_purchase_app",
                            //ip = ipAddress,
                            eventRevenue = Amount,
                            eventValue = new
                            {
                                origination = origination,
                                af_revenue = Amount,
                            },
                        });
                    }

                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"inttop_any_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = "total_transaction_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"inttop_{paymentMethod}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"inttop_dest_{destination}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"inttop_orig_{origination}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"inttop_any_{origination}_to_{destination}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    if (isTransferRequest)
                    {
                        transactionevents.Add(new CreateEventRequestModel
                        {
                            appsflyer_id = AppsFlyerId,
                            deviceType = DeviceType,
                            eventName = $"req_inttop_sent_app",
                            //ip = ipAddress,
                            eventRevenue = Amount
                        });

                    }
                }
                else
                {
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"inttop_failure_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"inttopfail_{paymentMethod}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                    transactionevents.Add(new CreateEventRequestModel
                    {
                        appsflyer_id = AppsFlyerId,
                        deviceType = DeviceType,
                        eventName = $"inttopfail_any_{origination}_app",
                        //ip = ipAddress,
                        eventRevenue = Amount
                    });
                }
                await CreateCustomEvent(transactionevents);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AppsFlyerService, Method: HandleIntTopupEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleAutoTopup(string AppsFlyerId, DeviceType DeviceType, bool isActive, decimal Amount,string ipAddress)
        {
            if (AppsFlyerId == null)
                return;
            if (!_appsFlyerConfig.IsActive)
                return;
            List<CreateEventRequestModel> transactionevents = new List<CreateEventRequestModel>();
            transactionevents.Add(new CreateEventRequestModel
            {
                appsflyer_id = AppsFlyerId,
                deviceType = DeviceType,
                eventName = isActive ? "enable_autotop_app" : "disable_autotop_app",
                //ip = ipAddress,
                eventRevenue = Amount
            });

            await CreateCustomEvent(transactionevents);
        }
        private string GetBundleType(BundleType bundleType)
        {
            if (bundleType == BundleType.Welcome)
            {
                return "welcome";
            }
            else if (bundleType == BundleType.PAYG)
            {
                return "payg";
            }
            else if (bundleType == BundleType.Monthly)
            {
                return "roll";
            }
            else
            {
                return "trial";
            }
        }
        private string GetPaymentMethod(bool? IsCard, string type = null)
        {
            if (IsCard.HasValue)
            {
                if (IsCard.Value)
                {
                    return "card";
                }
                else
                {
                    return "paypal";
                }
            }
            else
            {
                if (type == "Topup")
                {
                    return "voucher";
                }
                else
                {
                    return "balance";
                }
            }
        }
    }
}
