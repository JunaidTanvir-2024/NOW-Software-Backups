using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class SubscriptionBenefit : IBaseEntity<long>
{
    public long Id { get; set; }
    public int Type { get; set; }
    public int UnitType { get; set; }
    public int Unit { get; set; }
    public int AdsFreeExperience { get; set; }
    public long SubscriptionId { get; set; }
    public Subscription Subscription { get; set; } = null!;
}
