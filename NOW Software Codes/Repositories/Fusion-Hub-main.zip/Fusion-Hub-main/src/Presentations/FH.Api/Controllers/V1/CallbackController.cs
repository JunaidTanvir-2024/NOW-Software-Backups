using Asp.Versioning;

using FH.Api.Controllers.Common;
using FH.UseCases.Callbacks;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.V1;

[ApiVersion(1.0)]
public sealed class CallbackController : BaseApiController
{
    [HttpPost("/DTone/Transaction")]
    public async Task<ActionResult> DTOneTransaction([FromBody] Transaction.Query query)
    {
        await Mediator.Send(query);
        return Ok();
    }
}
