﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Serilog;
using StatsdClient;
using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using TalkHomeContactSyncApi.Infrastructure.ContactSync;
using TalkHomeContactSyncApi.Models.Configuration;
using TalkHomeContactSyncApi.Models.Database;

namespace TalkHomeContactSyncApi.MiddleWare
{
    public class DogStatsDMiddleware
    {
        private readonly RequestDelegate Next;
        private static string SerilogFilePath;
        private readonly ILogger Logger;
        private readonly IContactSyncDB DB;

        public DogStatsDMiddleware(RequestDelegate next, IOptions<SerilogConfig> serilogConfig, IContactSyncDB dB)
        {
            Next = next;
            SerilogFilePath = serilogConfig.Value.FilePath;
            if (Logger == null)
            {
                Logger = new LoggerConfiguration()
                        .MinimumLevel.Information()
                        .WriteTo.RollingFile(SerilogFilePath + "\\DogStatsD\\DogStatsD-log-{Date}.txt")
                        .CreateLogger();
            }
            DB = dB;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            string authHeader = context.Request.Headers["Authorization"];
            if (authHeader != null && authHeader.StartsWith("basic", StringComparison.OrdinalIgnoreCase))
            {
                var token = authHeader.Substring("Basic ".Length).Trim();
                //System.Console.WriteLine(token);
                var credentialstring = Encoding.UTF8.GetString(Convert.FromBase64String(token));
                var credentials = credentialstring.Split(':');
                User user = new User();
                user = await DB.Login(credentials[0], credentials[1]);
                if (user!=null)
                {
                    var claims = new[] { new Claim("name", credentials[0]), new Claim(ClaimTypes.Role, "Admin") };
                    var identity = new ClaimsIdentity(claims, "Basic");
                    context.User = new ClaimsPrincipal(identity);
                    await this.Next(context);
                }
                else
                {
                    context.Response.StatusCode = 401;
                    context.Response.Headers.Add("WWW-Authenticate", "Basic realm=\"dotnetthoughts.net\"");
                }
            }
            else
            {
                context.Response.StatusCode = 401;
                context.Response.Headers.Add("WWW-Authenticate", "Basic realm=\"dotnetthoughts.net\"");
            }
            // Call the next delegate/middleware in the pipeline
            

            stopwatch.Stop();

            var date = DateTime.UtcNow.ToString("s", System.Globalization.CultureInfo.InvariantCulture);
            var client = context.Request.Headers["X-Forwarded-For"].ToString() ?? context.Connection.RemoteIpAddress.ToString();
            var method = context.Request.Method;
            var path = context.Request.Path.ToString();
            var responseTime = stopwatch.ElapsedMilliseconds();
            var StatusCode = context.Response.StatusCode;
            var StatusDescription = ((HttpStatusCode)StatusCode).ToString();

            DogStatsd.Increment("ActionExecuted");
            DogStatsd.Increment($"ActionExecuted.StatusCode.{StatusCode}_{StatusDescription}");
            DogStatsd.Histogram("ActionExecuted.ResponseTime", responseTime);

            var message = $"{date} {client} \"{method} {path}\" Status: {StatusCode} {StatusDescription} ResponseTime: {responseTime}ms";

#if !RELEASE
            Console.WriteLine(message);
#endif
            Logger.Information(message);

            // Call the next delegate/middleware in the pipeline
            //return this.Next(context);
        }


    }
}
