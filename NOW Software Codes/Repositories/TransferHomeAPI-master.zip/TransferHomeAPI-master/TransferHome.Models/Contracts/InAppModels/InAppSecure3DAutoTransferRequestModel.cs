﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.InAppModels
{
    public class InAppSecure3DAutoTransferRequestModel
    {
        public string MD { get; set; }
        public string PaRes { get; set; }

        public int Ref { get; set; }
        public string NowtelTransactionRef { get; set; }
        public string OperatorId { get; set; }
        public string Product { get; set; }
        public string MessageToRecipient { get; set; }
        public string FromMSISDN { get; set; }

        public DateTime RequestDatetime { get; set; }
        public RegularityType RegularityType { get; set; }
    }
}
