﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    
    public enum AuthType
    {
        Basic = 1,
        Bearer = 2
    }
}
