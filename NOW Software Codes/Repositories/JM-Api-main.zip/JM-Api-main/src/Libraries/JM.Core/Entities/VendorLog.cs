using JM.Core.Entities.Common;

namespace JM.Core.Entities;
public sealed class VendorLog : IBaseEntity<long>
{
    public long Id { get; set; }
    public string RequestPath { get; set; } = null!;
    public string RequestMethod { get; set; } = null!;
    public string RequestBody { get; set; } = null!;
    public string ResponseBody { get; set; } = null!;
    public int StatusCode { get; set; }
    public long ProcessDuration { get; set; }
    public string? ErrorReason { get; set; }
    public string RequestHeaders { get; set; } = null!;
    public string RequestReference { get; set; } = null!;
    public string ProductReference { get; set; } = null!;
    public DateTime RequestTimeStamp { get; set; }
    public long VendorId { get; set; }
    public Vendor Vendor { get; set; } = null!;
}
