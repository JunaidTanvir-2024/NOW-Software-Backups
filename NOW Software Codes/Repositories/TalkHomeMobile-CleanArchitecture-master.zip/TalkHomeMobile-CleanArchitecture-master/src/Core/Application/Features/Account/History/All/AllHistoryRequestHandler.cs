﻿using Application.Common.Models;
using Application.Common.Settings;
using Application.Features.Account.History.Models;
using Application.Features.Bundle.Model;
using Application.Features.Payment.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Application.Features.Account.History.All;

public sealed class AllHistoryRequestHandler : IRequestHandler<AllHistoryRequest, Result<AllHistoryResponse>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<AllHistoryRequestHandler> _localizer;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;
    private readonly IMapper _mapper;
    private readonly CallBackSettings _callbackSettings;

    public AllHistoryRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<AllHistoryRequestHandler> localizer,
        ICommonService commonService,
        IOptions<CallBackSettings> callbackSettings,
        IUserService userService,
        IMapper mapper)
    {
        _uow = uow;
        _localizer = localizer;
        _commonService = commonService;
        _userService = userService;
        _mapper = mapper;
        _callbackSettings = callbackSettings.Value;
    }

    public async Task<Result<AllHistoryResponse>> Handle(AllHistoryRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, _, _) = _commonService.IsAppRequest();
        var startDate = DateTime.UtcNow.Date.AddDays(-7);
        var endDate = DateTime.UtcNow.Date;
        const int pageNo = 1;
        const int pageSize = 20;
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<AllHistoryResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var callHistory = await _uow.UserRepo.CallHistory(request.Msisdn, startDate, endDate, pageNo, pageSize);
        var smsHistory = await _uow.UserRepo.SmsHistory(request.Msisdn, startDate, endDate, pageNo, pageSize);
        var dataHistory = await _uow.UserRepo.DataHistory(request.Msisdn, startDate, endDate, pageNo, pageSize);
        foreach (var item in dataHistory)
        {
            item.SubscriberCharge = CurrencySymbol.GBP + item.SubscriberCharge;
            item.DataUsage = _commonService.GetDataSize(Convert.ToInt64(item.DataUsage));
        }
        var paymentHistory = await _uow.UserRepo.PaymentHistory(request.Msisdn, startDate, endDate, pageNo, pageSize);

        // var paymentHistory = await _uow.UserRepo.PaymentHistory(request.Msisdn, startDate, endDate, pageNo, pageSize);
        var paymentHistoryInfo = new List<PaymentHistoryInfo>();
        foreach (var item in paymentHistory)
        {
            string CardMaskedPan = "", ImageURL = "", GoodyBagColorCode = "";
            if (!String.IsNullOrEmpty(item.OrderData))
            {
                var orderData = JsonConvert.DeserializeObject<OrderData>(item.OrderData!)!;
                if (orderData != null)
                {
                    if (item.PaymentMethodType == (int) PaymentMethod.Card)
                    {
                        CardMaskedPan = string.IsNullOrEmpty(orderData.CardMaskedPan)
                        ? "Card Payment" : orderData.CardMaskedPan;
                        ImageURL = (IsAppRequest ? _callbackSettings.AppBaseUrl! : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(orderData.CardScheme!);
                    }
                    if (orderData.BundleInfo != null)
                    {
                        if (!String.IsNullOrEmpty(orderData!.BundleInfo!.GoodyBagColorCode))
                        {
                            GoodyBagColorCode = orderData!.BundleInfo!.GoodyBagColorCode;
                        }
                        else
                        {
                            var bundle = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(item?.BundleId!));
                            if (bundle != null)
                            {
                                GoodyBagColorCode = bundle?.GoodyBagColorCode!;
                            }
                            else
                            {
                                GoodyBagColorCode = "basic";
                            }
                        }
                    }
                    else
                    {
                        if (item.TransactionType == (int) TransactionType.Bundle && item.IsAuto)
                        {
                            var bundle = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(item?.BundleId!));
                            if (bundle != null)
                            {
                                GoodyBagColorCode = bundle?.GoodyBagColorCode!;
                            }
                        }
                        else if (item.TransactionType == (int) TransactionType.Bundle || item.TransactionType == (int) TransactionType.CancelBundleRefund || item.TransactionType == (int) TransactionType.EarlyTerminationCharges)
                        {
                            var bundle = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(item?.BundleId!));
                            if (bundle != null)
                            {
                                GoodyBagColorCode = bundle?.GoodyBagColorCode!;
                            }
                        }
                    }
                }
            }
            else
            {
                CardMaskedPan = "Card Payment";
                ImageURL = (IsAppRequest ? _callbackSettings.AppBaseUrl! : _callbackSettings.WebBaseUrl!) + _commonService.GetCardLogo(null!);
                if (!string.IsNullOrEmpty(item.BundleId))
                {
                    var bundle = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(item?.BundleId!));
                    if (bundle != null)
                    {
                        GoodyBagColorCode = bundle?.GoodyBagColorCode!;
                    }
                    else
                    {
                        GoodyBagColorCode = "basic";
                    }
                }
            }
            PaymentHistoryInfo vm = new PaymentHistoryInfo
            {
                Amount = item.Amount,
                BundleCountryCode = item.BundleCountryCode,
                BundleName = item.BundleName,
                Discount = item.Discount,
                Msisdn = item.Msisdn,
                OrderID = item.OrderID,
                PaymentMethodType = item.PaymentMethodType,
                TotalAmount = item.TotalAmount,
                TotalCount = item.TotalCount,
                TransactionDate = item.TransactionDate,
                TransactionId = item.TransactionId,
                TransactionItemType = item.TransactionItemType,
                TransactionType = item.TransactionType,
                CardMaskedPan = CardMaskedPan,
                ImageURL = ImageURL,
                GoodyBagColorCode = GoodyBagColorCode,
                IsAuto = item.IsAuto,
                OrderStatus = ((int) item.OrderStatus).ToString()
            };
            paymentHistoryInfo.Add(vm);
        }

        var callHistoryResponse = new AllHistoryResponse()
        {
            CallHistory = callHistory,
            DataHistory = dataHistory,
            SmsHistory = smsHistory,
            PaymentHistory = paymentHistoryInfo
        };
        return Result<AllHistoryResponse>.Success(callHistoryResponse, _localizer[CustomStatusKey.Success]);
    }
}