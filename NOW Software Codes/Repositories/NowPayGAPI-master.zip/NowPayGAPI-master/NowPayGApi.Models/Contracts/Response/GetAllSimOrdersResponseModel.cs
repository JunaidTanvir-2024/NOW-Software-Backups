﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
  public class GetAllSimOrdersResponseModel
    {
        public IEnumerable<SimOrderResponseModel> OrderList { get; set; }
    }
}
