﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using TransferHome.Infrastructure.Services;
using TransferHome.Infrastructure.Services.Interfaces;
using TransferHome.Models.Contracts.Request;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TransferHomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PushNotificationsController : ControllerBase
    {
        private readonly ILogger Logger;
        private readonly IPushNotificationService PushService;

        public PushNotificationsController(ILogger logger, IPushNotificationService pushService)
        {
            PushService = pushService;
            Logger = logger;
        }
        
        [HttpGet]
        [Route("SendPushNotificationToAllUsers")]
        public async Task<IActionResult> SendPushNotificationToAll(string Title, string Text)
        {
            try
            {
                PushService.SendPushNotificationToAll(Title, Text);

                return Ok();
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: GetProducts, Parameters=> text: {Text}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        [HttpPost]
        [Route("SendPushToSepecificUsers")]
        public async Task<IActionResult> SendPushToSepecific(SendPushToSpecificModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var userMsisdn = model.Msisdn.Split(',').ToList();

                if (userMsisdn.Count > 0)
                {
                    PushService.SendPushNotificationToSpecificUsers(userMsisdn, model.Title,  model.Text);
                }

                return Ok();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
