using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Country;

public abstract class GetTripList
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public QueryFilter Filters { get; set; } = new QueryFilter();
        public sealed record QueryFilter
        {
            public long TripId { get; set; }
            public long TravelerId { get; set; }
            public AppEnum.OrderByDirection OrderBy { get; set; }
            public AppEnum.TripType TripType { get; set; }
        }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Filters!.TravelerId).NotNull().GreaterThan(0).When(x => x.Filters?.TripType == AppEnum.TripType.Personal || x.Filters?.TripType == AppEnum.TripType.Shared);
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public required string Name { get; set; }
        public DateTime StartingDate { get; set; }
        public long CreatorId { get; set; }
        public int TotalPlaces { get; set; }
        public int TotalMedia { get; set; }
        public int TotalTravelers { get; set; }
        public int TotalExpense { get; set; }
        public required CurrencyInfo Currency { get; set; }
        public sealed record CurrencyInfo
        {
            public long Id { get; set; }
            public required string Name { get; set; }
            public required string Code { get; set; }
            public required string Symbol { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IMediator _mediator = mediator;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {

            var tripList = query.Filters is null ?
            await _unitOfWork.TripRepository.GetTripList(x => x.IsActive) :
            await _unitOfWork.TripRepository.GetTripList(x => x.IsActive, query.Filters!.OrderBy, query.Filters.TripType, query.Filters.TravelerId);

            if (tripList is not null)
            {
                return ResultWrapper.Success(tripList is not null ? tripList.Select(x => new Response()
                {
                    Id = x.Id,
                    Name = x?.Name!,
                    StartingDate = x?.StartingDate ?? default,
                    CreatorId = x?.CreatorId ?? default,
                    TotalExpense = x?.Media?.Count ?? default,
                    TotalMedia = x?.Media.Count ?? default,
                    TotalPlaces = x?.TripPlaces.Count ?? default,
                    TotalTravelers = x?.Travelers.Count ?? default,
                    Currency = x?.Currency is not null ? new Response.CurrencyInfo()
                    {
                        Id = x.Currency.Id,
                        Name = x.Currency.Name,
                        Code = x.Currency.Code,
                        Symbol = x.Currency.Symbol,
                    } : default!
                }) : default);
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
        }
    }
    #endregion
}
