﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using System.Threading.Tasks;
using Serilog;
using System;
using Newtonsoft.Json;
using System.Net;
using System.Linq;
using System.Collections.Generic;
using System.Security.Claims;
using THAApi.Utilities;
using Microsoft.AspNetCore.Authorization;

namespace THAApi.Controllers
{
    [Route("sms")]
    [ApiController]
    public class SmsController : ControllerBase
    {

        
        private readonly ISMS_BL SmsService;
        private readonly ILogger Logger;

        public SmsController(ISMS_BL smsService, ILogger logger)
        {
            SmsService = smsService;
            Logger = logger;
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("resend/pin/{attempt}/{msisdn}")]
        public async Task<IActionResult> ResendPin(string attempt, string msisdn)
        {
            try
            {
                var reponse = await SmsService.ReSendSMS(attempt, msisdn);
                return Ok(reponse);
            }
            catch (Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: SmsController, Method: ResendPin, Parameters => msisdn: {msisdn}, attempt: {attempt}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return StatusCode((int)HttpStatusCode.InternalServerError, errorMessage);
            }
        }

        [HttpPost]
        [Route("send/referral")]
        public async Task<IActionResult> SendReferral([FromBody] Msisdn request)
        {
            try
            {
                var refferer = User.Msisdn();       
                var reponse = await SmsService.SendReferralCode(request, refferer);
                return Ok(reponse);
            }
            catch(Exception ex)
            {

                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: SmsController, Method: SendReferral, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return StatusCode((int)HttpStatusCode.InternalServerError, errorMessage);
            }
        }

    }
}
