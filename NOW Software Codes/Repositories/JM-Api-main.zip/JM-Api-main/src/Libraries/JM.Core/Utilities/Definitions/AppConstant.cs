namespace JM.Core.Utilities.Definitions;

public static class AppConstant
{
	public static class ContentType
	{
		public const string ApplicationJson = "application/json";
		public const string ApplicationOctetStream = "application/octet-stream";
		public const string ApplicationXml = "application/xml";
		public const string XlsxFile = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	}
	public static class Headers
	{
		public const string ProductReference = "x-product-ref";
		public const string RequestReference = "x-request-ref";
	}
	public static class Database
	{
		public const string Schema = "jm";
		public const string JourneyMingle = "JourneyMingle";
	}

	public static class SecurityHeader
	{
		public const string XFrameOptions = "X-FrameOptions";
		public const string XContentTypeOptions = "X-Content-Type-Options";
		public const string ReferrerPolicy = "Referrer-Policy";
		public const string PermissionsPolicy = "Permissions-Policy";
		public const string SameSite = "SameSite";
		public const string XxssProtection = "X-XSS-Protection";
		public const string ContentPolicy = "ContentPolicy";
	}

	public static class StatusKey
	{
		public const string Success = "Congratulations! request fulfilled successfully.";
		public const string BadRequest = "Whoops! Something went wrong with your request.";
		public const string Forbidden = "Sorry, you are not allowed.";
		public const string NotFound = "Hmmm, we couldn't find what you're looking for.";
		public const string Unauthorized = "Oops! You are not authorized";
		public const string InternalServerError = "Whoops! Something went wrong on our end.";
		public const string Conflict = "Whoops! Similar record already exist";
		public const string TooManyRequests = "Whoops! You have reached requests limit";

		// Token
		public const string JwtTokenMissing = "Uh oh! Token is missing. Please try again with a valid token.";
		public const string JwtTokenExpired = "Whoops! Your token has expired. Please request a new one.";
		public const string JwtTokenInvalid = "Whoops! Your authorization token is invalid. Please try again with a valid token.";

		// Refresh Token
		public const string RefreshToken = "Congratulations! Your JWT token has been successfully refreshed";

		public const string UserCreated = "Congratulations! You have successfully signed up";
		public const string ProfileCompleted = "Congratulations! You have successfully completed your profile";
		public const string ChangePassword = "Congratulations! You have successfully changed your password";

		// Otp
		public const string OtpInvalid = "Invalid Otp";
		public const string OtpValid = "Otp is valid";
		public const string OtpSent = "You will receive otp code shortly";
		public const string AlreadyFriend = "You are already friend";
		public const string FriendshipPending = "Your request is already submitted";
	}

	public static class StatusCode
	{
		public const int Success = Microsoft.AspNetCore.Http.StatusCodes.Status200OK;
		public const int BadRequest = Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest;
		public const int Forbidden = Microsoft.AspNetCore.Http.StatusCodes.Status403Forbidden;
		public const int NotFound = Microsoft.AspNetCore.Http.StatusCodes.Status404NotFound;
		public const int Unauthorized = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;
		public const int InternalServerError = Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError;
		public const int Created = Microsoft.AspNetCore.Http.StatusCodes.Status201Created;
		public const int Conflict = Microsoft.AspNetCore.Http.StatusCodes.Status409Conflict;
		public const int TooManyRequests = Microsoft.AspNetCore.Http.StatusCodes.Status429TooManyRequests;

		// Token
		public const int JwtTokenMissing = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;
		public const int JwtTokenInvalid = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;
		public const int JwtTokenExpired = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;

		// Refresh
		public const int RefreshToken = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;
	}
}
