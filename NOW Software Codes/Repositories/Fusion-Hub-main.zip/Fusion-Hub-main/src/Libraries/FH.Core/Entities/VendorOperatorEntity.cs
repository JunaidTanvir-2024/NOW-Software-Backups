namespace FH.Core.Entities;

public sealed record VendorOperatorEntity : BaseEntity<long>
{
    public string? Name { get; set; }
    public string? Logo { get; set; }
    public string? VendorOperatorCode { get; set; }
    public long OperatorId { get; set; }
    public long CountryId { get; set; }
}
