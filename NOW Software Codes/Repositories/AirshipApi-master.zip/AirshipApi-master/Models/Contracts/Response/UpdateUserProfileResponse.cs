﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class UpdateUserProfileResponse
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("email")]       
        public string Email { get; set; }

        [JsonProperty("dateOfBirth")]       
        public DateTime DateOfBirth { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("image")]        
        public string Image { get; set; }
    }
}
