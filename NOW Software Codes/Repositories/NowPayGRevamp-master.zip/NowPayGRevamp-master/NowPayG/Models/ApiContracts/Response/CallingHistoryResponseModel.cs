﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Response
{
    public class CallingHistoryResponseModel
    {
        public string calling_party_number { get; set; }
        public string called_party_number { get; set; }
        public string start_time { get; set; }
        public string duration { get; set; }
        public string inbound { get; set; }
        public string subscriber_charge { get; set; }
    }
}
