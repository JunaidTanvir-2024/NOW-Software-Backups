﻿
using System.ComponentModel.DataAnnotations;

namespace THCC.Infrastructure.Services.Payment.Models
{
    public class ProductBasket
    {
        public string? ProductItemCode { get; set; }
        public decimal Amount { get; set; }
        public string? ProductRef { get; set; }
        public string? BundleRef { get; set; }
    }
}
