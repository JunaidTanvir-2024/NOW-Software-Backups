namespace Voucherify.Api.Features.Products.Responses;

public class ProductResponse
{

}
