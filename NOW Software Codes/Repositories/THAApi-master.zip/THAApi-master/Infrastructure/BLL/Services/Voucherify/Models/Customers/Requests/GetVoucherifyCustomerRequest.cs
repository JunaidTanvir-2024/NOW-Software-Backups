﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests
{
    public class GetVoucherifyCustomerRequest
    {
        public string SourceId { get; set; }
        public string LoyaltyCampaignId { get; set; }
    }
}
