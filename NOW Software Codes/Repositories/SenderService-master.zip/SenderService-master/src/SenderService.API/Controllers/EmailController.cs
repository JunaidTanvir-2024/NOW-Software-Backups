﻿using Microsoft.AspNetCore.Mvc;
using SenderService.API.Controllers.Common;
using SenderService.Core.Common;
using SenderService.Core.Features.Email;
using SenderService.Core.Features.Email.Request;
using SenderService.Core.Features.EmailValidation;

namespace SenderService.API.Controllers;

public class EmailController : BaseApiController
{

    private readonly IEmailService _emailService;
    private readonly IEmailValidationService _emailValidationService;

    public EmailController(IEmailService emailService, IEmailValidationService emailValidationService)
    {
        _emailService = emailService;
        _emailValidationService = emailValidationService;
    }

    [HttpGet]
    public async Task<ActionResult> GetUnsetEmails([FromQuery] GetEmailsRequest request)
    {
        var emails = await _emailService.GetEmailsAsync(request);
        if (emails.Status)
        {
            return Ok(emails);
        }
        else
        {
            return NotFound(emails);
        }
    }


    [HttpPost]
    public async Task<ActionResult<bool>> AddEmail(AddEmailRequest request)
    {
        var result = await _emailService.AddEmailAsync(request);
        if (result.Status)
        {
            return CreatedAtAction(nameof(GetUnsetEmails), routeValues: result.Payload, value: result);
        }
        else
        {
            return BadRequest(result);
        }
    }

    [HttpPost("Validation")]
    public async Task<ActionResult> EmailValidation(ValidateEmailRequest request)
    {
        var emailValidation = await _emailValidationService.ValidateEmailAsync(request);
        if (emailValidation.Status == true)
        {
            return Ok(emailValidation);
        }
        else
        {
            return BadRequest(emailValidation);
        }
    }

    [HttpDelete]
    public async Task<ActionResult<int>> DeleteEmail(RemoveEmailRequest request)
    {
        await _emailService.DeleteEmailAsync(request);
        return Ok(ApiResult<bool>.Success(message: "Email Deleted"));
    }

    private string GetIpAddress()
    {
        // Check X-Forwarded-For header first
        //if the request passes through multiple proxies then there will be multiple addresses
        
        if (Request.Headers.TryGetValue("X-Forwarded-For", out var headerValues))
        {
            var header = headerValues.FirstOrDefault();
            if (!string.IsNullOrEmpty(header))
            {
                var ips = header.Split(',', StringSplitOptions.RemoveEmptyEntries)
                                .Select(s => s.Trim())
                                .ToList();
                if (ips.Count > 0)
                {
                    return ips[0];
                }
            }
        }

        // Fall back to RemoteIpAddress if there is no address found in X-Forwarded-For header
        var remoteIpAddress = HttpContext.Connection.RemoteIpAddress;
        if (remoteIpAddress != null)
        {
            return remoteIpAddress.MapToIPv4().ToString();
        }

        // Unable to determine any valid IP address
        return "N/A";
    }
}
