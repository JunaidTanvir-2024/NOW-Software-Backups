﻿using Application.Common.Caching;
using Application.Common.Interfaces;
using Application.Features.Account.Product.Add;

namespace Application.Features.Account.Product.MakeDefault;
public class DefaultProductRequestHandler : IRequestHandler<DefaultProductRequest, Result<IOrderedEnumerable<UserProductInfo>>>
{
    #region Fields

    private readonly IStringLocalizer<AddProductRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly ICurrentUser _currentUser;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;
    private readonly IMapper _mapper;
    private readonly IUserService _userService;

    #endregion

    #region Ctor

    public DefaultProductRequestHandler(IStringLocalizer<AddProductRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService,
        ICurrentUser currentUser,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService,
        IMapper mapper,
        IUserService userService)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _currentUser = currentUser;
        _cacheService = cacheService;
        _cacheKeyService = cacheKeyService;
        _mapper = mapper;
        _userService = userService;
    }

    #endregion

    #region Method

    public async Task<Result<IOrderedEnumerable<UserProductInfo>>> Handle(DefaultProductRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<IOrderedEnumerable<UserProductInfo>>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Set Default Product
        await _unitOfWork.UserRepo.SetDefaultProduct(
           new UserProduct()
           {
               Msisdn = request.Msisdn,
               UserId = _currentUser.GetUserId()
           });

        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.UserProduct, _currentUser.GetUserId().ToString()), cancellationToken);

        var updatedProducts = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        var userProducts = _mapper.Map<IEnumerable<UserProductInfo>>(updatedProducts).ToList();

        return Result<IOrderedEnumerable<UserProductInfo>>.Success(userProducts.OrderByDescending(x => x.IsDefault), _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
