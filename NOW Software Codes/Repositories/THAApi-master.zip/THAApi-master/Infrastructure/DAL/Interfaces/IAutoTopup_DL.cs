﻿using Models.Database;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface IAutoTopup_DL
    {
        Task<AutoTopupDetail> Get(string msisdn);
        Task<int> Set(AutoTopupDetail entity);
    }
}