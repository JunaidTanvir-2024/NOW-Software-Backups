namespace Application.Features.Bundle.Bundle;

public sealed class UnSubscribeBundlesRequestValidator : AbstractValidator<UnSubscribeBundlesRequest>
{
    public UnSubscribeBundlesRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn)
            .NotEmpty()
            .NotNull()
             .WithMessage("Msisdn is required")
            .Must(p => commonService.IsValidMsisdn(p!))
            .When(p => !string.IsNullOrEmpty(p.Msisdn))
            .WithMessage("Invalid Msisdn");

        RuleFor(p => p.PackageId)
            .NotEmpty()
            .NotNull()
            .WithMessage("Package Id cannot be empty");
    }
}