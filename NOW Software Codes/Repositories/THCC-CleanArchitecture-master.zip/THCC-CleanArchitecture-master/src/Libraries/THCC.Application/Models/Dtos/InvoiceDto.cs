﻿namespace THCC.Application.Models.Dtos
{
    public class InvoiceDto
    {
        public string? Email { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? TransactionId { get; set; }
        public string? OrderDate { get; set; }
        public string? OrderTime { get; set; }
        public string? Product { get; set; }
        public string? PaymentMethod { get; set; }
        public string? RechargeAmount { get; set; }
        public string? TotalAmount { get; set; }
        public string? CardNumber { get; set; }
        public string? PinNumber { get; set; }
        public string? OpeningBalance { get; set; }
        public string? ClosingBalance { get; set; }
        public int? OpeningPoints { get; set; }
        public int? RewardPoints { get; set; }
        public int? ClosingPoints { get; set; }
        public bool IsGuestUser { get; set; }
    }
}
