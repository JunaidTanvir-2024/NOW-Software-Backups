﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{
    public class HttpConfig
    {
        public double TimeOut { get; set; }
    }
}
