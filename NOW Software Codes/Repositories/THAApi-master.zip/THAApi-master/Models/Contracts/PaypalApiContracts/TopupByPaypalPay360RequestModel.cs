﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.PaypalApiContracts
{
	public class TopupByPaypalPay360RequestModel
	{
		[Required]
		public string Token { get; set; }
	}
}
