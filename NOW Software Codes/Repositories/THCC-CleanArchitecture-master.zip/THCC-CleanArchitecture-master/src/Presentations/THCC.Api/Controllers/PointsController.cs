﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using THCC.Api.Controllers.Common;
using THCC.Application.Features.RedeemPoints;

namespace THCC.Api.Controllers
{
    public class PointsController : BaseApiController
    {
        [HttpPost("redeem/{Points}"), Authorize]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> RedeemPoints([FromRoute] RedeemPointRequest request, CancellationToken cancellationToken)
        {
            return HandleResponse(await Mediator.Send(request, cancellationToken));
        }
    }
}
