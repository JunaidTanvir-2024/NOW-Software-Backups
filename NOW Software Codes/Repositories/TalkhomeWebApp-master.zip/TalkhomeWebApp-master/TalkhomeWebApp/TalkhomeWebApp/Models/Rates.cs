﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models
{
    public class Rates
    {
        public int Id { get; set; }
        public string Destination { get; set; }
        public decimal Landline { get; set; }
        public decimal Mobile { get; set; }
        public decimal SMS { get; set; }
        public decimal OffPeakLandline { get; set; }
        public decimal OffPeakMobile { get; set; }
        public decimal OffPeakSMS { get; set; }
        public string ISO2Code { get; set; }
    }
}
