﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class PaypalPaymentResponseModel
    {
        public string clientRedirectUrl { get; set; }
    }

    public class PaypalByPay360PaymentCallBackResponseModel
    {
        public BundlePurchaseInfo bundlePurchaseInfo { get; set; }
        public TopupInfo topupInfo { get; set; }
        public string CampaignName { get; set; }
        public bool IsRedeemedSuccess { get; set; }
    }
}
