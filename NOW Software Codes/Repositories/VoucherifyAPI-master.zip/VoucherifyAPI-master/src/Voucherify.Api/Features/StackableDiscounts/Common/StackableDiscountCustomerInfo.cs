﻿using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.StackableDiscounts.Common;

public class StackableDiscountCustomerInfo
{
    public string? SourceId { get; set; }
    public Metadata? Metadata { get; set; }
}
