﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ViewModels.Account
{
    public class UserProfileViewModel
    {
        public int Id { get; set; }
        public string Token { get; set; }
        [Required(ErrorMessage = "Enter first name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-z]+([\s][a-zA-Z]+)*$", ErrorMessage = "Use letters only please")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Enter last name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-z]+([\s][a-zA-Z]+)*$", ErrorMessage = "Use letters only please")]
        public string LastName { get; set; }
        public string AccountNumber { get; set; }
        public string Address { get; set; }
        public int CountryId { get; set; }
        public string Email { get; set; }
        public string ProductRef { get; set; }
        public string ProductCode { get; set; }
        public string PinCode { get; set; }
        public int Points { get; set; }
        public string Cradit { get; set; }
        public string NavType { get; set; }
        public bool MailSubscription { get; set; }
        public string LastTopUpDate { get; set; }
        public decimal? LastTopUp { get; set; }
    }
}
