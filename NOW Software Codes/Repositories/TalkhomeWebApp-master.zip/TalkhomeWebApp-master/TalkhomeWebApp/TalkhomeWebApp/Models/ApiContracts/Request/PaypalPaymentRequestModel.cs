﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class PaypalPaymentRequestModel
    {
        public int TopUpAmount { get; set; }
        public string BundleId { get; set; }
        public CheckOutTypes CheckoutType { get; set; }
        public string ipAddress { get; set; }
        public string EmailAddress { get; set; }
        public string Msisdn { get; set; }

        public string FromBundleISO2 { get; set; }
        public BundleType BundleType { get; set; }
        public string ToBundleISO2 { get; set; }
    }
}
