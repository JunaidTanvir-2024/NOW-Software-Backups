USE [EmailSenderService]
GO
/****** Object:  StoredProcedure [dbo].[SP_AddEmailValidation]    Script Date: 2/28/2023 4:42:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Insert Valid, Invalid email address and block domain store procedure

CREATE PROCEDURE [dbo].[SP_AddEmailValidation] 
    @Email NVARCHAR(510),
    @Status NVARCHAR(50),
    @Domain NVARCHAR(250),
    @SubStatus NVARCHAR(50),
    @ProductCodeId BIGINT,
	@RequestBody NVARCHAR(MAX),
	@ResponseBody NVARCHAR(MAX)
AS
BEGIN
    DECLARE @IsValidEmail BIT
    SET @IsValidEmail = 0
    
    IF (@Status = 'Valid')
    BEGIN
        SET @IsValidEmail = 1
        INSERT INTO [dbo].[EmailValidations] (Email, IsVerified, ProcessDate, ProductCodeId, RequestBody, ResponseBody)
        VALUES (@Email, 1, SYSDATETIMEOFFSET(), @ProductCodeId,@RequestBody, @ResponseBody)
    END
    ELSE
    BEGIN
    -- Blocked domain if zero bounce api return substatus = disposable, and also add 
        IF (@SubStatus = 'Disposable')
        BEGIN
            INSERT INTO [dbo].[BlockedDomains] (Domain, BlockDate)
            VALUES (@Domain, SYSDATETIMEOFFSET())
            
            INSERT INTO [dbo].[EmailValidations] (Email, IsVerified, ProcessDate, InvalidReason, ProductCodeId, RequestBody, ResponseBody)
            VALUES (@Email, 0, SYSDATETIMEOFFSET(), 'Disposable Email Address', @ProductCodeId,@RequestBody, @ResponseBody)
        END
        ELSE
        BEGIN
            INSERT INTO [dbo].[EmailValidations] (Email, IsVerified, ProcessDate, InvalidReason, ProductCodeId, RequestBody, ResponseBody)
            VALUES (@Email, 0, SYSDATETIMEOFFSET(), 'Invalid Email Address', @ProductCodeId,@RequestBody, @ResponseBody)
        END
    END
END
