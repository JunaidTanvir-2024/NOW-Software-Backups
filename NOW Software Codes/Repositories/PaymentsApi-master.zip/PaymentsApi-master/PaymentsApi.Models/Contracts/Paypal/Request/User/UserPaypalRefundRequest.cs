﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace PaymentsApi.Models.Contracts.Paypal.Request.User
{
    public class UserPaypalRefundRequest
    {
        [Required]
        [JsonProperty("TransactionId")]
        public string TransactionId { get; set; }
    }
}
