﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Configurations
{
    public class ConnectionString
    {
        public string NowPaygDbConnection { get; set; }
        public string DigitalkMobileDbConnection { get; set; }
        public string NowMobileRepDbConnection { get; set; }
    }
}
