﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;
using THCC.Domain.Aggregates;

namespace THCC.Application.Interfaces.Repositories
{
    public interface ICallingCardRepository : ServiceType.IScoped
    {
        Task<PinDetail> GetPinInfo(string pin);
        Task<PinDetail> GetCardInfo(string cardNumber);
        Task<string> GetFirstUseDate(string cardNumber);
        Task<ClassicPinDetail> GetClassicPinDetails(string pinNumber);
        Task<bool> IsUserPinNumber(string pinNumber, string userId);
        Task<List<CardCallHistory>> GetClassicCardCallHistory(string pinNumber);
        Task<List<CardCallHistory>> GetRechargableCardCallHistory(string pinNumber);
        Task<bool> IsCardNumberRegistered(string cardNumber);
        Task<List<CallingCardConsumption>> GetClassicCardConsumptionHistory();
        Task UpdateClassicCardConsumptionItems(long id, float percentage);
      
        Task<List<CallingCardCDRHistory>> GetClassicCardCDRHistory();
        Task UpdateClassicCardCDRItem(long id);
        Task UpdateTHRCCCDRItem(long id);
        Task<List<CallingCardCDRHistory>> GetTHRCCCDRHistory();
    }
}
