﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Requests
{
    public class GetPromotionTiersRequest
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
