﻿namespace ATT.Models.Database
{
    public class AttSmsLogging
    {
        public string TransactionId { get; set; }
        public string SenderMsisdn { get; set; }
        public string ReceiverMsisdn { get; set; }
        public string PinCode { get; set; }
        public string SmsText { get; set; }
        public int SmsStatus { get; set; }
        public string SmsError { get; set; }
        public long UnixTimeStamp { get; set; }
        public string SmsSid { set; get; }  
    }
}
