CREATE TABLE [SchemaName].[Country]
(
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [IsoCode2] CHAR(2) NOT NULL,
    [IsoCode3] CHAR(3) NOT NULL,
    [CallingCode] SMALLINT NOT NULL,
    [Name] NVARCHAR(50) NOT NULL,
    [IsoCodeNumeric] NVARCHAR(5) NOT NULL,
    [Continent] NVARCHAR(50) NOT NULL,
    [FlagEmoji] NVARCHAR(50) NULL,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [IsDeleted] BIT NOT NULL DEFAULT 0,
    [CreatedAt] DATETIME NOT NULL DEFAULT GETUTCDATE(),
    [UpdatedAt] DATETIME NULL
);

CREATE TABLE [SchemaName].[Vendor]
(
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [Name] NVARCHAR(50) NOT NULL,
    [Description] NVARCHAR(MAX) NULL,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [IsDeleted] BIT NOT NULL DEFAULT 0,
    [CreatedAt] DATETIME NOT NULL DEFAULT GETUTCDATE(),
    [UpdatedAt] DATETIME NULL
);

CREATE TABLE [SchemaName].[AppLog]
(
    [Id]                BIGINT IDENTITY(1,1) PRIMARY KEY,
    [RequestReference]  NVARCHAR(50) NOT NULL,
    [RequestPath]       NVARCHAR(255) NOT NULL,
    [RequestMethod]     NVARCHAR(10) NOT NULL,
    [RequestBody]       NVARCHAR(2000) NOT NULL,
    [StatusCode]        INT NOT NULL,
    [ProcessDuration]   BIGINT NOT NULL,
    [ClientIp]          NVARCHAR(50) NOT NULL,
    [UserAgent]         NVARCHAR(255) NOT NULL,
    [ErrorReason]       NVARCHAR(MAX) NULL,
    [RequestHeaders]    NVARCHAR(3000) NOT NULL,
    [ResponseBody]      NVARCHAR(MAX) NOT NULL,
    [ProductReference]  NVARCHAR(50) NOT NULL,
    [RequestTimestamp]  DATETIME2 NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE [SchemaName].[VendorLog] (
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [RequestPath] NVARCHAR(255) NULL,
    [RequestMethod] NVARCHAR(10) NULL,
    [RequestBody] NVARCHAR(1000) NULL,
    [RequestReference] NVARCHAR(50) NOT NULL,
    [ProductReference] NVARCHAR(15) NOT NULL,
    [ResponseBody] NVARCHAR(MAX) NULL,
    [StatusCode] INT NULL,
    [ProcessDuration] BIGINT NULL,
    [ErrorReason] NVARCHAR(1000) NULL,
    [RequestHeaders] NVARCHAR(2000) NULL,
    [RequestTimeStamp] DATETIME2 NOT NULL DEFAULT CURRENT_TIMESTAMP,
    [VendorId] BIGINT NOT NULL FOREIGN KEY REFERENCES [SchemaName].[Vendor]([VendorId])
);

CREATE TABLE [SchemaName].[Otp]
(
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [Code] INT NOT NULL,
    [Type] SMALLINT NOT NULL,
    [UsageCount] SMALLINT NOT NULL,
    [IsAlreadyUsed] BIT NOT NULL DEFAULT 0,
    [IsBlocked] BIT NOT NULL DEFAULT 0,
    [IsRetryLimitExceeded] BIT NOT NULL DEFAULT 0,
    [BlockTime] DATETIME NULL,
    [ExpiryTime] DATETIME NOT NULL,
    [CreatedAt] DATETIME NOT NULL DEFAULT GETUTCDATE(),
    [UpdatedAt] DATETIME NULL,
    [UserId] BIGINT NOT NULL FOREIGN KEY REFERENCES [SchemaName].[User]([Id])
);


CREATE TABLE [SchemaName].[UserDetail]
(
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [FullName] NVARCHAR(255) NULL,
    [ProfilePhoto] NVARCHAR(255) NULL,
    [RefreshToken] NVARCHAR(500) NULL,
    [RefreshTokenExpiry] DATETIME NULL,
    [CreatedAt] DATETIME NOT NULL DEFAULT GETUTCDATE(),
    [UpdatedAt] DATETIME NULL,
    [UserId] BIGINT NOT NULL FOREIGN KEY REFERENCES [SchemaName].[User]([Id]),
    [CountryId] BIGINT NOT NULL FOREIGN KEY REFERENCES [SchemaName].[Country]([Id])
);


CREATE TABLE [SchemaName].[Trip] (
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [Name] NVARCHAR(255),
    [StartingDate] DATETIME,
    [EndingDate] DATETIME,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [IsDeleted] BIT NOT NULL DEFAULT 0,
    [Thumbnail] NVARCHAR(255),
    [DeletedAt] DATETIME,
    [CreatorId] BIGINT NOT NULL FOREIGN KEY REFERENCES [SchemaName].[User]([Id]),
);

CREATE TABLE [SchemaName].[Place]
(
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [Name] NVARCHAR(255) NOT NULL,
    [Description] NVARCHAR(MAX) NOT NULL,
    [Latitude] DECIMAL(9, 6) NULL,
    [Type] NVARCHAR(255) NULL,
    [ImageUrl] NVARCHAR(255) NULL,
    [Longitude] DECIMAL(9, 6) NULL,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [IsDeleted] BIT NOT NULL DEFAULT 0
);

CREATE TABLE [SchemaName].[ExpenseCategory]
(
    [Id] INT IDENTITY(1,1) PRIMARY KEY,
    [Name] NVARCHAR(50)
);

CREATE TABLE [SchemaName].[Traveler]
(
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [UserId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[User]([Id]),
    [TripId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[Trip]([Id])
);

CREATE TABLE [SchemaName].[Media]
(
    [Id] BIGINT PRIMARY KEY IDENTITY(1,1),
    [Type] NVARCHAR(50),
    [Url] NVARCHAR(255),
    [Description] NVARCHAR(MAX),
    [UploadDate] DATETIME,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [IsDeleted] BIT NOT NULL DEFAULT 0,
    [DeletedAt] DATETIME NULL,
    [TripId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[Trip]([Id]),
    [TravelerId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[Traveler]([Id])
);

CREATE TABLE [SchemaName].[Expense] (
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [Description] NVARCHAR(MAX),
    [Amount] DECIMAL(18,2),
    [CurrencyUnit] SMALLINT,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [IsDeleted] BIT NOT NULL DEFAULT 0,
    [TravelerId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[Traveler] ([Id]),
    [TripId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[Trip] ([Id]),
    [CategoryId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[ExpenseCategory] ([Id])
);


CREATE TABLE [SchemaName].[ChatRoom] (
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [Name] NVARCHAR(50),
    [IsPrivate] BIT,
    [TripId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[Trip] ([Id])
);


CREATE TABLE [SchemaName].[ChatMessage] (
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [Content] NVARCHAR(MAX),
    [Timestamp] DATETIME2 NOT NULL DEFAULT CURRENT_TIMESTAMP,
    [ChatRoomId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[ChatRoom] ([Id]),
    [SenderId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[User] ([Id]),
    [ReceiverId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[User] ([Id]),
);


CREATE TABLE [SchemaName].[Subscription] (
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [Price] DECIMAL(18,2),
    [IsActive] BIT NOT NULL DEFAULT 1,
    [IsDeleted] BIT NOT NULL DEFAULT 0,
    [StartDate] DATETIME NULL,
    [ExpiryDate] DATETIME NULL,
    [CreatedAt] DATETIME NOT NULL DEFAULT GETUTCDATE(),
    [UpdatedAt] DATETIME DEFAULT GETUTCDATE(),
    [DeletedAt] DATETIME NULL
);


CREATE TABLE [SchemaName].[SubscriptionBenefit] (
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [Type] INT NOT NULL,
    [UnitType] INT NOT NULL,
    [Unit] INT NOT NULL,
    [AdsFreeExperience] BIT NOT NULL DEFAULT 0,
    [CreatedAt] DATETIME NOT NULL DEFAULT GETUTCDATE(),
    [UpdatedAt] DATETIME DEFAULT GETUTCDATE(),
    [DeletedAt] DATETIME NULL,
    [SubscriptionId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[Subscription] ([Id])
);


CREATE TABLE [SchemaName].[UserSubscription] (
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [UserId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[User] ([Id]),
    [SubscriptionId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[Subscription] ([Id])
);


CREATE TABLE [SchemaName].[Friendship] (
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [Status] NVARCHAR(15),
    [InitiatorId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[User] ([Id]),
    [ResponderId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[User] ([Id])
);


CREATE TABLE [SchemaName].[TripPlace] (
    [Id] BIGINT IDENTITY(1,1) PRIMARY KEY,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [IsDeleted] BIT NOT NULL DEFAULT 0,
    [PlaceId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[Place] ([Id]),
    [TripId] BIGINT FOREIGN KEY REFERENCES [SchemaName].[Trip] ([Id])
);

-- Otp Table
CREATE INDEX IX_Otp_Code ON [SchemaName].[Otp](Code);
CREATE INDEX IX_Otp_ExpiryTime ON [SchemaName].[Otp](ExpiryTime);

-- User Detail Table
CREATE INDEX IX_UserDetail_UserId ON [SchemaName].[UserDetail](UserId);
CREATE INDEX IX_UserDetail_CountryId ON [SchemaName].[UserDetail](CountryId);

-- Trip Table
CREATE INDEX IX_Trip_CreatorId ON [SchemaName].[Trip](CreatorId);

-- Place Table
CREATE INDEX IX_Place_Name ON [SchemaName].[Place](Name);

-- Expense Table
CREATE INDEX IX_Expense_TravelerId ON [SchemaName].[Expense](TravelerId);
CREATE INDEX IX_Expense_TripId ON [SchemaName].[Expense](TripId);
CREATE INDEX IX_Expense_CategoryId ON [SchemaName].[Expense](CategoryId);

-- ChatRoom Table
CREATE INDEX IX_ChatRoom_TripId ON [SchemaName].[ChatRoom](TripId);

-- ChatMessage Table
CREATE INDEX IX_ChatMessage_ChatRoomId ON [SchemaName].[ChatMessage](ChatRoomId);
CREATE INDEX IX_ChatMessage_SenderId ON [SchemaName].[ChatMessage](SenderId);
CREATE INDEX IX_ChatMessage_ReceiverId ON [SchemaName].[ChatMessage](ReceiverId);

-- SubscriptionBenefit Table
CREATE INDEX IX_SubscriptionBenefit_SubscriptionId ON [SchemaName].[SubscriptionBenefit](SubscriptionId);

-- UserSubscription Table
CREATE INDEX IX_UserSubscription_UserId ON [SchemaName].[UserSubscription](UserId);
CREATE INDEX IX_UserSubscription_SubscriptionId ON [SchemaName].[UserSubscription](SubscriptionId);

-- Friendship Table
CREATE INDEX IX_Friendship_InitiatorId ON [SchemaName].[Friendship](InitiatorId);
CREATE INDEX IX_Friendship_ResponderId ON [SchemaName].[Friendship](ResponderId);

-- TripPlace Table
CREATE INDEX IX_TripPlace_PlaceId ON [SchemaName].[TripPlace](PlaceId);
CREATE INDEX IX_TripPlace_TripId ON [SchemaName].[TripPlace](TripId);
