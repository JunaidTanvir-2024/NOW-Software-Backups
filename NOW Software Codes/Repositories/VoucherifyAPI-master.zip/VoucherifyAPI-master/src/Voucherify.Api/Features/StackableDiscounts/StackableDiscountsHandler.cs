using RW;

using Voucherify.Api.Features.Customers;
using Voucherify.Api.Features.Customers.Requests;
using Voucherify.Api.Features.StackableDiscounts.Common;
using Voucherify.Api.Features.StackableDiscounts.Requests;
using Voucherify.Api.Features.StackableDiscounts.Responses;
using Voucherify.Api.Features.Vouchers;
using Voucherify.Api.Features.Vouchers.Requests;
using Voucherify.Core.Domain.Definitions;
using Voucherify.Core.Services.VoucherifyApi;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;
using Voucherify.Core.Services.VoucherifyApi.Models.Orders;
using Voucherify.Core.Services.VoucherifyApi.Models.Rewards;
using Voucherify.Core.Services.VoucherifyApi.Models.StackableDiscounts;

using static Voucherify.Api.Features.StackableDiscounts.Common.ApplicableOrder;
using static Voucherify.Api.Features.StackableDiscounts.Responses.StackableDiscountRedemptionResponse;
using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Api.Features.StackableDiscounts;

public interface IStackableDiscountsHandler
{
    Task<IResultWrapper<StackableDiscountRedemptionResponse>> RedeemStackableDiscounts(StackableDiscountRedemptionRequest request);
    Task<IResultWrapper<StackableDiscountValidationResponse>> ValidateStackableDiscounts(StackableDiscountValidationRequest request);
    Task<IResultWrapper<StackableDiscountRollbackResponse>> RollbackStackableDiscounts(StackableDiscountRollbackRequest request);
}

internal class StackableDiscountsHandler : IStackableDiscountsHandler
{
    private const string StackableDiscounts = "Stackable Discount Code";
    private readonly IVoucherifyImplementation _voucherifyImplementation;
    private readonly ICustomersHandler _customersHandler;
    private readonly IVouchersHandler _vouchersHandler;

    public StackableDiscountsHandler(
        IVoucherifyImplementation voucherifyImplementation,
        ICustomersHandler customersHandler,
        IVouchersHandler vouchersHandler)
    {
        _voucherifyImplementation = voucherifyImplementation;
        _customersHandler = customersHandler;
        _vouchersHandler = vouchersHandler;
    }

    public async Task<IResultWrapper<StackableDiscountValidationResponse>> ValidateStackableDiscounts(StackableDiscountValidationRequest request)
    {
        var voucherRecord = await _vouchersHandler.GetSpecificVoucher(new GetVoucherRequest() { VoucherCodeOrId = request.Validation.DiscountCode });

        var customerRecord = await _customersHandler.GetCustomer(new GetCustomerRequest()
        {
            CustomerSourceId = request.Customer.SourceId!
        });

        var customer = new Customer()
        {
            SourceId = customerRecord.Payload?.SourceId,
            Email = customerRecord.Payload?.Email,
            Phone = customerRecord.Payload?.Phone,
            Name = customerRecord.Payload?.Name,
            Description = customerRecord.Payload?.Description,
            Id = customerRecord.Payload?.Id,
            Address = new Address()
            {
                Country = customerRecord.Payload?.Country,
                State = customerRecord.Payload?.State,
                City = customerRecord.Payload?.City,
                Line1 = customerRecord.Payload?.AddressLine1,
                Line2 = customerRecord.Payload?.AddressLine2,
                PostalCode = customerRecord.Payload?.PostalCode
            },
            Loyalty = new CustomerLoyalty()
            {
                Campaigns = customerRecord.Payload?.LoyaltyCampaigns,
                Points = customerRecord?.Payload?.Points > 0 ? Convert.ToInt32(customerRecord?.Payload?.Points) : 0,
                ReferredCustomers = customerRecord?.Payload?.ReferredCustomers > 0 ? Convert.ToInt32(customerRecord?.Payload?.ReferredCustomers) : 0,
            },
            Metadata = request.Customer.Metadata
        };
        var redeemableDiscounts = new RedeemableDiscounts()
        {
            Redeemable = new List<StackableDiscount>() { new StackableDiscount()
            {
                DiscountType = request.Validation.DiscountType?.ToLower(), DiscountCode = request.Validation.DiscountCode,
                Reward = new Reward() { Id = request.Validation.RewardId, Metadata = request.Validation.Metadata }
            }
        }
        };
        var order = new OrderCreate()
        {
            Items = new List<OrderItem>() { new OrderItem() { SkuId = request.Order.SkuId, Quantity = request.Order.Quantity == null ? 1 : request.Order.Quantity, Amount = request.Order.Amount } },
            Metadata = request.Order.Metadata
        };

        var stackableDiscountValidation = await _voucherifyImplementation.ValidateStackableDiscounts(customer, redeemableDiscounts, order);

        if (stackableDiscountValidation != null && stackableDiscountValidation?.IsValid == true)
        {
            return ResultWrapper.Success(new StackableDiscountValidationResponse()
            {
                IsValid = stackableDiscountValidation?.IsValid == true,
                CampaignName = voucherRecord?.Payload?.Campaign,
                Order = new ApplicableOrder()
                {
                    Amount = stackableDiscountValidation?.Redeemables?.First().Order?.Amount,
                    DiscountAmount = stackableDiscountValidation?.Redeemables?.First().Order?.DiscountAmount,
                    PercentOff = stackableDiscountValidation?.Redeemables?.First().Result?.DiscountInfo?.PercentOff,
                    AmountOff = stackableDiscountValidation?.Redeemables?.First().Result?.DiscountInfo?.AmountOff,
                    AmountLimit = stackableDiscountValidation?.Redeemables?.First().Result?.DiscountInfo?.AmountLimit,
                    DiscountType = stackableDiscountValidation?.Redeemables?.First().Result?.DiscountInfo?.Type?.ToString(),
                    DiscountEffect = stackableDiscountValidation?.Redeemables?.First().Result?.DiscountInfo?.Effect?.ToString(),
                    UnitOff = stackableDiscountValidation?.Redeemables?.First().Result?.DiscountInfo?.UnitOff,
                    UnitType = stackableDiscountValidation?.Redeemables?.First().Result?.DiscountInfo?.UnitType,
                    Items = stackableDiscountValidation?.Redeemables?.Select(orderItem => new ApplicableOrderItems()
                    {
                        ProductId = orderItem.Order?.Items?.Select(x => x.ProductId).First(),
                        SkuId = orderItem.Order?.Items?.Select(x => x.SkuId).First(),
                        SkuPrice = orderItem.Order?.Items?.Select(x => x.Price).First(),
                    })
                }
            }); ;
        }
        else
        {
            var errorMessage = stackableDiscountValidation?.Redeemables?.First()?.Result?.VoucherifyError?.Key?.Contains("rules_violated");
            var failureMessage = errorMessage == true ? AppConstants.StatusMessages.StackableDiscountNotValidForCustomer : AppConstants.StatusMessages.StackableDiscountInvalid;
            var failureStatusCode = errorMessage == true ? AppConstants.StatusCodes.StackableDiscountNotValidForCustomer : AppConstants.StatusCodes.StackableDiscountInvalid;

            return ResultWrapper.Failure<StackableDiscountValidationResponse>(failureMessage, failureStatusCode);
        }
    }
    public async Task<IResultWrapper<StackableDiscountRedemptionResponse>> RedeemStackableDiscounts(StackableDiscountRedemptionRequest request)
    {
        var customerRecord = await _customersHandler.GetCustomer(new GetCustomerRequest()
        {
            CustomerSourceId = request.Customer.SourceId!
        });
        var customer = new Customer()
        {
            Id = customerRecord.Payload?.Id,
            SourceId = customerRecord.Payload?.SourceId,
            Email = customerRecord.Payload?.Email,
            Phone = customerRecord.Payload?.Phone,
            Name = customerRecord.Payload?.Name,
            Description = customerRecord.Payload?.Description,
            Address = new Address()
            {
                Country = customerRecord.Payload?.Country,
                State = customerRecord.Payload?.State,
                City = customerRecord.Payload?.City,
                Line1 = customerRecord.Payload?.AddressLine1,
                Line2 = customerRecord.Payload?.AddressLine2,
                PostalCode = customerRecord.Payload?.PostalCode
            },
            Loyalty = new CustomerLoyalty()
            {
                Campaigns = customerRecord.Payload?.LoyaltyCampaigns,
                Points = customerRecord?.Payload?.Points > 0 ? Convert.ToInt32(customerRecord?.Payload?.Points) : 0,
                ReferredCustomers = customerRecord?.Payload?.ReferredCustomers > 0 ? Convert.ToInt32(customerRecord?.Payload?.ReferredCustomers) : 0,
            },
            Metadata = request.Customer.Metadata
        };
        var redeemableDiscounts = new RedeemableDiscounts()
        {
            Redeemable = new List<StackableDiscount>() { new StackableDiscount()
            {
                DiscountType = request.Redemption.DiscountType?.ToLower(), DiscountCode = request.Redemption.DiscountCode,
                Reward = new Reward() { Id = request.Redemption.RewardId, Metadata = request.Redemption.Metadata }
            }
            }
        };
        var order = new OrderCreate()
        {
            Items = new List<OrderItem>() { new OrderItem() { SkuId = request.Order.SkuId, Quantity = request.Order.Quantity == null ? 1 : request.Order.Quantity, Amount = request.Order.Amount } },
            Metadata = request.Order.Metadata,
        };

        var stackableDiscountRedemption = await _voucherifyImplementation.RedeemStackableDiscounts(customer, redeemableDiscounts, order);

        return stackableDiscountRedemption != null && stackableDiscountRedemption.Redemptions?.Select(x => x.Result?.Equals(nameof(RedemptionResult.Success), StringComparison.InvariantCultureIgnoreCase)).First() == true

            ? ResultWrapper.Success(new StackableDiscountRedemptionResponse()
            {
                RedemptionId = stackableDiscountRedemption?.Redemptions?.Select(x => x.Id).First(),
                CampaignName = stackableDiscountRedemption?.Redemptions.First()?.Voucher?.Campaign,
                Referrer = stackableDiscountRedemption?.Redemptions.Select(x => x.Voucher?.IsReferralCode).First() == true ? stackableDiscountRedemption?.Redemptions?.Select(x => new ReferrerInfo()
                {
                    Email = x.Voucher?.Holder?.Email,
                    Name = x.Voucher?.Holder?.Name,
                    Id = x.Voucher?.Holder?.Id,
                    SourceId = x.Voucher?.Holder?.SourceId,
                }).First() : null,
                Order = new ApplicableOrder()
                {
                    Amount = stackableDiscountRedemption?.Redemptions?.First().Order?.Amount,
                    DiscountAmount = stackableDiscountRedemption?.Redemptions?.First().Order?.DiscountAmount,
                    PercentOff = stackableDiscountRedemption?.Redemptions?.First().Voucher?.DiscountInfo?.PercentOff,
                    AmountOff = stackableDiscountRedemption?.Redemptions?.First().Voucher?.DiscountInfo?.AmountOff,
                    AmountLimit = stackableDiscountRedemption?.Redemptions?.First().Voucher?.DiscountInfo?.AmountLimit,
                    DiscountType = stackableDiscountRedemption?.Redemptions?.First().Voucher?.DiscountInfo?.Type?.ToString(),
                    DiscountEffect = stackableDiscountRedemption?.Redemptions?.First().Voucher?.DiscountInfo?.Effect?.ToString(),
                    UnitOff = stackableDiscountRedemption?.Redemptions?.First().Voucher?.DiscountInfo?.UnitOff,
                    UnitType = stackableDiscountRedemption?.Redemptions?.First().Voucher?.DiscountInfo?.UnitType,
                    Items = stackableDiscountRedemption?.Redemptions?.Select(orderItem => new ApplicableOrderItems()
                    {
                        ProductId = orderItem.Order?.Items?.Select(x => x.ProductId).First(),
                        SkuId = orderItem.Order?.Items?.Select(x => x.SkuId).First(),
                        SkuPrice = orderItem.Order?.Items?.Select(x => x.Price).First(),
                    })
                }
            })
            : ResultWrapper.Failure<StackableDiscountRedemptionResponse>(AppConstants.StatusMessages.StackableDiscountInvalid, AppConstants.StatusCodes.StackableDiscountInvalid);
    }
    public async Task<IResultWrapper<StackableDiscountRollbackResponse>> RollbackStackableDiscounts(StackableDiscountRollbackRequest request)
    {
        var stackableDiscountRollback = await _voucherifyImplementation.RollbackStackableDiscounts(request.RedemptionId);
        if (stackableDiscountRollback == null)
        {
            return ResultWrapper.Failure<StackableDiscountRollbackResponse>(AppConstants.StatusMessages.RedemptionIdInvalid, AppConstants.StatusCodes.RedemptionIdInvalid);
        }

        var result = stackableDiscountRollback?.Rollbacks?.Select(x => x.Result?.Equals(nameof(RedemptionResult.Success), StringComparison.OrdinalIgnoreCase)).First();

        return result == true
            ? ResultWrapper.Success(new StackableDiscountRollbackResponse()
            {
                IsRollback = true
            })
            : ResultWrapper.Failure<StackableDiscountRollbackResponse>(AppConstants.StatusMessages.RedemptionNotRollback, AppConstants.StatusCodes.RedemptionNotRollback);
    }
}
