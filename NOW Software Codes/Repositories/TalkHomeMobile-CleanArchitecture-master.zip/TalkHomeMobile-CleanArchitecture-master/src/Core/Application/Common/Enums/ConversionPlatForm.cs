﻿namespace Application.Common.Enums;

public enum ConversionPlatForm
{
    None = 0,
    AWIN = 1
}