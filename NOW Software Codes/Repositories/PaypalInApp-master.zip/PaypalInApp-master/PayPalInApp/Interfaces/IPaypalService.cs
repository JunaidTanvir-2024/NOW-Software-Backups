﻿using PayPalInApp.Models;
using PayPalInApp.Models.Paypal;
using System.Threading.Tasks;

namespace PayPalInApp.Interfaces
{
    public interface IPayPalService
    {
        string GetResumeUrl(string path, string baseUrl);
        Task<GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>> PayPalCreateSalePayment(PayPalCreateSalePaymentRequest request, PaypalStartPaymentModel currency);
        Task<GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>> PayPalExecuteSalePayment(PayPalExecuteSalePaymentRequest request);
        Task<GenericPayPalApiResponse<Pay360PayPalCreateSalePaymentResponse>> Pay360PayPalCreateSalePayment( PaypalStartPaymentModel model,string baseUrl,string ipAddress,string FirstUseDate);
        Task<GenericPayPalApiResponse<Pay360PayPalCreateResumePaymentResponse>> Pay360ResumePayment(Pay360PayPalResumePaymentRequest request);
    }
}
