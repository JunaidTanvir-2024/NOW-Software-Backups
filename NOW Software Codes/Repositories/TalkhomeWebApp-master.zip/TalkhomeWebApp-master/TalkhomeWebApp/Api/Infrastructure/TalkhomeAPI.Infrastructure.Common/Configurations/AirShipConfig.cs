﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class AirShipConfig
    {
        public bool IsActive { get; set; }
        public string PaymentTagGroupName { get; set; }
        public string CustomerTagGroupName { get; set; }
        public string TransactionTagGroupName { get; set; }
        public string ActivityTagGroupName { get; set; }
        public string ServiceTagGroupName { get; set; }
        public string AirShipApiEndpoint { get; set; }
    }
}
