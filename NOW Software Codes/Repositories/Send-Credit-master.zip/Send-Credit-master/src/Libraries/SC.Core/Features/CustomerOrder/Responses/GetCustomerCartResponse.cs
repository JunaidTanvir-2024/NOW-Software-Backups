﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder.Responses;
public sealed class GetCustomerCartResponse
{
    public long CustomerCartID { get; set; } = default!;
    public string UserID { get; set; } = default!;
    public string? Logo { get; set; } = default!;
    public int ProductId { get; set; } = default!;
    public string ProductName { get; set; } = default!;
    public decimal Price { get; set; } = default!;
    public string Currency { get; set; } = default!;
    public string DiscountType { get; set; } = default!;
    public decimal DiscountAmount { get; set; } = default!;
    public string Status { get; set; } = default!;
    public string State { get; set; } = default!;
    public int CustomerOrderId { get; set; } = default!;
    public string ProductStatus { get; set; } = default!;
    public decimal TotalOrderPrice { get; set; } = default!;
    public decimal ServiceFeeAmount { get; set; } = default!;
    public string ProductType { get; set; } = default!;
    public decimal ProductPrice { set; get; } = default!;
    public string ProductPriceType { get; set; } = default!;
}
public sealed class GetCustomerCartResponseRapper
{
    public List<GetCustomerCartResponse> CustomerCart { get; set; } = new List<GetCustomerCartResponse>();
    public string UserID { get; set; } = default!;
    public decimal TotalOrderPrice { set; get;}
    public decimal TotalServiceFeeAmount { set; get;}

}

