using Application.Common.Interfaces.Payment;
using Application.Common.Interfaces.Repositories;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;

namespace Application.Features.Bundle.AutoRenewal.NewCard;

public class AutoRenewalNewCardRequestHandler : IRequestHandler<AutoRenewalNewCardRequest, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly IPayPalService _payPalService;
    private readonly IUnitOfWork _unitOfWork;

    public AutoRenewalNewCardRequestHandler(
        IPaymentService paymentService,
        ICurrentUser currentUser,
        IMapper mapper,
        IPayPalService payPalService,
        IUnitOfWork unitOfWork)
    {
        _paymentService = paymentService;
        _currentUser = currentUser;
        _mapper = mapper;
        _payPalService = payPalService;
        _unitOfWork = unitOfWork;
    }
    public async Task<Result<CardResponse>> Handle(AutoRenewalNewCardRequest request, CancellationToken cancellationToken)
    {
        request.PaymentCardInfo.SaveCard = true;
        request.PaymentCardInfo.MakeDefault = true;
        var bundleInfo = _mapper.Map<PaymentBundleInfo>(request);
        //Suspend PayPal subscription if Autorenewal is already setuped with paypal
        //var msisdnInfo = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn!);
        //var bundlesResponse = await _unitOfWork.BundleRepo.GetBundleById(new BundleByIdRequest() { Id = request.BundleId.ToString() });
        //var autoRenewal = await _unitOfWork.BundleRepo.GetBundleAutoRenewal(request.Msisdn!, msisdnInfo.AccountId!, bundlesResponse.UuId!);
        //if (autoRenewal?.IsRenew == true && autoRenewal?.PaymentMethod?.Equals("paypal", StringComparison.InvariantCultureIgnoreCase) == true)
        //{
        //    await _payPalService.PayPalCancelSubscription(new PaypalSuspendSubscriptionRequest
        //    {
        //        SubscriptionId = autoRenewal.InitialTransactionId!,
        //    });
        //}
        return await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: request.PaymentCardInfo,
            paymentExistingCardInfo: null!,
            paymentAddressInfo: request.PaymentAddressInfo,
            topupInfo: null!,
            bundleInfo: bundleInfo,
            creditSimInfo: null!,
            msisdn: request.Msisdn,
            email: _currentUser.GetUserEmail()!,
            ipAddress: request.IpAddress,
            cardMaskedPan: null!,
            cardScheme: null!,
            isAuthorizeOnly: true
            );
    }
}