﻿using System.Text.Json.Serialization;
namespace NTCB.Api.Features.DTOne.Models;

public class ProductInfo
{
    [JsonPropertyName("description")]
    public string? Description { get; set; }
    
    [JsonPropertyName("id")]
    public int? Id { get; set; }
    
    [JsonPropertyName("name")]
    public string? Name { get; set; }
    
    [JsonPropertyName("_operator")]
    public OperatorInfo? Operator { get; set; }
    
    [JsonPropertyName("regions")]
    public object? Regions { get; set; }
    
    [JsonPropertyName("service")]
    public ServiceInfo? Service { get; set; }

    [JsonPropertyName("tags")]
    public string[]? Tags { get; set; }
    
    [JsonPropertyName("type")]
    public string? Type { get; set; }
}
