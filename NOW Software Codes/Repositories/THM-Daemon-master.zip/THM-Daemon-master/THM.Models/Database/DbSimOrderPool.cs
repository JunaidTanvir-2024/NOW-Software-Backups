﻿using System;
using System.Collections.Generic;
using System.Text;

namespace THM.Models.Database
{
    public class DbSimOrderPool
    {
        public int id { get; set; }
        public string msisdn { get; set; }
        public bool? isAvailable { get; set; }
        public bool? isActive { get; set; }
        public string account { get; set; }
        public DateTime activation_Date { get; set; }
        public bool isFulfilled { get; set; }
        public string fulfillmentErrorMessage { get; set; }
        public DateTime fulfillmentDateTime { get; set; }
    }
}
