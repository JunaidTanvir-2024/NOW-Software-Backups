﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SMSOutReach.Infastructure.Interface;
using SMSOutReach.Modal.Xeebi;
using SMSOutReach.Web.Models;

namespace SMSOutReach.Web.Controllers
{
    [Produces("application/json")]
    //[Route("api/SMSAPI")]
    [Route("SMSAPI")]
    public class SMSAPIController : Controller
    {

        private ISMSCarrier SMSCarrier;
        private ISenderProduct SenderProduct;
        private ISMSJob SMSJob;

        public SMSAPIController(ISMSCarrier smsCarrier ,ISenderProduct senderProduct, ISMSJob smsJob)
        {
            SMSCarrier = smsCarrier;
            SenderProduct = senderProduct;
            SMSJob = smsJob;
        }


        [Route("SendSms")]
        [HttpPost]
        async public Task<JsonResult> SendSms(string msisdn, string message ,string productcode, string smscarrier, int priority)
        {

            try
            {

                if (msisdn == null || message == null || productcode == null || smscarrier == null)
                {
                    // Status 1= Success, 2=Failure
                    var jsonresult = new { Status = 2, Result = "Failure", Message = "In correct parameters" };
                    return Json(jsonresult);
                }
                else
                {
                    // check sms carrier in database 
                    var carrierlist = SMSCarrier.GetAllSMSCarriers();
                    int carrier = carrierlist.Where(x => x.Name == smscarrier).FirstOrDefault().ID;

                    if (carrier > 0)
                    {

                        // check priority value it should be 0 for urgent and less than 10

                        if(priority < 10)
                        {
                            // check senderproduct in database 
                            var productlist = SenderProduct.GetSenderProducts();

                            int product = productlist.Where(x => x.Code == productcode).FirstOrDefault().ID;

                            if (product > 0)
                            {


                                SMSJob jobViewModel = new SMSJob
                                {
                                    Priority = priority,
                                    //Campaign = "",
                                    Message = message,
                                    CarrierId = carrier,
                                    CreatedDate = DateTime.UtcNow,
                                    SenderProductID = product,
                                    //UserId = "",
                                    StartTime = DateTime.UtcNow,
                                    SmsCount = 1
                                };

                                var result = await SMSJob.InsertSmsJobApi(jobViewModel, msisdn);

                                if (result.DBStatus == 1)
                                {
                                    // Status 1= Success, 2=Failure
                                    var jsonresult = new { Status = 1, Result = "Success", Message = "SMS Job has been Created." };
                                    return Json(jsonresult);
                                }
                                else
                                {
                                    // Status 1= Success, 2=Failure
                                    var jsonresult = new { Status = 2, Result = "Failure", Message = result.DBErrorMessage };
                                    return Json(jsonresult);
                                }
                            }
                            else
                            {
                                // Status 1= Success, 2=Failure
                                var jsonresult = new { Status = 2, Result = "Failure", Message = "Product Code is not Valid" };
                                return Json(jsonresult);
                            }
                        }else
                        {
                            // Status 1= Success, 2=Failure
                            var jsonresult = new { Status = 2, Result = "Failure", Message = "Prority Value is not Valid" };
                            return Json(jsonresult);
                        }

                        
                    }
                    else
                    {
                        // Status 1= Success, 2=Failure
                        var jsonresult = new { Status = 2, Result = "Failure", Message = "SMS Carrier  is not Valid" };
                        return Json(jsonresult);
                    }
                }

            }
            catch (Exception ex)
            {

                // Status 1= Success, 2=Failure
                var jsonresult = new { Status = 2, Result = "Failure", Message = ex.Message };
                return Json(jsonresult);

            }



        }


       
    }


    
}