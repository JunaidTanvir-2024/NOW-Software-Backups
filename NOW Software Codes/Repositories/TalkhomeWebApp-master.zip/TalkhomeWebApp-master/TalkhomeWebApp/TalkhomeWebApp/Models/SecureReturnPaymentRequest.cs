﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models
{
    public class SecureReturnPaymentRequest
    {
        [Required]
        public string MD { get; set; }

        [Required]
        public string PaRes { get; set; }

        [Required]
        [Range(1,2)]
        public CheckOutTypes type { get; set; }

        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [EmailAddress(ErrorMessage = "Invalid email")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        public string customerEmail { get; set; }

        [Required(ErrorMessage = "Msisdn is required")]
        public string customerMsisdn { get; set; }

        [Required(ErrorMessage = "Currency is required")]
        public string currency { get; set; }

        public string bundleId { get; set; }
        public bool shouldSave { get; set; }
        public BundleType BundleType { get; set; }

        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }
        public string clientRedirectType { get; set; }

        public bool IsAutoTopUp { get; set; }
        public bool IsAutoBundleRenew { get; set; }
        public int PTId { get; set; }
        public string amount { get; set; }
    }
    public class SetAutoTopupWithCardSecureReturnPaymentRequest
    {
        [Required]
        public string MD { get; set; }

        [Required]
        public string PaRes { get; set; }

        [Required]
        [Range(1,2)]
        public CheckOutTypes type { get; set; }

        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [EmailAddress(ErrorMessage = "Invalid email")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        public string customerEmail { get; set; }

        [Required(ErrorMessage = "Msisdn is required")]
        public string customerMsisdn { get; set; }

        [Required(ErrorMessage = "Currency is required")]
        public string currency { get; set; }
        public bool shouldSave { get; set; }
        public string clientRedirectType { get; set; }
        public int PTId { get; set; }
        public float TopupAmount { get; set; }
        public float ThresholdAmount { get; set; }
    }
    public class SetAutoRenewalWithCardSecureReturnPaymentRequest
    {
        [Required]
        public string MD { get; set; }

        [Required]
        public string PaRes { get; set; }

        [Required]
        [Range(1, 2)]
        public CheckOutTypes type { get; set; }

        [MaxLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [EmailAddress(ErrorMessage = "Invalid email")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        public string customerEmail { get; set; }

        [Required(ErrorMessage = "Msisdn is required")]
        public string customerMsisdn { get; set; }

        [Required(ErrorMessage = "Currency is required")]
        public string currency { get; set; }
        public bool shouldSave { get; set; }
        public string clientRedirectType { get; set; }
        public int PTId { get; set; }
        public string BundleId { get; set; }
    }
}
