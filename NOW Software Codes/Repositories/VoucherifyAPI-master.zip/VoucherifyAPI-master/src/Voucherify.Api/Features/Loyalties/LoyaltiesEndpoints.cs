using Microsoft.AspNetCore.Mvc;

using Voucherify.Api.Features.Loyalties.Requests;

using Voucherify.Core.Commons.Filters;

namespace Voucherify.Api.Features.Loyalties;

public static class LoyaltiesEndpoints
{
    private const string EndpointPrefix = "/api/loyalties";
    private const string EndpointTag = "Loyalties Endpoints";
    public static void AddLoyaltiesEndpoints(this WebApplication app)
    {
        var loyaltiesEndpoints = app.MapGroup(EndpointPrefix).WithTags(EndpointTag);

        loyaltiesEndpoints.MapGet("", GetLoyaltyCampaigns)
            .AddEndpointFilter<FluentValidationFilter<GetLoyaltiesRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK);
        loyaltiesEndpoints.MapGet("/campaign", GetLoyaltyCampaignByNameOrId)
        .AddEndpointFilter<FluentValidationFilter<AddLoyaltyPointsRequest>>()
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status200OK);
        loyaltiesEndpoints.MapGet("/rewards", GetLoyaltyRewards)
            .AddEndpointFilter<FluentValidationFilter<AddLoyaltyPointsRequest>>()
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status200OK);

        loyaltiesEndpoints.MapPost("", AddLoyaltyPoints)
        .AddEndpointFilter<FluentValidationFilter<AddLoyaltyPointsRequest>>()
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status200OK);
    }
    private static async Task<IResult> GetLoyaltyCampaigns(ILoyaltiesHandler loyaltiesHandler, [AsParameters] GetLoyaltiesRequest request)
    {
        var result = await loyaltiesHandler.GetLoyalties(request);
        return result.IsSuccess ? Results.Ok(result) : Results.NotFound(result);
    }
    private static async Task<IResult> GetLoyaltyCampaignByNameOrId(ILoyaltiesHandler loyaltiesHandler, [AsParameters] GetLoyaltyByCampaignNameRequest request)
    {
        var result = await loyaltiesHandler.GetLoyaltyByCampaignName(request);
        return result.IsSuccess ? Results.Ok(result) : Results.NotFound(result);
    }
    private static async Task<IResult> AddLoyaltyPoints(ILoyaltiesHandler loyaltiesHandler, [FromBody] AddLoyaltyPointsRequest request)
    {
        var result = await loyaltiesHandler.GiveLoyaltyPointsToCustomer(request);
        return result.IsSuccess ? Results.Ok(result) : Results.BadRequest(result);
    }
    private static async Task<IResult> GetLoyaltyRewards(ILoyaltiesHandler loyaltiesHandler, [AsParameters] GetLoyaltyRewardsByCampaignIdRequest request)
    {
        var result = await loyaltiesHandler.GetLoyaltyRewardsByCampaignId(request);
        return result.IsSuccess ? Results.Ok(result) : Results.NotFound(result);
    }
}
