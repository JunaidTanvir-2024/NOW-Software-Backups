﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.DAO
{
    public class Product
    {
        public string product_code { get; set; }
        public string error_msg { get; set; }
        public int error_code { get; set; }
        public int subscriber_id { get; set; }
        public int account_id { get; set; }
        public int bundle_Count { get; set; }
    }
}
