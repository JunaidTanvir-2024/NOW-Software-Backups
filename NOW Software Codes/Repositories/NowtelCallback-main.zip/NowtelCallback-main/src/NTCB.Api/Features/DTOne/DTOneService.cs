﻿using System.Text.Json;

using NTCB.Api.Commons.Definations;
using NTCB.Api.Features.DTOne.Models;

using Serilog.Events;
using Serilog;

namespace NTCB.Api.Features.DTOne;

public class DTOneService : IDTOneService
{
    private readonly IDTOneRepository _dTOneRepository;

    public DTOneService(IDTOneRepository dTOneRepository)
    {
        _dTOneRepository = dTOneRepository;
    }
    #region DTOne Transaction

    public async Task<bool> VerifyDTOneTransaction(long transactionReferenceId)
    {
        return await _dTOneRepository.VerifyTransactionStatus(transactionReferenceId.ToString());
    }

    public async Task<bool> UpdateDTOneTransactionRecord(CallbackInfo callbackInfo)
    {
        var dtOneJsonResponse = SerializeResponse(callbackInfo);
        await _dTOneRepository.UpdateCallbackRecord(Convert.ToString(callbackInfo.Id), callbackInfo.Status?.Message!, dtOneJsonResponse);
        var transactionStatus = callbackInfo.Status?.Message == NTCBConstants.DTOneTransactionStatus.COMPLETED ? "Success" : "Failure";
        var transactionStatusMessage = callbackInfo.Status?.Message == NTCBConstants.DTOneTransactionStatus.COMPLETED ? null : callbackInfo.Status?.Message;
        var isVerified = await VerifyDTOneTransaction(callbackInfo.Id);
        if (!isVerified)
        {
            Log.Write(LogEventLevel.Information, "DTOne Transaction Callback Response {Callback}", dtOneJsonResponse);
            return false;
        }
        return await _dTOneRepository.UpdateTransactionRecord(Convert.ToString(callbackInfo.Id), transactionStatus, dtOneJsonResponse, transactionStatusMessage);
    }

    #endregion

    #region Helper Methods
    private string SerializeResponse(CallbackInfo callbackInfo)
    {
        return JsonSerializer.Serialize(callbackInfo);
    }
    #endregion
}
