﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.Models.ApiRequest.Admin
{
    public class SaveUpdateAdminRequestModel
    {
        public BasketWebPanel.Areas.Dashboard.Models.Admin adminData { get; set; }
    }
}