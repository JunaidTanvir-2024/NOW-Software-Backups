﻿namespace Application.Features.Account.AccountSummary;
public class AccountSummaryRequest : IRequest<Result<AccountSummaryResponse>> { }
