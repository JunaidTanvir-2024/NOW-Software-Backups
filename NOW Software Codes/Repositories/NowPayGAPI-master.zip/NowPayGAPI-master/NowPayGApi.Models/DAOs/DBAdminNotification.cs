﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBPlan
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string UuId { get; set; }
        public double Price { get; set; }
        public string CurrencySymbol { get; set; }
        public string Currency { get; set; }
        public string CurrencyID { get; set; }
        public string SubByTextNumber { get; set; }
        public string SubByTextCode { get; set; }
        public string Data { get; set; }
        public string OldData { get; set; }
        public bool MostPopular { get; set; }
        public string DataUnits { get; set; }
        public string LocalMins { get; set; }
        public string InternationalMins { get; set; }
        public string Sms { get; set; }
        public int ValidityDays { get; set; }
        public int ProductId { get; set; }
        public int CountryId { get; set; }
        public string CountryName { get; set; }
        public bool IsNational { get; set; }
        public bool IsTopPlan { get; set; }
        public int PlanCategoryId { get; set; }
        public string PlanCategoryName { get; set; }
        public int AddedByAdminId { get; set; }
        public DateTime AddedDatetime { get; set; }
        public bool IsActive { get; set; }
        public string PlanInfo { get; set; }
    }

    public class DBPlanCategory
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class DBProduct
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ProductCode { get; set; }
    }

    public class DBRole
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
    }
}
