﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.DbConnections;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class CustomEvents_DL : ICustomEvents_DL
    {
        private IDbConnectionSettings DefaultConnection;
        private ILogger Logger;

        public CustomEvents_DL(IOptions<ConnectionStrings> connectionConfig, ILogger logger)
        {

            DefaultConnection = new DbConnectionSettings(new SqlConnection(connectionConfig.Value.DefaultConnection));
            Logger = logger;
        }
        public async Task<GenericResult<bool>> AddCustomEvents(AddCustomEventsRequest request, ApiCustomEventResponse apiResponseModel, string airShipRequestJson, HttpStatusCode statusCode, bool isSuccess)
        {

            string logParameters = $" isSuccess: {isSuccess}, UserRequest => {JsonConvert.SerializeObject(request)}, ApiResponse => {JsonConvert.SerializeObject(apiResponseModel)}, ApiRequest: {airShipRequestJson}, ApiStatusCode: {statusCode.ToString()} ";
            try
            {
                DataTable tblProperties = new DataTable();
                tblProperties.Columns.Add("key", typeof(string));
                tblProperties.Columns.Add("value", typeof(string));
                if (request.Properties != null && request.Properties.Count > 0)
                {
                    for (int i = 0; i < request.Properties.Count; i++)
                    {
                        DataRow row = tblProperties.NewRow();
                        row["key"] = request.Properties.ElementAt(i).Key;
                        row["value"] = request.Properties.ElementAt(i).Value;
                        tblProperties.Rows.Add(row);
                    }
                }             

                var parameter = new DynamicParameters();
                parameter.Add("@name", request.CustomEventName);
                parameter.Add("@product_code", request.ProductCode);
                if (apiResponseModel != null && !string.IsNullOrWhiteSpace(apiResponseModel.OperationId))
                {
                    parameter.Add("@operation_id", apiResponseModel.OperationId);
                }
                parameter.Add("@channel_identifier", request.ChannelIdentifier);
                parameter.Add("@channel_identifier_value", request.ChannelIdentifierValue);
                if (request.Value > 0)
                {
                    parameter.Add("@value", request.Value);
                }
                parameter.Add("@transaction", request.Transaction);
                parameter.Add("@interaction_type", request.InteractionType);
                parameter.Add("@interaction_id", request.InteractionId);
                parameter.Add("@response_status_code", (int)statusCode);
                parameter.Add("@response_status", statusCode.ToString());
                parameter.Add("@user_request_Json", JsonConvert.SerializeObject(request));
                parameter.Add("@airship_request_Json", airShipRequestJson);
                parameter.Add("@airship_response_Json", JsonConvert.SerializeObject(apiResponseModel));
                parameter.Add("@is_success", isSuccess);
                parameter.Add("@properties", tblProperties.AsTableValuedParameter("dbo.CustEventProperties"));
              

                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_AddCustomEvent", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: CustomEvents_DL, Method: AddCustomEvents, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }

        public async Task<GenericResult<bool>> AddCustomEventsError(AddCustomEventsRequest request, string airShipResponseJson, string airShipRequestJson, HttpStatusCode statusCode, bool isSuccess)
        {

            string logParameters = $" isSuccess: {isSuccess}, UserRequest => {JsonConvert.SerializeObject(request)}, ApiResponse => {airShipResponseJson}, ApiRequest: {airShipRequestJson}, ApiStatusCode: {statusCode.ToString()} ";
            try
            {
                DataTable tblProperties = new DataTable();
                tblProperties.Columns.Add("key", typeof(string));
                tblProperties.Columns.Add("value", typeof(string));
                if (request.Properties != null && request.Properties.Count > 0)
                {
                    for (int i = 0; i < request.Properties.Count; i++)
                    {
                        DataRow row = tblProperties.NewRow();
                        row["key"] = request.Properties.ElementAt(i).Key;
                        row["value"] = request.Properties.ElementAt(i).Value;
                        tblProperties.Rows.Add(row);
                    }
                }

                var parameter = new DynamicParameters();
                parameter.Add("@name", request.CustomEventName);
                parameter.Add("@product_code", request.ProductCode);                
                parameter.Add("@channel_identifier", request.ChannelIdentifier);
                parameter.Add("@channel_identifier_value", request.ChannelIdentifierValue);
                if (request.Value > 0)
                {
                    parameter.Add("@value", request.Value);
                }
                parameter.Add("@transaction", request.Transaction);
                parameter.Add("@interaction_type", request.InteractionType);
                parameter.Add("@interaction_id", request.InteractionId);
                parameter.Add("@response_status_code", (int)statusCode);
                parameter.Add("@response_status", statusCode.ToString());
                parameter.Add("@user_request_Json", JsonConvert.SerializeObject(request));
                parameter.Add("@airship_request_Json", airShipRequestJson);
                parameter.Add("@airship_response_Json", airShipResponseJson);
                parameter.Add("@is_success", isSuccess);
                parameter.Add("@properties", tblProperties.AsTableValuedParameter("dbo.CustEventProperties"));


                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_AddCustomEvent", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: CustomEvents_DL, Method: AddCustomEventsError, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }

    }
}
