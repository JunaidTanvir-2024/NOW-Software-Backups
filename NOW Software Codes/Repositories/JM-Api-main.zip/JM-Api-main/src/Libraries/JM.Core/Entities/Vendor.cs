using JM.Core.Entities.Common;

namespace JM.Core.Entities;
public sealed class Vendor : IBaseEntity<long>
{
	public long Id { get; set; }
	public string Name { get; set; } = null!;
	public string? Description { get; set; }
	public ICollection<VendorLog> VendorLogs { get; set; } = [];
}
