using FH.Core.DependencyResolver;
using FH.Core.Entities;

namespace FH.Core.Interfaces.Database;

public interface IVendorRepository : ServiceType.IScoped
{
    Task<string?> GetVendorHash(VendorEntity vendorDto);
    Task<long> VendorInsert(VendorEntity vendorDto);
}
