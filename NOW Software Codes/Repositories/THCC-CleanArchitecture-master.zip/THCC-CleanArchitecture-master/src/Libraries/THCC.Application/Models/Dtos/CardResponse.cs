﻿namespace THCC.Application.Models.Dtos;

public class CardResponseDto
{
    public long OrderId { get; set; }
    public bool Require3dSecure { get; set; } = false;
    public Resume3DV2Info? Resume3dSecureData { get; set; }
    public PaymentResponse? PaymentResponse { get; set; }
}

public class PaymentResponse
{
    public string? Email { get; set; }
    public string? Amount { get; set; }
    public string? CardNumber { get; set; }
    public string? CardPin { get; set; }
    public string? Points { get; set; }
    public string? TransactionId { get; set; }
    public ProductType ProductType { get; set; }
    public string? Balance { get; set; }
    public string? ThresholdAmount { get; set; }
    public string? MaxLimit { get; set; }
    public PaymentMethod PaymentMethod { get; set; }
    public CardInfoDto? CardInfo { get; set; }

}
public class CardInfoDto
{
    public string? CardMaskedPan { get; set; }
    public string? CardType { get; set; }

}