﻿using System;
using System.Collections.Generic;

namespace THCC.Application.Models.Dtos;

public class RedeemPointsResponseDto
{
    public RedeemPointsResponseDto()
    {
        RedeemablePoints = new List<KeyValuePair<int, string>>();
    }
    public int Points { get; set; }
    public string Credit { get; set; } = default!;
    public List<KeyValuePair<int, string>> RedeemablePoints { get; set; }
}
