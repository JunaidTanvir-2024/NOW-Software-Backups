﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts
{
    public class PayPalByPay360ESPaymentResponse
    {
        public string customerId { get; set; }
        public string transactionId { get; set; }
        public string transactionAmount { get; set; }
        public PayPalByPay360OutcomeModel outcome { get; set; }
    }

    [JsonObject("outcome")]
    public class PayPalByPay360OutcomeModel
    {
        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("reasonCode")]
        public string ReasonCode { get; set; }

        [JsonProperty("reasonMessage")]
        public string ReasonMessage { get; set; }
    }
}
