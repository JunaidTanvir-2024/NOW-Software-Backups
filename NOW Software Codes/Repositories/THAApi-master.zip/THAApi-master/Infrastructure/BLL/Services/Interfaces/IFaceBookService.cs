﻿using Models.Contracts.Request;
using Models.Contracts.Request.FaceBook;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface IFaceBookService
    {
        Task CreateCustomEvent(string advertiserID, List<EventDetailsModel> eventDetails);
        Task HandleTopupEvents(string advertiserID, bool IsSuccess, bool? IsCard, decimal Amount, string currency, string origination);
        Task HandleBundlePurchaseEvents(string advertiserID, string origination, string destination, BundleType BundleType, bool IsSuccess, bool? IsCard, decimal Amount, string currency);
        Task HandleIntTopupEvents(string advertiserID, string origination, string destination, bool IsSuccess, bool? IsCard, decimal Amount,bool isTransferRequest);
    }
}
