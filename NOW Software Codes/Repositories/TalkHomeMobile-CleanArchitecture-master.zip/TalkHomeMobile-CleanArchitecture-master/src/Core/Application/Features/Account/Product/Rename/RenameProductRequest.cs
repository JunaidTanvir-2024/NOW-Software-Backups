﻿namespace Application.Features.Account.Product.Rename;
public class RenameProductRequest : IRequest<Result<object>>
{
    public string Alias { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
}
