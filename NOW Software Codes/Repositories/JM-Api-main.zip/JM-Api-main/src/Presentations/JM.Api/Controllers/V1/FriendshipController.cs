using JM.Api.Controllers.Common;
using JM.Core.Features.Friendship;
using JM.Core.Utilities.Definitions;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using RW.Common;
using RW.Failures;
using RW.Models;
using RW.Successes;

namespace JM.Api.Controllers.V1;

public class FriendshipController : V1ApiController
{
    [HttpPost("send")]
    [ProducesResponseType<SuccessPayload<CreateFriendship.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.InternalServerError)]
    [AllowAnonymous]
    public async Task<ActionResult> AddFriendship([FromBody] CreateFriendship.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }

    [HttpPost("filter")]
    [ProducesResponseType<SuccessPayload<GetFriendshipList.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    [AllowAnonymous]
    public async Task<ActionResult> GetFriendships([FromQuery] GetFriendshipList.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpGet("id")]
    [ProducesResponseType<SuccessPayload<GetFriendship.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.NotFound)]
    [AllowAnonymous]
    public async Task<ActionResult> GetFriendship([FromQuery] GetFriendship.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpPatch("block")]
    [ProducesResponseType<SuccessPayload<BlockFriendship.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.BadRequest)]
    [AllowAnonymous]
    public async Task<ActionResult> BlockFriendship([FromQuery] BlockFriendship.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpPatch("unblock")]
    [ProducesResponseType<SuccessPayload<UnblockFriendship.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.BadRequest)]
    [AllowAnonymous]
    public async Task<ActionResult> BlockFriendship([FromQuery] UnblockFriendship.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpPatch("accept")]
    [ProducesResponseType<SuccessPayload<AcceptFriendship.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.BadRequest)]
    [AllowAnonymous]
    public async Task<ActionResult> AcceptFriendship([FromQuery] AcceptFriendship.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
    [HttpPatch("reject")]
    [ProducesResponseType<SuccessPayload<RejectFriendship.Response>>(AppConstant.StatusCode.Success)]
    [ProducesResponseType<FailureErrors<IEnumerable<ValidationErrorDto>>>(AppConstant.StatusCode.BadRequest)]
    [ProducesResponseType<FailureStatus<IResultBase>>(AppConstant.StatusCode.BadRequest)]
    [AllowAnonymous]
    public async Task<ActionResult> RejectFriendship([FromQuery] RejectFriendship.Query query)
    {
        var result = await Mediator.Send(query, HttpContext.RequestAborted);
        if (result.IsSuccess)
        {
            return StatusCode(AppConstant.StatusCode.Success, result);
        }
        return StatusCode(result.Code, result);
    }
}
