﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Request
{
    public class ApiAddEmailChannelRequest
    {
        public ApiEmailChannelRequest channel { get; set; }
    }

    public class ApiEmailChannelRequest
    {
        public string type { get; set; }
        public string commercial_opted_in { get; set; }
        public string commercial_opted_out { get; set; }
        public string transactional_opted_in { get; set; }
        public string transactional_opted_out { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }
        [JsonProperty("timezone")]
        public string TimeZone { get; set; }
        [JsonProperty("locale_country")]
        public string LocaleCountry { get; set; }
        [JsonProperty("locale_language")]
        public string LocaleLanguage { get; set; }
    }
}
