﻿using MapsterMapper;
using RW.Models;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Vendors.FusionHub;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SC.Core.Features.MigrateGuestProfile;
public static class MigrateGuestData
{
    public sealed record Query : IRequest<IResultWrapper>
    {

        public bool IsGuestUser { get; set; } = false;
        public string? UserID { get; set; } = default;
        public string SignInUserID { get; set; } = default!;
    }


    public sealed class Validator : AbstractValidator<Query>
    {
        private readonly IHelperService _client;
        public Validator(IHelperService client)
        {
            _client = client;
            RuleFor(x => x.UserID).MustAsync(async (userId, cancellation) => await _client.IsValidUserID(userId)).WithMessage("User ID does not exist in system, must be a valid user").When(x => x.IsGuestUser);
        }
    }

    #region response
    public sealed record Response
    {

    }

    #endregion
    #region Handler
    internal sealed class Handler : IRequestHandler<Query, IResultWrapper>
    {
        private readonly ICustomerCartRespository _customerCartRespository;
        private readonly IMapper _mapper;
        public Handler(ICustomerCartRespository customerCartRespository, IMapper mapper)
        {
            _customerCartRespository = customerCartRespository;
            _mapper = mapper;
        }
        public async Task<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var response = await _customerCartRespository.MigrateGuestData(request.UserID, request.SignInUserID);
            return ResultWrapper.Success(response);
        }
    }
    #endregion
}

