﻿using System.Text.Json.Serialization;

namespace NTCB.Api.Features.DTOne.Models;

public class OperatorInfo
{
    [JsonPropertyName("country")]
    public CountryInfo? Country { get; set; }

    [JsonPropertyName("id")]
    public int? Id { get; set; }
    
    [JsonPropertyName("name")]
    public string? Name { get; set; }
    
    [JsonPropertyName("regions")]
    public object? Regions { get; set; }
}
