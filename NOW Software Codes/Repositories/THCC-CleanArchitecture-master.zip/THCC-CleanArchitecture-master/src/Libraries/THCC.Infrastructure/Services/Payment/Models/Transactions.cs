﻿
using System.ComponentModel.DataAnnotations;

namespace THCC.Infrastructure.Services.Payment.Models
{
    public class Transactions
    {
        [Required]
        public Amounts Amount { get; set; } = new Amounts();

        [Required]
        public string? Description { get; set; }
    }
}
