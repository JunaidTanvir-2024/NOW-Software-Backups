﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public class ValidationLimit
    {
        public string LimitType { get; set; }
        public float AmountLimit { get; set; }
    }
}
