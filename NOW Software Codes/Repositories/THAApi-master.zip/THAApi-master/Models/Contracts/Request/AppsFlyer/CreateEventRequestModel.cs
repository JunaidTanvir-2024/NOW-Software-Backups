﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Models.Contracts.Request.AppsFlyer
{
    public class CreateEventRequestModel
    {
        //public string customerUserId { get; set; }
        public string appsflyer_id { get; set; }
        public string ip { get; set; }
        public string eventName { get; set; }
        public string eventRevenenuCurrency { get; set; }
        public decimal eventRevenue { get; set; }
        public object eventValue { get; set; }
        public string productCode { get; set; } = "THA-WEB-API";
        public DeviceType deviceType { get; set; }
    }
    public class S2SMobileEventRequestModel
    {
        public string appsflyer_id { get; set; }
        public string eventName { get; set; }
        public object eventValue { get; set; }
        public string eventCurrency { get; set; }
        public DeviceType deviceType { get; set; }
        public string ip { get; set; }
        public string customData { get; set; }
        public string productCode { get; set; } = "THA-WEB-API";
    }
}