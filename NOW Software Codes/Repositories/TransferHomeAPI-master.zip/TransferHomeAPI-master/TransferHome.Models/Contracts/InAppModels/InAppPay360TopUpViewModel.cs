﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TransferHome.Models.Contracts.Response;

namespace TransferHome.Models.Contracts.InAppModels
{
    public enum TopUpMethod
    {
        Voucher,
        Card,
        Paypal,
        Call
    }

    public class AutoTopUpResponse
    {
        public string thresHold { get; set; }
        public string topup { get; set; }
        public bool status { get; set; }
    }

    public class InAppPay360TopUpRequestModel
    {
        [Required]
        public decimal Amount { get; set; }
        [Required]
        public string Currency { get; set; }
    }

    public class InAppPay360TopUpViewModel
    {
        public decimal Amount { get; set; }
        public int UserId { get; set; }
        public string Currency { get; set; }
        public string CurrencySymbol { get; set; }
        public GetCutomerInfoResponseModel Customer { get; set; }
    }

    public class InAppPay360TransferRequestModel
    {
        [Required]
        public string Currency { get; set; }
        [Required]
        public decimal Amount { get; set; }
        [Required]
        public string NowtelTransactionReference { get; set; }
        [Required]
        public string Operatorid { get; set; }
        [Required]
        public string Product { get; set; }
        [Required]
        public string MessageToRecipient { get; set; }
        [Required]
        public string FromMSISDN { get; set; }
    }

    public class InAppPay360TransferViewModel
    {
        public string Currency { get; set; }
        public string CurrencySymbol { get; set; }
        public decimal Amount { get; set; }
        public int UserId { get; set; }
        public GetCutomerInfoResponseModel Customer { get; set; }

        public string NowtelTransactionReference { get; set; }
        public string Operatorid { get; set; }
        public string Product { get; set; }
        public string MessageToRecipient { get; set; }
        public string FromMSISDN { get; set; }
    }


    public class I18nCountry
    {
        public I18nCountryName name { get; set; }

        public string cca2 { get; set; }

        public string ccn3 { get; set; }

        public string cca3 { get; set; }

        public string cioc { get; set; }
    }

    public class I18nCountryName
    {
        public string common { get; set; }
    }

    public class AddressModel
    {
        [CustomValidation(typeof(RequestValidations), "AddressLine1")]
        public string addressL1 { get; set; }

        public string addressL2 { get; set; }


        [Required(ErrorMessage = "City is required")]
        public string city { get; set; }

        public string county { get; set; }

        [CustomValidation(typeof(RequestValidations), "PostCode")]
        public string postCode { get; set; }

        [CustomValidation(typeof(RequestValidations), "CountryCode")]
        public string country { get; set; }

        public AddressModel()
        {
        }

        public AddressModel(string addressL1, string addressL2, string city, string county, string postCode, string country)
        {
            this.addressL1 = addressL1;

            this.addressL2 = addressL2;

            this.city = city;

            this.county = county;

            this.postCode = postCode;

            this.country = country;
        }

        /// <summary>
        /// Provides ToString() override for display purposes
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return string.Join(", ",
                !string.IsNullOrWhiteSpace(addressL1) ? addressL1 : "",
                !string.IsNullOrWhiteSpace(addressL2) ? addressL2 : "",
                !string.IsNullOrWhiteSpace(city) ? city : "",
                !string.IsNullOrWhiteSpace(county) ? county : "",
                !string.IsNullOrWhiteSpace(postCode) ? postCode : "");
        }


    }

    public class NameDetails
    {
        [Required(ErrorMessage = "First name required")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Last name required")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Email address required")]
        public string EmailAddress { get; set; }
    }

    public class AddressIoResponse
    {
        public string Latitude { get; set; }

        public string Longitude { get; set; }

        public IList<string> Addresses { get; set; }

        public string Message { get; set; }
    }

    public class Pay360CustomerModel
    {

        public string displayName { get; set; }
        public string merchantRef { get; set; }
        public string pay360CustId { get; set; }
        public string email { get; set; }
        public string defaultCurrency { get; set; }
        public string dob { get; set; }
        public string addressLine1 { get; set; }
        public string addressLine2 { get; set; }
        public string addressLine3 { get; set; }
        public string addressLine4 { get; set; }
        public string city { get; set; }
        public string region { get; set; }
        public string postCode { get; set; }
        public string country { get; set; }
        public string countryCode { get; set; }
        public string telephone { get; set; }
        public List<paymentMethodResponse> PaymentMethods { get; set; }
    }

    public class paymentMethodResponse
    {
        public bool registered { get; set; }
        public bool isPrimary { get; set; }
        public card card { get; set; }
        public string paymentClass { get; set; }
    }

    public class card
    {
        public string cardFingerprint { get; set; }
        public string cardToken { get; set; }
        public string cardType { get; set; }
        [JsonProperty(PropertyName = "new")]
        public bool newCard { get; set; }
        public string cardUsageType { get; set; }
        public string cardScheme { get; set; }
        public string maskedPan { get; set; }
        public string expiryDate { get; set; }
        public string issuer { get; set; }
        public string issuerCountry { get; set; }
        public string cardHolderName { get; set; }

    }
}
