namespace Voucherify.Api.Features.Customers.Responses;

public class ReferralCodeResponse
{
    public string? ReferralCode { get; set; }
    public string? ReferrerId { get; set; }
}
