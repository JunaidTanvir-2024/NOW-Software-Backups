﻿using Application.Common.Interfaces.Payment;
using Application.Common.Settings;
using Application.Features.AutoTopup;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Payment.Card.ExistingCardPayment;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;
using Microsoft.Extensions.Options;

namespace Application.Features.Payment.Card.ExistingCardPaymentV2;

public class ExistingCardPaymentRequestHandlerV2 : IRequestHandler<ExistingCardPaymentRequestV2, Result<CardResponse>>
{
    private readonly IStringLocalizer<ExistingCardPaymentRequestHandlerV2> _localizer;
    private readonly IPaymentService _paymentService;
    private readonly ICardService _cardService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly ITopupRepository _topupRepo;
    private readonly IPayPalService _payPalService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly TopupSettings _topupSettings;

    public ExistingCardPaymentRequestHandlerV2(
        IStringLocalizer<ExistingCardPaymentRequestHandlerV2> localizer,
        IPaymentService paymentService,
        ICardService cardService,
        ICurrentUser currentUser,
        IMapper mapper,
        ITopupRepository topupRepo,
        IPayPalService payPalService,
        IUnitOfWork unitOfWork,
        IOptions<TopupSettings> topupSettings)
    {
        _localizer = localizer;
        _paymentService = paymentService;
        _cardService = cardService;
        _currentUser = currentUser;
        _mapper = mapper;
        _topupRepo = topupRepo;
        _payPalService = payPalService;
        _unitOfWork = unitOfWork;
        _topupSettings = topupSettings.Value;
    }

    public async Task<Result<CardResponse>> Handle(ExistingCardPaymentRequestV2 request, CancellationToken cancellationToken)
    {
        string existigCardNumber, cardScheme;

        //Check if card is user own card
        var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
        if (cards == null || cards != null &&
            !cards.Any(x => x.CardToken.Equals(
                request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)))
        {
            return Result<CardResponse>.Failure(
                _localizer[CustomStatusKey.InvalidPaymentCard], CustomStatusCode.InvalidPaymentCard);
        }

        existigCardNumber = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).MaskedPan;

        cardScheme = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).CardScheme;
        var setAutoTopupInfo = _mapper.Map<PaymentTopupInfo>(request.TopupInfo!);

        //if (request.BundleInfo?.IsRenewable == true && request.CreditSimInfo==null)//Only for Purchase bundle
        //{
        //    //Suspend PayPal subscription if Autorenewal is already setuped with paypal
        //    var msisdnInfo = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn!);
        //    var bundlesResponse = await _unitOfWork.BundleRepo.GetBundleById(new BundleByIdRequest() { Id = request.BundleInfo.BundleId.ToString() });
        //    var autoRenewal = await _unitOfWork.BundleRepo.GetBundleAutoRenewal(request.Msisdn!, msisdnInfo.AccountId!, bundlesResponse.UuId!);
        //    if(autoRenewal?.IsRenew==true && autoRenewal?.PaymentMethod?.Equals("paypal", StringComparison.InvariantCultureIgnoreCase)==true)
        //    {
        //        await _payPalService.PayPalCancelSubscription(new Paypal.Models.PaypalSuspendSubscriptionRequest
        //        {
        //            SubscriptionId = autoRenewal.InitialTransactionId!,
        //        });
        //    }
        //}
        //if (setAutoTopupInfo?.AutoTopupInfo?.Status == true && request.CreditSimInfo == null)//Only for Purchase topup
        //{
        //    //Suspend PayPal subscription if Autotopup is already setuped with paypal
        //    var autoTopup = await _topupRepo.GetAutoTopup(request.Msisdn!, request.Email!);
        //    if (autoTopup?.Status == true && autoTopup.PaymentMethod?.Equals("paypal", StringComparison.InvariantCultureIgnoreCase) == true)
        //    {
        //        await _payPalService.PayPalCancelSubscription(new Paypal.Models.PaypalSuspendSubscriptionRequest
        //        {
        //            SubscriptionId = autoTopup.InitialTransactionId!,
        //        });
        //    }
        //}
        if (setAutoTopupInfo?.AutoTopupInfo != null)
        {
            setAutoTopupInfo.AutoTopupInfo.ThresHoldAmount = _topupSettings.ThresholdAmount;
        }
        return await _paymentService.HandleCardPaymentRequest(
                null!,
                request.PaymentCardInfo,
                null!,
                setAutoTopupInfo!,
                request.BundleInfo!,
                request.CreditSimInfo!,
                request.Msisdn!,
                request.Email!,
                request.IpAddress!,
                existigCardNumber,
                cardScheme,
                false,
                request.ConversionID,
               (int) (request.ConversionPlatFormID),
               request.IsRetry);
    }
}