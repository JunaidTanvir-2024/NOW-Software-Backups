using FluentValidation;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Promotions.Requests;

public class ValidatePromotionTierRequest
{
    public string PromotionTierId { get; set; } = null!;
    public string CustomerSourceId { get; set; } = null!;
    public Metadata? CustomerMetadata { get; set; }
}
internal class ValidatePromotionTierRequestValidator : AbstractValidator<ValidatePromotionTierRequest>
{
    public ValidatePromotionTierRequestValidator()
    {
        RuleFor(p => p.PromotionTierId).NotNull().NotEmpty();
        RuleFor(p => p.CustomerSourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.CustomerSourceId = phoneNumber);
    }
}
