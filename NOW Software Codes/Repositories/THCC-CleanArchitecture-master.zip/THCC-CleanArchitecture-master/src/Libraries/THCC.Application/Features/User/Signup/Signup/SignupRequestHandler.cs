using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.Signup.Signup;

public class SignupRequestHandler : IRequestHandler<SignupRequest, object>
{
    #region Fields

    private readonly IUserService _userService;
    private readonly ILegacyRepository _legacyRepo;
    private readonly IUserRepository _userRepository;
    private readonly IMailService _mailService;

    #endregion

    #region Ctor

    public SignupRequestHandler(
        IUserService userService,
        ILegacyRepository legacyRepository,
        IUserRepository userRepository,
        IMailService mailService)
    {
        _userService = userService;
        _legacyRepo = legacyRepository;
        _userRepository = userRepository;
        _mailService = mailService;
    }

    #endregion

    #region Request Handler

    public async Task<object> Handle(SignupRequest request, CancellationToken cancellationToken)
    {
        request.UserInfo.Email = request.UserInfo.Email.Trim();
        request.UserInfo.Password = request.UserInfo.Password.Trim();

        //Check if user exists in new DB
        var user = await _userRepository.GetUserByEmailAsync(request.UserInfo.Email);
        if (user?.EmailConfirmed == true)
        {
            return ErrorResult.Failure(CustomStatusKey.EmailAlreadyRegistered, CustomStatusCode.BadRequest);
        }

        //Check if user exists in legacy DB
        var legacyUser = await _legacyRepo.GetUserByEmail(request.UserInfo.Email);
        if (user == null && legacyUser?.IsConfirmedUser == true)
        {
            return ErrorResult.Failure(CustomStatusKey.EmailAlreadyRegistered, CustomStatusCode.BadRequest);
        }

        //Check email validation
        var isValidEmail = await _mailService.IsValidEmailAddress(request.UserInfo.Email);
        if (!isValidEmail)
        {
            return ErrorResult.Failure(
                CustomStatusKey.EmailNotSupported, CustomStatusCode.BadRequest);
        }

        var response = new SignUpInfoDto();
        if (user?.EmailConfirmed == false)
        {
            //Update this user in new db 
            response = await _userService.UpdateUserAsync(
               user!,
               request.UserInfo.FirstName,
               request.UserInfo.LastName,
               request.UserInfo.Password,
               false);
        }
        else
        {
            //Register this user in new db 
            response = await _userService.SignUpAsync(
               request.UserInfo.FirstName,
               request.UserInfo.LastName,
               request.UserInfo.Email,
               request.UserInfo.Password,
               UserRole.Customer,
               false);
        }
        return !response.IsSuccess ? ErrorResult.Failure(CustomStatusKey.SignUpFailed, CustomStatusCode.BadRequest) : Unit.Value;
    }

    #endregion
}