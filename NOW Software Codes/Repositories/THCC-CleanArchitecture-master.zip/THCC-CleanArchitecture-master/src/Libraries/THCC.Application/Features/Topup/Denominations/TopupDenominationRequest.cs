﻿using THCC.Application.Settings;

namespace THCC.Application.Features.Topup.Denominations
{
    public class TopupDenominationRequest : IRequest<TopupSettings>
    {
    }
}
