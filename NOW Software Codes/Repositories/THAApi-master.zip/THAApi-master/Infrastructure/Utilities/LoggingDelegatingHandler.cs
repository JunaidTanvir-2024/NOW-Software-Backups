﻿using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Infrastructure.Utilities
{
    public class LoggingDelegatingHandler : DelegatingHandler
    {
        string name;
        ILogger logger;

        public LoggingDelegatingHandler(string name) 
            : base(new HttpClientHandler())
        {
            this.name = name;
            this.logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .WriteTo.RollingFile($"..\\logs\\HttpClient\\{name}", outputTemplate: "{Message}{NewLine}")
                .CreateLogger();
        }

        protected async override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();
            stopwatch.Start();

            var response = await base.SendAsync(request, cancellationToken);

            var date = DateTime.UtcNow.ToString("s", System.Globalization.CultureInfo.InvariantCulture);
            var responseTime = stopwatch.ElapsedMilliseconds;

            string jsonContent = response.Content.ReadAsStringAsync().Result;

            var message = $"{date} {request.Method} {request.RequestUri}  {jsonContent} =>  {response.StatusCode} {responseTime}";

#if DEBUG
            System.Console.WriteLine($"{date} HttpClient[{this.name}] {request.Method} {request.RequestUri} => {response.StatusCode} {responseTime}");
#endif

            this.logger.Information(message);

            return response;
        }
    }
}
