﻿namespace Application.Common.Settings;

public class DatabaseSettings
{
    public const string SectionName = "DatabaseSettings";
    public static DatabaseSettings Bind = new DatabaseSettings();
    public string? DefaultConnection { get; set; }
    public string? DigiTalkConnection { get; set; }
    public string? DigitalkMobileRepConnection { get; set; }
    public string? PaypalConnection { get; set; }
    public string? THMGeneral { get; set; }
}