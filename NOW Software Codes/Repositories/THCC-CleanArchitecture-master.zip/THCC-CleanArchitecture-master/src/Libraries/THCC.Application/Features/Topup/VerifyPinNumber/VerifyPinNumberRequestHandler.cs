﻿using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Topup.VerifyPinNumber
{
    public class VerifyPinNumberRequestHandler : IRequestHandler<VerifyPinNumberRequest, object>
    {
        private readonly ICallingCardRepository _callingCardRepository;

        public VerifyPinNumberRequestHandler(ICallingCardRepository callingCardRepository)
        {
            _callingCardRepository = callingCardRepository;
        }

        public async Task<object> Handle(VerifyPinNumberRequest request, CancellationToken cancellationToken)
        {
            request.Pin = request.Pin.Trim();
            return await _callingCardRepository.GetPinInfo(request.Pin) == null
                ? ErrorResult.Failure(CustomStatusKey.InvalidPin, CustomStatusCode.BadRequest)
                : Unit.Value;
        }
    }
}