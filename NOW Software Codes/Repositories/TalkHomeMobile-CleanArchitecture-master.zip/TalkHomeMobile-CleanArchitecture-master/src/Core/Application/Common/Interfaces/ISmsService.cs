﻿using Application.Common.Extensions.DependencyResolver;

namespace Application.Common.Interfaces;

public interface ISmsService : IServicesType.ITransientService
{
    Task SendOtpMessage(string msisdn, string otp);
}
