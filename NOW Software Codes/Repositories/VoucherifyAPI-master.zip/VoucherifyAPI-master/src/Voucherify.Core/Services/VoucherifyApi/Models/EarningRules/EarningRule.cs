using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Loyalties;

namespace Voucherify.Core.Services.VoucherifyApi.Models.EarningRules;

public class EarningRule
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("validation_rule_id")]
    public string? ValidationRuleId { get; set; }

    [JsonPropertyName("loyalty")]
    public Loyalty? Loyalty { get; set; }

    [JsonPropertyName("event")]
    public string? EventType { get; set; }

    [JsonPropertyName("source")]
    public Source? Source { get; set; }

    [JsonPropertyName("active")]
    public bool IsActive { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}
