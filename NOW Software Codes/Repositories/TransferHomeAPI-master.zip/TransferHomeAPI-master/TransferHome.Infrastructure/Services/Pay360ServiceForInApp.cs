﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Infrastructure.BLL.Interfaces;
using TransferHome.Infrastructure.Services.Interfaces;
using TransferHome.Models.Contracts.InAppModels;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.Contracts.Response;
using TransferHome.Models.Contracts.Service.Pay360ApiContracts;
using TransferHomeAPI.Infrastructure.Services.Interfaces;
using TrasnferHome.Infrastructure.BLL.Interfaces;
using TrasnferHome.Models.Configurations;
using TrasnferHome.Models.Utility;

namespace TransferHomeAPIInfrastructure.Services
{
    public class Pay360ServiceForInApp : IPay360ServiceForInApp
    {
        private readonly IPay360Service Pay360Service;
        private readonly IBL_User UserBL;
        private readonly IBL_Transfer TransferBL;
        private readonly ILogger Logger;
        private readonly string Pay360APiEndpoint;

        private readonly bool IsAuthorization;
        private readonly bool Do3DSecure;
        private readonly bool IsDirectFullfilment;

        public Pay360ServiceForInApp(IPay360Service pay360Service, ILogger logger, IBL_User userBl, IBL_Transfer transferBL, IOptions<Pay360Config> Pay360Config)
        {
            Pay360Service = pay360Service;
            Logger = logger;
            UserBL = userBl;
            TransferBL = transferBL;
            Pay360APiEndpoint = Pay360Config.Value.Pay360ApiEndpoint;
            IsAuthorization = Pay360Config.Value.IsAuthorization;
            Do3DSecure = Pay360Config.Value.Do3DSecure;
            IsDirectFullfilment = Pay360Config.Value.IsDirectFullfilment;
        }

        public async Task<Tuple<GetCutomerInfoResponseModel, int>> GetCutomerInfo(int userId)
        {
            try
            {
                GetCutomerInfoResponseModel responseModel = new GetCutomerInfoResponseModel();

                var userResponse = await UserBL.GetUserById(userId);

                if (userResponse != null)
                {
                    responseModel.Balance = userResponse.Balance;
                    responseModel.BalanceCurrency = userResponse.BalanceCurrency;

                    var cardsResponse = await Pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
                    {
                        customerUniqueRef = string.IsNullOrEmpty(userResponse.Email) ? userResponse.PhoneNumber : userResponse.Email,
                        productCode = "TRH"
                    });

                    if (cardsResponse != null && cardsResponse.errorCode == 0)
                    {
                        responseModel.Pay360Cards = cardsResponse.payload;
                        return new Tuple<GetCutomerInfoResponseModel, int>(responseModel, 0);
                    }
                    else
                    {
                        return new Tuple<GetCutomerInfoResponseModel, int>(responseModel, cardsResponse.errorCode);
                    }
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360ServiceForInApp, Method: Topup, Parameters=> model: {userId}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return null;
            }
        }

        public async Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Resume3DTransaction(Pay360Resume3DRequest request)
        {

            string endpoint = Pay360APiEndpoint + "Pay360CashierApi/Resume3DSecureTransaction";

            GenericPay360ApiResponse<Pay360PaymentResponse> ret = new GenericPay360ApiResponse<Pay360PaymentResponse>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360PaymentResponse>>(Result);

            return ret;

        }

        public async Task<GenericPay360ApiResponse<RefundFullPaymentResponseModel>> RefundFullPayment(RefundFullPaymentRequestModel request)
        {

            string endpoint = Pay360APiEndpoint + "Pay360CommonServices/RefundFullPayment";

            GenericPay360ApiResponse<RefundFullPaymentResponseModel> ret = new GenericPay360ApiResponse<RefundFullPaymentResponseModel>();

            var Json = JsonConvert.SerializeObject(request);
            var Result = await Post(endpoint, Json);

            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<RefundFullPaymentResponseModel>>(Result);

            return ret;

        }

        public async Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType)
        {
            GenericPay360ApiResponse<Pay360PaymentResponse> ret = new GenericPay360ApiResponse<Pay360PaymentResponse>();

            string endpoint = "";
            string Json = "";
            string Result = "";

            switch (paymentType)
            {
                case Pay360PaymentType.New:
                    endpoint = Pay360APiEndpoint + "Pay360CashierApi/NewCustomerPayment";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestNew);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.Default:
                    endpoint = Pay360APiEndpoint + "Pay360CashierApi/ExistingCustomerPaymentDefaultCard";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestDefault);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.ExistingNew:
                    endpoint = Pay360APiEndpoint + "Pay360CashierApi/ExistingCustomerPaymentNewCard";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestExistingNew);
                    Result = await Post(endpoint, Json);
                    break;
                case Pay360PaymentType.Token:
                    endpoint = Pay360APiEndpoint + "Pay360CashierApi/PaymentToken";
                    Json = JsonConvert.SerializeObject(request.Pay360PaymentRequestToken);
                    Result = await Post(endpoint, Json);
                    break;
            }
            if (Result == null)
            {
                return null;
            }

            ret = JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360PaymentResponse>>(Result);
            return ret;

        }

        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address), Timeout = TimeSpan.FromSeconds(60) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                    {
                        throw new WebException();
                    }

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (System.Exception e)
            {
                return null;
            }
        }

        public string GetResumeUrl(string path, string baseUrl)
        {
            string Domain = "";

            Uri result = null;

            if (Debugger.IsAttached)
            {
                if (Uri.TryCreate(new Uri(baseUrl), path, out result))
                {
                    Domain = result.AbsoluteUri;
                }
                else
                {
                    Domain = baseUrl + "/" + path;
                }
            }
            else
            {
                if (Uri.TryCreate(new Uri(baseUrl), path, out result))
                {
                    Domain = result.AbsoluteUri.Replace("http", "https");
                }
                else
                {
                    Domain = new Uri(baseUrl).ToString();
                    Domain = Domain.Replace("http", "https");
                    Domain = Domain + path;
                }

            }
            return Domain;
        }



        public Pay360PaymentBase CreatePay360PaymentBaseRequest(InAppPay360CardPostModel model)
        {
            Pay360PaymentBase result = new Pay360PaymentBase
            {
                cardCv2 = model.CVV,
                customerMsisdn = model.CustomerPhoneNumber,
                isAuthorizationOnly = IsAuthorization,
                isDirectFullfilment = IsDirectFullfilment,
                transactionAmount = model.Amount,
                transactionCurrency = model.Currency,
                do3DSecure = Do3DSecure
            };

            return result;
        }

        public Pay360PaymentRequestNew CreatePay360PaymentRequestNew(InAppPay360CardPostModel model)
        {
            Pay360PaymentRequestNew result = new Pay360PaymentRequestNew
            {
                customerName = model.NameOnCard,
                cardCv2 = model.CVV,
                cardExpiryDate = model.ExpiryMonth + model.ExpiryYear,
                customerMsisdn = model.CustomerPhoneNumber,
                customerEmail = model.CustomerEmail,
                isAuthorizationOnly = IsAuthorization,
                isDirectFullfilment = IsDirectFullfilment,
                isDefaultCard = true,
                cardPan = model.CardNumber,
                do3DSecure = Do3DSecure,
                transactionAmount = model.Amount,
                transactionCurrency = model.Currency,
                billingAddress = new billingAddress
                {
                    line1 = "xx",
                    line2 = "",
                    line3 = "",
                    line4 = "",
                    city = "xx",
                    region = "xx",
                    postcode = "xx",
                    countryCode = "GB"
                }
            };

            return result;
        }

        public Pay360PaymentRequestExistingNew CreatePay360PaymentRequestExistingNew(InAppPay360CardPostModel model)
        {
            Pay360PaymentRequestExistingNew result = new Pay360PaymentRequestExistingNew
            {

                cardCv2 = model.CVV,
                cardExpiryDate = model.ExpiryMonth + model.ExpiryYear,
                cardPan = model.CardNumber,
                customerMsisdn = model.CustomerPhoneNumber,
                isAuthorizationOnly = IsAuthorization,
                isDirectFullfilment = IsDirectFullfilment,
                isDefaultCard = false,
                do3DSecure = Do3DSecure,
                transactionAmount = model.Amount,
                transactionCurrency = model.Currency,
                customerName = model.NameOnCard,
                billingAddress = new billingAddress
                {
                    line1 = "xx",
                    line2 = "",
                    line3 = "",
                    line4 = "",
                    city = "xx",
                    region = "xx",
                    postcode = "xx",
                    countryCode = "GB"
                }
            };

            return result;
        }

        public Pay360PaymentRequestToken CreatePay360PaymentRequestToken(InAppPay360CardPostModel model)
        {
            Pay360PaymentRequestToken result = new Pay360PaymentRequestToken
            {
                cardCv2 = model.CVV,
                customerMsisdn = model.CustomerPhoneNumber,
                isAuthorizationOnly = IsAuthorization,
                isDirectFullfilment = IsDirectFullfilment,
                transactionAmount = model.Amount,
                transactionCurrency = model.Currency,
                do3DSecure = Do3DSecure,
                cardToken = model.Token
            };

            return result;
        }

    }
}
