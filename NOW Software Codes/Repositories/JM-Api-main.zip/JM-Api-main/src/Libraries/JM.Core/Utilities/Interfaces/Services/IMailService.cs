using JM.Core.Utilities.DependencyResolver;
using JM.Core.Utilities.Dtos.Mail;

namespace JM.Infrastructure.Services.Mailing;
public interface IMailService : ResolveAs.IScoped
{
    Task SendEmail(MailDto.Request request, CancellationToken cancellationToken = default);
}
