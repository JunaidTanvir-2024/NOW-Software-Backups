﻿namespace SC.Core.Common.Definitions.Constants;
public static partial class AppConstants
{
    public class ConnectionStrings
    {
        public const string SectionName = "ConnectionStrings";
        public static ConnectionStrings Bind = new ConnectionStrings();
    }
}
