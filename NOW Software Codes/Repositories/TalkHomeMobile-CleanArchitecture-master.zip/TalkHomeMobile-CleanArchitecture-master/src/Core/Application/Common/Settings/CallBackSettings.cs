﻿namespace Application.Common.Settings;

public class CallBackSettings
{
    public const string SectionName = "CallBackSettings";
    public static CallBackSettings Bind = new CallBackSettings();
    public string? WebBaseUrl { get; set; }
    public string? AppBaseUrl { get; set; }
}