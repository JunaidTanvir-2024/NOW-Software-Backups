﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.Card.RemoveCard;

public class RemoveCardRequestHandler : IRequestHandler<RemoveCardRequest, object>
{
    #region Fields

    private readonly ICardService _cardService;
    private readonly ICurrentUser _currentUser;
    private readonly IUserRepository _userRepository;
    private readonly ITopupRepository _topupRepository;

    #endregion

    #region Ctors
    public RemoveCardRequestHandler(
        ICardService cardService,
        ICurrentUser currentUser,
        IUserRepository userRepository,
        ITopupRepository topupRepository)
    {
        _cardService = cardService;
        _currentUser = currentUser;
        _userRepository = userRepository;
        _topupRepository = topupRepository;
    }

    #endregion

    #region Method

    public async Task<object> Handle(RemoveCardRequest request, CancellationToken cancellationToken)
    {
        var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
        if (userProduct == null)
        {
            return ErrorResult.Failure(CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
        }

        //Get Customer Cards
        var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail());
        var card = cards.Find(e => e.CardToken == request.CardToken);
        if (card == null)
        {
            return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
        }

        //Get current Auto Top-up
        var autoTopupInfo = await _topupRepository.GetAutoTopup(userProduct.Product!, _currentUser.GetUserEmail()!);
        if (autoTopupInfo?.Status == true && autoTopupInfo.MaskedPan?.Equals(card.MaskedPan) == true)
        {
            await _topupRepository.SetAutoTopup(
                autoTopupInfo.Status,
                userProduct.Product!,
                _currentUser.GetUserEmail()!,
                Convert.ToDecimal(autoTopupInfo.Topup),
                autoTopupInfo.Currency!,
                Convert.ToDecimal(autoTopupInfo.ThresHold));
        }
        if (autoTopupInfo?.Status == true && card.IsPrimary && cards.Count == 1)
        {
            await _topupRepository.DisableAutoTopup(userProduct.Product!);
        }
        await _cardService.RemoveCard(request.CardToken, _currentUser.GetUserEmail()!);
        return await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
    }

    #endregion
}