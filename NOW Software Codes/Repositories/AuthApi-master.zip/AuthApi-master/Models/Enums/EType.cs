﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    
    public enum EType
    {
        Msisdn = 1,
        DeviceUUID = 2,
        Email = 3
    }
}
