﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Sochitel.Request
{
    public class SochitelExeReq
    {
        public string nowtelTransactionReference { get; set; }
        public int operatorid { get; set; }
        public string product { get; set; }
        public string messageToRecipient { get; set; }
        public string fromMSISDN { get; set; }
    }

    public class SochitelSMSReq
    {
        public string MSISDN { get; set; }
        public string Currency { get; set; }
        public string SMSContent { get; set; }
    }
}
