namespace Application.Common.Settings;

public sealed class MailSettings
{
    public const string SectionName = "MailSettings";
    public static MailSettings Bind = new MailSettings();
    public bool IsActive { get; set; }

    public string? Host { get; set; }
    public string? UserName { get; set; }
    public string? Password { get; set; }
    public int Port { get; set; }

    public string? AlternateHost { get; set; }
    public string? AlternateHostUserName { get; set; }
    public string? AlternateHostPassword { get; set; }
    public int AlternatePort { get; set; }
    public string[]? AlternateHostDomains { get; set; }

    public MailSettingsData ForgotPassword { get; set; } = default!;
    public MailSettingsData SignUp { get; set; } = default!;
    public MailSettingsData Payment { get; set; } = default!;
    public MailSettingsData FreeSim { get; set; } = default!;
}
public sealed class MailSettingsData
{
    public const string SectionName = "MailSettingsData";
    public static MailSettingsData Bind = new MailSettingsData();
    public string? From { get; set; }
    public string? DisplayName { get; set; }
    public string? Subject { get; set; }
    public bool SendEmail { get; set; }
}