﻿namespace THCC.Application.Features.User.SocialLoginSignUp;

public class SocialLoginSignUpRequest : IRequest<object>
{
    public string AccessToken { get; set; } = default!;
    public SocialLoginType SocialLoginType { get; set; } = default!;
}

public class SocialLoginSignUpRequestValidator : AbstractValidator<SocialLoginSignUpRequest>
{
    public SocialLoginSignUpRequestValidator()
    {
        RuleFor(p => p.AccessToken).NotEmpty();
        RuleFor(p => p.SocialLoginType).IsInEnum();
    }
}