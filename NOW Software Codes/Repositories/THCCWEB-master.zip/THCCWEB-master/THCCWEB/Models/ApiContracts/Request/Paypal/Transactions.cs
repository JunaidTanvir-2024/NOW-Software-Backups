﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request.Paypal
{
    public class Transactions
    {
        public Transactions()
        {
            Amount = new Amounts();
        }
        public Amounts Amount { get; set; }

        public string Description { get; set; }
    }
}
