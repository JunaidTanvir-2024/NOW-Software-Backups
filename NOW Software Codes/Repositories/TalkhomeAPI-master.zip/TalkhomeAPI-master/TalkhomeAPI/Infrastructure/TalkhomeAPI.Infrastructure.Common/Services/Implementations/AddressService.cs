﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class AddressService : IAddressService
    {
        private readonly HttpClient _httpClient;
        private readonly AddressApiConfig _addressConfig;

        public AddressService(
            HttpClient httpClient,
            IOptions<AddressApiConfig> addressConfig)
        {
            _httpClient = httpClient;
            _addressConfig = addressConfig.Value;
        }

        public async Task<HttpResponseMessage> GetAddress(string postCode)
        {

            String encodedBaiscAuthToken = Convert.ToBase64String(
                Encoding.GetEncoding("ISO-8859-1").GetBytes(_addressConfig.ApiKey));

            _httpClient.DefaultRequestHeaders.Add("Authorization", "Basic " + encodedBaiscAuthToken);

            return await _httpClient.GetAsync(_addressConfig.ApiEndpoint + postCode);
        }
    }
}
