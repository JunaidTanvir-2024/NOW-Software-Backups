﻿namespace THCC.Application.Models.Dtos
{
    public class UserDto
    {
        public string Id { get; set; } = default!;
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string Email { get; set; } = default!;
        public string? ImagePath { get; set; }
        public bool IsSubscribedToNewsletter { get; set; } = false;
    }
}