using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DC.Core.Common.Entities;
public class GetMsisdnWithNoPlan
{

    public string Msisdn { get; set; }
    public string TransactionType { get; set; }
    public DateTime CreatedOn { get; set; }
}
