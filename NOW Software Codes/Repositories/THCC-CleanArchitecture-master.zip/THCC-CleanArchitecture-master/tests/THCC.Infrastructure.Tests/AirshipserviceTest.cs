using System.Net.Http;


using FakeItEasy;

using FluentAssertions;

using Microsoft.Extensions.Options;

using Serilog;

using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Settings;
using THCC.Infrastructure.Services.Tracking.AirShip;

namespace THCC.Infrastructure.Tests
{
    public class AirshipserviceTest
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger _logger;
        private readonly IOptions<AirShipSettings> _airshipSetting;
        private readonly IAirshipService _airshipServiceInterface;
        private readonly AirshipService _airshipService;

        public AirshipserviceTest()
        {
            _airshipSetting = A.Fake<IOptions<AirShipSettings>>();
            _logger = A.Fake<ILogger>();
            _httpClientFactory = A.Fake<IHttpClientFactory>();
            _airshipServiceInterface = A.Fake<IAirshipService>();
            _airshipService = new AirshipService(_httpClientFactory, _airshipSetting, _logger);
        }

        [Fact]
        public async Task CreateandAssociate_EmailChannel_ExistingUser()
        {
            //Arrange
            var request = new
            {
                Email = "usman@yahoo.com",
            };
            (bool, string?) response = (true, null);
            A.CallTo(() => _airshipSetting.Value.IsActive).Returns(true);
            A.CallTo(() => _airshipSetting.Value.ApiEndpoint).Returns("http://172.24.1.95:20066/");
            A.CallTo(() => _airshipServiceInterface.EmailAssociationWithNamedUser(request.Email, request.Email)).Returns(response);


            //Act
            var result = await _airshipService.CreateEmailChannelAndAssociation(request.Email);

            //Assert
            result.Should().BeOfType<(bool, string)>()
                .Which.Should().BeEquivalentTo(response);
        }
        [Fact]
        public async Task CreateandAssociate_EmailChannel_NewUser()
        {
            //Arrange
            var request = new
            {
                Email = "habibulrehman@yopmail.com",

            };
            (bool, string?) response = (true, null);
            A.CallTo(() => _airshipSetting.Value.IsActive).Returns(true);
            A.CallTo(() => _airshipSetting.Value.ApiEndpoint).Returns("http://172.24.1.95:20066/");
            A.CallTo(() => _airshipServiceInterface.EmailAssociationWithNamedUser(request.Email, request.Email)).Returns(response);


            //Act
            var result = await _airshipService.CreateEmailChannelAndAssociation(request.Email, true);

            //Assert
            result.Should().BeOfType<(bool, string)>()
                .Which.Should().BeEquivalentTo(response);
        }
    }
}