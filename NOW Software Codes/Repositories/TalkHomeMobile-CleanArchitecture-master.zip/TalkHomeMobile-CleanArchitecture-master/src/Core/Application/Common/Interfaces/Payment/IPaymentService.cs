﻿using Application.Common.Extensions.DependencyResolver;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.InAppReceipt;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;

namespace Application.Common.Interfaces.Payment;

public interface IPaymentService : IServicesType.ITransientService
{
    Task<Result<CardResponse>> HandleCardPaymentRequest(
            PaymentNewCardInfo paymentNewCardInfo,
            PaymentExistingCardInfo paymentExistingCardInfo,
            PaymentAddressInfo paymentAddressInfo,
            PaymentTopupInfo topupInfo,
            PaymentBundleInfo bundleInfo,
            PaymentCreditSimInfo creditSimInfo,           
            string msisdn,
            string email,
            string ipAddress,
            string cardMaskedPan,
            string cardScheme,
            bool isAuthorizeOnly = default,
            string? ConversionID = default,
            int ConversionPlatFormID = default,
            bool IsRetry = false,
              PaymentEarlyTerminationChargesInfo? earlyTerminationChargesInfo=null);
    Task PaymentFulfillment(string transactionId, string msisdn, string emailAddress, float discount, bool IsCardPayment);
    Task<Result<PaypalResponse>> HandlePaypalExecuteSubscriptionRequest(
       string payerId,
       string paymentId,
       string uniqueRef,
       int orderId,
       string subscriptionId);
    Task<Result<CardResponse>> HandleCardPaymentResume3dRequest(
        string transactionId,
        int orderId,
        bool IsAuthorizeOnly,
        bool IsFastTopup = false,
        bool IsAppRequest = false);

    Task<Result<PaypalResponse>> HandlePaypalPaymentRequest(
        PaymentTopupInfo topupInfo,
        PaymentBundleInfo bundleInfo,
        PaymentCreditSimInfo creditSimInfo,
        string msisdn,
        string email,
        string ipAddress,
        bool isSubscriptionRequest = default,
        bool subscriptionWithInitialSale = default,
        string? ConversionID = null,
        int ConversionPlatFormID = default,
        PaymentEarlyTerminationChargesInfo? earlyTerminationChargesInfo = null);

    Task<Result<PaypalResponse>> HandleDirectPaypalExecuteRequest(
        string payerId,
        string paymentId,
        string uniqueRef,
        int orderId,
        bool IsFastTopup = false,
        bool IsAppRequest = false);

    Task<Result<InAppReceiptResponse>> VerifyInAppPurchaseReceipt(InAppReceiptRequest request);
}
