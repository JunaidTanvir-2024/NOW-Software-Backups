using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DC.Core.Features.Notifications.Requests;

public record SendActivationSmsRequest() : IRequest<IResultWrapper>
{ 
    public string RequestType { get; set; }
    public string RequestID { get; set; }



}
public class SendActivationSmsRequestValidator : AbstractValidator<SendActivationSmsRequest>
{
    public SendActivationSmsRequestValidator()
    {

    }
}

