﻿
using Application.Common.Enums;
using Application.Common.Interfaces;
using Application.Common.Interfaces.Payment;
using Application.Common.Interfaces.Shared;
using Application.Common.Settings;
using Application.Features.Bundle.Model;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;
using CancelBundleApi.Models.RequestModels;
using CancelBundleApi.Models.ResponseModels;
using CancelBundleApi.Services.Interfaces;
using Domain.Aggregate;
using Domain.Entities;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Sentry.Protocol;
using System;
using System.Reflection.Metadata;

namespace Application.Features.Bundle.CancelBundleDetail.RefundBundle;
public class RefundBundleRequestHandler : IRequestHandler<RefundBundleRequest, Result<RefundBundleResponse>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<CancelBundleDetailRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly ICurrentUser _currentUser;
    private readonly ICardService _cardService;
    private readonly IPayPalService _payPalService;
    private readonly IUnSubscribeBundlesRequestService _unSubscribeBundlesRequestService;
    private readonly CancelBundlesSettings _cancelBundlesSettings;

    public RefundBundleRequestHandler(IUnitOfWork uow,
        IStringLocalizer<CancelBundleDetailRequestHandler> localizer,
        IMapper mapper,
        ICommonService commonService,
        ICurrentUser currentUser,
        ICardService cardService,
        IPayPalService payPalService,
        IOptions<CancelBundlesSettings> cancelBundlesSettings,
        IUnSubscribeBundlesRequestService unSubscribeBundlesRequestService)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
        _commonService = commonService;
        _currentUser = currentUser;
        _cardService = cardService;
        _payPalService = payPalService;
        _unSubscribeBundlesRequestService = unSubscribeBundlesRequestService;
        _cancelBundlesSettings = cancelBundlesSettings.Value;
    }
    public async Task<Result<RefundBundleResponse>> Handle(RefundBundleRequest request, CancellationToken cancellationToken)
    {
        (bool isAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();


        var msisdnDetails = await _uow.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdnDetails == null)
        {
            return Result<RefundBundleResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }

        var subscribeBundlesList = _mapper.Map<List<SubscribedBundleInfo>>(await _uow.UserRepo.GetSubscribedBundlesV3(msisdnDetails.AccountId!));

        var subscribedBundle = subscribeBundlesList.FirstOrDefault(t => t.SubscriberBundleId == request.SubscriberBundleId);
        if (subscribedBundle == null || !Convert.ToString(subscribedBundle.Id).Equals(request.BundleGuidId, StringComparison.OrdinalIgnoreCase))
        {
            return Result<RefundBundleResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }

        var bundleInfo = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(subscribedBundle.Id.ToString()));
        if (bundleInfo == null)
        {
            return Result<RefundBundleResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }
        var (isSuccess, orderDetails, orderItemDetails) = await _uow.PaymentRepo.GetOrderDetailsBySubscribeBundleId(request.SubscriberBundleId);
        if (!isSuccess)
        {
            return Result<RefundBundleResponse>.Failure(new RefundBundleResponse() { OrderId = 0 }, _localizer[CustomStatusKey.InternalServerError], CustomStatusCode.InternalServerError);
        }
        if (isSuccess && orderDetails == null)
        {
            return Result<RefundBundleResponse>.Failure(new RefundBundleResponse() { OrderId = 0 }, _localizer[CustomStatusKey.CancelBundleBackwardCompatibility], CustomStatusCode.CancelBundleBackwardCompatibility);

        }
        //check if it is early termination              

        if (subscribedBundle.SubscriptionDate.AddDays(14) <= DateTime.UtcNow || (subscribedBundle.GrantedCount > 1))
        {
            return Result<RefundBundleResponse>.Failure(_localizer[CustomStatusKey.RefundCriteriaFailed], CustomStatusCode.RefundCriteriaFailed);
        }

        var orderData = orderDetails.OrderData != null ? JsonConvert.DeserializeObject<OrderData>(orderDetails.OrderData!)! : new OrderData();
        CancelBundleDetails cancelBundleDetails = new CancelBundleDetails()
        {
            BundleDetails = bundleInfo,
            SubscriberBundleId = subscribedBundle.SubscriberBundleId
        };


        int totalData = 0;
        if (subscribedBundle.GprsDataBytes != 0)
        {
            totalData += 1;
        }
        if (subscribedBundle.Minutes != null && subscribedBundle.Minutes != "0")
        {
            totalData += 1;
        }


        cancelBundleDetails.RefundDetail = new RefundDetail();
        cancelBundleDetails.RefundDetail.DataConsume = subscribedBundle.GprsDataBytes == 0 ? 0 : 100 - Math.Round(Convert.ToDecimal(subscribedBundle.RemainingGprsDataBytes) / Convert.ToDecimal(subscribedBundle.GprsDataBytes) * 100, 2);
        cancelBundleDetails.RefundDetail.SmsConsume = subscribedBundle.Texts == "0" ? 0 : 100 - Math.Round(Convert.ToDecimal(subscribedBundle.RemainingTexts) / Convert.ToDecimal(subscribedBundle.Texts) * 100, 2);
        cancelBundleDetails.RefundDetail.MinConsume = subscribedBundle.Minutes == "0" ? 0 : 100 - Math.Round(Convert.ToDecimal(subscribedBundle.RemainingMinutes) / Convert.ToDecimal(subscribedBundle.Minutes) * 100, 2);
        if (totalData == 1)
        {
            if (subscribedBundle.GprsDataBytes != 0)
            {
                cancelBundleDetails.RefundDetail.TotalConsume = cancelBundleDetails.RefundDetail.DataConsume;
            }
            else if (subscribedBundle.Minutes != null && subscribedBundle.Minutes != "0")
            {
                cancelBundleDetails.RefundDetail.TotalConsume = cancelBundleDetails.RefundDetail.MinConsume;
            }
        }
        else
        {
            cancelBundleDetails.RefundDetail.TotalConsume = (cancelBundleDetails.RefundDetail.DataConsume + cancelBundleDetails.RefundDetail.MinConsume) / 2;

        }
        cancelBundleDetails.RefundDetail.TotalConsumeAmount = cancelBundleDetails.RefundDetail.TotalConsume == 0 ? 0 : (bundleInfo.TotalPrice * cancelBundleDetails.RefundDetail.TotalConsume) / 100;
        cancelBundleDetails.RefundDetail.VAT = (bundleInfo.TotalPrice * _cancelBundlesSettings.VATPercentage) / 100;
        cancelBundleDetails.RefundDetail.TotalRefundAmount = Math.Round(Convert.ToDecimal(bundleInfo.TotalPrice) - (cancelBundleDetails.RefundDetail.VAT + cancelBundleDetails.RefundDetail.TotalConsumeAmount), 2);
        cancelBundleDetails.CancelStatusType = (int) CancelStatus.Refund;

        //Check if refund amount is less than 0.01 
        cancelBundleDetails.RefundDetail.TotalRefundAmount = cancelBundleDetails.RefundDetail.TotalRefundAmount < (decimal)0.01 ? 0 : cancelBundleDetails.RefundDetail.TotalRefundAmount;
      

        #region Order History Record
        var order = new Order();
        var orderhistoryBasket = new List<OrderItem>();
        orderhistoryBasket.Add(new OrderItem
        {
            Amount = Convert.ToSingle(cancelBundleDetails.RefundDetail.TotalRefundAmount),
            DiscountAmount = 0,
            BundleRef = bundleInfo.UuId!
        });

        order.BundleId = bundleInfo.UuId;
        order.BundleName = bundleInfo.DisplayName!;
        order.BundleCountryCode = bundleInfo.CountryCode!;
        order.OrderBaskets = orderhistoryBasket;
        order.Email = _currentUser.GetUserEmail()!;
        order.TransactionId = null!;
        order.Msisdn = request.Msisdn;
        order.PaymentMethod = orderDetails.PaymentMethodType;
        order.ConversionPlatFormID = 0;
        order.ConversionID = null!;
        order.IsRetry = false;
        order.IsRefund = true;
        order.OrderData = JsonConvert.SerializeObject(new OrderData()
        {
            IsAppRequest = isAppRequest,
            CheckoutType = (int) CheckOutType.CancelBundleRefund,
            AutoTopupInfo = null,
            BundleInfo = orderData.BundleInfo,
            CreditSimOrderId = 0,
            CardMaskedPan = orderData.CardMaskedPan,
            CardScheme = orderData.CardScheme,
            Alias = null!,
            SaveCard = false
        });

        int orderID = await _uow.PaymentRepo.SaveOrderHistory(order, (int) MediumType);
        bool refundPaymentSuccess = false;
        string refundPaymentTransactionId = string.Empty;
        // if amount is greater than 0 than refund otherwise this code is not executed
        if ((double) cancelBundleDetails.RefundDetail.TotalRefundAmount >= 0.01)
        {
            if (orderDetails.PaymentMethodType == (int) PaymentMethod.Card)
            {
                if (cancelBundleDetails.RefundDetail.TotalRefundAmount == (decimal) orderDetails.TotalAmount)
                {
                    (refundPaymentSuccess, refundPaymentTransactionId) = await _cardService.RefundFullPayment(orderDetails.TransactionId!);
                }
                else
                {
                    (refundPaymentSuccess, refundPaymentTransactionId) = await _cardService.RefundPartailPayment(
                        orderDetails.TransactionId!,
                        cancelBundleDetails.RefundDetail.TotalRefundAmount);

                }
                if (!refundPaymentSuccess)
                {
                    return Result<RefundBundleResponse>.Failure(_localizer[CustomStatusKey.InternalServerError], CustomStatusCode.InternalServerError);

                }
            }
            if (orderDetails.PaymentMethodType == (int) PaymentMethod.Paypal)
            {
                if (cancelBundleDetails.RefundDetail.TotalRefundAmount == (decimal) orderDetails.TotalAmount)
                {
                    (refundPaymentSuccess, refundPaymentTransactionId) = await _payPalService.PaypalRefundPayment(
                        new ApiRefundPaymentRequest
                        {
                            SaleId = orderDetails.TransactionId!
                        });
                }
                else
                {
                    (refundPaymentSuccess, refundPaymentTransactionId) = await _payPalService.PaypalRefundPayment(
                        new ApiRefundPaymentRequest
                        {
                            SaleId = orderDetails.TransactionId!,
                            Amount = new Amounts
                            {
                                Total = Convert.ToSingle(cancelBundleDetails.RefundDetail.TotalRefundAmount),
                                Currency = nameof(Currency.GBP)
                            }
                        });

                }
                if (!refundPaymentSuccess)
                {
                    return Result<RefundBundleResponse>.Failure(_localizer[CustomStatusKey.InternalServerError], CustomStatusCode.InternalServerError);

                }
            }
        }
        var existingAutoRenewalInfo = await _uow.BundleRepo.GetBundleAutoRenewal(orderDetails.Msisdn, msisdnDetails.AccountId, bundleInfo.UuId);
        if (existingAutoRenewalInfo?.IsRenew == true && existingAutoRenewalInfo?.PaymentMethod?.Equals("paypal", StringComparison.InvariantCultureIgnoreCase) == true)
        {
            await _payPalService.PayPalCancelSubscription(new PaypalSuspendSubscriptionRequest
            {
                SubscriptionId = existingAutoRenewalInfo.InitialTransactionId
            });
        }
        if (bundleInfo.Category == (int) BundleCategory.TwelveMonthsContract)
        {
            var changePlan = _mapper.Map<SubscribedBundleInfo>(await _uow.BundleRepo.GetChangePlanBundleByMsisdn(msisdnDetails.Msisdn!));
            if (changePlan != null)
            {
                if (changePlan.AutoRenewPaymentMethod?.Equals("paypal", StringComparison.InvariantCultureIgnoreCase) == true)
                {
                    var changePlanAutoRenewalInfo = await _uow.BundleRepo.GetBundleAutoRenewal(orderDetails.Msisdn, msisdnDetails.AccountId, changePlan.Id.ToString());
                    if (changePlanAutoRenewalInfo?.IsRenew == true && changePlanAutoRenewalInfo?.PaymentMethod?.Equals("paypal", StringComparison.InvariantCultureIgnoreCase) == true)
                    {
                        await _payPalService.PayPalCancelSubscription(new PaypalSuspendSubscriptionRequest
                        {
                            SubscriptionId = changePlanAutoRenewalInfo.InitialTransactionId
                        });
                    }
                }
                else
                {
                    await _uow.BundleRepo.SetBundleAutoRenewal(
                      false,
                      orderDetails.Msisdn,
                    msisdnDetails.AccountId!,
                      changePlan.Id.ToString()!,
                      orderDetails.Email,
                      PaymentMethod.Card,
                        null!,
                       isActive: false
                      );
                }
            }


        }

        await _uow.BundleRepo.SetBundleAutoRenewal(false,
                       orderDetails.Msisdn, msisdnDetails.AccountId!,
                       bundleInfo.UuId!,
                       orderDetails.Email,
                       (PaymentMethod) orderDetails.PaymentMethodType,
                       cardInitialTransactionId: Convert.ToString(request.SubscriberBundleId),
                       isActive: false);


        var AddOnRoamingSubscriberbundleId = await _uow.PaymentRepo.GetRoamingSubscriberBundleId(request.SubscriberBundleId, msisdnDetails.AccountId);

        await _unSubscribeBundlesRequestService.UnSubscribeService(new UnSubscribeBundlesRequest
        {
            SubscriberId = msisdnDetails.SubscriberId,
            SubscriberBundleId = request.SubscriberBundleId
        }
        );
        //If Any Roaming Bundle Activated than Cancel
        if (AddOnRoamingSubscriberbundleId != null && AddOnRoamingSubscriberbundleId.Count > 0)
        {
            foreach (var item in AddOnRoamingSubscriberbundleId.Where(x => x != null && x != 0))
            {
                await _unSubscribeBundlesRequestService.UnSubscribeService(new UnSubscribeBundlesRequest
                {
                    SubscriberId = msisdnDetails.SubscriberId,
                    SubscriberBundleId = (int) item
                });
            }
        }
        //If Any Addon Bundle Activated than Cancel



        await _uow.PaymentRepo.UpdateOrderHistoryStatus(new OrderStatusDetails()
        {
            OrderId = orderID,
            Status = refundPaymentSuccess ? (int) OrderStatus.CancelBundleRefunded : (int) OrderStatus.Success,
            ErrorCode = null!,
            ErrorMessage = null!,
            TransactionId = refundPaymentTransactionId!,
            Msisdn = null
        });
        #endregion
        return Result<RefundBundleResponse>.Success(new RefundBundleResponse { OrderId = orderID }, _localizer[CustomStatusKey.Success]);
    }
}
