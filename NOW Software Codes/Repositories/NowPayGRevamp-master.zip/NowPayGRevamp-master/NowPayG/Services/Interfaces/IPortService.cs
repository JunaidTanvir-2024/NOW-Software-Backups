﻿using System.Collections.Generic;
using System.Threading.Tasks;
using NowPayG.Models.Porting;

namespace NowPayG.Services.Interfaces
{
    public interface IPortService
    {
        Task<GenericPortingApiResponse<GetPortingRequestsResponseModel>> GetPortRequests(GetPortingDetailsRequestModel request);
        Task<GenericPortingApiResponse<bool>> PortOut(PortOutRequestModel request);
        Task<GenericPortingApiResponse<bool>> PortIn(PortInRequestModel request, PortTypes type);
        Task<GenericPortingApiResponse<bool>> CancelPortingRequest(CancelPortingRequestModel request);
        Task<GenericPortingApiResponse<SwitchingInformationApiResponseModel>> GetSwitchingInfo(GetSwitchingInformationRequestModel request);
    }
}
