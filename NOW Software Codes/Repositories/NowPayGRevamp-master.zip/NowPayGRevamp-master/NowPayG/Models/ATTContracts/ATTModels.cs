﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ATTContracts
{
    public class ATTModels
    {
        public class GetProductRequest
        {
            public string fromMSISDN { get; set; }
            public string account { get; set; }
            public string destinationMSISDN { get; set; }
            public string product { get; set; }
        }
        public class GetProductResponse
        {
            public string message { get; set; }
            public string status { get; set; }
            public int errorCodeDtOne { get; set; }
            public int errorCode { get; set; }
            public int servcieproviderid { get; set; }
            public PayLoad payload { get; set; }
        }

        public class PayLoad
        {
            public List<AttOperator> operators { get; set; }
        }

        public class AttOperator
        {
            public string id { get; set; }
            public string name { get; set; }
            public string country { get; set; }
            public string nowtelTransactionReference { get; set; }
            public string iconUri { get; set; }
            public List<AttProduct> products { get; set; }
            public int accessid { get; set; }
        }

        public class AttProduct
        {
            public string clientccy { get; set; }
            public string receiverccy { get; set; }
            public string product { get; set; }
            public string itemPriceClientccy { get; set; }
            public string transactionfeeClientccy { get; set; }
            public string totalPriceClientccy { get; set; }

        }

        public class ExecuteDataRequest
        {
            [Required]
            public string nowtelTransactionReference { get; set; }
            [Required]
            public string operatorid { get; set; }
            [Required]
            public string product { get; set; }
            [Required]
            public string messageToRecipient { get; set; }
            [Required]
            public string fromMSISDN { get; set; }
        }

        public class ExecuteDataResponse
        {
            public string errorCode { get; set; }
            public string errorCodeDtOne { get; set; }
            public string status { get; set; }
            public string message { get; set; }
            public string amount { get; set; }
            public string currency { get; set; }
            public string reference { get; set; }
        }
    }
}
