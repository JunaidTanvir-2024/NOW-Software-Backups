using Asp.Versioning;

using FH.Api.Controllers.Common;
using FH.UseCases.Operators;

using Microsoft.AspNetCore.Mvc;


namespace FH.Api.Controllers.V1;
[ApiVersion(1.0)]
public sealed class OperatorController : BaseApiController
{
	[HttpPost]
	public async Task<ActionResult> GetOperators([FromBody] GetOperators.Query request)
	{
		var result = await Mediator.Send(request);
		if (result.IsSuccess)
		{
			return Ok(result);
		}
		return NotFound(result);
	}



    [HttpPost("ByCategory")]
    public async Task<ActionResult> GetOperatorByCategory([FromBody] GetOperatorsByProductCategory.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }

    [HttpPost("BySubCategory")]
    public async Task<ActionResult> GetOperatorBySubCategory([FromBody] GetOperatorsBySubCategory.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}
