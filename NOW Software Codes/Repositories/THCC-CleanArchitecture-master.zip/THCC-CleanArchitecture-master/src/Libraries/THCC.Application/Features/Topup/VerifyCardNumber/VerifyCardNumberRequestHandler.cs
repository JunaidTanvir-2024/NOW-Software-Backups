﻿using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Topup.VerifyCardNumber
{
    public class VerifyCardNumberRequestHandler : IRequestHandler<VerifyCardNumberRequest, object>
    {
        private readonly ICallingCardRepository _callingCardRepository;

        public VerifyCardNumberRequestHandler(
            ICallingCardRepository callingCardRepository)
        {
            _callingCardRepository = callingCardRepository;
        }

        public async Task<object> Handle(
            VerifyCardNumberRequest request, CancellationToken cancellationToken)
        {
            request.CardNumber = request.CardNumber.Trim();
            if (await _callingCardRepository.GetCardInfo(request.CardNumber) == null)
            {
                return ErrorResult.Failure(
                    CustomStatusKey.InvalidCardNumnber, CustomStatusCode.BadRequest);
            }
            var response = new VerifyCardNumberResponse();
            var isRegistered = await _callingCardRepository.IsCardNumberRegistered(
                                                                    request.CardNumber);
            if (isRegistered)
            {
                response.IsRegistered = true;
                response.Message = CustomStatusKey.FastTopupCardNumberRegistered;
            }
            return response!;
        }
    }
}
