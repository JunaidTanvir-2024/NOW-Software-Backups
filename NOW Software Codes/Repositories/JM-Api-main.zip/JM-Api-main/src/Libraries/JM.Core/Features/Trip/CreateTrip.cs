using FluentValidation;

using JM.Core.Features.Traveler;
using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using Microsoft.AspNetCore.Http;

using RW;

namespace JM.Core.Features.Trip;

public abstract class CreateTrip
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public string Name { get; set; } = string.Empty;
		public AppEnum.CurrencyUnit CurrencyUnit { get; set; } = AppEnum.CurrencyUnit.Dollar;
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.Name).NotNull().NotEmpty();
		}
	}
	#endregion

	#region Response
	public sealed record Response
	{
		public long Id { get; set; }
		public required string Name { get; set; }
		public DateTime StartingDate { get; set; }
		public long CreatorId { get; set; }
		public required CurrencyInfo Currency { get; set; }
		public sealed record CurrencyInfo
		{
			public long Id { get; set; }
			public required string Name { get; set; }
			public required string Code { get; set; }
			public required string Symbol { get; set; }
		}
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork, IMediator mediator, IHttpContextAccessor contextAccessor) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		private readonly IMediator _mediator = mediator;
		private readonly IHttpContextAccessor _contextAccessor = contextAccessor;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{
			var userEmail = _contextAccessor.HttpContext?.User.GetEmail();

			if (string.IsNullOrEmpty(userEmail))
			{
				return ResultWrapper.Failure(AppConstant.StatusKey.Forbidden, AppConstant.StatusCode.Forbidden);
			}

			var user = await _unitOfWork.UserRepository.GetUser(x => x.NormalizedEmail!.Equals(userEmail!.ToUpperInvariant()));

			var newTrip = await _unitOfWork.TripRepository.AddTrip(new Entities.Trip()
			{
				Name = query.Name,
				StartingDate = DateTime.UtcNow,
				EndingDate = DateTime.UtcNow,
				CurrencyId = 1,
				IsActive = true,
				CreatorId = user!.Id
			});
			_unitOfWork.SaveChanges();

			await _mediator.Send(new CreateTraveler.Query()
			{
				UserId = newTrip.CreatorId,
				TripId = newTrip.Id,
			}, cancellationToken);
			_unitOfWork.SaveChanges();

			// await _unitOfWork.ChatRoomRepository.AddChatRoom(new Entities.PrivateChatRoom()
			// {
			//     IsPrivate = false,
			//     TripId = newTrip.Id,
			//     Name = newTrip.Name
			// });
			// _unitOfWork.SaveChanges();

			if (newTrip is not null)
			{
				return ResultWrapper.Success(new Response()
				{
					Id = newTrip.Id,
					Name = newTrip.Name,
					StartingDate = newTrip.StartingDate,
					CreatorId = newTrip.CreatorId,
					Currency = new Response.CurrencyInfo()
					{
						Id = newTrip.Currency.Id,
						Name = newTrip.Currency.Name,
						Code = newTrip.Currency.Code,
						Symbol = newTrip.Currency.Symbol,
					}
				});
			}
			return ResultWrapper.Failure(AppConstant.StatusKey.InternalServerError, AppConstant.StatusCode.InternalServerError);
		}
	}
	#endregion
}
