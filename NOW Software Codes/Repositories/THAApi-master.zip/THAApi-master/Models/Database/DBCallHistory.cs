﻿using System;

namespace Models.Database
{
    public class DBCallHistory
    {
        public string Destination { get; set; }
        public string Zone { get; set; }
        public string Duration { get; set; }
        public string TotalCharge { get; set; }
        public string Type { get; set; }
        public DateTime DateTime { get; set; }
    }
}
