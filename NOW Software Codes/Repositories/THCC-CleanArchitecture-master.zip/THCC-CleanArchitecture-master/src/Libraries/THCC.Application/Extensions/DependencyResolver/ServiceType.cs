namespace THCC.Application.Extensions.DependencyResolver;

public static class ServiceType
{
    public interface IScoped { }
    public interface ISingleton { }
    public interface ITransient { }
}