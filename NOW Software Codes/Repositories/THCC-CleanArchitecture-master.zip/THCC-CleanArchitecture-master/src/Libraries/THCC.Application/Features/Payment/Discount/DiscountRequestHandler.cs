﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.Payment.Discount
{
    public class DiscountRequestHandler : IRequestHandler<DiscountRequest, object>
    {
        private readonly IDiscountService _discountService;

        public DiscountRequestHandler(IDiscountService discountService)
        {
            _discountService = discountService;
        }

        Task<object> IRequestHandler<DiscountRequest, object>.Handle(
                                DiscountRequest request, CancellationToken cancellationToken)
        {
            return Task.FromResult<object>(new
            {
                discount = _discountService.GetDiscount(request.Amount)
            });
        }
    }
}
