﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TH.Models.Contracts.Response;
using TH.Models.Database;

namespace TH.Infrastructure.BLL
{
    public interface ITH_BL
    {
        Task<GenericApiResponse<Customer>> CustomerDetails(string msisdn);
        Task<GenericApiResponse<string>> SetPrimarySIMState(string msisdn, int state, string username);
        Task<GenericApiResponse<PurchaseResult>> Purchase(string msisdn, string bundleref, decimal amount, string transactionid);
        Task<GenericApiResponse<List<Plans>>> GetPlans();
        Task<GenericApiResponse<List<AccountPlans>>> GetAccountPlans(string msisdn);
        Task<GenericApiResponse<string>> TopupVoucher(string msisdn, string pin);
        Task<GenericApiResponse<List<TopupHistory>>> GetTopupHistory(string msisdn);
    }
}
