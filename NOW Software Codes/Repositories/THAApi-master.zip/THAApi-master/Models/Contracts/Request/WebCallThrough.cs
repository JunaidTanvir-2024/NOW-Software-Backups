﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
   
    public class WebCallThrough
    {
        public string destination { get; set; }
        public string via { get; set; }
        public bool IsIOS { get; set; }
        public bool IsAndroid { get; set; }
        public string IOSAllowedVersion { get; set; }
        public string AndroidAllowedVersion { get; set; }
    }
}
