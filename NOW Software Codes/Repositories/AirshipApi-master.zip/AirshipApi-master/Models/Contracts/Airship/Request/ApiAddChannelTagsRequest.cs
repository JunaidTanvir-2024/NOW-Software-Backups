﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Request
{
    
    public class ApiAddChannelTagsRequest
    {
        public ApiAddChannelTagsAudience audience { get; set; }
        public Dictionary<string, List<string>> add { get; set; }

    }
    public class ApiAddChannelTagsAudience
    {
        public string amazon_channel { get; set; }
        public bool ShouldSerializeamazon_channel()
        {
            // don't serialize the Telephone property if it is NULL or Empty
            if (deviceType == DeviceType.amazon)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public string android_channel { get; set; }
        public bool ShouldSerializeandroid_channel()
        {
            // don't serialize the Telephone property if it is NULL or Empty
            if (deviceType == DeviceType.android)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public string ios_channel { get; set; }
        public bool ShouldSerializeios_channel()
        {
            // don't serialize the Telephone property if it is NULL or Empty
            if (deviceType == DeviceType.ios)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public string channel { get; set; }
        public bool ShouldSerializechannel()
        {
            // don't serialize the Telephone property if it is NULL or Empty
            if (deviceType == DeviceType.email || deviceType == DeviceType.sms || deviceType == DeviceType.open || deviceType == DeviceType.web)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public DeviceType deviceType { get; set; }

        public bool ShouldSerializedeviceType()
        {
            return false;
        }
    }
}
