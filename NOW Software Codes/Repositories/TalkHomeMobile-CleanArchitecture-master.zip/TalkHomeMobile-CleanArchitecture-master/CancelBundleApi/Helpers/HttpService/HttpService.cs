using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using CancelBundleApi.Common;
using CancelBundleApi.Constants.Enums;
using CancelBundleApi.Repositories.Interfaces;
using CancelBundleApi.Models.HTTPModels;
using CancelBundleApi.Models.DbModels;

namespace CancelBundleApi.Helpers.HttpService;

public sealed partial class HttpService : IHttpService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IServiceLoggerRepository _loggerRepository;
    private string? _bearerToken;
    private string? _basicAuthUsername;
    private string? _basicAuthPassword;
    private bool _isLoggingEnabled;
    private readonly List<HttpServiceKeyValues> _headers;
    private readonly ILogger<HttpService> _logger;
    public HttpService(
        IHttpClientFactory httpClientFactory,
        IServiceLoggerRepository loggerRepository,
        ILogger<HttpService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _loggerRepository = loggerRepository;
        _headers = new List<HttpServiceKeyValues>();
        _logger = logger;
    }

    public IHttpService WithBearerAuth(string token)
    {
        _bearerToken = token;
        return this;
    }

    public IHttpService WithBasicAuth(string username, string password)
    {
        _basicAuthUsername = username;
        _basicAuthPassword = password;
        return this;
    }

    public IHttpService WithHeaders(IEnumerable<HttpServiceKeyValues> headers)
    {
        _headers.AddRange(headers);
        return this;
    }

    public IHttpService EnableLogging()
    {
        _isLoggingEnabled = true;
        return this;
    }

    #region HTTP Requests
    public async Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> GetAsync(string requestUri, object? data = default, string? correlationGuid = null)
    {
        var content = CreateJsonContent(data ?? string.Empty);
        return await SendRequestAsync(HttpMethod.Get, requestUri, content, correlationGuid);
    }
    public async Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> DeleteAsync(string requestUri, object? data = default, string? correlationGuid = null)
    {
        var content = CreateJsonContent(data ?? string.Empty);
        return await SendRequestAsync(HttpMethod.Delete, requestUri, content, correlationGuid);
    }
    public async Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> PostAsync(string requestUri, object? data = default)
    {
        var content = CreateJsonContent(data ?? string.Empty);
        return await SendRequestAsync(HttpMethod.Post, requestUri);
    }

    public async Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> PutAsync(string requestUri, object? data = default)
    {
        var content = CreateJsonContent(data ?? string.Empty);
        return await SendRequestAsync(HttpMethod.Put, requestUri);
    }


    #endregion

    private async Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> SendRequestAsync(HttpMethod method, string requestUri, HttpContent? content = null, string? correlationGuid = null)
    {
        var stopwatch = Stopwatch.StartNew();
        var client = _httpClientFactory.CreateClient();

        var request = new HttpRequestMessage(method, requestUri);

        if (_bearerToken != null)
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _bearerToken);
        }
        else if (_basicAuthUsername != null && _basicAuthPassword != null)
        {
            var authValue = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_basicAuthUsername}:{_basicAuthPassword}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authValue);
        }

        foreach (var header in _headers)
        {
            client.DefaultRequestHeaders.Add(header.Key, header.Value);
        }

        if (content != null)
        {
            request.Content = content;
        }

        var requestBody = request?.Content != null ? await request.Content.ReadAsStringAsync() : string.Empty;
        return await SendRequestAndSaveLog(client, request, requestBody, correlationGuid);
    }

    private async Task<(bool IsSuccessStatusCode, string ResponseBody, int HttpStatusCode)> SendRequestAndSaveLog(HttpClient client, HttpRequestMessage? request, string requestBody, string? correlationGuid = null)
    {
        long startTimeUnixTimeStamp = 0;
        long endTimeUnixTimestamp = 0;
        string responseBody = string.Empty;

        // Save log entry to the database
        try
        {
            startTimeUnixTimeStamp = TimeConverter.GetUnixTimeStamp();

            var result = await client.SendAsync(request!);

            endTimeUnixTimestamp = TimeConverter.GetUnixTimeStamp();

            responseBody = await result.Content.ReadAsStringAsync();
            var isSuccess = result.IsSuccessStatusCode;

            // Calculating response size
            var responseSize = Encoding.UTF8.GetByteCount(responseBody);

            await InsertLogs(request, requestBody, responseBody, startTimeUnixTimeStamp, endTimeUnixTimestamp, string.Empty, correlationGuid);

            return (isSuccess, responseBody, (int) result.StatusCode);
        }
        catch (Exception ex)
        {
            // Set the error message in the log entry
            endTimeUnixTimestamp = TimeConverter.GetUnixTimeStamp();
            // Response body and size will be zero as there is no response in case of error 
            string errorMessage = $"Message: " + ex.Message + ". \n" + ex.StackTrace?.ToString();
            await InsertLogs(request, requestBody, responseBody, startTimeUnixTimeStamp, endTimeUnixTimestamp, errorMessage, correlationGuid);

            _logger.LogError($"Message: {ex.Message}, " +
                $"Class: HttpService, " +
           $"Method: SendRequestAndSaveLog, " +
           $"Exception: {ex.StackTrace}");

            return (false, string.Empty, (int) HttpStatusCode.InternalServerError);
        }
    }

    private async Task InsertLogs(HttpRequestMessage? request, string? requestBody, string? responseBody, long startTimeUnixTimeStamp, long endTimeUnixTimestamp, string? stackTraceError, string? correlationGuid)
    {
        try
        {
            var lkpt_service = await _loggerRepository.GetServiceDetailsByName(BundleServiceEnum.BundleApiService.ToString());

            var auditLog = new ServiceApiAuditTrail
            {
                LkptServiceId = lkpt_service.LkptServiceId,
                ApiEndPoint = request != null && request.RequestUri != null ? request?.RequestUri?.ToString() : string.Empty,
                Error = stackTraceError,
                RequestData = requestBody,
                ResponseData = responseBody,
                IsViewable = false,
                StartTimeUnixTimeStamp = startTimeUnixTimeStamp,
                EndTimeUnixTimestamp = endTimeUnixTimestamp,
                TotalTimeMs = endTimeUnixTimestamp - startTimeUnixTimeStamp,
                HttpMethod = request != null && request.RequestUri != null ? request?.Method?.ToString() : null,
                ServiceCorrelationGuid = correlationGuid
            };
            await _loggerRepository.InsertServiceApiLog(auditLog);
        }
        catch (Exception ex)
        {
            _logger.LogError($"Message: {ex.Message}, " +
              $"Class: HttpService, " +
         $"Method: InsertLogs, " +
         $"Exception: {ex.StackTrace}");
        }
    }

    private static HttpContent CreateJsonContent(object data)
    {
        var json = JsonSerializer.Serialize(data);
        return new StringContent(json, Encoding.UTF8, "application/json");
    }

    public async Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> NoRequestDataFound(string requestUri, string noDataFound, object? data = null, string? correlationGuid = null)
    {
        var content = CreateJsonContent(data ?? string.Empty);
        var request = new HttpRequestMessage();

        //request.RequestUri = new Uri(requestUri);

        var requestBody = await content.ReadAsStringAsync();

        await InsertLogs(request, requestBody, noDataFound, 0, 0, string.Empty, correlationGuid);
        return (false, string.Empty, (int) HttpStatusCode.NotFound);
    }
}
