﻿using Infrastructure.BLL.Services.Interfaces;
using Models.Contracts.PaypalApiContracts;
using Models.Contracts.Response;
using Newtonsoft.Json;
using Serilog;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services
{
	public class PayPalPay360Service : IPayPalPay360Service
    {
        private readonly HttpClient _client;
        private readonly ILogger _logger;

        public PayPalPay360Service(HttpClient client, ILogger logger)
        {
            _client = client;
            _logger = logger;
        }
        public async Task<GenericPay360ApiResponse<PayPalByPay360CSPaymentResponse>> PayPalByPay360CS(PayPalByPay360CSPaymentRequest request)
        {
            string endpoint = "Paypal/Payment";
            string json = JsonConvert.SerializeObject(request);
            string result = await Post(endpoint, json);
            if (result == null)
            {
                return null;
            }
            return JsonConvert.DeserializeObject<GenericPay360ApiResponse<PayPalByPay360CSPaymentResponse>>(result);
        }
        public async Task<GenericPay360ApiResponse<PayPalByPay360ESPaymentResponse>> PayPalByPay360ES(PayPalByPay360ESPaymentRequest request)
        {
            string endpoint = "Paypal/Resume";
            string json = JsonConvert.SerializeObject(request);
            string result = await Post(endpoint, json);
            if (result == null)
            {
                return null;
            }
            return JsonConvert.DeserializeObject<GenericPay360ApiResponse<PayPalByPay360ESPaymentResponse>>(result);
        }
        public async Task<GenericPayPalApiResponse<PaypalRefundResponse>> PaypalRefund(RefundFullPaymentRequestModel request)
        {
            string endpoint = "Paypal/Refund";
            var json = JsonConvert.SerializeObject(request);
            var result = await Post(endpoint, json);
            if (result == null)
            {
                return null;
            }
            return JsonConvert.DeserializeObject<GenericPayPalApiResponse<PaypalRefundResponse>>(result);
        }
        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync(address, Content);
            if (!response.IsSuccessStatusCode)
            {
                //log errors here
                var responseString = await response.Content.ReadAsStringAsync();
                _logger.Error($"Service: PayPalService, Method: Post, Response: {responseString}-{response.StatusCode}");
                return null;
            }
            return await response.Content.ReadAsStringAsync();
        }
    }
}
