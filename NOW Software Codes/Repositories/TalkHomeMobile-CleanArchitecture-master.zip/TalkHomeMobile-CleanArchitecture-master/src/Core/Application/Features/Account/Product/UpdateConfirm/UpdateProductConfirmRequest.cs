﻿namespace Application.Features.Account.Product.UpdateConfirm;
public class UpdateProductConfirmRequest : IRequest<Result<object>>
{
    public int ProductId { get; set; }
    //public string Alias { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
    public int Otp { get; set; }
}
