﻿using System.ComponentModel;

namespace SC.Api.Model.CustomerOrder;
public record AddCustomerAddressModel
{
    [DefaultValue("")]
    public string AddressType { get; set; } = default!;
    [DefaultValue("")]
    public string StreetAddress1 { get; set; } = default!;
    [DefaultValue("")]
    public string StreetAddress2 { get; set; } = default!;
    [DefaultValue("")]
    public string City { get; set; } = default!;
    [DefaultValue("")]
    public string State { get; set; } = default!;
    [DefaultValue("")]
    public string PostalCode { get; set; } = default!;
    [DefaultValue("")]
    public string Country { get; set; } = default!;
    [DefaultValue("")]
    public string Email { get; set; } = default!;
    [DefaultValue("")]
    public string Phone { get; set; } = default!;
    public string Region { get; set; } = default!;
    public string CountryCode { get; set; } = default!;
}

