using System.Data;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.Extensions.Configuration;

using Npgsql;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;
internal class UnitOfWork(
	IConfiguration configuration,
	ILogger logger,
	ICountryRepository countryRepository,
	ILoggerRepository loggerRepository,
	IUserRepository userRepository,
	IOtpRepository otpRepository,
	ITripRepository tripRepository,
	ITravelerRepository travelerRepository,
	ISubscriptionRepository subscriptionRepository,
	IExpenseRepository expenseRepository,
	IMediaRepository mediaRepository,
	IPlaceRepository placeRepository,
	IFriendshipRepository friendshipRepository,
	IChatRoomRepository chatRoomRepository,
	AppDbContext context) : IUnitOfWork
{
	private IDbTransaction? _transaction;
	private readonly ILogger _logger = logger;
	private readonly IDbConnection _connection = new NpgsqlConnection(configuration.GetConnectionString(AppConstant.Database.JourneyMingle));
	private readonly Lazy<ICountryRepository> _countryRepository = new Lazy<ICountryRepository>(() => countryRepository);
	private readonly Lazy<ILoggerRepository> _appLoggerRepository = new Lazy<ILoggerRepository>(() => loggerRepository);
	private readonly Lazy<IUserRepository> _userRepository = new Lazy<IUserRepository>(() => userRepository);
	private readonly Lazy<IOtpRepository> _otpRepository = new Lazy<IOtpRepository>(() => otpRepository);
	private readonly Lazy<ITripRepository> _tripRepository = new Lazy<ITripRepository>(() => tripRepository);
	private readonly Lazy<ITravelerRepository> _travelerRepository = new Lazy<ITravelerRepository>(() => travelerRepository);
	private readonly Lazy<ISubscriptionRepository> _subscriptionRepository = new Lazy<ISubscriptionRepository>(() => subscriptionRepository);
	private readonly Lazy<IExpenseRepository> _expenseRepository = new Lazy<IExpenseRepository>(() => expenseRepository);
	private readonly Lazy<IMediaRepository> _mediaRepository = new Lazy<IMediaRepository>(() => mediaRepository);
	private readonly Lazy<IPlaceRepository> _placeRepository = new Lazy<IPlaceRepository>(() => placeRepository);
	private readonly Lazy<IFriendshipRepository> _friendshipRepository = new Lazy<IFriendshipRepository>(() => friendshipRepository);
	private readonly Lazy<IChatRoomRepository> _chatRoomRepository = new Lazy<IChatRoomRepository>(() => chatRoomRepository);

	private bool _disposed;
	private readonly AppDbContext _context = context;

	public ICountryRepository CountryRepository => _countryRepository.Value;
	public ILoggerRepository LoggerRepository => _appLoggerRepository.Value;
	public IUserRepository UserRepository => _userRepository.Value;
	public IOtpRepository OtpRepository => _otpRepository.Value;
	public ITripRepository TripRepository => _tripRepository.Value;
	public ITravelerRepository TravelerRepository => _travelerRepository.Value;
	public ISubscriptionRepository SubscriptionRepository => _subscriptionRepository.Value;
	public IExpenseRepository ExpenseRepository => _expenseRepository.Value;
	public IMediaRepository MediaRepository => _mediaRepository.Value;
	public IPlaceRepository PlaceRepository => _placeRepository.Value;
	public IFriendshipRepository FriendshipRepository => _friendshipRepository.Value;
	public IChatRoomRepository ChatRoomRepository => _chatRoomRepository.Value;

	public void BeginTransaction()
	{
		if (_transaction == null)
		{
			if (_connection.State == ConnectionState.Closed)
			{
				_connection.Open();
			}

			_transaction = _connection.BeginTransaction();
		}
		else
		{
			throw new InvalidOperationException("Transaction already started.");
		}
	}

	public void Commit()
	{
		try
		{
			_transaction?.Commit();
		}
		catch (Exception ex)
		{
			_logger.Error("Transaction commit failed: {Exception}", ex);
			Rollback();
			throw; // Re-throw the exception after rollback
		}
	}

	public void Rollback()
	{
		try
		{
			_transaction?.Rollback();
		}
		catch (Exception ex)
		{
			_logger.Error("Transaction rollback failed: {Exception}", ex);
			throw;
		}
	}

	public void SaveChanges()
	{
		try
		{
			_context.SaveChanges();
		}
		catch (Exception ex)
		{
			_logger.Error("SaveChanges failed: {Exception}", ex);
			Rollback();
			throw; // Re-throw the exception after rollback
		}
	}

	public void Dispose()
	{
		Dispose(true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing)
			{
				_transaction?.Dispose();
				_connection.Dispose();
			}
			_disposed = true;
		}
	}
}
