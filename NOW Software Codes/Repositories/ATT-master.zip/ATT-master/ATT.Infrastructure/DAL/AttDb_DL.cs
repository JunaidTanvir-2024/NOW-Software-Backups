﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using ATT.Models.Database;
using Serilog;
using ATT.Models.DbConnections;
using Microsoft.Extensions.Options;
using ATT.Models.Configurations;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Ding.Response;
using Newtonsoft.Json;
using ATT.Models.Contracts.Common;
using ServiceProvider = ATT.Models.Database.ServiceProvider;
using PhoneNumbers;
using ATT.Models.Contracts.TransferTo.Response;

namespace ATT.Infrastructure.DAL
{
    public class AttDb_DL : IAttDb_DL
    {

        private readonly ILogger _loggerAPIAccess;
        private IDbConnectionSettings AirtimeTransferConnection;
        private readonly ServiceProviderConfig ServiceProviderConfig;

        public AttDb_DL(ILogger logger, IOptions<ConnectionString> connectionString, IOptions<ServiceProviderConfig> _serviceProviderConfig)
        {
            _loggerAPIAccess = logger;
            AirtimeTransferConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
            ServiceProviderConfig = _serviceProviderConfig.Value;
        }
        public async Task<IEnumerable<DBCountriesWithOperatorNames>> GetTransferToCountriesWithOperatorNames(string continent = null)
        {
            try
            {
                var parameters = new DynamicParameters();
                var sp = "GetTransferToCountriesWithOperators";
                parameters.Add("@continent", continent);
                var result = await AirtimeTransferConnection.Connection.QueryAsync<DBCountriesWithOperatorNames>(sp, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   GetTransferToCountriesWithOperators   Message:{ex.ToString()}");
                return null;
            }
        }
        public async Task<IEnumerable<DBOperators>> GetTransferToOperators(string countryName)
        {
            try
            {
                var parameters = new DynamicParameters();
                var sp = "GetTransferToOperators";
                parameters.Add("@countryName", countryName);
                var result = await AirtimeTransferConnection.Connection.QueryAsync<DBOperators>(sp, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   GetTransferToCountriesWithOperators   Message:{ex.ToString()}");
                return null;
            }
        }
        public async Task<IEnumerable<DBOperators>> GetTransferToOperatorsByCountryId(string transferToCountryId)
        {
            try
            {
                var parameters = new DynamicParameters();
                var sp = "GetTransferToOperatorsByTransferToCountryID";
                parameters.Add("@transferToCountryId", transferToCountryId);
                var result = await AirtimeTransferConnection.Connection.QueryAsync<DBOperators>(sp, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   GetTransferToCountriesWithOperators   Message:{ex.ToString()}");
                return null;
            }
        }
        public async Task UpdateTransferToOperators(int transferToCountryID,List<OperatorsByCountry> operators)
        {
            try
            {
                var dataTable = new DataTable();
                dataTable.Columns.Add("serviceProviderOperatorID", typeof(int));
                dataTable.Columns.Add("name", typeof(string));
                dataTable.Columns.Add("iconUri", typeof(string));
                operators.ForEach(e =>
                {
                    dataTable.Rows.Add(e.OperatorId, e.OperatorName, e.OperatorImageUrl);
                });
                var parameters = new DynamicParameters();
                var sp = "at_UpdateTransferToOperatorsRange";
                parameters.Add("@transferToCountryID", transferToCountryID);
                parameters.Add("@operators", dataTable.AsTableValuedParameter());
                var result = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DBOperators>(sp, parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   UpdateTransferToOperators   Message:{ex.ToString()}");
            }
        }
        public async Task<DBOperators> GetTransferToOperatorDetails(string countryName,string operatorName)
        {
            try
            {
                var parameters = new DynamicParameters();
                var sp = "GetTransferToOperatorDetails";
                parameters.Add("@countryName", countryName);
                parameters.Add("@operatorName", operatorName);
                var result = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DBOperators>(sp, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   GetTransferToOperatorDetails   Message:{ex.ToString()}");
                return null;
            }
        }
        public async Task<DBResponse> insertTransactionGUID_Trh(string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId,
     string sourceMSisdn, string productItemCode, string countryCode = "", string operatorCode = "", string product = "", string operatorName = "", string operatorLogoUrl = "", string operatorCountryName = "", double? GetTokenApiTime = null, double? GetProviderApiTime = null, double? GetProductApiTime = null)
        {

            DBResponse result = new DBResponse();
            try
            {

                var parameters = new DynamicParameters();
                parameters.Add("@guid", guid);
                parameters.Add("@account", account);
                parameters.Add("@toMsisdn", toMsisdn);
                parameters.Add("@fromMsisdn", sourceMSisdn);
                parameters.Add("@productItemCode", productItemCode);
                parameters.Add("@productsJson", productsJson);
                parameters.Add("@requestJson", requestJson);
                parameters.Add("@responseJson", responseJson);
                parameters.Add("@serviceProviderId", serviceProviderId);
                parameters.Add("@countryCode", countryCode);     // Only for Ding API
                parameters.Add("@operatorCode", operatorCode); // Only for Ding API
                parameters.Add("@product", product);
                parameters.Add("@operatorName", operatorName);
                parameters.Add("@operatorLogoUrl", operatorLogoUrl);
                parameters.Add("@operatorCountryName", operatorCountryName);
                parameters.Add("@GetTokenApiTime", GetTokenApiTime);
                parameters.Add("@GetProviderApiTime", GetProviderApiTime);
                parameters.Add("@GetProductApiTime", GetProductApiTime);

                result = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DBResponse>("at_create_api_access_product_Trh_v1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   insertTransactionGUID   Message:{ex.ToString()}");
                result.DBStatus = 0;
                result.DBErrorMessage = ex.Message;
                result.InsertId = 0;
                return result;
            }
        }


        public async Task<DBResponse> insertTransactionGUID_Tha(string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId,
    string sourceMSisdn, string productItemCode, string countryCode = "", string operatorCode = "", string product = "", string operatorName = "", string operatorLogoUrl = "", string operatorCountryName = "", double? GetTokenApiTime = null, double? GetProviderApiTime = null, double? GetProductApiTime = null)
        {

            DBResponse result = new DBResponse();
            try
            {

                var parameters = new DynamicParameters();
                parameters.Add("@guid", guid);
                parameters.Add("@account", account);
                parameters.Add("@toMsisdn", toMsisdn);
                parameters.Add("@fromMsisdn", sourceMSisdn);
                parameters.Add("@productItemCode", productItemCode);
                parameters.Add("@productsJson", productsJson);
                parameters.Add("@requestJson", requestJson);
                parameters.Add("@responseJson", responseJson);
                parameters.Add("@serviceProviderId", serviceProviderId);
                parameters.Add("@countryCode", countryCode);     // Only for Ding API
                parameters.Add("@operatorCode", operatorCode); // Only for Ding API
                parameters.Add("@product", product);
                parameters.Add("@operatorName", operatorName);
                parameters.Add("@operatorLogoUrl", operatorLogoUrl);
                parameters.Add("@operatorCountryName", operatorCountryName);
                parameters.Add("@GetTokenApiTime", GetTokenApiTime);
                parameters.Add("@GetProviderApiTime", GetProviderApiTime);
                parameters.Add("@GetProductApiTime", GetProductApiTime);

                result = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DBResponse>("at_create_api_access_product_tha_v2", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   insertTransactionGUID   Message:{ex.ToString()}");
                result.DBStatus = 0;
                result.DBErrorMessage = ex.Message;
                result.InsertId = 0;
                return result;
            }
        }

        public async Task<DBResponse> insertTransactionGUID2(string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId,
            string sourceMSisdn, string countryCode = "", string operatorCode = "", string product = "")
        {

            DBResponse result = new DBResponse();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@guid", guid);
                parameters.Add("@account", account);
                parameters.Add("@toMsisdn", toMsisdn);
                parameters.Add("@fromMsisdn", sourceMSisdn);
                parameters.Add("@productsJson", productsJson);
                parameters.Add("@requestJson", requestJson);
                parameters.Add("@responseJson", responseJson);
                parameters.Add("@serviceProviderId", serviceProviderId);
                parameters.Add("@countryCode", countryCode);     // Only for Ding API
                parameters.Add("@operatorCode", operatorCode); // Only for Ding API
                parameters.Add("@product", product);


                result = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DBResponse>("at_create_api_access_product_v3", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   insertTransactionGUID   Message:{ex.ToString()}");
                result.DBStatus = 0;
                result.DBErrorMessage = ex.Message;
                result.InsertId = 0;
                return result;
            }
        }

        public async Task<DBResponse> insertTransactionGUID1(string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId,
            string sourceMSisdn, string countryCode = "", string operatorCode = "", double? GetProductApiTime = null, string productItemCode = null)
        {

            DBResponse result = new DBResponse();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@guid", guid);
                parameters.Add("@account", account);
                parameters.Add("@toMsisdn", toMsisdn);
                parameters.Add("@fromMsisdn", sourceMSisdn);
                parameters.Add("@productsJson", productsJson);
                parameters.Add("@requestJson", requestJson);
                parameters.Add("@responseJson", responseJson);
                parameters.Add("@serviceProviderId", serviceProviderId);
                parameters.Add("@countryCode", countryCode);     // Only for Ding API
                parameters.Add("@operatorCode", operatorCode);   // Only for Ding API
                parameters.Add("@GetProductApiTime", GetProductApiTime);
                parameters.Add("@@ProductItemCode", productItemCode);//if null then from db default THADTA will be added

                result = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DBResponse>("at_create_api_access_v4", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   insertTransactionGUID   Message:{ex.ToString()}");
                result.DBStatus = 0;
                result.DBErrorMessage = ex.Message;
                result.InsertId = 0;
                return result;
            }
        }



        // This method is used to insert GUID, ProductJson and other data neccessary for sending transfer request. Two extra parameters (CountryCode,  OperatorCode) added for DING API data saving
        public async Task<DBResponse> insertTransactionGUID(string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId, string countryCode = "", string operatorCode = "")
        {

            DBResponse result = new DBResponse();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@guid", guid);
                parameters.Add("@account", account);
                parameters.Add("@toMsisdn", toMsisdn);
                parameters.Add("@productsJson", productsJson);
                parameters.Add("@requestJson", requestJson);
                parameters.Add("@responseJson", responseJson);
                parameters.Add("@serviceProviderId", serviceProviderId);
                parameters.Add("@countryCode", countryCode);     // Only for Ding API
                parameters.Add("@operatorCode", operatorCode);   // Only for Ding API


                result = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DBResponse>("at_create_api_access_v12", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   insertTransactionGUID   Message:{ex.ToString()}");
                result.DBStatus = 0;
                result.DBErrorMessage = ex.Message;
                result.InsertId = 0;
                return result;
            }
        }

        public async Task<int> AddTransferToQueue(TransferToQueue data)
        {


            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@fromMSISDN", data.fromMSISDN);
                parameters.Add("@messageToRecipient", data.messageToRecipient);
                parameters.Add("@nowtelTransactionReference", data.nowtelTransactionReference);
                parameters.Add("@operatorid", data.operatorid);
                parameters.Add("@product", data.product);

                int result = await AirtimeTransferConnection.Connection.ExecuteAsync("at_AddTransferToQueue", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error:   AddTransferToQueue, ParametersJson: {JsonConvert.SerializeObject(data)}   ErrorMessage:{ex.ToString()}");
                return 0;
            }
        }

        async public Task<APIAccessGUID> getTransactionGUIDRecord(string guid, string product)
        {
            APIAccessGUID data = null;
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@guid", guid);
                parameters.Add("@product", product);

                data = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<APIAccessGUID>("at_getAPIAccessGUIDRecord", parameters, commandType: CommandType.StoredProcedure);


            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   getTransactionGUIDRecord    Message:{ex.ToString()}");
            }



            return data;
        }

        async public Task<APIAccessGUID> getTransactionGUIDRecord_v2(string guid, string product)
        {
            APIAccessGUID data = null;
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@guid", guid);
                parameters.Add("@product", product);

                data = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<APIAccessGUID>("at_getAPIAccessGUIDRecord_v2", parameters, commandType: CommandType.StoredProcedure);


            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   getTransactionGUIDRecord    Message:{ex.ToString()}");
            }



            return data;
        }

        async public Task<APIAccessGUID_Trh> getTransactionGUIDRecord_Trh(string guid, string product)
        {
            APIAccessGUID_Trh data = null;
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@guid", guid);
                parameters.Add("@product", product);

                data = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<APIAccessGUID_Trh>("at_getAPIAccessGUIDRecord_Trh2", parameters, commandType: CommandType.StoredProcedure);


            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   at_getAPIAccessGUIDRecord_Trh2    Message:{ex.ToString()}");
            }

            return data;
        }

        async public Task<CRM_ATT_APIAccessGUID> CRM_ATT_getTransactionGUIDRecord(string guid, string product)
        {
            CRM_ATT_APIAccessGUID data = null;
            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@guid", guid);
                parameters.Add("@product", product);

                data = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<CRM_ATT_APIAccessGUID>("crm_att_getAPIAccessGUIDRecord", parameters, commandType: CommandType.StoredProcedure);


            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   at_getAPIAccessGUIDRecord_Trh2    Message:{ex.ToString()}");
            }

            return data;
        }

        async public Task<OperatorMasterOperator> getOperatorMasterOperatorRecord(int ServiceProviderOperatorID)
        {
            OperatorMasterOperator data = null;

            try
            {

                var p = new DynamicParameters();


                p.Add("ServiceProviderOperatorID", ServiceProviderOperatorID, DbType.Int16);

                data = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<OperatorMasterOperator>("at_getOperatorMasterOperatorRecord", p, commandType: CommandType.StoredProcedure);


            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     getOperatorMasterOperatorRecord    Message:{ex.ToString()}");

            }

            return data;
        }



        async public Task<OperatorMasterOperator> getMasterServiceProviderRecord(int ServiceProviderID, int MasterOperatorID)
        {
            OperatorMasterOperator data = null;
            try
            {

                var p = new DynamicParameters();

                p.Add("ServiceProviderID", ServiceProviderID, DbType.Int16);
                p.Add("MasterOperatorID", MasterOperatorID, DbType.Int16);


                data = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<OperatorMasterOperator>("at_getMasterServiceProviderRecord", p, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error  getMasterServiceProviderRecord    Message:{ex.ToString()}");
            }

            return data;
        }


        public async Task<ServiceProvider> getServiceProviderRecord(int NS_id, string destination_msisdn)
        {
            ServiceProvider serviceProvider = null;
            try
            {

                var p = new DynamicParameters();

                p.Add("@NS_id", NS_id, DbType.Int16);
                p.Add("@destination_msisdn", destination_msisdn, DbType.String);


                serviceProvider = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<ServiceProvider>("at_getServiceProviderByNSID", p, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error  getServiceProviderRecord    Message:{ex.ToString()}");
            }

            return serviceProvider;
        }

        public async Task insertAirTimeTransferTransaction_Trh(
         string Date,
         string CurrencyAccountID,
         decimal Amount,
         decimal BuyAmount,
         decimal OperatorAmount,
         string Currency,
         string OperatorCurrency,
         string DestinationCountry,
         string Status,
         string ErrorMessage,
         string OperaterID,
         string ProductID,
         string OperatorName,
         string NowtelTranscationRefrence,
         string TransactionRefrence,
         string frommsisdn,
         string tomsisdn,
         int ServiceProviderID,
         string message_to_recipient,
         string productCode,
         string productItemCode,
         string accessRef,
            string json_request,
            string json_response,
            double? TopUpApiTime = null
         )
        {
            try
            {

                var p = new DynamicParameters();

                p.Add("@CurrencyAccountID", CurrencyAccountID, dbType: DbType.String);
                p.Add("Amount", Amount, dbType: DbType.Decimal);
                p.Add("@BuyAmount", BuyAmount, dbType: DbType.String);
                p.Add("@OperatorAmount", OperatorAmount, dbType: DbType.Double);
                p.Add("@Currency", Currency, dbType: DbType.String);
                p.Add("@OperatorCurrency", OperatorCurrency, dbType: DbType.String);
                p.Add("@DestinationCountry", DestinationCountry, dbType: DbType.String);
                p.Add("@Status", Status, dbType: DbType.String);
                p.Add("@ErrorMessage", ErrorMessage, dbType: DbType.String);
                p.Add("@OperaterID", OperaterID, dbType: DbType.String);
                p.Add("@ProductID", ProductID, dbType: DbType.String);
                p.Add("@OperatorName", OperatorName, dbType: DbType.String);
                p.Add("@NowtelTranscationRefrence", NowtelTranscationRefrence, dbType: DbType.String);
                p.Add("@TransactionRefrence", TransactionRefrence, dbType: DbType.String);
                p.Add("@frommsisdn", frommsisdn, dbType: DbType.String);
                p.Add("@tomsisdn", tomsisdn, dbType: DbType.String);
                p.Add("@ServiceProviderID", ServiceProviderID, dbType: DbType.String);
                p.Add("@message_to_recipient", message_to_recipient, dbType: DbType.String);
                p.Add("@productCode", productCode, dbType: DbType.String);
                p.Add("@productItemCode", productItemCode, dbType: DbType.String);
                p.Add("@accessGUID", accessRef, dbType: DbType.String);
                p.Add("@json_request", json_request, dbType: DbType.String);
                p.Add("@json_response", json_response, dbType: DbType.String);
                p.Add("@TopUpApiTime", TopUpApiTime, dbType: DbType.Double);

                await AirtimeTransferConnection.Connection.ExecuteAsync("at_createTransaction_Trh_v2", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     at_createTransaction    Message:{ex.ToString()}");
            }
        }

        public async Task insertAirTimeTransferTransaction_Trh_v3(
        string Date,
        string CurrencyAccountID,
        decimal Amount,
        decimal BuyAmount,
        decimal OperatorAmount,
        string Currency,
        string OperatorCurrency,
        string DestinationCountry,
        string Status,
        string ErrorMessage,
        string OperaterID,
        string ProductID,
        string OperatorName,
        string NowtelTranscationRefrence,
        string TransactionRefrence,
        string frommsisdn,
        string tomsisdn,
        int ServiceProviderID,
        string message_to_recipient,
        string productCode,
        string productItemCode,
        string accessRef,
         string json_request,
        string json_response,
         double? GetTokenApiTime = null, double? @TopUpApiTime = null
        )
        {
            try
            {

                var p = new DynamicParameters();

                p.Add("@CurrencyAccountID", CurrencyAccountID, dbType: DbType.String);
                p.Add("Amount", Amount, dbType: DbType.Decimal);
                p.Add("@BuyAmount", BuyAmount, dbType: DbType.String);
                p.Add("@OperatorAmount", OperatorAmount, dbType: DbType.Double);
                p.Add("@Currency", Currency, dbType: DbType.String);
                p.Add("@OperatorCurrency", OperatorCurrency, dbType: DbType.String);
                p.Add("@DestinationCountry", DestinationCountry, dbType: DbType.String);
                p.Add("@Status", Status, dbType: DbType.String);
                p.Add("@ErrorMessage", ErrorMessage, dbType: DbType.String);
                p.Add("@OperaterID", OperaterID, dbType: DbType.String);
                p.Add("@ProductID", ProductID, dbType: DbType.String);
                p.Add("@OperatorName", OperatorName, dbType: DbType.String);
                p.Add("@NowtelTranscationRefrence", NowtelTranscationRefrence, dbType: DbType.String);
                p.Add("@TransactionRefrence", TransactionRefrence, dbType: DbType.String);
                p.Add("@frommsisdn", frommsisdn, dbType: DbType.String);
                p.Add("@tomsisdn", tomsisdn, dbType: DbType.String);
                p.Add("@ServiceProviderID", ServiceProviderID, dbType: DbType.String);
                p.Add("@message_to_recipient", message_to_recipient, dbType: DbType.String);
                p.Add("@productCode", productCode, dbType: DbType.String);
                p.Add("@productItemCode", productItemCode, dbType: DbType.String);
                p.Add("@accessGUID", accessRef, dbType: DbType.String);
                p.Add("@json_request", json_request, dbType: DbType.String);
                p.Add("@json_response", json_response, dbType: DbType.String);
                p.Add("@GetTokenApiTime", GetTokenApiTime, dbType: DbType.Double);
                p.Add("@TopUpApiTime", TopUpApiTime, dbType: DbType.Double);

                await AirtimeTransferConnection.Connection.ExecuteAsync("at_createTransaction_Trh_v3", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     at_createTransaction    Message:{ex.ToString()}");
            }
        }
        public async Task insertAirTimeTransferTransaction_Trh_v4(
        string Date,
        string CurrencyAccountID,
        decimal Amount,
        decimal BuyAmount,
        decimal OperatorAmount,
        string Currency,
        string OperatorCurrency,
        string DestinationCountry,
        string Status,
        string ErrorMessage,
        string OperaterID,
        string ProductID,
        string OperatorName,
        string NowtelTranscationRefrence,
        string TransactionRefrence,
        string frommsisdn,
        string tomsisdn,
        int ServiceProviderID,
        string message_to_recipient,
        string productCode,
        string productItemCode,
        string accessRef,
         string json_request,
        string json_response,
        string discountPercentage,
            string orignalAmount
            , double? GetTokenApiTime = null, double? @TopUpApiTime = null
        )
        {
            try
            {

                var p = new DynamicParameters();

                p.Add("@CurrencyAccountID", CurrencyAccountID, dbType: DbType.String);
                p.Add("Amount", Amount, dbType: DbType.Decimal);
                p.Add("@BuyAmount", BuyAmount, dbType: DbType.String);
                p.Add("@OperatorAmount", OperatorAmount, dbType: DbType.Double);
                p.Add("@Currency", Currency, dbType: DbType.String);
                p.Add("@OperatorCurrency", OperatorCurrency, dbType: DbType.String);
                p.Add("@DestinationCountry", DestinationCountry, dbType: DbType.String);
                p.Add("@Status", Status, dbType: DbType.String);
                p.Add("@ErrorMessage", ErrorMessage, dbType: DbType.String);
                p.Add("@OperaterID", OperaterID, dbType: DbType.String);
                p.Add("@ProductID", ProductID, dbType: DbType.String);
                p.Add("@OperatorName", OperatorName, dbType: DbType.String);
                p.Add("@NowtelTranscationRefrence", NowtelTranscationRefrence, dbType: DbType.String);
                p.Add("@TransactionRefrence", TransactionRefrence, dbType: DbType.String);
                p.Add("@frommsisdn", frommsisdn, dbType: DbType.String);
                p.Add("@tomsisdn", tomsisdn, dbType: DbType.String);
                p.Add("@ServiceProviderID", ServiceProviderID, dbType: DbType.String);
                p.Add("@message_to_recipient", message_to_recipient, dbType: DbType.String);
                p.Add("@productCode", productCode, dbType: DbType.String);
                p.Add("@productItemCode", productItemCode, dbType: DbType.String);
                p.Add("@accessGUID", accessRef, dbType: DbType.String);
                p.Add("@json_request", json_request, dbType: DbType.String);
                p.Add("@json_response", json_response, dbType: DbType.String);
                p.Add("@GetTokenApiTime", GetTokenApiTime, dbType: DbType.Double);
                p.Add("@TopUpApiTime", TopUpApiTime, dbType: DbType.Double);
                p.Add("@orignalAmount", orignalAmount, dbType: DbType.String);
                p.Add("@discountPercentage", discountPercentage, dbType: DbType.String);

                await AirtimeTransferConnection.Connection.ExecuteAsync("at_createTransaction_Trh_v4", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     at_createTransaction_Trh_v4    Message:{ex.ToString()}");
            }
        }

        public async Task CRM_ATT_insertAirTimeTransferTransaction(
            string ProductId_rates,
    string Date,
    string CurrencyAccountID,
    decimal Amount,
    decimal BuyAmount,
    decimal OperatorAmount,
    string Currency,
    string OperatorCurrency,
    string DestinationCountry,
    string Status,
    string ErrorMessage,
    string OperaterID,
    string ProductID,
    string OperatorName,
    string NowtelTranscationRefrence,
    string TransactionRefrence,
    string frommsisdn,
    string tomsisdn,
    int ServiceProviderID,
    string message_to_recipient,
    string productCode,
    string productItemCode,
    string accessRef,
    string json_request,
    string json_response
    , double? GetTokenApiTime = null, double? @TopUpApiTime = null, string crmamount = null
    )
        {
            try
            {

                var p = new DynamicParameters();

                p.Add("@ProductId_rates", ProductId_rates, dbType: DbType.String);
                p.Add("@CurrencyAccountID", CurrencyAccountID, dbType: DbType.String);
                p.Add("Amount", Amount, dbType: DbType.Decimal);
                p.Add("@BuyAmount", BuyAmount, dbType: DbType.String);
                p.Add("@OperatorAmount", OperatorAmount, dbType: DbType.Double);
                p.Add("@Currency", Currency, dbType: DbType.String);
                p.Add("@OperatorCurrency", OperatorCurrency, dbType: DbType.String);
                p.Add("@DestinationCountry", DestinationCountry, dbType: DbType.String);
                p.Add("@Status", Status, dbType: DbType.String);
                p.Add("@ErrorMessage", ErrorMessage, dbType: DbType.String);
                p.Add("@OperaterID", OperaterID, dbType: DbType.String);
                p.Add("@ProductID", ProductID, dbType: DbType.String);
                p.Add("@OperatorName", OperatorName, dbType: DbType.String);
                p.Add("@NowtelTranscationRefrence", NowtelTranscationRefrence, dbType: DbType.String);
                p.Add("@TransactionRefrence", TransactionRefrence, dbType: DbType.String);
                p.Add("@frommsisdn", frommsisdn, dbType: DbType.String);
                p.Add("@tomsisdn", tomsisdn, dbType: DbType.String);
                p.Add("@ServiceProviderID", ServiceProviderID, dbType: DbType.String);
                p.Add("@message_to_recipient", message_to_recipient, dbType: DbType.String);
                p.Add("@productCode", productCode, dbType: DbType.String);
                p.Add("@productItemCode", productItemCode, dbType: DbType.String);
                p.Add("@accessGUID", accessRef, dbType: DbType.String);
                p.Add("@json_request", json_request, dbType: DbType.String);
                p.Add("@json_response", json_response, dbType: DbType.String);
                p.Add("@GetTokenApiTime", GetTokenApiTime, dbType: DbType.Double);
                p.Add("@TopUpApiTime", TopUpApiTime, dbType: DbType.Double);
                p.Add("@crmamount", crmamount, dbType: DbType.Double);


                await AirtimeTransferConnection.Connection.ExecuteAsync("[CRM_ATT_createTransaction]", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     CRM_ATT_insertAirTimeTransferTransaction    Message:{ex.ToString()}");
            }
        }
        public async Task insertAirTimeTransferTransaction_Trh(
         string Date,
         string CurrencyAccountID,
         decimal Amount,
         decimal BuyAmount,
         decimal OperatorAmount,
         string Currency,
         string OperatorCurrency,
         string DestinationCountry,
         string Status,
         string ErrorMessage,
         string OperaterID,
         string ProductID,
         string OperatorName,
         string NowtelTranscationRefrence,
         string TransactionRefrence,
         string frommsisdn,
         string tomsisdn,
         int ServiceProviderID,
         string message_to_recipient,
         string productCode,
         string productItemCode
         )
        {
            try
            {

                var p = new DynamicParameters();

                p.Add("@CurrencyAccountID", CurrencyAccountID, dbType: DbType.String);
                p.Add("Amount", Amount, dbType: DbType.Decimal);
                p.Add("@BuyAmount", BuyAmount, dbType: DbType.String);
                p.Add("@OperatorAmount", OperatorAmount, dbType: DbType.Double);
                p.Add("@Currency", Currency, dbType: DbType.String);
                p.Add("@OperatorCurrency", OperatorCurrency, dbType: DbType.String);
                p.Add("@DestinationCountry", DestinationCountry, dbType: DbType.String);
                p.Add("@Status", Status, dbType: DbType.String);
                p.Add("@ErrorMessage", ErrorMessage, dbType: DbType.String);
                p.Add("@OperaterID", OperaterID, dbType: DbType.String);
                p.Add("@ProductID", ProductID, dbType: DbType.String);
                p.Add("@OperatorName", OperatorName, dbType: DbType.String);
                p.Add("@NowtelTranscationRefrence", NowtelTranscationRefrence, dbType: DbType.String);
                p.Add("@TransactionRefrence", TransactionRefrence, dbType: DbType.String);
                p.Add("@frommsisdn", frommsisdn, dbType: DbType.String);
                p.Add("@tomsisdn", tomsisdn, dbType: DbType.String);
                p.Add("@ServiceProviderID", ServiceProviderID, dbType: DbType.String);
                p.Add("@message_to_recipient", message_to_recipient, dbType: DbType.String);
                p.Add("@productCode", productCode, dbType: DbType.String);
                p.Add("@productItemCode", productItemCode, dbType: DbType.String);

                await AirtimeTransferConnection.Connection.ExecuteAsync("at_createTransaction_Trh", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     at_createTransaction    Message:{ex.ToString()}");
            }
        }

        async public Task insertAirTimeTransferTransaction(
            string Date,
            string CurrencyAccountID,
            decimal Amount,
            decimal BuyAmount,
            decimal OperatorAmount,
            string Currency,
            string OperatorCurrency,
            string DestinationCountry,
            string Status,
            string ErrorMessage,
            string OperaterID,
            string ProductID,
            string OperatorName,
            string NowtelTranscationRefrence,
            string TransactionRefrence,
            string frommsisdn,
            string tomsisdn,
            int ServiceProviderID,
            string message_to_recipient)
        {
            try
            {

                var p = new DynamicParameters();

                p.Add("@CurrencyAccountID", CurrencyAccountID, dbType: DbType.String);
                p.Add("Amount", Amount, dbType: DbType.Decimal);
                p.Add("@BuyAmount", BuyAmount, dbType: DbType.String);
                p.Add("@OperatorAmount", OperatorAmount, dbType: DbType.Double);
                p.Add("@Currency", Currency, dbType: DbType.String);
                p.Add("@OperatorCurrency", OperatorCurrency, dbType: DbType.String);
                p.Add("@DestinationCountry", DestinationCountry, dbType: DbType.String);
                p.Add("@Status", Status, dbType: DbType.String);
                p.Add("@ErrorMessage", ErrorMessage, dbType: DbType.String);
                p.Add("@OperaterID", OperaterID, dbType: DbType.String);
                p.Add("@ProductID", ProductID, dbType: DbType.String);
                p.Add("@OperatorName", OperatorName, dbType: DbType.String);
                p.Add("@NowtelTranscationRefrence", NowtelTranscationRefrence, dbType: DbType.String);
                p.Add("@TransactionRefrence", TransactionRefrence, dbType: DbType.String);
                p.Add("@frommsisdn", frommsisdn, dbType: DbType.String);
                p.Add("@tomsisdn", tomsisdn, dbType: DbType.String);
                p.Add("@ServiceProviderID", ServiceProviderID, dbType: DbType.String);
                p.Add("@message_to_recipient", message_to_recipient, dbType: DbType.String);

                await AirtimeTransferConnection.Connection.ExecuteAsync("at_createTransaction", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     at_createTransaction    Message:{ex.ToString()}");
            }
        }

        async public Task insertAirTimeTransferTransaction(
            string Date,
            string CurrencyAccountID,
            decimal Amount,
            decimal BuyAmount,
            decimal OperatorAmount,
            string Currency,
            string OperatorCurrency,
            string DestinationCountry,
            string Status,
            string ErrorMessage,
            string OperaterID,
            string ProductID,
            string OperatorName,
            string NowtelTranscationRefrence,
            string TransactionRefrence,
            string frommsisdn,
            string tomsisdn,
            int ServiceProviderID,
            string message_to_recipient,
            string accessRef,
            string json_request,
            string json_response
            , string productCode
            , string productItemCode
             , string discountPercentage
            , string orignalAmount
            , double? TopUpApiTime = null
            )
        {
            try
            {

                var p = new DynamicParameters();

                p.Add("@CurrencyAccountID", CurrencyAccountID, dbType: DbType.String);
                p.Add("Amount", Amount, dbType: DbType.Decimal);
                p.Add("@BuyAmount", BuyAmount, dbType: DbType.String);
                p.Add("@OperatorAmount", OperatorAmount, dbType: DbType.Double);
                p.Add("@Currency", Currency, dbType: DbType.String);
                p.Add("@OperatorCurrency", OperatorCurrency, dbType: DbType.String);
                p.Add("@DestinationCountry", DestinationCountry, dbType: DbType.String);
                p.Add("@Status", Status, dbType: DbType.String);
                p.Add("@ErrorMessage", ErrorMessage, dbType: DbType.String);
                p.Add("@OperaterID", OperaterID, dbType: DbType.String);
                p.Add("@ProductID", ProductID, dbType: DbType.String);
                p.Add("@OperatorName", OperatorName, dbType: DbType.String);
                p.Add("@NowtelTranscationRefrence", NowtelTranscationRefrence, dbType: DbType.String);
                p.Add("@TransactionRefrence", TransactionRefrence, dbType: DbType.String);
                p.Add("@frommsisdn", frommsisdn, dbType: DbType.String);
                p.Add("@tomsisdn", tomsisdn, dbType: DbType.String);
                p.Add("@ServiceProviderID", ServiceProviderID, dbType: DbType.String);
                p.Add("@message_to_recipient", message_to_recipient, dbType: DbType.String);
                p.Add("@accessGUID", accessRef, dbType: DbType.String);
                p.Add("@json_request", json_request, dbType: DbType.String);
                p.Add("@json_response", json_response, dbType: DbType.String);
                p.Add("@productCode", productCode, dbType: DbType.String);
                p.Add("@productItemCode", productItemCode, dbType: DbType.String);
                p.Add("@discountPercentage", discountPercentage, dbType: DbType.String);
                p.Add("@orignalAmount", orignalAmount, dbType: DbType.String);
                p.Add("@TopUpApiTime", TopUpApiTime, dbType: DbType.Double);

                await AirtimeTransferConnection.Connection.ExecuteAsync("at_createTransaction_v4", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     at_createTransaction_v4    Message:{ex.ToString()}");
            }
        }


        async public Task updateProductsJSONOfGUID(string GUID, string productsJSON)
        {
            try
            {

                var p = new DynamicParameters();

                p.Add("GUID", GUID, DbType.String);
                p.Add("productsJSON", productsJSON, DbType.String);

                await AirtimeTransferConnection.Connection.ExecuteAsync("at_updateJSONGUID", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   updateProductsJSONOfGUID   Message:{ex.ToString()}");
            }
        }


        public AttProduct GetProduct(string account, string receiverccy, string product, string itemPriceClientccy, string totalPriceClientccy)
        {
            AttProduct attProduct = new AttProduct();
            attProduct.clientccy = account;
            attProduct.receiverccy = receiverccy;
            attProduct.product = product;
            attProduct.itemPriceClientccy = itemPriceClientccy;
            attProduct.transactionfeeClientccy = "0.00";
            attProduct.totalPriceClientccy = totalPriceClientccy;
            return attProduct;
        }



        public async Task<IList<SochitelCustomerRate>> GetEndRates(int serviceProviderOperaorId, string account, int serviceProviderId, int originDestinationId)
        {
            try
            {

                var parameters = new DynamicParameters();

                // parameters.Add("@serviceproviderId", ServiceProviderID);
                parameters.Add("@serviceProviderOperatorID", serviceProviderOperaorId);
                parameters.Add("@clientccy", account);
                parameters.Add("@originDestinationId", originDestinationId);
                parameters.Add("@serviceProviderId", serviceProviderId);
                var result = await AirtimeTransferConnection.Connection.QueryAsync<SochitelCustomerRate>("at_sochitel_get_display_rates", parameters, commandType: CommandType.StoredProcedure);

                return result.ToList<SochitelCustomerRate>();

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     GetEndRates    Message:{ex.ToString()}");

            }


            return null;
        }

        public async Task<int> insertaccessDetails(int accessid,
           string clientccy,
           string receiverccy,
           string product,
           string itemPriceClientccy,
           string totalPriceClientccy,
           int productId, string skuCode = null, string uatNumber = null)
        {

            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@accessid", accessid);
                parameters.Add("@clientccy", clientccy);
                parameters.Add("@receiverccy", receiverccy);
                parameters.Add("@product", product);
                parameters.Add("@itemPriceClientccy", itemPriceClientccy);
                parameters.Add("@totalPriceClientccy", totalPriceClientccy);
                parameters.Add("@productId", productId);
                parameters.Add("@skuCode", skuCode);
                parameters.Add("@uatNumber", uatNumber);
                await AirtimeTransferConnection.Connection.ExecuteAsync("at_create_api_access_detail_v2", parameters, commandType: CommandType.StoredProcedure);

                return 1;

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     insertTransactionGUID    Message:{ex.ToString()}");

            }


            return 0;

        }


        public async Task<int> insertaccessDetails(int accessid,
     string clientccy,
     string receiverccy,
     string product,
     string itemPriceClientccy,
     string totalPriceClientccy,
     string totalSellingPriceClientccy,
     int productId, string skuCode = null, string uatNumber = null, string crmamount = null)
        {

            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@accessid", accessid);
                parameters.Add("@clientccy", clientccy);
                parameters.Add("@receiverccy", receiverccy);
                parameters.Add("@product", product);
                parameters.Add("@itemPriceClientccy", itemPriceClientccy);
                parameters.Add("@totalPriceClientccy", totalPriceClientccy);
                parameters.Add("@totalSellingPriceClientccy", totalSellingPriceClientccy);
                parameters.Add("@productId", productId);
                parameters.Add("@skuCode", skuCode);
                parameters.Add("@uatNumber", uatNumber);
                parameters.Add("@crmamount", crmamount);
                await AirtimeTransferConnection.Connection.ExecuteAsync("at_create_api_access_detail_v4", parameters, commandType: CommandType.StoredProcedure);

                return 1;

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     insertTransactionGUID    Message:{ex.ToString()}");

            }


            return 0;

        }

        public async Task<int> insertaccessDetailsWithDiscount(int accessid,
     string clientccy,
     string receiverccy,
     string product,
     string itemPriceClientccy,
     string totalPriceClientccy,
     string totalSellingPriceClientccy,
     int productId, string skuCode = null, string uatNumber = null, string crmamount = null, decimal? discountPercentage = null, string orignalAmount = null)
        {

            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@accessid", accessid);
                parameters.Add("@clientccy", clientccy);
                parameters.Add("@receiverccy", receiverccy);
                parameters.Add("@product", product);
                parameters.Add("@itemPriceClientccy", itemPriceClientccy);
                parameters.Add("@totalPriceClientccy", totalPriceClientccy);
                parameters.Add("@totalSellingPriceClientccy", totalSellingPriceClientccy);
                parameters.Add("@productId", productId);
                parameters.Add("@skuCode", skuCode);
                parameters.Add("@uatNumber", uatNumber);
                parameters.Add("@crmamount", crmamount);
                parameters.Add("@discountPercentage", discountPercentage);
                parameters.Add("@orignalAmount", orignalAmount);
                await AirtimeTransferConnection.Connection.ExecuteAsync("at_create_api_access_detail_v6", parameters, commandType: CommandType.StoredProcedure);

                return 1;

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error     insertaccessDetailsWithDiscount    Message:{ex.ToString()}");

            }


            return 0;

        }
        public DingProduct GetDingProduct(string account, string receiverccy, string productExcludingTax, string product, string itemPriceClientccy, string totalPriceClientccy, string dingSkuCode)
        {
            DingProduct productDetails = new DingProduct();
            productDetails.clientccy = account;
            productDetails.receiverccy = receiverccy;
            productDetails.productExcludingTax = productExcludingTax;
            productDetails.product = product;
            productDetails.itemPriceClientccy = itemPriceClientccy;
            productDetails.transactionfeeClientccy = "0.00";
            productDetails.totalPriceClientccy = totalPriceClientccy;
            productDetails.dingSkuCode = dingSkuCode;
            return productDetails;
        }


        async public Task<int> GetTransferToCountryIdByCallingCode(int callingCode)
        {
            int data = -1;

            try
            {

                var p = new DynamicParameters();
                p.Add("callingCode", callingCode);

                data = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<int>("at_getCountryByCallingCode", p, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error:      GetTransferToCountryIdByCallingCode({callingCode}, ),    Message:{ex.ToString()}");
                //throw ex;
            }

            return data;
        }


        public async Task<bool> CheckFraudUser(string productCode, string toMsisdn, string fromMsisdn)
        {

            try
            {

                var parameters = new DynamicParameters();

                parameters.Add("@productCode", productCode);
                parameters.Add("@tomsisdn", toMsisdn);
                parameters.Add("@frommsisdn", fromMsisdn);
                parameters.Add("@isPermitted", null, DbType.Boolean, ParameterDirection.Output);
                parameters.Add("@errorCode", null, DbType.Int32, ParameterDirection.Output);


                await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<bool>("at_check_fraud_v2", parameters, commandType: CommandType.StoredProcedure);
                bool isPermitted = parameters.Get<bool>("@isPermitted");
                int errorCode = parameters.Get<int>("@errorCode");
                return isPermitted;

            }
            catch (Exception ex)
            {
                throw;
            }


        }


        public async Task<ATT_ValidateCustomer> ValidateNowtelCustomer(
           string frommsisdn, string tomsisdn, string nowtelreference, string product, decimal amount, string product_code, string product_item_code)
        {
            ATT_ValidateCustomer avc = new ATT_ValidateCustomer();
            var storedProcedure = "at_validate_customer_v4";

            var parameters = new DynamicParameters();

            parameters.Add("@frommsisdn", frommsisdn);
            parameters.Add("@tomsisdn", tomsisdn);
            parameters.Add("@nowtelreference", nowtelreference);
            parameters.Add("@amount", amount);
            parameters.Add("@product", product);
            parameters.Add("@product_code", product_code);
            parameters.Add("@product_item_code", product_item_code);
            parameters.Add("@error_msg", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
            parameters.Add("@isAllowed", dbType: DbType.Int32, direction: ParameterDirection.Output);

            try
            {
                var response = await
                 AirtimeTransferConnection.Connection.ExecuteAsync(storedProcedure, parameters,
                    commandType: CommandType.StoredProcedure);

                if (parameters.Get<string>("@error_msg") != null)
                {

                    avc.isAllowed = parameters.Get<Int32>("@isAllowed");
                    avc.Message = parameters.Get<string>("@error_msg");
                }

                return avc;

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Warning("Airtime Transfer Exception :" + ex.ToString());


            }


            return null;
        }


        public async Task<DestinationServiceProvider> GetFreeSwitchServiceProvider(string destination_msisdn)
        {
            DestinationServiceProvider serviceProvider = null;
            try
            {

                var p = new DynamicParameters();
                p.Add("@destination_msisdn", destination_msisdn, DbType.String);
                serviceProvider = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DestinationServiceProvider>("Fs_GetDestinationServiceProvider_v3", p, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttDb_DL, Method: GetFreeSwitchServiceProvider, Parameters => destination_msisdn: {destination_msisdn}, ErrorMessage:{ex.Message}");
            }

            return serviceProvider;
        }

        public async Task<int> UpdateFreeSwitchServiceProvider(int Id, int ServiceProviderTranCount_Current, int SecondServiceProviderTranCount_Current)
        {

            try
            {

                var p = new DynamicParameters();
                p.Add("@Id", Id);
                p.Add("@ServiceProviderTranCount_Current", ServiceProviderTranCount_Current);
                p.Add("@SecondServiceProviderTranCount_Current", SecondServiceProviderTranCount_Current);

                int result = await AirtimeTransferConnection.Connection.ExecuteAsync("Fs_UpdateDestinationServiceProvider", p, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttDb_DL, Method: UpdateFreeSwitchServiceProvider, Parameters => Id: {Id}, ServiceProviderTranCount_Current: {ServiceProviderTranCount_Current}, SecondServiceProviderTranCount_Current: {SecondServiceProviderTranCount_Current},  ErrorMessage:{ex.Message}");
                return 0;
            }

        }


        public async Task<int> CRM_ATT_UpdateServiceProvider(int Id, int ServiceProviderTranCount_Current, int SecondServiceProviderTranCount_Current)
        {

            try
            {

                var p = new DynamicParameters();
                p.Add("@Id", Id);
                p.Add("@ServiceProviderTranCount_Current", ServiceProviderTranCount_Current);
                p.Add("@SecondServiceProviderTranCount_Current", SecondServiceProviderTranCount_Current);

                int result = await AirtimeTransferConnection.Connection.ExecuteAsync("CRM_ATT_UpdateDestinationServiceProvider", p, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttDb_DL, Method: CRM_ATT_UpdateServiceProvider, Parameters => Id: {Id}, ServiceProviderTranCount_Current: {ServiceProviderTranCount_Current}, SecondServiceProviderTranCount_Current: {SecondServiceProviderTranCount_Current},  ErrorMessage:{ex.Message}");
                return 0;
            }

        }

        public async Task<THADestinationServiceProvider> GetTHAServiceProvider(string destination_msisdn, string source_msisdn, string productCode, string productItemCode)
        {
            THADestinationServiceProvider serviceProvider = null;
            try
            {
                bool checkProductItemCode = false;
                if (ServiceProviderConfig.THACheckProductItemCode && productCode.ToUpper().Equals("THA"))
                {
                    checkProductItemCode = true;
                }
                else if (ServiceProviderConfig.TRHCheckProductItemCode && productCode.ToUpper().Equals("TRH"))
                {
                    checkProductItemCode = true;
                }

                var p = new DynamicParameters();
                p.Add("@from_MSISDN", source_msisdn, DbType.String);
                p.Add("@to_MSISDN", destination_msisdn, DbType.String);
                p.Add("@ProductCode", productCode);
                p.Add("@ProductItemCode", productItemCode);
                p.Add("@checkProductItemCode", checkProductItemCode);
                serviceProvider = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<THADestinationServiceProvider>("at_get_destination_operator_service_provider_v3", p, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttBb_DL, Method: GetTHAServiceProvider,  ErrorMessage:{ex.ToString()}");
            }

            return serviceProvider;
        }

        public async Task<List<THADestinationDingProvider>> THAGetDingDestinationsOperators(string source_msisdn)
        {
            IEnumerable<THADestinationDingProvider> lServiceProvider = null;
            try
            {

                var p = new DynamicParameters();
                p.Add("@from_MSISDN", source_msisdn, DbType.String);
                p.Add("@ProductCode", "THA");
                p.Add("@ProductItemCode", "THADTA");
                lServiceProvider = await AirtimeTransferConnection.Connection.QueryAsync<THADestinationDingProvider>("at_get_ding_destinations_operators_v2", p, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttBb_DL, Method: THAGetDingDestinationsOperators,  ErrorMessage:{ex.ToString()}");
            }

            return lServiceProvider.ToList();
        }

        public async Task<CustomerChargeValueForReplacement> GetCustomerChargeValueForReplacement(string destinationMsisdn, string productItemCode)
        {
            CustomerChargeValueForReplacement serviceProvider = null;
            try
            {

                var p = new DynamicParameters();
                p.Add("@destinationMsisdn", destinationMsisdn);
                p.Add("@productItemCode", productItemCode);
                serviceProvider = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<CustomerChargeValueForReplacement>("Fs_GetCustomerChargeValueForReplacement", p, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttBb_DL, Method: GetCustomerChargeValueForReplacement, Parameters => destinationMsisdn: {destinationMsisdn}, productItemCode: {productItemCode},  ErrorMessage:{ex.ToString()}");
            }

            return serviceProvider;
        }

        public async Task<THACustomerChargeValuesForReplacement> GetTHACustomerChargeValuesForReplacement(int cdsp_config_id, string operator_code, int servcieproviderid, int from_country_code)
        {
            THACustomerChargeValuesForReplacement destPriceDetails = new THACustomerChargeValuesForReplacement();
            try
            {

                var p = new DynamicParameters();
                p.Add("@cdsp_config_id", cdsp_config_id);
                p.Add("@ding_operator_code", operator_code);
                p.Add("@service_provider_id", servcieproviderid);
                p.Add("@from_country_code", from_country_code);
                p.Add("@ProductCode", "THA");
                p.Add("@ProductItemCode", "THADTA");
                var chargeValues = await AirtimeTransferConnection.Connection.QueryAsync<THACustomerChargeValueForReplacement>("at_get_destination_operator_price_details_v3", p, commandType: CommandType.StoredProcedure);
                if (chargeValues != null)
                {
                    destPriceDetails.chargeValues = chargeValues.ToList();
                }

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttBb_DL, Method: GetTHACustomerChargeValuesForReplacement, Parameters => cdsp_config_id: {cdsp_config_id},  ErrorMessage:{ex.ToString()}");
            }

            return destPriceDetails;
        }

        public async Task<THACustomerChargeValuesForReplacement> GetTHAMobiquityCustomerChargeValuesForReplacement(int cdsp_config_id, int servcieproviderid, int from_country_code, string operator_name)
        {
            THACustomerChargeValuesForReplacement destPriceDetails = new THACustomerChargeValuesForReplacement();
            try
            {

                var p = new DynamicParameters();
                p.Add("@cdsp_config_id", cdsp_config_id);
                p.Add("@service_provider_id", servcieproviderid);
                p.Add("@operator_name", operator_name);
                p.Add("@from_country_code", from_country_code);
                p.Add("@ProductCode", "THA");
                p.Add("@ProductItemCode", "THADTA");
                var chargeValues = await AirtimeTransferConnection.Connection.QueryAsync<THACustomerChargeValueForReplacement>("at_get_destination_operator_price_details_mobiquity", p, commandType: CommandType.StoredProcedure);
                if (chargeValues != null)
                {
                    destPriceDetails.chargeValues = chargeValues.ToList();
                }

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttBb_DL, Method: GetTHACustomerChargeValuesForReplacement, Parameters => cdsp_config_id: {cdsp_config_id},  ErrorMessage:{ex.ToString()}");
            }

            return destPriceDetails;
        }
        public async Task<THACustomerChargeValuesForReplacement> GetReloadlyTHACustomerChargeValuesForReplacement(int cdsp_config_id, string reloadly_operator_id, int servcieproviderid, int from_country_code, string reloadly_operator_name)
        {
            THACustomerChargeValuesForReplacement destPriceDetails = new THACustomerChargeValuesForReplacement();
            try
            {

                var p = new DynamicParameters();
                p.Add("@cdsp_config_id", cdsp_config_id);
                p.Add("@reloadly_operator_id", reloadly_operator_id);
                p.Add("@reloadly_operator_name", reloadly_operator_name);
                p.Add("@service_provider_id", servcieproviderid);
                p.Add("@from_country_code", from_country_code);
                p.Add("@ProductCode", "THA");
                p.Add("@ProductItemCode", "THADTA");
                var chargeValues = await AirtimeTransferConnection.Connection.QueryAsync<THACustomerChargeValueForReplacement>("at_get_destination_operator_price_details_reloadly", p, commandType: CommandType.StoredProcedure);
                if (chargeValues != null)
                {
                    destPriceDetails.chargeValues = chargeValues.ToList();
                }

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttBb_DL, Method: GetReloadlyTHACustomerChargeValuesForReplacement, Parameters => cdsp_config_id: {cdsp_config_id}, reloadly_operator_id: {reloadly_operator_id},  ErrorMessage:{ex.Message}");
            }

            return destPriceDetails;
        }
        public async Task<ServicePRoviderThreshhold> Com_ATT_GetServiceProvidersThreshhold(int servcieproviderid)
        {
            ServicePRoviderThreshhold th = new ServicePRoviderThreshhold();
            try
            {

                var p = new DynamicParameters();
                p.Add("@serviceProviderID", servcieproviderid);

                th = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<ServicePRoviderThreshhold>("CRM_ATT_ServiceProvider_Threshhold", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttBb_DL, Method: Com_ATT_GetServiceProvidersThreshhold, Parameters => servcieproviderid: {servcieproviderid},  ErrorMessage:{ex.ToString()}");
            }

            return th;
        }

        #region CommonATT
        public async Task<Comm_ATT_DestinationServiceProvider> Com_ATT_GetServiceProvider(string fromMSISDN, string destinationMSISDN, string ProductId)
        {
            Comm_ATT_DestinationServiceProvider serviceProvider = null;
            try
            {

                var p = new DynamicParameters();
                p.Add("@fromMsisdn", fromMSISDN, DbType.String);
                p.Add("@ToMsisdn", destinationMSISDN, DbType.String);
                p.Add("@product_id", ProductId, DbType.String);
                serviceProvider = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<Comm_ATT_DestinationServiceProvider>("Com_ATT_GetDestinationServiceProviderConfig", p, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttDb_DL, Method: Com_ATT_GetServiceProvider, Parameters => fromMSISDN: {fromMSISDN} destinationMSISDN:{destinationMSISDN} ProductId:{ProductId}, ErrorMessage:{ex.Message}");
            }

            return serviceProvider;
        }
        public async Task<COMM_ATT_CustomerChargeValuesForReplacement> Com_ATT_GetCustomerChargeValuesForReplacement(int cdsp_config_id, int selectedCarrierNumber)
        {
            COMM_ATT_CustomerChargeValuesForReplacement destPriceDetails = new COMM_ATT_CustomerChargeValuesForReplacement();
            try
            {

                var p = new DynamicParameters();
                p.Add("@cdsp_config_id", cdsp_config_id);
                p.Add("@selected_Carrier_number", selectedCarrierNumber);

                var chargeValues = await AirtimeTransferConnection.Connection.QueryAsync<COMM_ATT_CustomerChargeValueForReplacement>("com_att_get_destination_operator_price_details_v2", p, commandType: CommandType.StoredProcedure);
                if (chargeValues != null)
                {
                    destPriceDetails.chargeValues = chargeValues.ToList();
                }

            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Class: AttBb_DL, Method: Com_ATT_GetCustomerChargeValuesForReplacement, Parameters => cdsp_config_id: {cdsp_config_id},  ErrorMessage:{ex.ToString()}");
            }

            return destPriceDetails;
        }

        public async Task<DBResponse> Com_ATT_insertTransactionGUID(string ProductId, string guid, string account, string toMsisdn, string productsJson, string requestJson, string responseJson, int serviceProviderId,
    string sourceMSisdn, string productItemCode, string countryCode = "", string operatorCode = "", string product = "", string operatorName = "", string operatorLogoUrl = "", string operatorCountryName = "", double? GetTokenApiTime = null, double? GetProviderApiTime = null, double? GetProductApiTime = null)
        {

            DBResponse result = new DBResponse();
            try
            {

                var parameters = new DynamicParameters();
                parameters.Add("@guid", guid);
                parameters.Add("@account", account);
                parameters.Add("@toMsisdn", toMsisdn);
                parameters.Add("@fromMsisdn", sourceMSisdn);
                parameters.Add("@productItemCode", productItemCode);
                parameters.Add("@productsJson", productsJson);
                parameters.Add("@requestJson", requestJson);
                parameters.Add("@responseJson", responseJson);
                parameters.Add("@serviceProviderId", serviceProviderId);
                parameters.Add("@countryCode", countryCode);     // Only for Ding API
                parameters.Add("@operatorCode", operatorCode); // Only for Ding API
                parameters.Add("@product", product);
                parameters.Add("@operatorName", operatorName);
                parameters.Add("@operatorLogoUrl", operatorLogoUrl);
                parameters.Add("@operatorCountryName", operatorCountryName);
                parameters.Add("@GetTokenApiTime", GetTokenApiTime);
                parameters.Add("@GetProviderApiTime", GetProviderApiTime);
                parameters.Add("@GetProductApiTime", GetProductApiTime);
                parameters.Add("@ProductId", ProductId);

                result = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DBResponse>("Com_ATT_create_api_access_product_tha_v2", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   insertTransactionGUID   Message:{ex.ToString()}");
                result.DBStatus = 0;
                result.DBErrorMessage = ex.Message;
                result.InsertId = 0;
                return result;
            }
        }

        public async Task<DBResponse> insertGetProductsAccessErrors(string account, string toMsisdn, int serviceProviderId,
    string sourceMSisdn, string ProductCode, string productItemCode, string ErrorMessage, double? GetTokenApiTime = null, double? GetProductApiTime = null, string DbConfiguredValues = null, string OperatorResponse = null)
        {

            DBResponse result = new DBResponse();
            try
            {

                var parameters = new DynamicParameters();
                parameters.Add("@account", account);
                parameters.Add("@toMsisdn", toMsisdn);
                parameters.Add("@fromMsisdn", sourceMSisdn);
                parameters.Add("@productItemCode", productItemCode);
                parameters.Add("@serviceProviderId", serviceProviderId);
                parameters.Add("@ProductCode", ProductCode);
                parameters.Add("@ErrorMessage", ErrorMessage);
                parameters.Add("@GetTokenApiTime", GetTokenApiTime);
                parameters.Add("@GetProductApiTime", GetProductApiTime);
                parameters.Add("@DbConfiguredValues", DbConfiguredValues);
                parameters.Add("@OperatorResponse", OperatorResponse);

                result = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<DBResponse>("insert_get_products_access_errors_v1", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"\"Database Error   insertTransactionGUID   Message:{ex.ToString()}");
                result.DBStatus = 0;
                result.DBErrorMessage = ex.Message;
                result.InsertId = 0;
                return result;
            }
        }


        #endregion


        #region Discount
        public async Task<decimal> GetDiscountSettings(string productCode, string productItemCode, string toMsisdn, string fromMsisdn, decimal amount)
        {

            PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
            string ori_prefix = "";
            try
            {
                string phone = fromMsisdn;
                if (!phone.StartsWith("+"))
                    phone = "+" + phone;
                // phone must begin with '+'
                PhoneNumber numberProto = phoneUtil.Parse(phone, "");
                ori_prefix = numberProto.CountryCode.ToString();
            }
            catch (NumberParseException e)
            {
                _loggerAPIAccess.Error($"  GetDiscountSettings-PhoneNumberUtil unable to fetch iso code against " + fromMsisdn + " error " + e.ToString());
            }

            try
            {
                toMsisdn = toMsisdn.Replace("+", "");
                ori_prefix = ori_prefix.Replace("+", "");
                fromMsisdn = fromMsisdn.Replace("+", "");

                var parameters = new DynamicParameters();
                parameters.Add("@productCode", productCode);
                parameters.Add("@productItemCode", productItemCode);
                parameters.Add("@toMsisdn", toMsisdn);
                parameters.Add("@ori_prefix", ori_prefix);
                parameters.Add("@frommsisdn", fromMsisdn);
                parameters.Add("@amount", amount);
                var discountPercentage = await AirtimeTransferConnection.Connection.QueryFirstOrDefaultAsync<decimal>("at_get_discount_settings_v2", parameters, commandType: CommandType.StoredProcedure);
                return discountPercentage;
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Error($"Class: AttBb_DL, Method: GetDiscountSettings,Error While getting discount settings. Parameters=> productCode: {productCode} productItemCode: {productItemCode} toMsisdn: {toMsisdn}, ErrorMessage: {ex.Message}");
                return 0;
            }
        }

        #endregion
    }
}
