﻿using Infrastructure.BLL.Interfaces;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class Jwt_BL : IJwt_BL
    {

        private readonly ILogger Logger;
        private readonly JwtConfig JwtConfig;

        public Jwt_BL(ILogger logger, IOptions<JwtConfig> jwtConfig)
        {
            Logger = logger;
            JwtConfig = jwtConfig.Value;
        }

        public JwtToken GenerateToken(UserAccount userAccount, string devicePersistentId, string remoteIp)
        {
            try
            {

                var authClaims = new List<Claim>
                {
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim("msisdn", userAccount.Msisdn.Trim()),
                    new Claim("email", userAccount.emailRegistration?.email??""),
                    new Claim("acc", userAccount.AccountID.Trim()),
                    new Claim("nsId", userAccount.UserAccountDetails.Na_Service_Id.ToString(CultureInfo.InvariantCulture)),
                    new Claim("currency", userAccount.UserAccountBalance.Currency),
                    new Claim("dId", devicePersistentId),
                    new Claim("ip", remoteIp),
                };

                //foreach (var userRole in userRoles)
                //{
                //    authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                //}
                var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtConfig.Secret));

                var token = new JwtSecurityToken(
                    issuer: JwtConfig.ValidIssuer,
                    audience: JwtConfig.ValidAudience,
                    expires: DateTime.UtcNow.AddMinutes(JwtConfig.TokenExpiryTimeInMins),
                    claims: authClaims,
                    signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                    );

                JwtToken tokenResonse = new JwtToken();
                tokenResonse.token = new JwtSecurityTokenHandler().WriteToken(token);
                tokenResonse.expiry = token.ValidTo.ToString("dd-MM-yyyy hh:mm:ss");

                return tokenResonse;

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Jwt_BL, Method: GenerateToken, ErrorMessage: {ex.Message}, Parameters -> {JsonConvert.SerializeObject(userAccount)}");
                return null;
            }
        }

        public JwtTokenValidationResponse ValidateToken(string token)
        {

            JwtTokenValidationResponse tokenValidationResp = new JwtTokenValidationResponse();


            try
            {

                var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtConfig.Secret));

                TokenValidationParameters tokenValidationParams = new TokenValidationParameters()
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidAudience = JwtConfig.ValidAudience,
                    ValidIssuer = JwtConfig.ValidIssuer,
                    IssuerSigningKey = authSigningKey,
                    ValidateLifetime = true,
                    LifetimeValidator = CustomLifetimeValidator,
                    RequireExpirationTime = true,
                };
                SecurityToken validatedToken;
                JwtToken tokenResonse = new JwtToken();
                ClaimsPrincipal claimsP = new JwtSecurityTokenHandler().ValidateToken(token, tokenValidationParams, out validatedToken);

                tokenValidationResp.isTokenValid = true;
                //tokenValidationResp.claims = claimsP.Claims.ToList();
                tokenValidationResp.claims = ((JwtSecurityToken)validatedToken).Claims.ToList();
                //tokenValidationResp.claims.Add(s.Claims.FirstOrDefault(e=>e.Type=="email"));
                tokenValidationResp.ErrorMessage = "";
                return tokenValidationResp;

            }
            catch (Exception ex)
            {
                //Logger.Error($"Class: Jwt_BL, Method: ValidateToken, ErrorMessage: {ex.Message}, Parameters -> Token: {token}");
                tokenValidationResp.isTokenValid = false;
                tokenValidationResp.ErrorMessage = ex.Message;
                tokenValidationResp.claims = null;
                return tokenValidationResp;
            }
        }

        private bool CustomLifetimeValidator(DateTime? notBefore, DateTime? expires, SecurityToken tokenToValidate, TokenValidationParameters @param)
        {
            if (expires != null)
            {
                return expires > DateTime.UtcNow;
            }
            return false;
        }

    }
}
