﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ATT.Infrastructure.BLL.Ding;
using ATT.Infrastructure.BLL.Reloady;
using ATT.Infrastructure.BLL.Sochitel;
using ATT.Infrastructure.BLL.TransferTo;
using ATT.Infrastructure.DAL;
using ATT.Models.Database;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace ATT.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class ATTController : ControllerBase
    {

        private ILogger _loggerAPIAccess;
        private IAttDb_DL _appDB;
        private ISochitelAutomation_BL _SochiTelAutomation;
        private ITransfertoAutomation_BL _TransfertoAutomation;
        private IReloadlyPost_BL _reloadlyPost_BL;
        private IDingPost_BL _dingPost_BL;
        public ATTController(ILogger appLoggers, IAttDb_DL appDB, ITransfertoAutomation_BL transfertoAutomation, ISochitelAutomation_BL sochiTelAutomation, IReloadlyPost_BL reloadlyPost_BL, IDingPost_BL dingPost_BL)
        {
            _loggerAPIAccess = appLoggers;
            _appDB = appDB;
            _TransfertoAutomation = transfertoAutomation;
            _SochiTelAutomation = sochiTelAutomation;
            _reloadlyPost_BL = reloadlyPost_BL;
            _dingPost_BL = dingPost_BL;
        }


        [HttpGet]
        [Route("getOperatorProductsMSISDN")]
        public async Task<IActionResult> getOperatorProductsMSISDNFunction(int nsid, string destinationMSISDN, string account, string fromMSISDN)
        {
            try
            {
                ServiceProvider serviceProviderRecord = await _appDB.getServiceProviderRecord(nsid, destinationMSISDN);
                if (serviceProviderRecord != null)
                {
                    if (serviceProviderRecord.DefaultServiceProviderID == 1) // Sochitel
                    {
                        var result = await _SochiTelAutomation.sochitelGetOperatorProductsMSISDN(destinationMSISDN, account, serviceProviderRecord.OriginDestinationId);
                        return Ok(result);
                        //return Ok("Sochitel Not Available.");
                    }
                    else if (serviceProviderRecord.DefaultServiceProviderID == 2) //transferto
                    {
                        var result = await _TransfertoAutomation.transferToGetOperatorProductsMSISDN(destinationMSISDN, account, serviceProviderRecord.OriginDestinationId, fromMSISDN);
                        return Ok(result);
                    }
                    else
                    {
                        _loggerAPIAccess.Debug($"  \"GET /getOperatorProductsMSISDN\"  Failed  Source:ATT API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}  NSID--{nsid}     Reason=Service Not Found ");
                        var result2 = new { errorCode = 2, status = "Failure", message = "Service Not Found For this  MSISDN" };
                        return Ok(result2);
                    }
                }
                else
                {
                    _loggerAPIAccess.Debug($"  \"GET /getOperatorProductsMSISDN\"  Failed  Source:ATT API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}  NSID--{nsid}     Reason=Service Not Found ");
                    var result2 = new { errorCode = 2, status = "Failure", message = "Service Not Found For this  MSISDN" };
                    return Ok(result2);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($"  \"GET /getOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error" };
                return Ok(errorResult);
            }

        }

        [HttpGet]
        [Route("GetFreeSwitchOperatorProducts")]
        public async Task<IActionResult> GetFreeSwitchOperatorProducts(string destinationMSISDN, string account, string fromMSISDN, string productCode, string productItemCode, int serviceProviderNumber = 1)
        {
            try
            {
                DestinationServiceProvider serviceProviderRecord = await _appDB.GetFreeSwitchServiceProvider(destinationMSISDN);
                if (serviceProviderRecord != null)
                {

                    RoutingInfo routingInfo = GetRoutingInfo(serviceProviderRecord, serviceProviderNumber);

                    if (routingInfo.ServiceProviderId == 1) // Sochitel
                    {
                        var result = await _SochiTelAutomation.GetFreeSwitchOperatorProducts(fromMSISDN, destinationMSISDN, account, productCode, productItemCode);
                        if(result.errorCode > 0 && routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.UpdateFreeSwitchServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);

                    }
                    else if (routingInfo.ServiceProviderId == 2) //transferto
                    {
                        var result = await _TransfertoAutomation.transferToFreeSwitchGetOperatorProductsMSISDN(fromMSISDN, destinationMSISDN, account, productCode, productItemCode);
                        if (result.errorCode > 0 && routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.UpdateFreeSwitchServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else if (routingInfo.ServiceProviderId == 3) //Ding
                    {
                        var result = await _dingPost_BL.DingFreeSwitchGetPhoneOperator(fromMSISDN, account, destinationMSISDN, productCode, productItemCode);
                        if (result.errorCode > 0 && routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.UpdateFreeSwitchServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else if (routingInfo.ServiceProviderId == 4) //Reloadly
                    {
                        var result = await _reloadlyPost_BL.ReloadlyFreeSwitchGetPhoneOperator(fromMSISDN, account, destinationMSISDN, productCode, productItemCode);
                        if (result.errorCode > 0 && routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.UpdateFreeSwitchServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else  // Use TransferTo
                    {
                        var result = await _TransfertoAutomation.transferToFreeSwitchGetOperatorProductsMSISDN(fromMSISDN, destinationMSISDN, account, productCode, productItemCode);
                        return Ok(result);
                    }
                }
                else // Use TransferTo
                {
                    var result = await _TransfertoAutomation.transferToFreeSwitchGetOperatorProductsMSISDN(fromMSISDN, destinationMSISDN, account, productCode, productItemCode);
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($" ATTController, \"GET /GetFreeSwitchOperatorProducts\"  Failed  Source:General  Parameters => destinationMSISDN: {destinationMSISDN},  currency:{account}, fromMSISDN: {fromMSISDN}, productCode: {productCode}, productItemCode: {productItemCode}, serviceProviderNumber: {serviceProviderNumber},  Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = ex.Message };
                return Ok(errorResult);
            }

        }

        [HttpPost]
        [Route("FreeSwitchExecute")]
        public async Task<IActionResult> FreeSwitchExecute(ExecuteData data)
        {
            try
            {
                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(data.nowtelTransactionReference, data.product);
                DestinationServiceProvider serviceProviderRecord = await _appDB.GetFreeSwitchServiceProvider(guidReferneceRecord.tomsisdn);
                if (serviceProviderRecord != null)
                {
                    RoutingInfo routingInfo = GetRoutingInfo(serviceProviderRecord, data.serviceProviderNumber);

                    if (routingInfo.ServiceProviderId == 1) // Sochitel
                    {
                        var result = await _SochiTelAutomation.FreeSwitch_Execute(data);
                        if (routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.UpdateFreeSwitchServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);

                    }
                    else if (routingInfo.ServiceProviderId == 2) //transferto
                    {
                        var result = await _TransfertoAutomation.ExecuteTransactionFreeSwitch(data);
                        if (routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.UpdateFreeSwitchServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else if (routingInfo.ServiceProviderId == 3) //Ding
                    {
                        var result = await _dingPost_BL.DingFreeSwitchTopUp(data);
                        if (routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.UpdateFreeSwitchServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else if (routingInfo.ServiceProviderId == 4) //Reloadly
                    {
                        var result = await _reloadlyPost_BL.ReloadlyFreeSwitchTopUp(data);
                        if (routingInfo.UpdateCount == true)
                        {
                            int resp = await _appDB.UpdateFreeSwitchServiceProvider(serviceProviderRecord.Id, routingInfo.NewServiceProviderTranCount_Current, routingInfo.NewSecondServiceProviderTranCount_Current);
                        }
                        return Ok(result);
                    }
                    else  // Use TransferTo
                    {
                        var result = await _TransfertoAutomation.ExecuteTransactionFreeSwitch(data);
                        return Ok(result);
                    }
                }
                else // Use TransferTo
                {
                    var result = await _TransfertoAutomation.ExecuteTransactionFreeSwitch(data);
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                _loggerAPIAccess.Debug($" ATTController, \"POST /FreeSwitchExecute\"  Failed  Source:General  Parameters-  RequestJson:{JsonConvert.SerializeObject(data)},  ErrorMessage:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = ex.Message };
                return Ok(errorResult);
            }

        }

        [NonAction]
        private RoutingInfo GetRoutingInfo(DestinationServiceProvider serviceProviderRecord, int serviceProviderNumber)
        {
            #region Routing

            int serviceProviderId = 0;
            bool updateCount = false;
            int NewServiceProviderTranCount_Current = 0;
            int NewSecondServiceProviderTranCount_Current = 0;

            #region PercentageRouting

            if (serviceProviderRecord.TypeofRouting == RoutingType.Percentage)
            {
                updateCount = true;

                if (serviceProviderRecord.ServiceProviderTranCount_Current >= serviceProviderRecord.ServiceProviderTranCount)
                {

                    if (serviceProviderRecord.SecondServiceProviderEnabled == false)  // Not Enable, So By Default 'TransferTo' will be used
                    {
                        updateCount = false;
                        serviceProviderId = 0;  // Not Enable, So By Default 'TransferTo' will be used
                    }
                    else if (serviceProviderRecord.SecondServiceProviderTranCount_Current >= (serviceProviderRecord.SecondServiceProviderTranCount - 1))
                    {
                        NewServiceProviderTranCount_Current = 0;
                        NewSecondServiceProviderTranCount_Current = 0;
                        serviceProviderId = serviceProviderRecord.SecondServiceProviderId;
                    }
                    else
                    {
                        NewServiceProviderTranCount_Current = serviceProviderRecord.ServiceProviderTranCount_Current;
                        NewSecondServiceProviderTranCount_Current = serviceProviderRecord.SecondServiceProviderTranCount_Current + 1;
                        serviceProviderId = serviceProviderRecord.SecondServiceProviderId;
                    }
                }
                else
                {

                    if (serviceProviderRecord.IsEnabled == false)  // Not Enable, So By Default 'TransferTo' will be used
                    {
                        updateCount = false;
                        serviceProviderId = 0;  // Not Enable, So By Default 'TransferTo' will be used
                    }
                    else
                    {
                        NewServiceProviderTranCount_Current = serviceProviderRecord.ServiceProviderTranCount_Current + 1;
                        NewSecondServiceProviderTranCount_Current = 0;
                        serviceProviderId = serviceProviderRecord.ServiceProviderId;
                    }
                }

            }

            #endregion PercentageRouting

            #region FailoverRouting

            else // Failover Routing
            {
                updateCount = false;

                if (serviceProviderNumber == 2) // Second Service Provider
                {
                    if (serviceProviderRecord.SecondServiceProviderEnabled == false)  // Not Enable, So By Default 'TransferTo' will be used
                    {
                        serviceProviderId = 0;  // Not Enable, So By Default 'TransferTo' will be used
                    }
                    else
                    {
                        serviceProviderId = serviceProviderRecord.SecondServiceProviderId;
                    }
                }
                else // Service Provider
                {
                    if (serviceProviderRecord.IsEnabled == false)  // Not Enable, So By Default 'TransferTo' will be used
                    {
                        serviceProviderId = 0;  // Not Enable, So By Default 'TransferTo' will be used
                    }
                    else
                    {
                        serviceProviderId = serviceProviderRecord.ServiceProviderId;
                    }
                }
            }

            RoutingInfo routingInfo = new RoutingInfo();
            routingInfo.ServiceProviderId = serviceProviderId;
            routingInfo.UpdateCount = updateCount;
            routingInfo.NewServiceProviderTranCount_Current = NewServiceProviderTranCount_Current;
            routingInfo.NewSecondServiceProviderTranCount_Current = NewSecondServiceProviderTranCount_Current;

            return routingInfo;

            #endregion FailoverRouting

            #endregion Routing

        }


       

    }
}