﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class VoucherTopupResponse
    {
        public string BalanceBefore { get; set; }

        public string CreditApplied { get; set; }

        public string BalanceAfter { get; set; }

        public int VoucherId { get; set; }

        public string Currency { get; set; }

        public string Result { get; set; }
    }
}
