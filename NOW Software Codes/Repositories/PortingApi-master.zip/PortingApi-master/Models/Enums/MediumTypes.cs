﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum MediumTypes
    {
        Web=1,
        Sms=2
    }
}
