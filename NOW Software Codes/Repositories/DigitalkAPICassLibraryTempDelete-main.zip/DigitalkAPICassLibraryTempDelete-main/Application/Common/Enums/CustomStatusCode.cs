﻿namespace Application.Common.Enums;

public static class CustomStatusCode
{
    public const int BadRequest = 100400;
    public const int Forbidden = 100403;
    public const int NotFound = 100404;
    public const int Unauthorized = 100401;
    public const int InternalServerError = 100500;

    public const int BundleUnSubscribeSuccess = 100001;
    public const int BundleUnSubscribeFail = 100002;
}

public static class CustomStatusKey
{
    public const string BadRequest = "We ran into an error - try again";
    public const string Unauthorized = "You're not authorized - please try again";
    public const string NotFound = "We couldn’t find it. Try searching for something else.";
    public const string InternalServerError = "Our server ran into an error - let's try again.";
    public const string Forbidden = "Oops, you're not authorized to access this.";
    public const string Success = "Success";
    
    public const string BundleUnSubscribeSuccess = "Bundle unsubscribed successfully";
    public const string BundleUnSubscribeFail = "Bundle unsubscribed failed";

   
}
public static class CustomStatusExtensions
{
    public static string? GetStatusNameByStatusCode(this int value)
    {
        var existingProperties = typeof(CustomStatusCode).GetFields(BindingFlags.Static | BindingFlags.Public).ToList();
        var statusName = string.Empty;
        if (existingProperties.Count > 0)
        {
            foreach (var item in existingProperties)
            {
                if (Convert.ToInt32(item.GetValue(item.Name)) == value)
                {
                    statusName = Convert.ToString(item.Name);
                    break;
                }
            }
        }
        return statusName;
    }
    public static int GetStatusCodeByStatusName(this string value)
    {
        var existingProperty = typeof(CustomStatusCode).GetField(value);
        var statusCode = 0;
        if (existingProperty != null)
        {
            statusCode = Convert.ToInt32(existingProperty.GetValue(existingProperty.Name));
        }
        return statusCode;
    }
    public static string? GetStatusNameByStatusCode<T>(this Result<T> value)
    {
        var existingProperties = typeof(CustomStatusCode).GetFields(BindingFlags.Static | BindingFlags.Public).ToList();
        if (existingProperties.Count > 0)
        {
            foreach (var item in existingProperties)
            {
                return Convert.ToInt32(item.GetValue(item.Name)) == value.ErrorCode ? Convert.ToString(item.Name) : string.Empty;
            }
        }
        return string.Empty;
    }
}