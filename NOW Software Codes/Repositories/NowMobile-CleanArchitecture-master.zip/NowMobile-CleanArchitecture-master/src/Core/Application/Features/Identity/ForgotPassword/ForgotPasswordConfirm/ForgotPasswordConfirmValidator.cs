﻿namespace Application.Features.Identity.ForgotPassword.ForgotPasswordConfirm;

public class ForgotPasswordResendValidator : AbstractValidator<ForgotPasswordConfirmRequest>
{
    public ForgotPasswordResendValidator(ICommonService commonService)
    {
        RuleFor(data => data.Email)
             .Cascade(CascadeMode.Stop)
             .NotNull().NotEmpty()
             .Must(p => commonService.IsValidEmailAddress(p))
             .WithMessage("Invalid Email Address");
        RuleFor(data => data.Otp).NotEmpty().NotNull();
    }
}