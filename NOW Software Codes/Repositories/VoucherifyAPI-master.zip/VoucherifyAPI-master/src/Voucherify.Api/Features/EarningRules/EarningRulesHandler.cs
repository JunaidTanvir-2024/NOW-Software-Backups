using System.Text.Json;

using RW;

using Voucherify.Api.Features.EarningRules.Requests;
using Voucherify.Api.Features.EarningRules.Responses;
using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Domain.Definitions;
using Voucherify.Core.Services.VoucherifyApi;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

using static Voucherify.Api.Features.EarningRules.Responses.EarningRuleResponse;

namespace Voucherify.Api.Features.EarningRules;

public interface IEarningRulesHandler
{
    Task<IResultWrapper<EarningRuleResponse>> DisableEarningRule(DisableEarningRuleRequest request);
    Task<IResultWrapper<EarningRuleResponse>> EnableEarningRule(EnableEarningRuleRequest request);
    Task<IResultWrapper<EarningRuleResponse>> GetEarningRule(GetEarningRuleRequest request);
    Task<IResultWrapper<List<EarningRuleResponse>>> GetEarningRules(GetEarningRulesRequest request);
}

internal class EarningRulesHandler : IEarningRulesHandler
{
    private const string EarningRules = "Earning Rules";
    private readonly IVoucherifyImplementation _voucherifyImplementation;

    public EarningRulesHandler(IVoucherifyImplementation voucherifyImplementation)
    {
        _voucherifyImplementation = voucherifyImplementation;
    }

    public async Task<IResultWrapper<List<EarningRuleResponse>>> GetEarningRules(GetEarningRulesRequest request)
    {
        var earningRules = await _voucherifyImplementation.GetEarningRules(request.CampaignNameOrId, request.PageNumber, request.PageSize);

        if (earningRules != null)
        {
            var result = earningRules?.Select(earningRule =>
            {
                var loyaltyMetadataInfo = earningRule?.Loyalty?.PointsInfo?.FirstOrDefault() != null ? JsonSerializer.Deserialize<LoyaltyEarningMetadata>(Convert.ToString(earningRule.Loyalty.PointsInfo.First().Value)!) : null;

                return new EarningRuleResponse()
                {
                    Id = earningRule?.Id,
                    Banner = earningRule?.Source?.Banner,
                    CampaignId = earningRule?.Source?.ObjectId,
                    EventType = earningRule?.EventType,
                    IsActive = earningRule!.IsActive,
                    LoyaltyPoints = (earningRule?.Loyalty?.Points) ?? 0,
                    LoyaltyType = earningRule?.Loyalty?.Type,
                    LoyaltyMetadata = new LoyaltyMetadataInfo()
                    {
                        Base = loyaltyMetadataInfo != null ? loyaltyMetadataInfo.Base : 0,
                        BasePoints = loyaltyMetadataInfo != null ? loyaltyMetadataInfo.BasePoints : 0,
                    },
                    Metadata = earningRule?.Metadata,
                    ValidationRuleId = earningRule?.ValidationRuleId,
                };
            }
            ).ToList();

            return ResultWrapper.Success(payload: result).IncludePagination(currentPage: request.PageNumber, totalRecordsPerPage: request.PageSize, totalAvailableRecords: result?.Count);
        }
        return ResultWrapper.Failure<List<EarningRuleResponse>>(AppConstants.StatusMessages.EarningRuleNotFound, AppConstants.StatusCodes.EarningRuleNotFound);
    }
    public async Task<IResultWrapper<EarningRuleResponse>> GetEarningRule(GetEarningRuleRequest request)
    {
        var earningRule = await _voucherifyImplementation.GetEarningRule(request.CampaignNameOrId, request.EarningRuleId);
        var loyaltyMetadataInfo = earningRule?.Loyalty?.PointsInfo?.FirstOrDefault() != null ? JsonSerializer.Deserialize<LoyaltyEarningMetadata>(Convert.ToString(earningRule.Loyalty.PointsInfo.First().Value)!) : null;

        return earningRule != null ?
            ResultWrapper.Success(new EarningRuleResponse()
            {
                Id = earningRule.Id,
                Banner = earningRule.Source?.Banner,
                CampaignId = earningRule.Source?.ObjectId,
                EventType = earningRule.EventType,
                IsActive = earningRule.IsActive,
                LoyaltyPoints = (earningRule?.Loyalty?.Points) ?? 0,
                LoyaltyType = earningRule?.Loyalty?.Type,
                LoyaltyMetadata = new LoyaltyMetadataInfo()
                {
                    Base = loyaltyMetadataInfo != null ? loyaltyMetadataInfo.Base : 0,
                    BasePoints = loyaltyMetadataInfo != null ? loyaltyMetadataInfo.BasePoints : 0,
                },
                Metadata = earningRule?.Metadata,
                ValidationRuleId = earningRule?.ValidationRuleId,
            }) :
            ResultWrapper.Failure<EarningRuleResponse>(AppConstants.StatusMessages.EarningRuleNotFound, AppConstants.StatusCodes.EarningRuleNotFound);
    }
    public async Task<IResultWrapper<EarningRuleResponse>> EnableEarningRule(EnableEarningRuleRequest request)
    {
        var earningRule = await _voucherifyImplementation.EnableEarningRule(request.CampaignId, request.EarningRuleId);
        var loyaltyMetadataInfo = earningRule?.Loyalty?.PointsInfo?.FirstOrDefault() != null ? JsonSerializer.Deserialize<LoyaltyEarningMetadata>(Convert.ToString(earningRule.Loyalty.PointsInfo.First().Value)!) : null;
        return earningRule != null ?
            ResultWrapper.Success(new EarningRuleResponse()
            {
                Id = earningRule.Id,
                Banner = earningRule.Source?.Banner,
                CampaignId = earningRule.Source?.ObjectId,
                EventType = earningRule.EventType,
                IsActive = earningRule.IsActive,
                LoyaltyPoints = (earningRule?.Loyalty?.Points) ?? 0,
                LoyaltyType = earningRule?.Loyalty?.Type,
                LoyaltyMetadata = new LoyaltyMetadataInfo()
                {
                    Base = loyaltyMetadataInfo != null ? loyaltyMetadataInfo.Base : 0,
                    BasePoints = loyaltyMetadataInfo != null ? loyaltyMetadataInfo.BasePoints : 0,
                },
                Metadata = earningRule?.Metadata,
                ValidationRuleId = earningRule?.ValidationRuleId,
            }) :
            ResultWrapper.Failure<EarningRuleResponse>(AppConstants.StatusMessages.EarningRuleNotEnabled, AppConstants.StatusCodes.EarningRuleNotEnabled);
    }
    public async Task<IResultWrapper<EarningRuleResponse>> DisableEarningRule(DisableEarningRuleRequest request)
    {
        var earningRule = await _voucherifyImplementation.DisableEarningRule(request.CampaignId, request.EarningRuleId);
        var loyaltyMetadataInfo = earningRule?.Loyalty?.PointsInfo?.FirstOrDefault() != null ? JsonSerializer.Deserialize<LoyaltyEarningMetadata>(Convert.ToString(earningRule.Loyalty.PointsInfo.First().Value)!) : null;
        return earningRule != null ?
            ResultWrapper.Success(new EarningRuleResponse()
            {
                Id = earningRule.Id,
                Banner = earningRule.Source?.Banner,
                CampaignId = earningRule.Source?.ObjectId,
                EventType = earningRule.EventType,
                IsActive = earningRule.IsActive,
                LoyaltyPoints = (earningRule?.Loyalty?.Points) ?? 0,
                LoyaltyType = earningRule?.Loyalty?.Type,
                LoyaltyMetadata = new LoyaltyMetadataInfo()
                {
                    Base = loyaltyMetadataInfo != null ? loyaltyMetadataInfo.Base : 0,
                    BasePoints = loyaltyMetadataInfo != null ? loyaltyMetadataInfo.BasePoints : 0,
                },
                Metadata = earningRule?.Metadata,
                ValidationRuleId = earningRule?.ValidationRuleId,
            }) :
            ResultWrapper.Failure<EarningRuleResponse>(AppConstants.StatusMessages.EarningRuleNotDisabled, AppConstants.StatusCodes.EarningRuleNotDisabled);
    }
}
