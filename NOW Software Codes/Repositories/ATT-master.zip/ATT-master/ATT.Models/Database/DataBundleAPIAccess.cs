﻿namespace ATT.Models.Database
{
    public class DataBundleAPIAccess
    {
        public string NowtelTransactionReference { get; set; }
        public string Account { get; set; }
        public string ToMsisdn { get; set; }
        public string ProductApiType { get; set; }
        public string Receiverccy { get; set; }
        public string Clientccy { get; set; }
        public int ProductId { get; set; }
        public string Product { get; set; }
        public string ProductDesc { get; set; }
        public string WholeSalePrice { get; set; }
        public string CustomerChargePrice { get; set; }
    }
}
