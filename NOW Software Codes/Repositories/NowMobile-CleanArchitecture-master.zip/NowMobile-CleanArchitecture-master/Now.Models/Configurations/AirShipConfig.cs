﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Now.Models.Configurations;
public class AirShipConfig
{
    public bool IsActive { get; set; }
    public string AccountTagGroupName { get; set; }
    public string CartTagGroupName { get; set; }
    public string UserTagGroupName { get; set; }
    public string PurchaseTagGroupName { get; set; }
    public string ActivityTagGroupName { get; set; }
    public string ApiEndpoint { get; set; }
}