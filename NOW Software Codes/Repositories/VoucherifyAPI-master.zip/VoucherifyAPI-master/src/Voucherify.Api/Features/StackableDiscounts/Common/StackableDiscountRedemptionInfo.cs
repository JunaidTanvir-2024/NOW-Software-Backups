using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.StackableDiscounts.Common;

public class StackableDiscountRedemptionInfo
{
    public string DiscountCode { get; set; } = null!;
    public string? DiscountType { get; set; }
    public string? RewardId { get; set; }
    public Metadata? Metadata { get; set; }
}
