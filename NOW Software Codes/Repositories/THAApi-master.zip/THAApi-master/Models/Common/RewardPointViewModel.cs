﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Common
{
    public class RewardPointViewModel
    {
        public string Min { get; set; }
        public string Max { get; set; }
    }
}
