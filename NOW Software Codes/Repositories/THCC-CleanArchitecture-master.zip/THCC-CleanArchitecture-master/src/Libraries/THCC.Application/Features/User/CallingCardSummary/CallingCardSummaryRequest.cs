﻿
namespace THCC.Application.Features.User.CallingCardSummary
{
    public class CallingCardSummaryRequest : IRequest<object>
    {
        public string CardPin { get; set; } = default!;
    }

    public class CallingCardSummaryRequestValidator : AbstractValidator<CallingCardSummaryRequest>
    {
        public CallingCardSummaryRequestValidator()
        {
            RuleFor(data => data.CardPin)
                    .NotNull()
                    .NotEmpty()
                    .MaximumLength(25).WithMessage("Your card number length must not exceed {0}");
        }
    }

}
