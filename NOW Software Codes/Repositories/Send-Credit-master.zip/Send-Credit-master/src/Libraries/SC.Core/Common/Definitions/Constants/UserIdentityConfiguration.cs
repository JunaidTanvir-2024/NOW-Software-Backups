﻿namespace SC.Core.Common.Definitions.Constants;
public static partial class AppConstants
{
    public static class UserIdentityConfiguration
    {
        public const int UserLockedOutTimeSpanMinutes = 5;
        public const int ConsectiveFailedAttemptsWithMinutees = 1;
        public const int MaxFailedAttempts = 3;
        public const int TokenValidityMinutees = 1;
        public const string DefaultCountry = "GB";
        public const string DefaultCurrency = "GBP";


    }
}
