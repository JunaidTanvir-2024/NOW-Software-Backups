﻿namespace Models.Enums
{
    public enum ApnServerType
    {
        Development=1,
        Production=2
    }
}
