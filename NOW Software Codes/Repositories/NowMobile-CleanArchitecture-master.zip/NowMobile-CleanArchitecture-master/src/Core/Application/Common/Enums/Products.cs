namespace Application.Common.Enums;

public enum Products
{
    NowPayg = 2
}
