﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrasnferHome.Models.DAOs
{
    public class DbResult<T>
    {
        public int DBStatus { get; set; }
        public string DBErrorMessage { get; set; }
        public T Data { get; set; }
    }
}
