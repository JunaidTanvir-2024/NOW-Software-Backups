﻿using System.Text.Json.Serialization;
namespace NTCB.Api.Features.DTOne.Models;

public class StatusInfo
{
    [JsonPropertyName("_class")]
    public ClassMessageInfo? Class { get; set; }
    
    [JsonPropertyName("id")]
    public int? Id { get; set; }
    
    [JsonPropertyName("message")]
    public string? Message { get; set; }
}
