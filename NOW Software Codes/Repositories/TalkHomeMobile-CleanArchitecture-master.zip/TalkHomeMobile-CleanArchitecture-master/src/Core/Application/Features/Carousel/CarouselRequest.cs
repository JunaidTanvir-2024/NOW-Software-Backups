﻿namespace Application.Features.Carousel;
public class CarouselRequest : IRequest<Result<IEnumerable<CarouselResponse>>>
{
    public string? Msisdn { get; set; }
}
