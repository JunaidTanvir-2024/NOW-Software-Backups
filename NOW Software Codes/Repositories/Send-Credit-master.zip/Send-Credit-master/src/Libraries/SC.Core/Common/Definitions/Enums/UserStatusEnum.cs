﻿using SC.Core.Common.Definitions.Utilities;

namespace SC.Core.Common.Definitions.Constants;
public static partial class AppEnums
{
    public enum UserStatusEnum
    {
        [Key("active")]
        Active,
        [Key("inactive")]
        Inactive,
        [Key("blocked")]
        Blocked,
        [Key("account Created")]
        AccountCreated,
        [Key("verification Pending")]
        VerificationPending,
        [Key("trial Period")]
        TrialPeriod,
        [Key("subscribed")]
        Subscribed,
        [Key("churned")]
        Churned,
    }
}



