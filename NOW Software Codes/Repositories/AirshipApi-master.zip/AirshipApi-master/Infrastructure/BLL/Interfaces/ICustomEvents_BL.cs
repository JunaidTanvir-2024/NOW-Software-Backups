﻿using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface ICustomEvents_BL
    {
        Task<GenericApiResponse<ApiCustomEventResponse>> AddCustomEvents(AddCustomEventsRequest request);
    }
}
