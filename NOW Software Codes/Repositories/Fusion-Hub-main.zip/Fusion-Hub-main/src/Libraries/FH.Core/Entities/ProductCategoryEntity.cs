namespace FH.Core.Entities;
public sealed record ProductCategoryEntity : BaseEntity<long>
{
	public string? Name { get; set; }
	public string? Description { get; set; }
}
