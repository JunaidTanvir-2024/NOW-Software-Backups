﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PhoneNumbers;
using Serilog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using TransferHome.Infrastructure.BLL.Interfaces;
using TransferHome.Infrastructure.Services.Interfaces;
using TransferHome.Models.Contracts.InAppModels;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.Contracts.Service.Pay360ApiContracts;
using TransferHome.Models.DAOs;
using TransferHome.Models.Resources;
using TransferHome.Models.Utility;
using TransferHomeAPI.Infrastructure.Services.Interfaces;
using TransferHomeAPI.Interfaces;
using TransferHomeAPI.Utilities;
using TrasnferHome.Infrastructure.BLL.Interfaces;
using TrasnferHome.Models.Utility;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TransferHomeAPI.Controllers
{
    public class InAppPay360Controller : Controller
    {
        private readonly IPay360ServiceForInApp Pay360ServiceForInApp;
        private readonly IBL_Transfer TransferBL;
        private readonly IBL_User UserBL;
        private readonly ILogger Logger;
        private readonly string ErrorView = string.Format("~/Views/InAppPay360/Error.cshtml");

        public InAppPay360Controller(IPay360ServiceForInApp pay360ServiceForInApp, IBL_User userBL, IBL_Transfer transferBL, ILogger logger)
        {
            Pay360ServiceForInApp = pay360ServiceForInApp;
            UserBL = userBL;
            TransferBL = transferBL;
            Logger = logger;
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [Route("card/topup")]
        [HttpGet]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<ActionResult> Checkout(InAppPay360TopUpRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                var userId = Convert.ToInt32(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value);

                var allRegions = CultureInfo.GetCultures(CultureTypes.SpecificCultures).Select(x => new RegionInfo(x.LCID));
                var currencySymbol = allRegions.FirstOrDefault(region => region.ISOCurrencySymbol == model.Currency)?.CurrencySymbol;

                var viewmodel = new InAppPay360TopUpViewModel()
                {
                    Amount = model.Amount,
                    Currency = model.Currency,
                    CurrencySymbol = currencySymbol,
                    UserId = Convert.ToInt32(userId)
                };

                var customer = await Pay360ServiceForInApp.GetCutomerInfo(userId);
                if (customer == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                if (customer.Item2 == 0)
                {
                    viewmodel.Customer = customer.Item1;
                    return View("TopUpCheckout", viewmodel);
                }
                else
                {
                    return View("TopUpCheckout", viewmodel);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPay360Controller, Method: Checkout, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }

        [HttpPost]
        [Route("card/starttopupbycard")]
        public async Task<ActionResult> StartTopUpByCard(InAppPay360CardPostModel model)
        {
            try
            {
                ModelState.Remove("nowtelTransactionReference");
                ModelState.Remove("operatorid");
                ModelState.Remove("product");
                ModelState.Remove("fromMSISDN");
                ModelState.Remove("messageToRecipient");

                model.IPAddress = ExtensionMethods.GetRemoteIPAddress(HttpContext);

                if (model.NoCards.Equals("Yes"))
                {
                    ModelState.Remove("Token");
                    ModelState.Remove("SecurityCode");

                    model.Pay360PaymentType = Pay360PaymentType.New;
                }
                else if (model.NoCards.Equals("No") && !string.IsNullOrEmpty(model.Token))
                {
                    ModelState.Remove("CardNumber");
                    ModelState.Remove("ExpiryMonth");
                    ModelState.Remove("ExpiryYear");
                    ModelState.Remove("CVV");
                    ModelState.Remove("NameOnCard");
                    ModelState.Remove("StreetAddress");
                    ModelState.Remove("CityTown");
                    ModelState.Remove("Country");
                    ModelState.Remove("Zip");


                    model.Pay360PaymentType = Pay360PaymentType.Token;
                    model.CVV = model.SecurityCode;
                }
                else if (string.IsNullOrEmpty(model.Token) && model.NoCards.Equals("No"))
                {
                    ModelState.Remove("Token");
                    ModelState.Remove("SecurityCode");

                    model.Pay360PaymentType = Pay360PaymentType.ExistingNew;
                }

                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                //Get User
                var user = await UserBL.GetUserById(model.UserId);
                if (user == null)
                {
                    var message = new InAppMessageViewModel() { Message = "User not found" };
                    return View(ErrorView, message);
                }

                //Validate TopUpRequest
                bool isIvalid = await UserBL.IsValidTopUpRequest(user.Id, user.BalanceCurrency, model.Amount);
                if (!isIvalid)
                {
                    var message = new InAppMessageViewModel() { Message = "Your daily topup limit is exceeded" };
                    return View(ErrorView, message);
                }

                model.CustomerEmail = user.Email;
                model.CustomerPhoneNumber = user.PhoneNumber;

                var Pay360PaymentResponse = await Pay360ServiceForInApp.Pay360Payment(await CreatePay360PaymentRequest(model), model.Pay360PaymentType);

                if (Pay360PaymentResponse == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                else if (Pay360PaymentResponse.errorCode > 0)
                {
                    var message = new InAppMessageViewModel();
                    message.Message = ErrorMessage(Pay360PaymentResponse.errorCode);

                    Logger.Error($"Controller: InAppPay360Controller, Method: StartTopUpByCard, Model: {JsonConvert.SerializeObject(model)}, Parameters=> Message: {Pay360PaymentResponse.message}");

                    return View(ErrorView, message);
                }

                var payload = Pay360PaymentResponse.payload;

                string view = string.Format("~/Views/InAppPay360/Redirect3dSecure.cshtml");
                InAppPay360TransactionModel pvm = null;

                if (payload.outcome.reasonCode == "U100")
                {
                    var baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                    string domain = Pay360ServiceForInApp.GetResumeUrl("card/SecureReturnTopUp?UserId=" + user.Id + "&Currency=" + model.Currency, baseUrl);

                    pvm = new InAppPay360TransactionModel
                    {
                        url = payload.clientRedirect.url,
                        pareq = payload.clientRedirect.pareq,
                        type = payload.clientRedirect.type,
                        TransactionId = Pay360PaymentResponse.payload.transactionId,
                        returnUrl = domain
                    };

                    return View(view, pvm);
                }
                else
                {
                    var creditrequest = new DBCredit() { TransactionNumber = Pay360PaymentResponse.payload.transactionId, UseId = user.Id, Amount = Convert.ToInt32(payload.transactionAmount), Currency = model.Currency, type = TopUpType.Pay360 };

                    var creditResponse = await TransferBL.CreditBalance(creditrequest);
                    if (creditResponse > 0)
                    {
                        ViewBag.IsTopUp = true;

                        var isFirstTimeTopUp = (await UserBL.GetCreditHistory(new GetCreditHistoryRequestModel { UserId = user.Id })).payload.CreditHistory.Count() == 1 ? true : false;
                        var message = new InAppMessageViewModel() { Message = "Top Up Balance <br/> Successfully" };

                        message.FirebaseTopUpEvent = new FirebaseUserTopUpEventModel { Currency = model.Currency, Msisdn = user.PhoneNumber, TopUpAmount = payload.transactionAmount, TopUpDateTime = DateTime.UtcNow.ToString(), IsFirstTimeTopUp = isFirstTimeTopUp, TopUpBy = TopUpMethod.Card.ToString() };
                        return View(string.Format("~/Views/InAppPay360/Success.cshtml"), message);
                    }
                    else
                    {
                        var refundResponse = await Pay360ServiceForInApp.RefundFullPayment(new RefundFullPaymentRequestModel()
                        {
                            transactionId = Pay360PaymentResponse.payload.transactionId
                        });

                        if (refundResponse.errorCode == 0)
                        {
                            Logger.Error($"Controller: InAppPay360Controller, Method: StartTopUpByCard, Model: {JsonConvert.SerializeObject(model)}, Parameters=> TransactionId: { Pay360PaymentResponse.payload.transactionId }, Message: Refund successfully");

                            var message = new InAppMessageViewModel() { Message = "Sorry, due to some reasons we couldn't top-up your account. Your payment is refunded." };
                            return View(ErrorView, message);
                        }
                        else
                        {
                            Logger.Error($"Controller: InAppPay360Controller, Method: StartTopUpByCard, Model: {JsonConvert.SerializeObject(model)}, Parameters=> TransactionId: { Pay360PaymentResponse.payload.transactionId }, Message: failed to refund , Refund-Response: {refundResponse.message} ");

                            var message = new InAppMessageViewModel() { Message = "Sorry, due to some reasons we couldn't top-up your account. Please contact customer service." };
                            return View(ErrorView, message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPay360Controller, Method: StartTopUpByCard, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }

        }

        [HttpPost]
        [Route("card/SecureReturnTopUp")]
        public async Task<IActionResult> SecureReturnTopup(InAppSecure3DTopUpViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                Pay360Resume3DRequest request = new Pay360Resume3DRequest
                {
                    pareq = model.PaRes,
                    pay360TransactionId = model.MD
                };

                var response = await Pay360ServiceForInApp.Resume3DTransaction(request);

                if (response == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                else if (response.errorCode > 0)
                {
                    var message = new InAppMessageViewModel();
                    message.Message = ErrorMessage(response.errorCode);

                    Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnTopup, Model: {JsonConvert.SerializeObject(model)}, Parameters=> Message: {response.message}");

                    return View(ErrorView, message);
                }
                else
                {
                    var creditRequest = new DBCredit() { TransactionNumber = response.payload.transactionId, Amount = Convert.ToDecimal(response.payload.transactionAmount), Currency = model.Currency, type = TopUpType.Pay360, UseId = model.UserId };
                    var creditResponse = await TransferBL.CreditBalance(creditRequest);
                    if (creditResponse > 0)
                    {
                        ViewBag.IsTopUp = true;

                        var user = await UserBL.GetUserById(model.UserId);
                        var isFirstTimeTopUp = (await UserBL.GetCreditHistory(new GetCreditHistoryRequestModel { UserId = model.UserId })).payload.CreditHistory.Count() == 1 ? true : false;

                        var message = new InAppMessageViewModel() { Message = "Top Up Balance <br/> Successfully" };
                        message.FirebaseTopUpEvent = new FirebaseUserTopUpEventModel { Currency = model.Currency, Msisdn = user.PhoneNumber, TopUpAmount = response.payload.transactionAmount, TopUpDateTime = DateTime.UtcNow.ToString(), IsFirstTimeTopUp = isFirstTimeTopUp, TopUpBy = TopUpMethod.Card.ToString() };

                        return View(string.Format("~/Views/InAppPay360/Success.cshtml"), message);
                    }
                    else
                    {
                        var refundResponse = await Pay360ServiceForInApp.RefundFullPayment(new RefundFullPaymentRequestModel()
                        {
                            transactionId = response.payload.transactionId
                        });

                        if (refundResponse.errorCode == 0)
                        {
                            Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnTopup, Parameters=> UserId:{ model.UserId }, TransactionId: { response.payload.transactionId }, Message: Refund successfully");

                            var message = new InAppMessageViewModel() { Message = "Sorry, due to some reasons we couldn't top-up your account. Your payment is refunded." };
                            return View(ErrorView, message);
                        }
                        else
                        {
                            Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnTopup, Parameters=> UserId:{ model.UserId },TransactionId: { response.payload.transactionId }, Message: failed to refund, Refund-Response: {refundResponse.message} ");

                            var message = new InAppMessageViewModel() { Message = "Sorry, due to some reasons we couldn't top-up your account. Please contact customer service." };
                            return View(ErrorView, message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnTopup, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }



        /// <summary>
        /// Required Bearer
        /// </summary>
        [Route("card/transfer")]
        [HttpGet]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<ActionResult> Transfer(InAppPay360TransferRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                var allRegions = CultureInfo.GetCultures(CultureTypes.SpecificCultures).Select(x => new RegionInfo(x.LCID));
                var currencySymbol = allRegions.FirstOrDefault(region => region.ISOCurrencySymbol == model.Currency)?.CurrencySymbol;

                var userId = Convert.ToInt32(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value);
                var user = await UserBL.GetUserById(userId);

                if (user == null)
                {
                    var message = new InAppMessageViewModel() { Message = "User not found" };
                    return View(ErrorView, message);
                }

                model.FromMSISDN = user.PhoneNumber;

                var viewmodel = new InAppPay360TransferViewModel()
                {
                    UserId = userId,
                    Amount = model.Amount,
                    Currency = model.Currency,
                    NowtelTransactionReference = model.NowtelTransactionReference,
                    Operatorid = model.Operatorid,
                    Product = model.Product,
                    FromMSISDN = model.FromMSISDN,
                    MessageToRecipient = model.MessageToRecipient,
                    CurrencySymbol = currencySymbol
                };

                //Get Customers (Cards)
                var customer = await Pay360ServiceForInApp.GetCutomerInfo(userId);
                if (customer == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                if (customer.Item2 == 0)
                {
                    viewmodel.Customer = customer.Item1;
                    return View("TransferCheckOut", viewmodel);
                }
                else
                {
                    return View("TransferCheckOut", viewmodel);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPay360Controller, Method: Transfer, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }

        [Route("card/starttransfercard")]
        [HttpPost]
        public async Task<ActionResult> StartTransferCard(InAppPay360CardPostModel model)
        {
            try
            {
                if (model.NoCards.Equals("Yes"))
                {
                    ModelState.Remove("Token");
                    ModelState.Remove("SecurityCode");

                    model.Pay360PaymentType = Pay360PaymentType.New;
                }
                else if (model.NoCards.Equals("No") && !string.IsNullOrEmpty(model.Token))
                {
                    ModelState.Remove("CardNumber");
                    ModelState.Remove("ExpiryMonth");
                    ModelState.Remove("ExpiryYear");
                    ModelState.Remove("CVV");
                    ModelState.Remove("NameOnCard");
                    ModelState.Remove("StreetAddress");
                    ModelState.Remove("CityTown");
                    ModelState.Remove("Country");
                    ModelState.Remove("Zip");

                    model.Pay360PaymentType = Pay360PaymentType.Token;
                    model.CVV = model.SecurityCode;
                }
                else if (string.IsNullOrEmpty(model.Token) && model.NoCards.Equals("No"))
                {
                    ModelState.Remove("Token");
                    ModelState.Remove("SecurityCode");

                    model.Pay360PaymentType = Pay360PaymentType.ExistingNew;
                }

                model.IPAddress = ExtensionMethods.GetRemoteIPAddress(HttpContext);

                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                var TransferTransactionDb = await TransferBL.GetTransferTransactionByNowtelTransactionReference(model.nowtelTransactionReference, model.product);
                if (TransferTransactionDb != null)
                {
                    if (model.Currency != TransferTransactionDb.fromCurrency || Convert.ToDecimal(model.Amount) < Convert.ToDecimal(TransferTransactionDb.CustomerChargeValue))
                    {
                        var message = new InAppMessageViewModel() { Message = "Payment amount or currency do not match transfer amount or currency" };
                        return View(ErrorView, message);
                    }
                }
                else
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                var user = await UserBL.GetUserById(model.UserId);
                if (user == null)
                {
                    var message = new InAppMessageViewModel() { Message = "User not found" };
                    return View(ErrorView, message);
                }

                model.CustomerEmail = user.Email;
                model.CustomerPhoneNumber = user.PhoneNumber;


                //validate request 
                int validateResponse = await TransferBL.ValidateTrasnferRequest(model.UserId, model.Amount);
                if (validateResponse > 0)
                {
                    var message = new InAppMessageViewModel() { Message = "You have exceeded your daily limit" };
                    return View(ErrorView, message);
                }


                var Pay360PaymentResponse = await Pay360ServiceForInApp.Pay360Payment(await CreatePay360PaymentRequest(model), model.Pay360PaymentType);

                if (Pay360PaymentResponse == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                else if (Pay360PaymentResponse.errorCode > 0)
                {
                    var message = new InAppMessageViewModel();
                    message.Message = ErrorMessage(Pay360PaymentResponse.errorCode);

                    Logger.Error($"Controller: InAppPay360Controller, Method: StartTransferCard, Model: {JsonConvert.SerializeObject(model)}, Parameters=> Message: {Pay360PaymentResponse.message}");

                    return View(ErrorView, message);
                }

                var payload = Pay360PaymentResponse.payload;

                string view = string.Format("~/Views/InAppPay360/Redirect3dSecure.cshtml");
                InAppPay360TransactionModel pvm = null;


                var userId = model.UserId;

                if (payload.outcome.reasonCode == "U100")
                {
                    var baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                    string domain = Pay360ServiceForInApp.GetResumeUrl("card/SecureReturnTransfer?Ref=" + userId + "&NowtelTransactionRef=" + model.nowtelTransactionReference + "&Product=" + model.product + "&OperatorId=" + model.operatorid + "&MessageToRecipient=" + model.messageToRecipient + "&FromMSISDN=" + model.fromMSISDN, baseUrl);

                    pvm = new InAppPay360TransactionModel
                    {
                        url = payload.clientRedirect.url,
                        pareq = payload.clientRedirect.pareq,
                        type = payload.clientRedirect.type,
                        TransactionId = Pay360PaymentResponse.payload.transactionId,
                        returnUrl = domain
                    };

                    return View(view, pvm);
                }
                else
                {
                    var request = new ExecuteDirectTransferRequestModel
                    {
                        nowtelTransactionReference = model.nowtelTransactionReference,
                        product = model.product,
                        fromMSISDN = model.fromMSISDN,
                        messageToRecipient = model.messageToRecipient,
                        operatorid = model.operatorid,
                        UserId = user.Id,
                        TransactionType = TransferTransactionType.TRHDT,
                        PaymentType = PaymentType.Card
                    };

                    try
                    {
                        var TransferResponse = await TransferBL.ExecuteDirectTransfer(request);

                        if (TransferResponse.errorCode == 0)
                        {
                            ViewBag.IsTopUp = false;

                            var message = new InAppMessageViewModel() { Message = TransferResponse.message };
                            message.FirebaseTransferEvent = new FirebaseUserTransferEventModel { TransferAmountCurrency = TransferResponse.payload.transferAmountCurrency, Msisdn = user.PhoneNumber, TransferAmount = payload.transactionAmount, TransferDateTime = DateTime.UtcNow.ToString(), DestinationNumber = TransferResponse.payload.DestinationMsisdn, TransferFrom = TopUpMethod.Card.ToString(), DestinationCountry = TransferResponse.payload.DestinationCountry, OperatorName = TransferResponse.payload.OperatorName };

                            return View(string.Format("~/Views/InAppPay360/Success.cshtml"), message);
                        }
                        else
                        {
                            var refundResponse = await Pay360ServiceForInApp.RefundFullPayment(new RefundFullPaymentRequestModel()
                            {
                                transactionId = Pay360PaymentResponse.payload.transactionId
                            });

                            if (refundResponse.errorCode == 0)
                            {
                                Logger.Error($"Controller: InAppPay360Controller, Method: StartTransferCard, Parameters=> Model: {JsonConvert.SerializeObject(model)}, TransactionId: { Pay360PaymentResponse.payload.transactionId }, Message: Refund successfully - TransferResponse: {TransferResponse.message}");

                                var message = new InAppMessageViewModel();

                                if (TransferResponse.errorCode == (int)ApiStatusCodes.TopupNumberLimitExceed
                                               || TransferResponse.errorCode == (int)ApiStatusCodes.TopupAmountLimitExceed
                                               || TransferResponse.errorCode == (int)ApiStatusCodes.DenominationBlocked
                                               || TransferResponse.errorCode == (int)ApiStatusCodes.DenominationsNotAvailable
                                               || TransferResponse.errorCode == (int)ApiStatusCodes.OperatorBlocked
                                               )
                                {
                                    message.Message = TransferResponse.message + "<br/> Sorry, we couldn't transfer your balance. Your payment is refunded.";
                                }
                                else
                                {
                                    message.Message = "Sorry, due to some reasons we couldn't transfer your balance. Your payment is refunded.";
                                }

                                return View(ErrorView, message);
                            }
                            else
                            {
                                Logger.Error($"Controller: InAppPay360Controller, Method: StartTransferCard, Parameters=> Model: {JsonConvert.SerializeObject(model)}, TransactionId: { Pay360PaymentResponse.payload.transactionId }, Message: failed to refund  - TransferResponse: {TransferResponse.message}: Refund Response: {refundResponse.message}");

                                var message = new InAppMessageViewModel();
                                if (TransferResponse.errorCode == (int)ApiStatusCodes.TopupNumberLimitExceed
                                                     || TransferResponse.errorCode == (int)ApiStatusCodes.TopupAmountLimitExceed
                                                     || TransferResponse.errorCode == (int)ApiStatusCodes.DenominationBlocked
                                                     || TransferResponse.errorCode == (int)ApiStatusCodes.DenominationsNotAvailable
                                                     || TransferResponse.errorCode == (int)ApiStatusCodes.OperatorBlocked
                                                     )
                                {
                                    message.Message = TransferResponse.message + "<br/> Sorry, we couldn't transfer your balance. Please contact customer service.";
                                }
                                else
                                {
                                    message.Message = "Sorry, due to some reasons we couldn't transfer your balance. Please contact customer service.";
                                }

                                return View(ErrorView, message);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Controller: InAppPay360Controller, Method: StartTransferCard, Parameters=> Model: {JsonConvert.SerializeObject(request)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                        var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                        return View(ErrorView, message);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPay360Controller, Method: StartTransferCard, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }

        [HttpPost]
        [Route("card/SecureReturnTransfer")]
        public async Task<IActionResult> SecureReturnTransfer(InAppSercure3DTransferViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                Pay360Resume3DRequest request = new Pay360Resume3DRequest
                {
                    pareq = model.PaRes,
                    pay360TransactionId = model.MD
                };

                var response = await Pay360ServiceForInApp.Resume3DTransaction(request);
                if (response == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }
                if (response.errorCode > 0)
                {
                    var message = new InAppMessageViewModel();
                    message.Message = ErrorMessage(response.errorCode);

                    return View(ErrorView, message);
                }
                else
                {
                    var TransferRequest = new ExecuteDirectTransferRequestModel
                    {
                        nowtelTransactionReference = model.NowtelTransactionRef,
                        product = model.Product,
                        fromMSISDN = model.FromMSISDN,
                        messageToRecipient = model.MessageToRecipient,
                        operatorid = model.OperatorId,
                        UserId = model.Ref,
                        TransactionType = TransferTransactionType.TRHDT,
                        PaymentType = PaymentType.Card
                    };

                    try
                    {
                        var transferResponse = await TransferBL.ExecuteDirectTransfer(TransferRequest);

                        if (transferResponse.errorCode == 0)
                        {
                            ViewBag.IsTopUp = false;

                            var message = new InAppMessageViewModel() { Message = transferResponse.message };
                            message.FirebaseTransferEvent = new FirebaseUserTransferEventModel { TransferAmountCurrency = transferResponse.payload.transferAmountCurrency, Msisdn = model.FromMSISDN, TransferAmount = response.payload.transactionAmount, TransferDateTime = DateTime.UtcNow.ToString(), DestinationNumber = transferResponse.payload.DestinationMsisdn, TransferFrom = TopUpMethod.Card.ToString(), DestinationCountry = transferResponse.payload.DestinationCountry, OperatorName = transferResponse.payload.OperatorName };

                            return View(string.Format("~/Views/InAppPay360/Success.cshtml"), message);
                        }
                        else
                        {
                            var refundResponse = await Pay360ServiceForInApp.RefundFullPayment(new RefundFullPaymentRequestModel()
                            {
                                transactionId = response.payload.transactionId
                            });

                            if (refundResponse.errorCode == 0)
                            {
                                Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnTransfer, Parameters=> Model: {JsonConvert.SerializeObject(model)}, TransactionId: { response.payload.transactionId }, Message: Refund successfully - TransferResponse: {transferResponse.message}");

                                var message = new InAppMessageViewModel();

                                if (transferResponse.errorCode == (int)ApiStatusCodes.TopupNumberLimitExceed
                                               || transferResponse.errorCode == (int)ApiStatusCodes.TopupAmountLimitExceed
                                               || transferResponse.errorCode == (int)ApiStatusCodes.DenominationBlocked
                                               || transferResponse.errorCode == (int)ApiStatusCodes.DenominationsNotAvailable
                                               || transferResponse.errorCode == (int)ApiStatusCodes.OperatorBlocked)
                                {
                                    message.Message = transferResponse.message + "<br/> Sorry, we couldn't transfer your balance. Your payment is refunded.";
                                }
                                else
                                {
                                    message.Message = "Sorry, due to some reasons we couldn't transfer your balance. Your payment is refunded.";
                                }

                                return View(ErrorView, message);
                            }
                            else
                            {
                                Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnTransfer, Parameters=> Model: {JsonConvert.SerializeObject(model)}, TransactionId: { response.payload.transactionId }, Message: failed to refund - TransferResponse: {transferResponse.message}: Refund Response: {refundResponse.message}");

                                var message = new InAppMessageViewModel();
                                if (transferResponse.errorCode == (int)ApiStatusCodes.TopupNumberLimitExceed
                                                     || transferResponse.errorCode == (int)ApiStatusCodes.TopupAmountLimitExceed
                                                     || transferResponse.errorCode == (int)ApiStatusCodes.DenominationBlocked
                                                     || transferResponse.errorCode == (int)ApiStatusCodes.DenominationsNotAvailable
                                                     || transferResponse.errorCode == (int)ApiStatusCodes.OperatorBlocked)
                                {
                                    message.Message = transferResponse.message + "<br/> Sorry, we couldn't transfer your balance. Please contact customer service.";
                                }
                                else
                                {
                                    message.Message = "Sorry, due to some reasons we couldn't transfer your balance. Please contact customer service.";
                                }

                                return View(ErrorView, message);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Controller: InAppPay360Controller, Method: StartTransferCard, Parameters=> Model: {JsonConvert.SerializeObject(TransferRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                        var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                        return View(ErrorView, message);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnTransfer, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }



        /// <summary>
        /// Required Bearer
        /// </summary>
        [Route("card/autotransfer")]
        [HttpGet]
        [Authorize]
        public async Task<ActionResult> AutoTransfer(InAppAutoTransferRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                var userId = Convert.ToInt32(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value);
                var user = await UserBL.GetUserById(userId);

                if (user == null)
                {
                    var message = new InAppMessageViewModel() { Message = "User not found" };
                    return View(ErrorView, message);
                }

                //From Msisdn is replaced with User Phonenumber
                model.fromMSISDN = user.PhoneNumber;

                var allRegions = CultureInfo.GetCultures(CultureTypes.SpecificCultures).Select(x => new RegionInfo(x.LCID));
                var currencySymbol = allRegions.FirstOrDefault(region => region.ISOCurrencySymbol == model.Currency)?.CurrencySymbol;

                var viewModel = new InAppAutoTransferViewModel()
                {
                    Amount = model.Amount,
                    Currency = model.Currency,
                    CurrencySymbol = currencySymbol,
                    UserId = userId,

                    NowtelTransactionReference = model.nowtelTransactionReference,
                    Operatorid = model.operatorid,
                    Product = model.product,
                    FromMSISDN = model.fromMSISDN,
                    MessageToRecipient = model.messageToRecipient,
                    RegularityType = model.RegularityType
                };

                var customer = await Pay360ServiceForInApp.GetCutomerInfo(userId);

                if (customer == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                if (customer.Item2 == 0) //Check Error Code
                {
                    viewModel.Customer = customer.Item1;
                    return View("AutoTransferCheckOut", viewModel);
                }
                else
                {
                    return View("AutoTransferCheckOut", viewModel);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPay360Controller, Method: AutoTransfer, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [Route("card/setautotransfer")]
        [HttpPost]
        public async Task<ActionResult> SetAutoTransfer(InAppSetAutoTransferRequestModel model)
        {
            try
            {
                var autotransferModel = new SaveAutoTransferSettingsRequestModel()
                {
                    RequestDateTime = DateTime.UtcNow
                };

                if (model.CardData.NoCards.Equals("Yes"))
                {
                    ModelState.Remove("CardData.Token");
                    ModelState.Remove("CardData.SecurityCode");

                    model.CardData.Pay360PaymentType = Pay360PaymentType.New;
                }
                else if (model.CardData.NoCards.Equals("No") && !string.IsNullOrEmpty(model.CardData.Token))
                {
                    ModelState.Remove("CardData.CardNumber");
                    ModelState.Remove("CardData.ExpiryMonth");
                    ModelState.Remove("CardData.ExpiryYear");
                    ModelState.Remove("CardData.CVV");
                    ModelState.Remove("CardData.NameOnCard");
                    ModelState.Remove("CardData.StreetAddress");
                    ModelState.Remove("CardData.CityTown");
                    ModelState.Remove("CardData.Country");
                    ModelState.Remove("CardData.Zip");

                    model.CardData.Pay360PaymentType = Pay360PaymentType.Token;
                    model.CardData.CVV = model.CardData.SecurityCode;
                }
                else if (string.IsNullOrEmpty(model.CardData.Token) && model.CardData.NoCards.Equals("No"))
                {
                    ModelState.Remove("CardData.Token");
                    ModelState.Remove("CardData.SecurityCode");

                    model.CardData.Pay360PaymentType = Pay360PaymentType.ExistingNew;
                }

                model.CardData.IPAddress = ExtensionMethods.GetRemoteIPAddress(HttpContext);

                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                var TransferTransactionDb = await TransferBL.GetTransferTransactionByNowtelTransactionReference(model.CardData.nowtelTransactionReference, model.CardData.product);
                if (TransferTransactionDb != null)
                {
                    if (model.CardData.Currency != TransferTransactionDb.fromCurrency || Convert.ToDecimal(model.CardData.Amount) < Convert.ToDecimal(TransferTransactionDb.CustomerChargeValue))
                    {
                        var message = new InAppMessageViewModel() { Message = "Payment amount or currency do not match transfer amount or currency" };
                        return View(ErrorView, message);
                    }
                }
                else
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                var user = await UserBL.GetUserById(model.CardData.UserId);
                if (user == null)
                {
                    var message = new InAppMessageViewModel() { Message = "User not found" };
                    return View(ErrorView, message);
                }

                model.CardData.CustomerEmail = user.Email;
                model.CardData.CustomerPhoneNumber = user.PhoneNumber;
                model.CardData.CheckOutType = CheckOutTypes.DirectTransfer;

                var Pay360PaymentResponse = await Pay360ServiceForInApp.Pay360Payment(await CreatePay360PaymentRequest(model.CardData), model.CardData.Pay360PaymentType);

                if (Pay360PaymentResponse == null)
                {
                    var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                    return View(ErrorView, message);
                }

                else if (Pay360PaymentResponse.errorCode > 0)
                {
                    var message = new InAppMessageViewModel();
                    message.Message = ErrorMessage(Pay360PaymentResponse.errorCode);

                    return View(ErrorView, message);
                }

                var payload = Pay360PaymentResponse.payload;

                string view = string.Format("~/Views/InAppPay360/Redirect3dSecure.cshtml");
                InAppPay360TransactionModel pvm = null;


                var userId = model.CardData.UserId;

                if (payload.outcome.reasonCode == "U100")
                {
                    var baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                    string domain = Pay360ServiceForInApp.GetResumeUrl("card/SecureReturnAutoTransfer?RegularityType=" + (int)model.RegularityType + "&RequestDatetime=" + autotransferModel.RequestDateTime + "&Ref=" + userId + "&NowtelTransactionRef=" + model.CardData.nowtelTransactionReference + "&Product=" + model.CardData.product + "&OperatorId=" + model.CardData.operatorid + "&MessageToRecipient=" + model.CardData.messageToRecipient + "&FromMSISDN=" + model.CardData.fromMSISDN, baseUrl);

                    pvm = new InAppPay360TransactionModel
                    {
                        url = payload.clientRedirect.url,
                        pareq = payload.clientRedirect.pareq,
                        type = payload.clientRedirect.type,
                        TransactionId = Pay360PaymentResponse.payload.transactionId,
                        returnUrl = domain
                    };

                    return View(view, pvm);
                }
                else
                {
                    var request = new ExecuteDirectTransferRequestModel
                    {
                        nowtelTransactionReference = model.CardData.nowtelTransactionReference,
                        product = model.CardData.product,
                        fromMSISDN = model.CardData.fromMSISDN,
                        messageToRecipient = model.CardData.messageToRecipient,
                        operatorid = model.CardData.operatorid,
                        UserId = user.Id,
                        TransactionType = TransferTransactionType.TRHDT,
                        PaymentType = PaymentType.Card
                    };
                    var response = await TransferBL.ExecuteDirectTransfer(request);

                    if (response == null)
                    {
                        var message = new InAppMessageViewModel() { Message = "This service is currently unavailable. Please try again later." };
                        return View(ErrorView, message);
                    }

                    if (response.errorCode == 0)
                    {
                        autotransferModel.LastTransactionExecutionDateTime = DateTime.UtcNow;
                        autotransferModel.RegularityType = model.RegularityType;
                        autotransferModel.fromMSISDN = model.CardData.fromMSISDN;
                        autotransferModel.messageToRecipient = model.CardData.messageToRecipient;
                        autotransferModel.nowtelTransactionReference = model.CardData.nowtelTransactionReference;
                        autotransferModel.operatorid = model.CardData.operatorid;
                        autotransferModel.PaymentType = PaymentType.Card;
                        autotransferModel.product = model.CardData.product;

                        var autoTransferResponse = await TransferBL.SaveAutoTransferSettings(autotransferModel, userId);

                        if (autoTransferResponse.errorCode == 0)
                        {
                            var message = new InAppMessageViewModel() { Message = "Auto Transfer Saved Successfully" };
                            return View(string.Format("~/Views/InAppPay360/Success.cshtml"), message);
                        }
                        else
                        {
                            Logger.Error($"Controller: InAppPay360Controller, Method: SetAutoTransfer, Parameters=> UserId:{JsonConvert.SerializeObject(autotransferModel)}, TransactionId: { Pay360PaymentResponse.payload.transactionId }, Message: Auto Transfer not enabled ");

                            var message = new InAppMessageViewModel() { Message = "Transfer Successfull, Failed to enable Auto Transfer" };
                            return View(string.Format("~/Views/InAppPay360/Success.cshtml"), message);
                        }
                    }
                    else
                    {
                        var refundResponse = await Pay360ServiceForInApp.RefundFullPayment(new RefundFullPaymentRequestModel()
                        {
                            transactionId = Pay360PaymentResponse.payload.transactionId
                        });

                        if (refundResponse.errorCode == 0)
                        {
                            Logger.Error($"Controller: InAppPay360Controller, Method: SetAutoTransfer, Parameters=> UserId:{ model.CardData.UserId }, TransactionId: { Pay360PaymentResponse.payload.transactionId }, Message: Refund successfully, TransferResponse: {response.message}");

                            var message = new InAppMessageViewModel();

                            if (response.errorCode == (int)ApiStatusCodes.TopupNumberLimitExceed
                                                   || response.errorCode == (int)ApiStatusCodes.TopupAmountLimitExceed
                                                   || response.errorCode == (int)ApiStatusCodes.DenominationBlocked
                                                   || response.errorCode == (int)ApiStatusCodes.DenominationsNotAvailable
                                                   || response.errorCode == (int)ApiStatusCodes.OperatorBlocked)
                            {
                                message.Message = response.message + "<br/> Sorry, we couldn't transfer your balance. Your payment is refunded.";
                            }
                            else
                            {
                                message.Message = "Sorry, due to some reasons we couldn't transfer your balance. Your payment is refunded.";
                            }

                            return View(ErrorView, message);
                        }
                        else
                        {
                            Logger.Error($"Controller: InAppPay360Controller, Method: SetAutoTransfer, Parameters => UserId:{ model.CardData.UserId }, TransactionId: { Pay360PaymentResponse.payload.transactionId }, Message: failed to refund, TransferResponse: {response.message}, RefundResponse:{refundResponse.message} ");

                            var message = new InAppMessageViewModel();

                            if (response.errorCode == (int)ApiStatusCodes.TopupNumberLimitExceed
                                                        || response.errorCode == (int)ApiStatusCodes.TopupAmountLimitExceed
                                                        || response.errorCode == (int)ApiStatusCodes.DenominationBlocked
                                                        || response.errorCode == (int)ApiStatusCodes.DenominationsNotAvailable
                                                        || response.errorCode == (int)ApiStatusCodes.OperatorBlocked)
                            {
                                message.Message = response.message + "Sorry, we couldn't transfer your balance. Please contact customer service.";
                            }
                            else
                            {
                                message.Message = "Sorry, due to some reasons we couldn't transfer your balance. Please contact customer service.";
                            }

                            return View(ErrorView, message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPay360Controller, Method: SetAutoTransfer, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }

        /// <summary>
        /// Allow Anonymus
        /// </summary>
        [HttpPost]
        [Route("card/SecureReturnAutoTransfer")]
        public async Task<IActionResult> SecureReturnAutoTransfer(InAppSecure3DAutoTransferRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var message = new InAppMessageViewModel() { Message = "Invalid Parameters" };
                    return View(ErrorView, message);
                }

                Pay360Resume3DRequest request = new Pay360Resume3DRequest
                {
                    pareq = model.PaRes,
                    pay360TransactionId = model.MD
                };

                var response = await Pay360ServiceForInApp.Resume3DTransaction(request);
                if (response == null)
                {
                    var message = new InAppMessageViewModel() { Message = "Payment service is not responding" };
                    return View(ErrorView, message);
                }
                if (response.errorCode > 0)
                {
                    var message = new InAppMessageViewModel();
                    message.Message = ErrorMessage(response.errorCode);

                    return View(ErrorView, message);
                }
                else
                {
                    var TransferRequest = new ExecuteDirectTransferRequestModel
                    {
                        nowtelTransactionReference = model.NowtelTransactionRef,
                        product = model.Product,
                        fromMSISDN = model.FromMSISDN,
                        messageToRecipient = model.MessageToRecipient,
                        operatorid = model.OperatorId,
                        UserId = model.Ref,
                        TransactionType = TransferTransactionType.TRHDT,
                        PaymentType = PaymentType.Card
                    };

                    var transferResponse = await TransferBL.ExecuteDirectTransfer(TransferRequest);
                    if (transferResponse == null)
                    {
                        var message = new InAppMessageViewModel() { Message = "Payment Service not responding." };
                        return View(ErrorView, message);
                    }

                    if (transferResponse.errorCode == 0)
                    {
                        var autotransferModel = new SaveAutoTransferSettingsRequestModel()
                        {
                            LastTransactionExecutionDateTime = DateTime.UtcNow,
                            RegularityType = model.RegularityType,
                            fromMSISDN = model.FromMSISDN,
                            messageToRecipient = model.MessageToRecipient,
                            nowtelTransactionReference = model.NowtelTransactionRef,
                            RequestDateTime = model.RequestDatetime,
                            operatorid = model.OperatorId,
                            PaymentType = PaymentType.Card,
                            product = model.Product,
                        };

                        var autoTransferResponse = await TransferBL.SaveAutoTransferSettings(autotransferModel, model.Ref);

                        if (autoTransferResponse.errorCode == 0)
                        {
                            var message = new InAppMessageViewModel() { Message = "Auto Transfer Saved Successfully" };
                            return View(string.Format("~/Views/InAppPay360/Success.cshtml"), message);
                        }
                        else
                        {
                            Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnAutoTransfer, Parameters=> UserId:{JsonConvert.SerializeObject(autotransferModel)}, TransactionId: { response.payload.transactionId }, Message: Auto Transfer not enabled ");

                            var message = new InAppMessageViewModel() { Message = "Transfer Successfull, Failed to enable Auto Transfer" };
                            return View(string.Format("~/Views/InAppPay360/Success.cshtml"), message);
                        }
                    }
                    else
                    {
                        var refundResponse = await Pay360ServiceForInApp.RefundFullPayment(new RefundFullPaymentRequestModel()
                        {
                            transactionId = response.payload.transactionId
                        });

                        if (refundResponse.errorCode == 0)
                        {
                            Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnAutoTransfer, Parameters=> UserId:{ model.Ref}, TransactionId: { response.payload.transactionId }, Message: Refund successfully : TransferResponse: {transferResponse.message}");

                            var message = new InAppMessageViewModel();

                            if (response.errorCode == (int)ApiStatusCodes.TopupNumberLimitExceed
                                                    || response.errorCode == (int)ApiStatusCodes.TopupAmountLimitExceed
                                                    || response.errorCode == (int)ApiStatusCodes.DenominationBlocked
                                                    || response.errorCode == (int)ApiStatusCodes.DenominationsNotAvailable
                                                    || response.errorCode == (int)ApiStatusCodes.OperatorBlocked)
                            {
                                message.Message = response.message + "<br/> Sorry, we couldn't transfer your balance. Your payment is refunded.";
                            }
                            else
                            {
                                message.Message = "Sorry, due to some reasons we couldn't transfer your balance. Your payment is refunded.";
                            }

                            return View(ErrorView, message);
                        }
                        else
                        {
                            Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnAutoTransfer, Parameters=> UserId:{ model.Ref }, TransactionId: { response.payload.transactionId }, Message: failed to refund: TransferResponse: {transferResponse.message}: RefundResponse: { refundResponse.message}");

                            var message = new InAppMessageViewModel();

                            if (response.errorCode == (int)ApiStatusCodes.TopupNumberLimitExceed
                                                    || response.errorCode == (int)ApiStatusCodes.TopupAmountLimitExceed
                                                    || response.errorCode == (int)ApiStatusCodes.DenominationBlocked
                                                    || response.errorCode == (int)ApiStatusCodes.DenominationsNotAvailable
                                                    || response.errorCode == (int)ApiStatusCodes.OperatorBlocked)
                            {
                                message.Message = response.message + "Sorry, we couldn't transfer your balance. Please contact customer service.";
                            }
                            else
                            {
                                message.Message = "Sorry, due to some reasons we couldn't transfer your balance. Please contact customer service.";
                            }

                            return View(ErrorView, message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: InAppPay360Controller, Method: SecureReturnAutoTransfer, Parameters=> Model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");

                var message = new InAppMessageViewModel() { Message = "There has been an error. Please try again later." };
                return View(ErrorView, message);
            }
        }

        private async Task<Pay360PaymentRequest> CreatePay360PaymentRequest(InAppPay360CardPostModel model)
        {
            List<basket> baskets = new List<basket>();

            basket basket = new basket()
            {
                amount = model.Amount,
                bundleRef = "",
                productItemCode = model.CheckOutType == CheckOutTypes.DirectTransfer ? ProductItemCode.TRHDT.ToString() : ProductItemCode.TRHAT.ToString(),
                productRef = ""
            };

            baskets.Add(basket);

            Pay360PaymentRequest request = new Pay360PaymentRequest();
            switch (model.Pay360PaymentType)
            {
                case Pay360PaymentType.New:
                    var PaymentNewBaseRequest = Pay360ServiceForInApp.CreatePay360PaymentRequestNew(model);
                    request.Pay360PaymentRequestNew = PaymentNewBaseRequest;
                    request.Pay360PaymentRequestNew.basket = baskets;
                    request.Pay360PaymentRequestNew.customerMsisdn = model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestNew.customerUniqueRef = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestNew.customerEmail = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : string.Empty;
                    request.Pay360PaymentRequestNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestNew.ipAddress = ExtensionMethods.GetRemoteIPAddress(HttpContext);
                    request.Pay360PaymentRequestNew.productCode = ProductCode.TRH.ToString();
                    request.Pay360PaymentRequestNew.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestNew.SaveCard = model.IsRegistered;
                    break;
                case Pay360PaymentType.Token:
                    var PaymentTokenBaseRequest = Pay360ServiceForInApp.CreatePay360PaymentRequestToken(model);
                    request.Pay360PaymentRequestToken = PaymentTokenBaseRequest;
                    request.Pay360PaymentRequestToken.basket = baskets;
                    request.Pay360PaymentRequestToken.customerMsisdn = model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestToken.customerUniqueRef = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestToken.customerEmail = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : string.Empty;
                    request.Pay360PaymentRequestToken.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestToken.ipAddress = ExtensionMethods.GetRemoteIPAddress(HttpContext);
                    request.Pay360PaymentRequestToken.productCode = ProductCode.TRH.ToString();
                    request.Pay360PaymentRequestToken.cardCv2 = model.CVV;
                    request.Pay360PaymentRequestToken.transactionAmount = model.Amount;
                    break;
                case Pay360PaymentType.ExistingNew:
                    var PaymentExistingNewBaseRequest = Pay360ServiceForInApp.CreatePay360PaymentRequestExistingNew(model);
                    request.Pay360PaymentRequestExistingNew = PaymentExistingNewBaseRequest;
                    request.Pay360PaymentRequestExistingNew.basket = baskets;
                    request.Pay360PaymentRequestExistingNew.customerMsisdn = model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestExistingNew.customerUniqueRef = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : model.CustomerPhoneNumber;
                    request.Pay360PaymentRequestExistingNew.customerEmail = !string.IsNullOrEmpty(model.CustomerEmail) ? model.CustomerEmail : string.Empty;
                    request.Pay360PaymentRequestExistingNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestExistingNew.ipAddress = ExtensionMethods.GetRemoteIPAddress(HttpContext);
                    request.Pay360PaymentRequestExistingNew.productCode = ProductCode.TRH.ToString();
                    request.Pay360PaymentRequestExistingNew.cardCv2 = model.CVV;
                    request.Pay360PaymentRequestExistingNew.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestExistingNew.SaveCard = model.IsRegistered;
                    break;
            }
            return request;
        }

        private string ErrorMessage(int errorCode)
        {
            var ErrorCodes = new int[] { 5, 11, 22, 27 };

            if (ErrorCodes.Contains(errorCode))
            {
                return ApiMessage.ResourceManager.GetString(Enum.GetName(typeof(PaymentAPIStatusCodes), errorCode));
            }
            else
            {
                return "This service is currently unavailable. Please try again later.";
            }
        }
    }
}
