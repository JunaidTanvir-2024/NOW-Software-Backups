﻿using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IHslSms_BL
    {
        Task<SmsResult> Send1(string sentFrom, string sentTo, string message, bool paid, bool isSignupPinSms = false, string language = "en");
    }
}
