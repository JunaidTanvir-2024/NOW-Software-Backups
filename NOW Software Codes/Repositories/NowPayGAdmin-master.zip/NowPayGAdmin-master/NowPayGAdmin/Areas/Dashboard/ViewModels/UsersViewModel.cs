﻿using BasketWebPanel.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.Areas.Dashboard.ViewModels
{
    public class UserViewModel
    {
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Address { get; set; }
        public int CountryId { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public bool IsEmailVerified { get; set; }
        public int SocialSignUpTypeId { get; set; }
        public DateTime CreatedDatetime { get; set; }
        public bool IsActive { get; set; }
    }
    public class UserAddressViewModel
    {
        public int ID { get; set; }
        public int UserID { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string County { get; set; }
        public string PostCode { get; set; }
        public string Country { get; set; }
        public int AddressTypeID { get; set; }
    }

    public class UserDetailBindingModel : BaseViewModel
    {
        public UserViewModel userData { get; set; }
        public IEnumerable<UserAddressViewModel> userAddressList { get; set; }

    }
}