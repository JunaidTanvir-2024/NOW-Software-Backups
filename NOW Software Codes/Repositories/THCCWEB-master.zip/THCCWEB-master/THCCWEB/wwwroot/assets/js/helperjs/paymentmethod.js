﻿

$(document).ready(function () {
    ShowMyPaymentMethods_myPayment();
    $("#SecurityCode").val('');
});
var SecurityCode_Validation_myPayment;
SecurityCode_Validation_myPayment = function (evt) {

    var theEvent = evt || window.event;
    var TotalLength = $("#" + evt.currentTarget.id).val().length;


    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }

    var regex = /[0-9]/;

    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }

    // length
    if (TotalLength >= 4) {
        theEvent.returnValue = false;
        theEvent.preventDefault();
    }
}

SetRemoveCardValues_myPayment = function (control) {
    $('#CardData_myPayment').val($(control).data("token"));
    //$('#RemoveCard-popup-myPayment').show();
    $('#RemoveCard-popup-myPayment').modal('show')
}

SetCardValuesAsDefult_myPayment = function (control) {
    $('#CardData_myPayment').val($(control).data("token"));
    $('#SetDefaultCardForm').ResetForm();
    $('#CV2-popup-myPayment').modal('show')
    //$('#CV2-popup-myPayment').show();
}
SetRemoveDefaultCardValues_myPayment = function (control) {

    $('#CardData_myPayment').val($(control).data("token"));
    $('#RemoveDefaultCard-popup-myPayment').modal('show')
}

$("#BtnCnfrmDefault_myPayment").on("click", function () {

    if (!$('#SetDefaultCardForm').valid()) {
        return false;
    }
    else {
        $.ajax({
            type: "POST",
            url: "/setdefaultcard",
            data: { defaultCardCV2: $('#SecurityCode').val(), cardToken: $('#CardData_myPayment').val() },
            beforeSend: function (xhr) {

                $('#BtnCnfrmDefault_myPayment,#CancelButton,#CloseButton').attr('disabled', true);

            },
            success: function (response) {

                if (response != null) {
                    if (response.status == true) {

                        //$('#CV2-popup-myPayment').hide();
                        $('#CV2-popup-myPayment').modal('hide');
                        ShowMyPaymentMethods_myPayment();
                        $("#SecurityCode").val('');
                    }
                    else {
                        $('#CnfrmDefaultFailureMsg_myPayment').text(response.message);
                        $('#CnfrmDefaultFailureAlert_myPayment').slideDown().delay(4000).slideUp();
                    }
                }
                else {
                    $('#CnfrmDefaultFailureMsg_myPayment').text('Something went wrong on server.');
                    $('#CnfrmDefaultFailureAlert_myPayment').slideDown().delay(4000).slideUp();
                }

            },
            complete: function (xhr, status) {



                $('#BtnCnfrmDefault_myPayment,#CancelButton,#CloseButton').attr('disabled', false);

            },
            error: function (xhr, status, error) {
                $('#CnfrmDefaultFailureMsg_myPayment').text('Something went wrong on server.');
                $('#CnfrmDefaultFailureAlert_myPayment').slideDown().delay(4000).slideUp();
            }
        });
    }
});



$("#BtnRemoveCard_myPayment").on("click", function () {
    $.ajax({
        type: "POST",
        url: "/removecard",
        data: { cardToken: $('#CardData_myPayment').val() },
        beforeSend: function (xhr) {

            $('#BtnRemoveCard_myPayment,#CancelButton,#CloseButton').attr('disabled', true);

            $('#BtnRemoveCard_lbl_myPayment').hide();
            $('#BtnRemoveCard_Spin_myPayment').show();

        },
        success: function (response) {

            if (response != null) {
                if (response.status == true) {

                    $/*('#RemoveCard-popup-myPayment').hide();*/
                    $('#RemoveCard-popup-myPayment').modal('hide')
                    ShowMyPaymentMethods_myPayment();
                    $('#SuccessMessage').html('<h5>Card remove successfully.</h5>');
                    $('#SuccessMessage').show();

                    setTimeout(function () {
                        $('#SuccessMessage').hide();

                    }, 2000);

                }
                else {
                    $('#RemoveCardFailureMsg_myPayment').text(response.message);
                    $('#RemoveCardFailureAlert_myPayment').slideDown().delay(4000).slideUp
                }
            }
            else {
                $('#RemoveCardFailureMsg_myPayment').text('Something went wrong on server.');
                $('#RemoveCardFailureAlert_myPayment').slideDown().delay(4000).slideUp();;
            }

        },
        complete: function (xhr, status) {

            $('#BtnRemoveCard_myPayment,#CancelButton,#CloseButton').attr('disabled', false);

            $('#BtnRemoveCard_lbl_myPayment').show();
            $('#BtnRemoveCard_Spin_myPayment').hide();

        },
        error: function (xhr, status, error) {

            $('#RemoveCardFailureMsg_myPayment').text('Something went wrong on server.');
            $('#RemoveCardFailureAlert_myPayment').slideDown().delay(4000).slideUp();

        }
    });
});

$('#BtnRemoveDefaultCard_myPayment').click(function () {

    $.ajax({
        url: "/removedefaultcard",
        type: "POST",
        data: { cardToken: $('#CardData_myPayment').val() },
        beforeSend: function (xhr) {

            $('#BtnRemoveDefaultCard_myPayment,#CancelButton,#CloseButton').attr('disabled', true);

        },
        success: function (response) {

            if (response != null) {
                if (response.status == true) {

                    //$('#RemoveDefaultCard-popup-myPayment').hide();
                    $('#RemoveDefaultCard-popup-myPayment').modal('hide')
                    ShowMyPaymentMethods_myPayment();
                    $('#SuccessMessage').html('<h5>Card remove successfully.</h5>');
                    $('#SuccessMessage').show();

                    setTimeout(function () {
                        $('#SuccessMessage').hide();

                    }, 2000);
                }
                else {
                    $('#RemoveDefaultCardFailureMsg_myPayment').text(response.message);
                    $('#RemoveDefaultCardFailureAlert_myPayment').slideDown().delay(4000).slideUp
                }
            }
            else {
                $('#RemoveDefaultCardFailureMsg_myPayment').text('Something went wrong on server.');
                $('#RemoveDefaultCardFailureAlert_myPayment').slideDown().delay(4000).slideUp();;
            }

        },
        complete: function (xhr, status) {

            $('#BtnRemoveDefaultCard_myPayment,#CancelButton,#CloseButton').attr('disabled', false);

        },
        error: function (xhr, status, error) {
            $('#RemoveDefaultCardFailureMsg_myPayment').text('Something went wrong on server.');
            $('#RemoveDefaultCardFailureAlert_myPayment').slideDown().delay(4000).slideUp();
        }
    });
});


$("#CancelButton,#CloseButton").on("click", function () {
    $(".modal").hide();
});


function ShowMyPaymentMethods_myPayment() {
    $.ajax({
        url: "/getusercards",
        type: "GET",
        success: function (json) {

            if (json != null) {

                if (json != null) {

                    var cardsHtML = '';

                    $('#MyPayments_DefaultCard_MaskedPan').html('');
                    $('#MyPayments_OtherCardsContent').html('');

                    $.each(json.paymentMethodResponses, function (key, val) {

                        if (val.isPrimary) {
                            //var defaultcardHtml = "<div class=\"credit-card default-card\">" +
                            //    "<div class=\"col-12 col-sm-5\">" +
                            //    "<div class=\"form-group\">" +
                            //    "<i class=\"fab fa-cc-" + val.card.cardScheme.toLowerCase() + "\"></i> " + "<label>" + val.card.maskedPan + "</label>" +
                            //    "</div>" +
                            //    "</div>" +
                            //    "<div class=\"col-12 col-sm-7\" > " +
                            //    "<button data-token=" + val.card.cardToken + " type=\"button\" onclick=\"SetRemoveDefaultCardValues_myPayment(this)\" class=\"btn btn-primary-3\">Remove</button>" +
                            //    "</div>" +
                            //    "</div>";

                            var defaultcardHtml = " <div class=\"credit-card default-card\">" +
                                "<h6 class=\"mb-1 font-weight-normal\">Card Number</h6>" +
                                "<h5 class=\"mb-3\">" + val.card.maskedPan + "</h5>" +
                                "<p class=\"mb-0\"><a onclick=\"SetRemoveDefaultCardValues_myPayment(this)\"data-token=" + val.card.cardToken +" href=\"#\">Remove Card</a></p></div>";

                            $('#MyPayments_DefaultCard_MaskedPan').html(defaultcardHtml);
                        }
                        else {
                            //cardsHtML += "<div class=\"credit-card default-card\">" +
                            //    "<div class=\"col-12 col-sm-5\">" +
                            //    "<div class=\"form-group\">" +
                            //    "<i class=\"mb-1 font-weight-normal" + val.card.cardScheme.toLowerCase() + "\"></i> " + "<label>" + val.card.maskedPan + "</label>" +
                            //    "</div>" +
                            //    "</div>" +
                            //    "<div class=\"col-12 col-sm-7\" > " +
                            //    "<button type=\"button\" class=\"btn btn-primary-3\" onclick=\"SetCardValuesAsDefult_myPayment(this)\" data-token=" + val.card.cardToken + ">Set Default Card</button> <button data-token=" + val.card.cardToken + " type=\"button\" onclick=\"SetRemoveCardValues_myPayment(this)\" class=\"btn btn-primary-3\">Remove</button>" +
                            //    "</div>" +
                            //    "</div>";

                            cardsHtML += "<div class=\"col-sm-6 mb-3\">" +
                                "<div class=\"credit-card\">" +
                                "<h6 class=\"mb-1 font-weight-normal\">Card Number</h6>" +
                                "<h5 class=\"mb-3\" > " + val.card.maskedPan + "</h5>" +
                                "<p class=\"mb-0\"><a onclick=\"SetCardValuesAsDefult_myPayment(this)\" data-token=" + val.card.cardToken + " href=\"#\">Set as Default</a> <span class=\"mx-2\">|</span> <a onclick=\"SetRemoveCardValues_myPayment(this)\"  data-token='" + val.card.cardToken + "'  href=\"#\" class=\"d-inline-block\">Remove Card</a></p>" +
                                "</div>" +
                                "</div>";
                        }

                    })
                    $('#MyPayments_OtherCardsContent').html(cardsHtML);
                }
                else {
                    $('#MyPayments_DefaultCard_MaskedPan').html('');
                    $('#MyPayments_OtherCardsContent').html('');
                }
            }
            else {
                $('#MyPayments_DefaultCard_MaskedPan').html('');
                $('#MyPayments_OtherCardsContent').html('');
            }

        },
        error: function (xhr, status, error) {
            $('#MyPayments_DefaultCard_MaskedPan').html('');
            $('#MyPayments_OtherCardsContent').html('');
        }
    });
}

