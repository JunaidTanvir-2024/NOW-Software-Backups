﻿namespace Application.Features.Account.History.Models;
public class PaymentHistoryResponse
{
    public IEnumerable<PaymentHistoryInfo> History { get; set; } = new List<PaymentHistoryInfo>();
    public int TotalCount { get; set; }
    public int RecordsFiltered { get; set; }
    public int PageNo { get; set; }
}
