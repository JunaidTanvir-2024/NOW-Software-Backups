﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

using static THCC.Domain.Constants.ThccConstants;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Api.Middlewares
{
    internal sealed class NotFoundMiddleware
    {
        private readonly RequestDelegate _next;

        public NotFoundMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            await ExceptionHandlerAsync(context);
        }

        private async Task ExceptionHandlerAsync(HttpContext context)
        {
            await _next(context);
            if (context.Response.StatusCode == 404)
            {
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsync(JsonConvert.SerializeObject(
                    new ErrorResult()
                    {
                        Errors = new List<ErrorDto>()
                        {
                            new ErrorDto(){Code = CustomStatusCode.NotFound,Message = CustomStatusKey.NotFound}
                        }
                    }
                  , new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() }));
            }
        }

    }
    internal static class NotFoundMiddlewareExtension
    {
        public static IApplicationBuilder UseNotFoundMiddleware(this IApplicationBuilder app)
        {
            return app.UseMiddleware<NotFoundMiddleware>();
        }
    }

}
