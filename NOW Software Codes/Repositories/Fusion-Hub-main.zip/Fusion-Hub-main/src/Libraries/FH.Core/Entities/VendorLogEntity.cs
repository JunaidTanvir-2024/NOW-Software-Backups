namespace FH.Core.Entities;
public sealed record VendorLogEntity
{
    public DateTimeOffset Timestamp { get; set; }
    public string? RequestPath { get; set; }
    public string? RequestMethod { get; set; }
    public string? RequestBody { get; set; }
    public string? ResponseBody { get; set; }
    public int StatusCode { get; set; }
    public long Duration { get; set; }
    public long ResponseSize { get; set; }
    public string? ErrorReason { get; set; }
    public string? Headers { get; set; }
    public string? QueryString { get; set; }
    public required string CorrelationId { get; set; }
    public required int VendorId { get; set; }
}
