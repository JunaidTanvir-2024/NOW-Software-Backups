﻿using Newtonsoft.Json;

using Serilog;

using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;

namespace THCC.Infrastructure.Services;
public class SocialLoginService : ISocialLoginService
{
    #region Fields

    private readonly ILogger _logger;
    private readonly IHttpClientFactory _httpClientFactory;

    #endregion

    #region Ctor

    public SocialLoginService(
        ILogger logger,
        IHttpClientFactory httpClientFactory)
    {
        _logger = logger;
        _httpClientFactory = httpClientFactory;
    }

    #endregion

    #region Methods

    #region Facebook

    public async Task<FacebookUserDto> GetUserFromFacebook(string accessToken)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            string profileEndPoint = "https://graph.facebook.com/me?fields=id,first_name,last_name,email,picture&access_token=" + accessToken;
            var output = await client.GetAsync(profileEndPoint);
            string outputData = await output.Content.ReadAsStringAsync();
            if (output.IsSuccessStatusCode)
            {
                return JsonConvert.DeserializeObject<FacebookUserDto>(outputData)!;
            }
            _logger.Error($"GetUserFromFacebook => accessToken : {accessToken} StatusCode : {output.StatusCode} {outputData}");
            return null!;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, $"GetUserFromFacebook => accessToken: {accessToken}  ErrorMessage: {ex.Message}");
            return null!;
        }
    }

    #endregion

    #region Google

    public async Task<GoogleUserDto> GetUserFromGoogle(string accessToken)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            string profileEndPoint = "https://oauth2.googleapis.com/tokeninfo?id_token=" + accessToken;
            var output = await client.GetAsync(profileEndPoint);
            string outputData = await output.Content.ReadAsStringAsync();
            if (output.IsSuccessStatusCode)
            {
                return JsonConvert.DeserializeObject<GoogleUserDto>(outputData)!;
            }
            _logger.Error($"GetUserFromGoogle => accessToken : {accessToken} StatusCode : {output.StatusCode} {outputData}");
            return null!;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, $"GetUserFromGoogle => accessToken: {accessToken}  ErrorMessage: {ex.Message}");
            return null!;
        }
    }

    

    #endregion

    #endregion
}
