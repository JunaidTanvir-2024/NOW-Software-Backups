﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts
{
    public class RefundFullPaymentRequestModel
    {
        public string transactionId { get; set; }
    }
}
