﻿namespace THCC.Application.Features.Payment.Card.RemoveCard;

public class RemoveCardRequest : IRequest<object>
{
    public string CardToken { get; set; } = default!;
}

public class RemoveCardRequestValidator : AbstractValidator<RemoveCardRequest>
{
    public RemoveCardRequestValidator()
    {
        RuleFor(p => p.CardToken)
                .NotEmpty()
                .NotNull();
    }
}