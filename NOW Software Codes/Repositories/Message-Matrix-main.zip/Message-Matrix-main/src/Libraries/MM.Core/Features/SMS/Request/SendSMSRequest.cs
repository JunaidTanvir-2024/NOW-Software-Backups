using MM.Core.Common.Definitions.Enums;

namespace MM.Core.Features.SMS.Request;

public record SendSMSRequest() : IRequest<IResultWrapper>
{
    public string? To { get; set; }
    public string message { get; set; }
    public string ProductCode { get; set; }
    public string RequestID { get; set; }
    public RequestType RequestType { get; set; }


}
public class SendSMSRequestValidator : AbstractValidator<SendSMSRequest>
{
    public SendSMSRequestValidator()
    {

    }
}



