﻿using SC.Core.Features.Email.Response;

namespace SC.Core.Features.Email.Request
{

    public sealed class SendEmailRequest: IRequest<SendEmailResponse>
    {
        public string To { get; set; } = default!;
        public string EmailBody { get; set; } = default!;
        public string ProductCode { get; set; } = default!;
        public string Subject { get; set; } = default!;
        public int EmailType { get; set; } = default!;
    }
    public sealed class SendEmailRequestValidator : AbstractValidator<SendEmailRequest>
    {
        public SendEmailRequestValidator()
        {
        }
    }

}
