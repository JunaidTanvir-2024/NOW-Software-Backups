﻿namespace Application.Features.Account.Product.Replace;

public class ReplaceProductRequestHandler : IRequestHandler<ReplaceProductRequest, Result<object>>
{
    #region Fields

    private readonly IStringLocalizer<ReplaceProductRequest> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly ICurrentUser _currentUser;

    #endregion

    #region Ctors

    public ReplaceProductRequestHandler(
        IStringLocalizer<ReplaceProductRequest> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService,
        ICurrentUser currentUser)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _currentUser = currentUser;
    }

    #endregion

    #region Method

    public async Task<Result<object>> Handle(ReplaceProductRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        //Get user products
        var products = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        if (!products.Any(x => x.Msisdn != null && x.Msisdn.Equals(request.Msisdn, StringComparison.InvariantCultureIgnoreCase)))
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Place sim replacement order
        var response = await _unitOfWork.SimRepo.AddReplacementSimOrder(request.AddressInfo, request.Msisdn, _currentUser.GetUserId());
        if (response > 0)
        {
            return Result<object>.Failure(
                _localizer[response.GenerateSimOrderValidationMessage()], response.GenerateSimOrderValidationCode());
        }

        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
