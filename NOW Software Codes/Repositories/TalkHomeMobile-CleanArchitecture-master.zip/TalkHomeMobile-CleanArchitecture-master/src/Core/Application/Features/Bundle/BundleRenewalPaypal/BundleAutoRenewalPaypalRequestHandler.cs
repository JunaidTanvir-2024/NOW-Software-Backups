using Application.Common.Interfaces.Payment;
using Application.Features.AutoTopup.Paypal;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;

namespace Application.Features.Bundle.BundleRenewalPaypal;

public sealed class BundleAutoRenewalPaypalRequestHandler : IRequestHandler<BundleAutoRenewalPaypalRequest, Result<BundleAutoRenewalPaypalResponse>>
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<BundleAutoRenewalPaypalRequestHandler> _localizer;
    private readonly IUserService _userService;
    private readonly ICommonService _commonService;
    private readonly IPayPalService _payPalService;
    private readonly IPaymentService _paymentService;

    public BundleAutoRenewalPaypalRequestHandler(
        IUnitOfWork unitOfWork,
        ICurrentUser currentUser,
        IStringLocalizer<BundleAutoRenewalPaypalRequestHandler> localizer,
        IUserService userService,
        ICommonService commonService,
        IPayPalService payPalService,
        IPaymentService paymentService)
    {
        _unitOfWork = unitOfWork;
        _currentUser = currentUser;
        _localizer = localizer;
        _userService = userService;
        _commonService = commonService;
        _payPalService = payPalService;
        _paymentService = paymentService;
    }

    public async Task<Result<BundleAutoRenewalPaypalResponse>> Handle(BundleAutoRenewalPaypalRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        //Check if user msisdn
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<BundleAutoRenewalPaypalResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Get bundle Info
        var bundlesResponse = await _unitOfWork.BundleRepo.GetBundleById(new BundleByIdRequest() { Id = request.BundleId.ToString() });
        if (bundlesResponse == null)
        {
            return Result<BundleAutoRenewalPaypalResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }
        //if (bundlesResponse.Type == (int) BundleType.Rolling)
        //{
        //    return Result<BundleAutoRenewalPaypalResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        //}

        var msisdnInfo = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);

        //Get subscribed bundles
        var subscribedBunldes = await _unitOfWork.UserRepo.GetSubscribedBundles(msisdnInfo.AccountId!);
        if (subscribedBunldes.Any())
        {
            if (!subscribedBunldes.Any(x => x.Id.ToString().Equals(bundlesResponse.UuId, StringComparison.InvariantCultureIgnoreCase)))
            {
                return Result<BundleAutoRenewalPaypalResponse>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
            }
        }

        //suspend paypal existing subscription
        //var autoRenewalStatus = await _unitOfWork.BundleRepo.GetBundleAutoRenewal(request.Msisdn, msisdnInfo.AccountId!, bundlesResponse.UuId!);
        //if (autoRenewalStatus?.IsRenew == true && (autoRenewalStatus?.PaymentMethod?.Equals("Paypal", StringComparison.InvariantCultureIgnoreCase) ?? true))
        //{
        //    var paymentRequest = new PaypalSuspendSubscriptionRequest
        //    {
        //        SubscriptionId = autoRenewalStatus!.InitialTransactionId
        //    };
        //    await _payPalService.PayPalCancelSubscription(paymentRequest);
        //}

        var paymentResponse = await _paymentService.HandlePaypalPaymentRequest(
            topupInfo: null!,
            bundleInfo: new PaymentBundleInfo
            {
                BundleId = request.BundleId,
                IsRenewable = request.IsAutoRenew
            },
            creditSimInfo: null!,
            msisdn: request.Msisdn,
            _currentUser.GetUserEmail()!,
            request.IpAddress!,
            isSubscriptionRequest: true,
            subscriptionWithInitialSale: false);
        if (paymentResponse != null && paymentResponse.ErrorCode == 0 && !string.IsNullOrEmpty(paymentResponse?.Data?.RedirectUrl))
        {
            //Redirect to paypal
            var responseModel = new BundleAutoRenewalPaypalResponse
            {
                RedirectUrl = paymentResponse?.Data?.RedirectUrl
            };
            return Result<BundleAutoRenewalPaypalResponse>.Success(responseModel, _localizer[CustomStatusKey.Success]);
        }
        else
        {
            return Result<BundleAutoRenewalPaypalResponse>.Failure(
            _localizer[CustomStatusKey.SetAutoTopupFailure], CustomStatusCode.InternalServerError);
        }
    }
}
