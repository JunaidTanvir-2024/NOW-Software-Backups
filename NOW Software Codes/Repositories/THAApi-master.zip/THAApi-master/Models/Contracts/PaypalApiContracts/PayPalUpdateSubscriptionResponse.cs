﻿namespace Models.Contracts.PaypalApiContracts
{
	public class PayPalDirectUpdateSubscriptionRequest
	{
		public string SubscriptionId { get; set; } = string.Empty;
		public string ProductRef { get; set; } = string.Empty;
	}
	public class PayPalUpdateSubscriptionResponse
	{
		public bool IsSuccess { get; set; }
		public int ErrorCode { get; set; }
		public string ErrorMessage { get; set; }
	}
}
