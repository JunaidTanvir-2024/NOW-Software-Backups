﻿using Dapper;
using Microsoft.Extensions.Options;
using SMSOutReach.Infastructure.Interface;
using SMSOutReach.Modal.Xeebi;
using SMSOutReach.Model.Configurations;
using SMSOutReach.Model.Connections;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace SMSOutReach.Infastructure.Repository
{
    public class SMSCarrierRepository : ISMSCarrier
    {

        private IDbConnectionSettings DbConnection;


        public SMSCarrierRepository(IOptions<ConnectionString> connectionString)
        {

            DbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));

        }

        public List<SMSCarrier> GetAllSMSCarriers()
        {
            var carrier = DbConnection.SqlConnection.Query<SMSCarrier>("Sp_Ui_GetAllSMSCarriers");
            var resultSet = carrier.ToList();
            return resultSet;
        }

        

       
    }
}
