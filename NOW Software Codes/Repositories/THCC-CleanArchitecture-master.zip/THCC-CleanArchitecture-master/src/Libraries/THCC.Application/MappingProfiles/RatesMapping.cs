﻿using THCC.Application.Models.Dtos;

namespace THCC.Application.MappingProfiles;
public sealed class RateMapping : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        TypeAdapterConfig<Rate, RatesDto>
            .NewConfig()
            .Map(rateDto => rateDto.CountryISOCode, rate => $"{rate.ISOThreeCharacterCode}");
    }
}