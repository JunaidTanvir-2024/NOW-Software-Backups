﻿using System;

namespace ATT.Models.Database
{
    public class APIAccessGUID
    {
        public string GUID { get; set; }
        public string account { get; set; }
        public DateTime Date { get; set; }
        public string tomsisdn { get; set; }
        public string ProductsJSON { get; set; }
        public string countryCode { get; set; }
        public string operatorCode { get; set; }
        public DateTime cr_date { get; set; }
        public int id { get; set; }
        public string product { get; set; }
        public decimal CustomerChargeValue { get; set; }
        public string fromCurrency { get; set; }
        public string toCurrency { get; set; }
        public string toAmount { get; set; }
        public string fromAmount { get; set; }
        public string destination_country { get; set; }
    }

    public class APIAccessGUID_Trh
    {
        public string GUID { get; set; }
        public string account { get; set; }
        public DateTime Date { get; set; }
        public string tomsisdn { get; set; }
        public string frommsisdn { get; set; }
        public string ProductsJSON { get; set; }
        public string countryCode { get; set; }
        public string operatorCode { get; set; }
        public string operatorName { get; set; }
        public DateTime cr_date { get; set; }
        public int id { get; set; }
        public string product { get; set; }
        public decimal CustomerChargeValue { get; set; }
        public decimal selling_price { get; set; }
        public string fromCurrency { get; set; }
        public string toCurrency { get; set; }
        public string toAmount { get; set; }
        public string fromAmount { get; set; }
        public string productCode { get; set; }
        public string ProductItemCode { get; set; }
        public string skuCode { get; set; }
        public string UatNumber { get; set; }
        public string destination_country { get; set; }
        public decimal discountPercentage { get; set; }
        public string orignalAmount { get; set; }
    }


    public class CRM_ATT_APIAccessGUID
    {
        public string ProductId { get; set; }
        public string GUID { get; set; }
        public string account { get; set; }
        public DateTime Date { get; set; }
        public string tomsisdn { get; set; }
        public string frommsisdn { get; set; }
        public string ProductsJSON { get; set; }
        public string countryCode { get; set; }
        public string operatorCode { get; set; }
        public string operatorName { get; set; }
        public DateTime cr_date { get; set; }
        public int id { get; set; }
        public string product { get; set; }
        public decimal CustomerChargeValue { get; set; }
        public decimal selling_price { get; set; }
        public string fromCurrency { get; set; }
        public string toCurrency { get; set; }
        public string toAmount { get; set; }
        public string crmAmount { get; set; }
        public string fromAmount { get; set; }
        public string productCode { get; set; }
        public string ProductItemCode { get; set; }
        public string skuCode { get; set; }
        public string UatNumber { get; set; }
        public string destination_country { get; set; }
    }

    public class ExecuteData
    {
        public string nowtelTransactionReference { get; set; }
        public string operatorid { get; set; }
        public string product { get; set; }
        public string messageToRecipient { get; set; }
        public string fromMSISDN { get; set; }
        public int serviceProviderNumber { get; set; } = 1;
    }      

    public class TransferToQueue
    {
        public string nowtelTransactionReference { get; set; }
        public string operatorid { get; set; }
        public string product { get; set; }
        public string messageToRecipient { get; set; }
        public string fromMSISDN { get; set; }
    }
}
