﻿namespace Application.Features.Account.Product.Replace;
public class ReplaceProductRequestValidator : AbstractValidator<ReplaceProductRequest>
{
    public ReplaceProductRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");

        #region Sim Address Info Validation

        RuleFor(p => p.AddressInfo.AddressL1).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.AddressInfo.City).Cascade(CascadeMode.Stop).NotNull().NotEmpty();
        RuleFor(p => p.AddressInfo.PostCode).Cascade(CascadeMode.Stop).NotNull().NotEmpty();

        #endregion

    }
}
