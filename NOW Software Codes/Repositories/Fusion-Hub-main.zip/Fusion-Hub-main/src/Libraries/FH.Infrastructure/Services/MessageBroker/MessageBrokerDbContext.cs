using MassTransit;

using Microsoft.EntityFrameworkCore;

namespace FH.Infrastructure.Services.MessageBroker;
internal class MessageBrokerDbContext(DbContextOptions<MessageBrokerDbContext> options) : DbContext(options)
{
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.AddOutboxMessageEntity();
        modelBuilder.AddInboxStateEntity();
        modelBuilder.AddOutboxStateEntity();
    }
}
