using THCC.Application.Models.Dtos;

namespace THCC.Application.Settings;

public sealed class TopupSettings
{
    public const string SectionName = nameof(TopupSettings);
    public static TopupSettings Bind = new TopupSettings();
    public List<TopupDenominationsDto> Amounts { get; set; } = default!;
    public decimal FirstRechargePoints { get; set; }
    public AutoTopUpSettings AutoTopupSettings { get; set; } = default!;
}

public sealed class AutoTopUpSettings
{
    public decimal ThresholdAmount { get; set; }
    public decimal MaxLimit { get; set; }
}