using Application.Features.Bundle.BundleDetail;
using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.BundleDetailByUUID;

public sealed class BundleByUUIdRequestHandler : IRequestHandler<BundleByUUIdRequest, Result<BundleInfo>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<BundleByIdRequestHandler> _localizer;
    private readonly IMapper _mapper;

    public BundleByUUIdRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<BundleByIdRequestHandler> localizer,
        IMapper mapper)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
    }

    public async Task<Result<BundleInfo>> Handle(BundleByUUIdRequest request, CancellationToken cancellationToken)
    {
        var bundle = _mapper.Map<BundleInfo>(await _uow.BundleRepo.GetBundleById(request.Id));
        if (bundle == null)
        {
            return Result<BundleInfo>.Failure(_localizer[CustomStatusKey.InvalidBundle], CustomStatusCode.InvalidBundle);
        }

        return Result<BundleInfo>.Success(bundle, _localizer[CustomStatusKey.Success]);
    }
}