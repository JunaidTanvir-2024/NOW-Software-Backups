﻿using PaymentsApi.Infrastructure.DAL.EnumToLookup;
using System.Collections.Generic;

namespace PaymentsApi.Infrastructure.DAL.Database
{
    public partial class PaymentMethod : LookupTableBase
    {
        public PaymentMethod()
        {
            Pay360Transaction = new HashSet<Pay360Transaction>();
        }

        public ICollection<Pay360Transaction> Pay360Transaction { get; set; }
    }
}
