﻿
namespace THCC.Application.Settings;

public class CallingCardSettings
{
    public const string SectionName = "CallingCardSettings";
    public static CallingCardSettings Bind = new CallingCardSettings();
    public List<float> ConsumptionPercentage { get; set; } = default!;
}
