﻿using System.ComponentModel;

namespace SC.Api.Model.CustomerOrder;
public class GetCustomerCartModel
{
    [DefaultValue(false)]
    public bool IsGuestUser { get; set; } = default!;
    public string? UserID { get; set; } = default;
}

