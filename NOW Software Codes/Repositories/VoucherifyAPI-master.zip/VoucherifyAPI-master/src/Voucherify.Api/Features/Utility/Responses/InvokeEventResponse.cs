namespace Voucherify.Api.Features.Utility.Responses;

public class InvokeEventResponse
{
    public string? EventType { get; set; }
    public bool IsEventInvoked { get; set; }
}
