using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.AutoTopup.Card.New;

public class SetAutoTopupNewCardRequestValidator : AbstractValidator<SetAutoTopupNewCardRequest>
{
    public SetAutoTopupNewCardRequestValidator(ICommonService commonService, IOptions<TopupSettings> options)
    {
        // Payment Card properties validation
        RuleFor(p => p.PaymentCardInfo.CardNumber).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MaximumLength(19);
        RuleFor(p => p.PaymentCardInfo.ExpiryMonth).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(2).MaximumLength(2);
        RuleFor(p => p.PaymentCardInfo.ExpiryYear).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(2).MaximumLength(2);
        RuleFor(p => p.PaymentCardInfo.NameOnCard).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.PaymentCardInfo.SecurityCode).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(3).MaximumLength(4);

        // Auto Topup properties validation
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");

        //RuleFor(p => p.ThresHoldAmount).Cascade(CascadeMode.Stop)
        //    .NotEmpty()
        //    .NotNull()
        //    .Must(p => options.Value.AutoTopupThresholdAmounts.Contains(p))
        //    .WithMessage("Invalid threshold amount");

        RuleFor(p => p.TopupAmount).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => options.Value.TopUpAmounts.Contains(p))
            .WithMessage("Invalid top-up amount");
    }
}