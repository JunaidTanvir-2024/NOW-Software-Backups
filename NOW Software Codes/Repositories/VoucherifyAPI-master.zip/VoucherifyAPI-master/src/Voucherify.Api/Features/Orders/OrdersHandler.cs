using RW;

using Voucherify.Core.Domain.Definitions;
using Voucherify.Core.Services.VoucherifyApi;
using Voucherify.Core.Services.VoucherifyApi.Models.Orders;

namespace Voucherify.Api.Features.Orders;

public interface IOrdersHandler
{
    Task<IResultWrapper<Order>> CreateOrder(OrderCreate newOrder);
    Task<IResultWrapper<Order>> GetOrder(string orderId, Order order);
    Task<IResultWrapper<List<Order>>> GetOrders(int pageNumber, int pageSize);
    Task<IResultWrapper<Order>> UpdateOrder(string orderId, OrderUpdate updateOrder);
}

public class OrdersHandler : IOrdersHandler
{
    private readonly IVoucherifyImplementation _voucherifyImplementation;

    public OrdersHandler(IVoucherifyImplementation voucherifyImplementation)
    {
        _voucherifyImplementation = voucherifyImplementation;
    }
    public async Task<IResultWrapper<List<Order>>> GetOrders(int pageNumber, int pageSize)
    {
        var result = await _voucherifyImplementation.GetOrders(pageNumber, pageSize);
        return result != null ?
            ResultWrapper.Success(result) :
            ResultWrapper.Failure<List<Order>>(AppConstants.StatusMessages.NotFound, AppConstants.StatusCodes.NotFound);
    }
    public async Task<IResultWrapper<Order>> GetOrder(string orderId, Order order)
    {
        var result = await _voucherifyImplementation.GetOrder(orderId, order);
        return result != null ?
            ResultWrapper.Success(result) :
            ResultWrapper.Failure<Order>(AppConstants.StatusMessages.NotFound, AppConstants.StatusCodes.NotFound);
    }
    public async Task<IResultWrapper<Order>> CreateOrder(OrderCreate newOrder)
    {
        var result = await _voucherifyImplementation.CreateOrder(newOrder);
        return result != null ?
            ResultWrapper.Success(result) :
            ResultWrapper.Failure<Order>(AppConstants.StatusMessages.NotFound, AppConstants.StatusCodes.NotFound);
    }
    public async Task<IResultWrapper<Order>> UpdateOrder(string orderId, OrderUpdate updateOrder)
    {
        var result = await _voucherifyImplementation.UpdateOrder(orderId, updateOrder);
        return result != null ?
            ResultWrapper.Success(result) :
            ResultWrapper.Failure<Order>(AppConstants.StatusMessages.BadRequest, AppConstants.StatusCodes.BadRequest);
    }
}
