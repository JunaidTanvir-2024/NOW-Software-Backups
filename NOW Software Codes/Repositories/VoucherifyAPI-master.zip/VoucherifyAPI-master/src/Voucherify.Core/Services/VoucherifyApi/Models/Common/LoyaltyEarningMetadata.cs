using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class LoyaltyEarningMetadata
{
    [JsonPropertyName("points")]
    public int BasePoints { get; set; }
    [JsonPropertyName("every")]
    public int Base { get; set; }
}

