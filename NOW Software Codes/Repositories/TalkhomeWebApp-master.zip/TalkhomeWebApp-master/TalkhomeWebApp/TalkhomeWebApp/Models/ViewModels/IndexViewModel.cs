﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class IndexViewModel
    {
        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        public string Msisdn { get; set; }

        public string CurrencySymbol { get; set; }
        public string CountryCode { get; set; }
    }
}
