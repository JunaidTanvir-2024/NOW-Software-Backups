﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class TwillioConfig
    {
        public string AccountSid { get; set; }
        public string AuthToken { get; set; }
        public string AccountSid2 { get; set; }
        public string AuthToken2 { get; set; }
        public string Prefix { get; set; }
        public string Route { get; set; }
        public Dictionary<string,string> CountryBaseSenders { get; set; }
    }
}
