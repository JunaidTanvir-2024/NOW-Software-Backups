﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.OrderCheckout.Payment;
public class BillingAddressDto
{
    public string? Line1 { get; set; } = default!;
    public string? Line2 { get; set; } = default!;
    public string? Line3 { get; set; } = default!;
    public string? Line4 { get; set; } = default!;
    public string? City { get; set; } = default!;
    public string? Region { get; set; } = default!;
    public string? PostCode { get; set; } = default!;
    public string? CountryCode { get; set; } = default!;
}

