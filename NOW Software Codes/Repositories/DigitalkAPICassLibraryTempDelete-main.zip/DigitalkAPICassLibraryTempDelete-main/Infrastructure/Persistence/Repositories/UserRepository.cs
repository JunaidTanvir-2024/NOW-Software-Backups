﻿using Application.Common.Models;
using Application.Common.Models.ResponseWrappers;
//using Application.Features.Account.History.Models;

namespace Infrastructure.Persistence.Repositories;

internal sealed class UserRepository : IUserRepository
{
    #region Fields

    //private readonly IDbConnectionSettings _dbConnection;
    private readonly IDbConnectionSettings _dbConnectionDigiTalk;
    /*private readonly IDbHelpers _dbHelpers;
    private readonly IDbConnectionSettings _dbConnectionRepConnection;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;
    private readonly CacheSettings _cacheSettings;*/

    #endregion

    #region Ctor

    public UserRepository(
        IOptions<DatabaseSettings> databaseSettings
        /*IDbHelpers dbHelpers,
        IOptions<CacheSettings> cacheSettings,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService*/)
    {
       // _dbConnection = new DbConnectionSettings(new SqlConnection(databaseSettings.Value.DefaultConnection));
        _dbConnectionDigiTalk = new DbConnectionSettings(new SqlConnection(databaseSettings.Value.DigiTalkConnection));
        //_dbConnectionRepConnection = new DbConnectionSettings(new SqlConnection(databaseSettings.Value.DigitalkMobileRepConnection));
        //_cacheSettings = cacheSettings.Value;
       // _dbHelpers = dbHelpers;
        //_cacheService = cacheService;
        //_cacheKeyService = cacheKeyService;
    }

    #endregion

    #region Methods

    /// <summary>
    /// get msisdn detail
    /// </summary>
    /// <param name="msisdn"></param>
    /// <returns></returns>
    public async Task<MsisdnDetails> GetMsisdnDetail(string msisdn)
    {
        var parameters = new DynamicParameters();
        parameters.Add("@msisdn", msisdn);

        return await _dbConnectionDigiTalk.SqlConnection.QueryFirstOrDefaultAsync<MsisdnDetails>(
                StoredProcedures.GetMsisdnDetails, parameters, commandType: CommandType.StoredProcedure);
    }
    #endregion
}