﻿namespace THCC.Application.Features.Payment.PayPal.Models
{
    public class PaypalPaymentResponse
    {
        public string RedirectUrl { get; set; } = default!;
    }
}
