using MM.Core.Common.Interfaces.Services.Models;

namespace MM.Core.Common.Interfaces.Services;

public interface IHttpService
{
    Task<HttpServiceResponse> DeleteAsync(string requestUri);
    Task<HttpServiceResponse> GetAsync(string requestUri);
    Task<HttpServiceResponse> PostAsync(string requestUri, object? data = default);
    Task<HttpServiceResponse> PutAsync(string requestUri, object? data = default);
    IHttpService EnableLogging();
    IHttpService WithBasicAuth(string? username, string? password);
    IHttpService WithBearerAuth(string? token);
    IHttpService WithHeaders(IEnumerable<Dictionary<string, string>> headers);
    IHttpService SetVendor(Vendors vendor);
}
