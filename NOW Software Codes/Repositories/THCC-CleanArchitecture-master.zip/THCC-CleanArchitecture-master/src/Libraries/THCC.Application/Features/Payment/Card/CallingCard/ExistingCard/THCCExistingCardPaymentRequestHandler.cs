﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Features.Payment.Card.CallingCard.ExistingCard
{
    public class THCCExistingCardPaymentRequestHandler : IRequestHandler<THCCExistingCardPaymentRequest, object>
    {
        #region Fields 

        private readonly IPaymentService _paymentService;
        private readonly ICurrentUser _currentUser;

        #endregion

        #region Ctors

        public THCCExistingCardPaymentRequestHandler(
            IPaymentService paymentService,
            ICurrentUser currentUser)
        {
            _paymentService = paymentService;
            _currentUser = currentUser;
        }

        #endregion

        #region Methods

        public async Task<object> Handle(THCCExistingCardPaymentRequest request, CancellationToken cancellationToken)
        {
            #region Trim Request

            request.PaymentCardInfo.CardToken = request.PaymentCardInfo.CardToken.Trim();
            request.PaymentCardInfo.SecurityCode = request.PaymentCardInfo.SecurityCode.Trim();

            #endregion

            return await _paymentService.HandleCardPaymentRequest(
                paymentNewCardInfo: null!,
                paymentAddressInfo: null!,
                paymentExistingCardInfo: request.PaymentCardInfo!,
                autoTopupInfo: null!,
                userInfo: new UserDto()
                {
                    Id = _currentUser.GetUserId(),
                    Email = _currentUser.GetUserEmail()
                },
                productType: ProductType.CallingCard,
                amount: request.Amount,
                cardNumber: null!);
        }

        #endregion
    }
}
