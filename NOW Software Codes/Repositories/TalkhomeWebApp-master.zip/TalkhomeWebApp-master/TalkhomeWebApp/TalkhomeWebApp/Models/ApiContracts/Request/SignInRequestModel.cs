﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class SignInRequestModel
    {
        [Required(ErrorMessage = "phone number is required")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "country code is required")]
        public string PhoneNumberCountryCode { get; set; }

        public string IpAddress { get; set; }
    }
}
