﻿
namespace THCC.Application.Features.Topup.AutoTopup;

public class AutoTopupRequest : IRequest<object> { }

