﻿using Application.Common.Interfaces;
using Application.Common.Models.Airship;
using Application.Common.Settings;
using Application.Features.Bundle.Bundle;
using Application.Features.Bundle.Model;
using Application.Features.Bundle.SuggestedBundle;
using Microsoft.Extensions.Options;

namespace Application.Features.Account.ProductSummary;
public class ProductSummaryRequestHandler : IRequestHandler<ProductSummaryRequest, Result<ProductSummaryResponse>>
{
    private readonly IStringLocalizer<ProductSummaryRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;
    private readonly IAirshipService _airshipService;
    private readonly BundleLimitSettings _bundleLimitSettings;

    public ProductSummaryRequestHandler(
         IStringLocalizer<ProductSummaryRequestHandler> localizer,
         IUnitOfWork unitOfWork,
         IMapper mapper,
         ICurrentUser currentUser,
         ICommonService commonService,
         IUserService userService,
         IAirshipService airshipService,
         IOptions<BundleLimitSettings> bundleLimitSettings
       )
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _currentUser = currentUser;
        _commonService = commonService;
        _userService = userService;
        _airshipService = airshipService;
        _bundleLimitSettings = bundleLimitSettings.Value;
    }

    public async Task<Result<ProductSummaryResponse>> Handle(ProductSummaryRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, DeviceType? deviceType, int MediumType) = _commonService.IsAppRequest();
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        string userEmail = _currentUser.GetUserEmail()!;
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<ProductSummaryResponse>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdnDetails == null)
        {
            return Result<ProductSummaryResponse>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var lastTopup = await _unitOfWork.UserRepo.GetUserLastTopupInfo(msisdnDetails.AccountId!);
        var subscribeBundlesList = _mapper.Map<List<SubscribedBundleInfo>>(await _unitOfWork.UserRepo.GetSubscribedBundles(msisdnDetails.AccountId!));
        var bundles = _mapper.Map<List<BundleInfo>>(await _unitOfWork.BundleRepo.GetBundles(new BundlesRequest()));

        if (subscribeBundlesList.Any() && subscribeBundlesList != null)
        {
            foreach (var item in subscribeBundlesList)
            {
                item.IsAllowancewbundle = false;
                var result = bundles.FirstOrDefault(x => x.UuId.Trim().ToLower() == item.Id.ToString().ToLower());
                if (result == null)
                {
                    item.IsAllowancewbundle = true;
                    item.PlanName = item.BrandedName;
                }
                else
                {
                    item.PlanName = result.Name;
                    item.Price = result.Price;
                    item.Bundleid = result.Id;
                   
                }
                item.NoOfDays = Convert.ToInt32((item.Expiry - DateTime.Now).TotalDays);
                item.ShowAutoRenew = item.Type != BundleType.Rolling;
            }
        }

        #region Events
        if (!IsAppRequest)
        {
            try
            {
                decimal totalMinutes = 0, totalSMS = 0, totalData = 0, totalRemainingMinutes = 0, totalRemainingSMS = 0, totalRemainingData = 0;
                decimal totalcallPercentage = 0, totalsmsPercentage = 0, totaldataPercentage = 0;
                List<decimal> bundleLimits = _bundleLimitSettings.Percentage;
                if (subscribeBundlesList.Any() && subscribeBundlesList != null)
                {
                    foreach (var item in subscribeBundlesList)
                    {
                        decimal callPercentage = 0, smsPercentage = 0, dataPercentage = 0;
                        totalMinutes = totalMinutes + Convert.ToDecimal(item.Minutes);
                        totalRemainingMinutes = totalRemainingMinutes + Convert.ToDecimal(item.RemainingMinutes);
                        totalSMS = totalSMS + Convert.ToDecimal(item.Texts);
                        totalRemainingSMS = totalRemainingSMS + Convert.ToDecimal(item.RemainingTexts);
                        if (item.GprsDataBytesConverted != "0 Bytes")
                        {
                            totalData = totalData + Convert.ToDecimal(item.GprsDataBytes);
                        }
                        if (item.RemainingGprsDataBytesConvertedWithoutUnit != "0 Bytes")
                        {
                            totalRemainingData = totalRemainingData + Convert.ToDecimal(item.RemainingGprsDataBytes);
                        }
                        if (Convert.ToInt32(item.Minutes) > 0)
                        {
                            callPercentage = (Convert.ToDecimal(item.RemainingMinutes) / Convert.ToDecimal(item.Minutes)) * 100;
                            callPercentage = 100 - callPercentage;
                        }
                        if (Convert.ToInt32(item.Texts) > 0)
                        {
                            smsPercentage = (Convert.ToDecimal(item.RemainingTexts) / Convert.ToDecimal(item.Texts)) * 100;
                            smsPercentage = 100 - smsPercentage;
                        }
                        if (item.GprsDataBytes > 0)
                        {
                            dataPercentage = (Convert.ToDecimal(item.RemainingGprsDataBytes) / Convert.ToDecimal(item.GprsDataBytes)) * 100;
                            dataPercentage = 100 - dataPercentage;
                        }
                        string bundleType = _commonService.GetBundleType(Convert.ToInt32(item.Category), Convert.ToInt32(item.Type));
                        if (callPercentage != 0 || smsPercentage != 0 || dataPercentage != 0)
                        {
                            foreach (var limit in bundleLimits)
                            {
                                if (callPercentage != 0 && callPercentage == limit)
                                {
                                    _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                    {
                                        EventName = $"plan_{bundleType}_mins_{limit}_dash",
                                        Value = 0,
                                        Email = userEmail,
                                        InteractionType = "Home-Page",
                                        TagGroupName = "Product"
                                    });
                                }
                                if (smsPercentage != 0 && smsPercentage == limit)
                                {
                                    _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                    {
                                        EventName = $"plan_{bundleType}_sms_{limit}_dash",
                                        Value = 0,
                                        Email = userEmail,
                                        InteractionType = "Home-Page",
                                        TagGroupName = "Product"
                                    });
                                }
                                if (dataPercentage != 0 && dataPercentage == limit)
                                {
                                    _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                    {
                                        EventName = $"plan_{bundleType}_data_{limit}_dash",
                                        Value = 0,
                                        Email = userEmail,
                                        InteractionType = "Home-Page",
                                        TagGroupName = "Product"
                                    });
                                }
                            }

                        }
                    }

                    if (totalMinutes > 0)
                    {
                        totalcallPercentage = (Convert.ToDecimal(totalRemainingMinutes) / Convert.ToDecimal(totalMinutes)) * 100;
                        totalcallPercentage = 100 - totalcallPercentage;
                    }
                    if (totalSMS > 0)
                    {
                        totalsmsPercentage = (Convert.ToDecimal(totalRemainingSMS) / Convert.ToDecimal(totalSMS)) * 100;
                        totalsmsPercentage = 100 - totalsmsPercentage;
                    }
                    if (totalData > 0)
                    {
                        totaldataPercentage = (Convert.ToDecimal(totalRemainingData) / Convert.ToDecimal(totalData)) * 100;
                        totaldataPercentage = 100 - totaldataPercentage;
                    }
                    if (totalcallPercentage != 0 || totalsmsPercentage != 0 || totaldataPercentage != 0)
                    {
                        foreach (var limit in bundleLimits)
                        {
                            if (totalcallPercentage != 0 && totalcallPercentage == limit)
                            {
                                _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                {
                                    EventName = $"plan_mins_{limit}_dash",
                                    Value = 0,
                                    Email = userEmail,
                                    InteractionType = "Home-Page",
                                    TagGroupName = "Product"
                                });
                            }
                            if (totalsmsPercentage != 0 && totalsmsPercentage == limit)
                            {
                                _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                {
                                    EventName = $"plan_sms_{limit}_dash",
                                    Value = 0,
                                    Email = userEmail,
                                    InteractionType = "Home-Page",
                                    TagGroupName = "Product"
                                });
                            }
                            if (totaldataPercentage != 0 && totaldataPercentage == limit)
                            {
                                _airshipService.HandleGenericTagsAndEvents(new GenericEventData
                                {
                                    EventName = $"plan_data_{limit}_dash",
                                    Value = 0,
                                    Email = userEmail,
                                    InteractionType = "Home-Page",
                                    TagGroupName = "Product"
                                });
                            }
                        }

                    }

                }
            }
            catch (Exception ex)
            {

            }
        }
        #endregion

        var suggestedBundles = _mapper.Map<List<BundleInfo>>
            (await _unitOfWork.BundleRepo.GetSuggestedBundles(new SuggestedBundleRequest() { Msisdn = request.Msisdn }));

        var response = new ProductSummaryResponse
        {
            SuggestedBundlesInfo = suggestedBundles,
            SubscribedBundlesInfo = subscribeBundlesList,
            MsisdnInfo = new MsisdnInfo()
            {
                LastTopUpAmount = lastTopup != null ? lastTopup.Amount : 0,
                LastTopUpDate = lastTopup?.Date!.Value.ToString("MM-dd-yyyy"),
                Credit = msisdnDetails.Credit!,
                FirstDate = msisdnDetails.FirstDate != null ? Convert.ToDateTime(msisdnDetails.FirstDate).ToString("MM-dd-yyyy") : null
            },
            Carousel = await _unitOfWork.PromotionRepo.GetPromotionCarousel(_currentUser.GetUserId(), request.Msisdn, null)
        };

        return Result<ProductSummaryResponse>.Success(response, _localizer[CustomStatusKey.Success]);
    }
}
