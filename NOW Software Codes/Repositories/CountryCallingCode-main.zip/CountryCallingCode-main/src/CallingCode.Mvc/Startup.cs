using CallingCode.Mvc;
using CallingCode.Mvc.Common;
using Serilog;

try
{
    StaticLogger.EnsureInitialized();
    Serilog.Log.Information("Application Started");

    var builder = WebApplication.CreateBuilder(args);
    {
        builder.AddWebDependencies();
    }
    var app = builder.Build();
    {
        app.AddMiddlewaresToRequestPipelines();
        app.Run();
    }
}
catch (Exception ex)
{
    Log.Error($"Unable to start the application {ex.Message}");
}