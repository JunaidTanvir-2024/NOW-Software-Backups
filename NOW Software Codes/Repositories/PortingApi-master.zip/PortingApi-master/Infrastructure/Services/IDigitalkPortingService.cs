﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public interface IDigitalkPortingService
    {
        Task<HttpResponseMessage> GetSwitchingInformation(string SubscriberId);
        Task<HttpResponseMessage> PortOut(int subscriberId, int codeType);
        Task<HttpResponseMessage> CancelPortOut(int subscriberId, int codeType);
    }
}
