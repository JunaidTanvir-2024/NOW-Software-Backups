﻿namespace Application.Features.Payment.Paypal.Models;

public class PaypalPaymentRequest
{
    public string? CustomerName { get; set; }
    public string Msisdn { get; set; } = default!;
    public string Email { get; set; } = default!;
    public CheckOutType CheckoutType { get; set; } = default!;
    public string? BundleUuid { get; set; }
    public float BundleAmount { get; set; }
    public float TopupAmount { get; set; }
    public string IpAddress { get; set; } = default!;
    public bool IsAppRequest { get; set; }
    public bool IsFastTopup { get; set; } = false;
    public int OrderId { get; set; }
}

public class PaypalPaymentResponse
{
    public string? RedirectUrl { get; set; }
    public string? TransactionId { get; set; }
    public bool IsSuccess { get; set; }
    public int ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }
}