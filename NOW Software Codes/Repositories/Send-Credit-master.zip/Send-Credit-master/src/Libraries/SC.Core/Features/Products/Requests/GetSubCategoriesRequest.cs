﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Products.Requests;
public sealed class GetSubCategoriesRequest : IRequest<IResultWrapper>
{
    public string? CategoryAliasName { get; set; } = default!;
}
public sealed class GetSubCategoriesRequestValidator : AbstractValidator<GetSubCategoriesRequest>
{
    public GetSubCategoriesRequestValidator()
    {

    }
}
