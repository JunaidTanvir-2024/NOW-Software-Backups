﻿
namespace THCC.Application.Features.Topup.VerifyCardNumber;

public class VerifyCardNumberResponse
{
    public bool IsRegistered { get; set; } = false;
    public string? Message { get; set; }
}
