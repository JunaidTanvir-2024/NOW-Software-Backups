﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.User.ForgotPassword.ForgotPasswordConfirm;

public class ForgotPasswordConfirmRequest : IRequest<object>
{
    public string Email { get; set; } = default!;
    public string Otp { get; set; } = default!;
}
public class ForgotPasswordResendValidator : AbstractValidator<ForgotPasswordConfirmRequest>
{
    public ForgotPasswordResendValidator(ICommonService commonService)
    {
        RuleFor(data => data.Email)
             .Cascade(CascadeMode.Stop)
             .NotNull().NotEmpty()
             .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
             .Must(p => commonService.IsValidEmailAddress(p))
             .WithMessage("Invalid Email Address");

        RuleFor(data => data.Otp)
            .NotEmpty()
            .NotNull()
            .MaximumLength(4).WithMessage("Your otp length must not exceed 4.");
    }
}
