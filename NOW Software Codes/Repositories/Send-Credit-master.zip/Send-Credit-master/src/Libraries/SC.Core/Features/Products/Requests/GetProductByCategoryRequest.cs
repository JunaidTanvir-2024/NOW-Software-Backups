﻿using SC.Core.Common.Model;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Products.Requests
{

    public sealed class GetProductByCategoryRequest : IRequest<IResultWrapper>
    {
        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public Filter? Filters { get; set; }

    }
    public sealed class GetProductByCategoryValidator : AbstractValidator<GetProductByCategoryRequest>
    {
        public GetProductByCategoryValidator()
        {

        }
    }

}
