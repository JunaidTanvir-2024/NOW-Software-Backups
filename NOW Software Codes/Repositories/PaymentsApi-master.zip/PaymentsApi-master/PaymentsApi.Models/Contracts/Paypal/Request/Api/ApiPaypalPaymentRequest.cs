﻿using Newtonsoft.Json;
using PaymentsApi.Models.Contracts.Pay360.Request.Api;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.Contracts.Paypal.Request.User;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts.Paypal.Request.Api
{
    public class ApiPaypalPaymentRequest
    {
        [JsonProperty("transaction")]
        public TransactionRequestModel Transaction { get; set; }

        [JsonProperty("customer")]
        public PaypalCustomerRequestModel Customer { get; set; }

        [JsonProperty("paymentMethod")]      
        public PaypalPaymentMethod PaymentMethod { get; set; }

        [JsonProperty("transactionOptions")]
        public PaypalTransactionOptionsModel TransactionOptions { get; set; }

        [JsonProperty("order")]
        public PaypalOrder Order { get; set; }

        [JsonProperty("customFields")]
        public CustomFields CustomFields { get; set; }

        public bool ShouldSerializeCustomFields()
        {

            if (CustomFields == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

    public class PaypalOrder
    {
        [JsonProperty("orderRef")]
        public string OrderRef { get; set; }

        [JsonProperty("shippingAddress")]
        public PaypalShippingAddress ShippingAddress { get; set; }
    }
    public class PaypalCustomerRequestModel
    {
        [JsonProperty("merchantRef")]
        public string MerchantRef { get; set; }

        [JsonProperty("displayName")]
        public string DisplayName { get; set; }

        [JsonProperty("registered")]
        public string Registered { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("ip")]
        public string IpAddress { get; set; }

        [JsonProperty("telephone")]
        public string Telephone { get; set; }

        public bool ShouldSerializeTelephone()
        {
            // don't serialize the Telephone property if it is NULL or Empty
            if (string.IsNullOrWhiteSpace(Telephone))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        [JsonProperty("billingAddress")]
        public PaypalCustomerBillingAddress CustomerBillingAddress { get; set; }

    }

    public class PaypalTransactionOptionsModel
    {       
        [JsonProperty("sendEmailReceipt")]
        public bool SendEmailReceipt { get; set; }
    }

}
