﻿namespace Application.Common.Models.ResponseWrappers;

public class Result<T>
{
    public bool Status { get; set; }
    public string? Message { get; set; }
    public T? Data { get; set; }
    public int ErrorCode { get; set; }
    public Dictionary<string, string>? Errors { get; set; }

    public static Result<T> Success(T payload, string message)
    {
        return new Result<T>
        {
            Data = payload,
            ErrorCode = 0,
            Message = message,
            Errors = null,
            Status = true
        };
    }
    public static Result<T> Success(string message)
    {
        return new Result<T>
        {
            ErrorCode = 0,
            Message = message,
            Status = true,
            Data = default,
            Errors = null
        };
    }
    public static Result<T> Failure(
        string message,
        int errorCode,
        Dictionary<string, string> errors)
    {
        return new Result<T>
        {
            ErrorCode = errorCode,
            Message = message,
            Errors = errors,
            Data = default,
            Status = false
        };
    }
    public static Result<T> Failure(
        string message,
        int errorCode)
    {
        return new Result<T>
        {
            ErrorCode = errorCode,
            Message = message,
            Data = default,
            Status = false,
            Errors = null
        };
    }
    public static Result<T> Failure(
            T payload,
            string message,
            int errorCode)
    {
        return new Result<T>
        {
            Data = payload,
            ErrorCode = errorCode,
            Message = message,
            Status = false,
            Errors = null
        };
    }
    public static Result<T> Failure(
        T payload,
        string message,
        int errorCode,
        Dictionary<string, string> errors)
    {
        return new Result<T>
        {
            Data = payload,
            ErrorCode = errorCode,
            Message = message,
            Errors = errors,
            Status = false
        };
    }
}
