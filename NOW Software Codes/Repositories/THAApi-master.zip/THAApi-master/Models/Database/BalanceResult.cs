﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    public class BalanceResult
    {
        public decimal new_balance { get; set; }

        public int audit_id { get; set; }
    }
    public class ChargeSubscriberResult
    {
        public int Result { get; set; }
    }

    
}
