﻿namespace Application.Features.Device.NotificationToken;

public class NotificationTokenRequestHandler : IRequestHandler<NotificationTokenRequest, Result<object>>
{
    private readonly IStringLocalizer<NotificationTokenRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;

    public NotificationTokenRequestHandler(
        IStringLocalizer<NotificationTokenRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
    }

    public async Task<Result<object>> Handle(NotificationTokenRequest request, CancellationToken cancellationToken)
    {
        var device = _commonService.IsAppRequest();
        await _unitOfWork.DeviceRepo.SaveUserDeviceNotificationToken(request.DeviceToken, request.DeviceId, (DeviceType) device.Item2!);
        return Result<object>.Success(_localizer[CustomStatusKey.Success]);
    }
}