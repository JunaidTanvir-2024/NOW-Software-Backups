﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class Offer_DL : IOffer_DL
    {

        private readonly ConnectionStrings _dbConnections;
        public Offer_DL(IOptions<ConnectionStrings> dbConnections)
        {
            _dbConnections = dbConnections.Value;
        }

        /// <summary>
        /// Add Greece Topup Offer
        /// </summary>
        /// <param name="userAccount"></param>
        /// <returns></returns>
        public async Task<bool> AddGreeceTopupOffer(UserAccount userAccount)
        {
            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
            {
                await dbConnection.ExecuteAsync("AccountUpdateBalance", new
                {
                    account = userAccount.AccountID,
                    channel = 1,
                    amount = 100m,
                    bonus = 0m,
                    creditReason = "TALK HOME App - Greece Topup Offer",
                    paymentMethod = "",
                    rechargeType = 45,
                    reference = "TALK HOME App - Greece Topup Offer",
                    ccsTransId = 0,
                    ccAuthCode = "THASU-PRM1"
                }, commandType: CommandType.StoredProcedure);
                
                return true;
            }
        }
    }
}
