﻿$("#resetpasswordform").validate({
    rules: {
        Email: {
            required: true
        },

    },
    messages: {
        Email: {
            required: "Please provide an Email"
        }
    },
});
$('#email').keyup(function () {
    if ($('#forgotpasswordErrorDiv').is(':visible'))
    $("#forgotpasswordErrorDiv").hide();
});

$("#resetpasswordform").on("submit", function () {


    if ($("#resetpasswordform").valid() !== true) {
        return;
    }
    else {
        var model = {};
        model.Email = $("#email").val();
        $.ajax({
            type: "POST",
            url: "/ResetForgotPassword",
            data: model,
            success: function (json) {
                if (json && json.errorCode != 0) {
                    $("#forgotpasswordErrorDiv").show();
                    $("#forgotpasswordErrorDiv").text(json.key)
                }
                else if (json && json.errorCode == 0) {
                    window.location.href = "/success/" + json.key
                }
            },
            error: function (error) {
                var a = error;
                alert("Error: " + a.responseText);
            }
        });
    }
    return false;
});