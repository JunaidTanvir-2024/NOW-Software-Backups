using RW;

using Voucherify.Api.Features.Customers;
using Voucherify.Api.Features.Customers.Requests;
using Voucherify.Api.Features.Promotions.Requests;
using Voucherify.Api.Features.Promotions.Responses;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Domain.Definitions;
using Voucherify.Core.Services.VoucherifyApi;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;
using Voucherify.Core.Services.VoucherifyApi.Models.Orders;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Api.Features.Promotions;

public interface IPromotionsHandler
{
    Task<IResultWrapper<PromotionTierResponse>> GetPromotionTier(GetPromotionTierByIdRequest request);
    Task<IResultWrapper<List<PromotionTierResponse>>> GetPromotionTiers(GetPromotionTiersRequest request);
    Task<IResultWrapper<PromotionTierValidationResponse>> PromotionTierValidation(ValidatePromotionTierRequest request);
    Task<IResultWrapper<PromotionTierRedemptionResponse>> PromotionTierRedemption(RedeemPromotionTierRequest request);
    Task<IResultWrapper<PromotionTierResponse>> GetPromotionTiersForCustomer(GetCustomerSpecificPromotionTiersRequest request);
}

internal class PromotionsHandler : IPromotionsHandler
{
    private readonly IVoucherifyImplementation _voucherifyImplementation;
    private readonly ICustomersHandler _customersHandler;

    public PromotionsHandler(
        IVoucherifyImplementation voucherifyImplementation,
        ICustomersHandler customersHandler)
    {
        _voucherifyImplementation = voucherifyImplementation;
        _customersHandler = customersHandler;
    }

    public async Task<IResultWrapper<List<PromotionTierResponse>>> GetPromotionTiers(GetPromotionTiersRequest request)
    {
        var promotions = await _voucherifyImplementation.GetPromotionTiers(request.PageNumber, request.PageSize);
        
        if (promotions != null)
        {
            var result = promotions?.Select(promotion => new PromotionTierResponse()
            {
                PromotionId = promotion.Id,
                Name = promotion.Name,
                Banner = promotion.Banner,
                Metadata = promotion.Metadata,
                Category = promotion.Category,
                CategoryId = promotion.CategoryId,
                CampaignId = promotion.Campaign?.Id,
                CampaignStartDate = promotion.Campaign?.StartDate,
                IsCampaignActive = promotion.Campaign?.Active,
                CampaignExpirationDate = promotion.Campaign?.ExpirationDate,
                AmountOff = promotion.Discount?.AmountOff,
                PercentOff = promotion?.Discount?.PercentOff,
                UnitOff = promotion?.Discount?.UnitOff,
                UnitType = promotion?.Discount?.UnitType,
                AmountLimit = promotion?.Discount?.AmountLimit,
                DiscountType = Convert.ToString(promotion?.Discount?.Type),
                DiscountEffect = Convert.ToString(promotion?.Discount?.Effect)
            }).ToList();

            return ResultWrapper.Success(result);
        }
        return ResultWrapper.Failure<List<PromotionTierResponse>>(AppConstants.StatusMessages.PromotionNotFound, AppConstants.StatusCodes.PromotionNotFound);
    }
    public async Task<IResultWrapper<PromotionTierResponse>> GetPromotionTier(GetPromotionTierByIdRequest request)
    {
        var promotion = await _voucherifyImplementation.GetPromotionTierById(request.PromotionTierId);
        return promotion != null ?
            ResultWrapper.Success(new PromotionTierResponse()
            {
                PromotionId = promotion.Id,
                Name = promotion.Name,
                Banner = promotion.Banner,
                Metadata = promotion.Metadata,
                Category = promotion.Category,
                CategoryId = promotion.CategoryId,
                CampaignId = promotion.Campaign?.Id,
                CampaignStartDate = promotion.Campaign?.StartDate,
                IsCampaignActive = promotion.Campaign?.Active,
                CampaignExpirationDate = promotion.Campaign?.ExpirationDate,
                AmountOff = promotion.Discount?.AmountOff,
                PercentOff = promotion?.Discount?.PercentOff,
                UnitOff = promotion?.Discount?.UnitOff,
                UnitType = promotion?.Discount?.UnitType,
                AmountLimit = promotion?.Discount?.AmountLimit,
                DiscountType = Convert.ToString(promotion?.Discount?.Type),
                DiscountEffect = Convert.ToString(promotion?.Discount?.Effect)
            }) :
            ResultWrapper.Failure<PromotionTierResponse>(AppConstants.StatusMessages.PromotionNotFound, AppConstants.StatusCodes.PromotionNotFound);
    }
    public async Task<IResultWrapper<PromotionTierValidationResponse>> PromotionTierValidation(ValidatePromotionTierRequest request)
    {
        var customerRecord = await _customersHandler.GetCustomer(new GetCustomerRequest()
        {
            CustomerSourceId = request.CustomerSourceId!
        });
        var customer = new Customer()
        {
            SourceId = customerRecord.Payload?.SourceId,
            Email = customerRecord.Payload?.Email,
            Phone = customerRecord.Payload?.Phone,
            Name = customerRecord.Payload?.Name,
            Description = customerRecord.Payload?.Description,
            Id = customerRecord.Payload?.Id,
            Address = new Address()
            {
                Country = customerRecord.Payload?.Country,
                State = customerRecord.Payload?.State,
                City = customerRecord.Payload?.City,
                Line1 = customerRecord.Payload?.AddressLine1,
                Line2 = customerRecord.Payload?.AddressLine2,
                PostalCode = customerRecord.Payload?.PostalCode
            },
            Loyalty = new CustomerLoyalty()
            {
                Campaigns = customerRecord.Payload?.LoyaltyCampaigns,
                Points = customerRecord?.Payload?.Points > 0 ? Convert.ToInt32(customerRecord?.Payload?.Points) : 0,
                ReferredCustomers = customerRecord?.Payload?.ReferredCustomers > 0 ? Convert.ToInt32(customerRecord?.Payload?.ReferredCustomers) : 0,
            },
            Metadata = request.CustomerMetadata
        };

        var result = await _voucherifyImplementation.ValidatePromotion(request.PromotionTierId, customer);

        return result != null ?
            ResultWrapper.Success(new PromotionTierValidationResponse()
            {
                IsValid = result!.Valid,
                PromotionTierId = result.Id,
            }) :
            ResultWrapper.Failure<PromotionTierValidationResponse>(AppConstants.StatusMessages.PromotionInvalid, AppConstants.StatusCodes.PromotionInvalid);
    }

    public async Task<IResultWrapper<PromotionTierResponse>> GetPromotionTiersForCustomer(GetCustomerSpecificPromotionTiersRequest request)
    {
        var customerRecord = await _customersHandler.GetCustomer(new GetCustomerRequest()
        {
            CustomerSourceId = request.Customer.SourceId!
        });
        var customer = new Customer()
        {
            SourceId = customerRecord.Payload?.SourceId,
            Email = customerRecord.Payload?.Email,
            Phone = customerRecord.Payload?.Phone,
            Name = customerRecord.Payload?.Name,
            Description = customerRecord.Payload?.Description,
            Id = customerRecord.Payload?.Id,
            Address = new Address()
            {
                Country = customerRecord.Payload?.Country,
                State = customerRecord.Payload?.State,
                City = customerRecord.Payload?.City,
                Line1 = customerRecord.Payload?.AddressLine1,
                Line2 = customerRecord.Payload?.AddressLine2,
                PostalCode = customerRecord.Payload?.PostalCode
            },
            Loyalty = new CustomerLoyalty()
            {
                Campaigns = customerRecord.Payload?.LoyaltyCampaigns,
                Points = customerRecord?.Payload?.Points > 0 ? Convert.ToInt32(customerRecord?.Payload?.Points) : 0,
                ReferredCustomers = customerRecord?.Payload?.ReferredCustomers > 0 ? Convert.ToInt32(customerRecord?.Payload?.ReferredCustomers) : 0,
            },
            Metadata = request.Customer.Metadata
        };
        
        var order = new OrderCreate()
        {
            Items = new List<OrderItem>() { new OrderItem() { SkuId = request.Order.SkuId, Quantity = request.Order.Quantity == null ? 1 : request.Order.Quantity, Amount = request.Order.Amount } },
            Metadata = request.Order.Metadata
        };

        var promotions = await _voucherifyImplementation.GetValidPromotions(customer, order, request.ValidationMetadata);

        var promotion = promotions?.Where(x => x.Metadata != null && x.Metadata?.ContainsKey("priority") == true)
                            .OrderBy(y => y.Metadata!["priority"].StringToInt())
                            .FirstOrDefault();

        // If promotion is null (no promotions with priority defined), get the first result
        if (promotions != null && promotion == null)
        {
            promotion = promotions?.FirstOrDefault();
        }

        return promotion != null ?
            ResultWrapper.Success(new PromotionTierResponse()
            {
                PromotionId = promotion.Id,
                Name = promotion.Name,
                Banner = promotion.Banner,
                Metadata = promotion.Metadata,
                Category = promotion.Category,
                CategoryId = promotion.CategoryId,
                CampaignId = promotion.Campaign?.Id,
                CampaignStartDate = promotion.Campaign?.StartDate,
                IsCampaignActive = promotion.Campaign?.Active,
                CampaignExpirationDate = promotion.Campaign?.ExpirationDate,
                AmountOff = promotion.Discount?.AmountOff,
                PercentOff = promotion?.Discount?.PercentOff,
                UnitOff = promotion?.Discount?.UnitOff,
                UnitType = promotion?.Discount?.UnitType,
                AmountLimit = promotion?.Discount?.AmountLimit,
                DiscountType = Convert.ToString(promotion?.Discount?.Type),
                DiscountEffect = Convert.ToString(promotion?.Discount?.Effect)
            }) :
            ResultWrapper.Failure<PromotionTierResponse>(AppConstants.StatusMessages.PromotionNotFound, AppConstants.StatusCodes.PromotionNotFound);
    }
    public async Task<IResultWrapper<PromotionTierRedemptionResponse>> PromotionTierRedemption(RedeemPromotionTierRequest request)
    {
        var customerData = new CustomerCreate()
        {
            SourceId = request.Customer.SourceId,
            Address = new Address()
            {
                City = request.Customer.City,
                Country = request.Customer.Country,
                Line1 = request.Customer.AddressLine1,
                Line2 = request.Customer.AddressLine2,
                PostalCode = request.Customer.PostalCode,
                State = request.Customer.State
            }
        };
        var result = await _voucherifyImplementation.RedeemVoucher(request.PromotionTierId, customerData);

        return result != null ?
            ResultWrapper.Success(new PromotionTierRedemptionResponse()
            {
                CustomerId = result?.Customer?.Id,
                CustomerMetadata = result?.Customer?.Metadata,
                Id = result?.Id,
                RedemptionDate = result?.Date,
                RedemptionStatus = result?.Result == RedemptionResult.Success,
                SourceId = result?.Customer?.SourceId,
                Voucher = result?.Voucher
            }) :
            ResultWrapper.Failure<PromotionTierRedemptionResponse>(AppConstants.StatusMessages.PromotionInvalid, AppConstants.StatusCodes.PromotionInvalid);
    }
}
