﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Airship.Request
{
    public class ApiWebNUserChannelAssociationRequest
    {
        [JsonProperty("channel_id")]
        public string ChannelId { get; set; }

        [JsonProperty("named_user_id")]
        public string NamedUserId { get; set; }
    }
}
