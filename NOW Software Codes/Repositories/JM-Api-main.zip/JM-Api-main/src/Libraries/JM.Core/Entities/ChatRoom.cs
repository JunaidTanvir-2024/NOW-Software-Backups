using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class ChatRoom : IBaseEntity<long>
{
    // public long Id { get; set; }
    // public string Name { get; set; } = null!;
    // public long InitiatorId { get; set; }
    // public long ResponderId { get; set; }
    // public User Initiator { get; set; } = null!;
    // public User Responder { get; set; } = null!;
    public long Id { get; set; }
    public string Name { get; set; } = null!;
    public bool IsPrivate { get; set; }
    public long TripId { get; set; }
    public Trip Trip { get; set; } = null!;
    public ICollection<ChatMessage> ChatMessages { get; set; } = new List<ChatMessage>();
}
