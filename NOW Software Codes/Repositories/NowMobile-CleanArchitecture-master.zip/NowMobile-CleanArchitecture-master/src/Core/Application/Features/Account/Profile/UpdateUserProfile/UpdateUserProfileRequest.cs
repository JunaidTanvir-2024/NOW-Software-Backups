﻿namespace Application.Features.Account.Profile.UpdateUserProfile;
public class UpdateUserProfileRequest : IRequest<Result<UserInfo>>
{
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public bool MailSubscription { get; set; } = default!;
    // public IFormFile Profile { get; set; } = null!;
    //public string? Path { get; set; } 
}
