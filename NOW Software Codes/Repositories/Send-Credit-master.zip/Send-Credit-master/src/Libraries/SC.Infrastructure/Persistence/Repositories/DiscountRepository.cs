﻿using SC.Core.Models.Dtos;
using SC.Core.Models.Entities;
using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Infrastructure.Persistence.Repositories
{
    public class DiscountRepository : IDiscountRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;

        public DiscountRepository(IConfiguration configuration, ILogger logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<IEnumerable<DiscountDto.Response>> GetDiscounts(DiscountDto.Request request)
        {
            try
            {
                using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
                {
                    var table = new DataTable();
                    table.Columns.Add("name", typeof(string));
                    table.Columns.Add("type", typeof(string));
                    table.Columns.Add("value", typeof(decimal));
                    table.Columns.Add("promo_code", typeof(string));
                    table.Columns.Add("start_date", typeof(DateTime));
                    table.Columns.Add("end_date", typeof(DateTime));

                    table.Rows.Add(request.Filters?.Name, request.Filters?.Type, request.Filters?.Value, request.Filters?.Promocode, request.Filters?.StartDate, request.Filters?.EndDate);

                    var discountParameters = new DynamicParameters();

                    discountParameters.Add("discountfilter", value: table.AsTableValuedParameter(AppConstants.TablesTypes.DiscountFilterType));

                    discountParameters.Add("is_active", request?.IsActive);
                    discountParameters.Add("is_deleted", request?.IsDeleted);

                    var discounts = await connection.QueryAsync<DiscountDto.Response>(AppConstants.StoreProcedures.GetDiscount, param: discountParameters, commandType: CommandType.StoredProcedure);
                    return discounts;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, nameof(DiscountEntity), nameof(GetDiscounts));
                return default!;
            }
        }
        public async Task<long> GetNoOfCustomersDiscountAvailedAsync(string? customerID, int DiscountTypeID)
        {
            using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
            {
                try
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@customer_id", customerID);
                    parameters.Add("@discount_type_id", DiscountTypeID);
                    parameters.Add("@order_status", OrderStatusEnum.Checkout.Getkey());

                    var result = await connection.ExecuteScalarAsync<long>(AppConstants.StoreProcedures.GetTotalCustomersDiscountAvailed, parameters, commandType: CommandType.StoredProcedure);
                    return result;
                }
                catch (Exception ex)
                {
                    _logger.Error("GetNoOfCustomersDiscountAvailedAsync, " +
                                    "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                    "StackTrace: " + ex.StackTrace);
                    return default;
                }
            }
        }
        public async Task<float> GetTotalOrderDiscountAmountByDiscountTypeID(string? customerID, int DiscountTypeID)
        {
            using (var connection = new SqlConnection(_configuration.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
            {
                try
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@customer_id", customerID);
                    parameters.Add("@discount_type_id", DiscountTypeID);
                    parameters.Add("@order_status", OrderStatusEnum.Checkout.Getkey());

                    var result = await connection.ExecuteScalarAsync<long>(AppConstants.StoreProcedures.GetTotalDiscountAmountByDiscountTypeID, parameters, commandType: CommandType.StoredProcedure);
                    return result;
                }
                catch (Exception ex)
                {
                    _logger.Error("GetNoOfCustomersDiscountAvailedAsync, " +
                                    "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                    "StackTrace: " + ex.StackTrace);
                    return default;
                }
            }
        }
    }
}