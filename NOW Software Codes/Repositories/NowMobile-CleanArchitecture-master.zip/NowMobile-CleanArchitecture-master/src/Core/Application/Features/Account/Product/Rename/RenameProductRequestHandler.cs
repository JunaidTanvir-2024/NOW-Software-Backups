﻿using Application.Common.Caching;
using Application.Features.Account.Product.Add;

namespace Application.Features.Account.Product.Rename;
public class RenameProductRequestHandler : IRequestHandler<RenameProductRequest, Result<object>>
{
    #region Fields
    private readonly IStringLocalizer<AddProductRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;
    private readonly ICurrentUser _currentUser;
    #endregion

    #region Ctor
    public RenameProductRequestHandler(IStringLocalizer<AddProductRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService,
        ICurrentUser currentUser)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _cacheService = cacheService;
        _cacheKeyService = cacheKeyService;
        _currentUser = currentUser;
    }
    #endregion

    #region Methods
    public async Task<Result<object>> Handle(RenameProductRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        //Check if product id exists user products
        var products = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        if (!products.Any(x => x.Msisdn != null && x.Msisdn.Equals(request.Msisdn, StringComparison.InvariantCultureIgnoreCase)))
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        await _unitOfWork.UserRepo.RenameProduct(new UserProduct() { Msisdn = request.Msisdn, Name = request.Alias });

        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.UserProduct, _currentUser.GetUserId().ToString()), cancellationToken);

        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }
    #endregion
}
