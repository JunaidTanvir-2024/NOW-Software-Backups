﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Configurations
{
    public class TransferToConfig
    {
        public string AttApiEndPoint { get; set; }
        public string AttPromotionApiEndPoint { get; set; }
        public bool AttSimulationMode { get; set; }
        public string AttUsernameGBP { get; set; }
        public string AttAppTokenGBP { get; set; }
        public string AttUsernameEUR { get; set; }
        public string AttAppTokenEUR { get; set; }
        public string AttUsernameEUR_GR { get; set; }
        public string AttAppTokenEUR_GR { get; set; }
        public string AttUsernameUSD { get; set; }
        public string AttAppTokenUSD { get; set; }
        public string AttFreeSwitchUsernameEUR { get; set; }
        public string AttFreeSwitchAppTokenEUR { get; set; }
        public string DataBundlesGsApiEndPoint { get; set; }
        public bool DataBundlesSimulationMode { get; set; }
        public string DataBundlesApiKeyGBP { get; set; }
        public string DataBundlesApiSecretGBP { get; set; }
        public string DataBundlesApiKeyEUR { get; set; }
        public string DataBundlesApiSecretEUR { get; set; }
        public string DataBundlesApiKeyUSD { get; set; }
        public string DataBundlesApiSecretUSD { get; set; }

        public string TRHUsernameGBP { get; set; }
        public string TRHAppTokenGBP { get; set; }
        public string TRHUsernameEUR { get; set; }
        public string TRHAppTokenEUR { get; set; }
        public string TRHUsernameUSD { get; set; }
        public string TRHAppTokenUSD { get; set; }
        

    }
}
