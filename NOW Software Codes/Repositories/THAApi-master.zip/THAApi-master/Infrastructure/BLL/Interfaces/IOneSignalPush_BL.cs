﻿using Infrastructure.BLL.Interfaces.Languages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
	public interface IOneSignalPush_BL
    {
        Task<bool> NotifyUser(string msisdn, Func<IMessageService, string> messageFunc, string data = null);

        Task<bool> NotifyUsers(string[] msisdns, Func<IMessageService, string> messageFunc);
    }
}
