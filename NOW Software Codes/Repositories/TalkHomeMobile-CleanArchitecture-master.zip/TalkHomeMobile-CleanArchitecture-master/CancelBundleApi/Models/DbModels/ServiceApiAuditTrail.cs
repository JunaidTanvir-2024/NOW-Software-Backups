﻿namespace CancelBundleApi.Models.DbModels
{
    public class ServiceApiAuditTrail
    {
        public int ServiceAuditTrailId { set; get; }
        public int LkptServiceId { set; get; }
        public string ApiEndPoint { set; get; }
        public long StartTimeUnixTimeStamp { set; get; }
        public long EndTimeUnixTimestamp { set; get; }
        public long TotalTimeMs { set; get; }
        public string RequestData { set; get; }
        public string ResponseData { set; get; }
        public string Error { set; get; }
        public bool IsViewable { set; get; }
        public string? HttpMethod { set; get; }
        public string? ServiceCorrelationGuid { set; get; }
    }
}
