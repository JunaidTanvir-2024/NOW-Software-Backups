﻿namespace SenderService.Core.Features.ProductCode.Request;
public class GetProductCodeByIdRequest
{
    public long Id { get; set; }
}
