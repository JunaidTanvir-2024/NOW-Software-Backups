﻿using System;
using System.Collections.Generic;
using System.Text;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class TransferByPayPalResponseModel
    {
        public string clientRedirectUrl { get; set; }
        public InternationalTopupProduct productData { get; set; }
    }
}
