﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Infrastructure.Utilities;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services
{
    internal class Pay360Service : IPay360Service
    {
        private readonly IApiCall _apiCall;
        private readonly ILogger _logger;
        private readonly IAddressService _addressService;

        private readonly Pay360Config _pay360Config;

        public Pay360Service(
            ILogger logger,
            IApiCall apiCall,
            IAddressService addressService,
            IOptions<Pay360Config> pay360Conf)
        {
            _logger = logger;
            _apiCall = apiCall;
            _pay360Config = pay360Conf.Value;
            _addressService = addressService;
        }

        public async Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType)
        {
            string endpoint = String.Empty;
            string json = String.Empty;
            HttpResponseMessage result = null;

            switch (paymentType)
            {
                case Pay360PaymentType.New:
                    request.Pay360PaymentRequestNew.sendPay360Email = _pay360Config.sendPay360Email;
                    endpoint = _pay360Config.ApiEndPoint + "/Pay360CashierApi/NewCustomerPayment";
                    json = JsonConvert.SerializeObject(request.Pay360PaymentRequestNew);
                    result = await _apiCall.PostAsync(endpoint, json);
                    break;
                case Pay360PaymentType.Default:
                    request.Pay360PaymentRequestDefault.sendPay360Email = _pay360Config.sendPay360Email;
                    endpoint = _pay360Config.ApiEndPoint + "/Pay360CashierApi/ExistingCustomerPaymentDefaultCard";
                    json = JsonConvert.SerializeObject(request.Pay360PaymentRequestDefault);
                    result = await _apiCall.PostAsync(endpoint, json);
                    break;
                case Pay360PaymentType.ExistingNew:
                    request.Pay360PaymentRequestExistingNew.sendPay360Email = _pay360Config.sendPay360Email;
                    endpoint = _pay360Config.ApiEndPoint + "/Pay360CashierApi/ExistingCustomerPaymentNewCard";
                    json = JsonConvert.SerializeObject(request.Pay360PaymentRequestExistingNew);
                    result = await _apiCall.PostAsync(endpoint, json);
                    break;
                case Pay360PaymentType.Token:
                    request.Pay360PaymentRequestToken.sendPay360Email = _pay360Config.sendPay360Email;
                    endpoint = _pay360Config.ApiEndPoint + "/Pay360CashierApi/PaymentToken";
                    json = JsonConvert.SerializeObject(request.Pay360PaymentRequestToken);
                    result = await _apiCall.PostAsync(endpoint, json);
                    break;
            }

            var responseString = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                _logger.Error($"Service: Pay360Service, Method: Pay360Payment, Request: {JsonConvert.SerializeObject(json)},  Response: {responseString}-{result.StatusCode}");

                return null;
            }

            return JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360PaymentResponse>>(responseString);
        }
        public async Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Resume3DV1Transaction(Pay360Resume3DRequest request)
        {
            string endpoint = _pay360Config.ApiEndPoint + "/Pay360CashierApi/Resume3DSecureTransaction";

            var Json = JsonConvert.SerializeObject(request);

            var result = await _apiCall.PostAsync(endpoint, Json);

            var responseString = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                _logger.Error($"Service: Pay360Service, Method: Resume3DV1Transaction, Request: {JsonConvert.SerializeObject(Json)},  Response: {responseString}-{result.StatusCode}");

                return null;
            }

            return JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360PaymentResponse>>(responseString);
        }
        public async Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Resume3DV2Transaction(Pay360Resume3DRequest request)
        {
            string endpoint = _pay360Config.ApiEndPoint + "/Pay360CashierApi/Resume3DsV2";

            var Json = JsonConvert.SerializeObject(request);

            var result = await _apiCall.PostAsync(endpoint, Json);

            var responseString = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                _logger.Error($"Service: Pay360Service, Method: Resume3DV2Transaction, Request: {JsonConvert.SerializeObject(Json)},  Response: {responseString}-{result.StatusCode}");

                return null;
            }

            return JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360PaymentResponse>>(responseString);
        }
        public async Task<GenericPay360ApiResponse<RefundFullPaymentResponseModel>> RefundFullPayment(RefundFullPaymentRequestModel request)
        {

            string endpoint = _pay360Config.ApiEndPoint + "/Pay360CommonServices/RefundFullPayment";

            var Json = JsonConvert.SerializeObject(request);
            HttpResponseMessage result = await _apiCall.PostAsync(endpoint, Json);

            var responseString = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                _logger.Error($"Service: Pay360Service, Method: RefundFullPayment, Request: {JsonConvert.SerializeObject(Json)},  Response: {responseString}-{result.StatusCode}");

                return null;
            }

            return JsonConvert.DeserializeObject<GenericPay360ApiResponse<RefundFullPaymentResponseModel>>(responseString);
        }
        public async Task<GenericPay360ApiResponse<CaptureTransactionResponseModel>> CaptureTransaction(CaptureTransactionRequestModel model)
        {
            string endpoint = _pay360Config.ApiEndPoint + "/Pay360CommonServices/CaptureTransaction";

            var Json = JsonConvert.SerializeObject(model);

            HttpResponseMessage result = await _apiCall.PostAsync(endpoint, Json);

            var responseString = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                _logger.Error($"Service: Pay360Service, Method: CaptureTransaction, Request: {JsonConvert.SerializeObject(Json)},  Response: {responseString}-{result.StatusCode}");

                return null;
            }

            return JsonConvert.DeserializeObject<GenericPay360ApiResponse<CaptureTransactionResponseModel>>(responseString);

        }
        public async Task CancelTransaction(CancelTransactionRequestModel model)
        {
            string endpoint = _pay360Config.ApiEndPoint + "/Pay360CommonServices/CancelTransaction";

            var Json = JsonConvert.SerializeObject(model);

            HttpResponseMessage result = await _apiCall.PostAsync(endpoint, Json);

            var responseString = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                _logger.Error($"Service: Pay360Service, Method: cancelTransaction, Request: {JsonConvert.SerializeObject(Json)},  Response: {responseString}-{result.StatusCode}");
            }
        }
        public async Task<GenericPay360ApiResponse<GetAddressByPostCodeResponseModel>> GetAddressByPostCode(GetAddressByPostCodeRequestModel model)
        {
            var addressRespons = new GetAddressByPostCodeResponseModel();

            var response = await _addressService.GetAddress(model.PostCode);
            if (response.StatusCode == HttpStatusCode.OK)
            {
                var addresseslist = await response.Content.ReadAsStringAsync();
                addressRespons.AddressData = JsonConvert.DeserializeObject<AddressModel>(addresseslist);
                addressRespons.AddressData.Addresses = addressRespons.AddressData.Addresses.OrderBy(s=>s,new AlphaNumericSort()).ToList();
                return GenericPay360ApiResponse<GetAddressByPostCodeResponseModel>.Success(
                                                                addressRespons, "Found addresses successfully");
            }
            else if (response.StatusCode == HttpStatusCode.NotFound
                            || response.StatusCode == HttpStatusCode.BadRequest)
            {
                return GenericPay360ApiResponse<GetAddressByPostCodeResponseModel>.Failure(
                                                                null, "No address found", ApiStatusCodes.NoAddressFound);
            }
            else if (response.StatusCode == HttpStatusCode.Unauthorized)
            {
                //send email + message to management




                return GenericPay360ApiResponse<GetAddressByPostCodeResponseModel>.Failure(
                                                    null, "No address found", ApiStatusCodes.NoAddressFound);
            }

            return GenericPay360ApiResponse<GetAddressByPostCodeResponseModel>.Failure(
                                             null, "Something went wrong on server", ApiStatusCodes.InternalServerError);
        }
        public async Task<GenericPay360ApiResponse<bool>> SetAutoTopUp(SetAutoTopUpRequestModel model, string msisdn, string currency, string email)
        {
            string endpoint = _pay360Config.ApiEndPoint + "/Pay360CommonServices/SetAutoTopup";

            Pay360SetAutoTopUpRequest request = new Pay360SetAutoTopUpRequest()
            {
                isAutoTopup = model.isActive,
                thresholdBalanceAmount = model.thresholdBalanceAmount,
                topupAmount = model.amount,
                productCode = ProductCode.THA.ToString(),
                productItemCode = ProductItemCode.THAATA.ToString(),
                productRef = msisdn,
                topupCurrency = currency,
                Email = !string.IsNullOrEmpty(email) ? email : "dummy@gmail.com"
            };

            var Json = JsonConvert.SerializeObject(request);

            var Result = await _apiCall.PostAsync(endpoint, Json);

            if (!Result.IsSuccessStatusCode || Result.Content == null)
            {
                return GenericPay360ApiResponse<bool>.Failure("Failure", ApiStatusCodes.PayloadEmpty);
            }
            else
            {
                var response = await Result.Content.ReadAsStringAsync();
                var respModel = JsonConvert.DeserializeObject<GenericPay360ApiResponse<string>>(response);
                if (respModel.ErrorCode == 0)
                {
                    return GenericPay360ApiResponse<bool>.Success(true, "Success");
                }
                else
                {
                    return GenericPay360ApiResponse<bool>.Failure("Failure", ApiStatusCodes.PayloadEmpty);
                }
            }
        }
        public async Task<GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(string msisdn, string email)
        {
            var model = new Pay360GetAutoTopUpRequest()
            {
                Email = !string.IsNullOrEmpty(email) ? email : "dummy@gmail.com",
                Msisdn = msisdn,
                ProductCode = ProductCode.THA.ToString()
            };

            string endpoint = _pay360Config.ApiEndPoint + "/Pay360CommonServices/GetAutoTopup";

            var Json = JsonConvert.SerializeObject(model);

            var Result = await _apiCall.PostAsync(endpoint, Json);

            if (!Result.IsSuccessStatusCode || Result.Content == null)
            {
                return GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>.Failure("Failure", ApiStatusCodes.PayloadEmpty);
            }

            var response = await Result.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>>(response);
        }
        public async Task<GenericPay360ApiResponse<PaymentMethodsPayload>> GetPaymentMethods(string msisdn)
        {

            try
            {
                string url = _pay360Config.ApiEndPoint + "/Pay360CommonServices/GetCustomerPaymentMethodsByCustomerUniqueRef";
                PaymentMethodsRequest request = new PaymentMethodsRequest() { CustomerUniqueRef = msisdn, ProductCode = "THA" };
                string jsonRequest = JsonConvert.SerializeObject(request);
                HttpResponseMessage httpResponse = await _apiCall.PostAsync(url, jsonRequest);
                if (httpResponse == null)
                {
                    _logger.Error($"Class: Pay360Service, Method: GetPaymentMethods, Parameters: msisdn: {msisdn}, {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received from Pay360 Api.");
                    return GenericPay360ApiResponse<PaymentMethodsPayload>.Failure("Null response received from Pay360 Api.", ApiStatusCodes.CodeException);
                }
                else
                {
                    if (httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        PaymentMethodsResponse apiResponseModel = JsonConvert.DeserializeObject<PaymentMethodsResponse>(responseJson);
                        if (apiResponseModel.errorCode == 0) // Success
                        {
                            for (int i = 0; i < apiResponseModel.payload.paymentMethodResponses.Count; i++)
                            {
                                apiResponseModel.payload.paymentMethodResponses[i].Card.CardLogo = GetCardLogo(apiResponseModel.payload.paymentMethodResponses[i].Card.CardScheme);
                            }
                            return GenericPay360ApiResponse<PaymentMethodsPayload>.Success(apiResponseModel.payload, "Success");
                        }
                        else // Error
                        {
                            return GenericPay360ApiResponse<PaymentMethodsPayload>.Success(new PaymentMethodsPayload(), "Success");
                        }
                    }
                    else if (httpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        return GenericPay360ApiResponse<PaymentMethodsPayload>.Failure(responseJson, ApiStatusCodes.Pay360Error);
                    }
                    else
                    {
                        return GenericPay360ApiResponse<PaymentMethodsPayload>.Failure("Failure", ApiStatusCodes.Pay360Error);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Pay360Service, Method: GetPaymentMethods, Parameters: msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericPay360ApiResponse<PaymentMethodsPayload>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public string GetCardLogo(string cardScheme)
        {
            string cardLogo = "";
            if (string.IsNullOrEmpty(cardScheme))
                return cardLogo;

            cardScheme = cardScheme.ToLower();

            if (cardScheme.Contains("amex"))
            {
                cardLogo = "/card_logo/Amex.png";
            }
            else if (cardScheme.Contains("master"))
            {
                cardLogo = "/card_logo/mastercard.png";
            }
            else if (cardScheme.Contains("visa"))
            {
                cardLogo = "/card_logo/visa.png";
            }
            else if (cardScheme.Contains("discover"))
            {
                cardLogo = "/card_logo/Discover.png";
            }
            else if (cardScheme.Contains("jcb"))
            {
                cardLogo = "/card_logo/JCB.png";
            }
            else if (cardScheme.Contains("union"))
            {
                cardLogo = "/card_logo/UnionPay.png";
            }
            return cardLogo;
        }
        public async Task<GenericPay360ApiResponse<bool>> RemoveCard(string msisdn, RemoveCardUserRequest removeCardReq)
        {

            try
            {
                string url = _pay360Config.ApiEndPoint + "/Pay360CommonServices/GetCustomerByCustomerUniqueRef";
                GetCustomerRequest request = new GetCustomerRequest() { CustomerUniqueRef = msisdn, ProductCode = "THA" };
                string jsonRequest = JsonConvert.SerializeObject(request);
                HttpResponseMessage httpResponse = await _apiCall.PostAsync(url, jsonRequest);
                if (httpResponse == null)
                {
                    _logger.Error($"Class: Pay360Service, Method: RemoveCard, Parameters: msisdn: {msisdn}, {JsonConvert.SerializeObject(removeCardReq)}, {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received from Pay360 Api(GetCustomerByCustomerUniqueRef).");
                    return GenericPay360ApiResponse<bool>.Failure("Null response received from Pay360 Api(GetCustomerByCustomerUniqueRef).", ApiStatusCodes.CodeException);
                }
                else
                {
                    if (httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        GetCustomerResponse apiResponseModel = JsonConvert.DeserializeObject<GetCustomerResponse>(responseJson);
                        if (apiResponseModel.errorCode == 0) // Success
                        {
                            string url2 = _pay360Config.ApiEndPoint + "/Pay360CommonServices/RemoveCard";
                            RemoveCardRequest cardReq = new RemoveCardRequest() { CardToken = removeCardReq.CardToken, Pay360CustomerID = apiResponseModel.payload.Pay360CustId.ToString(CultureInfo.InvariantCulture) };
                            string jsonCardRequest = JsonConvert.SerializeObject(cardReq);
                            HttpResponseMessage cardHttpResponse = await _apiCall.PostAsync(url2, jsonCardRequest);
                            if (cardHttpResponse == null)
                            {
                                _logger.Error($"Class: Pay360Service, Method: RemoveCard, Parameters: msisdn: {msisdn}, {JsonConvert.SerializeObject(removeCardReq)}, {JsonConvert.SerializeObject(cardReq)}, ErrorMessage: Null response received from Pay360 Api(RemoveCard).");
                                return GenericPay360ApiResponse<bool>.Failure("Null response received from Pay360 Api(RemoveCard).", ApiStatusCodes.CodeException);
                            }
                            else
                            {
                                if (cardHttpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                                {
                                    string responseJsonCard = cardHttpResponse.Content.ReadAsStringAsync().Result;
                                    RemoveCardResponse apiResponseModelCard = JsonConvert.DeserializeObject<RemoveCardResponse>(responseJsonCard);
                                    if (apiResponseModelCard.errorCode == 0) // Success
                                    {
                                        return GenericPay360ApiResponse<bool>.Success(true, "Success");
                                    }
                                    else // Failure
                                    {
                                        return GenericPay360ApiResponse<bool>.Failure(apiResponseModelCard.message, ApiStatusCodes.Pay360Error);
                                    }

                                }
                                else if (cardHttpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                                {
                                    string responseJson2 = cardHttpResponse.Content.ReadAsStringAsync().Result;
                                    return GenericPay360ApiResponse<bool>.Failure(responseJson2, ApiStatusCodes.Pay360Error);
                                }
                                else
                                {
                                    return GenericPay360ApiResponse<bool>.Failure("Failure", ApiStatusCodes.Pay360Error);
                                }
                            }
                        }
                        else // Error
                        {
                            return GenericPay360ApiResponse<bool>.Failure(apiResponseModel.message, ApiStatusCodes.Pay360Error);
                        }
                    }
                    else if (httpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        return GenericPay360ApiResponse<bool>.Failure(responseJson, ApiStatusCodes.Pay360Error);
                    }
                    else
                    {
                        return GenericPay360ApiResponse<bool>.Failure("Failure", ApiStatusCodes.Pay360Error);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Pay360Service, Method: RemoveCard, Parameters: msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericPay360ApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericPay360ApiResponse<RemoveAllPaymentMethodsResponse>> RemoveAllCardsAsync(string msisdn)
        {
            var result = new RemoveAllPaymentMethodsResponse();
            try
            {

                var cards = await GetPaymentMethods(msisdn);
                string url = _pay360Config.ApiEndPoint + "/Pay360CommonServices/GetCustomerByCustomerUniqueRef";
                GetCustomerRequest request = new GetCustomerRequest() { CustomerUniqueRef = msisdn, ProductCode = "THA" };
                string jsonRequest = JsonConvert.SerializeObject(request);
                HttpResponseMessage httpResponse = await _apiCall.PostAsync(url, jsonRequest);
                if (httpResponse == null)
                {
                    _logger.Error($"Class: Pay360Service, Method: RemoveCard, Parameters: msisdn: {msisdn}, {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received from Pay360 Api(GetCustomerByCustomerUniqueRef).");
                    return GenericPay360ApiResponse<RemoveAllPaymentMethodsResponse>.Failure("Null response received from Pay360 Api(GetCustomerByCustomerUniqueRef).", ApiStatusCodes.CodeException);
                }
                else
                {
                    if (httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        GetCustomerResponse apiResponseModel = JsonConvert.DeserializeObject<GetCustomerResponse>(responseJson);
                        if (apiResponseModel.errorCode == 0) // Success
                        {
                            var removeCardsResult = new List<(string cardToken, bool status, ApiStatusCodes? statusCode,string errorMsg)>();
                            foreach (var card in cards.Payload.paymentMethodResponses)
                            {
                                string url2 = _pay360Config.ApiEndPoint + "/Pay360CommonServices/RemoveCard";
                                RemoveCardRequest cardReq = new RemoveCardRequest() { CardToken = card.Card.CardToken, Pay360CustomerID = apiResponseModel.payload.Pay360CustId.ToString(CultureInfo.InvariantCulture) };
                                string jsonCardRequest = JsonConvert.SerializeObject(cardReq);
                                HttpResponseMessage cardHttpResponse = await _apiCall.PostAsync(url2, jsonCardRequest);
                                if (cardHttpResponse == null)
                                {
                                    _logger.Error($"Class: Pay360Service, Method: RemoveCard, Parameters: msisdn: {msisdn}, {JsonConvert.SerializeObject(card.Card.CardToken)}, {JsonConvert.SerializeObject(cardReq)}, ErrorMessage: Null response received from Pay360 Api(RemoveCard).");
                                    removeCardsResult.Add((card.Card.CardToken,false,ApiStatusCodes.CodeException, "Null response received from Pay360 Api(RemoveCard)."));
                                    continue;
                                }
                                else
                                {
                                    if (cardHttpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                                    {
                                        string responseJsonCard = cardHttpResponse.Content.ReadAsStringAsync().Result;
                                        RemoveCardResponse apiResponseModelCard = JsonConvert.DeserializeObject<RemoveCardResponse>(responseJsonCard);
                                        if (apiResponseModelCard.errorCode == 0) // Success
                                        {
                                            _logger.Information($"Class: Pay360Service, Method: RemoveAllCards, Parameters: msisdn: {msisdn}, {JsonConvert.SerializeObject(card.Card.CardToken)}, {JsonConvert.SerializeObject(cardReq)}, Message: Cards removed successfully.");

                                            removeCardsResult.Add((card.Card.CardToken, true, null, "Success"));
                                        }
                                        else // Failure
                                        {
                                            _logger.Error($"Class: Pay360Service, Method: RemoveAllCards, Parameters: msisdn: {msisdn}, {JsonConvert.SerializeObject(card.Card.CardToken)}, {JsonConvert.SerializeObject(cardReq)}, ErrorMessage: Error occured while removing card.");

                                            removeCardsResult.Add((card.Card.CardToken, false, ApiStatusCodes.Pay360Error, apiResponseModelCard.message));
                                        }
                                    }
                                    else if (cardHttpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                                    {
                                        string responseJson2 = cardHttpResponse.Content.ReadAsStringAsync().Result;
                                        removeCardsResult.Add((card.Card.CardToken, false, ApiStatusCodes.Pay360Error, responseJson2));
                                    }
                                    else
                                    {
                                        removeCardsResult.Add((card.Card.CardToken, false, ApiStatusCodes.Pay360Error, "Failure"));

                                    }
                                    continue;
                                }
                            }
                            result.SuccesfullyRemovedCards = removeCardsResult.Where(e => e.status).Select(e=>e.cardToken).ToList();
                            result.FailedToRemoveCards = removeCardsResult.Where(e => !e.status).Select(e=>e.cardToken).ToList();
                            return GenericPay360ApiResponse<RemoveAllPaymentMethodsResponse>.Success(result, "Cards removed successfully");
                        }
                        else // Error
                        {
                            return GenericPay360ApiResponse<RemoveAllPaymentMethodsResponse>.Failure("Failure", ApiStatusCodes.Pay360Error);
                        }
                    }
                    else if (httpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        return GenericPay360ApiResponse<RemoveAllPaymentMethodsResponse>.Failure(responseJson, ApiStatusCodes.Pay360Error);
                    }
                    else
                    {
                        return GenericPay360ApiResponse<RemoveAllPaymentMethodsResponse>.Failure("Failure", ApiStatusCodes.Pay360Error);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Pay360Service, Method: RemoveAllCards, Parameters: msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericPay360ApiResponse<RemoveAllPaymentMethodsResponse>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
        public async Task<GenericPay360ApiResponse<bool>> SetDefaultCard(string msisdn, SetDefaultCardUserRequest defaultCardReq)
        {

            try
            {
                string url = _pay360Config.ApiEndPoint + "/Pay360CommonServices/GetCustomerByCustomerUniqueRef";
                GetCustomerRequest request = new GetCustomerRequest() { CustomerUniqueRef = msisdn, ProductCode = "THA" };
                string jsonRequest = JsonConvert.SerializeObject(request);
                HttpResponseMessage httpResponse = await _apiCall.PostAsync(url, jsonRequest);
                if (httpResponse == null)
                {
                    _logger.Error($"Class: Pay360Service, Method: SetDefaultCard, Parameters: msisdn: {msisdn}, {JsonConvert.SerializeObject(defaultCardReq)}, {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received from Pay360 Api(GetCustomerByCustomerUniqueRef).");
                    return GenericPay360ApiResponse<bool>.Failure("Null response received from Pay360 Api(GetCustomerByCustomerUniqueRef).", ApiStatusCodes.CodeException);
                }
                else
                {
                    if (httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        GetCustomerResponse apiResponseModel = JsonConvert.DeserializeObject<GetCustomerResponse>(responseJson);
                        if (apiResponseModel.errorCode == 0) // Success
                        {
                            string url2 = _pay360Config.ApiEndPoint + "/Pay360CommonServices/SetCustomerDefaultCard";
                            SetDefaultCardRequest cardReq = new SetDefaultCardRequest() { CardToken = defaultCardReq.CardToken, DefaultCardCV2 = defaultCardReq.CV2, Pay360CustomerID = apiResponseModel.payload.Pay360CustId.ToString(CultureInfo.InvariantCulture) };
                            string jsonCardRequest = JsonConvert.SerializeObject(cardReq);
                            HttpResponseMessage cardHttpResponse = await _apiCall.PostAsync(url2, jsonCardRequest);
                            if (cardHttpResponse == null)
                            {
                                _logger.Error($"Class: Pay360Service, Method: SetDefaultCard, Parameters: msisdn: {msisdn}, {JsonConvert.SerializeObject(defaultCardReq)}, {JsonConvert.SerializeObject(cardReq)}, ErrorMessage: Null response received from Pay360 Api(SetCustomerDefaultCard).");
                                return GenericPay360ApiResponse<bool>.Failure("Null response received from Pay360 Api(SetCustomerDefaultCard).", ApiStatusCodes.CodeException);
                            }
                            else
                            {
                                if (cardHttpResponse.StatusCode == System.Net.HttpStatusCode.OK)
                                {
                                    string responseJsonCard = cardHttpResponse.Content.ReadAsStringAsync().Result;
                                    SetDefaultCardResponse apiResponseModelCard = JsonConvert.DeserializeObject<SetDefaultCardResponse>(responseJsonCard);
                                    if (apiResponseModelCard.errorCode == 0) // Success
                                    {
                                        return GenericPay360ApiResponse<bool>.Success(true, "Success");
                                    }
                                    else // Failure
                                    {
                                        return GenericPay360ApiResponse<bool>.Failure(apiResponseModelCard.message, ApiStatusCodes.Pay360Error);
                                    }

                                }
                                else if (cardHttpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                                {
                                    string responseJson2 = cardHttpResponse.Content.ReadAsStringAsync().Result;
                                    return GenericPay360ApiResponse<bool>.Failure(responseJson2, ApiStatusCodes.Pay360Error);
                                }
                                else
                                {
                                    return GenericPay360ApiResponse<bool>.Failure("Failure", ApiStatusCodes.Pay360Error);
                                }
                            }
                        }
                        else // Error
                        {
                            return GenericPay360ApiResponse<bool>.Failure(apiResponseModel.message, ApiStatusCodes.Pay360Error);
                        }
                    }
                    else if (httpResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        string responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                        return GenericPay360ApiResponse<bool>.Failure(responseJson, ApiStatusCodes.Pay360Error);
                    }
                    else
                    {
                        return GenericPay360ApiResponse<bool>.Failure("Failure", ApiStatusCodes.Pay360Error);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                _logger.Error($"Class: Pay360Service, Method: SetDefaultCard, Parameters: msisdn: {msisdn}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericPay360ApiResponse<bool>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
    }
}
