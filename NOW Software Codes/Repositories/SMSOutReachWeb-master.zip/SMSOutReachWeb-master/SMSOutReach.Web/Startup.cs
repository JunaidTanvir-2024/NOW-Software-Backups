﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SMSOutReach.Infastructure.Interface;
using SMSOutReach.Infastructure.Repository;
using SMSOutReach.Model.Configurations;
using SMSOutReach.Model.Connections;
using SMSOutReach.Web.Data;
using Serilog;
using System.IO;
using SMSOutReach.Web.Middleware;
using SMSOutReach.Modal.Configurations;

namespace SMSOutReach.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddSingleton((ILogger)new LoggerConfiguration()
             .MinimumLevel.Debug()
             .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "SmsOutReachWeb-log-{Date}.txt"))
             .CreateLogger());

            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            services.AddIdentity<ApplicationUser, ApplicationRole>()
                .AddEntityFrameworkStores<ApplicationDbContext>()
                .AddDefaultTokenProviders();


            services.Configure<ConnectionString>(Configuration.GetSection("ConnectionStrings"));
            services.Configure<ApplicationSetting>(Configuration.GetSection("ApplicationSettings"));
            services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));

            // services.Configure<XeebiConfiguration>(Configuration.GetSection("XeebiApiConfiguration"));

            services.AddTransient(typeof(IDbConnection), typeof(DbConnectionSettings));
            services.AddTransient(typeof(ISMSCarrier), typeof(SMSCarrierRepository));
            services.AddTransient(typeof(ISenderProduct), typeof(SenderProductRepository));
            services.AddTransient(typeof(ISMSJob), typeof(SMSJobRepository));

            // services.Configure<Pay360Configuration>(Configuration.GetSection("Pay360ApiConfiguration"));
            //services.AddTransient(typeof(IPay360Post), typeof(Pay360Post));


            //services.AddSingleton((ILogger)new LoggerConfiguration()
            //.MinimumLevel.Debug()
            //.WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "Pay360-log-{Date}.txt"))
            //.CreateLogger());

            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {

            // Logging middleware for capturing response time and other Request & Response details
            app.UseMiddleware<DogStatsDMiddleware>();

            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();
            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
