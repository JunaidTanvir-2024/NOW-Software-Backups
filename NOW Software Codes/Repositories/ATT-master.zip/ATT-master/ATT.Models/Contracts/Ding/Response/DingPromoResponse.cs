﻿using ATT.Models.Database;
using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Ding.Response
{
    
    public class DingPromoResponse
    {
        public List<DingPromo> items { get; set; } = new List<DingPromo>();

    }
    public class DingPromo
    {
        public string ProviderCode { get; set; }
        public DateTime StartUtc { get; set; }
        public DateTime EndUtc { get; set; }
        public string CurrencyIso { get; set; }
        public string ValidityPeriodIso { get; set; }
        public decimal MinimumSendAmount { get; set; }
        public Guid LocalizationKey { get; set; }
    }


    public class JsonPromoResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public int errorCodeDtOne { get; set; }
        public int servcieproviderid { get; set; }
        public PromonPayload payload { get; set; }
    }

    public class PromonPayload
    {
        public List<PromoDetails> item { get; set; }
        public List<string> dingCountries { get; set; }
    }

    public class PromoDetails
    {
        public string title { get; set; }
        public string description { get; set; }
        public string dateFrom { get; set; }
        public string dateTo { get; set; }
        public string pubDate { get; set; }
        public string operatorName { get; set; }
        public string operatorId { get; set; }
        public string subOperatorId { get; set; }
        public string countryId { get; set; }
        public string countryName { get; set; }
        public string title2 { get; set; }
        public string denomination { get; set; }
        public string denominationLocal { get; set; }
        public string promotionstatus { get; set; }
        //public string ProviderCode { get; set; }
        //public string CurrencyIso { get; set; }
        //public string ValidityPeriodIso { get; set; }
        //public decimal MinimumSendAmount { get; set; }
        //public Guid LocalizationKey { get; set; }
        //public string Dates { get; set; }
        //public string BonusValidity { get; set; }

        //public string LanguageCode { get; set; }

    }
    }
