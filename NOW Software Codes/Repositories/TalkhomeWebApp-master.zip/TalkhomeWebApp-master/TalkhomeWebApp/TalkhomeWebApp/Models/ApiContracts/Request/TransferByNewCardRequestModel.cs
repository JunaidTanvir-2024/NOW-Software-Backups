﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class TransferByNewCardRequestModel
    {
        public string nowtelRef { get; set; }
        public string product { get; set; }
        public string operatorId { get; set; }
        public PaymentCardModel cardData { get; set; }
        public BillingAddressModel billingAddressData { get; set; }
        public string ipAddress { get; set; }
    }
}
