﻿using System.Security.Claims;

namespace Application.Common.Interfaces.Identity;

public interface ICurrentUserInitializer
{
    void SetCurrentUser(ClaimsPrincipal user);
}
