﻿using Application.Common.Models.ResponseWrappers;

namespace Application.Features.Identity.ForgotPassword.ForgotPasswordConfirm;

public class ForgotPasswordConfirmRequest : IRequest<Result<object>>
{
    public string Email { get; set; } = default!;

    public int Otp { get; set; } = default!;
}
