using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DC.Core.Common.DTOs.Vendors.DTOne;

namespace DC.Infrastructure.Sms;
internal sealed class SMSService(ILogger logger, ISmsIntegration smsIntegration) : ISMSService
{
    private readonly ILogger _logger= logger;
    private readonly ISmsIntegration _smsIntegration= smsIntegration;

    public async Task<bool> SendSMS(SMSSend.Request request)
    {
        var response = await _smsIntegration.SendSMS(new DTOs.SMSDto.Request
        {
            message = request.Message,
            ProductCode = request.ProductCode,
            RequestID = request.RequestID,
            RequestType = request.RequestType,
            To = request.To
        });
        return response;
    }

}
