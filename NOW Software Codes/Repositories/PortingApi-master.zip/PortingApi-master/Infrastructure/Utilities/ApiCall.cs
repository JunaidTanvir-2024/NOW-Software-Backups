﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Utilities
{
    public class ApiCall : IApiCall
    {
        private HttpClient client;

        public async Task<HttpResponseMessage> Get(string Uri, TokenType authTokenType, string authToken, params string[] parameters)
        {
            HttpResponseMessage response;

            try
            {
                string paramString = parameters.Count() > 0 ? "?" : String.Empty;

                using (client = new HttpClient())
                {
                    foreach (var param in parameters)
                    {
                        paramString += param + "&";
                    }
                    paramString = paramString.TrimEnd('&');

                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);

                    response = await client.GetAsync(Uri + paramString);

                    return response;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<HttpResponseMessage> Get(string Uri, TokenType authTokenType, string authToken)
        {
            HttpResponseMessage response;

            try
            {

                using (client = new HttpClient())
                {

                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);

                    response = await client.GetAsync(Uri);

                    return response;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<HttpResponseMessage> PostUrlEncoded(string Uri, TokenType authTokenType, string authToken, List<KeyValuePair<string, string>> postDataModel)
        {
            try
            {
                using (client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                    //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", UtilityFunctions.CreateBasicHeader(pay360Config.ApiUserName, pay360Config.ApiPassword));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);
                    HttpContent content = new FormUrlEncodedContent(postDataModel);
                    content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
                    content.Headers.ContentType.CharSet = "UTF-8";
                    HttpResponseMessage resposne = await client.PostAsync(Uri, content);
                    return resposne;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }


        public async Task<HttpResponseMessage> Post(string Uri, TokenType authTokenType, string authToken, string requestJson)
        {
            try
            {
                using (client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                    //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", UtilityFunctions.CreateBasicHeader(pay360Config.ApiUserName, pay360Config.ApiPassword));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);
                    var stringContent = new StringContent(requestJson, Encoding.UTF8, "application/json");
                    HttpResponseMessage resposne = await client.PostAsync(Uri, stringContent);
                    return resposne;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<HttpResponseMessage> Delete(string Uri, TokenType authTokenType, string authToken, string requestJson)
        {
            try
            {
                using (client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);

                    var stringContent = new StringContent(requestJson, Encoding.UTF8, "application/json");

                    HttpResponseMessage resposne = await client.DeleteAsync(Uri);

                    return resposne;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<HttpResponseMessage> Post(string Uri, string requestJson)
        {
            try
            {
                using (client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                    var stringContent = new StringContent(requestJson, Encoding.UTF8, "application/json");
                    HttpResponseMessage resposne = await client.PostAsync(Uri, stringContent);
                    return resposne;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
