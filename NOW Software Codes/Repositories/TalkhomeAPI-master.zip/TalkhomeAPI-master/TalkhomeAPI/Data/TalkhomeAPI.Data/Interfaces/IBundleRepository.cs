﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Interfaces
{
    public interface IBundleRepository
    {
        Task<IEnumerable<BundlesCountries>> GetCountriesByBundle();
        Task<IEnumerable<Bundles>> GetBundleByCountry(string ServiceId);
        Task<Bundles> GetBundleById(string Id);
        Task<int> BundlePurchaseViaAccountBalance(string accountId, string bundleId);
    }
}
