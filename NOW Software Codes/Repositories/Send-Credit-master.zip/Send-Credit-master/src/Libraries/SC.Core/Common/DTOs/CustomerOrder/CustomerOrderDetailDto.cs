﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.DTOs.CustomerOrder;
public record CustomerOrderDetailDto
{
    public long CustomerOrderID { get; set; } = default!;
    public string CustomerID { get; set; } = default!;
    public string PromoCode { get; set; } = default!;
    public int DiscountTypeId { get; set; } = default!;
    public decimal DiscountInclusiveAmount { get; set; } = decimal.Zero;
    public decimal DiscountAmount { get; set; } = decimal.Zero;
    public decimal ServiceFee { get; set; } = decimal.Zero;
    public decimal TaxAmount { get; set; } = decimal.Zero;
    public decimal TaxInclusiveAmount { get; set; } = decimal.Zero;
    public decimal TaxExclusiveAmount { get; set; } = decimal.Zero;
    public decimal TotalOrderAmount { get; set; } = decimal.Zero;
    public string Currency { get; set; } = default!;
    public string OrderStatus { get; set; } = default!;
    public long CustomerAddressId { get; set; } = default!;
    public string RequestId { get; set; } = default!;
    public string AddressType { get; set; } = default!;
    public string StreetAddress1 { get; set; } = default!;
    public string StreetAddress2 { get; set; } = default!;
    public string City { get; set; } = default!;
    public string State { get; set; } = default!;
    public string PostalCode { get; set; } = default!;
    public string Country { get; set; } = default!;
    public string Email { get; set; } = default!;
    public string Phone { get; set; } = default!;
    public string Region { get; set; } = default!;
    public string CountryCode { get; set; } = default!;
    public string Firstname { get; set; } = default!;
    public string Lastname { get; set; } = default!;
    public string? PaymentMethod { get; set; }

    public List<GetCustomerCartDto> CartDetail { get; set; } = default!;
}

