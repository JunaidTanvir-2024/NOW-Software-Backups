using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;

using Serilog;

using Voucherify.Api;
using Voucherify.Core.Services.Loggers;

LoggerService.EnsureInitialized();
Log.Information("Voucherify Api Booting Up..");

try
{
    var builder = WebApplication.CreateBuilder(args);
    {
        builder.Host.UseSerilog((hostingContext, config) => config.ReadFrom.Configuration(hostingContext.Configuration).WriteTo.Sentry());

        builder.WebHost.UseSentry();

        builder.Services.AddApiDependencies(builder.Configuration);
    }
    // Get the port information and extract the port from the URL if available
    Log.Information($"Voucherify Api is running on port {builder.Configuration["urls"]?.Split(':').Last()}");

    var app = builder.Build();
    {
        app.AddApiMiddlewares();

        Log.Information($"Voucherify Api is running on port {GetPortInfo(app)}");

        app.Run();
    }

}
catch (Exception ex) when (!ex.GetType().Name.Equals("StopTheHostException", StringComparison.Ordinal))
{
    LoggerService.EnsureInitialized();
    Log.Error(ex, "Voucherify Api Shutting down...");
    Log.Fatal(ex, "Unhandled exception");
    throw;
}
finally
{
    LoggerService.EnsureInitialized();
    Log.Error("Voucherify Api Shutting down...");
    Log.CloseAndFlush();
}

// Get Application Running
static object? GetPortInfo(WebApplication app)
{
    var server = app.Services.GetRequiredService<IServer>();
    var addresses = server.Features.Get<IServerAddressesFeature>()?.Addresses;
    var address = addresses?.FirstOrDefault();
    return address?.Split(':').LastOrDefault();
}
