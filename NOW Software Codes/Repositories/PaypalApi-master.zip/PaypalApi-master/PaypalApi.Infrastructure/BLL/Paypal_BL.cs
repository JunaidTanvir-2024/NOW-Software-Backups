﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using PaypalApi.Infrastructure.DAL;
using PaypalApi.Models.Configurations;
using PaypalApi.Models.Contracts.Request;
using PaypalApi.Models.Contracts.Request.Api;
using PaypalApi.Models.Contracts.Request.User;
using PaypalApi.Models.Contracts.Response.Api;
using PaypalApi.Models.Contracts.Response.User;
using PaypalApi.Models.Database;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using Amounts = PaypalApi.Models.Contracts.Request.Api.Amounts;
using Payers = PaypalApi.Models.Contracts.Request.Api.Payers;
using Transactions = PaypalApi.Models.Contracts.Request.Api.Transactions;

namespace PaypalApi.Infrastructure.BLL
{
    public class Paypal_BL : IPaypal_BL
    {

        private PaypalConfig PaypalConfigurations;        
        private IPaypalDb_DL Db;
        private IApiCall ApiCall;
        private readonly ILogger Logger;
        private IAccessToken AccessToken;       
        private readonly SmsConfig SmsConfig;      
        private readonly SmtpConfig SmtpConfig;
        private readonly PushConfig PushConfig;
        private readonly FailureTopUpEmailConfig FailureTopUpEmailConfig;
        private readonly SimulationConfig StimulationConfig;

        public Paypal_BL(ILogger logger, IPaypalDb_DL db, IOptions<PaypalConfig> paypalConfig, IApiCall apiCall, IAccessToken accessToken, IOptions<SmsConfig> smsConfig, IOptions<SmtpConfig> smpt, IOptions<SimulationConfig> stimulationConfig, IOptions<PushConfig> pushConfig, IOptions<FailureTopUpEmailConfig> failureTopUpEmailConfig)
        {
            PaypalConfigurations = paypalConfig.Value;            
            Db = db;
            ApiCall = apiCall;
            Logger = logger;
            AccessToken = accessToken;
            SmsConfig = smsConfig.Value;
            SmtpConfig = smpt.Value;
            PushConfig = pushConfig.Value;
            StimulationConfig = stimulationConfig.Value;
            FailureTopUpEmailConfig = failureTopUpEmailConfig.Value;
            
        }

        public async Task<GenericApiResponse<UserCreateSalePaymentResponse>> CreateSalePayment(UserCreateSalePaymentRequest userRequest)
        {


            try
            {

                #region Validations

                DbResult<List<ProductItems>> productItems = await Db.GetProductItems(userRequest.CustomerMsisdn);
                string validationMesage = "";
                bool isValidationError = false;
                if (productItems.DBStatus == 2) // Error
                {
                    return GenericApiResponse<UserCreateSalePaymentResponse>.Failure(productItems.DBErrorMessage);
                }

                var description = "";

                if (userRequest.Basket != null)
                {
                    float basketTotal = 0;
                    for (int i = 0; i < userRequest.Basket.Length; i++)
                    {
                        #region ProductRef Validation

                        if (string.IsNullOrEmpty(description))
                            description = userRequest.Basket[i].ProductItemCode + ":" + userRequest.Basket[i].Amount.ToString();
                        else
                            description = description + "," + userRequest.Basket[i].ProductItemCode + ":" + userRequest.Basket[i].Amount.ToString();

                        var validateFailure = await ValidateProduct(i, productItems.Data, userRequest);

                        if (validateFailure != null)
                        {
                            return validateFailure;
                        }

                        #endregion  ProductRef Validation

                        #region Basket Amount Total Validation
                        basketTotal = basketTotal + userRequest.Basket[i].Amount;
                        #endregion Basket Amount Total Validation

                        #region ProductItem MaxLimit Validation
                        if (productItems.Data != null && productItems.Data.Count > 0)
                        {
                            ProductItems pItem = productItems.Data.Find(item => item.ProductCode == userRequest.ProductCode && item.ProductItemCode == userRequest.Basket[i].ProductItemCode);

                            if (pItem == null)
                            {
                                validationMesage += "Basket item " + userRequest.Basket[i].ProductItemCode + " not available in database, ";
                                isValidationError = true;
                            }
                            else
                            {
                                if (userRequest.Basket[i].Amount > pItem.AmountLimit)
                                {
                                    validationMesage += "Basket item " + userRequest.Basket[i].ProductItemCode + " amount exceeds MaxAmount(" + pItem.AmountLimit + ") limit, ";
                                    isValidationError = true;
                                }
                            }
                        }
                        #endregion ProductItem MaxLimit Validation
                    }
                    if (basketTotal != userRequest.Transaction.Amount.Total)
                    {
                        return  GenericApiResponse<UserCreateSalePaymentResponse>.Failure("Basket total and TransactionAmount are not same.");
                    }
                }
                else
                {
                    return GenericApiResponse<UserCreateSalePaymentResponse>.Failure("Basket is empty.");
                }

                if (isValidationError)
                {
                    return  GenericApiResponse<UserCreateSalePaymentResponse>.Failure(validationMesage);
                }


                #endregion Validations

                string customerMerchantReference = userRequest.ProductCode + "_" + userRequest.CustomerUniqueRef;

                Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);

                if (customer == null)
                {
                    //New Customer
                    customer = new Customer()
                    {
                        Name = userRequest.CustomerName,
                        MerchantRef = customerMerchantReference,
                        Email = userRequest.CustomerEmail,
                        ProductCode = userRequest.ProductCode,
                        Msisdn = userRequest.CustomerMsisdn                       

                    };
                    DbResult<int> result = await Db.AddCustomer(customer);
                    if (result.DBStatus != 1)
                    {
                        return GenericApiResponse<UserCreateSalePaymentResponse>.Failure(result.DBErrorMessage);
                       
                    }
                    else
                    {
                        customer.Id = result.Data;
                    }

                }

                string bearerToken = "";

                GenericApiResponse<string> tokenResponse = await GetToken();

                if (tokenResponse.errorCode == 0)
                {
                    bearerToken = tokenResponse.payload;                    
                }
                else
                {
                    return GenericApiResponse<UserCreateSalePaymentResponse>.Failure(tokenResponse.message);
                }
                

                string apiEndPoint = PaypalConfigurations.ApiEndPoint + "/payments/payment";

                string invoiceNumber = userRequest.ProductCode + "_" + Guid.NewGuid().ToString("N");

                ApiCreateSalePaymentRequest apiRequestModel = new ApiCreateSalePaymentRequest() {

                    Intent = "sale",
                    Payer = new Payers() { PaymentMethod = "paypal" },
                    RedirectUrl = new Models.Contracts.Request.Api.RedirectUrls() { CancelUrl = userRequest.RedirectUrl.CancelUrl, ReturnUrl = userRequest.RedirectUrl.ReturnUrl },
                    Transaction = new Transactions[1] { new Transactions() { Amount = new Amounts() { Currency = userRequest.Transaction.Amount.Currency, Total = userRequest.Transaction.Amount.Total }, Description = userRequest.Transaction.Description + ". " + description, InvoiceNumber = invoiceNumber } }

                };

                string requestJson = JsonConvert.SerializeObject(apiRequestModel);

                HttpResponseMessage httpResponse;

                DateTime requestTime = DateTime.UtcNow;

                try
                {
                    httpResponse = await ApiCall.Post(apiEndPoint, TokenType.Bearer, bearerToken, apiRequestModel);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Class: Paypal_BL, Method: CreateSalePayment, requestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                    return GenericApiResponse<UserCreateSalePaymentResponse>.Failure(ex.Message);
                }

                ApiCreateSalePaymentResponse apiResponseModel;
                string responseJson = "";
                if (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created || httpResponse.StatusCode == HttpStatusCode.Accepted || httpResponse.StatusCode == HttpStatusCode.NoContent)
                {
                    responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                    apiResponseModel = JsonConvert.DeserializeObject<ApiCreateSalePaymentResponse>(responseJson);

                    DbResult<int> dbResult = await Db.AddTransaction(apiResponseModel, customer.Id, userRequest.Basket, requestJson, responseJson);
                    if (dbResult.DBStatus == 1) // Success
                    {
                        string approvalUrl = (from r in apiResponseModel.RedirectLinks where r.Rel == "approval_url" select r.Href).FirstOrDefault();
                        UserCreateSalePaymentResponse response = new UserCreateSalePaymentResponse() { RedirectUrl = approvalUrl };
                        return GenericApiResponse<UserCreateSalePaymentResponse>.Success(response, "Success");
                    }
                    else // DB Error
                    {
                        return GenericApiResponse<UserCreateSalePaymentResponse>.Failure("Database Transaction Save Error: " + dbResult.DBErrorMessage);
                    }
                }
                else // Transaction Failure
                {
                    string jsonResult = await httpResponse.Content.ReadAsStringAsync();
                    string jsonKey = "";
                    jsonKey = (jsonResult.Contains("error_description") ? "error_description" : "message");
                    string reasonMessage = Utility.GetJsonObjectValueByKey(jsonKey, jsonResult);

                    DbResult<int> dbResult = await Db.AddErrorTransaction(customer.Id, invoiceNumber, userRequest.Transaction.Description, apiRequestModel.Intent, userRequest.Transaction.Amount.Total, userRequest.Transaction.Amount.Currency, requestTime, reasonMessage, userRequest.Basket, requestJson, jsonResult);
                    if (dbResult.DBStatus == 2) // Failure
                    {
                        reasonMessage = "Api Error: " + reasonMessage + ". Database Transaction Save Error: " + dbResult.DBErrorMessage;
                    }                   

                    return GenericApiResponse<UserCreateSalePaymentResponse>.Failure(reasonMessage);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Paypal_BL, Method: CreateSalePayment, requestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<UserCreateSalePaymentResponse>.Failure(ex.Message);

            }


        }

        public async Task<GenericApiResponse<UserExecuteSalePaymentResponse>> ExecuteSalePayment(UserExecuteSalePaymentRequest userRequest)
        {


            try
            {

                string customerMerchantReference = userRequest.ProductCode + "_" + userRequest.CustomerUniqueRef;

                DbTransactions transaction = await Db.CheckCustomerTransaction(customerMerchantReference, userRequest.PaymentId);

                if(transaction == null)
                {
                    return GenericApiResponse<UserExecuteSalePaymentResponse>.Failure("Invalid PaymentId.");
                }

                string bearerToken = "";

                GenericApiResponse<string> tokenResponse = await GetToken();

                if (tokenResponse.errorCode == 0)
                {
                    bearerToken = tokenResponse.payload;
                }
                else
                {
                    return GenericApiResponse<UserExecuteSalePaymentResponse>.Failure(tokenResponse.message);
                }

                string apiEndPoint = PaypalConfigurations.ApiEndPoint + $"/payments/payment/{userRequest.PaymentId}/execute";

                ApiExecuteSalePaymentRequest apiRequestModel = new ApiExecuteSalePaymentRequest()
                {
                    PayerId = userRequest.PayerId
                };

                HttpResponseMessage httpResponse;

                try
                {
                    httpResponse = await ApiCall.Post(apiEndPoint, TokenType.Bearer, bearerToken, apiRequestModel);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Class: Paypal_BL, Method: ExecuteSalePayment, requestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                    return GenericApiResponse<UserExecuteSalePaymentResponse>.Failure(ex.Message);
                }

                string requestJson = JsonConvert.SerializeObject(userRequest);

                ApiExecuteSalePaymentResponse apiResponseModel;
                string responseJson = "";
                if (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created || httpResponse.StatusCode == HttpStatusCode.Accepted || httpResponse.StatusCode == HttpStatusCode.NoContent)
                {
                    responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                    apiResponseModel = JsonConvert.DeserializeObject<ApiExecuteSalePaymentResponse>(responseJson);

                    if(apiResponseModel == null)
                    {
                        string reasonMessage = $"Http Status Code: {httpResponse.StatusCode.ToString()}, Null response received from Paypal Api.";

                        DbResult<int> dbResults = await Db.UpdateErrorTransaction(userRequest.PayerId, transaction.Id, reasonMessage, requestJson, responseJson, httpResponse.StatusCode.ToString());
                        if (dbResults.DBStatus == 2) // Failure
                        {
                            reasonMessage = "Api Error: " + reasonMessage + ". Database Transaction Save Error: " + dbResults.DBErrorMessage;
                        }

                        #region sendEmail
                        //Email Testing
                        EmailTransactionModel emailTransaction = new EmailTransactionModel();
                        emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                        emailTransaction.description = "Paypal  Details"; // set the text according to the type of transaction
                        emailTransaction.status = "Transaction status unknown. Null response received from Paypal APi."; // set the status text accordingly
                        emailTransaction.transactionId = userRequest.PaymentId;
                        emailTransaction.amount = transaction.Currency + " " + transaction.Amount.ToString();
                        emailTransaction.payerPaypalId = "Payer PaypalId: " + userRequest.PayerId;
                        bool isEmailSent = await SendEmail(emailTransaction);                       
                        #endregion

                        return GenericApiResponse<UserExecuteSalePaymentResponse>.Failure(reasonMessage);
                    }

                    DbResult<int> dbResult = await Db.UpdateTransaction(apiResponseModel, transaction.Id, requestJson, responseJson, httpResponse.StatusCode.ToString());
                    if (dbResult.DBStatus == 1) // Success
                    {

                        #region CustomerFullfilment

                        List<TransactionItems> transactionItems = await Db.GetTransactionItems(transaction.Id.ToString());

                        FullfilmentResponse result = new FullfilmentResponse();

                        string paypalTransactionId = "";

                        List<BasketItemsResponse> BasketResponse = new List<BasketItemsResponse>();

                        foreach (TransactionItems tranItem in transactionItems)
                        {

                            paypalTransactionId = tranItem.TransactionId.ToString();

                            if (StimulationConfig.SimulationMode)  // Simulation Mode
                            {
                                result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

                            }
                            else // Live Mode
                            {

                                if (tranItem.ProductItemCode.ToUpper() == "THM")
                                {
                                    var tranId = paypalTransactionId;
                                    var bundleRef = tranItem.BundleRef;
                                    var amount = tranItem.Amount;
                                    var productRef = tranItem.ProductRef;
                                    result = await Db.ThmCustomerFullfilment(tranId, bundleRef, amount.ToString(), productRef);
                                } else if (tranItem.ProductItemCode.ToUpper() == "THA")
                                {

                                    var tranId = paypalTransactionId;
                                    var bundleRef = tranItem.BundleRef;
                                    var amount = (tranItem.Amount*100);
                                    var productRef = tranItem.ProductRef;
                                    result = await Db.ThaCustomerFullfilment(tranId, bundleRef, amount.ToString(), productRef);


                                }
                                else if (tranItem.ProductItemCode == "THCC")
                                {
                                    var tranId = paypalTransactionId;
                                    var amount = tranItem.Amount * 100;
                                    result = await Db.ThccCustomerFullfilment(tranId, amount.ToString());
                                }
                                else if (tranItem.ProductItemCode == "THRCC")
                                {
                                    var tranId = paypalTransactionId;
                                    var bundleRef = tranItem.BundleRef;
                                    var amount = tranItem.Amount * 100;
                                    var productRef = tranItem.ProductRef;
                                    result = await Db.ThrccCustomerFullfilment(tranId, amount.ToString(), productRef);
                                }
                                else
                                {
                                    result.ErrorCode = 1;
                                    result.ErrorMessage = "Unknown ProductItemCode.";
                                }

                            }

                            bool IsFullfilled = false;
                            string FullfilmentErrorMessage = "";
                            DateTime FullfilmentDate = DateTime.UtcNow;

                            
                            EmailTransactionModel emailTransaction = new EmailTransactionModel();
                            emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                            emailTransaction.description = "Paypal  Details"; // set the text according to the type of transaction                           
                            emailTransaction.transactionId = userRequest.PaymentId;
                            emailTransaction.amount = transaction.Currency + " " + transaction.Amount.ToString();
                            emailTransaction.payerPaypalId = "Payer PaypalId: " + userRequest.PayerId;
                           
                           

                            if (result.ErrorCode == 0)
                            {
                                IsFullfilled = true;
                                FullfilmentErrorMessage = "";
                                emailTransaction.status = "Transaction and fullfilment Successfull for ProductItem: " + tranItem.ProductItemCode + ". ProductItem Amount: " + tranItem.Amount; // set the status text accordingly
                            }
                            else
                            {
                                IsFullfilled = false;
                                FullfilmentErrorMessage = result.ErrorMessage;
                                emailTransaction.status = "Transaction Successfull and fullfilment Un-Successfull for ProductItem: " + tranItem.ProductItemCode + ". ProductItem Amount: " + tranItem.Amount; // set the status text accordingly
                            }

                            bool isEmailSent = await SendEmail(emailTransaction);

                            BasketResponse.Add(new BasketItemsResponse() { IsFullFilled = IsFullfilled, ProductItemCode = tranItem.ProductItemCode, Pin = result.Pin });

                            int dBResult = await Db.UpdateTransactionItem(tranItem.Id, IsFullfilled, FullfilmentDate, FullfilmentErrorMessage);
                        }

                        #endregion CustomerFullfilment

                        UserExecuteSalePaymentResponse response = new UserExecuteSalePaymentResponse() { PaypalTransactionId = apiResponseModel.Id, CreateTime = apiResponseModel.CreateTime, Intent = apiResponseModel.Intent, State = apiResponseModel.State, SaleId = apiResponseModel.Transaction[0].RelatedResources[0].Sale.Id, BasketResponse = BasketResponse };
                        return GenericApiResponse<UserExecuteSalePaymentResponse>.Success(response, "Success");
                    }
                    else // DB Error
                    {

                        #region sendEmail
                        //Email Testing
                        EmailTransactionModel emailTransaction = new EmailTransactionModel();
                        emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                        emailTransaction.description = "Paypal  Details"; // set the text according to the type of transaction
                        emailTransaction.status = "Transaction Successfull but error in database insertion. Fullfilment not done for all Product items."; // set the status text accordingly
                        emailTransaction.transactionId = userRequest.PaymentId;
                        emailTransaction.amount = transaction.Currency + " " + transaction.Amount.ToString();
                        emailTransaction.payerPaypalId = "Payer PaypalId: " + userRequest.PayerId;
                        bool isEmailSent = await SendEmail(emailTransaction);
                        #endregion

                        return GenericApiResponse<UserExecuteSalePaymentResponse>.Failure("Database Transaction Save Error: " + dbResult.DBErrorMessage);
                    }

                    
                }
                else // Transaction Failure
                {
                    string jsonResult = await httpResponse.Content.ReadAsStringAsync();
                    string jsonKey = "";
                    jsonKey = (jsonResult.Contains("error_description") ? "error_description" : "message");
                    string reasonMessage = Utility.GetJsonObjectValueByKey(jsonKey, jsonResult);

                    DbResult<int> dbResult = await Db.UpdateErrorTransaction(userRequest.PayerId, transaction.Id, reasonMessage,  requestJson, jsonResult, httpResponse.StatusCode.ToString());
                    if (dbResult.DBStatus == 2) // Failure
                    {
                        reasonMessage = "Api Error: " + reasonMessage + ". Database Transaction Save Error: " + dbResult.DBErrorMessage;
                    }

                    #region sendEmail
                    //Email Testing
                    EmailTransactionModel emailTransaction = new EmailTransactionModel();
                    emailTransaction.msisdn = "Customer Reference: " + customerMerchantReference;
                    emailTransaction.description = "Paypal  Details"; // set the text according to the type of transaction
                    emailTransaction.status = "Transaction Failed"; // set the status text accordingly
                    emailTransaction.transactionId = userRequest.PaymentId;
                    emailTransaction.amount = transaction.Currency + " " + transaction.Amount.ToString();
                    emailTransaction.payerPaypalId = "Payer PaypalId: " + userRequest.PayerId;
                    bool isEmailSent = await SendEmail(emailTransaction);
                    #endregion

                    return GenericApiResponse<UserExecuteSalePaymentResponse>.Failure(reasonMessage);

                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Paypal_BL, Method: ExecuteSalePayment, requestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<UserExecuteSalePaymentResponse>.Failure(ex.Message);

            }


        }
              

        private async Task<GenericApiResponse<string>> GetToken()
        {


            try
            {                

                if (AccessToken.Token == null || AccessToken.ExpiryDate < DateTime.UtcNow)
                {
                    DateTime currentDate = DateTime.UtcNow;
                    GenericApiResponse<ApiGetTokenResponse> tokenResponse = await GetPaypalToken();
                    if (tokenResponse.errorCode == 0)
                    {                       
                        AccessToken.Token = tokenResponse.payload.AccessToken;
                        AccessToken.ExpiryDate = currentDate.AddSeconds(tokenResponse.payload.ExpiresIn);
                        return GenericApiResponse<string>.Success(tokenResponse.payload.AccessToken, "Success");
                    }
                    else
                    {
                        return GenericApiResponse<string>.Failure("AccessToken Error: " + tokenResponse.message);
                    }
                }
                else
                {
                   
                    return GenericApiResponse<string>.Success(AccessToken.Token, "Success");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Paypal_BL, Method: GetToken, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<string>.Failure("AccessToken Error: " + ex.Message);

            }

        }


        private async Task<GenericApiResponse<ApiGetTokenResponse>> GetPaypalToken()
        {

           
            try
            {                

                string apiEndPoint = PaypalConfigurations.ApiEndPoint + "/oauth2/token";

                List<KeyValuePair<string, string>> requestModel = new List<KeyValuePair<string, string>> {
                    new KeyValuePair<string, string>("grant_type", "client_credentials"),
                };

                //ApiGetTokenRequest requestModel = new ApiGetTokenRequest() {  GrantType = "client_credentials" };

                string basicHeader = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(PaypalConfigurations.CliendId + ":" + PaypalConfigurations.Secret));

                HttpResponseMessage httpResponse;

                try
                {
                    httpResponse = await ApiCall.PostUrlEncoded(apiEndPoint, TokenType.Basic, basicHeader, requestModel);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Class: Paypal_BL, Method: GetPaypalToken, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                    return GenericApiResponse<ApiGetTokenResponse>.Failure(ex.Message);                    
                }
               
                ApiGetTokenResponse apiResponseModel;
                string responseJson = "";
                if (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created || httpResponse.StatusCode == HttpStatusCode.Accepted || httpResponse.StatusCode == HttpStatusCode.NoContent)
                {
                    responseJson = httpResponse.Content.ReadAsStringAsync().Result;
                    apiResponseModel = JsonConvert.DeserializeObject<ApiGetTokenResponse>(responseJson);
                    return  GenericApiResponse<ApiGetTokenResponse>.Success(apiResponseModel, "Success");
                }                
                else
                {
                    string jsonResult = await httpResponse.Content.ReadAsStringAsync();
                    string jsonKey = "";
                    jsonKey  = (jsonResult.Contains("error_description") ?  "error_description" : "message");
                    string reasonMessage = Utility.GetJsonObjectValueByKey(jsonKey, jsonResult);
                    return GenericApiResponse<ApiGetTokenResponse>.Failure(reasonMessage);

                }
                
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Paypal_BL, Method: GetPaypalToken, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<ApiGetTokenResponse>.Failure(ex.Message);
                
            }

            
        }

        private async Task<GenericApiResponse<UserCreateSalePaymentResponse>> ValidateProduct(int i, List<ProductItems> productItems, UserCreateSalePaymentRequest userRequest)
        {
            GenericApiResponse<UserCreateSalePaymentResponse> response;

            ProductItems pItem = productItems.Find(item => item.ProductCode == userRequest.ProductCode && item.ProductItemCode == userRequest.Basket[i].ProductItemCode);

            if (userRequest.Basket[i].ProductItemCode.ToLower() == "thm")
            {
                ValidateRes result = await Db.ThmProductRefValidation(userRequest.Basket[i].ProductItemCode, userRequest.Basket[i].ProductRef, userRequest.Basket[i].BundleRef);


                if (result.Errorcode == 1) // Not Valid ProductRef
                {
                    return response = GenericApiResponse<UserCreateSalePaymentResponse>.Failure($"Invalid ProductRef: {userRequest.Basket[i].ProductRef} for ProductItem: {userRequest.Basket[i].ProductItemCode}.",1);
                } else if (result.Errorcode == 2)
                {
                    return response = GenericApiResponse<UserCreateSalePaymentResponse>.Failure($"You have reached the maximum number of bundles: {userRequest.Basket[i].BundleRef} for ProductItem: {userRequest.Basket[i].ProductItemCode}.",2);
                } else if  (result.Errorcode != 0) // Not Valid ProductRef
                {
                    return response = GenericApiResponse<UserCreateSalePaymentResponse>.Failure($"Paypal topup denied ProductRef: {userRequest.Basket[i].ProductRef} for ProductItem: {userRequest.Basket[i].ProductItemCode}.", 3);

                }else if (userRequest.Basket[i].Amount != 0 && result.Tamount != 0 && pItem.AmountLimit < (float.Parse(result.Tamount.ToString()) + float.Parse(userRequest.Basket[i].Amount.ToString())))
                {
                    return response = GenericApiResponse<UserCreateSalePaymentResponse>.Failure($"You exceeded daily the limit", 3);
                }

            }
            else if (userRequest.Basket[i].ProductItemCode.ToLower() == "tha")
            {
                ValidateRes result = await Db.ThaProductRefValidation(userRequest.Basket[i].ProductItemCode, userRequest.Basket[i].ProductRef);

                if (result.Errorcode != 0) // Not Valid ProductRef
                {
                    return response = GenericApiResponse<UserCreateSalePaymentResponse>.Failure($"Invalid ProductRef: {userRequest.Basket[i].ProductRef} for ProductItem: {userRequest.Basket[i].ProductItemCode}.");
                }
                else if (userRequest.Basket[i].Amount != 0 && result.Tamount != 0 && pItem.AmountLimit < (float.Parse(result.Tamount.ToString()) + float.Parse(userRequest.Basket[i].Amount.ToString())))
                {
                    return response = GenericApiResponse<UserCreateSalePaymentResponse>.Failure($"You exceeded daily the limit", 3);
                }
            }
            else if (userRequest.Basket[i].ProductItemCode.ToLower() == "thrcc")
            {
                int result = await Db.ThrccProductRefValidation(userRequest.Basket[i].ProductItemCode, userRequest.Basket[i].ProductRef);
                if (result != 0) // Not Valid ProductRef
                {
                    return response = GenericApiResponse<UserCreateSalePaymentResponse>.Failure($"Invalid ProductRef: {userRequest.Basket[i].ProductRef} for ProductItem: {userRequest.Basket[i].ProductItemCode}.");
                }
            }

            return null;
        }

        #region Sms_Email_PushNotification

        private async Task<PoppayoutsSendSmsResponse> SendPoppayoutSms(string from, string[] to, string textMessage, int SmsJobPriority)
        {
            PoppayoutsSendSmsResponse returnResult = null;


            string requestParameters = $" from: {from}, to: {JsonConvert.SerializeObject(to)}, textMessage: {textMessage}, SmsJobPriority: {SmsJobPriority} ";

            try
            {

                string PoppayoutsSMSEndPoint = SmsConfig.PoppayoutsApiEndPoint + "/SendSms";


                string response = "";

                PoppayoutsSendSmsRequest req = new PoppayoutsSendSmsRequest();
                req.from = from;
                req.to = to;
                req.textMessage = textMessage;
                req.SmsJobPriority = SmsJobPriority;

                string jsonRequest = JsonConvert.SerializeObject(req);
                Task<String> HttpPoppayoutsPostService = PostRequestToPoppayoutEndPoint(PoppayoutsSMSEndPoint, "Post", jsonRequest);
                response = await HttpPoppayoutsPostService;
                returnResult = JsonConvert.DeserializeObject<PoppayoutsSendSmsResponse>(response);
                if (returnResult == null)
                {
                    Logger.Error($"Pay360_BL - Method: SendSMS, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");
                    Console.WriteLine($"Pay360_BL - Method: SendSMS, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");

                }
                else if (returnResult.payload.data == null && returnResult.payload.error_string != null)
                {
                    Logger.Error($"Pay360_BL - Method: SendSMS, Parameters --> {requestParameters}, ErrorMessage: {returnResult.payload.error_string}");
                    Console.WriteLine($"Pay360_BLl - Method: SendSMS, Parameters --> {requestParameters}, ErrorMessage: {returnResult.payload.error_string}");
                }
                else
                {
                    if (returnResult.payload.data != null && returnResult.payload.error_string == null)
                    {
                        Logger.Debug($"Pay360_BL success - Method: SendSMS, Parameters --> {requestParameters}");
                        Console.WriteLine($"Pay360_BL success - Method: SendSMS, Parameters --> {requestParameters}");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Pay360_BL - Method: SendSMS, Parameters --> {requestParameters}, Exception: {ex.Message}");
            }

            return returnResult;
        }
        private async Task<XeebiSendSmsResponse> SendXeebiSms(string from, string to, string textMessage)
        {
            XeebiSendSmsResponse returnResult = null;


            string requestParameters = $" from: {from}, to: {to}, textMessage: {textMessage}";

            try
            {
                string XeebiSMSEndPoint = SmsConfig.XeebiApiEndPoint + "/SendSms";

                string response = "";

                XeebiSendSmsRequest req = new XeebiSendSmsRequest();
                req.from = from;
                req.to = to;
                req.text = textMessage;

                Task<String> HttpPoppayoutsPostService = PostRequestToXeebiEndPoint(XeebiSMSEndPoint, "Post", req);
                response = await HttpPoppayoutsPostService;
                returnResult = JsonConvert.DeserializeObject<XeebiSendSmsResponse>(response);
                if (returnResult == null)
                {
                    Logger.Error($"Pay360_BL - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");
                    Console.WriteLine($"Pay360_BL - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");

                }
                else if (returnResult.errorCode == 2)
                {
                    Logger.Error($"Pay360_BL - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: {returnResult.message}");
                    Console.WriteLine($"Pay360_BL - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: {returnResult.message}");
                }
                else
                {
                    if (returnResult.errorCode == 0 && returnResult.payload.submit_status == "OK")
                    {
                        Logger.Debug($"Pay360_BL success - Method: SendXeebiSms, Parameters --> {requestParameters}");
                        Console.WriteLine($"Pay360_BL success - Method: SendXeebiSms, Parameters --> {requestParameters}");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Pay360_BL - Method: SendXeebiSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
            }

            return returnResult;
        }

        private async Task<string> PostRequestToPoppayoutEndPoint(string apiEndPoint, string postType, string json)
        {

            string returnData = "";
            try
            {
                HttpClient httpClient = new HttpClient();

                httpClient.BaseAddress = new Uri(apiEndPoint);

                var httpContent = new StringContent(json, Encoding.UTF8, "application/json");


                HttpResponseMessage httpResponse;

                if (postType == "Post")
                {
                    httpResponse = await httpClient.PostAsync(apiEndPoint, httpContent);
                }
                else
                {
                    httpResponse = await httpClient.GetAsync(apiEndPoint);
                }

                if (httpResponse.Content != null)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    Exception ex = new Exception($"Pay360_BL Exception - Empty Contents Received for request - {json}");
                    throw ex;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            return returnData;
        }
        private async Task<string> PostRequestToXeebiEndPoint(string apiEndPoint, string postType, XeebiSendSmsRequest req)
        {

            string returnData = "";
            try
            {
                HttpClient httpClient = new HttpClient();

                httpClient.BaseAddress = new Uri(apiEndPoint);

                //var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

                MultipartFormDataContent content = new MultipartFormDataContent();
                content.Add(new StringContent(req.from), "from");
                content.Add(new StringContent(req.to), "to");
                content.Add(new StringContent(req.text), "textMessage");
                //content.Add(httpContent);

                HttpResponseMessage httpResponse;

                if (postType == "Post")
                {
                    httpResponse = await httpClient.PostAsync(apiEndPoint, content);
                }
                else
                {
                    httpResponse = await httpClient.GetAsync(apiEndPoint);
                }

                if (httpResponse.Content != null)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    Exception ex = new Exception($"Pay360_BL Exception - Empty Contents Received for request - ");
                    throw ex;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            return returnData;
        }

        private async Task<bool> SendEmail(EmailTransactionModel transactionModel)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }



                //client.DeliveryMethod = SmtpDeliveryMethod.Network;
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SmtpConfig.from);
                foreach (var to in SmtpConfig.to)
                {
                    mailMessage.To.Add(to);
                }
                foreach (var cc in SmtpConfig.cc)
                {
                    if (cc != "" && cc != null)
                    {
                        mailMessage.CC.Add(cc);
                    }
                }
                foreach (var bcc in SmtpConfig.bcc)
                {
                    if (bcc != "" && bcc != null)
                    {
                        mailMessage.Bcc.Add(bcc);
                    }
                }
                mailMessage.Body = transactionModel.msisdn + Environment.NewLine;
                mailMessage.Body += "Discription: " + transactionModel.description + Environment.NewLine;
                mailMessage.Body += "Status: " + transactionModel.status + Environment.NewLine;
                mailMessage.Body += "Paypal Transaction ID: " + transactionModel.transactionId + Environment.NewLine;
                mailMessage.Body +=  "" + transactionModel.payerPaypalId + Environment.NewLine;
                mailMessage.Body += "Amount: " + transactionModel.amount;
                mailMessage.Subject = SmtpConfig.subject;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Paypal_BL, Method: SendEmail, Parameters=> EmailModel: {JsonConvert.SerializeObject(transactionModel)}, ErrorMessage: {ex.Message}");
                return false;
            }

        }
        private async Task<bool> SendEmailToCustomer(string customerEmail, string Message)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }



                //client.DeliveryMethod = SmtpDeliveryMethod.Network;
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SmtpConfig.fromForCustomer);
                mailMessage.To.Add(customerEmail);
                mailMessage.Body = Message;
                mailMessage.Subject = SmtpConfig.subjectForCustomer;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Pay360_BL, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }

        }
        private async Task<int> SendPushNotification(string Message, string msisdn)
        {

            HttpClient client = new HttpClient
            {
                BaseAddress = new Uri(PushConfig.ApiEndPoint),
            };

            client.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
            client.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json");
            client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue(
                        "Basic",
                        Convert.ToBase64String(Encoding.ASCII.GetBytes(PushConfig.ApiUserName + ":" + PushConfig.ApiPassword)));


            var body = JsonConvert.SerializeObject(new { msg = Message, msisdn = new string[] { msisdn } }, new JsonSerializerSettings
            {
                ContractResolver = new DefaultContractResolver()
            });



            try
            {
                var requestMessage = new HttpRequestMessage(HttpMethod.Post,
                    $"push")
                {
                    Content = new StringContent(body, Encoding.UTF8, "application/json")
                };

                var result = await client.SendAsync(requestMessage);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured : " + ex.ToString());
                Logger.Error($"Class: Pay360_BL, Method: SendPushNotification, Parameters=> Message: {Message}, msisdn: {msisdn} , ErrorMessage: {ex.Message}");
            }
            return 0;


        }

        #endregion Sms_Email_PushNotification


        //public async Task FullFilment(string transactionId)
        //{
        //    List<TransactionItems> transactionItems = await Db.GetTransactionItems(transactionId);

        //    foreach (TransactionItems tranItem in transactionItems)
        //    {

        //        if (tranItem.ProductItemCode == "THM")
        //        {
        //            #region Call the fullfilment SP
        //            if (StimulationConfig.SimulationMode)  // Simulation Mode
        //            {
        //                result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "" };

        //            }
        //            else // Live Mode
        //            {
        //                var tranId = apiResponseModel.payload.Transaction.TransactionId;
        //                var bundleRef = tranItem.BundleRef;
        //                var amount = preAuthTransaction.TransactionAmount;
        //                var productRef = tranItem.ProductRef;

        //                result = await Db.ThmCustomerFullfilment(tranId, bundleRef, amount.ToString(), productRef);

        //            }
        //            #endregion Customer_Fullfilment
        //            if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
        //            {
        //                isfullfilment = true;
        //                fullfilmentDatetime = DateTime.UtcNow;
        //                fullfilmentRef = result.audit_id;
        //                var newBalance = result.new_balance;
        //                var newBalanceCurrency = preAuthTransaction.TransactionCurrency;
        //                if (newBalanceCurrency == "USD")
        //                {
        //                    newBalanceCurrency = "$";
        //                }
        //                else if (newBalanceCurrency == "GBP")
        //                {
        //                    newBalanceCurrency = "£";
        //                }
        //                else if (newBalanceCurrency == "EUR")
        //                {
        //                    newBalanceCurrency = "€";
        //                }
        //                Console.WriteLine($"Pay360_BL/StartPay360Job, Customer Fullfilment Successfull,  TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, CustomerMerchantRef: {apiResponseModel.payload.Transaction.MerchantRef}, Date_Utc: {DateTime.UtcNow}");

        //                #region SendSms
        //                //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
        //                var SmsMsg = $"Talkhome \r\nYou have successfully Topped Up. \r\nYour new balance is {newBalanceCurrency}{newBalance}\r\nTop Up Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {apiResponseModel.payload.Transaction.TransactionId}";
        //                var PushMsg = $"You have successfully Auto Topped Up. \r\nYour new balance is {newBalanceCurrency}{newBalance}\r\nTop Up Amount {newBalanceCurrency}{tranItem.Amount}\r\nTransaction Id: {apiResponseModel.payload.Transaction.TransactionId}";
        //                //var pushResult = SendPushNotification(PushMsg, autoTopupTransaction.Msisdn);
        //                if (SmsConfig.UsePoppayout == true)
        //                {

        //                    PoppayoutsSendSmsResponse smsResponse = await this.SendPoppayoutSms("TalkHome", new string[] { preAuthTransaction.Msisdn }, SmsMsg, 1);

        //                    if (smsResponse != null && smsResponse.errorCode == 0)
        //                    {
        //                        isSmsSent = true;
        //                        smsSentDatetime = DateTime.UtcNow;
        //                        Console.WriteLine($"Pay360_BL/StartPay360Job, Sms Sent Successfully, TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, Msisdn: {preAuthTransaction.Msisdn}, Date_Utc: {DateTime.UtcNow}");
        //                    }
        //                    else
        //                    {
        //                        isSmsSent = false;
        //                        Console.WriteLine($"Pay360_BL/StartPay360Job, Error in Sending Sms, TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, CustomerMerchantRef: {preAuthTransaction.Msisdn}, Date_Utc: {DateTime.UtcNow}");
        //                    }
        //                }
        //                else
        //                {
        //                    XeebiSendSmsResponse smsResponse = await this.SendXeebiSms("TalkHome", preAuthTransaction.Msisdn, SmsMsg);
        //                    if (smsResponse != null && smsResponse.errorCode == 0)
        //                    {
        //                        isSmsSent = true;
        //                        smsSentDatetime = DateTime.UtcNow;
        //                        Console.WriteLine($"Pay360_BL/StartPay360Job, Sms Sent Successfully, TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, Msisdn: {preAuthTransaction.Msisdn}, Date_Utc: {DateTime.UtcNow}");
        //                    }
        //                    else
        //                    {
        //                        isSmsSent = false;
        //                        Console.WriteLine($"Pay360_BL/StartPay360Job, Error in Sending Sms, TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, Msisdn: {preAuthTransaction.Msisdn}, Date_Utc: {DateTime.UtcNow}");
        //                    }
        //                }
        //                #endregion SendSms

        //                #region sendEmail
        //                //Email Testing
        //                EmailTransactionModel emailTransaction = new EmailTransactionModel();
        //                emailTransaction.msisdn = "Customer Reference:" + preAuthTransaction.CustomerMerchantRef;
        //                emailTransaction.description = "Pay360 THM Top Up Details"; // set the text according to the type of transaction
        //                emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
        //                emailTransaction.transactionId = apiResponseModel.payload.Transaction.TransactionId;
        //                emailTransaction.amount = apiResponseModel.payload.Transaction.Currency + " " + tranItem.Amount.ToString();
        //                isEmailSent = await SendEmail(emailTransaction);
        //                if (isEmailSent)
        //                {
        //                    emailSentDatetime = DateTime.UtcNow;
        //                    Console.WriteLine($"Pay360_BL/StartPay360Job, Email Sent Successfully, TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, Msisdn: {preAuthTransaction.Msisdn}, Date_Utc: {DateTime.UtcNow}");
        //                }
        //                else
        //                {
        //                    Console.WriteLine($"Pay360_BL/StartPay360Job, Error in Sending Email, TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, Msisdn: {preAuthTransaction.Msisdn}, Date_Utc: {DateTime.UtcNow}");
        //                }

        //                #endregion

        //                #region SendEmailToCustomer
        //                Customer customer = await Db.GetCustomerByMerchantRef(preAuthTransaction.CustomerMerchantRef);
        //                if (customer != null && !string.IsNullOrWhiteSpace(customer.Email) && SmtpConfig.sendEmailToCustomer)
        //                {
        //                    isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, SmsMsg);
        //                    customerEmailSentDatetime = DateTime.UtcNow;
        //                }
        //                #endregion

        //            }
        //        }
        //        else if (tranItem.ProductItemCode == "THCC")
        //        {
        //            #region Call the fullfilment SP
        //            if (StimulationConfig.StimulationMode)  // Simulation Mode
        //            {
        //                result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

        //            }
        //            else // Live Mode
        //            {
        //                var tranId = apiResponseModel.payload.Transaction.TransactionId;
        //                var amount = preAuthTransaction.TransactionAmount * 100;

        //                result = await Db.ThccCustomerFullfilment(tranId, amount.ToString());

        //            }
        //            #endregion Customer_Fullfilment
        //            if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
        //            {
        //                isfullfilment = true;
        //                fullfilmentDatetime = DateTime.UtcNow;
        //                fullfilmentRef = result.audit_id;
        //                var newBalance = result.new_balance;
        //                var newBalanceCurrency = preAuthTransaction.TransactionCurrency;
        //                if (newBalanceCurrency == "USD")
        //                {
        //                    newBalanceCurrency = "$";
        //                }
        //                else if (newBalanceCurrency == "GBP")
        //                {
        //                    newBalanceCurrency = "£";
        //                }
        //                else if (newBalanceCurrency == "EUR")
        //                {
        //                    newBalanceCurrency = "€";
        //                }
        //                Console.WriteLine($"Pay360_BL/StartPay360Job, Customer Fullfilment Successfull,  TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, CustomerMerchantRef: {preAuthTransaction.CustomerMerchantRef}, Date_Utc: {DateTime.UtcNow}");

        //                #region SendSms
        //                //string mailto = $"mailto:{FailureTopUpEmailConfig.to}" + "?&subject=" + Uri.EscapeUriString(FailureTopUpEmailConfig.subject) + "&body=" + Uri.EscapeUriString(FailureTopUpEmailConfig.body);
        //                var EmailMsg = $"Talkhome \r\nYou have successfully purchased TalkHome Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {preAuthTransaction.TransactionCurrency}{tranItem.Amount}\r\nTransaction Id: {apiResponseModel.payload.Transaction.TransactionId}";
        //                #endregion

        //                #region sendEmail
        //                //Email Testing
        //                EmailTransactionModel emailTransaction = new EmailTransactionModel();
        //                emailTransaction.msisdn = "Customer Reference: " + preAuthTransaction.CustomerMerchantRef;
        //                emailTransaction.description = "Pay360 THCC Details"; // set the text according to the type of transaction
        //                emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
        //                emailTransaction.transactionId = apiResponseModel.payload.Transaction.TransactionId;
        //                emailTransaction.amount = apiResponseModel.payload.Transaction.Currency + " " + tranItem.Amount.ToString();
        //                isEmailSent = await SendEmail(emailTransaction);
        //                if (isEmailSent)
        //                {
        //                    emailSentDatetime = DateTime.UtcNow;
        //                    Console.WriteLine($"Pay360_BL/StartPay360Job, Email Sent Successfully, TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, Customer Merchant Ref: {preAuthTransaction.CustomerMerchantRef}, Date_Utc: {DateTime.UtcNow}");
        //                }
        //                else
        //                {
        //                    Console.WriteLine($"Pay360_BL/StartPay360Job, Error in Sending Email, TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, Customer Merchant Ref: {preAuthTransaction.CustomerMerchantRef}, Date_Utc: {DateTime.UtcNow}");
        //                }

        //                #endregion

        //                #region SendEmailToCustomer
        //                Customer customer = await Db.GetCustomerByMerchantRef(preAuthTransaction.CustomerMerchantRef);
        //                if (customer != null && !string.IsNullOrWhiteSpace(customer.Email))
        //                {
        //                    isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, EmailMsg);
        //                    customerEmailSentDatetime = DateTime.UtcNow;
        //                }
        //                #endregion

        //            }
        //        }
        //        else if (tranItem.ProductItemCode == "THRCC")
        //        {
        //            #region Call the fullfilment SP
        //            if (StimulationConfig.StimulationMode)  // Simulation Mode
        //            {
        //                result = new FullfilmentResponse { ErrorCode = 0, ErrorMessage = "", Pin = "12345" };

        //            }
        //            else // Live Mode
        //            {
        //                var tranId = apiResponseModel.payload.Transaction.TransactionId;
        //                var bundleRef = tranItem.BundleRef;
        //                var amount = preAuthTransaction.TransactionAmount * 100;
        //                var productRef = tranItem.ProductRef;

        //                result = await Db.ThrccCustomerFullfilment(tranId, amount.ToString(), productRef);

        //            }
        //            #endregion Customer_Fullfilment
        //            if (result != null && result.ErrorCode == 0) // Fullfilment Successfull
        //            {
        //                isfullfilment = true;
        //                fullfilmentDatetime = DateTime.UtcNow;
        //                fullfilmentRef = result.audit_id;
        //                var newBalance = result.new_balance;
        //                var newBalanceCurrency = preAuthTransaction.TransactionCurrency;
        //                if (newBalanceCurrency == "USD")
        //                {
        //                    newBalanceCurrency = "$";
        //                }
        //                else if (newBalanceCurrency == "GBP")
        //                {
        //                    newBalanceCurrency = "£";
        //                }
        //                else if (newBalanceCurrency == "EUR")
        //                {
        //                    newBalanceCurrency = "€";
        //                }
        //                Console.WriteLine($"Pay360_BL/StartPay360Job, Customer Fullfilment Successfull,  TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, CustomerMerchantRef: {preAuthTransaction.CustomerMerchantRef}, Date_Utc: {DateTime.UtcNow}");

        //                #region SendSms
        //                var EmailMsg = "";
        //                if (tranItem.ProductRef == null)// Change the email for the customer accordingly.
        //                {
        //                    EmailMsg = $"Talkhome \r\nYou have successfully purchased TalkHome Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {preAuthTransaction.TransactionCurrency}{tranItem.Amount}\r\nTransaction Id: {apiResponseModel.payload.Transaction.TransactionId}";
        //                }
        //                else
        //                {
        //                    EmailMsg = $"Talkhome \r\nYou have successfully purchased TalkHome Calling Card. \r\nYour pin is {result.Pin}\r\nCalling Card Amount {preAuthTransaction.TransactionCurrency}{tranItem.Amount}\r\nTransaction Id: {apiResponseModel.payload.Transaction.TransactionId}";
        //                }
        //                #endregion SendSms

        //                #region sendEmail
        //                //Email Testing
        //                EmailTransactionModel emailTransaction = new EmailTransactionModel();
        //                emailTransaction.msisdn = "CustomerReference: " + preAuthTransaction.CustomerMerchantRef;
        //                emailTransaction.description = "Pay360 THRCC Details"; // set the text according to the type of transaction
        //                emailTransaction.status = "The payment was successfull for Item."; // set the status text accordingly
        //                emailTransaction.transactionId = apiResponseModel.payload.Transaction.TransactionId;
        //                emailTransaction.amount = apiResponseModel.payload.Transaction.Currency + " " + tranItem.Amount.ToString();
        //                isEmailSent = await SendEmail(emailTransaction);
        //                if (isEmailSent)
        //                {
        //                    emailSentDatetime = DateTime.UtcNow;
        //                    Console.WriteLine($"Pay360_BL/StartPay360Job, Email Sent Successfully, TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, Msisdn: {preAuthTransaction.Msisdn}, Date_Utc: {DateTime.UtcNow}");
        //                }
        //                else
        //                {
        //                    Console.WriteLine($"Pay360_BL/StartPay360Job, Error in Sending Email, TransactionId: {apiResponseModel.payload.Transaction.TransactionId}, Msisdn: {preAuthTransaction.Msisdn}, Date_Utc: {DateTime.UtcNow}");
        //                }

        //                #endregion

        //                #region SendEmailToCustomer
        //                Customer customer = await Db.GetCustomerByMerchantRef(preAuthTransaction.CustomerMerchantRef);
        //                if (customer != null && !string.IsNullOrWhiteSpace(customer.Email))
        //                {
        //                    isEmailSentToCustomer = await SendEmailToCustomer(customer.Email, EmailMsg);
        //                    customerEmailSentDatetime = DateTime.UtcNow;
        //                }
        //                #endregion

        //            }
        //        }



        //        int dBResult = await Db.UpdateTransactionItem(tranItem.Id, result != null ? result.ErrorMessage : "Code Exception Null Object", isSmsSent, isEmailSentToCustomer, isfullfilment, smsSentDatetime, customerEmailSentDatetime, fullfilmentDatetime);
        //    }
        //}

        //public async Task<GenericApiResponse<string>> Validation()
        //{

        //    List<ProductItems> productItems = await Db.GetProductItems();
        //    string validationMesage = "";
        //    bool isValidationError = false;
        //    if (productItems == null || productItems.Count < 1)
        //    {
        //        isValidationError = true;
        //        validationMesage = "Data not available in ProductItems table";
        //    }

        //    if (userRequest.Basket != null)
        //    {
        //        float basketTotal = 0;
        //        for (int i = 0; i < userRequest.Basket.Length; i++)
        //        {
        //            #region ProductRef Validation

        //            if (userRequest.Basket[i].ProductItemCode.ToLower() == "thm")
        //            {
        //                int result = await Db.ThmProductRefValidation(userRequest.Basket[i].ProductItemCode, userRequest.Basket[i].ProductRef);
        //                if (result != 0) // Not Valid ProductRef
        //                {
        //                    return response = GenericApiResponse<UserResponseModels>.Failure($"Invalid ProductRef: {userRequest.Basket[i].ProductRef} for ProductItem: {userRequest.Basket[i].ProductItemCode}.");
        //                }
        //            }
        //            else if (userRequest.Basket[i].ProductItemCode.ToLower() == "thrcc")
        //            {
        //                int result = await Db.ThrccProductRefValidation(userRequest.Basket[i].ProductItemCode, userRequest.Basket[i].ProductRef);
        //                if (result != 0) // Not Valid ProductRef
        //                {
        //                    return response = GenericApiResponse<UserResponseModels>.Failure($"Invalid ProductRef: {userRequest.Basket[i].ProductRef} for ProductItem: {userRequest.Basket[i].ProductItemCode}.");
        //                }
        //            }

        //            #endregion  ProductRef Validation

        //            #region Basket Amount Total Validation
        //            basketTotal = basketTotal + userRequest.Basket[i].Amount;
        //            #endregion Basket Amount Total Validation

        //            #region ProductItem MaxLimit Validation
        //            if (productItems != null && productItems.Count > 0)
        //            {
        //                ProductItems pItem = productItems.Find(item => item.ProductCode == userRequest.ProductCode && item.ProductItemCode == userRequest.Basket[i].ProductItemCode);
        //                if (pItem == null)
        //                {
        //                    validationMesage += "Basket item " + userRequest.Basket[i].ProductItemCode + " not available in database, ";
        //                    isValidationError = true;
        //                }
        //                else
        //                {
        //                    if (userRequest.Basket[i].Amount > pItem.AmountLimit)
        //                    {
        //                        validationMesage += "Basket item " + userRequest.Basket[i].ProductItemCode + " amount exceeds MaxAmount(" + pItem.AmountLimit + ") limit, ";
        //                        isValidationError = true;
        //                    }
        //                }
        //            }
        //            #endregion ProductItem MaxLimit Validation
        //        }
        //        if (basketTotal != userRequest.TransactionAmount)
        //        {
        //            return response = GenericApiResponse<UserResponseModels>.Failure("Basket total and TransactionAmount are not same.");
        //        }
        //    }
        //    else
        //    {
        //        return response = GenericApiResponse<UserResponseModels>.Failure("Basket is empty.");
        //    }

        //    if (isValidationError)
        //    {
        //        return response = GenericApiResponse<UserResponseModels>.Failure(validationMesage);
        //    }
        //}

    }
}
