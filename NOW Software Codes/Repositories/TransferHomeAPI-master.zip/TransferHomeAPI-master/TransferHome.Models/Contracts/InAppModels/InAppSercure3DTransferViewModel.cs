﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.InAppModels
{
    public class InAppSercure3DTransferViewModel
    {
        public string MD { get; set; }
        public string PaRes { get; set; }

        public int Ref { get; set; }
        public string NowtelTransactionRef { get; set; }
        public string OperatorId { get; set; }
        public string Product { get; set; }
        public string MessageToRecipient { get; set; }
        public string FromMSISDN { get; set; }

    }
}
