﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts.Pay360.Request.Api
{
    public class XeebiSendSmsRequest
    {
        public string from { get; set; }
        public string to { get; set; }
        public string text { get; set; }

    }
}
