using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;

namespace FH.UseCases.Exports;
public sealed class OperatorAliasFile
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public int Page { get; set; }
		public int RecordsPerPage { get; set; }
		public Filter? Filters { get; set; }

		public sealed record Filter
		{
			public string? OperatorName { get; set; }
			public string? CountryIsoCode { get; set; }
		}
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.Page).GreaterThan(0);
			RuleFor(x => x.RecordsPerPage).LessThan(101);
		}
	}
	#endregion

	#region Response
	public sealed record Response
	{
		public long OperatorId { get; set; }
		public string? OperatorName { get; set; }
		public string? OperatorAliasName { get; set; }
		public string? OperatorDescription { get; set; }
		public string? OperatorShortCode { get; set; }
	}
	#endregion

	#region Handler
	internal sealed class Handler(IMapper mapper, IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IMapper _mapper = mapper;
		private readonly IUnitOfWork _unitOfWork = unitOfWork;

		public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
		{
			var getOperatorsRequest = _mapper.Map<OperatorDto.Request>(request);

			// Setting Default Values
			getOperatorsRequest.IsActive = true;
			getOperatorsRequest.IsDeleted = false;

			(IEnumerable<OperatorDto.Response> operators, DatabasePaginationDto pagination) = await _unitOfWork.OperatorRepository.GetOperators(getOperatorsRequest);
			if (operators is null)
			{
				return ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
			}

			var excelFileData = operators.Select(x => new Response()
			{
				OperatorId = x.OperatorId,
				OperatorName = x.OperatorName,
				OperatorAliasName = string.Empty,
				OperatorDescription = string.Empty,
				OperatorShortCode = string.Empty
			});

			var excelFile = excelFileData.ConvertToCsvFile("Operators");
			return ResultWrapper.Success(excelFile);
		}
	}
	#endregion
}
