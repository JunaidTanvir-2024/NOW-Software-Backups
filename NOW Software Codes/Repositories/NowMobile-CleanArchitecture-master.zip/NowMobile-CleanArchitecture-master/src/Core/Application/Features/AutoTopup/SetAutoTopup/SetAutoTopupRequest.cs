﻿namespace Application.Features.AutoTopup.SetAutoTopup;

public class SetAutoTopupRequest : IRequest<Result<object>>
{
    public string Msisdn { get; set; } = default!;
    public float ThresholdAmount { get; set; } = default!;
    public float TopupAmount { get; set; } = default!;
    public bool Status { get; set; }
}