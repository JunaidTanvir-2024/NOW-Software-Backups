﻿namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class SetAutoTopupWithCardResponseModel
    {
        public ThreeDSecureData threeDSecureData { get; set; }
        public AutoTopupInfo AutoTopupInfo { get; set; }
    }
    public class SetAutoRenewalWithCardResponseModel
    {
        public ThreeDSecureData threeDSecureData { get; set; }
    }
}
