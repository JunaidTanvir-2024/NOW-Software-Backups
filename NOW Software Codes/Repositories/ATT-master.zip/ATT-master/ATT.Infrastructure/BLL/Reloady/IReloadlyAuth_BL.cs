﻿using ATT.Models.Contracts.Reloadly.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.Reloadly
{
    public interface IReloadlyAuth_BL
    {
        Task<ReloadlyAuthResponse> getAuthToken();
        Task<ReloadlyAuthResponse> getAuthToken(string currency);

        //for CRM mixed mode Free Switch and THA
        Task<ReloadlyAuthResponse> CRM_ATT_getAuthToken(string currency,string productId);
    }
}
