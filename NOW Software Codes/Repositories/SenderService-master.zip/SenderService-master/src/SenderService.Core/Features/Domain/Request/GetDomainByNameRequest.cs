﻿namespace SenderService.Core.Features.Domain.Request;
public class GetDomainByNameRequest
{
    public string Domain { get; set; } = default!;
}
