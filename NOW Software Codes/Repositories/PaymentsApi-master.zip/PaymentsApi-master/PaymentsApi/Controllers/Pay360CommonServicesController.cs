﻿using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PaymentsApi.Infrastructure.BLL.Interfaces.Pay360;
using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using Serilog;

namespace PaymentsApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class Pay360CommonServicesController : ControllerBase
    {
        private BL_IPay360CommonServices Pay360CommonServices;
        private readonly ILogger Logger;

        public Pay360CommonServicesController(BL_IPay360CommonServices pay360CommonServices, ILogger logger)
        {
            Pay360CommonServices = pay360CommonServices;
            Logger = logger;
        }

        [HttpGet("~/healthcheck")]
        public ActionResult HealthCheck()
        {
            return Ok();
        }

        [HttpPost("CaptureTransaction")]
        public async Task<ActionResult> CaptureTransaction(UserRequestCaptureOrCancelTransaction userRequest)
        {

            GenericApiResponse<ApiPaymentResponse> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.CaptureTransaction(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<ApiPaymentResponse>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: CaptureTransaction, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("CancelTransaction")]
        public async Task<ActionResult> CancelTransaction(UserRequestCaptureOrCancelTransaction userRequest)
        {

            GenericApiResponse<ApiPaymentResponse> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.CancelTransaction(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<ApiPaymentResponse>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: CancelTransaction, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("RefundFullPayment")]
        public async Task<ActionResult> RefundFullPayment(UserRequestRefundFullPayment userRequest)
        {
            GenericApiResponse<ApiPaymentResponse> response;

            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.RefundFullPayment(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<ApiPaymentResponse>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: RefundFullPayment, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }

            return Ok(response);
        }

        [HttpPost("RefundPartialPayment")]
        public async Task<ActionResult> RefundPartialPayment(UserRequestRefundPartialPayment userRequest)
        {
            GenericApiResponse<ApiPaymentResponse> response;

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.RefundPartialPayment(userRequest);
            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<ApiPaymentResponse>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: RefundPartialPayment, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }

            return Ok(response);
        }

        [HttpPost("GetCustomerPaymentMethodsByCustomerUniqueRef")]
        public async Task<ActionResult> GetCustomerPaymentMethodsByCustomerUniqueRef(UserRequestGetCustomerPaymentMethodsByCustomerUniqueRef userRequest)
        {

            GenericApiResponse<UserPaymentMethodsResponse> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.GetCustomerPaymentMethodsByCustomerUniqueRef(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserPaymentMethodsResponse>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: GetCustomerPaymentMethodsByCustomerUniqueRef, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("GetCustomerPaymentMethodsByCustomerID")]
        public async Task<ActionResult> GetCustomerPaymentMethodsByCustomerID(CUSTOMERID customerID)
        {

            GenericApiResponse<UserPaymentMethodsResponse> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.GetCustomerPaymentMethodsByCustomerID(customerID.CustomerID);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserPaymentMethodsResponse>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: GetCustomerPaymentMethodsByCustomerID, Parameters=> customerID: {customerID}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("SetCustomerDefaultCard")]
        public async Task<ActionResult> SetCustomerDefaultCard(UserRequestUpdateCard userRequest)
        {

            GenericApiResponse<UserPaymentMethodResponse> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.SetCustomerDefaultCard(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserPaymentMethodResponse>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: SetCustomerDefaultCard, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("GetCustomerByCustomerUniqueRef")]
        public async Task<ActionResult> GetCustomerByCustomerUniqueRef(UserRequestGetCustomerByCustomerUniqueRef userRequest)
        {

            GenericApiResponse<UserCustomerResponseModels> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.GetCustomerByCustomerUniqueRef(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserCustomerResponseModels>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: GetCustomerByCustomerUniqueRef, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("GetTransactionsByMerchantRef")]
        public async Task<ActionResult> GetTransactionsByMerchantRef(MERCHANTREF merchantRef)
        {

            GenericApiResponse<UserTransactionsResponseModel> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.GetTransactionsByMerchantRef(merchantRef.MerchantRef);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserTransactionsResponseModel>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: GetTransactionsByMerchantRef, Parameters=> UserRequestJson: {merchantRef}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("GetTransactionsByTransactionId")]
        public async Task<ActionResult> GetTransactionsByTransactionId(TRRANSACTIONID transactionId)
        {

            GenericApiResponse<UserTransactionResponseModel> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.GetTransactionsByTransactionId(transactionId.TransactionId);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<UserTransactionResponseModel>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: GetTransactionsByTransactionId, Parameters=> TransactionId: {transactionId}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }


        [HttpPost("GetAutoTopup")]
        public async Task<ActionResult> GetAutoTopup(UserRequestGetAutoTopup userRequest)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(await Pay360CommonServices.GetAutoTopup(userRequest));

            }
            catch (Exception ex)
            {
                Logger.Error($"Controller: Pay360CommonServicesController, Method: GetAutoTopup, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }


        [HttpPost("SetAutoTopup")]
        public async Task<ActionResult> SetAutoTopup(UserRequestSetAutoTopup userRequest)
        {

            GenericApiResponse<string> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.SetAutoTopup(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<string>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: SetAutoTopup, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }

        [HttpPost("RemoveCard")]
        public async Task<ActionResult> RemoveCard(UserRequestRemoveCard userRequest)
        {
            GenericApiResponse<string> response;
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Pay360CommonServices.RemoveCustomerCard(userRequest);

            }
            catch (Exception ex)
            {
                response = new GenericApiResponse<string>()
                {
                    errorCode = 14,
                    status = "Failure",
                    message = ex.Message,
                    payload = null
                };
                Logger.Error($"Controller: Pay360CommonServicesController, Method: RemoveCard, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return Ok(response);
        }
    }

    #region RemoveCardCode
    //[HttpPost("RemoveCustomerCard")]
    //public async Task<ActionResult> RemoveCustomerCard(UserRequestUpdateCard userRequest)
    //{

    //    GenericApiResponse<UserPaymentMethodResponse> response;
    //    try
    //    {

    //        if (!ModelState.IsValid)
    //        {
    //            return BadRequest(ModelState);
    //        }

    //        response = await Pay360CommonServices.SetCustomerDefaultCard(userRequest);

    //    }
    //    catch (Exception ex)
    //    {
    //        response = new GenericApiResponse<UserPaymentMethodResponse>()
    //        {
    //            errorCode = 14,
    //            status = "Failure",
    //            message = ex.Message,
    //            payload = null
    //        };
    //        Logger.Error($"Controller: Pay360CashierApiController, Method: RemoveCustomerCard, Parameters=> UserRequestJson: {JsonConvert.SerializeObject(userRequest)}, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
    //    }
    //    return Ok(response);
    //}
    #endregion
}