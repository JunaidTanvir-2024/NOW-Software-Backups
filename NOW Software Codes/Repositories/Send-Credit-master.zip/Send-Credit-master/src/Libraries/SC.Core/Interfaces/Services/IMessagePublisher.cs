﻿using SC.Core.DependencyResolver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MessageBrokerModel;

namespace SC.Core.Interfaces.Services;
public interface IMessagePublisher : ServiceType.IScoped
{
    Task PublishMessage(TransactionMessageDto message);
}

