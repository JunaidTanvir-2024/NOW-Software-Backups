﻿namespace Effortless.Api.Features.Auth.Password.Response;
public class SetNewPasswordResponse
{
    public bool IsPasswordReset { get; set; }
}