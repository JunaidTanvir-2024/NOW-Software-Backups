﻿

namespace SC.Core.Features.CustomerOrder.Responses;
public sealed class OrderCreationResponse
{
    public long OrderID { get; set; } = default!;
}

