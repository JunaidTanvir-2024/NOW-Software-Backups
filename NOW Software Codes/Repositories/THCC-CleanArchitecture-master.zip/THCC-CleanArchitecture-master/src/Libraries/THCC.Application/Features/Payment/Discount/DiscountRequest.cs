﻿using THCC.Application.Settings;

namespace THCC.Application.Features.Payment.Discount
{
    public class DiscountRequest : IRequest<object>
    {
        public decimal Amount { get; set; }
    }

    public class DiscountRequestValidator : AbstractValidator<DiscountRequest>
    {
        public DiscountRequestValidator(IOptions<TopupSettings> _topupSettings)
        {
            RuleFor(p => p.Amount).Cascade(CascadeMode.Stop)
                .NotEmpty()
                .NotNull()
                .Must(x => _topupSettings.Value.Amounts.Any(a => a.Amount==x))
                .WithMessage("Please only use: " + string.Join(",", values: _topupSettings.Value.Amounts.Select(a=>a.Amount)));
        }
    }
}
