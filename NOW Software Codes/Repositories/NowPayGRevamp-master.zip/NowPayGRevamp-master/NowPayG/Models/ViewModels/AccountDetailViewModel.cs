﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class AccountDetailViewModel : BaseViewModel
    {
        [Required(ErrorMessage = "Enter Password"), MinLength(length: 8, ErrorMessage = "The Password must be at least 8 characters long."), MaxLength(length: 150, ErrorMessage = "Maximum length exceeded.")]
        public string NewPassword { get; set; }
        [Required(ErrorMessage = "Enter Confirm Password"), Compare("NewPassword", ErrorMessage = "Confirm password doesn't match, Type again !")]
        public string ConfirmNewPassword { get; set; }
        [Required(ErrorMessage = "Enter Old Password"), MinLength(length: 8, ErrorMessage = "The Password must be at least 8 characters long."), MaxLength(length: 150, ErrorMessage = "Maximum length exceeded.")]
        public string OldPassword { get; set; }
        public IEnumerable<SelectListItem> UserProductsList { get; set; }
    }
}
