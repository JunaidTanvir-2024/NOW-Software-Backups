namespace Application.Features.Account.History.Models;

public sealed class PaymentHistoryInfo
{
    [JsonIgnore]
    public int TotalCount { get; set; }
    public int OrderID { get; set; }
    public string? TransactionId { get; set; }
    public string? Msisdn { get; set; }
    public DateTime TransactionDate { get; set; }
    public int? TransactionType { get; set; }
    public int? TransactionItemType { get; set; }
    public int PaymentMethodType { get; set; }
    public string Amount { get; set; } = default!;
    public string VatAmount { get; set; } = default!;
    public string Discount { get; set; } = default!;
    public string TotalAmount { get; set; } = default!;
    public string? BundleName { get; set; }
    public string? BundleCountryCode { get; set; }
    //public string? BundleId { get; set; }
    public string? CardMaskedPan { get; set; } = string.Empty;
    public string? ImageURL { get; set; } = string.Empty;
    public string? GoodyBagColorCode { get; set; } = string.Empty;
    public bool IsAuto { get; set; } = false;
    public string OrderStatus { get; set; }
}

public sealed class PaymentHistory
{
    [JsonIgnore]
    public int TotalCount { get; set; }
    public int OrderID { get; set; }
    public string? TransactionId { get; set; }
    //  public string? Email { get; set; }
    public string? Msisdn { get; set; }
    public DateTime TransactionDate { get; set; }
    //public string? TransactionTime { get; set; }
    public int? TransactionType { get; set; }
    public int? TransactionItemType { get; set; }
    public int PaymentMethodType { get; set; }
    public string Amount { get; set; } = default!;
    public string Discount { get; set; } = default!;
    public string TotalAmount { get; set; } = default!;
    //public string? OrderStatus { get; set; }
    //public string? CustomerName { get; set; }
    //public DateTime? CreatedatDateTime { get; set; }
    public string? BundleName { get; set; }
    public string? BundleCountryCode { get; set; }
    public string? BundleId { get; set; }
    public string? OrderData { get; set; }
    public bool IsAuto { get; set; } = false;
    public OrderStatus OrderStatus { get; set; }
}
