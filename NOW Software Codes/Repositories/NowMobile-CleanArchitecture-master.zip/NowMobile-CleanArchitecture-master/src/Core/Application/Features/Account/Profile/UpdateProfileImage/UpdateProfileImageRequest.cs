﻿using Microsoft.AspNetCore.Http;

namespace Application.Features.Account.Profile.UpdateProfileImage;
public class UpdateProfileImageRequest : IRequest<Result<UserInfo>>
{
    public IFormFile? Image { get; set; }
}
