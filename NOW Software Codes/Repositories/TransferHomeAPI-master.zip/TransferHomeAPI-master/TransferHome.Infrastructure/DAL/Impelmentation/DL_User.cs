﻿using Dapper;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.DAOs;
using TrasnferHome.Infrastructure.DAL.Interfaces;
using TrasnferHome.Models.Configurations;
using TrasnferHome.Models.DAOs;
using TrasnferHome.Models.DbConnections;
using TrasnferHome.Models.Utility;

namespace TrasnferHome.Infrastructure.DAL.Impelmentation
{
    public class DL_User : IDL_User
    {
        private readonly IDbConnectionSettings Db;

        public DL_User(IOptions<ConnectionString> connectionString)
        {
            Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TransferHomeDbConnection));
        }

        public async Task<bool> IsUserDeviceActive(string UDID, string Bearertoken, string userId, string path, string method)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UDID", UDID);
                parameters.Add("@Bearertoken", Bearertoken);
                parameters.Add("@userId", userId);
                parameters.Add("@apiname", path);
                parameters.Add("@methodname", method);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<bool>("Transferhome_Api_Common_IsUserDeviceActive_v2", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<bool> IsUserDeviceActive(string UDID)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UDID", UDID);

                //if (Db.SqlConnection.State != ConnectionState.Open && Db.SqlConnection.State != ConnectionState.Connecting)
                //{
                //    Db.SqlConnection.Open();
                //}

                //var attempts = 0;

                //while (Db.SqlConnection.State == ConnectionState.Connecting && attempts < 2)
                //{
                //    attempts++;
                //    Thread.Sleep(500);
                //}

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<bool>("Transferhome_Api_Common_IsUserDeviceActive", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<int> IsUserExistByEmail(string email)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@Email", email);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("Transferhome_Api_Common_IsUserExistByEmail", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<List<DBUserTokens>> GetAllActiveDeviceTokens()
        {
            try
            {
                var records = await Db.SqlConnection.QueryAsync<DBUserTokens>("TransferHome_Api_Common_GetAllUserDevices", commandType: CommandType.StoredProcedure);
                return records.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<List<DBUserTokens>> GetSpecificUsersActiveDeviceTokens(List<string> userMsisdns)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserMsisdns", String.Join(",", userMsisdns));

                var records = await Db.SqlConnection.QueryAsync<DBUserTokens>("TransferHome_Api_Common_GetSpecificUserDevices", parameters, commandType: CommandType.StoredProcedure);
                return records.ToList();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<int> RegisterUserByEmail(DBUser user)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@Email", user.Email);
                parameters.Add("@Password", user.Password);
                parameters.Add("@FirstName", user.FirstName);
                parameters.Add("@LastName", user.LastName);
                parameters.Add("@Role", (int)user.Role);
                parameters.Add("@SignUpTypeId", (int)user.SignUpType);
                parameters.Add("@IsEmailVerified", user.IsEmailVerified);
                parameters.Add("@MailSubscription", user.MailSubscription);
                parameters.Add("@IsEmailVerified", user.IsEmailVerified);
                parameters.Add("@BalanceCurrency", user.BalanceCurrency);
                parameters.Add("@BalanceCurrencySymbol", user.BalanceCurrencySymbol);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("Transferhome_Api_Common_RegisterUserByEmail", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<int> InsertUserToken(DBUserTokens userToken)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@Token", userToken.Token);
                parameters.Add("@TokenTypeId", userToken.TokenTypeId);
                parameters.Add("@UserId", userToken.UserId);

                return await Db.SqlConnection.ExecuteAsync("Transferhome_Api_Common_SaveUserToken", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<int> RegisterUserByPhoneNumber(DBUser user)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@PhoneNumber", user.PhoneNumber);
                parameters.Add("@Role", (int)user.Role);
                parameters.Add("@SignUpTypeId", (int)user.SignUpType);
                parameters.Add("@BalanceCurrency", user.BalanceCurrency);
                parameters.Add("@BalanceCurrencySymbol", user.BalanceCurrencySymbol);
                parameters.Add("@MailSubscription", user.MailSubscription);
                parameters.Add("@UDID", user.UDID);
                parameters.Add("@DeviceType", user.DeviceType);
                parameters.Add("@PinNumber", user.PinNumber);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("Transferhome_Api_Common_RegisterUserByPhoneNumber", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<int> IsUserExistByPhoneNumber(string phoneNumber)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@PhoneNumber", phoneNumber);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("Transferhome_Api_Common_IsUserExistByPhoneNumber", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<int> VerifyToken(string token, int tokenExpiryMinutes, int tokenTypeId)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Token", token);
                parameters.Add("@ExpiryHours", tokenExpiryMinutes);
                parameters.Add("@TokenTypeId", tokenTypeId);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("Transferhome_Api_Common_VerifyToken", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<int> VerifyPin(string token, int tokenExpiryMinutes, int tokenTypeId, int userId)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Token", token);
                parameters.Add("@ExpiryHours", tokenExpiryMinutes);
                parameters.Add("@TokenTypeId", tokenTypeId);
                parameters.Add("@UserId", userId);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("Transferhome_Api_Common_VerifyPin", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<DBUser> GetUserByEmail(string email)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", email);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("Transferhome_Api_Common_GetUserByEmail", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<int> ReSendToken(DBUserTokens userToken)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@Token", userToken.Token);
                parameters.Add("@TokenTypeId", userToken.TokenTypeId);
                parameters.Add("@UserId", userToken.UserId);

                return await Db.SqlConnection.ExecuteAsync("Transferhome_Api_Common_SaveUpdateUserToken", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<DBUser> GetUserByPhoneNumber(string phoneNumber)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@PhoneNumber", phoneNumber);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("Transferhome_Api_Common_GetUserByPhoneNumber", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Marks all devices as inactive against this user.
        /// </summary>
        /// <param name="UserId"></param>
        /// <param name="UDID"></param>
        /// <param name="deviceType"></param>
        /// <param name="phoneNumber"></param>
        /// <returns>List of userdevices that are marked inactive and were previously active</returns>
        public async Task<List<DBUserTokens>> MarkDeviceAsActive(int UserId, string UDID, DeviceType deviceType, string phoneNumber)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", UserId);
                parameters.Add("@UDID", UDID);
                parameters.Add("@DeviceType", deviceType);
                parameters.Add("@PhoneNumber", phoneNumber);

                var result = await Db.SqlConnection.QueryAsync<DBUserTokens>("TransferHome_Api_Common_MarkDeviceAsActive", parameters, commandType: CommandType.StoredProcedure);
                return result.ToList();
            }
            catch
            {
                throw;
            }
        }

        public async Task MarkDeviceAsInActive(string UDID)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UDID", UDID);
                var result = await Db.SqlConnection.QueryAsync<bool>("TransferHome_Api_Common_MarkDeviceAsInActive", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<DBUser> GetUserById(int Id)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Id", Id);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("Transferhome_Api_Common_GetUserById", parameters, commandType: CommandType.StoredProcedure);

            }
            catch
            {
                throw;
            }
        }

        public async Task<int> UpdatePassword(string token, int TokenExpiryMinutes, string password)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Token", token);
                parameters.Add("@ExpiryHours", TokenExpiryMinutes);
                parameters.Add("@Password", password);

                return await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("Transferhome_Api_Common_UpdatePassword", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<IEnumerable<DbCreditHistory>> GetCreditHistory(int userId)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserId", userId);

                return await Db.SqlConnection.QueryAsync<DbCreditHistory>("[dbo].[Transferhome_Api_Common_GetCreditHistory]", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<IEnumerable<DbTransferCreditHistory>> GetTransferCreditHistory(int userId)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserId", userId);

                return await Db.SqlConnection.QueryAsync<DbTransferCreditHistory>("[dbo].[Transferhome_Api_Common_GetTransferCreditHistory]", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<int> EditProfile(EditProfileRequestModel model, string userId)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserId", userId);
                parameters.Add("@FirstName", model.FirstName);
                parameters.Add("@LastName", model.LastName);
                parameters.Add("@MailSubscription", model.MailSubscription);

                return await Db.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_EditProfile]", parameters, commandType: CommandType.StoredProcedure);

            }
            catch
            {
                throw;
            }
        }

        public async Task<IEnumerable<DBTransferTransactions>> GetFavouriteTransactionNumbers(int userId)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserId", userId);

                return await Db.SqlConnection.QueryAsync<DBTransferTransactions>("[dbo].[Transferhome_Api_Common_GetFavouriteTransactionNumbers]", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<IEnumerable<DBTransferTransactions>> GetFrequentTransactionNumbers(int userId)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserId", userId);

                return await Db.SqlConnection.QueryAsync<DBTransferTransactions>("[dbo].[Transferhome_Api_Common_GetFrequentTransactionNumbers]", parameters, commandType: CommandType.StoredProcedure);
            }
            catch
            {
                throw;
            }
        }

        public async Task<int> SaveFavouriteTransactionNumber(DBFavouriteNumber model)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@UserId", model.UserId);
            parameters.Add("@Number", model.Number);

            return await Db.SqlConnection.QueryFirstAsync<int>("[dbo].[Transferhome_Api_Common_SaveUserFavouriteNumber]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> RemoveFavouriteTransactionNumber(DBFavouriteNumber model)
        {

            var parameters = new DynamicParameters();

            parameters.Add("@UserId", model.UserId);
            parameters.Add("@Number", model.Number);

            return await Db.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_RemoveUserFavouriteNumber]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> SaveUpdateFCMToken(DbUserPushNotificationIds model)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@Token", model.Token);
            parameters.Add("@UDID", model.UDID);
            parameters.Add("@DeviceTypeID", (int)model.DeviceType);

            return await Db.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_SaveUpdateFCMToken]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> RemoveCreditHistory(DbCreditHistory model)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@Id", model.Id);
            parameters.Add("@UserId", model.UserId);

            return await Db.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_RemoveCreditHistory]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> RemoveTransferCreditHistory(DbTransferCreditHistory model)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@Id", model.Id);
            parameters.Add("@UserId", model.UserId);

            return await Db.SqlConnection.ExecuteAsync("[dbo].[Transferhome_Api_Common_RemoveTransferCreditHistory]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<DBUser> UpdateUserNotificationsSetting(bool status, int userId)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@Status", status);
            parameters.Add("@UserId", userId);

            return await Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("[dbo].[Transferhome_Api_Common_UpdateUserNotificationsSetting]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<DBUser> UpdateMailSubscription(bool status, int userId)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@Status", status);
            parameters.Add("@UserId", userId);

            return await Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("[dbo].[Transferhome_Api_Common_UpdateMailSubscription]", parameters, commandType: CommandType.StoredProcedure);
        }

        public async Task<bool> IsValidTopUpRequest(int id, string balanceCurrency, decimal amount)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@UserId", id);
            parameters.Add("@Amount", amount);
            parameters.Add("@Currency", balanceCurrency);
            parameters.Add("@IsValid", dbType: DbType.Boolean, direction: ParameterDirection.Output);

            await Db.SqlConnection.ExecuteAsync("Transferhome_Api_Common_ValidateTopUpRequest", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<bool>("@IsValid");
        }
    }
}
