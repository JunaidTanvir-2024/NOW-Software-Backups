using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using Microsoft.EntityFrameworkCore;

using RW;

namespace JM.Core.Features.Currency;

public abstract class GetCurrency
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long Id { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Id).GreaterThan(0);
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public required string Name { get; set; }
        public required string Code { get; set; }
        public required string Symbol { get; set; }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IAppDbContext context) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IAppDbContext _context = context;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var currency = await _context.Currency.FirstOrDefaultAsync();
            if (currency is not null)
            {
                return ResultWrapper.Success(new Response()
                {
                    Id = currency.Id,
                    Code = currency.Code,
                    Name = currency.Name,
                    Symbol = currency.Symbol
                });
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
        }
    }
    #endregion

}
