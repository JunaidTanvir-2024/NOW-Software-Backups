﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class TransferByCardResponseModel
    {
        public TransferData transferData { get; set; }
        public ThreeDSecureData threeDSecureData { get; set; }
        public string IpAddress { get; set; }
    }

    public class TransferData
    {
        public string TransactionId { get; set; }
        public string fromMsisdn { get; set; }
        public string fromAmount { get; set; }
        public string fromCurrency { get; set; }
        
        public string toMsisdn { get; set; }
        public string toAmount { get; set; }
        public string toCurrency { get; set; }

        public string fromCountry { get; set; }
        public string toCountry { get; set; }
    }

    public class ThreeDSecureData
    {
        public string redirectUrl { get; set; }
        public string returnUrl { get; set; }
        public string pareq { get; set; }
        public string transactionId { get; set; }
    }
}
