namespace FH.Core.Entities;
public sealed record VendorDataHashEntity : BaseEntity<long>
{
    public long VendorHashId { get; set; }
    public long ApiPage { get; set; }
    public string? BatchHash { get; set; }
    public string? ApiType { get; set; }
}
