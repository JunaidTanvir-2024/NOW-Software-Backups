﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using THAPromotionsWEB.Models;

namespace THAPromotionsWEB.Controllers
{
    [Produces("application/json")]
    [Route("api/TransferToPromotions")]
    public class TransferToPromotionsController : Controller
    {
        Channel channel = new Channel();
        List<Item> items = new List<Item>();
        List<Country> countryList = new List<Country>();
        private readonly ILogger Logger;

        public TransferToPromotionsController(ILogger logger)
        {
            Logger = logger;            
        }

        // GET: api/TransferToPromotions
        [HttpGet]
        public async Task<RSS> GetAsync()
        {
            try
            {
               
                string url = "https://shop.transferto.com/shop/promotions2.xml";
                var return_response_data = await GetAsyncJsonData(url);

                if (!string.IsNullOrWhiteSpace(return_response_data))
                {


                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(return_response_data);


                    XmlNodeList xnList = doc.SelectNodes("rss/channel/item");
                    foreach (XmlNode xn in xnList)
                    {
                        string title = xn["title"].InnerText.Trim();
                        string description = xn["description"].InnerText.Trim();
                        string dateFrom = xn["dateFrom"].InnerText;
                        string dateTo = xn["dateTo"].InnerText;
                        string pubDate = xn["pubDate"].InnerText;
                        string operatorName = xn["operatorName"].InnerText;
                        string operatorId = xn["operatorId"].InnerText;
                        string subOperatorId = xn["subOperatorId"].InnerText;
                        string countryId = xn["countryId"].InnerText;
                        string countryName = xn["countryName"].InnerText;
                        string title2 = xn["title2"].InnerText.Trim();
                        string denomination = xn["denomination"].InnerText.Trim();

                        string denominationLocal = "";
                        if (xn["denominationLocal"] != null)
                        {
                            denominationLocal = xn["denominationLocal"].InnerText.Trim();
                        }

                        DateTime start = DateTime.Parse(dateFrom);
                        DateTime end = DateTime.Parse(dateTo);
                        DateTime now = DateTime.UtcNow;
                        string status = string.Empty;

                        string promotionstatus = "";


                        // see if start comes before end
                        if (start <= now && now <= end)
                        {
                            promotionstatus = "Active";
                        }
                        else if (start >= now && now <= end)
                        {
                            promotionstatus = "UpComing";
                        }

                        items.Add(new Item
                        {
                            dateFrom = dateFrom,
                            dateTo = dateTo,
                            denomination = denomination,
                            denominationLocal = denominationLocal,
                            description = description,
                            operatorId = operatorId,
                            operatorName = operatorName,
                            pubDate = pubDate,
                            subOperatorId = subOperatorId,
                            title = title,
                            title2 = title2,
                            countryId = countryId,
                            countryName = countryName,
                            promotionstatus = promotionstatus
                        });


                        countryList.Add(new Country
                        {
                            countryId = countryId,
                            countryName = countryName,

                        });



                    }

                    XmlNodeList xnChannel = doc.SelectNodes("rss/channel");
                    foreach (XmlNode xn in xnChannel)
                    {
                        string title = xn["title"].InnerText.Trim();
                        string description = xn["description"].InnerText.Trim();
                        string link = xn["link"].InnerText;
                        string pubDate = xn["pubDate"].InnerText;
                        string lastBuildDate = xn["lastBuildDate"].InnerText;
                        string ttl = xn["ttl"].InnerText;

                        channel.title = title;
                        channel.description = description;
                        channel.link = link;
                        channel.pubDate = pubDate;
                        channel.lastBuildDate = lastBuildDate;
                        channel.ttl = ttl;

                        channel.item = items;
                    }

                    var country = countryList.GroupBy(x => x.countryId)
                                .Select(g => g.First()).OrderBy(x => x.countryName);

                    RSS rss = new RSS { channel = channel, country = country.ToList() };
                    return rss;

                }
                else
                {
                    return null;
                }

            }
            catch(Exception ex)
            {
                Logger.Error($"Class: TransferToPromotionsController, Method: GetAsync, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return null;
            }


        }

      

        private async Task<string> GetAsyncJsonData(string url)
        {
            
            string return_response_data = string.Empty;
            try
            {
                
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                var client = new HttpClient();
                var response = await client.GetAsync(new Uri(url));
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    return_response_data = response.Content.ReadAsStringAsync().Result;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferToPromotionsController, Method: GetAsyncJsonData, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");               
            }
            return return_response_data;
        }
    }
}
