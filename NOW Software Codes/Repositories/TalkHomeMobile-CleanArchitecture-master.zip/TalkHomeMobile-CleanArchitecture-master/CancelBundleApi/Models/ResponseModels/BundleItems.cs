﻿namespace CancelBundleApi.Models.ResponseModels
{
    public class BundleItems
    {
        public List<Item> Items { get; set; }
    }
    public class Item
    {
        public string ServiceCorrelationGuid { get; set; }
        public int Type { get; set; }
        public int Id { get; set; }
        public CallingPackage CallingPackage { get; set; }
        public int State { get; set; }
        public int ChargePeriodsElapsed { get; set; }
        public int AllowancePeriodsElapsed { get; set; }
        public string AllowanceRenewalDate { get; set; }
        public DateTime LastChargePaymentDate { get; set; }
        public DateTime LastAllowancePaymentDate { get; set; }
        public DateTime Started { get; set; }
        public DateTime Expired { get; set; }
        public string NoticePeriodEnd { get; set; }
        public CommonAllowance CommonAllowance { get; set; }
        public VoiceAllowance VoiceAllowance { get; set; }
        public SMSAllowance SMSAllowance { get; set; }
        public MMSAllowance MMSAllowance { get; set; }
        public GPRSAllowance GPRSAllowance { get; set; }
    }
    public class CallingPackage
    {
        public int ServiceType { get; set; }
        public string PackageId { get; set; }
        public int PackageType { get; set; }
        public int PackageCategory { get; set; }
        public string PackageName { get; set; }
        public string BrandedName { get; set; }
        public object PIC { get; set; }
        public int MaximumBundles { get; set; }
        public bool IsMutuallyExclusive { get; set; }
        public string Description { get; set; }
        public double SubscriptionCharge { get; set; }
        public double RecurringCharge { get; set; }
        public int ChargePeriodLength { get; set; }
        public int ChargePeriodType { get; set; }
        public int ChargeRecurrence { get; set; }
        public bool ChargeAtEndOfPeriod { get; set; }
        public int AllowancePeriodType { get; set; }
        public int AllowancePeriodLength { get; set; }
        public int AllowanceRecurrence { get; set; }
        public string FullType { get; set; }
        public double InitialCharge { get; set; }
        public CommonAllowance CommonAllowance { get; set; }
        public VoiceAllowance VoiceAllowance { get; set; }
        public SMSAllowance SMSAllowance { get; set; }
        public MMSAllowance MMSAllowance { get; set; }
        public GPRSAllowance GPRSAllowance { get; set; }
    }

    public class CommonAllowance
    {
        public double Spend { get; set; }
        public int SpendMode { get; set; }
        public string SpendText { get; set; }
    }

    public class GPRSAllowance
    {
        public object Bytes { get; set; }
        public int BytesMode { get; set; }
        public string BytesText { get; set; }
        public double Spend { get; set; }
        public int SpendMode { get; set; }
        public string SpendText { get; set; }
    }



    public class MMSAllowance
    {
        public int Messages { get; set; }
        public int MessagesMode { get; set; }
        public string MessagesText { get; set; }
        public double Spend { get; set; }
        public int SpendMode { get; set; }
        public string SpendText { get; set; }
    }

    public class SMSAllowance
    {
        public int Messages { get; set; }
        public int MessagesMode { get; set; }
        public string MessagesText { get; set; }
        public double Spend { get; set; }
        public int SpendMode { get; set; }
        public string SpendText { get; set; }
    }

    public class VoiceAllowance
    {
        public int Seconds { get; set; }
        public int SecondsMode { get; set; }
        public string SecondsText { get; set; }
        public int Calls { get; set; }
        public int CallsMode { get; set; }
        public string CallsText { get; set; }
        public double Spend { get; set; }
        public int SpendMode { get; set; }
        public string SpendText { get; set; }
    }
}
