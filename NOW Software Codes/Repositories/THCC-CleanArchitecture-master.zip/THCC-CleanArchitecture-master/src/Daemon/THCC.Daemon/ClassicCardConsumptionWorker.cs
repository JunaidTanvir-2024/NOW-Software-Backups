﻿using THCC.Application.Interfaces.Services.Tracking;

namespace THCC.Daemon;

public class ClassicCardConsumptionWorker : BackgroundService
{
    private readonly ILogger<ClassicCardConsumptionWorker> _logger;
    private readonly IServiceScopeFactory _serviceProvider;

    public ClassicCardConsumptionWorker(
        ILogger<ClassicCardConsumptionWorker> logger,
        IServiceScopeFactory serviceProvider)
    {
        _logger = logger;
        _serviceProvider = serviceProvider;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _serviceProvider.CreateScope();
                var callingCardService = scope.ServiceProvider.GetRequiredService<ICallingCardConsumptionService>();
                await callingCardService.ClassicCardConsumptionJob();
            }
            catch (Exception ex)
            {
                _logger.LogError("CallingCardConsumptionWorker, " +
                                 "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                 "StackTrace: " + ex.StackTrace);
            }
            await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
        }
    }
}