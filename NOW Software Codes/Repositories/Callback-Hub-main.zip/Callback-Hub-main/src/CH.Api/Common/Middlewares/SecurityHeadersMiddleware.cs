using CH.Api.Common.Definitions;
using CH.Api.Common.Settings;

using Microsoft.Extensions.Options;

namespace CH.Api.Common.Middlewares;
internal class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;
    private readonly SecurityHeaderSetting _securityHeaderSetting;

    public SecurityHeadersMiddleware(RequestDelegate next, IOptions<SecurityHeaderSetting> options)
    {
        _next = next;
        _securityHeaderSetting = options.Value;
    }
    public async Task Invoke(HttpContext context)
    {
        if (_securityHeaderSetting?.Enable is true)
        {
            if (!context.Response.HasStarted)
            {
                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.XFrameOptions))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeaders.XFrameOptions, _securityHeaderSetting.XFrameOptions);
                }

                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.XContentTypeOptions))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeaders.XContentTypeOptions, _securityHeaderSetting.XContentTypeOptions);
                }

                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.ReferrerPolicy))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeaders.ReferrerPolicy, _securityHeaderSetting.ReferrerPolicy);
                }

                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.PermissionsPolicy))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeaders.PermissionsPolicy, _securityHeaderSetting.PermissionsPolicy);
                }

                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.SameSite))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeaders.SameSite, _securityHeaderSetting.SameSite);
                }

                if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.XXSSProtection))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeaders.XXSSProtection, _securityHeaderSetting.XXSSProtection);
                }
            }
        }

        await _next(context);
    }
}
