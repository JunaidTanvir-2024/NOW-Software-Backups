﻿namespace Models.Contracts.Response.Voucherify
{
    public class LoyaltyPointsRedemptionResponse
    {
        public bool IsRedeemed { get; set; }
    }
}
