﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.AppsFlyer
{
    public class SetCustomerIdRequestModel
    {
        public string customerUserId { get; set; }
        public string afUserId { get; set; }
        public string productCode { get; set; } = "THA-WEB";
    }
}
