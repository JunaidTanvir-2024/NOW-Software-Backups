﻿namespace Application.Common.Settings;

public class FaceBookSettings
{
    public const string SectionName = "FaceBookSettings";
    public static FaceBookSettings Bind = new FaceBookSettings();
    public string? APPID { get; set; }
    public bool? IsActive { get; set; }
}

