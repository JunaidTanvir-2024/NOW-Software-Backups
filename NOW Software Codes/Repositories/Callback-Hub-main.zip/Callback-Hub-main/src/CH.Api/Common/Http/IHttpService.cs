using CH.Api.Common.Definitions;

namespace CH.Api.Common.Http;

public interface IHttpService
{
    Task<(bool IsFailure, string Json)> PostAsync(string requestUri, object? data = default);
    IHttpService BaseUrl(string baseUrl);
    IHttpService SetVendor(AppEnums.Vendor vendor);
    IHttpService WithHeaders(Dictionary<string, string> headers);
}
