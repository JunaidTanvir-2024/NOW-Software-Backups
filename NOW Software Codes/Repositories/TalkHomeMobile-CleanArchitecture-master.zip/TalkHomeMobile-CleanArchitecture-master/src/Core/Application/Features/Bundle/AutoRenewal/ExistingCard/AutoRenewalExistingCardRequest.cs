using Application.Features.Payment.Card.Models;

namespace Application.Features.Bundle.AutoRenewal.ExistingCard;

public class AutoRenewalExistingCardRequest : IRequest<Result<CardResponse>>
{
    public string Msisdn { get; set; } = default!;
    public int BundleId { get; set; } = default!;
    [JsonIgnore]
    public bool IsAutoRenew { get; set; } = default!;
    [JsonIgnore]
    public string IpAddress { get; set; } = string.Empty;
    public PaymentExistingCardInfo PaymentCardInfo { get; set; } = new PaymentExistingCardInfo();
}
