﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Models.Common
{
    public class BaseApiResult
    {
        [JsonPropertyName("message")]
        public string Message { get; set; }
        [JsonPropertyName("code")]
        public int Code { get; set; }
    }
    public class ApiResult<T>
    {
        [JsonPropertyName("message")]
        public string Message { get; set; }
        [JsonPropertyName("code")]
        public int Code { get; set; }
        [JsonPropertyName("payload")]
        public T Payload { get; set; }
    }
    public class ApiResultSet<T>
    {
        [JsonPropertyName("message")]
        public string Message { get; set; }
        [JsonPropertyName("code")]
        public int Code { get; set; }

        [JsonPropertyName("paginationInfo")]
        public PaginationInfo PaginationInfo { get; set; }

        [JsonPropertyName("payload")]
        public List<T> Payload { get; set; }
    }

    public sealed class PaginationInfo
    {
        [JsonPropertyName("totalCount")]
        public int TotalCount { get; set; }

        [JsonPropertyName("pageCount")]
        public int PageCount { get; set; }

        [JsonPropertyName("currentPage")]
        public int CurrentPage { get; set; }

        [JsonPropertyName("pageSize")]
        public int PageSize { get; set; }
    }
}