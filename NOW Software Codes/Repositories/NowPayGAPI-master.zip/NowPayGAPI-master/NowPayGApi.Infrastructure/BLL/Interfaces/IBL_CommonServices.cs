﻿using NowPayGApi.Models.Contracts;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using NowPayGApi.Models.DAOs.Digitalk;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace NowPayGApi.Infrastructure.BLL.Interfaces
{
    public interface IBL_CommonServices
    {
        Task<GenericApiResponse<GetPlansResponseModel>> GetAllActivePlans();
        Task<GenericApiResponse<GetPlansResponseModel>> GetAllPlans();
        Task<GenericApiResponse<GetCountriesResponseModel>> GetCountries();
        Task<GenericApiResponse<GetPlanCategoriesResponseModel>> GetPlanCategories();
        Task<GenericApiResponse<GetProductResponseModel>> GetProduct();
        Task<GenericApiResponse<GetCurrencyResponseModel>> GetCurrency();
        Task<GenericApiResponse<GetPlanResponseModel>> GetPlanById(IdRequestModel model);
        Task<GenericApiResponse<GetAllInternationalRatesResponseModel>> GetAllInternationalRates();
        Task<GenericApiResponse<GetRoamingRatesResponseModel>> GetRoamingRates(GetRoamingRatesRequestModel model);
        Task<GenericApiResponse<GetAllUKRatesResponseModel>> GetAllUKRates();
        Task<GenericApiResponse<GetAllCountriesWithPlansResponseModel>> GetAllCountriesWithPlans();
        Task<GenericApiResponse<GetAddressResponseModel>> GetAddresses(GetAddressesRequestModel model);
        Task<GenericApiResponse<GetSimOrdersNoByEmailResponseModel>> GetSimOrdersNoByEmail(GetSimOrdersNoByEmailRequestModel model);
        Task<GenericApiResponse<string>> GetFirstUseDate(string msisdn);
    }
}
