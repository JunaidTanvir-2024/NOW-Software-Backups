﻿using Dapper;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Data.DbConnections;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Models.Configurations;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Repositories
{
    public class RatesRepository : IRatesRepository
    {
        private readonly IDbConnectionSettings TH_Db;
        public RatesRepository(IOptions<ConnectionString> connectionString)
        {
            TH_Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.TalkHomeAppDbConnection));
        }

        public async Task<IEnumerable<Rates>> GetRates(string IsoCode)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@isoCode", IsoCode);
                parameters.Add("@currencyCode", null);
                var result = await TH_Db.SqlConnection.QueryAsync<Rates>("tha_web_country_rates", parameters, commandType: CommandType.StoredProcedure);
                if (result != null)
                {
                    return result;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
