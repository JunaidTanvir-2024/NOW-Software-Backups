using RW;

using Voucherify.Api.Features.Customers;
using Voucherify.Api.Features.Customers.Responses;
using Voucherify.Api.Features.Utility.Requests;
using Voucherify.Api.Features.Utility.Responses;
using Voucherify.Core.Domain.Definitions;
using Voucherify.Core.Services.VoucherifyApi;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;
using Voucherify.Core.Services.VoucherifyApi.Models.Events;

namespace Voucherify.Api.Features.Utility;

public interface IUtilityHandler
{
    Task<IResultWrapper<InvokeEventResponse>> InvokeVoucherifyEvent(InvokeEventRequest request);
}

internal class UtilityHandler : IUtilityHandler
{
    private readonly IVoucherifyImplementation _voucherifyImplementation;
    private readonly ICustomersHandler _customersHandler;

    public UtilityHandler(
        IVoucherifyImplementation voucherifyImplementation,
        ICustomersHandler customersHandler)
    {
        _voucherifyImplementation = voucherifyImplementation;
        _customersHandler = customersHandler;
    }

    public async Task<IResultWrapper<InvokeEventResponse>> InvokeVoucherifyEvent(InvokeEventRequest request)
    {
        var customer = await _customersHandler.GetCustomer(new Customers.Requests.GetCustomerRequest()
        {
            CustomerSourceId = request.CustomerSourceId!
        });
        var newVourcherifyEvent = new EventCreate()
        {
            Name = request.EventName,
            Metadata = request.Metadata,
            Customer = new Customer()
            {
                Id = customer.Payload?.Id,
                SourceId = customer.Payload == null ? request.CustomerSourceId : customer?.Payload?.SourceId,
                Email = customer?.Payload?.Email,
                Name = customer?.Payload?.Name,
                Phone = customer?.Payload?.Phone,
                Description = customer?.Payload?.Description,
                Metadata = customer?.Payload?.Metadata,
                Address = new Core.Services.VoucherifyApi.Models.Common.Address()
                {
                    Country = customer?.Payload?.Country,
                    City = customer?.Payload?.City,
                    Line1 = customer?.Payload?.AddressLine1,
                    Line2 = customer?.Payload?.AddressLine2,
                    PostalCode = customer?.Payload?.PostalCode,
                    State = customer?.Payload?.State
                },
                Loyalty = new CustomerLoyalty()
                {
                    Campaigns = customer?.Payload?.LoyaltyCampaigns,
                    Points = customer?.Payload?.Points > 0 ? Convert.ToInt32(customer?.Payload?.Points) : 0,
                    ReferredCustomers = customer?.Payload?.ReferredCustomers > 0 ? Convert.ToInt32(customer?.Payload?.ReferredCustomers) : 0,
                },
            }
        };
        var voucherifyEvent = await _voucherifyImplementation.CreateVoucherifyEvent(newVourcherifyEvent);

        return voucherifyEvent != null
            ? ResultWrapper.Success(new InvokeEventResponse()
            {
                EventType = voucherifyEvent.Type,
                IsEventInvoked = true
            })
            : ResultWrapper.Failure<InvokeEventResponse>(AppConstants.StatusMessages.VoucherifyEventNotInvoked, AppConstants.StatusCodes.VoucherifyEventNotInvoked);
    }
}
