﻿namespace THCC.Application.Features.User.Profile.UserProfile;
public class UserProfileRequest : IRequest<object>
{
}
