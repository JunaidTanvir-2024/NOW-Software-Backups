﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Reloadly.Request
{
    public class ReloadlyAuthRequest
    {
        public string AuthApiEndPoint { get; set; }
        public string client_id { get; set; }
        public string client_secret { get; set; }
        public string grant_type { get; set; }
        public string audience { get; set; }
    }
}
