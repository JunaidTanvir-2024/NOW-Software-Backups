﻿namespace SenderService.Core.Common.Constants;
public static class GlobalConstants
{
    public static class ContentType
    {
        public const string ApplicationJson = "application/json";
        public const string ApplicationOctetStream = "application/octet-stream";
        public const string ApplicationXml = "application/xml";
    }

    public static class AuthType
    {
        public const string Basic = "Basic";
        public const string Jwt = "Bearer";
    }
}