﻿using CancelBundleApi.Extensions.DependencyContainers.ServicesContainers;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CancelBundleApi.Extensions.DependencyContainers;

public static class RegisterServicesContainer
{
    public static IServiceCollection RegisterApiLibraryServices(this IServiceCollection services, IConfiguration config)
    {

        services.RegisterSettingsServices(config);
        //services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

        services.RegisterHttpServices(config);
        services.RegisterApplicationServices(config);
        services.RegisterRepositoryServices(config);
        return services;
    }

}
