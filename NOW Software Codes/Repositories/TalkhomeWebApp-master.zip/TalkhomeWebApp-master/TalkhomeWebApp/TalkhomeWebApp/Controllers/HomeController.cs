﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using TalkhomeWebApp.Models;
using TalkhomeWebApp.Models.ApiContracts.Response;
using TalkhomeWebApp.Models.ViewModels;
using TalkhomeWebApp.Utilities;
using Serilog;
using Microsoft.Extensions.Options;
using TalkhomeWebApp.Models.Configurations;
using TalkhomeWebApp.Models.ApiContracts.Request;
using Newtonsoft.Json.Linq;
using TalkhomeWebApp.Utilities.Extension;
using Microsoft.AspNetCore.DataProtection;
using System.Web;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Diagnostics;
using NUglify.Helpers;
using TalkhomeWebApp.Models.AirShip;
using System.Security.Claims;
using System.Text;
using static TalkhomeWebApp.Models.ApiContracts.Response.TransferOperatorsResponse;
using TalkhomeWebApp.Services;
using TalkhomeWebApp.Models.Facebook.CustomEvents;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Authentication;

namespace TalkhomeWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger _logger;
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly IDataProtector _dataProtector;
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly EndPoints _Endpoints;
        private readonly IBundleService _bundleService;
        private readonly IRatesService _ratesService;
        private readonly IGeoService _geoService;
        private readonly IAirshipService _airshipService;
        private readonly IAppsFlyerService _appsFlyerService;
        private readonly IFacebookService _facebookService;
        private readonly IHelperService _helperService;
        private readonly IOptions<TopUpConfig> _topupConfig;
        private readonly ApiClient ApiClient;

        public HomeController(
            ILogger logger,
            IOptions<BasicAuthConfig> basicAuthConfig,
            IOptions<EndPoints> Endpoints,
            IDataProtectionProvider provider,
            IWebHostEnvironment hostEnvironment,
            IBundleService bundleService,
            IRatesService ratesService,
            IGeoService geoService,
            IAirshipService airshipService,
            IAppsFlyerService appsFlyerService,
            IFacebookService facebookService,
            IHelperService helperService,
            IOptions<TopUpConfig> topupConfig,
            ApiClient apiClient)
        {
            _logger = logger;
            _hostEnvironment = hostEnvironment;
            _dataProtector = provider.CreateProtector("THA-WEB-101");
            _basicAuthConfig = basicAuthConfig.Value;
            _Endpoints = Endpoints.Value;
            _bundleService = bundleService;
            _ratesService = ratesService;
            _geoService = geoService;
            _airshipService = airshipService;
            _facebookService = facebookService;
            _appsFlyerService = appsFlyerService;
            _helperService = helperService;
            _topupConfig = topupConfig;
            this.ApiClient = apiClient;
        }

        public async Task<IActionResult> Index()
        {

            try
            {
                if (User.Identity.IsAuthenticated)
                {                                            
                    var apiResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                        "Account/IsAccountDeleteRequestInProgress", User, ApiCallType.Bearer);

                    if (apiResponse.IsSuccessStatusCode)
                    {
                        var responseJson = JObject.Parse(apiResponse.Content.ReadAsStringAsync().Result);
                        int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                        bool isDeleteRequestInProgress = responseJson.GetValue("payload").ToObject<bool>();
                        if (errorCode == 0 && isDeleteRequestInProgress)
                        {
                            await HttpContext.SignOutAsync();
                        }
                                              
                    }
                    else if (apiResponse.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                    }
                    else
                    {
                        throw new Exception("Index - Error while getting data from API: StatusCode" + apiResponse.StatusCode);
                    }

                    #region Airship
                    if (_airshipService.IsActive)
                    {
                        string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                        //events
                        var customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = "opened_web"
                        };
                        _airshipService.AddCustomEvent(customEventsRequest);
                    }
                    #endregion
                }

                return View(new IndexViewModel()
                {
                    CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol("USD")
                });
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: Index, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }
        public IActionResult GetCurrencyByCountryCode(string countryCode)
        {
            countryCode = countryCode != null ? countryCode : countryCode = "";
            countryCode = countryCode.ToUpper();
            var CountryCurrencyJson = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountryCurrency.json");
            var _countriesCurrency = JsonConvert.DeserializeObject<AllCurrenciesModel>(CountryCurrencyJson);

            var currentCountry = _countriesCurrency.Currencies.Where(x => x.ContainsKey(countryCode)).FirstOrDefault();

            if (currentCountry != null)
            {
                var currency = currentCountry[countryCode];

                if (currency != "GBP" && currency != "EUR")
                {
                    currency = "USD";
                }

                return Json(new { currency = CommonExtentionMethods.GetCurrencySymbol(currency) });
            }
            else
            {
                return Json(new { currency = CommonExtentionMethods.GetCurrencySymbol("USD") });
            }
        }

        [HttpGet]
        [Route("bundles")]
        public IActionResult Bundles()
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    #region Airship
                    if (_airshipService.IsActive)
                    {
                        string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                        //events
                        var customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = "view_bundles_web"
                        };
                        _airshipService.AddCustomEvent(customEventsRequest);
                    }
                    #endregion
                }
                return View();
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: Bundles, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [HttpGet]
        [Route("bundlesCountries")]
        public async Task<IActionResult> BundlesCountries()
        {
            try
            {
                if (!User.Identity.IsAuthenticated)
                {
                    var BundlesCountries = await _bundleService.GetBundlesCountries(User);

                    return Json(new
                    {
                        isAuth = false,
                        BundlesCountries
                    });
                }
                else
                {
                    var _countries = JsonConvert.DeserializeObject<CountriesModel>(System.IO.File.ReadAllText(
                                                        _hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json"));

                    return Json(new
                    {
                        isAuth = true,
                        currencySymbol = CommonExtentionMethods.GetCurrencySymbol(User.Claims.Where(x => x.Type == "currency").FirstOrDefault().Value),
                        iso_code = User.Claims.Where(x => x.Type == "iso_two_country").FirstOrDefault().Value,
                        countryName = _countries.countries.Where(x => x.IsoTwoCharacterCode.Equals(User.Claims.Where(x => x.Type == "iso_two_country").FirstOrDefault().Value)).Select(x => x.Name).FirstOrDefault()
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: BundlesCountries, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetBundlesByOrigination(string Na_Service_Id, string fromCoutry)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    Na_Service_Id = User.Claims.Where(x => x.Type == "service_id").FirstOrDefault().Value;
                    fromCoutry = User.Claims.Where(x => x.Type == "iso_two_country").FirstOrDefault().Value;
                    var account = User.Claims.Where(x => x.Type == "account_id").FirstOrDefault().Value;
                    var Bundles = await _bundleService.GetBundleByCountry(Na_Service_Id, fromCoutry, account, User);
                    return Json(new { errorCode = 0, status = true, Data = Bundles });
                }
                else
                {
                    var Bundles = await _bundleService.GetBundleByCountry(Na_Service_Id, fromCoutry, null, User);
                    return Json(new { errorCode = 0, status = true, Data = Bundles });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: GetBundlesByOrigination, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetDestinationCountriesByOrigination(string Na_Service_Id, string fromCoutry)
        {
            try
            {
                List<Rates> payload = await _ratesService.GetRates(fromCoutry, User);

                if (payload.Count > 0)
                {
                    payload = payload.OrderBy(x => x.Destination).ToList();
                }

                var result = payload.Where(x=>x.Mobile>0 || x.Landline>0).Select(x => new
                {
                    CountryName = x.Destination,
                    CountryCode = x.ISO2Code
                });
                return Json(new { errorCode = 0, status = true, Data = result });

            }
            catch (Exception ex)
            {

                _logger.Error($"Class: HomeController, Method: Rates, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetBundleCountriesByOrigination(string Na_Service_Id, string fromCoutry)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    Na_Service_Id = User.Claims.Where(x => x.Type == "service_id").FirstOrDefault().Value;
                    fromCoutry = User.Claims.Where(x => x.Type == "iso_two_country").FirstOrDefault().Value;
                    var account = User.Claims.Where(x => x.Type == "account_id").FirstOrDefault().Value;
                    var Bundles = await _bundleService.GetBundleByCountry(Na_Service_Id, fromCoutry, account, User);
                    return Json(new { errorCode = 0, status = true, Data = Bundles });
                }
                else
                {
                    var Bundles = await _bundleService.GetBundleByCountry(Na_Service_Id, fromCoutry, null, User);
                    return Json(new { errorCode = 0, status = true, Data = Bundles });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: GetBundlesByOrigination, " +
                    $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetBundlesByCountryName(string fromCountrycode, string Na_Service_Id, string toCountryName, string toCountryCode)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    Na_Service_Id = User.Claims.FirstOrDefault(x => x.Type == "service_id").Value;
                    fromCountrycode = User.Claims.FirstOrDefault(x => x.Type == "iso_two_country").Value;
                }
                var model = new LandingPageModel();

                #region Rates Data Fetch

                IList<Rates> payload = await _ratesService.GetRates(fromCountrycode, User);

                if (payload.Count > 0)
                {
                    payload = payload.OrderBy(x => x.Destination).ToList();
                    model.CountryRates = payload.Where(r => r.ISO2Code.Equals(toCountryCode, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();
                }

                var topupuAmount = _topupConfig.Value.TopUpAmounts;
                foreach (var item in topupuAmount)
                {
                    model.Topups.Add(new LandingPageModel.Topup
                    {
                        Minutes = (int)Math.Round(item * 100 / (model.CountryRates.Mobile>0?model.CountryRates.Mobile:model.CountryRates.Landline)),
                        Price = item
                    });
                }
                model.CountryContent.CountryName = _helperService.GetCountryNameByCountryCode(fromCountrycode);
                #region Currency Get

                if (User.Identity.IsAuthenticated)
                {
                    model.MinorCurrencyunit = CommonExtentionMethods.GetMinorCurrencyUnit(
                                                                User.Claims.Where(x => x.Type == "currency").First().Value);
                    model.CurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(
                                                               User.Claims.Where(x => x.Type == "currency").First().Value);
                    model.CurrentCurreny = User.Claims.Where(x => x.Type == "currency").First().Value;
                }
                else
                {
                    var CurrencyJson = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountryCurrency.json");
                    var _countriesCurrency = JsonConvert.DeserializeObject<AllCurrenciesModel>(CurrencyJson);

                    if (!string.IsNullOrEmpty(fromCountrycode))
                    {
                        var currentCurrency = _countriesCurrency.Currencies.Where(x => x.ContainsKey(fromCountrycode)).FirstOrDefault();

                        if (currentCurrency != null)
                        {
                            model.CurrentCurreny = CommonExtentionMethods.GetCurrencyUnit(currentCurrency[fromCountrycode]);
                            model.MinorCurrencyunit = model.CurrentCurreny.GetMinorCurrencyUnit();
                            model.CurrencySymbol = model.CurrentCurreny.GetCurrencySymbol();
                        }
                        else
                        {
                            model.CurrentCurreny = "USD";
                            model.MinorCurrencyunit = model.CurrentCurreny.GetMinorCurrencyUnit();
                            model.CurrencySymbol = model.CurrentCurreny.GetCurrencySymbol();
                        }
                    }
                    else
                    {
                        model.CurrentCurreny = "USD";
                        model.MinorCurrencyunit = model.CurrentCurreny.GetMinorCurrencyUnit();
                        model.CurrencySymbol = model.CurrentCurreny.GetCurrencySymbol();
                    }
                }
                #endregion

                #endregion

                #region Bundles
                model.CountryData.Name = toCountryName;
                model.CountryData.IsoTwoCharacterCode = toCountryCode;
                string account = string.Empty;
                if (User.Identity.IsAuthenticated)
                {
                    account = User.Claims.Where(x => x.Type == "account_id").First().Value;
                }
                else
                {
                    account = null;
                }
                model.Bundles = (await _bundleService.GetBundleByDestinationCountry(Na_Service_Id, fromCountrycode, toCountryCode, account, User))
                   .ToList();
                #endregion

                if (User.Identity.IsAuthenticated)
                {
                    string namedUserId = User.Claims.First(x => x.Type == ClaimTypes.NameIdentifier).Value;
                    var customEventsRequest = new CustomEventsRequest()
                    {
                        ProductCode = "THA",
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = namedUserId,
                        CustomEventName = $"clicked_explore_{model.CountryData.IsoTwoCharacterCode.ToLower()}_web"
                    };
                    await _airshipService.AddCustomEvent(customEventsRequest);
                }
                return PartialView("~/Views/Partials/_CountryLandingPage.cshtml", model);
            }

            catch (Exception ex)
            {

                _logger.Error($"Class: LandingPagesController, Method: CountryLandingPage, " +
                                      $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                      $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("GetCountryBundleInfo")]
        public async Task<IActionResult> GetCountryBundleInfo(string fromCountryCode, string toCountrycode)
        {
            var model = new CountryBundleInfoModel();

            var BundlesCountries = await _bundleService.GetBundlesCountries(User);
            if (BundlesCountries.Any(x => x.ISO_Code.Equals(fromCountryCode)))
            {
                model.Bundles = (await _bundleService.GetBundleByDestinationCountry(
                         BundlesCountries.First(x => x.ISO_Code.Equals(fromCountryCode)).Na_Service_Id,
                         fromCountryCode,
                         toCountrycode,
                         null,
                         User)).ToList();
                model.Bundles = model.Bundles.Where(x => x.BundleType == BundleType.Welcome).ToList();
            }

            var payload = await _ratesService.GetRates(fromCountryCode, User);

            if (payload.Count > 0)
            {
                payload = payload.OrderBy(x => x.Destination).ToList();
                model.CountryRates = payload.Where(r => r.ISO2Code.Equals(toCountrycode, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();
            }
            if (model.CountryRates == null)
            {
                return RedirectToAction("Error", "Home", new { statuscode = 404 });
            }
            var topupuAmount = _topupConfig.Value.TopUpAmounts;
            foreach (var item in topupuAmount)
            {
                model.Topups.Add(new LandingPageModel.Topup
                {
                    Minutes = (int)Math.Round(item * 100 / (model.CountryRates?.Mobile > 0 ? model.CountryRates.Mobile : model.CountryRates.Landline)),
                    Price = item
                });
            }

            model.CountryContent.CountryName = _helperService.GetCountryNameByCountryCode(fromCountryCode);

            var CurrencyJson = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountryCurrency.json");
            var _countriesCurrency = JsonConvert.DeserializeObject<AllCurrenciesModel>(CurrencyJson);
            var currentCurrency = _countriesCurrency.Currencies.Where(x => x.ContainsKey(fromCountryCode)).FirstOrDefault();
            if (currentCurrency != null)
            {
                model.CurrentCurreny = CommonExtentionMethods.GetCurrencyUnit(currentCurrency[fromCountryCode]);
                model.MinorCurrencyunit = model.CurrentCurreny.GetMinorCurrencyUnit();
                model.CurrencySymbol = model.CurrentCurreny.GetCurrencySymbol();
            }
            else
            {
                model.CurrentCurreny = "USD";
                model.MinorCurrencyunit = model.CurrentCurreny.GetMinorCurrencyUnit();
                model.CurrencySymbol = model.CurrentCurreny.GetCurrencySymbol();
            }

            return Json(model);
        }

        [HttpGet]
        [Route("calling-rates")]
        public IActionResult Rates_old()
        {
            return RedirectToActionPermanent("Rates");
        }
        [HttpGet]
        [Route("rates")]
        public async Task<IActionResult> Rates()
        {
            try
            {
                string countryCode = "";

                if (User.Identity.IsAuthenticated)
                {
                    countryCode = User.Claims.Where(x => x.Type == "iso_two_country").FirstOrDefault().Value;
                }
                else
                {
                    var geoLocation = await _geoService.GetGeoInfo(HttpContext);

                    //_logger.Information($"Class: HomeController, Method: Rates, GeoLocation: {JsonConvert.SerializeObject(geoLocation)}");

                    countryCode = geoLocation != null && !string.IsNullOrEmpty(geoLocation.CountryCode) ? geoLocation.CountryCode.ToUpper() : "GB";
                }

                List<Rates> payload = await _ratesService.GetRates(countryCode, User);

                if (payload.Count > 0)
                {
                    payload = payload.OrderBy(x => x.Destination).ToList();
                }

                string currency = "";

                if (User.Identity.IsAuthenticated)
                {
                    currency = CommonExtentionMethods.GetMinorCurrencyUnit(
                                                                User.Claims.Where(x => x.Type == "currency").First().Value);
                }
                else
                {
                    var json = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountryCurrency.json");
                    var _countriesCurrency = JsonConvert.DeserializeObject<AllCurrenciesModel>(json);

                    if (!string.IsNullOrEmpty(countryCode))
                    {
                        var currentCountry = _countriesCurrency.Currencies.Where(x => x.ContainsKey(countryCode)).FirstOrDefault();

                        if (currentCountry != null)
                        {
                            currency = CommonExtentionMethods.GetMinorCurrencyUnit(currentCountry[countryCode]);
                        }
                        else
                        {
                            currency = "c";
                        }
                    }
                    else
                    {
                        currency = "c";
                    }
                }

                if (User.Identity.IsAuthenticated)
                {
                    #region Airship
                    if (_airshipService.IsActive)
                    {
                        string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                        //events
                        var customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = "view_rates_web"
                        };
                        await _airshipService.AddCustomEvent(customEventsRequest);
                    }
                    #endregion
                }
                return View(new RatesViewModel() { Rates = payload, MinorCurrencyunit = currency });

            }
            catch (Exception ex)
            {

                _logger.Error($"Class: HomeController, Method: Rates, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }
        [HttpGet]
        [Route("download-app")]
        public IActionResult DownloadApp_old()
        {
            return RedirectToActionPermanent("DownloadApp");
        }
        [HttpGet]
        [Route("download")]
        public IActionResult DownloadApp()
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    #region Airship
                    if (_airshipService.IsActive)
                    {
                        string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                        //events
                        var customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = "view_down_web"
                        };
                        _airshipService.AddCustomEvent(customEventsRequest);
                    }
                    #endregion
                }
                return View();
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: DownloadApp, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }
        [HttpPost]
        [Route("quick-topup")]
        public async Task<IActionResult> QuickTopup(int TopupAmount, string TopupMsisdn)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    #region Airship
                    if (_airshipService.IsActive)
                    {
                        string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                        //events
                        var customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = "clicked_quick_topup_web"
                        };
                        await _airshipService.AddCustomEvent(customEventsRequest);
                    }
                    #endregion
                }
                CheckOutViewModel model = new CheckOutViewModel
                {
                    TopupAmount = TopupAmount,
                    Msisdn = TopupMsisdn
                };

                string authToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").
                                        GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                //get user account details
                var response = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                "Account/GetAccountDetailsByMsisdn", User, ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "Msisdn=" + TopupMsisdn }, basicauthtoken: authToken);

                if (response.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = accountResponseJson.GetValue("payload").ToObject<GetAccountDetailsByMsisdnResponseModel>();

                        model.UserAccount = new UserAccountDetails()
                        {
                            BalanceCurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(payload.Currency)
                        };

                        model.EmailAddress = payload.EmailAddress;
                    }
                    else
                    {
                        return RedirectToAction("ErrorMessage", new { key = "InvalidMsisdn" });
                    }
                }
                else
                {
                    throw new Exception("Quick Topup - Error while getting data from API (GetAccountDetailsByMsisdn): StatusCode" + response.StatusCode);
                }


                //Get Countries List
                var json = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json");
                var _countries = JsonConvert.DeserializeObject<CountriesResponseModel>(json);
                model.ListOfCountries = _countries;

                model.CheckoutType = CheckOutTypes.FastTopup;

                if (User.Identity.IsAuthenticated)
                {
                    //Get Account Details
                    var accountResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                       "Account/GetAccountDetails", User, ApiCallType.Bearer, GetRequest: true);

                    if (accountResponse.IsSuccessStatusCode)
                    {
                        var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                        int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                        if (errorCode == 0)
                        {
                            var payload = accountResponseJson.GetValue("payload").ToObject<GetAccountDetailsResponseModel>();
                            model.UserAccount.AccountBalance = payload.Balance;
                            model.EmailAddress = !string.IsNullOrEmpty(payload.Email) ? payload.Email : "";
                            model.IsEmailVerified = payload.IsEmailVerified;
                        }
                        else
                        {
                            throw new Exception("Quick Topup - Error while getting data from API(GetAccountDetails): ErrorCode" + errorCode);
                        }
                    }
                    else if (accountResponse.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                    }
                    else
                    {
                        throw new Exception("Quick Topup - Error while getting data from API(GetAccountDetails): StatusCode" + accountResponse.StatusCode);
                    }


                    //Get User Cards
                    var cardsResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                    "Payment/GetCustomerCards", User, ApiCallType.Bearer, GetRequest: true);

                    if (cardsResponse.IsSuccessStatusCode)
                    {
                        var cardsResponseJson = JObject.Parse(cardsResponse.Content.ReadAsStringAsync().Result);
                        int errorCode = cardsResponseJson.GetValue("errorCode").ToObject<int>();

                        if (errorCode == 0)
                        {
                            var payload = cardsResponseJson.GetValue("payload").ToObject<Pay360CardsData>();
                            if (payload != null && payload.paymentMethodResponses.Count > 0)
                            {
                                payload.paymentMethodResponses = payload.paymentMethodResponses.OrderByDescending(x => x.isPrimary).ToList();
                            }
                            model.UserCards = payload;
                        }
                    }
                    else if (cardsResponse.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                    }
                    else
                    {
                        throw new Exception("Quick Topup - Error while getting data from API(GetCustomerCards): StatusCode" + cardsResponse.StatusCode);
                    }
                }

                //Get user promotions
                var promoResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                "Promotions/GetAccountPromotions", User, ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "msisdn=" + TopupMsisdn }, basicauthtoken: authToken);

                if (promoResponse.IsSuccessStatusCode)
                {
                    var promoResponseJson = JObject.Parse(promoResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = promoResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var promoData = promoResponseJson.GetValue("payload").ToObject<GetPromotionsResponseModel>();
                        if (promoData != null)
                        {
                            model.PromotionsDetails = promoData.PromotionsDetails;
                        }
                    }
                }
                else if (promoResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("Quick Topup promotions - Error while getting data from API(GetAccountPromotions): StatusCode" + promoResponse.StatusCode);
                }


                if (User.Identity.IsAuthenticated)
                {
                    var userNumber = User.Claims.First(i => i.Type == "phone_number").Value;
                    if (model.Msisdn.Equals(userNumber))
                    {
                        var autoTopUpResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                "Payment/GetAutoTopupSettings", User, ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "msisdn=" + TopupMsisdn }, basicauthtoken: authToken);

                        if (autoTopUpResponse.IsSuccessStatusCode)
                        {
                            var autoTopupresponseJson = JObject.Parse(autoTopUpResponse.Content.ReadAsStringAsync().Result);
                            int errorCode = autoTopupresponseJson.GetValue("errorCode").ToObject<int>();

                            if (errorCode == 0)
                            {
                                var responseModel = autoTopupresponseJson.GetValue("payload").ToObject<GetAutoTopUpResponse>();
                                if (responseModel != null)
                                {
                                    model.AutoToupThreshold = responseModel.ThresHold;
                                    model.ShowAutoTopup = true;
                                }
                            }
                        }
                        else if (autoTopUpResponse.StatusCode == HttpStatusCode.Unauthorized)
                        {
                            return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                        }
                        else
                        {
                            throw new Exception("Quick Topup GetAutoTopupSettings - Error while getting data from API(GetAutoTopupSettings): StatusCode" + autoTopUpResponse.StatusCode);
                        }
                    }
                }
                return View("~/Views/Home/Topup.cshtml", model);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: Quick Topup, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [HttpGet]
        [Route("account-top-up")]
        [Authorize]
        public async Task<IActionResult> Topup(int amount, string country = null)
        {
            try
            {
                var model = new CheckOutViewModel
                {
                    ShowAutoTopup = true
                };

                string authToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").
                        GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                //Get Countries List
                var json = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json");
                var _countries = JsonConvert.DeserializeObject<CountriesResponseModel>(json);
                model.ListOfCountries = _countries;
                model.TopupAmount = amount;
                model.CheckoutType = CheckOutTypes.TopUp;

                //Get Account Details
                var accountResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                   "Account/GetAccountDetails", User, ApiCallType.Bearer, GetRequest: true);

                if (accountResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = accountResponseJson.GetValue("payload").ToObject<GetAccountDetailsResponseModel>();
                        model.UserAccount = new UserAccountDetails()
                        {
                            AccountBalance = payload.Balance,
                            BalanceCurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(
                                        User.Claims.Where(x => x.Type == "currency").FirstOrDefault().Value)
                        };

                        model.EmailAddress = !string.IsNullOrEmpty(payload.Email) ? payload.Email : "";
                        model.IsEmailVerified = payload.IsEmailVerified;
                    }
                    else
                    {
                        throw new Exception("Topup - Error while getting data from API: ErrorCode" + errorCode);
                    }
                }
                else if (accountResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("Topup - Error while getting data from API: StatusCode" + accountResponse.StatusCode);
                }


                //Get User Cards
                var cardsResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                "Payment/GetCustomerCards", User, ApiCallType.Bearer, GetRequest: true);

                if (cardsResponse.IsSuccessStatusCode)
                {
                    var cardsResponseJson = JObject.Parse(cardsResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = cardsResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = cardsResponseJson.GetValue("payload").ToObject<Pay360CardsData>();
                        if (payload != null && payload.paymentMethodResponses.Count > 0)
                        {
                            payload.paymentMethodResponses = payload.paymentMethodResponses.OrderByDescending(x => x.isPrimary).ToList();
                        }
                        model.UserCards = payload;
                    }
                }
                else if (cardsResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("Topup - Error while getting data from API: StatusCode" + cardsResponse.StatusCode);
                }

                //Get user promotions
                var promoResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                                "Promotions/GetAccountPromotions", User, ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "msisdn=" + User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value }, basicauthtoken: authToken);

                if (promoResponse.IsSuccessStatusCode)
                {
                    var promoResponseJson = JObject.Parse(promoResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = promoResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var promoData = promoResponseJson.GetValue("payload").ToObject<GetPromotionsResponseModel>();
                        if (promoData != null)
                        {
                            model.PromotionsDetails = promoData.PromotionsDetails;
                        }
                    }
                }
                else if (promoResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("Quick Topup promotions - Error while getting data from API: StatusCode" + promoResponse.StatusCode);
                }


                var autoTopUpResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                        "Payment/GetAutoTopup", User, ApiCallType.Bearer, GetRequest: true);

                if (autoTopUpResponse.IsSuccessStatusCode)
                {
                    var autoTopupresponseJson = JObject.Parse(autoTopUpResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = autoTopupresponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var responseModel = autoTopupresponseJson.GetValue("payload").ToObject<GetAutoTopUpResponse>();
                        if (responseModel != null)
                        {
                            model.AutoToupThreshold = responseModel.ThresHold;
                        }
                    }
                }
                else if (autoTopUpResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("Quick Topup GetAutoTopupSettings - Error while getting data from API: StatusCode" + autoTopUpResponse.StatusCode);
                }

                #region Airship
                try
                {
                    string namedUserId = "";
                    namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                    if (_airshipService.IsActive)
                    {
#pragma warning disable CS4014

                        //events
                        //var customEventsRequest = new CustomEventsRequest()
                        //{
                        //    ProductCode = "THA",
                        //    ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        //    ChannelIdentifierValue = namedUserId,
                        //    CustomEventName = "checkout_topup"
                        //};
                        //_airshipService.AddCustomEvent(customEventsRequest);
                        if (string.IsNullOrEmpty(country))
                        {
                            var customEventsRequest = new CustomEventsRequest()
                            {
                                ProductCode = "THA",
                                ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                ChannelIdentifierValue = namedUserId,
                                CustomEventName = "view_topup_web"
                            };
                            _airshipService.AddCustomEvent(customEventsRequest);

                        }
                        else
                        {
                            var customEventsRequest = new CustomEventsRequest()
                            {
                                ProductCode = "THA",
                                ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                ChannelIdentifierValue = namedUserId,
                                CustomEventName = $"clicked_topup_{country.ToLower()}_web"
                            };
                            _airshipService.AddCustomEvent(customEventsRequest);



                        }


                        //tags
                        _airshipService.AddNamedUserTags(new NamedUserTagsRequest()
                        {
                            NamedUser = namedUserId,
                            ProductCode = "THA",
                            TagGroup = _airshipService.CustomerTagGroupName,
                            Tags = new List<string>() { "checkout_topup" }
                        });


#pragma warning restore CS4014
                    }
                    if (_facebookService.IsActive)
                    {
                        await _facebookService.CreateCustomEvent(namedUserId, new EventDetailsModel
                        {
                            _eventName = $"view_topup_web"
                        });
                    }

                    if (_appsFlyerService.IsActive)
                    {
                        await _appsFlyerService.CreateEvent(namedUserId, "view_topup_web", CommonExtentionMethods.GetRemoteIPAddress(HttpContext));
                    }

                }
                catch
                {

                }
                #endregion

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: Topup, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [HttpGet]
        [Route("bundle-purchase")]
        [Authorize]
        public async Task<IActionResult> BundlePurchase(string data)
        {
            try
            {
                if (string.IsNullOrEmpty(data)) { return BadRequest(); };

                string decryptedData;

                try
                {
                    data = HttpUtility.UrlDecode(data);

                    decryptedData = _dataProtector.Unprotect(data);
                }
                catch
                {
                    return BadRequest();
                }

                if (string.IsNullOrEmpty(decryptedData))
                    return BadRequest();

                var bundleInfo = decryptedData.Split("--");

                CheckOutViewModel model = new CheckOutViewModel();

                model.CheckoutType = CheckOutTypes.Bundle;

                //Get BundleDetails
                var BundlesList = new List<Bundles>() { };
                string token = Convert.ToBase64String(Encoding.
                   GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                //Check whether user is eligble for bundle or not
                var isValidToPurchaseResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Bundles/ValidateBundlePurchase/" + bundleInfo[2], User, ApiCallType.Bearer, GetRequest: false);

                if (isValidToPurchaseResponse.IsSuccessStatusCode)
                {
                    var isValidToPurchaseJson = JObject.Parse(await isValidToPurchaseResponse.Content.ReadAsStringAsync());
                    var isValidToPurchaseErrorCode = isValidToPurchaseJson.GetValue("errorCode").ToObject<int>();
                    if (isValidToPurchaseErrorCode > 0)
                    {
                        return Redirect("/bundles");
                    }
                }
                else if (isValidToPurchaseResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("BundlePurchase-isValidToPurchaseResponse - Error while getting data from API: StatusCode" + isValidToPurchaseResponse.StatusCode);
                }

                var bundlesResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Bundles/GetBundleByCountry", User,
                    ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "ServiceId=" + (User.Identity.IsAuthenticated ? User.Claims.Where(x => x.Type == "service_id").FirstOrDefault().Value : bundleInfo[1]) }, basicauthtoken: token);

                if (bundlesResponse.IsSuccessStatusCode)
                {
                    var BundleResponse = await bundlesResponse.Content.ReadAsStringAsync();
                    BundlesList = JsonConvert.DeserializeObject<IEnumerable<Bundles>>(BundleResponse).ToList();

                    if (BundlesList.Count == 0)
                    {
                        TempData["bundle-not-found"] = "Selected bundle is not available for your country";
                        return RedirectToAction("Bundles", "Home");
                    }

                    if (!BundlesList.Any(x => x.ID.ToString().Equals(bundleInfo[2])))
                    {
                        TempData["bundle-not-found"] = "Selected bundle is not available for your country";
                        return RedirectToAction("Bundles", "Home");
                    }
                }
                else if (bundlesResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("BundlePurchase-bundlesResponse - Error while getting data from API: StatusCode" + bundlesResponse.StatusCode);
                }

                //Get Countries List
                var json = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json");
                var _countries = JsonConvert.DeserializeObject<CountriesResponseModel>(json);
                model.ListOfCountries = _countries;

                //Get Bundles and countries data
                string ToCountryIsoCode = BundlesList.Where(x => x.ID.ToString().Equals(bundleInfo[2])).Select(x => x.Description.Replace(",", "")).First();

                model.Bundle = new BundleDetails()
                {
                    FromCountryName = _countries.countries.Where(x => x.IsoTwoCharacterCode.Equals(bundleInfo[0])).Select(x => x.Name).First(),
                    ToCountryName = _countries.countries.Where(x => x.IsoTwoCharacterCode.Equals(ToCountryIsoCode)).Select(x => x.Name).First(),
                    FromCountryISOCode = bundleInfo[0],
                    ToCountryISOCode = ToCountryIsoCode,
                    Minutes = BundlesList.Where(x => x.ID.ToString().Equals(bundleInfo[2])).Select(x => x.Minutes).First().ToString(),
                    Amount = BundlesList.Where(x => x.ID.ToString().Equals(bundleInfo[2])).Select(x => x.TotalCostPence / 100).First().ToString(),
                    BundleId = bundleInfo[2],
                    BundleCategory = BundlesList.Where(x => x.ID.ToString().Equals(bundleInfo[2])).Select(x => x.BundleCategory).First(),
                    Name = BundlesList.Where(x => x.ID.ToString().Equals(bundleInfo[2])).Select(x => x.BrandedName).First(),
                    BundleType = BundlesList.Where(x => x.ID.ToString().Equals(bundleInfo[2])).Select(x => x.BundleType).First(),
                    OffPercentage = BundlesList.Where(x => x.ID.ToString().Equals(bundleInfo[2])).Select(x => x.OffPercentage).First().ToString(),
                };

                //Get Account Details
                var accountResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                "Account/GetAccountDetails", User, ApiCallType.Bearer, GetRequest: true);

                if (accountResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = accountResponseJson.GetValue("payload").ToObject<GetAccountDetailsResponseModel>();
                        model.UserAccount = new UserAccountDetails()
                        {
                            AccountBalance = payload.Balance,
                            BalanceCurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(
                                    User.Claims.Where(x => x.Type == "currency").FirstOrDefault().Value)
                        };

                        model.EmailAddress = !string.IsNullOrEmpty(payload.Email) ? payload.Email : "";
                        model.IsEmailVerified = payload.IsEmailVerified;
                    }
                    else
                    {
                        throw new Exception("BundlePurchase - Error while getting data from API: Error Code " + errorCode);
                    }
                }
                else if (accountResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("BundlePurchase - Error while getting data from API: Status Code " + accountResponse.StatusCode);
                }

                //Get User Cards
                var cardsResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                                "Payment/GetCustomerCards", User, ApiCallType.Bearer, GetRequest: true);

                if (cardsResponse.IsSuccessStatusCode)
                {
                    var cardsResponseJson = JObject.Parse(cardsResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = cardsResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var payload = cardsResponseJson.GetValue("payload").ToObject<Pay360CardsData>();
                        if (payload != null && payload.paymentMethodResponses.Count > 0)
                        {
                            payload.paymentMethodResponses = payload.paymentMethodResponses.OrderByDescending(x => x.isPrimary).ToList();
                        }
                        model.UserCards = payload;
                    }
                }
                else if (cardsResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("BundlePurchase - Error while getting data from API: Status Code " + cardsResponse.StatusCode);
                }

                #region Airship
                try
                {
                    if (_airshipService.IsActive)
                    {
                        string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
#pragma warning disable CS4014

                        //events
                        var customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = "checkout_bundle_web"
                        };
                        _airshipService.AddCustomEvent(customEventsRequest);

                        var customEventsRequest1 = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = $"clicked_buybundle_{model.UserAccount.BalanceCurrencySymbol}{model.Bundle.Amount}{model.Bundle.FromCountryISOCode.ToLower()}_web"
                        };
                        _airshipService.AddCustomEvent(customEventsRequest1);


#pragma warning restore CS4014
                    }
                }
                catch
                {

                }
                #endregion


                return View("~/Views/Home/Topup.cshtml", model);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: Topup, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("VoucherRecharge")]
        public async Task<IActionResult> VoucherRecharge(VoucherRechargeRequest model)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    if (string.IsNullOrEmpty(model.Msisdn))
                    {
                        ModelState.Remove("Msisdn");
                        model.Msisdn = User.Claims.First(i => i.Type == "phone_number").Value;
                    }
                }

                String encodedToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var response = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint + "Payment/VoucherRecharge",
                    User, ApiCallType.BasicAuth, model: new VoucherRequestModel()
                    {
                        Pin = model.VoucherCode,
                        IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext),
                        Msisdn = model.Msisdn
                    }, basicauthtoken: encodedToken);


                if (response.IsSuccessStatusCode)
                {
                    var result = JObject.Parse(response.Content.ReadAsStringAsync().Result);

                    var errorCode = result.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var voucherRechargeData = result.GetValue("payload").ToObject<VoucherRechargeResponseModel>();

                        TempData.Put("VoucherRechargeInfo", voucherRechargeData);

                        return RedirectToAction("SuccessMessage", "Home", new { key = "voucherrechargesuccessful" });
                    }
                    else
                    {
                        TempData.Put("Voucher-Recharge-Error", result.GetValue("message").ToObject<string>());

                        //return RedirectToAction("ErrorMessage", new { key = "voucherrechargefailed" });
                        TempData.Add<string>("Key", "voucherrechargefailed");
                        return RedirectToAction("TopupError", "Home", new TopupTransactionModel
                        {
                            From = model.Msisdn,
                            AutoTopup = false,
                            //Origin=_helperService.GetCountryCode(User.PhoneNumber()),
                            Payment = PaymentMethodTypes.Voucher.ToString(),
                            Amount = "",
                            Id = model.VoucherCode
                        });
                    }
                }
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("VoucherRecharge - Error while getting data from API: Status Code " + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: VoucherRecharge, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [HttpGet]
        [Route("mobile-top-up/send")]
        public IActionResult SendCredit(string data, string country, string msisdn, string currency, string product)
        {
            if (!string.IsNullOrEmpty(msisdn) && !string.IsNullOrEmpty(product))
            {
                ViewBag.PageTitle = "Let's enter your payment details";
            }
            else
            {
                ViewBag.PageTitle = "Send Mobile Credit Worldwide";
            }

            if (country != null && country.Contains(' ', StringComparison.InvariantCultureIgnoreCase))
                return RedirectToActionPermanent("SendCredit", "Home", new
                {
                    data = data,
                    country = country.Replace(' ', '-'),
                    msisdn = msisdn,
                    currency = currency,
                    product = product
                });
            CountryModel currentCountry = null;

            if (!string.IsNullOrEmpty(country))
            {
                var _countries = JsonConvert.DeserializeObject<CountriesModel>(System.IO.File.ReadAllText(
                                                _hostEnvironment.ContentRootPath + "/wwwroot/json/CountriesName.json"));
                currentCountry = _countries.countries.Where(x => x.Name.Equals(country, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
            }
            if (!string.IsNullOrEmpty(data) && currentCountry == null)
            {
                try
                {
                    var Key = HttpUtility.UrlDecode(data);
                    string decryptedData;

                    decryptedData = _dataProtector.Unprotect(Key);

                    if (string.IsNullOrEmpty(decryptedData))
                        return RedirectToAction("SendCredit", "Home");

                    data = decryptedData.StartsWith("+") ? decryptedData : "+" + decryptedData;
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: HomeController, Method: SendCredit," +
                        $" ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");

                    return RedirectToAction("SendCredit", "Home");
                }
            }
            if (!string.IsNullOrEmpty(msisdn))
            {
                try
                {
                    data = msisdn.StartsWith("+") ? msisdn.Trim() : $"+{msisdn.Trim()}";
                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: HomeController, Method: SendCredit," +
                        $" ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");

                    return RedirectToAction("SendCredit", "Home");
                }
            }
            #region Airship
            try
            {
                if (_airshipService.IsActive && User.Identity.IsAuthenticated)
                {
                    var namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;

#pragma warning disable CS4014

                    //events
                    var customEventsRequest = new CustomEventsRequest()
                    {
                        ProductCode = "THA",
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = namedUserId,
                        CustomEventName = "checkout_int_topup"
                    };
                    //_airshipService.AddCustomEvent(customEventsRequest);
                    if (string.IsNullOrEmpty(country))
                    {
                        customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = "view_inttop_web"
                        };
                        _airshipService.AddCustomEvent(customEventsRequest);
                    }
                    else
                    {
                        customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = $"clicked_inttop_{country.ToLower()}_web"
                        };
                        _airshipService.AddCustomEvent(customEventsRequest);
                    }

                    customEventsRequest = new CustomEventsRequest()
                    {
                        ProductCode = "THA",
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = namedUserId,
                        CustomEventName = "view_sendcredit_web"
                    };
                    _airshipService.AddCustomEvent(customEventsRequest);

                    //events



                    //tags
                    _airshipService.AddNamedUserTags(new NamedUserTagsRequest()
                    {
                        NamedUser = namedUserId,
                        ProductCode = "THA",
                        TagGroup = _airshipService.CustomerTagGroupName,
                        Tags = new List<string>() { "checkout_int_topup" }
                    });
#pragma warning restore CS4014
                }
            }
            catch
            {

            }
            #endregion

            //_facebookService.CreateCustomEvent(msisdn, new EventDetailsModel
            //{
            //    _eventName = $"view_offers_{currentCountry.IsoTwoCharacterCode.ToLower()}_web",
            //});

            ModelState.Clear();
            return View(new SendCreditViewModel() { TransferPhoneNumber = data, twoLetterCountryCode = currentCountry != null ? currentCountry.IsoTwoCharacterCode : null, SelectedProductId = product, Currency = currency });
        }

        [HttpGet]
        [Route("account-summary")]
        [Authorize]
        public async Task<IActionResult> AccountSummary()
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {                   
                    var apiResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                        "Account/IsAccountDeleteRequestInProgress", User, ApiCallType.Bearer);

                    if (apiResponse.IsSuccessStatusCode)
                    {
                        var responseJson = JObject.Parse(apiResponse.Content.ReadAsStringAsync().Result);
                        int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                        bool isDeleteRequestInProgress = responseJson.GetValue("payload").ToObject<bool>();
                        if (errorCode == 0 && isDeleteRequestInProgress)
                        {
                            await HttpContext.SignOutAsync();
                            return RedirectToAction("Index", "Home");
                        }

                    }
                    else if (apiResponse.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                    }
                    else
                    {
                        throw new Exception("AccountSummary - Error while getting data from API: StatusCode" + apiResponse.StatusCode);
                    }

                    #region Airship
                    if (_airshipService.IsActive)
                    {
                        string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                        //events
                        var customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = "view_acc_summary_web"
                        };
                        _airshipService.AddCustomEvent(customEventsRequest);
                    }
                    #endregion
                }
                return View(new AccountSummaryViewModel()
                {
                    UserCurrencySymbol = CommonExtentionMethods.GetCurrencySymbol(
                        User.Claims.Where(x => x.Type == "currency").First().Value)
                });
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: AccountSummary, " +
                              $"ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                              $"StackTrace: {ex.StackTrace}");
                return StatusCode(500);
            }
        }


        [HttpGet]
        [Route("account-details")]
        [Authorize]
        public async Task<IActionResult> AccountDetails()
        {
            try
            {                

                var apiResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                    "Account/IsAccountDeleteRequestInProgress", User, ApiCallType.Bearer);

                if (apiResponse.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(apiResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                    bool isDeleteRequestInProgress = responseJson.GetValue("payload").ToObject<bool>();
                    if (errorCode == 0 && isDeleteRequestInProgress)
                    {
                        await HttpContext.SignOutAsync();
                        return RedirectToAction("Index", "Home");
                    }

                }
                else if (apiResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    throw new Exception("AccountDetails - Error while getting data from API: StatusCode" + apiResponse.StatusCode);
                }

                //Get Account Details
                var accountResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                    "Account/GetAccountDetails", User, ApiCallType.Bearer, GetRequest: true);

                if (accountResponse.IsSuccessStatusCode)
                {
                    var accountResponseJson = JObject.Parse(accountResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var response = accountResponseJson.GetValue("payload").ToObject<GetAccountDetailsResponseModel>();

                        var viewModel = new AccountDetailsViewModel()
                        {
                            Email = response.Email,
                            FirstName = response.FirstName,
                            LastName = response.LastName,
                            EmailSubscription = response.EmailSubscription,
                            IsEmailVerified = response.IsEmailVerified,
                            Pin = CommonExtentionMethods.DecryptString("b14ca5898a4e4133bbce2ea2315a1916", response.Pin),
                            DayOfBirth = response.DayOfBirth,
                            MonthOfBirth = response.MonthOfBirth
                        };

                        if (response.DayOfBirth != null && response.MonthOfBirth != null)
                        {
                            var dates = Enumerable.Range(1, DateTime.DaysInMonth(2020, (int)response.MonthOfBirth))
                                                  .Select(day => new DateTime(2020, (int)response.MonthOfBirth, day)) // Map each day to a date
                                                  .ToList(); // Load dates into a list

                            viewModel.DatesList = dates.Select(item => new SelectListItem()
                            {
                                Text = item.Day.ToString(),
                                Value = item.Day.ToString()
                            }).ToList();

                            if (response.MonthOfBirth == 2) //feb
                            {
                                if (!viewModel.DatesList.Any(x => x.Text == "29"))
                                {
                                    viewModel.DatesList.Add(new SelectListItem() { Text = "29", Value = "29" });
                                }
                            }
                        }
                        if (User.Identity.IsAuthenticated)
                        {
                            #region Airship
                            if (_airshipService.IsActive)
                            {
                                string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                                //events
                                var customEventsRequest = new CustomEventsRequest()
                                {
                                    ProductCode = "THA",
                                    ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                                    ChannelIdentifierValue = namedUserId,
                                    CustomEventName = "view_acc_detail_web"
                                };
                                await _airshipService.AddCustomEvent(customEventsRequest);
                            }
                            #endregion
                        }

                        return View(viewModel);
                    }
                    else
                    {
                        return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                    }
                }
                else if (accountResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: AccountDetails, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [Route("error/system/{statuscode}")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error(int statuscode)
        {
            var exceptionHandlerPathFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            if (exceptionHandlerPathFeature != null)
                _logger.Error($"Class: HomeController, Method: Error, Data: {JsonConvert.SerializeObject(exceptionHandlerPathFeature.Error.Message)}");

            var model = new ErrorViewModel();
            model.StatudCode = statuscode;

            switch (statuscode)
            {
                case 404:
                    return RedirectToAction("PageNotFound", "Home");
                case 401:
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                case 500:
                    model.Message = "We’re sorry, something went wrong on server, please go back to our homepage.";
                    break;
                default:
                    model.Message = "We’re sorry, something went wrong on server, please go back to our homepage.";
                    break;
            }

            return View(model);
        }

        [Route("error/{key}")]
        public IActionResult ErrorMessage(string key)
        {
            if (string.IsNullOrEmpty(key)) { return NotFound(); }

            return View(new TransactionErrorViewModel() { Key = key });
        }

        [Route("success/{key}")]
        public IActionResult SuccessMessage(string key)
        {
            if (string.IsNullOrEmpty(key)) { return NotFound(); }

            if (key == "bundlepurchasesuccessful" && !TempData.ContainsKey("BundlePurchaseInfo"))
            {
                return RedirectToAction("Index");
            }

            if (key == "topupsuccessful" && !TempData.ContainsKey("TopupInfo"))
            {
                return RedirectToAction("Index");
            }

            if (key == "voucherrechargesuccessful" && !TempData.ContainsKey("VoucherRechargeInfo"))
            {
                return RedirectToAction("Index");
            }

            if (key == "transfersuccessful" &&
                !(TempData.ContainsKey("AB-Transfer-Data")
                || TempData.ContainsKey("PP-Transfer-Data")
                || TempData.ContainsKey("Card-Transfer-Data")))
            {
                return RedirectToAction("Index");
            }

            //return View(new SuccessMessageViewModel() { Key = key, PaymentMethod = TempData.Get<string>("PaymentMethod") });
            switch (key)
            {
                case "bundlepurchasesuccessful":
                    var data = TempData.Get<BundlePurchaseInfo>("BundlePurchaseInfo");
                    return RedirectToAction(nameof(BundleSuccess), new BundleTransactionModel
                    {
                        Amount = data.BundleAmount,
                        AutoRenew = data.AutoRenew,
                        Bundle = data.BundleName.Replace(' ', '-'),
                        Destination = data.destination,
                        From = data.Msisdn,
                        Origin = data.origination,
                        Payment = data.PaymentMethod.ToString(),
                        Type = data.BundleType.ToString(),
                        Id = data.TransactionId
                    });
                case "topupsuccessful":
                    var topupInfo = TempData.Get<TopupInfo>("TopupInfo");
                    return RedirectToAction(nameof(TopupSuccess), new TopupTransactionModel
                    {
                        Amount = topupInfo.TopupAmount,
                        //Origin = topupInfo.origination,
                        From = topupInfo.Msisdn,
                        Payment = topupInfo.PaymentMethod.ToString(),
                        AutoTopup = topupInfo.AutoTopup,
                        Id = topupInfo.TransactionId
                    });
                case "transfersuccessful":
                    var transferData = new TransferData();

                    if (TempData.ContainsKey("AB-Transfer-Data"))
                    {
                        transferData = TempData.Get<TransferByAccountBalanceResponseModel>("AB-Transfer-Data").TransferData;
                    }

                    if (TempData.ContainsKey("PP-Transfer-Data"))
                    {
                        transferData = TempData.Get<TransferData>("PP-Transfer-Data");
                    }

                    if (TempData.ContainsKey("Card-Transfer-Data"))
                    {
                        transferData = TempData.Get<TransferData>("Card-Transfer-Data");
                    }
                    return RedirectToAction("SendMobileTopupSuccess", "Home");
                /*return RedirectToAction(nameof(MobileTopupSuccess), new MobileTopupTransactionModel
                {
                    Amount = transferData.fromAmount,
                    Origin = transferData.fromCountry,
                    Destination = transferData.toCountry,
                    From = transferData.fromMsisdn,
                    To = transferData.toMsisdn,
                    Payment = transferData.PaymentMethod.ToString(),
                    Id = transferData.TransactionId,
                    Network = transferData.operatorName.Replace(' ', '-')
                });*/
                case "voucherrechargesuccessful":
                    var voucherRechard = TempData.Get<VoucherRechargeResponseModel>("VoucherRechargeInfo");
                    var topupVoucher = new TopupInfo
                    {
                        AutoTopup = false,
                        Msisdn = voucherRechard.customerMsisdn,
                        Currency = voucherRechard.voucher_currency,
                        origination = voucherRechard.origin,
                        PaymentMethod = PaymentMethodTypes.Voucher,
                        shouldSave = false,
                        TopupAmount = voucherRechard.card_credit.ToString(),
                        TransactionId = voucherRechard.voucher_id.ToString()
                    };
                    TempData.Put("TopupInfo", topupVoucher);
                    return RedirectToAction(nameof(TopupSuccess), new TopupTransactionModel
                    {
                        Amount = voucherRechard.card_credit.ToString(),
                        Payment = PaymentMethodTypes.Voucher.ToString(),
                        Origin = voucherRechard.origin,
                        From = voucherRechard.customerMsisdn,
                        AutoTopup = false,
                    });
                default:
                    return View(new SuccessViewModel() { Key = key });
            }
        }
        [Route("SetAutoTopUp/success")]
        public IActionResult SetAutoTopupSuccess([FromQuery] SetAutoTopupTransactionModel request)
        {
            var model = new SetAutoTopupResultViewModel()
            {
                Key = "setautotopupsuccessful",
                SetAutoTopup = request
            };
            return View("SetAutoTopupResultMessage", model);
        }
        [Route("SetAutoRenewal/success")]
        public IActionResult SetAutoRenewalSuccess()
        {
            var model = new SetAutoRenewalResultViewModel()
            {
                Key = "setautorenewalsuccessful"
            };
            return View("SetAutoRenewalResultMessage", model);
        }
        [Route("top-up/success")]
        public IActionResult TopupSuccess([FromQuery] TopupTransactionModel request)
        {
            var model = new SuccessViewModel()
            {
                Key = "topupsuccessful",
                Topup = request
            };
            return View("SuccessMessage", model);
        }
        [Route("bundle/success")]
        public IActionResult BundleSuccess([FromQuery] BundleTransactionModel request)
        {
            var model = new SuccessViewModel()
            {
                Key = "bundlepurchasesuccessful",
                Bundle = request
            };
            return View("SuccessMessage", model);
        }
        [Route("mobile-top-up/success")]
        public IActionResult MobileTopupSuccess([FromQuery] MobileTopupTransactionModel request)
        {

            var model = new SuccessViewModel()
            {
                Key = "transfersuccessful",
                MobileTopup = request
            };
            return View("SuccessMessage", model);
        }
        [Route("top-up/error")]
        public IActionResult TopupError([FromQuery] TopupTransactionModel request)
        {
            var model = new TransactionErrorViewModel()
            {
                Key = TempData.Get<string>("Key"),
                CheckoutType = "topup",
                Topup = request
            };
            return View("ErrorMessage", model);
        }
        [Route("SetAutoTopup/error")]
        public IActionResult SetAutoTopupError([FromQuery] SetAutoTopupTransactionModel request)
        {
            var model = new SetAutoTopupResultViewModel()
            {
                Key = "setautotopuperror",
                SetAutoTopup = request
            };
            return View("SetAutoTopupResultMessage", model);
        }
        [Route("SetAutoRenewal/error")]
        public IActionResult SetAutoRenewalError()
        {
            var model = new SetAutoRenewalResultViewModel()
            {
                Key = "setautorenewalerror"
            };
            return View("SetAutoRenewalResultMessage", model);
        }
        [Route("bundle/error")]
        public IActionResult BundleError([FromQuery] BundleTransactionModel request)
        {
            var model = new TransactionErrorViewModel()
            {
                Key = TempData.Get<string>("Key"),
                CheckoutType = "bundle",
                Bundle = request
            };
            return View("ErrorMessage", model);
        }
        [Route("mobile-top-up/error")]
        public IActionResult MobileTopupError([FromQuery] MobileTopupTransactionModel request)
        {
            //request.Origin = _helperService.GetCountryCode(request.From);
            //request.Destination = _helperService.GetCountryCode(request.To);
            var model = new TransactionErrorViewModel()
            {
                Key = TempData.Get<string>("Key"),
                CheckoutType = "mobiletopup",
                MobileTopup = request
            };
            return RedirectToAction("SendMobileTopupError", "Home");
        }
        [Route("about-us")]
        public IActionResult AboutUs()
        {
            return View();
        }

        [Route("contact")]
        public IActionResult ContactUs()
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    #region Airship
                    if (_airshipService.IsActive)
                    {
                        string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                        //events
                        var customEventsRequest = new CustomEventsRequest()
                        {
                            ProductCode = "THA",
                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                            ChannelIdentifierValue = namedUserId,
                            CustomEventName = "view_help_web"
                        };
                        _airshipService.AddCustomEvent(customEventsRequest);
                    }
                    #endregion
                }

                return View();
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: ContactUs, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [Route("help/faqs")]
        public IActionResult FAQs()
        {

            try
            {
                //                if (User.Identity.IsAuthenticated)
                //                {
                //                    #region Airship
                //                    if (_airshipService.IsActive)
                //                    {
                //                        string namedUserId = User.Claims.Where(x => x.Type == ClaimTypes.NameIdentifier).First().Value;
                //#pragma warning disable CS4014
                //                        //events
                //                        var customEventsRequest = new CustomEventsRequest()
                //                        {
                //                            ProductCode = "THA",
                //                            ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                //                            ChannelIdentifierValue = namedUserId,
                //                            CustomEventName = "view_down_web"
                //                        };
                //                        _airshipService.AddCustomEvent(customEventsRequest);
                //                    }
                //                    #endregion
                //                }
                return View();
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: HomeController, Method: FAQs, ErrorMessage: " +
                    $"{(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw ex;
            }
        }

        [Route("how-it-works")]
        public IActionResult HowItWorks()
        {
            return View();
        }

        [Route("privacy-policy/{type?}")]
        [Route("privacy-policy")]
        public IActionResult PrivacyPolicy(string type)
        {
            if (type.IsNullOrWhiteSpace())
            {
                return View();
            }
            else
            {
                ViewBag.FromCookie = type;
                return View();
            }

        }

        [Route("terms-and-conditions")]
        public IActionResult TermsConditions_old()
        {
            return RedirectToActionPermanent("TermsConditions");
        }
        [Route("terms")]
        public IActionResult TermsConditions()
        {
            return View();
        }
        [Route("why-talkhomeapp")]
        public IActionResult WhyTalkHomeApp_old()
        {
            return RedirectToActionPermanent("WhyTalkHomeApp");
        }
        [Route("why-tha")]
        public IActionResult WhyTalkHomeApp()
        {
            return View();
        }
        [Route("complaints-procedure")]
        public IActionResult ComplaintsProcedure()
        {
            return View();
        }

        [Route("404")]
        public IActionResult PageNotFound()
        {
            return View();
        }

        //T&C's pages for app

        [Route("app_termsConditions.jsp")]
        public IActionResult App_termsConditions()
        {
            return View();
        }

        //Privacy Policy pages for app

        [Route("app_privacyPolicy.jsp")]
        public IActionResult App_privacyPolicy()
        {
            return View();
        }

        //FAQ's pages for app

        [Route("app_faq.jsp")]
        [Route("appfaq")]
        public IActionResult App_faq()
        {
            return View();
        }

        [HttpGet]
        [Route("healthcheck")]
        public IActionResult HealthCheck()
        {
            return Ok();
        }
        [HttpGet]
        [Route("mobile-top-up/{continent?}")]
        public async Task<IActionResult> SendCreditCountries(string continent = null)
        {
            //Get Account Details
            if (continent != null && continent.Contains(' ', StringComparison.InvariantCultureIgnoreCase))
                return RedirectToActionPermanent("SendCreditCountries", new { continent = continent.Replace(' ', '-') });
            var transferCountriesResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                "Transfer/TransferCountries?continent=" + continent?.Replace("-", " "), User, ApiCallType.Bearer, GetRequest: true);
            var model = new SendCreditCountriesViewModel();
            model.Continent = continent ?? "";
            if (transferCountriesResponse.IsSuccessStatusCode)
            {
                var accountResponseJson = JObject.Parse(transferCountriesResponse.Content.ReadAsStringAsync().Result);
                int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                if (errorCode == 0)
                {
                    var response = accountResponseJson.GetValue("payload").ToObject<TransferCountriesResponse>();
                    model.Countries = response.Countries.Select(e => new CountryViewModel()
                    {
                        Continent = e.Continent,
                        CountryId = e.CountryId,
                        Code = e.Code,
                        Name = e.Name,
                        OperatorsCount = e.OperatorsCount,
                        OperatorsName = e.OperatorsName,
                    }).ToList();
                }
            }
            return View(model);
        }
        [HttpGet]
        [Route("mobile-top-up/{continent}/{countryName}")]
        public async Task<IActionResult> SendCreditByCountry(string continent, string countryName)
        {
            if (continent.Contains(' ', StringComparison.InvariantCultureIgnoreCase) || countryName.Contains(' ', StringComparison.InvariantCultureIgnoreCase))
                return RedirectToActionPermanent("SendCreditByCountry", new { continent = continent.Replace(' ', '-'), countryName = countryName.Replace(' ', '-') });
            var model = new SendCreditByCountryViewModel();
            var country = _helperService.GetCountryByCountryName(countryName.Replace("-", " ")); ;
            if (country == null)
            {
                return RedirectToAction("PageNotFound", "Home");
            }
            model.CountryName = country.Name;
            model.Continent = continent;
            model.CountryCode = country.IsoTwoCharacterCode;
            var currency = "GBP";

            var allContinentCountries = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                   "Transfer/TransferCountries?continent=" + "", User, ApiCallType.Bearer, GetRequest: true);

            var transferCountriesResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                $"Transfer/TransferOperators?currency={currency}&countryName={countryName.Replace("-", " ")}", User, ApiCallType.Bearer, GetRequest: true);
            if (transferCountriesResponse.IsSuccessStatusCode)
            {

                var accountResponseJson = JObject.Parse(await transferCountriesResponse.Content.ReadAsStringAsync());
                int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                var allContinentCountriesJson = JObject.Parse(await allContinentCountries.Content.ReadAsStringAsync());
                var res = allContinentCountriesJson.GetValue("payload").ToObject<TransferCountriesResponse>();
                model.Countries = res.Countries.Select(e => new CountryViewModel()
                {
                    Continent = e.Continent,
                    CountryId = e.CountryId,
                    Code = e.Code,
                    Name = e.Name,
                    OperatorsCount = e.OperatorsCount,
                    OperatorsName = e.OperatorsName,
                }).ToList();

                if (errorCode == 0)
                {
                    /*var allContinentCountriesJson = JObject.Parse(await allContinentCountries.Content.ReadAsStringAsync());
                    var res = allContinentCountriesJson.GetValue("payload").ToObject<TransferCountriesResponse>();
                    model.Countries = res.Countries.Select(e => new CountryViewModel()
                    {
                        Continent = e.Continent,
                        CountryId = e.CountryId,
                        Code = e.Code,
                        Name = e.Name,
                        OperatorsCount = e.OperatorsCount,
                        OperatorsName = e.OperatorsName,
                    }).ToList();*/
                    var response = accountResponseJson.GetValue("payload").ToObject<TransferOperatorsResponse>();
                    if (response == null)
                    {
                        model.Operators = new List<OperatorViewModel>();
                        model.Promotions = new List<Item>();
                    }
                    else
                    {
                        model.Operators = response.Operators.Select(e => new OperatorViewModel()
                        {
                            Id = e.TransferToOperatorId,
                            ImageUrl = e.operatorImageUrl,
                            Name = e.operatorName,
                            CountryName = e.countryName,
                            CountryCode = e.countryCode,
                            Continent = e.Continent,
                        }).ToList();
                        model.Promotions = response.Promotions;
                    }
                    string jsonFilePath = _hostEnvironment.ContentRootPath + "/wwwroot/json/CallingRatesLandingPagesData/" + model.CountryName + ".json";
                    if (!System.IO.File.Exists(jsonFilePath))
                    {
                        model.CountryPictureUrl = null;
                    }
                    else
                    {
                        var json = System.IO.File.ReadAllText(jsonFilePath);

                        model.CountryPictureUrl = JsonConvert.DeserializeObject<CountryContent>(json).picurl3;
                    }
                }
            }
            return View(model);
        }
        [HttpGet]
        [Route("mobile-top-up/{continent}/{country}/{OperatorName}")]
        public async Task<IActionResult> SendCreditByOperatorAsync(string continent, string country, string OperatorName)
        {
            if (continent.Contains(' ', StringComparison.InvariantCultureIgnoreCase) || country.Contains(' ', StringComparison.InvariantCultureIgnoreCase))
                return RedirectToActionPermanent("SendCreditByOperator", new { continent = continent.Replace(' ', '-'), country = country.Replace(' ', '-'), OperatorName = OperatorName.Replace(' ', '-') });
            int index = OperatorName.LastIndexOf("recharge");

            if (index >= 0)
            {
                OperatorName = OperatorName.Substring(0, index);
            }

            var model = new SendCreditByOperatorViewModel();
            var countryData = _helperService.GetCountryByCountryName(country.Replace("-", " ")); ;
            if (countryData == null)
            {
                return RedirectToAction("PageNotFound", "Home");
            }
            var allContinentCountries = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                  "Transfer/TransferCountries?continent=" + "", User, ApiCallType.Bearer, GetRequest: true);

            var transferCountriesResponse = await ApiClient.CallApi(_Endpoints.TalkHomeAPIEndPoint +
                $"Transfer/TransferOperatorDetails?countryName={country.Replace("-", " ")}&operatorName={OperatorName.Replace("-", " ")}", User, ApiCallType.Bearer, GetRequest: true);
            if (transferCountriesResponse.IsSuccessStatusCode)
            {
                var allCountriesResponse = JObject.Parse(allContinentCountries.Content.ReadAsStringAsync().Result);
                var accountResponseJson = JObject.Parse(transferCountriesResponse.Content.ReadAsStringAsync().Result);
                int errorCode = accountResponseJson.GetValue("errorCode").ToObject<int>();

                if (errorCode == 0)
                {
                    model.Continent = continent;
                    var operatorDetails = accountResponseJson["payload"]["details"].ToObject<Operator>();
                    var promotions = accountResponseJson["payload"]["promotions"].ToObject<List<Item>>();
                    var operators = accountResponseJson["payload"]["operators"].ToObject<List<Operator>>();
                    var res = allCountriesResponse.GetValue("payload").ToObject<TransferCountriesResponse>();
                    model.Countries = res.Countries.Select(e => new CountryViewModel()
                    {
                        Continent = e.Continent,
                        CountryId = e.CountryId,
                        Code = e.Code,
                        Name = e.Name,
                        OperatorsCount = e.OperatorsCount,
                        OperatorsName = e.OperatorsName,
                    }).ToList();
                    model.Operators = operators.Select(e => new OperatorViewModel()
                    {
                        Id = e.TransferToOperatorId,
                        ImageUrl = e.operatorImageUrl,
                        Name = e.operatorName,
                        Continent = e.Continent,
                        CountryCode = e.countryCode,
                        CountryName = e.countryName,
                    }).ToList();
                    model.CountryName = operatorDetails.countryName;
                    model.CountryCode = operatorDetails.countryCode;
                    model.Continent = operatorDetails.Continent;
                    model.OperatorImageUrl = operatorDetails.operatorImageUrl;
                    model.OperatorId = operatorDetails.TransferToOperatorId;
                    model.OperatorName = operatorDetails.operatorName;
                    model.Promotions = promotions;

                    string jsonFilePath = _hostEnvironment.ContentRootPath + "/wwwroot/json/CallingRatesLandingPagesData/" + model.CountryName + ".json";
                    if (!System.IO.File.Exists(jsonFilePath))
                    {
                        model.CountryPictureUrl = null;
                    }
                    else
                    {

                        var json = System.IO.File.ReadAllText(jsonFilePath);

                        model.CountryPictureUrl = JsonConvert.DeserializeObject<CountryContent>(json).picurl3;
                    }
                }
                else
                {
                    return RedirectToAction("PageNotFound", "Home");
                }
            }
            return View(model);
        }

        [HttpGet]
        [Route("apple-app-site-association")]
        public IActionResult AppleAppSiteAssociation()
        {
            var data = System.IO.File.ReadAllText(_hostEnvironment.ContentRootPath + "/wwwroot/apple-app-site-association.json");

            return new ContentResult
            {
                Content = data,
                ContentType = "application/json"
            };
        }     
        /// <summary>
        /// Show mobile top-up success page
        /// </summary>
        /// <returns></returns>
        [Route("SendMobileTopupSuccess")]
        public IActionResult SendMobileTopupSuccess()
        {
            ViewBag.Title = "Talk Home App | Success";
            var model = new SendMobileTopupResultViewModel()
            {
                Key = "sendMobileTopupSuccess",
            };
            return View("SendMobileTopupResultMessage", model);
        }
        /// <summary>
        /// Show mobile top-up error page
        /// </summary>
        /// <returns></returns>
        [Route("SendMobileTopupError")]
        public IActionResult SendMobileTopupError()
        {
            ViewBag.Title = "Talk Home App | Error";
            var model = new SendMobileTopupResultViewModel()
            {
                Key = "sendMobileTopupError"
            };
            return View("SendMobileTopupResultMessage", model);
        }        
    }
}