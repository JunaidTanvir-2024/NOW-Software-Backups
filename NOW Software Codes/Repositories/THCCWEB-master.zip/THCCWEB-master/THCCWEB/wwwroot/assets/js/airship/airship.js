﻿var THCC_AirShip = {
    Tags: {
        types: {
            customer: 'customer',
            payment: 'payment'
        },
        names: {
            signup_web: 'thrcc_signup_web',
            thrcc_card_connected: 'thrcc_card_connected',
            thrcc_card_auto_connected: 'thrcc_card_auto_connected',
            thcc_first_purchase_web: 'thcc_first_purchase_web',
            thcc_purchase_web: 'thcc_purchase_web',
            thrcc_user_web: 'thrcc_user_web',
            thcc_user_web:'thcc_user_web',
            thrcc_order_web: 'thrcc_order_web', 
            thrcc_recharged_web: 'thrcc_recharged_web',
            thrcc_view_recharge_web: 'thrcc_view_recharge_web',
            thrcc_view_points_account_summary_web: 'thrcc_view_points_account_summary_web',
            thcc_view_rates_country_name_web: 'thcc_view_rates_country_name_Wweb',
            thrcc_recharge_viewed_checkout_web: 'thrcc_recharge_viewed_checkout_web',
            thcc_view_rates_country_name_web: 'thcc_view_rates_country_name_web',
            thrcc_signup_purchase_web: 'thrcc_signup_purchase_web',
            thrcc_redeem_points_web: 'thrcc_redeem_points_web',
            thcc_viewed_checkout_web: 'thcc_viewed_checkout_web',
            thrcc_signedup_offers_web: 'thrcc_signedup_offers_web'

        },
    },
    Events: {
        signedup_web: 'thrcc_signedup_web',
        thrcc_signedup_web: 'thrcc_signedup_web',
        view_rates_web: 'view_rates_web',
        rc_oder_failure_web: 'rc_oder_failure_web'
    },
    Init: function (registrationType) {

        try {
            UA.then(function (sdk) {
                if (!sdk.channel) {
                    if (registrationType == 1) {
                        sdk.register();
                    }
                    else {
                        sdk.plugins.load('html-prompt', 'https://aswpsdkus.com/notify/v1/ua-html-prompt.min.js?type=alert',
                            {
                                i18n: {
                                    en: {
                                        title: 'Subscribe to our notifications',
                                        message: 'Stay tunned to get our best offers by subscribing to our push notifications',
                                        accept: 'Yes, Subscribe me!',
                                        deny: 'No thanks',
                                    }
                                },
                                logo: "https://dl.asnapieu.com/binary/public/QzILLymLRAauEWWAKN5pKQ/c8cce378-e28a-4c70-a648-bdbe040b3cfb"
                            }).then(plugin => plugin.prompt());
                    }
                }
                else {
                    console.log(sdk.channel);
                }
            }).catch(function (err) {
                console.log("AirShip:" + err);
            });
        } catch (e) {
            console.log("Exception:" + err);
        }
    },
    AttachNamedUser: function (namedUser, callBackMethod) {
        try {
            UA.then(function (sdk) {
                if (sdk && sdk.channel) {
                    if (!sdk.channel.namedUser.id) {
                        sdk.channel.namedUser.set(namedUser).then(() => {
                            callBackMethod()
                        }).catch(function (err) {
                            callBackMethod();
                        });
                    }
                    else {
                        if (sdk.channel.namedUser.id != namedUser) {
                            sdk.channel.namedUser.remove();
                            sdk.channel.namedUser.set(namedUser).then(() => {
                                callBackMethod()
                            }).catch(function (err) {
                                callBackMethod();
                            });
                        }
                        callBackMethod();
                    }
                }
                else {
                    callBackMethod(true);
                }
            }).catch(function (err) {
                callBackMethod(true);
            });
        } catch (e) {
            callBackMethod(true);
        }
    },
    AddTag: function (name, type, isuserloggedin = false, callBackMethod) {
        try {
            UA.then(function (sdk) {
                sdk.getChannel()
                    .then(channel => {
                        if (isuserloggedin && !channel.namedUser.tags.has(name, type)) {
                            channel.namedUser.tags.add(name, type)
                                .then(() => {
                                    callBackMethod();
                                })
                                .catch(function (err) {
                                    callBackMethod();
                                });
                        }
                        else if (!isuserloggedin && !channel.tags.has(name, type)) {
                            channel.tags.add(name, type)
                                .then(() => {
                                    callBackMethod();
                                });
                        } else {
                            callBackMethod();
                        }
                    }).catch(function (err) {
                        callBackMethod();
                    });
            }).catch(function (err) {
                callBackMethod();
            });
        }
        catch (e) {
            callBackMethod();
        }
    },
    FireCustomEvent: function (eventName, propertiesList, callBackMethod) {
        try {
            UA.then(function (sdk) {

                var event = new sdk.CustomEvent(eventName);

                event.properties = propertiesList;

                event.track()
                    .then(function () {
                        callBackMethod();
                    }).catch(function () {
                        callBackMethod();
                    })

            }).catch(function (err) {
                callBackMethod();
            });

        } catch (e) {
            callBackMethod();
        }
    },
    DeAttachNamedUser: function (callBackMethod) {
        debugger;
        try {
            UA.then(function (sdk) {
                if (sdk && sdk.channel) {
                    if (sdk.channel.namedUser.id) {
                        sdk.channel.namedUser.remove().then(() => {
                            callBackMethod()
                        }).catch(function (err) {
                            callBackMethod();
                        });
                    } else {
                        callBackMethod();
                    }
                }
                else {
                    callBackMethod();
                }
            }).catch(function (err) {
                callBackMethod();
            });
        } catch (e) {
            callBackMethod();
        }
    }
};


$(document).ready(function () {
    THCC_AirShip.Init(1); // 1=>direct, 2=>Htmp-Prompt
});