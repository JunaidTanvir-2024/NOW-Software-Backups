﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class VerifyUserSimOrderRequestModel
    {

        [Required]
        public string Email { get; set; }
        [Required]
        public string PostCode { get; set; }
        [Required]
        public string Address { get; set; }
    }
}
