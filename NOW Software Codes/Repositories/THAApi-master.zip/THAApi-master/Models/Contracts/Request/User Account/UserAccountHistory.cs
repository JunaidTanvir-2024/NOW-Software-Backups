﻿using System.Collections.Generic;

namespace Models.Contracts.Request
{
    public class UserAccountHistory
    {
        public IList<UserAccountSmsHistory> SmsHistory { get; set; }

        public IList<UserAccountCallHistory> CallHistory { get; set; }

        public IList<UserAccountPaymentHistory> PaymentHistory { get; set; }
    }
}
