﻿
using System.Collections.Generic;



namespace ATT.Models.Contracts.Sochitel.Response
{
    public class Operator
    {
        public string id { get; set; }
        public string name { get; set; }
        public string brandId { get; set; }
        public List<string> productTypes;
        public string currency { get; set; }
        public List<string> locations;
        public List<string> prefixes;
        public OperatorCountry country;
    }


    public class OperatorCountry
    {
        public string id { get; set; }
        public string name { get; set; }
        public List<string> prefixes;
        public List<string> operatorPrefixes;
        public OperatorMsisdnLength msisdnLength { get; set; }
    }


    public class OperatorMsisdnLength
    {
        public int min { get; set; }
        public int max { get; set; }
    }

}
