﻿namespace Models.Contracts.Request
{
    public class SetBundleAutoRenewalRequestModel
    {
        public bool AutoRenewal { get; set; }
        public string BundleId { get; set; }
    }
}
