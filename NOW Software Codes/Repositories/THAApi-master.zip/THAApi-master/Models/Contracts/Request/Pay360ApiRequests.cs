﻿using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.Contracts.Request
{
    public class Pay360PaymentRequest
    {
        public Pay360PaymentRequestNew Pay360PaymentRequestNew { get; set; }
        public Pay360PaymentBase Pay360PaymentRequestDefault { get; set; }
        public Pay360PaymentRequestExistingNew Pay360PaymentRequestExistingNew { get; set; }
        public Pay360PaymentRequestToken Pay360PaymentRequestToken { get; set; }
    }
    public class Pay360PaymentRequestNew : Pay360PaymentRequestExistingNew
    {

    }

    public class Pay360PaymentRequestToken : Pay360PaymentBase
    {
        public string cardToken { get; set; }
    }

    public class Pay360PaymentRequestExistingNew : Pay360PaymentBase
    {
        public string cardPan { get; set; }
        public string cardExpiryDate { get; set; }
        public bool isDefaultCard { get; set; }
        public bool saveCard { get; set; }
        public financialServices financialServices { get; set; }

    }
    public class Pay360PaymentBase
    {
        public string customerName { get; set; }
        public string customerUniqueRef { get; set; }
        public string customerEmail { get; set; }
        public string customerMsisdn { get; set; }
        public string transactionCurrency { get; set; }
        public decimal transactionAmount { get; set; }
        public string cardCv2 { get; set; }
        public bool isAuthorizationOnly { get; set; }
        public bool isDirectFullfilment { get; set; }
        public bool do3DSecure { set; get; }
        public bool recurring { get; set; }
        public string ipAddress { get; set; }
        public string productCode { get; set; }
        public List<basket> basket { get; set; }
        public billingAddress billingAddress { get; set; }
        public billingAddress customerBillingAddress { get; set; }
        public customField customFields { get; set; }
        public Pay360PaymentType Pay360PaymentType { get; set; }
        public bool sendPay360Email { get; set; }
        public bool OverrideValidation { get; set; }
    }

    public class Pay360PaymentRequestData
    {       
        public CardData CustomerCardData { get; set; }
        public AddressData CustomerAddressData { get; set; }
        public string CustomerMsisdn { get; set; }
        public string CustomerEmail { get; set; }
        public string SecurityCode { get; set; }
        public string IpAddress { get; set; }
        public string CardToken { get; set; }
        public decimal ChargeAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        public string BundleId { get; set; }
        public string Currency { get; set; }
        public string RegistrationDate { get; set; }
        public string toMsisdn { get; set; }
        public bool ShouldSaveCard { get; set; }
        public Pay360PaymentType Pay360PaymentType { get; set; }
        public CheckOutTypes CheckoutPaymentType { get; set; }
        public string CustomerUniqueRef { get; set; }
        public string accountNumber { get; set; }
        public bool IsDefaultCard { get; set; } = true;
        public bool IsRecurring { get; set; }
        public bool OverrideValidation { get; set; } = false;
    }

    public class CardData
    {
        public string NameOnCard { get; set; }
        public string CardNumber { get; set; }
        public string ExpiryDate { get; set; }
        public string SecurityCode { get; set; }
    }

    public class AddressData
    {
        public string AddressL1 { get; set; }
        public string AddressL2 { get; set; }
        public string AddressL3 { get; set; }
        public string AddressL4 { get; set; }
        public string City { get; set; }
        public string CountryCode { get; set; }
        public string PostCode { get; set; }
        public string Region { get; set; }
    }


    public class billingAddress
    {
        public string line1 { get; set; }
        public string line2 { get; set; }
        public string line3 { get; set; }
        public string line4 { get; set; }
        public string city { get; set; }
        public string region { get; set; }
        public string postcode { get; set; }
        public string countryCode { get; set; }
    }
    public class customField
    {
        public List<fieldstate> fieldState { get; set; }
    }
    public class fieldstate
    {
        public string name { get; set; }
        public string value { get; set; }
        public bool transient { get; set; } = false;
    }
    public class TransactionbaketitemsResponseModel
    {
        public int id { get; set; }
        public decimal amount { get; set; }
        public decimal discount { get; set; }
        public decimal totalAmount { get; set; }
        public string bundleref { get; set; }
        public string Transactioncurrency { get; set; }
        public string ProductItemCode { get; set; }
        public string Email { get; set; }

    }
    public class basket
    {
        public string productItemCode { get; set; }
        [JsonProperty("amount")]
        public decimal chargeAmount { get; set; }
        public decimal discountAmount { get; set; }
        public string productRef { get; set; }
        public string bundleRef { get; set; }
    }

    public class PayPalByPay360Basket
    {
        public string productItemCode { get; set; }
        [JsonProperty("amount")]
        public decimal chargeAmount { get; set; }
        public decimal discountAmount { get; set; }
        public string productRef { get; set; }
        public string bundleRef { get; set; }
    }
    public class financialServices
    {
        public string dateOfBirth { get; set; }
        public string surname { get; set; }
        public string accountNumber { get; set; }
        public string postCode { get; set; }
    }

}
