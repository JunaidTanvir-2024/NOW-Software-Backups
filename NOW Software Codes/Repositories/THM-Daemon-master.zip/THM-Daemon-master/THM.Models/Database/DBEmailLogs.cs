﻿
using System;
using System.Collections.Generic;
using System.Text;
using THM.Models.Enums;

namespace THM.Models.Database
{
    public class DbEmailLogs
    {
        public int Id { get; set; }
        public int SimOrderId { get; set; }
        public SimOrderType SimOrderTypeId { get; set; }
        public EmailsType EmailTypeId { get; set; }
        public bool IsEmailSent { get; set; }
    }
}
