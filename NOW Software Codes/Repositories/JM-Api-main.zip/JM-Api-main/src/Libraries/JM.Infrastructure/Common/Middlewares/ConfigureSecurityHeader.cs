using JM.Core.Utilities.Definitions;

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace JM.Infrastructure.Common.Middlewares;
internal static class ConfigureSecurityHeader
{
    #region Security Header Dependency Extension
    internal static IServiceCollection AddSecurityHeaderConfiguration(this IServiceCollection services, IConfiguration configuration)
    {
        return services
                    .Configure<SecurityHeaderSetting>(configuration.GetSection(SecurityHeaderSetting.SectionName));
    }
    #endregion

    #region Setting
    public sealed class SecurityHeaderSetting
    {
        public const string SectionName = nameof(SecurityHeaderSetting);
        public bool Enable { get; set; }
        public string? XFrameOptions { get; set; }
        public string? XContentTypeOptions { get; set; }
        public string? ReferrerPolicy { get; set; }
        public string? PermissionsPolicy { get; set; }
        public string? SameSite { get; set; }
        public string? XxssProtection { get; set; }
        public List<string>? ContentPolicy { get; set; }
    }
    #endregion

    #region Middleware
    internal sealed class Middleware(RequestDelegate next, IOptions<SecurityHeaderSetting> options)
    {
        private readonly SecurityHeaderSetting _securityHeaderSetting = options.Value;

        public async Task Invoke(HttpContext context)
        {
            if (_securityHeaderSetting?.Enable is true)
            {
                if (!context.Response.HasStarted)
                {
                    if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.XFrameOptions))
                    {
                        context.Response.Headers.Append(AppConstant.SecurityHeader.XFrameOptions, _securityHeaderSetting.XFrameOptions);
                    }

                    if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.XContentTypeOptions))
                    {
                        context.Response.Headers.Append(AppConstant.SecurityHeader.XContentTypeOptions, _securityHeaderSetting.XContentTypeOptions);
                    }

                    if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.ReferrerPolicy))
                    {
                        context.Response.Headers.Append(AppConstant.SecurityHeader.ReferrerPolicy, _securityHeaderSetting.ReferrerPolicy);
                    }

                    if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.PermissionsPolicy))
                    {
                        context.Response.Headers.Append(AppConstant.SecurityHeader.PermissionsPolicy, _securityHeaderSetting.PermissionsPolicy);
                    }

                    if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.SameSite))
                    {
                        context.Response.Headers.Append(AppConstant.SecurityHeader.SameSite, _securityHeaderSetting.SameSite);
                    }

                    if (!string.IsNullOrWhiteSpace(_securityHeaderSetting.XxssProtection))
                    {
                        context.Response.Headers.Append(AppConstant.SecurityHeader.XxssProtection, _securityHeaderSetting.XxssProtection);
                    }
                }
            }

            await next(context);
        }
    }
    #endregion
}


