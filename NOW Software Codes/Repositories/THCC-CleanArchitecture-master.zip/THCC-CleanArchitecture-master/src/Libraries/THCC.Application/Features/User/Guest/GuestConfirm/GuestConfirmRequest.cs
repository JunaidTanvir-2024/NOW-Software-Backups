﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.User.Guest.GuestConfirm;

public sealed class GuestConfirmRequest : IRequest<object>
{
    public string Email { get; set; } = default!;
    public string EmailOtp { get; set; } = default!;
}

public sealed class GuestConfirmRequestValidator : AbstractValidator<GuestConfirmRequest>
{
    public GuestConfirmRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Email)
           .NotNull()
           .NotEmpty()
           .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
           .Must(p => commonService.IsValidEmailAddress(p)).WithMessage("Invalid Email Address");

        RuleFor(p => p.EmailOtp).Cascade(CascadeMode.Stop)
           .NotEmpty()
           .NotNull()
           .MaximumLength(6).WithMessage("Your otp length must not exceed 6."); ;
    }
}
