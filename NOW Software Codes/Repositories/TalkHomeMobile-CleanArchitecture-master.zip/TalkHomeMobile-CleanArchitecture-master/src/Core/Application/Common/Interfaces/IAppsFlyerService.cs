﻿using Application.Common.Extensions.DependencyResolver;
using Application.Common.Models;

namespace Application.Common.Interfaces;
public interface IAppsFlyerService : IServicesType.ITransientService
{
    Task SetCustomerId(string customerUserId, string afUserId);
    Task CreateCustomEvent(List<CreateEventRequestModel> request);
}
