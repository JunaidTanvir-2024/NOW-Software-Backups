﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Products.Requests
{
    public class GetVoucherifyProductRequest
    {
        public string ProductNameOrId { get; set; }
    }
}
