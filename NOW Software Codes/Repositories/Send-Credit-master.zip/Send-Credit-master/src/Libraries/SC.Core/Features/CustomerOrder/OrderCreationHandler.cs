﻿using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder;
internal sealed class OrderCreationHandler : IRequestHandler<OrderCreationRequest, IResultWrapper>
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly ICommonService _commonService;
    public OrderCreationHandler(ICustomerCartRespository customerCartRespository, ICommonService commonservice)
    {
        _customerCartRespository = customerCartRespository;
        _commonService = commonservice;
    }
    public async Task<IResultWrapper> Handle(OrderCreationRequest request, CancellationToken cancellationToken)
    {
        var order = new OrderCreationDto()
        {
            CustomerOrderID = request.CustomerOrderID,
            PromoCode = request.PromoCode,
            DiscountTypeId = request.DiscountTypeId,
            DiscountAmount = request.DiscountAmount,
            ServiceFee = request.ServiceFee,
            TaxAmount = request.TaxAmount,
            TaxInclusiveAmount = request.TaxInclusiveAmount,
            TaxExclusiveAmount = request.TaxExclusiveAmount,
            TotalOrderAmount = request.TotalOrderAmount,
            Currency = string.IsNullOrEmpty(request.Currency) ? _commonService.GetDefaultCurrency() : request.Currency,
            OrderStatus = OrderStatusEnum.Init.Getkey(),
            isDeleted = false,
            isActive = true,
            UserID = _commonService.GetUserID(),
            RequestId = _commonService.GetRequestID(),
        };
        var response = await _customerCartRespository.OrderCreationAsync(order);
        return ResultWrapper.Success(response);
    }
}

