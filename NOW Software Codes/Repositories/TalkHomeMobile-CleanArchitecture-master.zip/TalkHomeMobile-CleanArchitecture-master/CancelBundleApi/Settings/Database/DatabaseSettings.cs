﻿namespace CancelBundleApi.Settings.Database;

public class DatabaseSettings
{
    public const string SectionName = "DatabaseSettings";
    public static DatabaseSettings Bind = new DatabaseSettings();
    public string? DigiTalkConnection { get; set; }
    public string? ServiceApiConnection { get; set; }
}