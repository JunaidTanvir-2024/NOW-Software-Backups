﻿

using Application.Features.Device.ConfirmDevice;
using Application.Features.Device.ConfirmDeviceResend;
using Application.Features.Device.NotificationToken;

namespace NowMobile.Api.Controllers;

public class DeviceController : VersionedApiController
{
    [HttpPost("notification/token")]
    [AllowAnonymous]
    [OpenApiOperation("Save and update device notification token", "")]
    public async Task<IActionResult> NotificationTokenAsync([FromBody] NotificationTokenRequest request, CancellationToken cancellationToken)
    {
        return Ok(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("confirm")]
    [AllowAnonymous]
    [OpenApiOperation("Confirm user device", "")]
    public async Task<IActionResult> ConfirmDeviceAsync([FromBody] ConfirmDeviceRequest request, CancellationToken cancellationToken)
    {
        return Ok(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("confirm/resend")]
    [AllowAnonymous]
    [OpenApiOperation("Resend device confirmation otp", "")]
    public async Task<IActionResult> ResendConfirmDeviceTokenAsync([FromBody] ConfirmDeviceResendRequest request, CancellationToken cancellationToken)
    {
        return Ok(await Mediator.Send(request, cancellationToken));
    }
}
