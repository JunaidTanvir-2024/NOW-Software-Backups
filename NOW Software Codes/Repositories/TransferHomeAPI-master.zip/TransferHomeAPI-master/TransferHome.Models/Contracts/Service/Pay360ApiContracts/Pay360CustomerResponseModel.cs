﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TransferHome.Models.Contracts.Service.Pay360ApiContracts
{
    public class Pay360CustomerResponseModel
    {
        public string displayName { get; set; }
        public string merchantRef { get; set; }
        public string pay360CustId { get; set; }
        public string email { get; set; }
        public string defaultCurrency { get; set; }
        public string dob { get; set; }
        public string addressLine1 { get; set; }
        public string addressLine2 { get; set; }
        public string addressLine3 { get; set; }
        public string addressLine4 { get; set; }
        public string city { get; set; }
        public string region { get; set; }
        public string postCode { get; set; }
        public string country { get; set; }
        public string countryCode { get; set; }
        public string telephone { get; set; }
        public List<paymentMethodResponse> PaymentMethods { get; set; }
    }
}
