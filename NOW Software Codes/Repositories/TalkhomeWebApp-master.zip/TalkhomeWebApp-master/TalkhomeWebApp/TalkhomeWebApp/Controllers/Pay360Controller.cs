﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.Net;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.Configurations;
using TalkhomeWebApp.Models.ViewModels;
using TalkhomeWebApp.Utilities;
using TalkhomeWebApp.Models.ApiContracts.Response;
using TalkhomeWebApp.Models.ApiContracts.Request;
using TalkhomeWebApp.Models;
using TalkhomeWebApp.Utilities.Extension;
using System.Text;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using Microsoft.AspNetCore.DataProtection;
using System.Collections.Generic;
using TalkhomeWebApp.Services;

namespace TalkhomeWebApp.Controllers
{
    public class Pay360Controller : BaseController
    {
        private readonly EndPoints _endPoints;
        private readonly ILogger _logger;
        private readonly IDataProtector _dataProtector;
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly IAirshipService _airshipService;
		private readonly ApiClient _apiClient;

		public Pay360Controller(IOptions<EndPoints> endPointsSettings,
            ILogger logger,
            IDataProtectionProvider provider,
            IOptions<BasicAuthConfig> basicAuthConfig,
            IAirshipService airshipService,
            IHelperService helperService,
            ApiClient apiClient) : base(logger, helperService)
        {
            _endPoints = endPointsSettings.Value;
            _logger = logger;
            _basicAuthConfig = basicAuthConfig.Value;
            _dataProtector = provider.CreateProtector("THA-WEB-101");
            _airshipService = airshipService;
			this._apiClient = apiClient;
		}

        [Route("securereturnpayment")]
        public async Task<IActionResult> SecureReturn(SecureReturnPaymentRequest model)
        {
            try
            {
                if (model.clientRedirectType.Contains("V2"))
                {
                    ModelState.Remove("PaRes");
                }
                if (model.type == CheckOutTypes.TopUp)
                {
                    ModelState.Remove("BundleType");
                }
                if (!ModelState.IsValid) { return BadRequest(); };

                String encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var paymentResponse = await _apiClient.CallApi(_endPoints.TalkHomeAPIEndPoint +
                                                        "Payment/Resume3DTransaction", User, ApiCallType.BasicAuth,
                                                         new Pay360Resume3DRequestModel()
                                                         {
                                                             MD = model.MD,
                                                             PaRes = model.PaRes,
                                                             type = model.type,
                                                             customerEmail = model.customerEmail,
                                                             bundleId = model.bundleId,
                                                             clientRedirectType = model.clientRedirectType,
                                                             customerMsisdn = model.customerMsisdn,
                                                             currency = model.currency,
                                                             IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext),
                                                             FromBundleISO2 = model.FromBundleISO2,
                                                             ToBundleISO2 = model.ToBundleISO2,
                                                             IsAutoTopUp = model.IsAutoTopUp,
                                                             IsAutoBundleRenew= model.IsAutoBundleRenew,
                                                             PTId = model.PTId,
                                                             ShouldSaveCard = model.shouldSave
                                                         }, basicauthtoken: encoded);

                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(await paymentResponse.Content.ReadAsStringAsync());
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();
                    var purchaseInfo = paymentResponseJson.GetValue("payload").ToObject<Pay360Resume3DResponseModel>();

                    if (errorCode == 0)
                    {
                        if (purchaseInfo.topupInfo != null)
                        {
                            purchaseInfo.topupInfo.shouldSave = model.shouldSave;
                        }
                        else if (purchaseInfo.bundlePurchaseInfo != null)
                        {
                            purchaseInfo.bundlePurchaseInfo.shouldSave = model.shouldSave;
                            purchaseInfo.bundlePurchaseInfo.BundleType = model.BundleType;
                        }
                        ViewBag.SuccessModelData = JsonConvert.SerializeObject(new SuccessObjectViewModel { type = model.type, purchaseInfo = purchaseInfo, PaymentMethod = "Card" });
                        return PartialView("~/Views/Home/SuccesRedirection.cshtml");
                    }
                    else
                    {
                        //Need to handle error code values
                        return HandleErrorResponse<Pay360Resume3DResponseModel>(purchaseInfo, errorCode,
                                                    paymentResponseJson.GetValue("message").ToObject<string>(), true);
                    }
                }
                else
                {
                    // return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                    ViewBag.ErrorModelData = JsonConvert.SerializeObject(new ErrorObjectViewModel { Key = "InternalServerError", });
                    return PartialView("~/Views/Home/ErrorRedirection.cshtml");
                }
            }
            catch (Exception ex)
            {

                _logger.Error($"Class: Pay360Controller, Method: SecureReturn, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                ViewBag.ErrorModelData = JsonConvert.SerializeObject(new ErrorObjectViewModel { Key = "InternalServerError" });
                return PartialView("~/Views/Home/ErrorRedirection.cshtml");
            }
        }

        [HttpPost]
        [Route("bundlepurchaseviaaccountbalance")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> BundlePurchaseViaAccountBalance(BundlePurchaseViaABRequestModel model)
        {
            try
            {
                ModelState.Remove("EmailAddress");

                if (!ModelState.IsValid) { return BadRequest(); };

                model.IpAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext);

                var bundleResponse = await _apiClient.CallApi(_endPoints.TalkHomeAPIEndPoint +
                                     "Payment/BundlePurchaseViaAccountBalance", User, ApiCallType.Bearer, model);
                TempData.Put("PaymentMethod", "AccountBalance");
                if (bundleResponse.IsSuccessStatusCode)
                {
                    var bundleResponseJson = JObject.Parse(bundleResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = bundleResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var bundlePurchaseInfo = bundleResponseJson.GetValue("payload").ToObject<BundlePurchaseViaABResponseModel>().bundlePurchaseInfo;
                        bundlePurchaseInfo.BundleType = model.BundleType;
                        TempData.Put("BundlePurchaseInfo", bundlePurchaseInfo);

                        return RedirectToAction("SuccessMessage", "Home", new { key = "BundlePurchaseSuccessful" });
                    }
                    else
                    {
                        //Need to handle error code values
                        return HandleErrorResponse<BundlePurchaseViaABRequestModel>(model, errorCode,
                                                                    bundleResponseJson.GetValue("message").ToObject<string>());
                    }
                }
                else if (bundleResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Pay360Controller, Method: BundlePurchaseViaAccountBalance, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("newcustomerpayment")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> NewCustomerPayment(NewCustomerPaymentRequest model)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    if (string.IsNullOrEmpty(model.Msisdn))
                    {
                        ModelState.Remove("Msisdn");
                        model.Msisdn = User.Claims.First(i => i.Type == "phone_number").Value;
                    }
                }

                if (model.CheckoutPaymentType == CheckOutTypes.FastTopup)
                {
                    model.CheckoutPaymentType = CheckOutTypes.TopUp;
                }

                ModelState.Remove("UserCard.Token");

                if (!ModelState.IsValid) { return BadRequest(); };

                String encodedToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var paymentResponse = await _apiClient.CallApi(_endPoints.TalkHomeAPIEndPoint +
                                     "Payment/NewCustomerPayment", User, ApiCallType.BasicAuth, new NewCustomerPaymentRequestModel()
                                     {
                                         billingAddressData = new BillingAddressModel()
                                         {
                                             AddressL1 = model.AddressL1,
                                             AddressL2 = model.AddressL2,
                                             AddressL3 = model.AddressL3,
                                             AddressL4 = model.AddressL4,
                                             City = model.City,
                                             CountryCode = model.UserCard.CoutryCode,
                                             PostCode = model.PostCode,
                                             Region = model.Region
                                         },
                                         IsAutoBundleRenew = model.IsAutoBundleRenew,
                                         Msisdn = model.Msisdn,
                                         ipAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext),
                                         TopUpAmount = model.Amount,
                                         BundleId = model.BundleId,
                                         cardData = new PaymentCardModel()
                                         {
                                             CardNumber = model.UserCard.CardNumber,
                                             ExpiryMonth = model.UserCard.ExpiryMonth,
                                             ExpiryYear = model.UserCard.ExpiryYear,
                                             NameOnCard = model.UserCard.NameOnCard,
                                             SecurityCode = model.UserCard.SecurityCode,
                                             ShouldSaveCard = model.ShouldSave
                                         },
                                         CheckoutType = model.CheckoutPaymentType,
                                         EmailAddress = model.EmailAddress,
                                         FromBundleISO2 = model.FromBundleISO2,
                                         ToBundleISO2 = model.ToBundleISO2,
                                         IsAutoTopUp = model.IsAutoTopUp,
                                         CustomerUniqueRef = User.Identity.IsAuthenticated ? User.Claims.First(i => i.Type == "phone_number").Value : model.Msisdn
                                     }, basicauthtoken: encodedToken);
                TempData.Put("PaymentMethod", "Card");
                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();
                        var purchaseInfo = paymentResponseJson.GetValue("payload").ToObject<NewCustomerPaymentResponseModel>();

                    if (errorCode == 0)
                    {

                        if (model.CheckoutPaymentType == CheckOutTypes.Bundle)
                        {
                            TempData.Put("BundlePurchaseInfo", purchaseInfo.bundlePurchaseInfo);
                            return RedirectToAction("SuccessMessage", "Home", new { key = "BundlePurchaseSuccessful" });
                        }
                        else
                        {
                            TempData.Put("TopupInfo", purchaseInfo.topupInfo);

                            return RedirectToAction("SuccessMessage", "Home", new { key = "TopupSuccessful" });
                        }
                    }
                    else if (errorCode == (int)ApiStatusCodes.Pending3dSecure)
                    {

                        var payload = paymentResponseJson.GetValue("payload").ToObject<NewCustomerPaymentResponseModel>().threeDSecureData;

                        if (!payload.clientRedirectType.Contains("V2"))
                        {
                            var transactionViewModel = new Pay360TransactionViewModel
                            {
                                url = payload.redirectUrl,
                                pareq = payload.pareq,
                                TransactionId = payload.transactionId,
                                returnUrl = payload.returnUrl + "&shouldSave=" + model.ShouldSave
                            };
                            return View("~/Views/shared/View3DSecure.cshtml", transactionViewModel);
                        }
                        else
                        {
                            var transactionViewModel = new Pay360TransactionViewModel
                            {
                                url = payload.redirectUrl,
                                pareq = payload.pareq,
                                TransactionId = payload.transactionId,
                                returnUrl = payload.returnUrl + "&shouldSave=" + model.ShouldSave,
                                threeDSServerTransId = payload.threeDSServerTransId
                            };
                            return View("~/Views/shared/View3DSecureV2.cshtml", transactionViewModel);
                        }
                    }

                    //Need to handle error code values
                    return HandleErrorResponse<NewCustomerPaymentResponseModel>(purchaseInfo, errorCode,
                                                                paymentResponseJson.GetValue("message").ToObject<string>());
                }
                else if (paymentResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Pay360Controller, Method: NewCustomerPayment, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("newcardpayment")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> NewCardPayment(NewCardPaymentRequest model)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    if (string.IsNullOrEmpty(model.Msisdn))
                    {
                        ModelState.Remove("Msisdn");
                        model.Msisdn = User.Claims.First(i => i.Type == "phone_number").Value;
                    }
                }

                ModelState.Remove("UserCard.Token");

                if (model.CheckoutPaymentType == CheckOutTypes.FastTopup)
                {
                    model.CheckoutPaymentType = CheckOutTypes.TopUp;
                }

                if (!ModelState.IsValid) { return BadRequest(); };


                String encodedToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var paymentResponse = await _apiClient.CallApi(_endPoints.TalkHomeAPIEndPoint +
                                     "Payment/NewCardPayment", User, ApiCallType.BasicAuth, new NewCardPaymentRequestModel()
                                     {
                                         billingAddressData = new BillingAddressModel()
                                         {
                                             AddressL1 = model.AddressL1,
                                             AddressL2 = model.AddressL2,
                                             AddressL3 = model.AddressL3,
                                             AddressL4 = model.AddressL4,
                                             City = model.City,
                                             CountryCode = model.UserCard.CoutryCode,
                                             PostCode = model.PostCode,
                                             Region = model.Region
                                         },
                                         IsAutoBundleRenew = model.IsAutoBundleRenew,
                                         Msisdn = model.Msisdn,
                                         ipAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext),
                                         TopUpAmount = model.Amount,
                                         BundleId = model.BundleId,
                                         cardData = new PaymentCardModel()
                                         {
                                             CardNumber = model.UserCard.CardNumber,
                                             ExpiryMonth = model.UserCard.ExpiryMonth,
                                             ExpiryYear = model.UserCard.ExpiryYear,
                                             NameOnCard = model.UserCard.NameOnCard,
                                             SecurityCode = model.UserCard.SecurityCode,
                                             ShouldSaveCard = model.ShouldSave
                                         },
                                         CheckoutType = model.CheckoutPaymentType,
                                         EmailAddress = model.EmailAddress,
                                         FromBundleISO2 = model.FromBundleISO2,
                                         ToBundleISO2 = model.ToBundleISO2,
                                         IsAutoTopUp = model.IsAutoTopUp,
                                         CustomerUniqueRef = User.Identity.IsAuthenticated ? User.Claims.First(i => i.Type == "phone_number").Value : model.Msisdn
                                     }, basicauthtoken: encodedToken);
                TempData.Put("PaymentMethod", "Card");

                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();
                    var purchaseInfo = paymentResponseJson.GetValue("payload").ToObject<NewCustomerPaymentResponseModel>();

                    if (errorCode == 0)
                    {
                        if (model.CheckoutPaymentType == CheckOutTypes.Bundle)
                        {
                            purchaseInfo.bundlePurchaseInfo.PaymentMethod = PaymentMethodTypes.Card;
                            TempData.Put("BundlePurchaseInfo", purchaseInfo.bundlePurchaseInfo);
                            return RedirectToAction("SuccessMessage", "Home", new { key = "BundlePurchaseSuccessful" });
                        }
                        else
                        {
                            purchaseInfo.bundlePurchaseInfo.PaymentMethod = PaymentMethodTypes.Card;
                            TempData.Put("TopupInfo", purchaseInfo.topupInfo);
                            return RedirectToAction("SuccessMessage", "Home", new { key = "TopupSuccessful" });
                        }
                    }
                    else if (errorCode == (int)ApiStatusCodes.Pending3dSecure)
                    {

                        var payload = paymentResponseJson.GetValue("payload").ToObject<NewCustomerPaymentResponseModel>().threeDSecureData;

                        if (!payload.clientRedirectType.Contains("V2"))
                        {
                            var transactionViewModel = new Pay360TransactionViewModel
                            {
                                url = payload.redirectUrl,
                                pareq = payload.pareq,
                                TransactionId = payload.transactionId,
                                returnUrl = payload.returnUrl + "&shouldSave=" + model.ShouldSave + "&BundleType=" + model.BundleType
                            };
                            return View("~/Views/shared/View3DSecure.cshtml", transactionViewModel);
                        }
                        else
                        {
                            var transactionViewModel = new Pay360TransactionViewModel
                            {
                                url = payload.redirectUrl,
                                pareq = payload.pareq,
                                TransactionId = payload.transactionId,
                                returnUrl = payload.returnUrl + "&shouldSave=" + model.ShouldSave,
                                threeDSServerTransId = payload.threeDSServerTransId
                            };
                            return View("~/Views/shared/View3DSecureV2.cshtml", transactionViewModel);
                        }
                    }

                    //Need to handle error code values
                    return HandleErrorResponse<NewCustomerPaymentResponseModel>(purchaseInfo, errorCode,
                                                                paymentResponseJson.GetValue("message").ToObject<string>());
                }
                else if (paymentResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Pay360Controller, Method: NewCardPayment, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("existingcardpayment")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ExistingCardPayment(ExistingCardPaymentRequest model)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    if (string.IsNullOrEmpty(model.Msisdn))
                    {
                        ModelState.Remove("Msisdn");
                        model.Msisdn = User.Claims.First(i => i.Type == "phone_number").Value;
                    }
                }

                if (model.CheckoutPaymentType == CheckOutTypes.FastTopup)
                {
                    model.CheckoutPaymentType = CheckOutTypes.TopUp;
                }

                if (!ModelState.IsValid) { return BadRequest(); };

                String encodedToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var paymentResponse = await _apiClient.CallApi(_endPoints.TalkHomeAPIEndPoint +
                                     "Payment/ExistingCardPayment", User, ApiCallType.BasicAuth, new ExistingCardPaymentRequestModel()
                                     {
                                         ipAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext),
                                         TopUpAmount = model.Amount,
                                         BundleId = model.BundleId,
                                         CheckoutType = model.CheckoutPaymentType,
                                         EmailAddress = model.EmailAddress,
                                         cardToken = model.cardToken,
                                         securityCode = model.SecurityCode,
                                         IsAutoBundleRenew = model.IsAutoBundleRenew,
                                         FromBundleISO2 = model.FromBundleISO2,
                                         ToBundleISO2 = model.ToBundleISO2,
                                         Msisdn = model.Msisdn,
                                         IsAutoTopUp = model.IsAutoTopUp,
                                         CustomerUniqueRef = User.Identity.IsAuthenticated ? User.Claims.First(i => i.Type == "phone_number").Value : model.Msisdn
                                     }, basicauthtoken: encodedToken);

                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();
                        var purchaseInfo = paymentResponseJson.GetValue("payload").ToObject<NewCustomerPaymentResponseModel>();

                    if (errorCode == 0)
                    {

                        if (model.CheckoutPaymentType == CheckOutTypes.Bundle)
                        {
                            TempData.Put("BundlePurchaseInfo", purchaseInfo.bundlePurchaseInfo);

                            return RedirectToAction("SuccessMessage", "Home", new { key = "BundlePurchaseSuccessful" });
                        }
                        else
                        {
                            TempData.Put("TopupInfo", purchaseInfo.topupInfo);

                            return RedirectToAction("SuccessMessage", "Home", new { key = "TopupSuccessful" });
                        }
                    }
                    else if (errorCode == (int)ApiStatusCodes.Pending3dSecure)
                    {

                        var payload = paymentResponseJson.GetValue("payload").ToObject<NewCustomerPaymentResponseModel>().threeDSecureData;

                        if (!payload.clientRedirectType.Contains("V2", StringComparison.CurrentCultureIgnoreCase))
                        {
                            var transactionViewModel = new Pay360TransactionViewModel
                            {
                                url = payload.redirectUrl,
                                pareq = payload.pareq,
                                TransactionId = payload.transactionId,
                                returnUrl = payload.returnUrl + "&BundleType=" + model.BundleType
                            };
                            return View("~/Views/shared/View3DSecure.cshtml", transactionViewModel);
                        }
                        else
                        {
                            var transactionViewModel = new Pay360TransactionViewModel
                            {
                                url = payload.redirectUrl,
                                pareq = payload.pareq,
                                TransactionId = payload.transactionId,
                                returnUrl = payload.returnUrl + payload.clientRedirectType + "&BundleType=" + model.BundleType,
                                threeDSServerTransId = payload.threeDSServerTransId
                            };
                            return View("~/Views/shared/View3DSecureV2.cshtml", transactionViewModel);
                        }

                    }

                    //Need to handle error code values
                    return HandleErrorResponse<NewCustomerPaymentResponseModel>(purchaseInfo, errorCode,
                                                                paymentResponseJson.GetValue("message").ToObject<string>());
                }
                else if (paymentResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Pay360Controller, Method: ExistingCardPayment, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpGet]
        [Route("bundle-activate")]
        [Authorize]
        public async Task<IActionResult> ActivateBundleByDefaultCardPayment(string data)
        {
            try
            {
                if (string.IsNullOrEmpty(data)) { return BadRequest(); };

                string decryptedData;

                try
                {
                    data = HttpUtility.UrlDecode(data);

                    decryptedData = _dataProtector.Unprotect(data);
                }
                catch
                {
                    return BadRequest();
                }

                if (string.IsNullOrEmpty(decryptedData))
                    return BadRequest();

                var bundleInfo = decryptedData.Split("--");
                //Get BundleDetails
                var BundlesList = new List<Bundles>() { };
                string token = Convert.ToBase64String(Encoding.
                   GetEncoding("ISO-8859-1").GetBytes(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var bundlesResponse = await _apiClient.CallApi(_endPoints.TalkHomeAPIEndPoint + "Bundles/GetBundleByCountry", User,
					ApiCallType.BasicAuth, GetRequest: true, parameters: new string[] { "ServiceId=" + (User.Identity.IsAuthenticated ? User.Claims.Where(x => x.Type == "service_id").FirstOrDefault().Value : bundleInfo[1]) }, basicauthtoken: token);

                if (bundlesResponse.IsSuccessStatusCode)
                {
                    var BundleResponse = await bundlesResponse.Content.ReadAsStringAsync();
                    BundlesList = JsonConvert.DeserializeObject<IEnumerable<Bundles>>(BundleResponse).ToList();

                    if (BundlesList.Count == 0)
                    {
                        TempData["bundle-not-found"] = "Selected bundle is not available for your country";
                        return RedirectToAction("Bundles", "Home");
                    }

                    if (!BundlesList.Any(x => x.ID.ToString().Equals(bundleInfo[2])))
                    {
                        TempData["bundle-not-found"] = "Selected bundle is not available for your country";
                        return RedirectToAction("Bundles", "Home");
                    }
                }
                else
                {
                    throw new Exception("BundlePurchase - Error while getting data from API: StatusCode" + bundlesResponse.StatusCode);
                }
                //Get Bundles and countries data
                string ToCountryIsoCode = BundlesList.Where(x => x.ID.ToString().Equals(bundleInfo[2])).Select(x => x.Description.Replace(",", "")).First();


                String encodedToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(
                                        _basicAuthConfig.Username + ":" + _basicAuthConfig.Password));

                var paymentResponse = await _apiClient.CallApi(_endPoints.TalkHomeAPIEndPoint +
                                     "Payment/ActivateBundleByDefaultCardPayment", User, ApiCallType.BasicAuth, new DefaultCardPaymentRequestModel()
                                     {
                                         ipAddress = CommonExtentionMethods.GetRemoteIPAddress(HttpContext),
                                         BundleId = bundleInfo[2],
                                         FromBundleISO2 = bundleInfo[0],
                                         ToBundleISO2 = ToCountryIsoCode,
                                         Msisdn = User.PhoneNumber(),
                                         CustomerUniqueRef = User.PhoneNumber()
                                     }, basicauthtoken: encodedToken);
                TempData.Put("PaymentMethod", "Card");
                if (paymentResponse.IsSuccessStatusCode)
                {
                    var paymentResponseJson = JObject.Parse(paymentResponse.Content.ReadAsStringAsync().Result);
                    int errorCode = paymentResponseJson.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        var purchaseInfo = paymentResponseJson.GetValue("payload").ToObject<DefaultCardPaymentResponseModel>();

                        TempData.Put("BundlePurchaseInfo", purchaseInfo.bundlePurchaseInfo);

                        return RedirectToAction("SuccessMessage", "Home", new { key = "BundlePurchaseSuccessful" });

                    }

                    //Need to handle error code values
                    return HandleErrorResponse<DefaultCardPaymentResponseModel>(null, errorCode,
                                                                paymentResponseJson.GetValue("message").ToObject<string>());
                }
                else if (paymentResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    return RedirectToAction("UnauthorizedResponseApiCall", "Account");
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: Pay360Controller, Method: ExistingCardPayment, ErrorMessage:" +
                                $" {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, " +
                                $"StackTrace: {ex.StackTrace}");

                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }

        [HttpPost]
        [Route("PaymentSuccess")]
        [ValidateAntiForgeryToken]
        public IActionResult PaymentSuccess(string data)
        {
            var model = JsonConvert.DeserializeObject<SuccessObjectViewModel>(data);
            TempData.Put("PaymentMethod", model.PaymentMethod);
            if (model.type == CheckOutTypes.Bundle)
            {
                TempData.Put("BundlePurchaseInfo", model.purchaseInfo.bundlePurchaseInfo);

                return RedirectToAction("SuccessMessage", "Home", new { key = "BundlePurchaseSuccessful" });
            }
            else
            {
                TempData.Put("TopupInfo", model.purchaseInfo.topupInfo);

                return RedirectToAction("SuccessMessage", "Home", new { key = "TopupSuccessful" });
            }
        }

        [HttpPost]
        [Route("PaymentError")]
        [ValidateAntiForgeryToken]
        public IActionResult PaymentError(string data)
        {
            var Model = JsonConvert.DeserializeObject<ErrorObjectViewModel>(data);


            var ErrorModel = JsonConvert.DeserializeObject<ErrorObjectViewModel>(data);
            if (ErrorModel.Key == "paymentserviceerror")
            {
                TempData.Put("Payment-Service-Error", ErrorModel.ErrorMessage);
            }
            TempData.Put("Key", ErrorModel.Key);
            if (ErrorModel.BundleInfo != null)
            {
                return RedirectToAction("BundleError", "Home", ErrorModel.BundleInfo);
            }
            else if (ErrorModel.TopupInfo != null)
            {
                return RedirectToAction("TopupError", "Home", ErrorModel.TopupInfo);
            }
            return RedirectToAction("ErrorMessage", "Home", new { key = ErrorModel.Key });

        }
        [HttpPost]
        [Route("SetBundleAutoRenew")]
        public async Task<IActionResult> SetBundleAutoRenew(SetBundleAutoRenewRequestModel model)
        {
            try
            {
                var response = await _apiClient.CallApi(_endPoints.TalkHomeAPIEndPoint + "Bundles/SetBundleAutoRenew", User, ApiCallType.Bearer,
                    model: model, GetRequest: false);

                if (response.IsSuccessStatusCode)
                {
                    var result = JObject.Parse(response.Content.ReadAsStringAsync().Result);

                    var errorCode = result.GetValue("errorCode").ToObject<int>();

                    if (errorCode == 0)
                    {
                        return Json(new { status = true });
                    }
                    else
                    {
                        return Json(new { status = false, message = result.GetValue("message").ToObject<string>() });
                    }
                }
                else
                {
                    return StatusCode((int)response.StatusCode);
                }
            }
            catch
            {
                return StatusCode((int)ApiStatusCodes.InternalServerError);
            }
        }
    }
}
