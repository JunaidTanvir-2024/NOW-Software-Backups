﻿using Dapper;
using Microsoft.Extensions.Options;
using Now.Models.Configurations;
using Now.Models.Database;
using Now.Models.DbConnections;
using Now.Models.Enums;
using System.Data;
using System.Data.SqlClient;

namespace Now.Infrastructure.DAL;

public class SimOrderEmails_DL : ISimOrderEmails_DL
{
    private readonly IDbConnectionSettings _nowWebDb;

    public SimOrderEmails_DL(IOptions<ConnectionStrings> connectionString)
    {
        _nowWebDb = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
    }

    public async Task<DbSimOrder> GetCreditSimOrderDetails(int OrderId)
    {
        DynamicParameters parameters = new DynamicParameters();

        parameters.Add("@OrderId", OrderId);

        return await _nowWebDb.SqlConnection.QueryFirstOrDefaultAsync<DbSimOrder>
                                    ("now_sim_order_getCreditSimOrderDetails",
                                            parameters, commandType: CommandType.StoredProcedure);
    }

    public async Task<DbSimOrder> GetSimOrderDetails(int OrderId)
    {
        DynamicParameters parameters = new DynamicParameters();

        parameters.Add("@OrderId", OrderId);

        return await _nowWebDb.SqlConnection.QueryFirstOrDefaultAsync<DbSimOrder>
                                    ("now_sim_order_getFreeSimOrderDetails",
                                            parameters, commandType: CommandType.StoredProcedure);
    }

    public async Task<IEnumerable<DbSimOrder>> GetNotActivatedSimOrders(SimOrderType simOrderType)
    {
        DynamicParameters parameters = new DynamicParameters();

        parameters.Add("@Sim_Order_Type", (Int16)simOrderType);

        return await _nowWebDb.SqlConnection.QueryAsync<DbSimOrder>("now_sim_order_getNotActivatedSimOrders"
                                                                               , parameters, commandType: CommandType.StoredProcedure);
    }

    public async Task<IEnumerable<DbSimOrder>> GetNotToppedUpSimOrders(SimOrderType simOrderType)
    {
        DynamicParameters parameters = new DynamicParameters();

        parameters.Add("@Sim_Order_Type", (Int16)simOrderType);

        return await _nowWebDb.SqlConnection.QueryAsync<DbSimOrder>("now_sim_order_getNotToppedUpSimOrders",
                                                                parameters, commandType: CommandType.StoredProcedure);
    }

    public async Task<IEnumerable<DbSimOrder>> GetOrdersForOtherServicesEmail(SimOrderType simOrderType)
    {
        DynamicParameters parameters = new DynamicParameters();

        parameters.Add("@Sim_Order_Type", (Int16)simOrderType);

        return await _nowWebDb.SqlConnection.QueryAsync<DbSimOrder>("now_sim_order_getOrdersForOtherServicesEmail",
                                                                    parameters, commandType: CommandType.StoredProcedure);
    }

    public async Task<IEnumerable<DbSimOrder>> GetOrdersForSocialMediaEmails(SimOrderType simOrderType)
    {
        DynamicParameters parameters = new DynamicParameters();

        parameters.Add("@Sim_Order_Type", (Int16)simOrderType);

        return await _nowWebDb.SqlConnection.QueryAsync<DbSimOrder>("now_sim_order_getOrdersForSocialMediaEmails",
                                                                    parameters, commandType: CommandType.StoredProcedure);
    }

    public async Task<IEnumerable<DbSimOrder>> GetWhyAndBenefitsEmails(SimOrderType simOrderType)
    {
        DynamicParameters parameters = new DynamicParameters();

        parameters.Add("@Sim_Order_Type", (Int16)simOrderType);

        return await _nowWebDb.SqlConnection.QueryAsync<DbSimOrder>("now_sim_order_emails_get_whyandbenefits",
                                                                   parameters, commandType: CommandType.StoredProcedure);
    }

    public async Task LogEmail(int simOrderId, SimOrderType simOrderType, EmailsType emailsType, bool emailResponse, string emailErrorMessage)
    {
        DynamicParameters parameters = new DynamicParameters();

        parameters.Add("@simOrderId", simOrderId);
        parameters.Add("@simOrderType", (Int16)simOrderType);
        parameters.Add("@emailsType", (Int16)emailsType);
        parameters.Add("@isEmailSent", emailResponse);
        parameters.Add("@emailErrorMessage", emailErrorMessage);

        await _nowWebDb.SqlConnection.ExecuteAsync("now_sim_order_emails_saveEmailLogs",
                                                    parameters, commandType: CommandType.StoredProcedure);
    }

    public async Task<IEnumerable<DbEmailLogs>> GetSentEmailsDetail(int OrderId, SimOrderType simOrderType, EmailsType emailsType)
    {
        DynamicParameters parameters = new DynamicParameters();

        parameters.Add("@simOrderId", OrderId);
        parameters.Add("@simOrderType", (Int16)simOrderType);
        parameters.Add("@emailsType", (Int16)emailsType);

        return await _nowWebDb.SqlConnection.QueryAsync<DbEmailLogs>("now_sim_order_emails_get_sent_count",
                                                                            parameters, commandType: CommandType.StoredProcedure);
    }
}
