﻿
namespace THCC.Application.Features.User.Product.Product;

public class GetProductRequest : IRequest<object>
{
}
