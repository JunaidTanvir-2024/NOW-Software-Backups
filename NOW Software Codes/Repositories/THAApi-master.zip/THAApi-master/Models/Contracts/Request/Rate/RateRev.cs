﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Models.Configurations;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Models.Contracts.Request.Rate
{
    public class RateRev
    {
        public RateRev()
        {
            var configurationBuilder = new ConfigurationBuilder();
            var path = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");
            configurationBuilder.AddJsonFile(path, false);

            var root = configurationBuilder.Build();
            flag_folder = root.GetSection("ApiConfig").GetSection("App_Flag_Folder").Value;
        }

        public int Id { get; set; }

        public string Destination { get; set; }

        public string Landline { get; set; }

        public string Mobile { get; set; }

        public string SMS { get; set; }

        public string ISOCode { get; set; }

        public string OffPeakLandline { get; set; }

        public string OffPeakMobile { get; set; }

        public string OffPeakSMS { get; set; }

        public bool isBundleAvailable { get; set; }
        public string BundleCountryCode { get; set; }

        public bool showOffpeak { get; set; }

        private string appToAppChat;

        private string flag_folder
        {
            get; set;
        }



        public string AppToAppChat
        {
            get
            {
                return "Free";
            }
            set { this.appToAppChat = value; }
        }

        private string appToAppCalls;

        public string AppToAppCalls
        {
            get
            {
                return "Free";
            }
            set { this.appToAppCalls = value; }
        }

        private string flagImageUrl;

        public string FlagImageUrl
        {
            get
            {
                var encodedDestination = this.Destination.Replace(" ", "%20");
                return String.Format(flag_folder + "{0}.png", encodedDestination);
            }
            set { this.flagImageUrl = value; }
        }
    }
}
