using DC.Core.Common.Definitions;

namespace DC.Infrastructure.Common.Middlewares;
internal class SecurityHeaderMiddleware
{
    private readonly RequestDelegate _next;
    private readonly SecurityHeaderSetting _SecurityHeaderetting;

    public SecurityHeaderMiddleware(RequestDelegate next, IOptions<SecurityHeaderSetting> options)
    {
        _next = next;
        _SecurityHeaderetting = options.Value;
    }
    public async Task Invoke(HttpContext context)
    {
        if (_SecurityHeaderetting?.Enable is true)
        {
            if (!context.Response.HasStarted)
            {
                if (!string.IsNullOrWhiteSpace(_SecurityHeaderetting.XFrameOptions))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.XFrameOptions, _SecurityHeaderetting.XFrameOptions);
                }

                if (!string.IsNullOrWhiteSpace(_SecurityHeaderetting.XContentTypeOptions))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.XContentTypeOptions, _SecurityHeaderetting.XContentTypeOptions);
                }

                if (!string.IsNullOrWhiteSpace(_SecurityHeaderetting.ReferrerPolicy))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.ReferrerPolicy, _SecurityHeaderetting.ReferrerPolicy);
                }

                if (!string.IsNullOrWhiteSpace(_SecurityHeaderetting.PermissionsPolicy))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.PermissionsPolicy, _SecurityHeaderetting.PermissionsPolicy);
                }

                if (!string.IsNullOrWhiteSpace(_SecurityHeaderetting.SameSite))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.SameSite, _SecurityHeaderetting.SameSite);
                }

                if (!string.IsNullOrWhiteSpace(_SecurityHeaderetting.XXSSProtection))
                {
                    context.Response.Headers.Append(AppConstants.SecurityHeader.XXSSProtection, _SecurityHeaderetting.XXSSProtection);
                }
            }
        }

        await _next(context);
    }
}
