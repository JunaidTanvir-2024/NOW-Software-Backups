using System.Globalization;
using System.Security.Claims;

using JM.Core.Entities;
using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Dtos.Auth;
using JM.Core.Utilities.Interfaces.Database;
using JM.Core.Utilities.Interfaces.Services;
using JM.Infrastructure.Persistence;
using JM.Infrastructure.Services.Http;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;

namespace JM.Infrastructure.Services.Identity;

internal sealed class IdentityService(
    SignInManager<User> signInManager,
    UserManager<User> userManager,
    AppDbContext context,
    IJwtService jwtService,
    IHttpContextAccessor httpContextAccessor,
    IOtpService otpService,
    IUnitOfWork unitOfWork,
    IHttpService httpService) : IIdentityService
{
    private readonly SignInManager<User> _signInManager = signInManager;
    private readonly UserManager<User> _userManager = userManager;
    private readonly AppDbContext _context = context;
    private readonly IJwtService _jwtService = jwtService;
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;
    private readonly IOtpService _otpService = otpService;
    private readonly IUnitOfWork _unitOfWork = unitOfWork;
    private readonly IHttpService _httpService = httpService;

    public async Task<LoginDto.Response> LoginAsync(LoginDto.Request request)
    {
        var loginResult = await _signInManager.PasswordSignInAsync(request.Username!, request.Password, request.RememberMe, lockoutOnFailure: request.LockoutOnFailure);

        if (loginResult.IsNotAllowed)
        {
            return new LoginDto.Response() { IsSuccess = false, IsNotAllowed = true };
        }
        if (loginResult.Succeeded)
        {
            var userInfo = await _unitOfWork.UserRepository.GetUser(x => x.Id == request.Id);

            var (jwtToken, jwtTokenExpiry, refreshToken, refreshTokenExpiry) = _jwtService.GetTokensAsync(userInfo?.UserName!, request.Email!, request.Id);

            userInfo!.RefreshToken = refreshToken;
            userInfo.RefreshTokenExpiry = refreshTokenExpiry;
            _unitOfWork.SaveChanges();

            _httpContextAccessor?.HttpContext?.Response.Cookies.Append("refreshToken", refreshToken);

            return new LoginDto.Response()
            {
                IsSuccess = true,
                IsNotAllowed = false,
                User = new LoginDto.Response.UserInfo()
                {
                    Email = request.Email!,
                    Country = userInfo?.UserDetail?.Country is not null ? new LoginDto.Response.CountryInfo()
                    {
                        Id = userInfo?.UserDetail?.Country?.Id ?? default,
                        IsoCode3 = userInfo?.UserDetail?.Country?.IsoCode3!,
                        Name = userInfo?.UserDetail?.Country?.Name!
                    } : default!,
                    FullName = userInfo?.UserDetail?.FullName ?? default!,
                    Id = request.Id,
                    ProfilePhoto = userInfo?.UserDetail?.ProfilePhoto ?? default!,
                    Username = request.Username,
                },
                Token = new LoginDto.Response.TokenInfo()
                {
                    JwtToken = jwtToken,
                    RefreshToken = refreshToken,
                    RefreshTokenExpiry = refreshTokenExpiry,
                    JwtTokenExpiry = jwtTokenExpiry
                }
            };
        }

        return new LoginDto.Response() { IsSuccess = false, IsNotAllowed = false };
    }
    public async Task<RegisterDto.Response> RegisterAsync(RegisterDto.Request request)
    {
        var identityUser = new Core.Entities.User()
        {
            Email = request.Email,
            UserName = GenerateUniqueUsernameFromEmail(request.Email),
            EmailConfirmed = request.IsSocialLogin
        };
        var signupResult = await _userManager.CreateAsync(identityUser, request.Password);

        if (request.IsSocialLogin)
        {
            // Use UserManager to manually add the external login
            var loginProviderName = Enum.GetName(typeof(AppEnum.LoginProvider), request.Provider);
            var info = new ExternalLoginInfo(new ClaimsPrincipal(), loginProviderName!, request.ProviderKey!, loginProviderName!);
            await _userManager.AddLoginAsync(identityUser, info);
        }

        if (signupResult.Succeeded)
        {
            return new RegisterDto.Response() { IsSuccess = true };
        }

        return new RegisterDto.Response() { IsSuccess = false };
    }

    public async Task<ResetPasswordDto.Response> ResetPassword(ResetPasswordDto.Request request)
    {
        var user = await _userManager.FindByEmailAsync(request.Email);

        if (user != null)
        {
            var removePasswordResult = await _userManager.RemovePasswordAsync(user);

            if (removePasswordResult.Succeeded)
            {
                var isNewPasswordSet = await _userManager.AddPasswordAsync(user, request.Password);
                if (isNewPasswordSet.Succeeded)
                {
                    return new ResetPasswordDto.Response() { IsSuccess = true };
                }
            }
            return new ResetPasswordDto.Response() { IsSuccess = false };
        }

        return new ResetPasswordDto.Response() { IsSuccess = false };
    }
    public static string GenerateUniqueUsernameFromEmail(string email)
    {
        // Extract the part before '@' from the email
        string usernameBase = email.Split('@')[0];

        // Remove spaces and special characters
        string cleanedName = new string(usernameBase
            .Where(c => Char.IsLetterOrDigit(c) || Char.IsWhiteSpace(c))
            .ToArray());

        // Make the syntax case
        string syntaxCaseName = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(cleanedName.ToLower());

        // Append a unique 4-digit number
        string uniqueNumber = Guid.NewGuid().ToString().GetHashCode().ToString("X").Substring(0, 4);

        // Combine the components to form the unique username
        string uniqueUsername = $"{syntaxCaseName}{uniqueNumber}";

        return uniqueUsername;
    }

    // private async Task<bool> ValidateGoogleToken(string token)
    // {
    //     try
    //     {
    //         // Make a request to Google's token validation endpoint
    //         var response = await _httpService.GetAsync($"https://www.googleapis.com/oauth2/v3/tokeninfo?id_token={token}");
    //         return true;
    //     }
    //     catch (HttpRequestException)
    //     {
    //         // Handle exception
    //         return false;
    //     }
    // }

    // private async Task<bool> ValidateAppleToken(string token)
    // {
    //     try
    //     {
    //         // Make a request to Apple's token validation endpoint
    //         var response = await _httpService.GetAsync($"https://appleid.apple.com/auth/keys");

    //         // Validate the token using Apple's public keys
    //         var appleTokenValidator = new AppleTokenValidator(response.Json);
    //         var audience = ""; // provide audience/client ID here
    //         return appleTokenValidator.Validate(token, audience);
    //     }
    //     catch (HttpRequestException)
    //     {
    //         // Handle exception
    //         return false;
    //     }
    // }
}

// public class AppleTokenValidator
// {
//     private readonly string _jwks;

//     public AppleTokenValidator(string jwks)
//     {
//         _jwks = jwks;
//     }

//     public bool Validate(string token, string audience)
//     {
//         var handler = new JwtSecurityTokenHandler();

//         // Configure the token validation parameters
//         var validationParameters = new TokenValidationParameters
//         {
//             ValidIssuer = "https://appleid.apple.com",
//             ValidAudience = audience,
//             IssuerSigningKeys = GetSigningKeys()
//         };

//         try
//         {
//             SecurityToken validatedToken;
//             handler.ValidateToken(token, validationParameters, out validatedToken);
//             return true;
//         }
//         catch (SecurityTokenException)
//         {
//             // Token validation failed
//             return false;
//         }
//     }

//     private IEnumerable<SecurityKey> GetSigningKeys()
//     {
//         var keys = new List<SecurityKey>();

//         // Iterate through the JWKS to extract and add the signing keys
//         foreach (var key in JsonDocument.Parse(_jwks).RootElement.GetProperty("keys").EnumerateArray())
//         {
//             var n = Base64UrlDecode(key.GetProperty("n").GetString());
//             var e = Base64UrlDecode(key.GetProperty("e").GetString());

//             var rsa = new RSAParameters { Modulus = n, Exponent = e };
//             var rsaKey = RSA.Create();
//             rsaKey.ImportParameters(rsa);

//             keys.Add(new RsaSecurityKey(rsaKey));
//         }

//         return keys;
//     }

//     private static byte[] Base64UrlDecode(string? input)
//     {
//         // Replace URL-safe characters and padding characters
//         input = input?.Replace('-', '+').Replace('_', '/');
//         if (!string.IsNullOrEmpty(input))
//         {

//             // Ensure that the length is a multiple of 4
//             int padding = input.Length % 4;
//             if (padding > 0)
//             {
//                 input += new string('=', 4 - padding);
//             }

//             return Convert.FromBase64String(input);
//         };
//         return default!;
//     }
// }
