﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Services.Payment
{
    public interface IPayPalService : ServiceType.ITransient
    {
        Task<PayPalPaymentResponseDto> CreateSalePayment(PaypalPaymentRequestDto request);
        Task<PayPalPaymentResponseDto> ExecuteSalePayment(
               string customerUniqueRef,
               string payerId,
               string paymentId);
    }
}
