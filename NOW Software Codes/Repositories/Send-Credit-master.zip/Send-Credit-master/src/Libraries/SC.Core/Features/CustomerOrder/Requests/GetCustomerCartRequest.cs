﻿using SC.Core.Common.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder.Requests;
public sealed class GetCustomerCartRequest : IRequest<IResultWrapper>
{
    public bool IsGuestUser { get; set; } = false;
    public string? UserID { get; set; } = default;

}
public sealed class GetCustomerCartRequestValidator : AbstractValidator<GetCustomerCartRequest>
{
    private readonly IHelperService _client;
    public GetCustomerCartRequestValidator(IHelperService client) {
        _client = client;
        RuleFor(x => x.UserID).MustAsync(async (userId, cancellation) => await _client.IsValidUserID(userId)).WithMessage("User ID does not exist in system, must be a valid user").When(x => x.IsGuestUser);
    }
}

