﻿using System;
using System.Threading.Tasks;
using TransferHome.Models.Contracts.InAppModels;
using TransferHome.Models.Contracts.Response;
using TransferHome.Models.Contracts.Service.Pay360ApiContracts;

namespace TransferHomeAPI.Infrastructure.Services.Interfaces
{
    public interface IPay360ServiceForInApp
    {
        Task<Tuple<GetCutomerInfoResponseModel, int>> GetCutomerInfo(int userId);
        Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType);
        string GetResumeUrl(string path, string baseUrl);
        Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Resume3DTransaction(Pay360Resume3DRequest request);
        Task<GenericPay360ApiResponse<RefundFullPaymentResponseModel>> RefundFullPayment(RefundFullPaymentRequestModel request);


        Pay360PaymentRequestNew CreatePay360PaymentRequestNew(InAppPay360CardPostModel model);
        Pay360PaymentRequestExistingNew CreatePay360PaymentRequestExistingNew(InAppPay360CardPostModel model);
        Pay360PaymentRequestToken CreatePay360PaymentRequestToken(InAppPay360CardPostModel model);
        Pay360PaymentBase CreatePay360PaymentBaseRequest(InAppPay360CardPostModel model);

    }
}
