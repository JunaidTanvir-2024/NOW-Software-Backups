using FH.Core.DTOs.Database;
using FH.UseCases.Operators;

using Mapster;
namespace FH.UseCases.Common.MappingProfiles;

public class OperatorProfiles : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        // Handler Query & Response should be as destination and DTOs Request & Responses should be on the right

        config.NewConfig<GetOperatorByName.Query, OperatorByNameDto.Request>()
        .TwoWays()
        .Map(des => des.OperatorName, src => src.OperatorName);

        config.NewConfig<GetOperatorByName.Response, OperatorDto.Response>()
        .TwoWays()
        .Map(des => des.OperatorId, src => src.Operator.Id)
        .Map(des => des.OperatorName, src => src.Operator.Name)
        .Map(des => des.Description, src => src.Operator.Description)
        .Map(des => des.CountryName, src => src.Operator.Country.Name)
        .Map(des => des.CountryIsoCode, src => src.Operator.Country.IsoCode);

        config.NewConfig<GetOperators.Response, OperatorDto.Response>()
        .TwoWays()
        .Map(des => des.OperatorId, src => src.Operator.Id)
        .Map(des => des.OperatorName, src => src.Operator.OperatorName)
        .Map(des => des.OperatorLogo, src => src.Operator.OperatorLogo)
        .Map(des => des.Description, src => src.Operator.Description)
        .Map(des => des.CountryIsoCode, src => src.Operator.Country.IsoCode);

        config.NewConfig<GetOperators.Query, OperatorDto.Request>()
            .TwoWays()
            .Map(des => des.Page, src => src.Page)
            .Map(des => des.RecordsPerPage, src => src.RecordsPerPage);
    }
}
