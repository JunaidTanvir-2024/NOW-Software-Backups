﻿using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Customers;

public class CustomerReferrals
{
    [JsonPropertyName("total")]
    public int Total { get; set; }
    [JsonExtensionData, JsonPropertyName("campaigns")]
    public Metadata? Campaigns { get; set; }
}
