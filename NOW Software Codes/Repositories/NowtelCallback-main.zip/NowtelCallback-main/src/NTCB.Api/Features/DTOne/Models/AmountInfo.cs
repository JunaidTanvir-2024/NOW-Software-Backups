﻿using System.Text.Json.Serialization;
namespace NTCB.Api.Features.DTOne.Models;

public class AmountInfo
{
    [JsonPropertyName("_base")]
    public int? Base { get; set; }
    
    [JsonPropertyName("promotion_bonus")]
    public int? PromotionBonus { get; set; }
    
    [JsonPropertyName("total_excluding_tax")]
    public int? TotalExcludingTax { get; set; }
    
    [JsonPropertyName("total_including_tax")]
    public float? TotalIncludingTax { get; set; }
}