﻿using Application.Features.Sim;

namespace Application.Features.Account.Product.Replace;
public class ReplaceProductRequest : IRequest<Result<object>>
{
    public SimAddressInfo AddressInfo { get; set; } = new SimAddressInfo();
    public string Msisdn { get; set; } = default!;

    [JsonIgnore]
    public string? IpAddress { get; set; }
}