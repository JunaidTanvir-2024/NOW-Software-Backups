using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;
public interface ICountryRepository : ResolveAs.IScoped
{
	Task<IEnumerable<Country>> GetCountries();
	Task<Country?> GetCountry(Expression<Func<Country, bool>> expression);
	Task AddCountryList(IEnumerable<Country> countries);
}
