﻿namespace SC.Core.Interfaces.Repositories;
public interface IUserRepository
{
    Task UserSignInLogInsertAsync(LoginLogDto logDto);
    Task<int> GetLoginFailedAttemps(string UserId, DateTime TimeSpan);
    Task UpdateUserAsync(string UserID, string User_Status, string UserToken, string TokenPurpose, UserTypeEnum userType);
    Task<GetUserDetailDto> GetUserDetailByUserID(string UserID);
    Task<bool> ÚpdateAccountDetail(UserAccountDto detail);
}

