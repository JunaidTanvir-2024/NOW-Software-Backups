﻿using System;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models
{
    
    public class Bundles
    {
        public Guid ID { get; set; }
        public string BrandedName { get; set; }
        public string Description { get; set; }
        public string PackageType { get; set; }
        public string PackageCategory { get; set; }
        public int TotalCostPence { get; set; }
        public int ChargePeriodDays { get; set; }
        public int Texts { get; set; }
        public int Seconds { get; set; }
        public int Minutes { get; set; }
        public string Remarks { get; set; }
        public string RemainingMinutes { get; set; }
        public DateTime Expiry { get; set; }
        public int ExpiryInDays { get; set; }
        public string bundleInfo { get; set; }
        public string CountryName { get; set; }
        public BundleCategory BundleCategory { get; set; }
        public BundleType BundleType { get; set; }
        public string BundleCategoryName { get; set; }
        public string BundleTypeName { get; set; }
        public Guid? TrialId { get; set; }
        public bool IsTrial { get; set; }
        public int TrialChargePeriodDays { get; set; }
        public int TrialMinutes { get; set; }
        public int OffPercentage { get; set; }
        public bool IsRenew { get; set; }
        public bool IsTrialMinutesExpired { get; set; }
        public int PaymentMethod { get; set; }
        public string CardMaskedPAN { get; set; }
        public bool IsLastRenewalFailed { get; set; }
    }
}
