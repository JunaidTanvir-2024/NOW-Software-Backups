﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request
{
    public class ProductAdditionRequest
    {
        /// <summary>
        /// This property may be Mobile number for THA(PIN), card number for THCC(PIN) or mobile number for THM(PUK)
        /// </summary>
        [Required]
        public string cardnumber { get; set; }

        /// <summary>
        /// This property will act as the PIN for THA & THCC or PUK code for THM
        /// </summary>
        [Required]
        public string pinnumber { get; set; }

        public int userid { get; set; }
    }
}
