using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;

public class LoyaltyCard
{
    [JsonPropertyName("points")]
    public int Points { get; set; }

    [JsonPropertyName("balance")]
    public int Balance { get; set; }

    [JsonPropertyName("next_expiration_date")]
    public string? NextExpirationDate { get; set; }

    [JsonPropertyName("next_expiration_points")]
    public int NextExpirationPoints { get; set; }
}