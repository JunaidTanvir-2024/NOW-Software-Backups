﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    public class Profile
    {
        public Profile()
        {
            firstName = lastName = email = imageUrl = string.Empty;
        }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string msisdn { get; set; }
        public int dobDay { get; set; }
        public int dobMonth { get; set; }
        public int dobYear { get; set; }
        public string imageUrl { get; set; }
        public bool emailVerified { get; set; }
        public bool IsProfileCompleted { get; set; } // Added to track profile complete event
        public DateTime registration_date { set; get; }
    }

    public class UserNotifications
    {

        public bool canEmail { get; set; }
        public bool canPush { get; set; }
        public bool canSms { get; set; }

    }
}
