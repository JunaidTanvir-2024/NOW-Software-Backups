using DC.Core.Common.Definitions;
using DC.Core.Common.Entities;
using DC.Core.Common.Extensions;
using DC.Core.Common.Interfaces.Database;

namespace DC.Infrastructure.Persistence.Repositories;

internal sealed class AppLoggerRepository(IConfiguration configuration, ILogger logger) : IAppLoggerRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private readonly ILogger _logger = logger;

    public async Task AppLogUpsertAsync(AppLogEntity appLogDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("request_timestamp", appLogDto.Timestamp);
                parameters.Add("request_path", appLogDto.RequestPath);
                parameters.Add("request_method", appLogDto.RequestMethod);
                parameters.Add("request_body", appLogDto.RequestBody);
                parameters.Add("response_body", appLogDto.ResponseBody);
                parameters.Add("status_code", appLogDto.StatusCode);
                parameters.Add("duration", appLogDto.Duration);
                parameters.Add("client_ip", appLogDto.ClientIP);
                parameters.Add("user_agent", appLogDto.UserAgent);
                parameters.Add("response_size", appLogDto.ResponseSize);
                parameters.Add("error_reason", appLogDto.ErrorReason);
                parameters.Add("correlation_id", appLogDto.CorrelationId);
                parameters.Add("headers", appLogDto.Headers);
                parameters.Add("query_string", appLogDto.QueryString);
                parameters.Add("unique_reference", appLogDto.UniqueReference);
                parameters.Add("product_code", appLogDto.ProductCode);
                parameters.Add("product_item_code", appLogDto.ProductItemCode);

                await connection.ExecuteAsync(AppConstants.Database.StoreProcedure.AppLogUpsert, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, "LoggerRepository", "AppLogUpsertAsync");
        }
    }
    public async Task VendorLogInsertAsync(VendorLogEntity vendorLogDto)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var parameters = new DynamicParameters();
                parameters.Add("request_timestamp", vendorLogDto.Timestamp);
                parameters.Add("request_path", vendorLogDto.RequestPath);
                parameters.Add("request_method", vendorLogDto.RequestMethod);
                parameters.Add("request_body", vendorLogDto.RequestBody);
                parameters.Add("response_body", vendorLogDto.ResponseBody);
                parameters.Add("status_code", vendorLogDto.StatusCode);
                parameters.Add("duration", vendorLogDto.Duration);
                parameters.Add("response_size", vendorLogDto.ResponseSize);
                parameters.Add("error_reason", vendorLogDto.ErrorReason);
                parameters.Add("correlation_id", vendorLogDto.CorrelationId ?? Guid.NewGuid().ToString());
                parameters.Add("headers", vendorLogDto.Headers);
                parameters.Add("query_string", vendorLogDto.QueryString);
                parameters.Add("vendor_id", vendorLogDto.VendorId);
                await connection.ExecuteAsync(AppConstants.Database.StoreProcedure.VendorLogInsert, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(AppLoggerRepository), nameof(VendorLogInsertAsync));
        }
    }
}
