﻿using ATT.Models.Contracts.Sochitel.Request;


namespace ATT.Infrastructure.BLL.Sochitel
{
    public interface ISochiTelAuth_BL
    {
        Auth getAuthJSONObject(string currency);
        string[] GetSochitelAttCredentials(string currency);
    }
}
