﻿namespace THCC.Application.Features.Invoice;

public class InvoiceRequest:IRequest<object>
{
    public string EmailAddress { get; set; } = default!;
    public string ReferenceId { get; set; } = default!;
}

public class InvoiceRequestValidator : AbstractValidator<InvoiceRequest>
{
    public InvoiceRequestValidator()
    {
        RuleFor(p => p.ReferenceId)
            .NotNull()
            .NotEmpty();
    }
}
