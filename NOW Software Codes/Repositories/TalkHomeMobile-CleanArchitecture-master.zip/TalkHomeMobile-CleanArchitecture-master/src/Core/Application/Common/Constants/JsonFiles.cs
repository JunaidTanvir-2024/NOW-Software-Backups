﻿namespace Application.Common.Constants;
public static class JsonFiles
{
    public const string FolderName = "Configurations";
    public const string AppSettings = "appsettings";
    public const string Rating = "rating";
    public const string Logger = "logger";
    public const string Cache = "cache";
    public const string Database = "database";
    public const string Mail = "mail";
    public const string Middleware = "middleware";
    public const string Security = "security";
    public const string OpenApi = "openapi";
    public const string SecurityHeaders = "securityheaders";
    public const string Sms = "sms";
    public const string Common = "common";
    public const string Payment = "payment";
    public const string ConversionTracking = "conversiontracking";
    public const string InAppReceipt = "inappreceipt";
    public const string Integration = "integration";
}