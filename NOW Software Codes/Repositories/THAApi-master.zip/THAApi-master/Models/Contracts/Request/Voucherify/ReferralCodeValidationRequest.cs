﻿namespace Models.Contracts.Request.Voucherify
{
    public class ReferralCodeValidationRequest
    {
        public string ReferralCode { get; set; }
    }
}
