﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmsOutReachCallBackUrlApi.Models.Configurations
{
    public class ConnectionString
    {
        public string DefaultConnection { get; set; }
        public string SapDbConnection { get; set; }
        
    }
}
