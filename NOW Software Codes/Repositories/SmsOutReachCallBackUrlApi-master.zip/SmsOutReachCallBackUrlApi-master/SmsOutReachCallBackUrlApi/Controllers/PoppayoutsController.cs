﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using SmsOutReachCallBackUrlApi.Contracts.Poppayouts.Request;
using SmsOutReachCallBackUrlApi.Infrastructure.Poppayouts;
using SmsOutReachCallBackUrlApi.Models;

namespace SmsOutReachCallBackUrlApi.Controllers
{
    public class PoppayoutsController : Controller
    {
        private readonly ILogger Logger;
        private IPoppayoutsPost PoppayoutsPost;

        public PoppayoutsController(ILogger logger, IPoppayoutsPost poppayoutsPost)
        {
            Logger = logger;
            PoppayoutsPost = poppayoutsPost;
        }


        [HttpPost]
        async public Task<IActionResult> SmsCallBackUrl()
        {

            Logger.Information($"Processing - Post: Poppayouts/SmsCallBackUrl ");
            string requestJsonData = "";
            try
            {

                using (StreamReader reader = new StreamReader(Request.Body, Encoding.UTF8))
                {
                    requestJsonData = await reader.ReadToEndAsync();
                }
                PoppayoutsSmsCallBackUrlRequest deliveryReport;
                if (requestJsonData.Contains("["))
                {
                    deliveryReport = JsonConvert.DeserializeObject<PoppayoutsSmsCallBackUrlRequest>(requestJsonData);
                }
                else
                {
                    deliveryReport = new PoppayoutsSmsCallBackUrlRequest();
                    if (requestJsonData!="")
                    {
                        PoppayoutsSmsCallBackUrlRequest req = JsonConvert.DeserializeObject<PoppayoutsSmsCallBackUrlRequest>(requestJsonData);
                        deliveryReport = req;
                    }
                    else
                    {
                        return BadRequest();
                    }
                }
                DbResult result = await PoppayoutsPost.InsertUpdateSmsCallBackUrlData(deliveryReport);
                if (result.DBStatus == 1)
                {
                    return Ok("Success");
                }
                else
                {
                    Logger.Error($"Exception - Post: Poppayouts/SmsCallBackUrl, Parameters --> SmsCallBackUrlJson: {requestJsonData}, ExceptionMessage: {result.DBErrorMessage}");
                    return StatusCode((int)HttpStatusCode.InternalServerError, result.DBErrorMessage);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Exception - Post: Poppayouts/SmsCallBackUrl, Parameters --> SmsCallBackUrlJson: {requestJsonData}, ExceptionMessage: {ex.Message}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }

        }
    }
}