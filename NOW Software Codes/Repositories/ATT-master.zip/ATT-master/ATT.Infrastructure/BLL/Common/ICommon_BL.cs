﻿using ATT.Models.Contracts.Common;
using ATT.Models.Contracts.Reloadly;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Twilio.Rest.Api.V2010.Account;

namespace ATT.Infrastructure.BLL.Common
{
    public interface ICommon_BL
    {
        Task<decimal> GetDiscountSettings(string productCode, string productItemCode, string toMsisdn, string fromMsisdn, decimal amount);
        Task<bool> SendEmail(EmailTransactionModel transactionModel);
        Task SendTwilioSms(string to, string textMessage, string productCode = null, bool isOptionMessage = false);
        string AesEncrypt(string text);
        string AesDecrypt(string encryptedText);
        Task<MessageResource> SendTwilioSmsWithCallback(string to, string textMessage, string productCode = null, bool isOptionMessage = false);

    }
}
