﻿using PayPalInApp.Models.Enums;
using PayPalInApp.Models.Payments;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PayPalInApp.Models
{
    public class AutoTopUpResponse
    {
        public string thresHold { get; set; }
        public string topup { get; set; }
        public bool status { get; set; }
    }

    public class Pay360CustomerRequestModel
    {
        public string msisdn { get; set; }
    }

    public class TopUpViewModel
    {
        public string Msisdn { get; set; }
        public string NSId { get; set; }
        public string Currency { get; set; }
        public TopUpMethod Method { get; set; }
        public int Amount { get; set; }
        public List<I18nCountry> Countries { get; set; }
        public AddressModel Address { get; set; }
        public NameDetails NameDetails { get; set; }
        public MiPayCustomerModel MiPayCustomer { get; set; }
        public Pay360CustomerModel Pay360Customer { get; set; }
        public string CustId { get; set; }
        public PaymentProvider Provider { get; set; }
        public AutoTopUpResponse AutoTopUpViewModel { get; set; }

        public TopUpViewModel()
        {

        }

    }

    public class NameDetails
    {
        [Required(ErrorMessage = "First name required")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Last name required")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Email address required")]
        public string EmailAddress { get; set; }
    }

    public enum TopUpMethod
    {
        Voucher,
        Card,
        Paypal,
        Call
    }

    public class I18nCountry
    {
        public I18nCountryName name { get; set; }

        public string cca2 { get; set; }

        public string ccn3 { get; set; }

        public string cca3 { get; set; }

        public string cioc { get; set; }
    }

    public class I18nCountryName
    {
        public string common { get; set; }
    }

    public class AddressModel
    {
        [CustomValidation(typeof(RequestValidations), "AddressLine1")]
        public string addressL1 { get; set; }

        public string addressL2 { get; set; }


        [Required(ErrorMessage = "City is required")]
        public string city { get; set; }

        public string county { get; set; }

        [CustomValidation(typeof(RequestValidations), "PostCode")]
        public string postCode { get; set; }

        [CustomValidation(typeof(RequestValidations), "CountryCode")]
        public string country { get; set; }

        public AddressModel()
        {
        }

        public AddressModel(string addressL1, string addressL2, string city, string county, string postCode, string country)
        {
            this.addressL1 = addressL1;

            this.addressL2 = addressL2;

            this.city = city;

            this.county = county;

            this.postCode = postCode;

            this.country = country;
        }

        /// <summary>
        /// Provides ToString() override for display purposes
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return string.Join(", ",
                !string.IsNullOrWhiteSpace(addressL1) ? addressL1 : "",
                !string.IsNullOrWhiteSpace(addressL2) ? addressL2 : "",
                !string.IsNullOrWhiteSpace(city) ? city : "",
                !string.IsNullOrWhiteSpace(county) ? county : "",
                !string.IsNullOrWhiteSpace(postCode) ? postCode : "");
        }
    }

    public class PaypalStartPaymentModel
    {
        public string currency { get; set; }
        public string msisdn { get; set; }
        public string language { get; set; }
        public float amount { get; set; }
        public string utm_campaign { get; set; }
        public string utm_medium { get; set; }
        public string utm_source { get; set; }
    }

    public class PaypalTopUpViewModel
    {
        public string currency { get; set; }
        public string msisdn { get; set; }
        public string language { get; set; }
        public string utm_campaign { get; set; }
        public string utm_medium { get; set; }
        public string utm_source { get; set; }
    }

    public class SuccessReturnPayPalViewModel
    {
        public string paymentId { get; set; }
        public string token { get; set; }
        public string PayerID { get; set; }
        public string reference { get; set; }
        public string amount { get; set; }
        public string currency { get; set; }
        public string transactionId { get; set; }
        public string utm_campaign { get; set; }
        public string utm_medium { get; set; }
        public string utm_source { get; set; }
    }
}
