﻿using Application.Common.Interfaces.Infrastructure.Identity;

namespace Application.Features.Account.Product.Add;
public class AddProductRequestHandler : IRequestHandler<AddProductRequest, Result<object>>
{
    #region Fields

    private readonly IStringLocalizer<AddProductRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly IOtpService _otpService;
    private readonly ISmsService _smsService;

    #endregion

    #region Ctor

    public AddProductRequestHandler(
        IStringLocalizer<AddProductRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService,
        IOtpService otpService,
        ISmsService smsService
      )
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _otpService = otpService;
        _smsService = smsService;
    }

    #endregion

    #region Method

    public async Task<Result<object>> Handle(AddProductRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        //Check number is valid THM number
        var msisdn = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdn == null)
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Check number msisdn is not already attached
        if (await _unitOfWork.UserRepo.IsProductAlreadyAttached(request.Msisdn))
        {
            return Result<object>.Failure(
                _localizer[CustomStatusKey.MsisdnAlreadyRegistered], CustomStatusCode.MsisdnAlreadyRegistered);
        }

        //Crete verification Otp
        var (Otp, otpModel) = await _otpService.CreateOtp(request.Msisdn, OtpType.AddProduct, false);
        if (otpModel.StatusCode != CustomStatusCode.OtpIsNotCreated)
        {
            await _smsService.SendOtpMessage(request.Msisdn, Otp.ToString());
        }

        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
