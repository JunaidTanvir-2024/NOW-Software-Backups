﻿using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface IPush_DL
    {
        Task<GenericResult<bool>> AddPushToTagsRequest(SendPushToTagsRequest request, ApiPushResponse apiResponseModel, string airShipRequestJson, HttpStatusCode statusCode);
        Task<GenericResult<bool>> AddPushToTagsRequestError(SendPushToTagsRequest request, string airShipResponseJson, string airShipRequestJson, HttpStatusCode statusCode);
        Task<GenericResult<bool>> AddPushToNamedUser(SendPushToNamedUserRequest request, ApiPushResponse apiResponseModel, string airShipRequestJson, HttpStatusCode statusCode);
        Task<GenericResult<bool>> AddPushToNamedUserError(SendPushToNamedUserRequest request, string airShipResponseJson, string airShipRequestJson, HttpStatusCode statusCode);
    }
}
