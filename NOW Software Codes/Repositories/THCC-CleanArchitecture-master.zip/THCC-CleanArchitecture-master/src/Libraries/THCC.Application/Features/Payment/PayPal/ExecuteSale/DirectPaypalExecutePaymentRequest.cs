﻿namespace THCC.Application.Features.Payment.PayPal.ExecuteSale
{
    public class DirectPaypalExecutePaymentRequest : IRequest<object>
    {
        public string PayerId { get; set; } = default!;
        public string PaymentId { get; set; } = default!;
        public long OrderId { get; set; }
    }

    public class DirectPaypalExecutePaymentRequestValidator : AbstractValidator<DirectPaypalExecutePaymentRequest>
    {
        public DirectPaypalExecutePaymentRequestValidator()
        {
            RuleFor(p => p.PayerId)
                 .NotEmpty()
                 .NotNull();

            RuleFor(p => p.PaymentId)
                 .NotEmpty()
                 .NotNull();
        }
    }
}
