﻿
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PaymentsApi.Infrastructure.BLL.Interfaces.Pay360;
using PaymentsApi.Infrastructure.DAL.Database;
using PaymentsApi.Infrastructure.DAL.Interfaces;
using PaymentsApi.Models.Configurations;
using PaymentsApi.Models.Contracts;
using PaymentsApi.Models.Contracts.Pay360.Request.Api;
using PaymentsApi.Models.Contracts.Pay360.Request.User;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using PaymentsApi.Models.Utility;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace PaymentsApi.Infrastructure.BLL.Implementation.Pay360
{
    public class BL_Pay360CommonServices : BL_IPay360CommonServices
    {
        private Pay360Config Pay360Configurations;
        private DL_IPay360 Db;
        private IApiCall ApiCall;
        private BL_IPay360CashierApi BlPay360CashierApi;
        private readonly IPay360Auth pay360Auth;

        public BL_Pay360CommonServices(
            ILogger logger,
            DL_IPay360 db,
            IOptions<Pay360Config> pay360Config,
            IApiCall apiCall,
            BL_IPay360CashierApi blPay360CashierApi,
            IPay360Auth pay360Auth)
        {
            Pay360Configurations = pay360Config.Value;
            Db = db;
            this.ApiCall = apiCall;
            BlPay360CashierApi = blPay360CashierApi;
            this.pay360Auth = pay360Auth;
        }

        public async Task<GenericApiResponse<ApiPaymentResponse>> CaptureTransaction(UserRequestCaptureOrCancelTransaction userRequest)
        {
            GenericApiResponse<ApiPaymentResponse> response;
            string requestJson = "";
            try
            {
                var transactionToBeCaptured = await Db.GetTransactionByPay360TransactionId(userRequest.TransactionId);

                if (transactionToBeCaptured == null)
                {
                    return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction not found", 20);
                }
                requestJson = JsonConvert.SerializeObject(userRequest);
                var creds = pay360Auth.GetApiCredsByInstallationId(transactionToBeCaptured.ApiInstallationIdCashierApi);
                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/" + userRequest.TransactionId + "/capture";
                var apiResponse = await ApiCall.Post(apiEndPoint, new { transaction = new { merchantRef = transactionToBeCaptured.TransactionMerchantRef } }, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                string responseJson = "";
                if (apiResponse.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    responseJson = apiResponse.Content.ReadAsStringAsync().Result;
                    ApiPaymentResponse apiResponseModel = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);
                    //response = GenericApiResponse<UserResponseModels>.Success(apiResponseModel, "Transaction captured successfully");

                    #region TransactionModelInitialisation
                    Pay360Transaction transaction = CreateDbTransactionObject(apiResponseModel, transactionToBeCaptured.Customer_Id, creds.ApiInstallationIdCashierApi);
                    #endregion
                    transaction.RequestJsonToPay360 = requestJson;
                    transaction.ResponseJsonFromPay360 = responseJson;

                    DbResult<long> result = await Db.AddTransactionWithoutBasket(transaction); /// 

                    if (apiResponseModel.Outcome.Status.ToLower() != "success")
                    {
                        return response = GenericApiResponse<ApiPaymentResponse>.Failure("Payment Capture Failed", 12);
                    }

                    if (result.DBStatus != 1)
                    {
                        return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction Successful but not updated in database table", 11);
                    }
                    //Update TransactionSummary 
                    DbResult<int> resultUpdate = await Db.UpdateTransactionSummary(userRequest.TransactionId, result.Data, Pay360SummaryTransactionStatuses.CAPTURE, DateTime.UtcNow, false);
                    if (resultUpdate.DBStatus != 1)
                    {
                        return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction Successful but not updated in Summary table", 11);
                    }

                    Pay360TransactionSummary pay360TransactionSummary = await Db.GetTransactionSummaryByPay360TransactionId(userRequest.TransactionId);

                    UserResponseModels userResponse = new UserResponseModels()
                    {
                        //CustomerId = apiResponse.Customer.Id.ToString(),
                        TransactionAmount = apiResponseModel.Transaction.Amount.ToString(),
                        TransactionId = apiResponseModel.Transaction.TransactionId,
                        ThreeDSecure = apiResponseModel.ThreeDSecure,
                        OutcomeModel = new OutcomeModel() { ReasonCode = apiResponseModel.Outcome.ReasonCode, ReasonMessage = apiResponseModel.Outcome.ReasonMessage, Status = apiResponseModel.Outcome.Status }
                    };

                    if (pay360TransactionSummary.IsDirectFullfilment == true)
                    {
                        // Fullfilment
                        //return response = await BlPay360CashierApi.Fullfilment(userResponse, transactionToBeCaptured.Pay360TransactionId, transactionToBeCaptured.Id.ToString(), transactionToBeCaptured.TransactionCurrency, pay360TransactionSummary.CustomerMerchantRef, transactionToBeCaptured.Msisdn);
                        GenericApiResponse<UserResponseModels> fullfilmentResponse = await BlPay360CashierApi.Fullfilment(userResponse, transactionToBeCaptured.Pay360TransactionId, transactionToBeCaptured.Id.ToString(), transactionToBeCaptured.TransactionCurrency, pay360TransactionSummary.CustomerMerchantRef, "", transactionToBeCaptured.Msisdn);
                        if (fullfilmentResponse.errorCode == 0) // Fullfilment Successfull
                        {
                            apiResponseModel.BasketResponse = fullfilmentResponse.payload.BasketResponse;
                            return response = GenericApiResponse<ApiPaymentResponse>.Success(apiResponseModel, "Transaction captured successfully");
                        }
                        else // Fullfilment failure
                        {
                            return response = GenericApiResponse<ApiPaymentResponse>.Failure("Fullfilment Error. " + fullfilmentResponse.message, fullfilmentResponse.errorCode);
                        }
                    }

                    response = GenericApiResponse<ApiPaymentResponse>.Success(apiResponseModel, "Transaction captured successfully");
                }
                else
                {
                    //Update TransactionSummary status as capture failed
                    Pay360Transaction dbTransaction = new Pay360Transaction();
                    dbTransaction.RelatedTransactionId = userRequest.TransactionId;
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = await apiResponse.Content.ReadAsStringAsync();
                    dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    dbTransaction.TransactionType_Id = (int)Pay360TransactionTypes.CAPTURE;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;

                    DbResult<long> result = await Db.AddTransactionWithoutBasket(dbTransaction, Pay360SummaryTransactionTypes.CAPTURE, false);
                    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();

                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<ApiPaymentResponse>.Failure(result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }
                    DbResult<int> resultUpdate = await Db.UpdateTransactionSummary(userRequest.TransactionId, 0, Pay360SummaryTransactionStatuses.CAPTUREFAILED, DateTime.UtcNow, true);
                    if (resultUpdate.DBStatus != 1)
                    {
                        response = GenericApiResponse<ApiPaymentResponse>.Failure("Capture Failed and error in Summary table updation", 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    string resonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    response = GenericApiResponse<ApiPaymentResponse>.Failure(resonMessage, 12);
                    response.pay360ApiCode = reasonCode;
                }

            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public async Task<GenericApiResponse<ApiPaymentResponse>> CancelTransaction(UserRequestCaptureOrCancelTransaction userRequest)
        {

            GenericApiResponse<ApiPaymentResponse> response;
            string requestJson = "";
            try
            {
                var transactionToBeCancelled = await Db.GetTransactionByPay360TransactionId(userRequest.TransactionId);

                if (transactionToBeCancelled == null)
                {
                    return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction not found", 20);
                }
                requestJson = JsonConvert.SerializeObject(userRequest);
                var creds = pay360Auth.GetApiCredsByInstallationId(transactionToBeCancelled.ApiInstallationIdCashierApi);
                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/" + userRequest.TransactionId + "/cancel";
                var apiResponse = await ApiCall.Post(apiEndPoint, new { transaction = new { merchantRef = transactionToBeCancelled.TransactionMerchantRef } }, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                string responseJson = "";
                if (apiResponse.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    responseJson = apiResponse.Content.ReadAsStringAsync().Result;
                    ApiPaymentResponse apiResponseModel = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);
                    response = GenericApiResponse<ApiPaymentResponse>.Success(apiResponseModel, "Transaction cancelled successfully");

                    #region TransactionModelInitialisation
                    Pay360Transaction transaction = CreateDbTransactionObject(apiResponseModel, transactionToBeCancelled.Customer_Id, creds.ApiInstallationIdCashierApi);
                    #endregion
                    transaction.RequestJsonToPay360 = requestJson;
                    transaction.ResponseJsonFromPay360 = responseJson;
                    DbResult<long> result = await Db.AddTransactionWithoutBasket(transaction);
                    if (result.DBStatus != 1)
                    {
                        return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction cancelled but not saved in transaction", 11);
                    }
                    DbResult<int> resultUpdate = await Db.UpdateTransactionSummaryStatus(userRequest.TransactionId, result.Data, transaction.TransactionTime.Value, Pay360SummaryTransactionStatuses.CANCEL);
                    if (resultUpdate.DBStatus != 1)
                    {
                        return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction cancelled but not updated in transactionsummary", 11);
                    }
                }
                else
                {

                    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                    Pay360Transaction dbTransaction = new Pay360Transaction();
                    dbTransaction.Customer_Id = transactionToBeCancelled.Customer_Id;
                    dbTransaction.RelatedTransactionId = userRequest.TransactionId;
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = jsonResult;
                    dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    dbTransaction.TransactionType_Id = (int)Pay360TransactionTypes.CANCEL;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    dbTransaction.OutcomeReasonMessage = reasonMessage;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                    DbResult<long> result = await Db.AddTransactionWithoutBasket(dbTransaction, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_NEWCARD, false);
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();

                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<ApiPaymentResponse>.Failure(result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }
                    DbResult<int> resultUpdate = await Db.UpdateTransactionSummary(userRequest.TransactionId, 0, Pay360SummaryTransactionStatuses.CANCELFAILED, DateTime.UtcNow, true);
                    if (resultUpdate.DBStatus != 1)
                    {
                        response = GenericApiResponse<ApiPaymentResponse>.Failure("Cancel Failed and error in Summary table updation", 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }
                    response = GenericApiResponse<ApiPaymentResponse>.Failure(reasonMessage, 12);
                    response.pay360ApiCode = reasonCode;
                }

            }
            catch (Exception ex)
            {
                throw;
            }
            return response;
        }

        public async Task<GenericApiResponse<ApiPaymentResponse>> RefundFullPayment(UserRequestRefundFullPayment userRequest)
        {
            GenericApiResponse<ApiPaymentResponse> response;
            string requestJson = "";
            try
            {
                var transactionToBeRefunded = await Db.GetTransactionByPay360TransactionId(userRequest.TransactionId);

                if (transactionToBeRefunded == null)
                {
                    return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction not found", 20);
                }

                var creds = pay360Auth.GetApiCredsByInstallationId(transactionToBeRefunded.ApiInstallationIdCashierApi);

                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/" + userRequest.TransactionId + "/refund";

                HttpResponseMessage apiResponse;
                var refundRequest = new FullRefundModel()
                {
                    Transaction = new FullRefundTransactionModel() { MerchantRef = transactionToBeRefunded.TransactionMerchantRef }
                };
                requestJson = JsonConvert.SerializeObject(refundRequest);
                try
                {
                    apiResponse = await ApiCall.Post(apiEndPoint, refundRequest, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));
                }
                catch (Exception)
                {
                    await SaveFailedTransactionApiError(Pay360TransactionStatuses.ERROR, transactionToBeRefunded.Customer_Id, PaymentMethods.Card, Pay360TransactionTypes.REFUND, creds.ApiInstallationIdCashierApi);

                    throw;
                }
                string responseJson = "";
                if (apiResponse.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    responseJson = apiResponse.Content.ReadAsStringAsync().Result;
                    ApiPaymentResponse apiResponseModel = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);
                    response = GenericApiResponse<ApiPaymentResponse>.Success(apiResponseModel, "Amount has been refunded successfully");

                    Pay360Transaction transaction = CreateDbTransactionObject(apiResponseModel, transactionToBeRefunded.Customer_Id, creds.ApiInstallationIdCashierApi);
                    transaction.RequestJsonToPay360 = requestJson;
                    transaction.ResponseJsonFromPay360 = responseJson;
                    DbResult<long> result = await Db.AddTransactionWithoutBasket(transaction);
                    if (result.DBStatus != 1)
                    {
                        return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction Successful but not updated in Transaction table", 11);
                    }
                    DbResult<int> resultUpdate = await Db.UpdateTransactionSummaryStatus(userRequest.TransactionId, result.Data, transaction.TransactionTime.Value, Pay360SummaryTransactionStatuses.FULLREFUND);
                    if (resultUpdate.DBStatus != 1)
                    {
                        return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction Successful but not updated in transaction summary table", 11);
                    }
                }
                else
                {
                    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                    Pay360Transaction dbTransaction = new Pay360Transaction();
                    dbTransaction.Customer_Id = transactionToBeRefunded.Customer_Id;
                    dbTransaction.RelatedTransactionId = userRequest.TransactionId;
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = jsonResult;
                    dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    dbTransaction.TransactionType_Id = (int)Pay360TransactionTypes.REFUND;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    dbTransaction.OutcomeReasonMessage = reasonMessage;
                    DbResult<long> result = await Db.AddTransactionWithoutBasket(dbTransaction, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_NEWCARD, false);
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();

                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<ApiPaymentResponse>.Failure(result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<ApiPaymentResponse>.Failure(reasonMessage, 12);
                    response.pay360ApiCode = reasonCode;
                }
                //else
                //{
                //    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                //    string resonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                //    response = GenericApiResponse<ApiPaymentResponse>.Failure(resonMessage);
                //}

            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public async Task<GenericApiResponse<ApiPaymentResponse>> RefundPartialPayment(UserRequestRefundPartialPayment userRequest)
        {

            GenericApiResponse<ApiPaymentResponse> response;
            string requestJson = "";
            try
            {

                var transactionToBeRefunded = await Db.GetTransactionByPay360TransactionId(userRequest.TransactionId);

                if (transactionToBeRefunded == null)
                {
                    return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction not found", 20);
                }
                var creds = pay360Auth.GetApiCredsByInstallationId(transactionToBeRefunded.ApiInstallationIdCashierApi);
                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/transactions/" + creds.ApiInstallationIdCashierApi + "/" + userRequest.TransactionId + "/refund";
                var requestModel = new PartialRefundModel { Transaction = new PartialRefundTransactionModel { Amount = userRequest.Amount, Currency = userRequest.Currency, MerchantRef = transactionToBeRefunded.TransactionMerchantRef } };
                requestJson = JsonConvert.SerializeObject(requestModel);
                HttpResponseMessage apiResponse;

                try
                {
                    apiResponse = await ApiCall.Post(apiEndPoint, requestModel, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));

                }
                catch (Exception)
                {
                    await SaveFailedTransactionApiError(Pay360TransactionStatuses.ERROR, transactionToBeRefunded.Customer_Id, PaymentMethods.Card, Pay360TransactionTypes.REFUND, requestModel.Transaction.Amount, requestModel.Transaction.Currency, creds.ApiInstallationIdCashierApi);

                    throw;
                }

                string responseJson = "";
                if (apiResponse.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    responseJson = apiResponse.Content.ReadAsStringAsync().Result;
                    ApiPaymentResponse apiResponseModel = JsonConvert.DeserializeObject<ApiPaymentResponse>(responseJson);
                    response = GenericApiResponse<ApiPaymentResponse>.Success(apiResponseModel, "Amount has been refunded successfully");

                    Pay360Transaction transaction = CreateDbTransactionObject(apiResponseModel, transactionToBeRefunded.Customer_Id, creds.ApiInstallationIdCashierApi);
                    transaction.RequestJsonToPay360 = requestJson;
                    transaction.ResponseJsonFromPay360 = responseJson;
                    DbResult<long> result = await Db.AddTransactionWithoutBasket(transaction);
                    if (result.DBStatus != 1)
                    {
                        return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction Successful but not updated in transaction table", 11);
                    }
                    DbResult<int> resultUpdate = await Db.UpdateTransactionSummaryStatus(userRequest.TransactionId, result.Data, transaction.TransactionTime.Value, Pay360SummaryTransactionStatuses.PARTIALREFUND);
                    if (resultUpdate.DBStatus != 1)
                    {
                        return response = GenericApiResponse<ApiPaymentResponse>.Failure("Transaction successful but not updated in transaction summary", 11);
                    }
                }
                else
                {
                    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                    Pay360Transaction dbTransaction = new Pay360Transaction();
                    dbTransaction.Customer_Id = transactionToBeRefunded.Customer_Id;
                    dbTransaction.RelatedTransactionId = userRequest.TransactionId;
                    dbTransaction.RequestJsonToPay360 = requestJson;
                    dbTransaction.ResponseJsonFromPay360 = jsonResult;
                    dbTransaction.PaymentMethod_Id = (int)PaymentMethods.Card;
                    dbTransaction.TransactionStatus_Id = (int)Pay360TransactionStatuses.ERROR;
                    dbTransaction.TransactionType_Id = (int)Pay360TransactionTypes.REFUND;
                    dbTransaction.RequestTime = DateTime.UtcNow;
                    string reasonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    dbTransaction.OutcomeReasonMessage = reasonMessage;
                    dbTransaction.ApiInstallationIdCashierApi = creds.ApiInstallationIdCashierApi;
                    DbResult<long> result = await Db.AddTransactionWithoutBasket(dbTransaction, Pay360SummaryTransactionTypes.EXISTINGCUSTOMER_NEWCARD, false);
                    string reasonCode = UtilityFunctions.GetJsonObjectValueByKey("reasonCode", jsonResult).Trim();

                    if (result.DBStatus != 1)
                    {
                        response = GenericApiResponse<ApiPaymentResponse>.Failure(result.DBErrorMessage, 13);
                        response.pay360ApiCode = reasonCode;
                        return response;
                    }

                    response = GenericApiResponse<ApiPaymentResponse>.Failure(reasonMessage, 12);
                    response.pay360ApiCode = reasonCode;
                }

                //else
                //{
                //    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                //    string resonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                //    response = GenericApiResponse<ApiPaymentResponse>.Failure(resonMessage);
                //}

            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        #region PaymentMethods Utilites

        public async Task<GenericApiResponse<UserPaymentMethodsResponse>> GetCustomerPaymentMethodsByCustomerUniqueRef(UserRequestGetCustomerPaymentMethodsByCustomerUniqueRef userRequest)
        {
            GenericApiResponse<UserPaymentMethodsResponse> response;
            try
            {
                string customerMerchantReference;

                if (userRequest.ProductCode.ToLower() == "tha")
                {
                    customerMerchantReference = userRequest.CustomerUniqueRef;
                }
                else
                {
                    customerMerchantReference = userRequest.ProductCode + "_" + userRequest.CustomerUniqueRef;
                }

                Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);
                if (customer != null && customer.Pay360CustId > 0)
                {
                    var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(customer.Msisdn, userRequest.ProductCode, nameof(Pay360PaymentType.CARD));

                    string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/customers/" + creds.ApiInstallationIdCashierApi + "/" + customer.Pay360CustId + "/paymentMethods";
                    var apiResponse = await ApiCall.Get(apiEndPoint, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));

                    if (apiResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        var apiPaymentMethodsResponse = JsonConvert.DeserializeObject<List<PaymentMethodResponseModel>>(apiResponse.Content.ReadAsStringAsync().Result);
                        UserPaymentMethodsResponse userPaymentMethodsResponse = new UserPaymentMethodsResponse();
                        userPaymentMethodsResponse.paymentMethodResponses = apiPaymentMethodsResponse;
                        response = GenericApiResponse<UserPaymentMethodsResponse>.Success(userPaymentMethodsResponse, "Payment Methods Retrieved successfully");
                    }
                    else if (apiResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        OutcomeModel outcomeResponse = JsonConvert.DeserializeObject<OutcomeModel>(apiResponse.Content.ReadAsStringAsync().Result);
                        response = GenericApiResponse<UserPaymentMethodsResponse>.Failure(outcomeResponse.ReasonMessage, 12);
                    }
                    else
                    {
                        string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                        string resonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                        response = GenericApiResponse<UserPaymentMethodsResponse>.Failure(resonMessage, 12);
                    }
                }
                else
                {
                    response = GenericApiResponse<UserPaymentMethodsResponse>.Failure("Customer does not exists.", 23);
                }

            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public async Task<GenericApiResponse<UserPaymentMethodsResponse>> GetCustomerPaymentMethodsByCustomerID(string customerID)
        {

            GenericApiResponse<UserPaymentMethodsResponse> response;
            try
            {
                var customer = await Db.GetCustomerByPay360CustomerId(long.Parse(customerID));
                var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(customer.Msisdn, customer.ProductCode, nameof(Pay360PaymentType.CARD));
                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/customers/" + creds.ApiInstallationIdCashierApi + "/" + customerID + "/paymentMethods";
                var apiResponse = await ApiCall.Get(apiEndPoint, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));

                if (apiResponse.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var apiPaymentMethodsResponse = JsonConvert.DeserializeObject<List<PaymentMethodResponseModel>>(apiResponse.Content.ReadAsStringAsync().Result);
                    UserPaymentMethodsResponse userPaymentMethodsResponse = new UserPaymentMethodsResponse();
                    userPaymentMethodsResponse.paymentMethodResponses = apiPaymentMethodsResponse;
                    response = GenericApiResponse<UserPaymentMethodsResponse>.Success(userPaymentMethodsResponse, "Payment Methods Retrieved successfully");
                }
                else if (apiResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                {
                    OutcomeModel outcomeResponse = JsonConvert.DeserializeObject<OutcomeModel>(apiResponse.Content.ReadAsStringAsync().Result);
                    response = GenericApiResponse<UserPaymentMethodsResponse>.Failure(outcomeResponse.ReasonMessage, 12);
                }
                else
                {
                    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                    string resonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    response = GenericApiResponse<UserPaymentMethodsResponse>.Failure(resonMessage, 12);
                }


            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public async Task<GenericApiResponse<UserPaymentMethodResponse>> SetCustomerDefaultCard(UserRequestUpdateCard userRequest)
        {

            GenericApiResponse<UserPaymentMethodResponse> response;
            try
            {
                var customer = await Db.GetCustomerByPay360CustomerId(Convert.ToInt64(userRequest.Pay360CustomerID));
                var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(customer.Msisdn, customer.ProductCode, nameof(Pay360PaymentType.CARD));
                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/customers/" + creds.ApiInstallationIdCashierApi + "/" + userRequest.Pay360CustomerID + "/paymentMethod/" + userRequest.CardToken + "/makeDefault";
                var apiResponse = await ApiCall.Post(apiEndPoint, "{}", UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));

                if (apiResponse.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    if (customer != null)
                    {
                        string key = Guid.NewGuid().ToString("N");
                        string cV2 = RijndaelEncryption.Encrypt(userRequest.DefaultCardCV2, key);
                        await Db.UpdateCustomerDefaultCv2(customer.MerchantRef, cV2, key);
                    }

                    var apiSetDefaultCardResponse = JsonConvert.DeserializeObject<PaymentMethodResponseModel>(apiResponse.Content.ReadAsStringAsync().Result);
                    UserPaymentMethodResponse userPaymentMethodsResponse = new UserPaymentMethodResponse();
                    userPaymentMethodsResponse.PaymentMethodResponse = apiSetDefaultCardResponse;
                    response = GenericApiResponse<UserPaymentMethodResponse>.Success(userPaymentMethodsResponse, "Customer's default card set successfully.");
                }
                else if (apiResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                {
                    OutcomeModel outcomeResponse = JsonConvert.DeserializeObject<OutcomeModel>(apiResponse.Content.ReadAsStringAsync().Result);
                    response = GenericApiResponse<UserPaymentMethodResponse>.Failure(outcomeResponse.ReasonMessage, 12);
                }
                else
                {
                    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                    string resonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    response = GenericApiResponse<UserPaymentMethodResponse>.Failure(resonMessage, 12);
                }

            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public async Task<GenericApiResponse<string>> RemoveCustomerCard(UserRequestRemoveCard userRequest)
        {
            GenericApiResponse<string> response;
            try
            {
                var customer = await Db.GetCustomerByPay360CustomerId(Convert.ToInt64(userRequest.Pay360CustomerID));
                var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(customer.Msisdn, customer.ProductCode, nameof(Pay360PaymentType.CARD));
                string apiEndPoint = Pay360Configurations.ApiEndPoint + "/acceptor/rest/customers/" + creds.ApiInstallationIdCashierApi + "/" + userRequest.Pay360CustomerID + "/paymentMethod/" + userRequest.CardToken + "/remove";
                var apiResponse = await ApiCall.Post(apiEndPoint, "{}", UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));

                if (apiResponse.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var apiSetDefaultCardResponse = JsonConvert.DeserializeObject<string>(apiResponse.Content.ReadAsStringAsync().Result);
                    //UserPaymentMethodResponse userPaymentMethodsResponse = new UserPaymentMethodResponse();
                    //userPaymentMethodsResponse.PaymentMethodResponse = apiSetDefaultCardResponse;
                    response = GenericApiResponse<string>.Success(apiSetDefaultCardResponse, "Card Removed Succesfully");
                }
                else if (apiResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                {
                    OutcomeModel outcomeResponse = JsonConvert.DeserializeObject<OutcomeModel>(apiResponse.Content.ReadAsStringAsync().Result);
                    response = GenericApiResponse<string>.Failure(outcomeResponse.ReasonMessage, 12);
                }
                else
                {
                    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                    string resonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    response = GenericApiResponse<string>.Failure(resonMessage, 12);
                }

            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public async Task<object> GetAutoTopup(UserRequestGetAutoTopup userRequest)
        {
            if (userRequest.ProductCode.Equals("THCC"))
            {
                try
                {
                    var result = await Db.GetCustomerAutoTopup_THRCC(userRequest.Msisdn, userRequest.Email, userRequest.ProductCode);
                    if (result != null && result.payload != null)
                    {
                        result.payload.ThresHold = result.payload.ThresHold / 100;
                        return result;
                    }
                    else
                    {
                        return GenericApiResponse<UserResponseGetAutoTopup_THRCC>.Failure("Unable to get auto topup information", 12);
                    }
                }
                catch (Exception ex)
                {
                    return GenericApiResponse<UserResponseGetAutoTopup_THRCC>.Failure(ex.Message, 12);
                }
            }
            else if (userRequest.ProductCode.ToUpper() == "THA")
            {

                try
                {
                    var result = await Db.GetCustomerAutoTopup_THA(userRequest.Msisdn);
                    if (result != null && result.payload != null)
                    {

                        return result;
                    }
                    else
                    {
                        return GenericApiResponse<UserResponseGetAutoTopup>.Failure("Unable to get auto topup information", 12);
                    }
                }
                catch (Exception ex)
                {
                    return GenericApiResponse<UserResponseGetAutoTopup>.Failure(ex.Message, 12);
                }
            }
            else //   THM / NOWPAYG
            {
                try
                {
                    return await Db.GetCustomerAutoTopup(userRequest.Msisdn, userRequest.Email, userRequest.ProductCode);
                }
                catch (Exception ex)
                {
                    return GenericApiResponse<UserResponseGetAutoTopup>.Failure(ex.Message, 12);
                }
            }
        }

        public async Task<GenericApiResponse<UserResponseGetAutoTopup>> GetAutoTopup_old(UserRequestGetAutoTopup userRequest)
        {
            GenericApiResponse<UserResponseGetAutoTopup> response;
            try
            {

                return await Db.GetCustomerAutoTopup_old(userRequest.Msisdn);

            }
            catch (Exception ex)
            {
                response = GenericApiResponse<UserResponseGetAutoTopup>.Failure(ex.Message, 12);
            }
            return response;
        }

        public async Task<GenericApiResponse<string>> SetAutoTopup(UserRequestSetAutoTopup userRequest)
        {
            GenericApiResponse<string> response;
            try
            {
                int result;
                if (userRequest.ProductCode.Equals("THCC") && userRequest.ProductItemCode.Equals("THRCC"))
                {
                    userRequest.ThresholdBalanceAmount = userRequest.ThresholdBalanceAmount * 100;
                    result = await Db.UpdateCustomerAutoTopup_THRCC(userRequest.ThresholdBalanceAmount, userRequest.IsAutoTopup, userRequest.ProductRef, userRequest.TopupAmount, userRequest.TopupCurrency, userRequest.Email, userRequest.ProductCode);
                }
                if (userRequest.ProductCode.ToUpper() == "THA")
                {

                    result = await Db.UpdateCustomerAutoTopup_THA(userRequest.ThresholdBalanceAmount, userRequest.IsAutoTopup, userRequest.ProductRef, userRequest.TopupAmount, userRequest.TopupCurrency);
                }
                else //  THM / NOWPAYG
                {
                    result = await Db.UpdateCustomerAutoTopup(userRequest.ThresholdBalanceAmount, userRequest.IsAutoTopup, userRequest.ProductRef, userRequest.TopupAmount, userRequest.TopupCurrency, userRequest.Email, userRequest.ProductCode);
                }

                if (result > 0)
                {
                    response = GenericApiResponse<string>.Success("Auto topup settings updated successfully.", "Success");
                }
                else
                {
                    response = GenericApiResponse<string>.Failure("Error in setting auto Topup.", 12);
                }
            }
            catch (Exception ex)
            {
                response = GenericApiResponse<string>.Failure(ex.Message, 14);
            }
            return response;
        }

        public async Task<GenericApiResponse<string>> SetAutoTopup_old(UserRequestSetAutoTopup userRequest)
        {
            GenericApiResponse<string> response;
            try
            {
                //Customer customer = await Db.GetCustomerByMerchantRef(userRequest.Msisdn);

                //if (customer != null)
                //{
                int result = await Db.UpdateCustomerAutoTopup_old(userRequest.ThresholdBalanceAmount, userRequest.IsAutoTopup, userRequest.ProductRef, userRequest.TopupAmount, userRequest.TopupCurrency);
                if (result > 0)
                {
                    response = GenericApiResponse<string>.Success("Auto topup settings updated successfully.", "Success");
                }
                else
                {
                    response = GenericApiResponse<string>.Failure("Error in setting auto Topup.", 12);
                }
                //}
                //else
                //{
                //    response = GenericApiResponse<string>.Failure("Customer does not exists.");
                //}

            }
            catch (Exception ex)
            {
                response = GenericApiResponse<string>.Failure(ex.Message, 14);
            }
            return response;
        }

        #endregion

        #region Customer Utilities

        public async Task<GenericApiResponse<UserCustomerResponseModels>> GetCustomerByCustomerUniqueRef(UserRequestGetCustomerByCustomerUniqueRef userRequest)
        {
            GenericApiResponse<UserCustomerResponseModels> response;
            try
            {
                string customerMerchantReference;

                if (userRequest.ProductCode.ToLower() == "tha")
                {
                    customerMerchantReference = userRequest.CustomerUniqueRef;
                }
                else
                {
                    customerMerchantReference = userRequest.ProductCode + "_" + userRequest.CustomerUniqueRef;
                }
                Customer customer = await Db.GetCustomerByMerchantRef(customerMerchantReference);

                if (customer != null)
                {
                    UserCustomerResponseModels CustomerResponse = new UserCustomerResponseModels();
                    CustomerResponse.AddressLine1 = customer.AddressLine1;
                    CustomerResponse.AddressLine2 = customer.AddressLine2;
                    CustomerResponse.AddressLine3 = customer.AddressLine3;
                    CustomerResponse.AddressLine4 = customer.AddressLine4;
                    CustomerResponse.City = customer.City;
                    CustomerResponse.Country = customer.Country;
                    CustomerResponse.CountryCode = customer.CountryCode;
                    CustomerResponse.DefaultCurrency = customer.DefaultCurrency;
                    CustomerResponse.DisplayName = customer.DisplayName;
                    CustomerResponse.Dob = customer.Dob;
                    CustomerResponse.Email = customer.Email;
                    CustomerResponse.MerchantRef = customer.MerchantRef;
                    CustomerResponse.Pay360CustId = customer.Pay360CustId;
                    CustomerResponse.PostCode = customer.PostCode;
                    CustomerResponse.Region = customer.Region;
                    CustomerResponse.Telephone = customer.Telephone;
                    response = GenericApiResponse<UserCustomerResponseModels>.Success(CustomerResponse, "Cutomer details retrieved successfully");
                }
                else
                {
                    response = GenericApiResponse<UserCustomerResponseModels>.Failure("Customer does not exists.", 23);
                }

            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        #endregion

        #region Transactions Utilities

        public async Task<GenericApiResponse<UserTransactionsResponseModel>> GetTransactionsByMerchantRef(string merchantRef)
        {

            GenericApiResponse<UserTransactionsResponseModel> response;
            try
            {
                var customer = await Db.GetCustomerByMerchantRef(merchantRef);
                var creds = pay360Auth.GetApiCredsByProductCodeAndProductRef(customer.Msisdn, customer.ProductCode, nameof(Pay360PaymentType.CARD));

                string apiEndPoint = $"{Pay360Configurations.ApiEndPoint}/acceptor/rest/transactions/{creds.ApiInstallationIdCashierApi}/byRef?merchantRef={merchantRef}";
                var apiResponse = await ApiCall.Get(apiEndPoint, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));

                if (apiResponse.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var temp = apiResponse.Content.ReadAsStringAsync().Result;
                    var apiPaymentMethodsResponse = JsonConvert.DeserializeObject<List<ApiPaymentResponse>>(apiResponse.Content.ReadAsStringAsync().Result);
                    UserTransactionsResponseModel userPaymentMethodsResponse = new UserTransactionsResponseModel();
                    userPaymentMethodsResponse.Transactions = apiPaymentMethodsResponse;
                    response = GenericApiResponse<UserTransactionsResponseModel>.Success(userPaymentMethodsResponse, "Transactions Retrieved successfully");
                }
                else if (apiResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                {
                    OutcomeModel outcomeResponse = JsonConvert.DeserializeObject<OutcomeModel>(apiResponse.Content.ReadAsStringAsync().Result);
                    response = GenericApiResponse<UserTransactionsResponseModel>.Failure(outcomeResponse.ReasonMessage, 12);
                }
                else
                {
                    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                    string resonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    response = GenericApiResponse<UserTransactionsResponseModel>.Failure(resonMessage, 12);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public async Task<GenericApiResponse<UserTransactionResponseModel>> GetTransactionsByTransactionId(string transactionId)
        {
            GenericApiResponse<UserTransactionResponseModel> response;
            try
            {
                var transactionDetails = await Db.GetTransactionByPay360TransactionId(transactionId);
                if (transactionDetails == null)
                {
                    return response = GenericApiResponse<UserTransactionResponseModel>.Failure("Transaction not found", 20);
                }

                var creds = pay360Auth.GetApiCredsByInstallationId(transactionDetails.ApiInstallationIdCashierApi);

                string apiEndPoint = $"{Pay360Configurations.ApiEndPoint}/acceptor/rest/transactions/{creds.ApiInstallationIdCashierApi}/{transactionId}";
                var apiResponse = await ApiCall.Get(apiEndPoint, UtilityFunctions.CreateBasicHeader(creds.ApiUserName, creds.ApiPassword));

                if (apiResponse.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var temp = apiResponse.Content.ReadAsStringAsync().Result;
                    var apiPaymentMethodsResponse = JsonConvert.DeserializeObject<ApiPaymentResponse>(apiResponse.Content.ReadAsStringAsync().Result);
                    UserTransactionResponseModel userPaymentMethodsResponse = new UserTransactionResponseModel();
                    userPaymentMethodsResponse.Transaction = apiPaymentMethodsResponse;
                    response = GenericApiResponse<UserTransactionResponseModel>.Success(userPaymentMethodsResponse, "Transaction Retrieved successfully");
                }
                else if (apiResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                {
                    OutcomeModel outcomeResponse = JsonConvert.DeserializeObject<OutcomeModel>(apiResponse.Content.ReadAsStringAsync().Result);
                    response = GenericApiResponse<UserTransactionResponseModel>.Failure(outcomeResponse.ReasonMessage, 12);
                }
                else
                {
                    string jsonResult = await apiResponse.Content.ReadAsStringAsync();
                    string resonMessage = UtilityFunctions.GetJsonObjectValueByKey("reasonMessage", jsonResult);
                    response = GenericApiResponse<UserTransactionResponseModel>.Failure(resonMessage, 12);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        #endregion

        #region PrivateMethods

        private async Task SaveFailedTransactionApiError(Pay360TransactionStatuses transactionStatus, int customerId, PaymentMethods paymentMethod, Pay360TransactionTypes transactionType, string ApiInstallationIdCashierApi)
        {
            await Db.AddTransactionWithoutBasket(new Pay360Transaction
            {
                Customer_Id = customerId,
                PaymentMethod_Id = (int)paymentMethod,
                TransactionStatus_Id = (int)transactionStatus,
                RequestTime = DateTime.UtcNow,
                TransactionType_Id = (int)transactionType,
                ApiInstallationIdCashierApi = ApiInstallationIdCashierApi
            });
        }

        private async Task SaveFailedTransactionApiError(Pay360TransactionStatuses transactionStatus, int customerId, PaymentMethods paymentMethod, Pay360TransactionTypes transactionType, double amount, string currency, string ApiInstallationIdCashierApi)
        {
            await Db.AddTransactionWithoutBasket(new Pay360Transaction
            {
                Customer_Id = customerId,
                PaymentMethod_Id = (int)paymentMethod,
                TransactionStatus_Id = (int)transactionStatus,
                RequestTime = DateTime.UtcNow,
                TransactionType_Id = (int)transactionType,
                TransactionAmount = amount,
                TransactionCurrency = currency,
                ApiInstallationIdCashierApi = ApiInstallationIdCashierApi
            });
        }

        private Pay360Transaction CreateDbTransactionObject(ApiPaymentResponse apiResponseModel, int customerId, string ApiInstallationIdCashierApi)
        {
            try
            {
                return new Pay360Transaction
                {
                    Customer_Id = customerId,
                    TransactionMerchantRef = apiResponseModel.Transaction.MerchantRef,
                    RequestTime = DateTime.UtcNow,
                    Pay360TransactionId = apiResponseModel.Transaction.TransactionId,
                    TransactionAmount = apiResponseModel.Transaction.Amount,
                    TransactionStatus_Id = (int)apiResponseModel.Transaction.Status.ToEnum<Pay360TransactionStatuses>(),
                    TransactionType_Id = (int)apiResponseModel.Transaction.Type.ToEnum<Pay360TransactionTypes>(),
                    TransactionCurrency = apiResponseModel.Transaction.Currency,
                    TransactionTime = DateTimeOffset.Parse(apiResponseModel.Transaction.TransactionTime).UtcDateTime,
                    TransactionReceivedTime = DateTimeOffset.Parse(apiResponseModel.Transaction.ReceivedTime).UtcDateTime,
                    Route = apiResponseModel.Processing.Route,
                    OutcomeReasonCode = apiResponseModel.Outcome.ReasonCode,
                    OutcomeReasonMessage = apiResponseModel.Outcome.ReasonMessage,
                    OutcomeStatus = apiResponseModel.Outcome.Status,
                    AuthStatusCode = apiResponseModel.Processing.AuthResponse.StatusCode,
                    AuthMessage = apiResponseModel.Processing.AuthResponse.Message,
                    AuthCode = apiResponseModel.Processing.AuthResponse.AuthCode == null ? "" : apiResponseModel.Processing.AuthResponse.AuthCode,
                    AuthGatewayReference = apiResponseModel.Processing.AuthResponse.GatewayReference,
                    AuthGatewaySettlement = apiResponseModel.Processing.AuthResponse.GatewaySettlement,
                    AuthGatewayCode = apiResponseModel.Processing.AuthResponse.GatewayCode,
                    AuthGatewayMessage = apiResponseModel.Processing.AuthResponse.GatewayMessage,
                    AuthAvsAddressCheck = apiResponseModel.Processing.AuthResponse.AvsAddressCheck,
                    AuthAvsPostCodeCheck = apiResponseModel.Processing.AuthResponse.AvsPostCodeCheck,
                    AuthCv2Check = apiResponseModel.Processing.AuthResponse.Cv2Check,
                    AuthStatus = apiResponseModel.Processing.AuthResponse.Status,
                    FinancialServicesDob = apiResponseModel.FinancialServices == null ? null : apiResponseModel.FinancialServices.DateOfBirth,
                    FinancialServicesAccountNumber = apiResponseModel.FinancialServices == null ? null : apiResponseModel.FinancialServices.AccountNumber,
                    FinancialServicesPostCode = apiResponseModel.FinancialServices == null ? null : apiResponseModel.FinancialServices.PostCode,
                    FinancialServicesSurName = apiResponseModel.FinancialServices == null ? null : apiResponseModel.FinancialServices.Surname,
                    RelatedTransactionId = apiResponseModel.Transaction.RelatedTransaction.TransactionId,
                    RelatedTransactionMerchantRef = apiResponseModel.Transaction.RelatedTransaction.MerchantRef,
                    PaymentMethod_Id = (int)PaymentMethods.Card,
                    ApiInstallationIdCashierApi = ApiInstallationIdCashierApi
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion
    }
}
