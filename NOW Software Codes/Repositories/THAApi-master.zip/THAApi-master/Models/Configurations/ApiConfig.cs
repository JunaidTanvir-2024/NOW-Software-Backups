﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class ApiConfig
    {
        public bool Enable_SQL_Calls { get; set; }
        public string app_app_call_url { get; set; }
        public string app_app_call_enabled_country_codes { get; set; }
        public int app_app_call_complete_enable { get; set; }
        public string payment_itunes_only_version { get; set; }
        public int multiStepFO_complete_enable { get; set; }
        public string multiStepFO_enabled_country_codes { get; set; }
        public string force_update_country_codes { get; set; }
        public string App_Flag_Folder { get; set; }
        public bool ClientCallLogs { get; set; }
    }


}
