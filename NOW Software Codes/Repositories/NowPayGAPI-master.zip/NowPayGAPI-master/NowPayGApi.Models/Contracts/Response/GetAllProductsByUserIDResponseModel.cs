﻿using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetAllProductsByUserIDResponseModel
    {
        public IEnumerable<UserProductsResponseModel> ProductList { get; set; }
    }
}
