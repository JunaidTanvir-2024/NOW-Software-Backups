﻿namespace Application.Common.Models.ResponseWrappers;

public class GenericApiResponse<T>
{
    public string? Message { get; set; }
    public string? Status { get; set; }
    public int ErrorCode { get; set; }
    public T? Payload { get; set; }

    public static GenericApiResponse<T> Success(T payload, string message)
    {
        return new GenericApiResponse<T>
        {
            ErrorCode = 0,
            Status = "Success",
            Message = message,
            Payload = payload
        };
    }

    public static GenericApiResponse<T> Failure(string message, int errorCode = 2)
    {
        return new GenericApiResponse<T>
        {
            ErrorCode = errorCode,
            Status = "Failure",
            Message = message

        };
    }
}