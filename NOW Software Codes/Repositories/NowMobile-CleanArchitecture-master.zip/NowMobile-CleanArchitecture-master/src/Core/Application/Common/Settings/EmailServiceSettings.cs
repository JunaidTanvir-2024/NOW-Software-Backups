﻿public class EmailServiceSettings
{
    public const string SectionName = nameof(EmailServiceSettings);
    public static EmailServiceSettings Bind = new EmailServiceSettings();
    public string? BaseUrl { get; set; }
    public bool IsEnable { get; set; }
}
