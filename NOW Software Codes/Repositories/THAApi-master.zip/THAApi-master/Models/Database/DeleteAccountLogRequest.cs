﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    public class DeleteAccountLogRequest
    {
        public string AccountId { get; set; }
        public string Msisdn { get; set; }
        public DateTime? AccountActivationDate { set; get; }     
        public AccountDeleteStatus AccountDeleteStatus { set; get; }
        public DateTime? AllowedSignUpDate { set; get; }
        public DateTime? AccountDeleteRequestDate { set; get; }
    }
}
