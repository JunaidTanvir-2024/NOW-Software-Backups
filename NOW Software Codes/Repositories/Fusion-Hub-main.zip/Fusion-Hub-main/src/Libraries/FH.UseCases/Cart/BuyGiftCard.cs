using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.DTOs.Vendors.DTOne;
using FH.Core.DTOs.Vendors.Reloadly;
using FH.Core.Helpers;
using FH.Core.Interfaces.Database;
using FH.Core.Interfaces.Vendors;
using FluentValidation;
using Mediator;
using RW;

namespace FH.UseCases.Cart;
public sealed class BuyGiftCard
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public required string TransactionReference { get; set; }
        public required long ProductId { get; set; }
        public required string CartReference { get; set; }
        public required string ProductVendorCode { get; set; }
        public required string RecipientMsisdn { get; set; }
        public required string SenderMsisdn { get; set; }
        public required string SenderName { get; set; }
        public required ushort Quantity { get; set; }
    }

    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.TransactionReference).NotNull().NotEmpty();
            RuleFor(x => x.ProductId).GreaterThan(0);
            RuleFor(x => x.SenderMsisdn).NotNull().NotEmpty();
            RuleFor(x => x.RecipientMsisdn).NotNull().NotEmpty();
            RuleFor(x => x.SenderName).NotNull().NotEmpty();
        }
    }

    #endregion

    #region Response
    public sealed record Response
    {
        public required string TransactionReference { get; set; }
        public IEnumerable<PurchasedItem> PurchasedItems { get; set; } = [];
        public sealed record PurchasedItem
        {
            public required string ProductVendorCode { get; set; }
            public required long ProductId { get; set; }
            public required string Status { get; set; }
        }
    }

    #endregion

    #region Handler
    internal sealed class Handler(IReloadlyService reloadlyService, IUnitOfWork unitOfWork, IDTOneService dTOneService) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IReloadlyService _reloadlyService = reloadlyService;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IDTOneService _dTOneService = dTOneService;

        public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var productVendor = await _unitOfWork.ProductRepository.GetProductDetail(new ProductDetailDto.Request()
            {
                ProductId = request.ProductId,
                ProductVendorCode = request.ProductVendorCode
            });

            if (!string.IsNullOrEmpty(productVendor?.VendorName))
            {
                if (productVendor.VendorName.Equals(nameof(AppEnums.Vendor.DTOne), StringComparison.OrdinalIgnoreCase))
                {

                    var dtOneGiftCardExecutionResult = await DTOneGiftCardExecution(request);

                    if (dtOneGiftCardExecutionResult?.PurchasedItems.Count > 0)
                    {
                        foreach (var item in dtOneGiftCardExecutionResult.PurchasedItems)
                        {
                            await _unitOfWork.TransactionRepository.TransactionInsert(new ProductTransactionInsertDto.Request()
                            {
                                VendorTransactionId = item.VendorTransactionId,
                                CartReference = request.CartReference,
                                ProductId = item.ProductId,
                                ProductVendorCode = item.ProductVendorCode,
                                Status = item.Status,
                                VendorTransactionReference = item.VendorTransactionReference,
                                TransactionReference = request.TransactionReference
                            });
                        }
                        return ResultWrapper.Success(new Response()
                        {
                            TransactionReference = request.TransactionReference,
                            PurchasedItems = dtOneGiftCardExecutionResult.PurchasedItems.Select(x => new Response.PurchasedItem()
                            {
                                ProductId = x.ProductId,
                                ProductVendorCode = x.ProductVendorCode,
                                Status = x.Status
                            })
                        });
                    }
                }

                var reloadlyGiftCardExecutionResult = await ReloadlyGiftCardExecution(request);

                if (reloadlyGiftCardExecutionResult?.PurchasedItems.Count > 0)
                {
                    foreach (var item in reloadlyGiftCardExecutionResult.PurchasedItems)
                    {
                        await _unitOfWork.TransactionRepository.TransactionInsert(new ProductTransactionInsertDto.Request()
                        {
                            VendorTransactionId = item.VendorTransactionId,
                            ProductId = item.ProductId,
                            CartReference = request.CartReference,
                            ProductVendorCode = item.ProductVendorCode,
                            Status = item.Status,
                            VendorTransactionReference = item.VendorTransactionReference,
                            TransactionReference = request.TransactionReference
                        });
                    }
                    return ResultWrapper.Success(new Response()
                    {
                        TransactionReference = request.TransactionReference,
                        PurchasedItems = reloadlyGiftCardExecutionResult.PurchasedItems.Select(x => new Response.PurchasedItem()
                        {
                            ProductId = x.ProductId,
                            ProductVendorCode = x.ProductVendorCode,
                            Status = x.Status
                        })
                    });
                }
            }

            return ResultWrapper.Failure(AppConstants.StatusKey.BadRequest, AppConstants.StatusCode.BadRequest);
        }


        private async Task<DTOneBuyGiftCard.Response> DTOneGiftCardExecution(Query request)
        {
            (string firstName, string lastName) = AppHelpers.SplitNames(request.SenderName);
            return await _dTOneService.BuyGiftCard(new DTOneBuyGiftCard.Request
            {
                AutoConfirm = true,
                ProductId = request.ProductId,
                ProductVendorCode = request.ProductVendorCode,
                ReceiverMsisdn = request.SenderMsisdn,
                SenderMsisdn = request.SenderMsisdn,
                SenderFirstName = firstName,
                SenderLastName = lastName,
                Quantity = request.Quantity,
            });
        }

        private async Task<ReloadlyBuyGiftCard.Response> ReloadlyGiftCardExecution(Query request)
        {
            return await _reloadlyService.BuyGiftCard(new ReloadlyBuyGiftCard.Request
            {
                ProductId = request.ProductId,
                ProductVendorCode = request.ProductVendorCode,
                RecipientMsisdn = request.SenderMsisdn,
                SenderMsisdn = request.SenderMsisdn,
                SenderName = request.SenderName.Replace('_', ' '),
                Quantity = request.Quantity,
            });
        }
    }
    #endregion
}
