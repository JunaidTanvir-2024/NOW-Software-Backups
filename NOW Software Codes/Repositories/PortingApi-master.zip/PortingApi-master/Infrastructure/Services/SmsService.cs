﻿using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Response.SmsApiResponse;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Serilog;
using System.Net.Http;
using Models.Contracts.Request.SmsApiRequest;

namespace Infrastructure.Services
{
    public class SmsService : ISmsService
    {
        public readonly string ApiEndPoint;
        public readonly string SmsFrom;
        public readonly string SmsJobId;
        public ILogger Logger;

        public SmsService(IOptions<SmsConfig> config, ILogger logger)
        {
            ApiEndPoint = config.Value.ApiEndPoint;
            SmsFrom = config.Value.SmsFrom;
            SmsJobId = config.Value.SmsJobId;
            Logger = logger;
        }

        public async Task<XeebiSendSmsResponse> SendXeebiSms(string to, string textMessage)
        {
            XeebiSendSmsResponse returnResult = null;


            string requestParameters = $"to: {to}, textMessage: {textMessage}";

            try
            {
                string XeebiSMSEndPoint = ApiEndPoint + "Xeebi/SendSms";

                string response = "";

                XeebiSendSmsRequest req = new XeebiSendSmsRequest();
                req.from = SmsFrom;
                req.to = to;
                req.text = textMessage;

                Task<String> HttpPoppayoutsPostService = PostRequestToXeebiEndPoint(XeebiSMSEndPoint, "Post", req);
                response = await HttpPoppayoutsPostService;
                returnResult = JsonConvert.DeserializeObject<XeebiSendSmsResponse>(response);
                if (returnResult == null)
                {
                    Logger.Error($"SmsService - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");
                    Console.WriteLine($"SmsService - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: Null response received. Please check SmsOutReach APi.");

                }
                else if (returnResult.errorCode == 2)
                {
                    Logger.Error($"SmsService - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: {returnResult.message}");
                    Console.WriteLine($"SmsService - Method: SendXeebiSms, Parameters --> {requestParameters}, ErrorMessage: {returnResult.message}");
                }
                else
                {
                    if (returnResult.errorCode == 0 && returnResult.payload.submit_status == "OK")
                    {
                        Logger.Debug($"SmsService success - Method: SendXeebiSms, Parameters --> {requestParameters}");
                        Console.WriteLine($"SmsService success - Method: SendXeebiSms, Parameters --> {requestParameters}");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"SmsService - Method: SendXeebiSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
            }

            return returnResult;
        }
        private async Task<string> PostRequestToXeebiEndPoint(string apiEndPoint, string postType, XeebiSendSmsRequest req)
        {

            string returnData = "";
            try
            {
                HttpClient httpClient = new HttpClient();

                httpClient.BaseAddress = new Uri(apiEndPoint);

                //var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

                MultipartFormDataContent content = new MultipartFormDataContent();
                content.Add(new StringContent(req.from), "from");
                content.Add(new StringContent(req.to), "to");
                content.Add(new StringContent(req.text), "textMessage");
                //content.Add(httpContent);

                HttpResponseMessage httpResponse;

                if (postType == "Post")
                {
                    httpResponse = await httpClient.PostAsync(apiEndPoint, content);
                }
                else
                {
                    httpResponse = await httpClient.GetAsync(apiEndPoint);
                }

                if (httpResponse.Content != null)
                {
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    Exception ex = new Exception($"SmsService Exception - Empty Contents Received for request - ");
                    throw ex;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            return returnData;
        }
    }
}
