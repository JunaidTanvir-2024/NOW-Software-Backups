using THCC.Application.Extensions.DependencyResolver;
using THCC.Domain.Aggregates;

namespace THCC.Application.Interfaces.Services;

public interface IMailService : ServiceType.ITransient
{
    Task<bool> SendForgotPasswordEmail(string toEmail, string otp);
    Task<bool> SendChangePasswordEmail(string toEmail, string browser, string ipAddress, string location);
    Task<bool> SendEmailVerificationEmail(string toEmail, string otp);
    Task<bool> SendSignupSuccessEmail(string toEmail);
    Task<bool> IsValidEmailAddress(string email);
    Task<bool> SendTHRCCFastRechargeEmail(OrderDetail orderDetails);
    Task<bool> SendTHRCCRechargeEmail(OrderDetail orderDetails);
    Task<bool> SendRedeemEmail(OrderDetail orderDetails);
    Task<bool> SendTHRCCPurchaseEmail(OrderDetail orderDetails);
    Task<bool> SendTHCCPurchaseEmail(OrderDetail orderDetails);
}