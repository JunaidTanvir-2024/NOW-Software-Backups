﻿namespace Application.Features.Account.History.All;

public sealed class AllHistoryRequest : IRequest<Result<AllHistoryResponse>>
{
    public string Msisdn { get; set; } = default!;
}