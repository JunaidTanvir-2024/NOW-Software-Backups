﻿using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.CustomerOrder.Responses;
using Sentry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder;
internal sealed class RemoveProductFromCartHandler : IRequestHandler<RemoveProductFromCartRequest, IResultWrapper>
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly ICustomerOrderService _customerOrderService;
    private readonly ICommonService _commonService;
    public RemoveProductFromCartHandler(ICustomerCartRespository customerCartRespository, ICustomerOrderService customerOrderService, ICommonService commonService)
    {
        _customerCartRespository = customerCartRespository;
        _customerOrderService = customerOrderService;
        _commonService = commonService;
    }
    public async Task<IResultWrapper> Handle(RemoveProductFromCartRequest request, CancellationToken cancellationToken)
    {


        string Order_userID = string.Empty;
        if (request.IsGuestUser)
            Order_userID = request.UserID;
        else
            Order_userID = _commonService.GetUserID();

        if (string.IsNullOrEmpty(Order_userID))
            return ResultWrapper.Failure(AppConstants.StatusKeys.UserNotProvided, 404);



        long CustomerOrderID = 0;
        decimal CustomerOrderPrice = 0;
        GetCustomerOrderDto? Order = await GetCustomerExistingOrder(Order_userID);
        CustomerOrderID = Order != null ? Order.CustomerOrderID : CustomerOrderID;

        var productresponse = await _customerCartRespository.RemoveCartAsync(request.ProductID, request.CustomerCartID, CustomerOrderID);
        if (productresponse == null)
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);

        CustomerOrderPrice = await _customerOrderService.CalculateCustomerOrderPrice(Order_userID);

        RemoveProductFromCartResponse removeProductResult = new RemoveProductFromCartResponse()
        {
            IsRemoved = (bool)productresponse,
            TotalOrderPrice = CustomerOrderPrice,
            UserID= Order_userID
        };
        return ResultWrapper.Success(removeProductResult);
    }
    private async Task<GetCustomerOrderDto> GetCustomerExistingOrder(string userID)
    {
        return await _customerCartRespository.GetCustomerOrder(userID, AppEnums.OrderStatusEnum.Init.Getkey());
    }
}

