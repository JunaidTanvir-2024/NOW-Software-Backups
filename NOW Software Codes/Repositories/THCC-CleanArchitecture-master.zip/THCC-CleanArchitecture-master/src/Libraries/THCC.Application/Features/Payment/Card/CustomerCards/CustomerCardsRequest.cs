﻿namespace THCC.Application.Features.Payment.Card.CustomerCards;

public class CustomerCardsRequest : IRequest<object> { }
