﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Infrastructure.DAL.Interfaces
{
    public interface IDL_AppleReceipts
    {
    }
}
