﻿
$("input").keyup(function (e) {
    if (e.which == 13) {
        verifylogin(e);
    }
});


$("#submitlogin").on("click", function (event) {
    verifylogin(event);
});

function verifylogin(event) {
    event.preventDefault();
    if (!$("#loginform").valid()) {
        return false;
    }
    var model = {};
    model.Email = $("#email").val();
    model.Password = $("#password").val();
    $.ajax({
        beforeSend: function () {
            loader.btnloadershow(event);
        },
        type: "POST",
        url: $('#loginform').attr('action'),
        data: model,
        success: function (json) {
            if (json && json.errorCode != 0 && json.errorCode!=22) {
                $("#loginErrorDiv").text(json.key)
                if (json.errorCode == 2) { $("#Resendverificationemail").show(); }
                localStorage.setItem("AuthToken", json.token);
            }
            else if (json.errorCode == 22) {
                window.location.href = "/addproduct";
            }
            else if (json && json.errorCode == 0) {
                if (json.redirectUrl) {
                    window.location.href = json.redirectUrl
                } else {
                    window.location.href = "account/myaccount";
                }

            }
        },
        complete: function () {
            loader.btnloaderhide(event);
        },
        error: function (xhr, status, error) {
            //var a = error;
            //alert("Error: " + a.responseText);
            loader.btnloaderhide(event);
            $("#loginErrorDiv").text("Invalid email or password");
        }
    });
}