﻿using System.Text;

using Microsoft.Extensions.Options;

using Newtonsoft.Json;

using THCC.Application.Interfaces.Services;
using THCC.Application.Models.Dtos;
using THCC.Application.Settings;

using ILogger = Serilog.ILogger;

namespace THCC.Infrastructure.Services;
public class AddressService : IAddressService
{
    private readonly AddressSettings _addressSettings;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger _logger;

    public AddressService(
        IHttpClientFactory clientFactory,
        ILogger logger,
        IOptions<AddressSettings> addressapi)
    {
        _httpClientFactory = clientFactory;
        _logger = logger;
        _addressSettings = addressapi.Value;
    }

    public async Task<AddressDto> GetAddresses(string postcode)
    {
        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            var endpoint = _addressSettings.ApiEndpoint + postcode;
            string encodedBaiscAuthToken = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_addressSettings.ApiKey!));
            httpClient.DefaultRequestHeaders.Add("Authorization", "Basic " + encodedBaiscAuthToken);
            var output = await httpClient.GetAsync(endpoint);
            string outputData = await output.Content.ReadAsStringAsync();
            if (output.IsSuccessStatusCode)
            {
                return JsonConvert.DeserializeObject<AddressDto>(outputData)!;
            }
            else
            {
                var errorMessage = await output.Content.ReadAsStringAsync();
                _logger.Debug($"AddressService: GetAddresses=> {postcode} " + errorMessage);
            }
            return null!;
        }
        catch (Exception ex)
        {
            _logger.Error(exception: ex, $"AddressService: GetAddresses=> {postcode} " + ex.Message);
            return null!;
        }
    }
}
