﻿using Mapster;

namespace THCC.Application.Common.Extensions;

public static class UtitlityHelper
{
    public static T MapTo<T>(this object sourceObject)
    {
        return sourceObject.Adapt<T>();
    }
    public static List<T> MapToList<T>(this object sourceObject)
    {
        return sourceObject.Adapt<List<T>>();
    }
}