using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Orders;

public class OrderItem
{
    [JsonPropertyName("source_id")]
    public string? SourceId { get; set; }

    [JsonPropertyName("related_object")]
    public string? RelatedObject { get; set; }

    [JsonPropertyName("product_id")]
    public string? ProductId { get; set; }

    [JsonPropertyName("sku_id")]
    public string? SkuId { get; set; }

    [JsonPropertyName("quantity")]
    public int? Quantity { get; set; }

    [JsonPropertyName("product")]
    public OrderItemProduct? Product { get; set; }

    [JsonPropertyName("sku")]
    public OrderItemSku? Sku { get; set; }

    [JsonPropertyName("amount")]
    public long? Amount { get; set; }

    [JsonPropertyName("price")]
    public long? Price { get; set; }

    [JsonPropertyName("discount_amount")]
    public long? DiscountAmount { get; set; }

    [JsonPropertyName("applied_discount_amount")]
    public long? AppliedDiscountAmount { get; set; }

    [JsonPropertyName("subtotal_amount")]
    public long? SubtotalAmount { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}
