﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using TalkhomeWebApp.Models;
using TalkhomeWebApp.Models.ApiContracts.Request;
using TalkhomeWebApp.Models.ApiContracts.Response;
using TalkhomeWebApp.Models.ViewModels;
using TalkhomeWebApp.Services;
using TalkhomeWebApp.Utilities;
using TalkhomeWebApp.Utilities.Extension;

namespace TalkhomeWebApp.Controllers
{
    public class BaseController : Controller
    {
        private readonly ILogger _logger;
        private readonly IHelperService _helperService; 

        public BaseController(
            ILogger logger,
            IHelperService helperService)
        {
            _logger = logger;
            _helperService = helperService;
        }

        public IActionResult HandleErrorResponse<T>(T model, int errorCode, string errorMessage = null, bool isRequestFromIFrame = false)
        {
            _logger.Information($"Class: BaseController, Method: HandleErrorResponse, " +
                                            $"Model: {JsonConvert.SerializeObject(model)}, ErrorCode:{errorCode}, Message:{errorMessage}");
            string key = Enum.GetName(typeof(ApiStatusCodes), errorCode);
            if (string.IsNullOrEmpty(key))
                key = ApiStatusCodes.InternalServerError.ToString();

            if (key == "DTOneServiceError")
                key = "TransferServiceError";

            key = key.ToLower();

            if (model is NewCardPaymentRequest ||
                model is ExistingCardPaymentRequest ||
                model is NewCustomerPaymentRequest ||
                model is PayPalStartPaymentRequest ||
                model is PaypalPaymentRequestModel ||
                model is TransferByCardResponseModel ||
                model is TransferByPayPalResponseModel||
                model is NewCustomerPaymentResponseModel)
            {
                if (isRequestFromIFrame)
                {
                    var data = (dynamic)model;
                    var errorobjdata = new ErrorObjectViewModel
                    {
                        Key = key,
                        ErrorMessage = (int)ApiStatusCodes.PaymentServiceError == errorCode ? errorMessage : string.Empty,
                        MobileTopupInfo = new MobileTopupTransactionModel
                        {
                            Amount = data.productData.CustomerChargeValue,
                            From = data.productData.fromMsisdn,
                            Payment = data is TransferByCardResponseModel ? PaymentMethodTypes.Card.ToString() : PaymentMethodTypes.Paypal.ToString(),
                            Network = data.productData.operatorName.Trim().Replace(" ", "-"),
                            To = data.productData.tomsisdn,
                            Destination = _helperService.GetCountryCode(data.productData.tomsisdn),
                            Origin = _helperService.GetCountryCode(data.productData.fromMsisdn),
                            Id = data.productData.GUID
                        }
                    };
                    ViewBag.ErrorModelData = JsonConvert.SerializeObject(errorobjdata);
                    return PartialView("~/Views/Home/ErrorRedirection.cshtml");
                }
                else
                {
                    if (errorCode == (int)ApiStatusCodes.PaymentServiceError)
                        TempData.Put("Payment-Service-Error", errorMessage);

                    return RedirectToTransactionErrorPages(key, model);
                }
            }

            if (isRequestFromIFrame)
            {
                var errorobjdata = new ErrorObjectViewModel
                {
                    Key = key,
                    ErrorMessage = (int)ApiStatusCodes.PaymentServiceError == errorCode ? errorMessage : string.Empty
                };

                if (model is Pay360Resume3DResponseModel)
                {
                    var s = model as Pay360Resume3DResponseModel;
                    if (s.bundlePurchaseInfo!=null)
                    {
                        errorobjdata.BundleInfo = new BundleTransactionModel()
                        {
                            From = s.bundlePurchaseInfo.Msisdn,
                            Origin = s.bundlePurchaseInfo.origination,
                            Payment = PaymentMethodTypes.Card.ToString(),
                            Destination = s.bundlePurchaseInfo.destination,
                            AutoRenew = false,
                            Type = s.bundlePurchaseInfo.BundleType.ToString(),
                            Amount=s.bundlePurchaseInfo.BundleAmount,
                            Bundle=s.bundlePurchaseInfo.BundleName.Replace(' ','-'),
                            Id="-1",
                        };
                    }
                    else if (s.topupInfo !=null)
                    {
                        errorobjdata.TopupInfo = new TopupTransactionModel()
                        {
                            From = _helperService.GetCountryCode( s.topupInfo.Msisdn),
                            Payment = PaymentMethodTypes.Card.ToString(),
                            AutoTopup = false,
                            Amount=s.topupInfo.TopupAmount,
                            Id="-1",
                            //Origin=s.topupInfo.origination,
                        };
                    }
                }

                ViewBag.ErrorModelData = JsonConvert.SerializeObject(errorobjdata);

                return PartialView("~/Views/Home/ErrorRedirection.cshtml");
            }
            else
            {
                switch (errorCode)
                {
                    case (int)ApiStatusCodes.InvalidNowtelReferenceOrProduct:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "InvalidNowtelReferenceOrProduct".ToLower() });
                    case (int)ApiStatusCodes.UserNotRegistered:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "UserNotRegistered".ToLower() });
                    case (int)ApiStatusCodes.InsufficientBalance:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "InsufficientBalance".ToLower() });
                    case (int)ApiStatusCodes.InternalServerError:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError".ToLower() });
                    case (int)ApiStatusCodes.TopupNumberLimitExceed:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "TopupNumberLimitExceed".ToLower() });
                    case (int)ApiStatusCodes.TopupAmountLimitExceed:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "TopupAmountLimitExceed".ToLower() });
                    case (int)ApiStatusCodes.DenominationsNotAvailable:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "DenominationsNotAvailable".ToLower() });
                    case (int)ApiStatusCodes.DenominationBlocked:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "DenominationBlocked".ToLower() });
                    case (int)ApiStatusCodes.OperatorBlocked:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "OperatorBlocked".ToLower() });
                    case (int)ApiStatusCodes.PaymentServiceError:
                        TempData.Put("Payment-Service-Error", errorMessage);
                        return RedirectToAction("ErrorMessage", "Home", new { key = "PaymentServiceError".ToLower() });
                    case (int)ApiStatusCodes.DailyLimitExceeded:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "DailyLimitExceeded".ToLower() });
                    case (int)ApiStatusCodes.BundlePurchasedFailed:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "BundlePurchasedFailed".ToLower() });
                    case (int)ApiStatusCodes.BundleLimitExceeded:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "BundleLimitExceeded".ToLower() });
                    case (int)ApiStatusCodes.InvalidBundle:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "InvalidBundle".ToLower() });
                    case (int)ApiStatusCodes.DTOneServiceError:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "TransferServiceError".ToLower() });
                    case (int)ApiStatusCodes.TransferNotAuthorized:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "TransferNotAuthorized".ToLower() });
                    case (int)ApiStatusCodes.TransferServiceNotAvailable:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "TransferServiceNotAvailable".ToLower() });
                    case (int)ApiStatusCodes.PaymentCreationFailed_PayPal:
                        return RedirectToTransactionErrorPages("PaymentCreationFailed_Paypal".ToLower(), model);
                    default:
                        return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError".ToLower() });
                }
            }
        }
        private IActionResult RedirectToTransactionErrorPages(string key, dynamic data)
        {
            TempData.Put("Key", key);
            if(data is NewCustomerPaymentResponseModel)
            {
                var s=data as NewCustomerPaymentResponseModel;
                if (s.bundlePurchaseInfo!=null)
                {
                    return RedirectToAction("BundleError", "Home", new BundleTransactionModel
                    {
                        Amount = s.bundlePurchaseInfo.BundleAmount,
                        AutoRenew = s.bundlePurchaseInfo.AutoRenew,
                        Destination = s.bundlePurchaseInfo.destination,
                        From = s.bundlePurchaseInfo.Msisdn,
                        Origin = s.bundlePurchaseInfo.origination,
                        Payment = PaymentMethodTypes.Card.ToString(),
                        Bundle=s.bundlePurchaseInfo.BundleName.Replace(' ','-'),
                        Id="-1",
                        Type = s.bundlePurchaseInfo.BundleType.ToString()
                    });
                }
                else if (s.topupInfo !=null)
                {
                    return RedirectToAction("TopupError", "Home", new TopupTransactionModel()
                    {
                        Amount = s.topupInfo.TopupAmount.ToString(),
                        AutoTopup = s.topupInfo.AutoTopup,
                        //Origin=s.topupInfo.origination,
                        From = s.topupInfo.Msisdn,
                        Payment = PaymentMethodTypes.Card.ToString(),
                        Id = "-1"
                    });
                }
            }
            if (data is NewCardPaymentRequest || data is ExistingCardPaymentRequest || data is NewCustomerPaymentRequest)
            {
                if (data.CheckoutPaymentType == CheckOutTypes.Bundle)
                {
                    return RedirectToAction("BundleError", "Home", new BundleTransactionModel
                    {
                        Amount = data.Amount.ToString(),
                        AutoRenew = data.IsAutoBundleRenew,
                        Destination = data.ToBundleISO2,
                        From = data.Msisdn,
                        Origin = data.FromBundleISO2,
                        Payment = PaymentMethodTypes.Card.ToString(),
                        Type = data.BundleType.ToString()
                    });
                }
                else if (data.CheckoutPaymentType == CheckOutTypes.TopUp)
                {
                    return RedirectToAction("TopupError", "Home", new TopupTransactionModel()
                    {
                        Amount = data.Amount.ToString(),
                        AutoTopup = data.IsAutoTopUp,
                        From = data.Msisdn,
                        Payment = PaymentMethodTypes.Card.ToString(),
                        Id="-1"
                    });
                }
            }
            if (data is PayPalStartPaymentRequest)
            {
                if (data.CheckoutPaymentType == CheckOutTypes.Bundle)
                {
                    return RedirectToAction("BundleError", "Home", new BundleTransactionModel
                    {
                        Amount = data.Amount.ToString(),
                        //AutoRenew = data.IsAutoBundleRenew,
                        Destination = data.ToBundleISO2,
                        From = data.Msisdn,
                        Origin = data.FromBundleISO2,
                        Payment = PaymentMethodTypes.Paypal.ToString(),
                        Type = data.BundleType.ToString()
                    });
                }
                else if (data.CheckoutPaymentType == CheckOutTypes.TopUp)
                {
                    return RedirectToAction("TopupError", "Home", new TopupTransactionModel()
                    {
                        Amount = data.Amount.ToString(),
                        //AutoTopup = data.IsAutoTopUp,
                        From = data.Msisdn,
                        Payment = PaymentMethodTypes.Paypal.ToString(),
                        Id= "-1"
                    });
                }
            }
            if (data is PaypalPaymentRequestModel)
            {
                var s = data as PaypalPaymentRequestModel;
                if (s.CheckoutType == CheckOutTypes.Bundle)
                {
                    return RedirectToAction("BundleError", "Home", new BundleTransactionModel()
                    {
                        Amount = s.TopUpAmount.ToString(),
                        From = s.Msisdn,
                        Origin = s.FromBundleISO2,
                        Payment = PaymentMethodTypes.Paypal.ToString(),
                        Destination = s.ToBundleISO2,
                        AutoRenew = false,
                        Type = s.BundleType.ToString(),
                    });
                }
                else if (s.CheckoutType == CheckOutTypes.TopUp)
                {
                    return RedirectToAction("TopupError", "Home", new TopupTransactionModel()
                    {
                        Amount = s.TopUpAmount.ToString(),
                        From = s.Msisdn,
                        //Origin = s.FromBundleISO2,
                        Payment = PaymentMethodTypes.Paypal.ToString(),
                        AutoTopup = false,
                        Id= "-1"
                    });
                }

            }
            if (data is TransferByCardResponseModel || data is TransferByPayPalResponseModel)
            {
                return RedirectToAction("MobileTopupError", "Home", new MobileTopupTransactionModel()
                {
                    Amount = data.productData.CustomerChargeValue,
                    From = data.productData.fromMsisdn,
                    Payment = data is TransferByCardResponseModel ? PaymentMethodTypes.Card.ToString() : PaymentMethodTypes.Paypal.ToString(),
                    Network = data.productData.operatorName.Trim().Replace(" ", "-"),
                    To = data.productData.tomsisdn,
                    Destination = _helperService.GetCountryCode(data.productData.tomsisdn),
                    Origin = _helperService.GetCountryCode(data.productData.fromMsisdn),
                    Id = data.productData.GUID
                });
            }

            return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError".ToLower() });
        }
    }
}