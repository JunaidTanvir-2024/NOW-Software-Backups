﻿using System;
using System.Collections.Generic;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class DeleteAccountViewModel
    {
        public List<DeleteAccountReason> DeleteAccountReasons { get; set; } = new List<DeleteAccountReason>();
        public int[] SeletedAccountReasons { get; set; } = Array.Empty<int>();
        public string Comments { set; get; }
    }
}
