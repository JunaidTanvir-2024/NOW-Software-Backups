﻿using System.Text.Json.Serialization;

namespace Voucherify.Api.Features.Vouchers.Responses;

public class VoucherValidationResponse
{
    public bool IsValid { get; set; }

    public string? VoucherCode { get; set; }
}
