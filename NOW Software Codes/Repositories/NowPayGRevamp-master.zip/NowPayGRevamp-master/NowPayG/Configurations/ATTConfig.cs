﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Configurations
{
    public class ATTConfig
    {
        public string ApiEndPoint { get; set; }
    }
}
