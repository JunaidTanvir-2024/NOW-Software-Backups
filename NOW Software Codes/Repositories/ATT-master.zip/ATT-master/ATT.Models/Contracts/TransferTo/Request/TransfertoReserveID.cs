﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Request
{
    public class TransfertoReserveID : TransfertoBaseRequest
    {
        public string action = "reserve_id";

        public string toXML()
        {
            return "<TransferTo>" + base.toXML() + $"<action>{action}</action></TransferTo>";
        }
    }
}
