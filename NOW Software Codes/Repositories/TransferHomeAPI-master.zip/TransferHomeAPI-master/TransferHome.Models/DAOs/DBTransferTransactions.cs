﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.DAOs
{
    public class DBTransferTransactions
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public TransferTransactionType TransactionTypeId { get; set; }
        public TransferTransactionStatus StatusId { get; set; }
        public PaymentType PaymentTypeId { get; set; }
        public string OperatorId { get; set; }
        public int ServiceProviderId { get; set; }
        public string NowtelTransactionReference { get; set; }

        public string FromMsisdn { get; set; }
        public string ToMsisdn { get; set; }

        public string ClientCurrecny { get; set; }
        public string ReceiverCurrecny { get; set; }
        public decimal Product { get; set; }
        public decimal ItemPrice { get; set; }
        public decimal TransactionFee { get; set; }
        public decimal TotalPrice { get; set; }
        public string OperatorName { get; set; }
        public string OperatorLogoUrl { get; set; }
        public string OperatorCountryName { get; set; }
        public string CountryCode { get; set; }

        public string ExecuteReferenceNumber { get; set; }
    }
}
