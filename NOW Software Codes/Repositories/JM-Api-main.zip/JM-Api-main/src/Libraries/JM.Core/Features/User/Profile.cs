using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;

using RW;

namespace JM.Core.Features.User;

public abstract class Profile
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public string? FullName { get; set; }
        public IFormFile? ProfilePhoto { get; set; }
        public long CountryId { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.FullName).NotNull().NotEmpty();
            RuleFor(x => x.CountryId).NotNull().GreaterThan(0);
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public required long Id { get; set; }
        public required string Email { get; set; }
        public required string Username { get; set; }
        public string? FullName { get; set; }
        public string? ProfilePhoto { get; set; }
        public required CountryInfo Country { get; set; }
        public record CountryInfo
        {
            public required long Id { get; set; }
            public required string Name { get; set; }
            public required string IsoCode3 { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IHttpContextAccessor contextAccessor, IWebHostEnvironment webHostEnvironment) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IHttpContextAccessor _contextAccessor = contextAccessor;
        private readonly IWebHostEnvironment _webHostEnvironment = webHostEnvironment;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var userEmail = _contextAccessor.HttpContext?.User.GetEmail();

            if (!string.IsNullOrEmpty(userEmail))
            {
                var user = await _unitOfWork.UserRepository.GetUser(x => x.NormalizedEmail!.Equals(userEmail!.ToUpperInvariant()));

                var userProfilePicture = query.ProfilePhoto is not null ? await query.ProfilePhoto.SaveProfilePicture(user!.Id, _webHostEnvironment) : null!;

                if (user?.UserDetail is null)
                {
                    var newlyAddedUser = await _unitOfWork.UserRepository.AddUserDetail(new Entities.UserDetail()
                    {
                        UserId = user!.Id,
                        CountryId = query.CountryId,
                        FullName = query.FullName,
                        ProfilePhoto = userProfilePicture
                    });
                    _unitOfWork.SaveChanges();

                    return ResultWrapper.Success(new Response()
                    {
                        Email = user?.Email!,
                        FullName = newlyAddedUser?.FullName,
                        Id = user!.Id,
                        ProfilePhoto = newlyAddedUser?.ProfilePhoto,
                        Username = user?.UserName!,
                        Country = new Response.CountryInfo()
                        {
                            Id = newlyAddedUser?.Country?.Id ?? default,
                            IsoCode3 = newlyAddedUser?.Country?.IsoCode3!,
                            Name = newlyAddedUser?.Country?.Name!
                        },
                    });
                }
                user.UserDetail!.FullName = !string.IsNullOrEmpty(query.FullName) ? query.FullName : user.UserDetail.FullName;
                user.UserDetail!.ProfilePhoto = !string.IsNullOrEmpty(userProfilePicture) ? userProfilePicture : user.UserDetail.ProfilePhoto;
                user.UserDetail.CountryId = query.CountryId > 0 ? query.CountryId : user.UserDetail.CountryId;

                var updatedUserDetail = _unitOfWork.UserRepository.UpdateUserDetail(user.UserDetail);
                _unitOfWork.SaveChanges();

                var country = await _unitOfWork.CountryRepository.GetCountry(x => x.Id == updatedUserDetail!.CountryId);

                return ResultWrapper.Success(new Response()
                {
                    Email = user?.Email!,
                    FullName = updatedUserDetail?.FullName!,
                    Id = user!.Id,
                    ProfilePhoto = updatedUserDetail?.ProfilePhoto!,
                    Username = user?.UserName!,
                    Country = new Response.CountryInfo()
                    {
                        Id = country!.Id,
                        IsoCode3 = country?.IsoCode3!,
                        Name = country?.Name!
                    },
                });
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
    }
    #endregion
}
