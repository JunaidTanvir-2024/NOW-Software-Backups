﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Reloadly.Response
{
    public class ReloadlyOperatorResponse
    {
        public int operatorId { get; set; }
        public string name { get; set; }
        public bool bundle { get; set; }
        public bool data { get; set; }
        public bool pin { get; set; }
        public bool supportsLocalAmounts { get; set; }
        public string denominationType { get; set; }
        public string senderCurrencyCode { get; set; }
        public string senderCurrencySymbol { get; set; }
        public string destinationCurrencyCode { get; set; }
        public string destinationCurrencySymbol { get; set; }
        public decimal commission { get; set; }
        public decimal internationalDiscount { get; set; }
        public decimal localDiscount { get; set; }
        public decimal mostPopularAmount { get; set; }
        public decimal? mostPopularLocalAmount { get; set; }
        public decimal? minAmount { get; set; }
        public decimal? maxAmount { get; set; }
        public decimal? localMinAmount { get; set; }
        public decimal? localMaxAmount { get; set; }
        public Country country { get; set; }
        public fx fx { get; set; }
        public string[] logoUrls { get; set; }
        public decimal[] fixedAmounts { get; set; }
        public object fixedAmountsDescriptions { get; set; }
        public decimal[] localFixedAmounts { get; set; }
        public decimal[] suggestedAmounts { get; set; }
        public object suggestedAmountsMap { get; set; }
        public object promotions { get; set; }
    }

    public class Country
    {
        public string isoName { get; set; }
        public string name { get; set; }
    }

    public class fx
    {
        public decimal rate { get; set; }
        public string currencyCode { get; set; }
    }


}
